#ifndef TMATRIX_H__
#define TMATRIX_H__

#include <Const.h>
#include <Rvector3.h>
#include <Tarray.h>
#include <Dotfpu.h>

namespace Maverick
{
    /// Tmatrix.
    /// The ::Maverick library shall provide the capability to manage Matrices from Maverick::Tarray.
    template <class T>
    class Tmatrix: public Tarray<T>
    {
    public:
        /// Helper class to apply givens rotations.
        struct Givens_rotation
        {
            inline Givens_rotation(const T c0, const T s0) : c(c0), s(s0)
            {
            }

            static Givens_rotation make_givens(const T x,
                                               const T y,
                                               const T eps);

            inline static Givens_rotation make_transposed(const Givens_rotation& in)
            {
                return Givens_rotation(in.c, -in.s);
            }

            const T c; ///< Cosine
            const T s; ///< Sine
        };

        /// Tmatrix Constructor with Given Parameters.
        /// \wi{3108}
        /// Tmatrix class shall build itself upon construction with a specific number of rows and columns 
        /// and a memory type.
        /// \param[in] r        Number of rows.
        /// \param[in] c        Number of columns.
        /// \param[in] memtype  Memory type.
        Tmatrix(Uint16 r,
                Uint16 c,
                Base::Memmgr::Type memtype);
        /// Tmatrix Constructor with Given Parameters.
        /// \wi{18228}
        /// Tmatrix class shall build itself upon construction with a pointer to the first Matrix element and 
        /// specific number of rows and columns.
        /// \param[in] v0       Pointer to first Matrix element.
        /// \param[in] r        Number of rows.
        /// \param[in] c        Number of columns.
        Tmatrix(T* v0,
                Uint16 r,
                Uint16 c);
        
        /// Tmatrix Constructor with Given Parameters.
        /// \wi{18229}
        /// Tmatrix class shall build itself upon construction with a specific number of rows and columns and 
        /// an allocator.
        /// \param[in] r        Number of rows.
        /// \param[in] c        Number of columns.
        /// \param[in] alloc    Memory allocation.
        Tmatrix(Uint16 r,
                Uint16 c,
                Base::Allocator& alloc);

        /// Rows Number Retriever.
        /// \wi{6641}
        /// Tmatrix class shall be able to retrieve its internal number of rows.
        /// \return Number of rows.
        Uint16 rows()const;
        /// Columns Number Retriever.
        /// \wi{3265}
        /// Tmatrix class shall be able to retrieve its internal number of columns.
        /// \return Number of columns.
        Uint16 cols()const;

        /// Matrix Resizer.
        /// \wi{3127}
        /// Tmatrix class shall provide the capability to resize its internal Matrix.
        /// \param[in] nr0      New number of rows.
        /// \param[in] nc0      New number of columns.
        /// \return True if the resize was successful, false otherwise.
        bool resize_mat(Uint16 nr0, Uint16 nc0);

        /// Constant Matrix Element Retriever.
        /// \wi{17563}
        /// Tmatrix class shall provide the capability to obtain a constant reference to the element corresponding 
        /// to the given row and column.
        /// \param[in] i Row number (first row is zero).
        /// \param[in] j Column number (first column is zero).
        /// \return Constant Matrix element.
        const T& get_ij(Uint32 i,Uint32 j)const;

        /// Matrix Element Retriever.
        /// \wi{17564}
        /// Tmatrix class shall provide the capability to obtain a reference to the element corresponding to
        /// the given row and column.
        /// \param[in] i        Row number (first row is zero).
        /// \param[in] j        Column number (first column is zero).
        /// \return Matrix element.
        T& get_ij(Uint32 i,Uint32 j);

        /// Matrix Element Addition.
        /// \wi{3266}
        /// Tmatrix class shall provide the capability to add a value to an element of the Matrix.
        /// \param[in] i        Row number (first row is zero).
        /// \param[in] j        Column number (first column is zero).
        /// \param[in] a        Value to be added.
        void element_add(Uint32 i,
                         Uint32 j,
                         typename Base::JSF116_param<T>::type a);

        /// Matrix Element Setter.
        /// \wi{3267}
        /// Tmatrix class shall provide the capability to set a value to an element of the Matrix.
        /// \param[in] i        Row number (first row is zero).
        /// \param[in] j        Column number (first column is zero).
        /// \param[in] a        Value to be set.
        void set(Uint32 i,
                 Uint32 j,
                 typename Base::JSF116_param<T>::type a);

        void expand(const Uint16 extra_r, const Uint16 extra_c);

        /// Matrix Column Reference Retriever.
        /// \wi{3264}
        /// Tmatrix class shall be able to retrieve the reference of a given column the Matrix.
        /// \param[in] c        Column number.
        /// \return Reference to the begining of the given column number.
        T* colref(Uint16 c)const;

        /// Identity Matrix Setter.
        /// \wi{3125}
        /// Tmatrix class shall provide the capability to set the Matrix to the identity Matrix.
        void eye();
        /// Diagonal Elements Setter.
        /// \wi{3129}
        /// Tmatrix class shall provide the capability to set the elements in the diagonal of the Matrix.
        /// \param[in] d0       Constant values to be set.
        void set_diag(const T* d0);
        /// Matrix Diagonal Addition.
        /// \wi{3130}
        /// Tmatrix class shall provide the capability to add the diagonal of the given Matrix.
        /// \param[in] q0       Diagonal constant Matrix to be added.
        void add_diag(const Tmatrix<T>& q0);
        /// Two Vector Multiplication Computer.
        /// \wi{3131}
        /// Tmatrix class shall provide the capability to multiply two given vectors.
        /// \param[in] x        Column Vector.
        /// \param[in] y        Row Vector.
        void vecvect(const Tarray<T>& x, const Tarray<T>& y);
        /// Two Matrix Multiplication Computer.
        /// \wi{3126}
        /// Tmatrix class shall provide the capability to multiply two NxN Matrices.
        /// \param[in] a0       First Matrix (this!=a0).
        /// \param[in] b0       Second Matrix (this!=b0).
        void matmat(const Tmatrix<T>& a0, const Tmatrix<T>& b0);
        /// Transposed Matrix - Matrix Multiplication Computer.
        /// \wi{3268}
        /// Tmatrix class shall provide the capability to multiply two NxN Matrices, where the first matrix 
        /// is transposed.
        /// \param[in] a0       First Matrix (this!=a0).
        /// \param[in] b0       Second Matrix (this!=b0).
        void matTmat(const Tmatrix<T>& a0, const Tmatrix<T>& b0);

        /// Matrix - Transposed Matrix Multiplication Computer.
        /// \wi{18230}
        /// Tmatrix class shall provide the capability to multiply two NxN Matrices, where the second matrix 
        /// is transposed.
        /// \param[in] a0       First Matrix (this!=a0).
        /// \param[in] b0       Second Matrix (this!=b0).
        void matmatT(const Tmatrix<T>& a0, const Tmatrix<T>& b0);


        /// Diagonal Matrix Multiplication Computer.
        /// \wi{17973}
        /// Tmatrix class shall provide the capability to multiply a diagonal matrix represented as an array of its
        /// diagonal values and another matrix.
        /// \param[in] diag0    Diagonal matrix represented as a vector of its diagonal elements.
        /// \param[in] a0       Matrix to be multiplied.
        void diagmat(const Tarray<T>& diag0, const Tmatrix<T>& a0);

        void matdiag(const Tmatrix<T>& a0, const Tarray<T>& diag0);

        /// Diagonal Transposed Matrix Multiplication Computer.
        /// \wi{18268}
        /// Tmatrix class shall provide the capability to multiply a transposed matrix by a diagonal matrix, 
        /// represented as an array of its diagonal values, and by another matrix.
        /// \param[in] a0       First matrix to multiply which is transposed.
        /// \param[in] diag0    Diagonal matrix represented as a vector of its diagonal elements.
        /// \param[in] b0       Second matrix to multiply.
        void matTdiagmat(const Tmatrix<T>& a0, const Tarray<T>& diag0, const Tmatrix<T>& b0);

        /// Matrix Row Dot Product Computer.
        /// \wi{6640}
        /// Tmatrix class shall provide the capability to compute the dot product between a selected row of the 
        /// Matrix and a given vector.
        /// \param[in] k        Row number.
        /// \param[in] y1       Constant Vector to multiply.
        /// \return Row dot product value.
        T rowdot(Uint16 k, const Base::Array<T>& y1) const;
        /// Matrix Column Dot Product Computer.
        /// \wi{18231}
        /// Tmatrix class shall provide the capability to compute the dot product between a selected column of the 
        /// Matrix and a given vector.
        /// \param[in] k        Column number.
        /// \param[in] y1       Constant Vector to multiply.
        /// \return Column dot product value.
        T coldot(Uint16 c, const Base::Array<T>& y1) const;

        /// Diagonal Matrix Product
        /// \wi{18232}
        /// Tmatrix class shall provide the capability to compute the left and right product by two given diagonal 
        /// matrices for its Matrix (this=dl*this*dr).
        /// \param[in] dl       Left diagonal matrix represented as an Array.
        /// \param[in] dr       Right diagonal matrix represented as an Array.
        void diagthisdiag(const Base::Array<T>& dl, const Base::Array<T>& dr);

        /// Cholesky Decomposition Computer.
        /// \wi{2977}
        /// The Tmatrix class shall provide a method to compute the Cholesky decomposition for its managed matrix,
        /// replacing the managed matrix by the lower triangular result of the decomposition (A = L*L').
        /// \return True if Cholesky decomposition was successful.
        bool cholesky_decomp();

        /// Cholesky Solver.
        /// \wi{2986}
        /// Tmatrix class shall provide the capability to solve a system of linear equations using the Cholesky 
        /// decomposition.
        /// \param[in] b        Right-hand side Vector.
        /// \param[out] x       Solution Vector.
        void cholesky_solve(const Tarray<T>& b, Tarray<T>& x)const;

        /// Lower Triangula Matrix Inverter.
        /// \wi{18233}
        /// Tmatrix class shall provide the capability to invert a lower triangular matrix, this method computes 
        /// its inverse with the forward substitution method. This can be used to compute the inverse of a
        /// Cholesky decomposed matrix.
        /// \param[out] inv     Inverted Matrix.
        void lower_triangular_inverse(Tmatrix<T>& inv) const;

        void upper_triangular_backsolve(const Tarray<T>& b, Tarray<T>& x) const;

        void transpose();

        void remove_column(const Uint16 c);

        void remove_row(const Uint16 r);

        void apply_left_givens_rotation(const Givens_rotation& g,
                                        const Uint16 i,
                                        const Uint16 j);

        void apply_right_givens_rotation(const Givens_rotation& g,
                                         const Uint16 i,
                                         const Uint16 j);

    protected:
        Uint16 nr;              ///< Number of Matrix rows.
        Uint16 nc;              ///< Number of Matrix columns.

        /// Sub-Matrix Assembler.
        /// \wi{18234}
        /// Tmatrix class shall provide the capability to assemble a sub-matrix into its Matrix.
        /// \param[in] i0       Starting row number.
        /// \param[in] j0       Starting column number.
        /// \param[in] p0       Sub-matrix to be assembled.
        template <Uint32 p0rows, Uint32 p0cols>
        void assemble_ij(Uint16 i0,
                         Uint16 j0,
                         const T* p0);
    private:
        Tmatrix();                                 ///< = delete
        Tmatrix(const Tmatrix& src);               ///< = delete
        Tmatrix& operator=(const Tmatrix& src);    ///< = delete
    };

    /// Transposed Matrix - Matrix Multiplication Computer.
    /// \wi{3080}
    /// Maverick library shall provide the capability to multiply two NxN Matrices, where the first matrix 
    /// is transposed.
    /// \param[in] a0       First Matrix.
    /// \param[in] b0       Second Matrix.
    /// \param[out] v       Computed Matrix.
    void rmatrix_matTmat(const Tmatrix<Real>& a0,
                         const Tmatrix<Real>& b0,
                         Tmatrix<Real>& v);

    /// Cholesky Decomposition Computer.
    /// \wi{3286}
    /// Maverick library shall provide the capability to compute the Cholesky decomposition for the given Matrix.
    /// \param[in] M Matrix to compute the Cholesky decomposition.
    /// \return True if Cholesky decomposition was successful.
    bool rmatrix_cholesky_decomp(Tmatrix<Real>& M);

    /// Cholesky Solver.
    /// \wi{3287}
    /// Maverick library shall provide the capability to solve a system of linear equations using the Cholesky 
    /// decomposition.
    /// \param[in] b        Right-hand side Vector.
    /// \param[out] x       Solution Vector.
    /// \param[in] M        Positive-definite symmetric Matrix whose Cholesky decomposition has been precomputed.
    void rmatrix_cholesky_solve(const Tarray<Real>& b, Tarray<Real>& x, const Tmatrix<Real>& M);

    template <class T>
    Tmatrix<T>::Tmatrix(Uint16 r,
                        Uint16 c,
                        Base::Memmgr::Type memtype):
        Tarray<T>(static_cast<Uint32>(r*c),memtype),
        nr(r),
        nc(c)
    {
    }

    template <class T>
    Tmatrix<T>::Tmatrix(T* v0,
                        Uint16 r,
                        Uint16 c):
        Tarray<T>(v0,static_cast<Uint32>(r*c)),
        nr(r),
        nc(c)
    {
    }

    template <class T>
    Tmatrix<T>::Tmatrix(Uint16 r,
                        Uint16 c,
                        Base::Allocator& alloc) :
        Tarray<T>(r*c, alloc),
        nr(r),
        nc(c)
    {
    }

    template <class T>
    inline Uint16 Tmatrix<T>::rows()const
    {
        /// \alg
        /// - Return ::nr.
        return nr;
    }

    template <class T>
    inline Uint16 Tmatrix<T>::cols()const
    {
        /// \alg
        /// - Return ::nr.
        return nc;
    }

    template <class T>
    bool Tmatrix<T>::resize_mat(Uint16 nr0, Uint16 nc0)
    {
        /// \alg
        /// <ul>
        /// <li> Set the number of rows and columns to given values.
        Tmatrix<T>::nr = nr0;
        Tmatrix<T>::nc = nc0;

        /// <li> Call Array<T>::resize for the total numbers of elements in the resized matrix (number of rows times
        /// the number of columns), storing the result in the local "ret" variable.
        const bool ret = Base::Array<T>::resize(nr0*nc0);

        /// <li> IF "ret" is false THEN:
        if (!ret)
        {
            /// <ul>
            /// <li> IF number of rows greater than number of columns:
            if (nr > nc)
            {
                /// <ul>
                /// <li> Set ::nr as the resized Array length divided by ::nc.
                nr = static_cast<Uint16>(Base::Array<T>::n) / nc;
                /// </ul>
            }
            /// <li> ELSE
            else
            {
                /// <ul>
                /// <li> Set ::nc as the resized Array length divided by ::nr.
                nc = static_cast<Uint16>(Base::Array<T>::n) / nr;
                /// </ul>
            }
            /// </ul>
        }
        /// <li> Return the "ret" variable.
        return ret;
        /// </ul>
    }

    template <class T>
    inline const T& Tmatrix<T>::get_ij(Uint32 i,Uint32 j)const
    {
        /// \alg
        /// - Return constant Matrix element for the given row and column values.
        return Base::Array<T>::v[nr*j+i];
    }

    template <class T>
    inline T& Tmatrix<T>::get_ij(Uint32 i,Uint32 j)
    {
        /// \alg
        /// - Return Matrix element for the given row and column values.
        return Base::Array<T>::v[nr*j+i];
    }

    template <class T>
    inline void Tmatrix<T>::element_add(Uint32 i,
                            Uint32 j,
                            typename Base::JSF116_param<T>::type a)
    {
        /// \alg
        /// - Add the value to the Matrix element for the given row and column values.
        Base::Array<T>::v[nr*j+i]+=a;
    }

    template <class T>
    inline void Tmatrix<T>::set(Uint32 i,
                    Uint32 j,
                    typename Base::JSF116_param<T>::type a)
    {
        /// \alg
        /// - Set the given value to the Matrix element for the given row and column values.
        Base::Array<T>::v[nr*j+i]=a;
    }

    template <class T>
    void Tmatrix<T>::expand(const Uint16 extra_r, const Uint16 extra_c)
    {
        const Uint16 prev_nr = nr;
        const Uint16 prev_nc = nc;
        if (resize_mat(prev_nr + extra_r, prev_nc + extra_c))
        {
            int16 c = static_cast<int16>(nc) - 1;
            while (c >= static_cast<int16>(prev_nc))
            {
                Base::Tmem::set_sel(&Base::Array<T>::v[nr*c], 0U, (sizeof(T))*nr);
                --c;
            }
            while (c >= 0)
            {
                Base::Tmem::set_sel(&Base::Array<T>::v[prev_nr + (nr*c)], 0U, (sizeof(T))*extra_r);
                Base::Tmem::move(&Base::Array<T>::v[nr*c], &Base::Array<T>::v[prev_nr*c], (sizeof(T))*prev_nr);
                --c;
            }
        }
    }

    template <class T>
    inline T* Tmatrix<T>::colref(Uint16 c)const
    {
        /// \alg
        /// - Return Matrix reference to first column for the given value.
        return &Base::Array<T>::v[nr*c];
    }

    template <class T>
    void Tmatrix<T>::eye()
    {
        /// \alg
        /// <ul>
        /// <li> Call Array<T>::zeros.
        Base::Array<T>::zeros();
        /// <li> Set end pointer of the Matrix according to the rows and columns number.
        T* endptr = (nr >= nc) ? (Base::Array<T>::vz) : (Base::Array<T>::v + (nr*nr - 1));
        /// <li> Iterate over the elements of the diagonal.
        for(T* p = Base::Array<T>::v; p <= endptr; p += (nr + 1) )
        {
            /// <ul>
            /// <li> Set the corresponding Matrix element to 1.
            *p = static_cast<T>(1);
            /// </ul>
        }
        /// </ul>
    }

    template <class T>
    void Tmatrix<T>::set_diag(const T* d0)
    {
        /// \alg
        /// <ul>
        /// <li> Call Array<T>::zeros.
        Base::Array<T>::zeros();
        const T* d = d0;
        /// <li> Iterate over the elements of the diagonal.
        for(T* p =  Base::Array<T>::v; p<=Base::Array<T>::vz; p+=(nr+1))
        {
            /// <ul>
            /// <li> Set the corresponding Matrix element to the corresponding given array element.
            *p=*d;
            /// <li> Increment pointers to move to the next element of the given array.
            d++;
            /// </ul>
        }
        /// <ul>
    }

    template <class T>
    void Tmatrix<T>::add_diag(const Tmatrix<T>& q0)
    {
        /// \alg
        /// <ul>
        const T* q=q0.Base::Array<T>::v;
        /// <li> Iterate over the elements of the diagonal.
        for(T* p=Base::Array<T>::v; p<=Base::Array<T>::vz; p+=(nr+1),q+=(nr+1))
        {
            /// <ul>
            /// <li> Add the corresponding given array element to the corresponding Matrix element.
            (*p)+=(*q);
            /// </ul>
        }
        /// </ul>
    }

    template <class T>
    template <Uint32 p0rows, Uint32 p0cols>
    void Tmatrix<T>::assemble_ij(Uint16 i0,
                                 Uint16 j0,
                                 const T* p)
    {
        // Assumes p is a matrix of p0rows rows and p0cols cols and access is column major.
        /// \alg
        /// <ul>
        /// <li> Get pointer to the first element where the sub-matrix starts.
        T* q = &Base::Array<T>::v[nr*j0+i0];
        /// <li> Get pointer to the last element where the sub-matrix ends.
        const T* const pz = &p[p0rows*p0cols-1];
        /// <li> Iterate over each element of the sub-matrix.
        while(p<=pz)
        {
            /// <ul>
            /// <li> Copy the corresponding element to the Matrix.
            Base::Tmem::cpy<p0rows*sizeof(T)>(q,p);
            /// <li> Increment pointers to move to the next elements of the Matrix and given sub-matrix.
            q+=nr;
            p+=p0rows;
            /// </ul>
        }
        /// </ul>
    }

    template <class T>
    void Tmatrix<T>::vecvect(const Tarray<T>& x, const Tarray<T>& y)
    {
        /// \alg
        /// <ul>
        const T* pA = &x[0];
        T* p = Base::Array<T>::v;
        /// <li> Iterate over each row of the Matrix.
        for(Uint16 i = 0; i<Tmatrix<T>::nr; i++ )
        {
            /// <ul>
            const T* pB = &y[0];
            /// <li> Iterate over each column of the Matrix.
            for(Uint16 j = 0; j<Tmatrix<T>::nc; j++ )
            {
                /// <ul>
                /// <li> Compute the product of the corresponding elements of the given Arrays.
                (*p) = (*pA)*(*pB);
                /// <li> Increment pointers to move to the next elements of the Matrix and the second given array.
                p++;
                pB++;
                /// </ul>
            }
            /// <li> Increment pointer to move to the next element of the first given Arrays.
            pA++;
            /// </ul>
        }
        /// </ul>
    }

    template <class T>
    void Tmatrix<T>::matmat(const Tmatrix<T>& a0, const Tmatrix<T>& b0)
    {
        /// \alg
        /// <ul>
        /// <li> Set initial pointers to 0 for its Matrix and the two given Matrices.
        const T* pA=0;
        const T* pB=0;
        T* p=0;
        /// <li> Iterate over each row of the Matrix.
        for( Uint16 i = 0; i<Tmatrix<T>::nr; i++ )
        {
            /// <ul>
            /// <li> Set second Matrix pointer to its first element.
            pB = b0.Base::Array<T>::v;
            /// <li> Set its Matrix pointer to its first element plus the corrisponding row iteration.
            p = Base::Array<T>::v + i;
            /// <li> Iterate over each column of the Matrix.
            for( Uint16 j = 0; j<Tmatrix<T>::nc; j++ )
            {
                /// <ul>
                /// <li> Set first Matrix pointer to its first element plus the corrisponding row iteration.
                pA = a0.Base::Array<T>::v + i;
                /// <li> Set 0 for the current element of the Matrix
                (*p) = 0.0;
                /// <li> Iterate over each column of the first given Matrix.
                for( Uint16 k = 0; k<a0.Tmatrix<T>::nc; k++)
                {
                    /// <ul>
                    /// <li> Compute the sum of products between the corresponding elements of the given Matrices.
                    (*p) += (*pA)*(*pB);
                    /// <li> Increment pointer by the number of rows for the first given Matrix.
                    pA += Tmatrix<T>::nr;
                    /// <li> Increment pointer by 1 for second given Matrix.
                    pB++;
                    /// </ul>
                }
                /// <li> Increment pointer by ::nr for its Matrix.
                p += nr;
                /// </ul>
            }
            /// </ul>
        }
        /// </ul>
    }

    template <class T>
    void Tmatrix<T>::matTmat(const Tmatrix<T>& a0, const Tmatrix<T>& b0)
    {
        /// \alg
        /// <ul>
        /// <li> Set initial pointers to 0 for its Matrix and the two given Matrices.
        const T* pA=0;
        const T* pB=0;
        T* p=0;
        /// <li> Iterate over each row of its Matrix.
        for(Uint16 i = 0; i<Tmatrix<T>::nr; i++ )
        {
            /// <ul>
            /// <li> Set second Matrix pointer to its first element.
            pB = b0.Base::Array<T>::v;
            /// <li> Set its Matrix pointer to its first element plus the corrisponding row iteration.
            p = Base::Array<T>::v + i;
            /// <li> Iterate over each column of its Matrix.
            for(Uint16 j = 0; j<Tmatrix<T>::nc; j++ )
            {
                /// <ul>
                /// <li> Set first Matrix pointer to its first element plus the corrisponding row iteration.
                pA = a0.Base::Array<T>::v + i;
                /// <li> Set 0 for the current element of the Matrix.
                (*p) = 0.0;
                /// <li> Iterate over each column of the first given Matrix.
                for(Uint16 k = 0; k<a0.Tmatrix<T>::nc; k++, pA++, pB++ )
                {
                    /// <ul>
                    /// <li> Compute the sum of products between the corresponding elements of the given Matrices.
                    (*p) += (*pA)*(*pB);
                    /// </ul>
                }
                /// <li> Increment pointer by ::nr for its Matrix.
                p += nr;
                /// </ul>
            }
            /// </ul>
        }
        /// </ul>
    }

    template<class T>
    void Tmatrix<T>::matmatT(const Tmatrix<T>& a0, const Tmatrix<T>& b0)
    {
        /// \alg
        /// <ul>
        /// <li> Set initial pointers to 0 for its Matrix and the two given Matrices.
        const T* pA = 0;
        const T* pB = 0;
        T* p = 0;
        /// <li> Iterate over each row of its Matrix.
        for (Uint16 i = 0U; i < Tmatrix<T>::nr; i++)
        {
            /// <ul>
            /// <li> Set its Matrix pointer to its first element plus the corrisponding row iteration.
            p = Base::Array<T>::v + i;
            /// <li> Iterate over each column of its Matrix.
            for (Uint16 j = 0U; j < Tmatrix<T>::nc; j++)
            {
                /// <ul>
                /// <li> Set first Matrix pointer to its first element plus the corrisponding row iteration.
                pA = a0.Base::Array<T>::v + i;
                /// <li> Set second Matrix pointer to its first element plus the corrisponding column iteration.
                pB = b0.Base::Array<T>::v + j;
                /// <li> Set 0 for the current element of the Matrix.
                (*p) = 0.0;
                for (Uint16 k = 0U; k < a0.Tmatrix<T>::nc; k++)
                {
                    /// <ul>
                    /// <li> Compute the sum of products between the corresponding elements of the given Matrices.
                    (*p) += (*pA) * (*pB);
                    /// <li> Increment pointer by the number of rows for the first given Matrix.
                    pA += a0.Tmatrix<T>::nr;
                    /// <li> Increment pointer by the number of rows for the second given Matrix.
                    pB += b0.Tmatrix<T>::nr;
                    /// </ul>
                }
                /// <li> Increment pointer by ::nr for its Matrix.
                p += nr;
                /// </ul>
            }
            /// </ul>
        }
        /// </ul>
    }

    template <>
    inline void Tmatrix<Real>::matTmat(const Tmatrix<Real>& a0, const Tmatrix<Real>& b0)
    {
        /// \alg
        /// - Call Maverick::rmatrix_matTmat for this method and the given Matrices.
        rmatrix_matTmat(a0, b0, *this);
    }

    template <class T>
    void Tmatrix<T>::diagmat(const Tarray<T>& diag0, const Tmatrix<T>& a0)
    {
        const T* const d=&diag0[0];
        /// \alg
        /// <ul>
        /// <li> Iterate over ::nr.
        for (Uint16 r = 0U; r < nr; ++r)
        {
            /// <ul>
            /// <li> Iterate over ::nc.
            for (Uint16 c = 0U; c < nc; ++c)
            {
                /// <ul>
                /// <li> Set value by the product of the corresponding elements between the given diagonal Vector 
                /// and the given Matrix.
                Base::Array<T>::v[r + (nr*c)] = d[r] * a0.get_ij(r, c);
                /// </ul>
            }
            /// </ul>
        }
        /// </ul>
    }

    template <class T>
    void Tmatrix<T>::matdiag(const Tmatrix<T>& a0, const Tarray<T>& diag0)
    {
        const T* const d=&diag0[0];
        for (Uint16 r = 0U; r < nr; ++r)
        {
            for (Uint16 c = 0U; c < nc; ++c)
            {
                Base::Array<T>::v[r + (nr*c)] = d[c] * a0.get_ij(r, c);
            }
        }
    }

    template <class T>
    void Tmatrix<T>::matTdiagmat(const Tmatrix<T>& a0, const Tarray<T>& diag0, const Tmatrix<T>& b0)
    {
        /// \alg
        /// <ul>
        /// <li> Set initial pointers to 0 for its Matrix and the two given Matrices.
        const T* pA=0;
        const T* pB=0;
        const T* const d=&diag0[0];
        T* p=0;
        /// <li> Iterate over each row of its Matrix.
        for(Uint16 i = 0; i<Tmatrix<T>::nr; i++ )
        {
            /// <ul>
            /// <li> Set second Matrix pointer to its first element.
            pB = b0.Base::Array<T>::v;
            /// <li> Set its Matrix pointer to its first element plus the corresponding row iteration.
            p = Base::Array<T>::v + i;
            /// <li> Iterate over each column of its Matrix.
            for(Uint16 j = 0; j<Tmatrix<T>::nc; j++ )
            {
                /// <ul>
                /// <li> Set first Matrix pointer to its first element plus the corresponding row iteration.
                pA = a0.Base::Array<T>::v + i;
                /// <li> Set 0 for the current element of its Matrix.
                (*p) = 0.0;
                /// <li> Iterate over each column of the first given Matrix.
                for(Uint16 k = 0; k<a0.Tmatrix<T>::nc; k++, pA++, pB++ )
                {
                    /// <ul>
                    /// <li> Compute the sum of products between the corresponding elements of the given Matrices 
                    /// and the given diagonal Vector.
                    (*p) += (*pA) * d[k] * (*pB);
                    /// </ul>
                }
                /// <li> Increment pointer by ::nr for its Matrix.
                p += nr;
                /// </ul>
            }
            /// </ul>
        }
        /// </ul>
    }

    template <class T>
    T Tmatrix<T>::rowdot(Uint16 k, const Base::Array<T>& y1) const
    {
        /// \alg
        /// <ul>
        /// <li> Set initial value to 0.
        T s = 0;
        /// <li> Set initial pointer to the given row.
        const T* p=&Base::Array<T>::v[k];
        /// <li> Iterate over each element of given vector.
        for(const T* p1=&y1[0]; p<=Base::Array<T>::vz; p1++) //PRQA S 4231 #variable not set in initialization
        {
            /// <ul>
            /// <li> Compute the sum of products between the Matrix and the Vector elements.
            s += (*p)*(*p1);
            /// <li> Increment pointer by ::nr for its Matrix.
            p += nr;
            /// </ul>
        }
        /// <li> Return computed value.
        return s;
        /// </ul>
    }

    template <>
    inline Real Tmatrix<Real>::coldot(Uint16 c, const Base::Array<Real>& y1) const
    {
        /// \alg
        /// - Return retreived value by Maverik::dot_fpu for the number of rows and the given column reference 
        /// and given Vector.
        return dot_fpu(this->colref(c), &y1[0], nr);
    }



    template <class T>
    void Tmatrix<T>::diagthisdiag(const Base::Array<T>& dl, const Base::Array<T>& dr)
    {
        /// \alg
        /// <ul>
        /// <li> Iterate over ::nr.
        for (Uint16 r = 0U; r < nr; ++r)
        {
            /// <ul>
            /// <li> Iterate over ::nc.
            for (Uint16 c = 0U; c < nc; ++c)
            {
                /// <ul>
                /// <li> Compute the sum of products between the given diagonals and the corresponding element of 
                /// its Matrix.
                Base::Array<T>::v[r + (nr*c)] *= (dl[r]*dr[c]);
                /// </ul>
            }
            /// </ul>
        }
        /// </ul>
    }

    // Given a positive-definite symmetric matrix a[0..nr-1][0..nr-1], construct
    // and store its Cholesky decomposition, A D L   LT .
    template <>
    inline bool Tmatrix<Real>::cholesky_decomp()
    {
        /// \alg
        /// - Return retreived value by Maverik::rmatrix_cholesky_decomp for this method.
        return rmatrix_cholesky_decomp(*this);
    }

    template <>
    inline void Tmatrix<Real>::cholesky_solve(const Tarray<Real>& b, Tarray<Real>& x)const
    {
        /// \alg
        /// Return retreived value by Maverik::rmatrix_cholesky_solve for this method and the given parameters.
        rmatrix_cholesky_solve(b, x, *this);
    }

    template<class T>
    void Tmatrix<T>::lower_triangular_inverse(Tmatrix<T>& inv) const
    {
        // Attention: The ::inv and ::invt matrices shall have the same dimension as this matrix
        /// \alg
        /// To compute every column in the inverse matrix, it is considered a system with the form: \f$ Lx = b\f$,
        /// being L the lower triangular matrix to invert, x the colum of the inverse matrix, and b the corresponding
        /// column of the identity matrix depending on the index of the inverse matrix column. To compute
        /// every element of x, the forward substitution method is applied with the following formula:
        /// \f[
        /// x_m = \frac{b_m - \sum{m-1}{i=1}l_{m, i}x_i}{l_{m, m}}
        /// \f]
        /// ... with the indices starting at 1.
        for (Uint16 ci = 0U; ci < nc; ci++)
        {
            for (Uint16 r = 0U; r < nr; r++)
            {
                inv[r + (ci * nr)] = (r == ci) ? 1.0F : 0.0F; // Value of identity matrix on this index
                for (Uint16 c = 0U; c < r; c++)
                {
                    inv[r + (ci * nr)] -= Base::Array<T>::v[r + (c * nr)] * inv[c + (ci * nr)];
                }
                inv[r + (ci * nr)] /= Base::Array<T>::v[r + (r * nr)];
            }
        }
    }

    template <class T>
    void Tmatrix<T>::upper_triangular_backsolve(const Tarray<T>& b, Tarray<T>& x) const
    {
        const T* p = &Base::Array<T>::v[0];
        // Backward substitution
        for (int16 r = nr - 1; r >= 0; --r)
        {
            T sum = 0.0F;
            for (int16 c = r + 1; c < nc; ++c)
            {
                sum += p[r + (nc*c)] * x[c];
            }
            x[r] = (b[r] - sum) / p[r + (nc*r)];
        }
    }

    template <class T>
    void Tmatrix<T>::transpose()
    {
        for (Uint16 r = 1U; r < nr; ++r)
        {
            for (Uint16 c = 0U; c < r; ++c)
            {
                Rfun::swap(Base::Array<T>::v[r + (c * nr)], Base::Array<T>::v[c + (r * nr)]);
            }
        }
    }

    template <class T>
    void Tmatrix<T>::remove_column(const Uint16 c)
    {
        if (c < nc)
        {
            Base::Tmem::move(colref(c), colref(c + 1U), (nc - c - 1U)*nr*(sizeof(T)));
            resize_mat(nr, nc - 1U);
        }
    }

    template <class T>
    void Tmatrix<T>::remove_row(const Uint16 r)
    {
        if (r < nr)
        {
            T* vr = &Base::Array<Real>::v[r];
            for (Uint16 c = 0U; c < nc; ++c)
            {
                Base::Tmem::move(&vr[c * (nr - 1U)], &vr[c * nr], nc*(sizeof(T)));
            }
            resize_mat(nr - 1U, nc);
        }
    }

    template <>
    inline Tmatrix<Real>::Givens_rotation Tmatrix<Real>::Givens_rotation::make_givens(const Real x,
                                                                                      const Real y,
                                                                                      const Real eps)
    {
        const Real r = Rmath::sqrtr((x*x) + (y*y));
        return (r > eps) ?
                Givens_rotation(x / r, y / r) :
                Givens_rotation(1.0F, 0.0F);
    }

    template <>
    inline void Tmatrix<Real>::apply_left_givens_rotation(const Givens_rotation& g,
                                                          const Uint16 i,
                                                          const Uint16 j)
    {
        for (Uint16 col = 0; col < nc; ++col)
        {
            Real* vcol = &Base::Array<Real>::v[col * nr];
            const Real temp_i = vcol[i];
            const Real temp_j = vcol[j];
            vcol[i] = g.c * temp_i - g.s * temp_j;
            vcol[j] = g.s * temp_i + g.c * temp_j;
        }
    }

    template <>
    inline void Tmatrix<Real>::apply_right_givens_rotation(const Givens_rotation& g,
                                                           const Uint16 i,
                                                           const Uint16 j)
    {
        for (Uint16 row = 0; row < nr; ++row)
        {
            Real* vrow = &Base::Array<Real>::v[row];
            const Real temp_i = vrow[i * nr];
            const Real temp_j = vrow[j * nr];
            vrow[i * nr] = g.c * temp_i - g.s * temp_j;
            vrow[j * nr] = g.s * temp_i + g.c * temp_j;
        }
    }

}
#endif
