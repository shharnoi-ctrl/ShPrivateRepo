#ifndef WARNING_H_
#define WARNING_H_

namespace Bsp
{
    extern void warning();              ///< Runtime warning
    extern bool warning_assrt(bool b);  ///< Runtime assertion
}
#endif
