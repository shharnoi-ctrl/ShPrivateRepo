#ifndef VARIABLE_H__
#define VARIABLE_H__

#include <Entypes.h>

namespace Base
{
    /// Checksum types
    enum Cktype
    {
        ck_crc      = 0,    ///< (0) Cyclic redundancy check (CRC)
        ck_sum8     = 1,    ///< (1) 8-bit sum of data.
        ck_sum_modN = 2,    ///< (2) N-(sum % N)
        ck_crcmav   = 3,    ///< (3) X.25 compatible with mavlink
        ck_sagetech = 4,    ///< (4) 8-bit checksum for sagetech XP series communication = Sum(n(N-i)*D(i))
    };
    static const Uint16 ck_all      = 5;     ///< Limit enum

    enum Vtype
    {
        real_float32  =  0,  ///< (0) Rvarmgr value without compression
        real_fixed    =  1,  ///< (1) Rvarmgr value with compression
        uinteger16    =  2,  ///< (2) Uvarmgr value with compression
        bit           =  3,  ///< (3) Buil-In Test flag
        reserved      =  4,  ///< (4) Reserved
        real_ubits    =  5,  ///< (5) Rvarmgr value as unsigned with custom width.
        real_ibits    =  6,  ///< (6) Rvarmgr value as signed with custom width.
        checksum      =  7,  ///< (7) Checksum field
        matcher       =  8,  ///< (8) Fixed matcher field.
        skip          =  9,  ///< (9) Field to ignore
        fvar_abs_ftr  = 10,  ///< (10) Absolute feature
        fvar_ftr      = 11,  ///< (11) Icompress feature field
        real_strchar  = 12,  ///< (12) Float contained in a character string, format: 00.00
        fvar_abs_llh  = 13,  ///< (13) Absolute position with 64-bits components
        real_float64  = 14,  ///< (14) Rvar variable parsed as Real64
        real_float16  = 15,  ///< (15) Rvar variable parsed as Real16
        bcd_float     = 16,  ///< (16) Rvar variable parsed as BCD format
        bcd_uint      = 17,  ///< (17) Uvar variable parsed as BCD format
        real64        = 18,  ///< (18) Double precision R64var
        bitmap        = 19   ///< (19) Bitmap Type which is splitted in N Bvars.
    };
    static const Uint16 vtype_all = 19;   ///< Limit enum

    /// Stanag types
    enum Stanag_types
    {
        tint        = 0,    ///< Integer
        tchar       = 1,    ///< Character
        tfloat      = 2,    ///< Float32
        tunsig      = 3,    ///< Unsigned
        tbyte       = 4,    ///< Byte
        tcomp       = 5,    ///< Composite
        // Special types
        tunsig_sp   = 10    ///< Unsigned with special conversion
    };

}
#endif
