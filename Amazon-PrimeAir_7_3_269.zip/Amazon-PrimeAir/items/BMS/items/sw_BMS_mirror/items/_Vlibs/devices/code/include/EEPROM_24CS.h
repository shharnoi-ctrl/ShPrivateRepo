#ifndef EEPROM_24CS_H_
#define EEPROM_24CS_H_

#include <I2Cdevice.h>
#include <Iblock_device.h>
#include <U8ostream.h>

namespace Devices
{
    /// Support for 24CS256 I2C EEPROM (excluding security, configuration and host space).
    class EEPROM_24CS: public Dsp28335_ent::I2Cdevice, public Base::Iblock_device
    {
    public:
        static const Uint8 eeprom_addr = 0x50;  ///< I2C address for EEPROM.

        /// 24CS's EEPROM driver constructor.
        /// \wi{20950}
        /// EEPROM_24CS class shall initialize itself upon construction with provided parameters.
        /// \param[in] i2c0     I2C driver to use.
        /// \param[in] bit      Built-In-Test system variable.
        EEPROM_24CS(Dsp28335_ent::I2Cif& i2c0, volatile bool& bit);

        /// 24CS's EEPROM I2C device calling period.
        /// \wi{20951}
        /// EEPROM_24CS class shall be able to retrieve its current calling period.
        /// \return Current calling period.
        /// \rat Rely derived I2Cdevice abstract base.
        virtual Real get_period() const;

        /// 24CS's EEPROM I2C device set period.
        /// \wi{20952}
        /// EEPROM_24CS class shall provide the capability to set its current calling period.
        /// \param[in] period0  Period to set, in seconds.
        /// \rat Rely derived I2Cdevice abstract base.
        virtual void set_period(const Real& period0);

        /// 24CS's EEPROM I2C device default period.
        /// \wi{20953}
        /// EEPROM_24CS class shall be able to retrieve its default calling period.
        /// \return Default calling period.
        /// \rat Rely derived I2Cdevice abstract base.
        virtual Real get_default_period() const;

        /// 24CS's EEPROM desired rate.
        /// \wi{20954}
        /// EEPROM_24CS class shall be able to retrieve its desired rate.
        /// \return Desired calling rate.
        /// \rat Rely derived I2Cdevice abstract base.
        virtual Real get_desired_rate() const;

        /// 24CS's EEPROM initialization.
        /// \wi{20955}
        /// EEPROM_24CS class shall provide the capability to put the EEPROM in initialized state.
        /// \return True if successfully initialized.
        /// \rat Rely derived Iblock_device abstract base.
        virtual bool init_medium();

        /// 24CS's EEPROM initialized.
        /// \wi{20956}
        /// EEPROM_24CS class shall be able to check if it was initialized or not.
        /// \return True device was if successfully initialized.
        /// \rat Rely derived Iblock_device abstract base.
        virtual bool is_init() const;

        /// 24CS's EEPROM sector size.
        /// \wi{20957}
        /// EEPROM_24CS class shall be able to retrieve the byte-length of one sector.
        /// \return Sector size(in bytes).
        /// \rat Rely derived Iblock_device abstract base.
        virtual Uint32 get_sector_size() const
        {
            return page_sz;
        };

        /// 24CS's EEPROM sector count.
        /// \wi{20958}
        /// EEPROM_24CS class shall be able to retrieve the total number of sectors.
        /// \return Number of sectors of the device.
        /// \rat Rely derived Iblock_device abstract base.
        virtual Uint32 get_sector_count() const
        {
            return nb_page;
        };

        /// 24CS's EEPROM read one sector synchronously.
        /// \wi{20959}
        /// Not implemented yet.
        /// \param[in] sector Sector to read.
        /// \param[out] buffer Buffer of data where to read to.
        /// \return Always false.
        /// \rat Rely derived Iblock_device abstract base.
        virtual bool read_sector(Uint32 sector, Base::U8pkmblock& buffer);

        /// 24CS's EEPROM start read request.
        /// \wi{20960}
        /// EEPROM_24CS class shall provide the capability to asynchronously start a sector read operation.
        /// \param[in] sector Sector to read.
        /// \return Asynchronous state resulting from this operation.
        /// \rat Rely derived Iblock_device abstract base.
        virtual Base::Async_res read_sector_start(Uint32 sector);

        /// 24CS's EEPROM read sector asynchronously.
        /// \wi{20961}
        /// EEPROM_24CS class shall provide the capability to asynchronously retrieve read sector.
        /// \param[out] buffer Buffer to fill with read data.
        /// \return Asynchronous state of the read sector operation.
        /// \rat Rely derived Iblock_device abstract base.
        virtual Base::Async_res read_sector_get_data(Base::U8pkmblock& buffer);

        /// 24CS's EEPROM write one sector synchronously.
        /// \wi{20962}
        /// Not implemented yet.
        /// \param[in] sector Sector to write.
        /// \param[in] buffer Data to write in sector.
        /// \return Always false.
        /// \rat Rely derived Iblock_device abstract base.
        virtual bool write_sector(Uint32 SectorNo, const Base::U8pkmblock_k& buffer);

        /// 24CS's EEPROM start asynchronous sector write.
        /// \wi{20963}
        /// EEPROM_24CS class shall provide the capability to asynchronously start a sector write operation.
        /// \param[in] sector Sector to write.
        /// \param[in] buffer Data to write in sector.
        /// \return Asynchronous state of the start write operation.
        /// \rat Rely derived Iblock_device abstract base.
        virtual Base::Async_res write_sector_start(Uint32 sector, const Base::U8pkmblock_k& buffer);

        /// 24CS's EEPROM end write sector.
        /// \wi{20964}
        /// EEPROM_24CS class shall provide the capability to asynchronously end a sector write operation.
        /// \return Asynchronous state of the end write operation.
        /// \rat Rely derived Iblock_device abstract base.
        virtual Base::Async_res write_sector_ended();

    protected:
        /// 24CS's EEPROM step.
        /// \wi{20965}
        /// EEPROM_24CS class shall provide the capability to iterate through its internal FSM.
        /// \rat Rely derived I2Cdevice abstract base.
        virtual void do_step();

        /// 24CS's EEPROM set OK.
        /// \wi{20966}
        /// EEPROM_24CS class shall be able to set its internal OK flag.
        /// \param[in] ok   State to force (at true is OK, at false is not).
        /// \rat Rely derived I2Cdevice abstract base.
        virtual void set_ok(bool ok);

    private:
        enum State
        {
            st_por, ///< Power-on reset state, wait for mandatory time.
            st_ini, ///< Initialized state, do nothing.

            st_crd, ///< Read state, start read command.
            st_cwr, ///< Write state, start write command.

            st_wop, ///< Wait state, just forward to st_ini when called.

            st_err  ///< Error state.
        };

        static const Uint32 page_sz = 64UL;             ///< Total number of bytes per page.
        static const Uint32 nb_page = 500UL;            ///< Total number of page for whole EEPROM.
        static const Uint32 data_sz = page_sz*500UL;    ///< Size (in bytes) for EEPROM.

        static const Real wait_por_s;   ///< Time to wait next to power-up (1 ms), in seconds.
        static const Real wait_wrt_s;   ///< Time to wait next to write operation (5 ms), in seconds.

        ///< Desired rate rate, fixed at 100Hz, but not relevant as calling rate is fixed by Iblock_device user.
        static const Uint16 desired_rate_u = 100U;
        static const Real desired_rate; ///< Desired rate in floating-point format, reflect desired_rate_u.

        const Dsp28335_ent::I2Cif& i2c; ///< Driver for I2C (read-only access).

        State state;            ///< Internal state for FSM.
        Base::Chrono chr;       ///< Chrono to time.
        Real period_current;    ///< Current I2C device calling period.

        Uint32 op_pidx;                     ///< Current page index to work with.
        Uint16 op_addr;                     ///< EEPROM address to work with.
        Base::U8pkmblock cmd_mb;            ///< Two bytes memory block, reflect op_addr value.
        const Base::U8pkmblock_k* to_write; ///< Data to be written, used for asynchronous operations.

        /// 24CS's EEPROM valid data.
        /// \wi{20967}
        /// \param[in] page_idx Index of the page to operate with.
        /// \return True if it is within expected range, else return False.
        bool check_idx(Uint16 page_idx) const;

        /// 24CS's EEPROM initialiation state.
        /// \wi{20968}
        /// EEPROM_24CS class shall be able to check if the device has been initialized or not.
        /// \return True if device was initialized, else return False.
        bool is_init0() const;

        /// 24CS's EEPROM start request.
        /// \wi{20977}
        /// EEPROM_24CS class shall provide the capability to send the start command, as write request with address.
        /// \param[in] page_idx Page index.
        /// \return True if operation succeed, else return false.
        bool start_request(Uint16 page_idx);

        EEPROM_24CS(const EEPROM_24CS& orig); ///< = delete
        EEPROM_24CS& operator=(const EEPROM_24CS& orig); ///< = delete
    };

    inline bool EEPROM_24CS::check_idx(Uint16 page_idx) const
    {
        /// \alg
        /// - Return true if provided ::page_idx is strictly inferior to nb_page.
        return (page_idx < nb_page);
    }

    inline bool EEPROM_24CS::is_init0() const
    {
        /// \alg
        /// - Return True if ::state is equals to st_ini, else return
        return (state == st_ini);
    }
}

#endif
