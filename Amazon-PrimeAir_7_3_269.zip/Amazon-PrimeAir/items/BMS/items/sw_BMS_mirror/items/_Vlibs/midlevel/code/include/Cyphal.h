#ifndef CYPHAL_EMB_H_
#define CYPHAL_EMB_H_

#include <CRC.h>
#include <Spkt_hdr.h>
#include <U8ostream.h>

namespace Cyphal
{
    /// CRC16 for Cyphal.
    static const Base::CRC::Config crc_cyphal = Base::CRC::Config::build(Ku16::u16,
        0x8408,    // No reversed polynomial is 0x1021
        0xFFFF,
        0,
        false,
        false);
    static const Uint16 crc_size = 2U;  ///< CRC size in bytes.

    /// Enumeration to define Cyphal services.
    enum Services
    {
        sbj_info      = 430     ///< Information service.
    };

    /// Enumeration to define Cyphal message subjects.
    enum Subjects
    {
        sbj_heartbeat = 7509    ///< Heartbeat message.
    };

    /// Tail Byte.
    /// Cyphal library shall provide a union to manage the tail byte on Cyphal over CAN frames.
    union Tail_byte
    {
        Uint8 all;      ///< Provides access to the entire value of the header fields.
        struct
        {
            Uint8 transfer_id : 5;///< Transfer ID.
            Uint8 toggle_bit : 1; ///< Toggle bit.
            Uint8 eot : 1;        ///< End of transfer bit.
            Uint8 sot : 1;        ///< Start of transfer bit.
        };

        /// Tail Byte Builder.
        /// \wi{21255}
        /// Tail_byte union shall provide the capability to build a tail byte with transfer ID, toggle bit,
        /// start and end transfer bit.
        /// \param[in] transfer_id Transfer ID.
        /// \param[in] start Start of transfer bit.
        /// \param[in] end End of transfer bit.
        /// \param[in] toggle_b Toggle bit (Default = True).
        /// \return Tail byte built.
        static Tail_byte build(Uint8 transfer_id,
            bool start,
            bool end,
            bool toggle_b = true);

        /// Tail Byte Zero Builder.
        /// \wi{21256}
        /// Tail_byte union shall provide the capability to build a tail byte and initialize it with all zeros.
        /// \return Tail byte built with all zeros.
        static inline Tail_byte build()
        {
            /// \alg
            /// <ul>
            /// <li> Initialize Tail_byte "res" instance with zero.
            /// <li> Return "res".
            /// </ul>
            const Tail_byte res = { 0 };
            return res;
        }
    };

    /// Cyphal library shall provide a structure to manage Cyphal CAN ID for messages.
    struct CyCAN_msg
    {
        Uint32 src_node : 7;  ///< Source node ID.
        Uint32 res2 : 1;      ///< Reserved (Shall be '0').
        Uint32 subject : 13;  ///< Subject ID.
        Uint32 res1 : 3;      ///< Reserved (Shall be '011').
        Uint32 anon : 1;      ///< Anonymous message it is '1'.
        Uint32 svc_msg : 1;   ///< Is service(1) or message (0) flag.
        Uint32 priority : 3;  ///< Priority.
    };

    /// Cyphal library shall provide a structure to manage Cyphal CAN ID for services.
    struct CyCAN_svc
    {
        Uint32 src_node : 7;  ///< Source node ID.
        Uint32 dst_node : 7;  ///< Destination node ID.
        Uint32 service : 9;   ///< Service ID.
        Uint32 res1 : 1;      ///< Reserved (Shall be '0').
        Uint32 resp : 1;      ///< Is response(1) or request (0) flag.
        Uint32 svc_msg : 1;   ///< Is service(1) or message (0) flag.
        Uint32 priority : 3;  ///< Priority.
    };

    /// Cyphal CAN ID.
    /// Cyphal library shall provide a union to manage the header for CAN_2.0/CAN-FD ID.
    union CyCAN_id 
    {
        Uint32 all; ///< Provides access to the entire value of the header fields.
        CyCAN_msg msg;  ///< Instance of a Cyphal CAN ID message.
        CyCAN_svc svc;  ///< Instance of a Cyphal CAN ID service.

        /// Cyphal CAN ID Message Builder.
        /// \wi{21257}
        /// CyCAN_id shall provide the capability to build a Cyphal CAN ID as a message with given parameters.
        /// \param[in] priority Priority.
        /// \param[in] subject Subject ID.
        /// \param[in] src_node Source node ID.
        /// \return Return the built message.
        static CyCAN_id build_msg(Uint8 priority,
                                  Uint16 subject,
                                  Uint8 src_node);

        /// Cyphal CAN ID Service Builder.
        /// \wi{21258}
        /// CyCAN_id shall provide the capability to build a Cyphal CAN ID as a service with given parameters.
        /// \param[in] priority Priority.
        /// \param[in] is_response Indicates if the message is a response.
        /// \param[in] service Service ID.
        /// \param[in] dst_node Destination node ID.
        /// \param[in] src_node Source node ID.
        /// \return Return the built service.
        static CyCAN_id build_svc(Uint8 priority,
                                  bool is_response,
                                  Uint16 service,
                                  Uint8 dst_node,
                                  Uint8 src_node);
    };

    /// Cyphal STANAG Fields.
    /// Cyphal library shall provide a structure to manage fields needed for Cyphal over STANAG.
    struct Cyphal_stg_fields
    {
        union
        {
            Uint8 all;              ///< Full representation of data.
            struct
            {
                Uint8 anon_resp : 1; ///< Anonymous/Response field. Semantics depends on svc_msg field.
                Uint8 svc_msg : 1;   ///< Is service(1) or message (0) flag.
                Uint8 priority : 3;  ///< Priority.
            };
        };

        /// Number of bits needed from a Cyphal CAN ID to obtain a Cyphal CAN STANAG field.
        static const Uint8 cy_field_id_bits = 5U;
        /// Number of bits to shift to right a Cyphal CAN ID to obtain a Cyphal CAN STANAG field.
        static const Uint8 cy_field_id_despl = 29 - cy_field_id_bits;

        /// Cyphal STANAG Field Builder from Given Parameters.
        /// \wi{21259}
        /// Cyphal_stg_fields structure shall provide the capability to build Cyphal STANAG field from
        /// given parameters.
        /// \param[in] priority Priority.
        /// \param[in] is_svc Indicates if the message is a service.
        /// \param[in] anon_resp Indicates if the message is an anonymous response.
        /// \return Return the Cyphal STANAG field.
        static Cyphal_stg_fields build(Uint8 priority,
                                       bool is_svc,
                                       bool anon_resp);

        /// Cyphal STANAG Field Builder from Cyphal CAN ID.
        /// \wi{21260}
        /// Cyphal_stg_fields structure shall provide the capability to build Cyphal STANAG field from
        /// Cyphal CAN ID.
        /// \param[in] cy_id Cyphal CAN identifier.
        /// \return Return the Cyphal STANAG field.
        inline static Cyphal_stg_fields build(CyCAN_id cy_id)
        {
            /// \alg
            /// <ul>
            /// <li> Initialize Cyphal_stg_fields "res" instance with the result of a bitwise AND between the 
            /// right-shifted value of CyCAN_id::all for 
            /// the given "cy_id" by ::cy_field_id_despl and Base::Bitutils::get_mask_lsb_t::value.
            /// <li> Return "res".
            /// </ul>
            const Cyphal_stg_fields res = { (cy_id.all >> cy_field_id_despl) &
                                            Base::Bitutils::get_mask_lsb_t<Uint8,cy_field_id_bits>::value };
            return res;
        }
    };

    /// Full ID.
    /// The Cyphal library shall provide a structure to manage unique service/message subjects
    /// for handling identification.
    struct Full_id
    {        
        union
        {
            Uint16 all;         ///< Full representation of data.
            struct
            {
                Uint16 id : 13; ///< Message or service ID.
                Uint16 res : 2; ///< Reserved.
                Uint16 svd : 1; ///< Is service(1) or message(0) flag.
            };
        };

        /// Offset of the "is service" flag.
        static const Uint16 is_svc_offset = 15U;
        /// Service ID mask.
        static const Uint16 svc_id_mask = Base::Bitutils::get_mask_lsb_t<Uint16, 9U>::value;
        /// Message ID mask.
        static const Uint16 msg_id_mask = Base::Bitutils::get_mask_lsb_t<Uint16,13U>::value;

        /// Full ID Builder from Given Parameters.
        /// \wi{21261}
        /// Full_id shall provide the capability to build a full ID with "is service" flag and ID.
        /// \param[in] is_svc True if it is a service and False if it is a message.
        /// \param[in] id     Identifier.
        /// \return Return created full ID.
        inline static Full_id build(bool is_svc, Uint16 id)
        {
            /// \alg
            /// <ul>
            /// <li> Initialize Full_id "res" instance with the result of the bitwise OR between: 
            /// <ul>
            /// <li> The left-shifted bitwise operation of given "is_svc" by ::is_svc_offset positions and,
            /// <ul>
            /// <li> If given "is_svc" is True, then the bitwise AND operation between given "id" and ::svc_id_mask.
            /// <li> Otherwise, the bitwise AND operation between given "id" and ::msg_id_mask.
            /// </ul>
            /// </ul>
            /// <li> Return "res".
            /// </ul>
            const Full_id res = { (static_cast<Uint16>(is_svc) << is_svc_offset) | 
                                  (id & (is_svc ? svc_id_mask : msg_id_mask)) };
            return res;
        }

        /// Full ID Builder from a Cyphal CAN ID.
        /// \wi{21262}
        /// Full_id shall provide the capability to build a full ID from a Cyphal CAN ID.
        /// \param[in] cy_id Cyphal CAN ID to build full ID from.
        /// \return Return created full ID.
        inline static Full_id build(const CyCAN_id& cy_id)
        {
            /// \alg
            /// <ul>
            /// <li> Assign to "fid" the retrieved value by ::build with CyCAN_svc::svc_msg for CyCAN_id::svc in given 
            /// "cy_id" as first parameter and:
            /// <ul>
            /// <li> If first parameter is True, with CyCAN_svc::service for CyCAN_id::svc in given "cy_id" as second
            /// parameter.
            /// <li> Otherwise, with CyCAN_msg::subject for CyCAN_id::msg in "cy_id" 
            /// as second parameter.
            /// </ul>
            /// <li> Return "fid"
            /// </ul>
            const Full_id fid = Full_id::build(cy_id.svc.svc_msg,
                                               cy_id.svc.svc_msg ? cy_id.svc.service : cy_id.msg.subject);
            return fid;
        }
    };

    /// The Cyphal library shall provide a class to manage Cyphal messages.
    /// The payload is limited to 521 Bytes (528 from Stanag pkt - Cyphal_msg header).
    /// Structure:
    /// | Header   | Payload        |
    /// |  ---     |   ---          |
    /// |  7 Bytes | [0, 521] Bytes |
    ///
    /// With the Header defined as:
    /// | Field Name  | Sync | CyCAN_id | Len |
    /// | ---         | ---  |   ---    | --- |
    /// | Field Bytes |   1  |    4     |  2  |
    class Cyphal_msg
    {
    public:
        /// Offset for header data in the buffer.
        enum Offsets    
        {
            offset_sync    = 0U,    ///< Offset of the synchronization byte.
            offset_props   = 1U,    ///< Offset of the CyCAN_id value.
            offset_len     = 5U,    ///< Offset of the payload length value (low byte).
            offset_len_h   = 6U,    ///< Offset of the payload length value (high byte).
            offset_payload = 7U     ///< Offset of the start of payload data.
        };

        static const Uint8 start_byte = 0xC1; ///< Cyphal stream start byte.

        /// Size of header for Cyphal serialization. Minimum data size is: start_byte(1) + properties(4) + len(2).
        static const Uint16 hdr_sz = 1U + 4U + 2U;                
        /// Maximum Cyphal payload size.
        static const Uint16 max_payload = Base::Spkt_hdr::max_data_size - hdr_sz;                 
        static const Uint16 max_size = hdr_sz + max_payload;    ///< Maximum total Cyphal messsage buffer size.

        /// Cyphal Message Constructor with Given Parameter.
        /// \wi{21243}
        /// Cyphal_msg class shall build itself upon construction with given buffer memory block.
        /// \param[in] buffer Buffer memory block to be used.
        Cyphal_msg(Base::U8pkmblock buffer);

        /// Cyphal Message Copier.
        /// \wi{21244}
        /// Cyphal_msg class shall provide the capability to copy a cyphal message into itself.
        /// \param[in] obj Chypal message to copy.
        void copy(const Cyphal_msg& obj);

        /// Cyphal Message ID Retriever.
        /// \wi{21245}
        /// Cyphal_msg class shall provide the capability to retrieve the CyCAN identifier of the message.
        /// \return Identifier of the message.
        CyCAN_id get_id() const;

        /// Cyphal Message ID Setter.
        /// \wi{21246}
        /// Cyphal_msg class shall provide the capability to set the CyCAn identifier of the message.
        /// \param[in] id Identifier to be set.
        void set_id(CyCAN_id id);

        /// Cyphal Message Length Retriever.
        /// \wi{21247}
        /// Cyphal_msg class shall provide the capability to retrieve the payload length of the message.
        /// \return Length of the message.
        Uint16 get_len() const;

        /// Cyphal Message Buffer Retriever.
        /// \wi{21248}
        /// Cyphal_msg class shall provide the capability to retrieve the full packet buffer memory block.
        /// \return Full packet buffer memory block.
        inline Base::U8pkmblock_k get_buffer() const
        {
            /// \alg
            /// - Return Base::U8pkmblock_k instance initialized with ::buffer and ::hdr_sz plus retrieved value by ::get_len.
            return Base::U8pkmblock_k(buffer, hdr_sz + get_len());
        }

        /// The Cyphal Message class shall provide a class to change Cyphal message payload.
        class Mutator
        {
        public:
            /// Mutator Constructor with Given Parameter.
            /// \wi{21249}
            /// Mutator class shall build itself upon construction with given message to update Cyphal_msg payload.
            /// \param[in] msg0 Message which payload will be updated.
            inline explicit Mutator(Cyphal_msg& msg0) :
                os(Base::U8pkmblock(msg0.buffer, msg0.buffer.size())),
                msg(msg0)
            {
                /// \alg
                /// <ul>
                /// <li> Initialize ::os with Base::U8pkmblock instance initialized with ::buffer of given "msg0"
                /// and retrieved value by Base::U8pkmblock_k::size for ::buffer of given "msg0".
                /// <li> Initialize ::msg with given "msg0".
                /// <li> Call Base::U8ostream::seek with Offsets::offset_payload for Mutator::os.
                /// </ul>
                os.seek(offset_payload);
            }

            /// Mutator Destructor.
            /// \wi{21250}
            /// Mutator class shall compute the CRC packet when the Mutator is destroyed.
            inline ~Mutator()
            {
                /// \alg
                /// <ul>
                /// <li> Call Cyphal_msg::set_len in ::msg with Base::U8ostream::get_pos for Mutator::os minus 
                /// Offsets::offset_payload.
                /// </ul>
                msg.set_len(os.get_pos()-offset_payload);
            }

            Base::U8ostream os; ///< U8ostream where the payload will be serialized.
        private:
            Cyphal_msg& msg;    ///< Message which will be updated.
        };

    private:
        Base::U8pkmblock buffer;    ///< Message byte buffer.
        
        /// Cyphal Message Length Setter.
        /// \wi{21251}
        /// Cyphal_msg class shall provide the capability to set the payload length of the message.
        /// \param[in] len Payload length of the message to be set.
        void set_len(Uint16 len);
    };
}
#endif
