#ifndef KU8_H_
#define KU8_H_

#include <Entypes.h>

namespace Ku8
{
    static const Uint8 u0=            static_cast<Uint8>(0U);
    static const Uint8 u1=            static_cast<Uint8>(1U);
    static const Uint8 u2=            static_cast<Uint8>(2U);
    static const Uint8 u3=            static_cast<Uint8>(3U);
    static const Uint8 u4=            static_cast<Uint8>(4U);
    static const Uint8 u5=            static_cast<Uint8>(5U);
    static const Uint8 u6=            static_cast<Uint8>(6U);
    static const Uint8 u7=            static_cast<Uint8>(7U);
    static const Uint8 u8=            static_cast<Uint8>(8U);
    static const Uint8 u9=            static_cast<Uint8>(9U);
    static const Uint8 u10=           static_cast<Uint8>(10U);
    static const Uint8 u11=           static_cast<Uint8>(11U);
    static const Uint8 u12=           static_cast<Uint8>(12U);
    static const Uint8 u13=           static_cast<Uint8>(13U);
    static const Uint8 u14=           static_cast<Uint8>(14U);
    static const Uint8 u15=           static_cast<Uint8>(15U);
    static const Uint8 u16=           static_cast<Uint8>(16U);
    static const Uint8 u17=           static_cast<Uint8>(17U);
    static const Uint8 u19=           static_cast<Uint8>(19U);
    static const Uint8 u20=           static_cast<Uint8>(20U);
    static const Uint8 u21=           static_cast<Uint8>(21U);
    static const Uint8 u23=           static_cast<Uint8>(23U);
    static const Uint8 u24=           static_cast<Uint8>(24U);
    static const Uint8 u25=           static_cast<Uint8>(25U);
    static const Uint8 u28=           static_cast<Uint8>(28U);
    static const Uint8 u31=           static_cast<Uint8>(31U);
    static const Uint8 u32=           static_cast<Uint8>(32U);
    static const Uint8 u40=           static_cast<Uint8>(40U);
    static const Uint8 u48=           static_cast<Uint8>(48U);
    static const Uint8 u55=           static_cast<Uint8>(55U);
    static const Uint8 u56=           static_cast<Uint8>(56U);
    static const Uint8 u64=           static_cast<Uint8>(64U);
    static const Uint8 maxV=          static_cast<Uint8>(255U);


    static const Uint8 u0x0F=        static_cast<Uint8>(0x0FU);
    static const Uint8 u0xFA=        static_cast<Uint8>(0xFAU);
    static const Uint8 u0xFF=        static_cast<Uint8>(0xFFU);

}

#endif
