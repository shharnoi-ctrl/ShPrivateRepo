#ifndef FIFOSPSC_H_
#define FIFOSPSC_H_

#include <Array.h>
#include <Fifospsc0.h>

namespace Base
{
    /// Thread safe Fifo for single producer in one thread and single consumer in other thread.
    template <typename T>
    class Fifospsc : private Array<T>
    {
    public:
        typedef T type;     ///< Defined type for this FIFO.

        /// Fifospsc Constructor.
        /// \wi{6683}
        /// Fifospsc shall initialize itself upon construction with the provided parameters.
        /// \param[in] size     Size of the Fifospsc0 buffer.
        /// \param[in] mtype    Memory type.
        Fifospsc(Uint32 size, Memmgr::Type mtype);

        //Access methods to Fifospsc0

        /// Fifospsc Write.
        /// \wi{5018}
        /// Fifospsc shall provide the capability to write an element in the buffer.
        /// \param[in] element  Element to write in the buffer.
        /// \return             True if the action has worked, false if not.
        bool write(typename JSF116_param<T>::type element);
        /// Fifospsc Read.
        /// \wi{5020}
        /// Fifospsc shall provide the capability to read an element from the buffer.
        /// \param[out] element     Reference to save the value read.
        /// \return                 True if the action has worked, false if not.
        bool read(T& element);

        /// Fifospsc Read Available.
        /// \wi{5021}
        /// Fifospsc shall provide the capability to check if there is something to read from ::ff0_obj FIFO.
        /// \return     True if reading action is available, false if not.
        bool rd_available() const;
        /// Fifospsc Write Available.
        /// \wi{5019}
        /// Fifospsc shall provide the capability to check if writing action is available.
        /// \return     True if writing action is available, false if not.
        bool wr_available() const;

        /// Fifospsc Read Available Count.
        /// \wi{16839}
        /// Fifospsc shall provide the capability to retrieve the available reading count.
        /// \return     Count of available items to read.
        inline Uint32 rd_available_count() const
        {
            return ff0_obj.rd_available_count();
        }

        /// Fifospsc Write Available Count.
        /// \wi{16840}
        /// Fifospsc shall provide the capability to retrieve the available writing count.
        /// \return     Count of available items to write.
        inline Uint32 wr_available_count() const
        {
            return ff0_obj.wr_available_count();
        }

        /// Fifospsc Get Write Pointer.
        /// \wi{5022}
        /// Fifospsc shall provide the capability to retrieve its write pointer.
        /// \return     Write pointer of the FIFO.
        typename Fifospsc0<T>::Wtmp get_wr() const;
        /// Fifospsc Set Write Pointer.
        /// \wi{5024}
        /// Fifospsc shall provide the capability to set its write pointer.
        /// \param[in] wr0 New write pointer.
        void set_wr(typename Fifospsc0<T>::Wtmp wr0);

        /// Fifospsc Next.
        /// \wi{5023}
        /// Fifospsc shall provide the capability to retrieve the element next to provided one.
        /// \param[in] prv  Pointer to a buffer element.
        /// \return         Next element in the FIFO to prv.
        T* next(T* prv) const;

    private:
        Fifospsc0<T> ff0_obj;   ///< Internal FIFO buffer with both write and read pointers 
                                /// internally instantiated and managed by FIFO.
        
        Fifospsc(); ///< = delete
        Fifospsc(const Fifospsc& orig); ///< = delete
        Fifospsc& operator=(const Fifospsc& orig); ///< = delete
    };

    template <typename T>
    Fifospsc<T>::Fifospsc(Uint32 size, Memmgr::Type mtype) :
        Array<T>(size,mtype),
        ff0_obj(Array<T>::v,Array<T>::vz,Array<T>::v,Array<T>::v)
    {
    }

    template <typename T>
    inline bool Fifospsc<T>::write(typename JSF116_param<T>::type element)
    {
        return ff0_obj.write(element);
    }

    template <typename T>
    inline bool Fifospsc<T>::read(T& element)
    {
        return ff0_obj.read(element);
    }

    template <typename T>
    inline bool Fifospsc<T>::rd_available() const
    {
        return ff0_obj.rd_available();
    }

    template <typename T>
    inline bool Fifospsc<T>::wr_available() const
    {
        return ff0_obj.wr_available();
    }

    template <typename T>
    inline typename Fifospsc0<T>::Wtmp Fifospsc<T>::get_wr() const
    {
        return ff0_obj.get_wr();
    }

    template <typename T>
    inline void Fifospsc<T>::set_wr(typename Fifospsc0<T>::Wtmp wr0)
    {
        ff0_obj.set_wr(wr0);
    }

    template <typename T>
    inline T* Fifospsc<T>::next(T* prv) const
    {
        return ff0_obj.next(prv);
    }

    typedef Fifospsc<Uint8> Fifospsc_u8;
}
#endif
