#ifndef LOSSY_ERROR_H_
#define LOSSY_ERROR_H_

#include <Error.h>
#include <Lossy.h>

namespace Base
{
    /// Data serialization and de-serialization with error report management.
    /// The ::Base library shall provide the capability to serialize and de-serialize data and to store
    /// any errors that could happen at de-serialization stage.
    class Lossy_error : public Lossy
    {
    public:
        /// The ::Lossy_error class shall provide a structure to handle data traits errors for 16-bit data type.
        struct Mutator_traits16 : public Lossy::Mutator_traits16<Lossy_error>
        {
            /// Data Traits Error Retriever for 16-bit Data Type.
            /// \wi{20142}
            /// Mutator_traits16 structure shall be able to retrieve an error of a given Lossy_error instance.
            /// \param[in] str Lossy_error instance being requested.
            /// \return Reference to 16-bit error object attribute.
            static inline const Error& get_error(Lossy_error& str)
            {
                return str.get_error();
            }
        };

        /// The ::Lossy_error class shall provide a structure to handle data traits errors for 8-bit data type.
        struct Mutator_traits8 : public Lossy::Mutator_traits8<Lossy_error>
        {
            /// Data Traits Error Retriever for 8-bit Data Type.
            /// \wi{20143}
            /// Mutator_traits8 structure shall be able to retrieve an error of a given Lossy_error instance.
            /// \param[in] str Lossy_error instance being requested.
            /// \return Reference to 8-bit error object attribute.
            static inline const Error& get_error(Lossy_error& str)
            {
                return str.get_error();
            }
        };

        /// Lossy error constructor with size and memory type.
        /// \wi{6111}
        /// Lossy_error class shall be able to initialize itself from provided size and memory type.
        /// \param[in] n0           Size (in words) to allocate.
        /// \param[in] memtype      Memory type for the memory block to allocate.
        Lossy_error(Uint32 n0, Memmgr::Type memtype);

        /// Lossy error constructor with Lossy object.
        /// \wi{13404}
        /// Lossy_error class shall be able to initialize itself from provided Lossy object.
        /// \param[in] str0         Constant reference to the Lossy object to construct with.
        Lossy_error(const Lossy& str0);

        /// Lossy error constructor with memory block.
        /// \wi{13405}
        /// Lossy_error class shall be able to initialize itself from provided memory block.
        /// \param[in] mb           Unsigned 16-bit word memory block to construct the Lossy with.
        Lossy_error(Mblock_u16 mb);

        /// Lossy error constructor with pointer to unsigned 16-bit word and size.
        /// \wi{13426}
        /// Lossy_error class shall be able to initialize itself from provided pointer and size.
        /// \param[in]              Pointer to unsigned 16-bit word to build Lossy on.
        /// \param[in]              Number of words to store on Lossy from provided pointer.
        Lossy_error(Uint16* v0, Uint32 n0);

        /// Lossy error constructor with size and memory allocator.
        /// \wi{13585}
        /// Lossy_error class shall be able to initialize itself from provided memory allocator and size.
        /// \param[in,out]          Reference to memory allocator.
        Lossy_error(Uint32 n0, Allocator& alloc);

        /// Lossy error assert.
        /// \wi{6110}
        /// Lossy_error class shall provide the capability to assert an error (as describe \wi{6107}).
        /// \param[in] ck       Checking condition. If false, error will be stored.
        /// \param[in] e_src    Error source identifier. If different than err_ok, error will be stored.
        /// \return The value of the provided checking condition.
        bool assrt(bool ck, Errorsrc e_src);

        /// Lossy error OK.
        /// \wi{6112}
        /// Lossy_error class shall provide the capability to check if there are no errors (as described \wi{6109}).
        /// \return false if an error was previously appended, elsewhere it shall return true.
        bool is_ok() const;

        /// Lossy error failed.
        /// \wi{6113}
        /// Lossy_error class shall provide the capability to assert an error (as described in \wi{6108}).
        /// \param[in] e_src    Error source identifier (shall be different of err_ok to be asserted).
        void failed(Errorsrc e_src);

        /// Lossy error de-serialization from provided PDI type.
        /// \wi{13427}
        /// \rationale Policies are defined in Tuntraits.
        /// Lossy_error class shall provide the capability to de-serialize data from PDIC.
        /// \param[in,out]          Typed object on which we shall de-serialize PDI data.
        template <typename POLICY>
        void get_t(typename POLICY::type& a);

        /// Lossy error get list.
        /// \wi{13428}
        /// Lossy_error class shall be able to retrieve its list of errors.
        /// \return Reference to Error object attribute.
        Base::Error& get_error();

    private:
        Error err;                                       ///< Error object (containing the errors list)

        Lossy_error();                                   ///< = delete
        Lossy_error(const Lossy_error& orig);            ///< = delete
        Lossy_error& operator=(const Lossy_error& orig); ///< = delete
    };

    inline Lossy_error::Lossy_error(Uint32 n0, Memmgr::Type memtype):
        Base::Lossy(n0, memtype)
    {
    }

    inline Lossy_error::Lossy_error(const Lossy& str0):
        Base::Lossy(str0)
    {
    }

    inline Lossy_error::Lossy_error(Mblock_u16 mb):
        Base::Lossy(mb)

    {
    }

    inline Lossy_error::Lossy_error(Uint16* v0, Uint32 n0):
        Base::Lossy(v0,n0)
    {
    }

    inline Lossy_error::Lossy_error(Uint32 n0, Allocator& alloc):
        Base::Lossy(n0, alloc)
    {
    }

    inline bool Lossy_error::assrt(bool ck, Errorsrc e_src)
    {
        return err.assrt(ck, e_src);
    }

    inline bool Lossy_error::is_ok() const
    {
        return err.is_ok();
    }

    inline void Lossy_error::failed(Errorsrc e_src)
    {
        err.failed(e_src);
    }

    template <typename POLICY>
    inline void Lossy_error::get_t(typename POLICY::type& a)
    {
        POLICY::str2elem(a,*this);
    }

    inline Base::Error& Lossy_error::get_error()
    {
        return err;
    }
}
#endif
