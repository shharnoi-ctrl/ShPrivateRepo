#ifndef CAN_FD_CFG_FW_H_
#define CAN_FD_CFG_FW_H_

namespace Dsp28335_ent
{
    struct CAN_FD_cfg;
}
#endif
