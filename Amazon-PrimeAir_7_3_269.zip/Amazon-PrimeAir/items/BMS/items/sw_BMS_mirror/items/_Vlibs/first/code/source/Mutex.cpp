#include <Interrupts.h>
#include <Mutex.h>

namespace Base
{
    Mutex::Mutex(bool enter) : entered(false)
    {
        /// \alg
        /// <ul>
        /// <li> If given parameter is True.
        if(enter)
        {
            /// <ul>
            /// <li> Call ::enter_critical_section.
            enter_critical_section();
            /// </ul>
        }
        /// </ul>
    }

    void Mutex::enter_critical_section()
    {
        /// \alg
        /// <lu>
        /// <li> If ::entered is False.
        if(!entered)
        {
            /// <lu>
            /// <li> Set ::cpu_sr to retrieved value by Bsp::Interrupts::global_disable. 
            cpu_sr=Bsp::Interrupts::global_disable();
            /// <li> Set ::entered to True.
            entered=true;
            /// </lu>
        }
        /// </lu>
    }

    void Mutex::exit_critical_section()
    {
        /// \alg
        /// <lu>
        /// <li> If ::entered is True.
        if(entered)
        {
            /// <lu>
            /// <li> Call Bsp::Interrupts::global_restore with ::cpu_sr. 
            Bsp::Interrupts::global_restore(cpu_sr);
            /// <li> Set ::entered to False.
            entered=false;
            /// </lu>
        }
        /// </lu>
    }

    Mutex::~Mutex()
    {
        /// \alg
        /// <lu>
        /// <li> If ::entered is True.
        if(entered)
        {
            /// <lu>
            /// <li> Call Bsp::Interrupts::global_restore with ::cpu_sr. 
            Bsp::Interrupts::global_restore(cpu_sr);
            /// </lu>
        }
        /// </lu>
    }
}
