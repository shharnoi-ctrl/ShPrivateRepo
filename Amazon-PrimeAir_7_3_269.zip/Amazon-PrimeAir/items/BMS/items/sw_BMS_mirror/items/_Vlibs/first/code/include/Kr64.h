#ifndef KR64_H__
#define KR64_H__

#include <Entypes.h>

namespace Kr64
{
    static const Real64 ZERO    = static_cast<Real64>(0.0L);
    static const Real64 ONE     = static_cast<Real64>(1.0L);
    static const Real64 TWO     = static_cast<Real64>(2.0L);
    static const Real64 SIXTY   = static_cast<Real64>(60.0L);

    static const Real64 PI      = static_cast<Real64>(3.1415926535897932384626433832795L);
    static const Real64 PI2     = static_cast<Real64>(6.283185307179586476925286766559L);
    static const Real64 PI05    = static_cast<Real64>(1.5707963267948966192313216916398L);
    static const Real64 RAD2DEG = static_cast<Real64>(57.295779513082320876798154814105L);
    static const Real64 DEG2RAD = static_cast<Real64>(0.017453292519943295769236907684886L);
}

#endif
