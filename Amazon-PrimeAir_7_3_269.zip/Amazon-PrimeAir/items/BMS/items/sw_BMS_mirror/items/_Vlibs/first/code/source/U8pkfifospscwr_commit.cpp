#include <U8pkfifospscwr_commit.h>

namespace Base
{
    /// \alg
    /// <ul>
    /// <li> ::v is initialized with given parameter "v0".
    /// <li> ::rd is initialized with 0.
    /// <li> ::wr is initialized with 0.
    /// <li> ::wrp is initialized with 0.
    /// </ul>
    U8pkfifospscwr_commit::U8pkfifospscwr_commit(const U8pkmblock& v0) :
        v(v0),
        rd(0U),
        wr(0U),
        wrp(0U)
    {
    }

    /// \alg
    /// <ul>
    /// <li> ::v is initialized with given parameters "sz" and "mtype".
    /// <li> ::rd is initialized with 0.
    /// <li> ::wr is initialized with 0.
    /// <li> ::wrp is initialized with 0.
    /// </ul>
    U8pkfifospscwr_commit::U8pkfifospscwr_commit(Uint32 sz, Memmgr::Type mtype) :
        v(sz, mtype),
        rd(0U),
        wr(0U),
        wrp(0U)
    {
    }

    bool U8pkfifospscwr_commit::write(Uint8 element)
    {
        /// \alg
        /// <ul>
        /// <li> Initialize variable "ret" and set it to False.
        bool ret = false;
        // only writes wr, so no mutex is needed
        /// <li> Call ::next with ::wr and assign the retreived index in a variable "nxt".
        Uint32 nxt = next(wr);
        /// <li> If ::rd NOT equal to "nxt":
        if(rd != nxt)
        {
            /// <ul>
            /// <li> Call U8pkmblock::set for ::v with ::wr and given "element".
            v.set(wr, element);
            /// <li> Assign "nxt" to ::wr.
            wr = nxt;
            /// <li> Assign True to "ret".
            ret = true;
            /// </ul>
        }
        /// <li> Return "ret".
        return ret;
        /// </ul>
    }

    bool U8pkfifospscwr_commit::read(Uint8& element)
    {
        /// \alg
        /// <ul>
        /// <li> Initialize variable "ret" and set it to False.
        bool ret = false;
        // only writes rd, so no mutex is needed
        /// <li> If ::rd_available returns True:
        if(rd_available())
        {
            /// <ul>
            /// <li> Call ::next with ::rd and assign the retreived index in a variable "nxt".
            Uint32 nxt = next(rd);
            /// <li> Call U8pkmblock_k::get for ::v with ::rd and store the retrieved value in given "element".
            element = v.get(rd);
            /// <li> Assign "nxt" to ::rd.
            rd=nxt;
            /// <li> Assign True to "ret".
            ret = true;
            /// </ul>
        }
        /// <li> Return "ret".
        return ret;
        /// </ul>
    }
}
