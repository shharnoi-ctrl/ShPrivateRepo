#include <Kclk.h>

namespace
{
    void dummy()
    {
    }
}
