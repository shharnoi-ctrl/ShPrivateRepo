#include <ISRmgr.h>
#include <Asm.h>
#include <Assertions.h>
#include <Hregmap.h>
#include <Tnarray.h>

#include "Piectrl.h" //PRQA S 1015
#include "Default_isr.h" //PRQA S 1015

namespace Dsp28335_ent
{
    static const Uint32 isr_table_addr = 0x000D00UL;
    typedef Base::Tnarray<Isrptr, ISRmgr::pie_vect_sz> Pie_vect_table;
    typedef Hregmap::Handler<Pie_vect_table, isr_table_addr> Hpie_vect_table;

    void ISRmgr::init()
    {
        Hpie_vect_table isr_table;
        asm_eallow();
        for(int16 i=0; i < pie_vect_sz; i++)
        {
            if(i != 0) // First ptr is for debugging only. Do not change.
            {
                isr_table.regs[i] = Default_isr::isr;
            }
        }

        asm_edis();

        // Enable the PIE Vector Table
        Piectrl::enable_pie();
    }

    void ISRmgr::set_isr(Pievectid id, Isrptr func)
    {
        Hpie_vect_table isr_table;
        if(Base::Assertions::runtime(id < pie_vect_sz))
        {
            asm_eallow();
            isr_table.regs[id] = func;
            asm_edis();
        }
    }
}
