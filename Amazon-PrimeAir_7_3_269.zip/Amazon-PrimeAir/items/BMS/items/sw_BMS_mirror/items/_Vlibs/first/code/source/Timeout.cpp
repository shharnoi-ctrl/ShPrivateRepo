#include <Timeout.h>
#include <Kclk.h>

namespace Base
{
    Timeout::Timeout(Real time) :
        t_out(t_to_ticks(time, Bsp::Kclk::get_sysclkfreq_u32()))
    {
        compute_t_exp();
    }

    void Timeout::set_timeout_s(Real time)
    {
        t_out = t_to_ticks(time, Bsp::Kclk::get_sysclkfreq_u32());
        compute_t_exp();
    }
}
