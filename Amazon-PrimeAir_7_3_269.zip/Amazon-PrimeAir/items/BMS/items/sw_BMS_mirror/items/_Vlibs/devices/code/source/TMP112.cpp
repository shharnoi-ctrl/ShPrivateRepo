#include <TMP112.h>

#include <U8istream.h>

namespace Devices
{
    static const Real reset_delay = 0.026F; ///< After power-up, 26ms to wait first temperature measurement.

    TMP112::TMP112(Params params):
        I2Cdevice(params.i2c_hdlr, params.i2c_addr, i2c_buff_size, params.var_buit),
        period_current(get_default_period()),
        state(st_init),
        tout(reset_delay),
        tmp(params.var_meas)
    {
        /// \alg
        /// <ul>
        /// <li> Initialize attributes as following: <ul>
        /// Name            | Value
        /// --------------- | ----------------------------------------------
        /// I2Cdevice       | I2Cdevice(::i2c0, ::addr0, 2, ::bit0)
        /// period_current  | Returned value from get_default_period call
        /// state           | st_init
        /// tout            | reset_delay
        /// tmp             | tmp0
        /// </ul>
        /// <li> Then call set_desired_rate from I2Cdevice::callst with get_desired_rate returned value.
        /// </ul>
        callst.set_desired_rate(get_desired_rate());
    }

    Real TMP112::get_default_period() const
    {
        /// \alg
        /// <ul>
        ///     <li> We need 2 steps to collect one sample as:
        ///     <ul>
        ///         <li> One step to request sample.
        ///         <li> One step to read response.
        ///     </ul>
        ///     <li> Return result from calling I2Cdevice::get_default_period0 with required number steps.
        return I2Cdevice::get_default_period0(req_steps);
        /// </ul>
    }

    void TMP112::send_request()
    {
        /// \alg
        /// <ul>
        /// <li> Request I2C write operation by calling using I2Cdevice::send with unique data byte to zero value.
        static const Uint16 temperature_register = 0; // fromp datasheet at 7.5.1, P0/P1 = 0 for temperature register.
        /// <li> If it fails, assert a warning and fix state to st_error.
        const bool is_ok = Base::Assertions::runtime(send(temperature_register));
        /// <li> Else, fix state to st_read.
        state = static_cast<State>((is_ok*st_read) + (!is_ok*st_error));
    }

    void TMP112::gather_data()
    {
        /// \alg
        /// <ul>
        /// <li> Retrieve data content as byte input stream.
        Base::U8istream istr(get_buffer());
        /// <li> Store get_uint16 returned value from stream onto tmp.
        tmp = istr.get_uint16_le();   // from datasheet at 7.3.2.3, assuming little-endian.
        /// <li> Use call method from callst to compute statistics and set device bit consecuently.
        callst.call();
        /// <li> Fix state to st_request.
        state = st_request;
        /// </ul>
    }

    void TMP112::do_step()
    {
        /// \alg
        /// <ul>
        /// <li> Depending on state value: <ul>
        switch(state)
        {
            /// <li> At st_init: <ul>
            case st_init:
            {
                /// <li> Call send_request method if time out expired. </ul>
                tout.expired() && (send_request(), true);
                break;
            }
            /// <li> At st_request: <ul>
            case st_request:
            {
                /// <li> Call send_request method. </ul>
                send_request();
                break;
            }
            /// <li> At st_read: <ul>
            case st_read:
            {
                /// <li> Call gather_data method. </ul>
                gather_data();
                break;
            }
            /// <li> At st_error: <ul>
            case st_error:
            {
                /// <li> Assert a warning.
                Bsp::warning();
                /// <li> Clear I2Cdevice::callst bit by calling set_ready with true as parameter.
                callst.set_ready(true);
                /// <li> Then retry performing a new request by fixing state to st_request.
                state = st_request;
                /// </ul>
                break;
            }
            /// </ul>
        }
        /// </ul>
    }
}
