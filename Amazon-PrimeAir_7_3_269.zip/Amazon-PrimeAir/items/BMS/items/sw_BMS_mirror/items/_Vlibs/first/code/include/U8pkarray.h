#ifndef U8PKARRAY_H_
#define U8PKARRAY_H_

#include <Tnarray.h>
#include <U8pkmblock.h>
#include <U8pkmblock_k.h>

namespace Base
{
    /// Array of bytes, packed in native words of 16 bits.
    template <Uint32 n>
    class U8pkarray
    {
    public:
        /// U8pkarray size.
        /// \wi{5293}
        /// U8pkarray class shall provide the capability to retrieve its maximum number of bytes.
        /// \return Total number of bytes.
        static Uint32 size();

        /// U8pkarray set byte value.
        /// \wi{5292}
        /// U8pkarray class shall provide the capability to set byte's value at provided index.
        /// \param[in] i        Index of the byte that shall be modified.
        /// \param[in] value    Value that shall be set to the byte at provided index.
        void set(Uint32 i, Uint8 value);

        /// U8pkarray get byte value.
        /// \wi{5291}
        /// U8pkarray class shall provide the capability to access byte's value at provided index.
        /// \param[in] i        Index of the byte that shall be accessed.
        /// \return Byte's value at provided index.
        Uint8 get(Uint32 i)const;

        /// U8pkarray get volatile byte value.
        /// \wi{16246}
        /// U8pkarray class shall provide the capability to access byte's value at provided index.
        /// \param[in] i        Index of the byte that shall be accessed.
        /// \return Byte's value at provided index.
        Uint8 get(Uint32 i)const volatile;

        /// U8pkarray zeros.
        /// \wi{5290}
        /// U8pkarray class shall provide the capability to set zero value to all its bytes.
        void zeros();

        /// U8pkarray copy.
        /// \wi{5288}
        /// U8pkarray class shall provide the capability to bulk the content of an other U8pkarray object.
        /// \param[in] src      Reference to the U8pkarray wich content shall be be copied.
        template <Uint32 n2>
        void copy(const U8pkarray<n2>& src);

        /// U8pkarray set all.
        /// \wi{5289}
        /// U8pkarray class shall provide the capability to set an unique value to all its bytes.
        /// \param[in] value        Byte value that shall be set.
        void set_all(Uint8 value);

        /// U8pkarray to bytes memory block.
        /// \wi{16247}
        /// U8pkarray class shall provide the capability to return its content through a bytes memory block.
        /// \return Bytes (unsigned 8-bit integer) memory block.
        U8pkmblock to_mblock8();

        /// U8pkarray to Volatile Bytes Memory Block.
        /// \wi{20200}
        /// U8pkarray class shall provide the capability to return its content through a volatile bytes memory block.
        /// \return Bytes (unsigned 8-bit integer) volatile memory block.
        U8pkmblock to_mblock8() volatile;

        /// U8pkarray to constant bytes memory block.
        /// \wi{16248}
        /// U8pkarray class shall provide the capability to return its content through a constant bytes memory block.
        /// \return Bytes (unsigned 8-bit integer) constant memory block.
        U8pkmblock_k to_mblock8() const;

        /// U8pkarray to constant volatile bytes memory block.
        /// \wi{16249}
        /// U8pkarray class shall provide the capability to return its content through a constant
        /// volatile bytes memory block.
        /// \return Bytes (unsigned 8-bit integer) constant volatile memory block.
        U8pkmblock_k to_mblock8() const volatile;

        /// U8pkarray to words memory block.
        /// \wi{16250}
        /// U8pkarray class shall provide the capability to return its content through a words memory block.
        /// \return Words (unsigned 16-bits integer) memory block.
        Mblock_u16 to_mblock16() const;

        /// U8pkarray to volatile words memory block.
        /// \wi{16251}
        /// U8pkarray class shall provide the capability to return its content through a words memory block.
        /// \return Words (unsigned 16-bits integer) volatile memory block.
        Mblock_u16 to_mblock16() const volatile;

        /// U8pkarray Pointer Fixed-size Array Retriever.
        /// \wi{20201}
        /// U8pkarray class shall be able to retrieve a pointer of its internal fixed-size array.
        /// \return Pointer of its internal fixed-size array.
        inline void* get_pt()
        {
            /// \alg
            /// - Return Tnarray::v in ::v.
            return v.v;
        }

        /// U8pkarray Constant Pointer Fixed-size Array Retriever.
        /// \wi{20202}
        /// U8pkarray class shall be able to retrieve a constant pointer of its internal fixed-size array.
        /// \return Constant pointer of its internal fixed-size array.
        inline const void* get_pt() const
        {
            /// \alg
            /// - Return Tnarray::v in ::v.
            return v.v;
        }

    private:
        Tnarray<int16,((n+1)>>1) > v;       ///< Static fixed size array.
    };

    template <Uint32 n>
    inline Uint32 U8pkarray<n>::size()
    {
        return n;
    }

    template <Uint32 n>
    inline void U8pkarray<n>::set(Uint32 i, Uint8 value)  //PRQA S 4211 #const
    {
        Bitutils::set_u8(v.v, i, value);
    }

    template <Uint32 n>
    inline Uint8 U8pkarray<n>::get(Uint32 i)const
    {
        return Bitutils::get_u8(v.v, i);
    }

    template <Uint32 n>
    inline Uint8 U8pkarray<n>::get(Uint32 i)const volatile
    {
        return Bitutils::get_u8(v.v, i);
    }

    template <Uint32 n>
    inline void U8pkarray<n>::zeros()
    {
        v.zeros();
    }

    template <Uint32 n>
    template <Uint32 n2>
    inline void U8pkarray<n>::copy(const U8pkarray<n2>& src)
    {
        v.copy(src.v);
    }

    template <Uint32 n>
    inline void U8pkarray<n>::set_all(Uint8 value)
    {
        int16 aux;
        Bitutils::set_u8(&aux, Ku32::u0, value);
        Bitutils::set_u8(&aux, Ku32::u1, value);
        v.set_all(aux);
    }

    template <Uint32 n>
    inline U8pkmblock U8pkarray<n>::to_mblock8()
    {
        return U8pkmblock(v.v, n);
    }

    template <Uint32 n>
    inline U8pkmblock U8pkarray<n>::to_mblock8() volatile
    {
        return U8pkmblock(v.v, n);
    }

    template <Uint32 n>
    inline U8pkmblock_k U8pkarray<n>::to_mblock8() const
    {
        return U8pkmblock_k(v.v, n);
    }

    template <Uint32 n>
    inline U8pkmblock_k U8pkarray<n>::to_mblock8() const volatile
    {
        return U8pkmblock_k(v.v, n);
    }

    template <Uint32 n>
    inline Mblock_u16 U8pkarray<n>::to_mblock16() const
    {
        return Mblock_u16(reinterpret_cast<Uint16*>(const_cast<int16*>(v.v)), bytes_to_words16_c<n>::value);
    }

    template <Uint32 n>
    inline Mblock_u16 U8pkarray<n>::to_mblock16() const volatile
    {
        return Mblock_u16(reinterpret_cast<Uint16*>(const_cast<int16*>(v.v)), bytes_to_words16_c<n>::value);
    }
}
#endif
