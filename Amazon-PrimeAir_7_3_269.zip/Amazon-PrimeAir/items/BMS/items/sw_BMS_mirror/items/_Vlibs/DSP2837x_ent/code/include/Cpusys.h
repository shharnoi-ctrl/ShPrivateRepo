#ifndef CPUSYS_H_
#define CPUSYS_H_

#include <Entypes.h>

namespace Dsp28335_ent
{
    ///    Cpusys class declaration for DSP2837x processor.
    ///
    class Cpusys
    {
    public:
        /// Peripheral type. Value is also the index in the Registers.
        enum Peripheral_t
        {
            clk_general   =  0,     ///< Miscellaneous peripherals register.
            clk_emif      =  1,     ///< EMIF peripherals.
            clk_pwm       =  2,     ///< PWM modules.
            clk_ecap      =  3,     ///< ECAP modules.
            clk_equep     =  4,     ///< EQEP modules.
            // 5 is reserved
            clk_sd        =  6,     ///< SD modules.
            clk_sci       =  7,     ///< SCI modules.
            clk_spi       =  8,     ///< SPI modules
            clk_i2c       =  9,     ///< I2C modules.
            clk_can       = 10,     ///< CAN modules.
            clk_mcbsp_usb = 11,     ///< McBSP and USB modules.
            // 12 is reserved
            clk_adc       = 13,     ///< ADC modules.
            clk_cmpss     = 14,     ///< CMPSS modules.
            // 15 is reserved
            clk_dac       = 16,     ///< DAC modules.
            clk_clb       = 17,     ///< CLB modules. Only for 2838x.
            clk_fsi       = 18,     ///< FSI modules. Only for 2838x.
            // 19 is reserved
            clk_pmbus     = 20,     ///< PMBUS modules. Only for 2838x.
            clk_dcc       = 21,     ///< DCC modules. Only for 2838x.
            clk_mpost     = 22,     ///< MPOST modules. Only for 2838x.
            clk_ethercat  = 23      ///< EtherCAT modules. Only for 2838x.
        };

        static const Uint16 reg_sz = 32U; ///< Size of each CLK register.

        /// Peripheral identifiers for CLK enable.
        /// Highest 32bit is the Peripheral_t, lower 32bits are flags for each of the 32 possible
        /// modules to be enabled that peripheral.
        enum Peripheral
        {
            clk_dma     = (static_cast<Uint64>(clk_general) << reg_sz) | 0x04,   //!< clk_dma
            clk_timer0  = (static_cast<Uint64>(clk_general) << reg_sz) | 0x08,   //!< clk_timer0
            clk_timer1  = (static_cast<Uint64>(clk_general) << reg_sz) | 0x10,   //!< clk_timer1
            clk_timer2  = (static_cast<Uint64>(clk_general) << reg_sz) | 0x20,   //!< clk_timer2

            clk_emif1   = (static_cast<Uint64>(clk_emif) << reg_sz) | 0x01,      //!< clk_emif1
            clk_emif2   = (static_cast<Uint64>(clk_emif) << reg_sz) | 0x02,      //!< clk_emif2

            clk_ecap1   = (static_cast<Uint64>(clk_ecap) << reg_sz) | 0x01,      //!< clk_ecap1
            clk_ecap2   = (static_cast<Uint64>(clk_ecap) << reg_sz) | 0x02,      //!< clk_ecap2
            clk_ecap3   = (static_cast<Uint64>(clk_ecap) << reg_sz) | 0x04,      //!< clk_ecap3
            clk_ecap4   = (static_cast<Uint64>(clk_ecap) << reg_sz) | 0x08,      //!< clk_ecap4
            clk_ecap5   = (static_cast<Uint64>(clk_ecap) << reg_sz) | 0x10,      //!< clk_ecap5
            clk_ecap6   = (static_cast<Uint64>(clk_ecap) << reg_sz) | 0x20,      //!< clk_ecap6
            clk_ecap7   = (static_cast<Uint64>(clk_ecap) << reg_sz) | 0x40, // Only for 2838x

            clk_scia    = (static_cast<Uint64>(clk_sci) << reg_sz) | 0x01,       //!< clk_scia
            clk_scib    = (static_cast<Uint64>(clk_sci) << reg_sz) | 0x02,       //!< clk_scib
            clk_scic    = (static_cast<Uint64>(clk_sci) << reg_sz) | 0x04,       //!< clk_scic
            clk_scid    = (static_cast<Uint64>(clk_sci) << reg_sz) | 0x08,       //!< clk_scid

            clk_spia    = (static_cast<Uint64>(clk_spi) << reg_sz) | 0x01,       //!< clk_spia
            clk_spib    = (static_cast<Uint64>(clk_spi) << reg_sz) | 0x02,       //!< clk_spib
            clk_spic    = (static_cast<Uint64>(clk_spi) << reg_sz) | 0x04,       //!< clk_spic
            clk_spid    = (static_cast<Uint64>(clk_spi) << reg_sz) | 0x08, // Only for 2838x

            clk_i2ca    = (static_cast<Uint64>(clk_i2c) << reg_sz) | 0x01,       //!< clk_i2ca
            clk_i2cb    = (static_cast<Uint64>(clk_i2c) << reg_sz) | 0x02,       //!< clk_i2cb

            clk_cana    = (static_cast<Uint64>(clk_can) << reg_sz) | 0x01,       //!< clk_cana
            clk_canb    = (static_cast<Uint64>(clk_can) << reg_sz) | 0x02,       //!< clk_canb
            clk_canfd_a = (static_cast<Uint64>(clk_can) << reg_sz) | 0x10, // Only for 2838x

            clk_mcbspa  = (static_cast<Uint64>(clk_mcbsp_usb) << reg_sz) | 0x00001,//!< clk_mcbspa
            clk_mcbspb  = (static_cast<Uint64>(clk_mcbsp_usb) << reg_sz) | 0x00002,//!< clk_mcbspb
            clk_usba    = (static_cast<Uint64>(clk_mcbsp_usb) << reg_sz) | 0x10000,//!< clk_usba

            clk_adc_all = (static_cast<Uint64>(clk_adc) << reg_sz) | 0x0F        //!< clk_adc_all
        };

        Cpusys();

        /// Enables a peripheral clk.
        void clk_enable(Peripheral p);

        /// Disables a peripheral clk.
        void clk_disable(Peripheral p);

        /// Enables the clk of the specified peripheral device.
        /// \param pt       Peripheral type.
        /// \param dev_num  Device number.
        void clk_enable(Peripheral_t pt, Uint32 dev_num);

        /// Enables the clk of the specified peripheral device.
        /// \param pt     Peripheral type.
        /// \param dev_num  Device number.
        void clk_disable(Peripheral_t pt, Uint32 dev_num);

        /// Enables the clk of the specified peripheral device.
        /// \param p Peripheral.
        /// \param en     Enable or disable the device
        inline void clk_enable_set(Peripheral p, bool en)
        {
            en ? clk_enable(p) : clk_disable(p);
        }

        /// Enables the clk of the specified peripheral device.
        /// \param pt     Peripheral type.
        /// \param devid  Device Id.
        /// \param en     Enable or disable the device
        inline void clk_enable_set(Peripheral_t pt, Uint32 devid, bool en)
        {
            en ? clk_enable(pt, devid) : clk_disable(pt, devid);
        }

        /// Enables clock for a PWM module.
        /// \param module_id Module id (0..11)
        void clk_enable_pwm(Uint16 module_id);

        /// Sets peripheral frame control to DMA (instead of CLA)
        void pfsel_dma();

        /// \return CPU Timer 2 Clock Source Select
        Uint16 get_tmr2clkctl_srcsel() const;
        /// \return CPU Timer 2 Clock Pre-Scale Value
        Uint16 get_tmr2clkctl_prescale() const;
        /// Sets CPU Timer 2 Clock settings.
        /// \param srcsel CPU Timer 2 Clock Source Select
        /// \param prescale CPU Timer 2 Clock Pre-Scale Value
        void set_tmr2clkctl(Uint16 srcsel, Uint16 prescale);

        /// \return True if JTAG connection active.
        bool is_jtag_connected() const;
        /// \return True if last reset cause was watchdog reset.
        bool is_reset_wdog_flag() const;
        /// Clears flag indicating last reset cause was watchdog.
        void clear_reset_wdog_flag() const;

    private:
        struct Registers;
        volatile Registers& regs;

        Cpusys(const Cpusys& orig); // = delete
        Cpusys& operator=(const Cpusys& orig); // = delete
    };
}
#endif
