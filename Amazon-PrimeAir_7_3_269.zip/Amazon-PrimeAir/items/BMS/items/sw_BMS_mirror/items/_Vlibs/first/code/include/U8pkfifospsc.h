#ifndef U8PKFIFOSPSC_H_
#define U8PKFIFOSPSC_H_

#include <U8pkfifospsc0.h>
#include <Ttraits.h>

namespace Base
{
    class U8pkfifospsc : public type_is<Uint8>
    {
    public:
        /// Constructor with given U8pkmblock
        /// \param v U8pkmblock which use to build U8pkfifospscwr_commit
        explicit U8pkfifospsc(const U8pkmblock& v0);

        /// Constructor with size and memory type.
        /// \wi{6413}
        /// U8pkfifospsc class shall build itself upon construction with a given number of bytes for 
        /// the FIFO and its memory location.
        /// \param[in] sz Size of the FIFO buffer.
        /// \param[in] mtype Memory type for the FIFO buffer.
        U8pkfifospsc(Uint32 sz, Memmgr::Type mtype);


        //Access methods to U8pkfifospsc

        /// U8pkfifospsc Writer.
        /// \wi{6417}
        /// U8pkfifospsc class shall provide a method to write a given byte on U8pkfifospsc0 object if possible.
        /// \param[in] element Byte to be written.
        /// \return True if the action has succeeded, False if not.
        bool write(Uint8 element);

        /// U8pkfifospsc Reader.
        /// \wi{6416}
        /// U8pkfifospsc class shall provide a method to read a byte from queue if possible.
        /// \param[in] element Byte reference where retrieve read value.
        /// \return True if the action has succeeded, False if not.
        bool read(Uint8& element);

        /// Read Availability Checker.
        /// \wi{6414}
        /// U8pkfifospsc class shall provide the capability to determine if there is a new byte to read from the FIFO.
        /// \return True if read pointer is different from write pointer, False if not.
        bool rd_available() const;

        /// Write Availability Checker.
        /// \wi{6415}
        /// U8pkfifospsc class shall provide the capability to determine if a new byte can be writen into the FIFO.
        /// \return True if next write pointer is different from read pointer, False if not.
        bool wr_available() const;

        /// Available Reading Account Retriever.
        /// \wi{6446}
        /// U8pkfifospsc class shall provide the capability to retrieve the available memory in bytes 
        /// for reading from the queue. 
        /// \return The number of bytes available for reading.
        Uint32 rd_available_count() const;  

        /// Available Writing Account Retriever.
        /// \wi{6447}
        /// U8pkfifospsc class shall provide the capability to retrieve the available memory in bytes 
        /// for writing to the queue.
        /// \return The number of bytes available for writing.
        Uint32 wr_available_count() const;  

    private:
        U8pkmblock v;      ///< Queue buffer.
        Uint32 rd;         ///< Read index.
        Uint32 wr;         ///< Write index.

        U8pkfifospsc0 fifo; ///< Fifo object.

        U8pkfifospsc();                                     ///< = delete
        U8pkfifospsc(const U8pkfifospsc& orig);             ///< = delete
        U8pkfifospsc& operator=(const U8pkfifospsc& orig); ///< = delete
    };

    inline U8pkfifospsc::U8pkfifospsc(const U8pkmblock& v0) :
        v(v0), // In circular buffers the real container size is one less than the buffer size
        rd(0),
        wr(0),
        fifo(v, rd, wr)
    {
    }

    inline bool U8pkfifospsc::rd_available() const
    {
        /// \alg
        /// - Return U8pkfifospsc0::rd_available retrieved value for ::fifo.
        return fifo.rd_available();
    }

    inline Uint32 U8pkfifospsc::rd_available_count() const
    {
        /// \alg
        /// - Return U8pkfifospsc0::rd_available_count retrieved value for ::fifo.
        return fifo.rd_available_count();
    }

    inline bool U8pkfifospsc::wr_available() const
    {
        /// \alg
        /// - Return U8pkfifospsc0::wr_available retrieved value for ::fifo.
        return fifo.wr_available();
    }

    inline Uint32 U8pkfifospsc::wr_available_count() const
    {
        /// \alg
        /// - Return U8pkfifospsc0::wr_available_count retrieved value for ::fifo.
        return fifo.wr_available_count();
    }

    inline bool U8pkfifospsc::write(Uint8 element)
    {
        /// \alg
        /// - Return U8pkfifospsc0::write retrieved value for ::fifo.
        return fifo.write(element);
    }

    inline bool U8pkfifospsc::read(Uint8& element)
    {
        /// \alg
        /// - Return U8pkfifospsc0::read retrieved value for ::fifo.
        return fifo.read(element);
    }
}
#endif
