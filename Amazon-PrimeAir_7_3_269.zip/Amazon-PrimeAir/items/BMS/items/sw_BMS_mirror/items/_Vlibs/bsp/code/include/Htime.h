#ifndef HTIME_H_
#define HTIME_H_

#include <Ttime.h>
#include <Ttime32.h>

namespace Bsp
{
    struct Htime
    {
    public:
        /// Time Retriever.
        /// \wi{5653}
        /// Htime shall be able to retrieve the system time based on the tick count in a concurrent-safe way.
        /// \return Current time.
        static Base::Ttime get_time();
        
        /// Time 32 bits Retriever.
        /// \wi{6477}
        /// Htime shall be able to retrieve the system time based on the tick count as 32 bit size in a 
        /// concurrent-safe way.
        /// \return Current time with 32 bit size.
        static Base::Ttime32 get_time32();

    private:
        Htime();                                ///< = delete.
        Htime(const Htime& orig);               ///< = delete.
        ~Htime();                               ///< = delete.
        Htime& operator=(const Htime& orig);    ///< = delete.
    };
}
#endif
