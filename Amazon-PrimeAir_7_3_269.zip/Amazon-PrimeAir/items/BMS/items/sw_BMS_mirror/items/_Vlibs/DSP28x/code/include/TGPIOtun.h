#ifndef TGPIOTUN_H_
#define TGPIOTUN_H_

#include <Lossy_error.h>
#include <Enums.h>

namespace Dsp28335_ent
{
    // Base for GPIO tunable. MUX_TRAIT shall have defined:
    // - Type MUX_TRAIT::Type_mux With the type of the MUX enum.
    // - function bool MUX_TRAIT::is_valid(MUX_TRAIT::type) returning true when parameter is a valid mux.
    /// GPIO tunable
    /// The Dsp28335_ent library shall provide a class to be able to handle serialization and deserialization of GPIO
    /// tunables.
    template <typename MUX_TRAIT>
    struct TGPIOtun
    {
        typedef typename MUX_TRAIT::Type_mux Mux;   ///< Multiplexor type.

        enum Dir
        {
            dir_input  = 0, ///< GPIO as input.
            dir_output = 1  ///< GPIO as output.
        };

        enum Pullup
        {
            pu_dis = 0,     ///< Pull-up disabled.
            pu_en  = 1      ///< Pull-up enabled.
        };

        enum Qsel
        {
            qsel_sync     = 0, ///< Synchronous qualification.
            qsel_3samples = 1, ///< 3 Samples qualification.
            qsel_6samples = 2, ///< 6 Samples qualification.
            qsel_async    = 3  ///< Asynchronous qualification.
        };

        static const Uint16 dir_sz  = 2;    ///< Number of GPIO direction modes available.
        static const Uint16 pu_sz   = 2;    ///< Number of GPIO pull-up modes available.
        static const Uint16 qsel_sz = 4;    ///< Number of GPIO synchronization modes available.

        Dir         ioflag;     ///< IO flag.
        Pullup      pu;         ///< Pull-up flag.
        Mux         mux_sel;    ///< Function selection.
        Qsel        q;          ///< Qualification.

        /// Build TGPIOtun.
        /// \wi{13506}
        /// The TGPIOtun class shall provide a method to build a static TGPIOtun object.
        /// \param[in] io0 IO mode.
        /// \param[in] pu0 Pull-up selection.
        /// \param[in] mux0 Function selection.
        /// \param[in] q0 Qualification selection.
        /// \return The TGPIOtun object.
        static TGPIOtun<MUX_TRAIT> build(Dir io0,
                                         Pullup pu0,
                                         Mux mux0,
                                         Qsel q0);
        /// GPIO tunable deserialization.
        /// \wi{13507}
        /// The TGPIOtun class shall be deserializable from its PDIC.
        /// \param[in,out] str PDIC to deserialize and error flag.
        void cset(Base::Lossy_error& str);

        /// Check if valid.
        /// \wi{13509}
        /// When requested, TGPIOtun class shall return true if the applied config is valid.
        /// \return True if is valid.
        bool is_valid() const;
    };

    template <typename MUX_TRAIT>
    bool TGPIOtun<MUX_TRAIT>::is_valid() const
    {
        return (Base::Enums::is_gtez(ioflag))      && (ioflag < dir_sz)
                && (Base::Enums::is_gtez(pu))      && (pu     < pu_sz)
                && (Base::Enums::is_gtez(q))       && (q      < qsel_sz)
                && MUX_TRAIT::is_valid(mux_sel);
    }

    /// \pdi
    /// The TGPIOtun class configuration parameters shall be stored as a binary data structure as described in the
    /// following table:
    /// | Type   | Name            | Content                   |  Range  |
    /// | ------ | --------------- | ------------------------- | ------- |
    /// | Dir    |  ioflag       | IO flag configuration    | [0, dir_sz) |
    /// | Pullup |  pu           | IO flag configuration    |  [0, pu_sz) |
    /// | Mux    |  mux_sel      | IO flag configuration    | [0,  4 for Dsp28335 or 16 for Dsp2837_ent)|
    /// | Qsel   |  q            | IO flag configuration    | [0, qsel_sz) |
    template <typename MUX_TRAIT>
    void TGPIOtun<MUX_TRAIT>::cset(Base::Lossy_error& str)
    {
        str.get_enum16(ioflag);
        str.get_enum16(pu);
        str.get_enum16(mux_sel);
        str.get_enum16(q);

        str.assrt(is_valid(), Base::err_gpio);
    }

    template <typename MUX_TRAIT>
    TGPIOtun<MUX_TRAIT> TGPIOtun<MUX_TRAIT>::build(Dir io0,
                                                   Pullup pu0,
                                                   Mux mux0,
                                                   Qsel q0)
    {
        TGPIOtun<MUX_TRAIT> gpio_tun = {io0, pu0, mux0, q0};
        return gpio_tun;
    }
}
#endif
