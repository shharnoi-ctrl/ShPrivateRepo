#ifndef BITARRAY_FW_H_
#define BITARRAY_FW_H_

namespace Base
{

    template<Uint16 sz>
    struct Bitarray;

}

#endif
