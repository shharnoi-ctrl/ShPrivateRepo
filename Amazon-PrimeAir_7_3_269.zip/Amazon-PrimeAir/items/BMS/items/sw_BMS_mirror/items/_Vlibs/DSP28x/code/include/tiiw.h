#ifndef TIIW_H_
#define TIIW_H_

// this file should only be included by cpps solving C++ Template instantiation issues. 

#include <Tunarray.h>
#include <Cptraits.h>
#include <Tuntraits.h>

namespace
{

    template <typename T>
    struct Declval
    {
        static T& ref();
    };

    template <typename T>
    inline T& Declval<T>::ref()
    {
        T* ptr=0;
        return *ptr;
    }

    template <typename T, typename P>
    void build_arrayext_1param()
    {
        Base::Array<T>(0, Base::Memmgr::external, Declval<P>::ref());
    }

    template <typename T, typename P0, typename P1>
    void build_arrayext_2param()
    {
        Base::Array<T>(0, Base::Memmgr::external, Declval<P0>::ref(), Declval<P1>::ref());
    }

    template <typename T, typename P0, typename P1, typename P2>
    void build_arrayext_3param()
    {
        Base::Array<T>(0, Base::Memmgr::external, Declval<P0>::ref(), Declval<P1>::ref(), Declval<P2>::ref());
    }

    template <typename T, typename P, bool has_cget = false>
    void build_tunarrayext_1param()
    {
        Base::Tunarray<T, has_cget>(0, Base::Memmgr::external, Declval<P>::ref());
    }

    template <typename T, typename P0, typename P1>
    void build_tunarrayext_2param()
    {
        Base::Tunarray<T>(0, Base::Memmgr::external, Declval<P0>::ref(), Declval<P1>::ref());
    }

    template <typename T, Uint32 N>
    void build_tunarray_from_arraymsk()
    {
        Base::Tunarray<T>(Declval<Base::Arraymsk<T, N> >::ref());
    }

    template <typename T>
    void cptraits_podraw()
    {
        Base::Cptraits::Podraw<T>::copy(Declval<T>::ref(),Declval<T>::ref());
    }

    template <typename XCFG>
    void tuntrait_xcfg()
    {
        XCFG::Type_wstuntrait::str2elem(Declval<typename XCFG::Type_podsync>::ref(), Declval<Base::Lossy_error>::ref());
    }

    template <typename T1, typename T2>
    void tuntrait_array_no_rsz()
    {
        using namespace Base;
        using namespace Tuntraits;
        Arraytun_nosize<T1, T2>::str2elem(Declval<T2>::ref(), Declval<Base::Lossy_error>::ref());
    }

    template <typename T1, typename T2>
    void tuntrait_array()
    {
        using namespace Base;
        using namespace Tuntraits;
        Arraytun_nosize<T1, T2>::str2elem(Declval<T2>::ref(), Declval<Base::Lossy_error>::ref());
        Resize<Lossy16<Uint16>, T2>::str2elem(Declval<T2>::ref(), Declval<Base::Lossy_error>::ref());
    }

    template <typename T1, typename T2>
    void tuntrait_array_ref()
    {
        using namespace Base;
        using namespace Tuntraits;
        Arraytun_nosize<T1, T2&>::str2elem(Declval<T2>::ref(), Declval<Base::Lossy_error>::ref());
        Resize<Lossy16<Uint16>, T2&>::str2elem(Declval<T2>::ref(), Declval<Base::Lossy_error>::ref());
    }

    template <typename T, bool has_cget = false>
    void tunarray_cxet()
    {
        Declval<Base::Tunarray<T,has_cget> >::ref().cset(Declval<Base::Lossy_error>::ref());
        Declval<Base::Tunarray<T,has_cget> >::ref().cget(Declval<Base::Lossy>::ref());
    }

}
#endif
