#ifndef PIECTRL_H_
#define PIECTRL_H_

namespace Dsp28335_ent
{
    struct Piectrl
    {
    public:
        enum Group
        {
            grp01 =  0,
            grp02 =  1,
            grp03 =  2,
            grp04 =  3,
            grp05 =  4,
            grp06 =  5,
            grp07 =  6,
            grp08 =  7,
            grp09 =  8,
            grp10 =  9,
            grp11 = 10,
            grp12 = 11
        };

        enum Flag
        {
            flag_int01 = 0x0001U,
            flag_int02 = 0x0002U,
            flag_int03 = 0x0004U,
            flag_int04 = 0x0008U,
            flag_int05 = 0x0010U,
            flag_int06 = 0x0020U,
            flag_int07 = 0x0040U,
            flag_int08 = 0x0080U,
            flag_int09 = 0x0100U,
            flag_int10 = 0x0200U,
            flag_int11 = 0x0400U,
            flag_int12 = 0x0800U,
            flag_int13 = 0x1000U,
            flag_int14 = 0x2000U,
            flag_int15 = 0x4000U,
            flag_int16 = 0x8000U
        };

        /// Maskable interrupt id
        struct Mid
        {
            Group grp;
            Flag  flg;
        };

        /// Initializes the PIE control registers to a known state.
        static void init();
        /// Enable the PIE Vector Table
        static void enable_pie();
        /// Enable interrupt of related group and related flag (using TI notation: grp0.flg0).
        static void enable(Mid id);
        /// Enable interrupt of non maskable interrupt for timer 1.
        static void enable_nmi_tmr1();
        /// Enable interrupt of non maskable interrupt for timer 2.
        static void enable_nmi_tmr2();
        /// Disable interrupt of related group and related flag (using TI notation: grp0.flg0).
        static void disable(Mid id);
        /// Acknowlege interrupt of some group.
        static void ack(Group grp0);

        /// Clear given ISR flag
        static void clear_isr_flag(Mid id);
    private:
        struct Registers;
        volatile Registers& regs;

        Piectrl();

        Piectrl(const Piectrl& orig); ///< = delete
        Piectrl& operator=(const Piectrl& orig); ///< = delete
    };
}
#endif
