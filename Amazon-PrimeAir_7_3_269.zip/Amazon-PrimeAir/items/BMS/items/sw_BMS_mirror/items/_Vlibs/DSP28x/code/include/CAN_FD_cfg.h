#ifndef CAN_FD_CFG_H_
#define CAN_FD_CFG_H_

#include <CANcfg.h>
#include <Lossy_error_fw.h>

namespace Dsp28335_ent
{
    /// Configuration for CAN-FD peripheral.
    struct CAN_FD_cfg
    {
        // NOTE: combination 500k/5Mb is not working:
        enum Baudrate   ///< Baudrates for arbitration (<=1Mhz) and data (>=1Mhz).
        {
            bd_100K,    ///< 100Khz
            bd_200K,    ///< 200Khz
            bd_250K,    ///< 250Khz
            bd_500K,    ///< 500Khz
            bd_800K,    ///< 800Khz
            bd_1M,      ///< 1Mhz
            bd_2M,      ///< 2Mhz
            bd_4M,      ///< 4Mhz
            bd_5M       ///< 5Mhz
        };
        static const Uint16 baudrate_count = 9; ///< Number of different baudrates available.

        struct Timings          ///< Timings for MCAN peripheral.
        {
            Uint16 prescaler;   ///< Baud Rate Pre-scaler. ([0,511] for arbitration, [0,31] for data).
            Uint8  tseg1;       ///< Time segment before Sampling Point.
            Uint8  tseg2;       ///< Time segment after Sampling Point.
            Uint8  sjw;         ///< Sync Jump Width (SJW).

            /// CAN FD Timings Configuration Deserialization.
            /// \wi{18098}
            /// The CAN_FD_cfg::Timings structure shall be deserializable from its PDIC.
            /// \param[in,out] str Buffer to deserialize from.
            void cset(Base::Lossy_error& str);
        };

        struct Timings_ex       ///< Timing configuration.
        {
            bool use_timings;   ///< User timings or baudrate.
            Baudrate bdrt;      ///< Baudrate.
            Timings tim;        ///< Timings

            /// CAN FD Timings Extended Configuration Deserialization.
            /// wi{18099}
            /// The CAN_FD_cfg::Timings_ex structure shall be deserializable from its PDIC.
            /// \param[in,out] str Buffer to deserialize from.
            void cset(Base::Lossy_error& str);
        };

        bool can_fd_mode;       ///< Use CAN-FD mode (true) or CAN20 (false).
        bool enable_brs;        ///< Enable Bit Rate Switch.

        Timings_ex arb;         ///< Arbitration timings configuration.
        Timings_ex data;        ///< Data timings configuration.

        CANcfg::Trx_array rx_cfg;   ///< Configuration for each Rx filter.

        /// CAN FD Configuration Deserialization.
        /// \wi{18100}
        /// The CAN_FD_cfg structure shall be deserializable from its PDIC.
        /// \param[in,out] str Buffer to deserialize.
        void cset(Base::Lossy_error& str);

        /// Validate Configuration for Arbitration.
        /// \wi{18101}
        /// CAN_FD_cfg shall provide a method to check if the arbitration timings setup is valid.
        /// \return True values are valid or False if not.
        bool validate_arb();

        /// Validate Configuration for Data.
        /// \wi{18102}
        /// CAN_FD_cfg shall provide a method to check if the arbitration timings setup is valid.
        /// \return True values are valid or False if not.
        bool validate_data();
    };
}
#endif
