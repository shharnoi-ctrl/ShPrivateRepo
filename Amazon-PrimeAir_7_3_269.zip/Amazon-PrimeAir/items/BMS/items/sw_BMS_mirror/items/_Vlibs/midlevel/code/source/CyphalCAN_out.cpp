#include <CyphalCAN_out.h>
#include <Bitutils.h>
#include <CAN_FD.h>
#include <Rfun.h>

namespace Cyphal
{
    using namespace Base;

    /// \alg
    /// <ul>
    /// <li> ::max_can_sz is initialized with ::max_can_fd_sz if given "use_fd" is True, otherwise 
    /// with ::max_can_20_sz.
    /// <li> ::out_fifo is initialized by a Base::U8pkmblock instance initialized with the following parameters:
    /// <ul>
    /// <li> (Cyphal_msg::hdr_sz + ::max_can_sz + 1) * 2 + 1.
    /// <li> Given "alloc".
    /// </ul>
    /// <li> ::transfer_started is initialized with false.
    /// <li> ::pl_size is initialized with 0.
    /// <li> ::extra_size is initialized with 0.
    /// <li> ::pending_bytes is initialized with 1.
    /// <li> ::curr_tb is initialized with Tail_byte::build.
    /// <li> ::cy_can_id is initialized with default.
    /// <li> ::needs_crc is initialized with false.
    /// <li> ::crc16 is initialized with ::crc_cyphal
    /// <li> ::n_errors is initialized with 0.
    /// </ul>
    CyphalCAN_out::CyphalCAN_out(Allocator& alloc, bool use_fd) :
        max_can_sz(use_fd ? max_can_fd_sz: max_can_20_sz),
        out_fifo(U8pkmblock((Cyphal_msg::hdr_sz + max_can_sz + 1) * Ku16::u2 + 1, alloc)),
        transfer_started(false),
        pl_size(0),
        extra_size(0),
        pending_bytes(1),
        curr_tb(Tail_byte::build()),
        cy_can_id(),
        needs_crc(false),
        crc16(crc_cyphal),
        n_errors(0)
    {
        /// <ul>
        /// <li> CyCAN_id::all in ::cy_can_id is initialized with 0.
        /// </ul>
        cy_can_id.all = 0;
    }

    bool CyphalCAN_out::read(Itproducer_can::type_prod& frame)
    {
        bool res = false;

        /// \alg
        /// <ul>
        /// <li> If ::transfer_started NOT True:       
        if (!transfer_started) 
        {
            const Uint32 av = out_fifo.rd_available_count();
            //If the count of available data in the fifo is greater of equal to ::hdr_data_sz.
            /// <ul>
            /// <li> If U8pkfifospsc::rd_available_count for ::out_fifo is greater than or equal to Cyphal_msg::hdr_sz:
            if(av >= Cyphal_msg::hdr_sz)
            {
                /// <ul>
                /// <li> Assign 0 to Uint8 variables "d8", "d8_2", "d8_3" and "d8_4".
                Uint8 d8   = 0;
                Uint8 d8_2 = 0;
                Uint8 d8_3 = 0;
                Uint8 d8_4 = 0;

                //Read next available byte from the fifo.
                /// <li> Call U8pkfifospsc::read for ::out_fifo with "d8".
                out_fifo.read(d8);
                //If is a start byte.
                /// <li> If "d8" is equal to Cyphal_msg::start_byte:
                if(d8 == Cyphal_msg::start_byte) 
                {
                    /// <ul>
                    /// <li> Call CRC::reset for ::crc16.
                    crc16.reset();                  

                    /// <li> Assign True to ::transfer_started and Tail_byte::sot in ::curr_tb.
                    transfer_started = true;        
                    curr_tb.sot = true;             
                    /// <li> Assign False to Tail_byte::eot in ::curr_tb.
                    curr_tb.eot = false;
                    /// <li> Assign True to Tail_byte::toggle_bit in ::curr_tb.
                    curr_tb.toggle_bit = true;      
                    /// <li> Increment Tail_byte::transfer_id in  ::curr_tb by 1.
                    curr_tb.transfer_id++;          

                    /// <li> Call U8pkfifospsc::read for ::out_fifo with "d8", "d8_2", "d8_3" and "d8_4" separately.
                    out_fifo.read(d8);                    
                    out_fifo.read(d8_2);
                    out_fifo.read(d8_3);
                    out_fifo.read(d8_4);
                    
                    //Read subject and store it in ::cy_can_id.subject.
                    /// <li> Call Bitutils::get_u16 with "d8_4", "d8_3" and 
                    /// combine them into a 16-bit unsigned integer.
                    /// <li> Call Bitutils::get_u16 with "d8_2", "d8" and combine them into a 16-bit unsigned integer.
                    /// <li> Call Bitutils::get_u32 with previous outputs 
                    /// and combines them into a 32-bit unsigned integer.
                    /// <li> Assign the 32-bit unsigned integer output to CyCAN_id::all in ::cy_can_id.
                    cy_can_id.all = Bitutils::get_u32(Bitutils::get_u16(d8_4, d8_3), Bitutils::get_u16(d8_2, d8));

                    /// <li> Call U8pkfifospsc::read for ::out_fifo with "d8" and "d8_2" separately.
                    out_fifo.read(d8);                  
                    out_fifo.read(d8_2);
                    /// <li> Call Bitutils::get_u16 with "d8_2", "d8" and store 
                    /// the combined 16-bit unsigned integer in ::pl_size.
                    pl_size = Bitutils::get_u16(d8_2, d8); 

                    /// <li> Assign True to CANid::extended in CANframe::id of given "frame".
                    frame.id.extended = true;           
                    /// <li> Assign CyCAN_id:.all in ::cy_can_id to CANid::id in CANframe::id of given "frame".
                    frame.id.id = cy_can_id.all;      
                    /// <li> Call U8pkrszarray::resize for CANdata::data with 0 in CANframe::data of given "frame".
                    frame.data.data.resize(0);          

                    /// <li> If ::pl_size is greater than ::max_can_sz store True 
                    /// to ::needs_crc, otherwise store False to ::needs_crc.
                    needs_crc = (pl_size > max_can_sz);
                    /// <li> If ::needs_crc is True store ::crc_size in "crc_bytes", otherwise store 0 to "crc_bytes".
                    const Uint8 crc_bytes = needs_crc ? crc_size : 0U;                    
                    //Compute Length of last frame as frame length + 1 (for tail byte).
                    /// <li> Compute the remainder of the sum of ::pl_size plus ::crc_bytes divided by ::max_can_sz.
                    /// <li> Add 1 to the remainder and store the result in "last_f_len".
                    const Uint8 last_f_len = ((pl_size + crc_bytes) % max_can_sz) + 1U;
                    // Get as DLC
                    /// <li> Call Dsp28335_ent::CAN_FD::len_to_dlc with "last_f_len" and store 
                    /// the result in constant Dsp28335_ent::CAN_FD::DLC variable "dlc".
                    const Dsp28335_ent::CAN_FD::DLC dlc = Dsp28335_ent::CAN_FD::len_to_dlc(last_f_len);
                    // Compute padding byte count as dlc_len - frame len
                    /// <li> Call Dsp28335_ent::CAN_FD::dlc_to_len with "dlc" and store the result in  "dlc_len".
                    const Uint8 dlc_len = Dsp28335_ent::CAN_FD::dlc_to_len(dlc);
                    /// <li> Subtract "last_f_len" from "dlc_len" and store the result in "padding".
                    const Uint8 padding = dlc_len - last_f_len;
                    /// <li> Add "padding" with "crc_bytes" and store the result in ::extra_size.
                    extra_size = padding + crc_bytes; // padding + crc
                    /// <li> Add ::pl_size with ::extra_size and store the result in ::pending_bytes.
                    pending_bytes = pl_size + extra_size;
                    /// </ul>
                } 
                /// </ul>
            } 
            /// </ul>
        }   
        /// <li> Call U8pkfifospsc::rd_available_count for ::out_fifo and store the result in "av".
        const Uint32 av = out_fifo.rd_available_count();
        res = transfer_started &&
              ( (av >= max_can_sz) || 
                ((pending_bytes-extra_size) <= av) ||
                (pending_bytes <= extra_size)
              );
        /// <li> If ::transfer_started True AND "av" is greater than or equal to ::max_can_sz 
        /// OR ::pending_bytes minus ::extra_size is less than or equal to "av"
        /// OR ::pending_bytes is less than or equal to ::extra_size:
        if(res)
        {
            /// <ul>      
            /// <li> Assign CyCAN_id::all in ::cy_can_id to CANid::id in CANframe::id of given "frame".
            frame.id.id = cy_can_id.all;       
            /// <li> Call U8pkrszarray::resize for CANdata::data in CANframe::data of given "frame" with 0.
            frame.data.data.resize(0);
            /// <li> If ::pending_bytes is greater than ::extra_size:
            if(pending_bytes > extra_size)
            {
                /// <ul>
                /// <li> Call Rfun::min with the value of (::pending_bytes - ::extra_size) and ::max_can_sz.
                const Uint16 to_copy = Rfun::min<Uint16>(pending_bytes - extra_size, max_can_sz);
                /// <li> Assign 0 to "d8".
                Uint8 d8 = 0;
                /// <li> Call U8pkrszarray::resize for CANdata::data in CANframe::data of given "frame" with "to_copy".
                frame.data.data.resize(to_copy);
                /// <li> Initialize "i" to 0 and iterate until "i" is less than "to_copy":
                for(Uint16 i = 0; i < to_copy; i++)
                {
                    /// <ul>
                    /// <li> Call U8pkfifospsc::read for ::out_fifo with "d8" and store the result in "res".
                    const bool res = out_fifo.read(d8);
                    /// <li> Increment ::n_errors by 1 if "res" is False.
                    n_errors += !res;
                    /// <li> Call U8pkrszarray::set for CANdata::data in CANframe::data 
                    /// of given "frame" with "i" and "d8".
                    frame.data.data.set(i, d8);
                    /// <li> If ::needs_crc is True:
                    if(needs_crc)
                    {
                        /// <ul>
                        /// <li> Call CRC::update_byte for crc16 with "d8".
                        crc16.update_byte(d8);
                        /// </ul>
                    }
                    /// <li> Decrement ::pending_bytes by 1.
                    pending_bytes--;
                    /// </ul>
                }
                /// </ul>
            }
            /// <li> If ::pending_bytes is less than or equal to ::extra_size:
            if (pending_bytes <= extra_size)
            {
                /// <ul>
                /// <li> Multiply ::crc_size with the negated value of Tail_byte::sot 
                /// in ::curr_tb and store the result in "crc_sz".
                const Uint16 crc_sz = crc_size * (!curr_tb.sot);
                /// <li> Initialize "i" to 0 and iterate until "i" is less than ::extra_size minus "crc_sz".
                for(Uint16 i = 0; i < (extra_size-crc_sz); i++) // Add padding
                {
                    /// <ul>
                    /// <li> Call U8pkrszarray::append for CANdata::data in CANframe::data of given "frame" with 0.
                    frame.data.data.append(0);
                    /// <li> Call CRC::update_byte for ::crc16 with 0.
                    crc16.update_byte(0);
                    /// <li> Decrement ::pending_bytes by 1.
                    pending_bytes--;
                    /// </ul>
                }
                /// <li> If ::pending_bytes is equal to ::crc_size AND the output of U8pkrszarray::size 
                /// for CANdata::data in CANframe::data of given "frame" is less than ::max_can_sz:
                if( (pending_bytes == crc_size) && (frame.data.data.size() < max_can_sz) )
                {
                    /// <ul>
                    /// <li> Call U8pkrszarray::append for CANdata::data in CANframe::data of given "frame" with 
                    /// Bitutils::get_u16_h passing to it the current value of the CRC.
                    frame.data.data.append(Bitutils::get_u16_h(crc16.get_value()));
                    /// <li> Decrement ::pending_bytes by 1.
                    pending_bytes--;
                    /// </ul>
                }
                /// <li> If ::pending_bytes is equal to 1 AND the output of U8pkrszarray::size 
                /// for CANdata::data in CANframe::data of given "frame" is less than ::max_can_sz:
                if ((pending_bytes == 1U) && (frame.data.data.size() < max_can_sz))
                {
                    /// <ul>
                    /// <li> Call U8pkrszarray::append for CANdata::data in CANframe::data of given "frame" with 
                    /// Bitutils::get_u16_l passing to it the current value of the CRC.
                    frame.data.data.append(Bitutils::get_u16_l(crc16.get_value()));
                    /// <li> Decrement ::pending_bytes by 1.
                    pending_bytes--; 
                    /// </ul>                   
                }
                /// <li> If ::pending_bytes is equal to 0 assign true to :Tail_byte::eot
                /// in ::curr_tb, otherwise assign false. 
                curr_tb.eot = (pending_bytes == 0);
                /// <li> Assign negated value of Tail_byte::eot in ::curr_tb to ::transfer_started.
                transfer_started = !curr_tb.eot;
                /// </ul>
            }
            /// <li> Call U8pkrszarray::append for CANdata::data in CANframe::data 
            /// of given "frame" with Tail_byte::all in ::curr_tb.
            frame.data.data.append(curr_tb.all);
            /// <li> Compute bitwise XOR assignment operator between Tail_byte::toggle_bit in ::curr_tb and 1.
            curr_tb.toggle_bit ^= 1;
            /// <li> Assign false to Tail_byte::sot in ::curr_tb.
            curr_tb.sot = false; // After this one, it is not the first in the transfer. 
            /// <li> Return True. 
            /// </ul>          
        }
        /// <li> Else, return False.
        return res;
        /// </ul>
    }
}
