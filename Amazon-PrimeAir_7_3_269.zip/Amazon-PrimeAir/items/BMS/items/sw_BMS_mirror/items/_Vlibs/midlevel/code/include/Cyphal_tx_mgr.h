#ifndef CYPHAL_TX_MGR_H_
#define CYPHAL_TX_MGR_H_

#include <Array.h>
#include <Bitmask.h>
#include <CyphalCAN_out.h>
#include <Spkt_hdr.h>
#include <U8pkfifospsc.h>

#include <Espkt_fw.h>

namespace Cyphal
{
    /// Cyphal transmission manager.
    /// Can be used to send "native" Cyphal mmessage using Cyphal_msg or use Custom messages, that shall be defined
    /// as described in ::Cyphal_msg.
    class Cyphal_tx_mgr : public Base::Itconsumer_u8, public Base::Itproducer_u8
    {                
    public:
        Cyphal_tx_mgr(Uint16 max_msgs,
                      Uint16 max_msg_size,
                      Base::Memmgr::Type mtype);
        
        /// Send a Cyphal message.
        bool send(const Cyphal_msg& msg);

        /// Send a Stanag-wrapped Cyphal message.
        bool send(Cyphal_stg_fields fb,
                  const Base::Espkt& pkt);

        /// Writes data to be consumed. Normally from a Cyphal-Custom messages.
        /// \return True if write is accepted.
        virtual inline bool write(Uint8 data)
        {
            return ext_fifo.write(data);
        }

        /// \return True if write operation would be accepted.
        virtual inline bool wr_available() const
        {
            return ext_fifo.wr_available();
        }

        /// Read next byte to send.
        virtual bool read(Uint8& data);

    protected:
        class Msg  ///< Data structure to hold pending messages.
        {
        public:
            bool in_use;        ///< True if in use, False if free.
            Base::U8pkarray<Cyphal_msg::max_size> data; ///< Data buffer
            Cyphal_msg msg;     ///< Cyphal message to send.
            Base::U8istream is; ///< Input stream built over the Cyphal data buffer.

            /// Default constructor.
            inline Msg() : 
                in_use(false),
                msg(data.to_mblock8()), 
                is(data.to_mblock8())
            {
            }
        private:
            Msg(const Msg&); ///< = delete
            Msg* operator=(const Msg&); ///< = delete
        };

        /// External (U8 from custom) variables. U8 is parsed as it is being received and stored in the "ext_fifo".
        Base::U8pkfifospsc ext_fifo;    ///< Data from external source written using ::write(Uint8)
        Uint16 ext_idx;                 ///< External (U8) read index.
        Uint16 ext_pl_len;              ///< External (U8) message length. Read from the "length" field while parsing.

        Base::Array<Msg> msgs;          ///< Messages pending to be sent.

        enum Tx_type_t  ///< Current transmission type.
        {
            none,       ///< No transmission active.
            internal,   ///< Cyphal message.
            external    ///< External message (custom).
        };
        Tx_type_t tx_type;  ///< Current transmission.
        Msg* curr_tx_msg;   ///< Current Cyphal (internal) message being transmitted.

        /// \return Next available Msg object.
        Msg* get_free_msg();

        /// \return Next pending Msg object.
        Msg* get_next_msg();

        Cyphal_tx_mgr(const Cyphal_tx_mgr&); ///< = delete;
        Cyphal_tx_mgr& operator=(const Cyphal_tx_mgr&); ///< = delete;
    };
}
#endif
