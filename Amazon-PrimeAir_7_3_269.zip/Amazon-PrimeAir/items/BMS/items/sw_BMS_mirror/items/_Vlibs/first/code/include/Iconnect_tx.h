#ifndef ICONNECT_TX_H_
#define ICONNECT_TX_H_

namespace Base
{
    /// Interface to manages TX communication for generic port
    class Iconnect_tx
    {
    public:
        /// Enable TX-side
        virtual void connect_tx(bool en) = 0;

    protected:
        Iconnect_tx();
        virtual ~Iconnect_tx();

    private:
        Iconnect_tx(const Iconnect_tx& orig);               ///< = delete
        Iconnect_tx& operator=(const Iconnect_tx& orig);    ///< = delete
    };

    inline Iconnect_tx::Iconnect_tx()
    {
    }

    inline Iconnect_tx::~Iconnect_tx() //PRQA S 2635 #destructor replaced with default
    {
    }
}

#endif
