#ifndef GPIOID_28377_H_
#define GPIOID_28377_H_

namespace Dsp28335_ent
{
    enum GPIOid
    {
        gpio_000 =   0,
        gpio_001 =   1,
        gpio_002 =   2,
        gpio_003 =   3,
        gpio_004 =   4,
        gpio_005 =   5,
        gpio_006 =   6,
        gpio_007 =   7,
        gpio_008 =   8,
        gpio_009 =   9,
        gpio_010 =  10,
        gpio_011 =  11,
        gpio_012 =  12,
        gpio_013 =  13,
        gpio_014 =  14,
        gpio_015 =  15,     // PRO board MCBSP CS
        gpio_016 =  16,     // Arbiter WD
        gpio_017 =  17,     // CANRXB
        gpio_018 =  18,     // CANRXA
        gpio_019 =  19,     // CANTXA
        gpio_020 =  20,     // CANTXB
        gpio_021 =  21,
        gpio_022 =  22,
        gpio_023 =  23,
        gpio_024 =  24,
        gpio_025 =  25,
        gpio_026 =  26,     // SPIB SCK / SPI Expander SCK (V4.7)
        gpio_027 =  27,     // SPI Expander CS (V4.7)
        gpio_028 =  28,
        gpio_029 =  29,
        gpio_030 =  30,   // Reserved for EM1CLK / IMU1 CS (V4.5)
        gpio_031 =  31,   // Reserved for EM1WE
        gpio_032 =  32,
        gpio_033 =  33,     //REMOVE: Only for dock
        gpio_034 =  34,   // Reserved for !EM1CS2
        gpio_035 =  35,
        gpio_036 =  36,     // Aerobits TT-SC1a / Reset input (active low)
        gpio_037 =  37,   // Reserved for EM1OE
        gpio_038 =  38,   // Reserved for EMIF1_A00
        gpio_039 =  39,   // Reserved for EMIF1_A01 // Used in MC110 v2
        gpio_040 =  40,   // Reserved for EMIF1_A02
        gpio_041 =  41,   // Reserved for EMIF1_A03
        gpio_042 =  42,   // Reserved for USB D-
        gpio_043 =  43,   // Reserved for USB D+ // Used in MC110 v2
        gpio_044 =  44,   // Reserved for EMIF1_A04 // Used in 2838x dev board
        //gpio_045 =  45,   // Reserved for EMIF1_A05
        gpio_046 =  46,
        gpio_047 =  47,
        gpio_048 =  48,   // Reserved for EMIF1_A08
        gpio_049 =  49,   // Reserved for EMIF1_A09
        gpio_050 =  50,
        gpio_051 =  51,   // Reserved for EMIF1_A11
        gpio_052 =  52,   // Reserved for EMIF1_A12
        gpio_053 =  53,     // FTS2 feedback from SUC
        gpio_054 =  54,
        gpio_055 =  55,
        gpio_056 =  56,
        gpio_057 =  57,
        gpio_058 =  58,
        gpio_059 =  59,
        gpio_060 =  60,
        gpio_061 =  61,
        gpio_062 =  62,     // USB id
        gpio_063 =  63,     // SPIB MOSI / SPI Expander SI (V4.7)
        gpio_064 =  64,     // SPIB MISO / SPI Expander SO (V4.7)
        gpio_065 =  65,
        // ...
        gpio_067 =  67,     // FTS1 feedback from SUC
        // ...
        gpio_068 =  68,
        gpio_069 =  69,   // Reserved for EMIF1_D15
        gpio_070 =  70,   // Reserved for EMIF1_D14 // Used in 2838x MC110
        gpio_071 =  71,   // Reserved for EMIF1_D13 // Used in 2838x MC110
        gpio_072 =  72,   // Reserved for EMIF1_D12
        //gpio_073 =  73,   // Reserved for EMIF1_D11
        gpio_074 =  74,   // Reserved for EMIF1_D10 // Used in 2838x MC110
        gpio_075 =  75,   // Reserved for EMIF1_D09 // Used in 2838x dev board
        gpio_076 =  76,   // Reserved for EMIF1_D08 // Used in 2838x MC110
        gpio_077 =  77,   // Reserved for EMIF1_D07
        gpio_078 =  78,   // Reserved for EMIF1_D06
        gpio_079 =  79,   // Reserved for EMIF1_D05
        //gpio_080 =  80,   // Reserved for EMIF1_D04
        //gpio_081 =  81,   // Reserved for EMIF1_D03
        //gpio_082 =  82,   // Reserved for EMIF1_D02
        //gpio_083 =  83,   // Reserved for EMIF1_D01
        gpio_084 =  84,
        gpio_085 =  85,   // Reserved for EMIF1_D00
        gpio_086 =  86,   // Reserved for EMIF1_A13
        //gpio_087 =  87,   // Reserved for EMIF1_A14
        gpio_088 =  88,   // Reserved for EMIF1_A15
        gpio_089 =  89,   // Reserved for EMIF1_A16
        gpio_090 =  90,   // Reserved for EMIF1_A17
        gpio_091 =  91,   // Reserved for EMIF1_A18
        gpio_092 =  92,   // Reserved for EMIF1_EM1BA (Lower bit address)
        gpio_093 =  93,  //REMOVE: Only for dock
        gpio_094 =  94,
        gpio_095 =  95,     // FTS3 OUT MPU (V4.5)
        gpio_096 =  96,
        // ...

        gpio_098 =  98,     //3G_ON SARA
        gpio_099 =  99,     //PWR_ON SARA
        gpio_100 = 100,     //CONNECTOR: GPIO1 / EQEP2A
        gpio_101 = 101,     //CONNECTOR: GPIO2 / EQEP2B
        gpio_102 = 102,     //CONNECTOR: GPIO3 / EQEP2S
        gpio_103 = 103,     //CONNECTOR: GPIO4 / EQEP2I
        gpio_104 = 104,     //RESET_M2M SARA
        gpio_105 = 105,
        gpio_106 = 106,     // BMI088 Acc CS (V4.5)
        gpio_107 = 107,
        gpio_108 = 108,
        gpio_109 = 109,
        gpio_110 = 110,     // SPI Expander RST (V4.7)
        gpio_111 = 111,
        gpio_112 = 112,
        gpio_113 = 113,
        gpio_114 = 114,
        gpio_115 = 115,     // Aerobits TT-SC1a / Bootloader-Configuration mode input (active low)
        gpio_116 = 116,     // Led 1 (Green)
        gpio_117 = 117,
        gpio_118 = 118,
        gpio_119 = 119,
        gpio_120 = 120,     // USB pflt / FTS2 OUT MPU (V4.5)
        gpio_121 = 121,     // USB epen (input in V4.0), BMI088 Gyro CS (Output in V4.5)
        gpio_122 = 122,
        gpio_123 = 123,
        gpio_124 = 124,
        gpio_125 = 125,
        gpio_126 = 126,
        // ...
        gpio_128 = 128,     // Led 0 (Red)
        gpio_129 = 129,     // Led 1 (Green)
        // ...
        gpio_130 = 130,     // SPI-C CS Mux
        gpio_131 = 131,
        gpio_132 = 132,
        gpio_133 = 133,
        gpio_134 = 134,
        // ...
        gpio_137 = 137,     // Led 1 RSSI Modem
        gpio_138 = 138,     // Led 2 RSSI Modem
        gpio_139 = 139,     // Led 3 RSSI Modem
        gpio_140 = 140,
        gpio_141 = 141,
        gpio_142 = 142,
        // ...
        gpio_145 = 145,     // FTS1 OUT MPU (V4.5)
        gpio_146 = 146,     // IMU 3 ADIS !RST (V4.7)
        gpio_147 = 147,
        gpio_148 = 148,     // 4xV_MUX-A (v4.7+)
        gpio_149 = 149,     // 4xV_MUX-B (v4.7+)
        gpio_150 = 150,
        gpio_151 = 151,
        // ...
        gpio_152 = 152,
        gpio_153 = 153,     // 4xV_WD (v4.7+)
        gpio_154 = 154,     // Digi Radio /Reset (v4.7)
        gpio_155 = 155,     // Time pulse from Ublox 1
        gpio_156 = 156,     // Time pulse from Ublox 0
        // ...
        gpio_157 = 157,
        // ...
        gpio_159 = 159,
        gpio_160 = 160,
        gpio_161 = 161,
        // ...
        gpio_162 = 162, // SPI IMU0 int2
        gpio_165 = 165,
        gpio_166 = 166,
        gpio_167 = 167,
        gpio_168 = 168,
        gpio_all = 169
    };
}
#endif
