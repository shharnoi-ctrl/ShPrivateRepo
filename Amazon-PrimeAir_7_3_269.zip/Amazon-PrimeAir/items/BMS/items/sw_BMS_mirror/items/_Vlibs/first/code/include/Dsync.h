#ifndef DSYNC_H_
#define DSYNC_H_

#include <Assertions.h>
#include <Ku16.h>
#include <Ttraits.h>

namespace Base
{
    // Data synchronization control.
    class Dsync
    {
    public:
        /// The Reader class provides functionality to handle data synchronization operations.
        class Reader
        {
        public:
            /// Synchronous Reader Constructor with Given Data Synchronization Object.
            /// \wi{4987}
            /// Reader class shall build itself upon construction and initialize 
            /// its internal attributes with received Synchronization object.
            /// \param[in] ds0 Data Synchronization object.
            explicit Reader(const volatile Dsync& ds0);

            /// Synchronous Reader Constructor with Given Validity Flag.
            /// \wi{19047}
            /// Reader class shall build itself upon construction and initialize 
            /// its internal attributes depending on the received flag.
            /// \param[in] valid Flag indicating whether the reader object is valid. Default value set to False.
            explicit Reader(bool valid=false);

            /// Synchronous Reader Invalid Setter.
            /// \wi{4992}
            /// Reader class shall provide a method to set the reader object to an invalid state.
            void set_invalid();

            /// Synchronous Reader Wait Until Write Complete.
            /// \wi{4989}
            /// Reader class shall provide a method for the reader object to wait 
            /// until the completion of any ongoing write operation.
            void wr_wait() const;

            /// Synchronous Reader Validity Checker.
            /// \wi{6550}
            /// Reader class shall provide a method to check whether the reader object is currently valid.
            /// \return True if the reader object is valid, False otherwise.
            bool is_valid() const;

            /// Synchronous Reader Synchronization Value Retriever.    
            /// \wi{5100}
            /// Reader class shall provide a method to retrieve the synchronization 
            /// value associated with the reader object.
            /// \return Synchronization value.
            Uint16 get_sync_value() const;

            /// Null Reader Object Reference Retriever.    
            /// \wi{6621}
            /// Reader class shall provide a method to retrieve a reference to a null Dsync object.
            /// \return Constant reference to a null Dsync object.
            static const Dsync& get_null(); 

        private:

            /// New Null Reader Object Reference Builder.    
            /// \wi{6622}
            /// Reader class shall provide a method to create a new null Dsync object.
            /// \return Null Dsync object retrieved by value.
            static Dsync build_null(); 

            const volatile Dsync* ds;   ///< Pointer to the Data Synchronization object.
            Uint16 s;                   ///< Semaphore value at build time.
        };


        /// The Writer struct represents a Writer object for data synchronization 
        /// and provides functionality to interact with data synchronization.
        struct Writer
        {
            /// Synchronous Writer Constructor with Given Data Synchronization Object.
            /// \wi{4993}
            /// Writer struct shall build itself upon construction and initialize its internal Data Synchronization attribute.
            /// \param[in] ds0 Data Synchronization object.
            explicit Writer(Dsync& ds0);

            /// Synchronous Writer Destructor.
            /// \wi{19048}
            /// Writer struct shall destroy itself upon destruction and complete 
            /// the write operation when the writer object goes out of scope.
            ~Writer();
        private:
            Dsync& ds;   ///< Reference to the Dsync object.

            Writer();                               ///< = delete.
            Writer(const Writer& orig);             ///< = delete.
            Writer& operator=(const Writer& orig);  ///< = delete.
        };

        /// The Writer_async struct represents an asynchronous Writer object for data synchronization 
        /// and provides functionality to interact with data synchronization asynchronously.
        struct Writer_async
        {
            /// Asynchronous Writer Constructor with Given Data Synchronization Object.
            /// \wi{6295}
            /// Asynchronous Writer struct shall build itself upon 
            /// construction and initialize its internal Data Synchronization attribute.
            /// \param[in] ds0 Data Synchronization object.
            explicit Writer_async(Dsync& ds0);
            
            /// Asynchronous Writer Start Operation.
            /// \wi{6296}
            /// Asynchronous Writer struct shall provide a method to start a write operation.
            void write_start();

            /// Asynchronous Writer End Operation.
            /// \wi{6297}
            /// Asynchronous Writer struct shall provide a method to end a write operation if it is currently ongoing.
            void write_end();
            
            /// Asynchronous Writer Start Operation Checker.
            /// \wi{6344}
            /// Asynchronous Writer struct shall provide a method to check if a write operation has started.
            /// \return True if a write operation is started, False otherwise.
            bool started() const;
        private:
            Dsync& ds;  ///< Reference to the Data Synchronization object.

            Writer_async();                                     ///< = delete.
            Writer_async(const Writer_async& orig);             ///< = delete.
            Writer_async& operator=(const Writer_async& orig);  ///< = delete.
        };

        /// Data Synchronization Value Checker.
        /// \wi{4986}
        /// Dsync class shall provide a method to check if the provided 
        /// synchronization value matches the current semaphore value.
        /// \param[in] s0   Synchronization value to be checked.
        /// \return True if the synchronization value match, False otherwise.
        bool is_sync_value(Uint16 s0) const;

        /// Data Synchronization Write Operation Ongoing Checker.
        /// \wi{4991}
        /// Dsync class shall provide a method to check if a write operation is ongoing.
        /// \return True if a write operation is ongoing, False otherwise.
        bool wr_ongoing() const volatile;

    private:
        Uint16 sem; ///< Encodes semaphore state (bit 0: means writing, bits 1..15: incremental version).

        /// Data Synchronization Start Write Operation.
        /// \wi{4994}
        /// Dsync class shall provide a method to start a write operation.
        void write_start();

        /// Data Synchronization End Write Operation.
        /// \wi{4996}
        /// Dsync class shall provide a method to end a write operation.
        void write_end();

        /// Data Synchronization Semaphore Retriever.
        /// \wi{4988}
        /// Dsync class shall provide a method to retrieve the semaphore value before any ongoing write operation.
        /// \return Semaphore value before any ongoing write operation.
        Uint16 sem_prewrite() const volatile;

        /// Data Synchronization Wait Until Write Operation Complete.
        /// \wi{4990}
        /// Dsync class shall provide a method to wait until the completion of any ongoing write operation.
        void wr_wait() const volatile;
    };


    inline Dsync::Reader::Reader(const volatile Dsync& ds0) : ds(&ds0), s(ds0.sem_prewrite())
    {
        /// \alg
        /// - Initialize the Data Synchronization object pointer ::ds with the received object address "ds0".
        /// - Initialize the semaphore value ::s by invoking 
        /// Dsync::sem_prewrite for the Data Synchronization object "ds0".
    }
    inline Dsync::Reader::Reader(bool valid) : ds(&(Dsync::Reader::get_null())), s(valid ? ds->sem : !(ds->sem))
    {
        /// \alg
        /// - Initialize the Data Synchronization object pointer ::ds 
        /// with Dsync::Reader::get_null to point static instance of the null Dsync object.
        /// - Initialize the Encode semaphore state ::s based on the validity flag "valid".
    }
    inline void Dsync::Reader::set_invalid()
    {
        /// \alg
        /// <ul>
        /// <li> Call Dsync::Reader::get_null to set ::ds pointer to the null Dsync object.
        ds=&(Dsync::Reader::get_null());
        /// <li> Negate the semaphore value of ::ds and assign it to ::s.
        s=!(ds->sem);
        /// </ul>
    }
    inline void Dsync::Reader::wr_wait() const
    {
        /// \alg
        /// - Call Dsync::wr_wait for ::ds.
        ds->wr_wait();
    }
    inline bool Dsync::Reader::is_valid() const
    {
        /// \alg
        /// - Return True if ::s is equal to ::ds semaphore value, otherwise False.
        return (s==ds->sem);
    }
    inline Uint16 Dsync::Reader::get_sync_value() const
    {
        /// \alg
        /// - Return ::s. 
        return s;
    }


    inline Dsync::Writer::Writer(Dsync& ds0) : ds(ds0)
    {
        /// \alg
        /// - Call Dsync::write_start for ::ds.  
        ds.write_start();   
    }
    inline Dsync::Writer::~Writer()
    {
        /// \alg
        /// - Call Dsync::write_end for ::ds.  
        ds.write_end();   
    }

    inline Dsync::Writer_async::Writer_async(Dsync& ds0) : ds(ds0)
    {
    }

    inline void Dsync::Writer_async::write_start()
    {
        /// \alg
        /// - Call Dsync::write_start for ::ds. 
        ds.write_start();
    }

    inline void Dsync::Writer_async::write_end()
    {
        /// \alg
        /// <ul>
        /// <li> If ::ds synchronous write is ongoing: 
        if(Assertions::runtime(ds.wr_ongoing()))
        {
            /// <ul>
            /// <li> Call Dsync::write_end for ::ds. 
            ds.write_end();
            /// </ul>
        }
        /// </ul>
    }

    inline bool Dsync::Writer_async::started() const
    {
        /// \alg
        /// - Call Dsync::wr_ongoing for ::ds and return its retrieved value.
        return ds.wr_ongoing();
    }

    inline bool Dsync::is_sync_value(Uint16 s0) const
    {
        /// \alg
        /// - Return True if ::sem is equal to the given parameter s0, otherwise False. 
        return sem==s0;
    }
    inline bool Dsync::wr_ongoing() const volatile
    {
        /// \alg
        /// - Return True if the least significant bit of the semaphore value is set, otherwise False. 
        return sem&1U;
    }
    inline void Dsync::write_start()
    {
        /// \alg
        /// - Set the least significant bit of the semaphore value, indicating the start of a write operation.
        /// - sem |= 1 (intrinsic atomic).
        __or(reinterpret_cast<int16*>(&sem), 1); 
    }
    inline void Dsync::write_end()  //PRQA S 4212 #static
    {
        /// \alg
        /// - Increment the semaphore value, indicating the end of a write operation.
        /// - sem++ (intrinsic atomic).
        __inc(reinterpret_cast<int16*>(&sem));  
    }
    inline Uint16 Dsync::sem_prewrite() const volatile
    {
        /// \alg
        /// - Return the semaphore current value, or value before any possible ongoing write. 
        return sem&Ku16::u0xFFFEU; 
    }

    inline void Dsync::wr_wait() const volatile
    {
        /// \alg
        /// - Loop until the write operation is no longer ongoing (::wr_ongoing).
        while(wr_ongoing())
        {
        }
    }
}
#endif
