#ifndef FIFOSPSCWR_COMMIT_H_
#define FIFOSPSCWR_COMMIT_H_

#include <Fifospsc0.h>
#include <Fifospscwr_commit_fw.h>

namespace Base
{

    /// FIFO with commit/discard option for writes. 
    /// The Base namespace shall provide a class to use an auxiliary FIFO with external pointers,
    /// translating write state to externally visible FIFO on commit.
    template <typename T,
              template <typename> class RD = SPSCtraits::Internal,
              template <typename> class WR = SPSCtraits::Internal>
    class Fifospscwr_commit
    {

    public:
        typedef typename Base::Fifospsc0<T, RD,WR>::Rptr   Rptr;
        typedef typename Base::Fifospsc0<T, RD,WR>::Wptr   Wptr;

        /// FIFO SPSC Writer Constructor With Given Parameters.
        /// \wi{6681}
        /// Fifospscwr_commit class shall build itself upon construction to support commited writings.
        /// \param[in] v0 pointer to the first buffer element.
        /// \param[in] vz0 pointer to the last buffer element.
        /// \param[in] rd0 pointer to manage buffer readings.
        /// \param[in] wr0 pointer to manage buffer writings.
        Fifospscwr_commit(T* const v0,
                          T* const vz0,
                          Rptr rd0,
                          Wptr wr0);

        /// FIFO SPSC Writer Data Element Reader.
        /// \wi{5040}
        /// Fifospscwr_commit class shall be able to read from its final FIFO.
        /// \param[out] element Element already read from the buffer.
        /// \return True if the read action has worked, otherwise False.
        template <typename T2=T, typename CPTRAIT = Cptraits::Operator<T,T2> >
        bool read(T2& element);

        /// FIFO SPSC Writer Read Availablity Checker.
        /// \wi{5041}
        /// Fifospscwr_commit class shall be able to check if read action from final FIFO is available.
        /// \return True if the reading action is available, otherwise False.
        bool rd_available() const;

        /// FIFO SPSC Writer Read Available Count.
        /// \wi{20808}
        /// Fifospscwr_commit shall provide the capability to retrieve the available reading count of final FIFO.
        /// \return     Count of available items to read.
        inline Uint32 rd_available_count() const
        {
            /// \alg
            /// - Return retrieved count from Fifospsc0::rd_available_count for ::ff0_obj. 
            return ff0_obj.rd_available_count();
        }

        /// FIFO SPSC Writer Write Available Count.
        /// \wi{20809}
        /// Fifospscwr_commit shall provide the capability to retrieve the available writing count of final FIFO.
        /// \return     Count of available items to write.
        inline Uint32 wr_available_count() const    
        {
            /// \alg
            /// - Return retrieved count from Fifospsc0::wr_available_count for ::ff0_obj.
            return ff0_obj.wr_available_count();
        }

        /// FIFO SPSC Writer Data Element Writer.
        /// \wi{5042}
        /// Fifospscwr_commit class shall be able to write an element into private FIFO.
        /// \param[in] element Element to write in the buffer.
        /// \return True if the write action has worked, otherwise False.
        template <typename T2=T, typename CPTRAIT = Cptraits::Operator<T2,T> >
        bool write(typename JSF116_param<T2>::type element);

        /// FIFO SPSC Writer Write Availablity Checker.
        /// \wi{5043}
        /// Fifospscwr_commit class shall be able to check if write action in private FIFO is available.
        /// \return True if the writing action is available, otherwise False.
        bool wr_available() const;


        /// FIFO SPSC Writer Buffer Commit.
        /// \wi{5044}
        /// Fifospscwr_commit class shall be able to commit the write pointer 
        /// used on its private FIFO to the final FIFO.
        void commit();

        /// FIFO SPSC Buffer Discard.
        /// \wi{5045}
        /// Fifospscwr_commit class shall be able to discard the private FIFO write pointer since last commit.
        void discard();

        /// FIFO SPSC Writer Buffer Reset Read Pointer.
        /// \wi{5046}
        /// Fifospscwr_commit class shall be able to reset the write pointer of both FIFO queues.
        void reset();

    private:
        typedef Fifospsc0<T, SPSCtraits::Add_reference_to_trait<RD>::template Template, WR> Type_ff0_obj;
        Rptr rdaux; ///< Temporary read pointer.
        T* wraux;   ///< Temporary write pointer.
        /// FIFO where visible changes happen (Final FIFO).
        Type_ff0_obj ff0_obj;
        /// FIFO where temporary writes happen (Private/Temporary FIFO).
        Fifospsc0<T, SPSCtraits::External, SPSCtraits::Internal_ref> ffprivate;

        Fifospscwr_commit();                                            ///< = delete.
        Fifospscwr_commit(const Fifospscwr_commit& orig);               ///< = delete.
        Fifospscwr_commit& operator=(const Fifospscwr_commit& orig);    ///< = delete.
    };


    template <typename T,
              template <typename> class RD,
              template <typename> class WR>
    /// \alg
    /// <ul>
    /// <li> ::rdaux is initialized with given parameter "rd0".
    /// <li> ::wraux is initialized with given parameter "wr0".
    /// <li> ::ff0_obj is initialized with given parameters "v0", "vz0", ::rdaux and "wr0".
    /// <li> ::ffprivate is initialized with given parameters "v0", "vz0", ::rdaux and ::wraux.
    /// </ul>
    Fifospscwr_commit<T,RD,WR>::Fifospscwr_commit(T* const v0,
                                                  T* const vz0,
                                                  Rptr rd0,
                                                  Wptr wr0) :
        rdaux(rd0),
        wraux(wr0),
        ff0_obj(v0,vz0,rdaux,wr0),
        ffprivate(v0,vz0,rdaux,wraux)
    {
    }

    template <typename T,
              template <typename> class RD,
              template <typename> class WR>
    template <typename T2, typename CPTRAIT>
    inline bool Fifospscwr_commit<T,RD,WR>::read(T2& element)
    {
        /// \alg
        /// - Return retrieved boolean from Fifospsc0::read for ::ff0_obj with the given reference value "element". 
        return ff0_obj.template read<T2,CPTRAIT>(element);
    }

    template <typename T,
              template <typename> class RD,
              template <typename> class WR>
    inline bool Fifospscwr_commit<T,RD,WR>::rd_available() const
    {
        /// \alg
        /// - Return retrieved boolean from Fifospsc0::rd_available for ::ff0_obj. 
        return ff0_obj.rd_available();
    }

    template <typename T,
              template <typename> class RD,
              template <typename> class WR>
    template <typename T2, typename CPTRAIT>
    inline bool Fifospscwr_commit<T,RD,WR>::write(typename JSF116_param<T2>::type element)
    {
        /// \alg
        /// - Return retrieved boolean from Fifospsc0::write for ::ffprivate with the given value "element". 
        return ffprivate.template write<T2,CPTRAIT>(element);
    }

    template <typename T,
              template <typename> class RD,
              template <typename> class WR>
    inline bool Fifospscwr_commit<T,RD,WR>::wr_available() const
    {
        /// \alg
        /// - Return retrieved boolean from Fifospsc0::wr_available for ::ffprivate. 
        return ffprivate.wr_available();
    }

    template <typename T,
              template <typename> class RD,
              template <typename> class WR>
    inline void Fifospscwr_commit<T,RD,WR>::commit()
    {
        /// \alg
        /// - Call Fifospsc0::set_wr for ::ff0_obj with current write pointer instance ::wraux.
        ff0_obj.set_wr(wraux);
    }

    template <typename T,
              template <typename> class RD,
              template <typename> class WR>
    inline void Fifospscwr_commit<T,RD,WR>::discard()
    {
        /// \alg
        /// - Call Fifospsc0::get_wr for ::ff0_obj and store the retrieved value in ::wraux.
        wraux=ff0_obj.get_wr();
    }

    template <typename T,
              template <typename> class RD,
              template <typename> class WR>
    inline void Fifospscwr_commit<T,RD,WR>::reset()
    {
        /// \alg
        /// <ul>
        /// <li> Call Fifospsc0::get_v for ::ff0_obj to get the pointer to the first 
        /// buffer element and update current ::wraux.
        wraux = ff0_obj.get_v();
        /// <li> Call Fifospsc0::set_wr for ::ff0_obj with the retrieved value by Fifospsc0::get_v for ::ff0_obj.
        ff0_obj.set_wr(ff0_obj.get_v());
        /// </ul>
    }
}
#endif
