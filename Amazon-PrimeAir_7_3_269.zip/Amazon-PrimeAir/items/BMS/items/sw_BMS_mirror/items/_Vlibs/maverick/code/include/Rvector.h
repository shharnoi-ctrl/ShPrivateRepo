#ifndef RVECTOR_H__
#define RVECTOR_H__

#include <Tvector.h>
#include <Lossy_error_fw.h>
#include <Lossy_fw.h>

namespace Maverick
{
    /// Real Vector class inherits from Tvector<Real> and represents a vector of real values.
    class Rvector: public Tvector<Real>
    {
    public:
        struct K;

        /// Real Vector Constructor with Given Memory Block.
        /// \wi{3118}
        /// Rvector class shall build itself upon construction with a memory block buffer of Real values.
        /// \param[in] mb       Memory block.
        explicit Rvector(Base::Mblock<Real> mb);

        /// Real Vector Constructor with Templated Array.
        /// \wi{17562}
        /// Rvector class shall build itself upon construction with the given templated contiguous real array type.
        /// \param[in] array Reference to the templated array of real numbers.
        template <typename ARRAY>
        explicit Rvector(ARRAY& array);

        /// Real Vector Constructor with Given Real Pointer and Size.
        /// \wi{18414}
        /// Rvector class shall build itself upon construction with first 
        /// Vector element and specific number of elements.
        /// \param[in] v0       Pointer to first Real Vector element.
        /// \param[in] n0       Number of elements.
        Rvector(Real* v0,Uint16 n0);

        /// Real Vector Constructor with another Given Real Vector.
        /// \wi{18415} 
        /// Rvector class shall build itself upon construction with another Real Vector 
        /// and specific number of elements.
        /// \param[in] v0       Reference to Real Vector used to build the new one.
        /// \param[in] n0       Number of elements.
        Rvector(Rvector& v0,Uint16 n0);

        /// Real Vector Constructor with another Real Vector and given Offset.
        /// \wi{18416}  
        /// Rvector class shall build itself upon construction with another Real Vector instance, 
        /// starting from a given offset, and a specific number of elements.
        /// \param[in] v0       Reference to Real Vector used to build the new one.
        /// \param[in] offset   Starting offset within the referenced Real Vector.
        /// \param[in] n0       Number of elements.
        Rvector(Rvector& v0,Uint16 offset,Uint16 n0);

        /// Real Vector Constructor with Memory Allocation.
        /// \wi{18417}  
        /// Rvector class shall build itself upon construction with the 
        /// specified number of elements and a memory type.
        /// \param[in] n0       Number of elements.
        /// \param[in] memtype  Memory type.
        Rvector(Uint16 n0, Base::Memmgr::Type memtype);

        inline Rvector(Uint16 n0, Base::Allocator& alloc) : Tvector<Real>(n0, alloc)
        {
        }

        /// Real Vector Deserialization.
        /// \wi{3107}
        /// Rvector class shall provide a method to deserialize configuration from a PDIC.
        /// \param[in] str      PDIC to deserialize variable configuration from.
        void cset(Base::Lossy_error& str);

        /// Real Vector Serialization.
        /// \wi{3106}
        /// Rvector class shall provide a method to serialize its configuration to a PDIC.
        /// \param[in,out] str      Buffer where data shall be serialized.
        void cget(Base::Lossy& str)const;
    private:
        Rvector(const Rvector& orig);             ///< = delete
        Rvector& operator=(const Rvector& orig);  ///< = delete

        /// Real Vector Constructor with Given Constant Memory Block.
        /// \wi{18418}
        /// Rvector class shall build itself upon construction with a constant memory block buffer.
        /// \param[in] mb       Memory block.
        explicit Rvector(const Base::Mblock<const Real>& mb);

        /// Constructor of Rvector with constant pointer to data and size.
        /// \wi{19275}
        /// The Rvector class shall provide a private constructor method that receives as parameters a constant
        /// pointer to the first element of the vector and its size.
        /// \rat This constructor shall be private so that it is only used by the Rvector::K class to ensure const
        /// correctness.
        /// \param[in] v0 Const pointer to first element of the vector data.
        /// \param[in] n0 Maximum size of the data.
        inline Rvector(const Real* v0, const Uint16 n0) : Tvector<Real>(const_cast<Real*>(v0), n0)
        {
        }

    };

    /// Constant Real Vector that can be built using constant buffer.
    struct Rvector::K
    {
        const Rvector kvec; ///< Constant Real Vector instance.
        /// Real Vector Constructor with Given Constant Memory Block.
        /// \wi{3119}
        /// Rvector class shall build itself upon construction with a constant memory block buffer.
        /// \param[in] v       Constant memory block containing real values.
        explicit K(const Base::Mblock<const Real>& v);

        /// Constructor of Rvector::K with constant pointer to data and size.
        /// \wi{19276}
        /// The Rvector class shall provide a private constructor method that receives as parameters a constant
        /// pointer to the first element of the vector and its size.
        /// \param[in] v0 Const pointer to first element of the vector data.
        /// \param[in] n0 Maximum size of the data.
        inline K(const Real* v0, const Uint16 n0) : kvec(v0, n0)
        {
        }

    private:
        K();                            ///< = delete.
        K(const K& orig);               ///< = delete.
        K& operator=(const K& orig);    ///< = delete.
    };

    template <typename ARRAY>
    Rvector::Rvector(ARRAY& array) : Tvector<Real>(&array[0], array.size())
    {
    }

    inline Rvector::Rvector(const Base::Mblock<const Real>& mb) :
                Tvector<Real>(const_cast<Real*>(mb.v), mb.size())
    {
    }

    inline Rvector::K::K(const Base::Mblock<const Real>& v) : kvec(v)
    {
    }
}
#endif

