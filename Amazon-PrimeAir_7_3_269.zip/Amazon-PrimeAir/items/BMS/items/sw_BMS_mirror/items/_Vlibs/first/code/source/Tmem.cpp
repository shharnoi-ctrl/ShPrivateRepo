#include <Tmem.h>

namespace Base
{

    void Tmem::cpy_sel(void* dst,
                       const void* src,
                       Uint32 memsize)
    {
        /// \alg
        /// - Call ::cpy0 with given parameters. Template ::cpy0 with Method::m_rtsel.
        cpy0<m_rtsel>(dst, src, memsize);
    }

    void Tmem::set_sel(void* dst,
                       int16 value,
                       Uint32 memsize)
    {
        /// \alg
        /// - Call ::set0 with given parameters. Template ::set0 with Method::m_rtsel.
        set0<m_rtsel>(dst, value, memsize);
    }
}

