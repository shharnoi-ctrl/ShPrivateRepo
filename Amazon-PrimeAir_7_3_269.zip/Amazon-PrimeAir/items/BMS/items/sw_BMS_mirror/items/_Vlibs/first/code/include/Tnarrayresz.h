#ifndef TNARRAYRESZ_H_
#define TNARRAYRESZ_H_

#include <Tnarrayresz_fw.h>
#include <Tnarray.h>

namespace Base
{
    /// The Base library provides a struct to manage a resizable array with a fixed maximum size.
    template <typename T, Uint32 n>
    struct Tnarrayresz
    {
        typedef T type;                 ///< Type definition for the elements of the array.
        static const Uint32 szmax = n;  ///< Maximum size of the array.

        Uint32          m;      ///< Effective (used) size.
        Tnarray<T,n>    v;      ///< Array with max size.

        /// Resizable Array Zeros Setter.
        /// \wi{20250}
        /// Tnarrayresz class shall provide the capability to initialize 
        /// all the elements in the resizable array to zero.
        void zeros();

        /// Resizable Array Resizer.
        /// \wi{5233}
        /// Tnarrayresz class shall provide the capability to resize the array to the specified size.
        /// \param[in] m0 The new size of the array.
        /// \return True if resizing operation is successful, False otherwise.
        bool resize(Uint32 m0);

        /// Resizable Array [] Operator.
        /// \wi{5230}
        /// Tnarrayresz class shall provide the capability to retrieve 
        /// a reference to the element at given index.
        /// \param[in] i    Index in the resizable array.
        /// \return         Reference to the element at given index.
        /// \pre            Assume that provided index is not out of bounds.
        T& operator[](Uint32 i);

        /// Resizable Array Constant [] Operator.
        /// \wi{20251}
        /// Tnarrayresz class shall provide the capability to retrieve 
        /// a constant reference to the element at given index.
        /// \param[in] i    Index in the resizable array.
        /// \return         Constant reference to the element at given index.
        /// \pre            Assume that provided index is not out of bounds.
        const T& operator[](Uint32 i)const;

        /// Resizable Array Volatile [] Operator.
        /// \wi{20252}
        /// Tnarrayresz class shall provide the capability to retrieve 
        /// a volatile reference to the element at given index.
        /// \param[in] i    Index in the resizable array.
        /// \return         Volatile reference to the element at given index.
        /// \pre            Assume that provided index is not out of bounds.
        volatile T& operator[](Uint32 i) volatile;

        /// Resizable Array Constant Volatile [] Operator.
        /// \wi{20253}
        /// Tnarrayresz class shall provide the capability to retrieve 
        /// a constant and volatile reference to the element at given index.
        /// \param[in] i    Index in the resizable array.
        /// \return         Constant Volatile reference to the element at given index.
        /// \pre            Assume that provided index is not out of bounds.
        const volatile T& operator[](Uint32 i)const volatile;

        /// Resizable Array First Element Retriever.
        /// \wi{5231}
        /// Tnarrayresz class shall provide the capability to retrieve 
        /// a pointer to the first element of the array.
        /// \return         Pointer to the first element of the array.
        T* first();

        /// Resizable Array Constant First Element Retriever.
        /// \wi{20254}
        /// Tnarrayresz class shall provide the capability to retrieve 
        /// a constant pointer to the first element of the array.
        /// \return         Constant pointer to the first element of the array.
        const T* first() const;

        /// Resizable Array Constant Volatile First Element Retriever.
        /// \wi{20255}
        /// Tnarrayresz class shall provide the capability to retrieve 
        /// a constant and volatile pointer to the first element of the array.
        /// \return         Constant Volatile pointer to the first element of the array.
        const volatile T* first() const volatile;

        /// Resizable Array Last Element Retriever.
        /// \wi{5232}
        /// Tnarrayresz class shall provide the capability to retrieve 
        /// a pointer to the last element of the array.
        /// \return         Pointer to the last element of the array.
        T* last();

        /// Resizable Array Constant Last Element Retriever.
        /// \wi{20256}
        /// Tnarrayresz class shall provide the capability to retrieve 
        /// a constant pointer to the last element of the array.
        /// \return         Constant pointer to the last element of the array.
        const T* last() const;

        /// Resizable Array Constant Volatile Last Element Retriever.
        /// \wi{20257}
        /// Tnarrayresz class shall provide the capability to retrieve 
        /// a volatile pointer to the last element of the array.
        /// \return         Constant Volatile pointer to the last element of the array.
        const volatile T* last() const volatile;

        /// Resizable Array Memory Block Retriever.
        /// \wi{5234}
        /// Tnarrayresz class shall provide the capability to retrieve 
        /// the memory block of the array with its effective size.
        /// \return        Memory block of the array.
        Mblock<T> to_mblock();

        /// Resizable Array Constant Memory Block Retriever.
        /// \wi{20258}
        /// Tnarrayresz class shall provide the capability to retrieve a 
        /// constant memory block of the array with the effective size.
        /// \return         Constant memory block of the array.
        Mblock<const T> to_mblock() const;

        /// Resizable Array Volatile Memory Block Retriever.
        /// \wi{20259}
        /// Tnarrayresz class shall provide the capability to retrieve a 
        /// volatile memory block of the array with the effective size.
        /// \return         Volatile memory block of the array.
        Mblock<volatile T> to_mblock() volatile;

        /// Resizable Array Constant Volatile Memory Block Retriever.
        /// \wi{20260}
        /// Tnarrayresz class shall provide the capability to retrieve a constant 
        /// and volatile memory block of the array with the effective size.
        /// \return         Constant Volatile memory block of the array.
        Mblock<const volatile T> to_mblock() const volatile;

        /// Resizable Array Effective Array Size Retriever.
        /// \wi{5235}
        /// Tnarrayresz class shall provide the capability to retrieve the effective array size.
        /// \return         The current effective array size.
        Uint32 size() const volatile;

        /// Resizable Array Maximum Array Size Retriever.
        /// \wi{5236}
        /// Tnarrayresz class shall provide the capability to retrieve the maximum array size.
        /// \return         The maximum array size.
        Uint32 size_max() const volatile;

        /// Resizable Array Element Appender. 
        /// \wi{20261}
        /// Tnarrayresz class shall provide the capability to add an element to the end of the array.
        /// \param[in] elem The element to append.
        /// \return True if append is successful, False otherwise.
        bool append(const T& elem);

        /// Resizable Array Element Initializer. 
        /// \wi{20262}
        /// Tnarrayresz class shall provide the capability to initialize all elements of the array.
        void init();
    };

    template <typename T, Uint32 n>
    inline void Tnarrayresz<T,n>::zeros()
    {
        /// \alg
        /// - Store the effective size reference variable ::m to 0.
        m = 0;
        /// - Call Tnarray::zeros to set all elements in ::v to 0. 
        v.zeros();
    }

    template <typename T, Uint32 n>
    inline bool Tnarrayresz<T,n>::resize(Uint32 m0)
    {
        /// \alg
        /// - If the given size is within Tnarray bounds, set the effective size to the given size,
        ///  otherwise set to maximum size of Tnarray ::v.
        const bool ret = Assertions::runtime(m0<=n);
        m = ret ? m0 : n;
        /// - Return True if resizing of array is successful, otherwise False. 
        return ret;
    }

    template <typename T, Uint32 n>
    inline T& Tnarrayresz<T,n>::operator[](Uint32 i)
    {
        /// \alg
        /// - Return value of the Array at given position.
        return v[i];
    }

    template <typename T, Uint32 n>
    inline const T& Tnarrayresz<T,n>::operator[](Uint32 i)const
    {
        /// \alg
        /// - Return value of the Array at given position.
        return v[i];
    }

    template <typename T, Uint32 n>
    inline volatile T& Tnarrayresz<T,n>::operator[](Uint32 i) volatile
    {
        /// \alg
        /// - Return value of the Array at given position.
        return v[i];
    }

    template <typename T, Uint32 n>
    inline const volatile T& Tnarrayresz<T,n>::operator[](Uint32 i)const volatile
    {
        /// \alg
        /// - Return value of the Array at given position.
        return v[i];
    }

    template <typename T, Uint32 n>
    inline T* Tnarrayresz<T,n>::first()
    {
        /// \alg
        /// - Return retrieved value by Tnarray::first for ::v.
        return v.first();
    }

    template <typename T, Uint32 n>
    inline const T* Tnarrayresz<T,n>::first() const
    {
        /// \alg
        /// - Return retrieved value by Tnarray::first for ::v.
        return v.first();
    }

    template <typename T, Uint32 n>
    inline const volatile T* Tnarrayresz<T,n>::first() const volatile
    {
        /// \alg
        /// - Return retrieved value by Tnarray::first for ::v.
        return v.first();
    }

    template <typename T, Uint32 n>
    inline T* Tnarrayresz<T,n>::last()
    {
        /// \alg
        /// - Return the last element of the array ::v.
        return (&v[0] + m - 1);
    }

    template <typename T, Uint32 n>
    inline const T* Tnarrayresz<T,n>::last() const
    {
        /// \alg
        /// - Return the last element of the array ::v.
        return (&v[0] + m - 1);
    }

    template <typename T, Uint32 n>
    inline const volatile T* Tnarrayresz<T,n>::last() const volatile
    {
        /// \alg
        /// - Return the last element of the array ::v.
        return (&v[0] + m - 1);
    }

    template <typename T, Uint32 n>
    inline Mblock<T> Tnarrayresz<T,n>::to_mblock()
    {
        /// \alg
        /// - Return memory block of the Tnarray with parameters ::v and ::m.
        return Mblock<T>(v.v,m);
    }

    template <typename T, Uint32 n>
    inline Mblock<const T> Tnarrayresz<T,n>::to_mblock() const
    {
        /// \alg
        /// - Return memory block of the Tnarray with parameters ::v and ::m.
        return Mblock<const T>(v.v,m);
    }

    template <typename T, Uint32 n>
    inline Mblock<volatile T> Tnarrayresz<T,n>::to_mblock() volatile
    {
        /// \alg
        /// - Return memory block of the Tnarray with parameters ::v and ::m.
        return Mblock<volatile T>(v.v,m);
    }

    template <typename T, Uint32 n>
    inline Mblock<const volatile T> Tnarrayresz<T,n>::to_mblock() const volatile
    {
        /// \alg
        /// - Return memory block of the Tnarray with parameters ::v and ::m.
        return Mblock<const volatile T>(v.v,m);
    }

    template <typename T, Uint32 n>
    inline Uint32 Tnarrayresz<T,n>::size() const volatile
    {
        /// \alg
        /// - Return ::m.
        return m;
    }

    template <typename T, Uint32 n>
    inline Uint32 Tnarrayresz<T,n>::size_max() const volatile //PRQA S 4212 #static
    {
        /// \alg
        /// - Return retrieved value by Tnarray::size for ::v.
        return v.size();
    }

    template <typename T, Uint32 n>
    bool Tnarrayresz<T,n>::append(const T& elem)
    {
        /// \alg
        /// <ul>
        /// <li> Call ::resize with ::m+1 to accommodate one additional element.
        bool ret = resize(m+1U);
        /// <li> If resize operation successful:
        if(ret)
        {
            /// <ul>
            /// <li> Store the given element to the end of the array ::v.
            v[m-1U] = elem;
            /// <li> Return true.
            /// </ul>
        }
        /// <li> Else return false.
        return ret;
        /// </ul>
    }

    template <typename T, Uint32 n>
    void Tnarrayresz<T,n>::init()
    {
        /// \alg
        /// <ul>
        /// <li> Iterate through each element of the array.
        for(Uint32 i=0; i<n; i++)
        {
            /// <ul>
            /// <li> Call Tnarray::init for ::v to initialize each element.
            v[i].init();
            /// </ul>
        }
        /// </ul>
    }
}
#endif
