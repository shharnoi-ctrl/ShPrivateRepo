#ifndef U8PKMBLOCK_K_H_
#define U8PKMBLOCK_K_H_

#include <Bitutils.h>
#include <Mblock.h>

#include <U8pkmblock_fw.h>

namespace Base
{
    /// The Base library shall provide a read only class to manage packed version for block of bytes, using 
    /// high and low part of 16 bits word.
    /// \pre C2000 version cannot have a U8 block of size greater than 65535 (16bit addressing)
    class U8pkmblock_k
    {
    public:
        /// Read Only Packed Block of Bytes Default Constructor.
        /// \wi{6420}
        /// U8pkmblock_k class shall build itself upon construction and initialize its internal members as null.
        U8pkmblock_k();

        /// Read Only Packed Block of Bytes Constructor with Pointer and Size.
        /// \wi{20310}
        /// U8pkmblock_k class shall build itself upon construction with a given constant pointer and size.
        /// \pre C2000 cannot address more than ::max_c2000_sz consequtive bytes, so it is U8pkmblock_k maximum size.
        /// \param[in] data         Constant memory block of data to be used.
        /// \param[in] size_bytes   Size for the block of bytes (sz0 is in bytes).
        U8pkmblock_k(const void* data, Uint32 size);

        /// Read Only Packed Block of Bytes Constructor with Volatile Pointer and Size.
        /// \wi{20592}
        /// U8pkmblock_k class shall build itself upon construction with given volatile pointer and size.
        /// \pre C2000 cannot address more than ::max_c2000_sz consequtive bytes, so it is U8pkmblock_k maximum size.
        /// \param[in] data         Constant volatile memory block of data to be used.
        /// \param[in] size_bytes   Size for the block of bytes (sz0 is in bytes).
        U8pkmblock_k(const volatile void* data, Uint32 size_bytes);

        /// Read Only Packed Block of Bytes Copy Constructor with Given New Size.
        /// \wi{20593}
        /// U8pkmblock_k class shall build itself upon construction with another given U8pkmblock_k instance and a 
        /// new size.
        /// \pre New size should be lower or equals than the original one.
        /// \param[in] mb           Memory block to build of.
        /// \param[in] size         Size for the block of bytes.
        U8pkmblock_k(const U8pkmblock_k& mb, Uint32 size);

        /// Read Only Packed Block of Bytes Copy Constructor with Given new Size and Offset.
        /// \wi{20594}
        /// U8pkmblock_k class shall build itself upon construction with another given U8pkmblock_k instance from 
        /// a given offset and a new size.
        /// \pre Offset shall be aligned to 16-bit type words due to microcontroller architecture.
        /// \param[in] block        Memory block to build of.
        /// \param[in] offset       Offset in the input memory block.
        /// \param[in] size         Size for the block of bytes.
        U8pkmblock_k(const U8pkmblock_k& block, Uint32 offset, Uint32 size);

        /// Read Only Packed Block of Bytes Explicit Constructor with Given Memory Block of 16-bit Words.
        /// \wi{20595}
        /// U8pkmblock_k class shall build itself upon explicit construction with a given unsigned int 16-bit constant
        /// memory block.
        /// \pre C2000 cannot address more than ::max_c2000_sz consequtive bytes, so it is U8pkmblock_k maximum size.
        /// \param[in] buffer   Unigned int 16-bit constant memory block.
        explicit U8pkmblock_k(const Mblock<Uint16>& buffer);

        /// Read Only Packed Block of Bytes Explicit Constructor with Given Memory Block of Constant 16-bit Words.
        /// \wi{20596}
        /// U8pkmblock_k class shall build itself upon explicit construction with a given constant unsigned int
        /// 16-bit constant memory block.
        /// \pre C2000 cannot address more than ::max_c2000_sz consequtive bytes, so it is U8pkmblock_k maximum size.
        /// \param[in] buffer   Constant unigned int 16-bit constant memory block.
        explicit U8pkmblock_k(const Mblock<const Uint16>& buffer);

        /// Read Only Packed Block of Bytes Pointer Retriever.
        /// \wi{20597}
        /// U8pkmblock_k class shall be able to retrieve the pointer to its data first element.
        /// \return  Pointer to data.
        inline const void* get_pt() const
        {
            /// \alg
            /// - Return ::v.
            return U8pkmblock_k::v;
        }

        /// Read Only Packed Block of Bytes Same Memory Block Checker.
        /// \wi{6421}
        /// U8pkmblock_k class shall provide the capability to check if a given memory block is the same than the 
        /// current one.
        /// \param[in] block        Block of memory to be compared.
        /// \return True if both byte memory blocks are pointing to the same data and have the same size, 
        /// False otherwise.
        bool is_same(const U8pkmblock_k& block) const;

        /// Read Only Packed Block of Bytes Size Retriever.
        /// \wi{20598}
        /// U8pkmblock_k class shall be able to retrieve the size of its block of memory in bytes.
        /// \return Block size (in bytes).
        Uint32 size() const;

        /// Read Only Packed Block of Bytes Constant Volatile Size Retriever.
        /// \wi{5984}
        /// U8pkmblock_k class shall be able to retrieve the size of its block of memory in bytes in a volatile way.
        /// \return Block size (in bytes).
        Uint32 size() const volatile;

        /// Read Only Packed Block of Bytes Byte Retriever.
        /// \wi{5986}
        /// U8pkmblock_k class shall be able to retrieve a byte given its index.
        /// \param[in] i    Index of the byte to retrieve.
        /// \return  Byte at given index.
        Uint8 get(Uint32 i) const;

        /// Read Only Packed Block of Bytes Volatile Byte Retriever.
        /// \wi{20599}
        /// U8pkmblock_k class shall be able to retrieve a byte given its index in a volatile way.
        /// \param[in] i    Index of the byte to get.
        /// \return  Byte at given index
        Uint8 get(Uint32 i) const volatile;

        /// Read Only Packed Block of Bytes 16-bit Type Memory Block Retriever.
        /// \wi{6422}
        /// U8pkmblock_k class shall provide the capability to obtain a memory block of 16bits representation of 
        /// itself.
        /// \return This byte memory block as a Uint16 memory block.
        const Mblock<const Uint16> to_mblock() const;

        /// Read Only Packed Block of Bytes Equals Memory Block Checker.
        /// \wi{5983}
        /// U8pkmblock_k class shall provide the capability to compare its content to another U8pkmblock_k.
        /// \param[in] mb       Memory block to be compared.
        /// \return True if both contents are the same and the size are equal, False otherwise.
        bool equals(const U8pkmblock_k& mb) const;

        /// Read Only Packed Block of Bytes Reader.
        /// \wi{5988}
        /// U8pkmblock_k class shall provide the capability to read a part of itself, starting at given starting index, to 
        /// a provided memory block and an optional offset on it.
        /// Reads from this starting at start_idx to block.
        /// \param[in] start_idx    Offset in the source data.
        /// \param[in, out] dst     Destination memory block.
        /// \param[in] offset_dst   Offset in the destination memory block (default 0).
        /// \return Bytes actually read (stops writing at end of buffer).
        Uint32 read(Uint32 start_idx, U8pkmblock& dst, Uint32 offset_dst = 0) const;

    private:
        static const Uint32 max_c2000_sz = 65536;   ///< Max number of consecutive bytes C2000 can address.
        Uint32 sz;                                  ///< Size of this memory block.
        int16* v;                                   ///< Pointer to data.
        friend class U8pkmblock;
    };

    /// \alg
    /// - ::sz is initialized as 0.
    /// - ::v is initialized as 0.
    inline U8pkmblock_k::U8pkmblock_k() : sz(0), v(0)
    {
    }

    /// \alg
    /// - ::sz is initialized with given size.
    /// - ::v is initialized with given data.
    inline U8pkmblock_k::U8pkmblock_k(const void* data, Uint32 size) :
        sz(size),
        v(reinterpret_cast<int16*>(const_cast<void*>(data)))
    {
        Assertions::runtime(sz < max_c2000_sz);
    }

    /// \alg
    /// - ::sz is initialized with given size.
    /// - ::v is initialized with given data.
    inline U8pkmblock_k::U8pkmblock_k(const volatile void* data, Uint32 size) :
        sz(size),
        v(reinterpret_cast<int16*>(const_cast<void*>(data)))
    {
        Assertions::runtime(sz < max_c2000_sz);
    }

    /// \alg
    /// <ul>
    /// <li> ::sz is initialized as minimum size between given one and given byte memory block size.
    /// <li> ::v is initialized with the pointer to data of the given memory block.
    /// </ul>
    inline U8pkmblock_k::U8pkmblock_k(const U8pkmblock_k& mb, Uint32 size) :
        sz(Assertions::runtime(size<=mb.size()) ? size : mb.size()),
        v(mb.v)
    {
    }

    /// \alg
    /// <ul>
    /// <li> ::sz is initialized as the minimum size between the given one and the difference between the given 
    /// memory block size and the given offset.
    /// <li> ::v is initialized with the given offset, converted as words, from the data of the given memory block
    /// if given offset is lower than the size of the given memory block, otherwise with the data of the given 
    /// memory block.
    inline U8pkmblock_k::U8pkmblock_k(const U8pkmblock_k& block, Uint32 offset, Uint32 size) :
        sz((size <= (block.sz-offset)) ? size : block.sz-offset),
        v((offset<block.sz) ? block.v + (offset >> 1) : block.v)
    {
        // C2000 can not address bytes.
        Assertions::runtime((offset & 1) == 0);
    }

    /// \alg
    /// - ::sz is initialized size of the given memory block.
    /// - ::v is initialized with the pointer to the data of the given memory block.
    inline U8pkmblock_k::U8pkmblock_k(const Mblock<Uint16>& mb) :
        sz(Bitutils::words16_to_bytes(mb.sz)),
        v(reinterpret_cast<int16*>(mb.v))
    {
        Assertions::runtime(sz < max_c2000_sz);
    }

    /// \alg
    /// - ::sz is initialized size of the given memory block.
    /// - ::v is initialized with the pointer to the data of the given memory block.
    inline U8pkmblock_k::U8pkmblock_k(const Mblock<const Uint16>& mb) :
        sz(Bitutils::words16_to_bytes(mb.sz)),
        v(reinterpret_cast<int16*>(const_cast<Uint16*>(mb.v)))
    {
        Assertions::runtime(sz < max_c2000_sz);
    }

    inline bool U8pkmblock_k::is_same(const U8pkmblock_k& mb) const
    {
        /// \alg
        /// <ul>
        /// <li> Return true if:
        /// <ul>
        /// <li> ::v is equal to the pointer to the data of the given memory block.
        /// <li> ::sz is equal to the size of the given memory block.
        /// </ul>
        /// <li> False otherwise.
        /// </ul>
        return (v==mb.v) && (sz == mb.sz);
    }

    inline Uint32 U8pkmblock_k::size() const
    {
        /// \alg
        /// - Return ::sz.
        return sz;
    }

    inline Uint32 U8pkmblock_k::size() const volatile
    {
        /// \alg
        /// - Return ::sz.
        return sz;
    }

    inline Uint8 U8pkmblock_k::get(Uint32 i)const
    {
        /// \alg
        /// - Return retrieved value by Bitutils::get_u8 for ::v and given index.
        return Bitutils::get_u8(v, i);
    }

    inline const Mblock<const Uint16> U8pkmblock_k::to_mblock() const
    {
        /// \alg
        /// - Return Mblock<const Uint16> instance built with ::v and ::sz (converted from bytes to 16-bit words).
        // Size is in Uint16 = 2 byte
        return Mblock<const Uint16>(reinterpret_cast<const Uint16*>(v), Bitutils::bytes_to_words16(sz));
    }
}
#endif
