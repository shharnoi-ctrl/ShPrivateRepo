
#ifndef WATCHDOG_H_
#define WATCHDOG_H_

#include <Istep.h>
#include <Itunable.h>
#include <Array.h>

namespace Dsp28335_ent
{
    class Watchdog
    {
    public:
        enum Prescaler
        {
            pres01 = 1,
            pres02 = 2,
            pres04 = 3,
            pres08 = 4,
            pres16 = 5,
            pres32 = 6,
            pres64 = 7
        };

        /// Backup of watchdog registers at object creation time.
        struct Backup
        {
            Uint16 scsr;      ///< Backup of SCSR register
            Uint16 wdcr;      ///< Backup of WDCR register
            Uint16 wdwcr;     ///< Backup of WDWCR register
        };

        /// Enable Watchdog system.
        static void setup_enabled(Prescaler presc);
        /// Disable Watchdog system.
        static void setup_disabled();
        /// Disable windowed functionality
        static void disable_windowed();
        /// Clears watchdog counter
        static void notify();

        /// Setups watchdog to perform a reset instead of generating an interrupt on watchdog expiration
        /// enables it to generate a CPU reset.
        static void setup_for_reset();

        /// Create Watchdog backup
        static Backup backup();

        /// Restores watchdog registers backed up when b was built.
        static void restore(const Backup& bkp);

    private:
        Watchdog(); ///< = delete
        Watchdog(const Watchdog& orig); ///< = delete
        Watchdog& operator=(const Watchdog& orig); ///< = delete
    };
}
#endif
