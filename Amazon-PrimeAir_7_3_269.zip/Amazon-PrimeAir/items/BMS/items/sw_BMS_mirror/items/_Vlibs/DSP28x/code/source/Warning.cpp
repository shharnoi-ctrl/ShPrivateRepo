#include <Asm.h>

namespace Bsp
{
    void warning()
    {
        Dsp28335_ent::asm_stop();
    }

    bool warning_assrt(bool b)
    {
        if (!b)
        {
            Dsp28335_ent::asm_stop();
        }
        return b;
    }
}
