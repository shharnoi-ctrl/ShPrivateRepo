#ifndef RVECTOR3_H__
#define RVECTOR3_H__

#include <Irvector3.h>
#include <Ku16.h>
#include <Ir64vector3_fw.h>

namespace Maverick
{
    class Rvector3: public Irvector3
    {
    public:
        Rvector3();
        Rvector3(Real r0,
                 Real r1,
                 Real r2);

        explicit Rvector3(const Base::Tnarray<Real64, Ku16::u3>& val);

        explicit Rvector3(const Ir64vector3& val);

    protected:
        Real data[Ku16::u3];

    private:
        Rvector3(const Rvector3& src); ///< = delete
        Rvector3& operator=(const Rvector3& src); ///< = delete
    };
}
#endif
