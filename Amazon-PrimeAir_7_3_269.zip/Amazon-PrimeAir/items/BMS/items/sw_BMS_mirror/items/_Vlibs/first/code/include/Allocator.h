#ifndef ALLOCATOR_H
#define ALLOCATOR_H

#include <new>
#include <Assertions.h>
#include <Rngit.h>
#include <Ttraits.h>

#include <Mblock_fw.h>

namespace Base
{

    /// Manages the allocation and construction of elements in a reserved memory buffer.
    class Allocator
    {
    public:
        /// Allocator Constructor with Given Pointer.
        /// \wi{4894}
        /// Allocator class shall build itself upon construction with given first element address of memory buffer and
        /// its size.
        /// \param[in] pbuf0 Pointer to first element address of memory buffer.
        /// \param[in] size0 Buffer size.
        Allocator(Uint16* pbuf0, Uint32 size0);

        /// Allocator Constructor with Given Memory Block.
        /// \wi{17894}
        /// Allocator class shall build itself upon construction with a given memory block.
        /// \param[in] mem Memory block of Uint16 type data (Mblock<Uint16>) to be used as allocator buffer.
        explicit Allocator(Mblock<Uint16>& mem);

        /// Array of Elements Allocator.
        /// \wi{4896}
        /// Allocator class shall provide persistent memory for allocating an array of elements.
        /// \param[in] n_element Number of elements to be allocated.
        /// \param[in] element_size Each element size to be allocated.
        /// \return Memory pointer where data requested will be allocated.
        void* allocate(Uint32 n_elements, Uint32 element_size);

        /// Allocator Allocate Memory Block.
        /// \wi{20617}
        /// Allocator class shall provide a method to allocate memory for a given number of elements of the templated
        /// type.
        /// \return Memory block of the allocated memory.
        /// \rat Note that this method does not call the constructor of the allocated elements, it only returns the
        /// reserved memory. If the templated type needs the constructor a different method shall be used.
        template <typename T>
        Mblock<T> allocate_mblock(const Uint32 n_elements);

        /// One Element Allocator.
        /// \wi{6418}
        /// Allocator class shall provide persistent memory for allocating one element.
        /// \param[in] element_size Element size to be allocated.
        /// \return Memory pointer where data requested will be allocated.
        void* allocate_one(Uint32 element_size);

        /// Allocator Is Ok Requester.
        /// \wi{5675}
        /// Allocator class shall be able to determine if the allocator status is valid.
        /// \return True if the allocator is in a valid state, False if not.
        bool get_alloc_ok() const;

        /// Allocator Allocation Closer.
        /// \wi{5615}
        /// When requested, Allocator class shall close the allocation not allowing more allocations.
        void close_allocation();

        /// Allocator Total Memory Retriever.
        /// \wi{5679}
        /// Allocator class shall be able to retrieve total memory managed by the allocator.
        /// \return Total memory managed by the allocator established on construction.
        Uint32 total_mem() const;

        /// Allocator Used Memory Retriever.
        /// \wi{5677}
        /// Allocator class shall be able to retrieve current used memory by the allocator.
        /// \return Memory being used by the allocator.
        Uint32 used_mem() const;

        /// One Element Allocator Without Parameters.
        /// \wi{5681}
        /// Allocator class shall be able to build an element without parameters.
        /// \return Pointer to element already allocated.
        template <typename T>
        T* allocate_new();

        /// One Element Allocator With One Parameter.
        /// \wi{17895}
        /// Allocator class shall be able to build an element with one parameter.
        /// \param[in] param0 First parameter.
        /// \return Pointer to element already allocated.
        template <typename T, typename P0>
        T* allocate_new(P0& param0);

        /// One Element Allocator With Two Parameters.
        /// \wi{17896}
        /// Allocator class shall be able to build an element with two parameters.
        /// \param[in] param0 First parameter.
        /// \param[in] param1 Second parameter.
        /// \return Pointer to element already allocated.
        template <typename T,
                  typename P0,
                  typename P1>
        T* allocate_new(P0& param0, P1& param1);

        /// One Element Allocator With Three Parameters.
        /// \wi{17897}
        /// Allocator class shall be able to build an element with three parameters.
        /// \param[in] param0 First parameter.
        /// \param[in] param1 Second parameter.
        /// \param[in] param2 Third parameter.
        /// \return Pointer to element already allocated.
        template <typename T,
                  typename P0,
                  typename P1,
                  typename P2>
        T* allocate_new(P0& param0,
                        P1& param1,
                        P2& param2);

        /// One Element Allocator With Four Parameters.
        /// \wi{17898}
        /// Allocator class shall be able to build an element with four parameters.
        /// \param[in] param0 First parameter.
        /// \param[in] param1 Second parameter.
        /// \param[in] param2 Third parameter.
        /// \param[in] param3 Fourth parameter.
        /// \return Pointer to element already allocated.
        template <typename T,
                  typename P0,
                  typename P1,
                  typename P2,
                  typename P3>
        T* allocate_new(P0& param0,
                        P1& param1,
                        P2& param2,
                        P3& param3);

        /// One Element Allocator With Five Parameters.
        /// \wi{17899}
        /// Allocator class shall be able to build an element with five parameters.
        /// \param[in] param0 First parameter.
        /// \param[in] param1 Second parameter.
        /// \param[in] param2 Third parameter.
        /// \param[in] param3 Fourth parameter.
        /// \param[in] param4 Fifth parameter.
        /// \return Pointer to element already allocated.
        template <typename T,
                  typename P0,
                  typename P1,
                  typename P2,
                  typename P3,
                  typename P4>
        T* allocate_new(P0& param0,
                        P1& param1,
                        P2& param2,
                        P3& param3,
                        P4& param4);

        /// One Element Allocator With Six Parameters.
        /// \wi{17900}
        /// Allocator class shall be able to build an element with six parameters.
        /// \param[in] param0 First parameter.
        /// \param[in] param1 Second parameter.
        /// \param[in] param2 Third parameter.
        /// \param[in] param3 Fourth parameter.
        /// \param[in] param4 Fifth parameter.
        /// \param[in] param5 Sixth parameter.
        /// \return Pointer to element already allocated.
        template <typename T,
                  typename P0,
                  typename P1,
                  typename P2,
                  typename P3,
                  typename P4,
                  typename P5>
        T* allocate_new(P0& param0,
                        P1& param1,
                        P2& param2,
                        P3& param3,
                        P4& param4,
                        P5& param5);

        /// One Element Allocator With Seven Parameters.
        /// \wi{17901}
        /// Allocator class shall be able to build an element with seven parameters.
        /// \param[in] param0 First parameter.
        /// \param[in] param1 Second parameter.
        /// \param[in] param2 Third parameter.
        /// \param[in] param3 Fourth parameter.
        /// \param[in] param4 Fifth parameter.
        /// \param[in] param5 Sixth parameter.
        /// \param[in] param6 Seventh parameter.
        /// \return Pointer to element already allocated.
        template <typename T,
                  typename P0,
                  typename P1,
                  typename P2,
                  typename P3,
                  typename P4,
                  typename P5,
                  typename P6>
        T* allocate_new(P0& param0,
                        P1& param1,
                        P2& param2,
                        P3& param3,
                        P4& param4,
                        P5& param5,
                        P6& param6);

        /// One Element Allocator With Eight Parameters.
        /// \wi{17902}
        /// Allocator class shall be able to build an element with eight parameters.
        /// \param[in] param0 First parameter.
        /// \param[in] param1 Second parameter.
        /// \param[in] param2 Third parameter.
        /// \param[in] param3 Fourth parameter.
        /// \param[in] param4 Fifth parameter.
        /// \param[in] param5 Sixth parameter.
        /// \param[in] param6 Seventh parameter.
        /// \param[in] param7 Eighth parameter.
        /// \return Pointer to element already allocated.
        template <typename T,
                  typename P0,
                  typename P1,
                  typename P2,
                  typename P3,
                  typename P4,
                  typename P5,
                  typename P6,
                  typename P7>
        T* allocate_new(P0& param0,
                        P1& param1,
                        P2& param2,
                        P3& param3,
                        P4& param4,
                        P5& param5,
                        P6& param6,
                        P7& param7);

        /// Allocator for Array Of Elements Without Parameters.
        /// \wi{5682}
        /// Allocator class shall be able to allocate an array of elements built with no parameters.
        /// \param[in] n_elements Number of elements to be allocated.
        /// \return Pointer to first element of array already allocated.
        template <typename T>
        T* allocate_new_array(Uint32 n_elements);

        /// Allocator for Array of Elements With One Parameter.
        /// \wi{17903}
        /// Allocator class shall be able to allocate an array of elements built with one parameter.
        /// \param[in] n_elements Number of elements to be allocated.
        /// \param[in] param0 Parameter used to build each element into the array.
        /// \return Pointer to first element of array already allocated.
        template <typename T, typename P0>
        T* allocate_new_array(Uint32 n_elements, P0& param0);

        /// Allocator for Array of Elements With Two Parameters.
        /// \wi{17904}
        /// Allocator class shall be able to allocate an array of elements built with two parameters.
        /// \param[in] n_elements Number of elements to be allocated.
        /// \param[in] param0 First parameter used to build each element into the array.
        /// \param[in] param1 Second parameter used to build each element into the array.
        /// \return Pointer to first element of array already allocated.
        template <typename T,
                  typename P0,
                  typename P1>
        T* allocate_new_array(Uint32 n_elements,
                              P0& param0,
                              P1& param1);

        /// Allocator for Array of Elements With Three Parameters.
        /// \wi{17905}
        /// Allocator class shall be able to allocate an array of elements built with three parameters.
        /// \param[in] n_elements Number of elements to be allocated.
        /// \param[in] param0 First parameter used to build each element into the array.
        /// \param[in] param1 Second parameter used to build each element into the array.
        /// \param[in] param2 Third parameter used to buid each element into the array.
        /// \return Pointer to first element of array already allocated.
        template <typename T,
                  typename P0,
                  typename P1,
                  typename P2>
        T* allocate_new_array(Uint32 n_elements,
                              P0& param0,
                              P1& param1,
                              P2& param2);

        /// Allocator for Array of Elements Built With Iterator-type of Parameters.
        /// \wi{17906}
        /// Allocator class shall be able to allocate an array of elements building each one with a different
        /// parameter provided by an iterator-type of parameters.
        /// \param[in] n_elements Number of elements to be allocated.
        /// \param[in] param0 Parameters iterator to be used in the elements allocation.
        /// \return Pointer to first element of array already allocated.
        template <typename T, class T2>
        T* allocate_new_array_it(Uint32 n_elements, T2 param0);

        /// Allocator for Array of Elements Build with Array-type of Parameters.
        /// \wi{5683}
        /// Allocator class shall be able to allocate an array of elements building each one with a different
        /// parameter provided by an array-type of parameters.
        /// \param[in] n_elements Number of elements to be allocated.
        /// \param[in] param0 Parameters array to be used in the elements allocation.
        /// \return Pointer to first element of array already allocated.
        template <typename T, typename ARRAY>
        T* allocate_new_array_array(Uint32 n_elements, ARRAY param0);

        /// Allocator for Array of Elements with One static Parameter and Another Array-Type.
        /// \wi{17907}
        /// Allocator class shall be able to allocate an array of elements building each one with a shared parameter
        /// and another provided by an array-type of parameters.
        /// \param[in] n_elements Number of elements to be allocated.
        /// \param[in] p First parameter shared by all elements.
        /// \param[in] param0 Parameters array to be used in the elements allocation.
        /// \return Pointer to first element of array already allocated.
        template <typename T, class P, typename ARRAY>
        T* allocate_new_array_array(Uint32 n_elements, P p, ARRAY param0);


    private:

        /// Internal allocator storage buffer, manages the pointer in memory.
        class Allocator_buffer
        {
        public:
            /// Allocator Buffer Constructor.
            /// \wi{4895}
            /// Allocator_buffer class shall build itself upon construction with a given address to the first element
            /// of the memory buffer and the buffer size.
            /// \param[in] pbuf0 Pointer to the first element of the memory buffer.
            /// \param[in] Buffer size.
            Allocator_buffer(Uint16* pbuf0, Uint32 size0);

            /// Allocator Buffer Allocation.
            /// \wi{4897}
            /// Allocator_buffer class shall be able to allocate a given number of elements of a given size.
            /// \param[in] n_elements Number of elements to be allocated.
            /// \param[in] element_size Size of one element in minimum addressable word size of the system.
            void* allocate(Uint32 n_elements, Uint32 element_size);

            /// Allocator Buffer Checker.
            /// \wi{5676}
            /// Allocator_buffer class shall be able to check if the allocation is correct.
            /// \return True if there are available room in the buffer, False if not.
            bool get_alloc_ok() const;

            /// Allocator Buffer Close Allocation.
            /// \wi{5616}
            /// Allocator_buffer class shall be able to close the allocator not allowing more allocations.
            void close_allocation();

            /// Allocator Buffer Size Retriever.
            /// \wi{5680}
            /// Allocator_buffer class shall be able to retrieve the total size managed by this allocator.
            /// \return Size received in construction.
            Uint32 total_mem() const;

            /// Allocator Buffer Used Memory Retriever.
            /// \wi{5678}
            /// Allocator_buffer class shall be able to retrieve the memory being used by the allocator.
            /// \return Current memory used in minimum addressable word size by the system.
            Uint32 used_mem() const;

            inline const Uint16* get_pt() const
            {
                return pbuf;
            }

        private:
            /// Allocator buffer possible states.
            enum State
            {
                open   = 0,      ///< Allocator is open, new allocations are allowed.
                closed = 1,      ///< Allocator closed, new allocations will result in error.
                error  = 2       ///< Allocator with error overflow or allocation on closed state.
            };

            Uint16* const pbuf;  ///< Pointer to first buffer element.
            const Uint32 size;   ///< Buffer size.
            Uint32 idx;          ///< Index of first free position in buffer.
            State st;            ///< Current allocation state.

            Allocator_buffer();                                         ///< = delete
            Allocator_buffer(const Allocator_buffer& orig);             ///< = delete
            Allocator_buffer& operator=(const Allocator_buffer& orig);  ///< = delete
        };

        Allocator_buffer alloc_buffer;  ///< Data Buffer.

        Allocator();                                   ///< = delete
        Allocator(const Allocator& orig);              ///< = delete
        Allocator& operator=(const Allocator& orig);   ///< = delete

    };

    inline bool Allocator::Allocator_buffer::get_alloc_ok() const
    {
        /// \alg
        /// - Return True if ::st is different to State::error, False if not.
        return (st != error);
    }

    inline void Allocator::Allocator_buffer::close_allocation()
    {
        /// \alg
        /// - IF ::st is equals to State::open, set ::st to State::closed.
        if (st == open)
        {
            st = closed;
        }
    }

    inline Uint32 Allocator::Allocator_buffer::total_mem() const
    {
        /// \alg
        /// - Return ::size value.
        return size;
    }

    inline Uint32 Allocator::Allocator_buffer::used_mem() const
    {
        /// \alg
        /// - Return ::idx value.
        return idx;
    }

    inline Allocator::Allocator(Uint16* pbuf0, Uint32 size0) : alloc_buffer(pbuf0,size0)
    {
    }

    inline void* Allocator::allocate(Uint32 n_elements, Uint32 element_size)
    {
        return alloc_buffer.allocate(n_elements, element_size);
    }

    template <typename T>
    Mblock<T> Allocator::allocate_mblock(const Uint32 n_elements)
    {
        return Mblock<T>(static_cast<T*>(allocate(n_elements, sizeof(T))), n_elements);
    }

    inline bool Allocator::get_alloc_ok() const
    {
        /// \alg
        /// - Return Allocator_buffer::get_alloc_ok retrieved value for ::alloc_buffer.
        return alloc_buffer.get_alloc_ok();
    }

    inline void Allocator::close_allocation()
    {
        /// \alg
        /// - Call to Allocator_buffer::close_allocation for ::alloc_buffer.
        alloc_buffer.close_allocation();
    }

    inline Uint32 Allocator::total_mem() const
    {
        /// \alg
        /// - Return Allocator_buffer::total_mem retrieved value for ::alloc_buffer.
        return alloc_buffer.total_mem();
    }

    inline Uint32 Allocator::used_mem() const
    {
        /// \alg
        /// - Return Allocator_buffer::used_mem retrieved value for ::alloc_buffer.
        return alloc_buffer.used_mem();
    }


    template <typename T>
    inline T* Allocator::allocate_new()
    {
        T* const p = static_cast<T*>(allocate_one(sizeof(T)));
        new (p) T();
        return p;
    }

    template <typename T, typename P0>
    inline T* Allocator::allocate_new(P0& param0)
    {
        T* const p = static_cast<T*>(allocate_one(sizeof(T)));
        new (p) T(param0);
        return p;
    }

    template <typename T,
              typename P0,
              typename P1>
    inline T* Allocator::allocate_new(P0& param0, P1& param1)
    {
        T* const p = static_cast<T*>(allocate_one(sizeof(T)));
        new (p) T(param0,param1);
        return p;
    }

    template <typename T,
              typename P0,
              typename P1,
              typename P2>
    inline T* Allocator::allocate_new(P0& param0,
                                      P1& param1,
                                      P2& param2)
    {
        T* const p = static_cast<T*>(allocate_one(sizeof(T)));
        new (p) T(param0,param1,param2);
        return p;
    }

    template <typename T,
              typename P0,
              typename P1,
              typename P2,
              typename P3>
    inline T* Allocator::allocate_new(P0& param0,
                                      P1& param1,
                                      P2& param2,
                                      P3& param3)
    {
        T* const p = static_cast<T*>(allocate_one(sizeof(T)));
        new (p) T(param0,param1,param2,param3);
        return p;
    }

    template <typename T,
              typename P0,
              typename P1,
              typename P2,
              typename P3,
              typename P4>
    inline T* Allocator::allocate_new(P0& param0,
                                      P1& param1,
                                      P2& param2,
                                      P3& param3,
                                      P4& param4)
    {
        T* const p = static_cast<T*>(allocate_one(sizeof(T)));
        new (p) T(param0,param1,param2,param3,param4);
        return p;
    }

    template <typename T,
              typename P0,
              typename P1,
              typename P2,
              typename P3,
              typename P4,
              typename P5>
    inline T* Allocator::allocate_new(P0& param0,
                                      P1& param1,
                                      P2& param2,
                                      P3& param3,
                                      P4& param4,
                                      P5& param5)
    {
        T* const p = static_cast<T*>(allocate_one(sizeof(T)));
        new (p) T(param0,param1,param2,param3,param4,param5);
        return p;
    }

    template <typename T,
              typename P0,
              typename P1,
              typename P2,
              typename P3,
              typename P4,
              typename P5,
              typename P6>
    inline T* Allocator::allocate_new(P0& param0,
                                      P1& param1,
                                      P2& param2,
                                      P3& param3,
                                      P4& param4,
                                      P5& param5,
                                      P6& param6)
    {
        T* const p = static_cast<T*>(allocate_one(sizeof(T)));
        new (p) T(param0,param1,param2,param3,param4,param5,param6);
        return p;
    }

    template <typename T,
              typename P0,
              typename P1,
              typename P2,
              typename P3,
              typename P4,
              typename P5,
              typename P6,
              typename P7>
    inline T* Allocator::allocate_new(P0& param0,
                                      P1& param1,
                                      P2& param2,
                                      P3& param3,
                                      P4& param4,
                                      P5& param5,
                                      P6& param6,
                                      P7& param7)
    {
        T* const p = static_cast<T*>(allocate_one(sizeof(T)));
        new (p) T(param0,param1,param2,param3,param4,param5,param6,param7);
        return p;
    }

    template <typename T>
    T* Allocator::allocate_new_array(Uint32 n_elements)
    {
        T* const p = static_cast<T*>(allocate(n_elements,sizeof(T)));
        if (p != 0)
        {
            for (Uint32 i = 0; i < n_elements; ++i)
            {
                new (p+i) T();
            }
        }
        return p;
    }

    template <typename T, typename P0>
    T* Allocator::allocate_new_array(Uint32 n_elements, P0& param0)   //PRQA S 4283 #param0 is modified inside
    {
        T* const p = static_cast<T*>(allocate(n_elements,sizeof(T)));
        if (p != 0)
        {
            for (Uint32 i = 0; i < n_elements; ++i)
            {
                new (p+i) T(param0);
            }
        }
        return p;
    }

    template <typename T,
              typename P0,
              typename P1>
    T* Allocator::allocate_new_array(Uint32 n_elements,
                                     P0& param0,                     //PRQA S 4283 #param0 is modified inside
                                     P1& param1)                     //PRQA S 4283 #param1 is modified inside
    {
        T* const p = static_cast<T*>(allocate(n_elements,sizeof(T)));
        if (p != 0)
        {
            for (Uint32 i = 0; i < n_elements; ++i)
            {
                new (p+i) T(param0, param1);
            }
        }
        return p;
    }

    template <typename T,
              typename P0,
              typename P1,
              typename P2>
    T* Allocator::allocate_new_array(Uint32 n_elements,
                                     P0& param0,                    //PRQA S 4283 #param0 is modified inside
                                     P1& param1,                    //PRQA S 4283 #param1 is modified inside
                                     P2& param2)                    //PRQA S 4283 #param2 is modified inside
    {
        T* const p = static_cast<T*>(allocate(n_elements, sizeof(T)));
        if (p != 0)
        {
            for (Uint32 i = 0; i < n_elements; ++i)
            {
                new (p+i) T(param0,param1,param2);
            }
        }
        return p;
    }

    template <typename T, class T2>
    T* Allocator::allocate_new_array_it(Uint32 n_elements, T2 param0)
    {
        T* p = 0; // Return pointer
        // number of arguments shall match
        if (Base::Assertions::runtime(n_elements == param0.pending_size()))
        {
            p = static_cast<T*>(allocate(n_elements, sizeof(T)));
            if (p != 0)
            {
                for (Uint32 i = 0; i < n_elements; ++i)
                {
                    new (p+i) T(param0.next());
                }
            }
        }
        return p;
    }

    template <typename T, typename ARRAY>
    T* Allocator::allocate_new_array_array(Uint32 n_elements, ARRAY param0)
    {
        T* p = 0; // Return pointer
        // number of arguments shall match
        if (Base::Assertions::runtime(n_elements == param0.size()))
        {
            p = static_cast<T*>(allocate(n_elements, sizeof(T)));
            if (p != 0)
            {
                for (Uint32 i = 0; i < n_elements; ++i)
                {
                    new (p+i) T(param0[i]);
                }
            }
        }
        return p;
    }

    template <typename T, class P, typename ARRAY>
    T* Allocator::allocate_new_array_array(Uint32 n_elements, P param0, ARRAY param1)
    {
        T* p = 0; // Return pointer
        // number of arguments shall match
        if (Base::Assertions::runtime(n_elements == param1.size()))
        {
            p = static_cast<T*>(allocate(n_elements, sizeof(T)));
            if (p != 0)
            {
                for (Uint32 i = 0; i < n_elements; ++i)
                {
                    // As C++ doen't allow to create an array of references, it should be an array of pointers to an
                    // structure with to_mblock() function defined.
                    new (p+i) T(param0, param1[i]->to_mblock());
                }
            }
        }
        return p;
    }
}
#endif

