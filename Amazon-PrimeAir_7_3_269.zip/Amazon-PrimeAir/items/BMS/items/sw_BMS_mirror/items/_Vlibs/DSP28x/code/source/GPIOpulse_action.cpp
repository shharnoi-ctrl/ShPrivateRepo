#include <GPIOpulse_action.h>

#include <Const.h>
#include <Delay.h>
#include <Ku16.h>
#include <Mutex.h>

namespace Dsp28335_ent
{
    GPIOpulse_action::GPIOpulse_action(GPIOid gpio0, bool idle_state0):
        gpio(gpio0),
        idle_state(idle_state0),
        triggered(false),
        tout(0.0F)
    {
        /// \alg
        /// <ul>
        /// Initialize attributes as following: <ul>
        /// Name        | Value
        /// ----------- | ------------------
        /// gpio        | GPIO(gpio0)
        /// idle_state  | ::idle_state0
        /// triggered   | false
        /// tout        | Timeout(0.0F)
        /// </ul>
        /// <li> Set GPIO to provided ::idle_state0.
        gpio.set(idle_state);
        /// </ul>
    }

    void GPIOpulse_action::start_pulse(Real period0)
    {
        /// \alg
        /// <ul>
        /// <li> Assume that:
        /// <ul>
        ///     <li> Provided period0 is strictly greater than 1 millisecond.
        ///     <li> No pulse is currently pending to be performed.
        Base::Assertions::runtime((period0 >= Const::E1000) && (!triggered));
        /// </ul>

        /// <li> Fix tout expiration time to provided ::period0.
        tout.set_timeout_s(period0);

        /// <li> Set triggered flag to true in order to trigger high-priority process at step_hi.
        triggered = true;

        /// </ul>
    }

    void GPIOpulse_action::force_pulse(Uint16 period0)
    {
        /// \alg
        /// <li> Assume that provided period0 is less or equals to 20 (microseconds).
        Base::Assertions::runtime(period0 <= Ku16::u20);

        /// <li> Enter critical section, ensuring no process will interrupt those instructions.
        {
            Base::Mutex mutex(true);

            gpio.set(!idle_state);  /// <li> Set GPIO to pulse state (=inverted value of idle_state).
            Delay::us(period0);     /// <li> Wait period_mic microseconds.
            gpio.set(idle_state);   /// <li> Release GPIO to idle state.
        }
        /// </ul>
    }

    void GPIOpulse_action::step0()
    {
        /// \alg
        /// <ul>
        /// <li> Set gpio to idle_state if time out expired, else to inverted value of idle_state.
        const bool curr_state = (tout.expired()) ? idle_state : !idle_state;
        gpio.set(curr_state);
        /// <li> Set triggered value to false if gpio was set to idle_state, else to true.
        triggered = (curr_state != idle_state);
        /// </ul>
    }

    bool GPIOpulse_action::step_hi()
    {
        /// \alg
        /// <ul>
        /// <li> If both GPIO is not toggling and triggered flag is true, then start tout expiration timer.
        const bool has_trigger = (gpio.get() == idle_state) && triggered && (tout.start(), true);
        /// <li> Then, if triggered flag is true, call run_long_pulse or run_short_pulse depending in_ms flag is true.
        const bool perform_pulse = triggered && (step0(), true);
        /// <li> Finally return true if triggered flag is true, else return false.
        return !triggered;
        /// </ul>
    }
}
