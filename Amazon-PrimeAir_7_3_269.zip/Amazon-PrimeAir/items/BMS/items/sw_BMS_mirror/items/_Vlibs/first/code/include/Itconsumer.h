#ifndef ITCONSUMER_H_
#define ITCONSUMER_H_

#include <Itconsumer_fw.h>
#include <Ttraits.h>

namespace Base
{
    template<typename T>
    class Itconsumer
    {
    public:
        typedef typename JSF116_param<T>::type JSF116_param_type;
        typedef T type;

        /// Writes data to be consumed.
        /// \return True if write is accepted.
        virtual bool write(JSF116_param_type data) = 0;

        /// \return True if write operation would be accepted.
        virtual bool wr_available() const = 0;

    protected:
        inline ~Itconsumer() {};
    };
}
#endif

