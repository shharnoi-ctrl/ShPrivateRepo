#ifndef IENDIAN16_H__
#define IENDIAN16_H__

#include <Entypes.h>

namespace Base
{
    template<class T> class Array;

    class Iendian16
    {
    public:
        virtual void put_uint16(const Uint16& p,
                                NWord* v,
                                Uint32& x,
                                int16 nbits) const = 0;
        virtual void get_uint16(Uint16& p,
                                const NWord* v,
                                Uint32& x,
                                int16 nbits) const = 0;
    protected:
        Iendian16();
        ~Iendian16();
        
    private:
        Iendian16(const Iendian16& orig); ///< = delete
        Iendian16& operator=(const Iendian16& orig); ///< = delete
    };

    inline Iendian16::Iendian16()
    {
    }

    inline Iendian16::~Iendian16() //PRQA S 2635 #destructor replaced with default
    {
    }

}

#endif
