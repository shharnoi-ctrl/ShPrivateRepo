#ifndef INCLUDE_CANCFG_H_
#define INCLUDE_CANCFG_H_

#include <CANid.h>
#include <CANid_filter.h>
#include <Tnarrayresz.h>

#include <Lossy_fw.h>
#include <Lossy_error_fw.h>
#include <Tuntraits_fw.h>

namespace Dsp28335_ent
{
    // CAN Configuration.
    struct CANcfg
    {
        struct Rxcfg
        {
            // NOTE: Not applicable to CAN-FD peripherals.
            Uint16 sz;                          ///< Number of mailboxes dedicated to rx.
            Base::CANid_filter flt;             ///< Filter applied to mailbox subset.
            /// Rxcfg Deserialization.
            /// \wi{5797}
            /// The Rxcfg structure shall be deserializable from its PDIC.
            /// \param[in,out] str Buffer to deserialize.
            void cset(Base::Lossy_error& str);
        };

        static const Uint16 mbox_sz = 32;       ///< Mailbox count.
        static const Uint16 rxcfg_szmax = 16;   ///< Maximum number of of rx sets.

        Uint32 br; ///< CAN Baudrate. Must be <= baudrate_max.

        typedef Base::Tnarrayresz<Rxcfg, rxcfg_szmax> Trx_array;    ///< Type for each rx entry.
        typedef Base::Tuntraits::T2<Rxcfg, Trx_array>::Arraytun_sz16 Trx_array_tun; ///< Tunable type.
        Trx_array rx;       ///< Configuration for each Rx.

        /// CANcfg Init.
        /// \wi{6605}
        /// CANcfg structure shall provide the capability to initialize itself with default values.
        void init();
        /// CANcfg Validate.
        /// \wi{6606}
        /// CANcfg structure shall provide the capability to check if CANcfg has a valid configuration.
        /// \return True if the configuration is valid.
        bool validate() const;

        /// CANcfg Deserialization.
        /// \wi{6607}
        /// The CANcfg structure shall be deserializable from its PDIC.
        /// \param[in,out] str Buffer to deserialize.
        void cset(Base::Lossy_error& str);
    };    
}
#endif
