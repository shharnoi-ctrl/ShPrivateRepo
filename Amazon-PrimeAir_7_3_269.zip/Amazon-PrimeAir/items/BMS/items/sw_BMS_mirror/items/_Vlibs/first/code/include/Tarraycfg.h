#ifndef TARRAYCFG_H_
#define TARRAYCFG_H_

#include <Entypes.h>
#include <Assertions.h>

namespace Base
{
    /// Encapsulates calling to "config" method on each element of a vector/array
    /// NOTE: ARRAY can be a reference if needed.
    template <typename ARRAY, typename CFG>
    class Tarraycfg
    {
    public:
        ARRAY obj;                      ///< Array or reference to be configured

        explicit Tarraycfg(ARRAY& obj); ///< Constructor with reference

        void config(const CFG& cfg);    ///< Configure each object element with its corresponding configuration
    };

    template <typename ARRAY, typename CFG>
    Tarraycfg<ARRAY,CFG>::Tarraycfg(ARRAY& obj0) : obj(obj0)
    {
    }

    template <typename ARRAY, typename CFG>
    void Tarraycfg<ARRAY,CFG>::config(const CFG& cfg)
    {
        if(Base::Assertions::runtime(obj.size() == cfg.size()))
        {
            for(Uint32 i=0; i < obj.size(); ++i)
            {
                obj[i].config(cfg[i]);
            }
        }
    }
}
#endif
