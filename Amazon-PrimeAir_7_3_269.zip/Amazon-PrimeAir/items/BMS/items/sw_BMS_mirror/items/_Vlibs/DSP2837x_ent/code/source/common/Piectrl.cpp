#include "Piectrl.h"
#include <Asm.h>
#include <Tmem.h>
#include <Bitutils.h>
#include <Hregmap.h>

extern __cregister volatile Uint16 IFR;
extern __cregister volatile Uint16 IER;

namespace Dsp28335_ent
{
    struct Piectrl_bits 
    {                   // bits description
        Uint16 enpie:1;                     // 0 PIE Enable
        Uint16 pievect:15;                  // 15:1 PIE Vector Address
    };

    union Piectrl_reg 
    {
        Uint16        all;
        Piectrl_bits  bit;
    };

    struct Pie_ef_reg
    {
        Uint16 ier;  ///< interrupt group enable register
        Uint16 ifr;  ///< Interrupt Group Flag Register
    };

    struct Piectrl::Registers
    {
        static const Uint16 ef_size = 12;
        Piectrl_reg     ctrl;           ///< ePIE Control Register
        Uint16          ack;            ///< Interrupt Acknowledge Register for each group (4 MSB reserved)
        Pie_ef_reg      ef[ef_size];    ///< Enable and flag enable registers for each group
    };

    static const Uint32 piectrl_regs_addr = 0x000CE0UL;

    Piectrl::Piectrl() : regs(Hregmap::get<Piectrl::Registers, piectrl_regs_addr>())
    {
    }

    void Piectrl::init()
    {
        // Disable Interrupts at the CPU level:
        asm_dint();

        Piectrl pie;
        // Disable the PIE
        pie.regs.ctrl.bit.enpie = 0;

        // Clear all PIEIER and PIEIFR registers:
        Base::Tmem::set<sizeof(pie.regs.ef)>(const_cast<Pie_ef_reg*>(pie.regs.ef), 0);

        // clear IER, IFR
        IER = 0;
        IFR = 0;
    }

    void Piectrl::enable_pie()
    {
        Piectrl pie;
        pie.regs.ctrl.bit.enpie = 1;
    }

    void Piectrl::enable(Mid id)
    {
        IER |=  Base::Bitutils::get_mask_1bit<Uint16>(id.grp);
        Piectrl pie;
        pie.regs.ef[id.grp].ier |= id.flg;
    }

    void Piectrl::enable_nmi_tmr1()
    {
        // NMI have no mapping in pie.regs
        IER |= Base::Bitutils::bitset16_12;
    }

    void Piectrl::enable_nmi_tmr2()
    {
        // NMI have no mapping in pie.regs
        IER |= Base::Bitutils::bitset16_13;
    }

    void Piectrl::disable(Mid id)
    {
        Piectrl pie;
        pie.regs.ef[id.grp].ier &= (~id.flg);
    }

    void Piectrl::ack(Group grp0)
    {
        Piectrl pie;
        const Uint16 msk = Base::Bitutils::get_mask_1bit<Uint16>(grp0);
        pie.regs.ack |= msk;
    }

    void Piectrl::clear_isr_flag(Mid id)
    {
        Piectrl pie;
        pie.regs.ef[id.grp].ifr = pie.regs.ef[id.grp].ifr & ~id.flg;
    }
}
