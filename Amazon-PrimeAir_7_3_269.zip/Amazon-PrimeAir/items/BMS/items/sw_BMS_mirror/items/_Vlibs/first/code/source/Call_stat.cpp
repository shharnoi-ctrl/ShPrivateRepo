#include <Call_stat.h>

namespace Base
{
    Call_stat::Call_stat(Real t_check0) :
        chr(),
        ncalls(0),
        t_check((t_check0 > 0.0F)?t_check0:1.0F),
        calls_sec(0)
    {
        chr.tic();
    }

    bool Call_stat::step()
    {
        Real toc = chr.toc();
        bool res = false;
        if(toc > t_check)
        {
            calls_sec = static_cast<Real>(ncalls)/chr.toc();
            chr.tic();
            ncalls = 0;
            res = true;
        }
        return res;
    }
}
