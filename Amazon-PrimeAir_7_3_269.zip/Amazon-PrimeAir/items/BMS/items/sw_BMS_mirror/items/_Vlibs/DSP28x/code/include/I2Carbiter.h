#ifndef I2CARBITER_H_
#define I2CARBITER_H_

#include <Entypes.h>
#include <i2cif.h>
#include <I2Cdevice.h>
#include <Chrono.h>
#include <Fifospsc.h>
#include <Cptraits.h>

#include <Call_stat.h>
#include <I2Cif.h>
#include <Tiiw_fw.h>

namespace Dsp28335_ent
{
    /// I2C bus arbiter to manage registered I2C devices sharing underlying I2C line.
    class I2Carbiter
    {
    public:
        /// I2C Arbiter constructor.
        /// \wi{7562}
        /// I2Carbiter class shall initialize itself upon construction with provided I2C peripheral driver.
        /// \param[in] i2cif0   Reference to I2C peripheral driver.
        explicit I2Carbiter(Dsp28335_ent::I2Cif& i2cif0);

        /// I2C Arbiter driver.
        /// \wi{16837}
        /// I2Carbiter class shall provide the capability to retrieve its underlying I2C peripheral driver.
        /// \return Reference to I2C peripheral driver (as ::i2cif).
        Dsp28335_ent::I2Cif& get_i2c(); //PRQA S 4211 #const

        /// I2C Arbiter initialize.
        /// \wi{7563}
        /// I2Carbiter class shall provide the capability to initialize its I2C peripheral driver.
        void init();

        /// I2C Arbiter register.
        /// \wi{7564}
        /// I2Carbiter class shall provide the capability to register provided I2C device to operate with.
        /// \param[in] dev  Reference to I2Cdevice to register.
        /// \return True if registered, else return false.
        bool reg(I2Cdevice& dev);

        /// I2C Arbiter poll.
        /// \wi{7565}
        /// I2Carbiter class shall provide the capability to poll its registered I2C devices.
        void step();

    private:
        friend class Tiiw::Tiiw_t;  // TODO: remove when tiiw became removed

        /// I2C device timing handler.
        struct Handler_info
        {
            I2Cdevice* dev;         ///< Pointer to I2C device to operating with.
            Base::Chrono chr;       ///< Time since last operation.
        };

        Dsp28335_ent::I2Cif& i2cif;            ///< Reference to I2C peripheral driver.
        static const Uint16 max_devices = 12;   ///< Maximum I2C devices that an arbiter can handle (shall be <= 32).
        Base::Array<Handler_info> devices;      ///< Array of I2C device timing handler.
        Handler_info* current;                  ///< Current operating I2C device.

        /// I2C Arbiter device poll.
        /// \wi{7566}
        /// I2Carbiter shall be able to poll current operating I2C device.
        void step_dev();

        I2Carbiter(); ///< = delete
        I2Carbiter(const I2Carbiter&); ///< = delete
        I2Carbiter& operator=(const I2Carbiter&); ///< = delete
    };


    inline Dsp28335_ent::I2Cif& I2Carbiter::get_i2c() //PRQA S 4211 #const
    {
        return i2cif;
    }
    inline void I2Carbiter::init()
    {
        i2cif.init();
    }
}
#endif
