#ifndef ATUNARRAY_H_
#define ATUNARRAY_H_

#include <Bitmblock.h>
#include <Lossy_error.h>

namespace Base
{
    /// Abstract tunarray implementation
    /// The Base library shall provide a class to manage and manipulate elements within the Abstract Tunarray.
    class Atunarray
    {
    public:
        /// Abstract Tunable Array Constructor with Templated Array.
        /// \wi{4899}
        /// Atunarray class shall build itself upon construction with the given templated array type used as bit mask.
        /// \param[in] v0 Reference to the templated array used as bit mask.
        template<typename TARRAY>
        explicit Atunarray(TARRAY& v0);

        /// Abstract Tunable Array Constructor with Given Memory Type and Size.
        /// \wi{4898}
        /// Atunarray class shall build itself upon construction with array size and memory type.
        /// \param[in] n0 Array size.
        /// \param[in] memtype Memory type.
        Atunarray(Uint32 n0, Memmgr::Type memtype);

        /// Abstract Tunable Array Element Enabled Setter.
        /// \wi{4900}
        /// Atunarray class shall provide a method to set the enabled state of the element at given index i.
        /// \param[in] i Index of the element.
        /// \param[in] en0 Boolean value indicating whether the element should be enabled.
        void set_enabled(Uint16 i, bool en0);

        /// Abstract Tunable Array Element Checker.
        /// \wi{4901}
        /// Atunarray class shall provide a method to check whether the element at given index is enabled.
        /// \param[in] i Index of the element.
        /// \return  True if the element is enabled at the given index, False otherwise.
        bool is_enabled(Uint16 i)const;

        /// Abstract Tunable Array Clear.
        /// \wi{4902}
        /// Atunarray class shall provide a method to clear all elements in the Atunarray.
        void clear();

        /// Abstract Tunable Array Size Deserializer.
        /// \wi{5920}
        /// Atunarray class shall provide a method to deserialize and retrieve the size serialized.
        /// \param[in] str Lossy_error object where deserialize the size and report an error if needded.
        /// \return    Read size.
        Uint16 cset_size(Lossy_error& str);

        /// Abstract Tunable Array Element Deserializer.
        /// \wi{5919}
        /// Atunarray class shall provide a method to deserialize an element index from given stream of data, set it as enabled and retrieve it.
        /// \param[in] str Lossy_error where deserialize the element index and report an error if needded.
        /// \return    Deserialized index.
        Uint16 cset_element(Lossy_error& str);

        /// Abstract Tunable Array Size Serializer.
        /// \wi{4903}
        /// Atunarray class shall be able to serialize the enabled elements into Atunarray.
        /// \param[in] str Lossy instance where serialize the number of enabled elements.
        /// \return    Number of enabled elements.
        Uint16 cget_size(Lossy& str)const;

        /// Abstract Tunable Array Enabled Element Serializer.
        /// \wi{5918}
        /// Atunarray class shall be able to serialize a given index if it is enabled or search for the next enabled.
        /// \param[in/out] i Index of the element to be serialized and updated.
        /// \param[in] str Lossy instance where serialize the data.
        void cget_element(Uint16& i, Lossy& str)const;

        /// Abstract Tunable Array Find First Disabled.
        /// \wi{13929}
        /// Atunarray class shall provide a method to obtain the index of the first disabled element.
        /// \return Optional element containing the index of the first disable element in the array if there is any,
        /// otherwise the optional shall be disabled.
        Optional<Uint16> find_first_disabled() const;

    private:
        
        Bitmblock mask; ///< Bit memory block used as mask to control enabled elements.

        /// Abstract Tunarray Size Getter for Enabled Elements.
        /// \wi{4904}
        /// Atunarray class shall provide a method to get the size of the Atunarray with only enabled elements.
        /// \return  Size of the Atunarray with only enabled elements.
        Uint16 get_enabled_size()const;

        Atunarray();                                    ///< = delete.
        Atunarray(const Atunarray& orig);               ///< = delete.
        Atunarray& operator=(const Atunarray& orig);    ///< = delete.
    };


    template<typename TARRAY>
    inline Atunarray::Atunarray(TARRAY& v0) : mask(v0)
    {
    }

    inline Atunarray::Atunarray(Uint32 n0, Memmgr::Type memtype) : mask(static_cast<Uint16>(n0),memtype)
    {
    }

    inline void Atunarray::set_enabled(Uint16 i, bool en0)
    {
        /// \alg
        /// <ul>
        /// <li> Check the given index i is within the array bounds by comparing it with the Bitmblock::size for ::mask.  If it is within the range:
        if(i<mask.size())
        {
            /// <ul>
            /// <li> Call Bitmblock::Bitarray0::set for ::mask and set the enabled state of the element at index i.
            mask.set(i,en0);
            /// </ul>
        }
        /// </ul>
    }
    inline bool Atunarray::is_enabled(Uint16 i)const
    {
        /// \alg
        /// <ul>
        /// <li> Check the index i is within the bounds by comparing it with the Bitmblock::size for ::mask 
        /// and call Bitmblock::Bitarray0::get for ::mask to get the element is enabled.
        /// <li> Return True if the element is enabled and within bounds, False otherwise.
        return (i<mask.size()) && mask.get(i);
        /// </ul>
    }

    inline void Atunarray::clear()
    {
        /// \alg
        /// - Call Bitmblock::zeros for ::mask and clear all the elements in the Atunarray, setting them all to 0.
        mask.zeros();
    }

    inline Uint16 Atunarray::cget_size(Lossy& str)const
    {
        /// \alg
        /// <ul>
        /// <li> Call Atunarray::get_enabled_size to compute the number of enabled elements in the Atunarray.
        Uint16 enabled = get_enabled_size();
        /// <li> Call Lossy::put_uint16 for received lossy to store the count of enabled elements in the Lossy object.
         str.put_uint16(enabled);
        /// <li> Return the count of enabled elements.
        return enabled;
        /// </ul>
    }

    inline Optional<Uint16> Atunarray::find_first_disabled() const
    {
        /// \alg
        /// - Call Bitmblock::find_first_disabled for ::mask to return element 
        /// containing the index of the first disable element in the array if there is any.
        return mask.find_first_disabled();
    }

}

#endif

