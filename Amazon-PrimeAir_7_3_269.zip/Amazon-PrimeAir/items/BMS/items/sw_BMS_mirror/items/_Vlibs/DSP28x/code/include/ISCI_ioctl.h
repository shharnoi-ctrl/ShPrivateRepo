#ifndef ISCI_IOCTL_H_
#define ISCI_IOCTL_H_

#include <SCIcfg_fw.h>

namespace Dsp28335_ent
{
    // Interface to abstract the configuration of a SCI port (used by both SCI and SXP classes)
    class ISCI_ioctl
    {
    public:
        virtual void config(const SCIcfg& cfg0) = 0;

    protected:
        ISCI_ioctl();
        virtual ~ISCI_ioctl();

    private:
        ISCI_ioctl(const ISCI_ioctl& orig); ///< = delete
        ISCI_ioctl& operator= (const ISCI_ioctl& copy); ///< = delete
    };

    inline ISCI_ioctl::ISCI_ioctl()
    {
    }

    inline ISCI_ioctl::~ISCI_ioctl() //PRQA S 2635 #default destructor
    {
    }
}

#endif
