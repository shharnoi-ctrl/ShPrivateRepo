#ifndef EWMA0_H_
#define EWMA0_H_

#include <Entypes.h>

namespace Maverick
{

    /// EWMA filter helper functions.
    struct Ewma0
    {
    public:

        /// Main computation.
        /// \wi{16915}
        /// The Ewma0 struct shall implement an static function to calculate and return the filtered input
        /// with the time constant as a parameter.
        /// \pre This method shall be only called with a \a tau greater than zero.
        /// \param[in] tau: time constant [s]
        /// \param[in] dt: time step [s]
        /// \param[in] in: input signal
        /// \param[in] out_prev: previous output of the filtered signal
        /// \return filtered signal.
        static Real compute(Real tau,
                            Real dt,
                            Real in,
                            Real out_prev);

        /// Main computation.
        /// \wi{16916}
        /// The Ewma0 struct shall implement an static function to calculate and return the filtered input
        /// with the filter coefficient as parameter.
        /// \pre This method shall be only called with a \a alpha less or equals to one.
        /// \param[in] alpha: filter coefficient (0,1]
        /// \param[in] in: input signal
        /// \param[in] out_prev: previous output of the filtered signal
        /// \return filtered signal.
        static Real compute(Real alpha,
                            Real in,
                            Real out_prev);

        /// Filter coefficient computation.
        /// \wi{16917}
        /// The Ewma0 struct shall implement an static function to calculate and return the filter
        /// coefficient of the filter with the time constant
        /// \pre This method shall be only called with a \a tau greater than zero.
        /// \param[in] tau: time constant [s]
        /// \param[dt] dt: time step [s]
        /// \return filter coefficient in the range (0,1]
        static Real get_alpha(Real tau, Real dt);

        /// Main computation when goes down.
        /// \wi{16918}
        /// The Ewma0 struct shall implement an static function to calculate and return the filtered input
        /// with the filter coefficient as parameter when the input is decreasing.
        /// \pre This method shall be only called with a \a alpha less or equals to one.
        /// \param[in] alpha: filter coefficient (0,1]
        /// \param[in] in: input signal
        /// \param[in] out_prev: previous output of the filtered signal
        /// \return filtered signal.
        static Real compute_max(Real alpha,
                                Real in,
                                Real out_prev);
    private:

        Ewma0();                             ///< = delete
        Ewma0(const Ewma0& orig);            ///< = delete
        Ewma0& operator=(const Ewma0& orig); ///< = delete
    };


    inline Real Ewma0::get_alpha(Real tau, Real dt)
    {
        /// \alg
        /// - Coefficient shall be dt / (tau + dt)
        return dt/(tau+dt);
    }

    inline Real Ewma0::compute_max(Real alpha,
                                   Real in,
                                   Real out_prev)
    {
        /// \alg
        /// IF in <= out_prev calculate filter with compute(Real, Real, Real), ELSE return the
        /// same input
        return (in>out_prev) ? in : Ewma0::compute(alpha, in, out_prev);
    }

    inline Real Ewma0::compute(Real tau,
                               Real dt,
                               Real in,
                               Real out_prev)
    {
        /// \alg
        /// - Calculate alpha with ::get_alpha and calculate filter with compute(Real, Real, Real)
        return compute(get_alpha(tau, dt), in, out_prev);
    }

    inline Real Ewma0::compute(Real alpha,
                               Real in,
                               Real out_prev)
    {
        /// \alg
        /// - Filter output shall be (\a out_prev + \a alpha * (\a in - \a out_prev))
        return out_prev + alpha*(in-out_prev);
    }

}

#endif
