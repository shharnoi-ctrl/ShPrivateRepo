#ifndef DEFAULT_ISR_H_
#define DEFAULT_ISR_H_

namespace Dsp28335_ent
{
    /// Default Interrupt service routine class declaration.
    /// This function is the default function used to initialize Interrupts in the system.
    struct Default_isr
    {
    public:
        interrupt
        static void isr();
    private:
        Default_isr(); ///< = delete
        Default_isr(const Default_isr& orig); ///< = delete
        Default_isr& operator=(const Default_isr& orig); ///< = delete
    };
}
#endif
