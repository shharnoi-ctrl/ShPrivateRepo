#ifndef RANGE_H_
#define RANGE_H_

#include <Assertions.h>
#include <Entypes.h>
#include <Vtraits.h>

namespace Base
{
    /// Range of values abstraction.
    /// T shall be able to be compared (<=, >=), be added and subtracted (+, -)
    template<typename T, T vmin, T vmax>
    class Range
    {
    public:
        typedef T type; ///< Type for external usage

        static const int32 idx_not_found = -1;          ///< Index returned by get_idx() if not found
        static const int32 size = (vmax - vmin + 1);    ///< Actual size of the range

        /// Low value shall only be checked on signed ranges or if min is not zero for unsigned types.
        static const bool needs_low_check = Is_signed<T>::value || (vmin!=0);

        /// Returns true i v is in the [vmin, vmax] range
        template <typename TT = T>
        static bool in_range(typename Enable_if<needs_low_check, TT>::type v)
        {
            Assertions::Compile_time<(vmin <= vmax)>();
            return (vmin <= v) && (v <= vmax);
        }

        /// Returns true i v is in the [0, vmax] range.
        /// Only implemented when T is unsigned and vmin==0
        template <typename TT = T>
        static bool in_range(typename Enable_if<!needs_low_check, TT>::type v)
        {
            Assertions::Compile_time<(vmin <= vmax)>();
            return (v <= vmax);
        }
        
        /// Returns the index of v if in range or idx_not_found if not in range
        static inline int32 get_idx(T v)
        {
            return in_range(v) ? (v-vmin) : idx_not_found;
        }
    private:
        Range(); ///< = delete
        Range(const Range&); ///< = delete
        Range operator=(const Range&); ///< = delete
    };
}
#endif
