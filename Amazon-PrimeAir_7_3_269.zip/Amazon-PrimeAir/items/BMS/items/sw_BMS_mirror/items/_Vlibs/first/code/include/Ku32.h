#ifndef KU32_H_
#define KU32_H_

#include <Entypes.h>

namespace Ku32
{
    static const Uint32 u0=               static_cast<Uint32>(0);
    static const Uint32 u1=               static_cast<Uint32>(1);
    static const Uint32 u2=               static_cast<Uint32>(2);
    static const Uint32 u3=               static_cast<Uint32>(3);
    static const Uint32 u4=               static_cast<Uint32>(4);
    static const Uint32 u5=               static_cast<Uint32>(5);
    static const Uint32 u6=               static_cast<Uint32>(6);
    static const Uint32 u7=               static_cast<Uint32>(7);
    static const Uint32 u8=               static_cast<Uint32>(8);
    static const Uint32 u9=               static_cast<Uint32>(9);
    static const Uint32 u10=              static_cast<Uint32>(10);
    static const Uint32 u11=              static_cast<Uint32>(11);
    static const Uint32 u12=              static_cast<Uint32>(12);
    static const Uint32 u13=              static_cast<Uint32>(13);
    static const Uint32 u14=              static_cast<Uint32>(14);
    static const Uint32 u15=              static_cast<Uint32>(15);
    static const Uint32 u16=              static_cast<Uint32>(16);
    static const Uint32 u17=              static_cast<Uint32>(17);
    static const Uint32 u18=              static_cast<Uint32>(18);
    static const Uint32 u20=              static_cast<Uint32>(20);
    static const Uint32 u21=              static_cast<Uint32>(21);
    static const Uint32 u24=              static_cast<Uint32>(24);
    static const Uint32 u28=              static_cast<Uint32>(28);
    static const Uint32 u32=              static_cast<Uint32>(32);
    static const Uint32 u100=             static_cast<Uint32>(100);
    static const Uint32 u200=             static_cast<Uint32>(200);
    static const Uint32 u256=             static_cast<Uint32>(256);
    static const Uint32 u512=             static_cast<Uint32>(512);
    static const Uint32 u1000=            static_cast<Uint32>(1000);
    static const Uint32 u1024=            static_cast<Uint32>(1024);

    /// Number of milliseconds in a week
    static const Uint32 week_ms=          static_cast<Uint32>(604800000U);

    static const Uint32 u0xF=             static_cast<Uint32>(0xF);
    static const Uint32 u0xFF=            static_cast<Uint32>(0xFF);
    static const Uint32 u0x100=           static_cast<Uint32>(0x100);
    static const Uint32 u0x110=           static_cast<Uint32>(0x110);
    static const Uint32 u0x3F=            static_cast<Uint32>(0x3F);
    static const Uint32 u0xFFFF=          static_cast<Uint32>(0xFFFF);
    static const Uint32 u0x0000FFFF=      static_cast<Uint32>(0x0000FFFF);
    static const Uint32 u0xFFFF0000=      static_cast<Uint32>(0xFFFF0000);
    static const Uint32 u0xFF000000=      static_cast<Uint32>(0xFF000000);
    static const Uint32 u0xFFFFFFFF=      static_cast<Uint32>(0xFFFFFFFF);
    static const Uint32 u_max=            static_cast<Uint32>(0xFFFFFFFF);
}

#endif
