#include <SCI.h>
#include <Const.h>
#include <PDIcheck.h>
#include <SCIcfg.h>

#include "SCI_regs.h" //PRQA S 1015

namespace Dsp28335_ent
{
    static const Uint16 fifo_sz = 16; ///< Size of the peripheral FIFO

    SCI::SCI(Id id0) :
            id(id0),
            regs(get_regs(id)),
            tx_count(0),
            rx_count(0),
            rx_ok(true)
    {
        regs.SCIFFRX.bit.RXFFIL = fifo_sz-1;
        regs.SCIFFRX.bit.RXFFIENA = 0;

        regs.SCIFFTX.bit.TXFFIL = 0;
        regs.SCIFFTX.bit.TXFFIENA = 0; // enabled dynamically in case tx isr used

    }

    void SCI::config(const SCIcfg& cfg)
    {
        using namespace Ku16;
        if(cfg.validate())
        {
            // Reset Sci and rx fifo
            regs.SCICTL1.bit.SWRESET=0;
            regs.SCIFFTX.bit.TXFIFORESET=0;
            regs.SCIFFRX.bit.RXFIFORESET=0;
            // No parity,8 char bits,
            // async mode, idle-line protocol
            //SCCIR format: [2:0] character length (one to eight bits), 3 address enable (1)
            //              4 loop back enable, 5 parity enable, 6 parity even (1) or odd (0),
            //              7 stop bits: two (1) or one (0)
            regs.SCICCR.bit.ADDRIDLE_MODE=cfg.use_addr_mode;
            regs.SCICCR.bit.LOOPBKENA=0;

            if(cfg.parity==SCIcfg::par_dis)
            {
                regs.SCICCR.bit.PARITY=0;
                regs.SCICCR.bit.PARITYENA=0;
            }
            else
            {
                regs.SCICCR.bit.PARITYENA=1;
                regs.SCICCR.bit.PARITY=(cfg.parity==SCIcfg::par_even)?1:0;
            }

            if(cfg.stop==SCIcfg::stp_2)
            {
                regs.SCICCR.bit.STOPBITS=1;
            }
            else
            {
                regs.SCICCR.bit.STOPBITS=0;
            }

            switch(cfg.length)
            {
                case SCIcfg::len_4:
                {
                    regs.SCICCR.bit.SCICHAR=u3;
                    break;
                }
                case SCIcfg::len_5:
                {
                    regs.SCICCR.bit.SCICHAR=u4;
                    break;
                }
                case SCIcfg::len_6:
                {
                    regs.SCICCR.bit.SCICHAR=u5;
                    break;
                }
                case SCIcfg::len_7:
                {
                    regs.SCICCR.bit.SCICHAR=u6;
                    break;
                }
                case SCIcfg::len_8:
                {
                    regs.SCICCR.bit.SCICHAR=u7;
                    break;
                }
                default:
                {
                    regs.SCICCR.bit.SCICHAR=u7;
                    break;
                }
            }

            regs.SCICTL1.all = 0;
            // Activate TX-side
            regs.SCICTL1.bit.TXENA = Ku16::u1;
            // Activate RX-side with error
            regs.SCICTL1.bit.RXENA = Ku16::u1;
            regs.SCICTL1.bit.RXERRINTENA = Ku16::u1;
            // Onto CTL1 register, disable TXWAKE/SLEEP and keep SW_RESET to low

            // BRR = LSPCLK / (SCI Asynchronous Baud * 8) - 1
            // (-0.5) has been used instead of (-1) to round result to nearest value
            const Uint16 brr = static_cast<Uint16>((Bsp::Kclk::get_lspclkfreq()/(Const::EIGHT*cfg.speed)) -
                                                   Const::ONEHALF);
            regs.SCIHBAUD.all = brr>>u8;
            regs.SCILBAUD.all = brr&u0xFF;

            regs.SCIFFCT.all=0x00;

            regs.SCICTL1.bit.SWRESET=1;        // Relinquish SCI from Reset
            regs.SCIFFTX.bit.SCIFFENA=1;       // Enhanced features enabled
            regs.SCIFFTX.bit.TXFIFORESET=1;
            regs.SCIFFRX.bit.RXFIFORESET=1;
        }
        else
        {
            Base::Error err0;
            err0.failed(Base::err_sci_cfg);
            Base::PDIcheck::commit(err0);
        }
    }

    bool SCI::read(Uint8& data)
    {
        bool result = (regs.SCIFFRX.bit.RXFFST>0);
        if(result)
        {
            data = regs.SCIRXBUF.all & Ku16::u0xFF;
            rx_count++;
        }
        return result;
    }

    bool SCI::write(Uint8 data)
    {
        bool result = wr_available();
        if(result)
        {
            regs.SCITXBUF.bit.TXDT=data;
            tx_count++;
        }
        return result;
    }

    bool SCI::wr_available() const
    {
        return regs.SCIFFTX.bit.TXFFST<fifo_sz;
    }

    bool SCI::tx_pending() const
    {
        return !((regs.SCIFFTX.bit.TXFFST==0) && regs.SCICTL2.bit.TXEMPTY);
    }

    bool SCI::tx_fifo_pending() const
    {
        return regs.SCIFFTX.bit.TXFFST!=0;
    }

    void SCI::step()
    {
        if(regs.SCIRXST.bit.RXERROR && (regs.SCIRXST.bit.BRKDT || regs.SCIRXST.bit.FE))
        {
            if(regs.SCICTL1.bit.RXENA)
            {
                rx_ok = false;                  // Will set dedicated Bvar to false to signal Rx_error
                regs.SCICTL1.bit.SWRESET=0;     // Reset Sci
                regs.SCIFFRX.bit.RXFIFORESET=0; // Reset rx fifo
                regs.SCICTL1.bit.SWRESET=1;     // Re-enable Sci
                regs.SCIFFRX.bit.RXFIFORESET=1; // Re-enable rx fifo
            }
        }
    }

    Uint32 SCI::get_tx_count()    ///< Returns tx count and reset that count
    {
        Uint32 res = tx_count;
        tx_count = 0;
        return res;
    }

    Uint32 SCI::get_rx_count()    ///< Returns rx count and reset that count
    {
        Uint32 res = rx_count;
        rx_count = 0;
        return res;
    }

    bool SCI::is_rx_ok()
    {
        bool res = rx_ok;
        rx_ok = true;
        return res;
    }

    void SCI::enable_tx(bool en)
    {
        regs.SCICTL1.bit.TXENA = en;    // Enable TX
    }

    void SCI::enable_rx(bool en)
    {
        regs.SCICTL1.bit.RXENA = en;        // Enable RX
    }

    // NOTE: Only checked for 28335 SCI peripheral
    Uint8 SCI::compute_n_bits() const
    {
        Uint8 res = 1; // 1 start
        res += regs.SCICCR.bit.SCICHAR + 1;     // Length. 4 to 8 bits.
        res += regs.SCICCR.bit.ADDRIDLE_MODE;   // Address mode
        res += regs.SCICCR.bit.PARITYENA;       // 1 if parity enabled
        res += regs.SCICCR.bit.STOPBITS+1;      // Stop bits (1 or 2)
        return res;
    }

    // NOTE: Only checked for 28335 SCI peripheral
    Uint32 SCI::get_speed() const
    {
        // SCI Asynchronous Baud = (LSPCLK/(BRR + 1))/8
        Uint16 brr = regs.SCIHBAUD.all;
        brr <<= Ku16::u8;
        brr |= regs.SCILBAUD.all;
        Uint32 res = Bsp::Kclk::get_lspclkfreq32()/((brr+1)*Ku32::u8);
        return res;
    }
}
