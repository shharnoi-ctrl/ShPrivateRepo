#ifndef TIMER_REGS_H_H
#define TIMER_REGS_H_H

#include <Timer.h>

namespace Dsp28335_ent
{
    // CPUTIMER Individual Register Bit Definitions
    struct T32half
    {
        Uint16 LSW : 16;                      ///< 15:0 least significant word
        Uint16 MSW : 16;                      ///< 31:16 most significant word
    };

    /// PERIOD, PRDH: Period register definitions
    union Tim_reg
    {
        Uint32 all;
        T32half bit;
    };

    union Prd_reg
    {
        Uint32 all;
        T32half bit;
    };

    /// TCR: Control register bit definitions
    struct Tcr_bits
    {
        Uint16 rsvd1 : 4;                     ///< 3:0 Reserved
        Uint16 TSS : 1;                       ///< 4 CPU-Timer stop status bit.
        Uint16 TRB : 1;                       ///< 5 Timer reload
        Uint16 rsvd2 : 4;                     ///< 9:6 Reserved
        Uint16 SOFT : 1;                      ///< 10 Emulation modes
        Uint16 FREE : 1;                      ///< 11 Emulation modes
        Uint16 rsvd3 : 2;                     ///< 13:12 Reserved
        Uint16 TIE : 1;                       ///< 14 CPU-Timer Interrupt Enable.
        Uint16 TIF : 1;                       ///< 15 CPU-Timer Interrupt Flag.
    };

    union Tcr_reg
    {
        Uint16 all;
        Tcr_bits bit;
    };

    /// TPR: Pre-scale low bit definitions
    struct Tpr_bits
    {
        Uint16 TDDR : 8;                      ///< 7:0 CPU-Timer Divide-Down.
        Uint16 PSC : 8;                       ///< 15:8 CPU-Timer Prescale Counter.
    };

    union Tpr_reg
    {
        Uint16 all;
        Tpr_bits bit;
    };

    /// TPRH: Pre-scale high bit definitions
    struct Tprh_bits
    {
        Uint16 TDDRH : 8;                     ///< 7:0 CPU-Timer Divide-Down.
        Uint16 PSCH : 8;                      ///< 15:8 CPU-Timer Prescale Counter.
    };

    union Tprh_reg
    {
        Uint16 all;
        Tprh_bits bit;
    };

    /// CPU Timer Registers
    struct Timer::Cputimer_regs
    {
        Tim_reg     TIM;                    ///< CPU-Timer, Counter Register
        Prd_reg     PERIOD;                 ///< CPU-Timer, Period Register
        Tcr_reg     TCR;                    ///< CPU-Timer, Control Register
        Uint16      rsvd1;                  ///< Reserved
        Tpr_reg     TPR;                    ///< CPU-Timer, Prescale Register
        Tprh_reg    TPRH;                   ///< CPU-Timer, Prescale Register High
    };
}
#endif
