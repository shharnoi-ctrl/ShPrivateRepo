#ifndef ARRAY_H__
#define ARRAY_H__

#include <Iiterator.h>
#include <Iterator.h>
#include <string.h>    // for memmove()
#include <Memmgr.h>
#include <Rfun.h>
#include <Ttraits.h>
#include <Suiteref.h>
#include <Mblock.h>
#include <Memmgr.h>
#include <Ref_wrapper.h>

namespace Base
{
    // NOTE: In constructors, n0 cannot be 0 as it will cause to vz be equal to v-1 and some loops will access out of
    // boundaries.
    /// Variable-Size Array.
    template <class T>
    class Array
    {
    public:
        // Build with external buffer.
        // T2 is checked to have same size as T, and following assign must be legal: Array<T>::v = mb.v
        // (with Array<T>::v of type T* and mb.v of type T2*).
        // This constuctor form allows building when T is const and T2 is not const
        /// Variable-Size Array Constructor with Memory Block.
        /// \wi{6692}
        /// Array class shall build itself upon construction with a given memory block.
        /// \param[in] Memory block (Mblock) used to build the Array.
        template <class T2>
        explicit Array(Mblock<T2> mb);
        /// Variable-Size Array Constructor with External Buffer.
        /// \wi{6693}
        /// Array class shall build itself upon construction with a given pointer and size allocated externally.
        /// \param[in] v0 Pointer to first Array element.
        /// \param[in[ n0 Number of elements.
        Array(T* v0, Uint32 n0);
        /// Variable-Size Array Constructor and Allocator.
        /// \wi{16913}
        /// Array class shall build and allocate itself upon construction with a given size and a memory allocation
        /// type.
        /// \param[in] n0 Array size.
        /// \param[in] memtype Memory type.
        Array(Uint32 n0, Memmgr::Type memtype);
        /// Variable-Size Array Constructor and Allocator.
        /// \wi{16919}
        /// Array class shall build and allocate itself upon construction with a given size and memory allocator.
        /// \param[in] n0 Array size.
        /// \param[in] alloc Memory allocator.
        Array(Uint32 n0, Allocator& alloc);
        /// Variable-Size Array Constructor with Different Argument Values.
        /// \wi{16920}
        /// Array class shall build and allocate itself upon construction with a given size and memory allocation type
        /// and with a different argument values for each element.
        /// \param[in] n0 Array size.
        /// \param[in] memtype Memory type.
        /// \param[in] param Argument values to build each Array element.
        template <class T2>
        Array(Uint32 n0,
              Memmgr::Type memtype,
              Base::Rngit<T2> param);
        /// Variable-Size Array Constructor with Different Argument Values.
        /// \wi{16921}
        /// Array class shall build and allocate itself upon construction with a given size and memory allocation type
        /// and with a different argument values for each element.
        /// \param[in] n0 Array size.
        /// \param[in] memtype Memory type.
        /// \param[in] it Argument values to build each Array element represented as an Iterator.
        template <class T2>
        Array(Uint32 n0,
              Memmgr::Type memtype,
              Base::Iiterator<T2>& it);
        /// Variable-Size Array Constructor with Different Argument Values.
        /// \wi{16924}
        /// Array class shall build and allocate itself upon construction with a given size and memory allocation type
        /// and with different argument values for each element.
        /// \param[in] n0 Array size.
        /// \param[in] memtype Memory type.
        /// \param[in] param Argument values to build each Array element represented as a constant Array.
        template <class T2>
        Array(Uint32 n0,
              Memmgr::Type memtype,
              const Base::Array<T2>& param);
        /// Variable-Size Array Constructor with Different Argument Values.
        /// \wi{16925}
        /// Array class shall build and allocate itself upon construction with a given size and memory allocation type
        /// and with different argument values for each element.
        /// \param[in] n0 Array size.
        /// \param[in] memtype Memory type.
        /// \param[in] param Argument values to build each Array element represented as an Array.
        template <class T2>
        Array(Uint32 n0,
              Memmgr::Type memtype,
              Base::Array<T2>& param);
        /// Variable-Size Array Constructor with Different Argument Values.
        /// \wi{16926}
        /// Array class shall build and allocate itself upon construction with a given size and memory allocation type
        /// and with different argument values for each element.
        /// \param[in] n0 Array size.
        /// \param[in] memtype Memory type.
        /// \param[in] param Argument value to build each Array element represented as a Mblock.
        template <typename T2>
        Array(Uint32 n0,
              Memmgr::Type memtype,
              Mblock<T2> param);

        /// Variable-Size array constructor with allocator and different argument values.
        /// \wi{19155}
        /// Array class shall build and allocate itself upon construction with a given size and allocator
        /// and with different argument values for each element.
        /// \param[in] n0 Array size.
        /// \param[in] alloc Allocator to use.
        /// \param[in] param Argument value to build each Array element represented as a Mblock.
        template <typename T2>
        Array(Uint32 n0,
              Base::Allocator& alloc,
              Mblock<T2> param);

        /// Variable-Size Array Constructor with known Compile-time Size and Different Argument Values.
        /// \wi{16927}
        /// Array class shall build and allocate itself upon construction with given memory allocation type and with
        /// different argument values for each element.
        /// \param[in] memtype Memory Type.
        /// \param[in] param Argument value to build each Array element represented as a Suiteref.
        template <class T2, Uint16 n>
        Array(Memmgr::Type memtype,
              const Base::Suiteref<T2,n>& param);

        /// Variable-Size Array Constructor with One Fixed Argument.
        /// \wi{16928}
        /// Array class shall build and allocate itself upon construction with a given size and memory allocation type
        /// and with same argument value for all elements.
        /// \param[in] n0 Array size.
        /// \param[in] memtype Memory type.
        /// \param[in] param Argument used to build all Array elements.
        template <class T2>
        Array(Uint32 n0,
              Memmgr::Type memtype,
              T2 param);

        /// Variable-Size Array Constructor with One Fixed Argument of Type Ref_wrapper.
        /// \wi{21088}
        /// Array class shall build and allocate itself upon construction with a given size and memory allocation type
        /// and with the same argument reference for all elements.
        /// \param[in] n0 Array size.
        /// \param[in] memtype Memory type.
        /// \param[in] param Argument used to build all Array elements.
        template <class T2>
        Array(Uint32 n0,
              Memmgr::Type memtype,
              Ref_wrapper<T2> param);

        /// Variable-Size Array Constructor with Two Fixed Arguments.
        /// \wi{16929}
        /// Array class shall build and allocate itself upon construction with a given size and memory allocation type
        /// and with same two argument values for all elements.
        /// \param[in] n0 Array size.
        /// \param[in] memtype Memory type.
        /// \param[in] param0 First argument used to build all Array elements.
        /// \param[in] param1 Second argument used to build all Array elements.
        template <class T2, class T3>
        Array(Uint32 n0,
              Memmgr::Type memtype,
              T2 param0,
              T3 param1);
        /// Variable-Size Array Constructor with One Fixed Argument and a Block of Different Arguments.
        /// \wi{16930}
        /// Array class shall build and allocate itself upon construction with a given size and memory allocation type
        /// and with one fixed argument value of all elements and a block of arguments for each element.
        /// \param[in] n0 Array size.
        /// \param[in] memtype Memory type.
        /// \param[in] param0 Fixed argument used to build all Array elements.
        /// \param[in] param1 Block of argument used to build each Array element.
        template <class T2, class T3>
        Array(Uint32 n0,
              Memmgr::Type memtype,
              T2 param0,
              Mblock<T3> param1);
        /// Variable-Size Array Constructor with Three Fixed Arguments.
        /// \wi{16931}
        /// Array class shall build and allocate itself upon construction with a given size and memory allocation type
        /// and with three argument values for all elements.
        /// \param[in] n0 Array size.
        /// \param[in] memtype Memory type.
        /// \param[in] param0 First argument used to build all Array elements.
        /// \param[in] param1 Second argument used to build all Array elements.
        /// \param[in] param2 Third argument used to build all Array elements.
        template <class T2, class T3, class T4>
        Array(Uint32 n0,
              Memmgr::Type memtype,
              T2 param0,
              T3 param1,
              T4 param2);

        /// Variable-Size Array Constructor from another Array.
        /// \wi{16932}
        /// Array class shall build itself upon construction subtracting it from another Array.
        /// \param[in] src Source Array.
        /// \param[in] idx0 Index which will be consider the first element of the new Array.
        Array(Array<T>& src, Uint32 idx0);
        /// Variable-Size Array Constructor from another Array.
        /// \wi{16933}
        /// Array class shall build itself upon construction subtracting it from another Array and with a given size.
        /// \param[in] src Source Array.
        /// \param[in] idx0 Index which will be consider the first element of the new Array.
        /// \param[in] n0 Desired new size.
        /// \pre Desired size should be lower than source array size minus received index, if not, desired size will
        /// be ignored.
        Array(Array<T>& src,
              Uint32 idx0,
              Uint32 n0);

        typedef Base::Iterator<T> Iterator; ///< Iterator type with Base (T) type.

        /// Iterator Retriever.
        /// \wi{5379}
        /// Array class shall be able to retrieve a Iterator over all its elements.
        /// \return Iterator over Array contained elements.
        inline Iterator get_iterator() const
        {
            return Iterator(v, vz);
        }
        /// Iterator Over Given Range Retriever.
        /// \wi{5378}
        /// Array class shall be able to retrieve a Iterator over a given Range.
        /// \param[in] from First element of Iterator.
        /// \param[in] sz Size of Iterator.
        /// \return Iterator of given range.
        /// \pre A valid range is assumed.
        inline Iterator get_iterator_rng(Uint32 from, Uint32 sz) const
        {
            return Iterator(&v[from], &v[from+sz-1]);
        }

        /// Variable-Size Array Reset.
        /// \wi{6633}
        /// Array class shall be able to initialize its internal attributes to given ones.
        /// \param[in] v0 New pointer to first element.
        /// \param[in] n0 New size of array.
        void init(T* v0, Uint32 n0);

        /// Variable-Size Array Resize.
        /// \wi{4923}
        /// Array class shall provide the capability to be resized.
        /// \param[in] n0 New Size.
        /// \return True if resize has been successful, False if not.
        bool resize(Uint32 n0);

        /// Variable-Size Array Copy from another Array.
        /// \wi{4924}
        /// Array class shall be able to copy an instance of the class to another one.
        /// \param[in] v0 Instance to be copied.
        void copy(const Array<T>& v0);
        /// Variable-Size Array Copy from Pointer.
        /// \wi{16948}
        /// Array class shall be able to copy the received pointer data into and Array instance assuming same sizes.
        /// \param[in] v0 Pointer to first element to be copied.
        void copy(const T* v0);
        // Tc is T with optional constant qualifier
        /// Variable-Size Memory Block Copy.
        /// \wi{4925}
        /// Array class shall be able to copy an Mblock<T> instance to an Array instance.
        /// \param[in] mb Memory block to be copied.
        template<typename Tc>
        void copy(const Mblock<Tc>& mb);

        /// Memory Block Provider.
        /// \wi{4926}
        /// Array class shall be able to retrieve its data as a Memory Block.
        /// \return Array data as Mblock<T> data structure.
        Mblock<T> to_mblock();
        /// Constant Memory Block Provider.
        /// \wi{16949}
        /// Array class shall be able to retrieve its data as a Memory Block of constant data.
        /// \return Array data as a Mblock<const T> data structure.
        Mblock<const T> to_mblock() const;
        /// Volatile Memory Block Provider.
        /// \wi{16950}
        /// Array class shall be able to retrieve its data as a Memory Block of volatile data.
        /// \return Array data as a Mblock<volatile T> data structure.
        Mblock<volatile T> to_mblock() volatile;
        /// Constant Volatile Memory Block Provider.
        /// \wi{16951}
        /// Array class shall be able to retrieve its data as a Memory Block of constant volatile data.
        /// \return Array data as a Mblock<const volatile T> data structure.
        Mblock<const volatile T> to_mblock() const volatile;

        /// Element Getter.
        /// \wi{16952}
        /// Array class shall be able to retrieve to any element of an Array instance.
        /// \param[in] i Index element to be retrieved.
        /// \return Element value.
        T& get(Uint32 i);

        /// Element Individual Access.
        /// \wi{4927}
        /// Array class shall be able to access to any element of an Array instance.
        /// \param[in] i Array index to be accessed.
        /// \return Element requested.
        /// \pre Assumes requesting index is not out of range.
        T& operator[](Uint32 i);
        /// Element Individual Constant Access.
        /// \wi{16953}
        /// Array class shall be able to access as constant value to any element of an Array instance.
        /// \param[in] i Array index to be accessed.
        /// \return Element requested.
        /// \pre Assumes requesting index is not out of range.
        const T& operator[](Uint32 i)const;
        /// Element Individual Volatile Access.
        /// \wi{16954}
        /// Array class shall be able to access as a volatile value to any element of an Array instance.
        /// \param[in] i Array index to be accessed.
        /// \return Element requested.
        /// \pre Assumes requesting index is not out of range.
        volatile T& operator[](Uint32 i) volatile;
        /// Element Individual Constant Volatile Access.
        /// \wi{16955}
        /// Array class shall be able to access as a constant volatile value to any element of an Array instance.
        /// \param[in] i Array index to be accessed.
        /// \return Element requested.
        /// \pre Assumes requesting index is not out of range.
        const volatile T& operator[](Uint32 i)const volatile;

        /// First Element Access.
        /// \wi{4928}
        /// Array class shall be able to access to the first element of an Array instance.
        /// \return Pointer to the first Array element.
        T* first();
        /// First Element Constant Access.
        /// \wi{16956}
        /// Array class shall be able to access to the first element of an Array instance as constant.
        /// \return Pointer to the first Array element as constant.
        const T* first() const;
        /// First Element Volatile Access.
        /// \wi{16957}
        /// Array class shall be able to access to the first element of an Array instance as volatile.
        /// \return Pointer to the first Array element as volatile.
        volatile T* first() volatile;
        /// First Element Constant Volatile Access.
        /// \wi{16958}
        /// Array class shall be able to access to the first element of an Array instance as constant volatile.
        /// \return Pointer to the first Array element as constant volatile.
        const volatile T* first() const volatile;

        /// Last Element Access.
        /// \wi{4929}
        /// Array class shall be able to access to the last element of an Array instance.
        /// \return Pointer to the last Array element.
        T* last();
        /// Last Element Constant Access.
        /// \wi{16959}
        /// Array class shall be able to access to the las element of an Array instance as constant.
        /// \return Pointer to the last Array element as constant.
        const T* last() const;
        /// Last Element Volatile Access.
        /// \wi{16960}
        /// Array class shall be able to access to the las element of an Array instance as volatile.
        /// \return Pointer to the last Array element as volatile.
        volatile T* last() volatile;
        /// Last Element Constant Volatile Access.
        /// \wi{16961}
        /// Array class shall be able to access to the las element of an Array instance as constant volatile.
        /// \return Pointer to the last Array element as constant volatile.
        const volatile T* last() const volatile;

        /// Variable-Size Array Reset.
        /// \wi{4930}
        /// Array class shall be able to set all its elements to 0.
        void zeros();
        /// Variable-Size Array Assembling.
        /// \wi{4931}
        /// Array class shall be able to assemble an Array to another one.
        /// \param[in] k Destination position where assemble the array.
        /// \param[in] v0 Array to be assembled.
        void assemble(Uint32 k, const Array<T>& v0);
        /// Value Contained Request.
        /// \wi{4932}
        /// Array class shall be able to determine if given value is assigned to any of the elements contained into
        /// an array instance.
        /// \param[in] value Value to be compared with Array elements.
        /// \return True if the comparison between any Array element and received value has retrieved True, False if
        /// not.
        bool has(const T& value) const;

        /// Function Applier.
        /// \wi{4933}
        /// Array class shall be able to call a given function with each array element as argument.
        /// \param[in] f Function to be applied.
        template <typename TFUNC>
        void apply_all(TFUNC f) const;

        /// All Elements Setting.
        /// \wi{6691}
        /// Array class shall be able to set all the elements in an Array to a specific value.
        /// \param[in] u Value to be set.
        void set_all(const T u);

        /// Element Index Retriever Comparing the Content.
        /// \wi{6695}
        /// When requested, Array class shall retrieve the index of a given element value or -1 if the received value
        /// is not present into the Array.
        /// \param[in] value Element value to be found.
        /// \return Index of element if its value has been found, -1 if not found.
        /// \pre Operator "==" in T type shall be implemented. An element will be consider equals than another one if
        /// its "==" comparison return true.
        int32 get_index_of(const T& value) const;
        /// Element Index Retriever Comparing the Element.
        /// \wi{6696}
        /// When requested, Array class shall retrieve the index of a given element or -1 if this element does not
        /// exist into the Array.
        /// \param[in] elem Element to be found.
        /// \return Index of element if it has been found, -1 if not found.
        int32 get_index_of_element(const T* elem) const;

        /// Variable-Size Array Insertion Discarding Last Element.
        /// \wi{6690}
        /// Array class shall be able to insert an element in a specified position and discard the last element and
        /// shifting elements to the end.
        /// \param[in] idx Index where insert the new element.
        /// \param[in] value Value to be inserted.
        void insert_s2e(Uint32 idx,T value);
        /// Variable-Size Array Insertion Discarding First Element.
        /// \wi{6689}
        /// Array class shall be able to insert an element in a specified position and discard the first element and
        /// shifting one position from start.
        /// \param[in] idx Index where insert the new element.
        /// \param[in] value Value to be inserted.
        void insert_e2s(Uint32 idx, T value);

        /// Element Removal.
        /// \wi{4934}
        /// Array class shall be able to remove the element with given index shifting element from end to received
        /// index and resizing the array.
        /// \param[in] idx Element to be removed.
        void remove(Uint32 idx);
        /// Variable-Size Array Sum.
        /// \wi{4935}
        /// Array class shall be able to sum all the elements contained into an array instance.
        /// \return The sum of all elements.
        /// \pre Operator "+" in T type shall be implemented.
        T sum_all() const;

        /// Variable-Size Array Element Addition.
        /// \wi{6687}
        /// Array class shall be able to append an element and increment its internal size by one.
        /// \param[in] value Element value to be appended.
        /// \return True if addition has been successful, False if not.
        bool append(const T& value);

        // Tc is T with optional constant qualifier
        /// Variable-Size Array Block Addition.
        /// \wi{6688}
        /// Array class shall be able to append a block of elements and increment its internal size by memory block
        /// size.
        /// \param[in] mb Memory block to be appended.
        template<typename Tc>
        void append(const Mblock<Tc>& mb);

        /// Array In Ascending Order.
        /// \wi{4937}
        /// Array class shall be able to determine if all contained elements in an Array are sorted in ascending order.
        /// \return True if all elements are sorted in ascending order (repeated elements are permitted).
        /// \pre Operator "<" in T type shall be implemented.
        bool is_non_descending() const;
        /// Array In Descending Order.
        /// \wi{4936}
        /// Array class shall be able to determine if all contained elements in an Array are sorted in descending
        /// order.
        /// \return True if all the elements are sorted in descending oder (repeated elements are permitted), False if
        /// not.
        /// \pre Operator ">" in T type shall be implemented.
        bool is_non_ascending() const;

        /// Variable-Size Array Size Retriever.
        /// \wi{4938}
        /// When requested, Array class shall provide the number of contained elements.
        /// \return Retrieves ::n value.
        Uint32 size() const;
        /// Variable-Size Array Maximum Size Retriever.
        /// \wi{4939}
        /// When requested, Array class shall provide the maximum number of allowed elements.
        /// \return Retrieves ::num_max value.
        Uint32 size_max() const;
        /// Variable-Size Array Unused Size Retriever.
        /// \wi{4940}
        /// When requested, Array class shall provide the number of unused positions.
        /// \return Retrieves ::num_max - ::n computed value.
        Uint32 size_unused() const;

    protected:
        Uint32 n;       ///< Current array length. Maximum vector size 2^16-1, matrix 255x255.
        Uint32 num_max; ///< Maximum array length.
        T* v;           ///< Pointer to first element.
        T* vz;          ///< Pointer to last element.

    private:
        Array();                                ///< = delete
        Array(const Array& copy);               ///< = delete
        Array& operator= (const Array& copy);   ///< = delete
    };

    template <class T>
    template <class T2>
    inline Array<T>::Array(Mblock<T2> mb) : n(mb.sz),num_max(mb.sz),v(mb.v),vz((v+n)-1U)
    {
        Assertions::Compile_time<sizeof(T2)==sizeof(T)>();
    }

    template <typename T>
    inline Array<T>::Array(T* v0, Uint32 n0):
        n(n0),
        num_max(n0),
        v(v0),
        vz((v+n)-1U)
    {
    }

    template<typename T>
    Array<T>::Array(Uint32 n0, Memmgr::Type memtype):
        n(n0),
        num_max(n0),
        v(Memmgr::get_instance().get_allocator(memtype).allocate_new_array<T>(n0)),
        vz((v+n)-1U)
    {
    }

    template<typename T>
    Array<T>::Array(Uint32 n0, Allocator& alloc):
        n(n0),
        num_max(n0),
        v(alloc.allocate_new_array<T>(n0)),
        vz((v+n)-1U)
    {
    }

    template<typename T>
    template <class T2>
    Array<T>::Array(Uint32 n0,
                    Memmgr::Type memtype,
                    Base::Rngit<T2> param):
        n(n0),
        num_max(n0),
        v(Memmgr::get_instance().get_allocator(memtype).allocate_new_array_it<T,Base::Rngit<T2> >(n0,param)),
        vz((v+n)-1U)
    {
    }

    template<typename T>
    template <class T2>
    Array<T>::Array(Uint32 n0,
                    Memmgr::Type memtype,
                    Base::Iiterator<T2>& it) :
        n(n0),
        num_max(n0),
        v(Memmgr::get_instance().get_allocator(memtype).allocate_new_array_it<T,Base::Iiterator<T2>& >(n0, it)),
        vz((v+n)-1U)
    {
    }

    template<typename T>
    template <class T2>
    Array<T>::Array(Uint32 n0,
                    Memmgr::Type memtype,
                    const Base::Array<T2>& param):
        n(n0),
        num_max(n0),
        v(Memmgr::get_instance().get_allocator(memtype).allocate_new_array_array<T,const Base::Array<T2>& >(n0,
                                                                                                            param)),
        vz((v+n)-1U)
    {
    }

    template<typename T>
    template <class T2>
    Array<T>::Array(Uint32 n0,
                    Memmgr::Type memtype,
                    Base::Array<T2>& param):
        n(n0),
        num_max(n0),
        v(Memmgr::get_instance().get_allocator(memtype).allocate_new_array_array<T,Base::Array<T2>& >(n0,
                                                                                                     param)),
        vz((v+n)-1U)
    {
    }

    template<typename T>
    template <typename T2>
    Array<T>::Array(Uint32 n0,
                    Memmgr::Type memtype,
                    Mblock<T2> param) :
        n(n0),
        num_max(n0),
        v(Memmgr::get_instance().get_allocator(memtype).allocate_new_array_array<T,Mblock<T2> >(n0,param)),
        vz((v+n)-1U)
    {
    }

    template<typename T>
    template <typename T2>
    Array<T>::Array(Uint32 n0,
                    Base::Allocator& alloc,
                    Mblock<T2> param) :
        n(n0),
        num_max(n0),
        v(alloc.allocate_new_array_array<T,Mblock<T2> >(n0,param)),
        vz((v+n)-1U)
    {
    }

    template<typename T>
    template <class T2, Uint16 ns>
    Array<T>::Array(Memmgr::Type memtype,
                    const Base::Suiteref<T2,ns>& param):
        n(ns),
        num_max(ns),
        v(Memmgr::get_instance().get_allocator(memtype).allocate_new_array_array<T,const Base::Suiteref<T2,ns>& >(ns,
                                                                                                              param)),
        vz((v+n)-1U)
    {
    }

    template<typename T>
    template <class T2>
    Array<T>::Array(Uint32 n0,
                    Memmgr::Type memtype,
                    T2 param):
        n(n0),
        num_max(n0),
        v(Memmgr::get_instance().get_allocator(memtype).allocate_new_array<T,T2>(n0,param)),
        vz((v+n)-1U)
    {
    }

    template<typename T>
    template <class T2>
    Array<T>::Array(Uint32 n0,
                    Memmgr::Type memtype,
                    Ref_wrapper<T2> param):
        n(n0),
        num_max(n0),
        v(Memmgr::get_instance().get_allocator(memtype).allocate_new_array<T,T2>(n0,param.elem)),
        vz((v+n)-1U)
    {
    }

    template<typename T>
    template <class T2,class T3>
    Array<T>::Array(Uint32 n0,
                    Memmgr::Type memtype,
                    T2 param0,
                    T3 param1):
        n(n0),
        num_max(n0),
        v(Memmgr::get_instance().get_allocator(memtype).allocate_new_array<T,T2,T3>(n0,
                                                                                    param0,
                                                                                    param1)),
        vz((v+n)-1U)
    {
    }

    template<typename T>
    template <class T2, class T3>
    Array<T>::Array(Uint32 n0,
                    Memmgr::Type memtype,
                    T2 param0,
                    Mblock<T3> param1) :
            n(n0),
            num_max(n0),
            v(Memmgr::get_instance().get_allocator(memtype).allocate_new_array_array<T,T2, Mblock<T3> >(n0, param0, param1)),
            vz((v+n)-1U)
      {
      }

    template<typename T>
    template <class T2,class T3,class T4>
    Array<T>::Array(Uint32 n0,
                    Memmgr::Type memtype,
                    T2 param0,
                    T3 param1,
                    T4 param2):
        n(n0),
        num_max(n0),
        v(Memmgr::get_instance().get_allocator(memtype).allocate_new_array<T,T2,T3,T4>(n0,
                                                                                       param0,
                                                                                       param1,
                                                                                       param2)),
        vz((v+n)-1U)
    {
    }

    /// Obtener subarray a partir de otro array
    template<typename T>
    Array<T>::Array(Array<T>& src,Uint32 idx0):
        n(src.n-idx0),
        num_max(src.n-idx0),
        v(&src[idx0]),
        vz((v+n)-1U)
    {
        Assertions::runtime(n>0U);
    }

    /// Obtener subarray a partir de otro array
    template<typename T>
    Array<T>::Array(Array<T>& src,
                    Uint32 idx0,
                    Uint32 n0):
        n((n0<=(src.n-idx0))?n0:(src.n-idx0)),
        num_max((n0<=(src.n-idx0))?n0:(src.n-idx0)),
        v(&src[idx0]),
        vz((v+n)-1U)
    {
        Assertions::runtime(n==n0);
    }

    template<typename T>
    void Array<T>::init(T* v0,Uint32 n0)
    {
        v=v0;
        n=n0;
        num_max=n0;
        vz=(v+n)-1U;
    }

    template<typename T>
    bool Array<T>::resize(Uint32 n0)
    {
        /// \alg <ul>
        /// <li> Set ::n as minimum value between new size and ::num_max.
        n = Rfun::min<Uint32>(n0, num_max);
        /// <li> Compute ::vz as (::v+::n)-1.
        vz=(v+n)-1U;
        /// <li> Return True if new size is lower than maximum size, False if not.
        return Base::Assertions::runtime(n0 <= num_max);
        /// </ul>
    }

    template<typename T>
    inline void Array<T>::copy(const Array<T>& v0)
    {
        /// \alg <ul>
        /// <li> Call to Tmem::cpy_sel with arguments:
        /// <ul>
        ///     <li> Destination pointer: Current pointer to first element.
        ///     <li> Source pointer: Pointer to first element of received Array.
        ///     <li> Memory size to be copied: ::n * sizeof(T).
        /// </ul>
        Tmem::cpy_sel(v,v0.v,n*sizeof(T));
        /// </ul>
    }

    template<typename T>
    inline void Array<T>::copy(const T* v0)
    {
        Tmem::cpy_sel(v,v0,n*sizeof(T));
    }

    template<typename T>
    template<typename Tc>
    inline void Array<T>::copy(const Mblock<Tc>& mb)
    {
        /// \alg
        /// - Call to ::resize with Mblock<T>::size.
        /// - Call to ::copy with received memory block pointer.
        resize(mb.size());
        copy(mb.v);
    }

    template<typename T>
    inline Mblock<T> Array<T>::to_mblock() //PRQA S 4211 #const
    {
        return Mblock<T>(v,n);
    }

    template<typename T>
    inline Mblock<const T> Array<T>::to_mblock() const
    {
        return Mblock<const T>(v,n);
    }

    template<typename T>
    inline Mblock<volatile T> Array<T>::to_mblock() volatile
    {
        return Mblock<volatile T>(v,n);
    }

    template<typename T>
    inline Mblock<const volatile T> Array<T>::to_mblock() const volatile
    {
        return Mblock<const volatile T>(v,n);
    }

    template<typename T>
    inline T& Array<T>::get(Uint32 i) //PRQA S 4211 #const
    {
        return v[i];
    }

    template<typename T>
    inline T& Array<T>::operator[](Uint32 i) //PRQA S 4211 #const
    {
        return v[i];
    }

    template<typename T>
    inline const T& Array<T>::operator[](Uint32 i)const
    {
        return v[i];
    }
    template<typename T>
    inline volatile T& Array<T>::operator[](Uint32 i) volatile
    {
        return v[i];
    }
    template<typename T>
    inline const volatile T& Array<T>::operator[](Uint32 i)const volatile
    {
        return v[i];
    }
    template<typename T>
    inline T* Array<T>::first()
    {
        return v;
    }
    template<typename T>
    inline const T* Array<T>::first() const
    {
        return v;
    }
    template<typename T>
    inline volatile T* Array<T>::first() volatile
    {
        return v;
    }
    template<typename T>
    inline const volatile T* Array<T>::first() const volatile
    {
        return v;
    }
    template<typename T>
    inline T* Array<T>::last()
    {
        return vz;
    }
    template<typename T>
    inline const T* Array<T>::last() const
    {
        return vz;
    }
    template<typename T>
    inline volatile T* Array<T>::last() volatile
    {
        return vz;
    }
    template<typename T>
    inline const volatile T* Array<T>::last() const volatile
    {
        return vz;
    }
    template<typename T>
    inline void Array<T>::zeros()
    {
        Tmem::set_sel(v,0,n*sizeof(T));
    }
    template<typename T>
    inline void Array<T>::assemble(Uint32 k, const Array<T>& v0)
    {
        if(resize(k + v0.size()))
        {
            Tmem::cpy_sel(&v[k],v0.v,v0.n*sizeof(T));
        }
    }
    template<typename T>
    inline bool Array<T>::has(const T& value) const
    {
        return get_index_of(value)>=0;
    }

    template<typename T>
    template <typename TFUNC>
    void Array<T>::apply_all(TFUNC f) const
    {
        for(T* vi = v; vi<=vz; ++vi)
        {
            f(*vi);
        }
    }


    template<typename T>
    void Array<T>::set_all(const T u)
    {
        for(Uint32 i=0;i<n;i++)
        {
            Tmem::cpy<sizeof(T)>(&v[i],&u);
        }
    }

    template<typename T>
    int32 Array<T>::get_index_of(const T& value) const//PRQA S 4213 #TODO: Check if PRQA suppresion
                                                      ///can be removed adding in "Ttrait.h" support
                                                      ///to make "T" const in case of T being a value or
                                                      ///a pointer ("T" -> "const T", and "T*" -> "const T* const").
    {
        int32 ret = -1;
        bool ret_aux = false;

        for(Uint32 i=0; (i<n) && (ret_aux==false); ++i)
        {
            if(v[i]==value)
            {
                ret = static_cast<int32>(i);
                ret_aux = true;
            }
        }
        return ret;
    }

    template<typename T>
    int32 Array<T>::get_index_of_element(const T* elem) const
    {
        Uint16 i=(static_cast<const T*>(elem)-v)/sizeof(T);
        return ((elem>=v)&&(elem<=vz)) ? static_cast<int32>(i) : (-1);
    }

    template<typename T>
    void Array<T>::insert_s2e(Uint32 idx,T value)
    {
        if(idx<Array<T>::n)
        {
            Uint32 inxt=idx+1;
            memmove(&v[inxt],&v[idx],(Array<T>::n-inxt)*sizeof(T));
            v[idx]=value;
        }
    }

    template<typename T>
    void Array<T>::insert_e2s(Uint32 idx,T value)
    {
        if(idx<Array<T>::n)
        {
            memmove(v,&v[1],idx*sizeof(T));
            v[idx]=value;
        }
    }

    template<typename T>
    void Array<T>::remove(Uint32 idx)
    {
        /// \alg
        /// If index received is in range, call to ::memmove with these arguments (being received index idx):
        ///     - Pointer to idx element.
        ///     - Pointer to next idx element (idx + 1).
        ///     - (::n - idx - 1) * sizeof(T)
        /// If index received is in range, resize (::resize) the array as ::n - 1.
        if(idx<Array<T>::n)
        {
            memmove(&v[idx],&v[idx+1],(n-idx-1)*sizeof(T));
            resize(n-1);
        }
    }

    template<typename T>
    T Array<T>::sum_all()const
    {
        typename Remove_const<T>::type s=0;
        const T* const vz0 = Base::Array<T>::vz;
        for (const T* p = Base::Array<T>::v; p <= vz0; ++p)
        {
            s+=*p;
        }
        return s;
    }

    template<typename T>
    bool Array<T>::append(const T& value)
    {
        bool res = false;
        if(Assertions::runtime(n<num_max))
        {
            res = true;
            v[n] = value;
            resize(n+1);
        }
        return res;
    }

    template<typename T>
    template<typename Tc>
    void Array<T>::append(const Mblock<Tc>& mb)
    {
        Assertions::Compile_time<is_same<T, typename Remove_cv<Tc>::type>::value>();
        const Uint32 sz_cp = mb.size();
        if(resize(n + sz_cp))
        {
            Tmem::cpy_sel(v+n-sz_cp, const_cast<T*>(mb.v), sz_cp*sizeof(T));
        }
    }

    template<typename T>
    bool Array<T>::is_non_descending() const
    {
        bool ret = true;
        for (const T* p = Base::Array<T>::v; (p < Base::Array<T>::vz) && ret; ++p)
        {
            ret = (*p <= *(p+1));
        }
        return ret;
    }

    template<typename T>
    bool Array<T>::is_non_ascending() const
    {
        bool ret = true;
        for (const T* p = Base::Array<T>::v; (p < Base::Array<T>::vz) && ret; ++p)
        {
            ret = (*p >= *(p+1));
        }
        return ret;
    }

    template<typename T>
    inline Uint32 Array<T>::size() const
    {
        return n;
    }

    template<typename T>
    inline Uint32 Array<T>::size_max() const
    {
        return num_max;
    }

    template<typename T>
    inline Uint32 Array<T>::size_unused() const
    {
        return num_max-n;
    }
}
#endif
