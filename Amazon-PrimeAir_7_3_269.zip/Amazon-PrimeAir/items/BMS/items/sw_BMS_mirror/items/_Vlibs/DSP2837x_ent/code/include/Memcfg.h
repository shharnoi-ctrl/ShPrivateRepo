#ifndef MEMCFG_H_
#define MEMCFG_H_

#include <Entypes.h>

namespace Dsp28335_ent
{
    /// DSP Memory ownership helper
    class Memcfg
    {
    public:
        /// Sets MSEL.
        /// \param value Each bit represents a global shared memory block (GSRAM). Bit 0
        /// represents GS0 and bit 15 represents GS15. When bit is clear, related GSRAM is
        /// owned by CPU1. When bit is set, ownership of related GSRAM is for CPU2.
        static void gsram_msel_set(Uint16 value);

    private:
        Memcfg(); ///< = delete
        Memcfg(const Memcfg& orig); ///< = delete
        Memcfg& operator=(const Memcfg& orig); ///< = delete
    };
}
#endif
