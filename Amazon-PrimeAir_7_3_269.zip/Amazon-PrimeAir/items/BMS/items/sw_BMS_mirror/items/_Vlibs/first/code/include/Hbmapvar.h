#ifndef HBMAPVAR_H_
#define HBMAPVAR_H_

#include <Bvar.h>
#include <Entypes.h>
#include <U16stream_r_error.h>
#include <U16stream_w.h>

namespace Base
{
    /// Hbmapvar class used to manage Bitmap types into system variables.
    class Hbmapvar
    {
    public:
        /// Bitmap type.
        struct Type
        {
            Uint16 nbits;   ///< Number of bits for Bitmap type.
            Uint64 val;     ///< Raw value of Bitmap.

            /// Bitmap Deserialization.
            /// \wi{17269}
            /// Hbmapvar class shall be able to deserialize into its internal data following the structure:
            /// Type   | Name  | Description               | Range
            /// -------|-------|---------------------------|---------
            /// Uint16 | nbits | Number of bits for Bitmap | [0, 64]
            /// Uint64 | val   | Raw value of Bitmap       | -
            /// \param[in] str Stream of data where get the data.
            inline void cset(U16stream_r_error& str)
            {
                nbits = str.get_uint16();
                val = str.get_uint64();
            }

            /// Bitmap Serialization.
            /// \wi{17270}
            /// Hbmapvar class shall be able to serialize its internal data following the same structure as ::cset.
            /// \param[out] str Stream of data where serialize the data.
            inline void cget(U16stream_w& str) const
            {
                str.put_uint16(nbits);
                str.put_uint64(val);
            }
        };

        /// Bitmap Reference Type.
        struct Ref
        {
            Bvar_map id;    ///< ID type for Bitmap (::Bvar_map)
            Type value;     ///< Value (::Type).

            /// Hbmapvar Type Builder.
            /// \wi{17271}
            /// Hbmapvar class shall provide a static function able to build a reference type with an ID and a value.
            /// \param[in] id0 First ::Bvar (wrapped into a Bvar_map type) associated to Bitmap type.
            /// \param[in] value0 Bitmap value.
            /// \return Reference type already built with given data.
            static inline Ref build_bmapref(Bvar_map id0, const Type& value0)
            {
                Ref r = {id0, value0};
                return r;
            }

        };

        /// Hbmapvar Constructor.
        /// \wi{17272}
        /// Hbmapvar class shall build itself upon construction with a given Bva_map id.
        /// \param[in] id0 First bvar used to compute the bitmap wrapped into a Bvar_map type.
        inline explicit Hbmapvar(Bvar_map id0) :
            id(id0)
        {
        }
        /// Hbmapvar Getter.
        /// \wi{17273}
        /// Hbmapvar class shall be able to retrieve the bitmap value associated to internal id.
        /// \param[in, out] value Bitmap computed. Read only provided number of bits into received Hbmapvar::Type.
        void get(Hbmapvar::Type& value);
        /// Hbmapvar Setter.
        /// \wi{17274}
        /// Hbmapvar class shall be able to set a computed bitmap into a set of Bit system variables starting from
        /// internal id.
        /// \param[in] value Value to be set into a set of Bit variables.
        void set(const Hbmapvar::Type& value);

    private:
        Bvar_map id;    /// First Bvar to be updated (wrapped into a Bvar_map type).

        Hbmapvar(const Hbmapvar& orig); ///< = delete
        Hbmapvar& operator=(const Hbmapvar& orig);  ///< = delete
    };
}
#endif
