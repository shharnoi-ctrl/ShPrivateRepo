#ifndef U8PKMBLOCK_K_FW_H_
#define U8PKMBLOCK_K_FW_H_

namespace Base
{
    class U8pkmblock_k;
}
#endif
