#ifndef ASM_H_
#define ASM_H_

namespace Dsp28335_ent
{
    /// Debug stop (halts if JTAG is connected).
    inline void asm_stop()
    {
        #ifndef VCAST_COMPILE // Exception for JSF/PRQA required, ESTOP0 makes VectorCast testing fail.
        __asm(" ESTOP0");
        #endif
    }

    /// NOP instruction (useful to set breakpoints)
    inline void asm_nop()
    {
        __asm(" NOP");
    }

    /// Forces an illegal isr to be launched.
    inline void asm_itrap0()
    {
        __asm(" ITRAP0");
    }

    /// Forces a pipeline flush.
    inline void asm_pipeline_flush7()
    {
        __asm(" RPT #7 || NOP");
    }

    /// Enable interrupts
    inline void asm_eint()
    {
        __asm(" clrc INTM");
    }

    /// Disable interrupts
    inline void asm_dint()
    {
        __asm(" setc INTM");
    }

    /// Enable Global realtime interrupt DBGM
    inline void asm_ertm()
    {
        __asm(" clrc DBGM");
    }

    inline void asm_drtm()
    {
        __asm(" setc DBGM");
    }

    /// Enable writing in EALLOW protected registers
    inline void asm_eallow()
    {
        __asm(" EALLOW");
    }

    /// Disable writing in EALLOW protected registers
    inline void asm_edis()
    {
        __asm(" EDIS");
    }

    inline void asm_195NOP()
    {
        __asm(" RPT #195 || NOP");
    }

    inline void asm_200NOP()
    {
        __asm(" RPT #200 || NOP");
    }

    inline void asm_5NOP()
    {
        __asm(" RPT #5 || NOP");
    }

    inline void asm_20NOP()
    {
        __asm(" RPT #20 || NOP");
    }

    inline void asm_ALNOP()
    {
        // Execute as many NOPs as AL indicates
        __asm(" RPT AL || NOP");
    }

    // Clear flag of ST1[DBGM].
    inline void asm_DBGM()
    {
        __asm(" CLRC DBGM");
    }
}
#endif
