#ifndef FIFOSPSC0_H_
#define FIFOSPSC0_H_

#include <Ttraits.h>
#include <Cptraits.h>
#include <SPSCtraits.h>

namespace Base
{
    /// Thread safe Fifo for single producer in one thread and single consumer in other thread.
    /// Read and write pointers types are template parameters to allow any of them be references to
    /// some other decoupled writer/reader (write/read methods can also be disabled making them const).
    /// This class's size is limited to 2^32 elements.
    template <typename T,
              template <typename> class RD = SPSCtraits::Internal,
              template <typename> class WR = SPSCtraits::Internal>
    class Fifospsc0
    {
    public:
        typedef typename JSF116_param<T>::type JSF116_param_type;   ///< Parameter type definition for ::T data type.
        typedef T type;                                             ///< Type for ::T data type.
        typedef RD<const T>                         RDtrait;        ///< Types trait for read pointers (read-only).
        typedef WR<T>                               WRtrait;        ///< Types trait for write pointers.
        typedef typename RDtrait::Fftype_tmp        Rtmp;           ///< Type for read pointer to temporary value.
        typedef typename RDtrait::Fftype_ptr        Rptr;           ///< Type for read pointer to FIFO data.
        typedef typename WRtrait::Fftype_tmp        Wtmp;           ///< Type for write pointer to temporary value.
        typedef typename WRtrait::Fftype_ptr        Wptr;           ///< Type for write pointer to FIFO data.

        /// FIFO (Single Producer/Single Consumer) constructor.
        /// \wi{5025}
        /// Fifospsc0 class shall initialize itself upon construction with provided parameters.
        /// \param[in] v0   Pointer to the first buffer element.
        /// \param[in] vz0  Pointer to the last buffer element.
        /// \param[in] rd0  Pointer to manage buffer readings.
        /// \param[in] wr0  Pointer to manage buffer writings.
        Fifospsc0(T* const v0, T* const vz0, Rptr rd0, Wptr wr0);

        /// FIFO data write.
        /// \wi{5027}
        /// Fifospsc0 class shall provide the capability to write one element.
        /// \param[in] element  Element to write in the buffer (of ::T type).
        /// \return True if write, false if not.
        template <typename T2=T, typename CPTRAIT = Cptraits::Operator<T2,T> >
        bool write(typename JSF116_param<T2>::type element);

        /// FIFO data read.
        /// \wi{5029}
        /// Fifospsc0 class shall provide the capability to read one element.
        /// \param[out] element Reference to the variable to store the read element.
        /// \return True if read, false if not.
        template <typename T2=T, typename CPTRAIT = Cptraits::Operator<T,T2> >
        bool read(T2& element);

        /// FIFO read available.
        /// \wi{5030}
        /// Fifospsc0 class shall be able to check if reading action is available (based on writer state).
        /// \return True if the reading action is available, false if not.
        bool rd_available() const;

        /// FIFO write available.
        /// \wi{5028}
        /// Fifospsc0 class shall be able to check if writing action is available (based on reader state).
        /// \return True if the writing action is available, false if not.
        bool wr_available() const;

        /// FIFO read count.
        /// \wi{16823}
        /// Fifospsc0 class shall be able to compute the number of elements that can be read (based on write state).
        /// \return Available reading count.
        Uint32 rd_available_count() const;

        /// FIFO write count.
        /// \wi{16824}
        /// Fifospsc0 class shall be able to compute the number of elements that can be write (based on read state).
        /// \return Available writing count.
        Uint32 wr_available_count() const;

        /// FIFO get read pointer.
        /// \wi{5031}
        /// Fifospsc0 class shall be able to retrieve its read pointer.
        /// \return Read pointer as ::rd.
        Rtmp get_rd() const;

        /// FIFO get write pointer.
        /// \wi{5032}
        /// Retrieve write pointer
        /// \return Write pointer where points the next writing action.
        Wtmp get_wr() const;

        /// FIFO set read pointer.
        /// \wi{6353}
        /// Fifospsc0 class shall be able to set its read pointer from provided one.
        /// \param[in] wr0  New read pointer.
        void set_rd(Rtmp rd0);

        /// FIFO set write pointer.
        /// \wi{5033}
        /// Fifospsc0 class shall be able to set its write pointer from provided one.
        /// \param[in] wr0 New write pointer.
        void set_wr(Wtmp wr0);

        /// FIFO first element.
        /// \wi{5034}
        /// Fifospsc0 class shall be able to retrieve the pointer to the buffer first element.
        /// \return Pointer to the first element of the buffer.
        T* get_v() const;

        /// FIFO last element.
        /// \wi{5035}
        /// Fifospsc0 class shall be able to retrieve the pointer to the buffer last element.
        /// \return Pointer to the last element of the buffer.
        T* get_vz() const;

        /// FIFO next element.
        /// \wi{5036}
        /// Fifospsc0 class shall be able to retrieve the pointer to next element on its buffer.
        /// \param[in] prv  Pointer to current element.
        /// \return Element next to ::priv (shall located between ::v and ::vz).
        template <typename T2>
        T2* next(T2* prv) const;

    private:
        T* const v;         ///< Pointer to the first buffer element.
        T* const vz;        ///< Pointer to the last buffer element.
        Rptr rd;            ///< Pointer to manage buffer readings.
        Wptr wr;            ///< Pointer to manage buffer writings.
        const Uint32 size;  ///< Pre-computed FIFO size.

        Fifospsc0(); ///< = delete
        Fifospsc0(const Fifospsc0& orig); ///< = delete
        Fifospsc0& operator=(const Fifospsc0& orig); ///< = delete
    };


    /// \alg
    /// With template arguments as: <ul>
    /// <li> ::T    as the type of data to handle,
    /// <li> ::RD   as the type of read pointer,
    /// <li> ::WR   as the type of write pointer. </ul>
    /// Fifospsc0 class shall initialize itself as following:
    /// Type            | Name      | Description                           | Value
    /// --------------- | --------- | ------------------------------------- | -----------
    /// ::T* const      | ::v       | Pointer to the first buffer element   | ::v0
    /// ::T* const      | ::vz      | Pointer to the last buffer element    | ::vz0
    /// Rptr            | ::rd      | Pointer to manage buffer readings     | ::rd0
    /// Wptr            | ::wr      | Pointer to manage buffer writings     | ::wr0
    /// const Uint32    | ::size    | Pre-computed FIFO size                | ::vz-::v+1 </ul>
    /// Where: <ul>
    /// <li> Rptr as ::RD<const ::T>::Fftype_ptr,
    /// <li> Wptr as ::WR<const ::T>::Fftype_ptr. </ul>
    /// FIFO data management depends on Rptr and Wptr types, as: <ul>
    /// Name                        | Type                          | Data Management
    /// --------------------------- | ----------------------------- | --------------------------------------------
    /// SPSCtraits::External        | const ::T* const volatile&    | Reference not managed by FIFO
    /// SPSCtraits::Internal_ref    | T::* volatile&                | Reference managed by FIFO
    /// SPSCtraits::Internal        | ::T* volatile                 | Internally instantiated and managed by FIFO </ul>
    template <typename T,
              template <typename> class RD,
              template <typename> class WR>
    inline Fifospsc0<T,RD,WR>::Fifospsc0(T* const v0,
                                         T* const vz0,
                                         Rptr rd0,
                                         Wptr wr0) :
        v(v0),
        vz(vz0),
        rd(rd0),
        wr(wr0),
        size(static_cast<Uint32>(vz-v+1))
    {
    }

    template <typename T,
              template <typename> class RD,
              template <typename> class WR>
    template <typename T2, typename CPTRAIT>
    inline bool Fifospsc0<T, RD, WR>::write(typename JSF116_param<T2>::type element)
    {
        /// \alg
        /// If ::rd is pointing to the same returned value from ::next: <ul>
        /// <li> Copy the element to the ::wr_ptr element.
        /// <li> Store the returned value from ::next onto ::wr pointer.
        /// <li> Then return true. </ul>
        /// Else return false.
        bool ret = false;
        // only writes wr, so no mutex is needed
        Wtmp nxt = next(wr);
        if(rd != nxt)
        {
            CPTRAIT::copy(element,*wr);
            wr = nxt;
            ret = true;
        }
        return ret;
    }

    template <typename T,
              template <typename> class RD,
              template <typename> class WR>
    template <typename T2, typename CPTRAIT>
    inline bool Fifospsc0<T, RD, WR>::read(T2& element)
    {
        /// \alg
        /// If ::rd_available return true: <ul>
        /// <li> Load returned value from ::next onto temporary read pointer.
        /// <li> Load ::rd pointed value onto ::element variable.
        /// <li> Load returned value from ::next onto ::rd pointer.
        /// <li> Then return true. </ul>
        /// Else return false.
        bool ret = false;
        // only writes rd, so no mutex is needed
        if(rd_available())
        {
            Rtmp nxt = next(rd);
            // Assignation with volatile ignored , no concurrent write can happen (rd/wr pointers ensure it).
            CPTRAIT::copy(*rd, element);
            rd=nxt;
            ret = true;
        }
        return ret;
    }

    template <typename T,
              template <typename> class RD,
              template <typename> class WR>
    inline bool Fifospsc0<T, RD, WR>::rd_available() const
    {
        /// \alg
        /// Return false if ::rd is pointing the same element as ::wr, else return true.
        return (rd != wr);
    }

    template <typename T,
              template <typename> class RD,
              template <typename> class WR>
    inline bool Fifospsc0<T, RD, WR>::wr_available() const
    {
        /// \alg
        /// If ::rd is pointing to the same returned value from ::next, return false,
        /// else return true.
        return rd != next(wr);
    }

    template <typename T,
              template <typename> class RD,
              template <typename> class WR>
    inline Uint32 Fifospsc0<T, RD, WR>::rd_available_count() const
    {
        /// \alg
        /// If ::wr pointer is greater or equal to ::rd one: <ul>
        /// <li> Return \f$rd_cnt = (::wr-::rd)\f$. </ul>
        /// Else: <ul>
        /// <li> Return \f$rd_cnt = (::wr+size-::rd)\f$. </ul>
        return (wr>=rd) ? static_cast<Uint32>(wr-rd) : static_cast<Uint32>(wr+size-rd);
    }

    template <typename T,
              template <typename> class RD,
              template <typename> class WR>
    inline Uint32 Fifospsc0<T, RD, WR>::wr_available_count() const
    {
        /// \alg
        /// Return \f$wr_cnt = (1-rd_cnt)\f$ where \f$rd_cnt\f$ is the number of pending elements to be read
        /// (as described at \wi{16823}.
        return size - 1 - rd_available_count();
    }

    template <typename T,
              template <typename> class RD,
              template <typename> class WR>
    inline typename Fifospsc0<T, RD, WR>::Rtmp Fifospsc0<T, RD, WR>::get_rd() const
    {
        return rd;
    }

    template <typename T,
              template <typename> class RD,
              template <typename> class WR>
    inline typename Fifospsc0<T, RD, WR>::Wtmp Fifospsc0<T, RD, WR>::get_wr() const
    {
        return wr;
    }

    template <typename T,
              template <typename> class RD,
              template <typename> class WR>
    inline void Fifospsc0<T, RD, WR>::set_rd(typename Fifospsc0<T, RD, WR>::Rtmp rd0)
    { //PRQA S 5059 #PRQA fail (there's not 3 parameters)
        rd = rd0;
    }

    template <typename T,
              template <typename> class RD,
              template <typename> class WR>
    inline void Fifospsc0<T, RD, WR>::set_wr(typename Fifospsc0<T, RD, WR>::Wtmp wr0)
    { //PRQA S 5059 #PRQA fail (there's not 3 parameters)
        wr = wr0;
    }

    template <typename T,
              template <typename> class RD,
              template <typename> class WR>
    inline T* Fifospsc0<T, RD, WR>::get_v() const
    {
        return v;
    }

    template <typename T,
              template <typename> class RD,
              template <typename> class WR>
    inline T* Fifospsc0<T, RD, WR>::get_vz() const
    {
        return vz;
    }

    template <typename T,
              template <typename> class RD,
              template <typename> class WR>
    template <typename T2>
    inline T2* Fifospsc0<T, RD, WR>::next(T2* prv) const
    {
        return (prv>=vz) ? static_cast<T2*>(v) : (prv+1);
    }

} // namespace Base

#endif // FIFOSPSC0_H_

