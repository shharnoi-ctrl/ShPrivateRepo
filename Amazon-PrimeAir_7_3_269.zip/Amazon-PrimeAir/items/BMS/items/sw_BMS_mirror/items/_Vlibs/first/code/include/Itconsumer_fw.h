#ifndef ITCONSUMER_FW_H_
#define ITCONSUMER_FW_H_

#include <Entypes.h>

namespace Base
{
    template<typename T>
    class Itconsumer;

    typedef Itconsumer<Uint8> Itconsumer_u8;
    typedef Itconsumer<Uint16> Itconsumer_u16;
}
#endif
