#ifndef WSYNC_FW_H_
#define WSYNC_FW_H_

namespace Base
{
    namespace Tuntraits
    {
        /// Tdync based, write safe, read unsafe
        template <typename TDSYNC, typename DELEGATE_TRAIT>
        struct Wsync;
    }
}
#endif
