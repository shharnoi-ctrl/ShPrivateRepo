#ifndef ITERATOR_H_
#define ITERATOR_H_

#include <Mblock.h>

namespace Base
{
    /// Iterator class which allows to iterate across any range of consecutive values in memory.
    template <typename T>
    class Iterator
    {
    public:
        /// Iterator Constructor.
        /// \wi{6694}
        /// Iterator class shall build itself upon construction with a given Memory block which will be iterated.
        /// \param[in] mb Memory block of T type to be iterated.
        Iterator(Mblock<T> mb);
        /// Next Reference Element Retriever.
        /// \wi{5377}
        /// Iterator class shall be able to retrieve the reference to next element in contained elements.
        /// \param[out] value0 Reference where retrieve object.
        /// \return True if has been possible retrieve next element, False if not.
        bool next(T& value0);
        /// Next Pointer Element Retriever.
        /// \wi{16912}
        /// Iterator class shall be able to retrieve the pointer to next element in contained elements.
        /// \return The pointer to next element or zero if it doesn't exist.
        T* next();

    private:
        T* v;                   ///< Current element
        const T* const vend;    ///< Last element

        Iterator(); ///< = delete
    };

    template <typename T>
    inline Iterator<T>::Iterator(Mblock<T> mb) :
        v(mb.v),
        vend(mb.last())
    {
        /// \alg
        /// Internal atributes will be initialized as:
        ///     - ::v: Pointer to first element of received memory block.
        ///     - ::vend: Pointer to last element of received memory block.
    }

    template <typename T>
    inline bool Iterator<T>::next(T& value0)
    {
        /// \alg
        /// Call to ::next function. If value retrieved is different than 0, the iteration has not finished yet and
        /// its value will be retrieved in the output parameter and the function will return True. In other case
        /// the function will return False.
        T* val = next();
        const bool result = (val != 0);
        if(result)
        {
            value0 = *val;
        }
        return result;
    }

    template <typename T>
    T* Iterator<T>::next()
    {
        /// \alg
        /// If ::v is lower or equals to ::vend, return ::v++, so, the current element in incremented by one after
        /// being retrieved.
        T* result = 0;
        if(v<=vend)
        {
            result = v++;
        }
        return result;
    }
}

#endif
