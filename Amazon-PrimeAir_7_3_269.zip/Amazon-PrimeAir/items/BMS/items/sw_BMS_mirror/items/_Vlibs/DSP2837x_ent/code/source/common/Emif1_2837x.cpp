#include <Emif1.h>
#include <Hregmap.h>

namespace Dsp28335_ent
{
    volatile Emif1::Emif_regs& Emif1::get_emif1_regs()
    {
        static const Uint32 emif1_regs_addr = 0x047000UL;
        return Hregmap::get<Emif_regs, emif1_regs_addr>();
    }

    volatile Emif1::Emif1_config_regs& Emif1::get_emif1_config_regs()
    {
        static const Uint32 emif1_config_regs_addr = 0x05F480UL;
        return Hregmap::get<Emif1_config_regs, emif1_config_regs_addr>();
    }
}
