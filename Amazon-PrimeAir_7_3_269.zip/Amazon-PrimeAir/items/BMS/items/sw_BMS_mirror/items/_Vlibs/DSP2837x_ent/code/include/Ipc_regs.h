#ifndef IPC_REGS_H_
#define IPC_REGS_H_

#include <Entypes.h>

namespace Dsp28335_ent
{
    struct Ipc_regs                 ///< IPC Registers definition
    {
        Uint32      ipcack;         ///< IPC incoming flag clear (acknowledge) register
        Uint32      ipcsts;         ///< IPC incoming flag status register
        Uint32      ipcset;         ///< IPC remote flag set register
        Uint32      ipcclr;         ///< IPC remote flag clear register
        Uint32      ipcflg;         ///< IPC remote flag status register
        Uint16      rsvd1[2];       ///< Reserved
        Uint32      ipccounterl;    ///< IPC Counter Low Register
        Uint32      ipccounterh;    ///< IPC Counter High Register
        Uint32      ipc1to2com;     ///< Local to Remote IPC Command Register
        void*       ipc1to2addr;    ///< Local to Remote IPC Address Register
        Uint32      ipc1to2data;    ///< Local to Remote IPC Data Register
        Uint32      ipc2to1reply;   ///< Remote to Local IPC Reply Data Register
        Uint32      ipc2to1com;     ///< Remote to Local IPC Command Register
        void*       ipc2to1addr;    ///< Remote to Local IPC Address Register
        Uint32      ipc2to1data;    ///< Remote to Local IPC Data Register
        Uint32      ipc1to2reply;   ///< Local to Remote IPC Reply Data Register
        Uint32      ipcbootsts;     ///< CPU2 to CPU1 IPC Boot Status Register
        Uint32      ipcbootmode;    ///< CPU1 to CPU2 IPC Boot Mode Register
    };
}
#endif
