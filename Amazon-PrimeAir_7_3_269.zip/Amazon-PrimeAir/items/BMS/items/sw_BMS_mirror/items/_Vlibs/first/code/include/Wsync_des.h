#ifndef WSYNC_DES_H_
#define WSYNC_DES_H_


#include <Tdsync.h>

namespace Base
{
    namespace Tuntraits
    {

        /// Tdync based, write safe, read unsafe, Tuntrait
        template <typename TDSYNC, typename DELEGATE_TRAIT = Cset_only<typename TDSYNC::type> >
        struct Wsync_des : type_is<TDSYNC>
        {
        public:
            static void str2elem(TDSYNC& s, Lossy_error& str);
        private:
            Wsync_des(); ///< = delete
            Wsync_des(const Wsync_des& orig); ///< = delete
            Wsync_des& operator=(const Wsync_des& orig); ///< = delete
        };

        template <typename TDSYNC, typename DELEGATE_TRAIT>
        inline void Wsync_des<TDSYNC,DELEGATE_TRAIT>::str2elem(TDSYNC& s, Lossy_error& str)
        {
            typename TDSYNC::Wrsafe wr(s); // RAII
            DELEGATE_TRAIT::str2elem(wr.data,str);
        }

    }

}


#endif
