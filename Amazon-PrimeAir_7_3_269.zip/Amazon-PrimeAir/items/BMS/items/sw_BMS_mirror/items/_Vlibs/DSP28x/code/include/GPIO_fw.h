#ifndef GPIO_FW_H_
#define GPIO_FW_H_
namespace Dsp28335_ent
{
    class GPIO;
}
#endif
