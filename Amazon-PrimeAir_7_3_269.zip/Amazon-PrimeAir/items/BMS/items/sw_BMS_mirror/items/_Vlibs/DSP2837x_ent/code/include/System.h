#ifndef SYSTEM_H_
#define SYSTEM_H_

namespace Dsp28335_ent
{
    /// System initialization and reset routines.
    class System
    {
    public:
        /// Resets CPU. This method never returns.
        static void cpu_reset();

        /// \return True if "force bootloader" has been set
        static bool force_bootloader_mode();

        enum Ext_mem_size
        {
            mem_none,
            mem_1MW,
            mem_2MW
        };
    private:
        System(); ///< = delete
        System(const System& orig); ///< = delete
        System& operator=(const System& orig); ///< = delete
    };
}
#endif
