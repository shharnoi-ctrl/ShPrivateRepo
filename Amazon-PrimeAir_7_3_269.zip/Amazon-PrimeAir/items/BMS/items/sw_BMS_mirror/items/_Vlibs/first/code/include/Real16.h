#ifndef REAL16_H_
#define REAL16_H_

#include <Entypes.h>

/// Class to manage 16-bit floats
class Real16
{
public:
    /// Constructor with given Real
    inline Real16(Real r) : raw(get_real_as_float16(r))
    {
    }
    /// Constructor with given Real16
    inline Real16(Uint16 r) :
            raw(r)
    {
    }

    /// Return Real16 as a Real
    inline Real as_real()
    {
        return get_float16_as_real(raw);
    }

    /// Return Real16 representation as Uint16
    inline Uint16 get_raw()
    {
        return raw;
    }

private:
    Uint16 raw; ///< Real16 data saved as Uint16

    static Uint16 get_real_as_float16(Real r); ///< Retrieves the representation in Real16 of a Real as Uint16
    static Real get_float16_as_real(Uint16 r); ///< Retrieves the Real of a Real16 represented as Uint16
};

#endif
