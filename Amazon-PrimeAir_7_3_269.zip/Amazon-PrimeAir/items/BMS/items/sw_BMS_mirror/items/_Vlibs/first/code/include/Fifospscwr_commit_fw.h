///    \file Fifospscwr_commit_fw.h
///
///    \date 2 jul. 2018
///
///    \author  FJBurgos, jbm (at) embention.com
///    Company:  Embention
///
///    Fifospscwr_commit_fw class declaration.
///

#ifndef FIFOSPSCWR_COMMIT_FW_H_
#define FIFOSPSCWR_COMMIT_FW_H_

namespace Base
{

    template <typename T,
              template <typename> class,
              template <typename> class>
    class Fifospscwr_commit;

} // namespace Base

#endif // FIFOSPSCWR_COMMIT_FW_H_
