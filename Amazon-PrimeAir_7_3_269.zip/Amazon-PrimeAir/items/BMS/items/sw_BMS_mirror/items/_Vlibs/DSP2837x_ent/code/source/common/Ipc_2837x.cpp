#include <Ipc.h>
#include <Assertions.h>
#include <Delay.h>
#include <Devcfg.h>
#include <Hdual.h>
#include <Hregmap.h>
#include <ISRmgr.h>
#include <Ku16.h>
#include <Ku32.h>
#include <Memcfg.h>
#include <Mutex.h>

#include "Piectrl.h" //PRQA S 1015

namespace Dsp28335_ent
{
    namespace
    {
        static const Uint32 ipc_regs_addr = 0x050000UL;
        static const Uint32 flags1and32 = 0x80000001UL;
        static const Uint32 flags2and8  = 0x82;
        static const Uint32 c2_bootrom_bootsts_system_ready = 0x00000002UL;
    }

    void Ipc::set_isr(const Uint16 isr_num, Isrptr p_isr)
    {
        /// \alg
        /// <li> Ensure PIE is enabled
        Piectrl::enable_pie();
        /// <li> Vector id for the desired interrupt.
        const ISRmgr::Pievectid isr_id = static_cast<ISRmgr::Pievectid>(Piectrl::grp01 + isr_num);
        /// <li> Set the ISR handler.
        ISRmgr::set_isr(isr_id, p_isr);
        /// <li> Interrupt configuration flags.
        static const Piectrl::Mid mid_tmr0 = { Piectrl::grp01, Piectrl::flag_int13 };
        /// <li> Enable the interrupt.
        Piectrl::enable(mid_tmr0);
    }

    Ipc::Ipc() : regs(Hregmap::get<Ipc_regs, ipc_regs_addr>())
    {
    }

    Ipc& Ipc::get_instance()
    {
        static Ipc s;
        return s;
    }

    void Ipc::cpu1_boot_cpu2()
    {
        Hdual::assert_is_cpu1();

        Dsp28335_ent::Devcfg dc;
        dc.cpu2_hold_reset();       /// - Turn off CPU2.
        Delay::us(100);             /// - Wait for 100us.
        dc.cpu2_reset_deactivate(); /// - Turn on CPU2 again.

        // CPU02 has completed the boot and is ready for boot IPC command
        Uint32 bootStatus = regs.ipcbootsts & Ku32::u0xF;

        // Wait until CPU02 control system boot ROM is ready to receive
        // CPU01 to CPU02 INT1 interrupts.
        do
        {
            bootStatus = regs.ipcbootsts & c2_bootrom_bootsts_system_ready;
        } while ((bootStatus != c2_bootrom_bootsts_system_ready));

        // Loop until CPU02 control system IPC flags 1 and 32 are available
        while (regs.ipcflg & flags1and32) // (1 means bussy)
        {
        }

        //CPU01 to CPU02 IPC Boot Mode Register: 'boot from flash'
        static const Uint32 ulBootMode = 0x0000000BUL;
        regs.ipcbootmode = ulBootMode;

        // CPU01 To CPU02 IPC Command Register
        static const Uint32 brom_ipc_execute_bootmode_cmd = 0x00000013UL; // Boot
        regs.ipc1to2com = brom_ipc_execute_bootmode_cmd;

        // CPU01 to CPU02 IPC flag register
        regs.ipcset = flags1and32;
    }

    void Ipc::cpu1_unlock()
    {
        Hdual::assert_is_cpu2();
        regs.ipcset = flags2and8;
    }

    void Ipc::cpu2_unlock()
    {
        Hdual::assert_is_cpu1();
        regs.ipcset = flags2and8;
    }

    void Ipc::reset_flags()
    {
        regs.ipcclr = flags2and8;
    }

    void Ipc::set_flag(Uint8 flag, bool value)
    {
        regs.ipcset = static_cast<Uint32>(value) << flag;
    }

    bool Ipc::is_cpu1_locked()
    {
        Hdual::assert_is_cpu1();
        volatile Ipc_regs& lregs = Hregmap::get<Ipc_regs, ipc_regs_addr>();
        return (lregs.ipcsts & flags2and8) != flags2and8;
    }

    void Ipc::cpu1_wait_for_unlock()
    {
        while(is_cpu1_locked())
        {
        }
    }

    bool Ipc::is_cpu2_locked()
    {
        Hdual::assert_is_cpu2();
        volatile Ipc_regs& lregs = Hregmap::get<Ipc_regs, ipc_regs_addr>();
        return (lregs.ipcsts & flags2and8) != flags2and8;
    }

    void Ipc::cpu2_wait_for_unlock()
    {
        while(is_cpu2_locked())
        {
        }
    }

    void Ipc::send_reset_request_1to2_blocking()
    {
        Hdual::assert_is_cpu1();
        regs.ipcbootmode = rst_halt_request;    // Halt request for CPU2

        for(Uint32 i=0; (regs.ipcbootsts != rst_halt_ack) && (i<10000); i++)   // Wait for ACK
        {
            ;
        }
    }

    bool Ipc::is_reset_request() const
    {
        return regs.ipcbootmode == rst_halt_request;
    }

    void Ipc::send_ack_reset_request_2to1()
    {
        Hdual::assert_is_cpu2();
        regs.ipcbootsts = rst_halt_ack;
    }

    Uint32 Ipc::cpu2_get_ipc_param()
    {
        volatile Ipc_regs& regs(Hregmap::get<Ipc_regs, ipc_regs_addr>());
        return regs.ipc1to2data;
    }

    void Ipc::cpu2_set_ipc_result(Uint32 res)
    {
        volatile Ipc_regs& regs(Hregmap::get<Ipc_regs, ipc_regs_addr>());
        regs.ipc2to1reply = res;
    }

    Uint32 Ipc::cpu2_ipc_remote_call(Cpu2_start_func func, Uint32 data)
    {
        Dsp28335_ent::Ipc& ipc0 = Dsp28335_ent::Ipc::get_instance();
        Base::Mutex m(true);

        Dsp28335_ent::Devcfg dc;
        dc.cpu2_hold_reset();            // CPU2 off, ERAM available to write.

        Dsp28335_ent::Memcfg::gsram_msel_set(Ku16::u0xFFFF);    // GSRAM for cpu2
        dc.cpu2_reset_deactivate();                             // Release CPU2 from reset

        Uint32 res = cpu2_ipc_remote_call0(func, data);         // Make CPU2 execute code (blocking call)

        dc.cpu2_hold_reset();                                   // CPU2 off, also, flash pump is back to default(CPU1)
        Dsp28335_ent::Memcfg::gsram_msel_set(0);                // GSRAM for cpu1

        return res;
    }

    Uint32 Ipc::cpu2_ipc_remote_call0(Cpu2_start_func func, Uint32 data)
    {
        Hdual::assert_is_cpu1();

        Uint32 res = 0;

        // CPU02 has completed the boot and is ready for
        // CPU01 TO CPU02 IPC commands

        // Wait until CPU02 control system boot ROM is ready to receive
        // CPU01 to CPU02 INT1 interrupts.
        Uint32 bootStatus = 0;
        do
        {
            bootStatus = regs.ipcbootsts & c2_bootrom_bootsts_system_ready;
        } while ((bootStatus != c2_bootrom_bootsts_system_ready));

        regs.ipc1to2addr = reinterpret_cast<void*>(func);
        // C2-BootROM jump to the address in ADDR register and starts executing the code from that address
        static const Uint32 c1c2_brom_ipc_branch_call = 0x00000011UL;
        // CPU01 To CPU02 IPC Command Register
        regs.ipc1to2com  = c1c2_brom_ipc_branch_call;
        regs.ipc1to2data = data;

        // CPU01 to CPU02 IPC flag register
        regs.ipcset = flags1and32;

        // block
        while (regs.ipcsts != flags1and32) // CPU2 done?
        {
        }
        res = regs.ipc2to1reply;
        return res;
    }
}
