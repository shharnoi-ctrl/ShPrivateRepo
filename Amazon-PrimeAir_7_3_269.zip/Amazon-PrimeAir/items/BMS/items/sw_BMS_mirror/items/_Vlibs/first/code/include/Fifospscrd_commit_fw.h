#ifndef FIFOSPSCRD_COMMIT_FW_H_
#define FIFOSPSCRD_COMMIT_FW_H_

namespace Base
{
    template <typename T,
              template <typename> class,
              template <typename> class>
    class Fifospscrd_commit;

}

#endif
