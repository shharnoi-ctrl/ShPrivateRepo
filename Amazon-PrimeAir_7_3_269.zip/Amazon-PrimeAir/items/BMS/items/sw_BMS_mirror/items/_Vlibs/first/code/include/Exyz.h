// Exyz.h
//
//  Created on: 28 feb. 2019
//      Author: adm5
//

#ifndef EXYZ_H_
#define EXYZ_H_

namespace Base
{
    namespace Coord
    {
        enum Exyz
        {
            pos_x = 0,
            pos_y = 1,
            pos_z = 2
        };

    }

}

#endif
