#ifndef ERROR_FIFO_H_
#define ERROR_FIFO_H_

#include <Fifospscwr_commit.h>
#include <Fifospscrd_commit.h>

namespace Base
{
    /// Type definition for the error FIFO from writer-side
    typedef Fifospscwr_commit<volatile Uint16, SPSCtraits::External, SPSCtraits::Internal_ref> Fifo_err_wr;

    /// Type definition for the error FIFO from reader-side
    typedef Fifospscrd_commit<const volatile Uint16, SPSCtraits::Internal, SPSCtraits::External> Fifo_err_rd;
}

#endif
