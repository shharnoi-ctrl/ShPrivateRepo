///    \file Ttransfer.h
///
///    \date 28/02/2017
///
///    \author  FJBurgos, jbm (at) embention.com
///    Company:  Embention
///
///    Ttransfer class declaration.
///

#ifndef TTRANSFER_H_
#define TTRANSFER_H_

#include <Entypes.h>

namespace Base
{
    /// Tansfer methods from producer to consumer.
    /// Contract:
    /// TSRC has Itproducer behaviour.
    /// TDST has Iconsumer behaviour.
    template <typename TSRC, typename TDST>
    class Ttransfer
    {
    public:
        struct Until_full
        {
        public:
            static void transfer(TSRC& src, TDST& dst);

        private:
            Until_full(); ///< = delete
            Until_full(const Until_full& orig); ///< = delete
            Until_full& operator=(const Until_full& orig); ///< = delete
        };

        template <Uint16 n>
        struct Until_full_n
        {
        public:
            static void transfer(TSRC& src, TDST& dst);

        private:
            Until_full_n(); ///< = delete
            Until_full_n(const Until_full_n& orig); ///< = delete
            Until_full_n& operator=(const Until_full_n& orig); ///< = delete
        };

        struct All
        {
        public:
            static void transfer(TSRC& src, TDST& dst);

        private:
            All(); ///< = delete
            All(const All& orig); ///< = delete
            All& operator=(const All& orig); ///< = delete
        };

        template <Uint16 n>
        struct All_n
        {
        public:
            static void transfer(TSRC& src, TDST& dst);

        private:
            All_n(); ///< = delete
            All_n(const All_n& orig); ///< = delete
            All_n& operator=(const All_n& orig); ///< = delete
        };

    private:
        Ttransfer(); ///< = delete
        ~Ttransfer(); ///< disabled destructor
        Ttransfer(const Ttransfer& orig); ///< = delete
        Ttransfer& operator=(const Ttransfer& orig); ///< = delete
    };



    template <typename TSRC, typename TDST>
    inline void Ttransfer<TSRC,TDST>::Until_full::transfer(TSRC& src, TDST& dst)
    {
        typename TDST::type data = typename TDST::type();
        while(dst.wr_available() && src.read(data) && dst.write(data))
        {
        }
    }


    template <typename TSRC, typename TDST>
    template <Uint16 n>
    inline void Ttransfer<TSRC,TDST>::Until_full_n<n>::transfer(TSRC& src, TDST& dst)
    {
        typename TDST::type data = typename TDST::type();
        Uint16 i=0;
        while((n>i++) && dst.wr_available() && src.read(data) && dst.write(data))
        {
        }
    }


    template <typename TSRC, typename TDST>
    inline void Ttransfer<TSRC,TDST>::All::transfer(TSRC& src, TDST& dst)   //PRQA S 4283 #Can't define src as const
    {
        typename TDST::type data = typename TDST::type();
        while(src.read(data))
        {
            dst.write(data);
        }
    }


    template <typename TSRC, typename TDST>
    template <Uint16 n>
    inline void Ttransfer<TSRC,TDST>::All_n<n>::transfer(TSRC& src, TDST& dst)
    {
        typename TDST::type data = typename TDST::type();
        Uint16 i=0;
        while((n>i++) && src.read(data))
        {
            dst.write(data);
        }
    }

} // namespace Base

#endif // TTRANSFER_H_

