#ifndef U16STREAM_W_H_
#define U16STREAM_W_H_

#include <Mblock.h>
#include <Tmem.h>

namespace Base
{
    // JSF rule Rule 210 exception allows for endianness assumptions in marshalling (serialization).

    /// Uint16-base sized stream writer.
    /// Assumes little endian memory configuration.
    class U16stream_w
    {
    public:
        /// Data traits for 16-bit data type.
        struct Data_traits16 : public type_is<U16stream_w>
        {
            /// 16-bit Stream Writer 16-bit Memory Data Retriever.
            /// \wi{18134}
            /// Data_traits16 for U16stream_w structure shall be able to retrieve data 
            /// for a given 16-bit stream writer.
            /// \param[in] os   16-bit stream writer instance.
            /// \return Data storage in 16-bit memory block.
            static inline Mblock_u16& get_data(U16stream_w& os)
            {
                /// \alg
                /// - Return memory block value for the stream writer instance 
                /// calling to U16stream_w::to_mblock_all for received "os".
                return os.to_mblock_all();
            }

            /// 16-bit Stream Writer 16-bit Memory Size Updater.
            /// \wi{18135}
            /// Data_traits16 for U16stream_w structure shall be able to update size of the data 
            /// for the 16-bit stream writer.
            /// \param[in] os   16-bit stream writer instance.
            /// \param[in] sz   Size to be increased to 16-bit words.
            static inline void update_size(U16stream_w& os, Uint32 sz)
            {
                /// \alg
                /// - Call to U16stream_w::set_pos for received U16stream_w 
                /// increasing current size with received one.
                os.set_pos(os.get_pos() + sz);
            }

            /// 16-bit Stream Writer 16-bit Memory Maximum Size Retriever.
            /// \wi{18136}
            /// Data_traits16 for U16stream_w structure shall be able to retrieve maximum size
            /// of the data for the write 16-bit stream.
            /// \param[in] os   16-bit stream writer instance.
            /// \return Maximum size allowed for the 16-bit stream writer.
            static inline Uint16 get_max_size(U16stream_w& os)
            {
                /// \alg
                /// - Call U16stream_w::to_mblock_all::size for "os" and return the maximum size of memory block.
                return os.to_mblock_all().size();
            }

            /// 16-bit Stream Writer 16-bit Memory Position Retriever.
            /// \wi{18137}
            /// Data_traits16 for U16stream_w structure shall be able to retrieve position data in 16-bit type words
            /// for the 16-bit stream writer.
            /// \param[in] os   16-bit stream writer instance.
            /// \return Current position of the 16-bit stream writer.
            static inline Uint16 get_pos(U16stream_w& os)
            {
                /// \alg
                /// - Call to U16stream_w::get_pos for "os" to get the current position.
                return os.get_pos();
            }
        };

        /// 16-bit Stream Writer Constructor with Given Data Buffer.
        /// \wi{18138}
        /// U16stream_w class shall build itself upon construction with the provided parameter.
        /// \param[in] data0    Data buffer memory block.
        explicit U16stream_w(const Mblock<Uint16>& data0);

        /// 16-bit Stream Writer Memory Block Retriever.
        /// \wi{18139}
        /// U16stream_w shall be able to retrieve its already serialized memory block.
        /// \return Used memory block.
        Mblock<Uint16> to_mblock();   

        // TODO: Remove this when lossy is removed from Itunable.
        /// 16-bit Stream Writer All Memory Block Retriever.
        /// \wi{18109}
        /// U16stream_w shall be able to retrieve all its internal memory block data.
        /// \return All internal memory block.
        Mblock<Uint16>& to_mblock_all();    

        /// 16-bit Stream Writer Data Position Retriever.
        /// \wi{18140}
        /// U16stream_w class shall be able to retrieve its internal serializer position.
        /// \return Current write position.
        Uint32 get_pos() const;     

        /// 16-bit Stream Writer Data Position Setter.
        /// \wi{18141}
        /// U16stream_w class shall be able to set its internal serializer position.
        /// \param[in] pos  Stream position.
        void set_pos(Uint32 pos);   

        /// 16-bit Stream Writer Zero Position Setter.
        /// \wi{18142}
        /// U16stream_w class shall be able to set the internal position to zero.
        void reuse();                   

        /// 16-bit Stream Writer Boolean Serializer.
        /// \wi{18145}
        /// U16stream_w shall write the boolean value "v" as a 16-bit integer 
        /// to its internal stream and increment the position by 1.
        /// \param[in] v    Boolean value to be serialized.
        void put_bool16(bool v);    
        
        /// 16-bit Stream Writer Unsigned 16-bit Serializer.
        /// \wi{18146}
        /// U16stream_w shall write a given Uint16 value "v" 
        /// to its internal stream and increment the position by 1.
        /// \param[in] v    Uint16 value to be serialized.
        void put_uint16(Uint16 v);   
        
        /// 16-bit Stream Writer Signed int16 Serializer.
        /// \wi{18147}
        /// U16stream_w shall write a given int16 value "v" 
        /// to its internal stream and increment the position by 1.
        /// \param[in] v    int16 value to be serialized.
        void put_int16 (int16 v);    

        /// 16-bit Stream Writer Unsigned Uint32 Serializer.
        /// \wi{18148}
        /// U16stream_w shall write a given Uint32 value "v" 
        /// to its internal stream and increment the position by 2.
        /// \param[in] v    Uint32 value to be serialized.
        void put_uint32(Uint32 v);    
        
        /// 16-bit Stream Writer Signed int32 Serializer.
        /// \wi{18149}
        /// U16stream_w shall write a given int32 value "v" 
        /// to its internal stream and increment the position by 2.
        /// \param[in] v    int32 value to be serialized.
        void put_int32 (int32  v);    
       
        /// 16-bit Stream Writer Unsigned Uint64 Serializer.
        /// \wi{20210}
        /// U16stream_w shall write a given Uint64 value "v" 
        /// to its internal stream and increment the position by 4.
        /// \param[in] v    Uint64 value to be serialized.
        void put_uint64(Uint64 v);    
       
        /// 16-bit Stream Writer Signed int64 Serializer.
        /// \wi{18151}
        /// U16stream_w shall write a given int64 value "v" 
        /// to its internal stream and increment the position by 4.
        /// \param[in] v    int64 value to be serialized.
        void put_int64 (int64  v);    

        /// 16-bit Stream Writer Real 32-bit Serializer.
        /// \wi{18152}
        /// U16stream_w shall write a given 32-bit Real value "v" 
        /// to its internal stream and increment the position by 2.
        /// \param[in] v    32-bit value to be serialized.
        void put_float  (Real   v);   

        /// 16-bit Stream Writer Real 64-bit Serializer.
        /// \wi{18153}
        /// U16stream_w shall write a given 64-bit Real value "v" 
        /// to its internal stream and increment the position by 4.
        /// \param[in] v    64-bit value to be serialized.
        void put_float64(Real64 v);   

        /// 16-bit Stream Writer 16-bit Enumerator Serializer.
        /// \wi{18154}
        /// U16stream_w class shall be able to serialize 16 bits from the internal 
        /// stream of data and write them as a 16-bit given enumerator type value, incrementing position by 1.
        /// \param[in] v    16-bit value to be serialized.
        template<typename E>
        void put_enum16(E v);           

        /// 16-bit Stream Writer Memory Block Enumerator Serializer.
        /// \wi{18155}
        /// U16stream_w class shall be able to serialize a memory block, multiple of 16 bits, from the internal stream 
        /// of data and write them to a memory block given enumerator type value, incrementing the position by 1.
        /// \param[in] dst  Destination input stream to be serialized..
        template<typename T>
        void put(const Mblock<T>& dst);

        /// Policies are defined in Tuntraits.h
        /// 16-bit Stream Writer Put Type Serializer.
        /// \wi{18156}
        /// U16stream_w class shall provide a function to serialize an object following a given policy.
        /// \param[in] src  Element to be serialized.  
        template <typename POLICY>
        void put_t(const typename POLICY::type& src);

    private:
        Mblock<Uint16> data;        ///< Data buffer.
        Uint32 pos;                 ///< Current write position.

        /// 16-bit Stream Writer 16-bit Writer Previous.
        /// \wi{18917}
        /// U16stream_w class shall be able to write Uint16 
        /// memory block data and increment pos by 1.
        /// \param[in] v Current 16-bit input value.
        void write_prv(Uint16 v);   

        U16stream_w(const U16stream_w&);            ///< = delete.
        U16stream_w& operator=(const U16stream_w&); ///< = delete.
    };

    inline U16stream_w::U16stream_w(const Mblock<Uint16>& data0) :
        data(data0),
        pos(0)
    {
    }

    inline Mblock<Uint16> U16stream_w::to_mblock()
    {
        /// \alg
        /// - Call Mblock::sub_mblock_with_size for ::data with current write position 
        /// ::pos and return its sub-memory block.
        return data.sub_mblock_with_size(pos);
    }

    inline Mblock<Uint16>& U16stream_w::to_mblock_all()
    {
        /// \alg
        /// - Return a reference to the entire data block ::data.
        return data;
    }

    inline Uint32 U16stream_w::get_pos() const
    {
        /// \alg
        /// - Return a given write position ::pos.
        return pos;
    }

    inline void U16stream_w::set_pos(Uint32 pos0)
    {
        /// \alg
        /// <ul>
        /// <li> Set a given write position ::pos from the input index "pos0".
        /// </ul>
        pos = pos0;
    }

    inline void U16stream_w::reuse()
    {
        /// \alg
        /// <ul>
        /// <li> Reset a given write position ::pos to 0.
        /// </ul>
        pos = 0;
    }

    inline void U16stream_w::write_prv(Uint16 d)
    {
        /// \alg
        /// - Copy "d" to "data.v[pos++]".
        data.v[pos++] = d;
    }

    inline void U16stream_w::put_bool16(bool d)
    {
        /// \alg
        /// <ul>
        /// <li> Check Assertions::runtime, if a given write position ::pos incremented 
        /// by 1 is less than or equal to retrieved value by data::size. If within the valid range:
        if(Assertions::runtime((pos+1) <= data.sz))
        {
            /// <ul>
            /// <li> Call U16stream_w::write_prv for the input instance "d".
            /// </ul>
            write_prv(static_cast<Uint16>(d));
        }
        /// </ul>
    }

    inline void U16stream_w::put_uint16(Uint16 d)
    {
        /// \alg
        /// <ul>
        /// <li> Check Assertions::runtime, if a given write position ::pos incremented 
        /// by 1 is less than or equal to retrieved value by data::size. If within the valid range:
        if(Assertions::runtime((pos+1) <= data.sz))
        {
            /// <ul>
            /// <li> Call U16stream_w::write_prv for the input instance "d".
            /// </ul>
            write_prv(d);
        }
        /// </ul>
    }

    inline void U16stream_w::put_int16(int16 d)
    {
        /// \alg
        /// - Write the signed 16-bit value "d" by converting it to an 
        /// unsigned 16-bit value and call U16stream_w::put_uint16.
        put_uint16(static_cast<Uint16>(d));
    }

    inline void U16stream_w::put_uint32(Uint32 d)
    {
        /// \alg
        /// <ul>
        /// <li> Check Assertions::runtime, if a given write position ::pos incremented 
        /// by 2 is less than or equal to retrieved value by data::size. If within the valid range:
        if(Assertions::runtime((pos+Ku16::u2) <= data.sz))
        {
            /// <ul>
            /// <li> Call U16stream_w::write_prv to write Uint16 memory block data.
            write_prv(static_cast<Uint16>(d));
            /// <li> Call U16stream_w::write_prv to write Uint16 memory block data 
            /// shifted to the right specified in Ku16::u16.
            write_prv(static_cast<Uint16>(d >> Ku16::u16));
            /// </ul>
        }
        /// </ul>
    }

    inline void U16stream_w::put_int32(int32 d)
    {
        /// \alg
        /// - Call U16stream_w::put_uint32 to write the signed 32-bit value "d" 
        /// by converting it to an unsigned 16-bit value 
        /// and call U16stream_w::put_uint32.
        put_uint32(static_cast<Uint32>(d));
    }

    inline void U16stream_w::put_int64(int64 d)
    {
        /// \alg
        /// - Call U16stream_w::put_uint64 to write the signed 64-bit value "d" 
        /// by converting it to an unsigned 16-bit value 
        /// and call U16stream_w::put_uint64.
        put_uint64(static_cast<Uint64>(d));
    }

    inline void U16stream_w::put_float(Real d)
    {
        /// \alg
        /// - Call U16stream_w::put_uint32 to write the signed Real value "d" 
        /// by converting it to an unsigned 16-bit value 
        /// and call U16stream_w::put_uint32.
        put_uint32(*reinterpret_cast<Uint32*>(&d));
    }

    inline void U16stream_w::put_float64(Real64 d)
    {
        /// \alg
        /// - Call U16stream_w::put_uint64 to write the signed Real 64-bit 
        /// value by converting it to an unsigned 16-bit value 
        /// and call U16stream_w::put_uint64.
        put_uint64(*reinterpret_cast<Uint64*>(&d));
    }

    template<typename E>
    inline void U16stream_w::put_enum16(E v)
    {
        /// \alg
        /// <ul>
        /// <li> Check Assertions::Compile_time, if the size of given Enum "E" 
        /// is less than or equal to size of ::Uint16. If within the valid range:
        Assertions::Compile_time<sizeof(E) <= sizeof(Uint16)>();
        /// <ul>
        /// <li> Call U16stream_w::put_uint64 to write the enumerator value "v" 
        /// by converting it to unsigned 16-bit and call U16stream_w::put_uint16.
        /// </ul>
        put_uint16(static_cast<Uint16>(v));
        /// </ul>
    }

    template<typename T>
    inline void U16stream_w::put(const Mblock<T>& src)
    {
        /// Only multiple of 2 bytes are allowed.
        /// \alg
        /// <ul>
        /// <li> Check Assertions::Compile_time, if the least significant bit 
        /// of the size of the memory block is zero. If within the valid range:
        Assertions::Compile_time<(size_bytes_t<T>::value & 1) == 0>(); 
        const Uint32 sz = sizeof(T) * src.size();
        /// <li> Check Assertions::runtime, if a given write position ::pos plus size "sz"
        /// is less than or equal to retrieved value by data::size. If within the valid range:
        if(Assertions::runtime((pos+sz) <= data.sz))
        {
            /// <ul>
            /// <li> Call to Tmem::cpy_sel with v pointer of ::data plus ::pos, 
            /// v pointer of received source and size to be copied as parameters.
            Tmem::cpy_sel(data.v+pos, src.v, sz);
            /// <li> Add "size" with ::pos and copy it in ::pos.
            pos += sz;
            /// </ul>
        }
        /// </ul>
    }

    template <typename POLICY>
    inline void U16stream_w::put_t(const typename POLICY::type& src)
    {
        /// \alg
        /// <ul>
        /// <li> Call POLICY::elem2str and pass the source instance and this 
        /// U16stream_w instance as arguments.
        /// </ul>
        POLICY::elem2str(src, *this);
    }
}
#endif
