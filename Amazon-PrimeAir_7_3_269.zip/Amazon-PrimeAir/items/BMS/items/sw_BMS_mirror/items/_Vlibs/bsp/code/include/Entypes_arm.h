#ifndef ENTYPES_ARM_H__
#define ENTYPES_ARM_H__

#include <stdint.h>

#ifdef __TMS320C2000__
#error "This Entypes are NOT valid  for C2000 devices."
#endif

#define __attribute__(x) //SIL_CODE: SIL defines

//PRQA S 2300 EOF
//PRQA S 2400 EOF
typedef float               Real;
typedef double              Real64;
typedef char                int8;
typedef int16_t             int16;
typedef int32_t             int32;
typedef int64_t             int64;
typedef unsigned char       Uint8;
typedef uint16_t            Uint16;
typedef uint32_t            Uint32;
typedef uint64_t            Uint64;

typedef Uint16 NWord;                   ///< Native word for Veronte4

typedef Uint16 JSF119_word;             ///< Native word for current architecture. Used for JSF 119 rule

// Return the size of a a given type in bytes. this is the desired size, not the underlying size returned by sizeof.
template<typename T>
struct size_bytes_t
{
    static const Uint32 value = sizeof(T); // sizeof(uint8) returns 1, so we can use directly sizeof.
};

template<typename T>
inline Uint32 size_bytes(T)
{
    return size_bytes_t<T>::value;
};

inline void __or(int16* ptr, int16 val)
{
    (*ptr) |= val;
}

inline void __or(Uint16* ptr, int16 val)
{
    (*ptr) |= val;
}

inline void __inc(int16* ptr)
{
    (*ptr)++;
}

inline void __inc(Uint16* ptr)
{
    (*ptr)++;
}

inline Uint16 __disable_interrupts()
{
    Uint16 result = 0;  //This should be the current status of the Interrupt vector, and clear the interrupt vector.
    return result;
}

/// Retrieves the "idx"-nth byte pointed by ptr
inline Uint8 get_u8_impl(void* ptr, Uint32 idx)
{
    return (reinterpret_cast<Uint8*>(ptr))[idx];
}

/// Sets the "idx"-nth byte pointed by ptr
inline void set_u8_impl(void* ptr, Uint32 idx, Uint8 v)
{
    (reinterpret_cast<Uint8*>(ptr))[idx] = v;
}
#endif
