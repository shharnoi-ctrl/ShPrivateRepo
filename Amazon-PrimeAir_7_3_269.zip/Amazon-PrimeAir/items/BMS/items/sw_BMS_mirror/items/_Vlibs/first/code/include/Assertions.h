#ifndef ASSERTIONS_H_
#define ASSERTIONS_H_

#include <Warning.h>

namespace Base
{
    namespace Assertions
    {
        template<bool b>
        struct Compile_time;

        template<>
        struct Compile_time<true>
        {
        };

        inline bool runtime(bool b)
        {
            return Bsp::warning_assrt(b);
        }
    }
}
#endif
