#ifndef CYPHAL_CAN_OUT_H_
#define CYPHAL_CAN_OUT_H_

#include <Bitmask.h>
#include <Cyphal.h>
#include <Itconsumer.h>
#include <Itproducer_can.h>
#include <Timeout.h>
#include <U8pkfifospsc.h>

#include <Allocator_fw.h>

namespace Cyphal
{
    /// The Cyphal library shall provide a class to manage Cyphal CAN frames over CAN transport output implementation.
    /// - Accepts a stream of bytes and generates CAN frames.
    ///  -Note that the stream of bytes shall be composed as:
    /// - Start Byte (0xC1) - 1 Byte.
    /// - CyCAN_id          - CAN Id that is going to be used. 4 Bytes, little endian.
    /// - Payload Len       - Payload data length. 2 Bytes, little endian.
    class CyphalCAN_out : public Base::Itconsumer_u8, public Base::Itproducer_can
    {
    public:
        /// Cyphal CAN Out Constructor with Given Allocator and CAN Message Type Flag.
        /// \wi{21230}
        /// The CyphalCAN_out class shall build itself upon construction and initialize its internal members with given parameters.
        /// \param[in] alloc The allocator used for memory management.
        /// \param[in] use_fd Boolean flag indicating the CAN message type.
        CyphalCAN_out(Base::Allocator& alloc, bool use_fd);

        /// Cyphal CAN Out CAN Message Size Setter.
        /// \wi{21231}
        /// CyphalCAN_out class shall provide the capability to set the message 
        /// size based on the given CAN message type.
        /// \param[in] use_fd Boolean flag indicating the CAN message type, CAN-FD (True) or CAN2.0 (False).
        inline void set_use_fd(bool use_fd)
        {
            /// \alg
            /// - If given "use_fd" is True assign ::max_can_fd_sz byte size to ::max_can_sz.
            /// - Otherwise assign ::max_can_20_sz byte size to ::max_can_sz.
            max_can_sz = use_fd ? max_can_fd_sz : max_can_20_sz;
        }

        /// Cyphal CAN Out Write Availability Checker.
        /// \wi{21232}
        /// CyphalCAN_out class shall provide the capability to check if write action in FIFO is available.
        /// \return True if the writing action is available, otherwise False.
        virtual inline bool wr_available() const
        {
            /// \alg
            /// - Return the retrieved boolean by U8pkfifospsc::wr_available for ::out_fifo.
            return out_fifo.wr_available();
        }

        /// Cyphal CAN Out Data Element Writer.
        /// \wi{21233}
        /// CyphalCAN_out class shall provide the capability to write the given data into the FIFO. 
        /// \param[in] d Data byte to write.
        /// \return True if the writing is successful, otherwise False.
        virtual inline bool write(Uint8 d)
        {
            /// \alg
            /// - Return the retrieved boolean by U8pkfifospsc::write for ::out_fifo with given "d".
            return out_fifo.write(d);
        }

        /// Cyphal CAN Out Data Element Reader.
        /// \wi{21234}
        /// CyphalCAN_out class shall provide the capability to read data produced.
        /// \param[out] frame The frame to store the read data.
        /// \return True if data is successfully read, otherwise False.
        virtual bool read(Base::Itproducer_can::type_prod& frame);
        
        /// Cyphal CAN Out Number of Transmission Errors Retriever.
        /// \wi{21235}
        /// CyphalCAN_out class shall provide the capability to retrieve the number of transmission errors.
        /// \return The number of transmission errors.
        inline Uint32 get_nerrors()
        {
            /// \alg
            /// - Return ::n_errors.
            return n_errors;
        }

        /// Cyphal CAN Out Transmission Error Resetter.
        /// \wi{21236}
        /// CyphalCAN_out class shall provide the capability to reset the number of transmission errors.
        inline void reset_nerrors()
        {
            /// \alg
            /// - Assign 0 to ::n_errors.
            n_errors = 0;
        }

    private:
        /// Max data size for CAN-2.0 messages.
        static const Uint16 max_can_20_sz = Base::CANdata::length_max_std-1;
        /// Max data size for CAN-FD messages.
        static const Uint16 max_can_fd_sz = Base::CANdata::length_max_fd-1;
        
        Uint16 max_can_sz;          ///< Max actual data size for CAN frames.

        Base::U8pkfifospsc out_fifo;///< Output byte fifo.

        bool transfer_started;      ///< Indicates if a transfers has been started.
        Uint16 pl_size;             ///< Payload size.
        Uint16 extra_size;          ///< Extra size, due to padding and/or CRC.
        Uint16 pending_bytes;       ///< Number of pending bytes to be generated.
        Tail_byte curr_tb;          ///< Current tail-byte. Updated across transfers.
        
        CyCAN_id cy_can_id;         ///< Cyphal type of the CAN Id.
        bool needs_crc;             ///< Indicates if the transmission needs a CRC.
        Base::CRC crc16;            ///< Cyphal CRC commputer.

        Uint32 n_errors;            ///< Number of errors found.

        CyphalCAN_out(const CyphalCAN_out&);            ///< = delete.
        CyphalCAN_out& operator=(const CyphalCAN_out&); ///< = delete.
    };
}
#endif
