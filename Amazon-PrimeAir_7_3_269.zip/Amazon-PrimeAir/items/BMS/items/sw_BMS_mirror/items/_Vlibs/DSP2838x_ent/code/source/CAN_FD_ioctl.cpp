#include <CAN_FD_ioctl.h>
#include <Asm.h>
#include <CAN_FD.h>
#include <CAN_FD_cfg.h>
#include <Ptr_cast.h>

#include "CAN_FD_regs.h"
#include "Cpusys.h"     //PRQA S 1015

namespace Dsp28335_ent
{
    namespace
    {
        static const Uint32 mcan_std_id_filter_num = 128U;                      // 128*1 = 128 32bit-words
        static const Uint32 mcan_ext_id_filter_num = 64U;                       //  64*2 = 128 32bit-words
    }

    /// CAN-FD configuration lock.
    /// Dsp2838x_ent library shall provide a method to lock or unlock the MCAN configuration.
    /// \wi{12673}
    /// \param base_address Base address of the MCAN peripheral.
    /// \param lock         Boolean to lock(1) or unlock(0) the configuration registers.
    void set_mcan_cfg_lock(const Uint32 base_address, bool lock)
    {
        /// \alg Set the field "CCE" of the register MCAN CCCR to the opposite value of "lock".
        MCAN::CCCR cccr_reg = MCAN::read_reg<MCAN::CCCR>(base_address + MCAN::mcan_cccr);
        cccr_reg = MCAN::read_reg<MCAN::CCCR>(base_address + MCAN::mcan_cccr);
        cccr_reg.cce = !lock;
        MCAN::write_reg(base_address + MCAN::mcan_cccr, cccr_reg.all);
    }

    /// CAN-FD Peripheral Initialization.
    /// Dsp2838x_ent library shall provide a method to enable or disable the CAN-FD mode and the BRS mode.
    /// \wi{12674}
    /// \param base_address Base address of the MCAN peripheral.
    /// \param can_fd_mode  Flag to enable or disable the CAN-FD mode.
    /// \param brs          Flag to enable or disable the BRS mode.
    void init_mcan(const Uint32 base_address,
                   bool can_fd_mode,
                   bool brs)
    {
        /// \alg
        /// - Wait till MCAN memory initialization finishes.
        while(!MCAN::read_reg<MCAN::SS_STAT>(base_address + MCAN::mcanss_stat).mem_init_done)
        {
        }

        /// - Put MCAN in SW initialization mode.
        MCAN::CCCR cccr_reg = MCAN::read_reg<MCAN::CCCR>(base_address + MCAN::mcan_cccr);
        cccr_reg.init = 1;
        MCAN::write_reg(base_address + MCAN::mcan_cccr, cccr_reg.all);

        /// - Wait till MCAN is not initialized.
        while(MCAN::read_reg<MCAN::CCCR>(base_address + MCAN::mcan_cccr).init != true)
        {
        }

        /// - Unlock configuration by calling ::set_mcan_cfg_lock.
        set_mcan_cfg_lock(base_address, false);

        // Initialize MCAN module.
        {
            // Configure MCAN wakeup and clock stop controls
            MCAN::SS_CTRL ssctrl_reg = MCAN::read_reg<MCAN::SS_CTRL>(base_address + MCAN::mcanss_ctrl);
            ssctrl_reg.dbgsusp_free = true;
            MCAN::write_reg(base_address + MCAN::mcanss_ctrl, ssctrl_reg.all); // all zeros

            /// - Configure MCAN mode = "can_fd_mode" parameter.
            /// - Configure CAN-FD and BRS: "brs" parameter.
            cccr_reg = MCAN::read_reg<MCAN::CCCR>(base_address + MCAN::mcan_cccr);
            cccr_reg.fdoe = can_fd_mode;
            cccr_reg.brse = brs;
            MCAN::write_reg(base_address + MCAN::mcan_cccr, cccr_reg.all);

            // Configure Transceiver Delay Compensation
            MCAN::TDCR tdcr_reg = MCAN::read_reg<MCAN::TDCR>(base_address + MCAN::mcan_tdcr);
            tdcr_reg.tdcf = 0xAU;
            tdcr_reg.tdco = 0x6U;
            MCAN::write_reg(base_address + MCAN::mcan_tdcr, tdcr_reg.all);
            /// - Disable Transceiver Delay Compensation
            MCAN::DBTP dbtp_reg = MCAN::read_reg<MCAN::DBTP>(base_address + MCAN::mcan_dbtp);
            dbtp_reg.tdce = false;
            MCAN::write_reg(base_address + MCAN::mcan_dbtp, dbtp_reg.all);

            /// - Configure MSG RAM watchdog counter preload value as zero.
            MCAN::RWD rwd_reg = MCAN::read_reg<MCAN::RWD>(base_address + MCAN::mcan_rwd);
            rwd_reg.wdc = 0U;
            MCAN::write_reg(base_address + MCAN::mcan_rwd, tdcr_reg.all);
        }

        /// - Configure global Config parameters to discard filtered messages.
        {
            static const Uint16 gf_reject_non_matching = 2U;
            MCAN::GFC reg = MCAN::read_reg<MCAN::GFC>(base_address + MCAN::mcan_gfc);
            reg.rrfe = true;
            reg.rrfs = true;
            reg.anfe = gf_reject_non_matching;
            reg.anfs = gf_reject_non_matching;
            MCAN::write_reg(base_address + MCAN::mcan_gfc, reg.all);
        }

        /// - Lock MCAN configuration.
        set_mcan_cfg_lock(base_address, true);
    }

    /// CAN-FD Peripheral Initialization.
    /// Dsp2838x_ent library shall provide a method to set the nominal and data timings.
    /// \wi{12675}
    /// \param base_address Base address of the MCAN peripheral.
    /// \param nom_t  Nominal timings.
    /// \param data_t Data timings.
    void config_bdrt(const Uint32 base_address,
                     const CAN_FD_cfg::Timings& nom_t,
                     const CAN_FD_cfg::Timings& data_t)
    {
        /// \alg
        /// - Unlock configuration
        set_mcan_cfg_lock(base_address, false);

        { /// - Configure Nominal timings
            MCAN::NBTP reg = MCAN::read_reg<MCAN::NBTP>(base_address + MCAN::mcan_nbtp);
            reg.nbrp   = nom_t.prescaler;   // Nominal Baud Rate Pre-scaler.
            reg.ntseg1 = nom_t.tseg1;       // Nominal Time segment before SP
            reg.ntseg2 = nom_t.tseg2;       // Nominal Time segment after SP
            reg.nsjw   = nom_t.sjw;         // Nominal SJW
            MCAN::write_reg(base_address + MCAN::mcan_nbtp, reg.all);
        }

        { /// - Configure Data timings
            MCAN::DBTP reg = MCAN::read_reg<MCAN::DBTP>(base_address + MCAN::mcan_dbtp);
            reg.dbrp   = data_t.prescaler;  // Data Baud Rate Pre-scaler.
            reg.dtseg1 = data_t.tseg1;      // Data Time segment before SP
            reg.dtseg2 = data_t.tseg2;      // Data Time segment after SP
            reg.dsjw   = data_t.sjw;        // Data SJW
            MCAN::write_reg(base_address + MCAN::mcan_dbtp, reg.all);
        }
        /// - Lock configuration
        set_mcan_cfg_lock(base_address, true);
    }

    /// CAN-FD Memory Configuration.
    /// Dsp2838x_ent library shall provide a method to configure the peripheral memory distribution to have:
    ///  - 128 Standard filters.
    ///  -  64 Extended filters.
    ///  -  32 Element output prioritized queue.
    ///  -  64 Element input FIFO.
    /// \wi{12676}
    /// \param base_address Base address of the MCAN peripheral.
    void config_memory(const Uint32 base_address)
    {
        static const Uint16 mcan_elem_size_64bytes = 7U;

        static const Uint16 addr_f = 2U;
        static const Uint32 mcan_fifo_0_num        = 64U;
        static const Uint32 mcan_fifo_0_elem_size  = mcan_elem_size_64bytes;    // 64*18 = 1152 32bit-words
        static const Uint32 mcan_fifo_1_num        = 64U;
        static const Uint32 mcan_fifo_1_elem_size  = mcan_elem_size_64bytes;
        static const Uint32 mcan_rx_buff_num       = 0U;
        static const Uint32 mcan_tx_buff_size      = 32U;                       // 32*18 = 576 32bit-words
        static const Uint32 mcan_tx_buff_elem_size = mcan_elem_size_64bytes;
        static const Uint32 mcan_tx_event_size     = 32U;

        static const Uint32 mcanss_std_id_filter_size_word = 1U;
        static const Uint32 mcanss_ext_id_filter_size_word = 2U;
        static const Uint32 msg64_object_size = 18U;   // Size for a message of 64bytes. Cahnge if elem_size becomes different than 64.

        static const Uint32 mcan_std_id_filt_start_addr = 0x0U;
        static const Uint32 mcan_ext_id_filt_start_addr = mcan_std_id_filt_start_addr + ((mcan_std_id_filter_num * mcanss_std_id_filter_size_word * 4U));
        static const Uint32 mcan_fifo_0_start_addr      = mcan_ext_id_filt_start_addr + ((mcan_ext_id_filter_num * mcanss_ext_id_filter_size_word * 4U));
        static const Uint32 mcan_fifo_1_start_addr      = mcan_fifo_0_start_addr  + (msg64_object_size * 4U * mcan_fifo_0_num);
        static const Uint32 mcan_rx_buff_start_addr     = mcan_fifo_1_start_addr  + (msg64_object_size * 4U * mcan_fifo_1_num);
        static const Uint32 mcan_tx_buff_start_addr     = mcan_rx_buff_start_addr + (msg64_object_size * 4U * mcan_rx_buff_num);
        static const Uint32 mcan_tx_event_start_addr    = mcan_tx_buff_start_addr + (msg64_object_size * 4U * mcan_tx_buff_size);

        /// \alg
        /// - Unlock configuration
        set_mcan_cfg_lock(base_address, false);

        /// - Configure Standard Message Filters section
        {
            MCAN::SIDFC reg = MCAN::read_reg<MCAN::SIDFC>(base_address + MCAN::mcan_sidfc);
            reg.flssa = mcan_std_id_filt_start_addr >> addr_f;  // Standard ID Filter List Start Address
            reg.lss   = mcan_std_id_filter_num;                 // Standard ID Filter Size
            MCAN::write_reg(base_address + MCAN::mcan_sidfc, reg.all);
        }
        /// - Configure Extended Message Filters section
        {
            MCAN::XIDFC reg = MCAN::read_reg<MCAN::XIDFC>(base_address + MCAN::mcan_xidfc);
            reg.flesa = mcan_ext_id_filt_start_addr >> addr_f;  // Extended ID Filter List Start Address
            reg.lse   = mcan_ext_id_filter_num;                 // Extended ID Filter Size
            MCAN::write_reg(base_address + MCAN::mcan_xidfc, reg.all);
        }
        /// - Configure Rx FIFO 0 section
        {
            MCAN::RXFxC reg = MCAN::read_reg<MCAN::RXFxC>(base_address + MCAN::mcan_rxf0c);
            reg.fxsa = mcan_fifo_0_start_addr >> addr_f;    // Rx FIFO0 Start Address.
            reg.fxs  = mcan_fifo_0_num;                     // Number of Rx FIFO0 elements
            reg.fxwm = 0U;                                  // Rx FIFO0 watermark
            reg.fxom = 0U;                                  // FIFO blocking mode.
            MCAN::write_reg(base_address + MCAN::mcan_rxf0c, reg.all);
        }
        /// - Configure Rx FIFO 1 section
        {
            MCAN::RXFxC reg = MCAN::read_reg<MCAN::RXFxC>(base_address + MCAN::mcan_rxf1c);
            reg.fxsa = mcan_fifo_1_start_addr >> addr_f;    // Rx FIFO1 Start Address.
            reg.fxs  = mcan_fifo_1_num;                     // Number of Rx FIFO1 elements
            reg.fxwm = 0U;                                  // Rx FIFO1 watermark
            reg.fxom = 0U;                                  // FIFO blocking mode.
            MCAN::write_reg(base_address + MCAN::mcan_rxf1c, reg.all);
        }
        /// - Configure Rx FIFO elements sizes
        {
            MCAN::RXESC reg = MCAN::read_reg<MCAN::RXESC>(base_address + MCAN::mcan_rxesc);
            reg.f0ds = mcan_fifo_0_elem_size;   // RX FIFO 0 element size
            reg.f1ds = mcan_fifo_1_elem_size;   // RX FIFO 1 element size
            reg.rbds = 0U;                      // No Rx Buffer used
            MCAN::write_reg(base_address + MCAN::mcan_rxesc, reg.all);
        }
        /// - Configure Rx Buffer Start Address
        {
            MCAN::RXBC reg = MCAN::read_reg<MCAN::RXBC>(base_address + MCAN::mcan_rxbc);
            reg.rbsa = mcan_rx_buff_start_addr >> addr_f;
            MCAN::write_reg(base_address + MCAN::mcan_rxbc, reg.all);
        }
        /// - Configure Tx Buffer Start Address
        {
            MCAN::TXBC reg = MCAN::read_reg<MCAN::TXBC>(base_address + MCAN::mcan_txbc);
            reg.tbsa = mcan_tx_buff_start_addr >> addr_f;
            reg.ndbt = 0U;                  // No dedicated buffers
            reg.tfqs = mcan_tx_buff_size;
            reg.tfqm = 0U;                  // FIFO blocking mode.
            MCAN::write_reg(base_address + MCAN::mcan_txbc, reg.all);
        }
        /// - Configure Tx Event FIFO section
        {
            MCAN::TXEFC reg = MCAN::read_reg<MCAN::TXEFC>(base_address + MCAN::mcan_txefc);
            reg.efsa = mcan_tx_event_start_addr >> addr_f;
            reg.efs  = mcan_tx_event_size;
            reg.efwm = 0UL;
            MCAN::write_reg(base_address + MCAN::mcan_txefc, reg.all);
        }
        /// - Configure Tx Buffer/FIFO0/FIFO1 elements size
        {
            MCAN::TXESC reg = MCAN::read_reg<MCAN::TXESC>(base_address + MCAN::mcan_txesc);
            reg.tbds = mcan_tx_buff_elem_size;
            MCAN::write_reg(base_address + MCAN::mcan_txesc, reg.all);
        }
        /// - Lock configuration
        set_mcan_cfg_lock(base_address, true);
    }

    /// CAN-FD Input Filter Configuration.
    /// Dsp2838x_ent library shall provide a method to configure the peripheral input filters.
    /// \wi{12677}
    /// \param base_address Base address of the MCAN peripheral.
    /// \param rx_cfg       Input filters configuration.
    bool config_rx_filters(const Uint32 base_address, const CANcfg::Trx_array& rx_cfg)
    {
        static const Uint16 addr_f = 2U;    // Address conversion factor.
        static const Uint16 sf_size = 1U;   // Standard filter element size.
        static const Uint16 ef_size = 2U;   // Extended filter element size.
        Uint16 std_idx = 0;
        Uint16 ext_idx = 0;

        /// \alg
        /// - Set result to true.
        bool res = true;
        /// - Unlock configuration
        set_mcan_cfg_lock(base_address, false);

        /// - For each element in the configuration <ul>
        for(Uint32 i=0; i<rx_cfg.size(); i++ )
        {
            const CANcfg::Rxcfg& cfg = rx_cfg[i];
            /// <li> if it is a extended Id filter and there is room for it.
            ///   - Add the filter to the peripheral extended filters.
            if(cfg.flt.id.extended && (ext_idx < mcan_ext_id_filter_num))
            {
                MCAN::XIDFC reg = MCAN::read_reg<MCAN::XIDFC>(base_address + MCAN::mcan_xidfc);
                const Uint32 start_addr = MCAN::read_reg<MCAN::XIDFC>(base_address + MCAN::mcan_xidfc).flesa << addr_f;
                const Uint32 elem_addr = MCAN::mcan_msg_mem + start_addr + ((ext_idx * ef_size) << addr_f);
                const MCAN::Ext_filter0 filt0 =
                {
                    cfg.flt.id.id,  // Filter ID
                    2U              // 010 = Store in Rx FIFO 1 if filter matches
                };
                const MCAN::Ext_filter1 filt1 =
                {
                    cfg.flt.msk,    // Filter Mask
                    0U,
                    2U              //  10 = Classic filter: EFID1 = filter, EFID2 = mask
                };
                MCAN::write_reg(base_address + elem_addr,      filt0.all);
                MCAN::write_reg(base_address + elem_addr + 4U, filt1.all);
                ext_idx++;
            }
            /// <li> Else, if there is room for a standard filter.
            ///   - Add the filter to the peripheral standard filters.
            else if(std_idx < mcan_std_id_filter_num)
            {
                MCAN::SIDFC reg = MCAN::read_reg<MCAN::SIDFC>(base_address + MCAN::mcan_sidfc);
                const Uint32 start_addr = MCAN::read_reg<MCAN::SIDFC>(base_address + MCAN::mcan_sidfc).flssa << addr_f;
                const Uint32 elem_addr = MCAN::mcan_msg_mem + start_addr + ((std_idx * sf_size) << addr_f);
                const MCAN::Std_filter filt =
                {
                    cfg.flt.msk,        // Mask. A 0 in any bit-position indicates "don't care"
                    0U,                 // reserved
                    cfg.flt.id.id,      // Filter ID
                    2U,                 // 010 = Store in Rx FIFO 1 if filter matches
                    2U                  //  10 = Classic filter: EFID1 = filter, EFID2 = mask
                };
                MCAN::write_reg(base_address + elem_addr, filt.all);
                std_idx++;
            }
            else /// <li> Else, set result to false.
            {
                Bsp::warning();
                res = false;
            }
        } /// </ul>

        /// - Lock configuration
        set_mcan_cfg_lock(base_address, true);

        /// - Return result.
        return res;
    }

    /// CAN-FD Set Normal Mode.
    /// Dsp2838x_ent library shall put the peripheral in normal mode.
    /// \wi{12678}
    /// \param base_address Base address of the MCAN peripheral.
    void set_mcan_mode_normal(const Uint32 base_address)
    {
        /// \alg
        /// - Set the field "INIT" of the register MCAN CCCR to false.
        // Take MCAN out of the SW initialization mode
        MCAN::CCCR cccr_reg = MCAN::read_reg<MCAN::CCCR>(base_address + MCAN::mcan_cccr);
        cccr_reg.init = 0;
        MCAN::write_reg(base_address + MCAN::mcan_cccr, cccr_reg.all);
        /// - Wait for field "INIT" of the register MCAN CCCR to become false.
        while(MCAN::read_reg<MCAN::CCCR>(base_address + MCAN::mcan_cccr).init == true)
        {
        }
    }

    // NOTE:
    // Tx is using a queue (with priorities for sending).
    // Rs is using FIFO1
    bool CAN_FD_ioctl::config(CAN_FD& can, const CAN_FD_cfg& cfg)
    {
        /// ### Default timings for 200Mhz clock:
        /// | Baudrate| Prescaler | TSEG1 | TSEG2 | SJW |
        /// |---------|-----------|-------|-------|-----|
        /// |  100Khz |   99      |   9   |   8   |  8  |
        /// |  200Khz |   49      |   9   |   8   |  7  |
        /// |  250Khz |   39      |  10   |   7   |  7  |
        /// |  500Khz |   49      |   4   |   1   |  1  |
        /// |  800Khz |   24      |   6   |   1   |  0  |
        /// |  1Mhz   |   24      |   4   |   1   |  1  |
        /// |  2Mhz   |    9      |   5   |   2   |  2  |
        /// |  4Mhz   |    1      |  13   |   9   |  9  |
        /// |  5Mhz   |    4      |   4   |   1   |  1  |
        static const CAN_FD_cfg::Timings tmgs[CAN_FD_cfg::baudrate_count] = // @200Mhz clk
        {
             { 99,  9, 8, 8 },  // 100Khz
             { 49,  9, 8, 7 },  // 200Khz
             { 39, 10, 7, 7 },  // 250Khz

             { 49,  4, 1, 1 },  // 500Khz/ 75% sampling point
             { 24,  6, 1, 0 },  // 800Khz/ 80% sampling point
             { 24,  4, 1, 1 },  // 1Mhz  / 75% sampling point
             {  9,  5, 2, 2 },  // 2Mhz  / 70% sampling point
             {  1, 13, 9, 9 },  // 4Mhz  / 60% sampling point
             {  4,  4, 1, 1 }   // 5Mhz  / 75% sampling point
        };

        /// \alg
        bool res = true; /// - Set result to true.

        /// - If nominal configuration has "use_timings", set nominal timings from configuration.
        /// - Else set nominal timings from default timings table.
        const CAN_FD_cfg::Timings nom_t  = cfg.arb.use_timings ? cfg.arb.tim : tmgs[cfg.arb.bdrt];

        /// - Set data timings equal to nominal timings.
        CAN_FD_cfg::Timings data_t = nom_t;//cfg.enable_brs ? tmgs[cfg.dat.bdrt+CAN_FD_cfg::bda_1M] : tmgs[cfg.nom.bdrt];

        /// - If CAN-FD mode and BRS are enabled.<ul>
        if(cfg.can_fd_mode && cfg.enable_brs)
        {
            /// <li> If data configuration has "use_timings", set data timings from configuration.
            /// <li> Else set data timings from default timings table.
            data_t = cfg.data.use_timings ? cfg.data.tim : tmgs[cfg.data.bdrt];
        } /// </ul>

        /// - if CAN-FD is enabled, BRS is enabled and custom timings are not being used.
        ///   - Set result to true if nominal baudrate >= 500Khz.
        if( (cfg.arb.use_timings == false) &&
            (cfg.data.use_timings == false) &&
             cfg.can_fd_mode && cfg.enable_brs)
        {
            res = (cfg.arb.bdrt >= CAN_FD_cfg::bd_500K);
        }
        if(res) /// - If result is ok. <ul>
        {
            /// <li> Configure the divisor for the MCAN bit-clock to 200/1 = 200 Mhz
            {
                // Clears the divider then configures it.
                static const Uint32 clkcfg_base = 0x0005D200UL;
                static const Uint32 sysctl_o_auxclkdivsel = 0x24U;  // Auxillary Clock Divider Select register
                static const Uint16 mcan_offset = 8U;
                static const Uint16 mcan_clk_mask = Base::Bitutils::get_mask_lsb<Uint16>(mcan_offset);
                static const Uint16 mcan_clk_div = 1U - 1U; // Divisor value - 1
                asm_eallow();
                Uint16 auxclkdivsel = Base::get_mem<Uint16>(clkcfg_base + sysctl_o_auxclkdivsel);
                auxclkdivsel &= mcan_clk_mask;
                auxclkdivsel |= (mcan_clk_div << mcan_offset);
                Base::get_mem<Uint16>(clkcfg_base + sysctl_o_auxclkdivsel) = auxclkdivsel;
                asm_edis();
            }

            const Uint32 base_addr = Base::pt2addr(&can.impl);
            /// <li> Initialize MCAN peripheral by calling ::init_mcan.
            init_mcan(base_addr, cfg.can_fd_mode, cfg.enable_brs);
            /// <li> Configure MCAN baudrate by calling ::config_bdrt.
            config_bdrt(base_addr, nom_t, data_t);
            /// <li> Configure MCAN message memory distribution by calling ::config_memory.
            config_memory(base_addr);
            /// <li> Configure MCAN input filters by calling ::config_rx_filters and set result to its return value.
            res = config_rx_filters(base_addr, cfg.rx_cfg);
            /// <li> Set MCAN operation mode to "normal" to start communications.
            set_mcan_mode_normal(base_addr);

            /// <li> Set CAN-FD internal variables using data from configuration: <ul>
            ///   <li> BRS: cfg.enable_brs.
            ///   <li> CAN-FD Mode: cfg.can_fd_mode.
            ///   <li> Fifo size: 64.
            /// </ul>
            can.brs = cfg.enable_brs;
            can.canfd_mode = cfg.can_fd_mode;
            can.fifo_sz = MCAN::read_reg<MCAN::RXFxC>(base_addr + MCAN::mcan_rxf1c).fxs;
        } /// </ul>
        return res;
    }
}
