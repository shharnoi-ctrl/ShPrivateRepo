#ifndef ALLOCATOR_FW_H
#define ALLOCATOR_FW_H

namespace Base
{
    class Allocator;
}
#endif

