#ifndef RTABLE_H__
#define RTABLE_H__

#include <Wrapper.h>
#include <Xrtable.h>
#include <Rvector.h>
#include <Rtable_fw.h>
#include <Mblock.h>

namespace Maverick
{

    /// Map a list of (X sorted) values to vectors.
    class Rtable
    {
    public:
        /// Templated Real Interpolation Table Constructor with Given Xtrtable.
        /// \wi{3248}
        /// Rtable class shall build itself upon construction and initialize the data stored in the Xrtable.
        /// \param[in] xrt  Xrtable object used as input.
        template <Uint32 nrows, Uint32 ncols>
        explicit Rtable(const Base::Xrtable<nrows, ncols>& xrt);
        
        /// Real Interpolation Table Constructor with Given Memory Block.
        /// \wi{3247}
        /// Rtable class shall build itself upon construction with a memory block  of Real x and y values.
        /// \param[in] xin Memory block containing Real x values.
        /// \param[in] yin Memory block containing Real y values.
        Rtable(const Base::Mblock<const Real> xin,
               const Base::Mblock<const Real> yin);

        /// Real Interpolation Table Number of Interpolation Points Retriever.
        /// \wi{3250}
        /// Rtable shall provide a method to retrieve the total number of entries 
        /// (number of interpolation points, or breakpoints) in the interpolation table.
        /// \pre Non-blocking call as only read pointer gets the value.
        /// \return Number of entries in the Real Interpolation Table.
        Uint32 get_nentries() const;

        /// Real Interpolation Table Wrapping within Interpolation Points Interval.
        /// \wi{3249}
        /// Rtable class provides a method to wrap an input real value 
        /// within the limits defined by the x values in the interpolation table.
        /// \param[in] xi Input real value to be wrapped within the x value limits. 
        /// Upon function completion, this value may be modified if it falls outside the limits.
        /// \return True if the input value has been modified to fit within the x value limits, False otherwise.
        bool wrap_x(Real& xi) const;

        /// Real Interpolation Table Lower Boundary within Interpolation Points Checker.
        /// \wi{3251}
        /// Rtable class provides a method to check if an input real value falls 
        /// within the lower boundary defined by the x values in the interpolation table.
        /// \param[in] xi Input Real value to be checked.
        /// \return True if the input value is within the lower boundary, False otherwise.
        bool is_lower_bound(Real xi) const;

        /// Real Interpolation Table Upper Boundary within Interpolation Points Checker.
        /// \wi{3252}
        /// Rtable class provides a method to check if an input real value falls 
        /// within the upper boundary defined by the x values in the interpolation table.
        /// \param[in] xi Input Real value to be checked.
        /// \return True if the input value is within the upper boundary, False otherwise.
        bool is_upper_bound(Real xi) const;

        /// Real Interpolation Table Linear Interpolation with Extrapolation for Given Rvector and Real Value.
        /// \wi{3093}
        /// Rtable class provides a method to perform linear interpolation on 
        /// the given Rvector 'yi' for the interpolation x Real value 'xi'.
        /// It extrapolates values if the input 'xi' is out of range.
        /// \param[in] xi Interpolation x Real value.
        /// \param[in,out] yi Interpolated y Rvector. Upon function completion, 
        /// 'yi' will contain the interpolated values.
        void interp1_linear_extrapolate(Real xi,Rvector& yi) const;

        /// Real Interpolation Table Linear Interpolation with Extrapolation for Given Real Values.
        /// \wi{19037}
        /// Rtable class provides a method to perform linear interpolation on the 
        /// given y Real value 'y' for the interpolation x Real value 'xi'.
        /// It extrapolates values if the input 'xi' is out of range.
        /// \param[in] xi Interpolation x Real value.
        /// \param[in,out] y Interpolated y Real value. Upon function completion, 
        /// 'y' will contain the interpolated value.
        void interp1_linear_extrapolate(Real xi,Real& y)const;
     
        /// Real Interpolation Table Linear Interpolation for Given Rvector and Real Value.
        /// \wi{3091}
        /// Rtable class provides a method to perform linear interpolation on the 
        /// given Rvector 'yi' for the interpolation x Real value 'xi'.
        /// \param[in] xi Interpolation x Real value.
        /// \param[in,out] yi Interpolated y Rvector. Upon function completion,
        /// 'yi' will contain the interpolated values.
        /// \return True if the interpolation results in extrapolation 
        /// ('xi' is outside the range of x values in the table), False otherwise.
        bool interp1_linear(Real xi,Rvector& yi) const;

        /// Real Interpolation Table Linear Interpolation for Given Real Values.
        /// \wi{19038}
        /// Rtable class provides a method to perform linear interpolation on the 
        /// given y Real value 'y' for the interpolation x Real value 'xi'.
        /// \param[in] xi Interpolation x Real value.
        /// \param[in,out] y Interpolated y Real value. Upon function completion, 
        /// 'y' will contain the interpolated value.
        /// \return True if the interpolation results in extrapolation 
        /// ('xi' is outside the range of x values in the table), False otherwise.
        bool interp1_linear(Real xi,Real& y)const;

        /// Real Interpolation Table Linear Interpolation and Extrapolation for Single x Value at Index k.
        /// \wi{3094}
        /// Rtable class provides a method to perform linear interpolation 
        /// and extrapolation for a single x value 'xi' at index 'k' of the y vector.
        /// If 'extrapolate' is true and 'yi' is out of range, extrapolation is performed.
        /// \param[in] k Index of the vector y.
        /// \param[in] yi Real value of vector y at index k.
        /// \param[in,out] xi Interpolated x Real value. Upon function completion, 
        /// 'xi' will contain the interpolated or extrapolated value.
        /// \param[in] extrapolate Flag indicating whether to extrapolate values if 'yi' is out of range.
        void interp1_linear_1(Uint16 k,
                              const Real& yi,
                              Real& xi,
                              bool extrapolate)const;

        /// Real Interpolation Table Binary Search for x Value Index.
        /// \wi{3097}
        /// Rtable class provides a method to perform a binary search to 
        /// find the index of the 'x' value in the interpolation table.
        /// \param[in] xi Real value to search for.
        /// \return Index of the x value in the table.
        Uint32 xi_search(const Real xi) const;

        /// Real Interpolation Table Binary Search for y Value Index at Index k.
        /// \wi{3098}
        /// Rtable class provides a method to perform a binary search to 
        /// find the index of the 'y' value within the y vector at index 'k'.
        /// \param[in] k Index of the y vector.
        /// \param[in] yi Real value to search for within the y vector at index k.
        /// \return Index of the y value within the y vector index k.
        Uint32 yi_search(Uint16 k,Real yi) const;

        /// Real Interpolation Table Interpolation with Previous x Value.
        /// \wi{3096}
        /// Rtable class provides a method to retrieve the y values 
        /// corresponding to the x value immediately preceding the interpolation x value 'xi'.
        /// \param[in] xi Interpolation x Real value.
        /// \param[out] yi Interpolated y vector. Upon function completion, 
        /// 'yi' will contain the interpolated y values.
        /// \return True if the interpolation is successful (within the range of x values), 
        /// False otherwise (indicating extrapolation).
        bool interp1_prev(Real xi,Rvector& yi) const;

    private:
        Rtable(const Rtable& orig);                 ///< = delete.
        Rtable& operator=(const Rtable& orig);      ///< = delete.
        const Base::Mblock<const Real>  x;          ///< x Real values of table.
        const Base::Mblock<const Real>  y;          ///< y Real values of table.
        const Uint16                    esz;        ///< Entry size (y rows).
        const Uint32&                   nentries;   ///< Number of entries (x size, y cols).

        /// Real Interpolation Table Linear Interpolation Update for Given x Value and Interval Index.
        /// \wi{3092}
        /// Rtable class provides a method to perform linear interpolation for a given x value 
        /// 'xi' within the interval specified by the index 'i' in the x vector.
        /// \param[in] xi Real value to evaluate in the x vector.
        /// \param[out] yi Output result of the interpolation. Upon function completion, 
        /// 'yi' will contain the interpolated y values.
        /// \param[in] i Index of the interval used for interpolation.
        void interp1_linear0(Real xi,
                             Rvector& yi,
                             Uint32 i) const;

        /// Real Interpolation Table Retrieve Memory Block for Index j.
        /// \wi{19039}
        /// Rtable class shall provide a method to retrieve the memory block 
        /// containing the y values for a specified index 'j'.
        /// \param[in] j Index of the memory block to retrieve.
        /// \return Memory block reference containing the y values for the specified index 'j'.
        Base::Mblock<const Real> y_colref(Uint32 j) const;

        /// Real Interpolation Table Retrieve Specific Value from y Matrix.
        /// \wi{19040}
        /// Rtable class shall provide a method to retrieve a specific Real value from the y matrix.
        /// \param[in] i Row index.
        /// \param[in] j Column index.
        /// \return The Real value at the specified row and column indices in the y matrix.
        Real y_get(Uint32 i,Uint32 j) const;

        /// Real Interpolation Table Inverse Linear Interpolation for Column k and Entry j.
        /// \wi{3095}
        /// Rtable class shall provide a method to calculate the linearly interpolated Real value of x 
        /// for the given y related to column k using the inverse linear interpolation technique.
        /// \param[in] k Index of the column.
        /// \param[in] j Index of the entry.
        /// \param[in] yi Value of y to perform the inverse interpolation.
        /// \return The linearly interpolated Real value of x for the given y related to column k and entry j.
        Real intlin_1(Uint16 k, Uint32 j, Real yi) const;
    };

    template <Uint32 nrows, Uint32 ncols>
    inline Rtable::Rtable(const Base::Xrtable<nrows, ncols>& xrt) :
            x(xrt.x),
            y(xrt.y),
            esz(nrows),
            nentries(xrt.nentries)
    {
    }

    inline Uint32 Rtable::get_nentries() const
    {
        /// \alg
        /// - Return the total number of entries in the interpolation table.
        return nentries;
    }

    inline bool Rtable::wrap_x(Real& xi) const
    {
        /// \alg
        /// - Call Rfun::wrap for the given inputs and return True if the value 
        /// wrapped within the limits of the "x" values, False otherwise.
        return Rfun::wrap(x[0],x[nentries-1],xi,xi);
    }

    inline bool Rtable::is_lower_bound(Real xi) const
    {
        /// \alg
        /// - Check if the input Real value "xi" is within the lower 
        /// boundary of the "x" values in the interpolation table.
        /// - Return True if "xi" is less than the smallest x value 
        /// "x[0]", indicating that it is within the lower boundary; otherwise, return False.
        return xi<x[0];
    }

    inline bool Rtable::is_upper_bound(Real xi) const
    {
        /// \alg
        /// - Check if the input Real value "xi" is beyond the upper 
        /// boundary of the "x" values in the interpolation table.
        /// - Return True if "xi" is greater than the largest x value 
        /// "x[nentries-1]", indicating that it is beyond the upper boundary; otherwise, return False.
        return xi>x[nentries-1];
    }

    inline bool Rtable::interp1_linear(Real xi,Real& y)const
    {
        /// \alg
        /// <ul>
        /// <li> Construct a Rvector object with a single element initialized with the reference to y.
        Rvector ry(&y, 1);
        /// <li> Return Rtable::interp1_linear instance for the input xi and ry.
        return interp1_linear(xi, ry);
        /// </ul>
    }

    inline void Rtable::interp1_linear_extrapolate(Real xi,Real& y)const
    {
        /// \alg
        /// <ul>
        /// <li> Construct a Rvector object "ry" with a single element initialized with the reference to "y".
        Rvector ry(&y, 1);
        /// <li> Call Rtable::interp1_linear_extrapolate instance for the input xi and ry.
        interp1_linear_extrapolate(xi, ry);
        /// </ul>
    }
    inline Base::Mblock<const Real> Rtable::y_colref(Uint32 j) const
    {
        /// \alg
        /// - Call Mblock::sub_mblock with given inputs "j*esz" "esz" and return 
        /// the memory block reference corresponding to index "j" in the ::y matrix.
        return y.sub_mblock(j*esz, esz);
    }

    inline Real Rtable::y_get(Uint32 i,Uint32 j) const
    {
        /// \alg
        /// - Return the value from the ::y matrix at the specified index "esz*j+i".
        return y[esz*j+i];
    }

}
#endif
