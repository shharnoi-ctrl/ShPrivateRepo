#ifndef INCLUDE_XCFG_DES_H_
#define INCLUDE_XCFG_DES_H_

#include <Xcfg_des_fw.h>
#include <Tundefault.h>
#include <Twrapdes.h>
#include <Wsync_des.h>

namespace Base
{
    /// Type definitions for cset configurables read by cpu 1.
    template <typename XCFG, typename TUNTRAIT>
    struct Xcfg_des
    {
        /// Raw cfg data.
        typedef XCFG                                                Type_podcfg;
        /// type for shared memory (cfg + sync).
        typedef Tdsync<XCFG, Tdsynctraits::Rd_blocking<XCFG> >      Type_podsync;
        /// type for shared memory (cfg + sync). const version
        typedef const volatile Type_podsync                         Type_kpodsync;
        /// Tuntrait combined with Wsync
        typedef Tuntraits::Wsync_des<Type_podsync, TUNTRAIT>        Type_wstuntrait;
        /// Type to add to cfgmgr.
        typedef Twrapdes<Type_wstuntrait, Type_podsync&>            Type_tun;
        /// Type for reader.
        typedef typename Type_podsync::Rdsafe0                      Type_rd;
    };
}


#endif
