#ifndef BITMBLOCK_H_
#define BITMBLOCK_H_

#include <Bitarray.h>
#include <Optional.h>

namespace Base
{

    /// 16-bit word BIT memory block.
    /// The Base library shall provide a class to read/write the value of individual bits from an array of 16-bit
    /// words.
    class Bitmblock : public Bitarray0<Uint16*>
    {
    public:
        /// Bitmblock Constructor.
        /// \wi{4971}
        /// Bitmblock class shall build itself upon construction with the specified parameter.
        /// \param[in] v0       Bitarray to initialize itself.
        template<Uint16 sz0>
        explicit Bitmblock(Bitarray<sz0>& v0);

        /// Bitmblock Constructor.
        /// \wi{4970}
        /// Bitmblock class shall build itself upon construction with the specified parameters.
        /// \param[in] sz0          Size in bits to allocate 16-bit words.
        /// \param[in] mtype        Memory type to use for allocation.
        Bitmblock(Uint16 sz0, Memmgr::Type mtype);

        /// Bitmblock Size Getter.
        /// \wi{4972}
        /// Bitmblock class shall provide the capability to retrieve the number of words contained in a Bitmblock.
        /// \return         Size in words :sz.
        Uint16 size() const;

        /// Bitmblock Zeros.
        /// \wi{4973}
        /// Bitmblock class shall provide the capability to set all the elements in the bitmblock to zero.
        void zeros();

        /// 16-bit word BIT memory block find first disabled.
        /// \wi{13832}
        /// The Bitmblock class shall provide a method that searches word by word in the word array starting from the
        /// first and returns the position of the first bit that is false if there is any (with an optional).
        /// \return Position of the first disabled bit if there is any, otherwise the optional is set to not present.
        Optional<Uint16> find_first_disabled() const;

    private:
        typedef Bitarray0<Uint16*> Baseclass;   ///< Type for Base class.
        Uint16 sz;      ///< Number of words used.

        Bitmblock(); ///< = delete
        Bitmblock(const Bitmblock& orig); ///< = delete
        Bitmblock& operator=(const Bitmblock& orig); ///< = delete
    };


    template<Uint16 sz0>
    inline Bitmblock::Bitmblock(Bitarray<sz0>& v0) : sz(sz0)
    {
        Baseclass::v = v0.to_raw_mblock().v;
    }

    inline Uint16 Bitmblock::size() const
    {
        return sz;
    }

}

#endif
