///    \file Wsync.h
///
///    \date 12 sept. 2019
///
///    \author  FJBurgos, jbm (at) embention.com
///    Company:  Embention
///
///    Wsync class declaration.
///

#ifndef WSYNC_H_
#define WSYNC_H_

#include <Wsync_fw.h>
#include <Tdsync.h>

namespace Base
{

    namespace Tuntraits
    {

        /// Tdync based, write safe, read unsafe, Tuntrait
        template <typename TDSYNC, typename DELEGATE_TRAIT = Cxet<typename TDSYNC::type> >
        struct Wsync : type_is<TDSYNC>
        {
        public:
            static void str2elem(TDSYNC& s, Lossy_error& str);
            static void elem2str(const TDSYNC& s, Lossy& str);
        private:
            Wsync(); ///< = delete
            Wsync(const Wsync& orig); ///< = delete
            Wsync& operator=(const Wsync& orig); ///< = delete
        };

        template <typename TDSYNC, typename DELEGATE_TRAIT>
        inline void Wsync<TDSYNC,DELEGATE_TRAIT>::str2elem(TDSYNC& s, Lossy_error& str)
        {
            typename TDSYNC::Wrsafe wr(s); // RAII
            DELEGATE_TRAIT::str2elem(wr.data,str);
        }
        template <typename TDSYNC, typename DELEGATE_TRAIT>
        inline void Wsync<TDSYNC,DELEGATE_TRAIT>::elem2str(const TDSYNC& s, Lossy& str)
        {
            // assumes this method is called by the same thread that writer.
            DELEGATE_TRAIT::elem2str(s.read_unsafe(),str);
        }

    } // namespace Tuntraits

} // namespace Base

#endif // WSYNC_H_
