#ifndef RFUN_H__
#define RFUN_H__

#include <Const.h>
#include <Entypes.h>
#include <fpu_vector.h>
#include <Ku16.h>
#include <Ku32.h>
#include <Rmath.h>
#include <Ttraits.h>

/// The Rfun namespace encapsulates a collection of functions 
/// and structures related to various mathematical operations and utilities. 
namespace Rfun
{
    struct Rand
    {
        Uint32 seed; ///< Variable to store the seed value.
        /// Random Seed Updater.
        /// \wi{18384}
        /// Rand for Rfun structure shall be able to set a random seed.
        /// \param[in] seed0 Seed value to be set.
        inline Rand(Uint32 seed0)
        {
            /// \alg
            /// - Set ::seed to received "seed0" value.
            seed = seed0;
        }

        /// 16-bit Pseudorandom Integer Retriever.
        /// \wi{18385}
        /// Rand for Rfun structure shall be able to retrieve a 16-bit pseudorandom integer.
        /// \return 16-bit unsigned pseudorandom value to the nearest integer.
        inline Uint16 get(void)
        {
            /// \alg 
            /// - The seed value is computed as \f$ \text{seed} \times \text{cmp0} + \text{cmp1} \f$.
            seed = seed * cmp0 + cmp1;
            /// - Return value: \f$ (\text{seed} >> 16) \& \text{cmp2} \f$ as \f$ \text{Uint16} \f$.
            return static_cast<Uint16>((seed>>Ku16::u16) & cmp2);
        }

    private:
        static const Uint32 cmp0 = 1103515245UL; ///< Conditional (recursive) Mixed Process 0.
        static const Uint32 cmp1 = 12345UL;      ///< Conditional (recursive) Mixed Process 1.
        static const Uint32 cmp2 = 0xFFFFU;      ///< Conditional (recursive) Mixed Process 2.
    };

    /// Structure to divide two variables a and b of T type, at compilation-time.
    template <typename T, const T a, const T b>
    struct Div_t
    {
        typedef T type;
        static const Real value = static_cast<Real>(a) / static_cast<Real>(b);
    };

    /// Provide ceill value of instantiated parameter T type.
    /// \pre T shall define an integer "type" and a static const floating point variable.
    template <typename T>
    struct Ceilr_t
    {
        static const typename T::type value = T::value
                              + static_cast<typename T::type>(T::value > static_cast<typename T::type>(T::value));
    };

    /// Provide floor value of instantiated parameter T type.
    /// \pre T shall define an integer "type" and a static const floating point variable.
    template <typename T>
    struct Floorr_t
    {
        static const typename T::type value = static_cast<typename T::type>(T::value);
    };

    /// Integer Round Value Retriever.
    /// \wi{18387} 
    /// Rfun shall provide a method to retrieve the integer value for the given input.
    /// \param[in] x Real value to be rounded.
    /// \return Rounded integer 32-bit value nearest to the given Real value.
    inline int32 roundi(Real x)
    {
        // Note that int32 overflow could happen
        return static_cast<int32>(Rmath::roundr(x));
    }

    /// Computes the rounded division of value/divisor. Intended for integer values.
    /// \return Rounded value/divisor.
    template<typename T>
    inline T round_frac(T value, T divisor)
    {
        return (value + divisor - 1)/divisor;
    }

    /// Real Wrap Value Between 0 and 1 Retriever.
    /// \wi{18389} 
    /// Rfun shall provide a method to retrieve the real value within the range between 0 and 1.
    /// \param[in] ang_norm Real value to be wrapped.
    /// \return Real value wrapped to be within the range (0, 1).
    inline Real wrap21(Real ang_norm)
    {
        /// \alg 
        /// - Return \f$ (ang\_norm \f$ - Rmath::floorr\f$(ang\_norm))\f$.
        return (ang_norm - Rmath::floorr(ang_norm));
    }

    /// Real Wrap Value Between -0.5 and 0.5 Retriever.
    /// \wi{18390} 
    /// Rfun shall provide a method to retrieve the real value within the range between -0.5 and 0.5.
    /// \param[in] ang_norm Real value to be wrapped.
    /// \return Real value wrapped to be within the range (-0.5, 0.5).
    /// Some examples:
    /// <ul>
    ///     <li> Input: 2.3 returns 0.3
    ///     <li> Input: 3.8 returns -0.2
    ///     <li> Input: 5.5 returns -0.5
    ///     <li> Input: -2.3 returns -0.3
    ///     <li> Input: -3.8 returns 0.2
    ///     <li> Input: -5.5 returns 0.5
    /// </ul>
    template <typename T>
    inline T wrap205(T ang_norm)
    {
        return (ang_norm-Rmath::roundr(ang_norm));
    }

    /// Real Wrap Value Between 0 and 2pi Retriever.
    /// \wi{18391} 
    /// Rfun shall provide a method to retrieve the real value wrapped to be within the range (0, pi).
    /// \param[in] ang Real value representing the input angle in radians.
    /// \return Real value wrapped to be within the range (0, 2pi).
    template <typename T>
    inline T wrap2pi(T ang)
    {
        /// \alg 
        /// - Return (::wrap205\f$(ang \times \text{Const::INV2PI}) \times \text{Const::PI2})\f$. 
        return wrap205(ang*Const::INV2PI)*Const::PI2;
    }

    /// Real Wrap Desired Range Value Retriever.
    /// \wi{17909}
    /// The wrap2val method shall wrap ::num to be between +-val/2. The returned values are:
    /// <ul>
    /// <li> In the range (0, val/2) if the decimal component of (val/num) is less than 0.5. For example:
    /// wrap2val(0.9, 2.0) = 0.9
    /// <li> -val/2 if the decimal component of (val/num) is exactly 0.5
    /// <li> In the range (-val/2, 0) if the decimal component of (val/num) is greater than 0.5. For example:
    /// wrap2val(1.1, 2.0) = -0.9
    /// <li> 0 if (val/num) has no decimal component.
    /// </ul>
    /// \pre It is assumed that ::val is different from zero.
    /// \param[in] num Real value to be wrapped.
    /// \param[in] val Real value representing the range within which the number should be wrapped.
    /// \return Real value wrapped to be within the range defined by the given input.
    template <typename T>
    inline T wrap2val(const T num, const T val)
    {
        /// \alg 
        /// - Return (::wrap205 \f$\left(\frac{\text{num}}{\text{val}}\right) \times \text{val} \f$). 
        return wrap205(num / val) * val;
    }

    /// Real Wrap Value Between 0 and 2pi Retriever.
    /// \wi{18393} 
    /// Rfun shall provide a method to retrieve the real value wrapped to be within the range (0, 2pi).
    /// \param[in] ang Real value representing the input angle in radians.
    /// \return Real value wrapped to be within the range (0, 2pi).
    inline Real wrap22pi(Real ang)
    {
        /// \alg
        /// <ul>
        /// <li> Store "10430.37835047045" value into "rad2word" constant variable for conversion from radian to word.
        const Real rad2word =     static_cast<Real>(10430.37835047045);
        /// <li> Store "0.00009587379924285257" value into "word2rad" for for conversion from word to radian.
        const Real word2rad =     static_cast<Real>(0.00009587379924285257);
        /// <li> Return computed value as: \f$ \text{ang} \times \text{rad2word} \f$ &Ku16::u0xFFFF \f$ \times \text{word2rad} \f$
        return static_cast<Real>(static_cast<int32>(ang*rad2word)&Ku16::u0xFFFF)*word2rad;
        /// </ul>
    }

    /// Real Unwrapping Value Between 0 and pi Retriever.
    /// \wi{18394} 
    /// Rfun shall provide a method to retrieve the unwrapped Real value within the range (0, pi).
    /// \param[in] curr Current angle that needs to be unwrapped.
    /// \param[in] prev Previous angle before current angle. 
    /// \return Unwrapped angle within the range (0, pi).
    inline Real unwrap2pi(Real curr, Real prev)
    {
         /// \alg
         /// - Return \f$ (prev \f$ + Rfun::wrap2pi\f$(curr - prev))\f$.
         return prev + Rfun::wrap2pi(curr - prev);
    }

    /// Maximum of Two Values Retriever.
    /// \wi{18395}
    /// Rfun shall provide a method to retrieve the maximum value from the given inputs.
    /// \param[in] x First value to compare.
    /// \param[in] y Second value to compare.
    /// \return Maximum of the two input values.
    template <typename T>
    inline T max(typename Base::JSF116_param<T>::type x, typename Base::JSF116_param<T>::type y)
    {
        /// \alg 
        /// - Return maximum value between \f$ x \f$ and \f$ y \f$.
        return (x > y) ? x : y;
    }

    /// Maximum of Three Values Retriever.
    /// \wi{18396}
    /// Rfun shall provide a method to retrieve the maximum value from the three inputs.
    /// \param[in] x First value to compare.
    /// \param[in] y Second value to compare.
    /// \param[in] z Third value to compare.
    /// \return Maximum of the three input values.
    template <typename T>
    inline T max(typename Base::JSF116_param<T>::type x,
                 typename Base::JSF116_param<T>::type y,
                 typename Base::JSF116_param<T>::type z)
    {
        /// \alg 
        /// - Return \f$ \max(x, \max(y, z)) \f$.
        return max<T>(x,max<T>(y,z));
    }

    /// Minimum of Two Values Retriever.
    /// \wi{18397}
    /// Rfun shall provide a method to retrieve the minimum value for the two inputs.
    /// \param[in] x The first value to compare.
    /// \param[in] y The second value to compare.
    /// \return Minimum of the two input values.
    template <typename T>
    inline T min(typename Base::JSF116_param<T>::type x, typename Base::JSF116_param<T>::type y)
    {
        /// \alg 
        /// - Return minimum value between \f$ x \f$ and \f$ y \f$.
        return (x<y) ? x:y;
    }

    /// Clamped Value Retriever.
    /// \wi{18398}
    /// Rfun shall provide a method to retrieve the clamped value within the specified range.
    /// \param[in] x Value to clamp.
    /// \param[in] min_val Minimum value of the range.
    /// \param[in] max_val Maximum value of the range.
    /// \return Clamped value within the specified range.
    template <typename T>
    inline T clamp(typename Base::JSF116_param<T>::type x,
                   typename Base::JSF116_param<T>::type min_val,
                   typename Base::JSF116_param<T>::type max_val)
    {
        /// \alg 
        ///- Return \f$ \max(\min(x, \text{max_val}), \text{min_val}) \f$.
        return max<T>(min<T>(x,max_val),min_val);
    }

    /// Wrapped Value Retriever.
    /// \wi{18399}
    /// Rfun shall provide a method to retrieve the wrapped value within the specified range.
    /// \param[in] x Value to wrap.
    /// \param[in] min_val Minimum value of the range.
    /// \param[in] max_val Maximum value of the range.
    /// \return Wrapped value within the specified range.
    template <typename T>
    inline T wrap(typename Base::JSF116_param<T>::type x,
                  typename Base::JSF116_param<T>::type min_val,
                  typename Base::JSF116_param<T>::type max_val)
    {
        /// \alg 
        /// - Return retrieved value by ::clamp with received parameters.
        return clamp<T>(x, min_val, max_val);
    }

    /// Wrapped Value Checker.
    /// \wi{18400}
    /// Rfun shall provide a method to check if the output is wrapped for the given inputs.
    /// \param[in] vmin Minimum value of the range.
    /// \param[in] vmax Maximum value of the range.
    /// \param[in] vin  Input Value to be checked.
    /// \param[out] vout Output reference to store the wrapped value.
    /// \return True if the value is wrapped, False otherwise.
    bool wrap(const Real vmin,
              const Real vmax,
              const Real vin,
              Real& vout);

    /// Clamp Input Between Limits.
    /// \wi{18714}
    /// Rfun shall provide a method to clamp input values between input limits and update the saturated
    /// values if the input was clamped by lower or upper limit.
    /// \param[in] vmin Minimum value.
    /// \param[in] vmax Maximum value.
    /// \param[in] vin Input value.
    /// \param[out] vout Clamped value.
    /// \param[out] sat_up Input value was clamped by maximum value.
    /// \param[out] sat_low input value was clamped by mimnimum value.
    void clamp_sat(const Real vmin,
                   const Real vmax,
                   const Real vin,
                   Real& vout,
                   bool& sat_up,
                   bool& sat_low);

    /// Swapping Two Values.
    /// \wi{18401}
    /// Rfun shall provide a method to perfrom swapping between values.
    /// \param[in,out] a First variable whose value will be swapped.
    /// \param[in,out] b Second variable whose value will be swapped.
    template <typename T>
    inline void swap(T& a, T& b)
    {
        /// \alg 
        /// - Save "b" value into "a" and vice versa.
        const T aux = a;
        a = b;
        b = aux;
    }

    /// Factorial Value Retriever.
    /// \wi{18402}
    /// Rfun shall provide a method to compute the factorial value for the given input.
    /// \param[in] x Input value used to compute its factorial.
    /// \return Factorial value for the given input.
    Uint32 factorial(Uint16 x);

    /// Number of Possible Combinations Retriever.
    /// \wi{18403}
    /// Rfun shall provide a method to compute the number of combinations value for the given input.
    /// \param[in] n Total number of items.
    /// \param[in] m Number of items to choose.
    /// \return Total number of combinations.
    Uint32 n_over_m(Uint16 n,Uint16 m);

    /// Real Value Sign Retriever.
    /// \wi{18404}
    /// Rfun shall provide a method to retrive the sign value for the given input.
    /// \param[in] x Real value which sign is being computed.
    /// \return Sign of the real input number.
    Real sign(const Real x);

    /// Real Arc Sine Retriever.
    /// \wi{18405}
    /// Rfun shall provide a method to retrive the inverse sine value for the given input.
    /// \param[in] r Real value representing the input.
    /// \return Arc Sine value in radians.
    Real asinw(Real r);

    /// Real Arc Cosine Retriever.
    /// \wi{18406}
    /// Rfun shall provide a method to retrive the inverse cosine value for the given input.
    /// \param[in] r Real value representing the input.
    /// \return Arc Cosine value in radians.
    Real acosw(Real r);

    /// Power Exponent Retriever.
    /// \wi{18407} 
    /// Rfun shall provide a method to retrieve the power exponent value 
    /// from the given base and exponent input ensuring positive or zero base.
    /// \param[in] b Real value representing the base.
    /// \param[in] e Real value representing the exponent.
    /// \return Power exponent value from the given positive base and exponent input.
    inline Real powpb(Real b, Real e)
    {
        /// \alg 
        /// -Return Rmath::powr\f$(\max(b, 0), e) \f$.
        return Rmath::powr(max<Real>(b,0),e);
    }

    /// Real Values within Epsilon Range.
    /// \wi{18408} 
    /// Rfun shall provide a method to compare two real numbers within a given epsilon range.
    /// \param[in] a First real value.
    /// \param[in] b Second real value.
    /// \param[in] eps Epsilon value for comparison.
    /// \return True if the absolute difference between a and b is less than eps, False otherwise.
    template<typename T>
    inline bool comp_real(T a,
                          T b,
                          T eps)
    {
        /// \alg 
        /// -Return  Rmath::fabsr\f$(a - b) < \epsilon \f$.
        return Rmath::fabsr(a - b) < eps;
    }

    /// Interpolation ratio computer.
    /// \wi{20719}
    /// Rfun shall provide a method to compute the value of the interpolation ratio to interpolate between the
    /// lower and upper bounds passed as parameter with the given value.
    /// \param[in] x Value to obtain the interpolation parameter.
    /// \param[in] x_lower Lower bound for the interpolation.
    /// \param[in] x_upper Upper bound for the interpolation.
    /// \return Interpolation parameter.
    /// \alg This method returns the value computed as (x - x_lower) / (x_upper - x_lower).
    template <typename T>
    inline T interpolation_parameter(typename Base::JSF116_param<T>::type x,
                                     typename Base::JSF116_param<T>::type x_lower,
                                     typename Base::JSF116_param<T>::type x_upper)
    {
        return ((x - x_lower) / (x_upper - x_lower));
    }

    /// Linear Interpolation Retriever From Ratio.
    /// \wi{18409} 
    /// Rfun shall provide a method to retrieve the linear interpolation value between 
    /// the given inputs based on the input interpolation ratio between them.
    /// \param[in] r Interpolation ratio.
    /// \param[in] y_lower First real value.
    /// \param[in] y_upper Second real value.
    /// \return Interpolated Real value between y_lower and y_upper.
    template <typename T>
    T interp(typename Base::JSF116_param<T>::type r,
             typename Base::JSF116_param<T>::type y_lower,
             typename Base::JSF116_param<T>::type y_upper)
    {
        /// \alg
        /// - Return \f$ ((1.0F - r) \times y_\lower) + (r \times y\_upper) \f$.
        return ((static_cast<T>(1.0F) - r)*y_lower) + (r*y_upper);
    }

    /// Linear Interpolation Computation With Clipping.
    /// \wi{20928}
    /// The Rfun namespace shall provide a method to compute a clipped linear interpolation.
    /// \param[in] x X value to interpolate.
    /// \param[in] x_lower Lower bound for x.
    /// \param[in] x_upper Upper bound for x.
    /// \param[in] y_lower Lower bound for y.
    /// \param[in] y_upper Upper bound for y.
    /// \return Interpolated value of "y" at the point "x" clipped between [y_lower, y_upper].
    template <typename T>
    T interpolation_with_clipping(typename Base::JSF116_param<T>::type x,
                                  typename Base::JSF116_param<T>::type x_lower,
                                  typename Base::JSF116_param<T>::type x_upper,
                                  typename Base::JSF116_param<T>::type y_lower,
                                  typename Base::JSF116_param<T>::type y_upper)
    {
        /// \alg
        /// - This method shall call the method ::interpolation_parameter passing "x", "x_lower" and "x_upper" to
        /// obtain the interpolation ratio "r".
        /// - Then the method ::interp shall be called passing as argument "r", "y_lower" and "y_upper" to obtain
        /// the unbounded linear interpolation.
        /// - Finally the unbounded interpolation value shall be clipped between "y_lower" and "y_upper" using the
        /// ::clamp method.
        return clamp<T>(interp<T>(interpolation_parameter<T>(x,
                                                             x_lower,
                                                             x_upper),
                                  y_lower,
                                  y_upper),
                        y_lower,
                        y_upper);
    }

    /// Power Exponent Retriever.
    /// \wi{18410} 
    /// Rfun shall provide a method to retrieve the power exponent value from the given base and exponent input.
    /// \param[in] x 32-bit unsigned integer value representing the base.
    /// \param[in] n 8-bit unsigned integer value representing the exponent.
    /// \return Power exponent value from the given base and exponent input.
    Uint32 pow_u32(Uint32 x, Uint8 n);

    /// Range Value Checker.
    /// \wi{18411} 
    /// Rfun shall provide a method to check if the value is within a specified range.
    /// \param[in] x Input value to be checked.
    /// \param[in] min_val First real value.
    /// \param[in] max_val Second real value.
    /// \return True if x is within the range, False otherwise.
    template <typename T>
    inline bool in_range(typename Base::JSF116_param<T>::type x,
                         typename Base::JSF116_param<T>::type min_val,
                         typename Base::JSF116_param<T>::type max_val)
    {
        /// \alg 
        /// - Return True if \f$ (x \geq \text{min_val})\f$ && \f$(x \leq \text{max_val}) \f$, False otherwise.
        return (x >= min_val) && (x <= max_val);
    }


    /// Safe Division Operation.
    /// \wi{17910}
    /// Rfun shall provide a method to check if the denominator is different from zero, and return the division
    /// between the numerator and the denominator. If it is zero, it shall perform the division between the
    /// numerator and eps.
    /// \param[in] num Numerator of the division.
    /// \param[in] den Denominator of the division.
    /// \return result of the division.
    template <typename T>
    inline T safe_divide(const T num, T den, const T eps)
    {
        /// \alg 
        /// <ul>
        /// <li> If Rmath::fabsr with "den" is less than "eps", update "den" as Rmath::copysignr retrieved value for "eps" and "den".
        den = (Rmath::fabsr(den) < eps) ? Rmath::copysignr(eps, den) : den;
        ///<li> Return \f$ (num / den) \f$.
        return (num / den);
        /// </ul>
    }

}
#endif
