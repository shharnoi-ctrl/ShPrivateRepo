#ifndef TUNTRAITS_H_
#define TUNTRAITS_H_

#include <Async_sres.h>
#include <Lossy_error.h>
#include <Tunarray.h>
#include <Tuntraits_fw.h>
#include <Tuple.h>
#include <U16stream_r_error.h>
#include <U16stream_w.h>

namespace Base
{
    namespace Tuntraits
    {
        /// Null object idiom: Ignore element.
        template <typename T>
        struct Null : type_is<T>
        {
            static void str2elem(T& elem, Lossy_error& str);
            static void elem2str(const T& elem, Lossy& str);
        };

        template <typename T>
        struct Cset_only : type_is<T>
        {
            static void str2elem(T& elem, Lossy_error& str);
        };

        template <typename T1, typename T2>
        struct Tupletun : type_is <Tuple<typename T1::type, typename T2::type> >
        {
            static void str2elem(Tuple<typename T1::type, typename T2::type>& elem, Lossy_error& str);
        };

        template <typename T>
        struct Cxet : public Cset_only<T>
        {
            static void elem2str(const T& elem, Lossy& str);
        };

        template <typename T>
        struct U16strCxet : type_is<T>
        {
            static inline void str2elem(T& elem, U16stream_r_error& str)
            {
                elem.cset(str);
            }
            static inline void elem2str(const T& elem, U16stream_w& str)
            {
                elem.cget(str);
            }
        };

        template <typename T>
        struct Cset_only_async : type_is<T>
        {
            static Async_sres str2elem(T& elem, Lossy_error& str);
        };

        template <typename T>
        struct Cxet_async : public Cset_only_async<T>
        {
            static Async_sres elem2str(const T& elem, Lossy& str);
        };

        template <typename T>
        struct Cget_only : type_is<T>
        {
            static void str2elem(const T& elem, const Lossy_error& str);
            static void elem2str(const T& elem, Lossy& str);
        };

        template <typename T>
        struct Lossy8 : type_is<T> // T assumed to be Uint8 or int8
        {
            static void str2elem(T& elem, Lossy_error& str);
            static void elem2str(const T& elem, Lossy& str);
        };

        template <typename T>
        struct Lossy16 : type_is<T> // T assumed to be enum or Uint16
        {
            static void str2elem(T& elem, Lossy_error& str);
            static void elem2str(const T& elem, Lossy& str);
        };

        template <typename T>
        struct U16str_16 : type_is<T> // T assumed to be enum or Uint16
        {
            static inline void str2elem(T& elem, U16stream_r_error& is)
            {
                is.get_enum16(elem);
            }
            static inline void elem2str(const T& elem, U16stream_w& os)
            {
                os.put_uint16(static_cast<Uint16>(elem));
            }
        };

        template <typename T>
        struct Lossybool16 : type_is<T> // T assumed to be enum or Uint16
        {
            static void str2elem(T& elem, Lossy_error& str);
            static void elem2str(const T& elem, Lossy& str);
        };

        template <typename T>
        struct U16bool_16 : type_is<T> // T assumed to be enum or Uint16
        {
            static inline void str2elem(T& elem, U16stream_r_error& os)
            {
                elem = os.get_bool16();
            }
            static inline void elem2str(const T& elem, U16stream_w& is)
            {
                is.put_bool16(static_cast<bool>(elem));
            }
        };

        struct Lossy_float : type_is<Real>
        {
            static void str2elem(Real& elem, Lossy_error& str);
            static void elem2str(const Real& elem, Lossy& str);
        };

        struct U16str_float : type_is<Real>
        {
            static inline void str2elem(Real& elem, U16stream_r_error& is)
            {
                elem = is.get_float();
            }
            static inline void elem2str(const Real& elem, U16stream_w& os)
            {
                os.put_float(elem);
            }
        };

        template <typename TRAIT, typename ARRAY>
        struct Resize : type_is<ARRAY >
        {
            static void str2elem(ARRAY& a, Lossy_error& str);
            static void elem2str(const ARRAY& a, Lossy& str);
        };

        template <typename ARRAY>
        struct Resize16 : Resize<Lossy16<Uint16>,ARRAY>
        {
        };

        template <typename CONTAINER_POLICY, typename CONTAINER_TYPE>
        struct Arraytun_nosize : type_is<CONTAINER_TYPE>
        {
            static void str2elem(CONTAINER_TYPE& a, Lossy_error& str);
            static void elem2str(const CONTAINER_TYPE& a, Lossy& str);
        private:
            typedef typename CONTAINER_POLICY::type Element_type;
        };

        template <typename CONTAINER_POLICY,
                  typename SIZE_POLICY,
                  typename ARRAY = Array<typename CONTAINER_POLICY::type> >
        struct Arraytun : type_is<ARRAY >
        {
            static void str2elem(ARRAY& a, Lossy_error& str);
            static void elem2str(const ARRAY& a, Lossy& str);
        private:
            typedef Arraytun_nosize<CONTAINER_POLICY, ARRAY > Tnosize;
        };

        template <typename CONTAINER_POLICY, typename CONTAINER_TYPE>
        struct Arraytun_size16 : Arraytun<CONTAINER_POLICY, Resize16<CONTAINER_TYPE>, CONTAINER_TYPE>
        {
        };

        struct Rv3_nosize : type_is<Rv3>
        {
            static void str2elem(Rv3& a, Lossy_error& str);
            static void elem2str(const Rv3& a, Lossy& str);
        };

        template <typename T,Uint16 sz>
        struct Tunarraymsk : type_is<Arraymsk<T,sz> >
        {
            static void str2elem(Arraymsk<T,sz>& am,             //#PRQA fail (there's not 3 parameters)
                                        Lossy_error& str);                    //PRQA S 5059

            static void elem2str(const Arraymsk<T,sz>& am,       //#PRQA fail (there's not 3 parameters)
                                        Lossy& str);                    //PRQA S 5059

        };

        template <typename T>
        inline void Null<T>::str2elem(T& elem, Lossy_error& str)
        {
        }
        template <typename T>
        inline void Null<T>::elem2str(const T& elem, Lossy& str)
        {
        }

        template <typename T>
        inline void Cset_only<T>::str2elem(T& elem, Lossy_error& str)
        {
            elem.cset(str);
        }

        template <typename T1, typename T2>
        inline void Tupletun<T1, T2>::str2elem(Tuple<typename T1::type, typename T2::type>& elem, Lossy_error& str)
        {
            T1::str2elem(elem.t1, str);
            T2::str2elem(elem.t2, str);
        }

        template <typename T>
        inline void Cxet<T>::elem2str(const T& elem, Lossy& str)
        {
            elem.cget(str);
        }

        template <typename T>
        inline Async_sres Cset_only_async<T>::str2elem(T& elem, Lossy_error& str)
        {
            return elem.cset(str);
        }
        template <typename T>
        inline Async_sres Cxet_async<T>::elem2str(const T& elem, Lossy& str)
        {
            return elem.cget(str);
        }

        template <typename T>
        inline void Cget_only<T>::str2elem(const T& elem, const Lossy_error& str)
        {
        }
        template <typename T>
        inline void Cget_only<T>::elem2str(const T& elem, Lossy& str)
        {
            elem.cget(str);
        }

        template <typename T>
        inline void Lossy8<T>::str2elem(T& elem, Lossy_error& str)
        {
            str.get_uint8(reinterpret_cast<Uint8&>(elem)); //PRQA S 3100 #redundant
        }
        template <typename T>
        inline void Lossy8<T>::elem2str(const T& elem, Lossy& str)
        {
            str.put_uint8(static_cast<Uint8>(elem));
        }

        template <typename T>
        inline void Lossy16<T>::str2elem(T& elem, Lossy_error& str)
        {
            str.get_enum16(elem);
        }
        template <typename T>
        inline void Lossy16<T>::elem2str(const T& elem, Lossy& str)
        {
            str.put_uint16(static_cast<Uint16>(elem));
        }

        template <typename T>
        inline void Lossybool16<T>::str2elem(T& elem, Lossy_error& str)
        {
            str.get_bool16(elem);
        }
        template <typename T>
        inline void Lossybool16<T>::elem2str(const T& elem, Lossy& str)
        {
            str.put_bool16(static_cast<Uint16>(elem));
        }

        inline void Lossy_float::str2elem(Real& elem, Lossy_error& str)
        {
            str.get_float(elem);
        }
        inline void Lossy_float::elem2str(const Real& elem, Lossy& str)
        {
            str.put_float(elem);
        }

        template <typename TRAIT, typename ARRAY>
        void Resize<TRAIT,ARRAY>::str2elem(ARRAY& a, Lossy_error& str)
        {
            typename TRAIT::type sz = 0;
            TRAIT::str2elem(sz,str);
            a.resize(sz);
            str.assrt(sz==a.size(), Base::err_tuntrait);
        }
        template <typename TRAIT, typename ARRAY>
        inline void Resize<TRAIT,ARRAY>::elem2str(const ARRAY& a, Lossy& str)
        {
            TRAIT::elem2str(a.size(),str);
        }

        template <typename CONTAINER_POLICY, typename CONTAINER_TYPE>
        void Arraytun_nosize<CONTAINER_POLICY,CONTAINER_TYPE>::str2elem(CONTAINER_TYPE& a, Lossy_error& str)
        {
            const Element_type* const avz = a.last();
            for(Element_type* avi = &a[0]; avi<=avz; ++avi)
            {
                CONTAINER_POLICY::str2elem(*avi,str);
            }
        }
        template <typename CONTAINER_POLICY, typename CONTAINER_TYPE>
        void Arraytun_nosize<CONTAINER_POLICY,CONTAINER_TYPE>::elem2str(const CONTAINER_TYPE& a, Lossy& str)
        {
            const Element_type* const avz = a.last();
            for(const Element_type* avi = &a[0]; avi<=avz; ++avi)
            {
                CONTAINER_POLICY::elem2str(*avi,str);
            }
        }

        template <typename CONTAINER_POLICY,
                          typename SIZE_POLICY,
                          typename ARRAY>
        inline void Arraytun<CONTAINER_POLICY,SIZE_POLICY,ARRAY>::str2elem(ARRAY& a, Lossy_error& str)
        {
            SIZE_POLICY::str2elem(a,str);
            Tnosize::str2elem(a,str);
        }
        template <typename CONTAINER_POLICY,
                          typename SIZE_POLICY,
                          typename ARRAY>
        inline void Arraytun<CONTAINER_POLICY,SIZE_POLICY,ARRAY>::elem2str(const ARRAY& a, Lossy& str)
        {
            SIZE_POLICY::elem2str(a,str);
            Tnosize::elem2str(a,str);
        }

        template <typename T,Uint16 sz>
        inline void Tunarraymsk<T,sz>::str2elem(Arraymsk<T,sz>& am, Lossy_error& str) //PRQA S 5059 #PRQA fail (there's
        {                                                                             // not 3 parameters)
            Tunarray<T>(am).cset(str);
        }

        template <typename T,Uint16 sz>
        inline void Tunarraymsk<T,sz>::elem2str(const Arraymsk<T,sz>& am,Lossy& str) //PRQA S 5059 #PRQA fail (there's
        {                                                                            //               not 3 parameters)
            typename Tunarray<T,true>::Ktun(am).k.cget(str);
        }
    }
}
#endif
