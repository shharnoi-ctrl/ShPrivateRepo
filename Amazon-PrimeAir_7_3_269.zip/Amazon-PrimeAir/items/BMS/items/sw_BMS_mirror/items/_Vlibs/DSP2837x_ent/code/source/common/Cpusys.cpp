#include <Hregmap.h>
#include <Ku16.h>
#include <Ku32.h>
#include <Tnarray.h>
#include <Asm.h>
#include <Cpusys.h>

namespace Dsp28335_ent
{

    //PRQA S 2176 ++
    //#Unions used in HW register mapping in Texas Instruments' libraries.
    //PRQA S 2301 ++
    //#Bit-fields are needed.
    //PRQA S 5050 ++
    //#Identifiers will be kept by default
    //PRQA S 5051 ++
    //#Identifiers will be kept by default

    //---------------------------------------------------------------------------
    // SYSCTRL Individual Register Bit Definitions:

    struct CPUSYSLOCK1_BITS                 // bits description
    {
        Uint16 HIBBOOTMODE:1;               // 0 Lock bit for HIBBOOTMODE register
        Uint16 IORESTOREADDR:1;             // 1 Lock bit for IORESTOREADDR Register
        Uint16 PIEVERRADDR:1;               // 2 Lock bit for PIEVERRADDR Register
        Uint16 PCLKCR0:1;                   // 3 Lock bit for PCLKCR0 Register
        Uint16 PCLKCR1:1;                   // 4 Lock bit for PCLKCR1 Register
        Uint16 PCLKCR2:1;                   // 5 Lock bit for PCLKCR2 Register
        Uint16 PCLKCR3:1;                   // 6 Lock bit for PCLKCR3 Register
        Uint16 PCLKCR4:1;                   // 7 Lock bit for PCLKCR4 Register
        Uint16 PCLKCR5:1;                   // 8 Lock bit for PCLKCR5 Register
        Uint16 PCLKCR6:1;                   // 9 Lock bit for PCLKCR6 Register
        Uint16 PCLKCR7:1;                   // 10 Lock bit for PCLKCR7 Register
        Uint16 PCLKCR8:1;                   // 11 Lock bit for PCLKCR8 Register
        Uint16 PCLKCR9:1;                   // 12 Lock bit for PCLKCR9 Register
        Uint16 PCLKCR10:1;                  // 13 Lock bit for PCLKCR10 Register
        Uint16 PCLKCR11:1;                  // 14 Lock bit for PCLKCR11 Register
        Uint16 PCLKCR12:1;                  // 15 Lock bit for PCLKCR12 Register
        Uint16 PCLKCR13:1;                  // 16 Lock bit for PCLKCR13 Register
        Uint16 PCLKCR14:1;                  // 17 Lock bit for PCLKCR14 Register
        Uint16 PCLKCR15:1;                  // 18 Lock bit for PCLKCR15 Register
        Uint16 PCLKCR16:1;                  // 19 Lock bit for PCLKCR16 Register
        Uint16 SECMSEL:1;                   // 20 Lock bit for SECMSEL Register
        Uint16 LPMCR:1;                     // 21 Lock bit for LPMCR Register
        Uint16 GPIOLPMSEL0:1;               // 22 Lock bit for GPIOLPMSEL0 Register
        Uint16 GPIOLPMSEL1:1;               // 23 Lock bit for GPIOLPMSEL1 Register
        Uint16 rsvd1:8;                     // 31:24 Reserved
    };

    union CPUSYSLOCK1_REG
    {
        Uint32  all;
        struct  CPUSYSLOCK1_BITS  bit;
    };

    struct IORESTOREADDR_BITS               // bits description
    {
        Uint32 ADDR:22;                     // 21:0 restoreIO() routine address
        Uint16 rsvd1:10;                    // 31:22 Reserved
    };

    union IORESTOREADDR_REG
    {
        Uint32  all;
        struct  IORESTOREADDR_BITS  bit;
    };

    struct PIEVERRADDR_BITS                 // bits description
    {
        Uint32 ADDR:22;                     // 21:0 PIE Vector Fetch Error Handler Routine Address
        Uint16 rsvd1:10;                    // 31:22 Reserved
    };

    union PIEVERRADDR_REG
    {
        Uint32  all;
        struct  PIEVERRADDR_BITS  bit;
    };

    struct PCLKCR0_BITS                     // bits description
    {
        Uint16 CLA1:1;                      // 0 CLA1 Clock Enable Bit
        Uint16 rsvd1:1;                     // 1 Reserved
        Uint16 DMA:1;                       // 2 DMA Clock Enable bit
        Uint16 CPUTIMER0:1;                 // 3 CPUTIMER0 Clock Enable bit
        Uint16 CPUTIMER1:1;                 // 4 CPUTIMER1 Clock Enable bit
        Uint16 CPUTIMER2:1;                 // 5 CPUTIMER2 Clock Enable bit
        Uint16 rsvd2:10;                    // 15:6 Reserved
        Uint16 HRPWM:1;                     // 16 HRPWM Clock Enable Bit
        Uint16 rsvd3:1;                     // 17 Reserved
        Uint16 TBCLKSYNC:1;                 // 18 EPWM Time Base Clock sync
        Uint16 GTBCLKSYNC:1;                // 19 EPWM Time Base Clock Global sync
        Uint16 rsvd4:12;                    // 31:20 Reserved
    };

    union PCLKCR0_REG
    {
        Uint32  all;
        struct  PCLKCR0_BITS  bit;
    };

    struct PCLKCR1_BITS                     // bits description
    {
        Uint16 EMIF1:1;                     // 0 EMIF1 Clock Enable bit
        Uint16 EMIF2:1;                     // 1 EMIF2 Clock Enable bit
        Uint16 rsvd1:14;                    // 15:2 Reserved
        Uint16 rsvd2:16;                    // 31:16 Reserved
    };

    union PCLKCR1_REG
    {
        Uint32  all;
        struct  PCLKCR1_BITS  bit;
    };

    struct PCLKCR2_BITS                     // bits description
    {
        Uint16 EPWM1:1;                     // 0 EPWM1 Clock Enable bit
        Uint16 EPWM2:1;                     // 1 EPWM2 Clock Enable bit
        Uint16 EPWM3:1;                     // 2 EPWM3 Clock Enable bit
        Uint16 EPWM4:1;                     // 3 EPWM4 Clock Enable bit
        Uint16 EPWM5:1;                     // 4 EPWM5 Clock Enable bit
        Uint16 EPWM6:1;                     // 5 EPWM6 Clock Enable bit
        Uint16 EPWM7:1;                     // 6 EPWM7 Clock Enable bit
        Uint16 EPWM8:1;                     // 7 EPWM8 Clock Enable bit
        Uint16 EPWM9:1;                     // 8 EPWM9 Clock Enable bit
        Uint16 EPWM10:1;                    // 9 EPWM10 Clock Enable bit
        Uint16 EPWM11:1;                    // 10 EPWM11 Clock Enable bit
        Uint16 EPWM12:1;                    // 11 EPWM12 Clock Enable bit
        Uint16 rsvd1:1;                     // 12 Reserved
        Uint16 rsvd2:1;                     // 13 Reserved
        Uint16 rsvd3:1;                     // 14 Reserved
        Uint16 rsvd4:1;                     // 15 Reserved
        Uint16 rsvd5:16;                    // 31:16 Reserved
    };

    union PCLKCR2_REG
    {
        Uint32  all;
        struct  PCLKCR2_BITS  bit;
    };

    struct PCLKCR3_BITS                     // bits description
    {
        Uint16 ECAP1:1;                     // 0 ECAP1 Clock Enable bit
        Uint16 ECAP2:1;                     // 1 ECAP2 Clock Enable bit
        Uint16 ECAP3:1;                     // 2 ECAP3 Clock Enable bit
        Uint16 ECAP4:1;                     // 3 ECAP4 Clock Enable bit
        Uint16 ECAP5:1;                     // 4 ECAP5 Clock Enable bit
        Uint16 ECAP6:1;                     // 5 ECAP6 Clock Enable bit
        Uint16 rsvd1:1;                     // 6 Reserved
        Uint16 rsvd2:1;                     // 7 Reserved
        Uint16 rsvd3:8;                     // 15:8 Reserved
        Uint16 rsvd4:16;                    // 31:16 Reserved
    };

    union PCLKCR3_REG
    {
        Uint32  all;
        struct  PCLKCR3_BITS  bit;
    };

    struct PCLKCR4_BITS                     // bits description
    {
        Uint16 EQEP1:1;                     // 0 EQEP1 Clock Enable bit
        Uint16 EQEP2:1;                     // 1 EQEP2 Clock Enable bit
        Uint16 EQEP3:1;                     // 2 EQEP3 Clock Enable bit
        Uint16 rsvd1:1;                     // 3 Reserved
        Uint16 rsvd2:12;                    // 15:4 Reserved
        Uint16 rsvd3:16;                    // 31:16 Reserved
    };

    union PCLKCR4_REG
    {
        Uint32  all;
        struct  PCLKCR4_BITS  bit;
    };

    struct PCLKCR6_BITS                     // bits description
    {
        Uint16 SD1:1;                       // 0 SD1 Clock Enable bit
        Uint16 SD2:1;                       // 1 SD2 Clock Enable bit
        Uint16 rsvd1:1;                     // 2 Reserved
        Uint16 rsvd2:1;                     // 3 Reserved
        Uint16 rsvd3:1;                     // 4 Reserved
        Uint16 rsvd4:1;                     // 5 Reserved
        Uint16 rsvd5:1;                     // 6 Reserved
        Uint16 rsvd6:1;                     // 7 Reserved
        Uint16 rsvd7:8;                     // 15:8 Reserved
        Uint16 rsvd8:16;                    // 31:16 Reserved
    };

    union PCLKCR6_REG
    {
        Uint32  all;
        struct  PCLKCR6_BITS  bit;
    };

    struct PCLKCR7_BITS                     // bits description
    {
        Uint16 SCI_A:1;                     // 0 SCI_A Clock Enable bit
        Uint16 SCI_B:1;                     // 1 SCI_B Clock Enable bit
        Uint16 SCI_C:1;                     // 2 SCI_C Clock Enable bit
        Uint16 SCI_D:1;                     // 3 SCI_D Clock Enable bit
        Uint16 rsvd1:12;                    // 15:4 Reserved
        Uint16 rsvd2:16;                    // 31:16 Reserved
    };

    union PCLKCR7_REG
    {
        Uint32  all;
        struct  PCLKCR7_BITS  bit;
    };

    struct PCLKCR8_BITS                     // bits description
    {
        Uint16 SPI_A:1;                     // 0 SPI_A Clock Enable bit
        Uint16 SPI_B:1;                     // 1 SPI_B Clock Enable bit
        Uint16 SPI_C:1;                     // 2 SPI_C Clock Enable bit
        Uint16 rsvd1:1;                     // 3 Reserved
        Uint16 rsvd2:12;                    // 15:4 Reserved
        Uint16 rsvd3:1;                     // 16 Reserved
        Uint16 rsvd4:1;                     // 17 Reserved
        Uint16 rsvd5:14;                    // 31:18 Reserved
    };

    union PCLKCR8_REG
    {
        Uint32  all;
        struct  PCLKCR8_BITS  bit;
    };

    struct PCLKCR9_BITS                     // bits description
    {
        Uint16 I2C_A:1;                     // 0 I2C_A Clock Enable bit
        Uint16 I2C_B:1;                     // 1 I2C_B Clock Enable bit
        Uint16 rsvd1:14;                    // 15:2 Reserved
        Uint16 rsvd2:1;                     // 16 Reserved
        Uint16 rsvd3:1;                     // 17 Reserved
        Uint16 rsvd4:14;                    // 31:18 Reserved
    };

    union PCLKCR9_REG
    {
        Uint32  all;
        struct  PCLKCR9_BITS  bit;
    };

    struct PCLKCR10_BITS                    // bits description
    {
        Uint16 CAN_A:1;                     // 0 CAN_A Clock Enable bit
        Uint16 CAN_B:1;                     // 1 CAN_B Clock Enable bit
        Uint16 rsvd1:1;                     // 2 Reserved
        Uint16 rsvd2:1;                     // 3 Reserved
        Uint16 rsvd3:12;                    // 15:4 Reserved
        Uint16 rsvd4:16;                    // 31:16 Reserved
    };

    union PCLKCR10_REG
    {
        Uint32  all;
        struct  PCLKCR10_BITS  bit;
    };

    struct PCLKCR11_BITS                    // bits description
    {
        Uint16 McBSP_A:1;                   // 0 McBSP_A Clock Enable bit
        Uint16 McBSP_B:1;                   // 1 McBSP_B Clock Enable bit
        Uint16 rsvd1:14;                    // 15:2 Reserved
        Uint16 USB_A:1;                     // 16 USB_A Clock Enable bit
        Uint16 rsvd2:1;                     // 17 Reserved
        Uint16 rsvd3:14;                    // 31:18 Reserved
    };

    union PCLKCR11_REG
    {
        Uint32  all;
        struct  PCLKCR11_BITS  bit;
    };

    struct PCLKCR12_BITS                    // bits description
    {
        Uint16 uPP_A:1;                     // 0 uPP_A Clock Enable bit
        Uint16 rsvd1:1;                     // 1 Reserved
        Uint16 rsvd2:14;                    // 15:2 Reserved
        Uint16 rsvd3:16;                    // 31:16 Reserved
    };

    union PCLKCR12_REG
    {
        Uint32  all;
        struct  PCLKCR12_BITS  bit;
    };

    struct PCLKCR13_BITS                    // bits description
    {
        Uint16 ADC_A:1;                     // 0 ADC_A Clock Enable bit
        Uint16 ADC_B:1;                     // 1 ADC_B Clock Enable bit
        Uint16 ADC_C:1;                     // 2 ADC_C Clock Enable bit
        Uint16 ADC_D:1;                     // 3 ADC_D Clock Enable bit
        Uint16 rsvd1:12;                    // 15:4 Reserved
        Uint16 rsvd2:16;                    // 31:16 Reserved
    };

    union PCLKCR13_REG
    {
        Uint32  all;
        struct  PCLKCR13_BITS  bit;
    };

    struct PCLKCR14_BITS                    // bits description
    {
        Uint16 CMPSS1:1;                    // 0 CMPSS1 Clock Enable bit
        Uint16 CMPSS2:1;                    // 1 CMPSS2 Clock Enable bit
        Uint16 CMPSS3:1;                    // 2 CMPSS3 Clock Enable bit
        Uint16 CMPSS4:1;                    // 3 CMPSS4 Clock Enable bit
        Uint16 CMPSS5:1;                    // 4 CMPSS5 Clock Enable bit
        Uint16 CMPSS6:1;                    // 5 CMPSS6 Clock Enable bit
        Uint16 CMPSS7:1;                    // 6 CMPSS7 Clock Enable bit
        Uint16 CMPSS8:1;                    // 7 CMPSS8 Clock Enable bit
        Uint16 rsvd1:8;                     // 15:8 Reserved
        Uint16 rsvd2:16;                    // 31:16 Reserved
    };

    union PCLKCR14_REG
    {
        Uint32  all;
        struct  PCLKCR14_BITS  bit;
    };

    struct PCLKCR16_BITS                    // bits description
    {
        Uint16 rsvd1:1;                     // 0 Reserved
        Uint16 rsvd2:1;                     // 1 Reserved
        Uint16 rsvd3:1;                     // 2 Reserved
        Uint16 rsvd4:1;                     // 3 Reserved
        Uint16 rsvd5:12;                    // 15:4 Reserved
        Uint16 DAC_A:1;                     // 16 Buffered_DAC_A Clock Enable Bit
        Uint16 DAC_B:1;                     // 17 Buffered_DAC_B Clock Enable Bit
        Uint16 DAC_C:1;                     // 18 Buffered_DAC_C Clock Enable Bit
        Uint16 rsvd6:1;                     // 19 Reserved
        Uint16 rsvd7:12;                    // 31:20 Reserved
    };

    union PCLKCR16_REG
    {
        Uint32  all;
        struct  PCLKCR16_BITS  bit;
    };

    struct SECMSEL_BITS                     // bits description
    {
        Uint16 PF1SEL:2;                    // 1:0 Secondary Master Select for VBUS32_1 Bridge
        Uint16 PF2SEL:2;                    // 3:2 Secondary Master Select for VBUS32_2 Bridge
        Uint16 rsvd1:2;                     // 5:4 Reserved
        Uint16 rsvd2:2;                     // 7:6 Reserved
        Uint16 rsvd3:2;                     // 9:8 Reserved
        Uint16 rsvd4:2;                     // 11:10 Reserved
        Uint16 rsvd5:2;                     // 13:12 Reserved
        Uint16 rsvd6:2;                     // 15:14 Reserved
        Uint16 rsvd7:16;                    // 31:16 Reserved
    };

    union SECMSEL_REG
    {
        Uint32  all;
        struct  SECMSEL_BITS  bit;
    };

    struct LPMCR_BITS                       // bits description
    {
        Uint16 LPM:2;                       // 1:0 Low Power Mode setting
        Uint16 QUALSTDBY:6;                 // 7:2 STANDBY Wakeup Pin Qualification Setting
        Uint16 rsvd1:7;                     // 14:8 Reserved
        Uint16 WDINTE:1;                    // 15 Enable for WDINT wakeup from STANDBY
        Uint16 M0M1MODE:2;                  // 17:16 Configuration for M0 and M1 mode during HIB
        Uint16 rsvd2:13;                    // 30:18 Reserved
        Uint16 IOISODIS:1;                  // 31 IO Isolation Disable
    };

    union LPMCR_REG
    {
        Uint32  all;
        struct  LPMCR_BITS  bit;
    };

    struct GPIOLPMSEL0_BITS                 // bits description
    {
        Uint16 GPIO0:1;                     // 0 GPIO0 Enable for LPM Wakeup
        Uint16 GPIO1:1;                     // 1 GPIO1 Enable for LPM Wakeup
        Uint16 GPIO2:1;                     // 2 GPIO2 Enable for LPM Wakeup
        Uint16 GPIO3:1;                     // 3 GPIO3 Enable for LPM Wakeup
        Uint16 GPIO4:1;                     // 4 GPIO4 Enable for LPM Wakeup
        Uint16 GPIO5:1;                     // 5 GPIO5 Enable for LPM Wakeup
        Uint16 GPIO6:1;                     // 6 GPIO6 Enable for LPM Wakeup
        Uint16 GPIO7:1;                     // 7 GPIO7 Enable for LPM Wakeup
        Uint16 GPIO8:1;                     // 8 GPIO8 Enable for LPM Wakeup
        Uint16 GPIO9:1;                     // 9 GPIO9 Enable for LPM Wakeup
        Uint16 GPIO10:1;                    // 10 GPIO10 Enable for LPM Wakeup
        Uint16 GPIO11:1;                    // 11 GPIO11 Enable for LPM Wakeup
        Uint16 GPIO12:1;                    // 12 GPIO12 Enable for LPM Wakeup
        Uint16 GPIO13:1;                    // 13 GPIO13 Enable for LPM Wakeup
        Uint16 GPIO14:1;                    // 14 GPIO14 Enable for LPM Wakeup
        Uint16 GPIO15:1;                    // 15 GPIO15 Enable for LPM Wakeup
        Uint16 GPIO16:1;                    // 16 GPIO16 Enable for LPM Wakeup
        Uint16 GPIO17:1;                    // 17 GPIO17 Enable for LPM Wakeup
        Uint16 GPIO18:1;                    // 18 GPIO18 Enable for LPM Wakeup
        Uint16 GPIO19:1;                    // 19 GPIO19 Enable for LPM Wakeup
        Uint16 GPIO20:1;                    // 20 GPIO20 Enable for LPM Wakeup
        Uint16 GPIO21:1;                    // 21 GPIO21 Enable for LPM Wakeup
        Uint16 GPIO22:1;                    // 22 GPIO22 Enable for LPM Wakeup
        Uint16 GPIO23:1;                    // 23 GPIO23 Enable for LPM Wakeup
        Uint16 GPIO24:1;                    // 24 GPIO24 Enable for LPM Wakeup
        Uint16 GPIO25:1;                    // 25 GPIO25 Enable for LPM Wakeup
        Uint16 GPIO26:1;                    // 26 GPIO26 Enable for LPM Wakeup
        Uint16 GPIO27:1;                    // 27 GPIO27 Enable for LPM Wakeup
        Uint16 GPIO28:1;                    // 28 GPIO28 Enable for LPM Wakeup
        Uint16 GPIO29:1;                    // 29 GPIO29 Enable for LPM Wakeup
        Uint16 GPIO30:1;                    // 30 GPIO30 Enable for LPM Wakeup
        Uint16 GPIO31:1;                    // 31 GPIO31 Enable for LPM Wakeup
    };

    union GPIOLPMSEL0_REG
    {
        Uint32  all;
        struct  GPIOLPMSEL0_BITS  bit;
    };

    struct GPIOLPMSEL1_BITS                 // bits description
    {
        Uint16 GPIO32:1;                    // 0 GPIO32 Enable for LPM Wakeup
        Uint16 GPIO33:1;                    // 1 GPIO33 Enable for LPM Wakeup
        Uint16 GPIO34:1;                    // 2 GPIO34 Enable for LPM Wakeup
        Uint16 GPIO35:1;                    // 3 GPIO35 Enable for LPM Wakeup
        Uint16 GPIO36:1;                    // 4 GPIO36 Enable for LPM Wakeup
        Uint16 GPIO37:1;                    // 5 GPIO37 Enable for LPM Wakeup
        Uint16 GPIO38:1;                    // 6 GPIO38 Enable for LPM Wakeup
        Uint16 GPIO39:1;                    // 7 GPIO39 Enable for LPM Wakeup
        Uint16 GPIO40:1;                    // 8 GPIO40 Enable for LPM Wakeup
        Uint16 GPIO41:1;                    // 9 GPIO41 Enable for LPM Wakeup
        Uint16 GPIO42:1;                    // 10 GPIO42 Enable for LPM Wakeup
        Uint16 GPIO43:1;                    // 11 GPIO43 Enable for LPM Wakeup
        Uint16 GPIO44:1;                    // 12 GPIO44 Enable for LPM Wakeup
        Uint16 GPIO45:1;                    // 13 GPIO45 Enable for LPM Wakeup
        Uint16 GPIO46:1;                    // 14 GPIO46 Enable for LPM Wakeup
        Uint16 GPIO47:1;                    // 15 GPIO47 Enable for LPM Wakeup
        Uint16 GPIO48:1;                    // 16 GPIO48 Enable for LPM Wakeup
        Uint16 GPIO49:1;                    // 17 GPIO49 Enable for LPM Wakeup
        Uint16 GPIO50:1;                    // 18 GPIO50 Enable for LPM Wakeup
        Uint16 GPIO51:1;                    // 19 GPIO51 Enable for LPM Wakeup
        Uint16 GPIO52:1;                    // 20 GPIO52 Enable for LPM Wakeup
        Uint16 GPIO53:1;                    // 21 GPIO53 Enable for LPM Wakeup
        Uint16 GPIO54:1;                    // 22 GPIO54 Enable for LPM Wakeup
        Uint16 GPIO55:1;                    // 23 GPIO55 Enable for LPM Wakeup
        Uint16 GPIO56:1;                    // 24 GPIO56 Enable for LPM Wakeup
        Uint16 GPIO57:1;                    // 25 GPIO57 Enable for LPM Wakeup
        Uint16 GPIO58:1;                    // 26 GPIO58 Enable for LPM Wakeup
        Uint16 GPIO59:1;                    // 27 GPIO59 Enable for LPM Wakeup
        Uint16 GPIO60:1;                    // 28 GPIO60 Enable for LPM Wakeup
        Uint16 GPIO61:1;                    // 29 GPIO61 Enable for LPM Wakeup
        Uint16 GPIO62:1;                    // 30 GPIO62 Enable for LPM Wakeup
        Uint16 GPIO63:1;                    // 31 GPIO63 Enable for LPM Wakeup
    };

    union GPIOLPMSEL1_REG
    {
        Uint32  all;
        struct  GPIOLPMSEL1_BITS  bit;
    };

    struct TMR2CLKCTL_BITS                  // bits description
    {
        Uint16 TMR2CLKSRCSEL:3;             // 2:0 CPU Timer 2 Clock Source Select Bit
        Uint16 TMR2CLKPRESCALE:3;           // 5:3 CPU Timer 2 Clock Pre-Scale Value
        Uint16 rsvd1:10;                    // 15:6 Reserved
        Uint16 rsvd2:16;                    // 31:16 Reserved
    };

    union TMR2CLKCTL_REG
    {
        Uint32  all;
        struct  TMR2CLKCTL_BITS  bit;
    };

    struct RESC_BITS                        // bits description
    {
        Uint16 POR:1;                       // 0 POR Reset Cause Indication Bit
        Uint16 XRSn:1;                      // 1 XRSn Reset Cause Indication Bit
        Uint16 WDRSn:1;                     // 2 WDRSn Reset Cause Indication Bit
        Uint16 NMIWDRSn:1;                  // 3 NMIWDRSn Reset Cause Indication Bit
        Uint16 rsvd1:1;                     // 4 Reserved
        Uint16 HWBISTn:1;                   // 5 HWBISTn Reset Cause Indication Bit
        Uint16 HIBRESETn:1;                 // 6 HIBRESETn Reset Cause Indication Bit
        Uint16 rsvd2:1;                     // 7 Reserved
        Uint16 SCCRESETn:1;                 // 8 SCCRESETn Reset Cause Indication Bit
        Uint16 rsvd3:7;                     // 15:9 Reserved
        Uint16 rsvd4:14;                    // 29:16 Reserved
        Uint16 XRSn_pin_status:1;           // 30 XRSN Pin Status
        Uint16 TRSTn_pin_status:1;          // 31 TRSTn Status
    };

    union RESC_REG
    {
        Uint32  all;
        struct  RESC_BITS  bit;
    };


    struct Pclkcr_group
    {
        union   PCLKCR0_REG                      PCLKCR0;   ///< Peripheral Clock Gating Registers
        union   PCLKCR1_REG                      PCLKCR1;   ///< Peripheral Clock Gating Registers
        union   PCLKCR2_REG                      PCLKCR2;   ///< Peripheral Clock Gating Registers
        union   PCLKCR3_REG                      PCLKCR3;   ///< Peripheral Clock Gating Registers
        union   PCLKCR4_REG                      PCLKCR4;   ///< Peripheral Clock Gating Registers
        Uint32                                   rsvd3;     ///< Reserved
        union   PCLKCR6_REG                      PCLKCR6;   ///< Peripheral Clock Gating Registers
        union   PCLKCR7_REG                      PCLKCR7;   ///< Peripheral Clock Gating Registers
        union   PCLKCR8_REG                      PCLKCR8;   ///< Peripheral Clock Gating Registers
        union   PCLKCR9_REG                      PCLKCR9;   ///< Peripheral Clock Gating Registers
        union   PCLKCR10_REG                     PCLKCR10;  ///< Peripheral Clock Gating Registers
        union   PCLKCR11_REG                     PCLKCR11;  ///< Peripheral Clock Gating Registers
        union   PCLKCR12_REG                     PCLKCR12;  ///< Peripheral Clock Gating Registers
        union   PCLKCR13_REG                     PCLKCR13;  ///< Peripheral Clock Gating Registers
        union   PCLKCR14_REG                     PCLKCR14;  ///< Peripheral Clock Gating Registers
        Uint32                                   rsvd4;     ///< Reserved
        union   PCLKCR16_REG                     PCLKCR16;  ///< Peripheral Clock Gating Registers
    };

    static const Uint16 pclkcr_group_sz16 = 17;

    union Pclkcr_regs
    {
        Base::Tnarray<Uint32, pclkcr_group_sz16> v;
        Pclkcr_group regs;
    };

    struct Cpusys::Registers
    {
        CPUSYSLOCK1_REG     CPUSYSLOCK1;          ///< Lock bit for CPUSYS registers
        Uint16              rsvd1[Ku16::u4];      ///< Reserved
        Uint32              HIBBOOTMODE;          ///< HIB Boot Mode Register
        IORESTOREADDR_REG   IORESTOREADDR;        ///< IORestore() routine Address Register
        PIEVERRADDR_REG     PIEVERRADDR;          ///< PIE Vector Fetch Error Address register
        Uint16              rsvd2[Ku16::u22];     ///< Reserved
        Pclkcr_regs         pclkcr;               ///< Peripheral CLK enable registers
        Uint16              rsvd5[Ku16::u48];     ///< Reserved
        SECMSEL_REG         SECMSEL;              ///< Secondary Master Select for common peripherals between CLA & DMA
        LPMCR_REG           LPMCR;                ///< LPM Control Register
        GPIOLPMSEL0_REG     GPIOLPMSEL0;          ///< GPIO LPM Wakeup select registers
        GPIOLPMSEL1_REG     GPIOLPMSEL1;          ///< GPIO LPM Wakeup select registers
        TMR2CLKCTL_REG      TMR2CLKCTL;           ///< Timer2 Clock Measurement functionality control register
        Uint16              rsvd6[Ku16::u2];      ///< Reserved
        RESC_REG            RESC;                 ///< Reset Cause register
    };


    //PRQA S 2176 --
    //#Unions used in HW register mapping in Texas Instruments' libraries.
    //PRQA S 2301 --
    //#Bit-fields are needed.
    //PRQA S 5050 --
    //#Identifiers will be kept by default
    //PRQA S 5051 --
    //#Identifiers will be kept by default

    static const Uint32 cpu_sys_regs_addr = 0x05D300UL;
    static const Uint32 clk_dev_msk   = 0xFFFFFFFFU;

    Cpusys::Cpusys() : regs(Hregmap::get<Registers, cpu_sys_regs_addr>())
    {
        Base::Assertions::Compile_time<(sizeof(regs.pclkcr.v) == sizeof(regs.pclkcr.regs))>();
    }

    inline Cpusys::Peripheral_t get_clk_reg_idx(Cpusys::Peripheral p)
    {
        return static_cast<Cpusys::Peripheral_t>(p >> Cpusys::reg_sz);
    }

    inline static Uint32 get_clk_dev(Cpusys::Peripheral p)
    {
        return (p & clk_dev_msk);
    }

    void Cpusys::clk_enable(Peripheral p)
    {
        asm_eallow();
        regs.pclkcr.v[get_clk_reg_idx(p)] |= get_clk_dev(p);
        asm_edis();
    }

    void Cpusys::clk_disable(Peripheral p)
    {
        asm_eallow();
        regs.pclkcr.v[get_clk_reg_idx(p)] &= ~get_clk_dev(p);
        asm_edis();
    }

    void Cpusys::clk_enable(Peripheral_t pt, Uint32 dev_num)
    {
        asm_eallow();
        regs.pclkcr.v[pt] |= static_cast<Uint32>(1UL) << dev_num;
        asm_edis();
    }

    void Cpusys::clk_disable(Peripheral_t pt, Uint32 dev_num)
    {
        asm_eallow();
        regs.pclkcr.v[pt] &= ~static_cast<Uint32>(1UL) << dev_num;
        asm_edis();
    }


    void Cpusys::clk_enable_pwm(Uint16 module_id)
    {
        asm_eallow();
        regs.pclkcr.regs.PCLKCR0.bit.TBCLKSYNC = 0;
        regs.pclkcr.regs.PCLKCR2.all |= (1UL)<<module_id;
        regs.pclkcr.regs.PCLKCR0.bit.TBCLKSYNC = 1;
        asm_edis();
    }

    Uint16 Cpusys::get_tmr2clkctl_srcsel() const
    {
        return regs.TMR2CLKCTL.bit.TMR2CLKSRCSEL;
    }

    Uint16 Cpusys::get_tmr2clkctl_prescale() const
    {
        return regs.TMR2CLKCTL.bit.TMR2CLKPRESCALE;
    }

    void Cpusys::set_tmr2clkctl(Uint16 srcsel, Uint16 prescale)
    {
        asm_eallow();
        regs.TMR2CLKCTL.bit.TMR2CLKSRCSEL = srcsel;
        regs.TMR2CLKCTL.bit.TMR2CLKPRESCALE = prescale;
        asm_edis();
    }

    void Cpusys::pfsel_dma()
    {
        asm_eallow();
        regs.SECMSEL.bit.PF1SEL = 1; // peripheral frame control to DMA (instead of CLA)
        regs.SECMSEL.bit.PF2SEL = 1; // peripheral frame control to DMA (instead of CLA)
        asm_edis();
    }

    bool Cpusys::is_jtag_connected() const
    {
        return regs.RESC.bit.TRSTn_pin_status;
    }

    bool Cpusys::is_reset_wdog_flag() const
    {
        return regs.RESC.bit.WDRSn;
    }

    void Cpusys::clear_reset_wdog_flag() const
    {
        regs.RESC.bit.WDRSn = 1;
    }
}
