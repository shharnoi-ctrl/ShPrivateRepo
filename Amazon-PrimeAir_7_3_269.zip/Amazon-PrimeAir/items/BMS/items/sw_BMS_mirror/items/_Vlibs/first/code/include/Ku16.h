#ifndef KU16_H_
#define KU16_H_

#include <Entypes.h>

namespace Ku16
{
    static const Uint16 u0=           static_cast<Uint16>(0);
    static const Uint16 u1=           static_cast<Uint16>(1);
    static const Uint16 u2=           static_cast<Uint16>(2);
    static const Uint16 u3=           static_cast<Uint16>(3);
    static const Uint16 u4=           static_cast<Uint16>(4);
    static const Uint16 u5=           static_cast<Uint16>(5);
    static const Uint16 u6=           static_cast<Uint16>(6);
    static const Uint16 u7=           static_cast<Uint16>(7);
    static const Uint16 u8=           static_cast<Uint16>(8);
    static const Uint16 u9=           static_cast<Uint16>(9);
    static const Uint16 u10=          static_cast<Uint16>(10);
    static const Uint16 u11=          static_cast<Uint16>(11);
    static const Uint16 u12=          static_cast<Uint16>(12);
    static const Uint16 u13=          static_cast<Uint16>(13);
    static const Uint16 u14=          static_cast<Uint16>(14);
    static const Uint16 u15=          static_cast<Uint16>(15);
    static const Uint16 u16=          static_cast<Uint16>(16);
    static const Uint16 u17=          static_cast<Uint16>(17);
    static const Uint16 u18=          static_cast<Uint16>(18);
    static const Uint16 u19=          static_cast<Uint16>(19);
    static const Uint16 u20=          static_cast<Uint16>(20);
    static const Uint16 u21=          static_cast<Uint16>(21);
    static const Uint16 u22=          static_cast<Uint16>(22);
    static const Uint16 u23=          static_cast<Uint16>(23);
    static const Uint16 u24=          static_cast<Uint16>(24);
    static const Uint16 u25=          static_cast<Uint16>(25);
    static const Uint16 u26=          static_cast<Uint16>(26);
    static const Uint16 u28=          static_cast<Uint16>(28);
    static const Uint16 u29=          static_cast<Uint16>(29);
    static const Uint16 u30=          static_cast<Uint16>(30);
    static const Uint16 u31=          static_cast<Uint16>(31);
    static const Uint16 u32=          static_cast<Uint16>(32);
    static const Uint16 u33=          static_cast<Uint16>(33);
    static const Uint16 u36=          static_cast<Uint16>(36);
    static const Uint16 u40=          static_cast<Uint16>(40);
    static const Uint16 u42=          static_cast<Uint16>(42);
    static const Uint16 u43=          static_cast<Uint16>(43);
    static const Uint16 u46=          static_cast<Uint16>(46);
    static const Uint16 u48=          static_cast<Uint16>(48);
    static const Uint16 u50=          static_cast<Uint16>(50);
    static const Uint16 u53=          static_cast<Uint16>(53);
    static const Uint16 u56=          static_cast<Uint16>(56);
    static const Uint16 u60=          static_cast<Uint16>(60);
    static const Uint16 u61=          static_cast<Uint16>(61);
    static const Uint16 u64=          static_cast<Uint16>(64);
    static const Uint16 u70=          static_cast<Uint16>(70);
    static const Uint16 u71=          static_cast<Uint16>(71);
    static const Uint16 u72=          static_cast<Uint16>(72);
    static const Uint16 u84=          static_cast<Uint16>(84);
    static const Uint16 u96=          static_cast<Uint16>(96);
    static const Uint16 u100=         static_cast<Uint16>(100);
    static const Uint16 u101=         static_cast<Uint16>(101);
    static const Uint16 u112=         static_cast<Uint16>(112);
    static const Uint16 u120=         static_cast<Uint16>(120);
    static const Uint16 u128=         static_cast<Uint16>(128);
    static const Uint16 u150=         static_cast<Uint16>(150);
    static const Uint16 u180=         static_cast<Uint16>(180);
    static const Uint16 u192=         static_cast<Uint16>(192);
    static const Uint16 u200=         static_cast<Uint16>(200);
    static const Uint16 u256=         static_cast<Uint16>(256);
    static const Uint16 u300=         static_cast<Uint16>(300);
    static const Uint16 u340=         static_cast<Uint16>(340);
    static const Uint16 u500=         static_cast<Uint16>(500);
    static const Uint16 u512=         static_cast<Uint16>(512);
    static const Uint16 u1000=        static_cast<Uint16>(1000);
    static const Uint16 u2000=        static_cast<Uint16>(2000);
    static const Uint16 u25000=       static_cast<Uint16>(25000);
    static const Uint16 u30000=       static_cast<Uint16>(30000);

    static const Uint16 u0x0=         static_cast<Uint16>(0x0);
    static const Uint16 u0x3=         static_cast<Uint16>(0x3);
    static const Uint16 u0x6=         static_cast<Uint16>(0x6);
    static const Uint16 u0xF=         static_cast<Uint16>(0xF);
    static const Uint16 u0x00=        static_cast<Uint16>(0x00);
    static const Uint16 u0x01=        static_cast<Uint16>(0x01);
    static const Uint16 u0x02=        static_cast<Uint16>(0x02);
    static const Uint16 u0x04=        static_cast<Uint16>(0x04);
    static const Uint16 u0x08=        static_cast<Uint16>(0x08);
    static const Uint16 u0x10=        static_cast<Uint16>(0x10);
    static const Uint16 u0x20=        static_cast<Uint16>(0x20);
    static const Uint16 u0x0F=        static_cast<Uint16>(0x0F);
    static const Uint16 u0x1F=        static_cast<Uint16>(0x1F);
    static const Uint16 u0x7F=        static_cast<Uint16>(0x7F);
    static const Uint16 u0xFF=        static_cast<Uint16>(0xFF);
    static const Uint16 u0x00F0=      static_cast<Uint16>(0x00F0);
    static const Uint16 u0x00FF=      static_cast<Uint16>(0x00FF);
    static const Uint16 u0x8000=      static_cast<Uint16>(0x8000);
    static const Uint16 u0xFF00=      static_cast<Uint16>(0xFF00);
    static const Uint16 u0xFFFF=      static_cast<Uint16>(0xFFFF);
    static const Uint16 uMAX=         static_cast<Uint16>(0xFFFF);
    static const Uint16 u0xAA=        static_cast<Uint16>(0xAA);
    static const Uint16 u0x0002=      static_cast<Uint16>(0x0002);
    static const Uint16 u0x0003=      static_cast<Uint16>(0x0003);
    static const Uint16 u0x55=        static_cast<Uint16>(0x55);
    static const Uint16 u0x80=        static_cast<Uint16>(0x80);
    static const Uint16 u0x00B7=      static_cast<Uint16>(0x00B7);
    static const Uint16 u0x0037=      static_cast<Uint16>(0x0037);
    static const Uint16 u0x5C=        0x5C;
    static const Uint16 u0xFFFEU=     0xFFFEU;

}

#endif
