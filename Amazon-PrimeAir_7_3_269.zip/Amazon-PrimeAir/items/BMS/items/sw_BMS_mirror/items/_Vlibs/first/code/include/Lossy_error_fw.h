#ifndef LOSSY_ERROR_FW_H_
#define LOSSY_ERROR_FW_H_
namespace Base
{
    class Lossy_error;
}
#endif
