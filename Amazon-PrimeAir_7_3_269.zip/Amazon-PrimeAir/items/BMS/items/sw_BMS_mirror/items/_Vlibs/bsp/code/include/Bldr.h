#ifndef BLDR_H_
#define BLDR_H_

#include <Entypes.h>

namespace Bsp
{
    static const Uint32 force_bldr_value = 0x55AA5A5A;
    /// Bootloader Launcher.
    /// \wi{17618}
    /// launch_bootloader method shall provide the capability to enter in bootloader mode.
    void launch_bootloader();
    /// Bootloader Force Getter.
    /// \wi{17619}
    /// get_force_bootloader method shall provide the capability to retrieve ::force_bootloader value.
    /// \return     ::force_bootloader varaible.
    bool get_force_bootloader();
}
#endif
