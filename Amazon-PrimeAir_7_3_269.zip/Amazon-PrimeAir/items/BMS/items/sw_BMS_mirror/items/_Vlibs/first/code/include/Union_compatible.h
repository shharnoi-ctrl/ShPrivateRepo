#ifndef UNION_COMPATIBLE_H_
#define UNION_COMPATIBLE_H_

#include <Vtraits.h>

namespace Base
{
    namespace Assertions
    {
        /// compile failure if T is not compatible as member of an union
        /// usage: assert_union_compatible<int>();
        template <typename T>
        struct Union_compatible : public Value_is<typename union_of<T,char>::type*,
                                                  static_cast<typename union_of<T,char>::type*>(0)>
        {
        }; // TODO: Change this so it detects that a class has no virtual methods (in SIL it is used !std::is_polymorphic)

        template <typename T>
        struct is_trivial : public Value_is<typename union_of<T,char>::type*,
                                                  static_cast<typename union_of<T,char>::type*>(0)>
        {
        }; // TODO: Change this so it detects that a class is trivial (in SIL it is used std::is_trivial)
    }
}

#endif
