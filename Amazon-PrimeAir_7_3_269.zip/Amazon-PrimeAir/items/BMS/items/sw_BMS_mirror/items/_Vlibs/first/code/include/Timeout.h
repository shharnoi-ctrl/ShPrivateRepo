#ifndef BASE_TIMEOUT_H_
#define BASE_TIMEOUT_H_

#include <Entypes.h>
#include <Htime.h>

namespace Base
{
    /// Class to check for timeout. Optimized to work internally only in ticks.
    class Timeout
    {
    public:
        /// Timeout Constructor.
        /// \wi{16979}
        /// Timeout class shall initialize itself upon construction and initialize its internal members.
        /// \param[in] time     Time in seconds.
        explicit Timeout(Real time);
        /// Timeout Constructor.
        /// \wi{16980}
        /// Timeout class shall initialize itself upon constructor and initialize its internal members.
        /// \param[in] ticks    Time in ticks.
        explicit Timeout(int64 ticks);      ///< Initialize with time in ticks.

        /// Timeout Seconds Setter.
        /// \wi{16981}
        /// Timeout class shall provide the capability to reset the timeout and set its time in seconds.
        /// \param[in] time     Time in secsonds.
        void set_timeout_s(Real time);
        /// Timeout Ticks Setter.
        /// \wi{16982}
        /// Timeout class shall provide the capability to reset the timeout and set its timer in ticks.
        /// \param[in] ticks    Time in ticks.
        void set_timeout_t(int64 ticks);
        
        /// Timeout Starter.
        /// \wi{16983}
        /// Timeout class shall provide the capability to start the timeout check.
        void start();
        /// Timeout Expiration Checker.
        /// \wi{16984}
        /// Timeout class shall provide the capability to check if timeout has expired
        /// \return     True if timeout has been reach.
        bool expired() const;
        /// Timeout Force Expiration.
        /// \wi{16985}
        /// Timeout class shall provide the capability to make the timeout to expire.
        void make_expired();

    private:
        Ttime t_out;           ///< Expected timeout in ticks.
        Ttime t_expiration;    ///< Absolute time in which the timeout reaches its end.

        /// Timeout Time To Ticks Converter.
        /// \wi{16986}
        /// Timeout class shall provide the capability to convert time in seconds to ticks.
        /// \param[in] time     Time in seconds.
        /// \param[in] freq     Frequency for computing ticks.
        /// \return             Ttime object with time in ticks.
        static Ttime t_to_ticks(Real time, Uint32 freq);

        /// Timeout Expiration Time Computer.
        /// \wi{16987}
        /// Timeout class shall provide the capability to compute the expiration time.
        void compute_t_exp();
    };
    /// \alg
    inline Ttime Timeout::t_to_ticks(Real time, Uint32 freq)
    {
        /// <li> Build Ttime with the ticks computed as time * freq.
        return Ttime(static_cast<int64>(time * freq));
    }

    inline Timeout::Timeout(int64 ticks) :
         t_out(ticks)
    {
        compute_t_exp();
    }
    
    inline void Timeout::set_timeout_t(int64 ticks)
    {
        t_out = Ttime(ticks);
        compute_t_exp();
    }
    /// \alg
    inline void Timeout::compute_t_exp()
    {
        /// <li> Expiration time is computed as:
        /// <li> ::t_expiration = ::t_out + Bsp::Htime::get_time.
        t_expiration = t_out + Bsp::Htime::get_time();
    }

    inline void Timeout::start()
    {
        compute_t_exp();
    }
    /// \alg
    inline bool Timeout::expired() const
    {
        /// <li> IF Bsp::Htime::get_time >= ::t_expiration.
        int64 t1 = Bsp::Htime::get_time().get_tics();
        return t1 >= t_expiration.get_tics();
    }
    /// \alg
    inline void Timeout::make_expired()
    {
        /// <li> Set ::t_expiration to 0.
        t_expiration = Ttime(static_cast<int64>(0));
    }
}
#endif
