#ifndef REF_WRAPPER_H_
#define REF_WRAPPER_H_

namespace Base
{

    /// Auxiliary class to pass references to Array constructor.
    template <typename T>
    struct Ref_wrapper
    {
        /// Reference wrapper constructor.
        /// \wi{21086}
        /// The Ref_wrapper struct shall initialize its contained reference element with the reference of the element
        /// passed on construction.
        /// \param[in] elem0 Element to take the reference.
        inline explicit Ref_wrapper(T& elem0) : elem(elem0)
        {
        }
        T& elem; ///< Stored element reference.
    };

}

#endif
