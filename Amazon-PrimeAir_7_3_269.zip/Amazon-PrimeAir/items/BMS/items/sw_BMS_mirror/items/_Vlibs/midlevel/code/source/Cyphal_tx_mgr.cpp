#include <Cyphal_tx_mgr.h>
#include <Espkt.h>

namespace Cyphal
{
    using namespace Base;

    Cyphal_tx_mgr::Cyphal_tx_mgr(Uint16 max_msgs,
                                 Uint16 max_msg_size,
                                 Memmgr::Type mtype) :
         ext_fifo(max_msg_size, mtype),
         ext_idx(0),
         ext_pl_len(0),
         tx_type(none),
         msgs(max_msgs, mtype),
         curr_tx_msg(0)
    {
    }

    Cyphal_tx_mgr::Msg* Cyphal_tx_mgr::get_free_msg()
    {
        Msg* res = 0;
        for(Uint16 i=0; (i < msgs.size()) && (res==0); i++)
        {
            if(!msgs[i].in_use)
            {
                res = &msgs[i];
            }
        }
        return res;
    }

    Cyphal_tx_mgr::Msg* Cyphal_tx_mgr::get_next_msg()
    {
        Uint8 best_prio = Ku8::maxV;
        Msg* res = 0;
        for (Uint16 i = 0; (i < msgs.size()) && (res == 0); i++)
        {
            Msg& msg = msgs[i];            
            if(msg.in_use)
            {
                CyCAN_id cy_id = msg.msg.get_id();
                if(cy_id.msg.priority < best_prio)
                {
                    res = &msg;
                    best_prio = cy_id.msg.priority;
                }
            }
        }
        return res;
    }

    bool Cyphal_tx_mgr::send(const Cyphal_msg& cy_msg)
    {
        Cyphal_tx_mgr::Msg* msg = get_free_msg();
        bool res = (msg != 0);
        if(res)
        {
            msg->in_use = true;
            msg->msg.copy(cy_msg);
            msg->is = U8istream(msg->msg.get_buffer());
        }
        return res;
    }

    bool Cyphal_tx_mgr::send(Cyphal_stg_fields fb, const Espkt& pkt)
    {
        Cyphal_tx_mgr::Msg* msg = get_free_msg();
        bool res = (msg != 0);
        if (res)
        {
            msg->in_use = true;
            CyCAN_id cy_id = { 0 };
            cy_id.msg.priority = fb.priority;
            cy_id.msg.svc_msg = fb.svc_msg;
            cy_id.msg.anon = fb.anon_resp;
            cy_id.msg.src_node = pkt.get_src_address().id;

            Full_id fid = { pkt.get_type() };
            if(cy_id.msg.svc_msg)
            {
                cy_id.svc.dst_node = pkt.get_dst_address().id;
                cy_id.svc.service = fid.id & Full_id::svc_id_mask;
            }
            else
            {
                cy_id.msg.subject = fid.id & Full_id::msg_id_mask;
            }
            msg->msg.set_id(cy_id);
            U8istream is(pkt.get_as_spkt().get_payload());
            
            {
                Cyphal_msg::Mutator m(msg->msg);            
                while(is.get_pos() < is.get_max_size())
                {
                    m.os.put_uint8(is.get_uint8());
                }
            }
        }
        return res;
    }

    bool Cyphal_tx_mgr::read(Uint8& data)
    {
        bool res = false;
        switch(tx_type)
        {
            case none:
            {
                curr_tx_msg = get_next_msg();
                if (curr_tx_msg != 0)
                {
                    data = curr_tx_msg->is.get_uint8();
                    if (Assertions::runtime(data == Cyphal_msg::start_byte)) // Check start byte
                    {
                        tx_type = internal;
                        res = true;
                    }
                }
                else
                {
                    res = ext_fifo.read(data);
                    if (res)
                    {
                        tx_type = external;
                        res = true;
                    }
                }
                break;
            }
            case internal:
            {
                res = (curr_tx_msg->is.get_pos() < curr_tx_msg->is.get_max_size());
                if(res)
                {
                    data = curr_tx_msg->is.get_uint8();
                }
                else
                {
                    res = false;
                    tx_type = none;
                    curr_tx_msg->in_use = false;
                }
                break;
            }
            case external:
            {
                res = ext_fifo.read(data);
                if(res)
                {
                    switch(ext_idx)
                    {
                        case 0:
                        {
                            ext_idx += (data == Cyphal_msg::start_byte);
                            break;
                        }
                        case Cyphal_msg::offset_len:
                        {
                            ext_pl_len = data;
                            ext_idx++;
                            break;
                        }
                        case Cyphal_msg::offset_len_h:
                        {
                            ext_pl_len = Base::Bitutils::get_u16(data, static_cast<Uint8>(ext_pl_len & Ku8::maxV));
                            ext_idx++;
                            break;
                        }
                        default:
                        {
                            ext_idx++;
                            if(ext_idx >= ext_pl_len) // Transmission ended.
                            {
                                tx_type = none;
                            }
                        }
                    }
                }
                break;
            }
        }
        return res;
    }
}
