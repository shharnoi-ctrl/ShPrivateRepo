#ifndef INCLUDE_XCFG_DES_FW_H_
#define INCLUDE_XCFG_DES_FW_H_

#include <Tundefault.h>

namespace Base
{
    template <typename XCFG, typename TUNTRAIT=Tuntraits::Desdefault<XCFG> >
    struct Xcfg_des;
}


#endif
