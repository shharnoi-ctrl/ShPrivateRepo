#ifndef ENDIANNESS_H_
#define ENDIANNESS_H_

namespace Base
{
    /// Veronte's available endiannesses
    enum Endianness
    {
        endian_little = 1,  // Low byte first,  high byte last. I.E: 0x40302010 -> [ 0x10, 0x20, 0x30, 0x40]
        endian_big    = 2   // High byte first, low byte last.  I.E: 0x40302010 -> [ 0x40, 0x30, 0x20, 0x10]
    };
}
#endif
