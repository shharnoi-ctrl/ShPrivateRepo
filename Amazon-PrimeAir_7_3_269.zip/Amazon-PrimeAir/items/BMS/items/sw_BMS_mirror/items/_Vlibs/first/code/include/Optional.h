#ifndef OPTIONAL_H_
#define OPTIONAL_H_

#include <Ttraits.h>
#include <Assertions.h>
#include <Ku16.h>

namespace Base
{

    /// The Base library shall provide a structure to encapsulate a value that may or may not be present.
    template <typename T>
    struct Optional
    {
        /// Optional Value Present or Enabled Checker.
        /// \wi{5153}
        /// Optional structure shall be able to check if the value is present or enabled.
        /// \return True if value is present or enabled, otherwise False.
        bool is_present() const;

        /// Optional Templated Value Retriever.
        /// \wi{5154}
        /// Optional structure shall be able to retrieve the optional value. 
        /// \return Value. 
        /// \pre Caller must check if it is valid with is_present method.
        T get() const;

        /// Optional Templated Value Retriever with Given Default Value.
        /// \wi{21079}
        /// Optional structure shall be able to retrieve the optional value if it is present, 
        /// otherwise retrieve the default value. 
        /// \param[in] default0 Default value.
        /// \return Value if present, else default0.
        typename JSF116_param<T>::type get(typename JSF116_param<T>::type default0) const;
        
        /// Optional Value Resetter.
        /// \wi{5155}
        /// Optional structure shall be able to set the value as not present.
        void clear();

        /// Optional Value Setter.
        /// \wi{21080}
        /// Optional structure shall be able to set the given value as the present optional value.
        /// \param[in] value0 Value to be set as the optional value.
        void set(typename JSF116_param<T>::type value0);

        /// Optional Value Object Builder.
        /// \wi{21081}
        /// Optional structure shall be able to build an optional object with given parameters.
        /// \param[in] present0 Boolean indicating value is present or enabled.
        /// \param[in] value0 Value to be set as the optional value. 
        /// \return The static Optional object.
        static Optional<T> build(const bool present0, typename JSF116_param<T>::type value0);

        bool present;   ///< Indicates if the value is present or enabled.
        T value;        ///< Value of this optional when present.
    };

    template <typename T>
    inline bool Optional<T>::is_present() const
    {
        /// \alg
        /// - Return ::present.
        return present;
    }

    template <typename T>
    inline void Optional<T>::clear()
    {
        /// \alg
        /// - Assign false to ::present. 
        present=false;
    }

    template <typename T>
    inline void Optional<T>::set(typename JSF116_param<T>::type value0)
    {
        /// \alg
        /// - Assign true to ::present. 
        /// - Assign given "value0" to ::value. 
        present = true;
        value=value0;
    }

    template <typename T>
    inline T Optional<T>::get() const
    {
        // More generalization needed in Optional class to avoid returning big data by value.
        Base::Assertions::Compile_time<sizeof(T)<=(Ku16::u4*sizeof(JSF119_word))>();
        /// \alg
        /// - Return ::value.
        return value;
    }

    template <typename T>
    inline typename JSF116_param<T>::type Optional<T>::get(typename JSF116_param<T>::type default0) const
    {
        /// \alg
        /// - If ::present True, return ::value, Else return given "default0".
        return present ? value : default0;
    }

    template <typename T>
    inline Optional<T> Optional<T>::build(const bool present0, typename JSF116_param<T>::type value0)
    {
        /// \alg
        /// - Create an constant Optional object "ret" with given "present0" and "value0".
        /// - Return "ret".
        const Optional<T> ret = {present0, value0};
        return ret;
    }

}

#endif
