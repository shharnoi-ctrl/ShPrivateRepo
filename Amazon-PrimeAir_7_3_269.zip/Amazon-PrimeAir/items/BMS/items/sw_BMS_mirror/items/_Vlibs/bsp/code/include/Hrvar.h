#ifndef HRVAR_H_
#define HRVAR_H_

#include <Mblock.h>
#include <Rvar.h>
#include <Tcopy.h>
#include <Cptraits.h>
#include <Assertions.h>

namespace Bsp
{

    /// Rvar handler
    class Hrvar
    {
    public:
        class Range
        {
        public:
            /// Constructor with Given Parameters.
            /// \wi{18181}
            /// Range class shall build itself upon construction with its memory location range.
            /// \param[in] mb           Memory block.
            /// \param[in] from         Start range.
            /// \param[in] to_inclusive End range.
            Range(Base::Mblock<const volatile Real> mb,
                  Base::Rvar from,
                  Base::Rvar to_inclusive);

            /// Data Commiter.
            /// \wi{18183}
            ///  Range class shall be able to copy the internal range data to its final memory allocation.
            void commit();

            /// Range Variable Retriever.
            /// \wi{18184}
            /// Range class shall be able to retrieve a non-commited value with given index.
            /// \param[in] idx Variable ID.
            /// \return Variable value for given index.
            Real varget(Uint16 idx) const;

        private:
            /// Define Type_cp as a typedef representing a type capable of copying data between memory blocks
            /// of constant volatile Real and volatile Real types.
            typedef Base::Tcopy<Base::Cptraits::Array_memcpy32<
                Base::Mblock<const volatile Real>,
                Base::Mblock<volatile Real> > > Type_cp;
            /// Instantiate a Copy trait object which able to write a memory block from a source to a destination.    
            Type_cp cp;

            Range();                                ///< = delete
            Range& operator=(const Range& orig);    ///< = delete
        };

        /// Hrvar Constructor.
        /// \wi{18185}
        /// Hrvar class shall build itself upon construction with given variable ID.
        /// \param[in] id0 Variable Index to be accessed (Base::Rvar).
        explicit Hrvar(Base::Rvar id0);

        /// Hrvar Variable Updater.
        /// \wi{7972}
        /// Hrvar class shall provide a method to set the value for a variable ID.
        /// \param[in] v0 Variable value to be set.
        void set(Real v0);

        /// Hrvar Variable Retriever.
        /// \wi{7968}
        /// Hrvar class shall provide a method to get the value for a variable ID.
        /// \return Variable value.
        Real get() const;

        /// Constant Volatile Reference Retriever.
        /// \wi{7965}
        /// Hrvar class shall be able to retrieve a constant and volatile reference to a given Real variable ID value.
        /// \return Variable value reference.
        /// \pre This function will be implemented in all cores with read access to given memory block.
        const volatile Real& get_kref() const;

        /// Volatile Reference Retriever.
        /// \wi{18195}
        /// Hrvar class shall be able to retrieve a volatile reference to a given Real variable ID value.
        /// \return Variable reference from shared memory.
        /// \pre This function will be implemented in all cores with write access to given memory block.
        volatile Real& get_ref() const;

        /// Constant Volatile Real Memory Block Retriever.
        /// \wi{18358} 
        /// Hrvar class shall be able to retrieve a constant and volatile memory block 
        /// from a given range of Real variable ID.
        /// \param[in] from Starting Real variable ID of the memory block.
        /// \param[in] to_inclusive Ending Real variable ID of the memory block.
        /// \return Variable value references to the specified range.
        /// \pre This function will be implemented in all cores with read access to the given memory block.
        static Base::Mblock<const volatile Real> get_kblock(Base::Rvar from, Base::Rvar to_inclusive);

        /// Volatile Real Memory Block Retriever.
        /// \wi{18359} 
        /// Hrvar class shall be able to retrieve a volatile memory block 
        /// from a given range of Real variable ID.
        /// \param[in] from Starting Real variable ID of the memory block.
        /// \param[in] to_inclusive Ending Real variable ID of the memory block.
        /// \return Variable value references to the specified range.
        /// \pre This function will be implemented in all cores with write access to the given memory block.
        static Base::Mblock<volatile Real> get_block(Base::Rvar from, Base::Rvar to_inclusive);

    private:
        const Base::Rvar id;

        // disabled
        Hrvar();                                ///< = delete
        Hrvar(const Hrvar& orig);               ///< = delete
        Hrvar& operator=(const Hrvar& orig);    ///< = delete
    };

    inline void Hrvar::Range::commit()
    {
        /// \alg
        ///  - Call to Tcopy::copy for ::cp, which bulks data from source memory block to destination memory block.
        cp.copy();
    }

    inline Real Hrvar::Range::varget(Uint16 idx) const
    {
        /// \alg
        ///  - Read given index from source memory block (non-commited).
        return cp.get_to()[idx];
    }

}
#endif
