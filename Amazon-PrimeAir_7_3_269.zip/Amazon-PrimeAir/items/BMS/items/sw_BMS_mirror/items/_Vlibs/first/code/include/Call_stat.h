#ifndef CALL_STAT_H__
#define CALL_STAT_H__

#include <Chrono.h>
#include <Const.h>

namespace Base
{
    /// Call Statistics class to compute working frequencies.
    class Call_stat
    {
    public:
        /// Call_stat Constructor.
        /// \wi{5803}
        /// Call_stat class shall build itself upon construction and initialize it's internal members.
        /// \param[in] t_check Period to sample.
        explicit Call_stat(Real t_check);

        /// Call_stat Reset.
        /// \wi{5727}
        /// Call_stat class shall provide the capability to reset its state to start measuring again.
        /// \param[in] margin Margin indicates number of seconds to retard to the chrono tic.
        void reset(Real margin = Const::ZERO);

        /// Call_stat Call.
        /// \wi{4913}
        /// Call_stat class shall provide the capability to increase the number of callings since last sample.
        void call();

        /// Call_stat Statistics Getter.
        /// \wi{4914}
        /// Call_stat class shall provide the capability to return calling statistics per second.
        /// \return The calling statistics.
        Real get_calls_sec() const;

        /// Call_stat Stepper.
        /// \wi{5804}
        /// Call_stat class shall provide the capability to update the calling statistics.
        /// \return True if t_check seconds are reached, else return false.
        bool step();

    private:
        Call_stat(const Call_stat& src);    ///< = delete
        Call_stat& operator=(const Call_stat& src); ///< = delete
        
        Chrono chr;         ///< Chrono
        int16  ncalls;      ///< Number of callings since last t_check period
        Real   t_check;     ///< Period to sample
        Real   calls_sec;   ///< Callings per second statistic. Updated in step()
    };

    inline void Call_stat::reset(Real margin)
    {
        chr.tic(margin);
        ncalls = 0;
    }

    inline void Call_stat::call()
    {
        __inc(&ncalls);
    }

    inline Real Call_stat::get_calls_sec() const
    {
        return calls_sec;
    }
}
#endif
