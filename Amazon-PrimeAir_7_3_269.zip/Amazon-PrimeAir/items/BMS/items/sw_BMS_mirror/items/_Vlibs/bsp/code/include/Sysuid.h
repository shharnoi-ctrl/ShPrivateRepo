#ifndef SYSUID_H_
#define SYSUID_H_

#include <Address.h>
#include <Uid64.h>

namespace Bsp
{
    /// System unique identifier constant reference.
    /// \wi{13641}
    /// System shall provide the capability to retrieve its unique identifier location.
    /// \rationale On multi-core platforms, shall only be implemented on the core that have read-only access.
    /// \return Constant reference to Unique system identifier
    extern volatile const Uid64& get_uid_location();

    /// System unique identifier.
    /// \wi{13640}
    /// System shall provide the capability to retrieve its internal unique identifier as UID64 (defined onto \wi{13623}).
    /// \rationale System unique identifier shall be stored at internal on-chip OTP memory on TMS320F2837x and TMS32F28335 platforms.
    /// \return Copied value from internal unique system identifier.
    extern Uid64 get_uid();
}

#endif
