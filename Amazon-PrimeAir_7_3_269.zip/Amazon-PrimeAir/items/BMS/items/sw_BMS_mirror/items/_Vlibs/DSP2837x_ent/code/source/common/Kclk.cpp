#include <Kclk.h>

namespace Bsp
{
    namespace
    {
        static const Uint32 sys_freq    = 200000000UL;  // System clock frequency: 200Mhz
        static const Uint32 ls_sys_freq =  50000000UL;  // System low speed clock frequency: 50Mhz
    }

    Uint32 Kclk::sysclkfreq_u32   = sys_freq;
    Real64 Kclk::sysclkfreq_r64   = static_cast<Real64>(sys_freq);
    Real   Kclk::sysclkfreq_r32   = static_cast<Real>(sys_freq);
    Real64 Kclk::sysclkperiod_r64 = 1.0L / static_cast<Real64>(sys_freq);
    Real   Kclk::sysclkperiod_r32 = 1.0F / static_cast<Real>(sys_freq);

    Uint32 Kclk::lspclkfreq32     = ls_sys_freq;
}
