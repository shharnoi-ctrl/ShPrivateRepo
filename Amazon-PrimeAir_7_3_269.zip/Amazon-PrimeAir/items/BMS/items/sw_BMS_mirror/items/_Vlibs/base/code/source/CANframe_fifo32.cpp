#include <CANframe_fifo32.h>

namespace Base
{
    bool CANframe_fifo32::write(const CANframe& frame)
    {
        const Mblock<const Uint32> mb = frame.data.to_mblock32();
        bool res = wr_available(mb.sz);
        /// \alg If there is room to write the data. <ul>
        if(res)
        {
            /// <li> Write the ID
            res = fifo.write(frame.id.get_packed_id());
            /// <li> Write the size in bytes.
            res = fifo.write(frame.data.data.size());
            /// <li> Write the payload as Uint32 blocks.
            for(Uint8 i=0; i < mb.sz; ++i)
            {
                res &= fifo.write(mb[i]);
            }
            /// <li> Update write pointer if all read have been successful.
            if(res)
            {
                fifo.commit();
            }
        } /// </ul>
        /// \post If on any write failed, it will return False.
        return res;
    }

    bool CANframe_fifo32::read(CANframe& frame)
    {
        bool res = fifo.rd_available_count() >= hdr_data_sz_w32;
        /// \alg <li>If there is data in the fifo.<ul>
        if(res)
        {
            Uint32 id = 0;
            /// <li> Read the ID
            res = fifo.read(id);
            frame.id.set_packed_id(id);

            /// <li> Read the size in bytes.
            Uint32 sz = 0;
            res &= fifo.read(sz);
            /// <li> If the size is less of equal than the maximum allowed (64 bytes).
            ///   - Read the payload as Uint32 blocks.
            if(res && Assertions::runtime(sz <= frame.data.length_max_fd))
            {
                frame.data.data.resize(sz);
                Mblock<Uint32> mb = frame.data.to_mblock32();
                const Uint32 sz32 = Bitutils::bytes_to_words32(sz);
                for(Uint8 i=0; i < sz32; ++i)
                {
                    res &= fifo.read(mb[i]);
                }
                Assertions::runtime(res); // Should always read all 32bit words specified by sz32.
            }
        }/// </ul>
        /// \post If on any read, there was no data, or the size was greater than allowed, it will return False.
        return res;
    }
}
