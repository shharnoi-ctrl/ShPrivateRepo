#ifndef I2C_DEVICE_H_
#define I2C_DEVICE_H_

#include <Entypes.h>
#include <Hbvar.h>
#include <Call_statchk.h>
#include <I2Cif.h>
#include <Vector_u8.h>

namespace Dsp28335_ent
{
    using namespace Ku16;

    //PRQA S 1760 EOF
    /// I2Cdevice common driver and specific interface.
    class I2Cdevice
    {
    public:
        /// I2C device constructor.
        /// \wi{7546}
        /// I2Cdevice class shall initialize itself upon construction with provided parameters.
        /// \param[in,out] i2c          Reference to I2C module peripheral driver.
        /// \param[in] address0         Slave address.
        /// \param[in] buffer_sz        Total size of the memory block for this device (in bytes).
        /// \param[in, out] bit         Reference to the status bit for this device.
        I2Cdevice(Dsp28335_ent::I2Cif& i2c, Uint8 address0, Uint8 buffer_sz, volatile bool& bit);

        /// I2C device destructor.
        /// I2Cdevice class shall provide the capability to delete itself.
        virtual ~I2Cdevice();

        /// I2C device step.
        /// \wi{7547}
        /// I2Cdevice class shall be able to attempt communicate with the I2C device through its application driver,
        /// and to compute communication statistics as well as reporting status/integrity of this device.
        /// \return ::is_busy as described at \wi{16782}.
        bool step();

        /// I2C device is enable.
        /// \wi{7548}
        /// I2Cdevice class shall provide the capability to return its enabled flag.
        /// \return True if device is enabled, else return False.
        bool is_enabled() const;

        /// I2C device enable/disable.
        /// \wi{7552}
        /// I2Cdevice class shall provide the capability to enable or disable a device.
        /// \param[in] en   At true to enable, at false to disable.
        void set_enabled(bool en);

        /// Set I2C device address.
        /// \wi{7549}
        /// I2Cdevice class shall provide the capability to set its I2C address.
        /// \param[in] address0     Slave address.
        void set_address(Uint8 address0);

        /// Get I2C device status flag.
        /// \wi{7550}
        /// I2Cdevice class shall provide the capability to retrieve its status flag.
        /// \return Status flag.
        bool get_bit() const;

        /// Specific I2C device calling period.
        /// \wi{7553}
        /// I2Cdevice class shall declare a method for specific implementation to return its current expected amount
        /// of time between two calls.
        /// \return Current calling period.
        /// \rat To be implemented by inherited classes.
        virtual Real get_period() const = 0;

        /// Specific I2C device period.
        /// \wi{7556}
        /// I2Cdevice class shall declare a method for specific implementation to set new calling period based on
        /// provided one.
        /// \param[in] period0      Desired calling period.
        /// \rat To be implemented by inherited classes.
        virtual void set_period(const Real& period0) = 0;

        /// Specific I2C device default period.
        /// \wi{7555}
        /// I2Cdevice class shall declare a method for specific implementation to return its default amount of time
        /// between two calls.
        /// \return Default calling period.
        /// \rat To be implemented by inherited classes.
        virtual Real get_default_period() const = 0;

        /// Get I2C device bus identifier.
        /// \wi{16779}
        /// I2Cdevice class shall be able to retrieve its underlying I2C module identifier.
        /// \return I2C identifier.
        Dsp28335_ent::I2Cif::Id get_i2c_id() const;

    protected:
        Base::Call_statchk callst;         ///< Call statistics. Used for BIT/status flag.

        /// Specific I2C device step.
        /// I2Cdevice class shall declare a method for specific implementation to iterate over its device FSM.
        /// \rat To be implemented by inherited classes.
        virtual void do_step() = 0;

        /// Specific I2C device set OK.
        /// I2Cdevice calss shall declare a method for specific implementation to force its state.
        /// \param[in] ok   State to force (at true is OK, at false is not).
        virtual void set_ok(bool ok) = 0;

        /// I2C device desired rate.
        /// I2Cdevice class shall declare a method to return its desired measurement rate.
        /// \return Desired calling rate.
        /// \rat To be implemented by inherited classes.
        virtual Real get_desired_rate() const = 0;

        /// I2C device call.
        /// \wi{7008}
        /// I2Cdevice class shall provide the capability to report a call to communication statistics.
        void add_call();

        /// I2C device send one byte.
        /// \wi{7561}
        /// I2Cdevice class shall provide the capability to send an unique byte to I2C device.
        /// \param[in] d0   Byte to send.
        /// \return True if operation started, else return false.
        bool send(Uint8 d0);

        /// I2C device send two bytes.
        /// \wi{16777}
        /// I2Cdevice class shall provide the capability to send two bytes to I2C device.
        /// \param[in] d0   First byte to be byte to send.
        /// \param[in] d1   Second byte to send.
        /// \return True if operation started, else return false.
        bool send(Uint8 d0, Uint8 d1);

        /// I2C device send bytes memory block.
        /// \wi{16778}
        /// I2Cdevice class shall provide the capability to send content from provided bytes memory block.
        /// \param[in] d    Constant bytes memory block to send.
        /// \return True if operation started, else return false.
        bool send(const Base::U8pkmblock_k& d);

        /// I2C device send one byte no stop.
        /// \wi{7579}
        /// I2Cdevice class shall provide the capability to write an unique byte to I2C device without asserting
        /// a stop condition when finished.
        /// \param[in] d0   First byte to send.
        /// \return True if operation started, else return false.
        /// \rat Shall be called to initiate a repeated-start sequence.
        bool send_no_stop(Uint8 d0);

        /// I2C device read.
        /// \wi{7560}
        /// I2Cdevice class shall provide the capability to read a fixed number of bytes from I2C device.
        /// \param[in] size     Expected number of bytes to be read from I2C device.
        /// \return True if operation started, else return false.
        bool read(Uint8 size);

        /// Retrieve I2C device buffer.
        /// \wi{16780}
        /// I2Cdevice class shall be able to retrieve its working buffer.
        /// \return Constant memory block working buffer.
        Base::U8pkmblock_k get_buffer() const;

        /// Compute I2C device default period.
        /// \wi{7557}
        /// I2Cdevice class shall provide the capability to compute the default period
        /// with provided number of required steps.
        /// \param[in] req_steps    Required number of steps to collect one sample.
        /// \param[in] up_perc      Percentage to upper estimate number of steps.
        /// \return Default period.
        Real get_default_period0(Uint16 req_steps, Real up_perc = 1.0F) const;
    private:
        Dsp28335_ent::I2Cif& i2c;      ///< I2C bus device.
        bool enabled;                   ///< Enabled flag.
        bool busy;                      ///< Busy flag.
        Uint8 address;                  ///< I2C address if this device.
        Base::U8pkmblock buffer;        ///< Write/Read memory block to work with.

        /// I2C device start write.
        /// \wi{16781}
        /// I2Cdevice class shall provide the capability to perform a write start request through I2C peripheral.
        /// \param tx_sz[in]    Number of bytes to send.
        /// \param stop0[in]    At true when a stop condition shall be asserted by peripheral at finished operation.
        /// \return True if the operation succeed, else return false.
        bool send_priv(Uint32 tx_sz, bool stop0 = true);

        /// I2C device is busy.
        /// \wi{16782}
        /// I2Cdevice class shall be able to determine if it is currently communicating with the device or not.
        /// \return True if pending operation, else return false.
        bool is_busy() const;

        I2Cdevice(); ///< = delete
        I2Cdevice(const I2Cdevice& orig); ///< = delete
        I2Cdevice& operator=(const I2Cdevice& orig); ///< = delete
    };


    inline bool I2Cdevice::is_enabled() const
    {
        return enabled;
    }

    inline bool I2Cdevice::is_busy() const
    {
        return busy;
    }

    inline void I2Cdevice::set_address(Uint8 address0)
    {
        address = address0;
    }

    inline bool I2Cdevice::get_bit() const
    {
        return callst.get_bit();
    }

    inline void I2Cdevice::add_call()
    {
        callst.call();
    }

    inline Base::U8pkmblock_k I2Cdevice::get_buffer() const
    {
        return buffer;
    }

    inline Dsp28335_ent::I2Cif::Id I2Cdevice::get_i2c_id() const
    {
        return i2c.get_id();
    }
}
#endif
