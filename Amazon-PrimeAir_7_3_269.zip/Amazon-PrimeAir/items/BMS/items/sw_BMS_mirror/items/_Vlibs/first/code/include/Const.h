#ifndef CONST_H__
#define CONST_H__

#include <Entypes.h>
#include <Kr64.h>

namespace Const
{
    const Real ZERO=          static_cast<Real>(0.0);
    const Real ONE=           static_cast<Real>(1.0);
    const Real TWO=           static_cast<Real>(2.0);
    const Real THREE=         static_cast<Real>(3.0);
    const Real FOUR=          static_cast<Real>(4.0);
    const Real FIVE=          static_cast<Real>(5.0);
    const Real SIX=           static_cast<Real>(6.0);
    const Real SEVEN=         static_cast<Real>(7.0);
    const Real EIGHT=         static_cast<Real>(8.0);
    const Real NINE=          static_cast<Real>(9.0);
    const Real TEN=           static_cast<Real>(10.0);
    const Real ELEVEN=        static_cast<Real>(11.0);
    const Real TWELVE=        static_cast<Real>(12.0);
    const Real FIFTEEN=       static_cast<Real>(15.0);
    const Real SIXTEEN=       static_cast<Real>(16.0);
    const Real EIGHTEEN=      static_cast<Real>(18.0);
    const Real TWENTY=        static_cast<Real>(20.0);
    const Real TWENTYFIVE=    static_cast<Real>(25.0);
    const Real THIRTY=        static_cast<Real>(30.0);
    const Real FOURTY=        static_cast<Real>(40.0);
    const Real FIFTY=         static_cast<Real>(50.0);
    const Real SIXTY=         static_cast<Real>(60.0);
    const Real NINETY=        static_cast<Real>(90.0);
    const Real ISIXTY=        static_cast<Real>(0.016666666666666666666666666666667);
    const Real SQRT3=         static_cast<Real>(1.7320508075688772935274463415059);
    const Real ISQRT3=        static_cast<Real>(0.57735026918962576450914878050196);
    const Real SQRT2=         static_cast<Real>(1.4142135623730950488016887242097);
    const Real ISQRT2=        static_cast<Real>(0.70710678118654752440084436210485);
    const Real SQRT5=         static_cast<Real>(2.2360679774997896964091736687313);
    const Real PI=            static_cast<Real>(Kr64::PI);
    const Real PI2=           static_cast<Real>(Kr64::PI2);
    const Real PI05=          static_cast<Real>(Kr64::PI05);
    const Real PI025=         static_cast<Real>(0.78539816339744830961566084581988);
    const Real PI033=         static_cast<Real>(1.0471975511965977461542144610932);
    const Real PI0166=        static_cast<Real>(0.52359877559829887307710723054658);
    const Real PI0833=        static_cast<Real>(2.6179938779914943653855361527329);
    const Real TPI033_1=      static_cast<Real>(0.57735026918962576450915017676536);
    const Real ISQRTPI2=      static_cast<Real>(0.39894228040143267793994605993438);
    const Real INV2PI=        static_cast<Real>(0.15915494309189533576888376337251);
    const Real one_degree =   static_cast<Real>(0.01745329251994329576923690768489);
    const Real half_degree =  static_cast<Real>(0.00872664625997164788461845384244);
    const Real ONEHALF=       static_cast<Real>(0.5);
    const Real THREEHALVES=   static_cast<Real>(1.5);
    const Real FIVEHALVES=    static_cast<Real>(2.5);
    const Real ONETHIRD=      static_cast<Real>(0.33333333333333333333333333333333);
    const Real TWOTHIRDS=     static_cast<Real>(0.66666666666666666666666666666667);
    const Real ONEFOURTH=     static_cast<Real>(0.25);
    const Real ONEFIFTH=      static_cast<Real>(0.2);
    const Real ONESIXTH=      static_cast<Real>(0.16666666666666666666666666666667);
    const Real ONEEIGHTH=     static_cast<Real>(0.125);
    const Real FIVETHIRDS=    static_cast<Real>(1.6666666666666666666666666666667);
    const Real TENTHIRDS=     static_cast<Real>(3.3333333333333333333333333333333);
    const Real SQRT075=       static_cast<Real>(0.86602540378443864676372317075294);
    const Real E15=           static_cast<Real>(0.066666666666666666666666666666667);
    const Real E10=           static_cast<Real>(0.1);
    const Real E100=          static_cast<Real>(0.01);
    const Real E1000=         static_cast<Real>(0.001);
    const Real E10000=        static_cast<Real>(0.0001);
    const Real E1000000=      static_cast<Real>(1E-6);
    const Real E1000000000=   static_cast<Real>(1E-9);
    const Real POINT4=        static_cast<Real>(0.4);
    const Real POINT6=        static_cast<Real>(0.6);
    const Real POINT8=        static_cast<Real>(0.8);
    const Real ONE_HUNDRED=   static_cast<Real>(100.0);
    const Real TWO_HUNDRED=   static_cast<Real>(200.0);
    const Real ONE_HUNDRED_TWENTY = static_cast<Real>(120.0);
    const Real ONE_HUNDRED_FIFTY = static_cast<Real>(150.0);
    const Real ONE_THOUSAND=  static_cast<Real>(1000.0);
    const Real TWO_THOUSAND = static_cast<Real>(2000.0);
    const Real THREE_THOUSAND_SIX_HUNDRED = static_cast<Real>(3600.0);
    const Real TEN_THOUSAND=  static_cast<Real>(10000.0);
    const Real THIRTY_THOUSAND=  static_cast<Real>(30000.0);
    const Real ONE_HUNDRED_THOUSAND=  static_cast<Real>(100000.0);
    const Real ONE_MILLION=  static_cast<Real>(1000000.0);

    const Real FROM_MICRO=    static_cast<Real>(1E6);
    const Real FROM_NANO=     static_cast<Real>(1E9);
    const Real FROM_PICO=     static_cast<Real>(1E12);
    const Real TO_MICRO=      static_cast<Real>(1.0F/FROM_MICRO);
    const Real TO_NANO=       static_cast<Real>(1.0F/FROM_NANO);
    const Real TO_PICO=       static_cast<Real>(1.0F/FROM_PICO);

    const Real DEG2RAD=       static_cast<Real>(0.017453292519943295769236907684886);
    const Real DEG2RAD2=      static_cast<Real>(3.0461741978670859934674354937889E-4);
    const Real RAD2DEG=       static_cast<Real>(Kr64::RAD2DEG);
    const Real RAD2SEC=       static_cast<Real>(206264.80624709635515647335733078);    // RAD2DEG*DEG2SEC, 57.29*3600
    const Real RPM2RADS=      static_cast<Real>(PI2/SIXTY);
    const Real RADS2RPM=      static_cast<Real>(1/RPM2RADS);

    const Real TESLA2GAUSS=   static_cast<Real>(1E4);
    const Real GAUSS2TESLA=   static_cast<Real>(1E-4);
    const Real M2CM=          static_cast<Real>(1E2);                                  ///< Meters to centimeters
    const Real CM2M=          static_cast<Real>(1E-2);                                 ///< Centimeters to meters
    const Real M2KM=          static_cast<Real>(1E-3);                                 ///< Meters to kilometers
    const Real MM2M=          static_cast<Real>(1E-3);                                 ///< Millimeters to meters
    const Real KM2M=          static_cast<Real>(1E3);                                  ///< Kilometers to meters
    const Real FT2M=          static_cast<Real>(0.3048);                               ///< Feets to meters factor.

    ///< Knots to meters per second factor.
    const Real kn2ms=         static_cast<Real>(0.51444444444444444444444444444444);
    const Real g2ms2=         static_cast<Real>(9.80665);                              ///< g to m/s^2 factor.
    const Real g0_1=         static_cast<Real>(0.10197162129779282425700927431896);    ///< 1/g s^2/m
    ///< Astronomical Unit in kilometers
    const Real UA2KM=         static_cast<Real>(1.4959787E+008);
    ///< Kilometers per hour to meters per second.
    const Real kmh2ms=        static_cast<Real>(0.27777777777777777777777777777778);
    const Real PSI2PASCAL=    static_cast<Real>(6894.75729);                           ///< PSI to Pascal
    const Real MBAR2PASCAL=   static_cast<Real>(100);                                  ///< Milibar to Pascal

    const Real C2KELVIN=      273.15F;                                                 ///< Celsius to Kelvin offset.


    // 2.2204460492503131e-16 (double)
    const Real EPS=           static_cast<Real>(1.1920928955078125e-07);
    const Real MIN=           static_cast<Real>(1.1754943508222875e-38);              // 2.2250738585072014e-308
    const Real MAX=           static_cast<Real>(3.4028234663852886e+38);              // 1.7976931348623157e+308
    // 1.490116119384766e-008   // sqrt(EPS) // smallest such that 1.0+EPS != 1.0
    const Real SQRTEPS=       static_cast<Real>(3.452669830725203e-04);
    const Real SQRTMIN=       static_cast<Real>(1.0842021724855044e-19);                 // 1.4916681462400413e-154
    const Real SQRTMAX=       static_cast<Real>(1.8446743523953730e+19);                 // 1.3407807929942596e+154

    const Real i86400=        static_cast<Real>(1.1574074074074074074074074074074E-5);   ///< inverse of 86400.0

    const Real POW2M31=      static_cast<Real>(4.656612873077393E-10);
    const Real POW2M43=      static_cast<Real>(1.136868377216160E-13);
    const Real POW2M55=      static_cast<Real>(2.775557561562891E-17);
    const Real POW2M5=       static_cast<Real>(0.03125);
    const Real POW2M29=      static_cast<Real>(1.862645149230957E-09);
    const Real POW2M33=      static_cast<Real>(1.164153218269348E-10);
    const Real POW2M19=      static_cast<Real>(1.907348632812500E-06);

    const Real NE_WGS84=     static_cast<Real>(1.08262982131E-3);                       //Normal ellipsoids of WGS84

    // 16-bit BAM to radians scaler. Note that this scaler works for both signed and unsigned 16-bit BAM numbers.
    const Real BAM16_to_rad= static_cast<Real>(Kr64::PI2 / static_cast<Real64>(65536.0));

    // Radians to 16-bit BAM. Note that this scaler works for both signed and unsigned 16-bit BAM numbers.
    const Real rad_to_BAM16= static_cast<Real>(static_cast<Real64>(65536.0) / Kr64::PI2);

    // 32-bit BAM to radians scaler. Note that this scaler works for both signed and unsigned 32-bit BAM numbers.
    const Real BAM32_to_rad= static_cast<Real>(Kr64::PI2 / static_cast<Real64>(4294967296.0));

    // Radians to 32-bit BAM scaler. Note that this scaler works for both signed and unsigned 32-bit BAM numbers.
    const Real rad_to_BAM32= static_cast<Real>(static_cast<Real64>(4294967296.0) / Kr64::PI2);
}
#endif
