#ifndef ITPRODUCER_H_
#define ITPRODUCER_H_

#include <Itproducer_fw.h>
#include <Ttraits.h>

namespace Base
{
    template <typename T>
    class Itproducer
    {
    public:
        typedef T type_prod;

        /// Read data produced.
        /// \return True if there was data to be read.
        virtual bool read(T& data) = 0;
    };
}
#endif

