#ifndef DBGIER_IMPL_H_
#define DBGIER_IMPL_H_

#include <Entypes.h>

namespace Dsp28335_ent
{
    /// Debug Interrupt Enable Register function
    void set_dbgier(unsigned char num);
}

#endif
