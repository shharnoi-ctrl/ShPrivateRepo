#ifndef TIIW_FW_H_
#define TIIW_FW_H_

namespace Tiiw
{
    /// Remove this file when tiiw becomes removed
    class Tiiw_t;
}

#endif
