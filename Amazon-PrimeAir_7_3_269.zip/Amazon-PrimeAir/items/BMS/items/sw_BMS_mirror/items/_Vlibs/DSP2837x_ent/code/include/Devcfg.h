#ifndef DEVCFG_H_
#define DEVCFG_H_

#include <Entypes.h>

namespace Dsp28335_ent
{
    /// Devcfg registers handler.
    class Devcfg
    {
    public:
        struct Registers;
        
        /// Software peripheral reset identifier.
        /// Enum values addresses register relates to that peripheral in
        /// Softpres registers, with the following format: 0xRRMMMM where:
        /// - RR is register offset with respect SOFTPRES0 in words of 16 bits.
        /// - MMMM is mask for bits in that 16 bit word.
        enum Sprid
        {
            spr_emif1   = 0x020001,
            spr_emif2   = 0x020002,
            spr_usba    = 0x160008
        };

        /// CPU select peripheral identifier.
        enum Cpusel_dev
        {
            cs_dev_pwm =  0x00,
            cs_dev_ecap = 0x01,
            cs_dev_eqep = 0x02,
            cs_dev_sci  = 0x05,
            cs_dev_spi  = 0x06,
            cs_dev_i2c  = 0x07,
            cs_dev_can  = 0x08,
            cs_dev_mcbsp= 0x09,
            cs_dev_adc  = 0x0B
            // The rest aret not used
        };

        /// Default constructor
        Devcfg();
        /// Enter CPU2 to reset state (only defined for CPU1).
        static void cpu2_hold_reset();
        /// Makes CPU2 exit from reset state (only defined for CPU1).
        static void cpu2_reset_deactivate();

        /// Perform a Module soft reset on a peripheral
        void soft_reset(Sprid spr);

        /// Sets ownership of PWM registers to CPU1
        void set_cpu1_ownership(Cpusel_dev c_dev, Uint16 dev_bits);
        /// Sets ownership of PWM registers to CPU2
        void set_cpu2_ownership(Cpusel_dev c_dev, Uint16 dev_bits);

        /// Sets SYSDBGCTL.bit.BIT_0. This bit is reset only by power-on-reset (POR)
        /// and will not be cleared by a WD reset.
        void set_sysdbgctl(bool value);

        /// \return DSC high 32 bits of part ID.
        Uint32 get_partid_h() const;
        /// \return DSC low 32 bits of part ID.
        Uint32 get_partid_l() const;
        /// \return DSC revision ID.
        Uint32 get_revid() const;

        inline volatile Registers& get_regs()
        {
            return regs;
        }
    private:
        static const Uint32 devcfg_regs_addr = 0x05D000UL;        
        volatile Registers& regs;

        Devcfg(const Devcfg& orig); ///< = delete
        Devcfg& operator=(const Devcfg& orig); ///< = delete
    };
}
#endif
