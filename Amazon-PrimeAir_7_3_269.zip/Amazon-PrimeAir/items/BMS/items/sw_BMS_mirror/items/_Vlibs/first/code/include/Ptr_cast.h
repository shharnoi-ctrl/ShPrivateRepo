#ifndef PTR_CAST_H_
#define PTR_CAST_H_

#include <stddef.h>

namespace Base
{
    /// Convert a pointer to itself
    template <typename T>
    inline T* ptr_cast(T* t)
    {
        return t;
    }

    /// Convert a reference to a pointer
    template <typename T>
    inline T* ptr_cast(T& t)
    {
        return &t;
    }

    /// Convert a base address plus an offset to a referenced object
    template<typename T>
    inline volatile T& get_mem(size_t addr)
    {
        return (*reinterpret_cast<volatile T*>(addr));
    }

    /// Convert a pointer to an address
    inline size_t pt2addr(void* pt)
    {
        return reinterpret_cast<size_t>(pt);
    }
}
#endif
