#ifndef CAN_FD_IOCTL_FW_H_
#define CAN_FD_IOCTL_FW_H_

namespace Dsp28335_ent
{
    class CAN_FD_ioctl;
}
#endif
