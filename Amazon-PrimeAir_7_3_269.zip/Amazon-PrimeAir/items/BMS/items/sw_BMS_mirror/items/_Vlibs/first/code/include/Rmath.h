#ifndef RMATH_H_
#define RMATH_H_

#ifdef __TMS320C2000__
#include <Rmath_c2000.h>
#else
#include <Rmath_arm.h>
#endif

#endif
