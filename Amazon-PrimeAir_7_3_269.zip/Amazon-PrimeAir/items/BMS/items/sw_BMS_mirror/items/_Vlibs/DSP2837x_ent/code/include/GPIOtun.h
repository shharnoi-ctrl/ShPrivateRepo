#ifndef GPIOTUN_H_
#define GPIOTUN_H_

#include <GPIOmux16.h>
#include <TGPIOtun.h>

namespace Dsp28335_ent
{
    typedef TGPIOtun<GPIOmux16> GPIOtun;    ///< GPIO Tunable Type.
}
#endif
