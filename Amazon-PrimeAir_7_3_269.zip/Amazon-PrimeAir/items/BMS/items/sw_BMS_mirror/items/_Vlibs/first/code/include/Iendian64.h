#ifndef IENDIAN64_H__
#define IENDIAN64_H__

#include <Entypes.h>

namespace Base
{
    class Iendian64
    {
    public:
        virtual void put_uint64(const Uint64& p,
                                NWord* v,
                                Uint32& x,
                                int16 nbits) const = 0;
        virtual void get_uint64(Uint64& p,
                                const NWord* v,
                                Uint32& x,
                                int16 nbits) const = 0;

    protected:
        Iendian64();
        ~Iendian64();

    private:
        Iendian64(const Iendian64& orig); ///< = delete
        Iendian64& operator=(const Iendian64& orig); ///< = delete
    };

    inline Iendian64::Iendian64()
    {
    }

    inline Iendian64::~Iendian64() //PRQA S 2635 #destructor replaced with default
    {
    }

}

#endif

