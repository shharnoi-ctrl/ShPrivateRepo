#ifndef UID64_H_
#define UID64_H_

#include <Entypes.h>

namespace Bsp
{
    /// Union to handle both 64-bit word and unique identifier data structure.
    /// WARNING: This description shall rely User_otp one.
    union Uid64
    {
        Uint64 all;          ///< Unique identifier (64-bit word)
        struct
        {
            Uint64 app : 8;     ///< [0] Application identifier
            Uint64 hwv : 8;     ///< [1] Hardware version
            Uint64 var : 8;     ///< [2] Product variant
            Uint64 res : 8;     ///< [3] Reserved
            Uint64 phy : 32;    ///< [4:7] Physical address
        };

        /// Build an Uid64 will all zeros.
        inline static Uid64 build_zero()
        {
            const Uid64 v = { 0ULL };
            return v;
        }
    };
}

#endif
