#include <I2Carbiter.h>


namespace Dsp28335_ent
{
    I2Carbiter::I2Carbiter(Dsp28335_ent::I2Cif& i2cif0) :
        i2cif(i2cif0),
        devices(max_devices, Base::Memmgr::external),
        current(0)
    {
        /// \alg
        /// <li> First, initialize attributes from this class as: <ul>
        /// Type                    | Name          | Value
        /// ----------------------- | ------------- | ---------------
        /// I2Cif                   | ::i2cif       | ::i2cif0
        /// Array<Handler_info, 12> | ::devices     | (12, external)
        /// Handler_info*           | ::current     | 0 </ul>
        /// Where Handler_info defined as: <ul>
        /// Type        | Name  | Description
        /// ----------- | ----- | ----------------------------------------
        /// I2Cdevice*  | dev   | Pointer to I2C device to operating with.
        /// Chrono      | chr   | Time since last operation. </ul>
        /// <li> Then resize ::devices to zero.
        /// <li> Finally initialize I2C peripheral driver as described at \wi{7563}.
        devices.resize(0);
        init();
    }

    bool I2Carbiter::reg(I2Cdevice&  dev)
    {
        /// \alg
        /// <li> If ::devices size is already maximum value (as described at \wi{7562}), return false.
        /// <li> Else, append provided I2Cdevice to ::devices an start its chrono, then return true.
        bool ret = true;
        Uint32 sz = devices.size();
        if(sz==devices.size_max())
        {
            ret = false;
        }
        else
        {
            devices.resize(sz+1);
            devices[sz].dev = &dev;
            devices[sz].chr.tic();
        }
        return ret;
    }

    void I2Carbiter::step()
    {
        /// \alg
        /// <li> First, perform I2C driver polling (::step on ::i2cif as described at \wi{7569}).
        /// <li> If ::current handle an I2C device, step on it through ::step_dev (as described at \wi{7566}).
        /// <li> If ::current is free, it means that arbiter closes the communication with previously operating device,
        /// then: <ul>
        /// <li> For each device of ::devices, and until ::current is free: <ul>
        /// <li> If device is enable (calling ::is_enabled as described at \wi{7548}), and if its time since last
        /// operation is greater than it's calling period (as described at \wi{7553}): <ul>
        /// <li> Load iterated I2C device pointer onto ::current.
        /// <li> Poll it using ::step_dev (as described at \wi{7566}.
        /// <li> If ::current is free, then, re-start the related chrono. </ul> </ul>
        i2cif.step();
        if(current != 0)
        {
            step_dev();
        }
        if(current == 0)
        {
            for(Uint16 i=0; (i<devices.size()) && (current == 0); i++)
            {
                I2Cdevice* dev = devices[i].dev;
                if(dev->is_enabled())
                {
                    Real toc = devices[i].chr.toc();
                    Real p = dev->get_period();
                    if(toc > p)
                    {
                        current = &devices[i];
                        step_dev();
                        if(current!=0)
                        {
                            current->chr.tic();
                        }
                    }
                }
            }
        }
    }

    void I2Carbiter::step_dev()
    {
        /// \alg
        /// Perform an I2C driver polling (as described by \wi{7569}) onto ::current, if the result is false,
        /// set ::current to zero.
        if(!current->dev->step())   // Some steps dont generate I2C requests
        {
            current = 0;
        }
    }
}
