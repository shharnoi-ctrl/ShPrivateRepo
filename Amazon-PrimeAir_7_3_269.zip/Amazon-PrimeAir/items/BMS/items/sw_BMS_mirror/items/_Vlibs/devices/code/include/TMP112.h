#ifndef TMP112_H_
#define TMP112_H_

#include <I2Cdevice.h>

namespace Devices
{
    /// Driver for Texas Instruments TMP112 temperature sensor.
    class TMP112: public Dsp28335_ent::I2Cdevice
    {
    public:
        /// Set of I2C addresses for TMP112 devices.
        enum I2Caddr
        {
            addr_TMP112A = 0x48     ///< I2C address for TMP112A device.
        };

        struct Params   ///< Parameters to build instance of TMP112.
        {
            Dsp28335_ent::I2Cif&    i2c_hdlr;   ///< I2C handler.
            const I2Caddr           i2c_addr;   ///< I2C address.
            volatile bool&          var_buit;   ///< System variable flag for BIT.
            volatile Real&          var_meas;   ///< System variable for measurement.
        };

        /// TMP112 default constructor.
        /// \wi{19441}
        /// TMP112 class shall initialize itself upon construction with provided parameters.
        /// \param[in] params   Building parameters.
        explicit TMP112(Params params);

        /// TMP112 get desired sample rate.
        /// \wi{19442}
        /// TMP112 class shall be able to retrieve its desired sample rate.
        /// \return Desired sample rate.
        virtual Real get_desired_rate() const;

        /// TMP112 get sampling period.
        /// \wi{19443}
        /// TMP112 class shall be able to retrieve its sampling period.
        /// \return Sampling period.
        virtual Real get_period() const;

        /// TMP1122 get default period.
        /// \wi{19444}
        /// TMP112 class shall be able to retrieve its default period.
        /// \return Default period.
        virtual Real get_default_period() const;

        /// TMP1122 set period.
        /// \wi{19445}
        /// TMP112 class shall provide the capability to fix its period.
        /// \param[in] period0  New period to fix.
        virtual void set_period(const Real& period0);

    protected:
        /// TMP112 perform step.
        /// \wi{19446}
        /// TMP112 class shall provide the capability to perform specific tasks.
        virtual void do_step();

        /// TMP112 set OK flag.
        /// \wi{19447}
        /// TMP112 class shall provide a method to set OK flag.
        virtual void set_ok(bool ok);

    private:
        enum State  ///< FSM states.
        {
            st_init,    ///< Initialization state, wait for appropriated amount of time.
            st_request, ///< Request state, to write data to TMP112.
            st_read,    ///< Read state, to parse data from TMP112.
            st_error    ///< Error state, to manage error handling.
        };

        static const Uint16 i2c_buff_size = 2U; ///< Buffer for I2C received data.
        static const Uint16 desired_rate = 1U;  ///< Desired sampling update rate.
        static const Uint16 req_steps = 2U;     ///< Required number of step to collect one sample.

        Real period_current;    ///< Current configured period.
        State state;            ///< Current FSM state.
        Base::Timeout tout;     ///< Time out, used to wait mandatory times.
        volatile Real& tmp;     ///< Variable to store parsed measurement.

        /// TMP112 request temperature.
        /// \wi{19448}
        /// TMP112 class shall provide the capability to request temperature measurement.
        /// \return True if succeed, else return false.
        void send_request();

        /// TMP112 read temperature measurement.
        /// \wi{19449}
        /// TMP112 class shall provide the capaiblity to parse temperature measurement from read content.
        void gather_data();

        TMP112(const TMP112& orig); ///< = delete
        TMP112& operator=(const TMP112& orig); ///< = delete
    };

    inline Real TMP112::get_desired_rate() const
    {
        return static_cast<Real>(desired_rate);
    }

    inline Real TMP112::get_period() const
    {
        return period_current;
    }

    inline void TMP112::set_period(const Real& period0)
    {
        /// \alg
        /// From provided ::period0, call I2Cdevice::set_period and fix period_current.
        I2Cdevice::set_period(period0);
        period_current = period0;
    }

    inline void TMP112::set_ok(bool ok)
    {
        state = static_cast<State>((ok*state) + (!ok*st_error));
    }
}

#endif
