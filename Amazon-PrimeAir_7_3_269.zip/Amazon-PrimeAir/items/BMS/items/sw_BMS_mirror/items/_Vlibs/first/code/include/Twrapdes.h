#ifndef TWRAPDES_H_
#define TWRAPDES_H_

#include <Ideserializable.h>
#include <Ttraits.h>
#include <Tuntraits.h>

namespace Base
{
    /// Ideserializable Wrapper.
    /// Base library shall provide a wrapper class so that any class that
    /// implements a synchronous cset method can be converted to an Ideserializable.
    /// Twrapdes is defined as a template with POLICY and T which is the object to wrap.
    // Makes Ideserializable some T.
    // Note that T can be a reference.
    // T shall define synchronous cset method.
    // POLICY is a struct that must have static methods str2elem (see Tuntraits.h).
    template<typename POLICY, typename T = typename POLICY::type>
    class Twrapdes : public Ideserializable
    {
    public:
        T value;    ///< Class to wrap.

        /// Twrapdes Constructor.
        /// \wi{14251}
        /// The Twrapdes class shall provide a default constructor.
        inline Twrapdes()
        {
        }

        /// Twrapdes Constructor.
        /// \wi{14252}
        /// The Twrapdes class shall provide a constructor to build with one parameter.
        /// \param[in] param0 Reference to the parameter to build the T object.
        template<typename P0>
        inline explicit Twrapdes(P0& param0) : value(param0)
        {
        }

        /// Twrapdes Constructor.
        /// \wi{14253}
        /// The Twrapdes class shall provide a constructor to build with two parameters.
        /// \param[in] param0 First parameter to build the T object.
        /// \param[in] param1 Second parameter to build the T object.
        template<typename P0, typename P1>
        inline Twrapdes(P0 param0, P1 param1) : value(param0, param1)
        {
        }

        /// Twrapdes Deserialization.
        /// \wi{14254}
        /// Twrapdes class shall provide the capability to deserialize configuration from a PDIC.
        /// \param[in] str          PDIC to deserialize variable configuration from.
        inline virtual void cset(Base::Lossy_error& str)
        {
             POLICY::str2elem(value,str);
        }


    private:
        Twrapdes(const Twrapdes& orig); ///< = delete
        Twrapdes& operator=(const Twrapdes& orig); ///< = delete
    };

}

#endif
