
#ifndef GPIOMUX_H_
#define GPIOMUX_H_

#include <Vtraits.h>
#include <GPIOid.h>
#include <GPIOtun.h>

namespace Dsp28335_ent
{
    /// Possible mux options in a pin.
    enum Muxfun
    {
        mux_gpio,
        mux_scia,
        mux_scib,
        mux_scic,
        mux_scid,
        mux_spia,
        mux_spib,
        mux_spic,
        mux_spid,  //only for 2838x
        mux_mcbspa,
        mux_mcbspb,
        mux_i2ca,
        mux_i2cb,
        mux_usb0,
        mux_pwm,
        mux_cana,
        mux_canb,
        mux_canfd_a, //only for 2838x
        mux_eth,     //only for 2838x
        mux_cm_uart,  //only for 2838x
        mux_pmbusa
    };

    template <GPIOid id,Muxfun m>
    struct GPIOmux;

    /// Helper to specify value of type GPIOcfg::Mux
    template<GPIOtun::Mux m>
    struct Mux_is : Base::Value_is<GPIOtun::Mux, m>
    {
    };

    template <GPIOid id>struct GPIOmux<id,mux_gpio> : Mux_is<GPIOmux16::mux_0>{};
    template <>struct GPIOmux<gpio_000,mux_pwm>     : Mux_is<GPIOmux16::mux_1>{};
    template <>struct GPIOmux<gpio_001,mux_pwm>     : Mux_is<GPIOmux16::mux_1>{};
    template <>struct GPIOmux<gpio_002,mux_i2cb>    : Mux_is<GPIOmux16::mux_6>{};
    template <>struct GPIOmux<gpio_003,mux_pwm>     : Mux_is<GPIOmux16::mux_1>{};
    template <>struct GPIOmux<gpio_004,mux_pwm>     : Mux_is<GPIOmux16::mux_1>{};
    template <>struct GPIOmux<gpio_004,mux_cana>    : Mux_is<GPIOmux16::mux_6>{};
    template <>struct GPIOmux<gpio_004,mux_canfd_a> : Mux_is<GPIOmux16::mux_9>{};

    template <>struct GPIOmux<gpio_006,mux_pwm>     : Mux_is<GPIOmux16::mux_1>{};

    template <>struct GPIOmux<gpio_008,mux_pwm>     : Mux_is<GPIOmux16::mux_1>{};
    template <>struct GPIOmux<gpio_009,mux_pwm>     : Mux_is<GPIOmux16::mux_1>{};
    template <>struct GPIOmux<gpio_010,mux_pwm>     : Mux_is<GPIOmux16::mux_1>{};
    template <>struct GPIOmux<gpio_011,mux_pwm>     : Mux_is<GPIOmux16::mux_1>{};
    template <>struct GPIOmux<gpio_012,mux_pwm>     : Mux_is<GPIOmux16::mux_1>{};
    template <>struct GPIOmux<gpio_013,mux_pwm>     : Mux_is<GPIOmux16::mux_1>{};
    template <>struct GPIOmux<gpio_013,mux_scic>    : Mux_is<GPIOmux16::mux_6>{};
    template <>struct GPIOmux<gpio_014,mux_mcbspb>  : Mux_is<GPIOmux16::mux_3>{};
    template <>struct GPIOmux<gpio_015,mux_mcbspb>  : Mux_is<GPIOmux16::mux_3>{};

    template <>struct GPIOmux<gpio_017,mux_canb>  : Mux_is<GPIOmux16::mux_2>{};
    template <>struct GPIOmux<gpio_018,mux_cana>  : Mux_is<GPIOmux16::mux_3>{};
    template <>struct GPIOmux<gpio_018,mux_canfd_a>  : Mux_is<GPIOmux16::mux_9>{};
    template <>struct GPIOmux<gpio_019,mux_cana>  : Mux_is<GPIOmux16::mux_3>{};
    template <>struct GPIOmux<gpio_019,mux_canfd_a>  : Mux_is<GPIOmux16::mux_9>{};
    template <>struct GPIOmux<gpio_020,mux_canb>  : Mux_is<GPIOmux16::mux_3>{};


    //template <>struct GPIOmux<gpio_020,mux_mcbspa>  : Mux_is<GPIOmux16::mux_2>{};
    template <>struct GPIOmux<gpio_021,mux_mcbspa>  : Mux_is<GPIOmux16::mux_2>{};
    template <>struct GPIOmux<gpio_022,mux_mcbspa>  : Mux_is<GPIOmux16::mux_2>{};
    template <>struct GPIOmux<gpio_023,mux_mcbspa>  : Mux_is<GPIOmux16::mux_2>{};
    template <>struct GPIOmux<gpio_024,mux_mcbspb>  : Mux_is<GPIOmux16::mux_3>{};
    template <>struct GPIOmux<gpio_025,mux_mcbspb>  : Mux_is<GPIOmux16::mux_3>{};
    //template <>struct GPIOmux<gpio_024,mux_spib>    : Mux_is<GPIOmux16::mux_6>{};
    //template <>struct GPIOmux<gpio_025,mux_spib>    : Mux_is<GPIOmux16::mux_6>{};
    template <>struct GPIOmux<gpio_026,mux_spib>    : Mux_is<GPIOmux16::mux_6>{};
    template <>struct GPIOmux<gpio_027,mux_spib>    : Mux_is<GPIOmux16::mux_6>{};

    template <>struct GPIOmux<gpio_028,mux_scia>    : Mux_is<GPIOmux16::mux_1>{};
    template <>struct GPIOmux<gpio_029,mux_scia>    : Mux_is<GPIOmux16::mux_1>{};
    template <>struct GPIOmux<gpio_030,mux_canfd_a> : Mux_is<GPIOmux16::mux_3>{};
    template <>struct GPIOmux<gpio_031,mux_canfd_a> : Mux_is<GPIOmux16::mux_3>{};
    template <>struct GPIOmux<gpio_032,mux_i2ca>    : Mux_is<GPIOmux16::mux_1>{};
    template <>struct GPIOmux<gpio_033,mux_i2ca>    : Mux_is<GPIOmux16::mux_1>{}; //REMOVE: Only for dock

    template <>struct GPIOmux<gpio_035,mux_i2cb>    : Mux_is<GPIOmux16::mux_6>{};
    template <>struct GPIOmux<gpio_036,mux_cana>    : Mux_is<GPIOmux16::mux_6>{};
    template <>struct GPIOmux<gpio_036,mux_canfd_a> : Mux_is<GPIOmux16::mux_10>{};

    template <>struct GPIOmux<gpio_054,mux_scib>    : Mux_is<GPIOmux16::mux_6>{};
    template <>struct GPIOmux<gpio_055,mux_scib>    : Mux_is<GPIOmux16::mux_6>{};
    template <>struct GPIOmux<gpio_056,mux_scic>    : Mux_is<GPIOmux16::mux_6>{};
    template <>struct GPIOmux<gpio_056,mux_spia>    : Mux_is<GPIOmux16::mux_1>{};
    template <>struct GPIOmux<gpio_057,mux_scic>    : Mux_is<GPIOmux16::mux_6>{};

    template <>struct GPIOmux<gpio_058,mux_spia>    : Mux_is<GPIOmux16::mux_15>{};
    template <>struct GPIOmux<gpio_059,mux_spia>    : Mux_is<GPIOmux16::mux_15>{};
    template <>struct GPIOmux<gpio_060,mux_spia>    : Mux_is<GPIOmux16::mux_15>{};
    template <>struct GPIOmux<gpio_061,mux_spia>    : Mux_is<GPIOmux16::mux_15>{};

    template <>struct GPIOmux<gpio_063,mux_spib>    : Mux_is<GPIOmux16::mux_15>{};
    template <>struct GPIOmux<gpio_064,mux_spib>    : Mux_is<GPIOmux16::mux_15>{};

    template <>struct GPIOmux<gpio_084,mux_mcbspa>  : Mux_is<GPIOmux16::mux_15>{};
    template <>struct GPIOmux<gpio_093,mux_scid>    : Mux_is<GPIOmux16::mux_6>{}; //REMOVE: Only for dock
    template <>struct GPIOmux<gpio_094,mux_scid>    : Mux_is<GPIOmux16::mux_6>{};
    template <>struct GPIOmux<gpio_105,mux_i2ca>    : Mux_is<GPIOmux16::mux_1>{};

    template <>struct GPIOmux<gpio_120,mux_usb0>    : Mux_is<GPIOmux16::mux_15>{}; // USB Power fault
    template <>struct GPIOmux<gpio_121,mux_usb0>    : Mux_is<GPIOmux16::mux_15>{}; // USB Power output enabled
    template <>struct GPIOmux<gpio_122,mux_spic>    : Mux_is<GPIOmux16::mux_6>{};
    template <>struct GPIOmux<gpio_123,mux_spic>    : Mux_is<GPIOmux16::mux_6>{};
    template <>struct GPIOmux<gpio_124,mux_spic>    : Mux_is<GPIOmux16::mux_6>{};
    template <>struct GPIOmux<gpio_125,mux_spic>    : Mux_is<GPIOmux16::mux_6>{};
    template <>struct GPIOmux<gpio_140,mux_scic>    : Mux_is<GPIOmux16::mux_6>{};
    template <>struct GPIOmux<gpio_141,mux_scid>    : Mux_is<GPIOmux16::mux_6>{};
    template <>struct GPIOmux<gpio_142,mux_scid>    : Mux_is<GPIOmux16::mux_6>{};

    template <>struct GPIOmux<gpio_147,mux_pwm>     : Mux_is<GPIOmux16::mux_1>{};

    template <>struct GPIOmux<gpio_150,mux_pwm>     : Mux_is<GPIOmux16::mux_1>{};

    template <>struct GPIOmux<gpio_152,mux_pwm>     : Mux_is<GPIOmux16::mux_1>{};

    template <>struct GPIOmux<gpio_159,mux_pwm>     : Mux_is<GPIOmux16::mux_1>{};
    template <>struct GPIOmux<gpio_160,mux_pwm>     : Mux_is<GPIOmux16::mux_1>{};
    template <>struct GPIOmux<gpio_165,mux_mcbspa>  : Mux_is<GPIOmux16::mux_10>{};
    template <>struct GPIOmux<gpio_166,mux_mcbspa>  : Mux_is<GPIOmux16::mux_10>{};
    template <>struct GPIOmux<gpio_167,mux_mcbspa>  : Mux_is<GPIOmux16::mux_10>{};
    template <>struct GPIOmux<gpio_168,mux_mcbspa>  : Mux_is<GPIOmux16::mux_10>{};


    template <>struct GPIOmux<gpio_044,mux_eth>     : Mux_is<GPIOmux16::mux_11>{};
    template <>struct GPIOmux<gpio_075,mux_eth>     : Mux_is<GPIOmux16::mux_11>{};
    template <>struct GPIOmux<gpio_105,mux_eth>     : Mux_is<GPIOmux16::mux_14>{};
    template <>struct GPIOmux<gpio_106,mux_eth>     : Mux_is<GPIOmux16::mux_14>{};
    //..
    template <>struct GPIOmux<gpio_108,mux_eth>     : Mux_is<GPIOmux16::mux_14>{};
    template <>struct GPIOmux<gpio_109,mux_eth>     : Mux_is<GPIOmux16::mux_14>{};
    template <>struct GPIOmux<gpio_110,mux_eth>     : Mux_is<GPIOmux16::mux_14>{};
    template <>struct GPIOmux<gpio_111,mux_eth>     : Mux_is<GPIOmux16::mux_14>{};
    template <>struct GPIOmux<gpio_112,mux_eth>     : Mux_is<GPIOmux16::mux_14>{};
    template <>struct GPIOmux<gpio_113,mux_eth>     : Mux_is<GPIOmux16::mux_14>{};
    template <>struct GPIOmux<gpio_114,mux_eth>     : Mux_is<GPIOmux16::mux_14>{};
    template <>struct GPIOmux<gpio_115,mux_eth>     : Mux_is<GPIOmux16::mux_14>{};
    template <>struct GPIOmux<gpio_116,mux_eth>     : Mux_is<GPIOmux16::mux_14>{};
    template <>struct GPIOmux<gpio_117,mux_eth>     : Mux_is<GPIOmux16::mux_14>{};
    template <>struct GPIOmux<gpio_118,mux_eth>     : Mux_is<GPIOmux16::mux_14>{};
    template <>struct GPIOmux<gpio_119,mux_eth>     : Mux_is<GPIOmux16::mux_14>{};
    //..
    template <>struct GPIOmux<gpio_122,mux_eth>     : Mux_is<GPIOmux16::mux_14>{};
    template <>struct GPIOmux<gpio_123,mux_eth>     : Mux_is<GPIOmux16::mux_14>{};
    template <>struct GPIOmux<gpio_124,mux_eth>     : Mux_is<GPIOmux16::mux_14>{};

    template <>struct GPIOmux<gpio_024,mux_pmbusa>     : Mux_is<GPIOmux16::mux_9>{};
    template <>struct GPIOmux<gpio_025,mux_pmbusa>     : Mux_is<GPIOmux16::mux_9>{};
    template <>struct GPIOmux<gpio_093,mux_pmbusa>     : Mux_is<GPIOmux16::mux_10>{};
}
#endif
