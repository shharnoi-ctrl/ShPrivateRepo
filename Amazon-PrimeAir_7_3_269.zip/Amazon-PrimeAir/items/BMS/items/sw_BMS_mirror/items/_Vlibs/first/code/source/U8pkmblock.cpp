#include <U8pkmblock.h>
#include <Rfun.h>
#include <U8pkmblock_k.h>

namespace Base
{
    Uint32 U8pkmblock::write(Uint32 start_idx, const U8pkmblock_k& mb, Uint32 src_offset, Uint32 src_count)
    {
        /// \alg
        /// <ul>
        /// <li> Initialize "end" as minimum value between given ("start_idx" + "src_count") and U8pkmblock_k::sz.
        const Uint16 end = Rfun::min<Uint16>(start_idx + src_count, sz);
        /// <li> Initialize "j" as given "src_offset".
        Uint16 j = src_offset;
        /// <li> Iterate from given "start_idx" to "end":
        for(Uint16 i=start_idx; i<end; ++i)
        {
            /// <ul>
            /// <li> Call ::set with current iteration and retrieved value by U8pkmblock_k::get for U8pkmblock_k::mb
            /// with current "j".
            set(i, mb.get(j));
            /// <li> Increase "j" by one.
            ++j;
            /// </ul>
        }
        /// <li> Return "j" minus given "src_offset"
        return j-src_offset;
        /// </ul>
    }

    Uint32 U8pkmblock::write(const U8pkmblock_k& src) volatile
    {
        /// \alg
        /// <ul>
        Base::Assertions::runtime(src.size() <= sz);
        /// <li> Initialize "new_sz" as minimum value between U8pkmblock_k::sz and size of given packed memory 
        /// block "src".
        const Uint16 new_sz = Rfun::min<Uint16>(sz, src.size());
        /// <li> Initialize "size_in_words16" as ("new_sz" >> 1).
        const Uint16 size_in_words16 = new_sz >> Ku16::u1;

        /// <li> If "new_sz" is not 0:
        if(new_sz != 0)
        {
            /// <ul>
            /// <li> Call Tmem::cpy_max<65536> with ::v, pointer to data for "src" and 
            /// "size_in_words16"*sizeof(Uint16).
            Tmem::cpy_max<max_c2000_sz>(v, src.v, size_in_words16*sizeof(Uint16));
            /// <li> If new_sz is not even: 
            if((new_sz & 1) != 0) 
            {
                /// <ul>
                /// <li> Copy last byte by calling ::set with ("new_sz"-1) and retrieved value by U8pkmblock_k::get
                /// for given "src" with ("new_sz"-1).
                set(new_sz-1, src.get(new_sz-1));
                /// </ul>
            }
            /// </ul>
        }
        /// <li> Return "new_sz".
        return new_sz;
        /// </ul>
    }
}
