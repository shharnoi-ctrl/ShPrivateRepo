///    \file Vartraits.h
///
///    \date 22 sept. 2017
///
///    \author  FJBurgos, jbm (at) embention.com
///    Company:  Embention
///
///    Vartraits class declaration.
///

#ifndef VARTRAITS_H_
#define VARTRAITS_H_

#include <Ttraits.h>
#include <Hrvar.h>
#include <Huvar.h>
#include <Hbmapvar.h>
#include <Hbvar.h>
#include <Hfvar.h>
#include <Cptraits.h>

namespace Base
{

    namespace Vartraits
    {
        template<typename K, typename V, typename H, typename CPG>
        struct Vtypeset
        {
            typedef K   Type_key;
            typedef V   Type_val;
            typedef H   Type_bvh;    ///< Bsp variable handler
            typedef CPG Type_gct;    ///< Handler getter copy trait.
        };

        typedef Vtypeset<Rvar, Real   , Bsp::Hrvar, Cptraits::Getbyvalue<Bsp::Hrvar, Real   > > Rtypes ;
        typedef Vtypeset<Uvar, Uint16 , Bsp::Huvar, Cptraits::Getbyvalue<Bsp::Huvar, Uint16 > > Utypes ;
        typedef Vtypeset<Bvar, bool   , Bsp::Hbvar, Cptraits::Getbyvalue<Bsp::Hbvar, bool   > > Btypes ;
        typedef Vtypeset<Fid , Feature, Bsp::Hfvar, Cptraits::Getbyref  <Bsp::Hfvar, Feature> > Ftypes ;
        typedef Vtypeset<Bvar_map,
                         Hbmapvar::Type,
                         Hbmapvar,
                         Cptraits::Getbyvalue<Hbmapvar, Hbmapvar::Type> > BMaptype;



        // type mappings for Rvar-Real-Hrvar, Uvar-Uint16-Huvar, Bvar-bool-Hbvar,
        template <typename T> struct Types_for;
        template <> struct Types_for   <Rvar      > : Rtypes {};
        template <> struct Types_for   <Real      > : Rtypes {};
        template <> struct Types_for   <Bsp::Hrvar> : Rtypes {};
        template <> struct Types_for   <Uvar      > : Utypes {};
        template <> struct Types_for   <Uint16    > : Utypes {};
        template <> struct Types_for   <Bsp::Huvar> : Utypes {};
        template <> struct Types_for   <Bvar      > : Btypes {};
        template <> struct Types_for   <bool      > : Btypes {};
        template <> struct Types_for   <Bsp::Hbvar> : Btypes {};
        template <> struct Types_for   <Fid       > : Ftypes {};
        template <> struct Types_for   <Feature   > : Ftypes {};
        template <> struct Types_for   <Bsp::Hfvar> : Ftypes {};
        template <> struct Types_for   <Bvar_map  > : BMaptype {};


    } // namespace Vartraits

} // namespace Base

#endif // VARTRAITS_H_
