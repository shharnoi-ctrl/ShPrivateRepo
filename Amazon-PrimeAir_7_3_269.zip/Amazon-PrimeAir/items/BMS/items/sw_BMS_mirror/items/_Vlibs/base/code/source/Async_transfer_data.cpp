#include <Async_transfer_data.h>

namespace Base
{
    void Async_transfer_data::init(Uint32 data_sz)
    {
        /// \alg
        /// - Set ::position to 0.
        position = 0;
        /// - Set ::to_transfer to given data size.
        to_transfer = data_sz;
        /// - Set ::transferred to 0.
        transferred = 0;
        /// - Set ::transfering to ::to_transfer if ::to_transfer is lower than ::max_sz, ::max_sz otherwise.
        transfering = (to_transfer < max_sz)
                       ? to_transfer            // Will require only one iteration.
                       : max_sz;                // Will require multiple iterations.
    }

    bool Async_transfer_data::next()
    {
        /// \alg
        /// <ul>
        /// <li> Update async data record.
        const Uint32 nb_write = transfering;
        position      += nb_write;
        transferred   += nb_write;
 
        /// <li> If there is still data to write.
        const bool is_next = (transferred < to_transfer);

        if(is_next)
        {
            /// <ul>
            /// <li> Get Remaining bytes to write as ::to_transfer minus ::transferred.
            const Uint32 rem_write = to_transfer - transferred;

            /// <li> Set ::transfering as the minumum value between remaining bytes to write 
            /// and ::max_sz.
            transfering = Rfun::min<Uint32>(rem_write, max_sz);
            /// </ul>
        }

        /// <li> Return True If there is still data to write, False otherwise.
        return is_next;
        /// </ul>
    }
}
