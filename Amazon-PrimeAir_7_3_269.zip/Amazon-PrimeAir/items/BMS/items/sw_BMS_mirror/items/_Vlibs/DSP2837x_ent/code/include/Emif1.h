#ifndef EMIF1_H_
#define EMIF1_H_

#include <Entypes.h>

namespace Dsp28335_ent
{
    /// class to handle Emif1 peripheral registers.
    struct Emif1
    {
    public:
        /// \return ASYNC_CS2_CR register value.
        Uint32 get_async_cs2_cr();
        /// Sets ASYNC_CS2_CR register value for Veronte4 External RAM.
        void set_async_cs2_cr_veronte4();
        /// \return MSEL register value.
        Uint32 get_msel();
        /// Sets ownership for CPU1 (only CPU1 allowed).
        void cpu1_grab();
        /// Sets ownership for CPU2 (only CPU2 allowed).
        void cpu2_grab();
        /// Leave ownership free to allow other CPU to grab it.
        void ungrab();
        /// Checks that CPU has the ownership.
        void assert_is_grabbed_by_cpu1();
        /// Disables access protection (commit included) and locks the configuration
        /// so that EMIF1COMMIT register can't be changed any more.
        void lock();

        /// Builds EMIF1 handler.
        Emif1();

    private:
        struct Emif_regs;
        struct Emif1_config_regs;

        volatile Emif_regs& emif1_regs;
        volatile Emif1_config_regs& emif1_cfg_regs;

        /// Checks MSEL.
        void assert_msel(Uint32 rd_expected);
        /// Writes and checks MSEL.
        void set_msel(Uint32 msel0, Uint32 rd_expected);

        /// \return EMIF1 registers base address
        static volatile Emif_regs& get_emif1_regs();
        /// \return EMIF1 configuration registers base address
        static volatile Emif1_config_regs& get_emif1_config_regs();

        Emif1(const Emif1& orig); ///< = delete
        Emif1& operator=(const Emif1& orig); ///< = delete
    };
}
#endif
