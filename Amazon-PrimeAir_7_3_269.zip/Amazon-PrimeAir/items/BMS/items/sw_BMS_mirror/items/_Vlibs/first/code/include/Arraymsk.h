///    \file Arraymsk.h
///
///    \date 20 dic. 2017
///
///    \author  FJBurgos, jbm (at) embention.com
///    Company:  Embention
///
///    Arraymsk class declaration.
///

#ifndef ARRAYMSK_H_
#define ARRAYMSK_H_

#include <Bitarray.h>
namespace Base
{

    /// The Base library shall provide a structure to apply a bitmask to an static array.
    template <typename T,Uint16 sz>
    struct Arraymsk
    {
        Tnarray<T   ,sz> data;      ///< Static array.
        Bitarray<sz>     msk;       ///< Bitarray mask.

        /// Bitmask Static Array Is Enabled Checker.
        /// \wi{4951}
        /// Arraymsk struct shall provide the capability to check if a bit in the mask is enabled for a specified index.
        /// \param[in] i Bit index to be checked.
        /// \return True if bit is enabled, False otherwise.
        bool is_enabled(Uint16 i) const volatile;
        /// Bitmask Static Array Size Retriever.
        /// \wi{4952}
        /// Arraymsk struct shall be able to retrieve the size of its static array mask.
        /// \return Size of the bitmask static array.
        static Uint16 size();
    };


    template <typename T,Uint16 sz>
    inline bool Arraymsk<T,sz>::is_enabled(Uint16 i) const volatile
    {
        /// \alg
        /// <ul>
        /// <li> Return retrieved value by the logical AND operation between:
        /// <ul>
        /// <li> 'Less than' comparison for the given index and the templated array size ("i"<"sz").
        /// <li> Retrieved value by Bitarray0::get for ::msk with given index.
        /// </ul>
        /// </ul>
        return (i<sz) && (msk.get(i));
    }

    template <typename T,Uint16 sz>
    inline Uint16 Arraymsk<T,sz>::size()
    {
        /// \alg
        /// - Return size of the templated array "sz".
        return sz;
    }

} // namespace Base

#endif // ARRAYMSK_H_
