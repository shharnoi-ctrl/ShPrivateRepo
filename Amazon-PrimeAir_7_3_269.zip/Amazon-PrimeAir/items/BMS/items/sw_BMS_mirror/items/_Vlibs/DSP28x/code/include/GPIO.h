#ifndef GPIO_H_
#define GPIO_H_

#include <Entypes.h>
#include <GPIOid.h>

namespace Dsp28335_ent
{
    struct Gpio_data_regs;

    // Class to manage GPIO.
    class GPIO
    {
    public:
        /// GPIO Constructor.
        /// \wi{7589}
        /// GPIO class shall initialize itself upon construction and its internal members.
        /// \param[in] id GPIO Id to use.
        GPIO(GPIOid id);
        /// GPIO Id Getter.
        /// \wi{16657}
        /// GPIO class shall provide the capability to retrieve the GPIO id.
        /// \return GPIO id for this GPIO.
        GPIOid get_id() const;
        /// GPIO High Setter.
        /// \wi{7637}
        /// GPIO class shall provide the capability to set as high value by setting the correct peripheral register.
        void set_hi();
        /// GPIO Low Setter.
        /// \wi{7631}
        /// GPIO class shall provide the capability to set as low value by setting the correct peripheral register.
        void set_lo();
        /// GPIO Setter.
        /// \wi{7851}
        /// GPIO class shall provide the capability to set the GPIO to the desired value.
        /// \param[in] v Value to set the GPIO.
        void set(bool v);
        /// GPIO Toggler.
        /// \wi{7640}
        /// GPIO class shall provide the capability to toggle GPIO status from high to low or vice-versa.
        void toggle();
        /// GPIO Getter.
        /// \wi{7634}
        /// GPIO class shall provide the capability to retrieve the GPIO current value by reading
        /// the correct peripheral registers.
        /// \return True if high, false if low.
        bool get() const;

    private:
        const GPIOid id;                   ///< Id of this GPIO.
        volatile Gpio_data_regs& dregs;    ///< Registers for this GPIO, to speed up access.
        const Uint32 mask1;                ///< Mask to directly access to register bit for this GPIO.

        GPIO(); ///< = delete
        GPIO(const GPIO& orig); ///< = delete
        GPIO& operator=(const GPIO& orig); ///< = delete
    };

    inline GPIOid GPIO::get_id() const
    {
        return id;
    }
}
#endif
