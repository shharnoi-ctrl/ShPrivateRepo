#ifndef GPIOV_H_
#define GPIOV_H_

#include <GPIO.h>
#include <IGpio.h>

namespace Dsp28335_ent
{
    /// GPIOv
    /// Dsp28335_ent library shall provide a class to include the GPIO implementations from IGpio.
    class GPIOv: public Base::IGpio
    {
    public:
        /// Virtual GPIO Constructor with ID.
        /// \wi{21420}
        /// GPIOv class shall provide the capability of building itself upon construction
        /// and initialize its members.
        /// \param[in] id       The id for the GPIO.
        explicit GPIOv(GPIOid id);
        /// Virtual GPIO ID Getter.
        /// \wi{21421}
        /// GPIOv class shall provide the capability of
        /// retrieving the ID of GPIO.
        /// \return ID of the GPIO
        GPIOid get_id() const;
        /// Virtual GPIO High Setter.
        /// \wi{21422}
        /// GPIOv class shall provide the capability to set the GPIO to high.
        virtual void set_hi();
        /// Virtual GPIO Low Setter.
        /// \wi{7633}
        /// GPIOv class shall provide the capability to set the GPIO to low.
        virtual void set_lo();
        /// Virtual GPIO Setter.
        /// \wi{7853}
        /// GPIOv class shall provide the capability to set the GPIO to the given value.
        /// \param[in] v        The value to be assigned to the GPIO.
        virtual void set(bool v);
        /// Virtual GPIO Toggler.
        /// \wi{7642}
        /// GPIOv class shall provide the capability of toggle the GPIO value.
        virtual void toggle();
        /// Virtual GPIO Retriever.
        /// \wi{7636}
        /// GPIOv class shall provide the capability of retrieving the current GPIO value.
        /// \return True if the GPIO is high, otherwise False.
        virtual bool get() const;
    private:
        GPIO gpio;                              ///< GPIO to work with. Can be a reference.

        GPIOv(const GPIOv& orig);               ///< = delete.
        GPIOv& operator=(const GPIOv& orig);    ///< = delete.
    };

    /// \alg
    /// The members of GPIOv shall be initialized as:
    /// <ul>
    ///     <li> ::gpio: shall be constructed by passing to it "id".
    /// </ul> 
    inline GPIOv::GPIOv(GPIOid id) : gpio(id)
    {
    }

    inline GPIOid GPIOv::get_id() const
    {
        /// \alg
        /// Return the value retrieved by calling GPIO::get_id in ::gpio.
        return gpio.get_id();
    }

    inline void GPIOv::set_hi()
    {
        /// \alg
        /// Call GPIO::set_hi in ::gpio.
        gpio.set_hi();
    }

    inline void GPIOv::set_lo()
    {
        /// \alg
        /// Call GPIO::set_lo in ::gpio.
        gpio.set_lo();
    }

    inline void GPIOv::set(bool v)
    {
        /// \alg
        /// Call GPIO::set in ::gpio passing to it "v".
        gpio.set(v);
    }

    inline void GPIOv::toggle()
    {
        /// \alg
        /// Call GPIO::toggle in ::gpio.
        gpio.toggle();
    }

    inline bool GPIOv::get() const
    {
        /// \alg
        /// Return the value retrieved by calling GPIO::get in ::gpio.
        return gpio.get();
    }
}
#endif
