#include <CAN_FD.h>
#include <Asm.h>
#include <CAN_FD_ioctl.h>
#include <Allocator.h>
#include <CANframe.h>
#include <Cpusys.h>
#include <Ku8.h>
#include <Ptr_cast.h>
#include <U8ostream.h>

#include "CAN_FD_regs.h"//PRQA S 1015

namespace Dsp28335_ent
{
    namespace
    {
        static const Uint32 word32bytes = 4UL;
        static const Uint16 std_id_despl = 18U;
        static const Uint16 pt8_to_pt32_d = 2U;
        static const Uint32 obj_size[8] = {4, 5, 6, 7, 8, 10, 14, 18};

        enum DLC    /// Data Length Codes for CAN-FD
        {
            dlc0  =  0, ///< 0 bytes - Start of CAN 2.0 lengths
            dlc1  =  1, ///< 1 byte
            dlc2  =  2, ///< 2 bytes
            dlc3  =  3, ///< 3 bytes
            dlc4  =  4, ///< 4 bytes
            dlc5  =  5, ///< 5 bytes
            dlc6  =  6, ///< 6 bytes
            dlc7  =  7, ///< 7 bytes
            dlc8  =  8, ///< 8 bytes  - End of CAN20 lengths
            dlc12 =  9, ///< 12 bytes - Start of CAN-FD lengths
            dlc16 = 10, ///< 16 bytes
            dlc20 = 11, ///< 20 bytes
            dlc24 = 12, ///< 24 bytes
            dlc32 = 13, ///< 32 bytes
            dlc48 = 14, ///< 48 bytes
            dlc64 = 15  ///< 64 bytes - End of CAN-FD lengths
        };

        /// DLC value conversion table.
        static const Uint8 dlcs[14] = { dlc12, dlc16, dlc20, dlc24, dlc32, dlc32, dlc48, dlc48, dlc48, dlc48, dlc64, dlc64, dlc64, dlc64 };
    }

    /// CAN-FD private implementation.
    /// It just is used to have a base address holder.
    struct CAN_FD::Pimpl
    {
    };

    CAN_FD::CAN_FD(Base::CANpid id0) :
        id(id0),
        impl(*reinterpret_cast<Pimpl*>(Base::Assertions::runtime(id == Base::canpid_fda) ? MCAN::mcana_base_addr : MCAN::mcana_base_addr)),
        tx_count(0),
        rx_count(0),
        canfd_mode(false),
        brs(false),
        fifo_sz(0)
    {
        /// \alg Initialize its internal variables as follows:
        /// - Write counter: zero
        /// - Read counter: zero
        /// - CAN-FD mode: false
        /// - BRS: false
        Base::Assertions::runtime(id0 == Base::canpid_fda);

        Cpusys cs;
        cs.clk_enable(Cpusys::clk_canfd_a);

        // Allocate MCAN (a shared peripheral) to CPU1 (C28x)
        asm_eallow();
        static const Uint32 cmconf_base = 0x0005DC00UL;
        static const Uint32 sysctl_o_pallocate0 = 0x20U;
        static const Uint16 sysctl_pallocate_mcan_a = 4U;
        Uint32 reg_v = MCAN::read_reg<Uint32>(cmconf_base + sysctl_o_pallocate0);
        reg_v &= ~Base::Bitutils::get_mask_1bit<Uint32>(sysctl_pallocate_mcan_a);
        MCAN::write_reg(cmconf_base + sysctl_o_pallocate0, reg_v);
        asm_edis();
    }

    void CAN_FD::config(const CAN_FD_cfg& cfg)
    {
        CAN_FD_ioctl::config(*this, cfg);
    }

    bool CAN_FD::get_bus_on() const
    {
        return MCAN::read_reg<MCAN::PSR>(Base::pt2addr(&impl) + MCAN::mcan_psr).bo;
    }

    bool CAN_FD::get_warning_off() const
    {
        return MCAN::read_reg<MCAN::PSR>(Base::pt2addr(&impl) + MCAN::mcan_psr).ew;
    }

    Uint16 CAN_FD::get_tx_errors() const
    {
        return MCAN::read_reg<MCAN::ECR>(Base::pt2addr(&impl) + MCAN::mcan_ecr).tec;
    }

    Uint16 CAN_FD::get_rx_errors() const
    {
        return MCAN::read_reg<MCAN::ECR>(Base::pt2addr(&impl) + MCAN::mcan_ecr).rec;
    }

    bool CAN_FD::rd_available() const
    {
        return MCAN::read_reg<MCAN::RXFxS>(Base::pt2addr(&impl) + MCAN::mcan_rxf1s).fxfl;
    }

    bool CAN_FD::read(Base::CANframe& frame)
    {
        /// \alg
        const Uint32 base_addr =  Base::pt2addr(&impl);
        /// - Set result to true if read is available.
        bool res = MCAN::read_reg<MCAN::RXFxS>(base_addr + MCAN::mcan_rxf1s).fxfl > 0;
        if(res) /// - If read is available: <ul>
        {
            /// <li> Compute address of the message
            const Uint32 start_addr = static_cast<Uint32>(MCAN::read_reg<MCAN::RXFxC>(base_addr + MCAN::mcan_rxf1c).fxsa) << pt8_to_pt32_d;
            const Uint32 elem_size_e = MCAN::read_reg<MCAN::RXESC>(base_addr + MCAN::mcan_rxesc).f1ds;
            const Uint32 elem_size  = obj_size[elem_size_e] << pt8_to_pt32_d;
            const Uint32 idx = MCAN::read_reg<MCAN::RXFxS>(base_addr + MCAN::mcan_rxf1s).fxgi;
            Uint32 elem_addr = base_addr +start_addr + (elem_size * idx);

            /// <li> Read the message.
            MCAN::Frame_elem_id eid(MCAN::read_reg<MCAN::Frame_elem_id>(elem_addr));
            elem_addr += word32bytes;
            frame.id.id       = eid.id;
            frame.id.extended = eid.xtd;
            if(!frame.id.extended)
            {
                frame.id.id >>= std_id_despl;
            }

            MCAN::Rx_frame_elem_format ef(MCAN::read_reg<MCAN::Rx_frame_elem_format>(elem_addr));
            elem_addr += word32bytes;
            const Uint16 dsize = dlc_to_len(static_cast<DLC>(ef.dlc));
            frame.data.data.resize(dsize);

            Base::Mblock_u32 mb(frame.data.to_mblock32());
            const Uint32 n = frame.data.data.size() >> 2U; // Number of 32bit words
            for(Uint16 i=0; i<n; i++)
            {
                mb[i] = Base::get_mem<Uint32>(elem_addr);
                elem_addr += word32bytes;
            }

            /// <li> Mark message as read.
            // Full register can be written as there are no other fields than f1ai.
            MCAN::write_reg(base_addr + MCAN::mcan_rxf1a, idx);

            /// <li> Increment read counter.
            ++rx_count;
        } /// </ul>
        return res; /// - Return result.
    }

    bool CAN_FD::wr_available() const
    {
        return !MCAN::read_reg<MCAN::TXFQS>(Base::pt2addr(&impl) + MCAN::mcan_txfqs).tfqf;
    }

    bool CAN_FD::write(const Base::CANframe& frame)
    {
        /// \alg
        const Uint32 base_addr =  Base::pt2addr(&impl);
        /// - Set result to true if write is available.
        bool res = !MCAN::read_reg<MCAN::TXFQS>(base_addr + MCAN::mcan_txfqs).tfqf;
        if(res) /// - If write is available: <ul>
        {
            /// <li> Compute address of the message
            const Uint32 idx = MCAN::read_reg<MCAN::TXFQS>(base_addr + MCAN::mcan_txfqs).tfqp;
            const Uint32 start_addr = static_cast<Uint32>(MCAN::read_reg<MCAN::TXBC>(base_addr + MCAN::mcan_txbc).tbsa) << pt8_to_pt32_d;
            const Uint32 elemSize_e = MCAN::read_reg<MCAN::TXESC>(base_addr + MCAN::mcan_txesc).tbds;
            const Uint32 elemSize  = obj_size[elemSize_e] << pt8_to_pt32_d;
            Uint32 elem_addr = base_addr + start_addr + (elemSize * idx);

            /// <li> Write the message.
            MCAN::Frame_elem_id eid = { 0UL };
            eid.id = frame.id.id;
            if(!frame.id.extended)
            {
                eid.id <<= std_id_despl;
            }

            eid.xtd = frame.id.extended;
            MCAN::write_reg(elem_addr, eid.all);
            elem_addr += word32bytes;

            MCAN::Tx_frame_elem_format ef = { 0UL };
            ef.dlc = len_to_dlc(frame.data.data.size());
            ef.brs = brs;
            ef.fdf = canfd_mode;
            MCAN::write_reg(elem_addr, ef.all);
            elem_addr += word32bytes;

            Base::Mblock<const Uint32> mb(frame.data.to_mblock32());
            const Uint32 n = Base::Bitutils::bytes_to_words32(frame.data.data.size()); // Number of 32bit words
            for(Uint16 i=0; i<n; i++)
            {
                MCAN::write_reg(elem_addr, mb[i]);
                elem_addr += word32bytes;
            }

            /// <li> Mark message to be sent.
            MCAN::write_reg(base_addr + MCAN::mcan_txbar, Base::Bitutils::get_mask_1bit<Uint32>(idx));
            /// <li> Increment write counter.
            ++tx_count;
        } /// </ul>
        return res; /// - Return result.
    }
}
