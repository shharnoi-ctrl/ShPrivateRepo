#include <U8ostream.h>

namespace Base
{
    bool U8ostream::seek(Uint32 pos0)
    {
        /// \alg
        /// <ul>
        /// <li> Initialize the result as false.
        bool res = false;
        /// <li> Check if the position does not exceed the size of the internal buffer.
        if(Assertions::runtime( pos0<=mb.size() ))
        {
            /// <ul>
            /// <li> Set ::pos with given parameter. 
            /// <li> Set the result to true.
            /// </ul>
            pos = pos0;
            res = true;
        }
        /// <li> Return the result.
        return res;
        /// </ul>
    }

    void U8ostream::put_uint16_le(Uint16 v)
    {
        /// \alg
        /// <ul>
        /// <li> Check if the position plus the size of a 16-bit unsigned 
        /// integer does not exceed the size of the internal size buffer.
        if(Assertions::runtime((pos + Ku16::u2) <= mb.size()))
        {
            /// <ul>
            /// <li> Set the least significant byte of the value at the pos memory block position.
            mb.set(pos,          Bitutils::get_u8(&v, Ku16::u0));
            /// <li> Set the most significant byte of the value at the pos+Ku16::u1 memory block position.
            mb.set(pos+Ku16::u1, Bitutils::get_u8(&v, Ku16::u1));
            /// <li> Increment the position by the size of a 16-bit unsigned integer.
            pos += Ku32::u2;
            /// </ul>
        }
        /// </ul>
    }

    void U8ostream::put_uint24_le(Uint32 v)
    {
        /// \alg
        /// <ul>
        /// <li> Check if the position plus the size of a 24-bit unsigned 
        /// integer does not exceed the size of the internal size buffer.
        if(Assertions::runtime((pos + Ku16::u3) <= mb.size()))
        {
            /// <ul>
            /// <li> Set the least significant byte of the value at the pos memory block position.
            mb.set(pos,          Bitutils::get_u8(&v, Ku16::u0));
            /// <li> Set the second least significant byte of the value at the pos+Ku16::u1 memory block position.
            mb.set(pos+Ku16::u1, Bitutils::get_u8(&v, Ku16::u1));
            /// <li> Set the most significant byte of the value at the pos+Ku16::u2 memory block position.
            mb.set(pos+Ku16::u2, Bitutils::get_u8(&v, Ku16::u2));
            /// <li> Increment the position by the size of a 24-bit unsigned integer.
            pos += Ku32::u3;
            /// </ul>

        }
        /// </ul>
    }

    void U8ostream::put_uint32_le(Uint32 v)
    {
        /// \alg
        /// <ul>
        /// <li> Check if the position plus the size of a 32-bit unsigned 
        /// integer does not exceed the size of the internal size buffer.
        if(Assertions::runtime((pos + Ku16::u4) <= mb.size()))
        {
            /// <ul>
            /// <li> Set the least significant byte of the value at the pos memory block position.
            mb.set(pos,          Bitutils::get_u8(&v, Ku16::u0));
            /// <li> Set the second least significant byte of the value at the pos+Ku16::u1 memory block position.
            mb.set(pos+Ku16::u1, Bitutils::get_u8(&v, Ku16::u1));
            /// <li> Set the third least significant byte of the value at the pos+Ku16::u2 memory block position.
            mb.set(pos+Ku16::u2, Bitutils::get_u8(&v, Ku16::u2));
            /// <li> Set the most significant byte of the value at the pos+Ku16::u3 memory block position.
            mb.set(pos+Ku16::u3, Bitutils::get_u8(&v, Ku16::u3));
            /// <li> Increment the position by the size of a 32-bit unsigned integer.
            pos += Ku32::u4;
            /// </ul>
        }
        /// </ul>
    }

    void U8ostream::put_uint16_be(Uint16 v)
    {
        /// \alg
        /// <ul>
        /// <li> Check if the position plus the size of a 16-bit unsigned 
        /// integer does not exceed the size of the internal size buffer.
        if(Assertions::runtime((pos + Ku16::u2) <= mb.size()))
        {
            /// <ul>
            /// <li> Set the most significant byte of the value at the pos memory block position.
            mb.set(pos,          Bitutils::get_u8(&v, Ku16::u1));
            /// <li> Set the least significant byte of the value at the pos+Ku16::u1 memory block position.
            mb.set(pos+Ku16::u1, Bitutils::get_u8(&v, Ku16::u0));
            /// <li> Increment the position by the size of a 16-bit unsigned integer.
            pos += Ku32::u2;
            /// </ul>
        }
        /// </ul>
    }

    void U8ostream::put_uint24_be(Uint32 v)
    {
        /// \alg
        /// <ul>
        /// <li> Check if the position plus the size of a 24-bit unsigned 
        /// integer does not exceed the size of the internal size  buffer.
        if(Assertions::runtime((pos + Ku16::u3) <= mb.size()))
        {
            /// <ul>
            /// <li> Set the most significant byte of the value at the pos memory block position.
            mb.set(pos,          Bitutils::get_u8(&v, Ku16::u2));
            /// <li> Set the second most significant byte of the value at the pos+Ku16::u1 memory block position.
            mb.set(pos+Ku16::u1, Bitutils::get_u8(&v, Ku16::u1));
            /// <li> Set the least significant byte of the value at the pos+Ku16::u2 memory block position.
            mb.set(pos+Ku16::u2, Bitutils::get_u8(&v, Ku16::u0));
            /// <li> Increment the position by the size of a 24-bit unsigned integer.
            pos += Ku32::u3;
            /// </ul>
        }
        /// </ul>
    }

    void U8ostream::put_uint32_be(Uint32 v)
    {
        /// \alg
        /// <ul>
        /// <li> Check if the position plus the size of a 32-bit unsigned 
        /// integer does not exceed the size of the internal size buffer.
        if(Assertions::runtime((pos + Ku16::u4) <= mb.size()))
        {
            /// <ul>
            /// <li> Set the most significant byte of the value at the pos memory block position.
            mb.set(pos,          Bitutils::get_u8(&v, Ku16::u3));
            /// <li> Set the second most significant byte of the value at the pos+Ku16::u1 memory block position.
            mb.set(pos+Ku16::u1, Bitutils::get_u8(&v, Ku16::u2));
            /// <li> Set the third most significant byte of the value at the pos+Ku16::u2 memory block position.
            mb.set(pos+Ku16::u2, Bitutils::get_u8(&v, Ku16::u1));
            /// <li> Set the least significant byte of the value at the pos+Ku16::u3 memory block position.
            mb.set(pos+Ku16::u3, Bitutils::get_u8(&v, Ku16::u0));
            /// <li> Increment the position by the size of a 32-bit unsigned integer.
            pos += Ku32::u4;
            /// </ul>
        }
        /// </ul>
    }
    void U8ostream::put_uint64_le(Uint64 v)
    {
        /// \alg
        /// <ul>
        /// <li> Check if the position plus the size of a 64-bit 
        /// unsigned integer does not exceed the size of the internal size buffer.
        if(Assertions::runtime((pos + Ku16::u8) <= mb.size()))
        {
            /// <ul>
            /// <li> Set the least significant byte of the value at the pos memory block position.
            mb.set(pos,          Bitutils::get_u8(&v, Ku16::u0));
            /// <li> Set the second least significant byte of the value at the pos+Ku16::u1 memory block position.
            mb.set(pos+Ku16::u1, Bitutils::get_u8(&v, Ku16::u1));
            /// <li> Set the third least significant byte of the value at the pos+Ku16::u2 memory block position.
            mb.set(pos+Ku16::u2, Bitutils::get_u8(&v, Ku16::u2));
            /// <li> Set the fourth least significant byte of the value at the pos+Ku16::u3 memory block position.
            mb.set(pos+Ku16::u3, Bitutils::get_u8(&v, Ku16::u3));
            /// <li> Set the fifth least significant byte of the value at the pos+Ku16::u4 memory block position.
            mb.set(pos+Ku16::u4, Bitutils::get_u8(&v, Ku16::u4));
            /// <li> Set the sixth least significant byte of the value at the pos+Ku16::u5 memory block position.
            mb.set(pos+Ku16::u5, Bitutils::get_u8(&v, Ku16::u5));
            /// <li> Set the seventh least significant byte of the value at the pos+Ku16::u6 memory block position.
            mb.set(pos+Ku16::u6, Bitutils::get_u8(&v, Ku16::u6));
            /// <li> Set the most significant byte of the value at the pos+Ku16::u7 memory block position.
            mb.set(pos+Ku16::u7, Bitutils::get_u8(&v, Ku16::u7));
            /// <li> Increment the position by the size of a 64-bit unsigned integer.
            pos += Ku32::u8;
        /// </ul>
        }
        /// </ul>
    }

    void U8ostream::put_uint64_be(Uint64 v)
    {
        /// \alg
        /// <ul>
        /// <li> Check if the position plus the size of a 64-bit 
        /// unsigned integer does not exceed the size of the internal size buffer.
        if(Assertions::runtime((pos + Ku16::u8) <= mb.size()))
        {
            /// <ul>
            /// <li> Set the most significant byte of the value at the pos memory block position.
            mb.set(pos,          Bitutils::get_u8(&v, Ku16::u7));
            /// <li> Set the second most significant byte of the value at the pos+Ku16::u1 memory block position.
            mb.set(pos+Ku16::u1, Bitutils::get_u8(&v, Ku16::u6));
            /// <li> Set the third most significant byte of the value at the pos+Ku16::u2 memory block position.
            mb.set(pos+Ku16::u2, Bitutils::get_u8(&v, Ku16::u5));
            /// <li> Set the fourth most significant byte of the value at the pos+Ku16::u3 memory block position.
            mb.set(pos+Ku16::u3, Bitutils::get_u8(&v, Ku16::u4));
            /// <li> Set the fifth most significant byte of the value at the pos+Ku16::u4 memory block position.
            mb.set(pos+Ku16::u4, Bitutils::get_u8(&v, Ku16::u3));
            /// <li> Set the sixth most significant byte of the value at the pos+Ku16::u5 memory block position.
            mb.set(pos+Ku16::u5, Bitutils::get_u8(&v, Ku16::u2));
            /// <li> Set the seventh most significant byte of the value at the pos+Ku16::u6 memory block position.
            mb.set(pos+Ku16::u6, Bitutils::get_u8(&v, Ku16::u1));
            /// <li> Set the least significant byte of the value at the pos+Ku16::u7 memory block position.
            mb.set(pos+Ku16::u7, Bitutils::get_u8(&v, Ku16::u0));
            /// <li> Increment the position by the size of a 64-bit unsigned integer.
            pos += Ku32::u8;
            /// </ul>
        }
        /// </ul>
    }

    void U8ostream::put_uint64_be(Uint64 v, Uint16 nbytes)
    {
        /// \alg
        /// <ul>
        /// <li> Check if the position plus the specified number of bytes 
        /// does not exceed the size of the internal size buffer.
        if(Assertions::runtime((pos + nbytes) <= mb.size()))
        {
            /// <ul>
            /// <li> Iterate over each byte to serialize.
            for(Uint32 i=0; i<nbytes; i++)
            {
                /// <li> Set byte value until size of received parameter instance 
                /// with retrieved value by Bitutils::get_u8 incrementing the index of the byte to set.
                mb.set(pos+i, Bitutils::get_u8(&v, (nbytes - (i + 1))));
            }
            /// <li> Increment the position by the number of bytes serialized.
            pos += nbytes;
            /// </ul>
        }
        /// </ul>
    }

    void U8ostream::put_mblock(const U8pkmblock_k& mbaux)
    {
        /// \alg
        /// <ul>
        /// <li> Check if the position plus the specified number of bytes 
        /// does not exceed the size of the internal size buffer.
        if(Assertions::runtime((pos + mbaux.size()) <= mb.size()))
        {
            /// <ul>
            /// <li> Write the memory block data into the internal buffer..
            mb.write(pos, mbaux, Ku16::u0, mbaux.size());
            /// <li> Increment the position by the size of the memory block.
            pos += mbaux.size();
            /// </ul>
        }
    }
}
