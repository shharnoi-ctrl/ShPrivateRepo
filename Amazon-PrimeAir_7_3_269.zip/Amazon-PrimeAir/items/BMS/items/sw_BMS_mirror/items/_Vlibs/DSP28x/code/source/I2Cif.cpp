#include <Asm.h>
#include <Const.h>
#include <Delay.h>
#include <Hregmap.h>
#include <I2Cif.h>
#include <Ku8.h>

#include "I2Cif_Regs.h" //PRQA S 1015

namespace Dsp28335_ent
{
    I2Cif::I2Cif(Id id0, GPIOid sda_id0, GPIOid clk_id0, Speed speed0) :
        clk_id(clk_id0),
        sda(sda_id0),
        clk(clk_id0),
        id(id0),
        speed(speed0),
        busy(false),
        busy_tout(Const::ONE),
        rx_fails(0),
        tx_fails(0),
        status(i2c_ok),
        op_adata(fifo_sz),
        is_write_op(true),
        is_repeated_mode(false),
        regs(get_regs())
    {
        /// \alg
        /// Type                |   Name            | Value
        /// ------------------- | ----------------- | ---------------
        /// GPIOid              | clk_id            | ::clk_id0
        /// GPIO                | sda               | ::sda_id0
        /// GPIO                | clk               | ::clk_id0
        /// I2Cif::Id           | id                | ::id0
        /// I2Cif::Speed        | speed             | ::speed0
        /// volatile bool       | busy              | false
        /// Timeout             | busy_tout         | 1.0F
        /// Uint16              | rx_fails          | 0
        /// Uint16              | tx_fails          | 0
        /// I2Cif::Status       | status            | ::i2c_ok
        /// Async_transfer_data | op_adata          | 16 (bytes)
        /// bool                | is_write_op       | true
        /// bool                | is_repeated_mode  | false
        /// Regs                | regs              | I2C registers
    }

    void I2Cif::init()
    {
        /// \alg
        /// <ul>
        set_clk_enable();                   /// <li> Enable clock (as described at \wi{16673}),
        set_speed(speed);                   /// <li> Configure I2C speed (as described at \wi{7570}),
        regs.I2CMDR.bit.IRS  = 0;           /// <li> Disable I2C peripheral module, and configure it as: <ul>
        regs.I2CMDR.bit.MST  = 1;           ///     <li> Master Mode,
        regs.I2CMDR.bit.XA   = 0;           ///     <li> Expanded address disable,
        regs.I2CMDR.bit.BC   = 0;           ///     <li> 8 bits per byte,
        /// </ul>
        regs.I2CMDR.bit.IRS  = 1;           /// <li> Re-enable the I2C peripheral module,
        regs.I2CFFTX.bit.I2CFFEN    = 1;    /// <li> Enable I2C FIFO mode,
        regs.I2CFFTX.bit.TXFFRST    = 1;    /// <li> Reset transmission FIFO,
        regs.I2CFFTX.bit.TXFFINTCLR = 1;    /// <li> Clear transmission IRQ flag,
        regs.I2CFFTX.bit.TXFFIENA   = 0;    /// <li> Disable transmission FIFO IRQ.
        regs.I2CFFRX.bit.RXFFRST    = 1;    /// <li> Enable reception FIFO,
        regs.I2CFFRX.bit.RXFFINTCLR = 1;    /// <li> Clear reception IRQ flag,
        regs.I2CFFRX.bit.RXFFIENA   = 0;    /// <li> Disable reception FIFO IRQ,
        /// <li> Restart the bus through recover arbitration mechanism (as described at \wi{16680}). </ul>
        recover_arb();
    }

    /// \pre Assume that I2C module peripheral was previously disabled.
    void I2Cif::set_speed(Speed nspeed)
    {
        //PCLK = 200M/(I2CPSC+1)
        // I2C CLK = (I2CPSC+1)*(ICCL+d + ICCH+d)/PCLK
        //                   200M/(20*( 7+5 + 8+5)) = 400 Khz
        //                   200M/(20*(45+5 +45+5)) = 100 Khz

        /// \alg
        /// As described onto reference manual at I2C section, peripherals registers shall be
        /// configured as: <ul>
        /// Register    | Description                   | 100 KHz   | 400 KHz
        /// ----------- | ----------------------------- | --------- | --------
        /// I2CPSC      | Prescaler                     | 19        | 19
        /// I2CCLKL     | Low part of clock divider     | 65        | 10
        /// I2CCLKH     | High part of clock divider    | 25        | 5
        /// </ul>
        /// Then: <ul>
        /// <li> Fix ::speed attribute to ::nspeed parameter,
        /// <li> Configure the timeout to: 170/100000 for 100KHz or 170/100000 for 400KHz,
        /// <li> Enable the module.

        bool enable = static_cast<bool>(regs.I2CMDR.bit.IRS);
        regs.I2CMDR.bit.IRS  = 0;  // Disable i2c module
        switch(nspeed)
        {
            case i2c_100Khz:
            {
                speed = nspeed;
                regs.I2CPSC.all = 19;     // Prescaler - need 7-12 Mhz on module clk (200/20 = 10MHz)
                regs.I2CCLKL    = 65;       // NOTE: must be non zero
                regs.I2CCLKH    = 25;       // NOTE: must be non zero
                busy_tout.set_timeout_s(static_cast<Real>(max_queued_bits)/speed_100Khz);
                break;
            }
            case i2c_400Khz:
            {
                speed = nspeed;
                regs.I2CPSC.all = 19;     // Prescaler - need 7-12 Mhz on module clk (200/20 = 10MHz)
                regs.I2CCLKL    = 10;     // NOTE: must be non zero
                regs.I2CCLKH    = 5;      // NOTE: must be non zero
                busy_tout.set_timeout_s(static_cast<Real>(max_queued_bits)/speed_400Khz);
                break;
            }
            default:
            {
                Bsp::warning();
                break;
            }
        }
        regs.I2CMDR.bit.IRS  = enable;  // Enable i2c module

    }

    void I2Cif::stop()
    {
        /// \alg
        regs.I2CMDR.bit.STP = Ku16::u1;
        Delay::ns_by_50(Ku16::u1);
        regs.I2CMDR.bit.STP = 0;
        clear_busy();
    }

    void I2Cif::reset()
    {
        regs.I2CMDR.bit.IRS = 0;
        Delay::ns_by_50(Ku16::u1);
        regs.I2CMDR.bit.IRS = 1;
        Delay::ns_by_50(Ku16::u1);
        clear_busy();
    }

    /// \pre Assume that ::start_write or ::start_read has been previously called.
    void I2Cif::start_operation(bool is_wr0, Uint16 addr0)
    {
        /// \alg
        is_write_op = is_wr0;       /// <ul> <li> Fix operation type attribute from ::is_wr0,
        regs.I2CSAR.all = addr0;    /// <li> Fix slave address to ::addr0,
                                    /// <li> Fix expected length (in bytes) for this operation,
        regs.I2CCNT = static_cast<Uint16>(op_adata.to_transfer);

        /// <Fix the data mode as: <ul>
        // <li> ::mdr_mst as "Master mode",
        // <li> ::mdr_irs as "Releasing I2C bus" (if peripheral is holding it),
        // <li> ::mdr_stt as "Generate Start condition",
        // <li> ::mdr_stp as "Generate Stop" (after control byte). </ul>
        Uint16 mdr = mdr_mst | mdr_irs | mdr_stt;

        // <li> If write operation: <ul>
        if(is_wr0)
        {
            mdr |= mdr_trx; /// <li> Configure ::mdr_trx as "Transmitter mode" to 1 (write operation).
            bulk_tx();      /// <li> Bulk data from memory block to peripheral FIFO as described at \wi{16683} </ul>
        }
        /// <li> If not repeated mode, configure data mode to generate a stop condition after processing operation
        /// (configuring ::mdrs_stp as "Generate Stop" to 1). </ul>
        if(!is_repeated_mode)
        {
            mdr |= mdr_stp;
        }
        regs.I2CMDR.all = mdr;
    }

    bool I2Cif::start_write(Uint16 addr, const Base::U8pkmblock_k& mb_tx0, bool has_stop)
    {
        bool res = false;

        // Check if I2C peripheral is not currently busy
        // I2Carbiter shall ensure not calling more than 1 device at the same time
        if(is_busy())
        {
            recover_arb();
            set_status(i2c_busy);
        }
        else
        {
            // Initialize attributes of this class
            status = i2c_ok;
            set_busy();

            // Initialize data record with expected data size
            op_adata.init(mb_tx0.size());
            mb_tx = mb_tx0;
            mb_rx = Base::U8pkmblock();

            // Start operation (through peripheral registers)
            is_repeated_mode = !has_stop;
            start_operation(true, addr);
            res = true;
        }
        return res;
    }

    bool I2Cif::start_read(Uint16 addr, Base::U8pkmblock& mb_rx0, bool has_stop)
    {
        bool res = false;

        // Check if I2C peripheral is not currently busy
        // I2Carbiter shall ensure not calling more than 1 device at the same time
        if(is_busy())
        {
            recover_arb();
            set_status(i2c_busy);
        }
        else
        {
            // Wait for stop condition to be generated
            if(regs.I2CMDR.bit.STP == 1)
            {
                set_status(i2c_stp_not_ready);
            }
            else
            {
                // Initialize attributes of this class
                status = i2c_ok;
                set_busy();

                // Initialize data record with expected data size
                op_adata.init(mb_rx0.size());
                mb_rx = mb_rx0;
                mb_tx = Base::U8pkmblock_k();

                // Start operation (through peripheral registers)
                is_repeated_mode = !has_stop;
                start_operation(false, addr);
                res = true;
            }
        }
        return res;
    }

    bool I2Cif::check_fifo(bool bulk_rx0)
    {
        /// \alg
        /// <ul>
        /// <li> On write operation, return True if peripheral FIFO is empty,
        /// <li> On read operation, return True if peripheral FIFO rely memory block size. In addition,
        /// if ::bulk_rx0 is True, bulk FIFO content onto dedicated memory block.
        bool res = is_write_op ? (regs.I2CFFTX.bit.TXFFST == 0) : (regs.I2CFFRX.bit.RXFFST == op_adata.transfering);
        if(res && bulk_rx0)
        {
            bulk_rx();
        }
        return res;
    }

    bool I2Cif::check_transfer(bool bulk_rx0)
    {
        /// \alg
        /// If total number of bytes from data record rely I2C count,
        bool ret = (op_adata.position + op_adata.transfering) == regs.I2CCNT;
        if(ret)
        {
            ret = check_fifo(bulk_rx0); /// check expected FIFO count (as described at \wi{16888}).
        }
        return ret;
    }

    bool I2Cif::check_tout()
    {
        bool ret = false;
        if(busy_tout.expired())
        {
            set_status(i2c_lockup);
            recover_arb();  // clear busy
            ret = true;
        }
        return ret;
    }

    bool I2Cif::check_regs()
    {
        bool ret = true;
        if(regs.I2CSTR.bit.ARBL)                // Arbitration lost
        {
            set_status(i2c_arb_lost);
            recover_arb();  // busy cleared
        }
        else if(regs.I2CSTR.bit.NACK)           // No Acknowledgment received
        {
            set_status(i2c_nack);
            reset();        // busy cleared
        }
        else if(regs.I2CSTR.bit.AAS)            // Addressed as slave
        {
            set_status(i2c_slave_err);
            reset();        // busy cleared
        }
        else
        {
            ret = false;
        }
        return ret;
    }

    void I2Cif::finish()
    {
        const bool has_stop = regs.I2CSTR.bit.SCD;
        const bool is_data_remain = op_adata.has_next();

        bool has_finished = false;

        // Stop condition shall always be processed for driver part not to corrupt peripheral state
        if(has_stop)
        {
            // Error if remain data or if repeated start or if unfinished transfer
            if(is_data_remain || is_repeated_mode
               || !check_transfer(!is_write_op))    // Bulk RXFF in case of finished read operation
            {
                op_error();
            }
            regs.I2CSTR.bit.SCD = 1;    // Clear peripheral register stop flag
            clear_busy();
            has_finished = true;
        }
        else if(is_data_remain)
        {
            // Check for finished operation
            if(check_fifo(!is_write_op))    // Bulk RXFF in case of finished read operation
            {
                op_adata.next();            // Load next transfer
                if(is_write_op)
                {
                    bulk_tx();              // Bulk TXFF in case of write operation
                }
                has_finished = true;
            }
        }
        else
        {
            if(is_repeated_mode)
            {
                Base::Assertions::runtime(is_write_op); // Repeated start from read operation not supported
                if(check_transfer(false))
                {
                    clear_busy();
                    has_finished = true;
                }
            }
        }

        // If finished, restart the chrono, else check for time-out
        if(has_finished)
        {
            busy_tout.start();
        }
        else
        {
            check_tout();
        }
    }

    void I2Cif::step()
    {
        /// \alg If I2C is busy (as described at \wi{7572}): <ul>
        /// <li> If I2C status registers are OK, reestablish the time out for next transaction,
        /// <li> Else, finish the current transaction (as described at \wi{16892}).
        /// </ul>
        if(is_busy())
        {
            if(check_regs())
            {
                busy_tout.start();  // Reestablish the time out for next transaction
            }
            else
            {
                finish();
            }
        }
    }

    bool I2Cif::is_busy() const
    {
        // Do not check BB value on repeated start transaction
        return busy || (!is_repeated_mode && (regs.I2CSTR.bit.BB == 1));
    }

    void I2Cif::set_enabled(bool value)
    {
        regs.I2CMDR.bit.IRS = value;
    }

    void I2Cif::recover_arb()
    {
        /// \alg
        const Uint16 max_steps = max_queued_bits*2;

        set_enabled(0);     /// <ul> <li> Disable I2C peripheral (as described at \wi{16677}),
        config_gpio(false); /// <li> Configure SCL clock to be controlled by GPIO (as described at \wi{16674}),
        clk.set_lo();       /// <li> Set SCL GPIO to Low state,
        /// <li> Until SDA GPIO state is Low, and for a maximum of 340 attempts: <ul>
        for(Uint16 i=0;(i<max_steps) && !sda.get();i++)
        {
            clk.toggle();   ///     <li> Toggle the SCL pin,
            Delay::us(1);   ///     <li> Wait 1 microsecond. </ul>
        }
        clk.set_lo();       /// <li> Set SCL GPIO to Low state,
        config_gpio(true);  /// <li> Configure SCL clock to be controlled by I2C (as described at \wi{16674}),
        set_enabled(1);     /// <li> Enable I2C peripheral (and wait 50 nanoseconds to ensure changes to be effective),
        Delay::ns_by_50(Ku16::u1);
        clear_busy();       /// <li> Finally, clear the busy flag (as described at \wi{16676}).
    }

    void I2Cif::bulk_tx()
    {
        const Uint16 pos = static_cast<Uint16>(op_adata.position);
        const Uint16 len = static_cast<Uint16>(op_adata.transfering);
        for(Uint16 i=0; i<len; i++)
        {
            const Uint16 idx = pos + i;
            const Uint8 value = mb_tx.get(idx);
            regs.I2CDXR.all = value;
        }
    }

    void I2Cif::bulk_rx()
    {
        const Uint32 pos = static_cast<Uint16>(op_adata.position);
        const Uint32 len = static_cast<Uint16>(op_adata.transfering);
        for(Uint16 i=0; i<len; i++)
        {
            const Uint16 idx = pos + i;
            const Uint8 value = static_cast<Uint8>(regs.I2CDRR.all & Ku8::u0xFF);
            mb_rx.set(idx, value);
        }
    }

    void I2Cif::tx_error()
    {
        regs.I2CFFTX.bit.TXFFRST=0; // Reset FIFO
        tx_fails++;
        stop();
        set_status(i2c_error_tx);
        regs.I2CFFTX.bit.TXFFRST=1; // Re enable FIFO
    }

    void I2Cif::rx_error()
    {
        regs.I2CFFRX.bit.RXFFRST=0; // Reset FIFO
        rx_fails++;
        set_status(i2c_error_rx);
        regs.I2CFFRX.bit.RXFFRST=1; // Re enable FIFO
    }

    void I2Cif::op_error()
    {
        if(is_write_op)
        {
            tx_error();
        }
        else
        {
            rx_error();
        }
    }
}
