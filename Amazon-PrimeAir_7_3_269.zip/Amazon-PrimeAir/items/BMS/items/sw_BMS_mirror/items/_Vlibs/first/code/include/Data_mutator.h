#ifndef DATA_MUTATOR_H_
#define DATA_MUTATOR_H_

#include <Assertions.h>
#include <Entypes.h>

namespace Base
{
    /// Manages automatic resize of data object via a mutator object via destructor.
    /// <ul>
    /// <li> MTRAITS Traits for mutator object. Shall define:
    /// <ul>
    ///   <li> type -> Type of the mutator object to be used.
    ///   <li> static adapt_data(const U8pkmblock& mb) -> returns the appropiate data for construction
    ///                                              of the mutator object
    ///   <li> static Uint32 get_size(const U8ostream& os) -> returns the size of the mutator when finished
    ///   <li> static void set_pos(U8ostream& os, Uint16 sz) -> sets pointer in correct position
    /// </ul>
    ///
    /// <li> DTRAITS
    /// <ul>
    ///   <li> type -> Type of the data object.
    ///   <li> static Uint32 get_max_size(const CANdata& d) -> Returns max allowed length
    ///   <li> static U8pkmblock get_data(CANdata& d) -> Returns raw data block to be used by mutator
    ///   <li> static void update_size(CANdata& d, Uint32 sz) -> Resize the data object.
    ///   <li> static Uint16 get_pos(const CANdata& d) -> Returns position
    /// </ul>
    /// </ul>
    ///
    /// As an example, we can bulid a Lossy over a U8istream to be able to read bits from it and have the U8istream
    /// position automatically updated when the Data_mutator is destroyed:
    /// <ul>
    ///   <li> U8istream is(...);
    ///   <li> Base::Data_mutator<Base::Lossy::Mutator_traits8<>, Base::U8istream::Data_traits8> mutator(is);
    ///   <li> Base::Lossy& str(mutator.m);
    /// </ul>
    template<typename MTRAITS, typename DTRAITS>
    class Data_mutator
    {
    public:
        typename MTRAITS::type m; ///< Mutator object.

        /// Data Mutator Constructor.
        /// \wi{18107}
        /// Data_mutator class shall build itself upon construction with the given parameter data object.
        /// \param[in] data Data to be mutated.
        Data_mutator(typename DTRAITS::type& data);

        /// Data Mutator Destructor.
        /// \wi{18108}
        /// Data_mutator class shall destroy itself upon destruction and update the size of the data object.
        ~Data_mutator();

    protected:
        typename DTRAITS::type& d;  ///< Data object.
        Uint16 curr_pos;            ///< Current position when Data mutator is built.

    private:
        Data_mutator(const Data_mutator&); ///< = delete
        Data_mutator& operator=(const Data_mutator&); ///< = delete
    };

    template <typename MTRAITS, typename DTRAITS>
    Data_mutator<MTRAITS, DTRAITS>::Data_mutator(typename DTRAITS::type& data) :
        m(MTRAITS::adapt_data(DTRAITS::get_data(data))),
        d(data),
        curr_pos(DTRAITS::get_pos(d))
    {
        /// \alg
        /// Initialize class attributes as follows:
        /// <ul>
        /// <li> ::m will be initialized with retrieved value by MTRAITS::adapt_data(DTRAITS::get_data(data)).
        /// <li> ::d will be initialized with received data.
        /// <li> ::curr_pos will be initialized with retrieved value by DTRAITS::get_pos(d).
        /// </ul>
        /// <ul>
        /// <li> Set pointer in correct position by MTRAITS::set_pos(m, curr_pos).
        /// </ul>
        MTRAITS::set_pos(m, curr_pos);
    }

    template <typename MTRAITS, typename DTRAITS>
    Data_mutator<MTRAITS, DTRAITS>::~Data_mutator()
    {
        /// \alg
        /// <ul>
        /// <li> Store size by substracting the current size from the data position as MTRAITS::get_size - ::curr_pos.
        const Uint32 sz0 = MTRAITS::get_size(m) - curr_pos;
        /// <li> Check if calculated size is less than the maximum size allowed for the data object.
        /// <ul>
        /// <li> If True set the current size to the calculated size.
        /// <li> Else set the current size to the maximum allowed size for the data object.
        /// </ul>
        const Uint32 sz = Assertions::runtime(sz0 <= DTRAITS::get_max_size(d)) ? sz0 : DTRAITS::get_max_size(d);
        /// <li> Update the size of a given DTRAITS instance with the computed size  calling to DTRAITS::update_size. 
        DTRAITS::update_size(d, sz);
        /// </ul>
    }
}
#endif
