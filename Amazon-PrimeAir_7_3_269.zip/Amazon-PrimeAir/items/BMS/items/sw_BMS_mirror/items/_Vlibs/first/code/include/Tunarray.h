#ifndef TUNARRAY_H__
#define TUNARRAY_H__

#include <Ptr_cast.h>
#include <Atunarray.h>
#include <Array.h>
#include <Arraymsk.h>
#include <Ttraits.h>
#include <Itunable.h>

namespace Base
{
    template <typename T, bool has_cget = false>
    /// The Base library shall provide a class to manage and manipulate elements within the tunable array.
    class Tunarray: public Array<T>
    {
    public:

        /// Tunarray class shall provide a structure to build a constant tunable array for external,
        /// non modifiable reference.
        struct Ktun
        {
        public:
            const Tunarray<T, has_cget> k;      ///< Constant tunable array.

            template <typename T2, Uint16 sz>
            /// Constant Tunable Array Constructor with Bitmask Static Array.
            /// \wi{5252}
            /// Ktun structure shall build itself upon construction with given Arraymsk reference.
            /// \param[in] a Bitmask Static Array.
            explicit Ktun(const Arraymsk<T2, sz>& a);

        private:
            Ktun();                            ///< = delete.
            Ktun(const Ktun& orig);            ///< = delete.
            Ktun& operator=(const Ktun& orig); ///< = delete.
        };
        /// Tunable Array Constructor with Given Size and Memory Type.
        /// \wi{5250}
        /// Tunarray class shall build itself upon construction with given array size and memory type.
        /// \param[in] n0 Array size.
        /// \param[in] memtype Memory type.
        Tunarray(Uint32 n0,Memmgr::Type memtype);

        // Different parameter to each element
        /// Tunable Array Constructor with Given Size, Memory Type and Memory Block.
        /// \wi{5251}
        /// Tunarray class shall build itself upon construction with given array size, memory type and memory block.
        /// \param[in] n0 Array size.
        /// \param[in] memtype Memory type.
        /// \param[in] param Memory block.
        template <class T2>
        Tunarray(Uint32 n0,
              Memmgr::Type memtype,
              Mblock<T2> param);

        template <typename T2, Uint16 sz>
        /// Tunable Array Constructor with Bitmask Static Array.
        /// \wi{21027}
        /// Tunarray class shall build itself upon construction with given Arraymsk reference.
        /// \param[in] a Bitmask Static Array.
        explicit Tunarray(Arraymsk<T2, sz>& a);

        // Same parameter to each element
        /// Tunable Array Constructor with Given Size, Memory Type and One Parameter.
        /// \wi{21028}
        /// Tunarray class shall build itself upon construction with given array size, memory type and parameter.
        /// \param[in] n0 Array size.
        /// \param[in] memtype Memory type.
        /// \param[in] param0 First template parameter.
        template<class T0>
        Tunarray(Uint32 n0,Memmgr::Type memtype, T0 param0);

        template<class T0, class T1>
        /// Tunable Array Constructor with Given Size, Memory Type and Two Parameters.
        /// \wi{21029}
        /// Tunarray class shall build itself upon construction with given array size, memory type and two parameters.
        /// \param[in] n0 Array size.
        /// \param[in] memtype Memory type.
        /// \param[in] param0 First template parameter.
        /// \param[in] param1 Second template parameter.
        Tunarray(Uint32 n0,Memmgr::Type memtype, T0 param0, T1 param1);

        template<class T0, class T1, class T2>
        /// Tunable Array Constructor with Given Size, Memory Type and Three Parameters.
        /// \wi{21030}
        /// Tunarray class shall build itself upon construction with given array size, memory type and three
        /// parameters.
        /// \param[in] n0 Array size.
        /// \param[in] memtype Memory type.
        /// \param[in] param0 First template parameter.
        /// \param[in] param1 Second template parameter.
        /// \param[in] param2 Third template parameter.
        Tunarray(Uint32 n0,Memmgr::Type memtype, T0 param0, T1 param1, T2 param2);

        /// Tunable Array Element Enabled Setter.
        /// \wi{5253}
        /// Tunarray class shall provide a method to set the enabled state of the element at given index.
        /// \param[in] i Index of the element to be set.
        /// \param[in] en0 Boolean value indicating whether the element should be enabled or disabled.
        void set_enabled(Uint16 i, bool en0);
        /// Tunable Array Element Checker.
        /// \wi{5254} 
        /// Tunarray class shall provide a method to check whether the element at given index is enabled.
        /// \param[in] i Index of the element to be checked.
        /// \return  True if the element is enabled at the given index, False otherwise.
        bool is_enabled(Uint16 i)const;
        /// Tunable Array Clear.
        /// \wi{5255} 
        /// Tunarray class shall provide a method to clear all elements.
        void clear();

        /// Tunable Array Stepper.
        /// \wi{5256} 
        /// Tunarray class shall provide a method to perform a periodical step for all the Istep elements.
        void step();

        /// Tunable Array Deserialization.
        /// \wi{6192}
        /// Tunarray class shall provide the capability to deserialize configuration from a PDIC.
        /// \param[in] str Stream of data where deserialize the configuration from. 
        void cset(Base::Lossy_error& str);

        template<bool enabled = has_cget>
        /// Tunable Array Serialization.
        /// \wi{6191} 
        /// Tunarray class shall provide the capability to serialize its configuration to a PDIC.
        /// \param[in,out] str Lossy where data shall be serialized.
        typename Enable_if<enabled, void>::type cget(Base::Lossy& str) const;

        /// Tunable Array First Disabled Element Finder.
        /// \wi{13953}
        /// The Tunarray class shall provide a method to obtain the index of the first disabled element.
        /// \return Optional element containing the index of the first disable element in the array if
        /// there is any, otherwise the optional shall be disabled.
        Optional<Uint16> find_first_disabled() const;

    protected:
        /// Tunable Array Mask Retriever.
        /// \wi{21301}
        /// The Tunarray class shall provide the capability to retrieve the mask.
        /// \return Mask.
        Atunarray& get_msk();
    private:
        Atunarray msk;          ///< Mask to know which elements are present.

        template <typename T2, Uint16 sz>
        /// Tunable Array Constructor with Constant Bitmask Static Array.
        /// \wi{21089}
        /// Tunarray class shall build itself upon construction with given constant Arraymsk reference.
        /// \param[in] a Bitmask Static Array.
        explicit Tunarray(const Arraymsk<T2, sz>& a);

        Tunarray();                                 ///< = delete.
        Tunarray(const Tunarray& src);              ///< = delete.
        Tunarray& operator=(const Tunarray& src);   ///< = delete.
    };

    template <typename T, bool has_cget>
    template <typename T2, Uint16 sz>
    inline Tunarray<T, has_cget>::Ktun::Ktun(const Arraymsk<T2, sz>& a) : k (a) //PRQA S 3080 #Can't use a different cast here
    {
        /// \alg
        /// - ::k is initialized with given "a". 
    }

    template <typename T, bool has_cget>
    inline Tunarray<T, has_cget>::Tunarray(Uint32 n0,Memmgr::Type memtype):
        Array<T>(n0, memtype),
        msk(n0, memtype)
    {
        /// \alg
        /// <ul>
        /// <li> Construct the base class ::Array by passing to it "n0" and "memtype".
        /// <li> ::msk is initialized with "n0" and "memtype".
        /// <li> Call ::clear.
        /// </ul>
        clear();
    }

    template <typename T, bool has_cget>
    template <class T2>
    inline Tunarray<T, has_cget>::Tunarray(Uint32 n0,
          Memmgr::Type memtype,
          Mblock<T2> param) :
          Array<T>(n0, memtype, param),
          msk(n0, memtype)
    {
        /// \alg
        /// <ul>
        /// <li> Construct the base class ::Array by passing to it "n0", "memtype" and "param".
        /// <li> ::msk is initialized with "n0" and "memtype".
        /// </ul>
    }

    template <typename T, bool has_cget>
    template <typename T2, Uint16 sz>
    Tunarray<T, has_cget>::Tunarray(Arraymsk<T2, sz>& a) :
        Array<T>(a.data.to_mblock()),
        msk(a.msk)
    {
        /// \alg
        /// <ul>
        /// <li> Construct the base class ::Array by passing to it the retrieved value by Tnarray::to_mblock
        /// for Arraymsk::data in "a".
        /// <li> ::msk is initialized with ::msk for "a".
        /// <li> Call ::clear.
        /// </ul>
        clear();
    }

    template <typename T, bool has_cget >
    template<class T0>
    inline Tunarray<T, has_cget>::Tunarray(Uint32 n0,Memmgr::Type memtype, T0 param0):
        Array<T>(n0, memtype, param0),
        msk(n0, memtype)
    {
        /// \alg
        /// <ul>
        /// <li> Construct the base class ::Array by passing to it "n0", "memtype" and "param0".
        /// <li> ::msk is initialized with "n0" and "memtype".
        /// <li> Call ::clear.
        /// </ul>
        clear();
    }

    template <typename T, bool has_cget>
    template<class T0, class T1>
    inline Tunarray<T, has_cget>::Tunarray(Uint32 n0,Memmgr::Type memtype, T0 param0, T1 param1):
        Array<T>(n0, memtype, param0, param1),
        msk(n0, memtype)
    {
        /// \alg
        /// <ul>
        /// <li> Construct the base class ::Array by passing to it "n0", "memtype", "param0" and "param1".
        /// <li> ::msk is initialized with "n0" and "memtype".
        /// <li> Call ::clear.
        /// </ul>
        clear();
    }

    template <typename T, bool has_cget>
    template<class T0, class T1, class T2>
    inline Tunarray<T, has_cget>::Tunarray(Uint32 n0,Memmgr::Type memtype, T0 param0, T1 param1, T2 param2):
        Array<T>(n0, memtype, param0, param1, param2),
        msk(n0, memtype)
    {
        /// \alg
        /// <ul>
        /// <li> Construct the base class ::Array by passing to it "n0", "memtype", "param0", "param1", "param2".
        /// <li> ::msk is initialized with "n0" and "memtype".
        /// Call ::clear.
        /// </ul>
        clear();
    }

    template <typename T, bool has_cget>
    inline void Tunarray<T, has_cget>::set_enabled(Uint16 i, bool en0)
    {
        /// \alg
        /// - Call ::set_enabled for ::msk with "i" and "en0".
        msk.set_enabled(i, en0);
    }

    template <typename T, bool has_cget>
    inline bool Tunarray<T, has_cget>::is_enabled(Uint16 i)const
    {
        /// \alg
        /// - Return ::is_enabled for ::msk with "i".
        return msk.is_enabled(i);
    }

    template <typename T, bool has_cget>
    inline void Tunarray<T, has_cget>::clear()
    {
        /// \alg
        /// - Call ::clear for ::msk.
        msk.clear();
    }


    template <typename T, bool has_cget>
    void Tunarray<T, has_cget>::step()
    {
        /// \alg
        /// - Iterate over the elements of the array and if they are enabled for ::msk,
        /// perform a step for a pointer to each element of ::Array converted to itself.
        for(Uint16 i=0;i<Array<T>::n;i++)
        {
            if(msk.is_enabled(i))
            {
                ptr_cast(Array<T>::v[i]).step();
            }
        }
    }

    template <typename T, bool has_cget>
    /// \pdi
    /// PDIC shall admit the following structure depending on the field type:
    /// Type        | Name          | Description                                           | Range
    /// ----------- |-------------- | ----------------------------------------------------- | -----
    /// Uint16      | msk_size      | Size of the tunarray.                                 | -
    /// Uint16      | idx           | Index of the enabled elements of tunarray.            | [0, sz - 1]
    /// T           | element_idx   | Element of tunarray in index idx.                     | 

    void Tunarray<T, has_cget>::cset(Base::Lossy_error& str)
    {
        /// \alg
        /// <ul>
        /// <li> Deserialize ::sz using Atunarray::cset_size for ::msk.
        /// <li> Initialize ::idx as zero.
        /// <li> Decrease ::sz until reaching zero. While doing that action, perform:
        Uint16 sz = msk.cset_size(str);
        Uint16 idx = 0;
        while(sz-- > 0)
        {
            /// <ul>
            /// <li> Deserialize ::idx Atunarray::cset_element for ::msk.
            /// <li> Convert the pointer to each element to itself and deserialize them.
            /// </ul>
            idx = msk.cset_element(str);
            ptr_cast(Array<T>::v[idx])->cset(str);
        }
        /// </ul>
    }

    template <typename T, bool has_cget>
    inline Atunarray& Tunarray<T, has_cget>::get_msk()
    {
        /// \alg
        /// - Return ::msk.
        return msk;
    }

    /// \pdi
    /// - PDI Follows the same structure defined in ::cset function.
    template <typename T, bool has_cget>
    template<bool enabled>
    typename Enable_if<enabled, void>::type Tunarray<T, has_cget>::cget(Base::Lossy& str) const
    {
        /// \alg
        /// <ul>
        /// <li> Serialize ::sz using Atunarray::cget_size for ::msk.
        /// <li> Initialize ::i as zero.
        /// <li> Decrease ::sz until reaching zero. While doing that action, perform:
        Uint16 sz = msk.cget_size(str);
        Uint16 i=0;
        while(sz-->0)
        {
            /// <ul>
            /// <li> Serialize ::i using Atunarray::cget_element.
            /// <li> Convert the pointer to each element to itself and serialize them.
            /// <li> Increase i by one.
            /// </ul>
            msk.cget_element(i, str); // puts i on next element enabled
            ptr_cast(Array<T>::v[i])->cget(str);
            ++i;
        }
        /// </ul>
    }

    template <typename T, bool has_cget>
    template <typename T2, Uint16 sz>
    inline Tunarray<T, has_cget>::Tunarray(const Arraymsk<T2, sz>& a) :
        Array<T>(const_cast<Arraymsk<T2, sz>&>(a).data.to_mblock()),
        msk(const_cast<Arraymsk<T2, sz>&>(a).msk)
    {
        /// \alg
        /// <ul>
        /// <li> Construct the base class ::Array by passing to it the retrieved value by Tnarray::to_mblock for
        /// ::data in given parameter "a".
        /// <li> ::msk is initialized with ::msk for given parameter "a".
        /// </ul>
        // Constructor for constant Tunarray, no modification to Arraymsk reference passed
        // should be done in objects built with this constructor.
        // no call to clear done for this reason.
        // Only Ktun should use this constructor, it ensures that only const methods can be called.
    }

    template <typename T, bool has_cget>
    inline Optional<Uint16> Tunarray<T, has_cget>::find_first_disabled() const
    {
        /// \alg
        /// - Return retrieved value by Atunarray::find_first_disabled for ::msk.
        return msk.find_first_disabled();
    }
}
#endif
