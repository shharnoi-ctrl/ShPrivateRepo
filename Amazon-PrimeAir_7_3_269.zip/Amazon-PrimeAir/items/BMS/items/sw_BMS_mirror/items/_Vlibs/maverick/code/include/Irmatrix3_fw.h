#ifndef IRMATRIX3_FW_H__
#define IRMATRIX3_FW_H__

namespace Maverick
{
    class Irmatrix3;
}

#endif
