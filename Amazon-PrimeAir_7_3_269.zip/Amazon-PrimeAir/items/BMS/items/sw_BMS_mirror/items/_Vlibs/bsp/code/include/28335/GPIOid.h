#ifndef GPIOID_28335_H_
#define GPIOID_28335_H_

#include <Entypes.h>

namespace Dsp28335_ent
{
    enum GPIOid
    {
        gpio_000 =   0,     // GPIO1 Arbiter
        gpio_001 =   1,     // GPIO7 Arbiter / ECAP6
        gpio_002 =   2,     // GPIO2 Arbiter
        gpio_003 =   3,     // GPIO8 Arbiter / ECAP5
        gpio_004 =   4,     // GPIO3 Arbiter
        gpio_005 =   5,     // ECAP1
        gpio_006 =   6,     // GPIO4 Arbiter
        gpio_007 =   7,     // ECAP2 / VMC Stepper driver pulse
        gpio_008 =   8,     // GPIO5 Arbiter
        gpio_009 =   9,     // ECAP3
        gpio_010 =  10,     // GPIO6 Arbiter
        gpio_011 =  11,     // ECAP4 / VMC Stepper driver direction
        gpio_012 =  12,     // CANB TX Arbiter
        gpio_013 =  13,     // CANB RX Arbiter
        gpio_014 =  14,     // SCIB TX (RS232)
        gpio_015 =  15,     // SCIB RX (RS232)
        gpio_016 =  16,     // SPIA SIMO (SD) / ARINC ARX4_P
        gpio_017 =  17,     // SPIA MOSI (SD) / ARINC ARX3_P
        gpio_018 =  18,     // CANA RX Arbiter
        gpio_019 =  19,     // CANA TX Arbiter
        gpio_020 =  20,     // ARINC SI
        gpio_021 =  21,     // ARINC SO
        gpio_022 =  22,     // ARINC SCK
        gpio_023 =  23,     // ARINC CS!
        gpio_024 =  24,     // WD V1
        gpio_025 =  25,     // WD_EXT (buffered)
        gpio_026 =  26,     // WD V2
        gpio_027 =  27,     // WD V3
        gpio_028 =  28,     // ARINC ARX1_P
        // ...
        //gpio_029 =  29,   // Reserved for EMIF_A19
        gpio_030 =  30,     // Reserved for EMIF_A18 / CANA RX
        gpio_031 =  31,     // Reserved for EMIF_A17 / CANA TX
        gpio_032 =  32,     // I2CA SDA
        gpio_033 =  33,     // I2CA SCL
        gpio_034 =  34,     // ECAP1
        gpio_035 =  35,     // SCIA TX (RS232)
        gpio_036 =  36,     // SCIA RX (RS232)
        gpio_037 =  37,     // Reserved for EMIF CS / ECAP2
        //gpio_038 =  38,   // Reserved for EMIF WE
        gpio_039 =  39,   // Reserved for EMIF_A16, drv_dc_cal in VMC
        gpio_040 =  40,   // Reserved for EMIF_A00, drv_en_gate in VMC
        gpio_041 =  41,   // Reserved for EMIF_A01, drv_fault in VMC
        gpio_042 =  42,   // Reserved for EMIF_A02  drv_gain in VMC
        //gpio_043 =  43,   // Reserved for EMIF_A03
        //gpio_044 =  44,   // Reserved for EMIF_A04
        //gpio_045 =  45,   // Reserved for EMIF_A05
        //gpio_046 =  46,   // Reserved for EMIF_A06
        //gpio_047 =  47,   // Reserved for EMIF_A07
        // ...
        gpio_048 =  48,     // ECAP6
        gpio_049 =  49,     // EXT detect
        gpio_050 =  50,     // VMC Stepper driver disable
        // ...
        gpio_051 =  51,     // M2 arb (B mux output)
        gpio_052 =  52,     // M1 arb (A mux output)
        gpio_053 =  53,     // LED green / ARINC ARX3_N
        gpio_054 =  54,     // ARINC MR
        gpio_055 =  55,
        gpio_056 =  56,     // SPIA SCK (SD)
        gpio_057 =  57,     // SPIA CS (SD)
        gpio_058 =  58,     // ARINC ARX3_N
        gpio_059 =  59,     // LED red / ARINC ARX2_N
        gpio_060 =  60,     // ARINC ARX2_P
        gpio_061 =  61,     // ARINC ARX1_N
        gpio_062 =  62,     // SCI C RX
        gpio_063 =  63,     // SCI C TX
        //gpio_064 =  64,   // Reserved for EMIF1_D15
        //gpio_065 =  65,   // Reserved for EMIF1_D14
        //gpio_066 =  66,   // Reserved for EMIF1_D13
        //gpio_067 =  67,   // Reserved for EMIF1_D12
        //gpio_068 =  68,   // Reserved for EMIF1_D11
        //gpio_069 =  69,   // Reserved for EMIF1_D10
        //gpio_070 =  70,   // Reserved for EMIF1_D09
        //gpio_071 =  71,   // Reserved for EMIF1_D08
        //gpio_072 =  72,   // Reserved for EMIF1_D07
        //gpio_073 =  73,   // Reserved for EMIF1_D06
        //gpio_074 =  74,   // Reserved for EMIF1_D05
        gpio_075 =  75,   // Reserved for EMIF1_D04 / GPIO
        //gpio_076 =  76,   // Reserved for EMIF1_D03
        gpio_077 =  77,   // Reserved for EMIF1_D02 / GPIO
        //gpio_078 =  78,   // Reserved for EMIF1_D01
        gpio_079 =  79,   // Reserved for EMIF1_D00 / GPIO
        //gpio_080 =  80,   // Reserved for EMIF1_A08
        //gpio_081 =  81,   // Reserved for EMIF1_A09
        //gpio_082 =  82,   // Reserved for EMIF1_A10
        //gpio_083 =  83,   // Reserved for EMIF1_A11
        //gpio_084 =  84,   // Reserved for EMIF1_A12
        //gpio_085 =  85,   // Reserved for EMIF1_A13
        //gpio_086 =  86,   // Reserved for EMIF1_A14
        //gpio_087 =  87    // Reserved for EMIF1_A15

    };
    static const Uint16 gpio_all = 88;
}
#endif

