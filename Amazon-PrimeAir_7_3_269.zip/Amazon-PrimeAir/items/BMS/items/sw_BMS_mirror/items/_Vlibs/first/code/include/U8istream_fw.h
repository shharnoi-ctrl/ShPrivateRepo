#ifndef U8ISTREAM_FW_H_
#define U8ISTREAM_FW_H_

namespace Base
{
    class U8istream;
}
#endif
