#ifndef HREGISTER_H_
#define HREGISTER_H_

#include <Ttraits.h>
#include <Vtraits.h>

namespace Base
{
    template<typename T>
    /// Hardware Register Manager.
    /// The Base namespace shall provide a structure to manage read-only mutators.
    struct Mutator_rdo
    {
        /// Mutator Register Only Reader.
        /// \wi{20810}
        /// Mutator_rdo structure shall provide the capability to read a value from a specific field
        /// within a register.
        /// \param[in] reg Register to read from.
        /// \param[in] offset Offset of the field within the register.
        /// \param[in] Mask Bitmask representing the field within the register.
        /// \return Value read from the specified field.
        static T read(const volatile T& reg,
                      Uint16 offset,
                      T Mask);
    private:
        Mutator_rdo();                                   ///< = delete.
        Mutator_rdo(const Mutator_rdo& orig);            ///< = delete.
        Mutator_rdo& operator=(const Mutator_rdo& orig); ///< = delete.
    };

    template<typename T>
    inline T Mutator_rdo<T>::read(const volatile T& reg,
                                  Uint16 offset,
                                  T Mask)
    {
        /// \alg
        /// - Return the bitwise right shift operation by "offset" position for the result of the bitwise AND operation
        /// between "reg" and "Mask".
        return (reg & Mask) >> offset;
    }


    template<typename T>
    /// The Base namespace shall provide a structure to manage write-only mutators.
    struct Mutator_wro
    {
        /// Mutator Register Only Writer.
        /// \wi{20811}
        /// Mutator_wro structure shall provide the capability to write a value to a specific field
        /// within a register.
        /// \param[out] reg Register to write to.
        /// \param[in] offset Offset of the field within the register.
        /// \param[in] Mask Bitmask representing the field within the register.
        /// \param[in] value Value to write to the field.
        static void write(volatile T& reg,
                          Uint16 offset,
                          T Mask,
                          T value);
    private:
        Mutator_wro();                                   ///< = delete.
        Mutator_wro(const Mutator_wro& orig);            ///< = delete.
        Mutator_wro& operator=(const Mutator_wro& orig); ///< = delete.
    };

    template<typename T>
    inline void Mutator_wro<T>::write(volatile T& reg,
                                      Uint16 offset,
                                      T Mask,
                                      T value)
    {
        /// \alg
        /// - Update "reg" as the the bitwise left shift operation by "offset" position for "value",
        /// then performs the bitwise AND operation between the result of the bitwise operation and "Mask".
        reg = ((value << offset) & Mask);
    }


    template<typename T>
    /// The Base namespace shall provide a structure that inherits from Mutator_rdo to manage a read-write mutator.
    struct Mutator_rw : Mutator_rdo<T>
    {
    public:
        /// Mutator Register Writer.
        /// \wi{20853}
        /// Mutator_rw structure shall provide the capability to write a value to a specific field
        /// within a register.
        /// \param[in,out] reg Register to write to.
        /// \param[in] offset Offset of the field within the register.
        /// \param[in] Mask Bitmask representing the field within the register.
        /// \param[in] value Value to write to the field.
        static void write(volatile T& reg,
                          Uint16 offset,
                          T Mask,
                          T value);
    private:
        Mutator_rw();                                   ///< = delete.
        Mutator_rw(const Mutator_rw& orig);             ///< = delete.
        Mutator_rw& operator=(const Mutator_rw& orig);  ///< = delete.
    };

    template<typename T>
    inline void Mutator_rw<T>::write(volatile T& reg,
                                     Uint16 offset,
                                     T Mask,
                                     T value)
    {
        /// \alg
        /// - Update "reg" by \f$ reg = (reg \& \sim Mask) | ((value << offset) \& Mask) \f$.
        reg = (reg & ~Mask) | ((value << offset) & Mask);
    }


    template <typename T, template<typename> class Mutator, Uint32 addr, Uint16 offset, Uint16 width>
    /// The Base namespace shall provide a structure to manage hardware register.
    struct Hregister
    {
    public:
        /// Hardware Register Structure Default Constructor.
        /// \wi{20854}
        /// Hregister structure shall build itself upon construction.
        Hregister();
        /// Hardware Register Reader.
        /// \wi{20855}
        /// Hregister structure shall provide the capability to read the value form the hardware register.
        /// \return Value read from the register.
        T read() const; //PRQA S 4212 #static
        /// Hardware Register Writer.
        /// \wi{20856}
        /// Hregister structure shall provide the capability to write a value to the hardware register.
        /// \param[in] value Value to write to the field.
        void write(T value); //PRQA S 4212 #static

        template <Uint16 sub_offset, Uint16 sub_width>
        /// Hregister structure shall provide a structure to define a sub-register with specific properties.
        struct Subreg : Base::type_is<Hregister<T, Mutator, addr, offset+sub_offset, sub_width> >
        {
        };
    private:
        Hregister(const Hregister& orig);            ///< = delete.
        Hregister& operator=(const Hregister& orig); ///< = delete.
    };


    template <typename T, template<typename> class Mutator, Uint32 addr, Uint16 offset, Uint16 width>
    inline Hregister<T,Mutator,addr,offset,width>::Hregister()
    {
    }

    template <typename T, template<typename> class Mutator, Uint32 addr, Uint16 offset, Uint16 width>
    inline T Hregister<T,Mutator,addr,offset,width>::read() const //PRQA S 4212 #static
    {
        /// \alg
        /// - Return retrieved value by Mutator::read with parameters: the value in reinterpret_cast of "addr" 
        /// to pointer to T, "offset" and Base::Mask::value.
        return Mutator<T>::read(*reinterpret_cast<volatile T*>(addr), offset,Base::Mask<T, offset, width>::value);
    }

    template <typename T, template<typename> class Mutator, Uint32 addr, Uint16 offset, Uint16 width>
    inline void Hregister<T,Mutator,addr,offset,width>::write(T value) //PRQA S 4212 #static
    {
        /// \alg
        /// - Call Mutator::write with parameters: the value in reinterpret_cast of "addr" to pointer to T, "offset",
        /// Base::Mask::value and given "value".
        Mutator<T>::write(*reinterpret_cast<volatile T*>(addr),
                          offset,
                          Base::Mask<T,offset, width>::value,
                          value);
    }
}
#endif
