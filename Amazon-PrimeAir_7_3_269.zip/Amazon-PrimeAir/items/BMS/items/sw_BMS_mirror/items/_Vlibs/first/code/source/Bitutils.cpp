#include <Bitutils.h>
#include <Assertions.h>

namespace Base
{
    namespace Bitutils
    {
        void test()
        {
            Base::Assertions::Compile_time< size_bytes_t<  int8>::value == 1> ();
            Base::Assertions::Compile_time< size_bytes_t< Uint8>::value == 1> ();
            Base::Assertions::Compile_time< size_bytes_t< int16>::value == 2> ();
            Base::Assertions::Compile_time< size_bytes_t<Uint16>::value == 2> ();
            Base::Assertions::Compile_time< size_bytes_t< int32>::value == 4> ();
            Base::Assertions::Compile_time< size_bytes_t<Uint32>::value == 4> ();
            Base::Assertions::Compile_time< size_bytes_t< int64>::value == 8> ();
            Base::Assertions::Compile_time< size_bytes_t<Uint64>::value == 8> ();
            Base::Assertions::Compile_time< size_bytes_t<  Real>::value == 4> ();
            Base::Assertions::Compile_time< size_bytes_t<Real64>::value == 8> ();
        }

        extern const Uint16 mask16[Ku16::u17]=
        {
            0x0000,0x0001,0x0003,0x0007,
            0x000F,0x001F,0x003F,0x007F,
            0x00FF,0x01FF,0x03FF,0x07FF,
            0x0FFF,0x1FFF,0x3FFF,0x7FFF,
            0xFFFF
        };

        static const Uint16 reflect4lookup[] = {0x0,0x8,0x4,0xc,0x2,0xa,0x6,0xe,0x1,0x9,0x5,0xd,0x3,0xb,0x7,0xf};

        Uint16 reflect8(Uint16 word)
        {
            return (reflect4lookup[word & Ku16::u0xF] << Ku16::u4) | reflect4lookup[(word >> Ku16::u4) & Ku16::u0xF];
        }

        Uint16 reflect16(Uint16 word)
        {
            return (reflect8(word) << Ku16::u8) | reflect8(word >> Ku16::u8);
        }

        Uint32 reflect32(Uint32 word)
        {
            return (static_cast<Uint32>(reflect16(static_cast<Uint16>(word))) << Ku16::u16) |
                    (static_cast<Uint32>(reflect16(static_cast<Uint16>(word >> Ku16::u16))));
        }

        Uint32 reflectn(Uint32 word, Uint16 n)
        {
            return reflect32(word) >> (Ku16::u32 - n);
        }

        void get_lsbset_idx(Uint32 value, Uint16& idx)
        {
            /// \alg
            /// <ul>
            /// <li> IF value & 0xFFFF.
            if(value&Ku32::u0xFFFF)
            {
                /// <ul>
                /// <li> Call ::get_lsbset_idx casting value to Uint16.
                get_lsbset_idx((static_cast<Uint16>(value)),idx);
            }   /// </ul>
            /// <li> ELSE.
            else
            {
                /// <ul>
                /// <li> Call ::get_lsbset_idx shifting value 16 bits to the right and casting to Uin16.
                /// <li> Increment index by 16.
                get_lsbset_idx((static_cast<Uint16>(value>>Ku16::u16)),idx);
                idx+=Ku16::u16;
                /// </ul>
            }
            /// </ul>
        }

        void set_uint16(Uint16 value, Uint16 pos, Uint64& ret)
        {
            Uint16 displ = pos * Sizeof_bits<Uint16>::value;
            Uint64 aux = static_cast<Uint64>(1U) & (static_cast<Uint64>(Ku16::u0) << displ);
            ret = (static_cast<Uint64>(value) << displ) | aux;
        }

        void get_lsbset_idx(Uint16 value, Uint16& idx)
        {
            static const Uint16 mskbases[] = {0x00FF, 0x0F0F, 0x3333, 0x5555};
            static const Uint16 mskbases_sz = (sizeof(mskbases))/(sizeof(mskbases[0]));
            static const Uint16* const mskbases_last = &mskbases[mskbases_sz-1];

            Uint16 i=1<<(mskbases_sz-1);
            idx=0;
            for(const Uint16* mbi = mskbases; mbi<=mskbases_last;++mbi)
            {
                Uint16 mvalue = value & (*mbi); // masked value, auxiliar
                if(mvalue)
                {
                    value = mvalue;
                }
                else
                {
                    value &= ~(*mbi);
                    idx+=i;
                }
                i>>=1U;
            }
        }
    }
}
