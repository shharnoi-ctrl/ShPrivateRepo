#include <PDIcheck.h>

namespace Base
{
    namespace
    {
        const Uint16 ctxt_stt = Ku16::u0xFFFEU;     // Mark for the start of a sequence of errors characterized by a context
        const Uint16 ctxt_end = Ku16::u0xFFFF;      // Mark for the end of a sequence of errors characterized by a context
    }

    const Bsp::Hbvar PDIcheck::pdimode(kbit_is_wr_reset_allowed);
    Bsp::Huvar PDIcheck::pdicode(vu_pdi_source);
    Bsp::Huvar PDIcheck::opecode(vu_operr_source);
    Bsp::Hbvar PDIcheck::pdierror(kbit_pdi);
    Bsp::Hbvar PDIcheck::op_error(kbit_op_err_ok);
    Fifo_err_wr* PDIcheck::ff_wr = 0;

    void PDIcheck::set_fifo(Fifo_err_wr* ff_wr0)
    {
        ff_wr = ff_wr0;
    }

    PDIcheck::Opflush::Opflush() :
        tout(1.0F),
        last(err_ok)
    {
    }

    void PDIcheck::Opflush::step()
    {
        /// \alg
        const Uint16 current = opecode.get();
        if (current != last)                    /// When current value of system is different than the last one, change its value and restart the timeout,
        {
            tout.start();
            last = current;
        }
        else                                    /// Otherwise, wait for the timeout to expired in order to set the system variable value to err_ok .
        {
            if (tout.expired())
            {
                opecode.set(err_ok);
                op_error.set(true);
            }
        }
    }

    void PDIcheck::init()
    {
        pdicode.set(err_ok);
        opecode.set(err_ok);
        pdierror.set(true);
        op_error.set(true);
    }

    bool PDIcheck::commit0(const Error& err)
    {
        /// \alg
        const bool ret = !err.is_ok();
        if(ret)                                         /// <li>If provided error list have elements:<ul>
        {
            const Uint16 last_error = err.get_error();
            if (pdimode.get())                          /// <li>If occurred in PDI mode,
            {
                if (pdierror.get())                     /// and if kbit_pdi is true:<ul>
                {
                    pdierror.set(false);                /// <li> Set kbit_pdi to false, </li>
                    op_error.set(false);                /// <li> Set kbit_op_err_ok to false. </li>
                    pdicode.set(last_error);            /// <li> Set both vu_pdi_source
                    opecode.set(last_error);            /// and vu_operr_source to last error from list. </li>
                }                                       /// </ul> </li>
            }
            else                                        /// <li> Otherwise,
            {
                if (opecode.get() == err_ok)            /// and if vu_operr_source is equals to err_ok value (means no error),
                {
                    opecode.set(last_error);            /// set vu_operr_source to last error from list. </li> </ul>
                    op_error.set(false);                /// <li> Set kbit_op_err_ok to true. </li>
                }
            }
        }
        return ret;                                     /// <li> Then return true if provided list of error is not empty.
    }

    void PDIcheck::commit(Errorsrc err_id)
    {
        /// \alg
        if(err_id != err_ok)                            /// If provided error identifier is different than err_ok:
        {
            Error error;
            error.failed(err_id);
            commit(error);                              /// <li> If PDI mode is enabled, and kbit_pdi is true, publish the last error onto vu_pdi_source system variable, </li>
                                                        /// <li> If PDI mode is disabled, and vu_operr_source value is err_ok, publish the last error onto vu_operr_source, </li>
                                                        /// <li> Then, commit the entire array onto the FIFO, and commit a special word (0xFFFF) to signal a sequence of errors.</li>
        }
    }

    void PDIcheck::append0(const Error& err)
    {
        const Error::Error_l& errors = err.get_errors();
        const Uint16 sz = errors.size();
        for(Uint16 i=0; i<sz; ++i)
        {
            ff_wr->write(errors[i]);
        }
    }

    /// </ul>
    void PDIcheck::commit(const Error& err)
    {
        /// \alg
        if(commit0(err))            /// When the provided error list contains at least one element, process the following actions: <ul>
        {                           /// <li> If PDI mode is enabled, and kbit_pdi is true, publish the last error onto vu_pdi_source system variable,
                                    /// <li> If PDI mode is disabled, and vu_operr_source value is err_ok, publish the last error onto vu_operr_source,
            append0(err);           /// <li> Then, commit the entire array onto the FIFO, and commit a special word (0xFFFF) to signal a sequence of errors.
            ff_wr->commit();
        }
    }

    void PDIcheck::commit(Uint16 ctxt, const Error& err)
    {
        if(commit0(err))                    /// When the provided error list contains at least one element, process the following actions: <ul>
        {                                   /// <li> If PDI mode is enabled, and kbit_pdi is true, publish the last error onto vu_pdi_source system variable,
                                            /// <li> If PDI mode is disabled, and vu_operr_source value is err_ok, publish the last error onto vu_operr_source,
            ff_wr->write(ctxt_stt);         /// <li> Then, append:<ul><li>The context start mark (0xFFFE),
            append0(err);                   /// <li> The array of errors,
            ff_wr->write(ctxt);             /// <li> The provided context identifier,
            ff_wr->write(ctxt_end);         /// <li> The context end mark (0xFFFF). </ul></ul>
            ff_wr->commit();
        }
    }

    bool PDIcheck::wr_available()
    {
        return ff_wr->wr_available();
    }
}
