#ifndef ITPORT_H_
#define ITPORT_H_

#include <Itproducer.h>
#include <Itconsumer.h>

namespace Base
{
    /// TRD and TWR are the types of reader and writer respectively.
    template <typename TRD, typename TWR = TRD>
    class Itport : public Itproducer<TRD>, public Itconsumer<TWR>
    {
    public:

    protected:
        Itport();
    private:
        Itport(const Itport& orig); ///< = delete
        Itport& operator=(const Itport& orig); ///< = delete
    };

    template <typename TRD, typename TWR>
    Itport<TRD,TWR>::Itport()
    {
    }

    typedef Itport<Uint8, Uint8> Itport_u8;
    typedef Itport<Uint16, Uint16> Itport_u16;
}
#endif

