#ifndef CHRONO_H__
#define CHRONO_H__

#include <Entypes.h>
#include <Htime.h>

namespace Base
{
    /// \brief Time counter/chrono.
    class Chrono
    {
    public:
        /// Chrono Default Constructor.
        /// \wi{4915}
        /// Chrono class shall initialize itself upon construction and initialize it's internal members.
        Chrono();

        /// Chrono Constructor.
        /// \wi{5658}
        /// Chrono class shall initialize itself upon construction with the required parameter.
        /// \param[in] start    Flag to automatically start the chrono.
        explicit Chrono(bool start);

        /// Chrono Tic.
        /// \wi{4917}
        /// Chrono class shall provide the capability to reset chrono to zero.
        void tic();

        /// Chrono Tic.
        /// \wi{16613}
        /// Chrono class shall provide the capability to reset chrono with a given margin.
        /// \param[in] dt   Margin given to chrono.
        void tic(Real dt);

        /// Chrono Get Tic Time.
        /// \wi{4918}
        /// Chrono class shall provide the capability to get the time when ::tic was called.
        /// \return Time in seconds when ::tic was called if ::on is true.
        Real get_tic_time() const;

        /// Chrono Toc.
        /// \wi{4919}
        /// Chrono class shall provide the capability to get chrono time.
        /// \return Time in seconds.
        Real toc()const;

        /// Chrono Toc Ttime.
        /// \wi{19228}
        /// Chrono class shall provide the capability to get chrono time.
        /// \return Time in a Ttime type.
        Ttime toc_ttime()const;

        /// Chrono Cancel.
        /// \wi{4920}
        /// Chrono class shall provide the capability to stop the chronometer.
        void cancel();

        /// Chrono Ongoing.
        /// \wi{4921}
        /// Chrono class shall provide the capability to provide its state.
        /// \return True if the chrono is ongoing ::on.
        bool ongoing()const;

        /// Chrono Add.
        /// \wi{4922}
        /// Chrono class shall provide the capability to add delayed time to the elapsed time.
        /// \param[in] dt   Time to add.
        void add(Real dt);

        /// Chrono Stepper.
        /// \wi{4916}
        /// Chrono class shall provide the capability to measure the delayed time from the system time.
        /// \param[out] dt   Delayed time.
        /// \param[out] dt_1 Inverse of delayed time.
        void step(Real& dt,Real& dt_1);

        /// Chrono Stepper.
        /// \wi{16614}
        /// Chrono class shall provide the capability to measure the delayed time from the system time.
        /// \return Delayed time.
        Real step();

        /// Chrono Stepper.
        /// \wi{16615}
        /// \param[out] dt   Delayed time.
        void step(Real& dt);

    private:
        bool on;    ///< Enabled flag
        Ttime tk0;  ///< Initialization/tic time

        Chrono(const Chrono& src); ///< = delete
        Chrono& operator=(const Chrono& orig); ///< = delete
    };


    inline Chrono::Chrono() : on(false)
    {
    }

    inline void Chrono::tic()
    {
        tk0=Bsp::Htime::get_time();
        on=true;
    }

    inline void Chrono::tic(Real dt)
    {
        tk0=Bsp::Htime::get_time() - Ttime(dt);
        on=true;
    }

    inline Real Chrono::get_tic_time() const
    {
        return on?tk0.get_seconds():-1;
    }

    inline Real Chrono::toc()const
    {
        return on?(Bsp::Htime::get_time()-tk0).get_seconds():-1;
    }

    inline Ttime Chrono::toc_ttime()const
    {
        return on?(Bsp::Htime::get_time()-tk0): Ttime(-1.0F);
    }

    inline void Chrono::cancel()
    {
        on=false;
    }

    inline bool Chrono::ongoing()const
    {
        return on;
    }

    inline void Chrono::add(Real dt)
    {
        if(on)
        {
            tk0 -= Ttime(dt);
        }
    }

    inline void Chrono::step(Real& dt)
    {
        dt = step();
    }

}
#endif
