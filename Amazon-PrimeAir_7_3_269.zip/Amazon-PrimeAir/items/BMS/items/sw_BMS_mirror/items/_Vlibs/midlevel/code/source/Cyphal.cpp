#include <Cyphal.h>
#include <U8ostream.h>

namespace Cyphal
{
    using namespace Base;
    CyCAN_id CyCAN_id::build_msg(Uint8 priority,
                                 Uint16 subject,
                                 Uint8 src_node)                                 
    {
        /// \alg
        /// <ul>
        /// <li> Initialize a constant value "rsv_value" to 3.
        /// <li> Initialize a CyCAN_id instance "res" to 0.
        /// <li> Assign given "priority" to CyCAN_msg::priority for CyCAN_id::msg in "res".
        /// <li> Assign False to CyCAN_msg::svc_msg for CyCAN_id::msg in "res".
        /// <li> Assign False to CyCAN_msg::anon for CyCAN_id::msg in "res".
        /// <li> Assign "rsv_value" to CyCAN_msg::res1 for CyCAN_id::msg in "res".
        /// <li> Assign given "subject" to CyCAN_msg::subject for CyCAN_id::msg in "res".
        /// <li> Assign given "src_node" to CyCAN_msg::src_node for CyCAN_id::msg in "res".
        /// <li> Return "res".
        /// </ul>
        static const Uint32 rsv_value = 0x3;    // Value for reserved field.
        CyCAN_id res = { 0 };
        res.msg.priority = priority;
        res.msg.svc_msg = false;        
        res.msg.anon = false;
        res.msg.res1 = rsv_value;        
        res.msg.subject = subject;
        res.msg.src_node = src_node;
        return res;
    }

    CyCAN_id CyCAN_id::build_svc(Uint8 priority, 
                                 bool is_response,
                                 Uint16 service,
                                 Uint8 dst_node,
                                 Uint8 src_node)
    {
        /// \alg
        /// <ul>
        /// <li> Initialize a CyCAN_id instance "res" to 0.
        /// <li> Assign given "priority" to CyCAN_svc::priority for CyCAN_id::svc in "res".
        /// <li> Assign True to CyCAN_svc::svc_msg for CyCAN_id::svc in "res".
        /// <li> Assign given "is_response" to CyCAN_svc::resp for CyCAN_id::svc in "res".
        /// <li> Assign given "service" to CyCAN_svc::service for CyCAN_id::svc in "res".
        /// <li> Assign given "dst_node" to CyCAN_svc::dst_node for CyCAN_id::svc in "res".
        /// <li> Assign given "src_node" to CyCAN_svc::src_node for CyCAN_id::svc in "res".
        /// <li> Return "res".
        /// </ul>
        CyCAN_id res = { 0 };
        res.svc.priority = priority;
        res.svc.svc_msg = true;
        res.svc.resp = is_response;
        res.svc.service = service;
        res.svc.dst_node = dst_node;
        res.svc.src_node = src_node;
        return res;
    }

    Tail_byte Tail_byte::build(Uint8 transfer_id,
                               bool start,
                               bool end,
                               bool toggle_b)
    {
        /// \alg
        /// <ul>
        /// <li> Initialize a Tail_byte instance "res" to 0.
        /// <li> Assign given "transfer_id" to Tail_byte::transfer_id in "res".
        /// <li> Assign given "start" to Tail_byte::sot in "res".
        /// <li> Assign given "end" to Tail_byte::eot in "res".
        /// <li> Assign given "toggle_b" to Tail_byte::toggle_bit in "res".
        /// <li> Return "res".
        /// </ul>
        Tail_byte res = { 0 };
        res.transfer_id = transfer_id;
        res.sot = start;
        res.eot = end;
        res.toggle_bit = toggle_b;
        return res;
    }
    
    Cyphal_stg_fields Cyphal_stg_fields::build(Uint8 priority,
                                               bool is_svc,
                                               bool anon_resp)
    {
        /// \alg
        /// <ul>
        /// <li> Initialize a Cyphal_stg_fields instance "res" to 0.
        /// <li> Assign given "priority" to Cyphal_stg_fields::priority in "res".
        /// <li> Assign given "is_svc" to Cyphal_stg_fields::svc_msg in "res".
        /// <li> Assign given "anon_resp" to Cyphal_stg_fields::anon_resp in "res".
        /// <li> Return "res".
        /// </ul>
        Cyphal_stg_fields res = { 0 };
        res.priority = priority;
        res.svc_msg = is_svc;
        res.anon_resp = anon_resp;
        return res;
    }

    Cyphal_msg::Cyphal_msg(Base::U8pkmblock buffer0) : buffer(buffer0)
    {
        /// \alg
        /// <ul>
        /// <li> Initialize ::buffer with given "buffer0"
        /// <li> Initialize a Base::U8ostream instance "os" with ::buffer.
        /// <li> Call Base::U8ostream::put_uint8 with ::start_byte for "os".
        /// <li> Call Base::U8ostream::put_uint32_le with 0 for "os".
        /// <li> Call Base::U8ostream::put_uint16_le with 0 for "os".
        /// </ul>
        Assertions::runtime(buffer.size() > (hdr_sz + Ku16::u8)); // at least 8 bytes for payload required.
        U8ostream os(buffer);
        os.put_uint8(start_byte);
        os.put_uint32_le(0);        // Id.
        os.put_uint16_le(0);        // Payload length.
    }

    void Cyphal_msg::copy(const Cyphal_msg& obj)
    {
        /// \alg 
        /// - Call Base::U8pkmblock::write for ::buffer with Cyphal_msg::buffer in given "obj".
        buffer.write(obj.buffer);
    }

    CyCAN_id Cyphal_msg::get_id() const
    {
        /// \alg
        /// <ul>
        /// <li> Initialize a Base::U8istream instance "is" with ::buffer.
        /// <li> Call Base::U8istream::seek with Offsets::offset_props for "is".
        /// <li> Initialize a constant CyCAN_id instance "res" with Base::U8istream::get_uint32_le for "is".
        /// <li> Return "res".
        /// </ul>
        U8istream is(buffer);
        is.seek(offset_props);
        const CyCAN_id res = { is.get_uint32_le() };
        return res;
    }

    Uint16 Cyphal_msg::get_len() const
    {
        /// \alg
        /// <ul>
        /// <li> Initialize a Base::U8istream instance "is" with ::buffer.
        /// <li> Call Base::U8istream::seek with Offsets::offset_len for "is".
        /// <li> Return retrieved value by Base::U8istream::get_uint16_le for "is".
        /// </ul>
        U8istream is(buffer);
        is.seek(offset_len);
        return is.get_uint16_le();
    }

    void Cyphal_msg::set_id(CyCAN_id id)
    {
        /// \alg
        /// <ul>
        /// <li> Initialize a Base::U8ostream instance "os" with ::buffer.
        /// <li> Call Base::U8ostream::seek with Cyphal_msg::Offsets::offset_props for "os".
        /// <li> Return retrieved value by Base::U8ostream::get_uint32_le for "os" with CyCAN_id::all for given "id".
        /// </ul>
        U8ostream os(buffer);
        os.seek(offset_props);
        os.put_uint32_le(id.all);
    }

    void Cyphal_msg::set_len(Uint16 len)
    {
        /// \alg
        /// <ul>
        /// <li> Initialize a Base::U8ostream instance "os" with ::buffer.
        /// <li> Call Base::U8ostream::seek with Offsets::offset_len for "os".
        /// <li> Return retrieved value by Base::U8ostream::get_uint16_le for "os" with given "len".
        /// </ul>
        U8ostream os(buffer);
        os.seek(offset_len);
        os.put_uint16_le(len);
    }
}
