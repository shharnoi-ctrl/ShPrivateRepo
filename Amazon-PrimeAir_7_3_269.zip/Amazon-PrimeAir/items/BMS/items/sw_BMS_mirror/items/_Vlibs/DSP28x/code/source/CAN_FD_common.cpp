#include <CAN_FD.h>
#include <CANdata.h>
#include <Ku8.h>

namespace Dsp28335_ent
{
    CAN_FD::DLC CAN_FD::len_to_dlc(Uint8 len0)
    {
        Uint8 len = (len0 <= Base::CANdata::length_max_fd) ? len0 : Base::CANdata::length_max_fd;
        static const Uint8 dlcs[14] = { dlc12, dlc16, dlc20, dlc24, dlc32, dlc32, dlc48, dlc48, dlc48, dlc48, dlc64, dlc64, dlc64, dlc64 };
        return static_cast<DLC>((len <= Ku8::u8) ? len : dlcs[(len - Ku8::u9)>>Ku8::u2]);
    }

    Uint8 CAN_FD::dlc_to_len(DLC dlc0)
    {
        static const Uint8 dlc_mask = 0x0F; // 4 bits
        static Uint8 dlc_lengths[16] = { 0, 1, 2, 3, 4, 5, 6, 7, 8,     // CAN 2.0 lengths
                                        12, 16, 20, 24, 32, 48, 64 };   // CAN-FD  lengths
        return dlc_lengths[dlc0 & dlc_mask];
    }
}
