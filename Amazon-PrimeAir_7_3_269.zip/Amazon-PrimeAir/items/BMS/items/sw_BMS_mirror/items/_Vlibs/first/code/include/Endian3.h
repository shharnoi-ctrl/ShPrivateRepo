#ifndef ENDIAN3_H_
#define ENDIAN3_H_

namespace Base
{
    class Iendian16;
    class Iendian32;
    class Iendian64;

    /// The ::Base library shall provide a class to select an endian configuration for both little and
    /// big endian for 16, 32, and 64 bits.
    class Endian3
    {
    public:
        const Iendian16& e16;           ///< Constant reference to a Iendian16 class.
        const Iendian32& e32;           ///< Constant reference to a Iendian32 class.
        const Iendian64& e64;           ///< Constant reference to a Iendian64 class.

        /// Endian3 Constructor with Given Parameters.
        /// \wi{5000}
        /// Endian3 class shall build itself upon construction with a given Iendian class references.
        /// \param[in] e16      Iendian16 class reference.
        /// \param[in] e32      Iendian32 class reference.
        /// \param[in] e64      Iendian64 class reference.
        Endian3(const Iendian16& e16,
                const Iendian32& e32,
                const Iendian64& e64);
        /// Constant Endianness Configuration (Little-Little-Little) Retriever.
        /// \wi{5001}
        /// Endian3 class shall be able to retrieve the following endianness configuration:
        /// - Little Endian for 16 bits.
        /// - Little Endian for 32 bits.
        /// - Little Endian for 64 bits.
        /// \return Endianness configuration instance.
        static const Endian3& get_elll_preset();
        /// Constant Endianness Configuration (Big-Big-Big) Retriever.
        /// \wi{5004}
        /// Endian3 class shall be able to retrieve the following endianness configuration:
        /// - Big Endian for 16 bits.
        /// - Big Endian for 32 bits.
        /// - Big Endian for 64 bits.
        /// \return Endianness configuration instance.
        static const Endian3& get_ebbb_preset();
    private:
        Endian3();                                  ///< = delete.
        Endian3(const Endian3& orig);               ///< = delete.
        Endian3& operator=(const Endian3& orig);    ///< = delete.
    };


    inline Endian3::Endian3(const Iendian16& endn16,
                            const Iendian32& endn32,
                            const Iendian64& endn64) :
                     e16(endn16),
                     e32(endn32),
                     e64(endn64)
    {
    }
}
#endif
