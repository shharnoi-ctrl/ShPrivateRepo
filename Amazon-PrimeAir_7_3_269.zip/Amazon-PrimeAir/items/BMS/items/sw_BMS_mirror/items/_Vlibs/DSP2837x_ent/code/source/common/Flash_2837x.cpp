//PRQA S 5051 EOF
//#Identifiers will be kept by default

#include <Flash.h>
#include <Asm.h>
#include <Ku16.h>
#include <Hregmap.h>


namespace Dsp28335_ent
{
    //PRQA S 2176 ++
    //#Unions used in HW register mapping in Texas Instruments' libraries.
    //PRQA S 2301 ++
    //#Bit-fields are needed.
    //PRQA S 5050 ++
    //#Identifiers will be kept by default
    //PRQA S 5051 ++
    //#Identifiers will be kept by default

    const Uint32 Flash::flash_start = 0x080000;

    // FLASH Individual Register Bit Definitions:

    struct FRDCNTL_BITS
    {
        Uint16 rsvd1:8;                     ///< 7:0 Reserved
        Uint16 RWAIT:4;                     ///< 11:8 Random Read Waitstate
        Uint16 rsvd2:4;                     ///< 15:12 Reserved
        Uint16 rsvd3:16;                    ///< 31:16 Reserved
    };

    union FRDCNTL_REG
    {
        Uint32  all;
        struct  FRDCNTL_BITS  bit;
    };

    struct FBAC_BITS
    {
        Uint16 VREADST:8;                   ///< 7:0 VREAD Setup Time Count
        Uint16 rsvd1:8;                     ///< 15:8 Reserved
        Uint16 rsvd2:16;                    ///< 31:16 Reserved
    };

    union FBAC_REG
    {
        Uint32  all;
        struct  FBAC_BITS  bit;
    };

    struct FBFALLBACK_BITS
    {
        Uint16 BNKPWR0:2;                   ///< 1:0 Bank Power Mode
        Uint16 rsvd1:14;                    ///< 15:2 Reserved
        Uint16 rsvd2:16;                    ///< 31:16 Reserved
    };

    union FBFALLBACK_REG
    {
        Uint32  all;
        struct  FBFALLBACK_BITS  bit;
    };

    struct FBPRDY_BITS
    {
        Uint16 BANKRDY:1;                   ///< 0 Flash Bank Active Power State
        Uint16 rsvd1:14;                    ///< 14:1 Reserved
        Uint16 PUMPRDY:1;                   ///< 15 Flash Pump Active Power Mode
        Uint16 rsvd2:16;                    ///< 31:16 Reserved
    };

    union FBPRDY_REG
    {
        Uint32  all;
        struct  FBPRDY_BITS  bit;
    };

    struct FPAC1_BITS
    {
        Uint16 PMPPWR:1;                    ///< 0 Charge Pump Fallback Power Mode
        Uint16 rsvd1:15;                    ///< 15:1 Reserved
        Uint16 PSLEEP:12;                   ///< 27:16 Pump Sleep Down Count
        Uint16 rsvd2:4;                     ///< 31:28 Reserved
    };

    union FPAC1_REG
    {
        Uint32  all;
        struct  FPAC1_BITS  bit;
    };

    struct FMSTAT_BITS
    {
        Uint16 rsvd1:1;                     ///< 0 Reserved
        Uint16 PSUSP:1;                     ///< 1 Program suspend operation
        Uint16 ESUSP:1;                     ///< 2 Erase suspend operation
        Uint16 VOLTSTAT:1;                  ///< 3 Flash Pump Power Status
        Uint16 CSTAT:1;                     ///< 4 Command Fail Status
        Uint16 INVDAT:1;                    ///< 5 Invalid Data
        Uint16 PGM:1;                       ///< 6 Program Operation Status
        Uint16 ERS:1;                       ///< 7 Erase Operation Status
        Uint16 BUSY:1;                      ///< 8 Busy Bit
        Uint16 rsvd2:1;                     ///< 9 Reserved
        Uint16 EV:1;                        ///< 10 Erase Verify Status
        Uint16 rsvd3:1;                     ///< 11 Reserved
        Uint16 PGV:1;                       ///< 12 Programming Verify Status
        Uint16 rsvd4:1;                     ///< 13 Reserved
        Uint16 rsvd5:1;                     ///< 14 Reserved
        Uint16 rsvd6:1;                     ///< 15 Reserved
        Uint16 rsvd7:1;                     ///< 16 Reserved
        Uint16 rsvd8:1;                     ///< 17 Reserved
        Uint16 rsvd9:14;                    ///< 31:18 Reserved
    };

    union FMSTAT_REG
    {
        Uint32  all;
        struct  FMSTAT_BITS  bit;
    };

    struct FRD_INTF_CTRL_BITS
    {
        Uint16 PREFETCH_EN:1;               ///< 0 Prefetch Enable
        Uint16 DATA_CACHE_EN:1;             ///< 1 Data Cache Enable
        Uint16 rsvd1:14;                    ///< 15:2 Reserved
        Uint16 rsvd2:16;                    ///< 31:16 Reserved
    };

    union FRD_INTF_CTRL_REG
    {
        Uint32  all;
        struct  FRD_INTF_CTRL_BITS  bit;
    };

    struct FLASH_CTRL_REGS
    {
        union   FRDCNTL_REG                      FRDCNTL;           ///< Flash Read Control Register
        Uint16                                   rsvd1[Ku16::u28];  ///< Reserved
        union   FBAC_REG                         FBAC;              ///< Flash Bank Access Control Register
        union   FBFALLBACK_REG                   FBFALLBACK;        ///< Flash Bank Fallback Power Register
        union   FBPRDY_REG                       FBPRDY;            ///< Flash Bank Pump Ready Register
        union   FPAC1_REG                        FPAC1;             ///< Flash Pump Access Control Register 1
        Uint16                                   rsvd2[Ku16::u4];   ///< Reserved
        union   FMSTAT_REG                       FMSTAT;            ///< Flash Module Status Register
        Uint16                                   rsvd3[Ku16::u340]; ///< Reserved
        union   FRD_INTF_CTRL_REG                FRD_INTF_CTRL;     ///< Flash Read Interface Control Register
    };

    struct ECC_ENABLE_BITS
    {
        Uint16 ENABLE:4;                    ///< 3:0 Enable ECC
        Uint16 rsvd1:12;                    ///< 15:4 Reserved
        Uint16 rsvd2:16;                    ///< 31:16 Reserved
    };

    union ECC_ENABLE_REG
    {
        Uint32  all;
        struct  ECC_ENABLE_BITS  bit;
    };

    struct ERR_STATUS_BITS
    {
        Uint16 FAIL_0_L:1;                  ///< 0 Lower 64bits Single Bit Error Corrected Value 0
        Uint16 FAIL_1_L:1;                  ///< 1 Lower 64bits Single Bit Error Corrected Value 1
        Uint16 UNC_ERR_L:1;                 ///< 2 Lower 64 bits Uncorrectable error occurred
        Uint16 rsvd1:13;                    ///< 15:3 Reserved
        Uint16 FAIL_0_H:1;                  ///< 16 Upper 64bits Single Bit Error Corrected Value 0
        Uint16 FAIL_1_H:1;                  ///< 17 Upper 64bits Single Bit Error Corrected Value 1
        Uint16 UNC_ERR_H:1;                 ///< 18 Upper 64 bits Uncorrectable error occurred
        Uint16 rsvd2:13;                    ///< 31:19 Reserved
    };

    union ERR_STATUS_REG
    {
        Uint32  all;
        struct  ERR_STATUS_BITS  bit;
    };

    struct ERR_POS_BITS
    {
        Uint16 ERR_POS_L:6;                 ///< 5:0 Bit Position of Single bit Error in lower 64 bits
        Uint16 rsvd1:2;                     ///< 7:6 Reserved
        Uint16 ERR_TYPE_L:1;                ///< 8 Error Type in lower 64 bits
        Uint16 rsvd2:7;                     ///< 15:9 Reserved
        Uint16 ERR_POS_H:6;                 ///< 21:16 Bit Position of Single bit Error in upper 64 bits
        Uint16 rsvd3:2;                     ///< 23:22 Reserved
        Uint16 ERR_TYPE_H:1;                ///< 24 Error Type in upper 64 bits
        Uint16 rsvd4:7;                     ///< 31:25 Reserved
    };

    union ERR_POS_REG
    {
        Uint32  all;
        struct  ERR_POS_BITS  bit;
    };

    struct ERR_STATUS_CLR_BITS
    {
        Uint16 FAIL_0_L_CLR:1;              ///< 0 Lower 64bits Single Bit Error Corrected Value 0 Clear
        Uint16 FAIL_1_L_CLR:1;              ///< 1 Lower 64bits Single Bit Error Corrected Value 1 Clear
        Uint16 UNC_ERR_L_CLR:1;             ///< 2 Lower 64 bits Uncorrectable error occurred Clear
        Uint16 rsvd1:13;                    ///< 15:3 Reserved
        Uint16 FAIL_0_H_CLR:1;              ///< 16 Upper 64bits Single Bit Error Corrected Value 0 Clear
        Uint16 FAIL_1_H_CLR:1;              ///< 17 Upper 64bits Single Bit Error Corrected Value 1 Clear
        Uint16 UNC_ERR_H_CLR:1;             ///< 18 Upper 64 bits Uncorrectable error occurred Clear
        Uint16 rsvd2:13;                    ///< 31:19 Reserved
    };

    union ERR_STATUS_CLR_REG
    {
        Uint32  all;
        struct  ERR_STATUS_CLR_BITS  bit;
    };

    struct ERR_CNT_BITS
    {
        Uint16 ERR_CNT:16;                  ///< 15:0 Error counter
        Uint16 rsvd1:16;                    ///< 31:16 Reserved
    };

    union ERR_CNT_REG
    {
        Uint32  all;
        struct  ERR_CNT_BITS  bit;
    };

    struct ERR_THRESHOLD_BITS
    {
        Uint16 ERR_THRESHOLD:16;            ///< 15:0 Error Threshold
        Uint16 rsvd1:16;                    ///< 31:16 Reserved
    };

    union ERR_THRESHOLD_REG
    {
        Uint32  all;
        struct  ERR_THRESHOLD_BITS  bit;
    };

    struct ERR_INTFLG_BITS
    {
        Uint16 SINGLE_ERR_INTFLG:1;         ///< 0 Single Error Interrupt Flag
        Uint16 UNC_ERR_INTFLG:1;            ///< 1 Uncorrectable Interrupt Flag
        Uint16 rsvd1:14;                    ///< 15:2 Reserved
        Uint16 rsvd2:16;                    ///< 31:16 Reserved
    };

    union ERR_INTFLG_REG
    {
        Uint32  all;
        struct  ERR_INTFLG_BITS  bit;
    };

    struct ERR_INTCLR_BITS
    {
        Uint16 SINGLE_ERR_INTCLR:1;         ///< 0 Single Error Interrupt Flag Clear
        Uint16 UNC_ERR_INTCLR:1;            ///< 1 Uncorrectable Interrupt Flag Clear
        Uint16 rsvd1:14;                    ///< 15:2 Reserved
        Uint16 rsvd2:16;                    ///< 31:16 Reserved
    };

    union ERR_INTCLR_REG
    {
        Uint32  all;
        struct  ERR_INTCLR_BITS  bit;
    };

    struct FADDR_TEST_BITS
    {
        Uint16 rsvd1:3;                     ///< 2:0 Reserved
        Uint16 ADDRL:13;                    ///< 15:3 ECC Address Low
        Uint16 ADDRH:6;                     ///< 21:16 ECC Address High
        Uint16 rsvd2:10;                    ///< 31:22 Reserved
    };

    union FADDR_TEST_REG
    {
        Uint32  all;
        struct  FADDR_TEST_BITS  bit;
    };

    struct FECC_TEST_BITS
    {
        Uint16 ECC:8;                       ///< 7:0 ECC Control Bits
        Uint16 rsvd1:8;                     ///< 15:8 Reserved
        Uint16 rsvd2:16;                    ///< 31:16 Reserved
    };

    union FECC_TEST_REG
    {
        Uint32  all;
        struct  FECC_TEST_BITS  bit;
    };

    struct FECC_CTRL_BITS
    {
        Uint16 ECC_TEST_EN:1;               ///< 0 Enable ECC Test Logic
        Uint16 ECC_SELECT:1;                ///< 1 ECC Bit Select
        Uint16 DO_ECC_CALC:1;               ///< 2 Enable ECC Calculation
        Uint16 rsvd1:13;                    ///< 15:3 Reserved
        Uint16 rsvd2:16;                    ///< 31:16 Reserved
    };

    union FECC_CTRL_REG
    {
        Uint32  all;
        struct  FECC_CTRL_BITS  bit;
    };

    struct FECC_STATUS_BITS
    {
        Uint16 SINGLE_ERR:1;                ///< 0 Test Result is Single Bit Error
        Uint16 UNC_ERR:1;                   ///< 1 Test Result is Uncorrectable Error
        Uint16 DATA_ERR_POS:6;              ///< 7:2 Holds Bit Position of Error
        Uint16 ERR_TYPE:1;                  ///< 8 Holds Bit Position of 8 Check Bits of Error
        Uint16 rsvd1:7;                     ///< 15:9 Reserved
        Uint16 rsvd2:16;                    ///< 31:16 Reserved
    };

    union FECC_STATUS_REG
    {
        Uint32  all;
        struct  FECC_STATUS_BITS  bit;
    };

    struct FLASH_ECC_REGS
    {
        union   ECC_ENABLE_REG                   ECC_ENABLE;                   // ECC Enable
        Uint32                                   SINGLE_ERR_ADDR_LOW;          // Single Error Address Low
        Uint32                                   SINGLE_ERR_ADDR_HIGH;         // Single Error Address High
        Uint32                                   UNC_ERR_ADDR_LOW;             // Uncorrectable Error Address Low
        Uint32                                   UNC_ERR_ADDR_HIGH;            // Uncorrectable Error Address High
        union   ERR_STATUS_REG                   ERR_STATUS;                   // Error Status
        union   ERR_POS_REG                      ERR_POS;                      // Error Position
        union   ERR_STATUS_CLR_REG               ERR_STATUS_CLR;               // Error Status Clear
        union   ERR_CNT_REG                      ERR_CNT;                      // Error Control
        union   ERR_THRESHOLD_REG                ERR_THRESHOLD;                // Error Threshold
        union   ERR_INTFLG_REG                   ERR_INTFLG;                   // Error Interrupt Flag
        union   ERR_INTCLR_REG                   ERR_INTCLR;                   // Error Interrupt Flag Clear
        Uint32                                   FDATAH_TEST;                  // Data High Test
        Uint32                                   FDATAL_TEST;                  // Data Low Test
        union   FADDR_TEST_REG                   FADDR_TEST;                   // ECC Test Address
        union   FECC_TEST_REG                    FECC_TEST;                    // ECC Test Address
        union   FECC_CTRL_REG                    FECC_CTRL;                    // ECC Control
        Uint32                                   FOUTH_TEST;                   // Test Data Out High
        Uint32                                   FOUTL_TEST;                   // Test Data Out Low
        union   FECC_STATUS_REG                  FECC_STATUS;                  // ECC Status
    };

    //PRQA S 2176 --
    //#Unions used in HW register mapping in Texas Instruments' libraries.
    //PRQA S 2301 --
    //#Bit-fields are needed.
    //PRQA S 5050 --
    //#Identifiers will be kept by default
    //PRQA S 5051 --
    //#Identifiers will be kept by default


    /// Initializes the Flash Control registers.
    /// CAUTION: This function MUST be executed out of RAM. Executing
    /// it out of OTP/Flash will yield unpredictable results.
    void Flash::init()
    {
        static const Uint16 setDelay=     static_cast<Uint16>(0x14);
        static const Uint16 setFPAC=      static_cast<Uint16>(0x1);
        static const Uint16 setFB=        static_cast<Uint16>(0x3);
        static const Uint16 setFlash=     static_cast<Uint16>(0x3);
        static const Uint16 setEn=        static_cast<Uint16>(0xA);

        static const Uint32 flash0_ctrl_regs_addr = 0x05F800UL;
        //                      **CAUTION**
        //Making FLASH_CTRL_REGS static makes compiler think that the variable has already been initialized by CPU1
        // and skips initialization in CPU2
        volatile FLASH_CTRL_REGS& flash0_ctrl_regs = Hregmap::get<FLASH_CTRL_REGS, flash0_ctrl_regs_addr>();

        asm_eallow();
        //
        // Set VREADST to the proper value for the flash banks to power up
        // properly. This sets the bank power up delay.
        //
        flash0_ctrl_regs.FBAC.bit.VREADST = setDelay;

        //
        // At reset bank and pump are in sleep. A Flash access will power up the
        // bank and pump automatically.
        //
        // After a Flash access, bank and pump go to low power mode (configurable
        // in FBFALLBACK/FPAC1 registers) if there is no further access to flash.
        //
        // Power up Flash bank and pump. This also sets the fall back mode of
        // flash and pump as active.
        //
        flash0_ctrl_regs.FPAC1.bit.PMPPWR = setFPAC;
        flash0_ctrl_regs.FBFALLBACK.bit.BNKPWR0 = setFB;

        //
        // Disable Cache and prefetch mechanism before changing wait states
        //
        flash0_ctrl_regs.FRD_INTF_CTRL.bit.DATA_CACHE_EN = 0;
        flash0_ctrl_regs.FRD_INTF_CTRL.bit.PREFETCH_EN = 0;

        //
        // Set waitstates according to frequency
        //
        //      *CAUTION*
        // Minimum waitstates required for the flash operating at a given CPU rate
        // must be characterized by TI. Refer to the datasheet for the latest
        // information.
        //
        // Flash parameters
        // 150 < CPUCLK <= 200  -->  0x3
        // 100 < CPUCLK <= 150  -->  0x2
        //  50 < CPUCLK <= 100  -->  0x1
        //       CPUCLK <= 50   -->  0x0
        flash0_ctrl_regs.FRDCNTL.bit.RWAIT = setFlash;

        //
        // Enable Cache and prefetch mechanism to improve performance of code
        // executed from Flash.
        //
        flash0_ctrl_regs.FRD_INTF_CTRL.bit.DATA_CACHE_EN = 1;
        flash0_ctrl_regs.FRD_INTF_CTRL.bit.PREFETCH_EN = 1;

        //
        // At reset, ECC is enabled. If it is disabled by application software and
        // if application again wants to enable ECC.
        //
        static const Uint32 flash0_ecc_regs_addr  = 0x05FB00UL;

        //                         **CAUTION**
        //Making FLASH_ECC_REGS static makes compiler think that the variable has already been initialized by CPU1
        // and skips initialization in CPU2
        volatile FLASH_ECC_REGS&  flash0_ecc_regs  = Hregmap::get<FLASH_ECC_REGS , flash0_ecc_regs_addr>();
        flash0_ecc_regs.ECC_ENABLE.bit.ENABLE = setEn;

        asm_edis();

        //
        // Force a pipeline flush to ensure that the write to the last register
        // configured occurs before returning.
        //
        asm_pipeline_flush7();
    }
}
