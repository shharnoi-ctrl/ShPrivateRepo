#ifndef IENDIAN32_H__
#define IENDIAN32_H__

#include <Entypes.h>

namespace Base
{
    class Iendian32
    {
    public:
        virtual void put_uint32(const Uint32& p,
                                NWord* v,
                                Uint32& x,
                                int16 nbits) const = 0;
        virtual void get_uint32(Uint32& p,
                                const NWord* v,
                                Uint32& x,
                                int16 nbits) const = 0;

    protected:
        Iendian32();
        ~Iendian32();
        
    private:
        Iendian32(const Iendian32& orig); ///< = delete
        Iendian32& operator=(const Iendian32& orig); ///< = delete
    };

    inline Iendian32::Iendian32()
    {
    }

    inline Iendian32::~Iendian32() //PRQA S 2635 #destructor replaced with default
    {
    }

}

#endif

