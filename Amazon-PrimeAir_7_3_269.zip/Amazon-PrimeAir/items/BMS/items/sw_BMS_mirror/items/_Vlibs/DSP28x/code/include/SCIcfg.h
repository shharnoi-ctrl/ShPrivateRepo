#ifndef SCICFG_H_
#define SCICFG_H_

#include <Entypes.h>

//Forward references
#include <Lossy_fw.h>
#include <Lossy_error_fw.h>

namespace Dsp28335_ent
{
    /// SCI configuration parameters
    struct SCIcfg
    {
        /// Data length in bits
        enum Length
        {
            len_4   = 0,
            len_5   = 1,
            len_6   = 2,
            len_7   = 3,
            len_8   = 4
        };
        static const Uint16 len_all = 5;

        /// Stop bits
        enum Stop
        {
            stp_1   = 0,
            stp_1_5 = 1,
            stp_2   = 2
        };
        static const Uint16 stp_all = 3;

        /// Parity
        enum Parity_bits
        {
            par_even = 0,
            par_odd  = 1,
            par_dis  = 2        ///< Parity off
        };
        static const Uint16 par_all  = 3;

        Uint32 speed;           ///< Speed in bauds
        Length length;          ///< Bits
        Stop stop;              ///< Stop condition
        Parity_bits parity;     ///< Parity mode
        bool use_addr_mode;     ///< Address mode (9th data bit)

        static SCIcfg build(Uint32 spd0,            ///< Baudrate
                            Length lng0,            ///< Data length
                            Stop stp0,              ///< Number of stop bits
                            Parity_bits par0,       ///< Parity
                            bool use_addr_mode0);   ///< Address mode
        void init();
        bool validate() const;

        void cset(Base::Lossy_error& str);
    };
}
#endif
