#include <Chrono.h>
#include <Const.h>

namespace Base
{
    static const Real dt_condition = static_cast<Real>(1E-10);
    Chrono::Chrono(bool start):
        on(start)
    {
        if(start)
        {
            tic();
        }
    }

    /// \alg
    void Chrono::step(Real& dt,Real& dt_1)
    {
        /// <li> Measure time (dt) by subtracting current system time and ::tk0.
        /// <li> Update ::tk0 with current time.
        Ttime tk = Bsp::Htime::get_time();
        dt=(tk-tk0).get_seconds();
        tk0=tk;
        /// <li> IF measured time > 1E-10. <ul>
        /// <li> dt_1 is set as 1/dt.
        /// </ul>
        /// <li> ELSE. <ul>
        /// <li> dt_1 set to 0.
        /// </ul>
        if(dt>(dt_condition))
        {
            dt_1=Const::ONE/dt;
        }
        else 
        {
            dt_1=0;
        }
    }

    Real Chrono::step()
    {
        Ttime tk = tk0;
        tk0 = Bsp::Htime::get_time();
        return (tk0-tk).get_seconds();
    }

}
