///    \file Tdsynctraits.h
///
///    \date 15 nov. 2017
///
///    \author  FJBurgos, jbm (at) embention.com
///    Company:  Embention
///
///    Tdsynctraits class declaration.
///

#ifndef TDSYNCTRAITS_H_
#define TDSYNCTRAITS_H_

#include <Cptraits.h>
#include <Mutex.h>
#include <Dsync.h>

namespace Base
{
    /// Tdsynctraits
    /// The Base namespace shall provide a structure to define the reading and writing policies of templated 
    /// data synchronization control (Tdsync) traits.
    struct Tdsynctraits
    {
    public:

        /// Tdsynctraits shall provide a structure to induce failure if read or write methods are called
        /// at compile time.
        struct Disabled_struct
        {
        };

        /// Tdsynctraits shall provide a structure to try to read a Tdsync trait once.
        template <typename T, typename CPTRAIT = Cptraits::Podraw<volatile T> >
        struct Rd_nonblocking
        {
            /// Caller can not assume reader returned was in valid state at read time.
            static const bool always_succeed=false;
            /// Templated Data Synchronization Read Nonblocking Copier.
            /// \wi{5217}
            /// Rd_nonblocking structure shall provide the capability to copy a trait for read methods, in case
            /// default assignment operator is not working.
            /// \param[in] sync Dsync to read.
            /// \param[in] from Source structure to get.
            /// \param[out] to  Destination structure.
            /// \return         Reader object to know if read is (still) valid.
            static Dsync::Reader copy(const volatile Dsync& sync,
                                      const volatile T& from,
                                      T& to);
        };

        /// Tdsynctraits shall provide a structure to retry a Tdsync trait reading until the value is valid.
        /// This read policy assumes writes are fast and at low frequency, it should be combined with Wr_mutex.
        template <typename T, typename CPTRAIT = Cptraits::Podraw<volatile T> >
        struct Rd_blocking
        {
            /// Caller can assume reader returned was in valid state at read time.
            static const bool always_succeed=true; 
            /// Templated Data Synchronization Read Blocking Copier.
            /// \wi{5218}
            /// Rd_blocking structure shall provide the capability to copy a trait for read methods, in case
            /// default assignment operator is not working.
            /// \param[in] sync Dsync to read.
            /// \param[in] from Source structure to copy.
            /// \param[out] to  Destination structure.
            /// \return         Reader object to know if read is (still) valid.
            static Dsync::Reader copy(const volatile Dsync& sync,
                                      const volatile T& from,
                                      T& to);
        };

        /// Tdsynctraits shall provide a structure to write a Tdsync trait.
        template <typename T, typename CPTRAIT = Cptraits::Operator<T> >
        struct Wr
        {
            /// Templated Data Synchronization Writer Copier.
            /// \wi{5219}
            /// Wr structure shall provide the capability to copy trait for write methods, in case
            /// default assignment operator is not working.
            /// \param[in] sync Dsync to write.
            /// \param[in] from Source structure to copy.
            /// \param[out] to  Destination structure.
            static void copy(Dsync& sync,
                             const T& from,
                             T& to);
        };

        /// Tdsynctraits shall provide a structure to write with mutex (no ISRs can interrupt execution of write)
        /// a Tdsync trait.
        template <typename T, typename CPTRAIT = Cptraits::Operator<T> >
        struct Wr_mutex
        {
            /// Templated Data Synchronization Writer with Mutex Copier.
            /// \wi{5220}
            /// Wr_ mutex structure shall provide the capability to copy trait for write with mutex methods, in case
            /// default assignment operator is not working.
            /// \param[in] sync Dsync to write.
            /// \param[in] from Source structure to copy.
            /// \param[out] to  Destination structure.
            static void copy(Dsync& sync,
                             const T& from,
                             T& to);
        };


    private:
        Tdsynctraits();                                     ///< = delete.
        Tdsynctraits(const Tdsynctraits& orig);             ///< = delete.
        ~Tdsynctraits();
        Tdsynctraits& operator=(const Tdsynctraits& orig);  ///< = delete.
    };


    template <typename T, typename CPTRAIT>
    inline Dsync::Reader Tdsynctraits::Rd_nonblocking<T,CPTRAIT>::copy(const volatile Dsync& sync,
                                                                       const volatile T& from,
                                                                       T& to)
    {
        /// \alg
        /// <ul>
        /// <li> Create a new Dsync::Reader object "rd" initialized with given parameter "sync".
        /// <li> Call CPTRAIT::copy with given parameters "from" and "to".
        /// <li> Return "rd".
        /// </ul>
        Dsync::Reader rd(sync);
        CPTRAIT::copy(from,to);
        return rd;
    }


    template <typename T, typename CPTRAIT>
    inline Dsync::Reader Tdsynctraits::Rd_blocking<T,CPTRAIT>::copy(const volatile Dsync& sync,
                                                         const volatile T& from,
                                                         T& to)
    {
        // assumes writer not locked (else, this method will not return).
        /// \alg
        /// <ul>
        /// <li> While True, repeat the following steps:
        do
        {
            /// <ul>
            /// <li> Create a new Dsync::Reader object "rd" initialized with given parameter "sync".
            /// <li> Call Dsync::Reader::wr_wait for "rd".
            /// <li> Call CPTRAIT::copy with given parameters "from" and "to".
            Dsync::Reader rd(sync);
            rd.wr_wait();
            CPTRAIT::copy(from,to);
            /// <li> If retrieved value by Reader::is_valid for "rd" is True, return "rd".
            if(rd.is_valid())
            {
                return rd;
            }
            /// </ul>
        /// </ul>
        }
        while(true);  // retry if it was written
    }


    template <typename T, typename CPTRAIT>
    inline void Tdsynctraits::Wr<T,CPTRAIT>::copy(Dsync& sync,
                                       const T& from,
                                       T& to)
    {
        // not reentrant
        // note that reader can be locked waiting this operation to finish,
        // caller must think if disable interrupts is required (mutex).
        /// \alg
        /// <ul>
        /// <li> Create a new Dsync::Writer object "wr" initialized with given parameter "sync".
        /// <li> Call CPTRAIT::copy with given parameters "from" and "to".
        /// </ul>
        Dsync::Writer wr(sync); // RAII
        CPTRAIT::copy(from,to);
    }


    template <typename T, typename CPTRAIT>
    inline void Tdsynctraits::Wr_mutex<T,CPTRAIT>::copy(Dsync& sync,
                                             const T& from,
                                             T& to)
    {
        /// \alg
        /// <ul>
        /// <li> Construct a new Mutex object "m" passing to it True.
        /// <li> Call ::copy with given parameters "sync", "from" and "to".
        /// </ul>
        Base::Mutex m(true);
        Wr<T,CPTRAIT>::copy(sync,from,to);
    }

} // namespace Base

#endif // TDSYNCTRAITS_H_
