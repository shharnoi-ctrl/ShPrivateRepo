#ifndef ITPRODUCER_FW_H_
#define ITPRODUCER_FW_H_

#include <Entypes.h>

namespace Base
{

    template <typename T>
    class Itproducer;

    typedef Itproducer<Uint8> Itproducer_u8;
    typedef Itproducer<Uint16> Itproducer_u16;
}
#endif
