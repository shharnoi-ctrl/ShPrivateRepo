#ifndef ANALOG_SUBSYS_H_
#define ANALOG_SUBSYS_H_

namespace Dsp28335_ent
{
    /// Analog subsystem registers handler.
    /// CAUTION: registers are only available in CPU1.
    class Analog_subsys
    {
    public:
        static void set_tsnsctl(bool en);
        static void apply_static_calibration();

    private:
        Analog_subsys(); ///< = delete
        Analog_subsys(const Analog_subsys& orig); ///< = delete
        Analog_subsys& operator=(const Analog_subsys& orig); ///< = delete
    };
}
#endif
