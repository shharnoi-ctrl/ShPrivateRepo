#ifndef U8ISTREAM_H_
#define U8ISTREAM_H_

#include <Bitutils.h>
#include <Lossy_fw.h>
#include <Real16.h>
#include <U8pkmblock.h>

namespace Base
{
    /// Input byte streamer with Little and Big endian supported.
    /// The ::Base library shall provide the capability to read bytes for an input byte stream. 
    class U8istream
    {
    public:
        /// Data Traits for U8istream.
        struct Data_traits8 : public type_is<U8istream>
        {
            /// Data_traits8 Data Retriever.
            /// \wi{18027}
            /// Data_traits8 structure shall be able to retrieve data for the input byte stream.
            /// \param[in] is       Input byte stream instance.
            /// \return Data storage in input byte stream.
            static inline U8pkmblock_k get_data(const U8istream& is)
            {
                /// \alg
                /// - Return memory block value for the input instance.
                return is.mb;
            }

            /// Data_traits8 Data Size Retriever.
            /// \wi{18028}
            /// Data_traits8 structure shall be able to retrieve size of the data for the input byte stream.
            /// \param[in] is       Input byte stream instance.
            /// \return Size of the input byte stream.
            static inline Uint32 get_size(const U8istream& is)
            {
                /// \alg
                /// - Return U8istream::get_pos retrieved value for the input instance.
                return is.get_pos();
            }

            /// Data_traits8 Update Data Size.
            /// \wi{18029}
            /// Data_traits8 structure shall be able to update the input byte stream size of a given size.
            /// \param[in,out] is   Input byte stream instance.
            /// \param[in] sz       Size of the input byte stream to update.
            static inline void update_size(U8istream& is, Uint32 sz)
            {
                /// \alg
                /// - Set first received parameter instance position with retrieved value by U8istream::get_pos plus the second received parameter.
                is.seek(is.get_pos() + sz);
            }

            /// Data_traits8 Maximum Data Size Retriever.
            /// \wi{18030}
            /// Data_traits8 structure shall be able to retrieve the maximum size of the data for the input byte stream.
            /// \param[in] is       Input byte stream instance.
            /// \return Maximum size of the input byte stream.
            static inline Uint16 get_max_size(U8istream& is)
            {
                /// \alg
                /// - Return U8istream::get_max_size retrieved value for the input instance.
                return is.get_max_size();
            }

            /// Data_traits8 Current Data Position Retriever.
            /// \wi{18031}
            /// Data_traits8 structure shall be able to retrieve the current data position for the input byte stream.
            /// \param[in] is       Input byte stream instance.
            /// \return Current size of the input byte stream.
            static inline Uint16 get_pos(const U8istream& is)
            {
                /// \alg
                /// - Return U8istream::get_pos retrieved value for the input instance.
                return is.get_pos();
            }
        };

        /// Mutator 8-bit Data Traits for U8istream.
        struct Mutator_traits8 : public type_is<U8istream>
        {
            /// Mutator_traits8 Data Adapter.
            /// \wi{18032}
            /// Mutator_traits8 structure shall be able to retrieve an 8-bit memory block from a given 16-bit memory block.
            /// \param[in] mb       16-bit Memory block instance.
            /// \return 8-bit Memory block.
            static inline U8pkmblock_k adapt_data(const Mblock_u16& mb)
            {
                /// \alg
                /// - Return U8pkmblock_k::U8pkmblock_k retrieved reference for the input instance.
                return U8pkmblock_k(mb);
            }
            
            /// Data_traits8 Data Size Retriever.
            /// \wi{18033}
            /// Data_traits8 structure shall be able to retrieve size of the data for the input byte stream.
            /// \param[in] is       Input byte stream instance.
            /// \return Size of the input byte stream.
            static inline Uint32 get_size(const U8istream& is)
            {
                /// \alg
                /// - Return U8istream::get_pos retrieved value for the input instance.
                return is.get_pos();
            }

            /// Data_traits8 Data Position Setter.
            /// \wi{18034}
            /// Data_traits8 structure shall provide the capability to set the position for the input byte stream.
            /// \param[in,out] is   Input byte stream instance.
            /// \param[in] sz       Size of the input byte stream to set.
            static inline void set_pos(U8istream& is, Uint16 sz)
            {
                /// \alg
                /// - Call to U8istream::seek for the input instance with the input parameter sz.
                is.seek(sz);
            }
        };

        /// Constant Mutator 8-bit Data Traits for U8istream.
        struct Mutator_traits16 : public type_is<U8istream>
        {
            /// Mutator_traits16 Data Adapter.
            /// \wi{18035}
            /// Mutator_traits16 structure shall be able to retrieve an 8-bit memory block from a given constant 16-bit memory block.
            /// \param[in] mb       Constant 16-bit memory block instance.
            /// \return 8-bit Memory block.
            static inline U8pkmblock_k adapt_data(const Mblock<const Uint16>& mb)  /// \return Data to build the mutator
            {
                /// \alg
                /// - Return U8pkmblock_k::U8pkmblock_k retrieved reference for the input instance.
                return U8pkmblock_k(mb);
            }

            /// Data_traits16 Data Size Retriever.
            /// \wi{18036}
            /// Data_traits16 structure shall be able to retrieve size of the data for the input byte stream.
            /// \param[in] is       Input byte stream instance.
            /// \return Size of the input byte stream.
            static inline Uint32 get_size(const U8istream& is)
            {
                /// \alg
                /// - Return Bitutils::bytes_to_words16 retrieved value for U8istream::get_pos retrieved for the input instance.
                return Bitutils::bytes_to_words16(is.get_pos());
            }

            /// Data_traits16 Data Position Setter.
            /// \wi{18037}
            /// Data_traits16 structure shall provide the capability to set the position for the input byte stream with specific size.
            /// \param[in] is       Input byte stream instance.
            /// \param[in] sz       Size of the input byte stream to set.
            /// \return Number of bytes value set
            static inline Uint16 set_pos(U8istream& is, Uint16 sz)
            {
                /// \alg
                /// <ul>
                /// <li> Get the number of bytes needed to hold for input size.
                Uint16 pos = Bitutils::words16_to_bytes(sz);
                /// <li> Call to U8istream::seek for the number of bytes needed.
                is.seek(pos);
                /// <li> Return number of bytes set.
                /// </ul>
                return pos;
            }
        };

        /// U8istream Constructor with Given Data Buffer.
        /// \wi{5730}
        /// U8istream class shall build itself upon construction with the provided parameters.
        /// \param[in] mb0          Constant 8-bit memory block.
        explicit U8istream(const U8pkmblock_k& mb0);

        /// U8istream Constructor with Given Data Buffer at Given Position.
        /// \wi{18038}
        /// U8istream class shall build itself upon construction with the provided parameters.
        /// \param[in] mb0          Constant 8-bit memory block.
        /// \param[in] offset       Current read/write position.
        explicit U8istream(const U8pkmblock_k& mb0, Uint32 offset);

        /// U8istream Zero Position Setter.
        /// \wi{18039}
        /// U8istream class shall provide the capability to set its internal position to 0.
        void reuse();
        /// U8istream Position Setter.
        /// \wi{18040}
        /// U8istream class shall provide the capability to set the position to given position.
        /// \param[in] pos0         Position to set.
        /// \return True if the position is set, False if not.
        bool seek(Uint32 pos0);
        /// U8istream End Position Setter.
        /// \wi{18041}
        /// U8istream class shall provide the capability to set the position to the end of its internal stream.
        void seek_end();

        /// U8istream Position Retriever.
        /// \wi{18042}
        /// U8istream class shall be able to retrieve its internal position.
        /// \return Internal position.
        Uint32 get_pos() const;
        /// U8istream Maximum Stream Size Retriever.
        /// \wi{18043}
        /// U8istream shall be able to retrieve the maximum size readable of its internal stream.
        /// \return Maximum size of its internal stream.
        Uint32 get_max_size() const;

        /// U8istream 8-bit Stream Retriever.
        /// \wi{18044}
        /// U8istream shall be able to retrieve a 8-bit stream for its internal parameters.
        /// \return 8-bit stream for its internal memory block and position.
        U8pkmblock_k to_mblock8() const;
        /// U8istream All Stream Retriever.
        /// \wi{18045}
        /// U8istream shall be able to retrieve its internal memory block.
        /// \return Internal memory block.
        U8pkmblock_k all_mblock8() const;

        /// U8istream Unsigned 8-bit Retriever.
        /// \wi{5731}
        /// U8istream shall be able to retrieve the current Uint8 for its internal stream and increment position by 1.
        /// \return Current Uint8 little endian for its internal stream.
        Uint8 get_uint8();
         /// U8istream Signed 8-bit Retriever.
         /// \wi{5732}
         /// U8istream shall be able to retrieve the current int8 for its internal stream and increment position by 1.
         /// \return Current int8 little endian for its internal stream.
         int8 get_int8();
        /// U8istream Little Endian Unsigned 16-bit Retriever.
        /// \wi{5733}
        /// U8istream shall be able to retrieve the current little endian Uint16 for its internal stream and increment position by 2.
        /// \return Current Uint16 little endian for its internal stream.
        Uint16 get_uint16_le();
         /// U8istream Little Endian Signed 16-Byte Retriever.
         /// \wi{5734}
         /// U8istream shall be able to retrieve the current little endian int16 for its internal stream and increment position by 2.
         /// \return Current int16 little endian for its internal stream.
         int16 get_int16_le();
        /// U8istream Little Endian Unsigned 24-bit Retriever.
        /// \wi{6361}
        /// U8istream shall be able to retrieve the current little endian Uint24 for its internal stream and increment position by 3.
        /// \return Current Uint24 little endian for its internal stream.
        Uint32 get_uint24_le();
         /// U8istream Little Endian Signed 24-Byte Retriever.
         /// \wi{6362}
         /// U8istream shall be able to retrieve the current little endian int24 for its internal stream and increment position by 3.
         /// \return Current int24 little endian for its internal stream.
         int32 get_int24_le();
        /// U8istream Little Endian Unsigned 32-bit Retriever.
        /// \wi{6119}
        /// U8istream shall be able to retrieve the current little endian Uint32 for its internal stream and increment position by 4.
        /// \return Current Uint32 little endian for its internal stream.
        Uint32 get_uint32_le();
         /// U8istream Little Endian Signed 32-Byte Retriever.
         /// \wi{6120}
         /// U8istream shall be able to retrieve the current little endian int32 for its internal stream and increment position by 4.
         /// \return Current int32 little endian for its internal stream.
         int32 get_int32_le();
        /// U8istream Little Endian Unsigned 64-bit Retriever.
        /// \wi{6363}
        /// U8istream shall be able to retrieve the current little endian Uint64 for its internal stream and increment position by 8.
        /// \return Current Uint64 little endian for its internal stream.
        Uint64 get_uint64_le();
        /// U8istream Little Endian Real 16-bit Retriever.
        /// \wi{6502}
        /// U8istream shall be able to retrieve the current little endian Real 16-bit for its internal stream and increment position by 2.
        /// \return Current Real little endian 16-bit for its internal stream.
        Real   get_float16_le();
        /// U8istream Little Endian Real 32-bit Retriever.
        /// \wi{6365}
        /// U8istream shall be able to retrieve the current little endian Real 32-bit for its internal stream and increment position by 4.
        /// \return Current Real little endian 32-bit for its internal stream.
        Real   get_float32_le();
        /// U8istream Little Endian Real64 Retriever.
        /// \wi{18046}
         /// U8istream shall be able to retrieve the current little endian Real 64-bit for its internal stream and increment position by 8.
        /// \return Current Real 64-bit little endian for its internal stream.
        Real64 get_float64_le();

        /// U8istream Big Endian Unsigned 16-bit Retriever.
        /// \wi{6310}
        /// U8istream shall be able to retrieve the current big endian Uint16 for its internal stream and increment position by 2.
        /// \return Current Uint16 big endiand for its internal stream.
        Uint16 get_uint16_be();
         /// U8istream Big Endian Signed 16-Byte Retriever.
         /// \wi{5735}
         /// U8istream shall be able to retrieve the current big endian int16 for its internal stream and increment position by 2.
         /// \return Current int16 big endiand for its internal stream.
         int16 get_int16_be();
        /// U8istream Big Endian Unsigned 24-bit Retriever.
        /// \wi{5736}
        /// U8istream shall be able to retrieve the current big endian Uint24 for its internal stream and increment position by 3.
        /// \return Current Uint24 big endiand for its internal stream.
        Uint32 get_uint24_be();
         /// U8istream Big Endian Signed 24-Byte Retriever.
         /// \wi{5737}
         /// U8istream shall be able to retrieve the current big endian int24 for its internal stream and increment position by 3.
         /// \return Current int24 big endian for its internal stream.
         int32 get_int24_be();
        /// U8istream Big Endian Unsigned 32-bit Retriever.
        /// \wi{5738}
        /// U8istream shall be able to retrieve the current big endian Uint32 for its internal stream and increment position by 4.
        /// \return Current Uint32 big endian for its internal stream.
        Uint32 get_uint32_be();
         /// U8istream Big Endian Signed 32-Byte Retriever.
         /// \wi{5739}
         /// U8istream shall be able to retrieve the current big endian int32 for its internal stream and increment position by 4.
         /// \return Current int32 big endian for its internal stream.
         int32 get_int32_be();
        /// U8istream Big Endian Unsigned 64-bit Retriever.
        /// \wi{6364}
        /// U8istream shall be able to retrieve the current big endian Uint64 for its internal stream and increment position by 8.
        /// \return Current Uint64 big endian for its internal stream.
        Uint64 get_uint64_be();
        /// U8istream Big Endian Real 16-bit Retriever.
        /// \wi{6501}
        /// U8istream shall be able to retrieve the current big endian Real 16-bit for its internal stream and increment position by 2.
        /// \return Current real big endian 16-bit for its internal stream.
        Real   get_float16_be();
        /// U8istream Big Endian Real 32-bit Retriever.
        /// \wi{6366}
        /// U8istream shall be able to retrieve the current big endian Real 32-bit for its internal stream and increment position by 4.
        /// \return Current real big endian 32-bit for its internal stream.
        Real   get_float32_be();

        /// U8istream Fixed Length Deserialization.
        /// \wi{13954}
        /// The U8istream class shall provide a method to deserialize a fixed length set of bytes.
        /// \param[in, out] b       Memory buffer instance to store the deserialized data for its internal stream.
        void   get_u8pkmblock(U8pkmblock& b);

        /// U8istream Big Endian Given Bytes Unsigned 64-bit Retriever.
        /// \wi{18047}
        /// U8istream shall be able to retrieve the given bytes in big endian for its internal stream and increment position by the given bytes.
        /// \param[in] nbytes       Uint16 number of bytes to retrieve.
        /// \return Uint64 bytes in big endian for its internal stream.
        Uint64 get_uint64_be(const Uint16 nbytes);
         /// U8istream Big Endian Given Bytes Signed 64-bit Retriever.
         /// \wi{18048}
         /// U8istream shall be able to retrieve the given bytes in big endian for its internal stream and increment position by the given bytes.
         /// \param[in] nbytes       Uint16 number of bytes to retrieve.
         /// \return Current int64 bytes in big endian for its internal stream.
         int64 get_int64_be(const Uint16 nbytes);
        /// U8istream Little Endian Given Bytes Unsigned 64-bit Retriever.
        /// \wi{18049}
        /// U8istream shall be able to retrieve the given bytes in little endian for its internal stream and increment position by the given bytes.
        /// \param[in] nbytes       Uint16 number of bytes to retrieve.
        /// \return Current Uint64 bytes in little endian for its internal stream.
        Uint64 get_uint64_le(const Uint16 nbytes);

    private:
        
        static const Uint16 int8_displ = (sizeof(Uint8) == sizeof(Uint16)) ? 8 : 0;     ///< Displacement for int8 retrieval. It is needed if Uint8 is 2 bytes in size.

        U8pkmblock_k mb;                    ///< Working memory block.
        Uint32 pos;                         ///< Current read/write position.

        U8istream(); ///< = delete
    };

    inline U8istream::U8istream(const U8pkmblock_k& mb0) :
        mb(mb0),
        pos(0)
    {
    }

    inline U8istream::U8istream(const U8pkmblock_k& mb0, Uint32 offset) :
        mb(mb0),
        pos(offset)
    {
    }

    inline Uint32 U8istream::get_pos() const
    {
        /// \alg
        /// - Return ::pos.
        return pos;
    }

    inline Uint32 U8istream::get_max_size() const
    {
        /// \alg
        /// - Return retrieved value by U8pkmblock_k::size for ::mb.
        return mb.size();
    }

    inline void U8istream::reuse()
    {
        /// \alg
        /// - Set ::pos to 0.
        pos = 0;
    }

    inline bool U8istream::seek(Uint32 pos0)
    {
        /// \alg
        /// <ul>
        /// <li> Call to Assertions::runtime with result of the '<=' comparison between: 
        /// <ul>
        /// <li> Position received parameter.
        /// <li> Retrieved value by U8pkmblock_k::size for ::mb.
        /// </ul>
        /// <li> IF retrieved value is True:
        bool res = Assertions::runtime(pos0 <= mb.size());
        if(res)
        {
            /// <ul>
            /// <li> Set ::pos to position received parameter.
            /// </ul>
            pos = pos0;
        }
        /// <li> Return retrieved value for the comparison.
        return res;
    }

    inline void U8istream::seek_end()
    {
        /// \alg
        /// - Set ::pos to retrieved value by U8pkmblock_k::size for ::mb.
        pos = mb.size();
    }


    inline U8pkmblock_k U8istream::to_mblock8() const
    {
        /// \alg
        /// - Return U8pkmblock_k::U8pkmblock_k instance for ::mb and ::pos.
        return U8pkmblock_k(mb, pos);
    }

    inline U8pkmblock_k U8istream::all_mblock8() const
    {
        /// \alg
        /// - Return ::mb.
        return mb;
    }

    inline Uint8 U8istream::get_uint8()
    {
        /// \alg
        /// - Return retrieved value by U8pkmblock_k::get with next position for ::mb.
        return mb.get(pos++);
    }

    inline int8 U8istream::get_int8()
    {
        /// \alg
        /// - Return left and right ::int8_displ bit shift displacement for the retrieved value by U8istream::get_uint8 to extend sign.
        /// - NOTE: This code ensure it works in C2000 processors where Uint8 is 16bits long.
        return (static_cast<int8>(get_uint8()) << int8_displ) >> int8_displ;
    }

    // Little endian methods --------------------------------------------------
    inline Uint16 U8istream::get_uint16_le()
    {
        /// \alg
        /// <ul>
        /// <li> Get Uint16 retrieved value by U8pkmblock_k::get for ::mb with ::pos.
        Uint16 v =                     mb.get(pos);
        /// <li> Set value at index Ku16::u1 with value at ::pos+Ku16::u1 memory block position.
        Bitutils::set_u8(&v, Ku16::u1, mb.get(pos+Ku16::u1));
        /// <li> Increase Ku32::u2 for ::pos.
        pos += Ku32::u2;
        /// <li> Return value.
        return v;
        /// </ul>
    }

    inline int16 U8istream::get_int16_le()
    {
        /// \alg
        /// - Return conversion to signed 16-bit retrieved value by U8istream::get_uint16_le.
        return static_cast<int16>(get_uint16_le());
    }

    inline Uint32 U8istream::get_uint24_le()
    {
        /// \alg
        /// <ul>
        /// <li> Get Uint32 retrieved value by U8pkmblock_k::get for ::mb with ::pos.
        Uint32 v =                     mb.get(pos);
        /// <li> Set value at index Ku16::u1 with value at ::pos+Ku16::u1 memory block position.
        Bitutils::set_u8(&v, Ku16::u1, mb.get(pos+Ku16::u1));
        /// <li> Set value at index Ku16::u2 with value at ::pos+Ku16::u2 memory block position.
        Bitutils::set_u8(&v, Ku16::u2, mb.get(pos+Ku16::u2));
        /// <li> Increase Ku32::u3 for ::pos.
        pos += Ku32::u3;
         /// <li> Return value.
        return v;
        /// </ul>
    }

    inline int32 U8istream::get_int24_le()
    {
        /// \alg
        /// - Return left and right Ku16::u8 bit shift displacement for the retrieved value by U8istream::get_uint24_le to extend sign.
        return (static_cast<int32>(get_uint24_le()) << Ku16::u8) >> Ku16::u8;
    }

    inline Uint32 U8istream::get_uint32_le()
    {
        /// \alg
        /// <ul>
        /// <li> Get Uint32 retrieved value by U8pkmblock_k::get for ::mb with ::pos.
        Uint32 v =                     mb.get(pos);
        /// <li> Set value at index Ku16::u1 with value at ::pos+Ku16::u1 memory block position.
        Bitutils::set_u8(&v, Ku16::u1, mb.get(pos+Ku16::u1));
        /// <li> Set value at index Ku16::u2 with value at ::pos+Ku16::u2 memory block position.
        Bitutils::set_u8(&v, Ku16::u2, mb.get(pos+Ku16::u2));
        /// <li> Set value at index Ku16::u3 with value at ::pos+Ku16::u3 memory block position.
        Bitutils::set_u8(&v, Ku16::u3, mb.get(pos+Ku16::u3));
        /// <li> Increase Ku32::u4 for ::pos.
        pos += Ku32::u4;
        /// <li> Return value.
        return v;
        /// </ul>
    }

    inline int32 U8istream::get_int32_le()
    {
        /// \alg
        /// - Return conversion to signed 32-bit retrieved value by U8istream::get_uint32_le.
        return static_cast<int32>(get_uint32_le());
    }

    inline Real U8istream::get_float32_le()
    {
        /// \alg
        /// <ul>
        /// <li> Get retrieved value by U8istream::get_uint32_le.
        Uint32 aux = get_uint32_le();
        /// <li> Return conversion to Real retrieved value.
        return *reinterpret_cast<Real*>(&aux);
        /// </ul>
    }

    inline Real64 U8istream::get_float64_le()
    {
        /// \alg
        /// <ul>
        /// <li> Get retrieved value by U8istream::get_uint64_le.
        const Uint64 aux = get_uint64_le();
        /// <li> Return conversion to Real64 retrieved value.
        return *reinterpret_cast<const Real64*>(&aux);
        /// </ul>
    }

    // Big endian methods --------------------------------------------------
    inline Uint16 U8istream::get_uint16_be()
    {
        /// \alg
        /// <ul>
        /// <li> Get Uint16 retrieved value by U8pkmblock_k::get for ::mb with ::pos+Ku16::u1.
        Uint16 v =                     mb.get(pos+Ku16::u1);
        /// <li> Set value at index Ku16::u1 with value at ::pos+Ku16::u1 memory block position.
        Bitutils::set_u8(&v, Ku16::u1, mb.get(pos));
        /// <li> Increase Ku32::u4 for ::pos.
        pos += Ku32::u2;
        /// <li> Return value.
        return v;
        /// </ul>
    }

    inline int16 U8istream::get_int16_be()
    {
        /// \alg
        /// - Return conversion to signed 16-bit retrieved value by U8istream::get_uint16_be.
        return static_cast<int16>(get_uint16_be());
    }

    inline Uint32 U8istream::get_uint24_be()
    {
        /// \alg
        /// <ul>
        /// <li> Get Uint32 retrieved value by U8pkmblock_k::get for ::mb with ::pos+Ku16::u2.
        Uint32 v =                     mb.get(pos+Ku16::u2);
        /// <li> Set value at index Ku16::u1 with value at ::pos+Ku16::u1 memory block position.
        Bitutils::set_u8(&v, Ku16::u1, mb.get(pos+Ku16::u1));
        /// <li> Set value at index Ku16::u2 with value at ::pos+Ku16::u2 memory block position.
        Bitutils::set_u8(&v, Ku16::u2, mb.get(pos));
        /// <li> Increase Ku32::u3 for ::pos.
        pos += Ku32::u3;
        /// <li> Return value.
        return v;
        /// </ul>
    }

    inline int32 U8istream::get_int24_be()
    {
        /// \alg
        /// - Return left and right Ku16::u8 bit shift displacement for the retrieved value by U8istream::get_uint24_be to extend sign.
        return (static_cast<int32>(get_uint24_be()) << Ku16::u8) >> Ku16::u8;

    }

    inline Uint32 U8istream::get_uint32_be()
    {
        /// \alg
        /// <ul>
        /// <li> Get Uint32 retrieved value by U8pkmblock_k::get for ::mb with ::pos+Ku16::u3.
        Uint32 v =                     mb.get(pos+Ku16::u3);
        /// <li> Set value at index Ku16::u1 with value at ::pos+Ku16::u2 memory block position.
        Bitutils::set_u8(&v, Ku16::u1, mb.get(pos+Ku16::u2));
        /// <li> Set value at index Ku16::u2 with value at ::pos+Ku16::u1 memory block position.
        Bitutils::set_u8(&v, Ku16::u2, mb.get(pos+Ku16::u1));
        /// <li> Set value at index Ku16::u3 with value at ::pos memory block position.
        Bitutils::set_u8(&v, Ku16::u3, mb.get(pos));
        /// <li> Increase Ku32::u4 for ::pos.
        pos += Ku32::u4;
        /// <li> Return value.
        return v;
        /// </ul>
    }

    inline int32 U8istream::get_int32_be()
    {
        /// \alg
        /// - Return conversion to signed 32-bit retrieved value by U8istream::get_uint32_be.
        return static_cast<int32>(get_uint32_be());
    }

    inline Real U8istream::get_float32_be()
    {
        /// \alg
        /// <ul>
        /// <li> Get retrieved value by U8istream::get_uint32_be.
        Uint32 aux = get_uint32_be();
        /// <li> Return conversion to Real retrieved value.
        return *reinterpret_cast<Real*>(&aux);
        /// </ul>

    }

    inline Real U8istream::get_float16_be()
    {
        /// \alg
        /// - Return Real16::as_real instance for the retrieved value by U8istream::get_uint16_be.
        return Real16(get_uint16_be()).as_real();
    }

    inline Real U8istream::get_float16_le()
    {
        /// \alg
        /// - Return Real16::as_real instance for the retrieved value by U8istream::get_uint16_le.
        return Real16(get_uint16_le()).as_real();
    }

    inline int64 U8istream::get_int64_be(const Uint16 nbytes)
    {
        /// \alg
        /// - Return left and right nbits_displ bit shift displacement for the retrieved value by U8istream::get_uint64_be to extend sign.
        const Uint16 nbits_displ = Bitutils::bytes_to_bits(Ku16::u8 - nbytes);  // 8 because in int64 are 8 bytes
        return (static_cast<int64>(get_uint64_be(nbytes)) << nbits_displ) >> nbits_displ;
    }
}
#endif
