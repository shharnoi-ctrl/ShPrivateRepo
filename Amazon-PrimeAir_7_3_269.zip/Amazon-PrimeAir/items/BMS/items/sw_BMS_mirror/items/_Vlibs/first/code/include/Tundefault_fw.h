#ifndef TUNDEFAULT_FW_H_
#define TUNDEFAULT_FW_H_

namespace Base
{
    namespace Tuntraits
    {
        /// Default Tuntraits for some type T.
        /// Note that a change in any default behavior can cause tunable incompatibilities.
        template <typename T>
        struct Tundefault;
    }
}
#endif
