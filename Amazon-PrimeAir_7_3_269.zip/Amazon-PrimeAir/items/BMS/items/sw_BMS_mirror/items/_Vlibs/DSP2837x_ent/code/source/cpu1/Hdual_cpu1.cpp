#include <Hdual.h>

namespace Dsp28335_ent
{
    void Hdual::assert_is_cpu1()
    {
    }
}
