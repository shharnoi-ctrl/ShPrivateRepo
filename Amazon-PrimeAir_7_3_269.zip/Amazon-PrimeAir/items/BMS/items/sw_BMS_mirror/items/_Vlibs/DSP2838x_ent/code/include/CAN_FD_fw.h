#ifndef CAN_FD_FW_H_
#define CAN_FD_FW_H_

namespace Dsp28335_ent
{
    class CAN_FD;
}
#endif
