#ifndef IITERATOR_h_
#define IITERATOR_h_

#include <Entypes.h>

namespace Base
{
    template<typename T>
    class Iiterator
    {
    public:
        typedef T type;

        /// \return Number of elements pending in iteration
        virtual Uint16 pending_size() const = 0;

        /// \return Net element or last one if "max" is exceeded.
        virtual T next() = 0;
    };
}
#endif
