///    \file Txet.h
///
///    \date 20 sept. 2017
///
///    \author  FJBurgos, jbm (at) embention.com
///    Company:  Embention
///
///    Txet class declaration.
///

#ifndef TXET_H_
#define TXET_H_

#include <Ttraits.h>

namespace Base
{

    /// Helper class to encapsulate a field of type T with set and get methods.
    template<typename T>
    class Txet
    {
    public:
        /// Txet Constructor.
        /// \wi{5285}
        /// Txet class shall initialize itself upon construction and initialize its internal members.
        Txet();
        /// Txet Constructor.
        /// \wi{17451}
        /// Txet class shall initialize itself upon construction with the specified parameter.
        /// \param[in] v0   Value to initialize its internal value.
        explicit Txet(typename JSF116_param<T>::type v0);
        /// Txet Setter.
        /// \wi{5286}
        /// Txet class shall provide the capability to set the wrapped field to the desired value.
        /// \param[in] v0   Value to set its internal field.
        void set(typename JSF116_param<T>::type v0);

        /// Txet Getter.
        /// \wi{5287}
        /// Txet class shall provide the capability to get the value in the wrapped field.
        /// \return     Value in the field.
        typename JSF116_param<T>::type get() const;

        T value;    ///< Wrapped field value.

    private:
        Txet(const Txet& orig); ///< = delete
        Txet& operator=(const Txet& orig); ///< = delete

    };


    template<typename T>
    inline Txet<T>::Txet() : value()
    {
    }

    template<typename T>
    inline Txet<T>::Txet(typename JSF116_param<T>::type v0) : value(v0)
    {
    }

    template<typename T>
    inline void Txet<T>::set(typename JSF116_param<T>::type v0)
    {
        value=v0;
    }

    template<typename T>
    inline typename JSF116_param<T>::type Txet<T>::get() const
    {
        return value;
    }

} // namespace Base

#endif // TXET_H_
