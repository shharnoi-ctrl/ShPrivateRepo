#ifndef JID_H_
#define JID_H_

#include <Entypes.h>
#include <Rngit.h>
#include <Assertions.h>
#include <Karray.h>
#include <Error.h>

namespace Base
{
    /// The Base library shall provide a helper class for jagged ids creation and manipulation (used by jagged arrays).
    /// \pre The template should define:
    /// - Idtype: A typdef whith the ID type
    /// - szarray: Static array whith an "v" pointer and size() function. (e.g. Tnarray)
    /// - nbits_grp: The amount of bits which represent the ID group (it should be in high part)
    /// - nullid: The ID which represents the null ID.
    template <typename JTRAIT>
    class Jid
    {
    public:
        typedef typename JTRAIT::Idtype Idtype;

        /// Jagged ID Index Group Extractor.
        /// \wi{5080}
        /// Jid class shall provide the capability to extract the index (group) part of the Jagged ID.
        /// \param[in] f Jagged ID from which to extract the index (group).
        /// \return Index (group) extracted from the Jagged ID.
        static Uint16 id2i(Idtype f);

        /// Jagged ID Subindex Extractor.
        /// \wi{5083}
        /// Jid class shall provide the capability to extract the subindex part of the Jagged ID.
        /// \param[in] f Jagged ID from which to extract the subindex.
        /// \return Subindex extracted from the Jagged ID.
        static Uint16 id2s(Idtype f);

        /// Jagged ID Index and Subindex Extractor.
        /// \wi{5084}
        /// Jid class shall provide the capability to extract both the index (group) and subindex from the Jagged ID.
        /// \param[in] f Jagged ID from which to extract the index and subindex.
        /// \param[out] idx Index (group) reference extracted from the Jagged ID.
        /// \param[out] subidx Subindex reference extracted from the Jagged ID.
        static void id2is(Idtype f,
                          Uint16& idx,
                          Uint16& subidx);

        /// Jagged ID Index and Subindex Creator.
        /// \wi{5082}
        /// Jid class shall provide the capability to create a Jagged ID from given index (group) and subindex.
        /// \param[in] idx Index (group) to be used in the Jagged ID.
        /// \param[in] subidx Subindex to be used in the Jagged ID.
        /// \return Jagged ID created from the given index and subindex.
        static Idtype is2id(Uint16 idx, Uint16 subidx);

        /// Jagged ID with Different Subindex Creator.
        /// \wi{5081}
        /// Jid class shall provide the capability to create a Jagged ID from an existing one but with a different subindex.
        /// \param[in] f Existing Jagged ID.
        /// \param[in] subidx New subindex to be used in the Jagged ID.
        /// \return Jagged ID created with the same index as "f" but with the different subindex.
        static Idtype id2id(Idtype f, Uint16 subidx);

        /// Jagged ID Size Retriever.
        /// \wi{5085}
        /// Jid class shall provide the capability to retrieve the sizes of each group.
        /// \return Sizes of each group.
        static const Base::Karray<Uint16>& get_gsizes();

        /// Jagged ID Size Retriever for Given ID.
        /// \wi{5086}
        /// Jid class shall provide the capability to retrieve the size 
        /// of the group corresponding to a given Jagged ID.
        /// \param[in] id Jagged ID for which to get the group size.
        /// \return Size of the group corresponding to the given Jagged ID.
        static Uint16 get_gsize(Idtype id);

        /// Jagged ID Validator.
        /// \wi{5087}
        /// Jid class shall provide the capability to validate the given Jagged ID.
        /// \param[in] id Jagged ID to be validated.
        /// \param[in] def The given templated ID type.
        /// \return Given id if it is valid, else return given default value.
        static Idtype validate(Idtype id, Idtype def=JTRAIT::nullid);

        /// Jagged ID PDI Validator.
        /// \wi{5089}
        /// Jid class shall provide the capability to validate a Jagged ID with a PDI check.
        /// \param[in] id Jagged ID to be validated.
        /// \param[in] err Error object to handle validation errors.
        static void validate_pdicheck(Idtype id, Error& err);

        /// Jagged ID Range Retriever.
        /// \wi{5079}
        /// Jid class shall provide the capability to retrieve the range of 
        /// IDs within the same group as a given Jagged ID.
        /// \param[in] id Jagged ID for which to get the range of IDs in the same group.
        /// \return Range of IDs within the same group as the given Jagged ID.
        static Rngit<Idtype> get_rng_grp(Idtype id);

        /// Jagged ID Size Validator.
        /// \wi{5088}
        /// Jid class shall provide the capability to validate if the subindex of the 
        /// Jagged ID is less than the size of its group.
        /// \param[in] id ID subindex size to be validated.
        /// \return True if subindex of the given Jagged ID is less than the size of its group, false otherwise.
        static bool validate0(Idtype id);

    private:
        /// Number of bits to shift for the group part of the ID computed as 
        /// 16 less the number of bits which represent the group defined into "nbits_grp" of JTRAIT.
        static const Uint16 GrpShift = 16-JTRAIT::nbits_grp;
        ///  Mask for the group part of the ID computed as 0xFFFF bitwise 
        /// left shift of ::GrpShift and a bitwise AND with 0xFFFF.           
        static const Uint16 GrpMask  = (0xFFFF << GrpShift) & 0xFFFF;   
        /// Mask for the subindex part of the ID computed as a bitwise NOT of ::GrpMask.
        static const Uint16 SubMask  = static_cast<Uint16>(~GrpMask);   
    };


    template <typename JTRAIT>
    inline Uint16 Jid<JTRAIT>::id2i(Idtype f)
    {
        /// \alg
        /// - Return the result of right shifting given "f" by ::GrpShift bits.
        return f >> GrpShift;
    }

    template <typename JTRAIT>
    inline Uint16 Jid<JTRAIT>::id2s(Idtype f)
    {
        /// \alg
        /// - Return the result of bitwise AND operation with given "f" and ::SubMask.
        return f & SubMask;
    }

    template <typename JTRAIT>
    inline void Jid<JTRAIT>::id2is(Idtype f,
                                   Uint16& idx,
                                   Uint16& subidx)
    {
        /// \alg
        /// - Call ::id2i with given "f" and store the returned result in given reference "idx".
        idx = id2i(f);
        /// - Call ::id2s with given "f" and store the returned result in given reference "subidx".
        subidx = id2s(f);
    }

    template <typename JTRAIT>
    inline typename Jid<JTRAIT>::Idtype Jid<JTRAIT>::is2id(Uint16 idx, Uint16 subidx)
    {
        /// \alg
        /// <ul>
        /// <li> \f$ (\text{"idx"} \ll \f$ ::GrpShift) \f$ | (\text{"subidx"} \& \f$ ::SubMask).
        /// <li> Return the result from previous operation in casted ::Idtype.
        /// </ul>
        return static_cast<Idtype>((idx << GrpShift) | (subidx & SubMask));
    }

    template <typename JTRAIT>
    inline typename Jid<JTRAIT>::Idtype Jid<JTRAIT>::id2id(Idtype f, Uint16 subidx)
    {
        /// \alg
        /// <ul>
        /// <li> \f$ (\text{"f"} \& \f$ ::GrpMask) \f$ | (\text{"subidx"} \& \f$ ::SubMask).
        /// <li> Return the result from previous operation in casted ::Idtype.
        /// </ul>
        return static_cast<Idtype>(( f & GrpMask) | (subidx & SubMask));
    }

    template <typename JTRAIT>
    const Base::Karray<Uint16>& Jid<JTRAIT>::get_gsizes()
    {
        /// \alg
        /// - Initialize static constant Base::Karray instance "idsizes" with JTRAIT::szarray.
        static const Base::Karray<Uint16> idsizes(JTRAIT::szarray);
        /// - Return "idsizes".
        return idsizes;
    }

    template <typename JTRAIT>
    inline Uint16 Jid<JTRAIT>::get_gsize(Idtype id)
    {
        /// \alg
        /// <ul>
        /// <li> Call ::id2i with given "id" and store the returned result in Uint16 variable "g". 
        Uint16 g = id2i(id);
        /// <li> If "g" is less than the size of JTRAIT::szarray, return the 
        /// value of the element in array JTRAIT::szarray at index "g".
        /// <li> Else return 0.
        /// </ul>
        return (g<JTRAIT::szarray.size()) ? JTRAIT::szarray.v[g] : 0;
    }

    template <typename JTRAIT>
    inline bool Jid<JTRAIT>::validate0(Idtype id) {
        /// \alg
        /// <ul>
        /// <li> If the result of ::id2s with given "id" is less than ::get_gsize with given "id", return True.
        /// <li> Else return False.
        /// </ul>
        return id2s(id) < get_gsize(id);
    }

    template <typename JTRAIT>
    inline typename Jid<JTRAIT>::Idtype Jid<JTRAIT>::validate(Idtype id, Idtype def)
    {
        /// \alg
        /// <ul>
        /// <li> If the result of ::validate0 with given "id" is True, return given "id".
        /// <li> Else return given "def".
        /// </ul>
        return Assertions::runtime(validate0(id)) ? id : def;
    }

    template <typename JTRAIT>
    inline void Jid<JTRAIT>::validate_pdicheck(Idtype id, Error& err)
    {
        /// \alg
        /// - Call ::validate0 with given "id" to check invalid feature error.
        err.assrt(validate0(id), err_jid);
    }

    template <typename JTRAIT>
    inline Rngit<typename JTRAIT::Idtype> Jid<JTRAIT>::get_rng_grp(Idtype id)
    {
        // overflow (get_gsize(id)) should also work
        /// \alg
        /// <ul>
        /// <li> Call Base::Rngit constructor with following parameters and return the result:
        /// <ul>
        /// <li> Retrieved value by ::id2id with given "id" and 0 as parameters.
        /// <li> Retrieved value by ::id2id with "id" and  retrieved value by ::get_gsize for "id" minus 1 as parameters.
        /// </ul>
        /// </ul>
        return Rngit<Idtype>(id2id(id, 0),id2id(id,get_gsize(id)-1));
    }

}

#endif

