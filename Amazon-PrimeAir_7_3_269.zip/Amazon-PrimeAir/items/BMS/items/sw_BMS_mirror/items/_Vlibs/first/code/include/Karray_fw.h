///    \file Karray_fw.h
///
///    \date 7 jun. 2018
///
///    \author  FJBurgos, jbm (at) embention.com
///    Company:  Embention
///
///    Karray_fw class declaration.
///

#ifndef KARRAY_FW_H_
#define KARRAY_FW_H_

namespace Base
{

    template<typename T>
    class Karray;

} // namespace Base

#endif // KARRAY_FW_H_
