#ifndef CHRONO32_H_
#define CHRONO32_H_

#include <Htime.h>

namespace Base
{
    /// \brief Time chrono with 32bit integer representation.
    /// Limited to ~10s @ 200Mhz
    class Chrono32
    {
    public:
        inline Chrono32()  ///< Automatically starts the chrono
        {
            tic();
        }

        inline void tic()       ///< Resets chrono to zero
        {
            tk0=Bsp::Htime::get_time32();
        }

        inline Ttime32 toc() const///< \return Elapsed time
        {
            return Bsp::Htime::get_time32()-tk0;
        }
    private:
        Ttime32 tk0;          ///< Initial time

        Chrono32(const Chrono32& src); ///< = delete
        Chrono32& operator=(const Chrono32& orig); ///< = delete
    };
}
#endif
