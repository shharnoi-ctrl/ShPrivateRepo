///    \file SPSCtraits.h
///
///    \date 2 jul. 2018
///
///    \author  FJBurgos, jbm (at) embention.com
///    Company:  Embention
///
///    SPSCtraits class declaration.
///

#ifndef SPSCTRAITS_H_
#define SPSCTRAITS_H_

#include <SPSCtraits_fw.h>

namespace Base
{

    namespace SPSCtraits
    {

        template <typename T>
        struct SPSC0
        {
            typedef T Fftype_ptr;                                               ///< Type of member variable.
            typedef typename Remove_reference<Fftype_ptr>::type  Fftype_tmp;    ///< Type of temporary value.
        };

        /// reference no managed by fifo
        template <typename T>
        struct External : SPSC0<const T* const volatile&>
        {
        };

        /// reference managed by fifo
        template <typename T>
        struct Internal_ref : SPSC0<T* volatile&>
        {
        };

        /// internally instantiated and managed by fifo
        template <typename T>
        struct Internal : SPSC0<T* volatile>
        {
        };

        template <template<typename> class SPSCtrait>
        struct Add_reference_to_trait
        {
            template <typename T>
            struct Template : SPSC0<typename SPSCtrait<T>::Fftype_ptr&>
            {
            };
        };


    };

} // namespace Base

#endif // SPSCTRAITS_H_
