#ifndef XCUVAR_H_
#define XCUVAR_H_

#include <Mblock.h>
#include <Uvar.h>
#include <Tcopy.h>
#include <Cptraits.h>
#include <Assertions.h>

namespace Bsp
{

    /// Uvar handler
    class Huvar
    {
    public:
        class Range
        {
        public:
            /// Constructor with Given Parameters.
            /// \wi{18225}
            /// Range class shall build itself upon construction with its memory location range.
            /// \param[in] mb           Memory block.
            /// \param[in] from         Start range.
            /// \param[in] to_inclusive End range.
            Range(Base::Mblock<const volatile Uint16> mb,
                  Base::Uvar from,
                  Base::Uvar to_inclusive);
            
            /// Data Commiter.
            /// \wi{18226}
            /// Range class shall be able to copy the internal range data to its final memory allocation.
            void commit();

        private:
            /// Define Type_cp as a typedef representing a type capable of copying data between memory blocks
            /// of constant volatile Uint16 and volatile Uint16 types.
            typedef Base::Tcopy<Base::Cptraits::Array_memcpy16<
                Base::Mblock<const volatile Uint16>,
                Base::Mblock<volatile Uint16> > > Type_cp;
            /// Instantiate a Copy trait object which is able to write a memory block from a source to a destination.
            Type_cp cp;
        
            Range();                                ///< = delete
            Range& operator=(const Range& orig);    ///< = delete
        };
        
        /// Huvar Constructor.
        /// \wi{18227}
        /// Huvar class shall build itself upon construction with given variable ID.
        /// \param[in] id0 Variable Index to be accessed (Base::Uvar).
        explicit Huvar(Base::Uvar id0);

        /// Huvar Variable Updater.
        /// \wi{7973}
        /// Huvar class shall provide a method to set set the value for a variable ID.
        /// \param[in] v0 Variable value to be set.
        void set(Uint16 v0);

        /// Huvar Variable Retriever.
        /// \wi{7969}
        /// Huvar class shall provide a method to get the value for a variable ID.
        /// \return Variable value.
        Uint16 get() const;

         /// Volatile Reference Retriever.
        /// \wi{18235}
        /// Huvar class shall be able to retrieve a volatile reference to a given Unsigned variable ID value.
        /// \return Variable reference from shared memory.
        /// \pre This function will be implemented in all cores with write access to given shared memory.
        volatile Uint16& get_ref() const;

        /// Constant Volatile Reference Retriever.
        /// \wi{7966}
        /// Huvar class shall be able to retrieve a constant and volatile reference 
        /// to a given Unsigned variable ID value.
        /// \return Variable value reference.
        /// \pre This function will be implemented in all cores with read access to given memory block.
        const volatile Uint16& get_kref() const;

        /// Constant Volatile Memory Block Retriever.
        /// \wi{18356} 
        /// Huvar class shall be able to retrieve a constant and volatile memory block 
        /// from a given range of Unsigned variable ID.
        /// \param[in] from Starting Unsigned variable ID of the memory block.
        /// \param[in] to_inclusive Ending Unsigned variable ID of the memory block.
        /// \return Variable value references to the specified range.
        /// \pre This function will be implemented in all cores with read access to the given memory block.
        static Base::Mblock<const volatile Uint16> get_kblock(Base::Uvar from, Base::Uvar to_inclusive);

        /// Volatile Memory Block Retriever.
        /// \wi{18357} 
        /// Huvar class shall be able to retrieve a volatile memory block 
        /// from a given range of Unsigned variable ID.
        /// \param[in] from Starting Unsigned variable ID of the memory block.
        /// \param[in] to_inclusive Ending Unsigned variable ID of the memory block.
        /// \return Variable value references to the specified range.
        /// \pre This function will be implemented in all cores with write access to the given memory block.
        static Base::Mblock<volatile Uint16> get_block(Base::Uvar from, Base::Uvar to_inclusive);

    private:
        const Base::Uvar id;

        // disabled
        Huvar();                                ///< = delete
        Huvar(const Huvar& orig);               ///< = delete
        Huvar& operator=(const Huvar& orig);    ///< = delete
    };

    inline void Huvar::Range::commit()
    {
        /// \alg
        ///  - Call to Tcopy::copy for ::cp, which bulks data from source memory block to destination memory block.
        cp.copy();
    }

}
#endif
