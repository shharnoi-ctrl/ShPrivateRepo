#ifndef HREGMAP_H_
#define HREGMAP_H_

#include <Entypes.h>

namespace Dsp28335_ent
{
    /// Memory mapped hardware register.
    struct Hregmap
    {
    public:
        template <typename T, Uint32 addr>
        static volatile T& get();

        template <typename T, Uint32 addr>
        class Handler
        {
        public:
            volatile T& regs;
            Handler();

        private:
            Handler(const Handler& orig); ///< = delete
            Handler& operator=(const Handler& orig); ///< = delete
        };

    private:
        Hregmap(); // = delete
        Hregmap(const Hregmap& orig); // = delete
        Hregmap& operator=(const Hregmap& orig); // = delete
    };

    template <typename T, Uint32 addr>
    inline volatile T& Hregmap::get()
    {
        return (*reinterpret_cast<volatile T*>(addr));
    }

    template <typename T, Uint32 addr>
    inline Hregmap::Handler<T, addr>::Handler() : regs(Hregmap::get<T, addr>())
    {
    }
}
#endif
