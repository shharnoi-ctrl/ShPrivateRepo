#include <U8pkfifospsc.h>

namespace Base
{
    U8pkfifospsc::U8pkfifospsc(Uint32 sz, Memmgr::Type mtype) :
        v(sz + 1U, mtype), // In circular buffers the real container size is one less than the buffer size
        rd(0),
        wr(0),
        fifo(v, rd, wr)
    {
    }
}
