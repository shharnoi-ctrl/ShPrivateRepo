#ifndef U16STREAM_R_H_
#define U16STREAM_R_H_

#include <Mblock.h>

namespace Base
{
    /// The ::Base library shall provide the capability to read Unsigned 16-bit for an input byte stream. 
    /// Assumes little endian memory configuration.
    /// JSF rule Rule 210 exception allows for endianness assumptions in marshalling (serialization).
    class U16stream_r
    {
    public:
        /// U16stream_r Constructor with Given Data Buffer.
        /// \wi{18111}
        /// U16stream_r class shall build itself upon construction with the provided parameter.
        /// \param[in] data0     16-bit stream memory block.
        explicit U16stream_r(const Mblock<Uint16>& data0);

        /// U16stream_r Constructor with Constant Given Data Buffer.
        /// \wi{18112}
        /// U16stream_r class shall build itself upon construction with the constant provided parameter.
        /// \param[in] data0     Constant 16-bit stream memory block.
        explicit U16stream_r(const Mblock<const Uint16>& data0);

        // TODO: Remove this when lossy is removed from Itunable
        /// U16stream_r Constant Stream Retriever.
        /// \wi{18113}
        /// U16stream_r shall be able to retrieve its internal memory block.
        /// \return Constant internal memory block.
        const Mblock<const Uint16>& to_mblock_all() const;
        /// U16stream_r Maximum Stream Size Retriever.
        /// \wi{18114}
        /// U16stream_r shall be able to retrieve the maximum size readable of its internal stream.
        /// \return Maximum size of its internal stream.
        Uint32 get_max_size() const;

        /// U16stream_r Position Retriever.
        /// \wi{18115}
        /// U16stream_r class shall be able to retrieve its internal position.
        /// \return Current read position.
        Uint32 get_pos() const;
        /// U16stream_r Data Position Setter.
        /// \wi{18116}
        /// U16stream_r class shall provide the capability to set the position for the stream.
        /// \param[in] pos      Stream position.
        void set_pos(Uint32 pos);
        /// U16stream_r End Data Position Setter.
        /// \wi{18117}
        /// U16stream_r class shall provide the capability to set the position to the last element of the stream.
        void seek_end();

        /// U16stream_r Zero Position Setter.
        /// \wi{18118}
        /// U16stream_r class shall provide the capability to set its internal position to 0.
        void reuse();

        /// U16stream_r Bool Uint16 Retriever.
        /// \wi{18119}
        /// U16stream_r shall be able to retrieve the next Uint16 as boolean for its internal stream and increment position by 1.
        /// \return Current Uint16 boolean value.
        bool   get_bool16();
        /// U16stream_r Unsigned 16-bit Retriever.
        /// \wi{18120}
        /// U16stream_r shall be able to retrieve the current Uint16 for its internal stream and increment position by 1.
        /// \return Current Uint16.
        Uint16 get_uint16();
         /// U16stream_r Signed 16-bit Retriever.
         /// \wi{18121}
         /// U16stream_r shall be able to retrieve the current int16 for its internal stream and increment position by 1.
         /// \return Current int16.
         int16  get_int16();
        /// U16stream_r Unsigned 32-bit Retriever.
        /// \wi{18122}
        /// U16stream_r shall be able to retrieve the current Uint32 for its internal stream and increment position by 2.
        /// \return Current Uint16.
        Uint32 get_uint32();
         /// U16stream_r Signed 32-bit Retriever.
         /// \wi{18123}
         /// U16stream_r shall be able to retrieve the current int32 for its internal stream and increment position by 2.
         /// \return Current int32.
         int32  get_int32();
        /// U16stream_r Unsigned 64-bit Retriever.
        /// \wi{18124}
        /// U16stream_r shall be able to retrieve the current Uint64 for its internal stream and increment position by 4.
        /// \return Current Uint64.
        Uint64 get_uint64();
         /// U16stream_r Signed 64-bit Retriever.
         /// \wi{18125}
         /// U16stream_r shall be able to retrieve the current int64 for its internal stream and increment position by 4.
         /// \return Current int64.
         int64  get_int64();
        
        /// U16stream_r Real 32-bit Retriever.
        /// \wi{18126}
        /// U16stream_r shall be able to retrieve the current Real for its internal stream and increment position by 2.
        /// \return Current Real.
        Real   get_float();
        /// U16stream_r Real 64-bit Retriever.
        /// \wi{18127}
        /// U16stream_r shall be able to retrieve the current Real64 for its internal stream and increment position by 4.
        /// \return Current Real64.
        Real64 get_float64();

        /// U16stream_r 16-bit Enumerator Deserializer.
        /// \wi{18128}
        /// U16stream_r class shall be able to deserialize 16 bits from the internal stream of data and retrieve them as a
        /// 16-bit given enumerator type value and increment position by 1.
        /// \param[in,out] v        Read data as a 16-bit given enumerator type value.
        template<typename E>
        void get_enum16(E& v);

        /// Read a data block. T size must be multiple of 2 bytes

        /// U16stream_r Memory Block Enumerator Deserializer.
        /// \wi{18129}
        /// U16stream_r class shall be able to deserialize a memory block, multiple of 16 bits, from the internal stream of data 
        /// and retrieve them as a memory block given enumerator type value and increment position by 1.
        /// \param[in,out] dst      Read data as a memory block given enumerator type value.
        template<typename T>
        void get(const Mblock<T>& dst);

        // Policies are defined in Tuntraits.h
        /// U16stream_r Put Type Serializer.
        /// \wi{18130}
        /// U16stream_r class shall provide a function to serialize an object following a given policy.
        /// \param[in] dst          Element to be serialized.
        template <typename POLICY>
        void get_t(typename POLICY::type& dst);

    private:
        const Mblock<const Uint16> data;            ///< Data buffer.
        Uint32 pos;                                 ///< Current read position in words of 16 bits.

        U16stream_r(const U16stream_r&); ///< = delete
        U16stream_r& operator=(const U16stream_r&); ///< = delete
    };

    inline U16stream_r::U16stream_r(const Mblock<Uint16>& data0) :
        data(data0),
        pos(0)
    {
    }

    inline U16stream_r::U16stream_r(const Mblock<const Uint16>& data0) :
        data(data0),
        pos(0)
    {
    }

    inline const Mblock<const Uint16>& U16stream_r::to_mblock_all() const
    {
        /// \alg
        /// - Return ::data.
        return data;
    }

    inline Uint32 U16stream_r::get_max_size() const
    {
        /// \alg
        /// - Return Mblock::size retrieved value for ::data.
        return data.size();
    }

    inline Uint32 U16stream_r::get_pos() const
    {
        /// \alg
        /// - Return ::pos.
        return pos;
    }

    inline void U16stream_r::set_pos(Uint32 pos0)
    {
        /// \alg
        /// <ul>
        /// <li> Call to Assertions::runtime with result of the '<' comparison between: 
        /// <ul>
        /// <li> Position received parameter.
        /// <li> Retrieved value by Mblock::size for ::data.
        /// </ul>
        /// <li> IF retrieved value is True:
        if(Assertions::runtime(pos0 < data.size()))
        {
            /// <ul>
            /// <li> Set ::pos to received parameter.
            /// </ul>
            pos = pos0;
        }
    }

    inline void U16stream_r::seek_end()
    {
        /// \alg
        /// - Set ::pos to retrieved value by Mblock::size - 1 for ::data.
        pos = (data.size() - Ku32::u1);
    }

    inline void U16stream_r::reuse()
    {
        /// \alg
        /// Set ::pos to 0.
        pos = 0;
    }

    inline bool U16stream_r::get_bool16()
    {
        /// \alg
        /// - Return True if retrieved value by U16stream_r::get_uint16 is different from 0. 
        return get_uint16() != 0;
    }

    inline Uint16 U16stream_r::get_uint16()
    {
        /// \alg
        /// - Return value from ::data at position ::pos.
        /// - Increment position by 1.
        return data[pos++];
    }

    inline int16 U16stream_r::get_int16()
    {
        /// \alg
        /// - Return conversion to signed 16-bit retrieved value by U16stream_r::get_uint16.
        return static_cast<int16>(get_uint16());
    }

    inline Uint32 U16stream_r::get_uint32()
    {
        // due to addressing limitations, C2000 can not perform:
        //   d = *reinterpret_cast<const Uint32*>(data.v+pos);
        // So we copy word by word
        const Uint32 res = static_cast<Uint32>(get_uint16());
        return (static_cast<Uint32>(get_uint16()) << Ku16::u16) | res;
    }

    inline int32 U16stream_r::get_int32()
    {
        /// \alg
        /// - Return conversion to signed 32-bit retrieved value by U16stream_r::get_uint32.
        return static_cast<int32>(get_uint32());
    }

    inline int64 U16stream_r::get_int64()
    {
        /// \alg
        /// - Return conversion to signed 64-bit retrieved value by U16stream_r::get_uint64.
        return static_cast<int64>(get_uint64());
    }

    inline Real U16stream_r::get_float()
    {
        /// \alg
        /// - Return conversion to Real retrieved value by U16stream_r::get_uint32.
        Uint32 res = get_uint32();
        return *reinterpret_cast<Real*>(&res);
    }

    inline Real64 U16stream_r::get_float64()
    {
        /// \alg
        /// - Return conversion to Real64 retrieved value by U16stream_r::get_uint64.
        Uint64 res = get_uint64();
        return *reinterpret_cast<Real64*>(&res);
    }

    template<typename E>
    inline void U16stream_r::get_enum16(E& v)
    {
        Assertions::Compile_time<sizeof(E) >= sizeof(Uint16)>();
        v = static_cast<E>(get_uint16());
    }

    template<typename T>
    inline void U16stream_r::get(const Mblock<T>& dst)
    {
        Assertions::Compile_time<(size_bytes_t<T>::value & 1) == 0>(); // Only multiple of 2 bytes are allowed
        const Uint32 sz = Rfun::min<Uint16>(dst.size()*sizeof(T), data.sz-pos);
        Tmem::cpy_sel(dst.v, data.v+pos, sz);
        pos += sz;
    }

    template<typename POLICY>
    inline void U16stream_r::get_t(typename POLICY::type& dst)
    {
        /// \alg
        /// - Call to str2elem function for given policy using as arguments the instance received and this U16stream_r
        /// instance.
        POLICY::str2elem(dst, *this);
    }
}
#endif
