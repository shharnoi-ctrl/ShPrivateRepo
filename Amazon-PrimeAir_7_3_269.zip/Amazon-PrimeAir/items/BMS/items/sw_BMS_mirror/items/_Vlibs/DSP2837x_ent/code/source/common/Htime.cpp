#include <Htime.h>
#include <Hregister.h>

namespace Bsp
{
    ///< Low memory address of IPC counter control register.
    static const Uint32 reg_ipc_counter_l_addr = 0x05000CUL;
    ///< High memory address of IPC counter control register.
    static const Uint32 reg_ipc_counter_h_addr = 0x05000EUL;

    using namespace Base;
    ///< High memory of IPC counter control register.
    static Hregister<Uint32, Mutator_rdo, reg_ipc_counter_h_addr, 0, 32> reg_ipc_counter_h;
    ///< Low memory of IPC counter control register.
    static Hregister<Uint32, Mutator_rdo, reg_ipc_counter_l_addr, 0, 32> reg_ipc_counter_l;

    Base::Ttime Htime::get_time()
    {
        // TI doc:
        // When IPCCOUNTERL is read, the value of
        // IPCCOUNTERH is saved. A subsequent read to IPCCOUNTERH returns this saved value.

        // TI forum: https://e2e.ti.com/support/microcontrollers/c2000/f/171/t/550951
        // It says that if another CPU reads IPCCOUNTERL, IPCCOUNTERH is latched again, so,
        // invalid read is still possible.

        /// \alg
        /// <ul>
        /// <li> Call Hregister::read for ::reg_ipc_counter_l.
        Uint32 lo0 = reg_ipc_counter_l.read();
        /// <li> Call Hregister::read for ::reg_ipc_counter_h.
        Uint32 hi = reg_ipc_counter_h.read();

        /// <li> Call again Hregister::read for ::reg_ipc_counter_l.
        Uint32 lo = reg_ipc_counter_l.read();
        /// <li> If overflow.
        if(lo<lo0)
        {
            /// <ul>
            /// <li> Call Hregister::read for ::reg_ipc_counter_h.
            hi = reg_ipc_counter_h.read();
            /// </ul>
        }
        /// <li> Return signed 64-bits integer as a combination of retrieved low registry and high registry.
        return Base::Ttime(static_cast<int64>( (static_cast<Uint64>(hi)<<32) | lo));
        /// </ul>
    }

    Base::Ttime32 Htime::get_time32()
    {
        /// \alg
        /// - Return conversion to signed 32-bit retrieved value by Hregister::read for ::reg_ipc_counter_l.
        return Base::Ttime32(static_cast<int32>(reg_ipc_counter_l.read()));
    }
}
