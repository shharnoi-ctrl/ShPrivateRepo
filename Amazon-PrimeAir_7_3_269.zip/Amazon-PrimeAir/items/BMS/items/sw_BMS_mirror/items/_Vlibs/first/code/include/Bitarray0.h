#ifndef BITARRAY0_H_
#define BITARRAY0_H_

#include <Bitutils.h>
#include <Mblock.h>

namespace Base
{
    /// Base class for packed array of bits.
    template <typename ARRAY>
    struct Bitarray0
    {
    public:
        /// Array of Bits Getter.
        /// \wi{4960}
        /// Bitarray0 class shall be able to retrieve the value of given bit index as a boolean value.
        /// \param[in] i Array of bits index.
        /// \return Boolean value of given index in bits.
        bool get(Uint16 i) const;
        /// Array of Bits Volatile Getter.
        /// \wi{17651}
        /// Bitarray0 class shall be able to retrieve the value of a given bit index as a boolean value in a
        /// volatile way.
        /// \param[in] i Array of bits index.
        /// \return Boolean value of given index in bits.
        bool get(Uint16 i) const volatile;
        /// Array of Bits Setter.
        /// \wi{4962}
        /// Bitarray0 class shall be able to set to 1 the bit value of given bit index.
        /// \param[in] i Array of bits index to be set.
        void set(Uint16 i);
        /// Array of Bits Volatile Setter.
        /// \wi{17652}
        /// Bitarray0 class shall be able to set to 1 the bit value of a given bit index in a volatile way.
        /// \param[in] i Array of bits index.
        void set(Uint16 i) volatile;
        /// Array of Bits Clearer.
        /// \wi{4964}
        /// Bitarray0 class shall be able to set to 0 the bit value of a given bit index.
        ///  \param[in] i Array of bits index.
        void clear(Uint16 i);
        /// Array of Bits Value Setter.
        /// \wi{17653}
        /// Bitarray0 class shall be able to set to given value the bit of a given bit index.
        /// \param[in] i Array of bits index.
        /// \param[in] value Value to be set into the given bit index (true: 1, false: 0).
        void set(Uint16 i, bool value);

    protected:

        ARRAY v;    ///< Array to manage as bit array.

        /// Array Word Retriever.
        /// \wi{4965}
        /// Bitarray0 class shall be able to retrieve the word where given bit index is in.
        /// \param[in] idx_bit Bit index from retrieve a word.
        /// \return Word reference into array from a given bit index.
        Uint16& get_word(Uint16 idx_bit);
        /// Array Word Volatile Retriever.
        /// \wi{17654}
        /// Bitarray0 class shall be able to retrieve the word where given bit index is in, in a volatile way.
        /// \param[in] idx_bit Bit index from retrieve a word.
        /// \return Volatile word reference into array from a given bit index.
        volatile Uint16& get_word(Uint16 idx_bit) volatile;
        /// Array Word Constant Retriever.
        /// \wi{17655}
        /// Bitarray0 class shall be able to retrieve the constant word where given bit index is in.
        /// \param[in] idx_bit Bit index from retrieve a word.
        /// \return Constant word reference into array from a given bit index.
        const Uint16& get_word(Uint16 idx_bit) const;
        /// Array Word Constant Volatile Retriever.
        /// \wi{17656}
        /// Bitarray0 class shall be able to retrieve the constant word where given bit index is in, in a volatile way.
        /// \param[in] idx_bit Bit index from retrieve a word.
        /// \return Constant volatile word reference into array from a given bit index.
        const volatile Uint16& get_word(Uint16 idx_bit) const volatile;
        /// Bit Array Mask Retriever.
        /// \wi{4961}
        /// Bitarray0 class shall be able to retrieve the mask associated to a given bit index into its word it
        /// belongs.
        /// \param[in] idx_bit Bit index from retrieve a word.
        /// \return Mask for given bit index where only given bit position is 1.
        static Uint16 get_msk(Uint16 idx_bit);
    };


    template <typename ARRAY>
    inline bool Bitarray0<ARRAY>::get(Uint16 i) const
    {
        return (get_word(i) & get_msk(i))!=0;
    }

    template <typename ARRAY>
    inline bool Bitarray0<ARRAY>::get(Uint16 i) const volatile
    {
        return (get_word(i) & get_msk(i)) != 0;
    }

    template <typename ARRAY>
    inline void Bitarray0<ARRAY>::set(Uint16 i)
    {
        get_word(i) |= get_msk(i);
    }

    template <typename ARRAY>
    inline void Bitarray0<ARRAY>::set(Uint16 i) volatile
    {
        get_word(i) |= get_msk(i);
    }

    template <typename ARRAY>
    inline void Bitarray0<ARRAY>::clear(Uint16 i)
    {
        get_word(i) &= ~get_msk(i);
    }

    template <typename ARRAY>
    inline void Bitarray0<ARRAY>::set(Uint16 i, bool value)
    {
        value ? set(i) : clear(i);
    }

    template <typename ARRAY>
    inline Uint16& Bitarray0<ARRAY>::get_word(Uint16 idx_bit) //PRQA S 4211 #const
    {
        return v[idx_bit>>Ku16::u4];
    }

    template <typename ARRAY>
    inline volatile Uint16& Bitarray0<ARRAY>::get_word(Uint16 idx_bit) volatile //PRQA S 4211 #const
    {
        return v[idx_bit>>Ku16::u4];
    }

    template <typename ARRAY>
    inline const Uint16& Bitarray0<ARRAY>::get_word(Uint16 idx_bit) const
    {
        return v[idx_bit>>Ku16::u4];
    }

    template <typename ARRAY>
    inline const volatile Uint16& Bitarray0<ARRAY>::get_word(Uint16 idx_bit) const volatile
    {
        return v[idx_bit>>Ku16::u4];
    }

    template <typename ARRAY>
    inline Uint16 Bitarray0<ARRAY>::get_msk(Uint16 idx_bit)
    {
        return Bitutils::get_mask_1bit<Uint16>(idx_bit & Ku16::u0x0F);
    }
}
#endif
