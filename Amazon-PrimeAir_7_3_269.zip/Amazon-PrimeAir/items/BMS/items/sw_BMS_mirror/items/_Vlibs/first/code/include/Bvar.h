#ifndef BVAR_H__
#define BVAR_H__

#include <Range.h>

namespace Base
{
    /// System BIT (bvar) variables.
    /// \wi{9002}
    /// Bvar variables shall identify a Veronte boolean system variable with a Uint16 number.
    enum Bvar
    {
        kbit_fail         =   0,    ///< (0) Always fail.
        kbit_ok           =   1,    ///< (1) Always ok.
        kbit_license      =   2,    ///< (2) License check result.
        kbit_start        =   3,    ///< (3) System general startup BIT code.
        kbit_fdr_wr       =   4,    ///< (4) Fdr not writing code.
        kbit_power        =   5,    ///< (5) General Power BIT
        kbit_file_system  =   6,    ///< (6) File system code.
        kbit_system_ok    =   7,    ///< (7) System wide BIT. Written by deadman generator (Arbiter class)
        kbit_memory_alloc =   8,    ///< (8) Indicates memory allocation is ok.
        kbit_pdi          =   9,    ///< (9) PDI correct
        kbit_ciolo_c2_ok  =  10,    ///< (10) All threads running at specified frequencies. DEPRECATED
        kbit_can_4x       =  11,    ///< (11) 4x CAN failed

        kbit_pbit         =  12,    ///< (12) Power up Built in Test result
        kbit_is_wr_reset_allowed
                          =  13,    ///< (13) When true, indicates that reset and non-operation PDI writes are allowed.
        kbit_fts1_fb      =  14,    ///< (14) FTS-1 Feedback (V4.5)
        kbit_fts2_fb      =  15,    ///< (15) FTS-2 Feedback (V4.5)
        kbit_stack        =  16,    ///< (16) Stack CPU1 usage Ok
        kbit_stack_c2     =  17,    ///< (17) Stack CPU2 Ok
        kbit_pdi_mode     =  18,    ///< (18) PDI mode active
        kbit_ngncsim_mode =  19,    ///< (19) Not GNC simulation mode (all calibrations and sensor rotations disabled)
        //Exclusive variables for Arbiter CPU when read in another device.
        kbit_arb_sys_ok     = 20,   ///< (20) 4XV System wide BIT.
        kbit_arb_pbit       = 21,   ///< (21) 4XV Power up Built in Test result
        kbit_arb_pdi        = 22,   ///< (22) 4XV PDI
        kbit_arb_mem_alloc  = 23,   ///< (23) 4XV Memory allocation
        kbit_arb_cana_on    = 24,   ///< (24) 4XV CAN A Bus on.
        kbit_arb_canb_on    = 25,   ///< (25) 4XV CAN B Bus on.
        kbit_arb_task_c1    = 26,   ///< (26) 4XV CPU1 main task error
        kbit_arb_task_acq   = 27,   ///< (27) 4XV Acquisition task real time error.
        kbit_arb_pwr_a      = 28,   ///< (28) 4XV Power A
        kbit_arb_in_mtn     = 29,   ///< (29) 4XV Arbiter Maintenance Mode
        //
        kbit_arb_alv_ap0    = 30,   ///< (30) 4XV Autopilot 0 Alive
        kbit_arb_alv_ap1    = 31,   ///< (31) 4XV Autopilot 1 Alive
        kbit_arb_alv_ap2    = 32,   ///< (32) 4XV Autopilot 2 Alive
        kbit_arb_alv_ap3    = 33,   ///< (33) 4XV External autopilot Alive
        kbit_arb_rdy_ap0    = 34,   ///< (34) 4XV Autopilot 0 Ready
        kbit_arb_rdy_ap1    = 35,   ///< (35) 4XV Autopilot 1 Ready
        kbit_arb_rdy_ap2    = 36,   ///< (36) 4XV Autopilot 2 Ready
        kbit_arb_rdy_ap3    = 37,   ///< (37) 4XV External autopilot Ready
        kbit_arb_rdy        = 38,   ///< (38) 4XV Arbiter Ready
        //
        kbit_arb_files      = 39,   ///< (39) 4XV File system code
        kbit_arb_pdi_ver    = 40,   ///< (40) 4XV PDI compatible with current version.
        kbit_arb_stack      = 41,   ///< (41) 4XV Stack CPU usage Ok
        //
        kbit_arb_gpio_pwm1  = 42,   ///< (42) 4XV GPIO/PWM  1 read value
        kbit_arb_gpio_pwm2  = 43,   ///< (43) 4XV GPIO/PWM  2 read value
        kbit_arb_gpio_pwm3  = 44,   ///< (44) 4XV GPIO/PWM  3 read value
        kbit_arb_gpio_pwm4  = 45,   ///< (45) 4XV GPIO/PWM  4 read value
        kbit_arb_gpio_pwm5  = 46,   ///< (46) 4XV GPIO/PWM  5 read value

        //Exclusive variables for Arbiter CPU. Managed by Arbiter4x_fb
        kbit_arb_wd         = 47,   ///< (47) 4XV Watchdog ok. (v4.7+)

        kbit_cpu_temp_warn=  49,    ///< (49) Veronte CPU temperature warning: over 398.15K (125 celsius)
        kbit_sensors      =  50,    ///< (50) Sensors ok: IMU0, IMU1, Mag0 or Mag2, Stp1, Qinf, and external I2C devices
        kbit_s_imu0       =  51,    ///< (51) IMU0
        kbit_s_imu1       =  52,    ///< (52) IMU1
        kbit_s_mag0       =  53,    ///< (53) Mag0 - Internal LIS3MDL

        kbit_s_mag2       =  55,    ///< (55) Mag2 - External LIS3MDL
        kbit_s_stp0       =  56,    ///< (56) Stp0
        kbit_s_stp1       =  57,    ///< (57) Stp1
        kbit_s_qinf       =  58,    ///< (58) Qinf
        kbit_s_i2c_devs   =  59,    ///< (59) External I2C devices
        kbit_s_i2c_dev0   =  60,    ///< (60) External I2C device 0
        kbit_s_i2c_dev1   =  61,    ///< (61) External I2C device 1
        kbit_s_i2c_dev2   =  62,    ///< (62) External I2C device 2
        kbit_s_i2c_dev3   =  63,    ///< (63) External I2C device 3
        kbit_s_i2c_dev4   =  64,    ///< (64) External I2C device 4
        kbit_scia_tx      =  65,    ///< (65) SCI A transmitting during last check period. (Sara)
        kbit_scia_rx      =  66,    ///< (66) SCI A receiving during last check period.    (Sara)
        kbit_scib_tx      =  67,    ///< (67) SCI B transmitting during last check period. (Radio)
        kbit_scib_rx      =  68,    ///< (68) SCI B receiving during last check period.    (Radio)
        kbit_scic_tx      =  69,    ///< (69) SCI C transmitting during last check period. (RS485)
        kbit_scic_rx      =  70,    ///< (70) SCI C receiving during last check period.    (RS485)
        kbit_scid_tx      =  71,    ///< (71) SCI D transmitting during last check period. (RS232)
        kbit_scid_rx      =  72,    ///< (72) SCI D receiving during last check period.    (RS232)
        kbit_cana_bus_on  =  73,    ///< (73) CAN A Bus on.
        kbit_canb_bus_on  =  74,    ///< (74) CAN B Bus on.
        kbit_cana_warning =  75,    ///< (75) CAN A warning.
        kbit_canb_warning =  76,    ///< (76) CAN B warning.
        kbit_vn300_gpsfix =  77,    ///< (77) Vectornav VN-300 GPS fix
        kbit_vn300_imuerr =  78,    ///< (78) Vectornav VN-300 imu error
        kbit_vn300_mperr  =  79,    ///< (79) Vectornav VN-300 mag/press error
        kbit_vn300_gpserr =  80,    ///< (80) Vectornav VN-300 gps error
        kbit_extnavvn300  =  81,    ///< (81) External navigation from VN300 ok
        kbit_s_mag3       =  82,    ///< (82) Mag3 - External HSCDTD008A
        kbit_s_imu2       =  83,    ///< (83) IMU2 BMI088 MCBSP (V4.5)
        kbit_s_stp2       =  84,    ///< (84) STP2 - DPS310 sensor BIT
        kbit_s_mag4       =  85,    ///< (85) Mag4 - MMC5883MA internal V4.5 sensor BIT
        kbit_s_mag5       =  86,    ///< (86) Mag5 - MMC5883MA external sensor BIT
        kbit_s_ubx0       =  87,    ///< (87) Ublox 0 sensor BIT
        kbit_s_ubx1       =  88,    ///< (88) Ublox 1 sensor BIT
        kbit_s_mag6       =  89,    ///< (89) Mag6 - RM3100 external sensor BIT
        kbit_s_imu3       =  90,    ///< (90) IMU3 ADIS16505-3 (MCBSP)
        kbit_s_mag7       =  91,    ///< (91) Mag7 - RM3100 internal sensor BIT
        kbit_s_mag8       =  92,    ///< (92) Mag8 - RESERVED internal sensor BIT
        kbit_sci_exp      =  93,    ///< (93) SCI Expander
        kbit_trspd        =  94,    ///< (94) Internal TT-SC1a I2C transponder

        kbit_scia_rx_ok   =  96,    ///< (96) SCI A error on receiving
        kbit_scib_rx_ok   =  97,    ///< (97) SCI B error on receiving
        kbit_scic_rx_ok   =  98,    ///< (98) SCI C error on receiving
        kbit_scid_rx_ok   =  99,    ///< (99) SCI D error on receiving
        //
        kbit_gpsnav       = 100,    ///< (100) Gps navigation code.
        kbit_srtm         = 101,    ///< (101) SRTM source ok
        kbit_cana_rx      = 102,    ///< (102) CAN A RX code.
        kbit_canb_rx      = 103,    ///< (103) CAN B RX code.
        kbit_cap_a        = 104,    ///< (104) CAP A code.
        kbit_cap_b        = 105,    ///< (105) CAP B code.
        kbit_magfield     = 106,    ///< (106) Magfield measured check ok.
        kbit_insnav       = 107,    ///< (107) Navigation with INS.
        kbit_cap_c        = 108,    ///< (108) CAP C code.
        kbit_cap_d        = 109,    ///< (109) CAP D code.
        kbit_stick        = 110,    ///< (110) Stick receive watchdog.
        kbit_cana_tx      = 111,    ///< (111) CAN A TX code.
        kbit_canb_tx      = 112,    ///< (112) CAN B TX code.
        kbit_iridium      = 113,    ///< (113) Iridium state code.
        kbit_geoid        = 114,    ///< (114) Geoid ok (for MSL computation)
        kbit_inverse      = 115,    ///< (115) EKF: Inverse, condition number code.
        kbit_ralt_rx      = 116,    ///< (116) Radar altimeter Reception
        kbit_pwr_a        = 117,    ///< (117) Power A BIT code.
        kbit_pwr_b        = 118,    ///< (118) Power B BIT code.
        kbit_hovering     = 119,    ///< (119) True if cruise guidance is hovering, false otherwise
        kbit_pulse0       = 120,    ///< (120) Pulse 0 BIT code.
        kbit_pulse1       = 121,    ///< (121) Pulse 1 BIT code.
        kbit_pulse2       = 122,    ///< (122) Pulse 2 BIT code.
        kbit_pulse3       = 123,    ///< (123) Pulse 3 BIT code.
        //Exclusive variables for Arbiter CPU
        kbit_arb_vcc      = 124,    ///< (124) 4XV Vcc for Arbiter CPU
        kbit_arb_vccA     = 125,    ///< (125) 4XV Vcc-A
        kbit_arb_vccB     = 126,    ///< (126) 4XV Vcc-B
        kbit_arb_vcc1     = 127,    ///< (127) 4XV Vcc-1
        kbit_arb_vcc2     = 128,    ///< (128) 4XV Vcc-2
        kbit_arb_vcc3     = 129,    ///< (129) 4XV Vcc-3
        //
        kbit_ekfnav       = 130,    ///< (130) EKF navigation ok
        kbit_magfield_grid = 131,   ///< (131) Bit to indicate if there is magnetic field in the SD
        kbit_route_finished = 132,  ///< (132) True if the route is finished, false otherwise
        kbit_dem_cmd_rec  = 133,    ///< (133) True if AGL calibrated, false otherwise
        kbit_atm_cmd_rec  = 134,    ///< (134) True if atmosphere calibrated, false otherwise
        kbit_pos_cmd_rec  = 135,    ///< (135) True if UAV position was set by command, false otherwise
        kbit_yaw_cmd_rec  = 136,    ///< (136) True if UAV yaw was set by command, false otherwise
        kbit_wind_cmd_rec = 137,    ///< (137) True if wind estimation was initialized by command, false otherwise
        kbit_op_err_ok    = 138,    ///< (138) False if an operation error has occurred.

        kbit_simnav       = 140,    ///< (140) Simulatied navigation on.
        kbit_extnav       = 150,    ///< (150) External navigation VCP ok.

        kbit_extnavvar    = 160,    ///< (160) External navigation variables ok

        kbit_imu_acc_ok   = 170,    ///< (170) Selected accelerometer ok
        kbit_imu_gyr_ok   = 171,    ///< (171) Selected gyroscope ok

        kbit_bias_acc_ok  = 172,    ///< (172) Accelerometer bias not satured
        kbit_bias_gyr_ok  = 173,    ///< (173) Gyroscope bias not satured

        kbit_ext_attitude = 180,    ///< (180) External attitude

        kbit_fts_act      = 182,    ///< (182) FTS-Activation for redundant output (V4.5)
        kbit_4x_sel       = 183,    ///< (183) True when this AP is the one selected

        kbit_stps_ok      = 188,    ///< (188) BIT for static pressure sensors
        kbit_mags_ok      = 189,    ///< (189) BIT for magnetometer sensors

        kbit_internest_pos_status = 190, ///< (190) Internest ultrasound position status
        kbit_internest_ang_status = 191, ///< (191) Internest ultrasound angle status


        kbit_gps0nav      = 200,    ///< (200) DGPS1 used.
        kbit_gps0din      = 201,    ///< (201) DGPS1 Input Status.
        kbit_gps0dnav     = 202,    ///< (202) DGPS1 used.
        kbit_gps0surveyin = 203,    ///< (203) DGPS1 survey in
        kbit_gps0floatsol = 204,    ///< (204) DGPS1 float solution
        kbit_gps0fixsol   = 205,    ///< (205) DGPS1 fixed solution
        kbit_gps0rpos     = 206,    ///< (206) DGPS1 relative position valid.
        kbit_gps0movbase  = 207,    ///< (207) DGPS1 mov base.
        kbit_gps0all      = 208,

        kbit_dma_spia     = 210,    ///< (210) DMA peripheral error for SPI A
        kbit_dma_mcbspa   = 211,    ///< (211) DMA peripheral error for MCBSP A

        kbit_arb_msg0  = 230,       ///< (230) 4XV Arbiter Custom msg 0 timeout"),
        kbit_arb_msg1  = 231,       ///< (231) 4XV Arbiter Custom msg 1 timeout"),
        kbit_arb_msg2  = 232,       ///< (232) 4XV Arbiter Custom msg 2 timeout"),
        kbit_arb_msg3  = 233,       ///< (233) 4XV Arbiter Custom msg 3 timeout"),
        kbit_arb_msg4  = 234,       ///< (234) 4XV Arbiter Custom msg 4 timeout"),
        kbit_arb_msg5  = 235,       ///< (235) 4XV Arbiter Custom msg 5 timeout"),
        kbit_arb_msg6  = 236,       ///< (236) 4XV Arbiter Custom msg 6 timeout"),
        kbit_arb_msg7  = 237,       ///< (237) 4XV Arbiter Custom msg 7 timeout"),
        kbit_arb_msg8  = 238,       ///< (238) 4XV Arbiter Custom msg 8 timeout"),
        kbit_arb_msg9  = 239,       ///< (239) 4XV Arbiter Custom msg 9 timeout"),
        kbit_arb_msg10 = 240,       ///< (240) 4XV Arbiter Custom msg 10 timeout"),
        kbit_arb_msg11 = 241,       ///< (241) 4XV Arbiter Custom msg 11 timeout"),
        kbit_arb_msg12 = 242,       ///< (242) 4XV Arbiter Custom msg 12 timeout"),
        kbit_arb_msg13 = 243,       ///< (243) 4XV Arbiter Custom msg 13 timeout"),
        kbit_arb_msg14 = 244,       ///< (244) 4XV Arbiter Custom msg 14 timeout"),
        kbit_arb_msg15 = 245,       ///< (245) 4XV Arbiter Custom msg 15 timeout"),
        kbit_arb_msg16 = 246,       ///< (246) 4XV Arbiter Custom msg 16 timeout"),
        kbit_arb_msg17 = 247,       ///< (247) 4XV Arbiter Custom msg 17 timeout"),
        kbit_arb_msg18 = 248,       ///< (248) 4XV Arbiter Custom msg 18 timeout"),
        kbit_arb_msg19 = 249,       ///< (249) 4XV Arbiter Custom msg 19 timeout"),
        kbit_arb_msg20 = 250,       ///< (250) 4XV Arbiter Custom msg 20 timeout"),
        kbit_arb_msg21 = 251,       ///< (251) 4XV Arbiter Custom msg 21 timeout"),
        kbit_arb_msg22 = 252,       ///< (252) 4XV Arbiter Custom msg 22 timeout"),
        kbit_arb_msg23 = 253,       ///< (253) 4XV Arbiter Custom msg 23 timeout"),
        kbit_arb_msg24 = 254,       ///< (254) 4XV Arbiter Custom msg 24 timeout"),
        kbit_arb_msg25 = 255,       ///< (255) 4XV Arbiter Custom msg 25 timeout"),
        kbit_arb_msg26 = 256,       ///< (256) 4XV Arbiter Custom msg 26 timeout"),
        kbit_arb_msg27 = 257,       ///< (257) 4XV Arbiter Custom msg 27 timeout"),
        kbit_arb_msg28 = 258,       ///< (258) 4XV Arbiter Custom msg 28 timeout"),
        kbit_arb_msg29 = 259,       ///< (259) 4XV Arbiter Custom msg 29 timeout"),
        kbit_arb_msg30 = 260,       ///< (260) 4XV Arbiter Custom msg 30 timeout"),
        kbit_arb_msg31 = 261,       ///< (261) 4XV Arbiter Custom msg 31 timeout"),
        kbit_arb_msg32 = 262,       ///< (262) 4XV Arbiter Custom msg 32 timeout"),
        kbit_arb_msg33 = 263,       ///< (263) 4XV Arbiter Custom msg 33 timeout"),
        kbit_arb_msg34 = 264,       ///< (264) 4XV Arbiter Custom msg 34 timeout"),
        kbit_arb_msg35 = 265,       ///< (265) 4XV Arbiter Custom msg 35 timeout"),
        kbit_arb_msg36 = 266,       ///< (266) 4XV Arbiter Custom msg 36 timeout"),
        kbit_arb_msg37 = 267,       ///< (267) 4XV Arbiter Custom msg 37 timeout"),
        kbit_arb_msg38 = 268,       ///< (268) 4XV Arbiter Custom msg 38 timeout"),
        kbit_arb_msg39 = 269,       ///< (269) 4XV Arbiter Custom msg 39 timeout"),
        kbit_arb_msg40 = 270,       ///< (270) 4XV Arbiter Custom msg 40 timeout"),
        kbit_arb_msg41 = 271,       ///< (271) 4XV Arbiter Custom msg 41 timeout"),
        kbit_arb_msg42 = 272,       ///< (272) 4XV Arbiter Custom msg 42 timeout"),
        kbit_arb_msg43 = 273,       ///< (273) 4XV Arbiter Custom msg 43 timeout"),
        kbit_arb_msg44 = 274,       ///< (274) 4XV Arbiter Custom msg 44 timeout"),
        kbit_arb_msg45 = 275,       ///< (275) 4XV Arbiter Custom msg 45 timeout"),
        kbit_arb_msg46 = 276,       ///< (276) 4XV Arbiter Custom msg 46 timeout"),
        kbit_arb_msg47 = 277,       ///< (277) 4XV Arbiter Custom msg 47 timeout"),
        kbit_arb_msg48 = 278,       ///< (278) 4XV Arbiter Custom msg 48 timeout"),
        kbit_arb_msg49 = 279,       ///< (279) 4XV Arbiter Custom msg 49 timeout"),
        kbit_arb_msg50 = 280,       ///< (280) 4XV Arbiter Custom msg 50 timeout"),
        kbit_arb_msg51 = 281,       ///< (281) 4XV Arbiter Custom msg 51 timeout"),
        kbit_arb_msg52 = 282,       ///< (282) 4XV Arbiter Custom msg 52 timeout"),
        kbit_arb_msg53 = 283,       ///< (283) 4XV Arbiter Custom msg 53 timeout"),
        kbit_arb_msg54 = 284,       ///< (284) 4XV Arbiter Custom msg 54 timeout"),
        kbit_arb_msg55 = 285,       ///< (285) 4XV Arbiter Custom msg 55 timeout"),
        kbit_arb_msg56 = 286,       ///< (286) 4XV Arbiter Custom msg 56 timeout"),
        kbit_arb_msg57 = 287,       ///< (287) 4XV Arbiter Custom msg 57 timeout"),
        kbit_arb_msg58 = 288,       ///< (288) 4XV Arbiter Custom msg 58 timeout"),
        kbit_arb_msg59 = 289,       ///< (289) 4XV Arbiter Custom msg 59 timeout"),
        kbit_arb_msg60 = 290,       ///< (290) 4XV Arbiter Custom msg 60 timeout"),
        kbit_arb_msg61 = 291,       ///< (291) 4XV Arbiter Custom msg 61 timeout"),
        kbit_arb_msg62 = 292,       ///< (292) 4XV Arbiter Custom msg 62 timeout"),
        kbit_arb_msg63 = 293,       ///< (293) 4XV Arbiter Custom msg 63 timeout"),

        kbit_gps1nav      = 300,    ///< (300) DGPS2 used.
        kbit_gps1din      = 301,    ///< (301) DGPS2 Input Status.
        kbit_gps1dnav     = 302,    ///< (302) DGPS2 used.
        kbit_gps1surveyin = 303,    ///< (303) DGPS2 survey in
        kbit_gps1floatsol = 304,    ///< (304) DGPS2 float solution
        kbit_gps1fixsol   = 305,    ///< (305) DGPS2 fixed solution
        kbit_gps1rpos     = 306,    ///< (306) DGPS2 relative position valid.
        kbit_gps1movbase  = 307,    ///< (307) DGPS2 mov base.
        kbit_scie_tx      = 308,    ///< (308) SCI E transmitting during last check period.
        kbit_scie_rx      = 309,    ///< (309) SCI E receiving during last check period.
        kbit_scif_tx      = 310,    ///< (310) SCI F transmitting during last check period.
        kbit_scif_rx      = 311,    ///< (311) SCI F receiving during last check period.
        kbit_scie_rx_ok   = 312,    ///< (312) SCI E error on receiving
        kbit_scif_rx_ok   = 313,    ///< (313) SCI F error on receiving

        kbit_disable_comms= 320,    ///< (320) Disable external communications.

        kbit_power_3_3      = 329,  ///< (329) 3.3V Power source
        // CEX
        kbit_cex_jetibox_ok = 330,  ///< (330) Jetibox is communicating properly
        kbit_cex_hi_3210    = 331,  ///< (331) HI-3210 working normally
        // CEX Reserved       350

        // COMMEX
        kbit_commex_planet_ok = 351,///< (351) planet satcom is connected
        // COMMEX Reservd        365

        // CAN Isolator
        kbit_caniso_a_ok    = 370,  ///< (370) CAN Isolator A domain ok
        kbit_caniso_b_ok    = 371,  ///< (371) CAN Isolator A domain ok
        // CANisolator Reserv.379

        kbit_task_c1      = 400,    ///< (400) CPU1 main task error
        kbit_task_c2      = 401,    ///< (401) CPU2 fail
        kbit_task_acq     = 402,    ///< (402) Acquisition task real time error.
        kbit_task_ovr     = 403,    ///< (403) Acquisition task overload warning
        kbit_gnc_step_mis = 404,    ///< (404) GNC step missed
        kbit_reserved3    = 405,    ///< (405) Reserved.
        kbit_task_c2_lo   = 406,    ///< (406) CPU2 low priority task fail.

        // VMC
        kbit_stp_dir  = 480,     ///< (480) Stepper direction output.
        kbit_bl_fault = 481,     ///< (481) Brushless driver fault.
        kbit_hall     = 482,     ///< (482) Hall sensor ok bit
        kbit_sincos   = 483,     ///< (483) Sin/Cos sensor ok bit
        // MC
        kbit_health    = 484,    ///< (484) Health check
        kbit_f_curr    = 485,    ///< (485) Current sensing error
        kbit_f_cal_phu = 486,    ///< (486) Phase U Current Calibration Error
        kbit_f_cal_phv = 487,    ///< (487) Phase V Current Calibration Error
        kbit_f_cal_phw = 488,    ///< (488) Phase W Current Calibration Error
        kbit_f_temp    = 489,    ///< (489) Maximum Temperature Error
        kbit_f_ph_v    = 490,    ///< (490) Phase V Error
        kbit_f_drv     = 491,    ///< (491) General Driver Error
        kbit_f_swoc_ac = 492,    ///< (492) Over-current AC
        kbit_f_swov_adv= 493,    ///< (493) Over-voltage advertisement
        kbit_f_swov_cau= 494,    ///< (494) Over-voltage caution
        kbit_f_swuv_l  = 495,    ///< (495) Under-votage latching
        kbit_f_swuv_nl = 496,    ///< (496) Under-votage non latching
        kbit_f_rms_imb = 497,    ///< (497) RMS imbalance
        kbit_f_open_dc = 498,    ///< (498) Open DC fault
        kbit_f_swoc_dc = 499,    ///< (499) Over-current DC

        kbit_gndeffect_e2_cmd           = 500, ///< (500) Ground effect e2 compensation enabled
        kbit_gndeffect_correction_cmd   = 501, ///< (501) Ground effect correction limit compensation enabled
        kbit_srtm_data                  = 502, ///< (502) Bit to indicate if there is SRTM in the SD
        kbit_geoid_data                 = 503, ///< (503) Bit to indicate if there is Geoid data in the SD
        kbit_geocaging_ok               = 504, ///< (504) All geocaging polygons comply with standard

        kbit_wind_est       = 600,  ///< (600) Wind estimation enabled

        kbit_servo00        = 700,  ///< (700) SERVO 1 code.
        kbit_servo31        = 731,  ///< (731) SERVO 32 code.

        // MC
        kbit_f_ph_u         =  732, ///< (732) Phase U error
        kbit_f_ph_w         =  733, ///< (733) Phase W error
        kbit_f_dc_link      =  734, ///< (734) DC link error
        kbit_f_hwoc_ac      =  735, ///< (735) HW over-current AC side error
        kbit_f_hwoc_dc      =  736, ///< (736) HW over-current DC side error
        kbit_f_hw_gfd       =  737, ///< (737) HW ground fault detection
        kbit_f_hw_pgr       =  738, ///< (738) HW power good regulator
        kbit_f_hw_trip_pwm  =  739, ///< (739) HW general error to trip PWM
        kbit_f_bat_dis      =  740, ///< (740) Battery disconnected
        kbit_f_cal_idc      =  741, ///< (741) DC Current Calibration Error
        kbit_f_ester        =  742, ///< (742) Estimation position error
        kbit_f_rpm_follow   =  743, ///< (743) Speed reference tracking error
        kbit_f_posse        =  744, ///< (744) Position sensor error
        kbit_sc1_cal        =  745, ///< (745) SIN/COS sensor 1 calibration error
        kbit_sc2_cal        =  746, ///< (746) SIN/COS sensor 2 calibration error
        kbit_f_low_energy   =  747, ///< (747) UV low energy error
        kbit_f_input_msg    =  748, ///< (748) Input manager timeout reached

        kbit_gpio_pwm1      = 800,  ///< (800) GPIO/PWM  1 read value
        kbit_gpio_pwm2      = 801,  ///< (801) GPIO/PWM  2 read value
        kbit_gpio_pwm3      = 802,  ///< (802) GPIO/PWM  3 read value
        kbit_gpio_pwm4      = 803,  ///< (803) GPIO/PWM  4 read value
        kbit_gpio_pwm5      = 804,  ///< (804) GPIO/PWM  5 read value
        kbit_gpio_pwm6      = 805,  ///< (805) GPIO/PWM  6 read value
        kbit_gpio_pwm7      = 806,  ///< (806) GPIO/PWM  7 read value
        kbit_gpio_pwm8      = 807,  ///< (807) GPIO/PWM  8 read value
        kbit_gpio_pwm9      = 808,  ///< (808) GPIO/PWM  9 read value
        kbit_gpio_pwm10     = 809,  ///< (809) GPIO/PWM 10 read value
        kbit_gpio_pwm11     = 810,  ///< (810) GPIO/PWM 11 read value
        kbit_gpio_pwm12     = 811,  ///< (811) GPIO/PWM 12 read value
        kbit_gpio_pwm13     = 812,  ///< (812) GPIO/PWM 13 read value
        kbit_gpio_pwm14     = 813,  ///< (813) GPIO/PWM 14 read value
        kbit_gpio_pwm15     = 814,  ///< (814) GPIO/PWM 15 read value
        kbit_gpio_pwm16     = 815,  ///< (815) GPIO/PWM 16 read value
        kbit_gpio_io1       = 816,  ///< (816) GPIO/IO 1 read value
        kbit_gpio_io2       = 817,  ///< (817) GPIO/IO 2 read value
        kbit_gpio_io3       = 818,  ///< (818) GPIO/IO 3 read value
        kbit_gpio_io4       = 819,  ///< (819) GPIO/IO 4 read value
        kbit_gpio_rssi_led1 = 820,  ///< (820) Led 1 RSSI modem
        kbit_gpio_rssi_led2 = 821,  ///< (821) Led 2 RSSI modem
        kbit_gpio_rssi_led3 = 822,  ///< (822) Led 3 RSSI modem
        kbit_gpio_io5       = 823,  ///< (823) GPIO/IO 5 read value
        kbit_gpio_io6       = 824,  ///< (824) GPIO/IO 6 read value
        kbit_gpio_io7       = 825,  ///< (825) GPIO/IO 7 read value
        kbit_gpio_io8       = 826,  ///< (826) GPIO/IO 8 read value
        kbit_gpio_io9       = 827,  ///< (827) GPIO/IO 9 read value
        kbit_gpio_io10      = 828,  ///< (828) GPIO/IO 10 read value
        kbit_gpio_io11      = 829,  ///< (829) GPIO/IO 11 read value
        kbit_gpio_io12      = 830,  ///< (830) GPIO/IO 12 read value
        kbit_gpio_io13      = 831,  ///< (831) GPIO/IO 13 read value
        kbit_gpio_io14      = 832,  ///< (832) GPIO/IO 14 read value
        kbit_gpio_io15      = 833,  ///< (833) GPIO/IO 15 read value
        kbit_gpio_io16      = 834,  ///< (834) GPIO/IO 16 read value
        kbit_gpio_io17      = 835,  ///< (835) GPIO/IO 17 read value
        kbit_gpio_io18      = 836,  ///< (836) GPIO/IO 18 read value
        kbit_gpio_io19      = 837,  ///< (837) GPIO/IO 19 read value
        kbit_gpio_io20      = 838,  ///< (838) GPIO/IO 20 read value
        kbit_gpio_io21      = 839,  ///< (839) GPIO/IO 21 read value

        kbit_virtual_gpio00 = 900,  ///< (900) Virtual GPIO 00
        kbit_virtual_gpio01 = 901,  ///< (901) Virtual GPIO 01
        kbit_virtual_gpio02 = 902,  ///< (902) Virtual GPIO 02
        kbit_virtual_gpio03 = 903,  ///< (903) Virtual GPIO 03
        kbit_virtual_gpio04 = 904,  ///< (904) Virtual GPIO 04
        kbit_virtual_gpio05 = 905,  ///< (905) Virtual GPIO 05
        kbit_virtual_gpio06 = 906,  ///< (906) Virtual GPIO 06
        kbit_virtual_gpio07 = 907,  ///< (907) Virtual GPIO 07
        kbit_virtual_gpio08 = 908,  ///< (908) Virtual GPIO 08
        kbit_virtual_gpio09 = 909,  ///< (909) Virtual GPIO 09
        kbit_virtual_gpio10 = 910,  ///< (910) Virtual GPIO 10
        kbit_virtual_gpio11 = 911,  ///< (911) Virtual GPIO 11
        kbit_virtual_gpio12 = 912,  ///< (912) Virtual GPIO 12
        kbit_virtual_gpio13 = 913,  ///< (913) Virtual GPIO 13
        kbit_virtual_gpio14 = 914,  ///< (914) Virtual GPIO 14
        kbit_virtual_gpio15 = 915,  ///< (915) Virtual GPIO 15
        kbit_virtual_gpio16 = 916,  ///< (916) Virtual GPIO 16
        kbit_virtual_gpio17 = 917,  ///< (917) Virtual GPIO 17
        kbit_virtual_gpio18 = 918,  ///< (918) Virtual GPIO 18
        kbit_virtual_gpio19 = 919,  ///< (919) Virtual GPIO 19
        kbit_virtual_gpio20 = 920,  ///< (920) Virtual GPIO 20
        kbit_virtual_gpio21 = 921,  ///< (921) Virtual GPIO 21
        kbit_virtual_gpio22 = 922,  ///< (922) Virtual GPIO 22
        kbit_virtual_gpio23 = 923,  ///< (923) Virtual GPIO 23
        kbit_virtual_gpio24 = 924,  ///< (924) Virtual GPIO 24
        kbit_virtual_gpio25 = 925,  ///< (925) Virtual GPIO 25
        kbit_virtual_gpio26 = 926,  ///< (926) Virtual GPIO 26
        kbit_virtual_gpio27 = 927,  ///< (927) Virtual GPIO 27
        kbit_virtual_gpio28 = 928,  ///< (928) Virtual GPIO 28
        kbit_virtual_gpio29 = 929,  ///< (929) Virtual GPIO 29
        kbit_virtual_gpio30 = 930,  ///< (930) Virtual GPIO 30
        kbit_virtual_gpio31 = 931,  ///< (931) Virtual GPIO 31

        kbit_sim            = 1000, ///< (1000) Simulation variables TO DELETE, NOT USED

        kbit_msg0           = 1010, ///< (1010) Custom msg 0 timeout,
        kbit_msg15          = 1025, ///< (1025) Custom msg 15 timeout,
        kbit_msg103         = 1113, ///< (1113) Custom msg 103 timeout,

        kbit_msg_last       = 1169, ///< (1169) Last available Custom msg timeout,

        ///Ekf_in kbits
        kbit_ekf_gps_0      = 1170, ///< (1170) Ekf in gpsint0.
        kbit_ekf_gps_1      = 1171, ///< (1171) Ekf in gpsint1.
        kbit_ekf_gps_2      = 1172, ///< (1172) Ekf in gpsvar0.
        kbit_ekf_internest  = 1173, ///< (1173) Ekf in internest.
        kbit_ekf_gpscompass = 1174, ///< (1174) Ekf in gpscompass.
        kbit_ekf_compass    = 1175, ///< (1175) Ekf in Magnetometer.
        kbit_ekf_stp        = 1176, ///< (1176) Ekf in Static pressure.
        kbit_ekf_altimeter  = 1177, ///< (1177) Ekf in altimeter.
        kbit_ekf_vdownmeter = 1178, ///< (1178) Ekf in Radar altimeter.
        kbit_ekf_terrain    = 1179, ///< (1179) Ekf in DEM.

        kbit_ext_nav        = 1183, ///< (1183) External navigation
        kbit_ext_imu0_acc   = 1184, ///< (1184) External IMU 0 accelerometer OK
        kbit_ext_imu0_gyr   = 1185, ///< (1185) External IMU 0 gyroscope OK
        kbit_ext_imu1_acc   = 1186, ///< (1186) External IMU 1 accelerometer OK
        kbit_ext_imu1_gyr   = 1187, ///< (1187) External IMU 1 gyroscope OK
        kbit_ext_mag0       = 1188, ///< (1188) External magnetometer 0 OK
        kbit_ext_mag1       = 1189, ///< (1189) External magnetometer 1 OK
        kbit_snif0          = 1190, ///< (1190) Sniffer msg 0 timeout
        kbit_snif1          = 1191, ///< (1191) Sniffer msg 1 timeout

        // Update varmgr boolean buffer when this user list grows up
        kbit_user           = 1200, ///< (1200) User bit 00
        kbit_user9          = 1209, ///< (1209) User bit 09
        kbit_user_last      = 2199, ///< (2199) Last user bit

        kbit_none           = 2200
    };

    enum Bvar_map ///< Dummy Bvar type used for Bitmap type.
    {
    };

    static const Uint16 kbit_all = 2201;    ///< maximum number of bits

    inline bool is_valid(Bvar v)
    {
        return Range<Bvar, kbit_fail, static_cast<Bvar>(kbit_all)>::in_range(v);
    }

    /// @return True if the Bvar passed as argument can be written by the user, false if read-only
    bool user_writable(Bvar v);

    inline Bvar validate(Bvar v, Bvar def=kbit_none)
    {
        return is_valid(v) ? v : def;
    }
}
#endif
