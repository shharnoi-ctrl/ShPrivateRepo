#include <EEPROM_24CS.h>

namespace Devices
{
    using namespace Base;

    // From datasheet TABLE 1-4: TPOFF Minimum time at VCC = 0V between power cycles 1 � ms.
    const Real EEPROM_24CS::wait_por_s = Const::E1000;

    // From datasheet TABLE 1-2:  TWC Write Cycle Time (byte or page) � 5 ms.
    const Real EEPROM_24CS::wait_wrt_s = 5E-3F;

    const Real EEPROM_24CS::desired_rate = static_cast<Real>(desired_rate_u);

    EEPROM_24CS::EEPROM_24CS(Dsp28335_ent::I2Cif& i2c0, volatile bool& bit):
        Dsp28335_ent::I2Cdevice(i2c0, eeprom_addr, page_sz, bit),
        i2c(i2c0),
        state(st_por),
        chr(true),
        period_current(get_default_period()),
        op_addr(0),
        cmd_mb(&op_addr, Ku16::u2),
        to_write(0)
    {
        /// \alg
        /// <ul>
        /// <li> Initialize attributes as:
        /// <ul>
        /// Name            | Value
        /// --------------- | -----------------------------------------------------------------
        /// I2Cdevice       | Dsp28335_ent::I2Cdevice(::i2c0, eeprom_addr, page_sz, ::bit)
        /// i2c             | i2c0
        /// state           | st_por
        /// chr             | true
        /// period_current  | get_default_period returned value
        /// op_pidx         | 0
        /// op_addr         | 0
        /// cmd_mb          | Constant byte memory block of length 2 using pointer to op_addr
        /// to_write        | 0
        /// </ul>
        /// <li> Call callst ::set_desired_rate to desired_rate.
        callst.set_desired_rate(desired_rate);
        /// </ul>
    }

    Real EEPROM_24CS::get_period() const
    {
        /// \alg
        /// Return period_current.
        return period_current;
    };

    void EEPROM_24CS::set_period(const Real& period0)
    {
        /// \alg
        /// Use provided ::period0 to Call I2Cdevice ::set_period and to fix internal period_current.
        I2Cdevice::set_period(period0);
        period_current = period0;
    };

    Real EEPROM_24CS::get_default_period() const
    {
        /// \alg
        /// <ul>
        /// <li> Call I2Cdevice ::get_default_period0 with its parameters as:
        /// <ul>
        ///     <li> req_steps to the worst case in terms of number of steps.
        ///     As up to 16 bytes would be bulked at each I2C driver step,
        ///     and a page operation need (1 byte of start + 2 bytes for address)
        ///     both with (1 byte of start + 64 bytes for operation),
        ///     <li> up_perc to 1.
        /// </ul>
        static const Uint16 req_steps = Rfun::Ceilr_t<Rfun::Div_t<Uint16, Ku16::u3 + (Ku16::u1 + page_sz), Ku16::u16> >::value;
        Real res = I2Cdevice::get_default_period0(req_steps, Const::ONE);
        /// <li> From previous call, return result.
        return res;
        /// </ul>
    }

    Real EEPROM_24CS::get_desired_rate() const
    {
        /// \alg
        /// Return desired_rate.
        return desired_rate;
    }

    bool EEPROM_24CS::init_medium()
    {
        /// \alg
        /// Return value from is_init0 call.
        return is_init0();
    }

    bool EEPROM_24CS::is_init() const
    {
        /// \alg
        /// Return value from is_init0 call.
        return is_init0();
    }

    void EEPROM_24CS::do_step()
    {
        if(is_enabled())
        {
            switch(state)
            {
                case st_por:
                {
                    if(chr.toc() > wait_por_s)
                    {
                        state = st_ini;
                    }
                    break;
                }
                case st_ini:
                {
                    callst.call();
                    break;
                }
                case st_crd:
                {
                    read(page_sz);
                    state = st_wop;
                    break;
                }
                case st_cwr:
                {
                    if(to_write == 0)
                    {
                        Bsp::warning();
                        state = st_err;
                    }
                    else
                    {
                        send(*to_write);
                        state = st_wop;
                    }
                    break;
                }
                case st_wop:
                {
                    to_write = 0;
                    state = st_ini;
                    break;
                }
                case st_err:
                {
                    // can only change by calling I2Cdevice::set_ok with parameter at true.
                    break;
                }
            }
        }
    }

    void EEPROM_24CS::set_ok(bool ok)
    {
        /// \alg
        /// <ul>
        /// <li> If provided ::ok is False, assert a warning and set state to st_err.
        if(!ok)
        {
            Bsp::warning();
            state = st_err;
        }
        /// <li> Else, fix state to st_ini.
        else
        {
            state = st_ini;
        }
        /// </ul>
    };

    bool EEPROM_24CS::start_request(Uint16 page_idx)
    {
        /// \alg
        /// <ul>
        /// <li> Store returned value from check_idx call with provided ::page_idx within ret local variable.
        bool ret = check_idx(page_idx);
        /// <li> If ret value is true:
        if(ret)
        {
            /// <ul>
            /// <li> Instantiate a local U8ostream with ::cmd_mb.
            Base::U8ostream ostr(cmd_mb);
            /// <li> Call its ::put_uint16_le method with provided ::page_idx multiplied by ::page_sz.
            ostr.put_uint16_le(page_idx*page_sz);
            /// <li> Then, fix ret variable with returned value from ::send call with ::cmd_mb.
            ret = send(cmd_mb);
            /// </ul>
        }
        /// <li> Return ret value.
        return ret;
    }

    Async_res EEPROM_24CS::read_sector_start(Uint32 sector)
    {
        /// \alg
        /// <ul>
        /// <li> Initialize res variable with ::async_busy_error value.
        Async_res res = async_busy_error;
        /// <li> If ::is_init0 call return true and ::start_request with provided ::sector returned true:
        if(is_init0() && start_request(sector))
        {
            /// <ul>
            /// <li> Fix res variable to ::async_done_ok value.
            res = async_done_ok;
            /// <li> Fix ::state with ::st_crd.
            state = st_crd;
            /// </ul>
        }
        /// <li> Return res value.
        return res;
        /// </ul>
    }

    Async_res EEPROM_24CS::read_sector_get_data(U8pkmblock& buffer)
    {
        /// \pre Assume that read_sector_start has been previously called.
        /// \alg
        /// <ul>
        /// <li> Initialize res variable with ::async_ongoing value.
        Async_res res = async_ongoing;
        /// <li> If ::is_init0 call return true:
        if(is_init0())
        {
            /// <ul>
            /// <li> Call provided ::buffer ::write method with I2Cdevice ::get_buffer as parameter.
            buffer.write(I2Cdevice::get_buffer());
            /// <li> Fix res variable to ::async_done_ok.
            res = async_done_ok;
            /// </ul>
        }
        /// <li> Else if ::state is equals to ::st_err:
        else if(state == st_err)
        {
            /// <li> Fix res to async_done_error.
            res = async_done_error;
            /// </ul>
        }
        /// <li> Return res value.
        return res;
        /// </ul>
    }

    Async_res EEPROM_24CS::write_sector_start(Uint32 sector, const U8pkmblock_k& buffer)
    {
        /// \alg
        /// <ul>
        /// <li> Initialize res variable with ::async_busy_error value.
        Async_res res = async_busy_error;
        /// <li> If ::is_init0 call return true and ::start_request call with provided ::sector returned true:
        if(is_init0() && start_request(sector))
        {
            Assertions::runtime(to_write == 0);
            to_write = &buffer;
            res = async_done_ok;
            state = st_crd;
            /// </ul>
        }
        /// <li> Return res value.
        return res;
        /// </ul>
    }

    Async_res EEPROM_24CS::write_sector_ended()
    {
        /// \alg
        /// <ul>
        /// <li> Initialize res variable with ::async_busy_error value.
        Async_res res = async_busy_error;
        /// <li> If ::is_init0 call return true, fix res to ::async_done_ok.
        if(is_init0())
        {
            res = async_done_ok;
        }
        /// <li> Else if state is equals to ::st_err, fix res to ::async_done_error.
        else if(state == st_err)
        {
            res = async_done_error;
        }
        /// <li> Else, fix res to ::async_ongoing.
        else
        {
            res = async_ongoing;
        }
        /// <li> Return res value.
        return res;
        /// </ul>
    }

    bool EEPROM_24CS::read_sector(Uint32 sector, U8pkmblock& buffer)
    {
        // not needed actually.
        Bsp::warning();
        return false;
    }

    bool EEPROM_24CS::write_sector(Uint32 sector, const U8pkmblock_k& buffer)
    {
        // not needed actually.
        Bsp::warning();
        return false;
    }
}
