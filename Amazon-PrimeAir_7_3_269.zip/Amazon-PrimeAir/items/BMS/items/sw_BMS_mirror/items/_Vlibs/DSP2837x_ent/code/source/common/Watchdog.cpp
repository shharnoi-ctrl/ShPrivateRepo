#include <Watchdog.h>
#include <Ku16.h>
#include <Asm.h>
#include <Hregmap.h>

namespace Dsp28335_ent
{
    //PRQA S 2176 ++
    //#Unions used in HW register mapping in Texas Instruments' libraries.
    //PRQA S 2301 ++
    //#Bit-fields are needed.
    //PRQA S 5050 ++
    //#Identifiers will be kept by default
    //PRQA S 5051 ++
    //#Identifiers will be kept by default

    struct SCSR_BITS {                      // bits description
        Uint16 WDOVERRIDE:1;                // 0 WD Override for WDDIS bit
        Uint16 WDENINT:1;                   // 1 WD Interrupt Enable
        Uint16 WDINTS:1;                    // 2 WD Interrupt Status
        Uint16 rsvd1:13;                    // 15:3 Reserved
    };

    union SCSR_REG {
        Uint16  all;
        struct  SCSR_BITS  bit;
    };

    struct WDCNTR_BITS {                    // bits description
        Uint16 WDCNTR:8;                    // 7:0 WD Counter
        Uint16 rsvd1:8;                     // 15:8 Reserved
    };

    union WDCNTR_REG {
        Uint16  all;
        struct  WDCNTR_BITS  bit;
    };

    struct WDKEY_BITS {                     // bits description
        Uint16 WDKEY:8;                     // 7:0 WD KEY
        Uint16 rsvd1:8;                     // 15:8 Reserved
    };

    union WDKEY_REG {
        Uint16  all;
        struct  WDKEY_BITS  bit;
    };

    struct WDCR_BITS {                      // bits description
        Uint16 WDPS:3;                      // 2:0 WD Clock Prescalar
        Uint16 WDCHK:3;                     // 5:3 WD Check Bits
        Uint16 WDDIS:1;                     // 6 WD Disable
        Uint16 rsvd1:1;                     // 7 Reserved
        Uint16 rsvd2:8;                     // 15:8 Reserved
    };

    union WDCR_REG {
        Uint16  all;
        struct  WDCR_BITS  bit;
    };

    struct WDWCR_BITS {                     // bits description
        Uint16 MIN:8;                       // 7:0 WD Min Threshold setting for Windowed Watchdog functionality
        Uint16 FIRSTKEY:1;                  // 8 First Key Detect Flag
        Uint16 rsvd1:7;                     // 15:9 Reserved
    };

    union WDWCR_REG {
        Uint16  all;
        struct  WDWCR_BITS  bit;
    };

    struct Registers_wd
    {
        Uint16                                   rsvd1[34];                    // Reserved
        union   SCSR_REG                         SCSR;                         // System Control & Status Register
        union   WDCNTR_REG                       WDCNTR;                       // Watchdog Counter Register
        Uint16                                   rsvd2;                        // Reserved
        union   WDKEY_REG                        WDKEY;                        // Watchdog Reset Key Register
        Uint16                                   rsvd3[3];                     // Reserved
        union   WDCR_REG                         WDCR;                         // Watchdog Control Register
        union   WDWCR_REG                        WDWCR;                        // Watchdog Windowed Control Register
    };

    //PRQA S 2176 --
    //#Unions used in HW register mapping in Texas Instruments' libraries.
    //PRQA S 2301 --
    //#Bit-fields are needed.
    //PRQA S 5050 --
    //#Identifiers will be kept by default
    //PRQA S 5051 --
    //#Identifiers will be kept by default

    static const Uint8 watchdog_wdcr_check  = 0x28;
    static const Uint8 watchdog_wddis       = 0x40;
    static const Uint32 wdog_regs_addr = 0x007000UL;

    /// \return Watchdog registers
    inline volatile Registers_wd& get_regs()
    {
        return Hregmap::get<Registers_wd, wdog_regs_addr>();
    }

    Watchdog::Backup Watchdog::backup()
    {
        Backup bkp;
        volatile Registers_wd& regs(get_regs());
        bkp.scsr = regs.SCSR.all;
        bkp.wdcr = regs.WDCR.all;
        bkp.wdwcr= regs.WDWCR.all;
        return bkp;
    }

    void Watchdog::restore(const Backup& bkp)
    {
        volatile Registers_wd& regs(get_regs());
        asm_eallow();
        regs.WDCR.all  = bkp.wdcr | watchdog_wdcr_check;
        regs.WDWCR.all = bkp.wdwcr;
        regs.SCSR.all  = bkp.scsr & 0xFFFE;  // Mask write to bit 0 (W1toClr)
        asm_edis();
    }

    void Watchdog::setup_enabled(Prescaler presc) //PRQA S 4211 #const
    {
        volatile Registers_wd& regs(get_regs());
        asm_eallow();
        regs.SCSR.all = 0; // interrupts off
        regs.WDCR.all = presc | watchdog_wdcr_check; // Set enabled with prescaler
        asm_edis();
    }

    void Watchdog::setup_disabled()
    {
        volatile Registers_wd& regs(get_regs());
        asm_eallow();
        // Grab the clock config first so we don't clobber it
        volatile Uint16 presc = regs.WDCR.all & 0x0007;
        regs.WDCR.all = watchdog_wddis | watchdog_wdcr_check | presc; // Disable WD
        asm_edis();
    }

    void Watchdog::disable_windowed()
    {
        volatile Registers_wd& regs(get_regs());
        // Disable windowed functionality
        asm_eallow();
        regs.WDWCR.all = 0x0;
        asm_edis();
    }

    void Watchdog::notify()
    {
        volatile Registers_wd& regs(get_regs());
        asm_eallow();
        regs.WDKEY.bit.WDKEY = Ku16::u0x55;
        regs.WDKEY.bit.WDKEY = Ku16::u0xAA;
        asm_edis();
    }

    void Watchdog::setup_for_reset()
    {
        volatile Registers_wd& regs(get_regs());
        asm_eallow();
        regs.SCSR.all = 0;    // Setup to perform a reset instead of generating an interrupt on watchdog expiration.

        // Enable the watchdog to generate a reset. Prescaler = 1
        regs.WDCR.all = watchdog_wdcr_check;   //0 0 101 000
        asm_edis();
    }
}
