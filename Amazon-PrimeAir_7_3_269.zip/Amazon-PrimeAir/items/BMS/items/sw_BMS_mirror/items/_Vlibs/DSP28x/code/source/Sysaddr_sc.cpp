#include <Sysaddr.h>

namespace Bsp
{
    namespace
    {
        /// Single-core unique private address.
        /// Sysaddr file shall provide the capability to instantiate an unique Address object
        /// to be available on an unique core.
        /// \wi{17426}
        /// \return Reference to single-core unique private address.
        volatile Base::Address0& get_address_prv()
        {
            // Dynamic address (IP), built with physical value from OTP, then changed through set_sysaddr()
            static Base::Address ip_address = Base::Address(Base::Address0::null);
            return ip_address;
        }

        /// Single-core unique private VSM's address.
        /// Sysaddr file shall provide the capability to instantiate an unique Address object
        /// (for Stanag's VSM) to be available on an unique core.
        /// \wi{17427}
        /// \return Reference to single-core unique private address.
        volatile Base::Address0& get_vsmaddr_prv()
        {
            // Dynamic address (IP), built with physical value from OTP, then changed through set_sysaddr()
            static Base::Address vsm_addr = Base::Address(Base::Address0::null);
            return vsm_addr;
        }
    }

    volatile const Base::Address0& sysaddr()
    {
        return get_address_prv();
    }

    void set_sysaddr(Base::Address addr0)
    {
        get_address_prv().id = addr0.id;
    }

    const volatile Base::Address0& vsmaddr()
    {
        return get_vsmaddr_prv();
    }
}
