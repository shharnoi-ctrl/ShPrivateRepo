#ifndef GPIODEV_H_
#define GPIODEV_H_

#include <GPIOioctl.h>

namespace Dsp28335_ent
{
    /// GPIOdev
    /// Dsp28335_ent library shall provide a structure for configuring GPIOs.
    struct GPIOdev
    {
        // ------------ SCI ------------
        /// GPIO Device Configuration as SCI Bus.
        /// \wi{7913}
        /// GPIOdev structure shall provide the capability of configuring the GPIO pins as
        /// SCI bus.
        template <Muxfun m, GPIOid rx, GPIOid tx>
        static void apply_sci();

        // ------------ CAN ------------
        /// GPIO Device Configuration as CAN Bus.
        /// \wi{7923}
        /// GPIOdev structure shall provide the capability of configuring the GPIO pins as
        /// CAN bus.
        template <Muxfun m, GPIOid rx, GPIOid tx>
        static void apply_can();

        // ------------ MCBSP ------------
        // only inputs with async qualification.
        // Note that always in mcbsp, MDX is output and MRX is input, so:
        // - in master mode, mdx is SIMO, mdr is SOMI
        // - in slave  mode, mdx is SOMI, mdr is SIMO

        /// GPIO Device Configuration as the First 3 Master MCBSP Pins.
        /// \wi{7916}
        /// GPIOdev structure shall provide the capability of configuring the GPIO pins as
        /// master MCBSP simo, somi and clk pins.
        template <Muxfun m, GPIOid mdx, GPIOid mdr, GPIOid clk>
        static void apply3_mcbsp_master();

        /// GPIO Device Configuration as Full Master MCBSP.
        /// \wi{7917}
        /// GPIOdev structure shall provide the capability of configuring the GPIO pins as
        /// master MCBSP simo, somi, clk, and cs  pins.
        template <Muxfun m, GPIOid mdx, GPIOid mdr, GPIOid clk, GPIOid cs>
        static void apply4_mcbsp_master();

        /// CS managed manually
        /// GPIO Device Configuration as the First 3 Slave MCBSP Pins.
        /// \wi{21417}
        /// GPIOdev structure shall provide the capability of configuring the GPIO pins as
        /// slave MCBSP somi, simo, and clk pins.
        template <Muxfun m, GPIOid mdx, GPIOid mdr, GPIOid clk>
        static void apply3_mcbsp_slave();

        /// GPIO Device Configuration as Full Slave MCBSP.
        /// \wi{21418}
        /// GPIOdev structure shall provide the capability of configuring the GPIO pins as
        /// slave MCBSP somi, simo, clk and cs pins.
        template <Muxfun m, GPIOid mdx, GPIOid mdr, GPIOid clk, GPIOid cs>
        static void apply4_mcbsp_slave();

        // ------------ SPI ------------
        // all pins with async qualification.

        /// GPIO Device Configuration as the First 3 SPI Pins.
        /// \wi{7909}
        /// GPIOdev structure shall provide the capability of configuring the GPIO pins as
        /// SPI simo, somi and clk pins.
        template <Muxfun m, GPIOid simo, GPIOid somi, GPIOid clk>
        static void apply3_spi();

        /// GPIO Device Configuration as Full SPI.
        /// \wi{7910}
        /// GPIOdev structure shall provide the capability of configuring the GPIO pins as
        /// SPI simo, somi, clk, and cs pins.
        template <Muxfun m, GPIOid simo, GPIOid somi, GPIOid clk, GPIOid cs>
        static void apply4_spi();

        // ------------ I2C ------------
        /// GPIO Device Configuration as I2C.
        /// \wi{7920}
        /// GPIOdev structure shall provide the capability of configuring the GPIO pins as
        /// I2C pins.
        template <Muxfun m, GPIOid sda, GPIOid clk>
        static void apply_i2c();

        // ------------ USB ------------
        /// GPIO Device Configuration as USB.
        /// \wi{7926}
        /// GPIOdev structure shall provide the capability of configuring the GPIO pins as
        /// USB pins.
        template <Muxfun m, GPIOid usbid, GPIOid pflt, GPIOid epen>
        static void apply_usb();

        /// GPIO Device Configuration as Power Management Bus.
        /// \wi{21419}
        /// GPIOdev structure shall provide the capability of configuring the GPIO pins as
        /// power management bus.
        template <Muxfun m, GPIOid sda, GPIOid clk, GPIOid alert>
        static void apply_pmbus();
    }; // namespace GPIOdev


    template <Muxfun m, GPIOid rx, GPIOid tx>
    inline void GPIOdev::apply_sci()
    {
        /// \alg
        /// - Call GPIOioctl::apply passing to the template arguments below and with no function arguments:
        /// <ul>
        ///     <li> Templated "rx".
        ///     <li> GPIOtun::dir_input.
        ///     <li> GPIOtun::pu_dis.
        ///     <li> Templated "m".
        ///     <li> GPIOtun::qsel_async.
        /// </ul>
        /// - Call GPIOioctl::apply passing to the template arguments below and with no function arguments:
        /// <ul>
        ///     <li> Templated "tx".
        ///     <li> GPIOtun::dir_output.
        ///     <li> GPIOtun::pu_dis.
        ///     <li> Templated "m".
        ///     <li> GPIOtun::qsel_sync.
        /// </ul>
        GPIOioctl::apply<rx  ,GPIOtun::dir_input,  GPIOtun::pu_dis, m, GPIOtun::qsel_async>();
        GPIOioctl::apply<tx  ,GPIOtun::dir_output, GPIOtun::pu_dis, m, GPIOtun::qsel_sync >();
    }

    template <Muxfun m, GPIOid rx, GPIOid tx>
    inline void GPIOdev::apply_can()
    {
        /// \alg
        /// - Call GPIOioctl::apply passing to the template arguments below and with no function arguments:
        /// <ul>
        ///     <li> Templated "rx".
        ///     <li> GPIOtun::dir_input.
        ///     <li> GPIOtun::pu_en.
        ///     <li> Templated "m".
        ///     <li> GPIOtun::qsel_async.
        /// </ul>
        /// - Call GPIOioctl::apply passing to the template arguments below and with no function arguments:
        /// <ul>
        ///     <li> Templated "tx".
        ///     <li> GPIOtun::dir_output.
        ///     <li> GPIOtun::pu_en.
        ///     <li> Templated "m".
        ///     <li> GPIOtun::qsel_sync.
        /// </ul>
        GPIOioctl::apply<rx  ,GPIOtun::dir_input,  GPIOtun::pu_en, m, GPIOtun::qsel_async>();
        GPIOioctl::apply<tx  ,GPIOtun::dir_output, GPIOtun::pu_en, m, GPIOtun::qsel_sync >();
    }

    template <Muxfun m, GPIOid mdx, GPIOid mdr, GPIOid clk>
    inline void GPIOdev::apply3_mcbsp_master()
    {
        /// \alg
        /// - Call GPIOioctl::apply passing to the template arguments below and with no function arguments:
        /// <ul>
        ///     <li> Templated "mdx".
        ///     <li> GPIOtun::dir_output.
        ///     <li> GPIOtun::pu_dis.
        ///     <li> Templated "m".
        ///     <li> GPIOtun::qsel_sync.
        /// </ul>
        /// - Call GPIOioctl::apply passing to the template arguments below and with no function arguments:
        /// <ul>
        ///     <li> Templated "mdr".
        ///     <li> GPIOtun::dir_input.
        ///     <li> GPIOtun::pu_en.
        ///     <li> Templated "m".
        ///     <li> GPIOtun::qsel_async.
        /// </ul>
        /// - Call GPIOioctl::apply passing to the template arguments below and with no function arguments:
        /// <ul>
        ///     <li> Templated "clk".
        ///     <li> GPIOtun::dir_output.
        ///     <li> GPIOtun::pu_dis.
        ///     <li> Templated "m".
        ///     <li> GPIOtun::qsel_sync.
        /// </ul>
        GPIOioctl::apply<mdx ,GPIOtun::dir_output, GPIOtun::pu_dis, m, GPIOtun::qsel_sync >(); // simo/mdx/out
        GPIOioctl::apply<mdr ,GPIOtun::dir_input,  GPIOtun::pu_en,  m, GPIOtun::qsel_async>(); // somi/mdr/in
        GPIOioctl::apply<clk ,GPIOtun::dir_output, GPIOtun::pu_dis, m, GPIOtun::qsel_sync >(); // clk/out
    }

    template <Muxfun m, GPIOid mdx, GPIOid mdr, GPIOid clk, GPIOid cs>
    inline void GPIOdev::apply4_mcbsp_master()
    {
        /// \alg
        /// - Call ::apply3_mcbsp_master passing to the template arguments below and with no function arguments:
        /// <ul>
        ///     <li> Templated "m".
        ///     <li> Templated "mdx".
        ///     <li> Templated "mdr".
        ///     <li> Templated "clk".
        /// </ul>
        /// - Call GPIOioctl::apply passing to the template arguments below and with no function arguments:
        /// <ul>
        ///     <li> Templated "cs".
        ///     <li> GPIOtun::dir_output.
        ///     <li> GPIOtun::pu_dis.
        ///     <li> Templated "m".
        ///     <li> GPIOtun::qsel_sync.
        /// </ul>
        apply3_mcbsp_master<m,mdx,mdr,clk>();
        GPIOioctl::apply<cs  ,GPIOtun::dir_output , GPIOtun::pu_dis, m, GPIOtun::qsel_sync >(); // cs/mfsx/out
    }

    template <Muxfun m, GPIOid mdx, GPIOid mdr, GPIOid clk>
    inline void GPIOdev::apply3_mcbsp_slave()
    {
        /// \alg
        /// - Call GPIOioctl::apply passing to the template arguments below and with no function arguments:
        /// <ul>
        ///     <li> Templated "mdx".
        ///     <li> GPIOtun::dir_output.
        ///     <li> GPIOtun::pu_dis.
        ///     <li> Templated "m".
        ///     <li> GPIOtun::qsel_sync.
        /// </ul>
        /// - Call GPIOioctl::apply passing to the template arguments below and with no function arguments:
        /// <ul>
        ///     <li> Templated "mdr".
        ///     <li> GPIOtun::dir_input.
        ///     <li> GPIOtun::pu_en.
        ///     <li> Templated "m".
        ///     <li> GPIOtun::qsel_async.
        /// </ul>
        /// - Call GPIOioctl::apply passing to the template arguments below and with no function arguments:
        /// <ul>
        ///     <li> Templated "clk".
        ///     <li> GPIOtun::dir_input.
        ///     <li> GPIOtun::pu_en.
        ///     <li> Templated "m".
        ///     <li> GPIOtun::qsel_async.
        /// </ul>
        GPIOioctl::apply<mdx ,GPIOtun::dir_output, GPIOtun::pu_dis, m, GPIOtun::qsel_sync >(); // somi/mdx/out
        GPIOioctl::apply<mdr ,GPIOtun::dir_input,  GPIOtun::pu_en,  m, GPIOtun::qsel_async>(); // simo/mdr/in
        GPIOioctl::apply<clk ,GPIOtun::dir_input,  GPIOtun::pu_en,  m, GPIOtun::qsel_async>(); // clk/in
    }

    template <Muxfun m, GPIOid mdx, GPIOid mdr , GPIOid clk, GPIOid cs>
    inline void GPIOdev::apply4_mcbsp_slave()
    {
        /// \alg
        /// - Call ::apply3_mcbsp_slave passing to the template arguments below and with no function arguments:
        /// <ul>
        ///     <li> Templated "m".
        ///     <li> Templated "mdx".
        ///     <li> Templated "mdr".
        ///     <li> Templated "clk".
        /// </ul>
        /// - Call GPIOioctl::apply passing to the template arguments below and with no function arguments:
        /// <ul>
        ///     <li> Templated "cs".
        ///     <li> GPIOtun::dir_input.
        ///     <li> GPIOtun::pu_en.
        ///     <li> Templated "m".
        ///     <li> GPIOtun::qsel_async.
        /// </ul>
        apply3_mcbsp_slave<m,mdx,mdr,clk>();
        GPIOioctl::apply<cs  ,GPIOtun::dir_input , GPIOtun::pu_en, m, GPIOtun::qsel_async>(); // cs/mfsx/in
    }

    template <Muxfun m, GPIOid simo, GPIOid somi, GPIOid clk>
    inline void GPIOdev::apply3_spi()
    {
        /// \alg
        /// - Call GPIOioctl::apply passing to the template arguments below and with no function arguments:
        /// <ul>
        ///     <li> Templated "simo".
        ///     <li> GPIOtun::dir_output.
        ///     <li> GPIOtun::pu_dis.
        ///     <li> Templated "m".
        ///     <li> GPIOtun::qsel_async.
        /// </ul>
        /// - Call GPIOioctl::apply passing to the template arguments below and with no function arguments:
        /// <ul>
        ///     <li> Templated "somi".
        ///     <li> GPIOtun::dir_input.
        ///     <li> GPIOtun::pu_dis.
        ///     <li> Templated "m".
        ///     <li> GPIOtun::qsel_async.
        /// </ul>
        /// - Call GPIOioctl::apply passing to the template arguments below and with no function arguments:
        /// <ul>
        ///     <li> Templated "clk".
        ///     <li> GPIOtun::dir_output.
        ///     <li> GPIOtun::pu_dis.
        ///     <li> Templated "m".
        ///     <li> GPIOtun::qsel_async.
        /// </ul>
        GPIOioctl::apply<simo,GPIOtun::dir_output, GPIOtun::pu_dis, m, GPIOtun::qsel_async>(); // simo
        GPIOioctl::apply<somi,GPIOtun::dir_input,  GPIOtun::pu_dis, m, GPIOtun::qsel_async>(); // somi
        GPIOioctl::apply<clk ,GPIOtun::dir_output, GPIOtun::pu_dis, m, GPIOtun::qsel_async>(); // clk
    }

    template <Muxfun m, GPIOid simo, GPIOid somi, GPIOid clk, GPIOid cs>
    inline void GPIOdev::apply4_spi()
    {
        /// \alg
        /// - Call ::apply3_spi passing to the template arguments below and with no function arguments:
        /// <ul>
        ///     <li> Templated "m".
        ///     <li> Templated "simo".
        ///     <li> Templated "somi".
        ///     <li> Templated "clk".
        /// </ul>
        /// - Call GPIOioctl::apply passing to the template arguments below and with no function arguments:
        /// <ul>
        ///     <li> Templated "cs".
        ///     <li> GPIOtun::dir_output.
        ///     <li> GPIOtun::pu_dis.
        ///     <li> Templated "m".
        ///     <li> GPIOtun::qsel_async.
        /// </ul>
        apply3_spi<m, simo, somi, clk>();
        GPIOioctl::apply<cs, GPIOtun::dir_output, GPIOtun::pu_dis, m, GPIOtun::qsel_async>(); // cs
    }

    template <Muxfun m, GPIOid sda, GPIOid clk>
    inline void GPIOdev::apply_i2c()
    {
        /// \alg
        /// - Call GPIOioctl::apply passing to the template arguments below and with no function arguments:
        /// <ul>
        ///     <li> Templated "sda".
        ///     <li> GPIOtun::dir_output.
        ///     <li> GPIOtun::pu_dis.
        ///     <li> Templated "m".
        ///     <li> GPIOtun::qsel_async.
        /// </ul>
        /// - Call GPIOioctl::apply passing to the template arguments below and with no function arguments:
        /// <ul>
        ///     <li> Templated "clk".
        ///     <li> GPIOtun::dir_output.
        ///     <li> GPIOtun::pu_dis.
        ///     <li> Templated "m".
        ///     <li> GPIOtun::qsel_sync.
        /// </ul>
        GPIOioctl::apply<sda, GPIOtun::dir_output, GPIOtun::pu_dis, m, GPIOtun::qsel_async>();
        GPIOioctl::apply<clk, GPIOtun::dir_output, GPIOtun::pu_dis, m, GPIOtun::qsel_sync >();
    }

    template <Muxfun m, GPIOid usbid, GPIOid pflt, GPIOid epen>
    inline void GPIOdev::apply_usb()
    {
        /// \alg
        /// - Call GPIOioctl::apply_usb_pins with no arguments.
        /// - Call GPIOioctl::apply passing to the template arguments below and with no function arguments:
        /// <ul>
        ///     <li> Templated "usbid".
        ///     <li> GPIOtun::dir_input.
        ///     <li> GPIOtun::pu_dis.
        ///     <li> Dsp28335_ent::Muxfun::mux_gpio.
        ///     <li> GPIOtun::qsel_sync.
        /// </ul>
        /// - Call GPIOioctl::apply passing to the template arguments below and with no function arguments:
        /// <ul>
        ///     <li> Templated "pflt".
        ///     <li> GPIOtun::dir_input.
        ///     <li> GPIOtun::pu_dis.
        ///     <li> Templated "m".
        ///     <li> GPIOtun::qsel_sync.
        /// </ul>
        /// - Call GPIOioctl::apply passing to the template arguments below and with no function arguments:
        /// <ul>
        ///     <li> Templated "epen".
        ///     <li> GPIOtun::dir_input.
        ///     <li> GPIOtun::pu_dis.
        ///     <li> Templated "m".
        ///     <li> GPIOtun::qsel_sync.
        /// </ul>
        GPIOioctl::apply_usb_pins();   // D-, D+
        GPIOioctl::apply<usbid,GPIOtun::dir_input, GPIOtun::pu_dis, mux_gpio, GPIOtun::qsel_sync>();
        GPIOioctl::apply<pflt, GPIOtun::dir_input, GPIOtun::pu_dis, m, GPIOtun::qsel_sync>();
        GPIOioctl::apply<epen, GPIOtun::dir_input, GPIOtun::pu_dis, m, GPIOtun::qsel_sync>();
    }

    template <Muxfun m, GPIOid sda, GPIOid clk, GPIOid alert>
    inline void GPIOdev::apply_pmbus()
    {
        /// \alg
        /// - Call GPIOioctl::apply passing to the template arguments below and with no function arguments:
        /// <ul>
        ///     <li> Templated "sda".
        ///     <li> GPIOtun::dir_output.
        ///     <li> GPIOtun::pu_dis.
        ///     <li> Templated "m".
        ///     <li> GPIOtun::qsel_async.
        /// </ul>
        /// - Call GPIOioctl::apply passing to the template arguments below and with no function arguments:
        /// <ul>
        ///     <li> Templated "clk".
        ///     <li> GPIOtun::dir_output.
        ///     <li> GPIOtun::pu_dis.
        ///     <li> Templated "m".
        ///     <li> GPIOtun::qsel_sync.
        /// </ul>
        /// - Call GPIOioctl::apply passing to the template arguments below and with no function arguments:
        /// <ul>
        ///     <li> Templated "alert".
        ///     <li> GPIOtun::dir_input.
        ///     <li> GPIOtun::pu_dis.
        ///     <li> Templated "m".
        ///     <li> GPIOtun::qsel_async.
        /// </ul>
        GPIOioctl::apply<sda, GPIOtun::dir_output, GPIOtun::pu_dis, m, GPIOtun::qsel_async>();
        GPIOioctl::apply<clk, GPIOtun::dir_output, GPIOtun::pu_dis, m, GPIOtun::qsel_sync >();
        GPIOioctl::apply<alert, GPIOtun::dir_input, GPIOtun::pu_dis, m, GPIOtun::qsel_async>();
    }
}
#endif

