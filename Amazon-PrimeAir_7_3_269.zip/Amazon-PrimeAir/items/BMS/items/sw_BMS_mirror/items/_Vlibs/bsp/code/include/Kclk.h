#ifndef KCLK_H_
#define KCLK_H_

#include <Entypes.h>

namespace Bsp
{
    /// System clock constants.
    /// This is not a singleton on purpose to avoid calling get_instance for better performance.
    class Kclk
    {
    public:
        /// Crystal Configuration Getter.
        /// \wi{17916}
        /// Kclk class shall provide the capability to retrieve system crystal frequency.
        /// \rat  Platform dependent.
        /// \param[out] freq        Frequency of the installed crystal or oscillator.
        /// \param[out] is_crystal  Indicates if a crystal(true) or oscillator(false) is being used.
        static void get_sys_xtal_cfg(Uint32& freq, bool& is_crystal);
        /// System Clock Frequency Getter.
        /// \wi{17917}
        /// Kclk class shall provide the capability to retrieve the system desired system clock frequency.
        /// \return  Desired system clock frequency.
        static Uint32 get_sys_clk_freq();
        /// System Low Speed Clock Divider Getter.
        /// \wi{17918}
        /// Kclk class shall provide the capability to retrieve the system desired system low speed clock divider.
        /// \return  Desired system low speed clock divider.
        static Uint32 get_sys_ls_freq();

        /// System Clock Update.
        /// \wi{17919}
        /// Kclk class shall provide the capability to update the system clock and low speed clock divider.
        /// \pre SHALL be called on the very beginning of the code to ensure everyone sees the correct values.
        //  Only used in 28335.
        static void update_sys_clk();

        /// System Frequency Real Getter.
        /// \wi{17920}
        /// Kclk class shall provide the capability to retrieve the system frequency as Real.
        /// \return     System frequency as Real ::sysclkfreq_r32.
        static Real     get_sysclkfreq_r32();
        /// System Frequency Real64 Getter.
        /// \wi{20120}
        /// Kclk class shall provide the capability to retrieve the system frequency as Real64.
        /// \return     System frequency as Real ::sysclkfreq_r64.
        static Real     get_sysclkfreq_r64();
        /// System Frequency Uint32 Getter.
        /// \wi{17921}
        /// Kclk class shall provide the capability to retrieve the system frequency as Uint32.
        /// \return     System frequency as Uint32 ::sysclkfreq_u32.
        static Uint32   get_sysclkfreq_u32();
        /// System Period Getter.
        /// \wi{17922}
        /// Kclk class shall provide the capability to retrieve the system period.
        /// \return     System period ::sysclkperiod_r32.
        static Real     get_sysclkperiod_r32();
        /// System period Real64 Getter.
        /// \wi{19807}
        /// Kclk class shall provide the capability to retrieve the system period in Real64 precision.
        /// \return System period Real64 ::sysclkperiod_r64.
        static Real64   get_sysclkperiod_r64();
        /// System Low Speed Frequency Real Getter.
        /// \wi{17923}
        /// Kclk class shall provide the capability to retrieve the system low speed frequency as Real.
        /// \return     System low speed frequency as Real.
        static Real     get_lspclkfreq();
        /// System Low Speed Frequency Uint32 Getter.
        /// \wi{17924}
        /// Kclk class shall provide the capability to retrieve the system low speed frequency as Uint32.
        /// \return     System low speed frequency as Uint32 ::lspclkfreq32.
        static Uint32   get_lspclkfreq32();
    private:
        static Uint32   sysclkfreq_u32;   ///< System frequency in Hz as 32-bit unsigned integer.
        static Real64   sysclkfreq_r64;   ///< System frequency in Hz as double precision floating point.
        static Real     sysclkfreq_r32;   ///< System frequency in Hz as single precision floating point.
        static Real64   sysclkperiod_r64; ///< System period in seconds as double precision floating point.
        static Real     sysclkperiod_r32; ///< System period in seconds as single precision floating point.
        static Uint32   lspclkfreq32;     ///< Low speed frequency in Hz.
    };

    inline Real Kclk::get_sysclkfreq_r32()
    {
        return sysclkfreq_r32;
    }

    inline Real Kclk::get_sysclkfreq_r64()
    {
        return sysclkfreq_r64;
    }

    inline Uint32 Kclk::get_sysclkfreq_u32()
    {
        return sysclkfreq_u32;
    }

    inline Real Kclk::get_sysclkperiod_r32()
    {
        return sysclkperiod_r32;
    }

    inline Real64 Kclk::get_sysclkperiod_r64()
    {
        return sysclkperiod_r64;
    }

    inline Real Kclk::get_lspclkfreq()
    {
        return static_cast<Real>(get_lspclkfreq32());
    }

    inline Uint32 Kclk::get_lspclkfreq32()
    {
        return lspclkfreq32;
    }
}
#endif

