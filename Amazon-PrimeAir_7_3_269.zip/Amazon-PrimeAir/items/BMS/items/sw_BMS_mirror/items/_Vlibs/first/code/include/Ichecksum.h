#ifndef ICHECKSUM_H_
#define ICHECKSUM_H_

#include <Entypes.h>

namespace Base
{

    class Ichecksum
    {
    public:
        typedef Uint32 Tck;                     ///< Type Uint32 definition.
        static const Uint16 max_bits = 32;      ///< Max CRC bits.

        /// CRC Reset Computation Virtual Function Declaration.
        /// Ichecksum class shall provide a virtual function to reset the CRC.
        virtual void reset()=0;
        /// CRC Byte Updater Virtual Function Declaration.
        /// Ichecksum class shall provide a virtual function to update the CRC for a specific byte.
        /// \param[in] b        CRC Byte to be updated.
        virtual void update_byte(Uint8 b)=0;
        /// CRC Retriever Virtual Function Declaration.
        /// Ichecksum class shall provide a virtual function to retrieve the CRC.
        /// \return Computed CRC.
        virtual Tck get_value() const = 0;
        /// CRC Number of Bits Retriever Virtual Function Declaration.
        /// Ichecksum class shall provide a virtual function to retrieve the number of bits of the CRC.
        /// \return Number of bits of the CRC.
        virtual int16 get_nbits() const = 0;

    protected:
        /// Ckfletcher Default Constructor.
        /// Ichecksum class shall provide the capability to interface the checksum functionality.
        Ichecksum();
        /// Ckfletcher Default Destructor.
        /// Ichecksum class shall provide the capability to delete any instance of the class Ichecksum.
        ~Ichecksum();

    private:
        Ichecksum(const Ichecksum& orig);               ///< = delete.
        Ichecksum& operator=(const Ichecksum& orig);    ///< = delete.
    };


    inline Ichecksum::~Ichecksum() //PRQA S 2635 #destructor replaced with default
    {
    }

    inline Ichecksum::Ichecksum()
    {
    }

}

#endif

