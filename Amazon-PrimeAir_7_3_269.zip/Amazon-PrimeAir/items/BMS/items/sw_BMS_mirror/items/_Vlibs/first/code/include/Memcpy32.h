#ifndef MEMCPY32_H_
#define MEMCPY32_H_

#include <Entypes.h>
#include <Assertions.h>

namespace Base
{
    /// The Base library shall provide a structure to perform memory copying operations optimized for 32-bit data.
    struct Memcpy32
    {
        // TODO: Convert to ASM and include in array<T>::copy()
        /// Memory Copy Between Template Array.
        /// \wi{21175}
        /// Memcpy32 structure shall provide the capability to copy n positions of 32 bits from source to destination Templated arrays.
        /// \param[in] dst Destiny array where 32 bits data are going to be copied.
        /// \param[in] src Source array where 32 bits data are copied.
        /// from.
        /// \param[in] n Number of 32 bits positions to copy.
        template<typename T>
        static void copy(T* dst, const T* src, Uint16 n);

        /// Memory Copy Between Array.
        /// \wi{5968}
        /// Memcpy32 structure shall provide the capability to copy n positions of 32 bits from source to destination arrays.
        /// \param[in] dst Destiny array where 32 bits data are going to be copied.
        /// \param[in] src Source array where 32 bits data are copied.
        /// from.
        /// \param[in] n Number of 32 bits positions to copy.
        static void copy(void* dst,
                         const void* src,
                         Uint16 n);
    };


    template<typename T>
    inline void Memcpy32::copy(T* dst, const T* src, Uint16 n)
    {
        /// \alg
        /// - Check template byte size value is equal to 4.
        /// - Call ::copy with given "dst", "src" and "n".
        Assertions::Compile_time<size_bytes_t<T>::value==4>(); // T has to be 4 bytes in size
        copy(static_cast<void*>(dst),static_cast<const void*>(src),n);
    }
}
#endif
