#ifndef I2CIF_H__
#define I2CIF_H__

#include <Async_transfer_data.h>
#include <GPIO.h>
#include <Timeout.h>
#include <U8pkmblock_k.h>

namespace Dsp28335_ent
{
    /// I2C peripheral driver to handle communication using 283x TI's platform I2C module peripheral.
    class I2Cif
    {
    public:
        /// I2C identifier.
        enum Id
        {
            id_i2c_a   = 0,     ///< I2C-A.
            id_i2c_b   = 1,     ///< I2C-B.
            id_i2c_all = 2      ///< Both (I2C A and B).
        };

        /// I2C communication speed.
        enum Speed
        {
            i2c_100Khz = 0,     ///< I2C to 100KHz.
            i2c_400Khz = 1      ///< I2C to 400KHz.
        };

        /// I2C status.
        enum Status
        {
            i2c_ok,             ///< No error.
            i2c_busy,           ///< I2C busy.
            i2c_arb_lost,       ///< Arbitration lost.
            i2c_nack,           ///< Non-acknowledgment.
            i2c_error_rx,       ///< Error during read operation.
            i2c_error_tx,       ///< Error during write operation.
            i2c_slave_err,      ///< Address as slave.
            i2c_stp_not_ready,  ///< Previous I2C operation not stopped.
            i2c_lockup          ///< I2C lock-up.
        };

        /// I2C peripheral driver constructor.
        /// \wi{7567}
        /// I2Cif class shall initialize itself upon construction with provided parameters.
        /// \param[in] id       I2C identifier.
        /// \param[in] sda_id   Identifier for SDA's GPIO.
        /// \param[in] clk_id   Identifier for SCL's GPIO.
        /// \param[in] speed0   I2C Speed (in hertz).
        I2Cif(Id id, GPIOid sda_id, GPIOid clk_id, Speed speed0);

        /// I2C peripheral driver initialization.
        /// \wi{7568}
        /// I2Cif class shall be able to initialize underlying I2C line through dedicated peripheral registers.
        void init();

        /// I2C peripheral driver speed configuration.
        /// \wi{7570}
        /// I2Cif class shall be able to configure its peripheral speed from provided speed identifier.
        /// \param[in] nspeed   Speed identifier to be configured.
        /// \rat Available speeds are: <ul> <li> (0) 100KHz, <li> (1) 400KHz. </ul>
        void set_speed(Speed nspeed);

        /// I2C peripheral driver identifier.
        /// \wi{7571}
        /// I2Cif class shall provide the capability to retrieve its underlying I2C line (fixed at \wi{7567}).
        // \return I2C identifier as: <ul> <li> (0) if I2C-A, <li> (1) if I2C-B, <li> (2) if both.
        Id get_id() const;

        /// I2C peripheral driver busy.
        /// \wi{7572}
        /// I2Cif class shall provide the capability to determine if an operation was started but not finished yet.
        /// \return True if driver OR peripheral is in busy state.
        bool is_busy() const;

        /// I2C peripheral driver OK.
        /// \wi{7573}
        /// I2Cif class shall be able to determine if last operation finished without error.
        /// \return True if status equals to status_ok, else return False.
        bool is_ok() const;

        /// I2C peripheral driver transmit fail count.
        /// \wi{7574}
        /// I2Cif class shall provide the capability to retrieve the number of write operation that finished
        /// with a STOP condition with pending content to be sent.
        /// \return Transmission error count.
        Uint16 get_tx_fails() const;

        /// I2C peripheral driver receive fail count.
        /// \wi{7575}
        /// I2Cif class shall provide the capability to retrieve the number of read operation that finished
        /// with a STOP condition with pending content to be read.
        /// \return Transmission error count.
        Uint16 get_rx_fails() const;

        /// I2C peripheral driver start write.
        /// \wi{7576}
        /// I2Cif class shall provide the capability to start a write operation on its associated I2C bus using
        /// provided parameters.
        /// \param[in] addr     I2C-slave address
        /// \param[in] mb_tx0   Constant memory block containing bytes to write
        /// \param[in] has_stop At true to assert a stop condition at the end of the request.
        /// \return True if operation started, else return False.
        bool start_write(Uint16 addr, const Base::U8pkmblock_k& mb_tx0, bool has_stop = true);

        /// I2C peripheral driver start read.
        /// \wi{7577}
        /// I2Cif class shall provide the capability to start a read operation on its associated I2C bus using
        /// provided parameters.
        /// \param[in] addr     I2C-slave address
        /// \param[out] mb_rx0  Memory block to store read content
        /// \param[in] has_stop At true to assert a stop condition at the end of the request.
        /// \param True if operation started, else return False.
        bool start_read(Uint16 addr, Base::U8pkmblock& mb_rx0, bool has_stop = true);

        /// I2C peripheral driver polling.
        /// \wi{7569}
        /// I2Cif class shall provide the capability to poll the underlying I2C peripheral.
        /// \rat Refers to the sequence diagram onto related \dia.
        void step();

        /// I2C peripheral driver disabling.
        /// \wi{7578}
        /// I2Cif class shall be able to disable its associated I2C peripheral module by: <ul>
        /// <li> Disabling the I2C peripheral module,
        /// <li> Fixing both SCL and SDA GPIOs to input,
        /// <li> Wait 50 nanoseconds (to ensure changes are effective).
        /// \rat Shall be implemented for each platform.
        void disable();

    private:
        /// I2C mode register bits
        enum MDRbits
        {
            mdr_stb = 1 << Ku16::u4,    ///< Start
            mdr_irs = 1 << Ku16::u5,    ///< Reset
            mdr_trx = 1 << Ku16::u9,    ///< Transmit mode
            mdr_mst = 1 << Ku16::u10,   ///< Master mode
            mdr_stp = 1 << Ku16::u11,   ///< Stop condition
            mdr_stt = 1 << Ku16::u13    ///< Start condition
        };

        static const Uint16 fifo_sz = Ku16::u16;    ///< Peripheral FIFO size (in number of bytes, from SPRUG03B)

        /// Max queued bit transfer count (bytes: 1 address + 16 data, each: 8 data + 1 ack bit + 1 start)
        static const Uint16 max_queued_bits = 17*10;

        static const Uint32 speed_100Khz = 100000U;
        static const Uint32 speed_400Khz = 400000U;

        GPIOid clk_id;  ///< GPIO Identifier for SCL
        GPIO sda;       ///< GPIO Handler for SDA
        GPIO clk;       ///< GPIO Handler for SCL

        Id id;          ///< I2C identifier
        Speed speed;    ///< Current speed

        volatile bool busy;         ///< I2C busy (current operation pending)
        Base::Timeout busy_tout;    ///< Timeout chrono

        Uint16 rx_fails;            ///< RX reception error count.
        Uint16 tx_fails;            ///< TX transmission error count.

        Status status;              ///< Variable to store I2C status

        Base::Async_transfer_data   op_adata;       ///< Data record for asynchronous transfers
        Base::U8pkmblock            mb_rx;          ///< Memory block for read operations
        Base::U8pkmblock_k          mb_tx;          ///< Data recorder for write operations

        /// At true when write operation, else at False
        bool is_write_op;

        /// When set to True, current request will not assert a stop condition, allowing to perform other requests
        ///     with its respective start condition, until a stop is asserted.
        bool is_repeated_mode;

        struct Regs;
        volatile Regs& regs;    ///< I2C configuration registers, depend on platform.

        /// I2C peripheral driver peripheral registers.
        /// \wi{16672}
        /// I2Cif class shall provide the capability to retrieve its I2C module's peripheral registers.
        /// \return Reference to I2C module's peripheral registers.
        /// \rat Shall be implemented for each platform.
        volatile Regs& get_regs();

        /// I2C peripheral driver clock enabling.
        /// \wi{16673}
        /// I2Cif class shall provide the capability to enable its I2C module's peripheral clock.
        /// \rat Shall be implemented for each platform.
        void set_clk_enable();

        /// I2C peripheral driver SCL configuration.
        /// \wi{16674}
        /// I2Cif class shall provide the capability to configure its SCL's GPIO to be controlled by GPIO or by I2C
        /// peripheral driver in function of provided parameter.
        /// \param[in] sync     At true, to be controlled by I2C, at false by GPIO.
        /// \rat Shall be implemented for each platform.
        void config_gpio(bool sync);

        /// I2C peripheral driver set busy.
        /// \wi{16675}
        /// I2Cif class shall be able to set its ::busy attribute to True and to start related ::busy_tout.
        void set_busy();

        /// I2C peripheral driver set free.
        /// \wi{16676}
        /// I2Cif class shall be able to set its ::busy attribute to False.
        void clear_busy();

        /// I2C peripheral driver enable/disable peripheral.
        /// \wi{16677}
        /// I2Cif class shall provide the capability to enable or disable its I2C module's peripheral from parameter.
        /// \param[in] value        At true to enable the module, at false to disable it.
        void set_enabled(bool value);

        /// I2C peripheral driver assert stop.
        /// \wi{16678}
        /// I2Cif class shall be able to assert a STOP condition on the bus and to clear ::busy attribute (to false).
        void stop();

        /// I2C peripheral driver reset.
        /// \wi{16679}
        /// I2Cif class shall be able to reset the module by disabling the peripheral and clearing ::busy to false.
        void reset();

        /// I2C peripheral driver recover arbitration.
        /// \wi{16680}
        /// I2Cif class shall provide the capability to recover the arbitration of the underlying I2C line.
        void recover_arb();

        /// I2C peripheral driver set status.
        /// \wi{16681}
        /// I2Cif class shall be able to set its internal ::status attribute to provided value.
        /// \param[in] status0      Status to be set.
        void set_status(Status status0);

        /// I2C peripheral driver start operation.
        /// \wi{16682}
        /// I2Cif class shall be able to start an I2C operation from provided parameters.
        /// \param[in] is_wr0       True to write, False to read.
        /// \param[in] addr0        Slave address.
        void start_operation(bool is_wr0, Uint16 addr0);

        /// I2C peripheral driver bulk transmit.
        /// \wi{16683}
        /// I2Cif class shall be able to bulk data from memory block to dedicated peripheral FIFO.
        void bulk_tx();

        /// I2C peripheral driver bulk received.
        /// \wi{16884}
        /// I2Cif class shall be able to bulk received data from peripheral FIFO to dedicated memory block.
        void bulk_rx();

        /// I2C peripheral driver transmission error.
        /// \wi{16885}
        /// I2Cif class shall be able to reset transmit FIFO, and to increment and report write operation error.
        void tx_error();

        /// I2C peripheral driver reception error.
        /// \wi{16886}
        /// I2Cif class shall be able to reset receive FIFO, and to increment and report read operation error.
        void rx_error();

        /// I2C peripheral driver operation error.
        /// \wi{16887}
        /// I2Cif class shall provide the capability to report an operation error by forwarding call to relevant error
        /// method as \wi{16885} or \wi{16886} for respective write and read operations.
        void op_error();

        /// I2C peripheral driver expected FIFO count.
        /// \wi{16888}
        /// I2Cif class shall be able to check if FIFO count have the expected value.
        /// \param[in] bulk_rx0     At true if read content from FIFO shall be bulked to its related memory block.
        /// \return <ul> <li> At write operation, return True if peripheral transmit FIFO is empty, else return False.
        /// <li> At read operation, return True if receive FIFO count rely memory block size, else return False.
        bool check_fifo(bool bulk_rx0);

        /// I2C peripheral driver check transfer.
        /// \wi{16889}
        /// I2Cif class shall be able to check if a transfer has finished or not.
        /// \param[in] bulk_rx0     At true if read content from FIFO shall be bulked to its related memory block.
        /// \return True if both FIFO status and I2C CNT match with current transfer size.
        bool check_transfer(bool bulk_rx0);

        /// I2C peripheral driver check expired.
        /// \wi{16890}
        /// I2Cif class shall be able to check if it's ::busy_tout have expired.
        /// \return True if time out expired and take the necessary steps.
        /// \rat Set ::status to ::i2c_lockup and try to recover the arbitration as described at \wi{16680}).
        bool check_tout();

        /// I2C peripheral driver check peripheral registers.
        /// \wi{16891}
        /// \return True if an error was detected through peripheral status register and take the necessary steps.
        bool check_regs();

        /// I2C peripheral driver check finished operation.
        /// \wi{16892}
        /// I2Cif class shall provide the capability to check if current operation has finished
        /// and to take the necessary steps.
        /// \rat Refers to the sequence diagram onto related \dia{7569}.
        void finish();

        I2Cif(const I2Cif& orig); ///< = delete
        I2Cif& operator=(const I2Cif& orig); ///< = delete
    };


    inline I2Cif::Id I2Cif::get_id() const
    {
        return id;
    }

    inline bool I2Cif::is_ok() const
    {
        return status == i2c_ok;
    }

    inline Uint16 I2Cif::get_tx_fails() const
    {
        return tx_fails;
    }

    inline Uint16 I2Cif::get_rx_fails() const
    {
        return rx_fails;
    }

    inline void I2Cif::set_busy()
    {
        busy = true;
        busy_tout.start();
    }

    inline void I2Cif::clear_busy()
    {
        busy = false;
    }

    inline void I2Cif::set_status(Status status0)
    {
        status = status0;
    }
}
#endif
