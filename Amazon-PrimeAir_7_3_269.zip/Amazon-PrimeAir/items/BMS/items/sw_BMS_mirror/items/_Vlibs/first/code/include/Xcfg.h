#ifndef XCFG_H_
#define XCFG_H_

#include <Xcfg_fw.h>
#include <Tundefault.h>
#include <Twraptun.h>

namespace Base
{
    /// Type definitions for cset/cget configurables read by cpu 1.
    template <typename XCFG, typename TUNTRAIT>
    struct Xcfg
    {
        /// Raw cfg data.
        typedef XCFG                                                Type_podcfg;
        /// type for shared memory (cfg + sync).
        typedef Tdsync<XCFG, Tdsynctraits::Rd_blocking<XCFG> >      Type_podsync;
        /// type for shared memory (cfg + sync). const version
        typedef const volatile Type_podsync                         Type_kpodsync;
        /// Tuntrait combined with Wsync
        typedef Tuntraits::Wsync<Type_podsync, TUNTRAIT>            Type_wstuntrait;
        /// Type to add to cfgmgr.
        typedef Twraptun<Type_wstuntrait, Type_podsync&>            Type_tun;
        /// Type for reader.
        typedef typename Type_podsync::Rdsafe0                      Type_rd;
    };
}
#endif
