#ifndef CLKCFGB_H_
#define CLKCFGB_H_

namespace Dsp28335_ent
{

    /// CLK CFG B registers handler.
    class Clkcfgb
    {
    public:
        /// EMIF1 Clock Divide Select
        enum Emif1_clk_div_sel
        {
            emif1_div_by_1 = 0,     ///< /1 of PLLSYSCLK is selected
            emif1_div_by_2 = 1      ///< /2 of PLLSYSCLK is selected
        };

        /// EPWM Clock Divide Select
        enum Pwm_clk_div_sel
        {
            pwm_div_by_1 = 0,       ///< /1 of PLLSYSCLK is selected
            pwm_div_by_2 = 1        ///< /2 of PLLSYSCLK is selected
        };

        Clkcfgb();

        /// Set the EMIf1 clk divider.
        void set_emif1_clk_div_sel(Emif1_clk_div_sel sel);

        /// Set the PWM clk divider.
        void set_pwm_clk_div_sel(Pwm_clk_div_sel sel);

    private:
        struct Clkcfg_regs;

        volatile Clkcfg_regs& regs;

        Clkcfgb(const Clkcfgb& orig); // = delete
        Clkcfgb& operator=(const Clkcfgb& orig); // = delete
    };

} // namespace Dsp28335_ent

#endif // CLKCFGB_H_
