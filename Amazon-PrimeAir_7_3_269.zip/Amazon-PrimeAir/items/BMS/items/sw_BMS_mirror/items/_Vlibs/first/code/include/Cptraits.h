#ifndef CPTRAITS_H_
#define CPTRAITS_H_

#include <Assertions.h>
#include <Memcpy32.h>
#include <Tmem.h>
#include <Ku16.h>
#include <Union_compatible.h>

namespace Base
{
    /// Policies to copy an object
    struct Cptraits
    {
    public:
        template <typename T1, typename T2>
        struct Cptypedefs
        {
            typedef T1 Type_from;
            typedef T2 Type_to;
        };

        // Calls set on destination element
        template <typename T1, typename T2=T1>
        struct Set : Cptypedefs<T1, T2>
        {
            /// Cptraits Set Copy.
            /// \wi{4979}
            /// Set structure shall provide the capability to copy a structure to another one.
            /// \param[in] from     Source structure to copy.
            /// \param[out] to      Destination structure to set.
            static void copy(const T1& from, T2& to);
        };

        template <typename T1, typename T2=T1>
        struct Getbyref : Cptypedefs<T1, T2>
        {
            /// Cptraits Getbyref Copy.
            /// \wi{4980}
            /// Getbyref structure shall provide the capability to copy a structure to another one by reference.
            /// \param[in] from     Source structure to get.
            /// \param[out] to      Destination structure.
            static void copy(const T1& from, T2& to);
        };

        template <typename T1, typename T2=T1>
        struct Getbyvalue : Cptypedefs<T1, T2>
        {
            /// Cptraits Getbyvalue Copy.
            /// \wi{4981}
            /// Getbyvalue structure shall provide the capability to copy a structure to another one by value.
            /// \param[in] from     Source structure to get.
            /// \param[out] to      Destination structure.
            static void copy(const T1& from, T2& to);
        };

        template <typename T1, typename T2=T1>
        struct Array_memcpybool : Cptypedefs<T1, T2>
        {
            /// Cptraits Array_memcpybool Copy.
            /// \wi{17913}
            /// Array_memcpybool structure shall provide the capability to copy a parameterized array of elements
            /// to another one using Tmem::cpy_sel.
            /// \param[in]  from    Source structure to get.
            /// \param[out] to      Destination structure.
            static void copy(const T1& from, T2& to);
        };

        template <typename T1, typename T2=T1>
        struct Array_memcpy16 : Cptypedefs<T1, T2>
        {
            /// Cptraits Array_memcpy16 Copy.
            /// \wi{4982}
            /// Array_memcpy16 structure shall provide the capability to copy a parameterized array of elements
            /// to another one using Tmem::cpy_sel.
            /// \param[in]  from    Source structure to get.
            /// \param[out] to      Destination structure.
            static void copy(const T1& from, T2& to);
        };

        template <typename T1, typename T2=T1>
        struct Array_memcpy32 : Cptypedefs<T1, T2>
        {
            /// Cptraits Array_memcpy32 Copy.
            /// \wi{4983}
            /// Array_memcpy32 structure shall provide the capability to copy a parameterized array of elements
            /// to another one using Memcpy32::copy.
            /// \param[in]  from    Source structure to get.
            /// \param[out] to      Destination structure.
            static void copy(const T1& from, T2& to);
        };

        /// Useful to copy from volatile, that is not supported by default copy nor memcpy
        template <typename T>
        struct Podraw : Cptypedefs<T, T>
        {
            /// Cptraits Podraw Copy.
            /// \wi{4984}
            /// Podraw structure shall provide the capability to copy PODs structures.
            /// \param[in]  from    Source POD structure to get.
            /// \param[out] to      Destination POD structure.
            static void copy(const T& from, T& to);
        private:
            typedef typename Remove_cv<T>::type Type_nocv;
        };

        /// Uses "copy" method.
        template <typename TF, typename TT>
        struct Copy : Cptypedefs<TF, TT>
        {
            /// Cptraits Copy Copy.
            /// \wi{17914}
            /// Copy structure shall provide the capability to copy a structure to another one using a copy method.
            /// \param[in] from     Source structure to get.
            /// \param[out] to      Destination structure.
            inline static void copy(TF& from, TT& to)
            {
                const_cast<Type_to&>(to).copy(const_cast<const Type_from&>(from));
            }
        private:
            typedef typename Remove_cv<TT>::type       Type_to;
            typedef typename Remove_volatile<TF>::type Type_from;
        };


        /// Uses operator '='
        template <typename T1, typename T2=T1>
        struct Operator : Cptypedefs<T1, T2>
        {
            /// Cptraits Operator Copy.
            /// \wi{4985}
            /// Operator structure shall provide the capability to copy a structure to another one using "=" operator.
            /// \param[in] from     Source structure to get.
            /// \param[out] to      Destination structure.
            static void copy(const T1& from, T2& to)
            {
                to=from;
            }
        };

    private:
        Cptraits(); ///< = delete
        Cptraits(const Cptraits& orig); ///< = delete
        Cptraits& operator=(const Cptraits& orig); ///< = delete
    };



    template <typename T1, typename T2>
    inline void Cptraits::Set<T1,T2>::copy(const T1& from, T2& to) //PRQA S 4283
    {
        to.set(from);
    }

    template <typename T1, typename T2>
    inline void Cptraits::Getbyref<T1,T2>::copy(const T1& from, T2& to)
    {
        from.get(to);
    }

    template <typename T1, typename T2>
    inline void Cptraits::Getbyvalue<T1,T2>::copy(const T1& from, T2& to)
    {
        to=from.get();
    }

    template <typename T1, typename T2>
    inline void Cptraits::Array_memcpybool<T1,T2>::copy(const T1& from, T2& to)
    {
        const volatile void* from0 = &from[0];
        const volatile void* to0 = &to[0];
        Tmem::cpy_sel(const_cast<void*>(to0), const_cast<void*>(from0), to.size()*(sizeof(to[Ku16::u0])));
    }

    template <typename T1, typename T2>
    inline void Cptraits::Array_memcpy16<T1,T2>::copy(const T1& from, T2& to)
    {
        const volatile void* from0 = &from[0];
        const volatile void* to0 = &to[0];
        Tmem::cpy_sel(const_cast<void*>(to0), const_cast<void*>(from0), to.size()*(sizeof(to[Ku16::u0])));
    }

    template <typename T1, typename T2>
    inline void Cptraits::Array_memcpy32<T1,T2>::copy(const T1& from, T2& to)
    {
        const volatile void* from0 = &from[0];
        const volatile void* to0 = &to[0];
        Memcpy32::copy(const_cast<void*>(to0),
                       const_cast<void*>(from0),
                       static_cast<Uint16>(to.size()*((sizeof(to[Ku16::u0]))/sizeof(Uint32))));
    }

    template <typename T>
    inline void Cptraits::Podraw<T>::copy(const T& from, T& to)
    {
        Assertions::Union_compatible<T>(); // replace by is_pod when available
        Tmem::cpy<sizeof(T)>(const_cast<Type_nocv*>(&to), const_cast<const Type_nocv*>(&from));
    }
}
#endif
