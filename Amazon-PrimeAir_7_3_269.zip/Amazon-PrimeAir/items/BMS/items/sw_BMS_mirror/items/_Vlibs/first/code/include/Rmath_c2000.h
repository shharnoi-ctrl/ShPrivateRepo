#ifndef RMATH_C2000_H_
#define RMATH_C2000_H_

#include <Entypes.h>
#include <math.h>
#include <fpu_vector.h>

/// Contains access methods to native math library math.h.
namespace Rmath
{
    /// Arc Cosine Retriever.
    /// \wi{5157}
    /// Rmath shall provide a method to retrieve the arc cosine value of given "x".
    /// \param[in] x Real value representing the angle in radians.
    /// \return Arc Cosine Real value from the given input.
    inline Real acosr (Real x)
    {
        /// \alg
        ///  - Return arc cosine of given "x" value computed calling to acosf function of native math library.
        return acosf(x);
    }
    /// Arc Sine Retriever.
    /// \wi{5158}
    /// Rmath shall provide a method to retrieve the arc sine value of given "x".
    /// \param[in] x Real value representing the angle in radians.
    /// \return Arc Sine Real value from the given input.
    inline Real asinr (Real x)
    {
        /// \alg
        ///  - Return arc sine of given "x" value computed calling to asinf function of native math library.
        return asinf(x);
    }
    /// Arc Tangent Retriever.
    /// \wi{5159}
    /// Rmath shall provide a method to retrieve the arc tangent value of "x".
    /// \param[in] x Real value representing the angle in radians.
    /// \return Arc Tangent Real value from the given input.
    inline Real atanr (Real x)
    {
        /// \alg
        ///  - Return arc tangent of given "x" value computed calling to atanf function of native math library.
        return atanf(x);
    }
    /// Arc Tangent Two Arguments Real Value Retriever.
    /// \wi{5160}
    /// Rmath shall provide a method to retrieve the arc tangent of "y" / "x".
    /// \param[in] y Real value representing the angle in radians.
    /// \param[in] x Real value representing the angle in radians.
    /// \return Arc Tangent Real value from the given input instances.
    inline Real atan2r (Real y, Real x)
    {
        /// \alg
        ///  - Return arc tangent of given "y" and "x" values computed calling
        /// to atan2f function of native math library.
        return atan2f(y,x);
    }
    /// Arc Tangent Two Arguments Real64 Value Retriever.
    /// \wi{21434}
    /// Rmath shall provide a method to retrieve the arc tangent of "y" / "x".
    /// \param[in] y Real64 value representing the angle in radians.
    /// \param[in] x Real64 value representing the angle in radians.
    /// \return Arc Tangent Real64 value from the given input instances.
    inline Real64 atan2r (Real64 y, Real64 x)
    {
        /// \alg
        ///  - Return arc tangent of given "y" and "x" values computed calling
        /// to atan2l function of native math library.
        return atan2l(y, x);
    }
    /// Cosine Real Value Retriever.
    /// \wi{4978}
    /// Rmath shall provide a method to retrieve the cosine value of "x".
    /// \param[in] x Real value representing the angle in radians.
    /// \return Cosine Real value from the given input instance.
    inline Real cosr (Real x)
    {
        /// \alg
        ///  - Return cosine of given "x" value computed calling to cosf function of native math library.
        return cosf(x);
    }
    /// Cosine Real64 Value Retriever.
    /// \wi{21435}
    /// Rmath shall provide a method to retrieve the cosine value of "x".
    /// \param[in] x Real64 value representing the angle in radians.
    /// \return Cosine Real64 value from the given input instance.
    inline Real64 cosr (Real64 x)
    {
        /// \alg
        ///  - Return cosine of given "x" value computed calling to cosl function of native math library.
        return cosl(x);
    }
    /// Sine Real Value Retriever.
    /// \wi{4977}
    /// Rmath shall provide a method to retrieve the sine value of "x".
    /// \param[in] x Real value representing the angle in radians.
    /// \return Sine Real value from the given input instance.
    inline Real sinr (Real x)
    {
        /// \alg
        ///  - Return sine of given "x" value computed calling to sinf function of native math library.
        return sinf(x);
    }
    /// Sine Real64 Value Retriever.
    /// \wi{21436}
    /// Rmath shall provide a method to retrieve the sine value of "x".
    /// \param[in] x Real64 value representing the angle in radians.
    /// \return Sine Real64 value from the given input instance.
    inline Real64 sinr (Real64 x)
    {
        /// \alg
        ///  - Return sine of given "x" value computed calling to sinl function of native math library.
        return sinl(x);
    }
    /// Tangent Retriever.
    /// \wi{5161}
    /// Rmath shall provide a method to retrieve the tangent value of "x".
    /// \param[in] x Real value representing the angle in radians.
    /// \return Tangent Real value from the given input instance.
    inline Real tanr (Real x)
    {
        /// \alg
        ///  - Return tangent of given "x" value computed calling to tanf function of native math library.
        return tanf(x);
    }
    /// Hyperbolic Tangent Retriever.
    /// \wi{18353}
    /// Rmath shall provide a method to retrieve the hyperbolic tangent value of "x".
    /// \param[in] x Real value representing the angle in radians.
    /// \return Hyperbolic tangent Real value from the given input instance.
    inline Real tanhr(Real x)
    {
        /// \alg
        ///  - Return hyperbolic tangent of given "x" value computed calling to tanhf function of native math library.
        return tanhf(x);
    }
    /// Exponential Retriever.
    /// \wi{5162}
    /// Rmath shall provide a method to retrieve the exponential value of "x".
    /// \param[in] x Real value representing the angle.
    /// \return Exponential Real value from the given input instance.
    inline Real expr (Real x)
    {
        /// \alg
        ///  - Return exponential of given "x" value computed calling to expf function of native math library.
        return expf(x);
    }
    /// Exponential Minus One Retriever.
    /// \wi{5163}
    /// Rmath shall provide a method to retrieve the value of the exponential minus one of "x".
    /// \param[in] x Real value representing the angle.
    /// \return Exponential minus one Real value from the given input instance.
    inline Real expm1r(Real x)
    {
        /// \alg
        ///  - Return exponential minus one of given "x" value computed calling
        /// to expm1f function of native math library.
        return expm1f(x);
    }
    /// Natural Logarithm Retriever.
    /// \wi{5164}
    /// Rmath shall provide a method to retrieve the value of the natural logarithm of "x".
    /// \param[in] x Real value representing the angle.
    /// \return Natural logarithm Real value from the given input instance.
    inline Real logr (Real x)
    {
        /// \alg
        ///  - Return natural logarithm Real value of given "x" value computed calling
        /// to logf function of native math library.
        return logf(x);
    }
    /// Absolute Real Value Retriever.
    /// \wi{5165}
    /// Rmath shall provide a method to retrieve the absolute Real value of "x".
    /// \param[in] x Real value representing the angle.
    /// \return Absolute Real value from the given input instance.
    inline Real fabsr (Real x)
    {
        /// \alg
        ///  - Return absolute Real of given "x" value computed calling to fabsf function of native math library.
        return fabsf(x);
    }
    /// Absolute Real64 Value Retriever.
    /// \wi{21437}
    /// Rmath shall provide a method to retrieve the absolute Real64 value of "x".
    /// \param[in] x Real64 value representing the angle.
    /// \return Absolute Real64 value from the given input instance.
    inline Real64 fabsr (Real64 x)
    {
        /// \alg
        ///  - Return absolute Real64 of given "x" value computed calling to fabsl function of native math library.
        return fabsl(x);
    }
    /// Power Exponent Retriever for Real.
    /// \wi{5166}
    /// Rmath shall provide a method to retrieve the power exponent value of given base "x" and exponent "y".
    /// \param[in] x Real value representing the base.
    /// \param[in] y Real value representing the exponent.
    /// \return Power exponent value from the given base and exponent input instances.
    inline Real powr (Real x, Real y)
    {
        /// \alg
        ///  - Return power exponent value of given "x" and "y" values computed calling
        /// to powf function of native math library.
        return powf(x,y);
    }
    /// Power Exponent Retriever for Real64.
    /// \wi{21438}
    /// Rmath shall provide a method to retrieve the power exponent value of given base "x" and exponent "y".
    /// \param[in] x Real64 value representing the base.
    /// \param[in] y Real64 value representing the exponent.
    /// \return Power exponent value from the given base and exponent input instances.
    inline Real64 powr (Real64 x, Real64 y)
    {
        /// \alg
        ///  - Return power exponent value of given "x" and "y" values computed calling
        /// to powl function of native math library.
        return powl(x,y);
    }
    /// Power Exponent Retriever for Real.
    /// \wi{21439}
    /// Rmath shall provide a method to retrieve the power exponent value of given base "x" and exponent "y".
    /// \param[in] x Real value representing the base.
    /// \param[in] y Real value representing the exponent.
    /// \return Power exponent value from the given base and exponent input instances.
    inline Real sqrtr (Real x)
    {
        /// \alg
        ///  - Return power exponent value of given "x" and "y" values computed calling
        /// to sqrtf function of native math library.
        return sqrtf(x);
    }
    /// Power Exponent Retriever for Real64.
    /// \wi{21440}
    /// Rmath shall provide a method to retrieve the power exponent value of given base "x" and exponent "y".
    /// \param[in] x Real64 value representing the base.
    /// \param[in] y Real64 value representing the exponent.
    /// \return Power exponent value from the given base and exponent input instances.
    inline Real64 sqrtr (Real64 x)
    {
        /// \alg
        ///  - Return power exponent value of given "x" and "y" values computed calling
        /// to sqrtl function of native math library.
        return sqrtl(x);
    }
    /// Ceiling Retriever.
    /// \wi{5168}
    /// Rmath shall provide a method to retrieve the value of the
    /// smallest integer value greater than or equal to the given Real number "x".
    /// \param[in] x Real value representing the input.
    /// \return Ceiling Real value from the given input instance.
    inline Real ceilr (Real x)
    {
        /// \alg
        ///  - Return ceiling of given "x" value computed calling to ceilf function of native math library.
        return ceilf(x);
    }
    /// Floor Real Value Retriever.
    /// \wi{5169}
    /// Rmath shall provide a method to retrieve the value of the
    /// largest integer value less than or equal to the given Real number of "x".
    /// \param[in] x Real value representing the input.
    /// \return Floor Real value from the given input instance.
    inline Real floorr (Real x)
    {
        /// \alg
        ///  - Return Floor of given "x" value computed calling to floorf function of native math library.
        return floorf(x);
    }
    /// Floor Real64 Value Retriever.
    /// \wi{21441}
    /// Rmath shall provide a method to retrieve the value of the
    /// largest integer value less than or equal to the given Real64 number of "x".
    /// \param[in] x Real64 value representing the input.
    /// \return Floor Real64 value from the given input instance.
    inline Real64 floorr (Real64 x)
    {
        /// \alg
        ///  - Return Floor of given "x" value computed calling to floorl function of native math library.
        return floorl(x);
    }
    /// Floating-Point Remainder Retriever.
    /// \wi{5170}
    /// Rmath shall provide a method to retrieve the value of the
    /// floating-point remainder of dividing two Real numbers "y" / "x".
    /// \param[in] x Real value representing the dividend.
    /// \param[in] y Real value representing the divisor.
    /// \return Floating-point remainder from the given dividend and divisor values.
    inline Real fmodr (Real x, Real y)
    {
        /// \alg
        ///  - Return Floating-point remainder of given "x" and "y" values computed calling
        /// to fmodf function of native math library.
        return fmodf(x,y);
    }
    /// Copy Sign Real Value Retriever.
    /// \wi{18354}
    /// Rmath shall provide a method to retrieve a Real number with the magnitude
    /// of the first Real number x and the sign of the second Real number "y".
    /// \param[in] x Real value representing the magnitude.
    /// \param[in] y Real value representing the sign.
    /// \return Real number from the given magnitude and the sign values.
    inline Real copysignr (Real x, Real y)
    {
        /// \alg
        ///  - Return Real number of given "x" and "y" values computed calling
        /// to copysignf function of native math library.
        return copysignf(x,y);
    }
    /// Copy Sign Real64 Value Retriever.
    /// \wi{21442}
    /// Rmath shall provide a method to retrieve a Real64 number with the magnitude
    /// of the first Real64 number x and the sign of the second Real64 number "y".
    /// \param[in] x Real64 value representing the magnitude.
    /// \param[in] y Real64 value representing the sign.
    /// \return Real64 number from the given magnitude and the sign values.
    inline Real64 copysignr (Real64 x, Real64 y)
    {
        /// \alg
        ///  - Return Real number of given "x" and "y" values computed calling
        /// to copysignl function of native math library.
        return copysignl(x, y);
    }
    /// Base-10 Logarithm Retriever.
    /// \wi{18355}
    /// Rmath shall provide a method to retrieve the base-10 logarithm value of "x".
    /// \param[in] x Real value representing the input.
    /// \return Base-10 logarithm Real value from the given input instance.
    inline Real log10r (Real x)
    {
        /// \alg
        ///  - Return Base-10 logarithm of given "x" value computed calling
        /// to log10 function of native math library, casting the result to Real type.
        return log10f(x);
    }
    /// Round Real Value Retriever.
    /// \wi{19816}
    /// The round function shall return the nearest integral (as a Real value) to the one passed as argument. Some
    /// examples:
    /// <ul>
    ///     <li> Input: 2.3 returns 2.0
    ///     <li> Input: 3.8 returns 4.0
    ///     <li> Input: 5.5 returns 6.0
    ///     <li> Input: -2.3 returns -2.0
    ///     <li> Input: -3.8 returns -4.0
    ///     <li> Input: -5.5 returns -6.0
    /// </ul>
    /// \param[in] Input floating point to compute the nearest integral number.
    /// \returns Nearest integral number to the input.
    inline Real roundr(Real x)
    {
        /// \alg
        ///  - Return round of given "x" value computed calling to rnd_SP_RS function.
        return rnd_SP_RS(x);
    }
    /// Round Real64 Value Retriever.
    /// \wi{21443}
    /// The round function shall return the nearest integral (as a Real64 value) to the one passed as argument. Some
    /// examples:
    /// <ul>
    ///     <li> Input: 2.3 returns 2.0
    ///     <li> Input: 3.8 returns 4.0
    ///     <li> Input: 5.5 returns 6.0
    ///     <li> Input: -2.3 returns -2.0
    ///     <li> Input: -3.8 returns -4.0
    ///     <li> Input: -5.5 returns -6.0
    /// </ul>
    /// \param[in] Input floating point to compute the nearest integral number.
    /// \returns Nearest integral number to the input.
    inline Real64 roundr(Real64 x)
    {
        /// \alg
        ///  - Return round of given "x" value computed calling to roundl function of native math library.
        return roundl(x);
    }
}
#endif
