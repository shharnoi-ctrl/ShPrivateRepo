#include <Assertions.h>
#include <Memmgr.h>

// Linker-generated values
// Defined in the CMD of each project.
// The memory buffer shall also be instantiated by the mainapp.
//PRQA S 2300 ++
extern Uint16 Memmgr_int_cmd;       ///< Internal buffer array defined in the CMD of each project.
extern Uint16 Memmgr_int_sz;        ///< Size of the internal buffer defined in the CMD of each project.
extern Uint16 Memmgr_ext_cmd;       ///< External buffer array defined in the CMD of each project.
extern Uint16 Memmgr_ext_sz;        ///< Size of the external buffer defined in the CMD of each project
//PRQA S 2300 --

namespace Base
{
    Memmgr:: Memmgr(Allocator& internal_alloc, Allocator& external_alloc):
            init_stage(true)
    {
        /// \alg
        /// - Set its internal and external Allocator to given allocators.
        allocators[internal]=&internal_alloc;
        allocators[external]=&external_alloc;
    }

    Memmgr& Memmgr::get_instance()
    {
        /// \alg
        /// - Create internal Allocator instance for ::Memmgr_int_cmd and Uint32 conversion for ::Memmgr_int_sz. 
        static Allocator internal_alloc(&Memmgr_int_cmd,reinterpret_cast<Uint32>(&Memmgr_int_sz));
        /// - Create external Allocator instance for ::Memmgr_ext_cmd and Uint32 conversion for ::Memmgr_ext_sz. 
        static Allocator external_alloc(&Memmgr_ext_cmd,reinterpret_cast<Uint32>(&Memmgr_ext_sz));
        /// - Create Memory Manager instance with the created internal and external Allocators.
        static Memmgr mgr(internal_alloc, external_alloc);
        /// - Return created Memory Manager instance.
        return mgr;
    }

    void Memmgr::close_allocation()
    {
        /// \alg
        /// - Call Allocator::close_allocation for its internal memory Allocator.
        allocators[internal]->close_allocation();
        /// - Call Allocator::close_allocation for its external memory Allocator.
        allocators[external]->close_allocation();
        /// - Set ::init_stage to False.
        init_stage = false;
    }

    Allocator& Memmgr::get_allocator(Type type0)
    {
        /// \alg
        /// - Assert if ::init_stage and if given memory type is lower than ::mem_type_max.
        Base::Assertions::runtime(init_stage && (type0 < mem_type_max));
        /// - Return retrieved value by ::get_instance for the given memory type.
        return *get_instance().allocators[type0];
    }
}
