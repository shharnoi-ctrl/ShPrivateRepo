#ifndef TNARRAY_FW_H_
#define TNARRAY_FW_H_

#include <Entypes.h>
#include <Ku16.h>

namespace Base
{
    /// Tnarray forward declaration.
    template <typename T, Uint32 n>
    struct Tnarray;

    typedef Tnarray<Real, Ku16::u2> Rv2;      ///< Rv2 defined as a Tarray of Real values with size 2.
    typedef Tnarray<Real, Ku16::u3> Rv3;      ///< Rv3 defined as a Tarray of Real values with size 3.
    typedef Tnarray<Real, Ku16::u4> Rv4;      ///< Rv4 defined as a Tarray of Real values with size 4.
    typedef Tnarray<Real, Ku16::u9> Rv9;      ///< Rv9 defined as a Tarray of Real values with size 9.

    typedef Tnarray<Real64, Ku16::u3> R64v3;  ///< R64v3 defined as a Tarray of Real64 values with size 3.

}

#endif
