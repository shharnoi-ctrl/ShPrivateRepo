///    \file Tcopy.h
///
///    \date 21 may. 2018
///
///    \author  FJBurgos, jbm (at) embention.com
///    Company:  Embention
///
///    Tcopy class declaration.
///

#ifndef TCOPY_H_
#define TCOPY_H_

namespace Base
{

    /// Store 2 objects (T can be a reference) and provides a method to copy one to another
    /// with a given CPTRAIT defined in Cptraits.h.
    template <typename CPTRAIT>
    class Tcopy
    {
    public:
        Tcopy(const typename CPTRAIT::Type_from from0, typename CPTRAIT::Type_to to0);

        ~Tcopy();

        void copy();

        const typename CPTRAIT::Type_to& get_to() const;

    private:
        typedef typename CPTRAIT::Type_from Type_from;
        typedef typename CPTRAIT::Type_to Type_to;

        const Type_from from;
        Type_to to;

        Tcopy(); ///< = delete
        Tcopy& operator=(const Tcopy& orig); ///< = delete
    };

    template <typename CPTRAIT>
    inline Tcopy<CPTRAIT>::Tcopy(const typename CPTRAIT::Type_from from0, typename CPTRAIT::Type_to to0) :
        from(from0), to(to0)
    {
    }

    template <typename CPTRAIT>
    inline Tcopy<CPTRAIT>::~Tcopy()
    {
    }

    template <typename CPTRAIT>
    inline void Tcopy<CPTRAIT>::copy()
    {
        CPTRAIT::copy(from, to);
    }

    template <typename CPTRAIT>
    inline const typename CPTRAIT::Type_to& Tcopy<CPTRAIT>::get_to() const
    {
        return to;
    }

} // namespace Base

#endif // TCOPY_H_
