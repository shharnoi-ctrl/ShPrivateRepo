///    \file Xrtable.h
///
///    \date 3 abr. 2018
///
///    \author  FJBurgos, jbm (at) embention.com
///    Company:  Embention
///
///    Xrtable class declaration.
///

#ifndef XRTABLE_H_
#define XRTABLE_H_

#include <Errorsrc.h>
#include <Tnarray.h>
#include <Lossy_error.h>
#include <Lossy.h>
#include <Array.h>
#include <Karray.h>

namespace Base
{

    /// Map a list of (X sorted) values to vectors.
    template <Uint32 nrows, Uint32 ncols>
    struct Xrtable
    {
        Uint32                      nentries;   ///< Number of effective entries (x size, y cols)
        Tnarray<Real, ncols>        x;          ///< y column header
        Tnarray<Real, nrows*ncols>  y;          ///< for each element of x, related (column) vector

        /// Plain table data reset.
        /// \wi{21087}
        /// The Xrtable struct shall provide a method to reset its contained data.
        void reset();

        void cset(Lossy_error& str);
        void cset_col(Lossy_error& str, Uint16 col_cmd);
        void cget(Lossy& str) const;
        void cget_col(Lossy& str, Uint16 col_cmd) const;

    };

    template <Uint32 nrows, Uint32 ncols>
    void Xrtable<nrows,ncols>::reset()
    {
        /// \alg
        /// This method shall:
        nentries = 1U;  /// - Set ::nentries to 1.
        x.zeros();      /// - Set all the elements in ::x to zero.
        y.zeros();      /// - Set all the elements in ::y to zero.
    }

    template <Uint32 nrows, Uint32 ncols>
    void Xrtable<nrows,ncols>::cset(Lossy_error& str)
    {
        {
            Uint16 n = 0;
            str.get_uint16(n);
            nentries = str.assrt(n<=ncols, err_xrtable) ? n : ncols;
        }
        for(Uint16 i=0;i<nentries;i++)
        {
            str.get_float(x[i]);
            cset_col(str, i);
        }
    }

    template <Uint32 nrows, Uint32 ncols>
    void Xrtable<nrows, ncols>::cset_col(Lossy_error& str, Uint16 col_cmd)
    {
        if (str.assrt(col_cmd < nentries, err_xrtable))
        {
            Array<Real> aux(y.to_mblock().sub_mblock(col_cmd * nrows, nrows));
            str.get_n_float(aux, nrows);
        }
    }

    template <Uint32 nrows, Uint32 ncols>
    void Xrtable<nrows,ncols>::cget(Lossy& str) const
    {
        str.put_uint16(static_cast<Uint16>(nentries));
        for(Uint32 i=0;i<nentries;i++)
        {
            str.put_float(x[i]);
            cget_col(str, i);
        }
    }

    template <Uint32 nrows, Uint32 ncols>
    void Xrtable<nrows, ncols>::cget_col(Lossy& str, Uint16 col_cmd) const
    {
        str.put_n_float(Karray<Real>(y.to_mblock().sub_mblock(col_cmd*nrows,nrows)), nrows);
    }

} // namespace Base

#endif // XRTABLE_H_
