#ifndef SCI_FW_H_
#define SCI_FW_H_
namespace Dsp28335_ent
{
    class SCI;
}
#endif
