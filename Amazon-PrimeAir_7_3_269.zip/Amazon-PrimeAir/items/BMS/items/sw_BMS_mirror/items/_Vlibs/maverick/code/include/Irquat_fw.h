#ifndef IRQUAT_FW_H__
#define IRQUAT_FW_H__

namespace Maverick
{
    class Irquat;
}
#endif
