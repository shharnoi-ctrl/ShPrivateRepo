#include <Default_cfg.h>
#include <CANid.h>

namespace Midlevel
{
    using namespace Dsp28335_ent;

    Uint16 Default_cfg::set_default_can_rx(Dsp28335_ent::CANcfg::Trx_array& rx_arr, bool has_arb, bool as_master)
    {
        // Configure for Serial to CAN
        Uint16 idx = Ku16::u0;
        rx_arr[idx].sz = def_nb_rx_mboxes;
        rx_arr[idx].flt.id.extended = false;
        rx_arr[idx].flt.id.id = (!as_master) ? def_can_ser_id : def_ser_can_id;
        rx_arr[idx].flt.msk = Base::CANid::id_msk_std;
        idx++;

        if(has_arb)
        {
            // Number of autopilots for arbitration
            static const Uint16 def_nb_aps = 3;

            // Check if there is enough space into rx array to append all APS ids
            Assertions::runtime((def_nb_aps+idx) <= rx_arr.szmax);

            // Construct default APS RX
            static const CANcfg::Rxcfg rx_cfg =
            {
                def_nb_rx_mboxes,
                {
                    {false, def_ap_base_id},
                    Base::CANid::id_msk_std
                }
            };

            // For each RX, append the default AP RX and fix id
            for(Uint16 i=0; i<def_nb_aps; i++)
            {
                rx_arr[idx] = rx_cfg;
                rx_arr[idx].flt.id.id += i;
                idx++;
            }
        }

        // Resize the rxset
        rx_arr.resize(idx);

        return idx;
    }

    Uint16 Default_cfg::set_default_can(CANcfg& cfg, Uint32 bdr, bool has_arb, bool as_master)
    {
        /// \alg
        // <li> Set baudrate.
        cfg.br = bdr;
        /// <li> Set default Rx configuration by calling to ::set_default_can_rx.
        return set_default_can_rx(cfg.rx, has_arb, as_master);
    }


    Uint16 Default_cfg::set_default_can_fd(CAN_FD_cfg& cfg,
                                           Dsp28335_ent::CAN_FD_cfg::Baudrate bd_arb,
                                           Dsp28335_ent::CAN_FD_cfg::Baudrate bd_data,
                                           bool has_arb,
                                           bool as_master)
    {
        /// \alg
        /// Set the configuration parameters as:
        /// <ul>
        /// <li> Set CAN-FD mode to true.
        cfg.can_fd_mode = true;
        /// <li> Disable Bit Rate Switch.
        cfg.enable_brs = false;
        /// <li> Disable arbitration timings usage.
        cfg.arb.use_timings = false;
        /// <li> Set arbitration baudrate to bd_arb input parameter.
        cfg.arb.bdrt = bd_arb;

        /// <li> Disable data timings usage.
        cfg.data.use_timings = false;
        /// <li> Set data baudrate to bd_data input parameter.
        cfg.data.bdrt = bd_data;

        /// <li> Set default Rx configuration by calling to ::set_default_can_rx.
        return set_default_can_rx(cfg.rx_cfg, has_arb, as_master);
    }

    void Default_cfg::reset_ports(const Pkt_router::Tports& ports)
    {
        for(Uint16 i = 0; i < ports.size(); i++)
        {
            if (ports[i] != 0)
            {
                ports[i]->reset();
            }
        }
    }
    
}
