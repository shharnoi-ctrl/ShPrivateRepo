#ifndef PDICHECK_H_
#define PDICHECK_H_

#include <Entypes.h>
#include <Timeout.h>
#include <Hbvar.h>
#include <Huvar.h>
#include <Error.h>
#include <Error_fifo.h>
#include <Errorsrc.h>

namespace Base
{
    /// Error commit management.
    /// The ::Base library shall provide the capability to commit provided errors on:<ul>
    /// <li> dedicated unsigned 16-bit system variable (vu_pdi_source or vu_operr_source), </li>
    /// <li> dedicated FIFO. </li> </ul>
    class PDIcheck
    {
    public:
        /// PDIcheck FIFO setter.
        /// \wi{13437}
        /// \rationale Shall be called before using other methods of this class.
        /// The PDIcheck class shall provide the capability to fix the pointer to provided writing FIFO,
        /// allowing all instances of PDIcheck to write on an unique FIFO.
        /// \param[in] ff_wr0       Pointer to writing FIFO that shall be used to commit reported errors.
        static void set_fifo(Fifo_err_wr* ff_wr0);

        /// PDIcheck initialization.
        /// \wi{5156}
        /// \rationale Shall be called before using other methods of this class.
        /// The PDIcheck class shall provide the capability to fix the value of all the system variables, as: <ul>
        /// <li> vu_pdi_source, as unsigned 16-bit integer, shall be fixed to err_ok, </li>
        /// <li> vu_operr_source, as unsigned 16-bit integer, shall be fixed to err_ok, </li>
        /// <li> kbit_pdi, as boolean, shall be fixed to true. </li>
        /// </ul>
        static void init();

        /// PDIcheck commit with unique error source.
        /// \wi{13438}
        /// The PDIcheck class shall be able to commit an unique error from provided source identifier.
        /// and pass it to the commit method with Error parameter \wi{5680}.
        /// \param[in] err_id       Error source identifier.
        static void commit(Errorsrc err_id);

        /// PDIcheck commit with Error object.
        /// \wi{6580}
        /// The PDIcheck class shall be able to commit an error list.
        /// \param[in] err          Constant reference to an Error object containing the list of errors.
        static void commit(const Error& err);

        /// PDIcheck commit with Error object and context.
        /// \wi{13439}
        /// The PDIcheck class shall be able to commit an error list and its configurable identifier.
        /// \param[in] ctxt         Value to characterize the list of errors.
        /// \param[in] err          Constant reference to an Error object containing the list of errors.
        static void commit(Uint16 ctxt, const Error& err);

        /// PDIcheck commit available.
        /// \wi{13462}
        /// The PDIcheck class shall be able to check if the FIFO has room for one more error.
        /// \return false if the FIFO is full, else return true.
        static bool wr_available();

        /// Operation error system variable flushing.
        /// The ::PDIcheck class shall provide the capability to periodically reset the value (to err_ok) of the system variables
        /// dedicated to report error from PDI operations.
        class Opflush
        {
        public:
            /// Opflush constructor.
            /// \wi{6581}
            /// The PDIcheck class shall initialize itself by setting a timeout to 1 second.
            Opflush();

            /// Opflush step.
            /// \wi{6582}
            /// The PDIcheck class shall provide the capability to flush the system variables each time the timeout expired.
            void step();
        private:
            Base::Timeout tout;                         ///< Timeout
            Uint16 last;                                ///< Last operation error
            Opflush(const Opflush& orig);               ///< = delete
            Opflush& operator=(const Opflush& orig);    ///< = delete
        };

    private:
        static const Bsp::Hbvar pdimode;                ///< True if in PDI mode
        static Bsp::Huvar pdicode;                      ///< PDI error code handler
        static Bsp::Huvar opecode;                      ///< Operation error code handler
        static Bsp::Hbvar pdierror;                     ///< PDI error code handler
        static Bsp::Hbvar op_error;                     ///< Operation error bit code handler

        static Fifo_err_wr* ff_wr;

        static bool commit0(const Error& err);
        static void append0(const Error& err);

        PDIcheck();                                     ///<= delete
        PDIcheck(const PDIcheck& orig);                 ///< = delete
        PDIcheck& operator=(const PDIcheck& orig);      ///< = delete
    };

}

#endif
