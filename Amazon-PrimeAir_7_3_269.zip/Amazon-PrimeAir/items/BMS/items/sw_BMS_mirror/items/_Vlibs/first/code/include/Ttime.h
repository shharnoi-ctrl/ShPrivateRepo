#ifndef TTIME_H_
#define TTIME_H_

#include <Entypes.h>
#include <Kclk.h>

namespace Base
{

    /// Time representation with precission of tics (1 tic ~ 6ns) with range from 0 s to 3953 years
    class Ttime
    {
    public:
        /// Ttime Default Constructor.
        /// \wi{5629}
        /// Ttime class shall initialize itself upon construction and initialize its internal members.
        Ttime();

        /// Ttime Constructor with Seconds.
        /// \wi{16994}
        /// Ttime class shall initialize itself upon construction with provided seconds.
        /// \param[in] seconds      Time in seconds.
        explicit Ttime(const Real seconds);

        /// Ttime Constructor with Seconds.
        /// \wi{18433}
        /// Ttime class shall initialize itself upon construction with provided seconds in Real64 precision.
        /// \param[in] seconds      Time in seconds with Real64 precision.
        explicit Ttime(const Real64 seconds);

        /// Ttime Constructor with Tics.
        /// \wi{16995}
        /// Ttime class shall initialize itself upon construction with the provided tics.
        /// \param[in] ticks        Time in ticks.
        explicit Ttime(const int64 tics);

        /// Ttime Ticks Getter.
        /// \wi{5630}
        /// Ttime class shall provide the capability to retrieve its internal time counter in CPU tics.
        /// \return     Internal time in ticks.
        int64 get_tics() const;

        /// Ttime Seconds Getter.
        /// \wi{6601}
        /// Ttime class shall provide the capability to retrieve its internal time counter in seconds.
        /// \return     Internal time in seconds.
        Real get_seconds() const;

        /// Ttime Seconds in Real64 Getter.
        /// \wi{19821}
        /// Ttime class shall provide the capability to retrieve its internal time counter in seconds and Real64
        /// precision.
        /// \return     Internal time in seconds and Real64 precision.
        Real64 get_seconds64() const;

        /// Ttime Millisecods Getter.
        /// \wi{6412}
        /// Ttime class shall provide the capability to retrieve its internal time counter as a signed 64bit integer.
        /// \return Time in milliseconds
        int64 get_msecs() const;

        /// Ttime Tics Adder.
        /// \wi{16996}
        /// Ttime class shall provide the capability to add tics to its internal time counter.
        /// \param[in] tics0    Tics to add.
        void add_tics(const int64& tics0);

        /// Ttime Sum Operator.
        /// \wi{5245}
        /// Ttime class shall provide the capability to provide an increment operator for time representation.
        /// \param[in] t2   Time to increment.
        /// \return         Incremented time.
        Ttime operator+(const Ttime& t2) const;

        /// Ttime Subtract Operator.
        /// \wi{6600}
        /// Ttime class shall provide the capability to provide a decrement operator for time representation.
        /// \param[in] t2   Time to decrement.
        /// \return         Decremented time.
        Ttime operator-(const Ttime& t2) const;

        /// Ttime Subtract Volatile Operator.
        /// \wi{16997}
        /// Ttime class shall provide the capability to provide a volatile decrement operator for time representation.
        /// \param[in] t2   Time to decrement.
        /// \return         Decremented time.
        Ttime operator-(const volatile Ttime& t2) const;

        /// Ttime Sum and Assign Operator.
        /// \wi{5244}
        /// Ttime class shall provide the capability to provide an increment operator for time representation.
        /// \param[in] t2   Time to increment.
        /// \return         Incremented time.
        Ttime& operator+=(const Ttime& t2);

        /// Ttime Subtract and Assign Operator.
        /// \wi{6599}
        /// Ttime class shall provide the capability to provide a decrement operator for time representation.
        /// \param[in] t2   Time to decrement.
        /// \return         Decremented time.
        Ttime& operator-=(const Ttime& t2);

        /// Ttime Less Than Operator.
        /// \wi{5977}
        /// Ttime class shall provide the capability to compare whether the time represented by an instance
        /// of that type is lower than other specified time.
        /// \param[in] t2   Time to compare.
        /// \return         True if this instance time is lower than compared time.
        bool operator<(const Ttime& t2) const;

        /// Ttime Greater Than Operator.
        /// \wi{5978}
        /// Ttime class shall provide the capability to compare whether the time represented by an instance
        /// of that type is higher than other specified time.
        /// \param[in] t2   Time to compare.
        /// \return         True if this instance time is higher than compared time.
        bool operator>(const Ttime& t2) const;

        /// Ttime Greater or Equals Than Operator.
        /// \wi{5981}
        /// Ttime class shall provide the capability to compare whether the time represented by an instance
        /// of that type is higher or equal than other specified time.
        /// \param[in] t2   Time to compare.
        /// \return         True if this instance time is higher or equal to the compared time.
        bool operator>=(const Ttime& t2) const;

        /// Ttime Lower or Equals Than Operator.
        /// \wi{17436}
        /// Ttime class shall provide the capability to compare whether the time represented by an instance
        /// of that type is lower or equal than other specified time.
        /// \param[in] t2   Time to compare.
        /// \return         True if this instance time is lower or equal to the compared time.
        bool operator<=(const Ttime& t2) const;

        /// Ttime Equals Operator.
        /// \wi{5979}
        /// Ttime class shall provide the capability to compare whether the time represented by an instance
        /// of that type is equal than other specified time.
        /// \param[in] t2   Time to compare.
        /// \return         True if this instance time is equal to the compared time.
        bool operator==(const Ttime& t2) const;

        /// Ttime Different Operator.
        /// \wi{5980}
        /// Ttime class shall provide the capability to compare whether the time represented by an instance
        /// of that type is different than other specified time.
        /// \param[in] t2   Time to compare.
        /// \return         True if this instance time is different from the compared time.
        bool operator!=(const Ttime& t2) const;

    private:
        int64 tics; ///< Time in ticks of CPU clock
    };

    inline Ttime::Ttime() : tics(0LL)
    {
    }

    inline Ttime::Ttime(const Real seconds) : tics(static_cast<int64>(seconds*Bsp::Kclk::get_sysclkfreq_r32()))
    {
    }

    inline Ttime::Ttime(const Real64 seconds) : tics(static_cast<int64>(seconds*Bsp::Kclk::get_sysclkfreq_r64()))
    {
    }

    inline Ttime::Ttime(const int64 tics0) : tics(tics0)
    {
    }

    inline int64 Ttime::get_tics() const
    {
        return tics;
    }

    inline Real Ttime::get_seconds() const
    {
        return static_cast<Real>(tics)*Bsp::Kclk::get_sysclkperiod_r32();
    }

    inline Real64 Ttime::get_seconds64() const
    {
        return static_cast<Real64>(tics)*Bsp::Kclk::get_sysclkperiod_r64();
    }

    inline void Ttime::add_tics(const int64& tics0)
    {
        tics+=tics0;
    }

    inline Ttime Ttime::operator+(const Ttime& t2) const
    {
        return Ttime(tics+t2.tics);
    }

    inline Ttime Ttime::operator-(const Ttime& t2) const
    {
        return Ttime(tics-t2.tics);
    }

    inline Ttime Ttime::operator-(const volatile Ttime& t2) const
    {
        return Ttime(tics-t2.tics);
    }

    inline Ttime& Ttime::operator+=(const Ttime& t2)
    {
        tics+=t2.tics;
        return *this;
    }

    inline Ttime& Ttime::operator-=(const Ttime& t2)
    {
        tics-=t2.tics;
        return *this;
    }

    inline bool Ttime::operator<(const Ttime& t2) const
    {
        return tics < t2.tics;
    }

    inline bool Ttime::operator>(const Ttime& t2) const
    {
        return tics > t2.tics;
    }

    inline bool Ttime::operator>=(const Ttime& t2) const
    {
        return tics >= t2.tics;
    }

    inline bool Ttime::operator<=(const Ttime& t2) const
    {
        return tics <= t2.tics;
    }

    inline bool Ttime::operator==(const Ttime& t2) const
    {
        return tics == t2.tics;
    }

    inline bool Ttime::operator!=(const Ttime& t2) const
    {
        return tics != t2.tics;
    }

}

#endif
