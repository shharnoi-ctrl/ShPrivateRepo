#ifndef INCLUDE_BITMASK_H_
#define INCLUDE_BITMASK_H_

#include <Bitutils.h>

namespace Base
{

    /// Helper class for masks of bits that fit in a single type
    template <typename T>
    struct Bitmask
    {
        T value;                ///< Mask value.
        /// Bitmask Bit Getter.
        /// \wi{17669}
        /// Bitmask structure shall provide the capability to retrieve the specified bit in the mask.
        /// \param[in] i    Index in the mask for the bit to retrieve.
        /// \return         Bit specified in the mask.
        bool get(const Uint16 i) const;
        /// Bitmask Bit Getter.
        /// \wi{17670}
        /// Bitmask structure shall provide the capability to retrieve the specified bit in the mask.
        /// \param[in] i    Index in the mask for the bit to retrieve.
        /// \return         Bit specified in the mask.
        bool get(const Uint16 i) const volatile;
        /// Bitmask Bit Setter.
        /// \wi{17671}
        /// Bitmask structure shall provide the capability to set to true the specified bit in the mask.
        /// \param[in] i    Index in the mask for the bit to set.
        void set(const Uint16 i);
        /// Volatile Bitmask Bit Setter.
        /// \wi{17672}
        /// Bitmask structure shall provide the capability to set to true the specified bit in the mask in a volatile way.
        /// \param[in] i    Index in the mask for the bit to set.
        void set(const Uint16 i) volatile;
        /// Bitmask Clear Bit.
        /// \wi{17673}
        /// Bitmask structure shall provide the capability to clear the specified bit in the mask by
        /// setting its value to false.
        /// \param[in] i    Index in the mask for the bit to clear.
        void clear(const Uint16 i);
        /// Volatile Bitmask Clear Bit.
        /// \wi{18438}
        /// Bitmask structure shall provide the capability to clear the specified bit in the mask by
        /// setting its value to false in a volatile way.
        /// \param[in] i    Index in the mask for the bit to clear.
        void clear(const Uint16 i) volatile;
        /// Bitmask Bit Setter.
        /// \wi{17674}
        /// Bitmask structure shall provide the capability to set the specified bit in the mask to the desired value.
        /// \param[in] i        Index in the mask for the bit to set.
        /// \param[in] value0   Value to set the specified bit.
        void set(const Uint16 i, const bool value0);
        /// Bitmask Bit Setter.
        /// \wi{19466}
        /// Bitmask structure shall provide the capability to set the specified bit in the mask to the desired value.
        /// \param[in] i        Index in the mask for the bit to set.
        /// \param[in] value0   Value to set the specified bit.
        void set(const Uint16 i, const bool value0) volatile;
        /// Bitmask Builder.
        /// \wi{17675}
        /// Bitmask structure shall provide the capability to build a bitmask with the desired initial value.
        /// \param[in] ini      Initial value to set the bitmask.
        /// \return             Bitmask with the initial value.
        static Bitmask build(const T ini);
    };

    template <typename T>
    inline bool Bitmask<T>::get(const Uint16 i) const
    {
        return (value & Bitutils::get_mask_1bit<T>(i)) != 0;
    }

    template <typename T>
    inline bool Bitmask<T>::get(const Uint16 i) const volatile
    {
        return (value & Bitutils::get_mask_1bit<T>(i)) != 0;
    }

    template <typename T>
    inline void Bitmask<T>::set(const Uint16 i)
    {
        value |= Bitutils::get_mask_1bit<T>(i);
    }

    template <typename T>
    inline void Bitmask<T>::set(const Uint16 i) volatile
    {
        value |= Bitutils::get_mask_1bit<T>(i);
    }

    template <typename T>
    inline void Bitmask<T>::clear(const Uint16 i)
    {
        value &= (~Bitutils::get_mask_1bit<T>(i));
    }

    template <typename T>
    inline void Bitmask<T>::clear(const Uint16 i) volatile
    {
        value &= (~Bitutils::get_mask_1bit<T>(i));
    }

    template <typename T>
    inline void Bitmask<T>::set(const Uint16 i, const bool value0)
    {
        value0 ? set(i) : clear(i);
    }

    template <typename T>
    inline void Bitmask<T>::set(const Uint16 i, const bool value0) volatile
    {
        value0 ? set(i) : clear(i);
    }

    template <typename T>
    inline Bitmask<T> Bitmask<T>::build(const T ini)
    {
        Bitmask<T> ret = {ini};
        return ret;
    }

}

#endif
