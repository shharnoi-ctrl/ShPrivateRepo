#ifndef U8PKRSZARRAY_H_
#define U8PKRSZARRAY_H_

#include <U8pkarray.h>

namespace Base
{
    /// U8pkarray resizable.
    /// The ::Base library shall provide a class for a resizable Array of bytes, packed in native words of 16 bits.
    /// \param nmax Maximum size of the U8pkarray.
    template <Uint32 nmax>
    class U8pkrszarray
    {
    public:
        /// The U8pkrszarray class shall provide a structure to manage the data traits of the resizable U8pkarray.
        struct Data_traits8 : public type_is<U8pkrszarray>
        {
            /// U8pkrszarray 8-bits Data Traits Data Retriever.
            /// \wi{20431}
            /// Data_traits8 structure shall be able to retrieve the content of a given array to a constant memory 
            /// bytes block.
            /// \param[in] array    Resizable U8pkarray to be retrieved as a constant block of memory bytes.
            /// \return Constant block of memory bytes.
            static inline const U8pkmblock get_data(U8pkrszarray& array)
            {
                /// \alg
                /// - Return retrieved value by ::full_mblock8 for given array.
                return array.full_mblock8();
            }

            /// U8pkrszarray 8-bits Data Traits Size Updater.
            /// \wi{20432}
            /// Data_traits8 structure shall provide the capability to update the size of a given array.
            /// \param[in] array    Resizable U8pkarray to be resized.
            /// \param[in] sz       New size.
            static inline void update_size(U8pkrszarray& array, Uint32 sz)
            {
                /// \alg
                /// - Call ::resize for given array with given size.
                array.resize(sz);
            }

            /// U8pkrszarray 8-bits Data Traits Maximum Size Retriever.
            /// \wi{20433}
            /// Data_traits8 structure shall be able to retrieve the maximum size of a given array.
            /// \param[in] array    Resizable U8pkarray to retrieve the maximum size.
            /// \return Maximum size of the given array.
            static inline Uint16 get_max_size(U8pkrszarray& array)
            {
                /// \alg
                /// - Return retrieved value by ::size_max for given array.
                return array.size_max();
            }

            /// U8pkrszarray 8-bits Data Traits Position Retriever.
            /// \wi{20434}
            /// Data_traits8 structure shall be able to retrieve the position of a given array.
            /// \param[in] str      Resizable U8pkarray to retrieve the position.
            /// \return The position of a given array, always 0.
            static inline Uint16 get_pos(const U8pkrszarray& str)
            {
                /// \alg
                /// - Return 0.
                return 0;
            }
        };

        /// Resizable U8pkarray Constant Block Used Size Retrieved.
        /// \wi{5294}
        /// U8pkrszarray class shall be able to retrieve the constant block used size of the resizable U8pkarray instance.
        /// \return Constant block used size (in bytes).
        Uint32 size() const;

        /// Resizable U8pkarray Constant Volatile Block Used Size Retrieved.
        /// \wi{20435}
        /// U8pkrszarray class shall be able to retrieve the constant and volatile block used size of the 
        /// resizable U8pkarray instance.
        /// \return Constant volatile block used size (in bytes).
        Uint32 size() const volatile;

        /// Resizable U8pkarray Constant Max Size Retrieved.
        /// \wi{5295}
        /// U8pkrszarray class shall be able to retrieve the constant maximum size of the resizable U8pkarray instance.
        /// \return Constant maximum size (in bytes).
        Uint32 size_max() const;

        /// Resizable U8pkarray Constant Volatile Max Size Retrieved.
        /// \wi{20436}
        /// U8pkrszarray class shall be able to retrieve the constant and volatile maximum size of the resizable 
        /// U8pkarray instance.
        /// \return Constant volatile maximum size (in bytes).
        Uint32 size_max() const volatile;


        /// Resizable U8pkarray Constant Block Unused Size Retrieved.
        /// \wi{5296}
        /// U8pkrszarray class shall be able to retrieve the constant unused size of the resizable U8pkarray instance.
        /// \return Constant block unused size (in bytes).
        Uint32 size_unused() const;

        /// Resizable U8pkarray Resizer.
        /// \wi{5297}
        /// U8pkrszarray class shall provide the capability to resize the resizable U8pkarray instance.
        /// \param[in] n0       New size (in bytes).
        /// \return True if the resize is successful, False otherwise.
        bool resize(Uint32 n0);

        /// Resizable U8pkarray Volatile Resizer.
        /// \wi{20437}
        /// U8pkrszarray class shall provide the capability to volatile resize the resizable U8pkarray instance.
        /// \param[in] n0       New size (in bytes).
        /// \return True if the resize is successful, False otherwise.
        bool resize(Uint32 n0) volatile;

        /// Resizable U8pkarray Value Setter.
        /// \wi{5298}
        /// U8pkrszarray class shall provide the capability to set a value in a specific position of the resizable 
        /// U8pkarray instance.
        /// \param[in] i        Index into block.
        /// \param[in] value    Value to put in index position.
        void set(Uint32 i, Uint8 value);

        /// Resizable U8pkarray Constant Value Retriever.
        /// \wi{5300}
        /// U8pkrszarray class shall be able to retrieve a constant value from a specific position of the resizable 
        /// U8pkarray instance.
        /// \param[in] i        Index into block.
        /// \return Constant value of given index.
        Uint8 get(Uint32 i) const;

        /// Resizable U8pkarray Constant Volatile Value Retriever.
        /// \wi{20438}
        /// U8pkrszarray class shall be able to retrieve a constant and volatile value from a specific position of 
        /// the resizable U8pkarray instance.
        /// \param[in] i        Index into block.
        /// \return Constant volatile value of given index.
        Uint8 get(Uint32 i) const volatile;

        /// Resizable U8pkarray Value Append.
        /// \wi{20439}
        /// U8pkrszarray class shall provide the capability to append a specific value to the resizable U8pkarray, 
        /// if possible, and update its size by 1.
        /// \param[in] d    Value to append.
        void append(Uint8 d);

        /// Resizable U8pkarray Zero Setter.
        /// \wi{5301}
        /// U8pkrszarray class shall provide the capability to set 0 in all the positions of the resizable U8pkarray 
        /// instance.
        void zeros();

        /// Resizable U8pkarray Copier.
        /// \wi{5302}
        /// U8pkrszarray class shall provide the capability to copy the data from an U8pkmblock into itself, 
        /// setting its size to the provided data size. If the provided data does not fit, it will apply the 
        /// maximum possible size.
        /// \param[in] src      Memory block to copy.
        void copy(const U8pkmblock_k& src);
        /// Resizable U8pkarray Volatile Copier.
        /// \wi{5303}
        /// U8pkrszarray class shall provide the capability to volatile copy the data from an U8pkmblock into itself,
        /// setting its size to the provided data size. If the provided data does not fit, it will apply the 
        /// maximum possible size.
        /// \param[in] src      Memory block to copy.
        void copy(const U8pkmblock_k& src) volatile;

        /// Resizable U8pkarray Value Setter.
        /// \wi{5299}
        /// U8pkrszarray class shall provide the capability to set all bytes of the resizable U8pkarray to a specifig value.
        void set_all(Uint8 value);

        /// Resizable U8pkarray Memory Block Converter.
        /// \wi{6343}
        /// U8pkrszarray class shall provide the capability to return all its content converted in block of 
        /// memory bytes.
        /// \return Block of memory bytes.
        U8pkmblock to_mblock8();
        /// Resizable U8pkarray Constant Memory Block Converter.
        /// \wi{20440}
        /// U8pkrszarray class shall provide the capability to return all its content converted in constant block of
        /// memory bytes.
        /// \return Constant block of memory bytes.
        U8pkmblock_k to_mblock8() const;
        /// Resizable U8pkarray Constant Volatile Memory Block Converter.
        /// \wi{20441}
        /// U8pkrszarray class shall provide the capability to return all its content converted in constant and 
        /// volatile block of memory bytes.
        /// \return Constant volatile block of memory bytes.
        U8pkmblock_k to_mblock8() const volatile;

        /// Resizable U8pkarray Full Memory Block Converter.
        /// \wi{20442}
        /// U8pkrszarray class shall provide the capability to return all the pointer memory converted in block
        /// of memory bytes.
        /// \return Block of memory bytes.
        U8pkmblock full_mblock8();

        /// Resizable U8pkarray Pointer Retriever.
        /// \wi{20443}
        /// U8pkrszarray class shall be able to retrieve a pointer of the resizable U8pkarray instance.
        /// \return Pointer of its internal resizable U8pkarray instance.
        inline void* get_pt()
        {
            /// \alg
            /// - Return retrieved value by U8pkarray::get_pt for ::v.
            return v.get_pt();
        }

        /// Resizable U8pkarray Constant Pointer Retriever.
        /// \wi{20444}
        /// U8pkrszarray class shall be able to retrieve a constant pointer of the resizable U8pkarray instance.
        /// \return Constant pointer of its internal resizable U8pkarray instance.
        inline const void* get_pt() const
        {
            /// \alg
            /// - Return retrieved value by U8pkarray::get_pt for ::v.
            return v.get_pt();
        }

    private:
        U8pkarray<nmax> v;      ///< U8pkarray instance with <nmax>.
        Uint32 n;               ///< Current size of the U8pkarray.
    };

    template <Uint32 nmax>
    inline Uint32 U8pkrszarray<nmax>::size() const
    {
        /// \alg
        /// - Return ::n.
        return n;
    }

    template <Uint32 nmax>
    inline Uint32 U8pkrszarray<nmax>::size() const volatile
    {
        /// \alg
        /// - Return ::n.
        return n;
    }

    template <Uint32 nmax>
    inline Uint32 U8pkrszarray<nmax>::size_max() const
    {
        /// \alg
        /// - Return <nmax>.
        return nmax;
    }

    template <Uint32 nmax>
    inline Uint32 U8pkrszarray<nmax>::size_max() const volatile
    {
        /// \alg
        /// - Return <nmax>.
        return nmax;
    }

    template <Uint32 nmax>
    inline Uint32 U8pkrszarray<nmax>::size_unused() const
    {
        /// \alg
        /// - Return <nmax>-::n
        return nmax-n;
    }

    template <Uint32 nmax>
    inline bool U8pkrszarray<nmax>::resize(Uint32 n0)
    {
        /// \alg
        /// <ul>
        /// <li> If given new size is greater than <nmax>:
        /// <ul>
        /// <li> Establish ::n as <nmax>.
        /// <li> Return False.
        /// </ul>
        /// <li> Else:
        /// <ul>
        /// <li> Establish ::n as given new size.
        /// <li> Return True.
        /// </ul>
        /// </ul>
        const bool ret = Assertions::runtime(n0<=nmax);
        n = ret ? n0 : nmax;
        return ret;
    }

    template <Uint32 nmax>
    inline bool U8pkrszarray<nmax>::resize(Uint32 n0) volatile
    {
        /// \alg
        /// <ul>
        /// <li> If given new size is greater than <nmax>:
        /// <ul>
        /// <li> Establish ::n as <nmax>.
        /// <li> Return False.
        /// </ul>
        /// <li> Else:
        /// <ul>
        /// <li> Establish ::n as given new size.
        /// <li> Return True.
        /// </ul>
        /// </ul>
        const bool ret = Assertions::runtime(n0<=nmax);
        n = ret ? n0 : nmax;
        return ret;
    }

    template <Uint32 nmax>
    inline void U8pkrszarray<nmax>::set(Uint32 i, Uint8 value)
    {
        /// \alg
        /// - Return retrieved value by U8pkarray::set for ::v with given index and value.
        return v.set(i, value);
    }

    template <Uint32 nmax>
    inline Uint8 U8pkrszarray<nmax>::get(Uint32 i)const
    {
        /// \alg
        /// - Return retrieved value by U8pkarray::get for ::v with given index.
        return v.get(i);
    }

    template <Uint32 nmax>
    inline Uint8 U8pkrszarray<nmax>::get(Uint32 i) const volatile
    {
        /// \alg
        /// - Return retrieved value by U8pkarray::get for ::v with given index.
        return v.get(i);
    }


    template <Uint32 nmax>
    inline void U8pkrszarray<nmax>::append(Uint8 d)
    {
        /// \alg
        /// <ul>
        /// <li> If ::n is lower than <nmax>
        if(Assertions::runtime(n < nmax))
        {
            /// <ul>
            /// <li> Call U8pkarray::set for ::v with ::n++ and given value.
            v.set(n++, d);
            /// </ul>
        }
        /// </ul>
    }

    template <Uint32 nmax>
    inline void U8pkrszarray<nmax>::zeros()
    {
        /// \alg
        /// - Call U8pkarray::zeros for ::v.
        v.zeros();
    }


    template <Uint32 nmax>
    inline void U8pkrszarray<nmax>::copy(const U8pkmblock_k& src)
    {
        /// \alg
        /// <ul>
        /// <li> If retrieved value by ::resize with size of the given parameter "src".
        if (resize(src.size()))
        {
            /// <ul>
            /// <li> Call U8pkmblock::write with given parameter "src" for the retrieved value by 
            /// U8pkarray::to_mblock8 for ::v.
            v.to_mblock8().write(src);
            /// </ul>
        }
        /// </ul>
    }

    template <Uint32 nmax>
    inline void U8pkrszarray<nmax>::copy(const U8pkmblock_k& src) volatile
    {
        /// \alg
        /// <ul>
        /// <li> If retrieved value by ::resize with size of the given parameter "src".
        if (resize(src.size()))
        {
            /// <ul>
            /// <li> Call U8pkmblock::write with given parameter "src" for the retrieved value by 
            /// U8pkarray::to_mblock8 for ::v.
            v.to_mblock8().write(src);
            /// </ul>
        }
        /// </ul>
    }

    template <Uint32 nmax>
    inline void U8pkrszarray<nmax>::set_all(Uint8 value)
    {
        /// \alg
        /// - Call U8pkarray::set_all for ::v with given value.
        v.set_all(value);
    }

    template <Uint32 nmax>
    inline U8pkmblock U8pkrszarray<nmax>::to_mblock8()
    {
        /// \alg
        /// - Return U8pkmblock instance built with retrieved value by U8pkarray::to_mblock8 for ::v and ::n.
        return U8pkmblock(v.to_mblock8(), n);
    }

    template <Uint32 nmax>
    inline U8pkmblock_k U8pkrszarray<nmax>::to_mblock8() const
    {
        /// \alg
        /// - Return U8pkmblock_k instance built with retrieved value by U8pkarray::to_mblock8 for ::v and ::n.
        return U8pkmblock_k(v.to_mblock8(), n);
    }

    template <Uint32 nmax>
    inline U8pkmblock_k U8pkrszarray<nmax>::to_mblock8() const volatile
    {
        /// \alg
        /// - Return U8pkmblock_k instance built with retrieved value by U8pkarray::to_mblock8 for ::v and ::n.
        return U8pkmblock_k(v.to_mblock8(), n);
    }

    template <Uint32 nmax>
    inline U8pkmblock U8pkrszarray<nmax>::full_mblock8()
    {
        /// \alg
        /// - Return retrived value by U8pkarray::to_mblock8 for ::v.
        return v.to_mblock8();
    }
}
#endif
