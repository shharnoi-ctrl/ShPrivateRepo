#include <Error.h>

#include <Assertions.h>

namespace Base
{
    Error::Error():
        errors(buff.v, buff.sz)
    {
        errors.resize(0);
    }

    bool Error::assrt(bool ck, Errorsrc e_src)
    {
        if(!Assertions::runtime(ck) && (e_src != err_ok))
        {
            errors.append(e_src);
        }
        return ck;
    }
}
