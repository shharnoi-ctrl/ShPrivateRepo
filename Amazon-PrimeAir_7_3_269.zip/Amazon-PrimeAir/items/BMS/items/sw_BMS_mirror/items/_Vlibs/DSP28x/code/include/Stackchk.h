#ifndef STACKCHK_H
#define STACKCHK_H

#include <Entypes.h>

namespace Dsp28335_ent
{
    /// Checks for stack usage
    class Stackchk
    {
    public:
        Stackchk();     ///< Initialize stack with fill values. Shall be called before actual C++ code starts
        bool check();   ///< Returns true if stack usage is ok (free > margin)
    private:
        static const Uint16 fill_v = 0xA5A5;    ///< Value for unused stack area
        /// Number of consecutive words to assume has not been written.
        static const Uint16 check_cnt = 16;
        /// Having less than this number of words free in the stack is considered an error.
        static const Uint16 check_margin = 32;
        /// Free stack
        Uint16 free;
    };
}
#endif
