#ifndef DEFAULT_CFG_H_
#define DEFAULT_CFG_H_

#include <CAN.h>
#include <CANcfg.h>
#include <CAN_FD_cfg.h>
#include <CANin_suite.h>
#include <CANout_suite.h>
#include <CANsc_suite.h>
#include <Fieldsvec.h>
#include <Kfieldsvec.h>
#include <Lossy_error.h>
#include <Pkt_router.h>
#include <SCI.h>
#include <SCIcfg.h>
#include <Xfmsgcan_hdl.h>
#include <Xfmsgcanp.h>
#include <Xpc.h>


namespace Midlevel
{
    using namespace Base;

    /// Support for default configuration at maintenance mode.
    class Default_cfg
    {
    public:

        /// Default CAN identifier for Serial to CAN.
        /// \wi{8198}
        /// Default_cfg class shall be able to retrieve the default CAN identifier for Serial to CAN.
        /// \return Default Serial to CAN ID.
        static Uint16 get_default_ser_can_id();

        /// Default CAN identifier for CAN to Serial.
        /// \wi{8199}
        /// Default_cfg class shall be able to retrieve the default CAN identifier for CAN to Serial.
        /// \return Default CAN to Serial ID.
        static Uint16 get_default_can_ser_id();

        /// Default CAN configuration (1MBps).
        /// \wi{8251}
        /// Default_cfg class shall be able to set default configuration for CAN's PDI onto provided PDIC
        /// from provided parameters and fixing speed to 1 MBps.
        /// \param[in] cfg          Reference to CAN configuration.
        /// \param[in] has_arb      At true, configure a CANin for arbitrating, else do not.
        /// \param[in] as_master    At true, configure to arbitrate, at false to be arbitrated.
        /// \return Index of the last configured RX element incremented by one.
        static Uint16 set_default_can_1000(Dsp28335_ent::CANcfg& cfg, bool has_arb, bool as_master);

        /// Default CAN configuration (500KBps).
        /// \wi{8252}
        /// Default_cfg class shall be able to set default configuration for CAN's PDI onto provided PDIC
        /// from provided parameters and fixing speed to 500 KBps.
        /// \param[in] cfg          Reference to CAN configuration.
        /// \param[in] has_arb      At true, configure a CANin for arbitrating, else do not.
        /// \param[in] as_master    At true, configure to arbitrate, at false to be arbitrated.
        /// \return Index of the last configured RX element incremented by one.
        static Uint16 set_default_can_500(Dsp28335_ent::CANcfg& cfg, bool has_arb, bool as_master);

        /// Default CAN configuration for given baudrate.
        /// \wi{18104}
        /// Default_cfg class shall be able to set default configuration for CAN FD's PDI onto provided PDIC
        /// from provided parameters with FD mode, and 1Mhz for arbitration and data.
        /// \param[in] cfg          Reference to CAN configuration.
        /// \param[in] bd_arb       Baudrate to be used for arbitration.
        /// \param[in] bd_data      Baudrate to be used for data.
        /// \param[in] has_arb      At true, configure a CANin for arbitrating, else do not.
        /// \param[in] as_master    At true, configure to arbitrate, at false to be arbitrated.
        /// \return Index of the last configured RX element incremented by one.
        static Uint16 set_default_can_fd(Dsp28335_ent::CAN_FD_cfg& cfg,
                                         Dsp28335_ent::CAN_FD_cfg::Baudrate bd_arb,
                                         Dsp28335_ent::CAN_FD_cfg::Baudrate bd_data,
                                         bool has_arb,
                                         bool as_master);

        /// Default CAN IN suite configuration.
        /// \wi{8195}
        /// Default_cfg class shall provide the capability to build a default configuration for CAN IN's PDI
        /// from provided parameters.
        /// \param[in] has_arb      At true, configure a CANin for arbitrating, else do not.
        /// \param[in] as_master    At true, configure to arbitrate, at false to be arbitrated.
        /// \return Reference to the built PDIC.
        template <typename CANIN>
        static const CANIN& get_default_can_in(bool has_arb, bool as_master);

        /// Default CAN OUT suite configuration.
        /// \wi{8196}
        /// Default_cfg class shall provide the capability to build a default configuration for CAN OUT's PDI
        /// from provided parameters.
        /// \param[in] port     CAN port for each CANout configuration of the suite.
        /// \return Reference to the built PDIC.
        template <typename CANOUT>
        static const CANOUT& get_default_can_out(CANport::Port port);

        /// Default Serial/CAN suite configuration.
        /// \wi{8197}
        /// Default_cfg class shall provide the capability to build a default configuration for XPC Serial/CAN's PDI
        /// from provided parameters.
        /// \param[in] tout         Time out for each CANsc configuration of the suite.
        /// \param[in] as_master    At true, configure to arbitrate, at false to be arbitrated.
        /// \return Reference to the built PDIC.
        template <typename CANSC>
        static const CANSC& get_default_can_sc(Real tout, bool as_master);

        /// Default byte cross producer/consumer configuration.
        template <typename XU8>
        struct Xpcu8
        {
        public:
            typedef typename Xpc<XU8>::Type_map Tmap;   ///< Type for XPC U8 trait.

            /// Default Serial Cross Producer/Consumer configuration (0 serial).
            /// \wi{8253}
            /// Default_cfg class shall provide the capability to build a default configuration for SCI PDI.
            /// \return XPCU8 map configured with Serial to CAN <-> Commgr 0.
            static const Tmap& get_default_0sci();

            /// Default Serial Cross Producer/Consumer configuration (1 serial).
            /// \wi{8254}
            /// Default_cfg class shall provide the capability to build a default configuration for SCI PDI.
            /// \return XPCU8 map with following configured ports: <ul>
            /// <li> One serial to CAN <-> Commgr 0.
            /// <li> SCI-A <-> Commgr 1.
            /// </ul>
            static const Tmap& get_default_1sci();

            /// Default Serial Cross Producer/Consumer configuration (2 serial).
            /// \wi{8255}
            /// Default_cfg class shall provide the capability to build a default configuration for SCI PDI.
            /// \return XPCU8 map with following configured ports: <ul>
            /// <li> One serial to CAN <-> Commgr 0.
            /// <li> SCI-A <-> Commgr 1.
            /// <li> SCI-B <-> Commgr 2.
            /// </ul>
            static const Tmap& get_default_2sci();

            /// Default Serial Cross Producer/Consumer configuration (3 serial).
            /// \wi{8256}
            /// Default_cfg class shall provide the capability to build a default configuration for SCI PDI.
            /// \return XPCU8 map with following configured ports: <ul>
            /// <li> One serial to CAN <-> Commgr 0.
            /// <li> SCI-A <-> Commgr 1.
            /// <li> SCI-B <-> Commgr 2.
            /// <li> SCI-C <-> Commgr 3.
            /// </ul>
            static const Tmap& get_default_3sci();

            /// Default Serial Cross Producer/Consumer configuration (4 serial).
            /// \wi{8257}
            /// Default_cfg class shall provide the capability to build a default configuration for SCI PDI.
            /// \return XPCU8 map with following configured ports: <ul>
            /// <li> One serial to CAN <-> Commgr 0.
            /// <li> SCI-A <-> Commgr 1.
            /// <li> SCI-B <-> Commgr 2.
            /// <li> SCI-C <-> Commgr 3.
            /// <li> SCI-D <-> Commgr 4.
            /// </ul>
            static const Tmap& get_default_4sci();

        private:
            Xpcu8(); ///< = delete
            Xpcu8(const Xpcu8& orig); ///< = delete
            Xpcu8& operator=(const Xpcu8& orig); ///< = delete
        };

        /// Default CAN cross producer/consumer configuration.
        template <typename XCAN>
        struct Xpccan
        {
            typedef typename Xpc<XCAN>::Type_map Tmap;  ///< Type for XPC CAN trait.

            /// Default CAN Cross Producer/Consumer configuration.
            /// \wi{8200}
            /// Default_cfg class shall provide the capability to build a default configuration for XPCCAN PDI.
            /// \return Reference to the built PDIC.
            static const Tmap& get_default();

        private:
            Xpccan(); ///< = delete
            Xpccan(const Xpccan& orig); ///< = delete
            Xpccan& operator=(const Xpccan& orig); ///< = delete
        };

        /// Default telemetry configuration.
        /// \wi{8202}
        /// Default_cfg class shall provide the capability to build a default configuration for telemetry PDI
        /// from provided parameters.
        /// \param[in,out] fsvec            Vectored field set to be configured.
        /// \param[in] entries              Array of Vref::entry of required variables and its types.
        /// \param[in] vdata                Extra data for configured vector.
        /// \param[in] nb_fields_per_vec    Number of field for each vector.
        template <typename FVECDATA>
        static void set_default_tm(typename FVECDATA::Fsv0& fsvec,
                                   const Mblock<const Vref::Entry>& entries,
                                   const typename FVECDATA::Vecdata& vdata,
                                   Uint16 nb_fields_per_vec);

        /// Default telemetry configuration.
        /// \wi{18131}
        /// Default_cfg class shall provide the capability to build a default configuration for telemetry PDI with
        /// a custom number of vectors and fields for each vector
        /// from provided parameters.
        /// \param[in,out] fsvec            Vectored field set to be configured.
        /// \param[in] entries              Array of entries with which is possible to build a Field.
        /// \param[in] vdata                Extra data for configured vector.
        /// \return First vector being added.
        template <typename FVECDATA, typename DATA_TYPE>
        static Uint16 update_fmset(typename FVECDATA::Fsv0& fsvec,
                                 const Mblock<const Mblock<const DATA_TYPE> > entries,
                                 const typename FVECDATA::Vecdata vdata);

        /// Default CAN telemetry configuration.
        /// \wi{8203}
        /// Default_cfg class shall provide the capability to build a default configuration for CAN telemetry PDI
        /// from provided parameters.
        /// \param[in,out] cfg      Reference to CAN telemetry configuration.
        template <Uint16 nvecs>
        static void set_default_can_tm(Xfmsgcanp0array<nvecs>& cfg, Uint16 nb_ids);

        /// Default CAN telemetry configuration.
        /// \wi{18132}
        /// Default_cfg class shall provide the capability to build a default configuration for CAN telemetry PDI
        /// from provided parameters
        /// \param[in,out] cfg      Reference to CAN telemetry configuration.
        /// \param[in] ids:         Identification number for each message
        template <Uint16 nvecs>
        static void set_default_can_tm(Xfmsgcanp0array<nvecs>& cfg, const Mblock<const Uint16> ids);

        /// Default CAN RX Configuration.
        /// \wi{18187}
        /// Default_cfg class shall provide the capability to set a default configuration with given data for
        /// CAN custom RX PDI.
        /// \param[in] cfg Reference to CAN custom RC configuration.
        /// \param[in] ids CAN IDs to be configured for each vector.
        template <Uint16 nvecs, Uint16 max_per_c>
        static void set_default_can_rx(Xfmsgcanc0array<nvecs, max_per_c>& cfg, const Mblock<const Uint32> ids, bool extended, Uint16 first_id);

        /// Ports Reset.
        /// Default_cfg shall provide a function to reset all given ports usign their reset function.
        /// \param[in] ports Ports to be reset.
        static void reset_ports(const Pkt_router::Tports& ports);

        /// Ports Tunable Reset.
        /// Default_cfg shall provide a function to reset the given ports tunable, seting them to default value (0).
        /// \param[in] Ports tunable to be reset.
        template <class PTYPE>
        static void reset_ports_tun(typename PTYPE::Xports_cfg::Type_tun& ports_tun)
        {
            ports_tun.value.resize(PTYPE::n_ports);
            ports_tun.value.v.zeros();
        }

        private:
            static const Uint16 def_nb_rx_mboxes = 4;       ///< Number of mailboxes for each CAN configured RX.

            static const Uint16 def_rx_mbox_mask = 2044;    ///< RX CAN ID mask to allow from all APS if using IDs 8 to 11.
            static const Uint16 def_ap_base_id = 8;         ///< RX CAN ID, from 10 to 13 for each AP.

            static const Uint16 def_ser_can_id = 1301;      ///< Serial-CAN default ID (out) for slave devices.
            static const Uint16 def_can_ser_id = 1302;      ///< CAN-Serial default ID (in ) for slave devices.

            static const Uint32 can_bdr_1000 = 1000000;     ///< CAN speed of 1Mbps.
            static const Uint32 can_bdr_500 = 500000;       ///< CAN speed of 500Kbps.

            static const Uint16 def_tm_base_id = 35;        ///< Base ID for CAN telemetry.

            /// Default CAN configuration.
            /// \wi{16842}
            /// Default_cfg class shall be able to set default configuration for CAN's PDI onto provided PDIC
            /// from provided parameters.
            /// \param[in] cfg          Reference to CAN configuration.
            /// \param[in] bdr          Baudrate to configure.
            /// \param[in] has_arb      At true, configure a CANin for arbitrating, else do not.
            /// \param[in] as_master    At true, configure to arbitrate, at false to be arbitrated.
            /// \return Index of the last configured RX element incremented by one.
            static Uint16 set_default_can(Dsp28335_ent::CANcfg& cfg, Uint32 bdr, bool has_arb, bool as_master);

            /// Default Rx CAN configuration.
            /// \wi{18094}
            /// Default_cfg class shall be able to set default configuration for Rx CAN's PDI onto provided PDIC
            /// from provided parameters.
            /// \param[in] cfg          Reference to CAN configuration.
            /// \param[in] has_arb      At true, configure a CANin for arbitrating, else do not.
            /// \param[in] as_master    At true, configure to arbitrate, at false to be arbitrated.
            /// \return Index of the last configured RX element incremented by one.
            static Uint16 set_default_can_rx(Dsp28335_ent::CANcfg::Trx_array& rx_arr, bool has_arb, bool as_master);

            Default_cfg(); ///< = delete
            Default_cfg(const Default_cfg& orig); ///< = delete
            Default_cfg& operator=(const Default_cfg& orig); ///< = delete
    };

    inline Uint16 Default_cfg::get_default_ser_can_id()
    {
        /// \alg
        /// Return ::def_ser_can_id.
        return def_ser_can_id;
    }

    inline Uint16 Default_cfg::get_default_can_ser_id()
    {
        /// \alg
        /// Return ::def_can_ser_id.
        return def_can_ser_id;
    }

    inline Uint16 Default_cfg::set_default_can_1000(Dsp28335_ent::CANcfg& cfg, bool has_arb, bool as_master)
    {
        return set_default_can(cfg, can_bdr_1000, has_arb, as_master);
    }

    inline Uint16 Default_cfg::set_default_can_500(Dsp28335_ent::CANcfg& cfg, bool has_arb, bool as_master)
    {
        return set_default_can(cfg, can_bdr_500, has_arb, as_master);
    }

    template <typename CANIN>
    const CANIN& Default_cfg::get_default_can_in(bool has_arb, bool as_master)
    {
        static CANIN cfg;
        const Uint16 sz_can_in = CANIN::szmax;
        cfg.resize(sz_can_in);

        // First, apply a default configuration to all elements
        for(Uint16 i=0; i<sz_can_in; i++)
        {
            cfg[i] = CANin_p::Config::build_default();
        }
        // Then configure Serial over CAN
        Uint16 idx = Ku16::u0;
        cfg[idx].filter.can_filter.id.id = (!as_master) ? def_can_ser_id : def_ser_can_id;
        idx++;

        // If need to configure CANin for APS
        if(has_arb)
        {
            static const CANin_p::Config ap_cfg =
            {
                CANport::can_ab,
                {
                    {
                        { false, def_ap_base_id },
                        def_rx_mbox_mask
                    },
                    true
                }
            };
            cfg[idx] = ap_cfg;
            idx++;
        }
        return cfg;
    }

    template <typename CANOUT>
    const CANOUT& Default_cfg::get_default_can_out(CANport::Port port)
    {
        static CANOUT cfg;
        const Uint16 sz_can_out = CANOUT::szmax;
        cfg.resize(sz_can_out);

        // First, apply a default configuration to all elements
        for(Uint16 i=0; i<sz_can_out; i++)
        {
            cfg[i].port = port;
        }

        return cfg;
    }

    template <typename CANSC>
    const CANSC& Default_cfg::get_default_can_sc(Real tout, bool as_master)
    {
        static CANSC cfg;
        const Uint16 sz_can_sc = CANSC::szmax;
        cfg.resize(sz_can_sc);
        Uint16 id = (!as_master) ? def_ser_can_id : def_can_ser_id;

        for(Uint16 i=0; i<sz_can_sc; i++)
        {
            cfg[i] = SerialCAN::Config::build(id, false, tout);
        }

        return cfg;
    }

    template <typename XU8>
    const typename Default_cfg::Xpcu8<XU8>::Tmap& Default_cfg::Xpcu8<XU8>::get_default_0sci()
    {
        static const Uint32 xpcu8_1sci_sz = Ku32::u2;
        // Construct the Tnarrayresz
        static const Tmap tmap = {
                                  // Fix used size (equivalent to resize function)
                                  xpcu8_1sci_sz,
                                  {
                                       {
                                            // COM0 <-> SerialCAN
                                            { XU8::XP::com0,        XU8::XC::ser_can0,      XU8::grp_lo},
                                            { XU8::XP::can_ser0,    XU8::XC::com0,          XU8::grp_lo}
                                       }
                                  }
        };
        return tmap;
    }

    template <typename XU8>
    const typename Default_cfg::Xpcu8<XU8>::Tmap& Default_cfg::Xpcu8<XU8>::get_default_1sci()
    {
        static const Uint32 xpcu8_1sci_sz = Ku32::u4;
        // Construct the Tnarrayresz
        static const Tmap tmap = {
            // Fix used size (equivalent to resize function)
            xpcu8_1sci_sz,
            {
                {
                    // COM0 <-> SerialCAN
                    { XU8::XP::com0,      XU8::XC::ser_can0,  XU8::grp_lo,  Base::kbit_ok},
                    { XU8::XP::can_ser0,  XU8::XC::com0,      XU8::grp_lo,  Base::kbit_ok},

                    // COM1 <-> SCIA
                    { XU8::XP::scia,      XU8::XC::com1,      XU8::grp_lo,  Base::kbit_ok},
                    { XU8::XP::com1,      XU8::XC::scia,      XU8::grp_lo,  Base::kbit_ok}
                }
            }
        };
        return tmap;
    }

    template <typename XU8>
    const typename Default_cfg::Xpcu8<XU8>::Tmap& Default_cfg::Xpcu8<XU8>::get_default_2sci()
    {
        static const Uint32 xpcu8_2sci_sz = Ku32::u6;
        // Construct the Tnarrayresz
        static const Tmap tmap = {
            // Fix used size (equivalent to resize function)
            xpcu8_2sci_sz,
            {
                {
                    // COM0 <-> SerialCAN
                    { XU8::XP::com0,      XU8::XC::ser_can0,  XU8::grp_lo,  Base::kbit_ok},
                    { XU8::XP::can_ser0,  XU8::XC::com0,      XU8::grp_lo,  Base::kbit_ok},

                    // COM1 <-> SCIA
                    { XU8::XP::scia,      XU8::XC::com1,      XU8::grp_lo,  Base::kbit_ok},
                    { XU8::XP::com1,      XU8::XC::scia,      XU8::grp_lo,  Base::kbit_ok},

                    // COM2 <-> SCIB
                    { XU8::XP::scib,      XU8::XC::com2,      XU8::grp_lo,  Base::kbit_ok},
                    { XU8::XP::com2,      XU8::XC::scib,      XU8::grp_lo,  Base::kbit_ok}
                }
            }
        };
        return tmap;
    }

    template <typename XU8>
    const typename Default_cfg::Xpcu8<XU8>::Tmap& Default_cfg::Xpcu8<XU8>::get_default_3sci()
    {
        static const Uint32 xpcu8_3sci_sz = Ku32::u8;
        // Construct the Tnarrayresz
        static const Tmap tmap = {
            // Fix used size (equivalent to resize function)
            xpcu8_3sci_sz,
            {
                {
                    // COM0 <-> SerialCAN
                    { XU8::XP::com0,      XU8::XC::ser_can0,  XU8::grp_lo,  Base::kbit_ok},
                    { XU8::XP::can_ser0,  XU8::XC::com0,      XU8::grp_lo,  Base::kbit_ok},

                    // COM1 <-> SCIA
                    { XU8::XP::scia,      XU8::XC::com1,      XU8::grp_lo,  Base::kbit_ok},
                    { XU8::XP::com1,      XU8::XC::scia,      XU8::grp_lo,  Base::kbit_ok},

                    // COM2 <-> SCIB
                    { XU8::XP::scib,      XU8::XC::com2,      XU8::grp_lo,  Base::kbit_ok},
                    { XU8::XP::com2,      XU8::XC::scib,      XU8::grp_lo,  Base::kbit_ok},

                    // COM3 <-> SCIC
                    { XU8::XP::scic,      XU8::XC::com3,      XU8::grp_lo,  Base::kbit_ok},
                    { XU8::XP::com3,      XU8::XC::scic,      XU8::grp_lo,  Base::kbit_ok}
                }
            }
        };
        return tmap;
    }


    template <typename XU8>
    const typename Default_cfg::Xpcu8<XU8>::Tmap& Default_cfg::Xpcu8<XU8>::get_default_4sci()
    {
        static const Uint32 xpcu8_4sci_sz = Ku32::u10;
        // Construct the Tnarrayresz
        static const Tmap tmap = {
            // Fix used size (equivalent to resize function)
            xpcu8_4sci_sz,
            {
                {
                    // COM0 <-> SerialCAN
                    { XU8::XP::com0,      XU8::XC::ser_can0,  XU8::grp_lo,  Base::kbit_ok},
                    { XU8::XP::can_ser0,  XU8::XC::com0,      XU8::grp_lo,  Base::kbit_ok},

                    // COM1 <-> SCIA
                    { XU8::XP::scia,      XU8::XC::com1,      XU8::grp_lo,  Base::kbit_ok},
                    { XU8::XP::com1,      XU8::XC::scia,      XU8::grp_lo,  Base::kbit_ok},

                    // COM2 <-> SCIB
                    { XU8::XP::scib,      XU8::XC::com2,      XU8::grp_lo,  Base::kbit_ok},
                    { XU8::XP::com2,      XU8::XC::scib,      XU8::grp_lo,  Base::kbit_ok},

                    // COM3 <-> SCIC
                    { XU8::XP::scic,      XU8::XC::com3,      XU8::grp_lo,  Base::kbit_ok},
                    { XU8::XP::com3,      XU8::XC::scic,      XU8::grp_lo,  Base::kbit_ok},

                    // COM4 <-> SCID
                    { XU8::XP::scid,      XU8::XC::com4,      XU8::grp_lo,  Base::kbit_ok},
                    { XU8::XP::com4,      XU8::XC::scid,      XU8::grp_lo,  Base::kbit_ok}
                }
            }
        };
        return tmap;
    }

    template <typename XCAN>
    const typename Default_cfg::Xpccan<XCAN>::Tmap& Default_cfg::Xpccan<XCAN>::get_default()
    {
        static const Uint32 xpccan_sz = Ku32::u2;
        // Construct the Tnarrayresz
        static const Tmap tmap = {
            // Fix used size (equivalent to resize function)
            xpccan_sz,
            {
                {
                    // SERIAL TO CAN
                    { XCAN::XP::ser_can0,      XCAN::XC::can_out_filt0,  XCAN::grp_hi,  Base::kbit_ok},
                    { XCAN::XP::can_in_filt0,  XCAN::XC::can_ser0,       XCAN::grp_hi,  Base::kbit_ok}
                }
            }
        };
        return tmap;
    }

    template <typename FVECDATA>
    void Default_cfg::set_default_tm(typename FVECDATA::Fsv0& fsvec,
                                     const Mblock<const Vref::Entry>& entries,
                                     const typename FVECDATA::Vecdata& vdata,
                                     Uint16 nb_fields_per_vec)
    {
        const Uint16 nb_req_vars = entries.sz;                  // Number of required variables

        const Uint16 nb_vecs = FVECDATA::nvecs;                 // Number of available vector into fsvec

        // Const number of required vectors
        const Uint16 nb_req_vecs = static_cast<Uint16>(Rfun::roundi(nb_req_vars/nb_fields_per_vec));

        // Check if the configured number of fields per vector feet with number of required fields
        if(Base::Assertions::runtime((nb_vecs*nb_fields_per_vec)>=nb_req_vars))
        {
            // Boolean to break the loop on error
            bool is_ok = true;

            // Counter to iterate through all fields of entries
            Uint16 it = 0;

            // Const number of iterations through vectors
            const Uint16 max_vec = Rfun::min<Uint16>(nb_vecs, nb_req_vecs);

            // First resize each vector of the fsvec
            for(Uint16 i=0; (i<max_vec) && is_ok; i++)
            {
                // Add a fixed-size vector into fsvec (Return false when failed, break the loop)
                if(fsvec.add_sub_vec(nb_fields_per_vec))
                {
                    bool do_abort = false;
                    // Add all required fields in current vector
                    for(Uint16 j=0; j<nb_fields_per_vec && !do_abort; j++)
                    {
                        do_abort = !fsvec.add_sub_field(i, j, Field::build_field(entries[it]));
                        it++;
                    }

                    if(Base::Assertions::runtime(!do_abort))
                    {
                        // Append extra data to describe current vector fields
                        fsvec.sub_vdat(i, vdata);
                    }
                    else
                    {
                        is_ok = false;
                    }
                }
                else
                {
                    is_ok = false;      // Finish because of error
                }
            }
        }
    }

    template <typename FVECDATA, typename DATA_TYPE>
    Uint16 Default_cfg::update_fmset(typename FVECDATA::Fsv0& fsvec,
                                   const Mblock<const Mblock<const DATA_TYPE> > entries,
                                   const typename FVECDATA::Vecdata vdata)
    {
        const Uint16 first_vector = fsvec.size();
        const Uint16 max_vectors = FVECDATA::nvecs-first_vector;
        const Uint16 nb_vecs = Bsp::warning_assrt(entries.sz < max_vectors) ? entries.sz : max_vectors;  // Number of vectors

        // Boolean to break the loop on error
        bool is_ok = true;

        // First resize each vector of the fsvec
        for(Uint16 i=0; (i<nb_vecs) && is_ok; ++i)
        {
            Uint16 vec_idx = i + first_vector;
            const Uint16 nb_fields_per_vec = entries[i].sz;
            bool do_abort = false;
            if(Bsp::warning_assrt(fsvec.add_sub_vec(nb_fields_per_vec)))
            {
                for(Uint16 j=0; j<nb_fields_per_vec && !do_abort; ++j)
                {

                    do_abort = !fsvec.add_sub_field(vec_idx, j, Field::build_field(entries[i][j]));
                    if(Bsp::warning_assrt(!do_abort))
                    {
                        // Append extra data to describe current vector fields
                        fsvec.sub_vdat(vec_idx, vdata);
                    }
                    else
                    {
                        is_ok = false;
                    }
                }
            }
            else
            {
                is_ok = false;
            }
        }
        return first_vector;
    }

    template <Uint16 nvecs>
    void Default_cfg::set_default_can_tm(Xfmsgcanp0array<nvecs>& cfg, Uint16 nb_ids)
    {
        // There is no initialization message
        cfg.ini.resize(0);
        cfg.tx.resize(nb_ids);
        for(Uint16 i=0; i<nb_ids; i++)
        {
            cfg.tx.v[i].canid.extended = false;
            cfg.tx.v[i].canid.id = def_tm_base_id + i;
            cfg.tx.v[i].msgid = i;
        }
    }

    template <Uint16 nvecs>
    void Default_cfg::set_default_can_tm(Xfmsgcanp0array<nvecs>& cfg, const Mblock<const Uint16> ids)
    {
        // There is no initialization message
        cfg.ini.resize(0);
        cfg.tx.resize(ids.sz);
        for(Uint16 i=0; i<ids.sz; ++i)
        {
            cfg.tx.v[i].canid.extended = false;
            cfg.tx.v[i].canid.id = ids[i];
            cfg.tx.v[i].msgid = i;
        }
    }

    template <Uint16 nvecs, Uint16 max_per_c>
    void Default_cfg::set_default_can_rx(Xfmsgcanc0array<nvecs, max_per_c>& cfg, const Mblock<const Uint32> ids, bool extended, Uint16 first_id)
    {
        cfg.resize(ids.sz);
        for(Uint16 i=0; i<ids.sz; ++i)
        {
            cfg.v[i].canid.extended = extended;
            cfg.v[i].canid.id = ids[i];
            cfg.v[i].msgid = first_id + i;
            cfg.v[i].bitid = static_cast<Bvar>(Base::kbit_msg0 + i);
        }
    }
}

#endif
