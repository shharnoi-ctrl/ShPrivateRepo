#ifndef MBLOCK_FW_H_
#define MBLOCK_FW_H_

namespace Base
{
    template<typename T>
    struct Mblock;
}
#endif
