#include <Call_statchk.h>

namespace Base
{
    Call_statchk::Call_statchk(volatile bool& bit0,
                               Real desired_rate0,
                               Real check_tout) :
       bit(bit0),
       desired_rate(desired_rate0),
       callst(check_tout),
       status_ready(false)
    {
        bit = true;
    }

    void Call_statchk::step()
    {
        if(callst.step())
        {
            bit = ((callst.get_calls_sec() >= desired_rate) || !status_ready);
        }
    }
}
