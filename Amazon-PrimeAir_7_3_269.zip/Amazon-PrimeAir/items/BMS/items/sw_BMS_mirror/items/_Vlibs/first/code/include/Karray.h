///    \file Karray.h
///
///    \date 23/01/2014
///
///    \author  FJBurgos, jbm (at) embention.com
///    Company:  Embention
///
///    Karray class declaration.
/// 

#ifndef KARRAY_H_
#define KARRAY_H_

#include <Array.h>
#include <Tnarray.h>
#include <Karray_fw.h>

namespace Base
{
    /// The Base library shall provide a class to manage constant Array, common base for Array<T> and Array<const T>.
    template<typename T>
    class Karray
    {
    public:
        const Array<const T> k;     ///< Constant Array with constant Templated instance.
        /// Constant Array Constructor with Constant Tnarray.
        /// \wi{5090}
        /// Karray class shall build itself upon construction with given parameter.
        /// \param[in] a    Constant Tnarray.
        template <Uint32 sz>
        explicit Karray(const Tnarray<T,sz>& a);
        /// Constant Array Constructor with Given Constant Templated Constant Tnarray.
        /// \wi{20894}
        /// Karray class shall build itself upon construction with given parameter.
        /// \param[in] a    Constant templated constant Tnarray.
        template <Uint32 sz>
        explicit Karray(const Tnarray<const T,sz>& a);
        /// Constant Array Constructor with Given Constant Templated Constant Array.
        /// \wi{20889}
        /// Karray class shall build itself upon construction with given parameter.
        /// \param[in] a    Constant templated constant Array.
        explicit Karray(const Array<const T>& a);
        /// Constant Array Constructor with Given Templated Constant Array.
        /// \wi{20890}
        /// Karray class shall build itself upon construction with given parameter.
        /// \param[in] a    Templated constant Array.
        explicit Karray(const Array<T>& a);
        /// Constant Array Constructor with Given Constant Templated Constant Mblock.
        /// \wi{20891}
        /// Karray class shall build itself upon construction with given parameter.
        /// \param[in] a    Constant templated constant Mblock.
        explicit Karray(const Mblock<const T>& a);
        /// Constant Array Constructor with Given Templated Constant Mblock.
        /// \wi{20892}
        /// Karray class shall build itself upon construction with given parameter.
        /// \param[in] a    Templated constant Mblock.
        explicit Karray(const Mblock<T>& a);
        /// Constant Array Constructor with Given Constant Pointer Fixed Array and Size.
        /// \wi{20893}
        /// Karray class shall build itself upon construction with given parameters.
        /// \param[in] kv0  Pointer to the first element of the fixed array.
        /// \param[in] kn0  Size of the array.
        Karray(const T* const kv0, Uint32 kn0);

    private:
        Karray();                               ///< = delete.
        Karray(const Karray& orig);             ///< = delete.
        Karray& operator=(const Karray& orig);  ///< = delete.
    };


    template<typename T>
    template <Uint32 sz>
    inline Karray<T>::Karray(const Tnarray<T,sz>& a) : k(a.v, sz)
    {
    }
    template<typename T>
    template <Uint32 sz>
    inline Karray<T>::Karray(const Tnarray<const T,sz>& a) : k(a.v, sz)
    {
    }
    template<typename T>
    inline Karray<T>::Karray(const Array<const T>& a) : k(a.first(), a.size())
    {
    }
    template<typename T>
    inline Karray<T>::Karray(const Array<T>& a) : k(a.first(), a.size())
    {
    }
    template<typename T>
    inline Karray<T>::Karray(const Mblock<const T>& a) : k(a.v, a.size())
    {
    }
    template<typename T>
    inline Karray<T>::Karray(const Mblock<T>& a) : k(a.v, a.size())
    {
    }
    template<typename T>
    inline Karray<T>::Karray(const T* const kv0, Uint32 kn0) : k(kv0, kn0)
    {
    }

} // namespace Base
#endif // KARRAY_H_
