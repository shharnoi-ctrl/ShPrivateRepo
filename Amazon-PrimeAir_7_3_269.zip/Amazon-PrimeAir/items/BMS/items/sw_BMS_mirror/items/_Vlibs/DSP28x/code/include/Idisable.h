#ifndef IDISABLE_H__
#define IDISABLE_H__

namespace Dsp28335_ent
{
    /// Interface to disable a peripheral by accessing platform registers
    class Idisable
    {
    public:
        virtual void disable() = 0;   ///< Disable function

    protected:
        ~Idisable();  ///< Destructor (does nothing)
    };

    inline Idisable::~Idisable()
    {
    }

}

#endif
