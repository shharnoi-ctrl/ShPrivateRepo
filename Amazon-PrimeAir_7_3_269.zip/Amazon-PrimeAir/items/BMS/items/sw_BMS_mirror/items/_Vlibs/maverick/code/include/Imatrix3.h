#ifndef INCLUDE_IMATRIX3_H_
#define INCLUDE_IMATRIX3_H_

#include <Ivector.h>

namespace Maverick
{
    template <typename T>
    class Imatrix3 : public Ivector<T>
    {
    public:
        enum Positions      ///< Matrix position enumeration for construction.
        {
            a00 = 0,
            a10 = 1,
            a20 = 2,    //|a00 a01 a02|
            a01 = 3,    //|a10 a11 a12|
            a11 = 4,    //|a20 a21 a22|
            a21 = 5,
            a02 = 6,
            a12 = 7,
            a22 = 8
        };

        enum Uvector        ///< Unitary vector identifiers for construction.
        {
            px,         ///< +X.
            nx,         ///< -X.
            py,         ///< +Y.
            ny,         ///< -Y.
            pz,         ///< +Z.
            nz          ///< -Z.
        };
        /// Imatrix3 Constructor with Given Parameters.
        /// \wi{19790}
        /// Imatrix3 class shall build itself upon construction with a memory block buffer.
        /// \param[in] mb       Memory block.
        explicit Imatrix3(Base::Mblock<T> mb);
        /// Imatrix3 Constructor with Given Parameters.
        /// \wi{19791}
        /// Imatrix3 class shall build itself upon construction with a pointer.
        /// \param[in] v0       Pointer to first Array element.
        explicit Imatrix3(T* v0);
        /// Imatrix3 Size Retriever.
        /// \wi{19792}
        /// Imatrix3 shall be able to retrieve the size of the matrix.
        /// \return Size of the Matrix.
        static Uint32 size();
        /// Imatrix3 Memory Block Retriever.
        /// \wi{19793}
        /// Imatrix3 shall be able to retrieve a memory block from a 3x3 Matrix.
        /// \return Memory block for the matrix.
        Base::Mblock<const T> to_kmblock() const;
        /// Imatrix3 Memory Block Setter.
        /// \wi{19794}
        /// Imatrix3 shall provide the capability to set a 3x3 Matrix for a given memory block.
        /// \param[in] data     Memory block with the data.
        void set(const Base::Mblock<T>& data);
        /// Imatrix3 Zero Setter.
        /// \wi{19795}
        /// Imatrix3 shall provide the capability to set to 0 the values of the Matrix.
        inline void zeros()
        {
            Base::Tmem::set<sz*sizeof(T)>(Ivector<T>::v,0);
        }
        /// Imatrix3 Values Copier.
        /// \wi{19796}
        /// Imatrix3 class shall provide the capability to copy new values from a given source.
        /// \param[in] v0       Pointer to a Real Array.
        inline void copy(const T* v0)
        {
            /// \alg
            /// - Call Ivector::copy0 for ::sz and given pointer.
            Ivector<T>::template copy0<sz>(v0);
        }
        /// Imatrix3 Copier.
        /// \wi{19797}
        /// Imatrix3 class shall provide the capability to copy new values from a given 3x3 Matrix.
        /// \param[in] v0       Reference to a 3x3 Matrix.
        void copy(const Imatrix3<T>& v0)
        {
            /// \alg
            /// - Call Ivector::copy0 for ::sz and given 3x3 Matrix.
            Ivector<T>::template copy0<sz>(v0);
        }
        /// Imatrix3 Post-Multiplication Computer.
        /// \wi{3018}
        /// Imatrix class shall provide the capability to compute the post-multiplication for a given 3x3 Matrix.
        /// \param[in] y        Reference to the 3x3 Matrix.
        void thismat(const Imatrix3<T>& y);
        /// Imatrix3 Pre-Multiplication Computer.
        /// \wi{3017}
        /// Imatrix3 class shall provide the capability to compute the pre-multiplication for a given 3x3 Matrix.
        /// \param[in] x        Reference to the 3x3 Matrix.
        void matthis(const Imatrix3<T>& x);

    private:
        static const Uint32 sz = 9U;        ///< Size for Ivector.

        Imatrix3();                                ///< = delete
        Imatrix3(const Imatrix3& src);             ///< = delete
        Imatrix3& operator=(const Imatrix3& src);  ///< = delete
    };


    template <typename T>
    inline Imatrix3<T>::Imatrix3(Base::Mblock<T> mb):Ivector<T>(mb.v)
    {
        /// \alg
        /// - Assert for correct given memory block size.
        Base::Assertions::runtime(mb.sz==sz);
    }

    template <typename T>
    inline Imatrix3<T>::Imatrix3(T* v0):Ivector<T>(v0)
    {
    }

    template <typename T>
    inline Uint32 Imatrix3<T>::size()
    {
        /// \alg
        /// - Return ::sz.
        return sz;
    }

    template <typename T>
    inline Base::Mblock<const T> Imatrix3<T>::to_kmblock() const
    {
        /// \alg
        /// - Return Real memory block for ::v and ::sz.
        return Base::Mblock<const T>(Ivector<T>::v,sz);
    }

    template <typename T>
    inline void Imatrix3<T>::set(const Base::Mblock<T>& data)
    {
        /// \alg
        /// <ul>
        /// <li> If Assert for correct given memory block size:
        if(Base::Assertions::runtime(data.sz == sz))
        {
            /// <ul>
            /// <li> Initialize Real memory block for ::v and ::sz.
            Base::Mblock<T> mb(Ivector<T>::v, sz);
            /// <li> Copy given data values in memory block.
            mb.copy(data);
            /// </ul>
        }
        /// </ul>
    }

    template <typename T>
    void Imatrix3<T>::thismat(const Imatrix3<T>& y)
    {
        /// \alg
        /// <ul>
        /// <li> Copy its internal 3x3 Matrix.
        T x[Ku16::u6];
        Base::Tmem::cpy<Ku16::u6*sizeof(T)>(x,Ivector<T>::v);
        /// <li> Get pointer to the first element of the given 3x3 Matrix.
        const T* const yv = &y[0U];

        /// <li> Calculate the multiplication of its internal 3x3 Matrix by the given 3x3 Matrix.
        Ivector<T>::v[a00]=(Ivector<T>::v[a00]*yv[a00]) + (Ivector<T>::v[a01]*yv[a10]) + (Ivector<T>::v[a02]*yv[a20]);
        Ivector<T>::v[a10]=(Ivector<T>::v[a10]*yv[a00]) + (Ivector<T>::v[a11]*yv[a10]) + (Ivector<T>::v[a12]*yv[a20]);
        Ivector<T>::v[a20]=(Ivector<T>::v[a20]*yv[a00]) + (Ivector<T>::v[a21]*yv[a10]) + (Ivector<T>::v[a22]*yv[a20]);

        Ivector<T>::v[a01]=(x[Ku16::u0]*yv[a01]) + (Ivector<T>::v[a01]*yv[a11]) + (Ivector<T>::v[a02]*yv[a21]);
        Ivector<T>::v[a11]=(x[Ku16::u1]*yv[a01]) + (Ivector<T>::v[a11]*yv[a11]) + (Ivector<T>::v[a12]*yv[a21]);
        Ivector<T>::v[a21]=(x[Ku16::u2]*yv[a01]) + (Ivector<T>::v[a21]*yv[a11]) + (Ivector<T>::v[a22]*yv[a21]);

        Ivector<T>::v[a02]=(x[Ku16::u0]*yv[a02]) + (x[Ku16::u3]*yv[a12]) + (Ivector<T>::v[a02]*yv[a22]);
        Ivector<T>::v[a12]=(x[Ku16::u1]*yv[a02]) + (x[Ku16::u4]*yv[a12]) + (Ivector<T>::v[a12]*yv[a22]);
        Ivector<T>::v[a22]=(x[Ku16::u2]*yv[a02]) + (x[Ku16::u5]*yv[a12]) + (Ivector<T>::v[a22]*yv[a22]);
        /// </ul>
    }

    template <typename T>
    void Imatrix3<T>::matthis(const Imatrix3<T>& x)
    {
        /// \alg
        /// <ul>
        /// <li> Copy its internal 3x3 Matrix.
        T y[Ku16::u6]= {Ivector<T>::v[a00],Ivector<T>::v[a10],Ivector<T>::v[a01],
                        Ivector<T>::v[a11],Ivector<T>::v[a02],Ivector<T>::v[a12]};
        /// <li> Get pointer to the first element of the given 3x3 Matrix.
        const T* const xv = &x[0U];

        /// <li> Calculate the multiplication of the given 3x3 Matrix by its internal 3x3 Matrix by.
        Ivector<T>::v[a00]=(xv[a00]*Ivector<T>::v[a00]) + (xv[a01]*Ivector<T>::v[a10]) + (xv[a02]*Ivector<T>::v[a20]);
        Ivector<T>::v[a10]=(xv[a10]*y[Ku16::u0]) + (xv[a11]*Ivector<T>::v[a10]) + (xv[a12]*Ivector<T>::v[a20]);
        Ivector<T>::v[a20]=(xv[a20]*y[Ku16::u0]) + (xv[a21]*y[Ku16::u1]) + (xv[a22]*Ivector<T>::v[a20]);

        Ivector<T>::v[a01]=(xv[a00]*Ivector<T>::v[a01]) + (xv[a01]*Ivector<T>::v[a11]) + (xv[a02]*Ivector<T>::v[a21]);
        Ivector<T>::v[a11]=(xv[a10]*y[Ku16::u2]) + (xv[a11]*Ivector<T>::v[a11]) + (xv[a12]*Ivector<T>::v[a21]);
        Ivector<T>::v[a21]=(xv[a20]*y[Ku16::u2]) + (xv[a21]*y[Ku16::u3]) + (xv[a22]*Ivector<T>::v[a21]);

        Ivector<T>::v[a02]=(xv[a00]*Ivector<T>::v[a02]) + (xv[a01]*Ivector<T>::v[a12]) + (xv[a02]*Ivector<T>::v[a22]);
        Ivector<T>::v[a12]=(xv[a10]*y[Ku16::u4]) + (xv[a11]*Ivector<T>::v[a12]) + (xv[a12]*Ivector<T>::v[a22]);
        Ivector<T>::v[a22]=(xv[a20]*y[Ku16::u4]) + (xv[a21]*y[Ku16::u5]) + (xv[a22]*Ivector<T>::v[a22]);
        /// </ul>
    }
}

#endif
