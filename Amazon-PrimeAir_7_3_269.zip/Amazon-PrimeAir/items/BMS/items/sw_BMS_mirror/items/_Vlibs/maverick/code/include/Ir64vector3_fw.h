#ifndef IR64VECTOR3_FW_H_
#define IR64VECTOR3_FW_H_

namespace Maverick
{
    class Ir64vector3;
}

#endif
