#ifndef PLL_H_
#define PLL_H_

#include <Entypes.h>

namespace Dsp28335_ent
{
    namespace PLL
    {
        /// Initializes System PLL.
        void pll_sys_init();

        /// Initializes AUX PLL.
        /// \note This method uses Timer 2 internally, so, timer status is changed.
        void pll_aux_init();

        /// Update Kclk internal values.
        void update_sys_clk();
    }
}
#endif
