#ifndef FLASH_H_
#define FLASH_H_

#include <Entypes.h>

namespace Dsp28335_ent
{
    /// Flash initialization helper.
    /// Dsp28x library shall provide support in order to handle Flash on-chip memory initialization.
    class Flash
    {
    public:
        /// Physical Flash on-chip memory start address
        static const Uint32 flash_start;

        /// Flash peripheral initialization.
        /// \wi{8051}
        /// Flash class shall provide a method to initialize the Flash peripheral access timings (wait states) through internal registers.
        /// \rationale Shall be executed out of RAM. Executing it out of OTP/Flash will yield unpredictable results.
        static void init();

    private:
        Flash(); ///< = delete
        Flash(const Flash& orig); ///< = delete
        Flash& operator=(const Flash& orig); ///< = delete
    };
}

#endif
