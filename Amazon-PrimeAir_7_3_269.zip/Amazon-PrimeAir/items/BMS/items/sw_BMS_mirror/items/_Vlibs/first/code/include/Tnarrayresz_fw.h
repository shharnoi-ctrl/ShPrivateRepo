#ifndef TNARRAYRESZ_FW_H_
#define TNARRAYRESZ_FW_H_

#include <Entypes.h>

namespace Base
{
    template <typename T, Uint32 n>
    struct Tnarrayresz;
}
#endif
