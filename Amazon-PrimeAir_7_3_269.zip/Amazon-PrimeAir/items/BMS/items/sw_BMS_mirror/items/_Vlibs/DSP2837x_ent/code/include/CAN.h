#ifndef INCLUDE_CAN_H_
#define INCLUDE_CAN_H_

#include <Entypes.h>

// Forward references
#include <CANcfg_fw.h>
#include <CANframe_fw.h>
#include <CANpid.h>
#include <Error.h>
#include <Timeout.h>

namespace Dsp28335_ent
{
    struct Regshandler;

    // Methods are not supposed to be called from different tasks.
    class CAN
    {
    public:
        typedef Base::CANframe type; // required by producer/consumer contract

        /// CAN Constructor.
        /// \wi{7581}
        /// CAN class shall initialize itself upon construction with the provided parameter.
        /// \param[in] id0  CAN peripheral identifier.
        explicit CAN(Base::CANpid id0);         ///< Build with given CAN id
        /// CAN Configuration.
        /// \wi{7686}
        /// CAN class shall provide the capability to configure CAN by setting the correct peripheral registers.
        /// \param[in] cfg CAN configuration.
        void config(const CANcfg& cfg);

        /// CAN Transmission Clear By Timeout.
        /// \wi{15807}
        /// CAN instance shall provide a method to check if transmission has been blocked by more than 100ms and clear
        /// the output mailboxes if that happens.
        /// \rat If the write is blocked for more than 100ms, we can assume the pending messages are too old and must
        /// be removed to avoid communication glitches.
        void check_tx_tout();       
        
        /// CAN Read.
        /// \wi{7705}
        /// CAN class shall provide the capability to retrieve its next available received CAN message.
        /// \param[out] data CAN message read.
        /// \return True if there is is data to read.
        bool read(Base::CANframe& data);

        /// CAN Write.
        /// \wi{7716}
        /// CAN class shall provide the capability to write a CAN message if there is any output mailbox available.
        /// \param[in] data CAN frame to write.
        /// \return True if data actually written.
        bool write(const Base::CANframe& data);
        /// CAN Write Available.
        /// \wi{7727}
        /// CAN class shall provide the capability to check if there is any output mailbox available to write.
        /// \return True if data can be written.
        bool wr_available() const;

        /// CAN Get Bus On.
        /// \wi{7625}
        /// CAN class shall provide the capability to check if the bus is on by reading peripheral registers.
        /// \return True if the bus is on, False if is in error state.
        bool   get_bus_on() const;
        /// CAN Get Warning.
        /// \wi{7626}
        /// CAN class shall provide the capability to check if there is any warning.
        /// \return True if there is no warning.
        bool   get_warning_off() const;
        /// CAN Get Tx Errors.
        /// \wi{7628}
        /// CAN class shall provide the capability to get the number of tx errors.
        /// \return Tx error counter.
        Uint16 get_tx_errors() const;
        /// CAN Get Rx Errors.
        /// \wi{7627}
        /// CAN class shall provide the capability to get the number of rx errors.
        /// \return Rx error counter.
        Uint16 get_rx_errors() const;
        /// CAN Get Tx Count.
        /// \wi{7826}
        /// CAN class shall provide the capability to get the transmitted CANframes count and reset it.
        /// \return Number of CANframes transmitted since last check.
        Uint32 get_tx_count();
        /// CAN Get Rx Count.
        /// \wi{7822}
        /// CAN class shall provide the capability to get the received CANframes count and reset it.
        /// \return Number of CANframes received since last check.
        Uint32 get_rx_count();

        /// CAN Manage Rx.
        /// \wi{8036}
        /// CAN class shall provide the capability to process pending messages.
        void manage_rx();

    private:
        const Base::CANpid id;  ///< CAN Id.
        Regshandler& regs;      ///< Hardware registers.
        Uint32 tx_count;        ///< Number of CANframes transmitted since last check.
        Uint32 rx_count;        ///< Number of CANframes received since last check.
        Uint32 rx_mb_count;     ///< Number of rx CAN mailboxes.
        Base::Timeout tx_tout;  ///< CAN Tx timeout to flush mailboxes.
        bool configuring;       ///< True while configuration ongoing.

        /// CAN Transmission Mailboxes Clear.
        /// \wi{15808}
        /// CAN instance shall provide a method to clear the output mailboxes.
        void clear_tx_mbs();

        CAN(); ///< = delete
        CAN(const CAN& orig); ///< = delete
        CAN& operator=(const CAN& orig); ///< = delete
    };

    inline Uint32 CAN::get_tx_count()
    {
        Uint32 res = tx_count;
        tx_count = 0;
        return res;
    }

    inline Uint32 CAN::get_rx_count()
    {
        Uint32 res = rx_count;
        rx_count = 0;
        return res;
    }

    inline void CAN::manage_rx()
    {
        // Not implemented by 28377
    }
}
#endif
