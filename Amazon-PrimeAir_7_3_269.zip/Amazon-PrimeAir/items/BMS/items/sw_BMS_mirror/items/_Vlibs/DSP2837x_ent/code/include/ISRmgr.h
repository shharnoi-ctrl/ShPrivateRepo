#ifndef ISRMGR_H_
#define ISRMGR_H_

#include <Isrptr.h>
#include <Entypes.h>

namespace Dsp28335_ent
{
    /// Interrupt Service Manager
    class ISRmgr
    {
    public:
        /// Vector Table identifiers
        enum Pievectid
        {
            pie1_reserved_int,              ///< Reserved
            pie2_reserved_int,              ///< Reserved
            pie3_reserved_int,              ///< Reserved
            pie4_reserved_int,              ///< Reserved
            pie5_reserved_int,              ///< Reserved
            pie6_reserved_int,              ///< Reserved
            pie7_reserved_int,              ///< Reserved
            pie8_reserved_int,              ///< Reserved
            pie9_reserved_int,              ///< Reserved
            pie10_reserved_int,             ///< Reserved
            pie11_reserved_int,             ///< Reserved
            pie12_reserved_int,             ///< Reserved
            pie13_reserved_int,             ///< Reserved
            timer1_int,                     ///< CPU Timer 1 Interrupt
            timer2_int,                     ///< CPU Timer 2 Interrupt
            datalog_int,                    ///< Datalogging Interrupt
            rtos_int,                       ///< RTOS Interrupt
            emu_int,                        ///< Emulation Interrupt
            nmi_int,                        ///< Non-Maskable Interrupt
            illegal_int,                    ///< Illegal Operation Trap
            user1_int,                      ///< User Defined Trap 1
            user2_int,                      ///< User Defined Trap 2
            user3_int,                      ///< User Defined Trap 3
            user4_int,                      ///< User Defined Trap 4
            user5_int,                      ///< User Defined Trap 5
            user6_int,                      ///< User Defined Trap 6
            user7_int,                      ///< User Defined Trap 7
            user8_int,                      ///< User Defined Trap 8
            user9_int,                      ///< User Defined Trap 9
            user10_int,                     ///< User Defined Trap 10
            user11_int,                     ///< User Defined Trap 11
            user12_int,                     ///< User Defined Trap 12
            adca1_int,                      ///< 1.1 - ADCA Interrupt 1
            adcb1_int,                      ///< 1.2 - ADCB Interrupt 1
            adcc1_int,                      ///< 1.3 - ADCC Interrupt 1
            xint1_int,                      ///< 1.4 - XINT1 Interrupt
            xint2_int,                      ///< 1.5 - XINT2 Interrupt
            adcd1_int,                      ///< 1.6 - ADCD Interrupt 1
            timer0_int,                     ///< 1.7 - Timer 0 Interrupt
            wake_int,                       ///< 1.8 - Standby and Halt Wakeup Interrupt
            epwm1_tz_int,                   ///< 2.1 - ePWM1 Trip Zone Interrupt
            epwm2_tz_int,                   ///< 2.2 - ePWM2 Trip Zone Interrupt
            epwm3_tz_int,                   ///< 2.3 - ePWM3 Trip Zone Interrupt
            epwm4_tz_int,                   ///< 2.4 - ePWM4 Trip Zone Interrupt
            epwm5_tz_int,                   ///< 2.5 - ePWM5 Trip Zone Interrupt
            epwm6_tz_int,                   ///< 2.6 - ePWM6 Trip Zone Interrupt
            epwm7_tz_int,                   ///< 2.7 - ePWM7 Trip Zone Interrupt
            epwm8_tz_int,                   ///< 2.8 - ePWM8 Trip Zone Interrupt
            epwm1_int,                      ///< 3.1 - ePWM1 Interrupt
            epwm2_int,                      ///< 3.2 - ePWM2 Interrupt
            epwm3_int,                      ///< 3.3 - ePWM3 Interrupt
            epwm4_int,                      ///< 3.4 - ePWM4 Interrupt
            epwm5_int,                      ///< 3.5 - ePWM5 Interrupt
            epwm6_int,                      ///< 3.6 - ePWM6 Interrupt
            epwm7_int,                      ///< 3.7 - ePWM7 Interrupt
            epwm8_int,                      ///< 3.8 - ePWM8 Interrupt
            ecap1_int,                      ///< 4.1 - eCAP1 Interrupt
            ecap2_int,                      ///< 4.2 - eCAP2 Interrupt
            ecap3_int,                      ///< 4.3 - eCAP3 Interrupt
            ecap4_int,                      ///< 4.4 - eCAP4 Interrupt
            ecap5_int,                      ///< 4.5 - eCAP5 Interrupt
            ecap6_int,                      ///< 4.6 - eCAP6 Interrupt
            pie14_reserved_int,             ///< 4.7 - Reserved
            pie15_reserved_int,             ///< 4.8 - Reserved
            eqep1_int,                      ///< 5.1 - eQEP1 Interrupt
            eqep2_int,                      ///< 5.2 - eQEP2 Interrupt
            eqep3_int,                      ///< 5.3 - eQEP3 Interrupt
            pie16_reserved_int,             ///< 5.4 - Reserved
            pie17_reserved_int,             ///< 5.5 - Reserved
            pie18_reserved_int,             ///< 5.6 - Reserved
            pie19_reserved_int,             ///< 5.7 - Reserved
            pie20_reserved_int,             ///< 5.8 - Reserved
            spia_rx_int,                    ///< 6.1 - SPIA Receive Interrupt
            spia_tx_int,                    ///< 6.2 - SPIA Transmit Interrupt
            spib_rx_int,                    ///< 6.3 - SPIB Receive Interrupt
            spib_tx_int,                    ///< 6.4 - SPIB Transmit Interrupt
            mcbspa_rx_int,                  ///< 6.5 - McBSPA Receive Interrupt
            mcbspa_tx_int,                  ///< 6.6 - McBSPA Transmit Interrupt
            mcbspb_rx_int,                  ///< 6.7 - McBSPB Receive Interrupt
            mcbspb_tx_int,                  ///< 6.8 - McBSPB Transmit Interrupt
            dma_ch1_int,                    ///< 7.1 - DMA Channel 1 Interrupt
            dma_ch2_int,                    ///< 7.2 - DMA Channel 2 Interrupt
            dma_ch3_int,                    ///< 7.3 - DMA Channel 3 Interrupt
            dma_ch4_int,                    ///< 7.4 - DMA Channel 4 Interrupt
            dma_ch5_int,                    ///< 7.5 - DMA Channel 5 Interrupt
            dma_ch6_int,                    ///< 7.6 - DMA Channel 6 Interrupt
            pie21_reserved_int,             ///< 7.7 - Reserved
            pie22_reserved_int,             ///< 7.8 - Reserved
            i2ca_int,                       ///< 8.1 - I2CA Interrupt 1
            i2ca_fifo_int,                  ///< 8.2 - I2CA Interrupt 2
            i2cb_int,                       ///< 8.3 - I2CB Interrupt 1
            i2cb_fifo_int,                  ///< 8.4 - I2CB Interrupt 2
            scic_rx_int,                    ///< 8.5 - SCIC Receive Interrupt
            scic_tx_int,                    ///< 8.6 - SCIC Transmit Interrupt
            scid_rx_int,                    ///< 8.7 - SCID Receive Interrupt
            scid_tx_int,                    ///< 8.8 - SCID Transmit Interrupt
            scia_rx_int,                    ///< 9.1 - SCIA Receive Interrupt
            scia_tx_int,                    ///< 9.2 - SCIA Transmit Interrupt
            scib_rx_int,                    ///< 9.3 - SCIB Receive Interrupt
            scib_tx_int,                    ///< 9.4 - SCIB Transmit Interrupt
            cana0_int,                      ///< 9.5 - CANA Interrupt 0
            cana1_int,                      ///< 9.6 - CANA Interrupt 1
            canb0_int,                      ///< 9.7 - CANB Interrupt 0
            canb1_int,                      ///< 9.8 - CANB Interrupt 1
            adca_evt_int,                   ///< 10.1 - ADCA Event Interrupt
            adca2_int,                      ///< 10.2 - ADCA Interrupt 2
            adca3_int,                      ///< 10.3 - ADCA Interrupt 3
            adca4_int,                      ///< 10.4 - ADCA Interrupt 4
            adcb_evt_int,                   ///< 10.5 - ADCB Event Interrupt
            adcb2_int,                      ///< 10.6 - ADCB Interrupt 2
            adcb3_int,                      ///< 10.7 - ADCB Interrupt 3
            adcb4_int,                      ///< 10.8 - ADCB Interrupt 4
            cla1_1_int,                     ///< 11.1 - CLA1 Interrupt 1
            cla1_2_int,                     ///< 11.2 - CLA1 Interrupt 2
            cla1_3_int,                     ///< 11.3 - CLA1 Interrupt 3
            cla1_4_int,                     ///< 11.4 - CLA1 Interrupt 4
            cla1_5_int,                     ///< 11.5 - CLA1 Interrupt 5
            cla1_6_int,                     ///< 11.6 - CLA1 Interrupt 6
            cla1_7_int,                     ///< 11.7 - CLA1 Interrupt 7
            cla1_8_int,                     ///< 11.8 - CLA1 Interrupt 8
            xint3_int,                      ///< 12.1 - XINT3 Interrupt
            xint4_int,                      ///< 12.2 - XINT4 Interrupt
            xint5_int,                      ///< 12.3 - XINT5 Interrupt
            pie23_reserved_int,             ///< 12.4 - Reserved
            pie24_reserved_int,             ///< 12.5 - Reserved
            vcu_int,                        ///< 12.6 - VCU Interrupt
            fpu_overflow_int,               ///< 12.7 - FPU Overflow Interrupt
            fpu_underflow_int,              ///< 12.8 - FPU Underflow Interrupt
            pie25_reserved_int,             ///< 1.9 - Reserved
            pie26_reserved_int,             ///< 1.10 - Reserved
            pie27_reserved_int,             ///< 1.11 - Reserved
            pie28_reserved_int,             ///< 1.12 - Reserved
            ipc0_int,                       ///< 1.13 - IPC Interrupt 0
            ipc1_int,                       ///< 1.14 - IPC Interrupt 1
            ipc2_int,                       ///< 1.15 - IPC Interrupt 2
            ipc3_int,                       ///< 1.16 - IPC Interrupt 3
            epwm9_tz_int,                   ///< 2.9 - ePWM9 Trip Zone Interrupt
            epwm10_tz_int,                  ///< 2.10 - ePWM10 Trip Zone Interrupt
            epwm11_tz_int,                  ///< 2.11 - ePWM11 Trip Zone Interrupt
            epwm12_tz_int,                  ///< 2.12 - ePWM12 Trip Zone Interrupt
            pie29_reserved_int,             ///< 2.13 - Reserved
            pie30_reserved_int,             ///< 2.14 - Reserved
            pie31_reserved_int,             ///< 2.15 - Reserved
            pie32_reserved_int,             ///< 2.16 - Reserved
            epwm9_int,                      ///< 3.9 - ePWM9 Interrupt
            epwm10_int,                     ///< 3.10 - ePWM10 Interrupt
            epwm11_int,                     ///< 3.11 - ePWM11 Interrupt
            epwm12_int,                     ///< 3.12 - ePWM12 Interrupt
            pie33_reserved_int,             ///< 3.13 - Reserved
            pie34_reserved_int,             ///< 3.14 - Reserved
            pie35_reserved_int,             ///< 3.15 - Reserved
            pie36_reserved_int,             ///< 3.16 - Reserved
            pie37_reserved_int,             ///< 4.9 - Reserved
            pie38_reserved_int,             ///< 4.10 - Reserved
            pie39_reserved_int,             ///< 4.11 - Reserved
            pie40_reserved_int,             ///< 4.12 - Reserved
            pie41_reserved_int,             ///< 4.13 - Reserved
            pie42_reserved_int,             ///< 4.14 - Reserved
            pie43_reserved_int,             ///< 4.15 - Reserved
            pie44_reserved_int,             ///< 4.16 - Reserved
            sd1_int,                        ///< 5.9 - SD1 Interrupt
            sd2_int,                        ///< 5.10 - SD2 Interrupt
            pie45_reserved_int,             ///< 5.11 - Reserved
            pie46_reserved_int,             ///< 5.12 - Reserved
            pie47_reserved_int,             ///< 5.13 - Reserved
            pie48_reserved_int,             ///< 5.14 - Reserved
            pie49_reserved_int,             ///< 5.15 - Reserved
            pie50_reserved_int,             ///< 5.16 - Reserved
            spic_rx_int,                    ///< 6.9 - SPIC Receive Interrupt
            spic_tx_int,                    ///< 6.10 - SPIC Transmit Interrupt
            pie51_reserved_int,             ///< 6.11 - Reserved
            pie52_reserved_int,             ///< 6.12 - Reserved
            pie53_reserved_int,             ///< 6.13 - Reserved
            pie54_reserved_int,             ///< 6.14 - Reserved
            pie55_reserved_int,             ///< 6.15 - Reserved
            pie56_reserved_int,             ///< 6.16 - Reserved
            pie57_reserved_int,             ///< 7.9 - Reserved
            pie58_reserved_int,             ///< 7.10 - Reserved
            pie59_reserved_int,             ///< 7.11 - Reserved
            pie60_reserved_int,             ///< 7.12 - Reserved
            pie61_reserved_int,             ///< 7.13 - Reserved
            pie62_reserved_int,             ///< 7.14 - Reserved
            pie63_reserved_int,             ///< 7.15 - Reserved
            pie64_reserved_int,             ///< 7.16 - Reserved
            pie65_reserved_int,             ///< 8.9 - Reserved
            pie66_reserved_int,             ///< 8.10 - Reserved
            pie67_reserved_int,             ///< 8.11 - Reserved
            pie68_reserved_int,             ///< 8.12 - Reserved
            pie69_reserved_int,             ///< 8.13 - Reserved
            pie70_reserved_int,             ///< 8.14 - Reserved
            uppa_int,                       ///< 8.15 - uPPA Interrupt (Only CPU1)
            pie72_reserved_int,             ///< 8.16 - Reserved
            pie73_reserved_int,             ///< 9.9 - Reserved
            pie74_reserved_int,             ///< 9.10 - Reserved
            pie75_reserved_int,             ///< 9.11 - Reserved
            pie76_reserved_int,             ///< 9.12 - Reserved
            pie77_reserved_int,             ///< 9.13 - Reserved
            pie78_reserved_int,             ///< 9.14 - Reserved
            usba_int,                       ///< 9.15 - USBA Interrupt (Only CPU1)
            pie80_reserved_int,             ///< 9.16 - Reserved
            adcc_evt_int,                   ///< 10.9 - ADCC Event Interrupt
            adcc2_int,                      ///< 10.10 - ADCC Interrupt 2
            adcc3_int,                      ///< 10.11 - ADCC Interrupt 3
            adcc4_int,                      ///< 10.12 - ADCC Interrupt 4
            adcd_evt_int,                   ///< 10.13 - ADCD Event Interrupt
            adcd2_int,                      ///< 10.14 - ADCD Interrupt 2
            adcd3_int,                      ///< 10.15 - ADCD Interrupt 3
            adcd4_int,                      ///< 10.16 - ADCD Interrupt 4
            pie81_reserved_int,             ///< 11.9 - Reserved
            pie82_reserved_int,             ///< 11.10 - Reserved
            pie83_reserved_int,             ///< 11.11 - Reserved
            pie84_reserved_int,             ///< 11.12 - Reserved
            pie85_reserved_int,             ///< 11.13 - Reserved
            pie86_reserved_int,             ///< 11.14 - Reserved
            pie87_reserved_int,             ///< 11.15 - Reserved
            pie88_reserved_int,             ///< 11.16 - Reserved
            emif_error_int,                 ///< 12.9 - EMIF Error Interrupt
            ram_correctable_error_int,      ///< 12.10 - RAM Correctable Error Interrupt
            flash_correctable_error_int,    ///< 12.11 - Flash Correctable Error Interrupt
            ram_access_violation_int,       ///< 12.12 - RAM Access Violation Interrupt
            sys_pll_slip_int,               ///< 12.13 - System PLL Slip Interrupt
            aux_pll_slip_int,               ///< 12.14 - Auxiliary PLL Slip Interrupt
            cla_overflow_int,               ///< 12.15 - CLA Overflow Interrupt
            cla_underflow_int,              ///< 12.16 - CLA Underflow Interrupt
            pie_vect_sz
        };

        /// Initializes all ISR to point to reset_isr()
        static void init();
        static void set_isr(Pievectid id, Isrptr func);

    private:
        ISRmgr(); ///< = delete
        ISRmgr(const ISRmgr& obj); ///< = delete
        ISRmgr& operator=(const ISRmgr& obj); ///< = delete
    };
}
#endif
