#ifndef VREF_H__
#define VREF_H__

#include <Entypes.h>
#include <Rvar.h>

#include <Lossy_fw.h>
#include <Lossy_error_fw.h>

namespace Base
{
    /// The ::Base library shall provide a structure to manage variable reference to its corresponing system variables.
    struct Vref
    {
        /// The Vref struct shall provide an enumeration for the different configurations of the variable reference used.
        enum Type
        {
            rvar = 0,       ///< (0) Rvar type (Real).
            uvar = 1,       ///< (1) Uvar type (Uint).
            bvar = 2,       ///< (2) Bvar type (Bit).
            // Update cset if this enum changes
            kval = 65534,   ///< (65534) Constant value, not Varmgr.
            none = 65535    ///< (65535) None.
        };

        /// The Vref struct shall provide a struct with a type of variable and a variable identifier.
        struct Entry
        {
            Type   type;    ///< Type of variable (bvar,rvar,uvar).
            Uint16 id;      ///< Variable identifier, when type is related to Varmgr.
        };

        Entry   entry;      ///< Type and Id data.
        Real    value;      ///< Real value associated with the type and the identifier.

        /// Variable Reference Static Builder.
        /// \wi{4872}
        /// Vref shall provide the capability to build an empty variable reference instance.
        /// \return Variable reference structure instance.
        static Vref build();
        /// Variable Reference Static Builder.
        /// \wi{19808}
        /// Vref shall provide the capability to build a variable reference instance for a given real variable
        /// identifier.
        /// \param[in] id0      Real variable identifier.
        /// \return Variable reference structure instance.
        static Vref build(Rvar id0);
        /// Variable Reference Static Builder.
        /// \wi{19809}
        /// Vref shall provide the capability to build a variable reference instance for a given real value.
        /// \param[in] value0   Real value for Type::kval variable type.
        /// \return Variable reference structure instance.
        static Vref build(Real value0);
        /// Variable Reference Static Builder.
        /// \wi{19810}
        /// Vref shall provide the capability to build a variable reference instance for given paremeters.
        /// \return Variable reference instance.
        /// \param[in] type0    Type of the variable.
        /// \param[in] id0      Variable identifier.
        /// \param[in] value0   Real value for variable type.
        /// \return Variable reference structure instance.
        static Vref build(Type type0,
                          Uint16 id0,
                          Real value0);

        /// Variable Reference Value Setter.
        /// \wi{4511}
        /// Vref structure shall provide the capability to set its internal variable reference value from its 
        /// internal type and identifier.
        void compute();

        /// Variable Reference Value Retriever.
        /// \wi{4512}
        /// Vref structure shall be able to retrieve its internal variable reference value from its internal type 
        /// and identifier.
        /// \return Internal variable reference value.
        Real kget() const;

        /// Variable Reference Unsigned 8-bits Retriever.
        /// \wi{19811}
        /// Vref structure shall be able to retrieve its internal variable reference value as Uint8.
        /// \return Internal variable reference value as Uint8.
        Uint8 as_uint8() const;
        /// Variable Reference Unsigned 16-bits Retriever.
        /// \wi{4873}
        /// Vref structure shall be able to retrieve its internal variable reference value as Uint16.
        /// \return Internal variable reference value as Uint16.
        Uint16 as_uint16() const;
        /// Variable Reference Unsigned 32-bits Retriever.
        /// \wi{19813}
        /// Vref structure shall be able to retrieve its internal variable reference value as Uint32.
        /// \return Internal variable reference value as Uint32.
        Uint32 as_uint32() const;

        /// Variable Reference Signed 16-bits Retriever.
        /// \wi{6493}
        /// Vref structure shall be able to retrieve its internal variable reference value as int16.
        /// \return Internal variable reference value as int16.
        int16 as_int16() const;
        /// Variable Reference Signed 32-bits Retriever.
        /// \wi{6494}
        /// Vref structure shall be able to retrieve its internal variable reference value as int32.
        /// \return Internal variable reference value as int32.
        int32 as_int32() const;

        /// Variable Reference Deserialization.
        /// \wi{4513}
        /// Vref structure shall provide the capability to deserialize the type, identifier and value.
        /// \param[in,out] str          Lossy which deserialize the data.
        void cset(Base::Lossy_error& str);

        /// Variable Reference Serialization.
        /// \wi{4510}
        /// Vref structure shall shall be able to serialize the type, identifier and value to a PDI.
        /// \param[out] str Lossy where serialize the data.
        void cget(Base::Lossy& str) const;
    };

    inline Vref Vref::build()
    {
        /// \alg
        /// - Return retrieved value by ::build with "none" type and identifier, with 0 value.
        return build(none, none,0);
    }

    inline Vref Vref::build(Rvar id0)
    {
        /// \alg
        /// - Return retrieved value by ::build with Type::rvar type, given identifier and 0 value.
        return build(rvar, id0, 0);
    }

    inline Vref Vref::build(Real value0)
    {
        /// \alg
        /// - Return retrieved value by ::build with Type::kval type, 0 identifier and given value.
        return build(kval, 0, value0);
    }

    inline Vref Vref::build(Type type0,
                            Uint16 id0,
                            Real value0)
    {
        /// \alg
        /// - Return variable reference with given type, identifier and value.
        Vref res = { {type0, id0}, value0 };
        return res;
    }

    inline void Vref::compute()
    {
        /// \alg
        /// - Set ::value by the retrieved value by ::kget.
        value = kget();
    }

    inline Uint8 Vref::as_uint8() const
    {
        /// \alg
        /// - Return static cast to unsigned integer 8-bits for ::value.
        return static_cast<Uint8>(value);
    }

    inline Uint16 Vref::as_uint16() const
    {
        /// \alg
        /// - Return static cast to unsigned integer 16-bits for ::value.
        return static_cast<Uint16>(value);
    }

    inline Uint32 Vref::as_uint32() const
    {
        /// \alg
        /// - Return static cast to unsigned integer 32-bits for ::value.
        return static_cast<Uint32>(value);
    }

    inline int16 Vref::as_int16() const
    {
        /// \alg
        /// - Return static cast to integer 16-bits for ::value.
        return static_cast<int16>(value);
    }

    inline int32 Vref::as_int32() const
    {
        /// \alg
        /// - Return static cast to integer 32-bits for ::value.
        return static_cast<int32>(value);
    }
}
#endif

