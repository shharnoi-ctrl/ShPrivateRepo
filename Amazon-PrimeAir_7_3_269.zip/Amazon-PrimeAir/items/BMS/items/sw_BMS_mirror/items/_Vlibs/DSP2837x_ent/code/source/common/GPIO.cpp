#include <GPIO.h>
#include <GPIOvalid.h>
#include <Assertions.h>
#include <Hregmap.h>
#include <Tnarray.h>

namespace Dsp28335_ent
{
    struct Gpio_data_regs //PRQA S 1701
    {
    public:
        Uint32 dat;                       // Data Register (1 bit groups)
        Uint32 set;                       // Data Set Register (1 bit groups)
        Uint32 clear;                     // Data Clear Register (1 bit groups)
        Uint32 toggle;                    // Data Toggle Register (1 bit groups)

        /// GPIO Get Data Registers.
        /// \wi{16972}
        /// GPIO class shall be able to retrieve associated registers for the specified GPIO id in a Gpio_data_regs structure.
        /// \param[in] id0  GPIO id to use.
        /// \return         The bank related to given id0.
        static volatile Gpio_data_regs& get_bank(GPIOid id0);

    private:
        Gpio_data_regs& operator=(const Gpio_data_regs& orig); ///< = delete
    };



    volatile Gpio_data_regs& Gpio_data_regs::get_bank(GPIOid id0)
    {
        static const Uint16 banks_gpio_shift = 5;
        static const Uint16 a2f_banks = 6;  // A to F banks
        Base::Assertions::Compile_time<(gpio_all <= (a2f_banks << banks_gpio_shift))>();

        Uint16 bank = id0 >> banks_gpio_shift;

        typedef Base::Tnarray<Gpio_data_regs, a2f_banks> Type_array_gpio_data_regs;
        static const Uint32 array_gpio_data_regs_addr = 0x007F00UL;
        static volatile Type_array_gpio_data_regs& array_gpio_data_regs =
                Hregmap::get<Type_array_gpio_data_regs, array_gpio_data_regs_addr>();

        return array_gpio_data_regs[bank];
    }


    GPIO::GPIO(GPIOid id0) :
            id(id0),
            dregs(Gpio_data_regs::get_bank(id)),
            mask1(static_cast<Uint32>(1)<<(id&Ku16::u0x1F))
    {
        Base::Assertions::runtime(is_gpioid_valid(id0));
        // note that sanitize call assumes that changing registers for missing GPIO169 has no effect.
    }

    void GPIO::set_hi()
    {
        dregs.set |= mask1;
    }

    void GPIO::set_lo()
    {
        dregs.clear |= mask1;
    }


    void GPIO::set(bool v)
    {
        if(v)
        {
            set_hi();
        }
        else
        {
            set_lo();
        }
    }

    void GPIO::toggle()
    {
        dregs.toggle |= mask1;
    }

    bool GPIO::get() const
    {
        return (dregs.dat&mask1) != 0;
    }
}
