#ifndef ICONNECT_RX_H_
#define ICONNECT_RX_H_

namespace Base
{
    /// Interface to manages RX communication for generic port
    class Iconnect_rx
    {
    public:
        /// Enable RX-side
        virtual void connect_rx(bool en) = 0;

    protected:
        Iconnect_rx();
        virtual ~Iconnect_rx();

    private:
        Iconnect_rx(const Iconnect_rx& orig);               ///< = delete
        Iconnect_rx& operator=(const Iconnect_rx& orig);    ///< = delete
    };

    inline Iconnect_rx::Iconnect_rx()
    {
    }

    inline Iconnect_rx::~Iconnect_rx() //PRQA S 2635 #destructor replaced with default
    {
    }
}

#endif
