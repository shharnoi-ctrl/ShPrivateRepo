#ifndef LOSSY_FW_H_
#define LOSSY_FW_H_
namespace Base
{
    class Lossy;
}
#endif
