#ifndef BITUTILS_H_
#define BITUTILS_H_

#include <Assertions.h>
#include <Vtraits.h>
#include <Ku16.h>
#include <Ku32.h>
#include <Ku64.h>

Uint8 get_u8_impl(void* ptr, Uint32 idx);
void  set_u8_impl(void* ptr, Uint32 idx, Uint8 v);

namespace Base
{
    /// The ::Base library shall provide a namespace for bit operations.
    namespace Bitutils
    {
        static const Uint16 bitset16_00 = Bitset<Uint16, Ku16::u0 >::value; ///< (0000000000000001) 16 bits mask.
        static const Uint16 bitset16_01 = Bitset<Uint16, Ku16::u1 >::value; ///< (0000000000000010) 16 bits mask.
        static const Uint16 bitset16_02 = Bitset<Uint16, Ku16::u2 >::value; ///< (0000000000000100) 16 bits mask.
        static const Uint16 bitset16_03 = Bitset<Uint16, Ku16::u3 >::value; ///< (0000000000001000) 16 bits mask.
        static const Uint16 bitset16_04 = Bitset<Uint16, Ku16::u4 >::value; ///< (0000000000010000) 16 bits mask.
        static const Uint16 bitset16_05 = Bitset<Uint16, Ku16::u5 >::value; ///< (0000000000100000) 16 bits mask.
        static const Uint16 bitset16_06 = Bitset<Uint16, Ku16::u6 >::value; ///< (0000000001000000) 16 bits mask.
        static const Uint16 bitset16_07 = Bitset<Uint16, Ku16::u7 >::value; ///< (0000000010000000) 16 bits mask.
        static const Uint16 bitset16_08 = Bitset<Uint16, Ku16::u8 >::value; ///< (0000000100000000) 16 bits mask.
        static const Uint16 bitset16_09 = Bitset<Uint16, Ku16::u9 >::value; ///< (0000001000000000) 16 bits mask.
        static const Uint16 bitset16_10 = Bitset<Uint16, Ku16::u10>::value; ///< (0000010000000000) 16 bits mask.
        static const Uint16 bitset16_11 = Bitset<Uint16, Ku16::u11>::value; ///< (0000100000000000) 16 bits mask.
        static const Uint16 bitset16_12 = Bitset<Uint16, Ku16::u12>::value; ///< (0001000000000000) 16 bits mask.
        static const Uint16 bitset16_13 = Bitset<Uint16, Ku16::u13>::value; ///< (0010000000000000) 16 bits mask.
        static const Uint16 bitset16_14 = Bitset<Uint16, Ku16::u14>::value; ///< (0100000000000000) 16 bits mask.
        static const Uint16 bitset16_15 = Bitset<Uint16, Ku16::u15>::value; ///< (1000000000000000) 16 bits mask.

        /// Bits to nibbles.
        /// \wi{17696}
        /// Bitutils shall provide the capability to retrieve the number of bytes needed to hold the
        /// specified number of bits.
        /// \param[in] nbits    Number of bits.
        /// \return             Number of nibbles needed to hold the specified bits.
        inline Uint16 bits_to_nibbles(Uint32 nbits)
        {
            return static_cast<Uint16>((nbits + Ku16::u3)>>Ku16::u2);
        }
        /// Bits to bytes.
        /// \wi{17697}
        /// Bitutils shall provide the capability to retrieve the number of bytes needed to hold the
        /// specified number of bits.
        /// \param[in] nbits    Number of bits.
        /// \return             Number of bytes needed to hold the specified bits.
        inline Uint16 bits_to_bytes(Uint32 nbits)
        {
            return static_cast<Uint16>((nbits + Ku16::u7)>>Ku16::u3);
        }

        /// Bytes to bits.
        /// \wi{17698}
        /// Bitutils shall provide the capability to retrieve the number of bits in the specified bytes.
        /// \param[in] nbytes   Number of bytes.
        /// \return             Number of equivalent bits.
        inline Uint16 bytes_to_bits(Uint32 nbytes)
        {
            return static_cast<Uint16>(nbytes << Ku16::u3);
        }

        /// Bits to 16 bits words.
        /// \wi{4909}
        /// Bitutils shall provide the capability to retrieve the number of 16 bits words needed to hold the
        /// specified number of bits.
        /// \param[in] nbits    Number of bits.
        /// \return             Number of words needed to hold the specified bits.
        inline Uint16 bits_to_words16(Uint32 nbits)
        {
            return static_cast<Uint16>((nbits+Ku32::u16-1) >> Ku32::u4);
        }

        /// Bytes to 16 bits words.
        /// \wi{17699}
        /// Bitutils shall provide the capability to retrieve the number of 16 bits words needed to hold the
        /// specified number of bytes.
        /// \param[in] nbytes   Number of bytes.
        /// \return             Number of words needed to hold the specified bytes.
        inline Uint32 bytes_to_words16(Uint32 nbytes)
        {
            return ((nbytes+1) >> Ku16::u1);
        }

        /// Bytes to 32 bits words.
        /// \wi{17700}
        /// Bitutils shall provide the capability to retrieve the number of 32 bits words needed to hold the
        /// specified number of bytes.
        /// \param[in] nbytes   Number of bytes.
        /// \return             Number of 32 bit words needed to hold the specified bytes.
        inline Uint32 bytes_to_words32(Uint32 nbytes)
        {
            return ((nbytes+Ku16::u3) >> Ku16::u2);
        }

        /// 16 bit words to bytes.
        /// \wi{17701}
        /// Bitutils shall provide the capability to retrieve the number of bytes needed to hold the specified
        /// number of 16 bit words.
        /// \param[in] nwords16     Number of 16 bit words.
        /// \return                 Number of bytes needed to hold the specified 16 bit words.
        inline Uint32 words16_to_bytes(Uint32 nwords16)
        {
            return (nwords16 << Ku16::u1);
        }

        /// 16 bit words to bits.
        /// \wi{17702}
        /// Bitutils shall provide the capability to retrieve the number of bits needed to hold the specified
        /// number of 16 bit words.
        /// \param[in] nwords16     Number of 16 bit words.
        /// \return                 Number of bits needed to hold the specified 16 bit words.
        inline Uint32 words16_to_bits(Uint32 nwords16)
        {
            return (nwords16 << Ku16::u4);
        }

        extern const Uint16 mask16[Ku16::u17];  ///< Array with 16 bits masks.

        /// LSB mask getter.
        /// \wi{17703}
        /// Bitutils shall provide the capability to retrieve a LSB aligned mask with the specified
        /// number of bits to set.
        /// \param[in] nbits    Number of bits to set in the mask.
        /// \return             Computed mask with specified number of bits.
        template<typename T>
        inline T get_mask_lsb(Uint16 nbits)
        {
            return (nbits >= Sizeof_bits<T>::value) ?
                    Lsbmask<T, Sizeof_bits<T>::value>::value : // all bits set
                    ((static_cast<T>(1) << nbits) - 1);
        }

        /// Defines max value representable for an unsigned integer of given number of bits in size.
        template <typename T, Uint16 nbits>
        struct get_mask_lsb_t
        {
            static const typename Enable_if<nbits <= Sizeof_bits<T>::value, T>::type value =
                    static_cast<T>(Ku64::u_max >> (Ku16::u64-nbits));
        };

        /// Defines max value representable for an unsigned integer of given number of bytes in size.
        template <typename T, Uint16 nbytes>
        struct get_mask_t
        {
            static const T value = get_mask_lsb_t<T, bytes_to_bits_c<nbytes>::value >::value;
        };

        /// LSB mask getter.
        /// \wi{17704}
        /// Bitutils shall provide the capability to retrieve a LSB aligned mask with the specified
        /// number of bits and with the first bit to set.
        /// \param[in] bit_from     First bit to be set (least significant is bit zero).
        /// \param[in] bit_num      Number of bits to be set.
        /// \return                 Computed mask with the specified parameters.
        template<typename T>
        inline T get_mask_lsb(Uint16 bit_from, Uint16 bit_num)
        {
            return (get_mask_lsb<T>(bit_num) << bit_from);
        }

        /// 32 bit mask getter.
        /// \wi{4910}
        /// Bitutils shall provide the capability to retrieve a mask of 32 bits with the specified number of bits set.
        /// \param[in] nbits        Number of bits to set.
        /// \return                 Computed mask with the specified parameter.
        inline Uint32 get_mask32(Uint16 nbits)
        {
            return get_mask_lsb<Uint32>(nbits);
        }

        /// 1 bit mask getter.
        /// \wi{4911}
        /// Bitutils shall provide the capability to retrieve a mask with one bit set in the specified position.
        /// \param[in] idx          Index of the bit in the mask to set.
        /// \return                 Computed mask.
        template <typename T>
        inline T get_mask_1bit(Uint16 idx)
        {
            return static_cast<T>(1)<<idx;
        }

        template <typename T, Uint16 idx>
        struct get_mask_1bit_c
        {
            static const T value = static_cast<T>(1U) << idx;
        };

        /// Statically computes number of bits needed to contain a given number
        template <Uint32 number>
        struct Bits_to_contain
        {
            static const Uint32 value = Bits_to_contain<(number&1)>::value + Bits_to_contain<(number>>1)>::value;
        };

        template<>
        struct Bits_to_contain<1>
        {
            static const Uint32 value = 1;
        };

        template<>
        struct Bits_to_contain<0>
        {
            static const Uint32 value = 1;
        };

        /// Reflect8.
        /// \wi{4905}
        /// Bitutils shall provide the capability to reflect a byte.
        /// \param[in] word     Byte to reflect.
        /// \return             Reflected value.
        Uint16 reflect8(Uint16 word);
        /// Reflect16.
        /// \wi{4906}
        /// Bitutils shall provide the capability to reflect a 16 bit word.
        /// \param[in] word     16 bit word to reflect.
        /// \return             Reflected value.
        Uint16 reflect16(Uint16 word);
        /// Reflect32.
        /// \wi{4907}
        /// Bitutils shall provide the capability to reflect a 32 bit word.
        /// \param[in] word     32 bit word to reflect.
        /// \return             Reflected value.
        Uint32 reflect32(Uint32 word);
        /// Reflect bits.
        /// \wi{4908}
        /// Bitutils shall provide the capability to reflect a specified number of bits.
        /// \param[in] word     32 bit word to reflect.
        /// \param[in] n        Number of bits to reflect.
        /// \return             Reflected value.
        Uint32 reflectn(Uint32 word, Uint16 n);

        /// Read.
        /// \wi{17705}
        /// Bitutils shall provide the capability to read a value in a mask with a specified offset and width.
        /// \param[in] reg  Value to read.
        /// \return         Read value.
        template <typename T, Uint16 offset, Uint16 width>
        inline T read(const T& reg)
        {
            return (reg & Base::Mask<T, offset, width>::value) >> offset;
        }

        /// Write.
        /// \wi{17706}
        /// Bitutils shall provide the capability to write a value in a mask with a specified offset and width.
        /// \param[out] reg     Masked value.
        /// \param[in] value    Value to write.
        template <typename T, Uint16 offset, Uint16 width>
        inline void write(T& reg, T value)
        {
            reg = (reg & ~Base::Mask<T,offset,width>::value)|((value<<offset) & Base::Mask<T, offset, width>::value);
        }

        /// Mask Match.
        /// \wi{4912}
        /// Bitutils shall provide the capability to check if two values match with a provided mask.
        /// \param[in] mask     Mask to compare both values.
        /// \param[in] v1       Value to check.
        /// \param[in] v2       Value to check.
        /// \return             True if both values math with the given mask.
        template <typename T>
        inline bool maskmatch(typename JSF116_param<T>::type Mask,
                              typename JSF116_param<T>::type v1,
                              typename JSF116_param<T>::type v2)
        {
            return (Mask&v1) == (Mask&v2);
        }

        /// LSBset Index Getter.
        /// \wi{5921}
        /// Bitutils shall provide the capability to retrieve the index of the least significant bit enabled in the
        /// given mask.
        /// \param[in]  value    Value to evaluate. Assumed to be different from zero.
        /// \param[out] idx      Index of least significant bit enabled.
        void get_lsbset_idx(Uint16 value, Uint16& idx);
        /// LSBset Index Getter.
        /// \wi{17707}
        /// Bitutils shall provide the capability to retrieve the index of the least significant bit enabled in the
        /// given mask.
        /// \param[in]  value    Value to evaluate. Assumed to be different from zero.
        /// \param[out] idx      Index of least significant bit enabled.
        void get_lsbset_idx(Uint32 value, Uint16& idx);

        static const Uint8 n_byte_bits = 8; ///< Number of bits for a byte.
        /// High part of Uint16 getter.
        /// \wi{17708}
        /// Bitutils shall provide the capability to retrieve the high byte of a Uint16.
        /// \param[in] v    Value to get the high byte.
        /// \return         High byte for the specified value.
        inline Uint8 get_u16_h(Uint16 v)
        {
            return static_cast<Uint8>(v >> n_byte_bits);
        }

        static const Uint16 msk8_bits = 0x00FF;
        /// Low part of Uint16 getter.
        /// \wi{17709}
        /// Bitutils shall provide the capability to retrieve the low byte of a Uint16.
        /// \param[in] v    Value to get the low byte.
        /// \return         Low byte for the specified value.
        inline Uint8 get_u16_l(Uint16 v)
        {
            return static_cast<Uint8>(v & msk8_bits);
        }

        /// Uint16 getter.
        /// \wi{6118}
        /// Bitutils shall provide the capability to build a 16 bit unsigned from two 8 bit unsigned values.
        /// \param[in] h    High byte.
        /// \param[in] l    Low byte.
        /// \return         Built 16 bit unsigned.
        inline Uint16 get_u16(Uint8 h, Uint8 l)
        {
            return (static_cast<Uint16>(h) << n_byte_bits) | (static_cast<Uint16>(l) & msk8_bits);
        }

        /// Uint16 setter.
        /// \wi{17710}
        /// Bitutils shall provide the capability to set a Uint16 in a relative position (as word of 16bits)
        /// and retrieve it.
        /// \param[in]  value   Value to be set.
        /// \param[in]  pos     Position (as word) where set the value.
        /// \param[out] ret     Return value with the computed word.
        void set_uint16(Uint16 value, Uint16 pos, Uint64& ret);
        /// Uint16 from Uint64 getter.
        /// \wi{17711}
        /// When requested, get_uint16 shall retrieve an Uint16 from a Uint64 in a given position.
        /// \param[in] data     Value being read.
        /// \param[in] pos      Position (as word16) where get the value.
        /// \return             The Uint16 in the given position of a given Uint64.
        inline Uint16 get_uint16(const Uint64& data, Uint16 pos)
        {
            Uint16 displ = pos * Sizeof_bits<Uint16>::value;
            return static_cast<Uint16>(data >> displ);
        }

        static const Uint32 msk16_bits = 0x0000FFFF;    ///< 16 bits mask.
        static const Uint16 n_bits_shif = 16U;          ///< 16 bits to shift.
        /// High part of Uint32 getter.
        /// \wi{17712}
        /// Bitutils shall provide the capability to retrieve the high part of a given Uint32.
        /// \param[in] value    Uint32 value to spit.
        /// \return             High part for the given value.
        inline Uint16 get_u32_h(Uint32 value)
        {
            return static_cast<Uint16>(value >> n_bits_shif);
        }

        /// Low part of Uint32 getter.
        /// \wi{17713}
        /// Bitutils shall provide the capability to retrieve the low part of a given Uint32.
        /// \param[in] value    Uint32 value to spit.
        /// \return             Low part for the given value.
        inline Uint16 get_u32_l(Uint32 value)
        {
            return static_cast<Uint16>(value & msk16_bits);
        }

        /// Uint32 getter.
        /// \wi{17714}
        /// Bitutils shall provide the capability to build a 32 bit unsigned from two 16 bit unsigned values.
        /// \param[in] h    High part.
        /// \param[in] l    Low part.
        /// \return         Built 32 bit unsigned.
        inline Uint32 get_u32(Uint16 h, Uint16 l)
        {
            return (static_cast<Uint32>(h) << n_bits_shif) | (static_cast<Uint32>(l) & msk16_bits);
        }

        /// 16-bit word swap bytes.
        /// \wi{17715}
        /// Bitutils shall provide the capability to swap the bytes in a 16 bit word.
        /// \param[in] v    Value to swap.
        /// \return         Computed 16 bit word with the bytes swap.
        inline Uint16 swap_bytes(Uint16 v)
        {
            return (v << n_byte_bits) | (msk8_bits & (v >> n_byte_bits));
        }

        /// Pointed byte getter.
        /// \wi{17716}
        /// Bitutils shall provide the capability to the byte pointed by a pointer with the specified index.
        /// \param[in] ptr      Pointer.
        /// \param[in] idx      Index of byte to retrieve.
        /// \return             Byte pointed by ptr
        template<typename T>
        inline Uint8 get_u8(const T* ptr, Uint32 idx)
        {
            //PRQA S 3080 #Can't apply a cast because of a compiler intrinsic function call
            return get_u8_impl(reinterpret_cast<int16*>(const_cast<typename Remove_volatile<typename Remove_const<T>::type>::type*>(ptr)), idx);
        }

        /// Pointed byte setter.
        /// \wi{17717}
        /// Bitutils shall provide the capability to set the the byte with a specified index
        /// pointed by the given pointer.
        /// \param[out] ptr     Pointer value.
        /// \param[in]  idx     Index of byte to set the pointer.
        /// \param[in]  v       Byte value to set.
        template<typename T>
        inline void set_u8(T* ptr, Uint32 idx, Uint8 v)
        {
            //PRQA S 3080 #Can't apply a cast because of a compiler intrinsic function call
            set_u8_impl(reinterpret_cast<int16*>(const_cast<typename Remove_volatile<T>::type*>(ptr)), idx, v);
        }

        /// Only one bit is set.
        /// \wi{17718}
        /// Bitutils shall provide the capability to check if only one bit is set in a given mask.
        /// \param[in] n    Mask value.
        /// \return         True if only one bit is in the mask is high.
        inline bool check_only_one_bit_set(Uint32 n)
        {
            return ((n & (n-1)) == 0);
        }

        /// Data Decodification.
        /// \wi{20138}
        /// Bitutils shall provide the capability to decode a value inside a word with a given bit range.
        /// \param[in] data Data which will be decoded.
        /// \return Decoded value.
        template<typename T, Uint32 x0, Uint32 x1>
        inline T get_decoded_value(const Uint32 data)
        {
            /// \alg
            /// - Perform a bitwise left shift operation as \f$ res = (data << (31 - x1)) \f$.
            const Uint16 despl = 31U;
            T res = (data << (despl - x1));
            /// - Perform a bitwise right shift operation as \f$ res >>= (31 - (x1 - x0)) \f$.
            res >>= (despl - (x1 - x0));
            /// - Return decoded data.
            return res;
        }
    }
}
#endif
