#ifndef HFVAR_H_
#define HFVAR_H_

#include <Fid.h>
#include <Dsync.h>

namespace Base
{
    struct Feature;
}

namespace Bsp
{

    /// System feature handler.
    /// The Bsp library shall provide a class to read and publish system features (absolue or relative positions).
    class Hfvar
    {
    public:
        /// System feature handler constructor.
        /// \wi{14208}
        /// The Hfvar class shall be constructable by passing the feature identifier (Base::Fid) that the instance
        /// shall manage.
        /// \param[in] id0 Feature identifier to manage.
        explicit Hfvar(Base::Fid id0);

        /// System feature handler constant setter.
        /// \wi{14209}
        /// The Hfvar class shall provide a method to set the value of the handled system feature passing a constant
        /// reference to the feature value to set.
        /// \param[in] v0 Value to be set.
        void set(const Base::Feature& v0); //PRQA S 4211 const

        /// System feature handler constant volatile setter.
        /// \wi{14210}
        /// The Hfvar class shall provide a method to set the value of the handled system feature passing a constant
        /// volatile reference to the feature value to set.
        /// \param[in] v0 Value to be set.
        void set(const volatile Base::Feature& v0); //PRQA S 4211 const

        /// System feature handler getter.
        /// \wi{14211}
        /// The Hfvar class shall provide a method to get the value of the handled system feature.
        /// \param[out] f0 Reference where the read feature shall be stored.
        /// \return Synchronization value to detect updates in the feature.
        Base::Dsync::Reader get(Base::Feature& f0) const;

        /// System feature handler identifier getter.
        /// \wi{14212}
        /// The Hfvar class shall provide a method to obtain the handled feature identifier.
        /// \return Handled feature identifier.
        Base::Fid get_id() const;

    private:
        const Base::Fid id;  ///< Handled feature identifier.

        Hfvar(); ///< = delete
        Hfvar(const Hfvar& orig); ///< = delete
        Hfvar& operator=(const Hfvar& orig); ///< = delete
    };


    inline Hfvar::Hfvar(Base::Fid id0) : id(Base::Jfid::validate(id0))
    {
    }

    inline void Hfvar::set(const volatile Base::Feature& v0)
    {
        set(const_cast<const Base::Feature&>(v0));
    }

    inline Base::Fid Hfvar::get_id() const
    {
        return id;
    }
}
#endif
