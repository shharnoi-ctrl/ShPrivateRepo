#ifndef WRAPPER_H_
#define WRAPPER_H_

#include <Entypes.h>
#include <Rfun.h>

#include <Lossy_error_fw.h>
#include <Lossy_fw.h>

namespace Maverick
{
    /// Wrapper.
    /// The Maverick library shall provide a class to bound the value of a real variable between configurable
    /// minimum and maximum limits.
    class Wrapper
    {
    public:
        /// Wrapper constructor.
        /// \wi{3109}
        /// The Wrapper class shall be constructable without parameters, being initialized without any limits enabled.
        Wrapper();

        /// Wrapper computation.
        /// \wi{3112}
        /// The Wrapper class shall provide a method that wraps (bounds) the value of the passed parameter.
        /// \param[in,out] v Value to apply bounds to, the result is applied directly in the variable.
        /// \return True if the value was modified (bounded) false if the value was within the allowed limits.
        bool wrap(Real& v) const;

        /// Wrapper minimum limit getter.
        /// \wi{3114}
        /// The Wrapper class shall provide a method to obtain the minimum limit.
        /// \return The minimum limit.
        Real get_min() const;

        /// Wrapper maximum limit getter.
        /// \wi{3113}
        /// The Wrapper class shall provide a method to obtain the maximum limit.
        /// \return The maximum limit.
        Real get_max() const;

        /// Wrapper deserialization.
        /// \wi{3111}
        /// The Wrapper class shall be deserializable from its PDIC.
        /// \param[in,out] str Buffer to deserialize.
        void cset(Base::Lossy_error& str);

        /// Wrapper serialization.
        /// \wi{19119}
        /// The Wrapper class shall be serializable to its PDIC. See format in ::cset.
        /// \param[in,out] str Buffer where to serialize.
        void cget(Base::Lossy& str) const;

    private:
        Real min;                                ///< Effective minimum
        Real max;                                ///< Effective maximum
        Real cmin;                               ///< Configured minimum
        Real cmax;                               ///< Configured maximum
        Wrapper(const Wrapper& orig);            ///< = delete
        Wrapper& operator=(const Wrapper& orig); ///< = delete
    };

    inline bool Wrapper::wrap(Real& v) const
    {
        return Rfun::wrap(min,max,v,v);
    }

    inline Real Wrapper::get_min()const
    {
        return min;
    }

    inline Real Wrapper::get_max()const
    {
        return max;
    }
}
#endif

