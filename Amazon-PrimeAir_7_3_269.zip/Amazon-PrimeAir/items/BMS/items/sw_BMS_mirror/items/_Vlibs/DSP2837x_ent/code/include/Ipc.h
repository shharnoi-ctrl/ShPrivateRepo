#ifndef IPC_H_
#define IPC_H_

#include <Ipc_regs.h>
#include <Isrptr.h>

namespace Dsp28335_ent
{
    /// Inter Process Communications. Direct CPU1 to CPU2 and CPU2 to CPU1 signaling.
    struct Ipc
    {
    public:
        /// To be used only by CPU1, handles normal path CPU2 boot.
        void cpu1_boot_cpu2();

        /// Releases CPU1 to start after CPU has finished all the initialization steps.
        /// To be used only by CPU2.
        void cpu1_unlock();

        /// Returns true if the CPU 1 is locked.
        static bool is_cpu1_locked();

        /// Forces CPU1 to wait for cpu2_unlock() to be called by CPU2.
        /// To be used only by CPU1
        static void cpu1_wait_for_unlock();

        /// Releases CPU2 to start after CPU has finished all the initialization steps.
        /// To be used only by CPU1.
        void cpu2_unlock();

        /// Returns true if the CPU 2 is locked.
        static bool is_cpu2_locked();

        /// Forces CPU2 to wait for cpu2_unlock() to be called by CPU1.
        /// To be used only by CPU2
        static void cpu2_wait_for_unlock();

        /// To be used only by CPU1, requests reset to CPU2.
        void send_reset_request_1to2_blocking();

        /// \return True if reset has been requested to CPU2.
        bool is_reset_request() const;

        /// To be used only by CPU2, confirms to CPU1 that reset
        /// request has been read and global reset can be applied.
        void send_ack_reset_request_2to1();

        /// Function interface for remote calls
        typedef void (*Cpu2_start_func)();

        /// Executes a remote call in CPU2.
        /// \param func Function to be executed by CPU2, it must be in a accessible memory zone by CPU2 with FETCH
        ///             (execution) access protection enabled.
        /// \param data Parameters to pass to the function.
        Uint32 cpu2_ipc_remote_call(Cpu2_start_func func, Uint32 data);

        /// Retrieve the IPC parameter from the invoker core
        static Uint32 cpu2_get_ipc_param();

        /// Sets the IPC result
        static void cpu2_set_ipc_result(Uint32 res);

        /// Reset C1 to C2 flags after C2 unlocking
        void reset_flags();

        /// Set flag for the othe core to the given value.
        /// \param flag  Flag index.
        /// \param value Value to set.
        void set_flag(Uint8 flag, bool value);

        /// Set an interrupt handler.
        /// \param isr_num Interrupt to be handled. [0,1]
        /// \param p_isr   Handler function.
        static void set_isr(const Uint16 isr_num, Isrptr p_isr);

        /// Clear interrupt flag.
        /// \param isr_num Interrupt to clear.
        static void clear_irq_flags(const Uint16 isr_num);

        /// \return Single unique instance of IPC handler.
        static Ipc& get_instance();

    private:
        enum Reset_command              ///< Reset commands
        {
            rst_halt_request = 0xFF5A,  ///< Halt request for CPU2
            rst_halt_ack     = 0xFFA5   ///< Halt request ack from CPU2
        };

        volatile Ipc_regs& regs;    ///< IPC registers.

        /// Default unique constructor.
        Ipc();

        Ipc(const Ipc& orig); ///< = delete
        Ipc& operator=(const Ipc& orig); ///< = delete

        /// Executes a remote call in CPU2.
        /// \param func Function to be executed by CPU2, it must be in a accessible memory zone by CPU2 with FETCH
        ///             (execution) access protection enabled.
        /// \param data Parameters to pass to the function.
        Uint32 cpu2_ipc_remote_call0(Cpu2_start_func func, Uint32 data);
    };
}
#endif
