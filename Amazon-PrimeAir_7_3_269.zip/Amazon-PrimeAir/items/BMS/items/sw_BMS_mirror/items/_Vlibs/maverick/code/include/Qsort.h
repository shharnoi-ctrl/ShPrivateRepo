#ifndef QSORT_H_
#define QSORT_H_

#include <Mblock.h>
#include <Rfun.h>

namespace Maverick
{
    /// Array quick sort with templates parameters defined as:
    /// - ARRAY for array to store that shall define [] operator and size() method.
    /// - TYPE for array type, by default from ARRAY::type.
    template <typename ARRAY, typename TYPE = typename ARRAY::type>
    struct Qsort
    {
    public:
        typedef Base::Mblock<int16> STACK;
        /// Destructive quick sort.
        /// \wi{20414}
        /// Qsort structure shall provide a method to sort an array of values.
        /// \param[in] mb0  Memory block to sort.
        static void sort(ARRAY& arr, STACK& stk);

    private:
        /// Order sub-array.
        /// \wi{20415}
        /// Qsort structure shall provide a method to order provided array.
        /// \param[in,ou] arr   Entire array.
        /// \param[in] low_idx  Low index of the sub-array.
        /// \param[in] high_idx High index of the sub-array.
        /// \return Pivot index.
        static int16 part(ARRAY& arr, int16 low_idx, int16 high_idx);

        Qsort(); ///< = delete
        Qsort(const Qsort& orig); ///< = delete
        Qsort& operator=(const Qsort& orig); ///< = delete
    };

    template <typename ARRAY, typename TYPE>
    int16 Qsort<ARRAY, TYPE>::part(ARRAY& arr, int16 low_idx, int16 high_idx)
    {
        /// \alg
        /// <ul>

        /// <li> Keep track of indice of element to pivot within ::arr, initialized with previous index from ::low_idx.
        int16 pivot_idx = low_idx - Ku16::u1;

        /// <li> For each element of :arr between ::low_idx and ::high_idx indices:
        for(Uint16 i = low_idx; i < high_idx; i++)
        {
            /// <ul>
            /// <li> If current element value is less or equals to the one to pivot:
            if(arr[i] <= arr[high_idx])
            {
                /// <ul>
                /// <li> Increment the pivot index and swap it with current element.
                Rfun::swap(arr[++pivot_idx], arr[i]);
                /// </ul>
            }
            /// </ul>
        }

        /// <li> Increment pivot index and swap it with the one from high_idx.
        Rfun::swap(arr[++pivot_idx], arr[high_idx]);

        /// <li> Finally, return pivot index.
        return pivot_idx;
    }

    template <typename ARRAY, typename TYPE>
    void Qsort<ARRAY, TYPE>::sort(ARRAY& arr, STACK& stk)
    {
        /// \alg
        /// <ul>
        /// <li> Retrieve provided ::arr size by calling its ::size() method.
        const Uint16 total_sz = arr.size();
        /// <li> If total size is strictly greater than one, and provided ::stk size is greater or equals:
        if(Base::Assertions::runtime((total_sz > Ku16::u1) && (stk.size() >= total_sz)))
        {
            /// <ul>
            /// <li>  Initialize low index to zero and high to last index from provided ::arr.
            int16 low_idx = 0;
            int16 high_idx = total_sz - Ku16::u1;

            /// <li> Keep track of stack by instantiating a pointer variable to its top, currently its second element.
            int16 top_ptr = -Ku16::u1;

            /// <li> Push first ::low_idx and then ::high_index on the stack.
            stk[++top_ptr] = low_idx;
            stk[++top_ptr] = high_idx;

            /// <li> As long as top pointer is within stack:
            while(top_ptr >= 0)
            {
                /// <ul>
                /// <li> Pop first high and then low indices from the stack using top pointer.
                high_idx = stk[top_ptr--];
                low_idx = stk[top_ptr--];

                /// <li> Call part method to order array from low_idx to high_idx and retrieve pivot index.
                Uint16 pivot_idx = part(arr, low_idx, high_idx);

                /// <li> If there are elements on the left of the pivot:
                if(pivot_idx > (low_idx + 1))
                {
                    /// <ul>
                    stk[++top_ptr] = low_idx;                 /// <li> Push ::low_idx
                    stk[++top_ptr] = pivot_idx - Ku16::u1;    /// <li> Push index of previous element to pivot.
                    /// </ul>
                }

                /// <li> If there are elements on the right of the pivot:
                if ((pivot_idx) < high_idx)
                {
                    /// <ul>
                    stk[++top_ptr] = pivot_idx + Ku16::u1;    /// <li> Push index of element next to pivot.
                    stk[++top_ptr] = high_idx;                /// <li> Push ::high_idx.
                    /// </ul>
                }
                /// </ul>
            }
            /// </ul>
        }
        /// </ul>
    }
}

#endif
