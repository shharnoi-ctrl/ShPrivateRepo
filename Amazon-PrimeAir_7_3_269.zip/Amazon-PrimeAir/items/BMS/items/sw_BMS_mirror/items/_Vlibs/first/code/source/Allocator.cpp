#include <Allocator.h>
#include <Mblock.h>

namespace Base
{

    Allocator::Allocator(Mblock<Uint16>& mem) : alloc_buffer(&mem[0], mem.size())
    {
    }

    Allocator::Allocator_buffer::Allocator_buffer(Uint16* pbuf0, Uint32 size0) :
            pbuf(pbuf0),
            size(size0),
            idx(0),
            st(open)
    {
        // Ensure that ::pbuf is aligned to 2Word boundary
        Assertions::runtime((reinterpret_cast<Uint32>(pbuf) & 1U) == 0);
    }

    void* Allocator::Allocator_buffer::allocate(Uint32 n_elements, Uint32 element_size)
    {
        /// \alg
        /// <ul>
        Base::Assertions::Compile_time<(sizeof(void*)==(sizeof(size_t)))>();

        /// <li> Align ::idx to required pointer boundary.
        static const Uint8 align_to = 2; // 2 words -> 4 bytes
        const Uint8 idx_msk = (idx & (align_to-1));
        if( idx_msk != 0)
        {
            idx += align_to - idx_msk;
        }
        /// <li> Compute next memory pointer as ::pbuf + ::idx.
        void* mem_pos = static_cast<void*>(pbuf+idx);

        /// <li> Update ::idx with data to be allocated using the number of elements to be allocated and those
        /// element sizes.
        idx += ((n_elements*element_size) + sizeof(Uint16) - 1U)/sizeof(Uint16);

        /// <li> IF any of the following conditions is evaluated to TRUE, set the allocator state (::st) to Error
        /// (State::error):
        /// <ul>
        /// <li> The allocator buffer is closed (::st == State::closed).
        /// <li> Next memory position (::idx) is out of allocator bounds (::size).
        /// <li> Number of elements requested to be allocated is higher than allowed Allocator size (::size).
        /// <li> Element size requested to be allocated is bigger than allowed Allocator size (::size).
        /// </ul>
        // Checks in n_elements and element_size have been added to prevent overflow of idx when by mistake
        // they are very big due to a negative number casted to unsigned
        if ((st == closed) || (idx > size) || (n_elements > size) || (element_size > size))
        {
            st = error;
        }
        /// <li> Return next memory pointer already computed if ::st is equals to State::open, else return 0.
        return Base::Assertions::runtime(st == open) ? mem_pos : 0;
        /// </ul>
    }

    void* Allocator::allocate_one(Uint32 element_size)
    {
        return alloc_buffer.allocate(1U, element_size);
    }
}
