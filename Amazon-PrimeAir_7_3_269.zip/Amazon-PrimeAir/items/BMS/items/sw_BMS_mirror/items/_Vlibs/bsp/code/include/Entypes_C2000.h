#ifndef ENTYPES_C2000_H__
#define ENTYPES_C2000_H__

#include <stdint.h>

// Note: Texas instruments does not not define in stdint uint8_t nor int8_t, that's why
// both are defined without reference a type defined by stdint.

#ifndef __TMS320C2000__
#error "This Entypes are only for C2000 devices."
#endif

//PRQA S 2300 EOF
//PRQA S 2400 EOF # Global types declared in global namespace.
typedef float               Real;
typedef long double         Real64;
typedef char                int8;
typedef int16_t             int16;
typedef int32_t             int32;
typedef int64_t             int64;
typedef unsigned char       Uint8;
typedef uint16_t            Uint16;
typedef uint32_t            Uint32;
typedef uint64_t            Uint64;


typedef Uint16 NWord;       ///< Native word for Veronte4

typedef Uint16 JSF119_word; ///< Native word for current architecture. Used for JSF 119 rule

static const void* nullptr = 0;

// Return the size of a a given type in bytes. this is the desired size, not the underlying size returned by sizeof.
template<typename T>
struct size_bytes_t
{
    static const Uint32 value = sizeof(T) << 1; // sizeof(uint16) returns 1, so we must multiply by 2
};

template<>
struct size_bytes_t<Uint8>
{
    static const Uint32 value = 1;
};

template<>
struct size_bytes_t<int8>
{
    static const Uint32 value = 1;
};

template<typename T>
inline Uint32 size_bytes(T)
{
    return size_bytes_t<T>::value;
};

/// Retrieves the "idx"-nth byte pointed by ptr
inline Uint8 get_u8_impl(void* ptr, Uint32 idx)
{
    return __byte(reinterpret_cast<int16*>(ptr), idx);
}

/// Sets the "idx"-nth byte pointed by ptr
inline void set_u8_impl(void* ptr, Uint32 idx, Uint8 v)
{
    __byte(reinterpret_cast<int16*>(ptr), idx) = v;
}
#endif
