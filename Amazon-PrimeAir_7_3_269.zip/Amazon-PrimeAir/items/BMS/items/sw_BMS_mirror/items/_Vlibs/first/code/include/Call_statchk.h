#ifndef CALLSTATCHK_H_
#define CALLSTATCHK_H_

#include <Call_stat.h>
#include <Const.h>

namespace Base
{
    /// Call_stat Checker
    /// Checks the rate of calling "call" to be not less than desired_rate and updates
    /// a given boolean.
    class Call_statchk
    {
    public:
        /// Call_statchk Constructor.
        /// \wi{5719}
        /// Call_statchk class shall build itself upon construction and initialize its internal members.
        /// \param[out] bit         Boolean to be updated with the status.
        /// \param[in] desired_rate Desired call rate.
        /// \param[in] check_tout   Period to wait between checks.
        Call_statchk(volatile bool& bit,
                     Real desired_rate,
                     Real check_tout);

        /// Call_statchk Desired Rate Setter.
        /// \wi{5720}
        /// Call_statchk class shall provide the capability to set the desired rate (::desired_rate).
        /// \param[in] desired_rate  Desired rate.
        void set_desired_rate(Real desired_rate);
        /// Call_statchk Desired Rate Getter.
        /// \wi{5721}
        /// Call_statchk class shall provide the capability to retrieve its desired rate (::desired_rate).
        /// \return     Desired rate.
        Real get_desired_rate() const;

        /// Call_statchk Rate Getter.
        /// \wi{16973}
        /// Call_statchk class shall provide the capability to retrieve its rate.
        /// \return     Get actual rate.
        Real get_rate();

        /// Call_statchk Ready Setter.
        /// \wi{5742}
        /// Call_statchk class shall provide the capability to set if device is ready to compute BIT.
        /// \param[in] ready    Flag to set if the device is ready.
        /// \param[in] n_steps  Number of intervals at the configured frequency.
        void set_ready(bool ready,Real n_steps= Const::ZERO);
        /// Call_statchk Ready Checker.
        /// \wi{5743}
        /// Call_statchk class shall provide the capability to retrieve if device is ready to compute BIT.
        /// \return     True if device is ready to compute BIT.
        bool is_ready() const;
        /// Call_statck Stepper.
        /// \wi{5722}
        /// Call_statchk class shall provide the capability to on each check iteration, update the check value
        /// comparing the desired frequency with the current frequency.
        void step();
        /// Call_statck Call.
        /// \wi{5724}
        /// Call_statchk class shall provide the capability to increase the number of calls since last check.
        void call();
        /// Call_statck Get Bit.
        /// \wi{5726}
        /// Call_statchk class shall provide the capability to the get the bit (::bit).
        /// \return     Status bit.
        bool get_bit() const;
        /// Call_statck Reset.
        /// \wi{5728}
        /// Call_statchk class shall provide the capability to its counter to start measuring again.
        void reset();

    private:
        Call_statchk(); ///< = delete
        Call_statchk(const Call_statchk&); ///< = delete
        Call_statchk& operator=(const Call_statchk&); ///< = delete

        volatile bool& bit;     ///< Bit reference.
        Real desired_rate;      ///< Desired call rate.
        Base::Call_stat callst; ///< Internal Call stats.
        bool status_ready;      ///< Indicates that the device has been initialized after power on.
    };

    inline void Call_statchk::set_desired_rate(Real desired_rate0)
    {
        desired_rate = desired_rate0;
    }

    inline Real Call_statchk::get_desired_rate() const
    {
        return desired_rate;
    }

    inline Real Call_statchk::get_rate()
    {
        return callst.get_calls_sec();
    }

    inline void Call_statchk::call()
    {
        callst.call();
    }

    inline bool Call_statchk::get_bit() const
    {
        return bit;
    }
    inline void Call_statchk::set_ready(bool ready, Real n_steps)
    {
        //Restart callst on status_ready first change to true.
        if ((!status_ready) && ready)
        {
            //Avoid n_steps in first frequency computation.
            callst.reset(-n_steps/desired_rate);
        }
        status_ready = ready;
    }
    inline bool Call_statchk::is_ready() const
    {
        return status_ready;
    }
    
    inline void Call_statchk::reset()
    {
        callst.reset(Const::ZERO);
    }
}
#endif
