// FIXME JSF133
#ifndef TARRAY_H__
#define TARRAY_H__

#include <Array.h>

namespace Maverick
{
    /// Tarray.
    /// The ::Maverick library shall provide the capability to deal with Base::Array. 
    template <class T>
    class Tarray: public Base::Array<T>
    {
    public:
        /// Tarray Constructor with Given Parameters.
        /// \wi{3259}
        /// Tarray class shall build itself upon construction with a memory block buffer.
        /// \param[in] mb       Memory block.
        template <typename T2>
        explicit Tarray(Base::Mblock<T2> mb);

        /// Tarray Constructor with Given Parameters.
        /// \wi{3260}
        /// Tarray class shall build itself upon construction with first array element and specific numbers of elements.
        /// \param[in] v0 Pointer to first Array element.
        /// \param[in] n0 Number of elements.
        Tarray(T* v0,Uint32 n0);

        /// Tarray Constructor with Given Parameters.
        /// \wi{18170}
        /// Tarray class shall build itself upon construction with array size and memory type.
        /// \param[in] n0 Array size.
        /// \param[in] memtype Memory type.
        Tarray(Uint32 n0, Base::Memmgr::Type memtype);

        /// Tarray Constructor with Given Parameters.
        /// \wi{18171}
        /// Tarray class shall build itself upon construction with the specified number of elements and an allocator.
        /// \param[in] n0      Number of elements to allocate space for.
        /// \param[in] alloc   Allocator to be used for memory allocation.
        Tarray(Uint32 n0, Base::Allocator& alloc);

        /// Minimum Value Retriever.
        /// \wi{3285}
        /// Tarray class shall be able to retrieve the minimum value of its array components.
        /// \return Minimum value.
        T min_value() const;
        /// Maximum Value Retriever.
        /// \wi{3283}
        /// Tarray class shall be able to retrieve the maximum value of its array components.
        /// \return Maximum value.
        T max_value() const;

        /// Array Sum Computer.
        /// \wi{3261}
        /// Tarray class shall provide the capability to compute the sum of two Array instances, element by element.
        /// \param[in] y1       First Array instance to be added.
        /// \param[in] y2       Second Array instance to be added.
        void sum(const Base::Array<T>& y1,const Base::Array<T>& y2);
        /// Array Addition Computer.
        /// \wi{3120}
        /// Tarray class shall provide the capability to add a provided Array instance, element by element.
        /// \param[in] y1       Array instance to add.
        void add(const Base::Array<T>& y1);
        /// Constant Addition Computer.
        /// \wi{18172}
        /// Tarray class shall provide the capability to add a provided constant value for each element of the Array.
        /// \param[in] y1       Constant value to add.
        void add(const T& y1);
        /// Scaled Array Addition Computer.
        /// \wi{18173}
        /// Tarray class shall provide the capability to add a scaled Array instance, element by element.
        /// \param[in] a1       Constant ascalar value.
        /// \param[in] y1       Array instance to add.
        void add(T a1,const Base::Array<T>& y1);

        /// Constant Subtraction Computer.
        /// \wi{3121}
        /// Tarray class shall provide the capability to subtract a provided constant value for each element of the Array.
        /// \param[in] y1       Constant value to subtract.
        void subtract(const T& y1);
        /// Two Array Subtraction Computer.
        /// \wi{18174}
        /// Tarray class shall provide the capability to compute the subtraction of two Array instances, element by element.
        /// \param[in] y1       First Array instance to be subtracted.
        /// \param[in] y2       Second Array instance to be subtracted.
        void subtract(const Base::Array<T>& y1,const Base::Array<T>& y2);
        /// Array Subtraction Computer.
        /// \wi{18175}
        /// Tarray class shall provide the capability to subtract a provided Array instance, element by element.
        /// \param[in] y1       Array instance to subtract.
        void subtract(const Base::Array<T>& y1);
        
        /// Constant Scaler.
        /// \wi{3122}
        /// Tarray class shall provide the capability to scale each element of the Array to a provided constant value.
        /// \param[in] a        Constant scalar value.
        void scale(const T& a);
        /// Two Array Multiplier.
        /// \wi{3263}
        /// Tarray class shall provide the capability to multiply two Array instances, element by element.
        /// \param[in] k1       Starting multiplication index for the first array.
        /// \param[in] h1       Step size for accessing the first array.
        /// \param[in] y1       First Array instance to be multiplied.
        /// \param[in] k2       Starting multiplication index for the second array.
        /// \param[in] h2       Step size for accessing the second array.
        /// \param[in] y2       Second Array instance to be multiplied.
        void multiply(Uint16 k1,
                      Uint16 h1,
                      const Base::Array<T>& y1,
                      Uint16 k2,
                      Uint16 h2,
                      const Base::Array<T>& y2);
        /// Inversion Array Computer.
        /// \wi{3124}
        /// Tarray class shall provide the capability to invert the sign of the array, equivalent to scale it by -1.
        void signinv();

        /// Array Scaler.
        /// \wi{17728}
        /// Tarray class shall provide the capability to scale a provided Array by a provided value.
        /// The length of the passed array shall be ignored, the multiplication shall be done using the dimensions of
        /// the calling vector.
        /// \param[in] a1       Constant scalar value.
        /// \param[in] y1       Array instance to be scaled.
        void lincmb(const T a1,
                    const Base::Array<T>& y1);

        /// Array Addition Computer
        /// \wi{19014}
        /// Tarray class shall provide the capability to add a scaled Array, element by element.
        /// \param[in] a1       Constant value to scale the given Array.
        /// \param[in] y1       Array instance.
        void lincmb_add(const T a1,
                        const Base::Array<T>& y1);

        /// Two Scaled Array Sum Computer.
        /// \wi{3068}
        /// Tarray class shall provide the capability to add two scaled Array, element by element.
        /// \param[in] a1       Constant value to scale the first Array.
        /// \param[in] y1       First Array instance.
        /// \param[in] a2       Constant value to scale the second Array.
        /// \param[in] y2       Second Array instance.
        void lincmb(T a1,
                    const Base::Array<T>& y1,
                    T a2,
                    const Base::Array<T>& y2);
        /// Minimum Array Value and Position Retriever.
        /// \wi{18176}
        /// Tarray class shall provide the capability to find the minimum value of its array components and its position.
        /// \param[in,out] a    Instance variable to store the minimum value found.
        /// \return Index of the minimum value position found within the array.
        Uint32 find_min(T& a)const;
        /// Maximum Array Value and Position Retriever.
        /// \wi{3284}
        /// Tarray class shall provide the capability to find the maximum value of its array components and its position.
        /// \param[in,out] a    Instance variable to store the maximum value found.
        /// \return Index of the maximum value position found within the array.
        Uint32 find_max(T& a)const;

        /// Element Wise Array Multiplier.
        /// \wi{18177}
        /// Tarray class shall provide the capability to compute element-wise multiplication with a provided array.
        /// \param[in] a    Array instance to be multiplied.
        void mul_wise(const Base::Array<T>& a);
        /// Element Wise Array Division Computer.
        /// \wi{18178}
        /// Tarray class shall provide the capability to compute element-wise division with a provided array.
        /// \param[in] a    Array instance to be divided.
        void div_wise(const Base::Array<T>& a);

        /// Array Span Computer.
        /// \wi{3262}
        /// Tarray class shall provide the capability to compute the span of its array elements.
        /// \return The computed span of the array elements.
        inline T span()const
        {
            /// \alg
            /// - Return the difference between the last and first elements of the array.
            return (Base::Array<T>::v[Base::Array<T>::n-1]-Base::Array<T>::v[0]);
        }

    private:
        /// Maximum Array Value Retriever.
        /// \wi{18179}
        /// Tarray class shall provide the capability to find the maximum value of its array components.
        /// \return Maximum value found.
        T* max0() const;
        /// Minimum Array Value Retriever.
        /// \wi{18180}
        /// Tarray class shall provide the capability to find the minimum value of its array components.
        /// \return Minimum value found.
        T* min0() const;

        Tarray();                                ///< = delete
        Tarray(const Tarray& src);               ///< = delete
        Tarray& operator=(const Tarray& src);    ///< = delete
    };

    template<typename T>
    template<typename T2>
    inline Tarray<T>::Tarray(Base::Mblock<T2> mb) : Base::Array<T>(mb)
    {
    }

    template<typename T>
    inline Tarray<T>::Tarray(T* v0,Uint32 n0) : Base::Array<T>(v0,n0)
    {
    }

    template<typename T>
    inline Tarray<T>::Tarray(Uint32 n0, Base::Memmgr::Type memtype) : Base::Array<T>(n0,memtype)
    {
    }

    template<typename T>
    inline Tarray<T>::Tarray(Uint32 n0, Base::Allocator& alloc) : Base::Array<T>(n0, alloc)
    {
    }

    template<typename T>
    void Tarray<T>::subtract(const T& y1)
    {
        /// \alg
        /// <ul>
        /// <li> Iterate over each element of the array represented.
        for(T* p=Base::Array<T>::v; p<=Base::Array<T>::vz; p++)
        {
            /// <ul>
            /// <li> Subtract the value 'y1' from each element of the array.
            (*p)-=y1;
            /// </ul>
        }
        /// </ul>
    }

    template<typename T>
    inline T Tarray<T>::max_value() const
    {
        /// \alg
        /// - Return retrieved reference value by Tarray<T>::max0().
        T* result=max0();
        return *result;
    }

    template<typename T>
    Uint32 Tarray<T>::find_max(T& a)const
    {
        /// \alg
        /// - Get retrieved value by Tarray<T>::max0().
        T* result=max0();
        a = *result;
        /// - Return index position as the subtraction between value found and the pointer to first element of the Array.
        return static_cast<Uint32>(result-Base::Array<T>::v);
    }

    template<typename T>
    T* Tarray<T>::max0() const
    {
        /// \alg
        /// <ul>
        /// <li> Iterate over each element of the array starting from the second element.
        T* result=Base::Array<T>::v;
        for(T* p=&(Base::Array<T>::v[1]); p<=Base::Array<T>::vz; p++)
        {
            /// <ul>
            /// <li> Compare each element with the current maximum value.
            /// <li> If the current element is greater than the current maximum value, update to point to this element.
            if((*p)>(*result))
            {
                result=p;
            }
            /// </ul>
        }
        /// <li> Return the pointer to the maximum value found within the array.
        return result;
        /// </ul>
    }

    template<typename T>
    inline T Tarray<T>::min_value() const
    {
        /// \alg
        /// - Return retrieved reference value by Tarray<T>::min0().
        T* result=min0();
        return *result;
    }

    template<typename T>
    Uint32 Tarray<T>::find_min(T& a)const
    {
        /// \alg
        /// - Get retrieved value by Tarray<T>::min0().
        T* result=min0();
        a = *result;
        /// - Return index position as the subtraction between value found and the pointer to first element of the Array.
        return static_cast<Uint32>(result-Base::Array<T>::v);
    }

    template<typename T>
    T* Tarray<T>::min0() const
    {
        /// \alg
        /// <ul>
        /// <li> Iterate over each element of the array starting from the second element.
        T* result=Base::Array<T>::v;
        for(T* p=&(Base::Array<T>::v[1]); p<=Base::Array<T>::vz; p++)
        {
            /// <ul>
            /// <li> Compare each element with the current maximum value.
            /// <li> If the current element is lower than the current maximum value, update to point to this element.
            if((*p)<(*result))
            {
                result=p;
            }
            /// </ul>
        }
        /// <li> Return the pointer to the maximum value found within the array.
        return result;
        /// </ul>
    }

    template<typename T>
    void Tarray<T>::subtract(const Base::Array<T>& y1,const Base::Array<T>& y2)
    {
        /// \alg
        /// <ul>
        /// <li> Iterate over each element of the array starting from the first element.
        const T* p1=&y1[0];
        const T* p2=&y2[0];
        for(T* p=Base::Array<T>::v; p<=Base::Array<T>::vz; p++)
        {
            /// <ul>
            /// <li> Subtract the corresponding elements for given arrays.
            *p=(*p1)-(*p2);
            /// <li> Increment pointers to move to the next elements of the given arrays.
            p1++;
            p2++;
            /// </ul>
        }
        /// </ul>
    }

    template<typename T>
    void Tarray<T>::add(const Base::Array<T>& y1)
    {
        /// \alg
        /// <ul>
        /// <li> Iterate over each element of the array starting from the first element.
        const T* p1=&y1[0];
        for(T* p=Base::Array<T>::v; p<=Base::Array<T>::vz; p++)
        {
            /// <ul>
            /// <li> Add the corresponding element for the given array.
            (*p)+=*p1;
            /// <li> Increment pointer to move to the next element of the given array.
            p1++;
            /// </ul>
        }
        /// </ul>
    }

    template<typename T>
    void Tarray<T>::add(const T& y1)
    {
        /// \alg
        /// <ul>
        /// <li> Iterate over each element of the array starting from the first element.
        for(T* p=Base::Array<T>::v; p<=Base::Array<T>::vz; p++)
        {
            /// <ul>
            /// <li> Add the given constant value to the corresponding element.
            (*p)+=y1;
            /// </ul>
        }
        /// </ul>
    }

    template<typename T>
    void Tarray<T>::add(T a1,const Base::Array<T>& y1)
    {
        /// \alg
        /// <ul>
        /// <li> Iterate over each element of the array starting from the first element.
        const T* p1=&y1[0];
        for(T* p=Base::Array<T>::v; p<=Base::Array<T>::vz; p++)
        {
            /// <ul>
            /// <li> Add the corresponding scaled element for the given array.
            (*p)+=a1*(*p1);
            /// <li> Increment pointer to move to the next element of the given array.
            p1++;
            /// </ul>
        }
        /// </ul>
    }

    template<typename T>
    void Tarray<T>::scale(const T& a)
    {
        /// \alg
        /// <ul>
        /// <li> Iterate over each element of the array starting from the first element.
        for(T* p=Base::Array<T>::v; p<=Base::Array<T>::vz; p++)
        {
            /// <ul>
            /// <li> Scale the corresponding element by the given constant.
            (*p)*=a;
            /// </ul>
        }
        /// </ul>
    }

    template<typename T>
    void Tarray<T>::sum(const Base::Array<T>& y1,const Base::Array<T>& y2)
    {
        /// \alg
        /// <ul>
        /// <li> Iterate over each element of the array starting from the first element.
        const T* p1=&y1[0];
        const T* p2=&y2[0];
        for(T* p=Base::Array<T>::v; p<=Base::Array<T>::vz; p1++,p2++,p++)
        {
            /// <ul>
            /// <li> Sum the corresponding elements for the given arrays.
            *p=(*p1)+(*p2);
            /// </ul>
        }
        /// </ul>
    }

    template<typename T>
    void Tarray<T>::subtract(const Base::Array<T>& y1)
    {
        /// \alg
        /// <ul>
        /// <li> Iterate over each element of the array starting from the first element.
        const T* p1=&y1[0];
        for(T* p=Base::Array<T>::v; p<=Base::Array<T>::vz; p++)
        {
            /// <ul>
            /// <li> Subtract the corresponding element for the given array.
            (*p)-=*p1;
            /// <li> Increment pointer to move to the next element of the given array.
            p1++;
            /// </ul>
        }
        /// </ul>
    }

    template<typename T>
    void Tarray<T>::multiply(Uint16 k1,
                             Uint16 h1,
                             const Base::Array<T>& y1,
                             Uint16 k2,
                             Uint16 h2,
                             const Base::Array<T>& y2)
    {
        /// \alg
        /// <ul>
        /// <li> Iterate over each element of the array starting from the first element.
        const T* p1=&y1[k1];
        const T* p2=&y2[k2];
        for(T* p=Base::Array<T>::v; p<=Base::Array<T>::vz; p1+=h1,p2+=h2,p++)
        {
            /// <ul>
            /// <li> Multiply the corresponding element for the given arrays.
            *p=(*p1)*(*p2);
            /// </ul>
        }
        /// </ul>
    }

    template<typename T>
    void Tarray<T>::signinv()
    {
        /// \alg
        /// <ul>
        /// <li> Iterate over each element of the array starting from the first element.
        for(T* p=Base::Array<T>::v; p<=Base::Array<T>::vz; p++)
        {
            /// <ul>
            /// <li> Invert the sign of the corresponding element.
            (*p)=-(*p);
            /// </ul>
        }
        /// </ul>
    }

    template<typename T>
    void Tarray<T>::lincmb(const T a1,
                           const Base::Array<T>& y1)
    {
        /// \alg
        /// <ul>
        /// <li> Iterate over each element of the array starting from the first element.
        const T* p1=&y1[0];
        for(T* p=Base::Array<T>::v; p<=Base::Array<T>::vz; p++)
        {
            /// <ul>
            /// <li> Scale the corresponding element for the given array.
            *p=a1*(*p1);
            /// <li> Increment pointer to move to the next element of the given array.
            p1++;
            /// </ul>
        }
        /// </ul>
    }

    template<typename T>
    void Tarray<T>::lincmb_add(const T a1,
                               const Base::Array<T>& y1)
    {
        /// \alg
        /// <ul>
        /// <li> Iterate over each element of the array starting from the first element.
        const T* p1=&y1[0];
        for(T* p=Base::Array<T>::v; p<=Base::Array<T>::vz; p++)
        {
            /// <ul>
            /// <li> Add the corresponding scaled element for the given array.
            *p+=a1*(*p1);
            /// <li> Increment pointer to move to the next element of the given array.
            p1++;
            /// </ul>
        }
        /// </ul>
    }

    template<typename T>
    void Tarray<T>::lincmb(T a1,
                           const Base::Array<T>& y1,
                           T a2,
                           const Base::Array<T>& y2)
    {
        /// \alg
        /// <ul>
        /// <li> Iterate over each element of the array starting from the first element.
        const T* p1=&y1[0];
        const T* p2=&y2[0];
        for(T* p=Base::Array<T>::v; p<=Base::Array<T>::vz; p++)
        {
            /// <ul>
            /// <li> Sum the corresponding scaled elements for the given arrays.
            *p=a1*(*p1)+a2*(*p2);
            /// <li> Increment pointers to move to the next elements of the given arrays.
            p1++;
            p2++;
            /// </ul>
        }
        /// </ul>
    }

    template<typename T>
    void Tarray<T>::mul_wise(const Base::Array<T>& a)
    {
        /// \alg
        /// <ul>
        /// <li> Iterate over each element of the array starting from the first element.
        const T* pa = &a[0];
        for(T* p = Base::Array<T>::v; p <= Base::Array<T>::vz; ++p)
        {
            /// <ul>
            /// <li> Multiply by the corresponding element for the given array.
            *p *= (*pa);
            /// <li> Increment pointer to move to the next element of the given array.
            ++pa;
            /// </ul>
        }
        /// </ul>
    }

    template<typename T>
    void Tarray<T>::div_wise(const Base::Array<T>& a)
    {
        /// \alg
        /// <ul>
        /// <li> Iterate over each element of the array starting from the first element.
        const T* pa = &a[0];
        for(T* p = Base::Array<T>::v; p <= Base::Array<T>::vz; ++p)
        {
            /// <ul>
            /// <li> Divide by the corresponding element for the given array.
            *p /= (*pa);
            /// <li> Increment pointer to move to the next element of the given array.
            ++pa;
            /// </ul>
        }
        /// </ul>
    }

}

#endif

