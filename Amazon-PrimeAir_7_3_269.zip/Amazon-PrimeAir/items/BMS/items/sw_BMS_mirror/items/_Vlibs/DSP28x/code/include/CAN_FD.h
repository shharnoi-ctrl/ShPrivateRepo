#ifndef CAN_FD_H_
#define CAN_FD_H_

#include <CANpid.h>
#include <Entypes.h>

#include <CANframe_fw.h>
#include <CAN_FD_cfg_fw.h>
#include <CAN_FD_ioctl_fw.h>

namespace Dsp28335_ent
{
    /// CAN FD Driver.
    /// The DSP2838x_ent library shall be able to send and receive CAN-FD messages using the MCAN peripheral.
    class CAN_FD
    {
    public:
        typedef Base::CANframe type; // required by producer/consumer contract

        enum DLC    /// Data Length Codes for CAN-FD
        {
            dlc0  =  0, ///< 0 bytes - Start of CAN 2.0 lengths
            dlc1  =  1, ///< 1 byte
            dlc2  =  2, ///< 2 bytes
            dlc3  =  3, ///< 3 bytes
            dlc4  =  4, ///< 4 bytes
            dlc5  =  5, ///< 5 bytes
            dlc6  =  6, ///< 6 bytes
            dlc7  =  7, ///< 7 bytes
            dlc8  =  8, ///< 8 bytes  - End of CAN20 lengths
            dlc12 =  9, ///< 12 bytes - Start of CAN-FD lengths
            dlc16 = 10, ///< 16 bytes
            dlc20 = 11, ///< 20 bytes
            dlc24 = 12, ///< 24 bytes
            dlc32 = 13, ///< 32 bytes
            dlc48 = 14, ///< 48 bytes
            dlc64 = 15  ///< 64 bytes - End of CAN-FD lengths
        };

        /// CAN-FD constructor.
        /// CAN_FD constructor shall initialize all its internal variables upon construction.
        /// \wi{12656}
        /// \param[in] id0 CAN-FD identifier.
        explicit CAN_FD(Base::CANpid id0);

        /// CAN-FD Read Available.
        /// When requested, CAN_FD shall provide a boolean indicating if there is a frame ready to be read.
        /// \wi{12658}
        /// \return True if there is data available for reading.
        bool rd_available() const;

        /// CAN-FD Read.
        /// When requested, CAN_FD shall provide the next available frame and increment its read count if read.
        /// \wi{12659}
        /// \param[out] frame Holder for message data.
        /// \return True if data actually read.
        bool read(Base::CANframe& frame);

        /// CAN-FD Write Available.
        /// When requested, CAN_FD shall provide a boolean indicating if a frame can be written.
        /// \wi{12660}
        /// \return True if data can be written.
        bool wr_available() const;

        /// CAN-FD Write a CAN frame if possible.
        /// When requested, CAN_FD shall, if possible, writes a CAN frame and increments its write count.
        /// \wi{12661}
        /// \param[in] frame Message to write.
        /// \return True if data actually written.
        bool write(const Base::CANframe& frame);

        /// CAN-FD Get Bus ON.
        /// When requested, CAN_FD shall return a boolean indicating if the CAN-FD not in error.
        /// \wi{12662}
        /// \return True if the bus is on, False if is in error state (Bus off)
        bool get_bus_on() const;

        /// CAN-FD Get Warning Off.
        /// When requested, CAN_FD shall return a boolean indicating if there are no CAN-FD warnings.
        /// \wi{12663}
        bool get_warning_off() const; ///< \return True if there is no warning.

        /// CAN-FD Get Transmit Error Count.
        /// When requested, CAN_FD shall return the number of transmit errors.
        /// \wi{12664}
        ///< \return Tx error counter
        Uint16 get_tx_errors() const;

        /// CAN-FD Get Transmit Error Count.
        /// When requested, CAN_FD shall return the number of receive errors.
        /// \wi{12665}
        ///< \return Rx error counter.
        Uint16 get_rx_errors() const;

        /// CAN-FD Get Transmit Count.
        /// When requested, CAN_FD shall return the number of messages sent and then set that counter to zero.
        /// \wi{12666}
        /// \return Tx count and reset that count.
        inline Uint32 get_tx_count()
        {
            Uint32 res = tx_count;
            tx_count = 0;
            return res;
        }

        /// CAN-FD Get Receive Count.
        /// When requested, CAN_FD shall return the number of messages received and then set that counter to zero.
        /// \wi{12667}
        /// \return Rx count and reset that count.
        inline Uint32 get_rx_count()
        {
            Uint32 res = rx_count;
            rx_count = 0;
            return res;
        }
        
        /// CAN-FD Configuration.
        /// wi{18103}
        /// When requested, CAN_FD shall configure itself with given ::CAN_FD_cfg configuration object.
        /// \param[in] cfg  Configuration to apply.
        void config(const CAN_FD_cfg& cfg);

        /// CAN-FD Length to DLC.
        /// Dsp2838x_ent library shall provide a method to convert data length to CAN-FD DLC.
        /// \wi{12668}
        /// \param[in] len Length in bytes.
        /// \return DLC for given length.
        static DLC len_to_dlc(Uint8 len);

        /// CAN-FD DLC to length.
        static Uint8 dlc_to_len(DLC dlc0);

    private:
        const Base::CANpid id;  ///< CAN Id.
        struct Pimpl;           ///< Implementation forward declaration.
        Pimpl& impl;            ///< Implementation reference.
        Uint32 tx_count;        ///< Number of CANframes transmitted since last check.
        Uint32 rx_count;        ///< Number of CANframes received since last check.
        bool canfd_mode;        ///< Use CAN-FD mode. Can be changed by CAN_FD_ioctl "config" method.
        bool brs;               ///< Bit rate switching. Can be changed by CAN_FD_ioctl "config" method.
        Uint16 fifo_sz;         ///< Configured fifo size.

        CAN_FD(const CAN_FD& orig); ///< = delete
        CAN_FD& operator=(const CAN_FD& orig); ///< = delete

        friend class CAN_FD_ioctl;
    };
}
#endif
