#ifndef DELAY_H_
#define DELAY_H_

#include <Entypes.h>
namespace Dsp28335_ent
{
    /// Busy delays
    class Delay
    {
    public:
        static void ns_by_5(Uint16 ns5);        ///< Delay by "ns5" * 5 nanoseconds. Only for 28377.
        static void ns_25();                    ///< Delay of 25 nanoseconds. Both micros.
        static void ns_by_50(Uint16 ns50);      ///< Delay by "ns50" * 50 nanoseconds. Both micros.
        static void us(Uint16 us);              ///< Delay for "us" microseconds
        static void ms(Uint16 ms);              ///< Delay for "ms" milliseconds
    private:
        Delay(); ///< = delete
        ~Delay(); ///< = delete
        Delay(const Delay& obj); ///< = delete
        Delay& operator=(const Delay& obj); ///< = delete
    };
}
#endif
