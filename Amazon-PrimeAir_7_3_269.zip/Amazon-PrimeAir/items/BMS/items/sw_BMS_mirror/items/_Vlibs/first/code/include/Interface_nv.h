#ifndef INTERFACE_NV_H_
#define INTERFACE_NV_H_

namespace Base
{

    /// Non-virtual destructor interface class.
    /// The Base library shall provide a class with its destructor declared as protected so that classes derived
    /// from this class cannot be destroyed through their interface classes.
    /// \rat When using inheritance in C++ usually the base classes have their destructor declared as virtual so that
    /// when derived classes are destroyed through references to their base class the correct destructor is called
    /// (the destructor from the derived class, if any). This class is for cases when virtual destructor does not
    /// need to be supported as the derived classes will not be destroyed from their base classes, that way there are
    /// less destructors being generated in flash, saving program memory.
    class Interface_nv
    {
    protected:
        /// Non-virtual destructor interface class destructor.
        /// \wi{14223}
        /// The Interface_nv class shall provide a protected destructor that does nothing.
        ~Interface_nv();
    };

    inline Interface_nv::~Interface_nv()
    {
    }

}

#endif
