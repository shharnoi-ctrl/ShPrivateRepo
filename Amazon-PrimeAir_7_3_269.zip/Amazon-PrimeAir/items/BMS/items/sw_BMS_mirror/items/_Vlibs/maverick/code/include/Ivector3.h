#ifndef IVECTOR3_H_
#define IVECTOR3_H_

#include <Ivector.h>
#include <Irmatrix3_fw.h>
#include <Imatrix3.h>

namespace Maverick
{
    /// Ivector3.
    /// The ::Maverick library shall provide the capability of creating 3D Vectors of generic type.
    template <typename T>
    class Ivector3 : public Ivector<T>
    {
    public:
        /// Enum that contains the indices of Ivector3 elements.
        enum pos_vector
        {
            vx = 0,     ///< x-component index.
            vy = 1,     ///< y-component index.
            vz = 2      ///< z-component index.
        };

        /// Ivector3 Constructor with Pointer of Template Datatype Initialization.
        /// \wi{19609}
        /// Ivector3 class shall be able to initialize its own parameters with pointer of type T.
        /// \param[in] v0   Pointer to T.
        /// \alg
        /// - Initialize the base class ::Ivector with v0.
        inline explicit Ivector3(T* v0) : Ivector<T>(v0)
        {
        }

        /// Ivector3 Constructor with Memory Block Initialization.
        /// \wi{19610}
        /// Ivector3 class should be capable of initializing its own parameters with a memory block
        /// (Base::Mblock).
        /// \param[in] mb   Memory block of type T.
        /// \alg
        /// Initialize the base class ::Ivector with mb.v.<br>
        /// The algorithm for Ivector3::Ivector3 function shall be implemented as follows:
        inline explicit Ivector3(Base::Mblock<T> mb) : Ivector<T>(mb.v)
        {
            /// - Call runtime assertion for memory block "mb" size equal to ::sz (3U).
            Base::Assertions::runtime(mb.sz==sz);
        }

        /// Ivector3 Size Getter.
        /// \wi{19614}
        /// Ivector3 shall provide a method to return size of the vector which is constant as 3U.
        /// \return The size of the vector
        /// \alg
        /// The algorithm for Ivector3::size function shall be implemented as follows:
        static inline Uint16 size()
        {
            /// - Return the size (::sz).
            return sz;
        }

        /// Ivector3 Zeros Initializer.
        /// \wi{19615}
        /// Ivector3 shall provide a method to zero all of its elements.
        /// \alg
        /// The algorithm for Ivector3::zeros function shall be implemented as follows:
        inline void zeros()
        {
            /// - Set all elements of the vector to zero by calling Base::Tmem::set with template argument
            /// sz * sizeof(T) representing the number of bytes, and function arguments
            /// Ivector<T>::v and 0U.
            Base::Tmem::set<sz*sizeof(T)>(Ivector<T>::v,0);
        }

        /// Ivector3 Copy from Ivector3 of Type T.
        /// \wi{19626}
        /// Ivector3 shall provide a method to replace its internal data with a copy of the
        /// data inside an Ivector3 "v0".
        /// \param[in] v0   Ivector3 input vector to be copied.
        /// \alg
        /// The algorithm for Ivector3::copy function shall be implemented as follows:
        inline void copy(const Ivector3<T>& v0)
        {
            /// - Call Ivector::copy0 passing to it as template argument ::sz, and as function argument "v0".
            Ivector<T>::template copy0<sz>(v0);
        }

        /// Ivector3 Copy from Pointer of Type T.
        /// \wi{19627}
        /// Ivector3 shall provide a method to replace its internal data with a copy of the
        /// data found at the address specified by the pointer to T "v0".
        /// \param[in] v0   T pointer to be copied.
        /// \alg
        /// The algorithm for Ivector3::copy function shall be implemented as follows:
        inline void copy(const T* v0)
        {
            /// - Call Ivector::copy0 passing to it as template argument ::sz, and as function argument "v0".
           Ivector<T>::template copy0<sz>(v0);
        }

        /// Ivector3 Copy from Memory Block.
        /// \wi{19632}
        /// Ivector3 shall provide a method to replace its internal data with a copy of the
        /// data inside a memory block "v0".
        /// \param[in] v0   Mblock to be copied.
        /// \alg
        /// The algorithm for Ivector3::copy function shall be implemented as follows:
        inline void copy(const Base::Mblock<const T>& v0)
        {
            /// - Call runtime assertion for memory block "v0" size equal to ::sz (3U).
            Base::Assertions::runtime(v0.size()==sz);
            /// - Call Ivector::copy0 passing to it as template argument ::sz, and as function argument "v0.v".
            Ivector<T>::template copy0<sz>(v0.v);
        }

        /// Ivector3 Two Vector Difference.
        /// \wi{19633}
        /// Ivector3 class shall provide a method to calculate the difference between two input 3x1 vectors
        /// and store the result in itself.
        /// \param[in] x First 3x1 vector.
        /// \param[in] y Second 3x1 vector.
        void vecres(const Ivector3& x,const Ivector3& y);
        
        /// Ivector3 Vector Subtraction.
        /// \wi{19636}
        /// Ivector3 class shall provide a method to update itself by subtracting input Ivector3 vector
        /// from itself and store the result in itself.
        /// \param[in] x 3x1 vector to be subtracted.
        void vecsub(const Ivector3& x);

        /// 3D Vector Add Computation.
        /// \wi{3061}
        /// Ivector3 class shall provide the capability to add the given Real 3D Vectors.
        /// \param[in] x        3D Vector for addition.
        void vecadd(const Ivector3<T>& x);
        

        /// Ivector3 Dot Product.
        /// \wi{19637}
        /// Ivector3 class shall provide a method to calculate the dot product of itself and input vector
        /// and return the result.
        /// \param[in] v0 3x1 vector to perform the dot product.
        /// \return Dot product result.
        T dot(const Ivector3<T>& v0) const;

        /// Ivector3 X-Y Components Dot Product.
        /// \wi{19638}
        /// Ivector3 class shall provide a method to calculate the dot product of the first two elements of 
        /// itself and input vector and return the result.
        /// \param[in] a 3x1 vector to perform the dot product.
        /// \return X-Y components dot product result.
        T dotxy(const Ivector3<T>& a) const;

        /// Ivector3 2nd Norm Square.
        /// \wi{19639}
        /// Ivector3 shall provide a method to calculate its 2nd norm squared and return the result.
        /// \return Ivector3 dot product squared.
        /// \alg
        /// The algorithm for Ivector3::norm22 function shall be implemented as follows:
        inline T norm22() const
        {
            /// - Calculate the dot product of Ivector3 with itself
            /// using ::dot passing to it Ivector3 and return the result.
            return this->dot(*this);
        }

        /// Ivector3 X-Y Components 2nd Norm Square.
        /// \wi{19640}
        /// Ivector3 shall provide a method to calculate the X-Y dot 2nd norm square of Ivector3
        /// and return the result.
        /// \return Ivector3 X-Y components dot product squared.
        T norm22xy() const;

        /// Multiplication of Matrix by Vector.
        /// \wi{3054}
        /// Ivector3 class shall provide a method to multiply a 3x3 matrix by a 3x1 vector
        /// and store the result in itself.
        /// \param[in] A        3x3 Input Matrix.
        /// \param[in] b        3x1 Input Vector.
        void matvec(const Imatrix3<T>& A, const Ivector3<T>& b);


    private:
        static const Uint16 sz = 3;                ///< Size for Ivector3

        Ivector3();                                ///< = delete
        Ivector3(const Ivector3& src);             ///< = delete
        Ivector3& operator=(const Ivector3& src);  ///< = delete
    };

    template <typename T>
    T Ivector3<T>::dot(const Ivector3<T>& v0) const
    {
        return (Ivector<T>::v[vx] * v0[vx]) +
               (Ivector<T>::v[vy] * v0[vy]) +
               (Ivector<T>::v[vz] * v0[vz]);
    }
    
    template <typename T>
    void Ivector3<T>::vecadd(const Ivector3<T>& x)
    {
        /// \alg
        /// - Add the corresponding component of the given Real 3D Vector to its Real 3D Vector.
        Ivector<T>::v[vx]+=x.v[vx];
        Ivector<T>::v[vy]+=x.v[vy];
        Ivector<T>::v[vz]+=x.v[vz];
    }

    template <typename T>
    void Ivector3<T>::vecres(const Ivector3<T>& x,const Ivector3<T>& y)
    {
        Ivector<T>::v[vx]=x[vx]-y[vx];
        Ivector<T>::v[vy]=x[vy]-y[vy];
        Ivector<T>::v[vz]=x[vz]-y[vz];
    }

    template <typename T>
    void Ivector3<T>::vecsub(const Ivector3<T>& x)
    {
        Ivector<T>::v[vx]-=x[vx];
        Ivector<T>::v[vy]-=x[vy];
        Ivector<T>::v[vz]-=x[vz];
    }

    template <typename T>
    T Ivector3<T>::dotxy(const Ivector3<T>& a) const
    {
        return (Ivector<T>::v[vx]*a[vx])+(Ivector<T>::v[vy]*a[vy]);
    }

    /// \alg
    /// The algorithm for Ivector3::norm22xy function shall be implemented as follows:
    template <typename T>
    T Ivector3<T>::norm22xy() const
    {
        /// - Calculate the dot product of Ivector3 with itself
        /// using ::dotxy passing to it Ivector3 and return the result.
        return dotxy(*this);
    }

    template <typename T>
    void Ivector3<T>::matvec(const Imatrix3<T>& A, const Ivector3<T>& b)
    {
        const T* a=&A[0];
        Ivector3<T>::v[vx] = (a[Imatrix3<T>::a00]*b[vx]) + (a[Imatrix3<T>::a01]*b[vy]) + (a[Imatrix3<T>::a02]*b[vz]);
        Ivector3<T>::v[vy] = (a[Imatrix3<T>::a10]*b[vx]) + (a[Imatrix3<T>::a11]*b[vy]) + (a[Imatrix3<T>::a12]*b[vz]);
        Ivector3<T>::v[vz] = (a[Imatrix3<T>::a20]*b[vx]) + (a[Imatrix3<T>::a21]*b[vy]) + (a[Imatrix3<T>::a22]*b[vz]);
    }
}

#endif
