#ifndef CAN_FD_IOCTL_H_
#define CAN_FD_IOCTL_H_

#include <CAN_FD_fw.h>
#include <CAN_FD_cfg_fw.h>

namespace Dsp28335_ent
{
    /// CAN-FD Peripheral Configurator.
    /// The DSP2838x_ent library shall be able to configure the CAN-FD peripherals.
    class CAN_FD_ioctl
    {
    public:
        /// CAN-FD Peripheral Configure.
        /// CAN_FD_ioctl shall provide a method to configure a CAN-FD peripheral.
        /// \wi{12672}
        /// \param can CAN-FD peripheral to be configured.
        /// \param cfg CAN-FD configuration to be set.
        /// \return True if configuration succeeded, False if not.
        static bool config(CAN_FD& can, const CAN_FD_cfg& cfg);    ///< Configure the CAN peripheral

    private:
        CAN_FD_ioctl(); ///< = delete
        CAN_FD_ioctl(const CAN_FD_ioctl& orig); ///< = delete
        CAN_FD_ioctl& operator=(const CAN_FD_ioctl& orig); ///< = delete
    };
}
#endif
