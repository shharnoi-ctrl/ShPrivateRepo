#ifndef UVAR_H__
#define UVAR_H__

#include <Range.h>

namespace Base
{
    enum Uvar
    {
        vu_mode         =    0,     ///< (0) Actuators configuration (auto, man, arc, mix...)
        vu_phase        =    1,     ///< (1) Current phase identifier
        vu_adc00        =    2,     ///< (2) ADC channel 0
        vu_adc01        =    3,     ///< (3) ADC channel 1
        vu_adc02        =    4,     ///< (4) ADC channel 2
        vu_adc03        =    5,     ///< (5) ADC channel 3
        vu_adc04        =    6,     ///< (6) ADC channel 4
        vu_adc05        =    7,     ///< (7) ADC channel 5
        vu_adc06        =    8,     ///< (8) ADC channel 6
        vu_adc07        =    9,     ///< (9) ADC channel 7
        vu_adc08        =   10,     ///< (10) ADC channel 8
        vu_adc09        =   11,     ///< (11) ADC channel 9
        vu_adc10        =   12,     ///< (12) ADC channel 10
        vu_adc11        =   13,     ///< (13) ADC channel 11
        vu_adc12        =   14,     ///< (14) ADC channel 12
        vu_adc13        =   15,     ///< (15) ADC channel 13
        vu_adc14        =   16,     ///< (16) ADC channel 14
        vu_adc15        =   17,     ///< (17) ADC channel 15
        vu_adc16        =   18,     ///< (18) ADC channel 16
        vu_curr_envelope=   19,     ///< (19) Current envelope (deprecated)
        vu_c2_cnt       =   20,     ///< (20) Counter for C2 system BIT
        vu_blk_sz_total_lo = 21,    ///< (21) Total words available for blocks (low part)
        vu_blk_sz_total_hi = 22,    ///< (22) Total words available for blocks (high part)
        vu_blk_sz_used_lo  = 23,    ///< (23) Words used for blocks in allocator (low part)
        vu_blk_sz_used_hi  = 24,    ///< (24) Words used for blocks in allocator (high part)
        vu_srtm_type    =   25,     ///< (25) SRTM source type
        vu_flight_term     = 26,    ///< (26) Stanag Flight Termination Mode.

        vu_pdi_source   =   50,     ///< (50) First pdi Error identifier
        vu_operr_source =   51,     ///< (51) Operation error identifier

        vu_4x_id            = 53,     ///< (53) ID of this AP in a redundant (0-3) to compare with the selected CAP
        //Exclusive variables for Arbitration. Managed by Arbiter4x_fb
        /// (54) 4XV Current autopilot (CAP) from mux readings (v4.7+).If <4.7, then is copied from vu_arb_apsel.
        vu_arb_cap          = 54,
        //Exclusive variables for Arbiter CPU when read in another device.
        vu_arb_apsel        = 55,     ///< (55) 4XV Current autopilot ID selected by the arbiter (user variable)
        vu_arb_cfg_ldst     = 56,     ///< (56) 4XV Config manager status (flash / sd / safe mode).
        vu_arb_sw_dfs2_st   = 57,     ///< (57) 4XV State error for DFS2 File System
        vu_arb_can_ser0_err = 58,     ///< (58) 4XV CAN to Serial 0 frames dropped
        vu_arb_can_ser1_err = 59,     ///< (59) 4XV CAN to Serial 1 frames dropped
        vu_arb_adc00        = 60,     ///< (60) 4XV ADC channel 0
        vu_arb_adc01        = 61,     ///< (61) 4XV ADC channel 1
        vu_arb_adc02        = 62,     ///< (62) 4XV ADC channel 2
        vu_arb_adc03        = 63,     ///< (63) 4XV ADC channel 3
        vu_arb_adc04        = 64,     ///< (64) 4XV ADC channel 4
        vu_arb_adc05        = 65,     ///< (65) 4XV ADC channel 5
        vu_arb_adc06        = 66,     ///< (66) 4XV ADC channel 6
        vu_arb_adc07        = 67,     ///< (67) 4XV ADC channel 7
        vu_arb_adc08        = 68,     ///< (68) 4XV ADC channel 8
        vu_arb_adc09        = 69,     ///< (69) 4XV ADC channel 9
        vu_arb_adc10        = 70,     ///< (70) 4XV ADC channel 10
        vu_arb_adc11        = 71,     ///< (71) 4XV ADC channel 11
        vu_arb_adc12        = 72,     ///< (72) 4XV ADC channel 12
        vu_arb_adc13        = 73,     ///< (73) 4XV ADC channel 13
        vu_arb_adc14        = 74,     ///< (74) 4XV ADC channel 14
        vu_arb_adc15        = 75,     ///< (75) 4XV ADC channel 15

        vu_detour_changed     = 80,   ///< (80) Detour calculation id
        vu_approach_changed   = 81,   ///< (81) Approach calculation id
        vu_climb_changed      = 82,   ///< (82) Climb calculation id
        vu_cruise_changed     = 83,   ///< (83) Cruise calculation id
        vu_rendezvous_changed = 84,   ///< (84) Rendezvous calculation id
        vu_taxi_changed       = 85,   ///< (85) Taxi calculation id
        vu_vtol_changed       = 86,   ///< (86) Vtol calculation id

        vu_sw_ver_major    = 90,    ///< (90) Major software version
        vu_sw_ver_minor    = 91,    ///< (91) Minor software version
        vu_sw_ver_revision = 92,    ///< (92) Revision software version
        vu_sys_addr_h      = 93,    ///< (93) High part of system address (communications)
        vu_sys_addr_l      = 94,    ///< (94) Low part of system address (communications)
        vu_hw_addr         = 95,    ///< (95) Hardware address
        vu_sw_dfs2_state   = 96,    ///< (96) State error for DFS2 FS
        vu_dfs2_nb_part    = 97,    ///< (97) Number of registered partitions in DFS2 File System

        vu_gps0_nsat           =  100,  ///< (100) GPS 1 number of satellites used in solution.
        vu_gps0_rtcm1005_nfail =  101,  ///< (101) GPS 1 number of RTCM 1005 rejected by wrong CRC
        vu_gps0_rtcm1005_numok =  102,  ///< (102) GPS 1 number of RTCM 1005 correctly received by Ublox
        vu_gps0_rtcm1077_nfail =  103,  ///< (103) GPS 1 number of RTCM 1077 rejected by wrong CRC
        vu_gps0_rtcm1077_numok =  104,  ///< (104) GPS 1 number of RTCM 1077 correctly received by Ublox
        vu_gps0_rtcm1087_nfail =  105,  ///< (105) GPS 1 number of RTCM 1087 rejected by wrong CRC
        vu_gps0_rtcm1087_numok =  106,  ///< (106) GPS 1 number of RTCM 1087 correctly received by Ublox
        vu_gps0_rtcm1127_nfail =  107,  ///< (107) GPS 1 number of RTCM 1127 rejected by wrong CRC
        vu_gps0_rtcm1127_numok =  108,  ///< (108) GPS 1 number of RTCM 1127 correctly received by Ublox
        vu_gps0_rtcm1230_nfail =  109,  ///< (109) GPS 1 number of RTCM 1230 rejected by wrong CRC
        vu_gps0_rtcm1230_numok =  110,  ///< (110) GPS 1 number of RTCM 1230 correctly received by Ublox
        vu_gps0_rtcm4072_nfail =  111,  ///< (111) GPS 1 number of RTCM 4072 rejected by wrong CRC
        vu_gps0_rtcm4072_numok =  112,  ///< (112) GPS 1 number of RTCM 4072 correctly received by Ublox
        vu_gps0_rtcm_unk_nfail =  113,  ///< (113) GPS 1 number of RTCM unknown type rejected by wrong CRC
        vu_gps0_week           =  114,  ///< (114) GPS 1 week
        vu_gps0_jammst         =  115,  ///< (115) GPS 1 Jamming/interference monitor
        vu_gps0_spoofing       =  116,  ///< (116) GPS 1 Spoofing detection state
        vu_gps0all             =  117,  ///< (117) Total number of Uvars used by GPS

        vu_gps1_nsat           =  150,  ///< (150) GPS 2 number of satellites used in solution.
        vu_gps1_rtcm1005_nfail =  151,  ///< (151) GPS 2 number of RTCM 1005 rejected by wrong CRC
        vu_gps1_rtcm1005_numok =  152,  ///< (152) GPS 2 number of RTCM 1005 correctly received by Ublox
        vu_gps1_rtcm1077_nfail =  153,  ///< (153) GPS 2 number of RTCM 1077 rejected by wrong CRC
        vu_gps1_rtcm1077_numok =  154,  ///< (154) GPS 2 number of RTCM 1077 correctly received by Ublox
        vu_gps1_rtcm1087_nfail =  155,  ///< (155) GPS 2 number of RTCM 1087 rejected by wrong CRC
        vu_gps1_rtcm1087_numok =  156,  ///< (156) GPS 2 number of RTCM 1087 correctly received by Ublox
        vu_gps1_rtcm1127_nfail =  157,  ///< (157) GPS 2 number of RTCM 1127 rejected by wrong CRC
        vu_gps1_rtcm1127_numok =  158,  ///< (158) GPS 2 number of RTCM 1127 correctly received by Ublox
        vu_gps1_rtcm1230_nfail =  159,  ///< (159) GPS 2 number of RTCM 1230 rejected by wrong CRC
        vu_gps1_rtcm1230_numok =  160,  ///< (160) GPS 2 number of RTCM 1230 correctly received by Ublox
        vu_gps1_rtcm4072_nfail =  161,  ///< (161) GPS 2 number of RTCM 4072 rejected by wrong CRC
        vu_gps1_rtcm4072_numok =  162,  ///< (162) GPS 2 number of RTCM 4072 correctly received by Ublox
        vu_gps1_rtcm_unk_nfail =  163,  ///< (163) GPS 2 number of RTCM unknown type rejected by wrong CRC
        vu_gps1_week           =  164,  ///< (164) GPS 2 week
        vu_gps1_jammst         =  165,  ///< (165) GPS 2 Jamming/interference monitor
        vu_gps1_spoofing       =  166,  ///< (166) GPS 2 Spoofing detection state
        // 100-200 reserved for GPS

        vu_radarst      =  200,     ///< (200) Radar altimeter state
        vu_tpselected   =  201,     ///< (201) Current track patch
        vu_tpachieved   =  202,     ///< (202) Last achieved track patch
        vu_track_stage  =  203,     ///< (203) Track stage (loitering, routing, off).
        vu_patchset     =  204,     ///< (204) Current patchset ID.
        vu_tplaps       =  205,     ///< (205) Amount of laps done.

        vu_idm_tx_pkts  =  310,     ///< (310) Number of packets successfully sent
        vu_idm_rx_pkts  =  311,     ///< (311) Number of packets successfully received

        // id range here preferred for vars in cpu1 (regvars)

        vu_ext_nav_status       = 397, ///< (397) External navigation status
        vu_vn300_mode           = 398, ///< (398) Mode of operation of Vectornav VN-300
        vu_stepacq_idmax        = 399, ///< (399) (CPU1) Identifier of max duration step in CIO.
        vu_internest_raw_status = 400,  ///< (400) Internest raw status.
        vu_nav_source   =  401,         ///< (401) Navigation source. See values in (Base::Navtype).
        vu_gpsmainsel   =  402,         ///< (402) Gps identifier selected as main.

        vu_stp_sel      =  403,     ///< (403) Selected static pressure sensor
        vu_qinf_sel     =  404,     ///< (404) Selected dynamic pressure sensor
        vu_acc0_sel     =  405,     ///< (405) Selected primary accelerometer
        vu_gyr0_sel     =  406,     ///< (406) Selected primary gyroscope
        vu_mag_sel      =  409,     ///< (409) Selected magnetometer
        vu_stkprt_sel   =  410,     ///< (410) Selected stick priority table

        vu_stepc2_idmax   = 425,    ///< (425) (CPU2) Identifier of max duration step in C2.
        vu_cbits_selected = 426,    ///< (426) GRoup of user bits selected to be computed with system CBIT

        vu_syserr_bits  =  449,     ///< (449) Configured system errors that had triggered.
        vu_cana_txerr   =  450,     ///< (450) CAN-A Tx errors
        vu_cana_rxerr   =  451,     ///< (451) CAN-A Rx errors
        vu_canb_txerr   =  452,     ///< (452) CAN-B Tx errors
        vu_canb_rxerr   =  453,     ///< (453) CAN-B Rx errors
        vu_can_ser0_err =  454,     ///< (454) CAN to Serial 0 frames dropped
        vu_can_ser1_err =  455,     ///< (455) CAN to Serial 1 frames dropped
        vu_can_ser2_err =  456,     ///< (456) CAN to Serial 2 frames dropped
        vu_can_ser3_err =  457,     ///< (457) CAN to Serial 3 frames dropped
        vu_can_ser4_err =  458,     ///< (458) CAN to Serial 4 frames dropped
        vu_can_ser5_err =  459,     ///< (459) CAN to Serial 5 frames dropped

        vu_periodic_first = 460,    ///< (460) First file of the periodic log
        vu_periodic_last  = 461,    ///< (461) Last file of the periodic log
        vu_event_first    = 462,    ///< (462) First file of the event log
        vu_event_last     = 463,    ///< (463) Last file of the event log
        vu_fast_first     = 464,    ///< (464) First file of the fast log
        vu_fast_last      = 465,    ///< (465) Last file of the fast log

        vu_vpkt_discarded0 = 480,    ///< (480) Number of Vpkts discarded on port 0.
        vu_vpkt_discarded1 = 481,    ///< (481) Number of Vpkts discarded on port 1.
        vu_vpkt_discarded2 = 482,    ///< (482) Number of Vpkts discarded on port 2.
        vu_vpkt_discarded3 = 483,    ///< (483) Number of Vpkts discarded on port 3.
        vu_vpkt_discarded4 = 484,    ///< (484) Number of Vpkts discarded on port 4.
        vu_vpkt_discarded5 = 485,    ///< (485) Number of Vpkts discarded on port 5.

        vu_mobs_count   =  490,     ///< (490) Number of moving obstacles detected
        vu_cfg_vfcrc_h  =  491,     ///< (491) Veronte static cfg CRC (no Operation) of files (higher 16 bits).
        vu_cfg_vfcrc_l  =  492,     ///< (492) Veronte static cfg CRC (no Operation) of files (lower 16 bits).
        vu_cfg_vmcrc_h  =  493,     ///< (493) Veronte static cfg CRC (no Operation) of memory (higher 16 bits).
        vu_cfg_vmcrc_l  =  494,     ///< (494) Veronte static cfg CRC (no Operation) of memory (lower 16 bits).
        vu_cfg_gfcrc_h  =  495,     ///< (495) Global configuration state (crc) of files (higher 16 bits).
        vu_cfg_gmcrc_h  =  496,     ///< (496) Global configuration state (crc) of memory (higher 16 bits).
        vu_cfg_loadst   =  497,     ///< (497) Config manager status (flash / sd / maintenance mode).
        vu_cfg_gfcrc_l  =  498,     ///< (498) Global configuration state (crc) of files (lower 16 bits).
        vu_cfg_gmcrc_l  =  499,     ///< (499) Global configuration state (crc) of memory (lower 16 bits).

        // Gimbal variables reserved until 559
        comm_gim1       =  550,     ///< (550) Command 1 uard over can of gimbal
        comm_gim2       =  551,     ///< (551) Command 2 uard over can of gimbal
        comm_gim3       =  552,     ///< (552) Command 3 uard over can of gimbal
        comm_gim4       =  553,     ///< (553) Command 4 uard over can of gimbal
        zoom_eo         =  554,     ///< (554) Zoom level eo camera
        zoom_ir         =  555,     ///< (555) Zoom level ir camera
        track_x         =  556,     ///< (556) Gimbal track pixel X
        track_y         =  557,     ///< (557) Gimbal track pixel Y

        // CEX Start
        vu_cex_ppm_ch00     = 600,  ///< (600) PPM channel  0 output
        vu_cex_ppm_ch01     = 601,  ///< (601) PPM channel  1 output
        vu_cex_ppm_ch02     = 602,  ///< (602) PPM channel  2 output
        vu_cex_ppm_ch03     = 603,  ///< (603) PPM channel  3 output
        vu_cex_ppm_ch04     = 604,  ///< (604) PPM channel  4 output
        vu_cex_ppm_ch05     = 605,  ///< (605) PPM channel  5 output
        vu_cex_ppm_ch06     = 606,  ///< (606) PPM channel  6 output
        vu_cex_ppm_ch07     = 607,  ///< (607) PPM channel  7 output
        vu_cex_ppm_ch08     = 608,  ///< (608) PPM channel  8 output
        vu_cex_ppm_ch09     = 609,  ///< (609) PPM channel  9 output
        vu_cex_ppm_ch10     = 610,  ///< (610) PPM channel 10 output
        vu_cex_ppm_ch11     = 611,  ///< (611) PPM channel 11 output
        vu_cex_ppm_ch12     = 612,  ///< (612) PPM channel 12 output
        vu_cex_ppm_ch13     = 613,  ///< (613) PPM channel 13 output
        vu_cex_ppm_ch14     = 614,  ///< (614) PPM channel 14 output
        vu_cex_ppm_ch15     = 615,  ///< (615) PPM channel 15 output
        // CEX Reserved
        vu_jetibox_max_stage= 620,  ///< (620) Jetibox max successfully parsed message
        // CEX Reserved       699

        // COMMEX START
        vu_commex_planet_con= 700,  ///< (700) Planet Satcom connection Status
        vu_commex_planet_sgn= 701,  ///< (701) Planet Satcom signal strength
        // COMMEX Reserved   750

        // Transponder variables reserved until 799
        //  - Generic variables reserved until 729
        vu_squawk       = 710,
        vu_icao         = 711,
        vu_ident        = 712,
        vu_adsb_mode    = 713,
        vu_callsign1    = 714,
        vu_callsign2    = 715,
        vu_callsign3    = 716,
        vu_callsign4    = 717,
        vu_callsign5    = 718,
        vu_callsign6    = 719,
        vu_callsign7    = 720,
        vu_callsign8    = 721,
        //  - uAvionnix variables reserved until 739
        vu_p1090_seq    = 730,
        //  - Sagetech variables reserved until 749
        vu_mxs_hmsphr   = 741,
        vu_mxs_gnd_trk  = 742,
        vu_mxs_air_spd  = 743,
        // ADS-B Out variables
        vu_adsbout_icao_h   = 750,
        vu_adsbout_icao_l   = 751,
        vu_adsbout_emtype   = 752,
        vu_adsbout_calls0   = 753,
        vu_adsbout_calls1   = 754,
        vu_adsbout_calls2   = 755,
        vu_adsbout_calls3   = 756,
        vu_adsbout_calls4   = 757,
        vu_adsbout_calls5   = 758,
        vu_adsbout_calls6   = 759,
        vu_adsbout_calls7   = 760,
        vu_adsbout_type     = 761,
        vu_adsbout_control  = 762,
        vu_adsbout_squawk   = 763,
        vu_adsbout_ident    = 764,
        vu_adsbout_custom   = 765,
        // TRANSPONDER RESERVED     799

        vu_fault_id     = 800,  ///< (800) Fault ID
        vu_control_mode = 801,  ///< (801) Control mode: 0 fail_safe, 1 PPM, 2 CAN
        vu_state        = 802,  ///< (802) Actual state

        vu_sim          =  900,     ///< (900) Simulation variables

        // Update varmgr Uint16 buffer when this user list grows up
        vu_user         = 1000,     ///< (1000) User variables start (cero-based names)
        vu_user19       = 1019,     ///< (1019) User variable 19
        vu_user_last    = 1999,     ///< (1999) LAst user variable

        vu_none         = 2000,
        vu_zero         = 2001,     ///< (2001) zero value
        vu_all          = 2002
    };

    inline bool is_valid(Uvar v)
    {
        return Range<Uvar, vu_mode, vu_all>::in_range(v);
    }

    /// @return True if the Uvar passed as argument can be written by the user, false if read-only
    bool user_writable(Uvar v);

    inline Uvar validate(Uvar v, Uvar def=vu_none)
    {
        return is_valid(v) ? v : def;
    }
}
#endif
