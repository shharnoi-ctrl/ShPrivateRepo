#ifndef ASYNC_RES_H_
#define ASYNC_RES_H_

namespace Base
{
    /// Asynchronous result.
    /// \wi{14022}
    /// The Base library shall provide an enum to indicate the result of an asynchronous system operation.
    enum Async_res
    {
        async_ongoing,        ///< Last operation not finished.
        async_done_ok,        ///< Done with no errors.
        async_done_error,     ///< Done with errors.
        async_busy_error      ///< Not able to perform the request because a request was already ongoing
    };

    /// Check asynchronous result pending.
    /// \wi{14020}
    /// The Base library shall provide a method to check if an ::Async_res type is pending.
    /// \param[in] res Asynchronous response to check.
    /// \return True if the asynchronous response is pending, that is, if it is ::async_ongoing or ::async_busy_error,
    /// false otherwise.
    bool is_async_pending(const Async_res res);

    /// Check asynchronous result finished.
    /// \wi{14021}
    /// The Base library shall provide a method to check if an ::Async_res type is finished.
    /// \param[in] res Asynchronous response to check.
    /// \return True if the asynchronous response is finished, that is, if it is ::async_done_ok or
    /// ::async_done_error, false otherwise.
    bool is_async_finished(const Async_res res);
}
#endif

