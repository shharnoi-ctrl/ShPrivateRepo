#ifndef XCFG_FW_H_
#define XCFG_FW_H_

#include <Tundefault_fw.h>

namespace Base
{
    template <typename XCFG, typename TUNTRAIT=Tuntraits::Tundefault<XCFG> >
    struct Xcfg;
}
#endif
