#ifndef TDSYNC_H_
#define TDSYNC_H_

#include <Dsync.h>
#include <Tdsynctraits.h>

namespace Base
{
    /// The Base library shall provide a class to templated data synchronization 
    /// for controlled read and write operations in a concurrent environment. 
    template <typename T, typename TDTRAITRD=Tdsynctraits::Disabled_struct,
            typename TDTRAITWR=Tdsynctraits::Disabled_struct>
    class Tdsync : type_is<T> //PRQA S 1701,1702 #Default copy/operator constructor used
    {
    public:
        /// The Tdsync class shall provide a class to safely write data.
        class Wrsafe
        {
        public:
            T& data; ///< Reference to the templated data being synchronized.

            /// Write Safe Constructor with Given Reference to Templated Data Synchronization.
            /// \wi{6529} 
            /// Wrsafe class shall build itself upon construction and initialize its internal members.
            /// \param[in] tds Reference to a Tdsync object to synchronize.
            Wrsafe(Tdsync<T,TDTRAITRD,TDTRAITWR>& tds);
        private:
            /// Writer synchronization object.
            Dsync::Writer wsync;  // RAII idiom
            Wrsafe();                               ///< = delete.
            Wrsafe(const Wrsafe& orig);             ///< = delete.
            Wrsafe& operator=(const Wrsafe& orig);  ///< = delete.
        };

        /// The Tdsync class shall provide a class to safely read data.
        class Rdsafe0 : public Dsync::Reader // RAII idiom
        {
        public:
            const volatile T& data; ///< Reference to the constant volatile templated data being read.

            /// Read Safe Constructor with Given Reference to 
            /// Constant Volatile Templated Data Synchronization.
            /// \wi{6530}
            /// Rdsafe0 class shall build itself upon construction and initialize its internal members.
            /// \param[in] tds Reference to a constant volatile Tdsync object to synchronize.
            explicit Rdsafe0(const volatile Tdsync<T,TDTRAITRD,TDTRAITWR>& tds);

            /// Read Safe Copy Constructor with Given Reference to Templated RDSAFE.
            /// \wi{21019}
            /// Rdsafe0 class shall build itself upon construction and initialize its internal members.
            /// \param[in] rd Reference to the templated RDSAFE object to synchronize.
            /// \pre Dsync::Reader shall be constructible with a RDSAFE type.
            // - It is required that RDSAFE 'data' member can be assigned to const volatile T& (e.g. child of T).
            // - This method whould allow copy from derived to base (references).
            template<typename RDSAFE>
            explicit Rdsafe0(RDSAFE& rd);

        private:
            Rdsafe0();                                  ///< = delete.
            Rdsafe0(const Rdsafe0& orig);               ///< = delete.
            Rdsafe0& operator=(const Rdsafe0& orig);    ///< = delete.
        };

        /// The Tdsync class shall provide a class to safely read data.
        class Rdsafe //PRQA S 1701,1702 #Default copy/operator constructor used
        {
        public:
            /// Read Safe Default Constructor.
            /// \wi{6531}
            /// Rdsafe class shall build itself upon construction and initialize its internal members.
            Rdsafe();

            /// Read Safe Constructor with Given Reference to Constant Volatile Templated Data Synchronization.
            /// \wi{21020} 
            /// Rdsafe class shall build itself upon construction and initialize its internal members.
            /// \param[in] d0 Reference to a constant volatile Tdsync object to synchronize.
            explicit Rdsafe(const volatile Tdsync<T,TDTRAITRD,TDTRAITWR>& d0);

            /// Read Safe New Reader Checker.
            /// \wi{5211} 
            /// Rdsafe class shall be able to check if the reader object is new.
            /// \return True if the reader object is new, False otherwise. 
            bool is_new() const;

            /// Read Safe Reader Validity Checker.
            /// \wi{5210}
            /// Rdsafe class shall be able to check whether the reader object is currently valid.
            /// \return True if the reader object is valid, False otherwise.
            bool is_valid() const;

            /// Read Safe Synchronous Object Retriever.
            /// \wi{5212} 
            /// Rdsafe class shall be able to retreive the synchronous reader object.
            /// \return The Dsync reader object associated with the Tdsync object.
            Dsync::Reader get_dsync_reader() const;

            /// Read Safe Refresh New Reader.
            /// \wi{5214}
            /// Rdsafe class shall be able to refresh the reader if it is new.
            /// \return True if the reader object can be refreshed, False otherwise.
            bool refresh();

            /// Read Safe Updated Value Retriever.
            /// \wi{5216}
            /// Rdsafe class shall be able to retrieve the updated templated data value. 
            /// \return Reference to the updated templated data value.
            const T& get_updated_value();

            /// Read Safe Last Value Retriever.
            /// \wi{5213}
            /// Rdsafe class shall be able to retrieve the last known templated data value.
            /// \return Reference to the last templated data value.
            const T& get_last_value() const;

        private:
            const volatile Tdsync<T,TDTRAITRD,TDTRAITWR>* d;    ///< Pointer to the constant volatile Tdsync object.
            Dsync::Reader rd;                                   ///< Reader synchronization object.
            T value;                                            ///< Local copy of the templated data value.

            /// Read Safe Refresh Reader.
            /// \wi{5215}
            /// Rdsafe class shall be able to read the templated data value 
            /// and check if reader object is currently valid.
            /// \return True if the reader object is currently valid, False otherwise.
            bool do_refresh();
        };

        Dsync sync; ///< Data synchronization control object.

        /// Templated Data Synchronization Constant Volatile Unsafe Reader.
        /// \wi{21021}
        /// Tdsync class shall be able to retrieve a constant and volatile templated data.
        /// \return Reference to the constant volatile templated data.
        const volatile T& read_unsafe() const volatile;

        /// Templated Data Synchronization Constant Unsafe Reader.
        /// \wi{21022}
        /// Tdsync class shall be able to retrieve a constant templated data.
        /// \return Reference to the constant templated data.
        const T& read_unsafe() const;

        /// Templated Data Synchronization Unsafe Reader.
        /// \wi{6525}
        /// Tdsync class shall be able to retrieve a templated data.
        /// \return Reference to the templated data.
        T& read_unsafe();

        /// Templated Data Synchronization Reader.
        /// \wi{6523}
        /// Tdsync class shall be able to read templated data with policy-defined safety.
        /// \param[in] dst Reference to a templated where the read data shall be stored.
        /// \return A constant volatile Dsync::Reader object which represents 
        /// the synchronization mechanism used for this read operation.
        Dsync::Reader read(T& dst) const volatile;

        /// Templated Data Synchronization Writer.
        /// \wi{6524}
        /// Tdsync class shall be able to write templated data with policy-defined safety.
        /// \param[in] src JSF116_param templated type data that will be written to the synchronized data.
        void write(typename JSF116_param<T>::type src);

        /// Templated Data Synchronization Null Object Reference Retriever.
        /// \wi{6528}
        /// Tdsync class shall be able to retrieve a reference to a null Tdsync object.
        /// \return Constant reference to a null Tdsync object.
        static const Tdsync<T,TDTRAITRD,TDTRAITWR>& get_null();

    private:


        /// Type alias for the Tdsync class with the specified template parameters.
        typedef Tdsync<T,TDTRAITRD,TDTRAITWR> Tdsynctype;

        /// Templated Data Synchronization Null Builder.
        /// \wi{6527}
        /// Tdsync class shall be able to build a null Tdsync object with default values.
        /// \return Null Tdsync object.
        static Tdsynctype build_null();
        
        T data;         ///< Templated data to protect with synchronization.

    };


    /// \alg
    /// <ul>
    /// <li> ::data is initialized with given "tds" templated ::data.
    /// <li> ::wsync is initialized with given "tds" data synchronization control object ::sync.
    /// </ul>
    template <typename T, typename TDTRAITRD, typename TDTRAITWR>
    inline Tdsync<T, TDTRAITRD, TDTRAITWR>::Wrsafe::Wrsafe(Tdsync<T,TDTRAITRD,TDTRAITWR>& tds) :
        data(tds.data),
        wsync(tds.sync)
    {
    }


    /// \alg
    /// <ul>
    /// <li> Dsync::Reader is initialized with given "tds" data synchronization control object ::sync.
    /// <li> ::data is initialized with given "tds" templated ::data.
    /// </ul>
    template <typename T, typename TDTRAITRD, typename TDTRAITWR>
    inline Tdsync<T, TDTRAITRD, TDTRAITWR>::Rdsafe0::Rdsafe0(const volatile Tdsync<T,TDTRAITRD,TDTRAITWR>& tds) :
        Dsync::Reader(tds.sync),
        data(tds.data)
    {
    }

    /// \alg
    /// <ul>
    /// <li> Dsync::Reader is initialized with given parameter "rd".
    /// <li> ::data is initialized with given "rd" templated ::data.
    /// </ul>
    template <typename T, typename TDTRAITRD, typename TDTRAITWR>
    template<typename RDSAFE>
    inline Tdsync<T, TDTRAITRD, TDTRAITWR>::Rdsafe0::Rdsafe0(RDSAFE& rd) :
        Dsync::Reader(rd),  // copy reader
        data(rd.data)       // rd.data must be of type compatible with T&
    {
    }


    /// \alg
    /// <ul>
    /// <li> ::d is initialized with null Tdsync object by calling ::get_null.
    /// <li> ::rd is initialized with pointer ::d data synchronization control object ::sync.
    /// <li> ::value is initialized with default.
    /// </ul>
    template <typename T, typename TDTRAITRD, typename TDTRAITWR>
    inline Tdsync<T, TDTRAITRD, TDTRAITWR>::Rdsafe::Rdsafe() :
        d(&(Tdsync<T,TDTRAITRD,TDTRAITWR>::get_null())),rd(d->sync),
        value()
    {
        // builds null reader
    }

    /// \alg
    /// <ul>
    /// <li> ::d is initialized with given reference parameter "d0".
    /// </ul>
    template <typename T, typename TDTRAITRD, typename TDTRAITWR>
    inline Tdsync<T, TDTRAITRD, TDTRAITWR>::Rdsafe::Rdsafe(const volatile Tdsync<T,TDTRAITRD,TDTRAITWR>& d0) : d(&d0)
    {
        /// <ul>
        /// <li> Call ::do_refresh.
        do_refresh();
        /// </ul>
    }

    template <typename T, typename TDTRAITRD, typename TDTRAITWR>
    inline bool Tdsync<T, TDTRAITRD, TDTRAITWR>::Rdsafe::is_new() const
    {
        /// \alg
        /// Call Dsync::Reader::is_valid for ::rd and return the negated result.
        return !rd.is_valid();
    }

    template <typename T, typename TDTRAITRD, typename TDTRAITWR>
    inline bool Tdsync<T, TDTRAITRD, TDTRAITWR>::Rdsafe::is_valid() const
    {
        /// \alg
        /// Call Dsync::Reader::is_valid for ::rd and return the result.
        return rd.is_valid();
    }

    template <typename T, typename TDTRAITRD, typename TDTRAITWR>
    inline Dsync::Reader Tdsync<T, TDTRAITRD, TDTRAITWR>::Rdsafe::get_dsync_reader() const
    {
        /// \alg
        /// Call Dsync::Reader with ::d data synchronization control object ::sync and return the result. 
        return Dsync::Reader(d->sync);
    }

    template <typename T, typename TDTRAITRD, typename TDTRAITWR>
    inline bool Tdsync<T, TDTRAITRD, TDTRAITWR>::Rdsafe::refresh()
    {
        /// \alg
        /// <ul>
        /// <li> Call ::is_new and if the result is True:
        /// <ul>
        /// <li> Call ::do_refresh and return the result.
        /// </ul>
        /// <li> Else:
        /// <ul>
        /// <li> Return False.
        /// </ul>
        /// </ul>
        return is_new() ? do_refresh() : false;
    }

    template <typename T, typename TDTRAITRD, typename TDTRAITWR>
    inline const T& Tdsync<T, TDTRAITRD, TDTRAITWR>::Rdsafe::get_updated_value()
    {
        Assertions::Compile_time<TDTRAITRD::always_succeed>();
        /// \alg
        /// <ul>
        /// <li> Call ::refresh.
        refresh();
        /// <li> Return ::value.
        return value;
        /// </ul>
    }

    template <typename T, typename TDTRAITRD, typename TDTRAITWR>
    inline const T& Tdsync<T, TDTRAITRD, TDTRAITWR>::Rdsafe::get_last_value() const
    {
        /// \alg
        /// - Return ::value.
        return value;
    }

    template <typename T, typename TDTRAITRD, typename TDTRAITWR>
    inline bool Tdsync<T, TDTRAITRD, TDTRAITWR>::Rdsafe::do_refresh()
    {
        /// \alg
        /// - Call ::read for ::d with ::value and store the result in ::rd.
        rd = d->read(value);
        /// - Call Dsync::Reader::is_valid for ::rd and return the result.
        return rd.is_valid(); // for blocking trait, always true
    }


    template <typename T, typename TDTRAITRD, typename TDTRAITWR>
    inline const volatile T& Tdsync<T, TDTRAITRD, TDTRAITWR>::read_unsafe() const volatile
    {
        /// \alg
        /// - Return ::data.
        return data;
    }

    template <typename T, typename TDTRAITRD, typename TDTRAITWR>
    inline const T& Tdsync<T, TDTRAITRD, TDTRAITWR>::read_unsafe() const
    {
        /// \alg
        /// - Return ::data.
        return data;
    }

    template <typename T, typename TDTRAITRD, typename TDTRAITWR>
    inline T& Tdsync<T, TDTRAITRD, TDTRAITWR>::read_unsafe()
    {
        /// \alg
        /// - Return ::data.
        return data;
    }

    template <typename T, typename TDTRAITRD, typename TDTRAITWR>
    inline Dsync::Reader Tdsync<T, TDTRAITRD, TDTRAITWR>::read(T& dst) const volatile
    {
        /// \alg
        /// - Call TDTRAITRD::copy with ::sync, ::data and "dst" and return the result. 
        return TDTRAITRD::copy(sync,data,dst);
    }

    template <typename T, typename TDTRAITRD, typename TDTRAITWR>
    inline void Tdsync<T, TDTRAITRD, TDTRAITWR>::write(typename JSF116_param<T>::type src)
    {
        /// \alg
        /// - Call TDTRAITRD::copy with ::sync, "src" and ::data and return the result.
        TDTRAITWR::copy(sync,src,data);
    }


    template <typename T, typename TDTRAITRD, typename TDTRAITWR>
    const Tdsync<T, TDTRAITRD, TDTRAITWR>& Tdsync<T, TDTRAITRD, TDTRAITWR>::get_null()
    {
        //WARNING: Parameter-less constructor does not guarantee zero initializetion on Texas C200 COFF.
        /// \alg
        /// - Call ::build_null and store the result in static ::Tdsynctype variable "dnull".
        static Tdsynctype dnull = build_null();// Never written
        /// - Return "dnull".
        return dnull;
    }

    template <typename T, typename TDTRAITRD, typename TDTRAITWR>
    Tdsync<T, TDTRAITRD, TDTRAITWR> Tdsync<T, TDTRAITRD, TDTRAITWR>::build_null()
    {
        /// \alg
        /// - Initialize ::Tdsynctype variable "dnull".
        Tdsynctype dnull;
        /// - Call Dsync::Reader::get_null and store the retrieved result in "dnull" 
        /// data synchronization control object ::sync.
        dnull.sync = Dsync::Reader::get_null();
        /// - Return "dnull".
        return dnull;
    }
}

#endif
