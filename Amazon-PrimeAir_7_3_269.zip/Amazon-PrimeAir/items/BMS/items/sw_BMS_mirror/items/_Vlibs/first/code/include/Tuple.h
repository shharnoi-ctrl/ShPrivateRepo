#ifndef TUPLE_H_
#define TUPLE_H_

namespace Base
{
    /// Tuple Class. This class is able to hold two instances of two different types without relationship between
    /// them but they make sense together.
    template <typename T1, typename T2>
    struct Tuple
    {
        T1 t1;  ///< Instance of Type 1
        T2 t2;  ///< Instance of Type 2
    };
}

#endif
