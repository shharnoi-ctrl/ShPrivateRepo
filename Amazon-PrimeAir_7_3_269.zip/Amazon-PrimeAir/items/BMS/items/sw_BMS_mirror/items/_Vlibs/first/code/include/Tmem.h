#ifndef TMEM_H_
#define TMEM_H_

#include <Vtraits.h>
#include <fpu_vector.h>
#include <string.h>
#include <Rfun.h>

namespace Base
{

    /// Memcpy/memset utils
    ///
    /// IMPORTANT NOTE:
    ///
    /// The compilers guarantee that the memset and memcpy functions expect memory sizes compatible with the
    /// return of the sizeof() function. In the DSP28x family the sizeof() returns number of 16-bit words while
    /// in PC sizeof() returns size in bytes.
    ///
    /// This class assumes that the sizes provided to copy or set data are the result of a sizeof() function
    /// (times the number of elements if necessary), which is the parameter called 'memsize' in this class.
    /// This way the size consistency is ensured across different platforms.
    ///
    class Tmem
    {
    public:

        /// The Tmem class shall provide an auxiliary class to force a cast and to know at compile time if memcpy
        /// fast can be used.
        class Size_u16
        {
        public:

            /// Unsigned Integer 16-bits Casting for Tmem Size Explicit Constructor.
            /// \wi{21368}
            /// Size_u16 class shall build itself upon construction with given size.
            /// \param[in] sz0      Internal size to be casted.
            inline explicit Size_u16(Uint16 sz0) : sz(sz0)
            {
            }
        private:
            friend class Tmem;                             ///< Tmem should be able to access sz.
            Uint16 sz;                                     ///< Internal size.
        };

        /// Maximum value representable with Uint16 (limitation of function memset_fast)
        static const Uint32 words16_max_fast = Base::Lsbmask<Uint32,Ku16::u16>::value;

        /// Memory Utils Data Copy with Templated Maximum Memory Size.
        /// \wi{5222}
        /// Tmem class shall provide the capability to select, on compilation time, an appropriate method to copy, 
        /// for cases where amount of data to copy is a compile time constant.
        /// \param[out] dst     Pointer to data destination.
        /// \param[in] src      Pointer to data source.
        template <Uint32 memsize>
        inline static void cpy(void* dst, const void* src);

        /// Memory Utils Maximum Data Copy with Templated Maximum Memory Size.
        /// \wi{5223}
        /// Tmem class shall provide the capability to select, on compilation time, an appropriate method to copy
        /// the maximum size of data, for cases where amount of data to copy size is a compile time constant.
        /// \param[out] dst     Pointer to data destination.
        /// \param[in] src      Pointer to data source.
        /// \param[in] memsize  Size of the memory to be copied.
        /// \return Memory size copied.
        template <Uint32 memsize_max>
        inline static Uint32 cpy_max(void* dst, const void* src, Uint32 memsize);

        /// Memory Utils Data Copy with Selection Method and Memory Size.
        /// \wi{5224}
        /// Tmem class shall provide the capability to copy the data choosing between memcpy or memcpy_fast
        /// depending on memory size at runtime.
        /// \param[out] dst     Pointer to data destination.
        /// \param[in] src      Pointer to data source.
        /// \param[in] memsize  Size of the memory to be copied.
        static void cpy_sel(void* dst,
                            const void* src,
                            Uint32 memsize);

        /// Memory Utils Data Copy with Size.
        /// \wi{21369}
        /// Tmem class shall provide the capability to select, on compilation time, an appropriate method to copy
        /// with given Uint16 size, for cases where amount of data to copy is a compile time constant.
        /// \param[out] dst     Pointer to data destination.
        /// \param[in] src      Pointer to data source.
        /// \param[in] sz       Size of the data to be copied.
        inline static void cpy(void* dst, const void* src, Size_u16 sz);

        /// Memory Utils Data Setter with Templated Maximum Memory Size.
        /// \wi{5226}
        /// Tmem class shall provide the capability to set the first number of bytes of the block of memory pointed
        /// by a pointer to the specified value.
        /// \param[out] dst     Pointer to data destination.
        /// \param[in] value    Value to set.
        template <Uint32 memsize>
        inline static void set(void* dst, int16 value);

        /// Memory Utils Maximum Data Setter with Templated Maximum Memory Size.
        /// \wi{5228}
        /// Tmem class shall provide the capability to set all bytes of the block of memory pointed by a pointer
        /// to the specified value.
        /// \param[out] dst     Pointer to data destination.
        /// \param[in] value    Value to set.
        /// \param[in] memsize  Size of the memory to be set.
        /// \return Memory size set.
        template <Uint32 memsize_max>
        inline static Uint32 set_max(void* dst, int16 value, Uint32 memsize);

        /// Memory Utils Data Setter with Selection Method and Memory Size.
        /// \wi{5229}
        /// Tmem class shall provide the capability to set the first number of bytes of the block of memory pointed
        /// by a pointer to the specified value choosing between memcpy or memcpy_fast depending on memory size at 
        /// runtime.
        /// \param[out] dst     Pointer to data destination.
        /// \param[in] value    Value to set.
        /// \param[in] memsize  Size of the memory to be set.
        static void set_sel(void* dst,
                            int16 value,
                            Uint32 memsize);

        /// Memory Utils Data Move.
        /// \wi{21370}
        /// Tmem class shall provide the capability to move the data with given memory size.
        /// \param[out] dst     Pointer to data destination.
        /// \param[in] src      Pointer to data source.
        /// \param[in] memsize  Size of the memory to be moved.
        inline static void move(void* dst, const void* src, Uint32 memsize);

    private:
        /// Memcpy method enumerator.
        enum Method
        {
            m_std,      ///< Standard memcpy.
            m_fast,     ///< Fast memcpy.
            m_rtsel     ///< Runtime selection.
        };

        /// Memory Utils Private Data Copy with Templated Method.
        /// \wi{5221}
        /// Tmem class shall provide the capability to copy the values of number of bytes from the location 
        /// pointed to by source directly to the memory block pointed to by destination.
        /// \param[out] dst     Pointer to data destination.
        /// \param[in] src      Pointer to data source.
        /// \param[in] memsize  Size of the memory to be copied.
        template <Method>
        inline static void cpy0(void* dst, const void* src, Uint32 memsize);

        /// Memory Utils Private Data Setter with Templated Method.
        /// \wi{5225}
        /// Tmem class shall provide the capability to set the first number of bytes of the block of memory 
        /// pointed by a pointer to the specified value.
        /// \param[out] dst     Pointer to data destination.
        /// \param[in] value    Value to set.
        /// \param[in] memsize  Size of the memory to be set.
        template <Method>
        inline static void set0(void* dst, int16 value, Uint32 memsize);

        /// Memory Utils Private Maximum Data Copy with Templated Maximum Memory Size.
        /// \wi{21371}
        /// Tmem class shall provide the capability to select, on compilation time, an appropriate method to copy
        /// the maximum size of data, for cases where amount of data to copy size is a compile time constant.
        /// \param[out] dst     Pointer to data destination.
        /// \param[in] src      Pointer to data source.
        /// \param[in] memsize  Size of the memory to be copied.
        /// \return Memory size copied.
        // cpy_max helper
        template <Uint32 memsize_max>
        inline static Uint32 cpy_max0(void* dst, const void* src, Uint32 memsize);

        /// Memory Utils Private Maximum Data Setter with Templated Maximum Memory Size.
        /// \wi{5227}
        /// Tmem class shall provide the capability to set all bytes of the block of memory pointed by a pointer
        /// to the specified value.
        /// \param[out] dst     Pointer to data destination.
        /// \param[in] value    Value to set.
        /// \param[in] memsize  Size of the memory to be set.
        /// \return Memory size set.
        // set_max helper
        template <Uint32 memsize_max>
        inline static Uint32 set_max0(void* dst, int16 value, Uint32 memsize);

        Tmem();                             ///< = delete.
        Tmem(const Tmem& orig);             ///< = delete.
        ~Tmem();
        Tmem& operator=(const Tmem& orig);  ///< = delete.
    };

    // these inline definitions are in this order to make specialization to be defined before usage
    // (explicit specialization of function must precede its first use)

    template <>
    inline void Tmem::cpy0<Tmem::m_std>(void* dst, const void* src, Uint32 memsize)
    {
        /// \alg
        /// Function templated with Method::m_std.
        /// - Call memcpy with given parameters.
        memcpy(dst, src, memsize);
    }

    template <>
    inline void Tmem::cpy0<Tmem::m_fast>(void* dst, const void* src, Uint32 memsize)
    {
        /// \alg
        /// Function templated with Method::m_fast.
        /// - Call memcpy_fast with given parameters.
        memcpy_fast(dst, src, static_cast<Uint16>(memsize));
    }

    template <>
    inline void Tmem::cpy0<Tmem::m_rtsel>(void* dst, const void* src, Uint32 memsize)
    {
        /// \alg
        /// Function templated with Method::m_rtsel.
        /// - Call ::cpy0 with given parameters. Template ::cpy0 with Method::m_fast if given "memsize" parameter
        /// is lower than or equal to ::words16_max_fast, otherwise with Method::m_std.
        (memsize<=Tmem::words16_max_fast) ? cpy0<m_fast>(dst, src, memsize) : cpy0<m_std>(dst, src, memsize);
    }

    template <>
    inline void Tmem::set0<Tmem::m_std>(void* dst, int16 value, Uint32 memsize)
    {
        /// \alg
        /// Function templated with Method::m_std.
        /// - Call memset with given parameters.
        memset(dst, value, memsize);
    }

    template <>
    inline void Tmem::set0<Tmem::m_fast>(void* dst, int16 value, Uint32 memsize)
    {
        /// \alg
        /// Function templated with Method::m_fast.
        /// - Call memset_fast with given parameters.
        memset_fast(dst, value, static_cast<Uint16>(memsize));
    }

    template <>
    inline void Tmem::set0<Tmem::m_rtsel>(void* dst, int16 value, Uint32 memsize)
    {
        /// \alg
        /// Function templated with Method::m_rtsel.
        /// - Call ::set0 with given parameters. Template ::set0 with Method::m_fast if given "memsize" paremeter
        /// is lower than or equal to ::words16_max_fast, otherwise with Method::m_std.
        (memsize<=Tmem::words16_max_fast) ? set0<m_fast>(dst, value, memsize) : set0<m_std>(dst, value, memsize);
    }

    template <Uint32 memsize>
    inline void Tmem::cpy(void* dst, const void* src)
    {
        /// \alg
        /// - Call ::cpy0 with given parameters and templated "memsize" value. Template ::cpy0 with Method::m_fast if
        /// templated "memsize" value is lower than or equal to ::words16_max_fast, otherwise with Method::m_std.
        cpy0<(memsize<=words16_max_fast)?m_fast:m_std>(dst,src,memsize);
    }

    template <Uint32 memsize_max>
    inline Uint32 Tmem::cpy_max0(void* dst, const void* src, Uint32 memsize)
    {
        // assumes memsize already checked to be lower than max
        /// \alg
        /// - Call ::cpy0 with given parameters. Template ::cpy0 with Method::m_fast if templated "memsize_max" value
        /// is lower than or equal to ::words16_max_fast, otherwise with Method::m_rtsel.
        cpy0<(memsize_max<=words16_max_fast)?m_fast:m_rtsel>(dst,src,memsize);
        return memsize;
    }

    template <Uint32 memsize_max>
    inline Uint32 Tmem::cpy_max(void* dst, const void* src, Uint32 memsize)
    {
        /// \alg
        /// - Call ::cpy_max0 with given "dst", "src" and the minimum value between templated "memsize_max" value
        /// and given "memsize" parameter. Template ::cpy_max0 with templated "memsize_max" value.
        return cpy_max0<memsize_max>(dst, src, Rfun::min<Uint32>(memsize_max, memsize));
    }

    inline void Tmem::cpy(void* dst, const void* src, Size_u16 sz)
    {
        /// \alg
        /// - Call memcpy_fast with given parameters "dst" and "src" and Size_u16::sz in given paremeter "sz".
        memcpy_fast(dst, src, sz.sz);
    }

    template <Uint32 memsize>
    inline void Tmem::set(void* dst, int16 value)
    {
        /// \alg
        /// - Call ::set0 with given parameters and templated "memsize" value. Template ::set0 with Method::m_fast if
        /// templated "memsize" is lower than or equal to ::words16_max_fast, otherwise with Method::m_std
        set0<(memsize<=words16_max_fast)?m_fast:m_std>(dst, value, memsize);
    }

    template <Uint32 memsize_max>
    inline Uint32 Tmem::set_max0(void* dst, int16 value, Uint32 memsize)
    {
        // assumes memsize already checked to be lower than max
        /// \alg
        /// - Call ::set0 with given "dst" and "value" parameters and the minimum value between templated 
        /// "memsize_max" value and given "memsize" parameter. Template ::set0 with Method::m_fast if templated
        /// "memsize_max" value is lower than or equal to ::words16_max_fast, otherwise with Method::m_rtsel.
        return set0<(memsize_max<=words16_max_fast)?m_fast:m_rtsel>(dst,
                                                                     value,
                                                                     Rfun::min<Uint32>(memsize_max, memsize));
    }

    template <Uint32 memsize_max>
    inline Uint32 Tmem::set_max(void* dst, int16 value, Uint32 memsize)
    {
        /// \alg
        /// - Call ::set_max0 with templated "memsize_max" value and with given "dst" and "value" parameters and
        ///  the minimum value between templated "memsize_max" value and given "memsize" parameter.
        return set_max0<memsize_max>(dst, value, Rfun::min<Uint32>(memsize_max, memsize));
    }

    inline void Tmem::move(void* dst, const void* src, Uint32 memsize)
    {
        /// \alg
        /// - Call memmove with given parameters.
        memmove(dst, src, memsize);
    }

}

#endif
