#ifndef RMATH_ARM_H_
#define RMATH_ARM_H_

#include <Entypes.h>
#include <math.h>

namespace Rmath // Contains access methods to math.h
{
    inline Real acosr (Real x)
    {
        return acosf(x);
    }

    inline Real asinr (Real x)
    {
        return asinf(x);
    }

    inline Real atanr (Real x)
    {
        return atanf(x);
    }

    inline Real atan2r (Real y, Real x)
    {
        return atan2f(y,x);
    }
    inline Real64 atan2r (Real64 y, Real64 x)
    {
        return atan2(y, x);
    }

    inline Real cosr (Real x)
    {
        return cosf(x);
    }
    inline Real64 cosr (Real64 x)
    {
        return cos(x);
    }

    inline Real sinr (Real x)
    {
        return sinf(x);
    }
    inline Real64 sinr (Real64 x)
    {
        return sin(x);
    }

    inline Real tanr (Real x)
    {
        return tanf(x);
    }

    inline Real tanhr(Real x)
    {
        return tanhf(x);
    }

    inline Real expr (Real x)
    {
        return expf(x);
    }

    inline Real expm1r(Real x)
    {
        return expm1f(x);
    }

    inline Real logr (Real x)
    {
        return logf(x);
    }

    inline Real fabsr (Real x)
    {
        return fabsf(x);
    }
    inline Real64 fabsr (Real64 x)
    {
        return fabs(x);
    }

    inline Real powr (Real x, Real y)
    {
        return powf(x,y);
    }
    inline Real64 powr (Real64 x, Real64 y)
    {
        return pow(x,y);
    }

    inline Real sqrtr (Real x)
    {
        return sqrtf(x);
    }
    inline Real64 sqrtr (Real64 x)
    {
        return sqrt(x);
    }

    inline Real ceilr (Real x)
    {
        return ceilf(x);
    }

    inline Real floorr (Real x)
    {
        return floorf(x);
    }
    inline Real64 floorr (Real64 x)
    {
        return floor(x);
    }

    inline Real fmodr (Real x, Real y)
    {
        return fmodf(x,y);
    }

    inline Real copysignr (Real x, Real y)
    {
        return copysignf(x,y);
    }
    inline Real64 copysignr (Real64 x, Real64 y)
    {
        return copysign(x, y);
    }

    inline Real log10r (Real x)
    {
        return log10f(x);
    }

    /// Round Real.
    /// \wi{19816}
    /// The round function shall return the nearest integral (as a Real value) to the one passed as argument. Some
    /// examples:
    /// <ul>
    ///     <li> Input: 2.3 returns 2.0
    ///     <li> Input: 3.8 returns 4.0
    ///     <li> Input: 5.5 returns 6.0
    ///     <li> Input: -2.3 returns -2.0
    ///     <li> Input: -3.8 returns -4.0
    ///     <li> Input: -5.5 returns -6.0
    /// </ul>
    /// \param[in] Input floating point to compute the nearest integral number.
    /// \returns Nearest integral number to the input.
    inline Real roundr(Real x)
    {
        return roundf(x);
    }
    inline Real64 roundr(Real64 x)
    {
        return round(x);
    }
}
#endif
