//
// Rtable_fw.h
//
//  Created on: 2 jun. 2020
//      Author: jsf3
//

#ifndef INCLUDE_RTABLE_FW_H_
#define INCLUDE_RTABLE_FW_H_

namespace Maverick
{
    class Rtable;
}


#endif // INCLUDE_RTABLE_FW_H_ //
