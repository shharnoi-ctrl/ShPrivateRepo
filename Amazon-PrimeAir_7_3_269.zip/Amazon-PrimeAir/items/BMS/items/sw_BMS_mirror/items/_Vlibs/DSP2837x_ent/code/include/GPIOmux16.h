#ifndef GPIOMUX16_H_
#define GPIOMUX16_H_

#include <Enums.h>

namespace Dsp28335_ent
{
    /// MUX for GPIO onto 28377 platforms.
    struct GPIOmux16
    {
    public:
        /// MUX values available.
        enum Type_mux
        {
            mux_0,  ///< MUX 0.
            mux_1,  ///< MUX 1.
            mux_2,  ///< MUX 2.
            mux_3,  ///< MUX 3.
            mux_4,  ///< MUX 4.
            mux_5,  ///< MUX 5.
            mux_6,  ///< MUX 6.
            mux_7,  ///< MUX 7.
            mux_8,  ///< MUX 8.
            mux_9,  ///< MUX 9.
            mux_10, ///< MUX 10.
            mux_11, ///< MUX 11.
            mux_12, ///< MUX 12.
            mux_13, ///< MUX 13.
            mux_14, ///< MUX 14.
            mux_15, ///< MUX 15.

            mux_gpio = mux_0    ///< GPIO Mux (Mux 0).
            // if this enum is updated, change is_valid method
        };

        /// Multiplexor Validator.
        /// \wi{17359}
        /// GPIOmux16 class shall be able to identify if a received multiplexor type is a valid one.
        /// \return True if provided MUX value is greater of equals to zero and strictly smaller than maximum from
        /// enumerator ::Type_mux.
        static bool is_valid(Type_mux mux_sel);
    private:
        GPIOmux16(); ///< = delete
        GPIOmux16(const GPIOmux16& orig); ///< = delete
        GPIOmux16& operator=(const GPIOmux16& orig); ///< = delete
    };

    inline bool GPIOmux16::is_valid(Type_mux mux)
    {
        return Base::Enums::is_gtez(mux) && (mux <= mux_15);
    }
}
#endif
