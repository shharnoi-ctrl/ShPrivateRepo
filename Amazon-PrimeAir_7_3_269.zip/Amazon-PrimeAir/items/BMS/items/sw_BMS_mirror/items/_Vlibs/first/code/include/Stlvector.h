#ifndef STLVECTOR_H__
#define STLVECTOR_H__

#include <Array.h>

namespace Base
{
    /// The ::Base library shall provide a class to manage a vector instance as an array with the ability to 
    /// resize itself automatically when an element is inserted or deleted.
    template <class T>
    class Stlvector
    {
    public:
        /// STL for Vector Constructor with Given Parameters.
        /// \wi{5174}
        /// Stlvector class shall build itself upon construction with the given parameters.
        /// \param[in] n0 Array size.
        /// \param[in] memtype Memory type.
        Stlvector(Uint16 n0,Memmgr::Type memtype);
        /// STL for Vector Constructor with Given Parameters.
        /// \wi{5175}
        /// Stlvector class shall build itself upon construction with the given parameters.
        /// \param[in] n0 Array size.
        /// \param[in] memtype Memory type.
        /// \param[in] param0 First argument used to build all Array elements.
        template<typename T0>
        Stlvector(Uint16 n0,Memmgr::Type memtype, T0 param0);
        /// STL for Vector Constructor with Given Parameters.
        /// \wi{19812}
        /// Stlvector class shall build itself upon construction with the given parameters.
        /// \param[in] n0 Array size.
        /// \param[in] memtype Memory type.
        /// \param[in] param0 First argument used to build all Array elements.
        /// \param[in] param1 Second argument used to build all Array elements.
        template<typename T0, typename T1>
        Stlvector(Uint16 n0,Memmgr::Type memtype, T0 param0, T1 param1);

        /// STL for Vector Empty Checker.
        /// \wi{5176}
        /// Stlvector class shall provide the capability to determine if an instance of the class contains an 
        /// empty vector.
        /// \return True if the vector is empty, False otherwise.
        bool empty()const;
        /// STL for Vector Last Element Retriever.
        /// \wi{5178}
        /// Stlvector class shall be able to retrieve the last element of the vector.
        /// \return Reference to the last element of the vector
        T& back();
        /// STL for Vector Current Size Retriever.
        /// \wi{5180}
        /// Stlvector class shall provide the capability to provide the number of elements contained 
        /// in the internal vector data.
        /// \return The number of elements used.
        Uint32 end()const;
        /// STL for Vector Maximum Size Retriever.
        /// \wi{5179}
        /// Stlvector class shall provide the capability to provide the maximum number of elements that can be 
        /// contained in the internal vector data.
        /// \return Maximum size of the vector.
        Uint32 size()const;

        /// STL for Vector Elements Exceed Checker.
        /// \wi{5182}
        /// Stlvector class shall provide the capability to determine if the max number of contained elements
        /// is exceeded.
        /// \return True if vector is full, False otherwise.
        bool is_full() const;
    
        /// STL for Vector New Element Addition.
        /// \wi{5183}
        /// Stlvector class shall provide the capability to add a new element at the end of the vector.
        /// \param[in] u    Element to be added.
        /// \return True if element is succesfully added, False otherwise.
        bool push_back(const T& u);
        /// STL for Vector One Last Element Addition.
        /// \wi{5184}
        /// Stlvector class shall provide the capability to increase the size of the vector by one, allocating 
        /// memory for one more element, returning its reference.
        /// \return Reference to the new last element of the vector.
        T& push();

        /// STL for Vector Reset.
        /// \wi{5185}
        /// Stlvector class shall provide the capability to reset the vector.
        void reset();
        /// STL for Vector First Element Retriever.
        /// \wi{5186}
        /// Stlvector class shall be able to retrieve the first element of the vector.
        /// \return Reference to the first element of the vector.
        T* first();
        /// STL for Vector Constant First Element Retriever.
        /// \wi{19814}
        /// Stlvector class shall be able to retrieve the first element of the vector.
        /// \return Constant reference to the first element of the vector.
        const T* first()const;
        /// STL for Vector Last Element Retriever.
        /// \wi{5177}
        /// Stlvector class shall be able to retrieve the last element of the vector.
        /// \return Reference to the last element of the vector.
        T* last();
        /// STL for Vector Constant Last Element Retriever.
        /// \wi{19815}
        /// Stlvector class shall be able to retrieve the last element of the vector.
        /// \return Constant reference to the last element of the vector.
        const T* last()const;
        /// STL for Vector Index Value Retriever.
        /// \wi{5187}
        /// The Stlvector shall be able to retrieve the index of an element contained in the vector.
        /// \param[in] value Value to be searched.
        /// \return Index of the position where the value is found, -1 if it is not found.
        int32 get_index_of(const T& value) const;
        /// STL for Vector [] Operator.
        /// \wi{5188}
        /// Stlvector class shall provide the capability to retrieve a reference to the element at given index.
        /// \param[in] i    Index in the fixed-size array.
        /// \return         Reference to the element at given index.
        /// \pre            Assume that provided index is not out of bounds.
        T& operator[](Uint32 i);
        /// STL for Vector Constant [] Operator.
        /// \wi{20030}
        /// Stlvector class shall provide the capability to retrieve a reference to the element at given index.
        /// \param[in] i    Index in the fixed-size array.
        /// \return         Constant reference to the element at given index.
        /// \pre            Assume that provided index is not out of bounds.
        const T& operator[](Uint32 i)const;
        /// STL for Vector Constant Volatile [] Operator.
        /// \wi{20031}
        /// Stlvector class shall provide the capability to retrieve a reference to the element at given index.
        /// \param[in] i    Index in the fixed-size array.
        /// \return         Constant Volatile reference to the element at given index.
        /// \pre            Assume that provided index is not out of bounds.
        const volatile T& operator[](Uint32 i)const volatile;
        /// STL for Vector Value Contained Request.
        /// \wi{5189}
        /// Stlvector class shall provide the capability to determine if an element is contained in the vector.
        /// \param[in] value Value to be compared.
        /// \return True if the element is contained in the vector, False otherwise.
        bool has(const T& value) const;
        /// STL for Vector Zero Setter.
        /// \wi{5190}
        /// Stlvector class shall provide the capability set 0 to all the contained elements.
        void zeros();
        /// STL for Vector Resizer.
        /// \wi{5191}
        /// Stlvector class shall provide the capability resize the vector.
        /// \param[in] n0   New size.
        void resize(Uint32 n0);
        /// STL for Vector Constant Array Retriever.
        /// \wi{5193}
        /// Stlvector class shall be able to retrieve the internal Array.
        /// \return Constant reference to its internal array.
        const Array<T>& get_arr()const;
        /// STL for Vector Copier
        /// \wi{5192}
        /// Stlvector class shall provide the capability to copy the content of an instance of the class to another 
        /// instance.
        /// \param[in] v0       Array reference to copy the content.
        /// \param[in] src_pos  Current pointer to first element.    
        /// \param[in] dst_pos  Pointer to first element of the given Array.
        /// \param[in] len      Length of the Array.
        void copy(const Stlvector<T>& v0,
                  Uint32 src_pos,
                  Uint32 dst_pos,
                  Uint32 len);
        /// STL for Vector Element Remover.
        /// \wi{5194}
        /// Stlvector class shall provide the capability to remove an element from the vector.
        /// \param[in] idx      Index of the element to be removed.
        void remove(Uint32 idx);

    private:
        Array<T> v;     ///< Templated Array.

        Stlvector();                                    ///< = delete.
        Stlvector(const Stlvector& copy);               ///< = delete.
        Stlvector& operator= (const Stlvector& copy);   ///< = delete.
    };


    template <typename T>
    inline Stlvector<T>::Stlvector(Uint16 n0,Memmgr::Type memtype):
        v(n0,memtype)
    {
        /// \alg
        /// - Initialize ::v with the given parameters.
        /// - Call Array::resize for ::v with 0 value.
        v.resize(0);
    }

    template <typename T>
    template<typename T0>
    Stlvector<T>::Stlvector(Uint16 n0,Memmgr::Type memtype, T0 param0):
        v(n0,memtype, param0)
    {
        /// \alg
        /// - Initialize ::v with the given parameters.
        /// - Call Array::resize for ::v with 0 value.
        v.resize(0);
    }

    template <typename T>
    template<typename T0, typename T1>
    Stlvector<T>::Stlvector(Uint16 n0,Memmgr::Type memtype, T0 param0, T1 param1):
        v(n0,memtype, param0, param1)
    {
        /// \alg
        /// - Initialize ::v with the given parameters.
        /// - Call Array::resize for ::v with 0 value.
        v.resize(0);
    }

    template <typename T>
    inline bool Stlvector<T>::empty()const
    {
        /// \alg
        /// - Return True if retrieved value by Array::size for ::v is equal to 0, False otherwise.
        return (v.size()==0);
    }

    template <typename T>
    inline T& Stlvector<T>::back()
    {
        /// \alg
        /// - Return reference of the retrieved value by Array::last for ::v.
        return *v.last();
    }

    template <typename T>
    inline Uint32 Stlvector<T>::end()const
    {
        /// \alg
        /// - Return retrieved value by Array::size for ::v.
        return v.size();
    }

    template <typename T>
    inline Uint32 Stlvector<T>::size()const
    {
        /// \alg
        /// - Return retrieved value by Array::size_max for ::v.
        return v.size_max();
    }

    template <typename T>
    inline bool Stlvector<T>::is_full() const
    {
        /// \alg
        /// - Return True if current size is greater than or equal to maximum size of Stlvector, False otherwise.
        return v.size() >= v.size_max();
    }

    template <typename T>
    bool Stlvector<T>::push_back(const T& u)
    {
        /// \alg
        /// <ul>
        /// <li> If current size is lower than maximum size of Stlvector:
        bool b=(v.size() < v.size_max());
        if(b)
        {
            /// <ul>
            /// <li> Call Array::resize for ::v with current Stlvector size plus 1.
            v.resize(v.size()+1);
            /// <li> Set last index value to given value.
            *v.last()=u;
            /// <li> Return True.
            /// </ul>
        }
        /// <li> Otherwise, return False.
        /// </ul>
        return b;
    }

    template <typename T>
    inline T& Stlvector<T>::push()
    {
        /// \alg
        /// - Call Array::resize for ::v with current Stlvector size plus 1.
        v.resize(v.size()+1);
        /// - Return retrieved pointer value by Array::last for ::v as a reference.
        return (*v.last());
    }

    template <typename T>
    inline void Stlvector<T>::reset()
    {
        /// \alg
        /// - Call Array::resize for ::v with 0.
        v.resize(0);
    }

    template <typename T>
    inline T* Stlvector<T>::first()
    {
        /// \alg
        /// - Return retrieved value by Array::first for ::v.
        return v.first();
    }

    template <typename T>
    inline const T* Stlvector<T>::first()const
    {
        /// \alg
        /// - Return retrieved value by Array::first for ::v.
        return v.first();
    }

    template <typename T>
    inline T* Stlvector<T>::last()
    {
        /// \alg
        /// - Return retrieved value by Array::last for ::v.
        return v.last();
    }

    template <typename T>
    inline const T* Stlvector<T>::last()const
    {
        /// \alg
        /// - Return retrieved value by Array::last for ::v.
        return v.last();
    }

    template <typename T>
    inline int32 Stlvector<T>::get_index_of(const T& value) const
    {
        /// \alg
        /// - Return retrieved value by Array::get_index_of for ::v.
        return v.get_index_of(value);
    }

    template <typename T>
    inline T& Stlvector<T>::operator[](Uint32 i)
    {
        /// \alg
        /// - Return value of the Array at given position.
        return v[i];
    }

    template <typename T>
    inline const T& Stlvector<T>::operator[](Uint32 i)const
    {
        /// \alg
        /// - Return value of the Array at given position.
        return v[i];
    }

    template <typename T>
    inline const volatile T& Stlvector<T>::operator[](Uint32 i)const volatile
    {
        /// \alg
        /// - Return value of the Array at given position.
        return v[i];
    }

    template <typename T>
    inline bool Stlvector<T>::has(const T& value) const
    {
        /// \alg
        /// - Return retrieved value by Array::has for ::v with given value.
        return v.has(value);
    }

    template <typename T>
    inline void Stlvector<T>::zeros()
    {
        /// \alg
        /// - Call Array::zeros for ::v.
        v.zeros();
    }

    template <typename T>
    inline void Stlvector<T>::resize(Uint32 n0)
    {
        /// \alg
        /// - Call Array::resize for ::v with given value size.
        v.resize(n0);
    }

    template <typename T>
    inline const Array<T>& Stlvector<T>::get_arr()const
    {
        /// \alg
        /// - Return ::v.
        return v;
    }

    template <typename T>
    inline void Stlvector<T>::copy(const Stlvector<T>& v0,
                                   Uint32 src_pos,
                                   Uint32 dst_pos,
                                   Uint32 len)
    {
        /// \alg
        /// - Call Array::copy for ::v with given Array, source position, destination position and length.
        v.copy(v0.get_arr(), src_pos, dst_pos, len);
    }

    template <typename T>
    inline void Stlvector<T>::remove(Uint32 idx)
    {
        /// \alg
        /// - Call Array::remove for ::v with given index.
        v.remove(idx);
    }

}
#endif
