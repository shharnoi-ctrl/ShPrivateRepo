//PRQA S 4114 EOF
//#Code readability is preferred over declarations being on the smallest feasible scope
//PRQA S 5051 EOF
//#Identifiers will be kept by default
//PRQA S 5052 EOF
//#Identifiers will be kept by default

#include <Asm.h>
#include <Bldr.h>
#include <Cpusys.h>
#include <Delay.h>
#include <Devcfg.h>
#include <GPIOioctl.h>
#include <GPIOtun.h>
#include <Emif1.h>
#include <Flash.h>
#include <Ipc.h>
#include <ISRmgr.h>
#include <Kclk.h>
#include <Memcfg.h>
#include <Piectrl.h>
#include <Pll.h>
#include <Reset.h>
#include <System.h>
#include <Sysuid.h>
#include <Sysaddr.h>
#include <Watchdog.h>

#include "../common/Analog_subsys.h" //PRQA S 1015
#include "../common/Clkcfgb.h" //PRQA S 1015

namespace
{
    /// This variable cannot be initialized due to if it is, cannot be changed.
    static bool force_bootloader;
}

namespace Bsp
{
    bool get_force_bootloader()
    {
        return force_bootloader;
    }
}

namespace Dsp28335_ent
{
    static void setup_emif1_pinmux_async_16bit_20_21_addr(GPIOid ba1, GPIOmux16::Type_mux ba1_mux, GPIOid alast)
    {
        static const GPIOid gpio_em1clk    = gpio_030;
        static const GPIOid gpio_em1we     = gpio_031;
        static const GPIOid gpio_notem1cs2 = gpio_034;
        static const GPIOid gpio_em1oe     = gpio_037;
        const GPIOid gpio_em1ba1           = ba1;
        static const GPIOid gpio_em1a0     = gpio_038;
        static const GPIOid gpio_em1a12    = gpio_052;
        static const GPIOid gpio_em1a13    = gpio_086;
        const GPIOid gpio_em1a_last        = alast; // A18 or A19
        static const GPIOid gpio_data_from = gpio_069;
        static const GPIOid gpio_data_to   = gpio_085;

        //Ctrl pins
        static const GPIOtun gpio_in_pulldis_mux2_qsync =
        {
                GPIOtun::dir_input,
                GPIOtun::pu_dis,
                GPIOmux16::mux_2,
                GPIOtun::qsel_sync
        };
        GPIOioctl::apply(gpio_em1clk,    gpio_in_pulldis_mux2_qsync); // EM1CLK
        GPIOioctl::apply(gpio_em1we,     gpio_in_pulldis_mux2_qsync); // EM1WE
        GPIOioctl::apply(gpio_notem1cs2, gpio_in_pulldis_mux2_qsync); // !EM1CS2
        GPIOioctl::apply(gpio_em1oe,     gpio_in_pulldis_mux2_qsync); // EM1OE

        //Address pins
        GPIOioctl::apply(gpio_em1ba1,
                       GPIOtun::build(GPIOtun::dir_input,
                                      GPIOtun::pu_dis,
                                      ba1_mux,
                                      GPIOtun::qsel_sync));                     // EM1BA1 (A0)
        for(Uint16 i=gpio_em1a0; i<=gpio_em1a12; i++)                           // EM1A0 - EM1A12 (A1 - A13)
        {
            if ((i != Ku16::u42) && (i != Ku16::u43))
            {
                GPIOioctl::apply(GPIOid(i), gpio_in_pulldis_mux2_qsync);
            }
        }
        for(Uint16 i=gpio_em1a13; i<=gpio_em1a_last; i++)                          // EM1A13 - EM1A18 (A14 - A19)
        {
            GPIOioctl::apply(GPIOid(i), gpio_in_pulldis_mux2_qsync);
        }

        //Data Pins
        static const GPIOtun gpio_in_pullen_mux2_qasync =
        {
                GPIOtun::dir_input,
                GPIOtun::pu_en,
                GPIOmux16::mux_2,
                GPIOtun::qsel_async
        };
        for(Uint16 i=gpio_data_from; i<=gpio_data_to; i++)
        {
            if (i != gpio_084)
            {
                GPIOioctl::apply(GPIOid(i), gpio_in_pullen_mux2_qasync);
            }
        }
    }

    void init_emif1(System::Ext_mem_size size)
    {
        // Initialize EMIF1 to a known state
        // Perform a Module soft reset on EMIF
        Devcfg dc;
        dc.soft_reset(Devcfg::spr_emif1);

        // Grab EMIF1 For CPU1
        Emif1 em1;
        em1.cpu1_grab();

        //Start EMIF1 clock
        Cpusys cs;
        cs.clk_enable(Cpusys::clk_emif1);

        //Configure to run EMIF1 on full Rate (EMIF1CLK = CPU1SYSCLK)
        Clkcfgb ccfgb;
        ccfgb.set_emif1_clk_div_sel(Clkcfgb::emif1_div_by_1);

        // Configure the GPIO for EMIF1 with a 16-bit data bus 19-bit address width

        switch(size)
        {
            case System::mem_1MW:
            {
                setup_emif1_pinmux_async_16bit_20_21_addr(Dsp28335_ent::gpio_092, GPIOmux16::mux_3, Dsp28335_ent::gpio_091);
                break;
            }
            case System::mem_2MW:
            {
                setup_emif1_pinmux_async_16bit_20_21_addr(Dsp28335_ent::gpio_094, GPIOmux16::mux_9, Dsp28335_ent::gpio_092);
                break;
            }
            case System::mem_none:
            default:
            {
                break;
            }
        }

        //Configure the access timing for CS2 space
        em1.set_async_cs2_cr_veronte4();

        //Force a pipeline flush to ensure that the write to
        //the last register configured occurs before returning.
        asm_pipeline_flush7();
    }

    // IMPORTANT NOTE: This code is called before call to .cinit0, so
    // global variables are not initialized yet. Early execution of this
    // lines allow ebss initialized memory to be allocated into external ram.
    // Otherwise, ebss allocated on external RAM would not be initialized.
    // Failure case if not done: static local object (singleton, get_instance
    // method) never calls contructor.
    // NOTE: xtal_freq is ignored. I maintainde for compatiblity with 2838x initialization.
    extern void init_sys_cpu1_0()
    {
        // Watchdog was disabled in "DSP28x_CodeStartBranch.asm"

        /// Step 1. Disable IRQ:
        /// At entering the bootloader from running application,
        /// previously configured IRQ shall be disabled.
        asm_dint();

        // Step 2. Initialize System Control:
        // PLL, WatchDog, enable Peripheral Clocks
        // This example function is found in the F2837xD_SysCtrl.c file.

        // Enable pull-ups on unbounded IOs as soon as possible to reduce power consumption.
        //GPIO_EnableUnbondedIOPullups();   //EMB:

        // Initialize the PLL control: SYSPLLMULT and SYSCLKDIVSEL.
        // Note: The internal oscillator CANNOT be used as the PLL source if the
        // PLLSYSCLK is configured to frequencies above 194 MHz.
        //
        //  PLLSYSCLK = (XTAL_OSC) * (IMULT + FMULT) / (PLLSYSCLKDIV)
        //
        PLL::pll_sys_init();
    }

    // IMPORTANT NOTE: This code is called before call to .cinit0, so
    // global variables are not initialized yet. Early execution of this
    // lines allow ebss initialized memory to be allocated into external ram.
    // Otherwise, ebss allocated on external RAM would not be initialized.
    // Failure case if not done: static local object (singleton, get_instance
    // method) never calls contructor.
    extern void init_sys_cpu1(System::Ext_mem_size size)
    {
        // Initialize PLL
        init_sys_cpu1_0();

        /// Initialize external memory driver
        init_emif1(size);
    }

    // IMPORTANT NOTE: This code is called before call to .cinit0, so
    // global variables are not initialized yet. Early execution of this
    // lines allow ebss initialized memory to be allocated into external ram.
    // Otherwise, ebss allocated on external RAM would not be initialized.
    // Failure case if not done: static local object (singleton, get_instance
    // method) never calls contructor.
    extern void init_sys_cpu1_bldr(Uint32 reset_value)
    {
        force_bootloader = (reset_value == Bsp::force_bldr_value);
        init_sys_cpu1_0();

        Dsp28335_ent::Devcfg::cpu2_hold_reset();    // CPU2 off, also, flash pump is back to default(CPU1)
        Dsp28335_ent::Memcfg::gsram_msel_set(0);    // GSRAM for cpu1
        Delay::ms(10);
    }

    extern void post_init_sys_cpu1_bldr()
    {
        Bsp::set_sysaddr(Base::Address(static_cast<Base::Address0::Id_t>(Bsp::get_uid().phy)));

        // Call Flash Initialization to setup flash waitstates
        Flash::init();

        // Step 3. Clear all interrupts and initialize PIE vector table:
        // Disable CPU interrupts
        asm_dint();
        asm_drtm();

        // Initialize the PIE control registers to their default state.
        // The default state is all PIE interrupts disabled and flags
        // are cleared.
        Piectrl::init();

        // Disable CPU interrupts and clear all CPU interrupt flags:
        // Set all ISR to point to a reset ISR
        ISRmgr::init();

    }

    extern void post_init_sys_cpu1(bool is_dual_core, bool emif1_for_c2)
    {
        Bsp::set_sysaddr(Base::Address(Bsp::get_uid().phy));

        Cpusys cs;
        cs.clk_enable(Cpusys::clk_adc_all);

        // Check if device is trimmed
        if(*(reinterpret_cast<Uint16 *>(0x5D1B6)) == 0x0000)
        {
            // Device is not trimmed--apply static calibration values
            Analog_subsys::apply_static_calibration();
        }

        cs.clk_disable(Cpusys::clk_adc_all);

        // other CPU waits for this init and "ungrabbed" EMIF.
        if(emif1_for_c2)
        {
            Emif1 em1;
            em1.assert_is_grabbed_by_cpu1();
            em1.ungrab();
        }

        // if no JTAG connected or watchdog reset, launch CPU2 boot
        if((!cs.is_jtag_connected()) || cs.is_reset_wdog_flag())
        {
            cs.clear_reset_wdog_flag(); // clear flag to ensure next reboot can detect condition again.
            if(is_dual_core)
            {
                // Send boot command to allow the CPU2 application to begin execution
                Ipc::get_instance().cpu1_boot_cpu2();
            }
        }

        // Signals to CPU2 that it can continue it's execution flow.
        if(is_dual_core)
        {
            Ipc::get_instance().cpu2_unlock();
        }

        //NOTE: ADC clock setting has been moved to adif ADC_if::init()

        // Call Flash Initialization to setup flash waitstates
        Flash::init();

        // Step 3. Clear all interrupts and initialize PIE vector table:
        // Disable CPU interrupts
        asm_dint();
        asm_drtm();

        // Initialize the PIE control registers to their default state.
        // The default state is all PIE interrupts disabled and flags
        // are cleared.
        Piectrl::init();

        // Disable CPU interrupts and clear all CPU interrupt flags:
        // Set all ISR to point to a reset ISR
        ISRmgr::init();


        Ipc::get_instance().reset_flags();
    }

    extern void post_init_sys_cpu1_sc()
    {
        post_init_sys_cpu1(false, false);
    }

    extern void init_sys_fboot(Uint32 reset_value)
    {
        force_bootloader = (reset_value == Bsp::force_bldr_value);
    }

    /// This method shall be in RAM or it will crash the system when called from firmware update.
    void System::cpu_reset()
    {
        while(true)
        {
            Watchdog::setup_for_reset();
        }
    }
}
