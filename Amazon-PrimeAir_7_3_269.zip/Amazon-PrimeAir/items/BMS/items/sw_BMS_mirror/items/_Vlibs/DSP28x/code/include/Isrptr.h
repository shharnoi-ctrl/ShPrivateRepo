#ifndef ISRPTR_H_
#define ISRPTR_H_

namespace Dsp28335_ent
{
    typedef interrupt void(*Isrptr)(void);
}
#endif
