#ifndef IDESERIALIZABLE_H_
#define IDESERIALIZABLE_H_

#include <Lossy_error_fw.h>

namespace Base
{
    /// Synchronous interface for deserializable objects
    class Ideserializable
    {
    public:
        /// description: This function is used to parse the data from the input parameter str into the
        /// data members of the class (Deserialization).
        /// param str: Array of data, with the encoding format (big, little, mixed endian)
        virtual void cset(Lossy_error& str) = 0;
    protected:
        ~Ideserializable(); ///< Base virtual destructor
    };

    inline Ideserializable::~Ideserializable() //PRQA S 2635 #destructor replaced with default
    {
    }
}
#endif
