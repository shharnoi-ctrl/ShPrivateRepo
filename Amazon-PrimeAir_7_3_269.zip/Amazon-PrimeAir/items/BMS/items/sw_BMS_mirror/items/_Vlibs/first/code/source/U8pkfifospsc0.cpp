#include <U8pkfifospsc0.h>

namespace Base
{
    U8pkfifospsc0::U8pkfifospsc0(U8pkmblock& buf0, Uint32& rd0, Uint32& wr0) :
            v(buf0),
            rd(rd0),
            wr(wr0)
    {
    }

  
    bool U8pkfifospsc0::write(Uint8 element)
    {
        /// \alg
        /// <ul>
        /// <li> Calculate the next write pointer.
        Uint32 nxt = next(wr);
        /// <li> Check if there is space available for writing.
        bool ret = rd != nxt;
        /// <li> If space is available, write the byte to the queue as follows:
        if(ret)
        {
            /// <ul>
            /// <li> Write the byte into the memory block.
            /// <li> Update the write pointer to the next pointer.
            /// </ul>
            v.set(wr, element);
            wr = nxt;
        }
        /// <li> Return True if writing was successful, else return False.
        return ret;
        /// </ul>
    }

    
    bool U8pkfifospsc0::read(Uint8& element)
    {
        /// \alg
        /// <ul>
        /// <li> Check if there is a new byte available for reading.
        bool ret = rd_available();
        /// <li> If there is a byte available for reading, read it from the queue as follows:
        if(ret)
        {
            /// <ul>
            /// <li> Calculate the next read pointer.
            /// <li> Read the byte from the memory block.
            /// <li> Update the read pointer to the next pointer.
            /// </ul>
            Uint32 nxt = next(rd);
            element = v.get(rd);
            rd=nxt;
        }
        /// <li> Return True if reading was successful, else return False.
        return ret;
        /// </ul>
    }
}
