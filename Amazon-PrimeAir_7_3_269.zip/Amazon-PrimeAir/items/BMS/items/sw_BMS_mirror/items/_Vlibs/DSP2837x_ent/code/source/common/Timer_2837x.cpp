#include <Timer.h>
#include <Hregmap.h>
#include <Asm.h>
#include <Cpusys.h>
#include <ISRmgr.h>

#include "Piectrl.h" //PRQA S 1015

namespace Dsp28335_ent
{
    volatile Timer::Cputimer_regs& Timer::get_regs(Timer::Id id0)
    {
        // Enable SCI clock and select registers.
        static const Uint32 hw_addr_tmr0 = 0xC00UL;
        volatile Timer::Cputimer_regs* result = &Hregmap::get<Timer::Cputimer_regs,hw_addr_tmr0>();

        Cpusys cs;
        switch(id0)
        {
            case Timer::timer0:
            {
                cs.clk_enable(Cpusys::clk_timer0);
                break;
            }
            case Timer::timer1:
            {
                static const Uint32 hw_addr_tmr1 = 0xC08UL;
                result = &Hregmap::get<Timer::Cputimer_regs,hw_addr_tmr1>();
                cs.clk_enable(Cpusys::clk_timer1);
                break;
            }
            case Timer::timer2:
            {
                static const Uint32 hw_addr_tmr2 = 0xC10UL;
                result = &Hregmap::get<Timer::Cputimer_regs,hw_addr_tmr2>();
                cs.clk_enable(Cpusys::clk_timer2);
                break;
            }
        }

        return *result;
    }

    void Timer::pie_enable(Id id0, Isrptr p_isr)
    {
        switch (id0)
        {
            case timer0:
            {
                Piectrl::enable_pie();      // Ensure PIE is enabled
                ISRmgr::set_isr(ISRmgr::timer0_int, p_isr);
                static const Piectrl::Mid mid_tmr0 = { Piectrl::grp01, Piectrl::flag_int07 };
                Piectrl::enable(mid_tmr0);
                break;
            }
            case timer1:
            {
                ISRmgr::set_isr(ISRmgr::timer1_int, p_isr);
                Piectrl::enable_nmi_tmr1();
                break;
            }
            case timer2:
            {
                ISRmgr::set_isr(ISRmgr::timer2_int, p_isr);
                Piectrl::enable_nmi_tmr2();
                break;
            }
        }
    }
}
