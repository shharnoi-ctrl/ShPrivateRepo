#ifndef SCICFG_FW_H_
#define SCICFG_FW_H_

namespace Dsp28335_ent
{
    struct SCIcfg;
}
#endif
