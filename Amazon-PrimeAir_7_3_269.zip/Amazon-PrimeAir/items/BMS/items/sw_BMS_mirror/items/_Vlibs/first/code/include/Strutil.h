#ifndef _STRUTIL_H__
#define _STRUTIL_H__

#include <Bitutils.h>
#include <Ku8.h>
#include <Lossy.h>
#include <Vector_u8.h>
#include <Vstring.h>

namespace Base
{
    /// String Utils Helper Functions.
    /// The Base library shall provide static methods to perform different tasks related with strings and characters.
    class Strutil
    {
    public:
        /// Strutil Is Digit.
        /// \wi{5199}
        /// The Strutil class shall provide a method that returns true if received value is
        /// an ASCII digit.
        /// \param[in] d        Data to check.
        /// \return             Returns true if data is between '0' and '9' (inclusive).
        static bool is_digit(Uint8 d);

        /// Strutil As Digit.
        /// \wi{5767}
        /// Strutil class shall provide a method that checks if parameter is a digit and make assign
        /// the converted value (from 0 to 9) to the result.
        /// \param[in]  d       Data to convert.
        /// \param[out] red     Converted value.
        /// \return             Returns true if parameter is a digit.
        static bool as_digit(Uint8 d, Uint8& res);

        /// Strutil As String.
        /// \wi{6317}
        /// Strutil class shall provide a method that appends a 32-bit unsigned integer to a Vstring.
        /// \param[in]  uvalue           32-bit unsigned integer to appends.
        /// \param[out] res              Vstring destination.
        static void as_string(Uint32 uvalue, Vstring& res);

        /// Strutil As String.
        /// \wi{14583}
        /// Strutil class shall provide a method that appends a 32-bit unsigned integer to a Vstring
        /// (with a minimum number of digits and extra padding character).
        /// \param[in] uvalue           32-bit unsigned integer to appends.
        /// \param[in] min_digits       Minimum number of digits to appends.
        /// \param[in] padding_ch       Extra character for padding in the case of insignificant digit.
        /// \param[out] res             Vstring destination.
        static void as_string(Uint32 uvalue, Uint8 min_digits, char padding_ch, Vstring& res);

        /// Strutil As String.
        /// \wi{14584}
        /// Strutil class shall provide a method that appends a Real to a Vstring (with number of fractional digits).
        /// \param[in] rvalue           Single precision value to appends.
        /// \param[in] frac_digits      Number of digits for the fractional part
        /// \param[out] res             Vstring destination
        static void as_string(Real rvalue, Uint8 frac_digits, Vstring& res);

        /// Strutil As String.
        /// \wi{14585}
        /// Strutil class shall provide a method that appends a Real to a Vstring (with given format).
        /// \param[in] rvalue           Single precision value to appends.
        /// \param[in] int_digits       Number of digits for integer part.
        /// \param[in] int_char         Character for digits to the left of first integer significant digit.
        /// \param[in] frac_digits      Number of digits for fractional part.
        /// \param[in] frac_char        Character for digits to the right of last fractional significant digit.
        /// \param[in] en_sep           Enable separator between integer and fractional part.
        /// \param[in] sep_char         Character for separator.
        /// \param[out] res             Vstring destination.
        static void as_string(Real rvalue,
                              Uint8 int_digits,
                              char int_char,
                              Uint8 frac_digits,
                              char frac_char,
                              bool en_sep,
                              char sep_char,
                              Vstring& res);

        /// Strutil Parse Uint.
        /// \wi{5765}
        /// Strutil class shall provide a method that parses an integer from a buffer.
        /// \param[in]      buff        Single precision value to appends.
        /// \param[in, out] index       Number of digits for integer part.
        /// \param[out]     res         Character for digits to the left of first integer significant digit.
        /// \return                     Return true if data can be parsed in to an uint.
        static bool parse_uint(const Vector_u8& buff,
                               Uint32& index,
                               Uint32& res);

        /// Strutil Parse Real.
        /// \wi{5766}
        /// Strutil class shall provide a method that parses a real with up to maximum number of digits and up to
        /// maximum fractional digits fractional digits and fills the result.
        /// \param[in] str              Buffer to be parsed
        /// \param[in] int_digits       Number of digits for integer part.
        /// \param[in] frac_digits      Number of digits for fractional part.
        /// \param[in] fraq_sep         Character for digits to the right of last fractional significant digit.
        /// \param[in] en_sep           Enable separator between integer and fractional part.
        /// \param[out] res             Destination with parsed real.
        /// \param[in] en_spc           Ignore blank spaces when parsing the real.
        /// \return                     Return true if data can be parsed in to a real.
        template< typename T>
        static bool parse_real(Lossy& str, Uint8 int_digits, Uint8 frac_digits, char fraq_sep, bool en_sep, T& res, bool en_spc = false);

        /// Strutil To Hexadecimal.
        /// \wi{6299}
        /// Strutil class shall provide a method to generate a string from an integer using hexadecimal representation.
        /// \param[in]  v               Integer to parse
        /// \param[out] res             Vstring destination.
        static void to_hex( Uint8 v, Vstring& s);

        /// Strutil To Hexadecimal.
        /// \wi{14586}
        /// Strutil class shall provide a method to generate a string from an integer using hexadecimal representation.
        /// \param[in]  v               Integer to parse
        /// \param[out] res             Vstring destination.
        static void to_hex(Uint16 v, Vstring& s);

        /// Strutil To Hexadecimal.
        /// \wi{14587}
        /// Strutil class shall provide a method to generate a string from an integer using hexadecimal representation.
        /// \param[in]  v               Integer to parse
        /// \param[in]  nbits           Number of bits to parse
        /// \param[out] res             Vstring destination.
        static void to_hex(Uint32 v, Uint8 nbits, Vstring& s);
    private:
        static const char min_digit='0';
        static const char max_digit='9';
        static const char hexchars[16];

        /// Strutil As String.
        /// \wi{14588}
        /// Appends a 32-bit unsigned integer to a Vstring (with divisor and extra padding character).
        /// \param[in]  uvalue           32-bit unsigned integer to appends.
        /// \param[in]  div              Divisor to iteratively recover each digit.
        /// \param[in]  padding_ch       Extra character for padding in the case of insignificant digit.
        /// \param[out] res              Vstring destination.
        static void as_string_prv(Uint32 uvalue, Uint32 div, char padding_ch, Vstring& res);

        /// Strutil Parse Real Aux.
        /// \wi{14589}
        /// Strutil class shall provide a method that parses a real with up to maximum number of digits and up to
        /// maximum fractional digits fractional digits and fills the result.
        /// \param[in]  str             Buffer to be parsed
        /// \param[in]  max_digits      Maximum number of digits.
        /// \param[in]  frac_factor     Conversion factor for fractional part.
        /// \param[out] res             Destination with parsed real.
        /// \return                     Return true if some digit could be read.
        template< typename T>
        static bool parse_real_aux(Lossy& str, Uint8 max_digits, T frac_factor, T& res, bool en_spc);
        /// Strutil Check If Ignored.
        /// \wi{16170}
        /// Strutil class shall provide the capability to check if a character shall be ignored.
        /// \param[in]  d           Character to check.
        /// \return                 Return true if it's considered as ignored.
        static bool is_ignored(Uint8 d);
    };

    template< typename T>
    bool Strutil::parse_real(Lossy& str, Uint8 int_digits, Uint8 frac_digits, char fraq_sep, bool en_sep, T& res, bool en_spc)
    {   /// \alg
        bool negative = false;      /// <li> Initialize negative to false.
        Uint8 c;
        str.get_uint8(c);           /// <li> Get Uint8 from str buffer and set c variable.
        if(c == '-')                /// <li> IF, c == '-'. <ul>
        {
            negative = true;        /// <li> Set negative to true.
        }/// </ul>
        else                        /// <li> ELSE <ul>
        {
            str.turnback_bytes(1);  /// <li> Call str Lossy::turnback_bytes with parameter (1).
        }/// </ul>

        ///<li> Set ndigits to the return of calling Strutil::parse_real_aux with parameters (str, int_digits, 1, res, en_spc).
        Uint16 ndigits = parse_real_aux(str, int_digits, static_cast<T>(Const::ONE), res, en_spc);
        bool bres = ndigits > 0;    /// <li> Set bres to true if  ndigits > 0.

        // Parse fractional part
        if(bres)                    /// <li> IF bres == true. <ul>
        {
            if(frac_digits>0)       /// <li> IF frac_digits>0. <ul>
            {
                if(en_sep)          /// <li> IF en_sep == true. <ul>
                {
                    str.get_uint8(c);   /// <li> Get Uint8 from str buffer and set c variable.
                    bres = (c == fraq_sep); /// <li> Set bres to true if (c == fraq_sep).
                    if(bres)                /// <li> IF bres == true. <ul>
                    {
                        T frac = 0.0F;      /// <li> Initialize frac to 0.0.
        ///<li> Set bres to the return of calling Strutil::parse_real_aux with parameters (str, frac_digits, 1, frac, false).
                        bres = parse_real_aux(str, frac_digits, static_cast<T>(Const::TEN), frac, false);
                        res += frac;    /// <li> Set res to res + frac.
                    }/// </ul>
                }/// </ul>
            }/// </ul>
        }/// </ul>
        if(bres && negative)    /// <li> IF bres == true and negative == true. <ul>
        {
            res = -res;         /// <li> res is set to -res.
        } /// </ul>
        return bres;            /// <li> Return bres.
    }

    template< typename T>
    bool Strutil::parse_real_aux(Lossy& str, Uint8 max_digits, T frac_factor,  T& res, bool en_spc)
    {   /// \alg
        bool bres = true;                         /// <li> Initialize bres to true.
        Uint8 iaux=0;                             /// <li> Initialize iaux to 0.
        T curr_f = static_cast<T>(Const::ONE);    /// <li> Initialize curr_f to 1.
        Uint16 nread = 0;                         /// <li> Initialize nread to 0.
        res = static_cast<T>(Const::ZERO);        /// <li> res is set to 0.
        while(bres && (max_digits>0))             /// <li> WHILE bres is true and max_digits > 0. <ul>
        {
            str.get_uint8(iaux);                  /// <li> Get Uint8 from str buffer and set iaux.
            bres = as_digit(iaux, iaux);          /// <li> bres is set to Strutil::as_digit with parameters (iaux, iaux).
            if(bres)                              /// <li> IF bres is true. <ul>
            {
                curr_f *= frac_factor;            /// <li> curr_f is set to curr_f*frac_factor.
                res *= static_cast<T>(Const::TEN);/// <li> res is set to res*10.
                res += static_cast<T>(iaux);      /// <li> res is set to res + iaux.
                ++nread;                          /// <li> Increment nread value by 1.
            }/// </ul>
            /// <li> ELSE IF res == 0 and en_spc is true and the current char is ignored<ul>
            else if ((res == 0) && en_spc && is_ignored(iaux))
            { /// <ul>
                ++nread;                          /// <li> Increment nread value by 1.
                 bres = true;                     /// <li> Set bres to true.
            }/// </ul>
            else                                  /// <li> ELSE <ul>
            {
                str.turnback_bytes(1);            /// <li> Call str Lossy::turnback_bytes with parameter (1).
            }/// </ul>
            --max_digits;                         /// <li> Decrement max_digits value by 1.
        }   /// </ul>
        res /= curr_f;                            /// <li> res is set to res/curr_f.
        return (nread>0);                         /// <li> Return true if nread>0.
    }

    inline bool Strutil::is_digit(Uint8 d)
    {
        return ((d>=min_digit) && (d<=max_digit));
    }

    inline void Strutil::as_string(Uint32 uvalue, Vstring& res)
    {
        as_string(uvalue, Ku8::u1, 0, res);
    }

    inline void Strutil::to_hex(Uint8 v, Vstring& s)
    {
        s.append_char(hexchars[(v&0xF0) >> Ku8::u4]);
        s.append_char(hexchars[v&0x0F]);
    }

    inline void Strutil::to_hex(Uint16 v, Vstring& s)
    {
        to_hex(Bitutils::get_u16_h(v), s);
        to_hex(Bitutils::get_u16_l(v), s);
    }


}
#endif
