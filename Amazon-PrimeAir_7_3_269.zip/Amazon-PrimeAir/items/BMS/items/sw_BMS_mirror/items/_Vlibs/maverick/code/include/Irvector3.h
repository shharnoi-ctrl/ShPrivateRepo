#ifndef IRVECTOR3_H__
#define IRVECTOR3_H__

#include <Ivector3.h>

#include <Irmatrix3_fw.h>
#include <Irquat_fw.h>
#include <Irvector3_fw.h>
#include <Tnarray.h>
#include <Lossy_fw.h>
#include <Ir64vector3_fw.h>

namespace Maverick
{
    /// Irvector3.
    /// The ::Maverick library shall provide the capability to manage Real 3D Vectors.
    class Irvector3 : public Ivector3<Real>
    {
    public:
        struct K;

        /// Real 3D Vector Constructor with Given Parameters.
        /// \wi{17560}
        /// Irvector3 class shall build itself upon construction with a plain 3-dimensional real vector.
        /// \param[in] v        Plain 3-dimensional real vector data to point to.
        explicit Irvector3(Base::Rv3& v);

        /// Real 3D Vector Constructor with Given Parameters.
        /// \wi{3230}
        /// Irvector3 class shall build itself upon construction with a a memory block buffer.
        /// \param[in] mb       Memory block.
        explicit Irvector3(Base::Mblock<Real> mb);
        /// Irvector3 Constructor with Given Parameters.
        /// \wi{18290}
        /// Irvector3 class shall build itself upon construction with a pointer.
        /// \param[in] v0       Pointer to first Array element.
        explicit Irvector3(Real* v0);

        /// Real 3D Vector Zero Vector Checker.
        /// \wi{3225}
        /// Irvector3 shall provide the capability to determine if all the components of Irvector3 are zero, with a configurable tolerance ("eps").
        /// \param[in] eps      Epsilon value. Set to 0 by default.
        /// \return True if all the components Irvector3 is equal to zero, else false.
        bool is_zero(Real eps = 0) const;
        /// Real 3D Vector Retriever.
        /// \wi{3234}
        /// Irvector3 shall be able to retrieve its Real 3D Vector.
        /// \param[in,out] v0   Reference to the Real 3D Vector to retrieve.
        void get(Base::Rv3& v0) const;

        /// Real 3D Vector Setter.
        /// \wi{3233}
        /// Irvector3 class shall provide the capability to set its Real 3D Vector for a given Real 3D Vector.
        /// array of data.
        /// \param[in] v0       Reference to the Real 3D Vector data to copy.
        void set(const Base::Rv3& v0);

        /// Real 3D Vector Low Resolution Setter.
        /// \wi{17561}
        /// Irvector3 class shall provide the capability to set its Real 3D Vector for a given 
        /// Real 64-bit 3D Vector.
        /// \param[in] v0       Reference to the Real 64-bit 3D Vector data to copy.
        void set_low_res(const Maverick::Ir64vector3& v0);

        /// Real 3D Vector Real Value Setter.
        /// \wi{18291}
        /// Irvector3 class shall provide the capability to set its Real 3D Vector components to a given Real value.
        /// \param[in] val      Real value to be set.
        void set_all(const Real val);

        /// Real 3D Vector Components Absolute Values.
        /// \wi{3157}
        /// Irvector3 class shall provide the capability to compute the absolute value for its 
        /// individual Real 3D Vector components.
        void abs();

        /// Real 3D Vector to Azimuth, Elevation and Length Computation.
        /// \wi{3045}
        /// Irvector3 class shall provide the capability to transform to azimuth, elevation and length for its 
        /// Real 3D Vector expressed in NED.
        /// \param[out] Az   Azimuth reference to be set.
        /// \param[out] E    Elevation reference to be set.
        /// \param[out] d    Distance reference to be set.
        void azeld(Real& Az,
                   Real& E,
                   Real& d)const;
        /// Real 3D Vector from Azimuth, Elevation and Length Computation.
        /// \wi{3046}
        /// Irvector3 class shall provide the capability to transform for a given azimuth, elevation and length 
        /// to Real 3D Vector expressed in NED.
        /// \param[in] Az       Azimuth value.
        /// \param[in] E        Elevation value.
        /// \param[in] d        Distance value.
        void azeld_1(const Real& Az,
                     const Real& E,
                     const Real& d);

        /// Real 3D Vector Azimuth Getter.
        /// \wi{3239}
        /// Irvector3 shall be able to retrieve the azimuth for its Real 3D Vector.
        /// \return Real azimuth value.
        Real azimuth()const;
        /// Real 3D Vector Elevation Getter.
        /// \wi{3238}
        /// Irvector3 shall be able to retrieve the elevation for its Real 3D Vector.
        /// \return Real elevation value.
        Real elevation()const;

        /// Real 3D Vector Filtered EWMA Increment Addition Computation.
        /// \wi{3049}
        /// Irvector3 shall be able to compute to add filtered increments with an EWMA filter for 
        /// its Real 3D Vector.
        /// \param[in] tau      Time constant.
        /// \param[in] dt       Time step.
        /// \param[in] x        Input Real 3D Vector to be added.
        void ewma_add(Real tau,
                      Real dt,
                      const Irvector3& x);

        /// Real 3D Vector Scaler.
        /// \wi{3059}
        /// Irvector3 class shall provide the capability to scale each element of the Real 3D Vector to a 
        /// provided Real constant value.
        /// \param[in] a        Constant scalar value.
        void scale(Real a);
        /// Real 3D Vector Sign Inversion.
        /// \wi{3060}
        /// Irvector3 class shall provide the capability to invert the sign of its Real 3D Vector 
        /// components, equivalent to scale it by -1.
        void signinv();
        /// Real 3D Vector Components Inversion.
        /// \wi{3158}
        /// Irvector3 class shall provide the capability to invert its Real 3D Vector components.
        /// \pre This method shall only be called if no member of the vector is zero.
        void inv();
        /// Real 3D Vector Sum Computation.
        /// \wi{3062}
        /// Irvector3 class shall provide the capability to compute the sum for two given Real 3D Vectors.
        /// \param[in] x        First 3D Vector for addition.
        /// \param[in] y        Second 3D Vector for addition.
        void vecsum(const Irvector3& x,const Irvector3& y);
        /// Real 3D Vector X-Y Components Subtraction.
        /// \wi{3067}
        /// Irvector3 class shall provide the capability to compute the subtraction of the 'x' and 
        /// 'y' components for two given Real 3D Vectors.
        /// \param[in] x        First 3D Vector for x-y subtraction.
        /// \param[in] y        Second 3D Vector for x-y subtraction.
        void vecresxy(const Irvector3& x,const Irvector3& y);

        /// Real 3D Vector Transposed Matrix and Vector Product Computation.
        /// \wi{18292}
        /// Irvector3 class shall provide the capability to compute the multiplication between 
        /// the given Transposed Real 3x3 Matrix and Real 3D Vector.
        /// \param[in] A        Transposed 3x3 Matrix for multiplication.
        /// \param[in] b        3D Vector for multiplication.
        void matTvec(const Irmatrix3& A,const Irvector3& b);
        /// Real 3D Vector Incrementation by 3x3 Matrix Times 3D Vector Computation.
        /// \wi{3055}
        /// Irvector3 class shall provide the capability to compute the addition between 
        /// the given Real 3x3 Matrix and Real 3D Vector.
        /// \param[in] A        3x3 Matrix for addition.
        /// \param[in] b        3D Vector for addition.
        void matvec_add(const Irmatrix3& A,const Irvector3& b);
        /// Real 3D Vector Decrementation by 3x3 Matrix Times 3D Vector Computation.
        /// \wi{3056}
        /// Irvector3 class shall provide the capability to compute the subtraction between 
        /// the given Real 3x3 Matrix and Real 3D Vector.
        /// \param[in] A        3x3 Matrix for subtraction.
        /// \param[in] b        3D Vector for subtraction.
        void matvec_sub(const Irmatrix3& A,const Irvector3& b);
        /// Real 3D Vector Update by 3x3 Matrix Times Itself.
        /// \wi{3053}
        /// Irvector3 class shall provide the capability to compute the multiplication between 
        /// the given Real 3x3 Matrix and its Real 3D Vector.
        /// \param[in] A        3x3 Matrix for addition.
        void matthis(const Irmatrix3& A);

        /// Real 3D Vector Quadratic Form Evaluation.
        /// \wi{19641}
        /// Irvector3 class shall provide a method of computing the quadratic form, in
        /// which is Irvector3 transposed multiplied by the a given matrix "A" multiplied
        /// by Irvector3.
        /// \param[in] A        Irmatrix3 given matrix.
        /// \return The evaluation of the quadratic form.
        Real thismatthist(const Irmatrix3& A) const;

        /// Real 3D Vector Conjugated Quaternion and Quaternion Multiplication.
        /// \wi{3058}
        /// Irvector3 class shall provide the capability to compute the product between 
        /// the first given quaternion conjugated, Irvector3 and the second given quaternion.
        /// \param[in] q1       First conjugated quaternion.
        /// \param[in] q2       Second quaternion.
        void qcq(const Irquat& q1,const Irquat& q2);
        /// Real 3D Vector Cross Product Computation.
        /// \wi{3047}
        /// Irvector3 class shall provide the capability to compute the cross product between 
        /// the two given Real 3D Vector.
        /// \param[in] a        First 3D Vector for cross product.
        /// \param[in] b        Second 3D Vector for cross product.
        void cross(const Irvector3& a, const Irvector3& b);
        /// 3D Vector Cross Product with Vertial Vector Computation.
        /// \wi{3048}
        /// Irvector3 class shall provide the capability to compute the cross product of a 3D vector with a 
        /// vertical vector (understood as a 3D vector with the third component set to 0).
        /// \param[in] a        Vertical Vector for cross product.
        void cross_axkn(const Irvector3& a);

        /// Real 3D Vector Euclidean Squared Norm Computation.
        /// \wi{3226}
        /// Irvector3 class shall provide the capability to compute the euclidean squared norm of its internal
        /// Real 3D Vector components.
        /// \return Euclidean squared norm value.
        Real norm2()const;

        /// Real 3D Vector Euclidean Squared X-Y Norm Computation.
        /// \wi{3228}
        /// Irvector3 class shall provide the capability to compute the euclidean squared norm of its internal
        /// 'x' and 'y' Real 3D Vector components.
        /// \return The euclidean squared norm for X-Y components.
        Real norm2xy()const;

        /// Real 3D Vector Normalized Euclidean Squared Norm Computation.
        /// \wi{3057}
        /// Irvector3 class shall provide the capability to compute the normilize euclidean squared 
        /// norm of its Real 3D Vector components.
        /// \return Normalize euclidean squared norm value.
        Real norm2alize();

        /// Real 3D Vector Scalar Multiplication Computation.
        /// \wi{3050}
        /// Irvector3 class shall provide the capability to compute the linear combination between 
        /// the given scalar value and the Real 3D Vector.
        /// \param[in] a        Scalar value.
        /// \param[in] a1       Real 3D Vector.
        void lincmb(Real a, const Irvector3& a1);

        /// Real 3D Vector Linear Combination Computation.
        /// \wi{18293}
        /// Irvector3 class shall provide the capability to compute the linear combination between the two given
        /// scalar values and the two Real 3D Vectors.
        /// \param[in] a        First scalar value.
        /// \param[in] a1       First Real 3D Vector.
        /// \param[in] b        Second scalar value.
        /// \param[in] b1       Second Real 3D Vector.
        void lincmb(Real a,
                    const Irvector3& a1,
                    Real b,
                    const Irvector3& b1); //PRQA S 4211 #const
        /// Real 3D Vector Linear Combination Computation.
        /// \wi{3051}
        /// Irvector3 class shall provide the capability to compute the linear combination between the given 
        /// 3D vector and its 3D Vector.
        /// \param[in] a        Scalar value.
        /// \param[in] a1       Real 3D Vector.
        void lincmb_add(Real a,const Irvector3& a1);

        /// Real 3D Vector Element-wise Multiplication Adding Computation.
        /// \wi{3159}
        /// Irvector3 class shall provide the capability to compute the element-wise multiplication 
        /// between the two given vectors and add to its Real 3D Vector.
        /// \param[in] a        First Real 3D Vector for multiplication.
        /// \param[in] b        Second Real 3D Vector for multiplication.
        void mul_wise_add(const Irvector3& a, const Irvector3& b);

        /// Real 3D Vector Element-wise Multiplication Computation.
        /// \wi{3160}
        /// Irvector3 class shall provide the capability to compute the element-wise multiplication 
        /// between the two given vectors.
        /// \param[in] a        First Real 3D Vector for multiplication.
        /// \param[in] b        Second Real 3D Vector for multiplication.
        void mul_wise(const Irvector3& a, const Irvector3& b);

        /// Real 3D Vector Element-wise Division Computation.
        /// \wi{3170}
        /// Irvector3 class shall provide the capability to compute the element-wise division for the
        /// given Real 3D Vector. 
        /// \param[in] a        First Real 3D Vector for division.
        /// \pre This method shall only be called if no member of the given "a" vector is zero.
        void div_wise(const Irvector3& a);

        /// Real 3D Vector Irvector3 Serialization.
        /// \wi{3236}
        /// Irvector3 class shall provide the capability to serialize its configuration to a PDIC.
        /// \param[in,out] str          Lossy where serialize the data.
        void compress(Base::Lossy& str)const;
        /// Real 3D Vector Irvector3 Deserialization.
        /// \wi{3224}
        /// Irvector3 class shall provide the capability to deserialize configuration from a PDIC.
        /// \param[in,out] str          Lossy which deserialize the data.
        void uncompress(Base::Lossy& str);

    private:
        /// Private constructors to be only used by Irvector3::K, it ensures const correctnes.

        /// Real 3D Vector Private Constructor with Given Parameters.
        /// \wi{18294}
        /// Irvector3 class shall build itself upon construction with a a memory block buffer.
        /// \param[in] mb       Memory block.
        explicit Irvector3(const Base::Mblock<const Real>& mb);

        /// Real 3D Vector Private Constructor with Given Parameters.
        /// \wi{18295}
        /// Irvector3 class shall build itself upon construction with a plain 3-dimensional real vector.
        /// \param[in] v        Plain 3-dimensional real vector data to point to.
        explicit Irvector3(const Base::Rv3& v);

        /// Real 3D Vector Private Constructor with Given Parameters.
        /// \wi{18296}
        /// Irvector3 class shall build itself upon construction with a pointer.
        /// \param[in] v0       Pointer to first Array element.
        explicit Irvector3(const Real* v0);

        Irvector3();                                    ///< = delete
        Irvector3(const Irvector3& src);                ///< = delete
        Irvector3& operator=(const Irvector3& src);     ///< = delete
    };

    /// K structure for Irvector3
    struct Irvector3::K
    {
        const Irvector3 kvec;           ///< Constant Real 3D Vector.
        /// Irvector3::K Constructor with Given Parameters.
        /// \wi{3231}
        /// Irvector3::K structure shall build itself upon construction with a a memory block buffer.
        /// \param[in] v        Memory block.
        explicit K(const Base::Mblock<const Real>& v);
        /// Irvector3::K Constructor with Given Parameters.
        /// \wi{18297}
        /// Irvector3::K structure shall build itself upon construction with a plain 3-dimensional real vector.
        /// \param[in] v        Plain 3-dimensional real vector data to point to.
        explicit K(const Base::Rv3& v);
        /// Irvector3::K Constructor with Given Parameters.
        /// \wi{18298}
        /// Irvector3::K structure shall build itself upon construction with a pointer.
        /// \param[in] v        Pointer to first Array element.
        explicit K(const Real* v);
    private:
        K();                                            ///< = delete
        K(const K& orig);                               ///< = delete
        K& operator=(const K& orig);                    ///< = delete
    };


    inline Irvector3::Irvector3(Base::Rv3& v) : Ivector3(v.v)
    {
    }

    inline Irvector3::Irvector3(Base::Mblock<Real> mb) : Ivector3(mb)
    {
    }

    inline Irvector3::Irvector3(Real* v0):Ivector3(v0)
    {
    }

    inline void Irvector3::get(Base::Rv3& v0) const
    {
        /// \alg
        /// - Call Rv3::copy for given Real 3D Vector with this method.
        v0.copy(*this);
    }

    inline void Irvector3::set(const Base::Rv3& v0)
    {
        /// \alg
        /// - Call Ivector3::copy for given Real 3D Vector.
        Ivector3<Real>::copy(v0.v);
    }

    inline Real Irvector3::elevation()const
    {
        /// \alg
        /// - Return retrieved value by Rmath::atan2r for minus 'z' component of its 3D Vector and 
        /// Irvector3::norm2xy retrieved value.
        return Rmath::atan2r(-v[vz],norm2xy());
    }

    inline Real Irvector3::norm2()const
    {
        /// \alg
        /// - Return square root value for the retrieved value by Irvector3<Real>::norm22.
        return Rmath::sqrtr(norm22());
    }

    inline Real Irvector3::norm2xy()const
    {
        /// \alg
        /// - Return square root value for the retrieved value by Irvector3<Real>::norm22xy.
        return Rmath::sqrtr(norm22xy());
    }

    inline Irvector3::Irvector3(const Base::Mblock<const Real>& mb) : Ivector3(const_cast<Real*>(mb.v))
    {
    }

    inline Irvector3::Irvector3(const Base::Rv3& v) : Ivector3(const_cast<Real*>(v.v))
    {
    }

    inline Irvector3::Irvector3(const Real* v0) : Ivector3(const_cast<Real*>(v0))
    {
    }

    inline Irvector3::K::K(const Base::Mblock<const Real>& v) : kvec(v)
    {
    }

    inline Irvector3::K::K(const Base::Rv3& v) : kvec(v)
    {
    }

    inline Irvector3::K::K(const Real* v) : kvec(v)
    {
    }
}
#endif
