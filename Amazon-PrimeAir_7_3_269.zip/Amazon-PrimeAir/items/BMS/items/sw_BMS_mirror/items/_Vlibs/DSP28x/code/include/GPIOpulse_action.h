#ifndef GPIOPULSE_ACTION_H_
#define GPIOPULSE_ACTION_H_

#include <Assertions.h>
#include <Timeout.h>
#include <GPIO.h>

namespace Dsp28335_ent
{
    /// Manage GPIO to perform a fixed-width pulse from trigger.
    class GPIOpulse_action
    {
    public:
        /// GPIO pulse action default constructor.
        /// \wi{18495}
        /// GPIOpulse_action class shall initialize itself upon construction with provided parameters.
        /// \param[in] gpio0        Identifier for the GPIO.
        /// \param[in] idle_state0  GPIO state at idle state (not performing pulse).
        GPIOpulse_action(GPIOid gpio0, bool idle_state0);

        /// Start GPIO pulse.
        /// \wi{18496}
        /// GPIOtoggler_action class shall provide the capability to start a pulse of provided width.
        /// \param[in] period0  Amount of seconds that GPIO shall hold pulsed state before returning idle state.
        /// \pre <ul>
        ///     <li> Shall be called from low-priority thread.
        ///     <li> Provided period0 is strictly greater than 1 millisecond.
        /// </ul>
        void start_pulse(Real period0);

        /// Force GPIO pulse.
        /// \wi{18818}
        /// GPIOtoggler_action class shall provide the capability to perform a pulse of provided period.
        /// \param[in] period0  Amount of microseconds that GPIO shall hold pulsed state before returning idle state.
        /// \pre Assume that:
        /// <ul>
        /// <li> This method shall be called from low-priority task.
        /// <li> Provided period0 is less than 20 microseconds.
        /// </ul>
        void force_pulse(Uint16 period0);

        /// GPIO pulse action High-priority step.
        /// \wi{18497}
        /// GPIOpulse_action class shall provide the capability to perform GPIO action.
        /// \return True when fixed period expired, else return False.
        /// \pre Shall be called from a real-time task if we want to ensure pulse duration consistency.
        bool step_hi();

    private:
        GPIO gpio;                  ///< GPIO handler.
        const bool idle_state;      ///< GPIO idle state (when not toggled).
        bool triggered;             ///< At true when a trigger has been received.
        Base::Timeout tout;         ///< Timeout for desired pulse width, fixed with period in seconds.

        /// Perform GPIO pulse.
        /// \wi{18819}
        /// GPIOpulse_action class shall provide the capability to perform a long pulse.
        void step0();

        GPIOpulse_action(const GPIOpulse_action& orig); ///< = delete
        GPIOpulse_action& operator=(const GPIOpulse_action& orig); ///< = delete
    };
}

#endif
