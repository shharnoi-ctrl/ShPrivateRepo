#include <Devcfg.h>
#include <Devcfg_regs.h>
#include <Asm.h>
#include <Hregmap.h>
#include <Ku16.h>
#include <Ku32.h>

namespace Dsp28335_ent
{
    Devcfg::Devcfg() : regs(Hregmap::get<Registers, devcfg_regs_addr>())
    {
    }

    void Devcfg::cpu2_hold_reset()
    {
        static const Uint32 varCPU2_reset_hold = 0xA5A50001UL;
        volatile Registers& regs(Hregmap::get<Registers, devcfg_regs_addr>());
        // CPU2 is held in reset. This also causes ERAM writable by CPU1.
        asm_eallow();
        regs.CPU2RESCTL.all = varCPU2_reset_hold;
        asm_edis();
    }

    void Devcfg::soft_reset(Sprid spr)
    {
        volatile Uint16& softpres = regs.softpres[spr >> Ku16::u16];
        const Uint16 msk = spr & Ku32::u0xFFFF;
        asm_eallow();
        softpres |= msk;
        asm_nop();
        asm_nop();
        asm_nop();
        asm_nop();
        softpres &= (~msk);
        asm_edis();
    }

    void Devcfg::set_cpu1_ownership(Cpusel_dev c_dev, Uint16 dev_bits)
    {
        volatile Uint32& cpusel = regs.cpusel[c_dev];
        asm_eallow();
        cpusel &= ~dev_bits; // Sets ownership to CPU1
        asm_edis();
    }

    void Devcfg::set_cpu2_ownership(Cpusel_dev c_dev, Uint16 dev_bits)
    {
        volatile Uint32& cpusel = regs.cpusel[c_dev];
        asm_eallow();
        cpusel |= dev_bits; // Sets ownership to CPU2
        asm_edis();
    }

    void Devcfg::set_sysdbgctl(bool value)
    {
        asm_eallow();
        regs.SYSDBGCTL.bit.BIT_0 = value;
        asm_edis();
    }

    Uint32 Devcfg::get_partid_h() const
    {
        return regs.PARTIDH.all;
    }

    Uint32 Devcfg::get_partid_l() const
    {
        return regs.PARTIDL.all;
    }

    Uint32 Devcfg::get_revid() const
    {
        return regs.REVID;
    }
}
