#include <I2Cdevice.h>

#include <Ku16.h>

namespace Dsp28335_ent
{
    I2Cdevice::I2Cdevice(Dsp28335_ent::I2Cif& i2c0,
                         Uint8 address0,
                         Uint8 buffer_sz,
                         volatile bool& bit0) :
        callst(bit0, Const::ONE, Const::ONE),
        i2c(i2c0),
        enabled(false),
        busy(false),
        address(address0),
        buffer(buffer_sz, Base::Memmgr::external)
    {
        /// \alg
        /// Name          | Description               | Value
        /// ------------- | ------------------------- | -------------------------------
        /// ::callst      | Call statistic checker    | (::bit0, 1.0, 1.0)
        /// ::i2c         | I2C peripheral driver     | ::i2c0
        /// ::enabled     | Enabled flag              | false
        /// ::busy        | Busy flag                 | false
        /// ::address     | Slave address             | ::address0
        /// ::buffer      | Working buffer            | ::buffer_sz
    }

    I2Cdevice::~I2Cdevice() //PRQA S 2635 #destructor replaced with default
    {
    }

    bool I2Cdevice::send(Uint8 d0)
    {
        /// \alg
        /// Append ::d0 parameter to ::buffer attribute and call ::send_priv (as described at \wi{16781}).
        buffer.set(Ku32::u0, d0);
        return send_priv(Ku32::u1);
    }

    bool I2Cdevice::send(Uint8 d0, Uint8 d1)
    {
        /// \alg
        /// Append ::d0 and ::d1 parameters to ::buffer attribute and call ::send_priv (as described at \wi{16781}).
        buffer.set(Ku32::u0, d0);
        buffer.set(Ku32::u1, d1);
        return send_priv(Ku32::u2);
    }

    bool I2Cdevice::send(const Base::U8pkmblock_k& d)
    {
        /// \alg
        /// Write ::d parameter content to ::buffer attribute and call ::send_priv (as described at \wi{16781}).
        const Uint32 tx_sz = buffer.write(d);
        return send_priv(tx_sz);
    }

    bool I2Cdevice::send_no_stop(Uint8 d0)
    {
        /// \alg
        /// Append ::d0 parameter to ::buffer attribute and call ::send_priv (as described at \wi{16781}) with ::stop0
        /// parameter to true for repeated-start mode initialization.
        buffer.set(Ku32::u0, d0);
        return send_priv(Ku32::u1, false);
    }

    bool I2Cdevice::send_priv(Uint32 tx_sz, bool stop0)
    {
        /// \alg
        /// If not busy, modify the size of the working buffer from provided ::tx_sz, start the operation
        /// by calling I2C peripheral driver ::start_write method. Then load result (at true if correctly
        /// started) onto ::busy attribute and return it.
        bool ret = false;
        if(!busy)
        {
            const Base::U8pkmblock_k tx_mb(buffer, tx_sz);  // Memory block of expected size
            busy = i2c.start_write(address, tx_mb, stop0);  // Return true if succeed
            ret = busy;
        }
        return ret;
    }

    void I2Cdevice::set_enabled(bool en)
    {
        /// \alg
        /// <li> If ::en is true and ::enabled attribute is false, reset the call statistics.
        /// <li> In any case, set ::enabled attribute to ::en parameter.
        if((enabled != en) && en)
        {
            callst.reset();
        }
        enabled = en;
    }

    void I2Cdevice::set_period(const Real& period0)
    {
        /// \alg
        /// The current calling rate \f$current\f$ shall be: <br>
        /// \f$current = (default/provided)*specific\f$ <br>
        /// Where: <ul>
        /// <li> \f$specific\f$ is the specific device rate from \wi{7554},
        /// <li> \f$provided\f$ is the provided calling rate from ::period0,
        /// <li> \f$default\f$ is the specific device default rate from \wi{7555}. </ul>
        /// In addition: <ul>
        /// <li> Update the ::callst with the previously computed calling rate multiplied by 0.75,
        /// <li> If the device has already been initialized, force ::callst to initialize with new value. </ul>
        Real curr_cr = get_desired_rate();

        // Calculate and actualize call state calling rate
        curr_cr = ((get_default_period()/period0)*curr_cr);
        callst.set_desired_rate(curr_cr*0.75);

        // If the device has already been initialized
        if(callst.is_ready())
        {
            callst.set_ready(false);                // Force a change from false to true
            callst.set_ready(true, curr_cr);
        }
    }

    bool I2Cdevice::read(Uint8 size)
    {
        /// \alg
        /// If not busy, modify the size of the working buffer from provided ::size, start the operation
        /// by calling I2C peripheral driver ::start_read method. Then load result (at true if correctly
        /// started) onto ::busy attribute and return it.
        bool ret = false;
        if(!busy)
        {
            Base::U8pkmblock rx_mb(buffer, size);  // Memory block of expected size
            busy = i2c.start_read(address, rx_mb);
            ret = busy;
        }
        return ret;
    }

    /// \pre ::up_perc parameter shall be greater or equals to 1.0F.
    Real I2Cdevice::get_default_period0(Uint16 req_steps, Real up_perc) const
    {
        /// \alg
        /// Default period \f$default\f$ shall be: <br>
        /// \f$default = 1/((req_steps*desired)*up_perc)\f$
        /// Where: <ul>
        /// <li> \f$req_steps\f$ is the required number of steps to collect one sample from ::req_steps,
        /// <li> \f$desired\f$ is the specific device rate from \wi{7554},
        /// <li> \f$up_perc\f$ is the up-percentage factor from ::up_perc. </ul>
        const Real req_cycles = static_cast<Real>(req_steps) * get_desired_rate();
        Base::Assertions::runtime(up_perc >= Const::ONE);
        return Const::ONE / (req_cycles*up_perc);
    }

    bool I2Cdevice::step()
    {
        /// \alg
        /// First, compute call statistics through its ::step call. <br>
        /// Then if an operation is pending: <ul>
        /// <li> If ::i2c peripheral driver reporting to be free, check for ::i2c status and load it onto
        /// specific driver through ::set_ok call (as described at \wi{7559}} and set ::busy attribute to false.
        /// <li> Else, step through specific device FSM through ::do_step (as described at \wi{7558}). </ul>
        /// Finally, return ::is_busy (as described at \wi{16782}).
        callst.step();

        if(is_busy())
        {
            if(!i2c.is_busy())
            {
                set_ok(i2c.is_ok());
                busy = false;
            }
        }
        else
        {
            do_step();
        }
        return is_busy();
    }
}
