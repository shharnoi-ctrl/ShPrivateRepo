#ifndef HDUAL_H_
#define HDUAL_H_

namespace Dsp28335_ent
{
    /// Linkage time check to assert some code is linked for expected CPU.
    class Hdual
    {
    public:
        static void assert_is_cpu1();
        static void assert_is_cpu2();

    private:
        Hdual(); ///< = delete
        Hdual(const Hdual& orig); ///< = delete
        ~Hdual();
        Hdual& operator=(const Hdual& orig); ///< = delete
    };
}
#endif
