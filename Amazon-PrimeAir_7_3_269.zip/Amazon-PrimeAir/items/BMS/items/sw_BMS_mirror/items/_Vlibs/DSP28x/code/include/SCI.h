#ifndef SCI_H_
#define SCI_H_

#include <Entypes.h>
#include <ISCI_ioctl.h>

namespace Dsp28335_ent
{
    /// Serial Communication Interface (SCI).
    /// The Dsp28x library shall provide the capability to control the SCI peripheral through dedicated registers.
    class SCI: public ISCI_ioctl
    {
    public:
        typedef Uint8 type; // required by producer/consumer contract
        /// SCI Module Id.
        enum Id
        {
            scia = 0,   ///< SCI A.
            scib = 1,   ///< SCI B.
            scic = 2,   ///< SCI C.
            scid = 3    ///< SCI D.
        };
        static const Uint16 sci_all = 4;    ///< Total count of SCI modules.

        /// SCI Constructor.
        /// \wi{7600}
        /// The SCI class shall build itself upon construction with provided module identifier.
        /// \param[in] id0     SCI module to be used.
        explicit SCI(Id id0);

        /// Config SCI.
        /// \wi{7778}
        /// SCI class shall provide the capability to configure itself with provided configuration.
        /// \param[in] cfg           Reference to the configuration for this module.
        virtual void config(const SCIcfg& cfg);

        /// SCI Read.
        /// \wi{7850}
        /// SCI class shall provide the capability to read data received from SCI peripheral.
        /// \param[out] data          Received data to be read.
        /// \return                   Return true if the data was read successfully.
        bool read(Uint8& data);

        /// SCI Write.
        /// \wi{7854}
        /// SCI class shall provide the capability to write data to the SCI peripheral.
        /// \param[in] data          Data to write.
        /// \return                  Return true if the data was written successfully.
        bool write(Uint8 data);

        /// SCI Write Available.
        /// \wi{7783}
        /// SCI class shall provide the capability to check for a write availability.
        /// \return                  Return true if write is available.
        bool wr_available() const;

        /// SCI Step.
        /// \wi{7784}
        /// SCI class shall provide a step method to signal a reception error and recover from it by processing
        /// a software reset of the SCI peripheral.
        void step();

        /// SCI Tx Pending.
        /// \wi{14911}
        /// SCI class shall provide the capability to check if there is pending data to be transmitted on peripheral.
        /// \return                  Return true if there is tx data pending.
        bool tx_pending() const;

        /// SCI Tx Fifo Pending.
        /// \wi{14912}
        /// SCI class shall provide the capability to check if there is pending data
        /// to be copied from fifo to peripheral.
        /// \return                  Return true if there is tx data pending.
        bool tx_fifo_pending() const;

        /// SCI Tx Count Getter.
        /// \wi{7630}
        /// SCI class shall provide the capability to get the transmitted count and reset that count.
        /// \return                 Return tx count.
        Uint32 get_tx_count();

        /// SCI Rx Count Getter.
        /// \wi{7629}
        /// SCI class shall provide the capability to get the received count and reset that count.
        /// \return                 Return rx count.
        Uint32 get_rx_count();

        /// SCI Is Rx Okay.
        /// \wi{7953}
        /// SCI class shall provide the capability to check if an error has occurred since last error check.
        /// \return                 Return false when an error occurs on RX-Side.
        bool is_rx_ok();

        // Comcon template-mandated methods
        /// SCI Tx Enabler.
        /// \wi{7951}
        /// SCI class shall provide the capability to distinctly enable/disable transmission.
        /// \param[in] en           Enable/disable setting.
        void enable_tx(bool en);

        /// SCI Rx Enabler.
        /// \wi{7952}
        /// SCI class shall provide the capability to distinctly enable/disable reception.
        /// \param[in] en           Enable/disable setting.
        void enable_rx(bool en);

        /// SCI Compute Number of Bits.
        /// \wi{14913}
        /// SCI class shall provide the capability to compute the number of bits used in SCI module.
        /// \return                 Return the number of bits.
        Uint8 compute_n_bits() const;

        /// SCI Speed Getter.
        /// \wi{14914}
        /// SCI class shall provide the capability get the speed of SCI peripheral.
        /// \return                 Return the current speed.
        Uint32 get_speed() const;

    private:
        const Id id;                ///< Id of this SCI.
        struct Sci_regs;
        volatile Sci_regs& regs;    ///< SCI hardware registers.

        Uint32 tx_count;            ///< Transmitted byte count since last call to get_tx_count().
        Uint32 rx_count;            ///< Received byte count since last call to get_rx_count().

        bool rx_ok;                 ///< Flag to false when an error occurred on RX-Side.

        /// SCI Registers Getter.
        /// \wi{14915}
        /// The SCI class shall provide the capability to retrieve internal registers for provided SCI module.
        /// \param[in] id0      Id for the desired SCI module.
        /// \return             Returns a reference to the registers of the desired module.
        static volatile Sci_regs& get_regs(Id id0);

        SCI(); ///< = delete
        SCI(const SCI& orig); ///< = delete
        SCI& operator=(const SCI& orig); ///< = delete
    };
}
#endif
