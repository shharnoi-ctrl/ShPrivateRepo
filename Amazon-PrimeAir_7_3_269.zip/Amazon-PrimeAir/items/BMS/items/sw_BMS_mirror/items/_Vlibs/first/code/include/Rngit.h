#ifndef RNGIT_H_
#define RNGIT_H_

#include <Iiterator.h>

namespace Base
{
    /// Range iterator.
    template <typename T>
    class Rngit : public Iiterator<T>
    {
    public:
        /// Range iterator constructor.
        /// \wi{5171}
        /// \pre This class assumes that the template type T has the operator + and can be added one to it.
        /// The ::Rngit class shall be constructable passing as argument the first and last element used for the
        /// iteration.
        /// \param[in] v0 First element of the iteration.
        /// \param[in] vz0 Last element of the iteration (the last iteration shall return this element).
        Rngit(T v0, T vz0);

        /// Range iterator builder with iteration count.
        /// \wi{17046}
        /// The ::Rngit class shall provide a method to build a ::Rngit instance with the starting element of the
        /// iteration and the number of iterations.
        /// \param[in] v0 First element to iterate.
        /// \param[in] count Number of iterations.
        static Rngit build_count(T v0, Uint32 count)
        {
            Rngit ret(v0, static_cast<T>(v0+count-1));
            return ret;
        }

        /// Range iterator pending size.
        /// \wi{5172}
        /// The ::Rngit class shall provide a method that returns the number of iterations pending.
        /// \return Number of elements pending in iteration
        virtual Uint16 pending_size() const;

        /// Range iterator next element.
        /// \wi{5173}
        /// The ::Rngit class shall provide a method to obtain the next element in the iteration and increase the
        /// iteration counter.
        /// \return Next element or last if the number of iterations is exceeded.
        virtual T next();

    private:
        T v;            ///< First element
        const T vz;     ///< Last element (inclusive)

        Rngit();                             ///< = delete
        Rngit& operator=(const Rngit& orig); ///< = delete
    };

    template <typename T>
    inline Rngit<T>::Rngit(T v0, T vz0) : v(v0), vz(vz0)
    {
    }

    template <typename T>
    inline Uint16 Rngit<T>::pending_size() const
    {
        return 1+static_cast<Uint16>(vz-v); // overflow should be supported
    }

    template <typename T>
    T Rngit<T>::next()
    {
        T res = v;
        v = static_cast<T>(v+1); //PRQA S 3100 #redundant cast for this instantiation
        if (v > vz)
        {
            v = vz;
        }
        return res;
    }

}
#endif
