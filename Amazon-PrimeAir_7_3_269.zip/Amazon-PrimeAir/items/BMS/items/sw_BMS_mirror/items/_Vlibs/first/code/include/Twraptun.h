#ifndef TWRAPTUN_H_
#define TWRAPTUN_H_

#include <Itunable.h>
#include <Ttraits.h>
#include <Tuntraits.h>

namespace Base
{
    /// Makes Itunable some T.
    /// Note that T can be reference.
    /// T shall define synchronous cset and cget methods.
    /// POLICY is a struct that must have static methods str2elem and elem2str (see Tuntraits.h).
    template<typename POLICY, typename T = typename POLICY::type>
    class Twraptun : public Itunable
    {
    public:
        T value;

        /// Default constructor
        inline Twraptun()
        {
        }

        /// Build with one parameter, can be a reference to T
        template<typename P0>
        inline explicit Twraptun(P0& param0) : value(param0)
        {
        }

        /// Build with two parameters
        template<typename P0, typename P1>
        inline Twraptun(P0 param0, P1 param1) : value(param0, param1)
        {
        }

        inline virtual void cset(Base::Lossy_error& str)
        {
             POLICY::str2elem(value,str);
        }

        inline virtual void cget(Base::Lossy& str) const
        {
            POLICY::elem2str(value,str);
        }

    private:
        Twraptun(const Twraptun& orig); ///< = delete
        Twraptun& operator=(const Twraptun& orig); ///< = delete
    };

    typedef Twraptun<Tuntraits::Lossy16<Uint16> > U16tun;
    typedef Twraptun<Tuntraits::Lossy_float>      Realtun;
}
#endif
