#ifndef U8PKMBLOCK_H_
#define U8PKMBLOCK_H_

#include <Allocator.h>
#include <Bitutils.h>
#include <Mblock.h>
#include <Memmgr.h>
#include <U8pkmblock_k.h>

namespace Base
{
    /// The Base library shall provide a class to manage packed version for block of bytes, using high and low
    /// part of 16 bits word.
    /// NOTE: C2000 version cannot have a U8 block of size greater than 65535 (16bit addressing)
    class U8pkmblock : public U8pkmblock_k
    {
    public:
        /// Packed Block of Bytes Default Constructor.
        /// \wi{5982}
        /// U8pkmblock class shall build itself upon construction and initialize its internal members as null.
        U8pkmblock();

        /// Packed Block of Bytes Constructor with Given Parameters.
        /// \wi{20510}
        /// U8pkmblock class shall build itself upon construction with a given size and memory type.
        /// \param[in] sz0      Size for the block of bytes.
        /// \param[in] mtype    Memory type to be allocated.
        U8pkmblock(Uint32 sz0, Memmgr::Type mtype);

        /// Packed Block of Bytes Constructor with Given Parameters.
        /// \wi{20502}
        /// U8pkmblock class shall build itself upon construction with a given size and memory allocator.
        /// \param[in] sz0      Size for the block of bytes (sz0 is in bytes).
        /// \param[in] alloc    Allocator memory.
        U8pkmblock(Uint32 sz0, Allocator& alloc);

        /// Packed Block of Bytes Constructor with Given Parameters.
        /// \wi{20503}
        /// U8pkmblock class shall build itself upon construction to work on given constant memory block and size.
        /// \param[in] data             Constant memory block of data to be used.
        /// \param[in] size_bytes       Size for the block of bytes (sz0 is in bytes).
        U8pkmblock(const void* data, Uint32 size_bytes);
        /// Packed Block of Bytes Constructor with Given Parameters.
        /// \wi{20504}
        /// U8pkmblock class shall build itself upon construction to work on given constant volatile memory block
        /// and size.
        /// \param[in] data             Constant volatile memory block of data to be used.
        /// \param[in] size_bytes       Size for the block of bytes (sz0 is in bytes).
        U8pkmblock(const volatile void* data, Uint32 size_bytes);

        /// Packed Block of Bytes Explicit Constructor with Given Parameters.
        /// \wi{20505}
        /// U8pkmblock class shall build itself upon explicit construction with a given constant memory block.
        /// \param[in] buffer   Memory block.
        explicit U8pkmblock(const Base::Mblock<Uint16>& buffer);

        /// Packed Block of Bytes Constructor with Given Parameters.
        /// \wi{20506}
        /// U8pkmblock class shall build itself upon construction with the given packed block of bytes and size.
        /// \param[in] block        Memory block to build of.
        /// \param[in] size         Size for the block of bytes, it must be <= (block.size - offset).
        U8pkmblock(const U8pkmblock& block, Uint32 size);

        /// Packed Block of Bytes Constructor with Given Parameters.
        /// \wi{20507}
        /// U8pkmblock class shall build itself upon construction with the given packed block of bytes, offset and
        /// size.
        /// \param[in] block        Memory block to build of.
        /// \param[in] offset       Offset in the input memory block.
        /// \param[in] size         Size for the block of bytes, it must be <= (block.size - offset).
        U8pkmblock(const U8pkmblock& block, Uint32 offset, Uint32 size);

        /// Packed Block of Bytes Volatile Value Setter.
        /// \wi{5985}
        /// U8pkmblock class shall provide the capability to volatile set a byte given its index and value.
        /// \pre Warning, C2000 implementation does not allow index greater than 16 bits.
        /// \param[in] i        Byte index.
        /// \param[in] value    Value to be set.
        void set(Uint32 i, Uint8 value) volatile;

        /// Packed Block of Bytes Memory Block Converter.
        /// \wi{5987}
        /// U8pkmblock class shall provide the capability to obtain a memory block of 16bits representation of itself.
        /// \return This U8 memory block as a Uint16 memory block.
        Base::Mblock_u16 to_mblock() const;

        /// Packed Block of Bytes Memory Writer.
        /// \wi{5989}
        /// U8pkmblock class shall provide the capability to write a part of itself from a provided memory 
        /// block and optionally, a writting offset, a read offset and a read count.
        /// \param[in] start_idx    Offset to write into this block.
        /// \param[in] mb           Data buffer to write.
        /// \param[in] src_offset   Offset in the data to write.
        /// \param[in] src_count    Number of bytes to write.
        /// \return Bytes actually written (stops writing at end of buffer).
        Uint32 write(Uint32 start_idx, const U8pkmblock_k& mb, Uint32 src_offset, Uint32 src_count);

        /// Packed Block of Bytes Volatile Memory Writer.
        /// \wi{20508}
        /// U8pkmblock class shall provide the capability to volatile write a part of itself from a provided memory
        /// block, starting at 0 to the size of the provided memory block.
        /// \param[in] src      Data buffer to write.
        /// \return Bytes actually written (stops writing at end of buffer).
        Uint32 write(const U8pkmblock_k& src) volatile;

        /// Packed Block of Bytes Zero Setter
        /// \wi{20509}
        /// U8pkmblock class shall provide the capability to set all bytes of block to zero value.
        void zeros();
    };

    inline U8pkmblock::U8pkmblock() : U8pkmblock_k(static_cast<void*>(0), 0)
    {
        /// \alg
        /// - Call to parent constructor U8pkmblock_k with null values.
    }

    inline U8pkmblock::U8pkmblock(Uint32 sz, Memmgr::Type mtype) :
        U8pkmblock_k((static_cast<int16*>(Memmgr::get_instance().get_allocator(mtype).allocate(
                        Bitutils::bytes_to_words16(sz), sizeof(int16)))),
                     sz)
    {
        /// \alg
        /// - Call to parent constructor U8pkmblock_k with given parameters.
    }

    inline U8pkmblock::U8pkmblock(Uint32 sz, Allocator&alloc) :
        U8pkmblock_k(static_cast<int16*>(alloc.allocate(Bitutils::bytes_to_words16(sz), sizeof(int16))),
                     sz)
    {
        /// \alg
        /// - Call to parent constructor U8pkmblock_k with given parameters.
    }

    inline U8pkmblock::U8pkmblock(const void* data, Uint32 size_bytes) :
        U8pkmblock_k(reinterpret_cast<int16*>(const_cast<void*>(data)), size_bytes)
    {
        /// \alg
        /// - Call to parent constructor U8pkmblock_k with given parameters.
    }

    inline U8pkmblock::U8pkmblock(const volatile void* data, Uint32 size_bytes) :
        U8pkmblock_k(reinterpret_cast<int16*>(const_cast<void*>(data)), size_bytes)
    {
        /// \alg
        /// - Call to parent constructor U8pkmblock_k with given parameters.
    }

    inline U8pkmblock::U8pkmblock(const Base::Mblock<Uint16>& mb) :
        U8pkmblock_k(mb)
    {
        /// \alg
        /// - Call to parent constructor U8pkmblock_k with given parameter.
    }

    inline U8pkmblock::U8pkmblock(const U8pkmblock& block, Uint32 size0) :
        U8pkmblock_k(block, size0)
    {
        /// \alg
        /// - Call to parent constructor U8pkmblock_k with given parameters.
    }

    inline U8pkmblock::U8pkmblock(const U8pkmblock& block, Uint32 offset, Uint32 size0) :
        U8pkmblock_k(block, offset, size0)
    {
        /// \alg
        /// - Call to parent constructor U8pkmblock_k with given parameters.
    }

    inline void U8pkmblock::set(Uint32 i, Uint8 value) volatile  //PRQA S 4211 #const
    {
        /// \alg
        /// - Call Bitutils::set_u8 with U8pkmblock_k::v, given index and given value.
        Bitutils::set_u8(v, i, value);
    }

    inline Mblock_u16 U8pkmblock::to_mblock() const
    {
        /// \alg
        /// - Return Mblock_u16 instant built with Uint16 pointer cast for U8pkmblock_k::v and retrieved value by 
        /// Bitutils::bytes_to_words16 with U8pkmblock_k::sz.
        return Mblock_u16(reinterpret_cast<Uint16 *>(v), Bitutils::bytes_to_words16(sz));
    }

    inline void U8pkmblock::zeros()
    {
        /// \alg
        /// - Call Tmem::set_sel with U8pkmblock_k::v, 0, and retrieved value by Bitutils::bytes_to_words16 with 
        /// U8pkmblock_k::sz.
        Tmem::set_sel(v, 0, Bitutils::bytes_to_words16(sz));
    }
}
#endif
