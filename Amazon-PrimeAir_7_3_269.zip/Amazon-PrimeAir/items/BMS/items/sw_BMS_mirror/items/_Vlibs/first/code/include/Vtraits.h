#ifndef VTRAITS_H_
#define VTRAITS_H_

#include <Ku16.h>
#include <Ku32.h>
#include <Ttraits.h>

namespace Base
{

    /// Base friendly value result (standarizes templates returning values).
    template <typename T, T value0>
    struct Value_is
    {
        static const T value = value0;
    };

    struct True_type : Value_is<bool, true>
    {
    };

    struct False_type : Value_is<bool, false>
    {
    };

    template <Uint32 nbits>
    struct bits_to_bytes_c
    {
        static const Uint16 value = static_cast<Uint16>((nbits + Ku16::u7)>>Ku16::u3);
    };

    template <Uint32 nbytes>
    struct bytes_to_bits_c
    {
        static const Uint16 value = nbytes<< Ku16::u3;
    };

    template <Uint32 nbits>
    struct bits_to_words16_c
    {
        static const Uint16 value = (nbits+Ku16::u16-1)/Ku16::u16;
    };

    template<Uint32 nbytes>
    struct bytes_to_words16_c
    {
        static const Uint32 value = (nbytes+1) >> Ku16::u1;
    };

    template<Uint32 nwords16>
    struct words16_to_bytes_c
    {
        static const Uint32 value = nwords16 * 2;
    };

    template<Uint64 v>
    struct Enabled_bits_of : Value_is<Uint16, (v&1U) + Enabled_bits_of<(v>>1U)>::value>
    {
    };

    template<>
    struct Enabled_bits_of<0> : Value_is<Uint16, 0>
    {
    };

    /// Size of a type in bits
    template<typename T>
    struct Sizeof_bits : Value_is<Uint16, sizeof(T)*Enabled_bits_of<static_cast<Uint8>(-1)>::value>
    {
    };

    template<typename T>
    struct Sizeof_bytes : Value_is<Uint16, bits_to_bytes_c<Sizeof_bits<T>::value>::value >
    {
    };

    /// Compile time 1-bit set value
    template<typename T, Uint16 pos>
    struct Bitset : Value_is<T, static_cast<T>(1) << pos >
    {
    };

    /// Type for "allowing" bitset
    template<Uint16 pos>
    struct Bitset8 : public Bitset<Uint8, pos>
    {};

    template<Uint16 pos>
    struct Bitset16: public Bitset<Uint16, pos>
    {};

    template<Uint16 pos>
    struct Bitset32 : public Bitset<Uint32, pos>
    {};

    template<Uint16 pos>
    struct Bitset64 : public Bitset<Uint64, pos>
    {};

    /// Check if a bit is set in T value
    template <typename T>
    inline bool has_bit_set(T value, Uint16 idx)
    {
        return (value & static_cast<T>(1)<<idx) != 0;
    }

    template <typename T>
    inline void set_bit(T& data, Uint16 idx, bool value)
    {
        data = (data & ~(static_cast<T>(1) << idx)) | (static_cast<T>(value) << idx);
    }
    /// Compile time mask computation (LSB aligned)
    // Example:
    //          Base::Lsbmask<Uint8, 2>::value = 0b00000011
    template<typename T, Uint16 width>
    struct Lsbmask : Value_is<T, Bitset<T, width-1>::value | Lsbmask<T, width-1>::value >
    {
    };

    template<typename T>
    struct Lsbmask<T,0> : Value_is<T, 0>
    {
    };

    /// Compile time mask computation (with offset)
    template<typename T, Uint16 offset, Uint16 width>
    struct Mask : Value_is<T, Lsbmask<T, width>::value << offset >
    {
    };

    /// Compile time mask computation (MSB aligned)
    // Example:
    //          Base::Msbmask<Uint8, 2>::value = 0b11000000
    template<typename T, Uint16 width>
    struct Msbmask : Mask<T, (Sizeof_bits<T>::value-width), width >
    {
    };


    template<class T, class U>
    struct Is_same : False_type
    {
    };
    template<class T>
    struct Is_same<T, T> : True_type
    {
    };

    template<class T>
    struct Is_const : Is_same<T, const T>
    {
    };

    template <class T>
    struct Is_reference : False_type
    {
    };
    template <class T>
    struct Is_reference<T&> : True_type
    {
    };

    template <typename T> struct Is_signed : Value_is<bool, T(-1) < T(0)> //PRQA S 3100 #redundant cast for
    {                                                                     //             this instantiation
    };

    template<typename T, T v1, T v2>
    struct Value_min : Value_is<T, (v1<v2) ? v1 : v2>
    {
    };

    template<typename T, T v1, T v2>
    struct Value_max : Value_is<T, (v1>v2) ? v1 : v2>
    {
    };
}
#endif

