#ifndef VSTRING_H__
#define VSTRING_H__

#include <Kstring.h>
#include <Ku8.h>
#include <Ku32.h>

namespace Base
{

    /// Vstring
    /// Base library shall provide a structure for handling and storing of modifiable string.
    struct Vstring : public Kstring
    {
    public:
        /// Modifiable String Constructor with Length and Memory Type.
        /// \wi{4514}
        /// Vstring structure shall build itself upon construction and initialize its internal members given the
        /// maximum length of the string (excluding the NULL character) and the memory type.
        /// \param[in] max_length The maximum length excluding the NULL character.
        /// \param[in] type The type of the memory where the string shall be stored.
        Vstring(Uint32 max_length, Memmgr::Type type);

        /// Modifiable String Constructor with Memory Block.
        /// \wi{19675}
        /// Vstring structure shall build itself upon construction and initialize its internal members with
        /// memory type.
        /// \param[in] buffer Memory block to work with.
        explicit Vstring(Mblock<char> buffer);

        /// Modifiable String Effective Length.
        /// \wi{5350}
        /// Vstring structure shall provide the capability to retrieve the length of the string without the NULL
        /// character, which is known as the effective length.
        /// \return The effective length of the string.
        Uint32 effective_length() const;

        /// Modifiable String Clear.
        /// \wi{5351}
        /// Vstring structure shall provide the capability to set the string to a NULL character.
        void clear();

        /// Modifiable String Length Setter.
        /// \wi{5352}
        /// Vstring structure shall provide the capability to set the string length to the given input
        /// value plus one, to account for the NULL character at the end of the string.
        /// \pre The input length is not greater than the maximum possible array length, otherwise the action
        /// will not be performed.
        /// \param[in] len      The desired length value excluding the NULL character length.
        void set_length(Uint16 len);

        /// Modifiable String Character Append.
        /// \wi{5353}
        /// Vstring structure shall provide the capability to append a single character at the end of the string.
        /// \pre The length of string is less than or equal the maximum possible array length by 2 at least.
        /// \param[in] c The character to be appended.
        void append_char(const char c);

        /// Modifiable String Constant String Append.
        /// \wi{5354}
        /// Vstring structure shall provide the capability to append a constant string at the end of the string.
        /// \pre The given str length added to the effective length plus 1 shall be less than or equal
        /// the maximum possible array length.
        /// \param[in] str The constant string to be appended.
        void append_kstr(const Kstring& str);

        /// Modifiable String Memory Block Retriever.
        /// \wi{6318}
        /// Vstring structure shall provide the capability to retrieve the memory block where the string is stored, 
        /// excluding the NULL character.
        ///\return Mblock for the current string data.
        const Mblock<const char> to_mblock();

        /// This reference is used to access to all constant methods of the base Array.
        Array<char>& s;
    private:
        static const char zero_ch = '0';                    ///< Null character shall be at the end of the string.
        /// Modifiable String Setter.
        /// \wi{19676}
        /// The Vstring structure shall provide the capability to set the string using a given pointer to the 
        /// first element of a character array. Additionally, it shall be specified the string length and 
        /// the offset for displacement within the current existing string. The offset has a default value of 0.
        /// \param[in] src              Pointer to first element in the string to be copied.
        /// \param[in] len              Length of the array to be set.
        /// \param[in] dst_offset       Offset to be displaced in the existing string (default is 0).
        void set(const char* src,
                 Uint32 len,
                 Uint32 dst_offset = 0);

        Vstring(const Vstring& str);                        ///< = delete.
        Vstring& operator=(const Vstring& src);             ///< = delete.
    };


    inline Uint32 Vstring::effective_length() const
    {
        /// \alg
        /// - Return Array::size - 1.
        return Array::size() - 1;
    }

    inline void Vstring::clear()
    {
        /// \alg
        /// - Call Array::resize passing to it 1 and set Array::v[0] to ::zero_ch.
        Array::resize(1);
        v[0] = zero_ch;
    }

    inline void Vstring::set_length(Uint16 len)
    {
        /// \alg
        /// <ul>
        ///     <li> IF given "len" is less than Array::size_max - 1, THEN:
        ///     <ul>
        ///         <li> Call Array::resize passing to it given "len"+1 and Array::v["len"] to ::zero_ch.
        ///     </ul>
        /// </ul>
        if( len < (size_max()-1) )
        {
            Array::resize(len + 1);
            v[len] = zero_ch;
        }
    }

    inline void Vstring::append_char(const char c)
    {
        /// \alg
        /// - Call ::set passing to it the address of "c", 1 and ::effective_length.
        set(&c, 1, effective_length());
    }

    inline void Vstring::append_kstr(const Kstring& str)
    {
        /// \alg
        /// - Call ::set passing to it Array::first in Kstring::k in "str", Kstring::length in "str"
        /// and retrieved value by ::effective_length.
        set(str.k.first(), str.length(), effective_length());
    }

    inline const Mblock<const char> Vstring::to_mblock()
    {
        /// - Return Mblock with template argument const char and function argument Array::first in Kstring::k
        /// as well as the retrieved value by ::effective_length.
        return Mblock<const char>(k.first(), effective_length());
    }
}
#endif
