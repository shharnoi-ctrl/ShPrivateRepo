#ifndef MUTEX_H__
#define MUTEX_H__

#include <Entypes.h>

namespace Base
{
    /// Class to manage critical sections. It ensures state is restored on destructor.
    class Mutex
    {
    public:
        /// Mutex Default Constructor.
        /// \wi{7748}
        /// Mutex class shall build itself upon construction and initialize its internal members either
        /// locked or unlocked.
        /// \param[in] enter        When True, it starts critical section on construction time. Default False.
        explicit Mutex(bool enter=false);
        /// Critical Section Enter.
        /// \wi{7749}
        /// Mutex class shall be able to enter a critical section if not done.
        void enter_critical_section();
        /// Critical Section Exit.
        /// \wi{7750}
        /// Mutex class shall be able to exit from a critical section if it was inside.
        void exit_critical_section();
        /// Mutex Default Destructor.
        /// \wi{7751}
        /// Mutex class shall ensure that critical section has exited when object scope finishes.
        ~Mutex();

    private:
        Uint32 cpu_sr;      ///< Saved status on enter to be able to restore on exit.
        bool entered;       ///< Flag to ensure same object does not start critical section more than once.
        
        Mutex(const Mutex& orig);               ///< = delete.
        Mutex& operator=(const Mutex& orig);    ///< = delete.
    };
}
#endif
