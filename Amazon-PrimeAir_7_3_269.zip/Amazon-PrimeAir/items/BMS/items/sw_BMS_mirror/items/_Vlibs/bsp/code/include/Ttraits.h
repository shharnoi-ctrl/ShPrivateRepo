#ifndef TTRAITS_H_
#define TTRAITS_H_

#include <Entypes.h>

/// Type support imitating standard <type_traits> library header.
namespace Base
{

    /// Base friendly type result (standarizes templates returning types).
    template <typename T>
    struct type_is
    {
        typedef T type;
    };


    /// Compare 2 type to be the same
    template<class T, class U>
    struct is_same
    {
        static const bool value = false;
    };

    template<class T>
    struct is_same<T, T>
    {
        static const bool value = true;
    };


    /// Enable_if::type defined as T if and only if B is true.
    /// Enable_if::Else::type defined always. If B is true, defined as T, else defined as TELSE.
    /// Specialization for false case.
    template<bool B, typename T = void>
    struct Enable_if
    {
        template<typename TELSE>
        struct Else : type_is<TELSE>
        {
        };
    };

    /// Specialization of Enable_if and Enable_if::Else for true case.
    template<typename T>
    struct Enable_if<true, T> : type_is<T>
    {
        template<typename TELSE>
        struct Else : type_is<T>
        {
        };
    };

    /// Remove_const
    template<typename T>
    struct Remove_const : type_is<T>
    {
    };

    template<typename T>
    struct Remove_const<T const> : type_is<T>
    {
    };

    // remove volatile
    template<typename T>
    struct Remove_volatile : type_is<T>
    {
    };

    template<typename T>
    struct Remove_volatile<T volatile> : type_is<T>
    {
    };

    template<typename T>
    struct Remove_cv : Remove_volatile<typename Remove_const<T>::type>
    {
    };

    /// remove reference
    template<typename T>
    struct Remove_reference : type_is<T>
    {
    };
    template<typename T>
    struct Remove_reference<T&> : type_is<T>
    {
    };

    template<typename T>
    struct Remove_cvref : Remove_volatile<typename Remove_const<typename Remove_reference<T>::type >::type>
    {
    };



    // copy cv qualifiers
    template<typename FROM, typename TO>
    struct Copy_volatile : Remove_volatile<TO>
    {
    };

    template<typename FROM, typename TO>
    struct Copy_volatile<FROM volatile, TO> : type_is<typename Remove_volatile<TO>::type volatile>
    {
    };


    /// Rule 116: Small, concrete-type arguments (two or three words in size) should be passed
    /// by value if changes made to formal parameters should not be reflected in the calling function.
    /// This template selects between pass by value or const reference.
    template<typename T>
    struct JSF116_param : Enable_if<sizeof(T) <= (2*sizeof(JSF119_word)), T>::template Else<const T&>
    {
    };

    typedef JSF116_param<int64>::type  JSF116_int64;
    typedef JSF116_param<Uint64>::type JSF116_Uint64;
    typedef JSF116_param<Real64>::type JSF116_Real64;

    template <typename T1, typename T2>
    struct union_of
    {
        union type      //PRQA S 2406
        {               //#No float variable is intended to be used as template type
            T1 first;
            T2 second;
        };
    };
}
#endif
