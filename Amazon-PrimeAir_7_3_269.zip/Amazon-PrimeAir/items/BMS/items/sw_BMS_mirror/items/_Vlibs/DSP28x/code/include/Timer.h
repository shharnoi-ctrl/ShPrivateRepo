#ifndef TIMER_H_
#define TIMER_H_

#include <Entypes.h>
#include <Isrptr.h>
//PRQA S 2301 EOF
//#Bit-fields are needed.

namespace Dsp28335_ent
{
    /// Timer Peripheral.
    class Timer
    {
    public:
        /// Hardware peripheral identifier.
        enum Id
        {
            timer0    = 0,  ///< (0) Timer 0.
            timer1    = 1,  ///< (1) Timer 1.
            timer2    = 2   ///< (2) Timer 2.
        };
        static const Uint16 timer_all = 3;  ///< Total number of Timers.

        /// Timer Peripheral Constructor.
        /// \wi{7799}
        /// Timer class shall build itself upon construction initializing its internal attributes with given arguments.
        /// \param[in] id0 Timer ID.
        /// \param[in] period Timer period. Zero or negative initializes it to maximum period.
        /// \param[in] start0 If true, Timer starts running, else, it is left stopped.
        Timer(Id id0, Real period, bool start0);
        /// Timer Peripheral Configuration.
        /// \wi{7800}
        /// When requested, Timer class shall configure the correct Timer peripheral with received period writing on
        /// correct register/s.
        /// \param[in] period Period of timer in seconds. Negative value means max.
        void config(Real period);
        /// Period Retriever.
        /// \wi{16654}
        /// When requested, Timer class shall retrieve the configured period for current timer.
        /// \return Period of timer in seconds.
        Real get_period() const;
        /// Timer Interruption Configuration.
        /// \wi{7801}
        /// Timer class shall provide the functionality of register an interrupt handler for current Timer.
        /// \param[in] p_isr Pointer to interrupt function handler. Null means disable interrupt.
        void config_irq(Isrptr p_isr);
        /// Timer Enable/Disable.
        /// \wi{7802}
        /// Timer class shall provide a function able to enable/disable the current timer.
        /// \param[in] run Status requested (enabled or disabled).
        void set_running(bool run);
        ///  Is Running Retriever.
        /// \wi{16661}
        /// When requested, Timer shall retrieve if Timer is running.
        /// \return True if Timer is running, False if not.
        bool is_running() const;
        /// Period Reload.
        /// \wi{7755}
        /// When requested, Timer class shall reload the period value updating the correct peripheral register/s.
        void reload();
        /// Overflow Flag Checker.
        /// \wi{7754}
        /// When requested, Timer class shall retrieve the overflow flag value reading from correct peripheral
        /// register.
        /// \return True if overflow occurred since last clear, False if not.
        bool is_ovf() const;
        /// Overflow Flag Clear.
        /// \wi{7753}
        /// When requested, Timer class shall clear the overflow flag using the correct peripheral register/s.
        void clear_ovf();
        /// Timer Value Retriever.
        /// \wi{16655}
        /// When requested, Timer class shall retrieve its value in tics as it is a downwards counter.
        /// \return Timer value in tics (period minus the counter, as it is a downwards counter).
        Uint32 get() const;
        /// Task Start.
        /// \wi{16656}
        /// Timer class shall provide a function to configure an interrupt handler with a given frequency using the
        /// Timer peripheral.
        /// \param[in] freq Period of execution.
        /// \param[in] cb Task to execute (interrupt handler).
        void start_task(Real freq, Isrptr cb);

    private:
        struct Cputimer_regs;           ///< Forward declaration of CPU Timer registers.
        const Id id;                    ///< Timer ID.
        volatile Cputimer_regs& regs;   ///< Peripheral registers for current ID.

        /// Registers Retriever.
        /// \wi{16658}
        /// Timer class shall provide a function able to retrieve the peripheral registers associated to a given Timer
        /// ID.
        /// \param[in] id0 Timer ID.
        /// \return Peripheral registers associated to given Timer ID.
        static volatile Cputimer_regs& get_regs(Id id0);
        /// Peripheral Interrupt Expansion (PIE) Enable.
        /// \wi{16659}
        /// Timer class shall provide a function to enable the PIE associated to given Peripheral Timer ID and given
        /// interrupt handler.
        /// \param[in] id0 Timer ID.
        /// \param[in] p_isr Task to be enabled (interrupt handler).
        static void pie_enable(Id id0, Isrptr p_isr);

        Timer(); ///< = delete
        Timer(const Timer& orig); ///< = delete
        Timer& operator=(const Timer& orig); ///< = delete
    };
}
#endif
