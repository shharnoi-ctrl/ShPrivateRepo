#ifndef MBLOCK_H_
#define MBLOCK_H_

#include <Entypes.h>
#include <Assertions.h>
#include <Memmgr.h>
#include <Tmem.h>
#include <Ttraits.h>
#include <Union_compatible.h>
#include <Vtraits.h>

namespace Base
{
    /// The Base library shall provide a structure to manage any field data abstraction as a memory block, 
    /// implemented and parameterized by one template parameter.
    template<typename T>
    struct Mblock //PRQA S 1701
    {
    public:
        typedef T type;

        T* const v;             ///< Pointer to the first element of the memory block.
        const Uint32 sz;        ///< Size of the memory block.

        /// Memory Block Copy Constructor with Given Constant Memory Block.
        /// \wi{5141}
        /// Mblock structure shall build itself upon construction with given constant memory block.
        /// \param[in] v0       Constant memory block to be copied upon construction.
        template<typename P>
        explicit Mblock(const Mblock<P>& v0);

        /// Memory Block Copy Constructor with Given Constant Volatile Memory Block.
        /// \wi{5142}
        /// Mblock structure shall build itself upon construction with given constant and volatile memory block.
        /// \param[in] v0       Constant and volatile memory block to be copied upon construction.
        template<typename P>
        explicit Mblock(const volatile Mblock<P>& v0);

        /// Memory Block Constructor with Given Templated Array.
        /// \wi{21052}
        /// Mblock structure shall build itself upon construction with given templated array.
        /// \param[in] v0       Templated array.
        template<typename TARRAY>
        explicit Mblock(TARRAY& v0);

        /// Memory Block Constructor with Native Array.
        /// \wi{21053}
        /// Mblock structure shall build itself upon construction with given Native Array.
        /// \param[in] v0  Native Array.
        template<Uint32 sz0>
        explicit Mblock(T(&v0)[sz0]);

        /// Memory Block Constructor with Size and Allocator.
        /// \wi{21054}
        /// Mblock structure shall build and allocate itself upon construction with a given size and a memory 
        /// allocation type.
        /// \param[in] sz0      Size of the memory block.
        /// \param[in] mtype    Type of memory allocator.
        Mblock(Uint32 sz0, Memmgr::Type mtype);

        /// Memory Block Constructor with Pointer to First Element and Size.
        /// \wi{21055}
        /// Mblock structure shall build itself upon construction with given pointer to the first element and a size.
        /// \param[in] v0       Pointer to first element.
        /// \param[in] sz0      Size of the memory block.
        Mblock(T* v0, Uint32 sz0);

        /// Memory Block Last Element Retriever.
        /// \wi{5144}
        /// Mblock structure shall be able to retrieve the last element in a memory block.
        /// \return Last element in the memory block.
        const T* last() const;
        /// Memory Block Size Retriever.
        /// \wi{5146}
        /// Mblock structure shall be able to retrieve the number of the elements contained in a memory block.
        /// \return Number of elements contained in the memory block.
        Uint32 size() const;
        /// Memory Block Element Individual Access.
        /// \wi{5145}
        /// Mblock structure shall be able to access to any allocated element of the struct.
        /// \pre Assumes requesting index is not out of range.
        /// \param[in] i Mblock index to be accessed.
        /// \return Element requested.
        T& operator[](Uint32 i);
        /// Memory Block Element Individual Constant Access.
        /// \wi{21056}
        /// Mblock structure shall be able to access to any allocated element of the struct in a constant way.
        /// \pre Assumes requesting index is not out of range.
        /// \param[in] i Mblock index to be accessed.
        /// \return Element requested as constant.
        const T& operator[](Uint32 i)const;
        /// Memory Block Element Individual Volatile Access.
        /// \wi{21057}
        /// Mblock structure shall be able to access to any allocated element of the struct in a volatile way.
        /// \pre Assumes requesting index is not out of range.
        /// \param[in] i Mblock index to be accessed.
        /// \return Element requested as volatile.
        volatile T& operator[](Uint32 i) volatile;
        /// Memory Block Element Individual Constant and Volatile Access.
        /// \wi{21058}
        /// Mblock structure shall be able to access to any allocated element of the struct in a constant and 
        /// volatile way.
        /// \pre Assumes requesting index is not out of range.
        /// \param[in] i Mblock index to be accessed.
        /// \return Element requested as constant a volatile.
        const volatile T& operator[](Uint32 i)const volatile;

        /// Memory Block Zeros Setter.
        /// \wi{5147}
        /// Mblock shall provide the capability to set the contained memory block to 0.
        void zeros();

        /// Memory Block to Constant Memory Block Converter.
        /// \wi{5143}
        /// Mblock structure shall be able to retrieve a constant copy of its internal memory block.
        /// \return Constant memory block.
        Mblock<const T> to_const() const;

        /// Memory Block to Constant and Non Volatile Memory Block Converter.
        /// \wi{21059}
        /// Mblock structure shall be able to retrieve a constant and non volatile copy of its internal memory block.
        /// \return Constant and non volatile memory block.
        Mblock<const typename Remove_volatile<T>::type> to_non_volatile() const;

        /// Sub Memory Block Retriever with Given Size.
        /// \wi{5150}
        /// Mblock structure shall be able to retrieve a sub-block of the contained memory block with the given size.
        /// \param[in] newsz        New size of the sub memory block.
        /// \return Sub memory block with specified size.
        Mblock<T> sub_mblock_with_size(Uint32 newsz);
        /// Sub Memory Block Constant Retriever with Given New Size.
        /// \wi{21060}
        /// Mblock structure shall be able to retrieve a constant sub-block of the contained memory block with the 
        /// given size.
        /// \param[in] newsz        New size of the sub memory block.
        /// \return Constant Sub memory block with specified size.
        Mblock<const T> sub_mblock_with_size(Uint32 newsz) const;

        /// Sub Memory Block Retrieved Starting at Given Index.
        /// \wi{5148}
        /// Mblock structure shall be able to retrieve a sub-block of the contained memory block starting
        /// at the given index.
        /// \param[in] idx          Index with which to start the sub memory block.
        /// \return Sub memory block starting at the given index.
        Mblock<T> sub_mblock_with_start_at(Uint32 idx);
        /// Sub Memory Block Constant Retrieved Starting at Given Index.
        /// \wi{21061}
        /// Mblock structure shall be able to retrieve a constant sub-block of the contained memory block starting
        /// at the given index.
        /// \param[in] idx          Index with which to start the sub memory block.
        /// \return Constant sub memory block starting at the given index.
        Mblock<const T> sub_mblock_with_start_at(Uint32 idx) const;

        /// Sub Memory Block Retrieved Starting at Given Index with Given New Size.
        /// \wi{5149}
        /// Mblock structure shall be able to retrieve a sub-block of the contained memory block starting
        /// at the given index with new size.
        /// \param[in] idx          Index with which to start the sub memory block.
        /// \param[in] newsz        New size of the sub memory block.
        /// \return Sub memory block starting at the given index with the given new size.
        Mblock<T> sub_mblock(Uint32 idx,Uint32 newsz);

        /// Sub Memory Block Constant Retrieved Starting at Given Index with Given New Size.
        /// \wi{21062}
        /// Mblock structure shall be able to retrieve a constant sub-block of the contained memory block starting
        /// at the given index with new size.
        /// \param[in] idx          Index with which to start the sub memory block.
        /// \param[in] newsz        New size of the sub memory block.
        /// \return Sub memory block starting at the given index with the given new size.
        Mblock<const T> sub_mblock(Uint32 idx,Uint32 newsz) const;

        /// Memory Block Copier.
        /// \wi{21063}
        /// Mblock structure shall provide the capability to copy one Mblock into another, and to check that the 
        /// source and the destination Mblocks have same size.
        /// \param[in] v0          Block to be copied.
        template<typename P>
        void copy(const Mblock<P>& v0);

    private:
        Mblock();                               ///< = delete.
        Mblock& operator=(const Mblock& orig);  ///< = delete.
    };

    typedef Mblock<Uint16> Mblock_u16;
    typedef Mblock<Uint32> Mblock_u32;

    template<typename T>
    template<typename P>
    inline Mblock<T>::Mblock(const Mblock<P>& v0) : v(v0.v), sz(v0.sz)
    {
    }

    template<typename T>
    template<typename P>
    inline Mblock<T>::Mblock(const volatile Mblock<P>& v0) : v(v0.v), sz(v0.sz)
    {
    }

    template<typename T>
    template<typename TARRAY>
    inline Mblock<T>::Mblock(TARRAY& v0) : v(&v0[0]), sz(v0.size())
    {
    }

    template<typename T>
    template<Uint32 sz0>
    inline Mblock<T>::Mblock(T(&v0)[sz0]) : v(v0), sz(sz0)
    {
    }

    template<typename T>
    inline Mblock<T>::Mblock(Uint32 sz0, Memmgr::Type mtype) :
        v(static_cast<T*>(Memmgr::get_instance().get_allocator(mtype).allocate(sz0, sizeof(T)))),
        sz(sz0)
    {
        Assertions::is_trivial<T>(); // Not to use with types that require constructor
    }

    template<typename T>
    inline Mblock<T>::Mblock(T* v0, Uint32 sz0) : v(v0), sz(sz0)
    {
    }

    template<typename T>
    inline const T* Mblock<T>::last() const
    {
        /// \alg
        /// - Retun pointer to ::v + ::sz - 1.
        return (v + sz - 1);
    }

    template<typename T>
    inline Uint32 Mblock<T>::size() const
    {
        return sz;
    }

    template<typename T>
    inline T& Mblock<T>::operator[](Uint32 i) //PRQA S 4211 #const
    {
        return v[i];
    }
    template<typename T>
    inline const T& Mblock<T>::operator[](Uint32 i)const
    {
        return v[i];
    }
    template<typename T>
    inline volatile T& Mblock<T>::operator[](Uint32 i) volatile
    {
        return v[i];
    }
    template<typename T>
    inline const volatile T& Mblock<T>::operator[](Uint32 i)const volatile
    {
        return v[i];
    }
    template<typename T>
    inline void Mblock<T>::zeros()
    {
        /// \alg
        /// - Call Tmem::set_sel with ::v, 0 and ::sz*sizeof(T).
        Tmem::set_sel(v,0,sz*sizeof(T));
    }

    template<typename T>
    inline Mblock<const T> Mblock<T>::to_const() const
    {
        /// \alg
        /// - Return constant Mblock initialized with ::v and ::sz.
        return Mblock<const T>(v, sz);
    }

    template<typename T>
    inline Mblock<const typename Remove_volatile<T>::type> Mblock<T>::to_non_volatile() const
    {
        /// \alg
        /// - Return Mblock with Remove_volatile template instance intialized with ::v and ::sz.
        return Mblock<const typename Remove_volatile<T>::type>(
            const_cast<const typename Remove_volatile<T>::type*>(v), sz);
    }

    template<typename T>
    inline Mblock<T> Mblock<T>::sub_mblock_with_size(Uint32 newsz) //PRQA S 4211 #const
    {
        /// \alg
        /// - Return Mblock instance initialized with ::v and minimum size between "newsz" and ::sz.
        return Mblock<T>(v, Assertions::runtime(newsz<=sz) ? newsz : sz);
    }
    template<typename T>
    inline Mblock<const T> Mblock<T>::sub_mblock_with_size(Uint32 newsz) const
    {
        /// \alg
        /// - Return constant Mblock instance initialized with ::v and and minimum size between "newsz" and ::sz.
        return Mblock<const T>(v, Assertions::runtime(newsz<=sz) ? newsz : sz);
    }

    template<typename T>
    inline Mblock<T> Mblock<T>::sub_mblock_with_start_at(Uint32 idx) //PRQA S 4211 #const
    {
        // null block considered invalid, in case it is admitted, '<=' should be used instead of '<'
        /// \alg
        /// - Return Mblock instance initialized with ::v["idx"] and ::sz-"idx", if given "idx" is lower than
        /// ::sz, otherwise with ::v[::sz] and 0 (null block).
        return Assertions::runtime(idx<sz) ? Mblock<T>(&v[idx], sz-idx) : Mblock<T>(&v[sz], 0);
    }
    template<typename T>
    inline Mblock<const T> Mblock<T>::sub_mblock_with_start_at(Uint32 idx) const
    {
        // null block considered invalid, in case it is admitted, '<=' should be used instead of '<'
        /// \alg
        /// - Return constant Mblock instance initialized with ::v["idx"] and ::sz-"idx", if given "idx" is lower 
        /// than ::sz, otherwise with ::v[::sz] and 0 (null block).
        return Assertions::runtime(idx<sz) ? Mblock<const T>(&v[idx], sz-idx) : Mblock<const T>(&v[sz], 0);
    }

    template<typename T>
    inline Mblock<T> Mblock<T>::sub_mblock(Uint32 idx,Uint32 newsz)
    {
        /// \alg
        /// - Return retrieved value by ::sub_mblock_with_size with given "newsz" in Mblock instance retrieved by 
        /// ::sub_mblock_with_start_at with given "idx".
        return sub_mblock_with_start_at(idx).sub_mblock_with_size(newsz);
    }

    template<typename T>
    inline Mblock<const T> Mblock<T>::sub_mblock(Uint32 idx,Uint32 newsz) const
    {
        /// \alg
        /// - Return retrieved value by ::sub_mblock_with_size with given "newsz" in Mblock instance retrieved by 
        /// ::sub_mblock_with_start_at with given "idx".
        return sub_mblock_with_start_at(idx).sub_mblock_with_size(newsz);
    }

    template<typename T>
    template<typename P>
    inline void Mblock<T>::copy(const Mblock<P>& src)
    {
        Assertions::Compile_time<(Is_same<typename Remove_cv<T>::type, typename Remove_cv<P>::type>::value)>();
        Assertions::Union_compatible<T>(); // Copy only plain types
        Assertions::runtime(sz == src.sz);
        /// \alg
        /// - Call Tmem::cpy_sel with ::v, given Mblock::v in given "src" and ::sz*sizeof(T).
        Tmem::cpy_sel(const_cast<typename Remove_volatile<T>::type*>(v),
                      const_cast<typename Remove_volatile<T>::type*>(src.v),
                      sz*sizeof(T));
    }
}
#endif
