#ifndef ECAP_IO_CTL_H_
#define ECAP_IO_CTL_H_

#include <ECAP.h>

namespace Dsp28335_ent
{
    /// \brief Handle registers configuration for ECAP.
    class ECAP_ioctl
    {
    private:
        /// Default input value if none especified. It makes the 2838x behave as a 2837x in terms of which
        /// Input is used for a given Peripheral (see GPIOxbar_in.h for pin assignments).
        static const Uint16 def_input = 127U;
    public:
        /// ECAP Configuration.
        /// \wi{16831}
        /// ECAP_ioctl class shall provide the capability to configure an ECAP with the given configuration.
        /// \param[in,out] ecap         ECAP to configure.
        /// \param[in]     cfg          ECAP peripheral configuration.
        /// \param[in]     xbar_input   Xbar input to use
        static void config(ECAP& ecap, const ECAPcfg& cfg, Uint16 xbar_input = def_input);

    private:
        ECAP_ioctl(); ///< = delete
        ECAP_ioctl(const ECAP_ioctl&); ///< = delete
        ECAP_ioctl& operator= (const ECAP_ioctl&); ///< = delete
    };
}
#endif

