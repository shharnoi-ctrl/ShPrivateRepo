#ifndef TUNDEFAULT_H_
#define TUNDEFAULT_H_

#include <Tuntraits.h>
#include <Tnarrayresz.h>
#include <Tarraycfg.h>
#include <Wsync.h>
#include <Wsync_des.h>

namespace Base
{
    namespace Tuntraits
    {
        /// Default Tuntraits for some type T.
        /// Note that a change in any default behavior can cause tunable incompatibilities.
        template <typename T>
        struct Tundefault : public Cxet<T>
        {
        };

        /// Default Tuntraits for some type T.
        /// Note that a change in any default behavior can cause tunable incompatibilities.
        template <typename T>
        struct Desdefault : public Cset_only<T>
        {
        };

        /// Default Async Tuntraits for some type T.
        /// Note that a change in any default behavior can cause tunable incompatibilities.
        template <typename T>
        struct Tundefault_async : public Cxet_async<T>
        {
        };

        /// Default Async Tuntraits for some type T.
        /// Note that a change in any default behavior can cause tunable incompatibilities.
        template <typename T>
        struct Desdefault_async : public Cset_only_async<T>
        {
        };


        template <>
        struct Tundefault<Uint8> : public Tuntraits::Lossy8<Uint8>
        {
        };

        template <>
        struct Tundefault<char> : public Tuntraits::Lossy8<char>
        {
        };

        template <>
        struct Tundefault<bool> : public Tuntraits::Lossy16<bool>
        {
        };

        template <>
        struct Tundefault<Uint16> : public Tuntraits::Lossy16<Uint16>
        {
        };

        template <>
        struct Tundefault<int16> : public Tuntraits::Lossy16<int16>
        {
        };

        template <>
        struct Tundefault<Real> : public Tuntraits::Lossy_float
        {
        };

        template <typename T, Uint32 n>
        struct Tundefault<Tnarray<T,n> > : public Arraytun_nosize<Tundefault<T>,Tnarray<T,n> >
        {
        };

        template <typename T, Uint32 n>
        struct Desdefault<Tnarray<T,n> > : public Arraytun_nosize<Desdefault<T>,Tnarray<T,n> >
        {
        };

        template <typename T>
        struct Tundefault<Array<T> > : public Arraytun_size16<Tundefault<T>,Array<T> >
        {
        };

        template <typename T>
        struct Desdefault<Array<T> > : public Arraytun_size16<Desdefault<T>,Array<T> >
        {
        };

        template <typename T>
        struct Tundefault<Array<T>& > : public Arraytun_size16<Tundefault<T>, Array<T>& >
        {
        };

        template <typename T>
        struct Desdefault<Array<T>& > : public Arraytun_size16<Desdefault<T>, Array<T>& >
        {
        };

        template <typename T, Uint32 n>
        struct Tundefault<Tnarrayresz<T,n> > : public Arraytun_size16<Tundefault<T>,Tnarrayresz<T,n> >
        {
        };

        template <typename T, Uint32 n>
        struct Desdefault<Tnarrayresz<T,n> > : public Arraytun_size16<Desdefault<T>,Tnarrayresz<T,n> >
        {
        };

        template <>
        struct Tundefault<Rv3> : public Rv3_nosize
        {
        };

        template <>
        struct Desdefault<Rv3> : public Rv3_nosize
        {
        };

        template <typename T, typename TDTRAITRD, typename TDTRAITWR>
        struct Tundefault<Tdsync<T,TDTRAITRD,TDTRAITWR> > : public Wsync<Tdsync<T,TDTRAITRD,TDTRAITWR>, Tundefault<T> >
        {
        };

        template <typename T, typename TDTRAITRD, typename TDTRAITWR>
        struct Desdefault<Tdsync<T,TDTRAITRD,TDTRAITWR> > : public Wsync_des<Tdsync<T,TDTRAITRD,TDTRAITWR>, Desdefault<T> >
        {
        };

        template <typename T,Uint16 sz>
        struct Tundefault<Arraymsk<T,sz> > : public Tunarraymsk<T,sz>
        {
        };

        template <typename T,Uint16 sz>
        struct Desdefault<Arraymsk<T,sz> > : public Tunarraymsk<T,sz>
        {
        };
    }
}
#endif
