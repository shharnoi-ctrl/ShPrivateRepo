#ifndef INTERRUPTS_H_
#define INTERRUPTS_H_

#include <Entypes.h>

namespace Bsp
{
    namespace Interrupts
    {
        /// Disable global interrupts.
        /// \return status.
        extern Uint16 global_disable();

        /// Restore global interrupts.
        /// \param cpu_sr status to restore given by global disable.
        extern void global_restore(Uint16 cpu_sr);
    }
}
#endif
