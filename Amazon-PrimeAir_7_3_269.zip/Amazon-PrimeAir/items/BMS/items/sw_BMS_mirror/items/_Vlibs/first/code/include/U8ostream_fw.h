#ifndef U8OSTREAM_FW_H_
#define U8OSTREAM_FW_H_

namespace Base
{
    class U8ostream;
}
#endif
