#ifndef ERROR_H_
#define ERROR_H_

#include <Entypes.h>
#include <Errorsrc.h>
#include <Array.h>
#include <Tnarray.h>

namespace Base
{
    /// Error report management.
    /// The ::Base library shall provide the capability to store errors in a list for further usage.
    class Error
    {
    public:
        typedef Array<Errorsrc> Error_l;    ///< Type definition for the errors list.

        /// Error constructor.
        /// \wi{6106}
        /// Error class shall be able initialize itself with an empty error list.
        Error();

        /// Error setter.
        /// \wi{6107}
        /// Error class shall provide the capability to store check and store a provided error in its list,
        /// and sets up a debug breakpoint (only used when in debug mode with the probe connected).
        /// \param[in] ck       Checking condition. If false, error will be stored.
        /// \param[in] e_src    Error source identifier. If different than err_ok, error will be stored.
        /// \return The value of the provided checking condition.
        bool assrt(bool ck, Errorsrc e_src);

        /// Error OK.
        /// \wi{6109}
        /// Error class shall provide the capability to check if it has no errors.
        /// \return True if there are no errors, false other case.
        bool is_ok() const;

        /// Error failed.
        /// \wi{6108}
        /// Error class shall provide the capability to store a provided error in its list.
        /// \param[in] e_src    Error source identifier (shall be different of err_ok to be asserted).
        void failed(Errorsrc e_src);

        /// Error list getter.
        /// \wi{13400}
        /// Error class shall be able to retrieve its error list.
        /// \return Array of appended errors (could be zero size).
        const Error_l& get_errors() const;

        /// Error last getter.
        /// \wi{13401}
        /// Error class shall be able to retrieve the last error from its list.
        /// \return Last asserted error source, if none it shall return err_ok.
        Errorsrc get_error() const;

        /// Error reset.
        /// \wi{6657}
        /// Error class shall be able to clear the error list by removing all its elements.
        void reset();

    private:
        static const Uint16 max_nb_errors = 4U; ///< Maximum number of errors that can handle the array.
        Tnarray<Errorsrc, max_nb_errors> buff;  ///< Buffer of errors to construct the list (as Array).
        Error_l errors;                         ///< Errors list (as Array).

        Error(const Error& src); ///< = delete
        Error& operator=(const Error& src); ///< = delete
    };

    inline void Error::failed(Errorsrc e_src)
    {
        assrt(false,e_src);
    }

    inline const Error::Error_l& Error::get_errors() const
    {
        return errors;
    }

    inline Errorsrc Error::get_error() const
    {
        return Assertions::runtime(!is_ok()) ? *errors.last() : err_ok;
    }

    inline bool Error::is_ok() const
    {
        return (errors.size() == 0U);
    }

    inline void Error::reset()
    {
        errors.resize(0);
    }
}
#endif
