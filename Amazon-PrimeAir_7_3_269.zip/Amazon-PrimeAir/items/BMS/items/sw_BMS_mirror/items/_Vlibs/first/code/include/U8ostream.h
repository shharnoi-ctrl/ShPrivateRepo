#ifndef U8OSTREAM_H_
#define U8OSTREAM_H_

#include <Bitutils.h>
#include <Real16.h>
#include <Ttraits.h>
#include <U8pkmblock.h>
#include <U8pkmblock_k.h>

namespace Base
{
    /// Output byte streamer with Little and Big endian supported.
    class U8ostream
    {
    public:
        /// Data traits for 8-bit data type.
        template <typename TYPE = U8ostream>
        struct Data_traits8 : public type_is<TYPE>
        {
            /// Data Retriever.
            /// \wi{18050}
            /// Data_traits8 for U8ostream structure shall be able to retrieve data for the output byte stream.
            /// \param[in] os       Output byte stream instance.
            /// \return Data storage in output byte stream.
            static inline U8pkmblock get_data(const U8ostream& os)
            {
                /// \alg
                /// - Return memory block value for the U8ostream received instance.
                return os.mb;
            }

            /// Data Size Retriever.
            /// \wi{18051}
            /// Data_traits8 for U8ostream structure shall be able to retrieve size of the data for the 
            /// output byte stream in bytes.
            /// \param[in] os       Output byte stream instance.
            /// \return Size of the output byte stream in bytes.
            static inline Uint32 get_size(const U8ostream& os)         
            {
                /// \alg
                /// - Return U8ostream::get_pos retrieved value for the U8ostream received instance.
                return os.get_pos();
            }

            /// 8-bit Size Updater.
            /// \wi{18052}
            /// Data_traits8 for U8ostream structure shall be able to update size of the data for the output byte 
            /// stream assuming it is being received in bytes.
            /// \param[in] os       Output byte stream instance.
            /// \param[in] sz       Size to increase.
            static inline void update_size(U8ostream& os, Uint32 sz)
            {
                /// \alg
                /// - Update the position of the data by adding the U8ostream::get_pos with the received size.
                os.seek(os.get_pos() + sz);
            }

            /// 8-bit Maximum Size Retriever.
            /// \wi{18053}
            /// Data_traits8 for U8ostream structure shall be able to retrieve maximum size of the data for the 
            /// output byte stream in bytes.
            /// \param[in] os       Output byte stream instance.
            /// \return Maximum size allowed for the output byte stream in bytes.
            static inline Uint16 get_max_size(U8ostream& os)
            {
                /// \alg
                /// - Return U8ostream::get_max_size retrieved value for the output instance.
                return os.get_max_size();
            }

            /// 8-bit Pointer Retriever.
            /// \wi{18056}
            /// Data_traits8 for U8ostream structure shall be able to retrieve Position of the data for the 
            /// output byte stream in bytes.
            /// \param[in] os       Output byte stream instance.
            /// \return Position of the output byte stream in bytes.
            static inline Uint16 get_pos(const U8ostream& os)
            {
                /// \alg
                /// - Return U8ostream::get_pos retrieved value for the output instance.
                return os.get_pos();
            }
        };

        /// Mutator traits for 8-bit data type.
        struct Mutator_traits8 : public type_is<U8ostream>
        {
            /// Adapt Constant 16-bit Block Type to 8-bit Block Type.
            /// \wi{18058}
            /// Mutator_traits8 for U8ostream structure shall provide a function to adapt a 16-bit 
            /// constant memory block into a 8-bit memory block.
            /// \param[in] mb Data represented as a 16-bit constant memory block.
            /// \return Data represented as a 8-bit memory block.
            static inline U8pkmblock adapt_data(const Mblock_u16& mb)
            {
                /// \alg
                /// - Return U8pkmblock::U8pkmblock retrieved reference for the output instance.
                return U8pkmblock(mb);
            }

            /// Adapt Constant 8-bit Block Type to 8-bit Block Type.
            /// \wi{18059}
            /// Mutator_traits8 for U8ostream structure shall provide a function to adapt a 8-bit 
            /// constant memory block into a 8-bit memory block.
            /// \param[in] mb Data represented as a 8-bit constant memory block.
            /// \return Data represented as a 8-bit memory block.
            static inline U8pkmblock adapt_data(const U8pkmblock& mb)  
            {
                /// \alg
                /// - Return U8pkmblock::U8pkmblock retrieved reference for the output instance.
                return U8pkmblock(mb);
            }

            /// 8-bit Size Retriever.
            /// \wi{18060}
            /// Mutator_traits8 for U8ostream structure shall provide a function to retrieve the 8-bit 
            /// size of a given U8ostream instance in bytes.
            /// \param[in] os U8ostream instance being requested.
            /// \return Current position of the given output stream in bytes.
            static inline Uint32 get_size(const U8ostream& os)            
            {
                /// \alg
                /// - Return U8ostream::get_pos retrieved value for the output instance.
                return os.get_pos();
            }

            /// 8-bit Position Setter.
            /// \wi{18061}
            /// Mutator_traits8 for U8ostream structure shall provide a function to update the internal pointer
            /// of given U8ostream instance assuming new size is being provided in 8-bit size.
            /// \param[out] os U8ostream instance which size will be updated.
            /// \param[in] sz New position to set, provided in 8-bit size.
            static inline void set_pos(U8ostream& os, Uint16 sz)
            {
                /// \alg
                /// - Call to U8ostream::seek for the input instance with the output parameter sz.
                os.seek(sz);
            }
        };

        /// Data traits for 16-bit data type.
        struct Mutator_traits16 : public type_is<U8ostream>
        {
            /// Adapt Constant 16-bit Block Type to 8-bit Block Type.
            /// \wi{18062}
            /// Mutator_traits16 for U8ostream structure shall provide a function to adapt a 16-bit 
            /// constant memory block into a 8-bit memory block.
            /// \param[in] mb Data represented as a 16-bit constant memory block.
            /// \return Data represented as a 8-bit memory block.
            static inline U8pkmblock adapt_data(const Mblock_u16& mb) 
            {
                /// \alg
                /// - Return U8pkmblock::U8pkmblock retrieved reference for the output instance.
                return U8pkmblock(mb);
            }

            /// 16-bit Size Retriever.
            /// \wi{18063}
            /// Mutator_traits16 for U8ostream structure shall provide a function to retrieve 
            /// the 16-bit size of a given U8ostream instance.
            /// \param[in] os U8ostream instance being requested.
            /// \return Current position of the given output stream in 16-bit words.
            static inline Uint32 get_size(const U8ostream& os)            
            {
                /// \alg
                /// - Return the size of the output byte stream by converting the number of bytes obtained 
                /// from U8ostream::get_pos() to 16-bit words using Bitutils::bytes_to_words16.
                return Bitutils::bytes_to_words16(os.get_pos());
            }

            /// 16-bit Position Setter.
            /// \wi{18064}
            /// Mutator_traits16 for U8ostream structure shall provide a function to update the internal pointer 
            /// of given U8ostream instance assuming new size is being provided in 16-bit size.
            /// \param[in] os       Input byte stream instance.
            /// \param[in] sz New size to be applied being provided in 16-bit size.
            static inline void set_pos(U8ostream& os, Uint16 sz)
            {
                /// \alg
                /// - Set the position of the output byte stream instance by converting the input size in 16-bit words 
                /// to bytes using Bitutils::words16_to_bytes and then using U8ostream::seek to update the position.
                os.seek(Bitutils::words16_to_bytes(sz));
            }
        };

        /// U8ostream Constant Copy Constructor.
        /// \wi{18065}
        /// U8ostream class shall build itself upon construction with a given 8-bit memory block.
        /// \param[in] mb0 Memory block.
        explicit U8ostream(const U8pkmblock& mb0);  

        /// U8ostream Constructor with given Memory block and offset.
        /// \wi{6385}
        /// U8ostream class shall build itself upon construction with a given 8-bit memory block and offset position.
        /// \param[in] mb0 Memory block.
        /// \param[in] offset Offset of memory block.
        U8ostream(const U8pkmblock& mb0, Uint32 offset);  

        /// U8ostream Pointer Restart.
        /// \wi{18066}
        /// When requested, U8ostream class shall restart its internal serializer pointer.
        void reuse();                       

        /// U8ostream Current Position Setter.
        /// \wi{18067} 
        /// U8ostream class shall be able to set its internal serializer pointer to given one.
        /// \param[in] pos0 New byte position to be used.  
        /// \return  True if new position is valid, False if not.    
        bool seek(Uint32 pos0);             

        /// U8ostream Current Position Retriever.
        /// \wi{18068}  
        /// U8ostream class shall be able to retrieve its internal serializer position in bytes.
        /// \return Current byte position.
        Uint32 get_pos() const;             
        
        /// Constant Maximum Size Retriever.
        /// \wi{18069} 
        /// U8ostream class shall be able to retrieve maximum size of the data for the output byte stream in bytes.
        /// \return Maximum Buffer size. 
        Uint32 get_max_size() const;        

        /// Constant Memory Block Retriever.
        /// \wi{18070} 
        /// U8ostream class shall be able to return a constant 8-bit type memory block with already used data.
        /// \return Constant Memory Block with already written data.
        U8pkmblock_k to_mblock8() const;    

        /// 8-bit Unsigned Integer Serializer.
        /// \wi{18071} 
        /// U8ostream class shall be able to serialize a 8-bit unsigned integer value into the internal stream of data.
        /// \param[in] v 8-bit Unsigned Integer value to be serialized.
        void put_uint8(Uint8 v);            

        /// 8-bit Signed Integer Serializer.
        /// \wi{6368}
        /// U8ostream class shall be able to serialize a 8-bit signed integer value into the internal stream of data.
        /// \param[in] v 8-bit Signed Integer value to be serialized.
        void  put_int8( int8 v);            

        /// 16-bit Unsigned Integer Serializer in Little Endian Format.
        /// \wi{18073} 
        /// U8ostream class shall be able to serialize a 16-bit unsigned integer value into the 
        /// internal stream of data in Little Endian Format.
        /// \param[in] v 16-bit Unsigned Integer value to be serialized.
        void put_uint16_le(Uint16 v);       

        /// 16-bit Signed Integer Serializer in Little Endian Format.
        /// \wi{6371}
        /// U8ostream class shall be able to serialize a 16-bit signed integer value into the 
        /// internal stream of data in Little Endian Format.
        /// \param[in] v 16-bit Signed Integer value to be serialized.
        void  put_int16_le( int16 v);       

        /// 24-bit Unsigned Integer Serializer in Little Endian Format.
        /// \wi{6373} 
        /// U8ostream class shall be able to serialize a 24-bit unsigned integer value into the 
        /// internal stream of data in Little Endian Format.
        /// \param[in] v 24-bit Unsigned Integer value to be serialized.
        void put_uint24_le(Uint32 v);      

        /// 24-bit Signed Integer Serializer in Little Endian Format.
        /// \wi{6375}
        /// U8ostream class shall be able to serialize a 24-bit signed integer value into the 
        /// internal stream of data in Little Endian Format.
        /// \param[in] v 24-bit Signed Integer value to be serialized.
        void  put_int24_le( int32 v);       

        /// 32-bit Unsigned Integer Serializer in Little Endian Format.
        /// \wi{6377} 
        /// U8ostream class shall be able to serialize a 32-bit unsigned integer value into the 
        /// internal stream of data in Little Endian Format.
        /// \param[in] v 32-bit Unsigned Integer value to be serialized.
        void put_uint32_le(Uint32 v);       

        /// 32-bit Signed Integer Serializer in Little Endian Format.
        /// \wi{6379}
        /// U8ostream class shall be able to serialize a 32-bit signed integer value into the 
        /// internal stream of data in Little Endian Format.
        /// \param[in] v 32-bit Signed Integer value to be serialized.
        void  put_int32_le( int32 v);       

        /// 64-bit Unsigned Integer Serializer in Little Endian Format.
        /// \wi{6381}
        /// U8ostream class shall be able to serialize a 64-bit unsigned integer value into the 
        /// internal stream of data in Little Endian Format.
        /// \param[in] v 64-bit Unsigned Integer value to be serialized.
        void put_uint64_le(Uint64 v);       

        /// 16-bit Floating Point Serializer in Little Endian Format.
        /// \wi{6500}
        /// U8ostream class shall be able to serialize a 16-bit floating point value into the 
        /// internal stream of data in Little Endian Format.
        /// \param[in] v 16-bit float value to be serialized.
        void put_float16_le(Real v);        

        /// 32-bit Floating Point Serializer in Little Endian Format.
        /// \wi{6383}
        /// U8ostream class shall be able to serialize a 32-bit floating point value into the 
        /// internal stream of data in Little Endian Format.
        /// \param[in] v 32-bit float value to be serialized.
        void put_float32_le(Real v);        

        /// 16-bit Unsigned Integer Serializer in Big Endian Format.
        /// \wi{6370}
        /// U8ostream class shall be able to serialize a 16-bit unsigned integer value into the 
        /// internal stream of data in Big Endian Format.
        /// \param[in] v 16-bit Unsigned Integer value to be serialized.
        void put_uint16_be(Uint16 v);       

        /// 16-bit Signed Integer Serializer in Big Endian Format.
        /// \wi{18074}
        /// U8ostream class shall be able to serialize a 16-bit signed integer value into the 
        /// internal stream of data in Big Endian Format.
        /// \param[in] v 16-bit Signed Integer value to be serialized.
        void  put_int16_be( int16 v);       

        /// 24-bit Unsigned Integer Serializer in Big Endian Format.
        /// \wi{6374}
        /// U8ostream class shall be able to serialize a 24-bit unsigned integer value into the 
        /// internal stream of data in Big Endian Format.
        /// \param[in] v 24-bit Unsigned Integer value to be serialized.
        void put_uint24_be(Uint32 v);       

        /// 24-bit Signed Integer Serializer in Big Endian Format.
        /// \wi{6376}
        /// U8ostream class shall be able to serialize a 24-bit signed integer value into the 
        /// internal stream of data in Big Endian Format.
        /// \param[in] v 24-bit Signed Integer value to be serialized.
        void  put_int24_be( int32 v);       

        /// 32-bit Unsigned Integer Serializer in Big Endian Format.
        /// \wi{6378}
        /// U8ostream class shall be able to serialize a 32-bit unsigned integer value into the 
        /// internal stream of data in Big Endian Format.
        /// \param[in] v 32-bit Unsigned Integer value to be serialized.
        void put_uint32_be(Uint32 v);       

        /// 32-bit Signed Integer Serializer in Big Endian Format.
        /// \wi{6380}
        /// U8ostream class shall be able to serialize a 32-bit signed integer value into the 
        /// internal stream of data in Big Endian Format.
        /// \param[in] v 32-bit Signed Integer value to be serialized.
        void  put_int32_be( int32 v);       

        /// 64-bit Unsigned Integer Serializer in Big Endian Format.
        /// \wi{6382}
        /// U8ostream class shall be able to serialize a 64-bit unsigned integer value into the 
        /// internal stream of data in Big Endian Format.
        /// \param[in] v 64-bit Unsigned Integer value to be serialized.
        void put_uint64_be(Uint64 v);       

        /// 16-bit Floating Point Serializer in Big Endian Format.
        /// \wi{6499}
        /// U8ostream class shall be able to serialize a 16-bit floating point value into the 
        /// internal stream of data in Little Endian Format.
        /// \param[in] v Real value to be serialized.
        void put_float16_be(Real v);        

        /// 32-bit Floating Point Serializer in Big Endian Format.
        /// \wi{6384}
        /// U8ostream class shall be able to serialize a 32-bit floating point value into the 
        /// internal stream of data in Little Endian Format.
        /// \param[in] v Real value to be serialized.
        void put_float32_be(Real v);        

        /// Given Bytes of Unsigned Integer Serializer in Big Endian Format.
        /// \wi{18075}
        /// U8ostream class shall be able to serialize a given number of bytes of a 64-bit unsigned integer 
        /// value into the internal stream of data in Big Endian Format.
        /// \param[in] v 64-bit Unsigned Integer value to be serialized.
        /// \param[in] nbytes Number of bytes to be serialized.
        void put_uint64_be(Uint64 v, const Uint16 nbytes);
        
        /// Given bytes of Signed Integer Serializer in Big Endian Format.
        /// \wi{18076}
        /// U8ostream class shall be able to serialize a given number of bytes of a 64-bit signed integer 
        /// value into the internal stream of data in Big Endian Format.
        /// \param[in] v 64-bit signed Integer value to be serialized.
        /// \param[in] nbytes Number of bytes to be serialized.
        void  put_int64_be(int64 v, const Uint16 nbytes);
        
        /// Memory Block Serializer.
        /// \wi{18077}
        /// U8ostream class shall be able to serialize a memory block to its internal stream of data.
        /// \param[in] mbaux Memory Block to be serialized.
        void put_mblock(const U8pkmblock_k& mbaux);

        /// Memory Block Serializer.
        /// \wi{20203}
        /// U8ostream class shall be able to serialize a memory block to its internal 
        /// stream of data if the size of the type is 1 byte.
        /// \param[in] mb0 Memory Block to be serialized.
        template <typename T>
        void put_mblock(const Mblock<typename Enable_if<sizeof(T) == 1U, T>::type>& mb0);

    private:
        U8pkmblock mb;  ///< Working memory block
        Uint32 pos;     ///< Current read/write position

        U8ostream(); ///< = delete
    };

    inline U8ostream::U8ostream(const U8pkmblock& mb0) :
        mb(mb0),
        pos(0)
    {
    }

    inline U8ostream::U8ostream(const U8pkmblock& mb0, Uint32 offset) :
        mb(mb0),
        pos(offset)
    {
    }

    inline Uint32 U8ostream::get_pos() const
    {
        /// \alg
        /// - Return ::pos
        return pos;
    }

    inline Uint32 U8ostream::get_max_size() const
    {
        /// \alg
        /// - Return ::mb size
        return mb.size();
    }

    inline void U8ostream::reuse()
    {
        /// \alg
        /// - Set ::pos to 0.
        pos = 0;
    }

    inline U8pkmblock_k U8ostream::to_mblock8() const
    {
        /// \alg
        /// - Return U8pkmblock_k with internal ::mb and ::pos size.
        return U8pkmblock_k(mb, pos);
    }

    inline void U8ostream::put_uint8(Uint8 v)
    {
        /// \alg
        /// <ul>
        /// <li>  Check if the current position is within the bounds of the memory block.
        if(Assertions::runtime(pos<mb.size()))
        {
            /// <ul>
            /// <li>  Set the value at the current position in the memory block and increment the position.
            /// </ul>
            mb.set(pos++, v);
        }
        /// </ul>
    }

    inline void U8ostream::put_int8(int8 v)
    {
        /// \alg
        /// - Call U8ostream::put_uint8 for given casted to unsigned 8-bit value.
        put_uint8(static_cast<Uint8>(v));
    }

    // Little endian methods --------------------------------------------------

    inline void U8ostream::put_int16_le(int16 v)
    {
        /// \alg
        /// - Call U8ostream::put_uint16_le for given casted to Signed 16-bit value.
        put_uint16_le(static_cast<Uint16>(v));
    }

    inline void U8ostream::put_int24_le(int32 v)
    {
        /// \alg
        /// - Call U8ostream::put_uint24_le for given casted to Signed 32-bit value.
        put_uint24_le(static_cast<Uint32>(v));
    }

    inline void U8ostream::put_int32_le(int32 v)
    {
        /// \alg
        /// - Call U8ostream::put_uint32_le for given casted to Signed 32-bit value.
        put_uint32_le(static_cast<Uint32>(v));
    }

    inline void U8ostream::put_float32_le(Real v)
    {
        /// \alg
        /// - Call U8ostream::put_uint32_le for given casted to Real value.
        put_uint32_le(*reinterpret_cast<Uint32*>(&v));
    }

    // Big endian methods --------------------------------------------------
    inline void U8ostream::put_int16_be(int16 v)
    {
        /// \alg
        /// - Call U8ostream::put_uint16_be for given casted to Signed 16-bit value.
        put_uint16_be(*reinterpret_cast<Uint16*>(&v));
    }

    inline void U8ostream::put_int24_be(int32 v)
    {
        /// \alg
        /// - Call U8ostream::put_uint24_be for given casted to Signed 32-bit value.
        put_uint24_be(*reinterpret_cast<Uint32*>(&v));
    }

    inline void U8ostream::put_int32_be(int32 v)
    {
        /// \alg
        /// - Call U8ostream::put_uint32_be for given casted to Signed 32-bit value.
        put_uint32_be(*reinterpret_cast<Uint32*>(&v));
    }

    inline void U8ostream::put_float32_be(Real v)
    {
        /// \alg
        /// - Call U8ostream::put_uint32_be for given casted to Real value.
        put_uint32_be(*reinterpret_cast<Uint32*>(&v));
    }

    inline void U8ostream::put_float16_be(Real v)
    {
        /// \alg
        /// - Call U8ostream::put_uint16_be for given casted to Real-16 value using Real16::get_raw for received Real.
        put_uint16_be(Real16(v).get_raw());
    }

    inline void U8ostream::put_float16_le(Real v)
    {
        /// \alg
        /// - Call U8ostream::put_uint16_le for given casted to Real-16 value using Real16::get_raw for received Real.
        put_uint16_le(Real16(v).get_raw());
    }

    inline void U8ostream::put_int64_be(int64 v, const Uint16 nbytes)
    {
        /// \alg
        /// - Call U8ostream::put_uint64_be for given casted to Signed 64-bit byte value.
        put_uint64_be(*reinterpret_cast<Uint64*>(&v), nbytes);
    }

    template <typename T>
    void U8ostream::put_mblock(const Mblock<typename Enable_if<sizeof(T) == 1U, T>::type>& blk)
    {
        /// \alg
        /// <ul>
        /// <li> Check if the sum of position and size of the memory block does not 
        /// exceed the size of the internal size buffer.
        if(Assertions::runtime((pos + blk.size()) <= mb.size()))
        {
            /// <ul>
            /// <li> Iterate through each byte of the memory block.
            for(Uint16 i = 0; i < blk.size(); i++)
            {
                /// <ul>
                /// <li> Convert each byte to an 8-bit unsigned integer and serialize it 
                /// using put_uint8 incrementing the position each time.
                put_uint8(static_cast<Uint8>(blk[i]));
                /// </ul>
            }
            /// </ul>
        }
        /// </ul>
    }
}
#endif
