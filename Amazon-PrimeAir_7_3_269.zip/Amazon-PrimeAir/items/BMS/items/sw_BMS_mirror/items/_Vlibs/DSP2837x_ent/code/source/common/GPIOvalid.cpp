#include <GPIOvalid.h>
#include <GPIOid.h>

namespace Dsp28335_ent
{
    extern bool is_gpioid_valid(Uint16 id)
    {
        return id<gpio_all;
    }
}
