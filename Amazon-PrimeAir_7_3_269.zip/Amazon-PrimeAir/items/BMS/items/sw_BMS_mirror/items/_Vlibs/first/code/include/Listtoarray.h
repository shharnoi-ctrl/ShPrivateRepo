#ifndef LISTTOARRAY_H_
#define LISTTOARRAY_H_

#include <Tnarray.h>
#include <Warning.h>
#include <Ttraits.h>
#include <Ku16.h>

namespace Base
{
    /// List to array abstraction.
    /// Converts a set of elements to an array of pointers object.
    template<typename T, Uint16 size>
    class Listtoarray
    {
    public:
        typedef Base::Tnarray<T*, size> Tarr;   ///< Type for the array
        Tarr values; ///< Array of element pointers

        // These methods are inlined in the declaration because T is only defined inside the class and
        // will not work outside the class declaration
        /// Constructor with 1 element
        template <typename TT = T>
        explicit Listtoarray(typename Enable_if<size==1, TT>::type& v0)
        {
            values[Ku16::u0] = &v0;
        }
        /// Constructor with 2 elements
        template <typename TT = T>
        Listtoarray(typename Enable_if<size==Ku16::u2, TT>::type& v0, T& v1)
        {
            values[Ku16::u0] = &v0;
            values[Ku16::u1] = &v1;
        }
        /// Constructor with 3 elements
        template <typename TT = T>
        Listtoarray(typename Enable_if<size==Ku16::u3, TT>::type& v0, T& v1, T& v2)
        {
            values[Ku16::u0] = &v0;
            values[Ku16::u1] = &v1;
            values[Ku16::u2] = &v2;
        }
        /// Constructor with 4 elements
        template <typename TT = T>
        Listtoarray(typename Enable_if<size==Ku16::u4, TT>::type& v0, T& v1, T& v2, T& v3)
        {
            values[Ku16::u0] = &v0;
            values[Ku16::u1] = &v1;
            values[Ku16::u2] = &v2;
            values[Ku16::u3] = &v3;
        }
        /// Constructor with 5 elements
        template <typename TT = T>
        Listtoarray(typename Enable_if<size==Ku16::u5, TT>::type& v0, T& v1, T& v2, T& v3, T& v4)
        {
            values[Ku16::u0] = &v0;
            values[Ku16::u1] = &v1;
            values[Ku16::u2] = &v2;
            values[Ku16::u3] = &v3;
            values[Ku16::u4] = &v4;
        }
        /// Constructor with 6 elements
        template <typename TT = T>
        Listtoarray(typename Enable_if<size==Ku16::u6, TT>::type& v0, T& v1, T& v2, T& v3, T& v4, T& v5)
        {
            values[Ku16::u0] = &v0;
            values[Ku16::u1] = &v1;
            values[Ku16::u2] = &v2;
            values[Ku16::u3] = &v3;
            values[Ku16::u4] = &v4;
            values[Ku16::u5] = &v5;
        }
        /// Constructor with 7 elements
        template <typename TT = T>
        Listtoarray(typename Enable_if<size==Ku16::u7, TT>::type& v0, T& v1, T& v2, T& v3, T& v4, T& v5, T& v6)
        {
            values[Ku16::u0] = &v0;
            values[Ku16::u1] = &v1;
            values[Ku16::u2] = &v2;
            values[Ku16::u3] = &v3;
            values[Ku16::u4] = &v4;
            values[Ku16::u5] = &v5;
            values[Ku16::u6] = &v6;
        }
        
        /// Constructor with 8 elements
        template <typename TT = T>
        Listtoarray(typename Enable_if<size==Ku16::u8, TT>::type& v0, T& v1, T& v2, T& v3, T& v4, T& v5, T& v6, T& v7)
        {
            values[Ku16::u0] = &v0;
            values[Ku16::u1] = &v1;
            values[Ku16::u2] = &v2;
            values[Ku16::u3] = &v3;
            values[Ku16::u4] = &v4;
            values[Ku16::u5] = &v5;
            values[Ku16::u6] = &v6;
            values[Ku16::u7] = &v7;
        }

        /// Constructor with 9 elements
        template <typename TT = T>
        Listtoarray(typename Enable_if<size==Ku16::u9, TT>::type& v0, T& v1, T& v2, T& v3, T& v4, T& v5, T& v6, T& v7,
                    T& v8)
        {
            values[Ku16::u0] = &v0;
            values[Ku16::u1] = &v1;
            values[Ku16::u2] = &v2;
            values[Ku16::u3] = &v3;
            values[Ku16::u4] = &v4;
            values[Ku16::u5] = &v5;
            values[Ku16::u6] = &v6;
            values[Ku16::u7] = &v7;
            values[Ku16::u8] = &v8;
        }

        /// Constructor with 10 elements
        template <typename TT = T>
        Listtoarray(typename Enable_if<size==Ku16::u10, TT>::type& v0, T& v1, T& v2, T& v3, T& v4, T& v5, T& v6, T& v7,
                    T& v8, T& v9)
        {
            values[Ku16::u0] = &v0;
            values[Ku16::u1] = &v1;
            values[Ku16::u2] = &v2;
            values[Ku16::u3] = &v3;
            values[Ku16::u4] = &v4;
            values[Ku16::u5] = &v5;
            values[Ku16::u6] = &v6;
            values[Ku16::u7] = &v7;
            values[Ku16::u8] = &v8;
            values[Ku16::u9] = &v9;
        }
    private:
        Listtoarray(const Listtoarray&); ///< = delete
        Listtoarray& operator=(const Listtoarray&); ///< = delete
    };
}
#endif
