#ifndef DEVCFG_REGS_H_
#define DEVCFG_REGS_H_

#include <Entypes.h>
#include <Tnarray.h>

namespace Dsp28335_ent
{
    //PRQA S 2176 ++
    //#Unions used in HW register mapping in Texas Instruments' libraries.
    //PRQA S 2301 ++
    //#Bit-fields are needed.
    //PRQA S 5050 ++
    //#Identifiers will be kept by default
    //PRQA S 5051 ++
    //#Identifiers will be kept by default

    //---------------------------------------------------------------------------
    // SYSCTRL Individual Register Bit Definitions:

    struct DEVCFGLOCK1_BITS {               // bits description
        Uint16 CPUSEL0:1;                   // 0 Lock bit for CPUSEL0 register
        Uint16 CPUSEL1:1;                   // 1 Lock bit for CPUSEL1 register
        Uint16 CPUSEL2:1;                   // 2 Lock bit for CPUSEL2 register
        Uint16 CPUSEL3:1;                   // 3 Lock bit for CPUSEL3 register
        Uint16 CPUSEL4:1;                   // 4 Lock bit for CPUSEL4 register
        Uint16 CPUSEL5:1;                   // 5 Lock bit for CPUSEL5 register
        Uint16 CPUSEL6:1;                   // 6 Lock bit for CPUSEL6 register
        Uint16 CPUSEL7:1;                   // 7 Lock bit for CPUSEL7 register
        Uint16 CPUSEL8:1;                   // 8 Lock bit for CPUSEL8 register
        Uint16 CPUSEL9:1;                   // 9 Lock bit for CPUSEL9 register
        Uint16 CPUSEL10:1;                  // 10 Lock bit for CPUSEL10 register
        Uint16 CPUSEL11:1;                  // 11 Lock bit for CPUSEL11 register
        Uint16 CPUSEL12:1;                  // 12 Lock bit for CPUSEL12 register
        Uint16 CPUSEL13:1;                  // 13 Lock bit for CPUSEL13 register
        Uint16 CPUSEL14:1;                  // 14 Lock bit for CPUSEL14 register
        Uint16 rsvd1:1;                     // 15 Reserved
        Uint16 rsvd2:16;                    // 31:16 Reserved
    };

    union DEVCFGLOCK1_REG {
        Uint32  all;
        struct  DEVCFGLOCK1_BITS  bit;
    };

    struct PARTIDL_BITS {                   // bits description
        Uint16 rsvd1:3;                     // 2:0 Reserved
        Uint16 rsvd2:2;                     // 4:3 Reserved
        Uint16 rsvd3:1;                     // 5 Reserved
        Uint16 QUAL:2;                      // 7:6 Qualification Status
        Uint16 PIN_COUNT:3;                 // 10:8 Device Pin Count
        Uint16 rsvd4:1;                     // 11 Reserved
        Uint16 rsvd5:1;                     // 12 Reserved
        Uint16 INSTASPIN:2;                 // 14:13 Motorware feature set
        Uint16 rsvd6:1;                     // 15 Reserved
        Uint16 FLASH_SIZE:8;                // 23:16 Flash size in KB
        Uint16 rsvd7:4;                     // 27:24 Reserved
        Uint16 PARTID_FORMAT_REVISION:4;    // 31:28 Revision of the PARTID format
    };

    union PARTIDL_REG {
        Uint32  all;
        struct  PARTIDL_BITS  bit;
    };

    struct PARTIDH_BITS {                   // bits description
        Uint16 rsvd1:8;                     // 7:0 Reserved
        Uint16 FAMILY:8;                    // 15:8 Device family
        Uint16 PARTNO:8;                    // 23:16 Device part number
        Uint16 DEVICE_CLASS_ID:8;           // 31:24 Device class ID
    };

    union PARTIDH_REG {
        Uint32  all;
        struct  PARTIDH_BITS  bit;
    };

    struct DC0_BITS {                       // bits description
        Uint16 SINGLE_CORE:1;               // 0 Single Core vs Dual Core
        Uint16 rsvd1:15;                    // 15:1 Reserved
        Uint16 rsvd2:16;                    // 31:16 Reserved
    };

    union DC0_REG {
        Uint32  all;
        struct  DC0_BITS  bit;
    };

    struct DC1_BITS {                       // bits description
        Uint16 CPU1_FPU_TMU:1;              // 0 CPU1's FPU1+TMU1
        Uint16 CPU2_FPU_TMU:1;              // 1 CPU2's FPU2+TMU2
        Uint16 CPU1_VCU:1;                  // 2 CPU1's VCU
        Uint16 CPU2_VCU:1;                  // 3 CPU2's VCU
        Uint16 rsvd1:2;                     // 5:4 Reserved
        Uint16 CPU1_CLA1:1;                 // 6 CPU1.CLA1
        Uint16 rsvd2:1;                     // 7 Reserved
        Uint16 CPU2_CLA1:1;                 // 8 CPU2.CLA1
        Uint16 rsvd3:1;                     // 9 Reserved
        Uint16 rsvd4:6;                     // 15:10 Reserved
        Uint16 rsvd5:16;                    // 31:16 Reserved
    };

    union DC1_REG {
        Uint32  all;
        struct  DC1_BITS  bit;
    };

    struct DC2_BITS {                       // bits description
        Uint16 EMIF1:1;                     // 0 EMIF1
        Uint16 EMIF2:1;                     // 1 EMIF2
        Uint16 rsvd1:14;                    // 15:2 Reserved
        Uint16 rsvd2:16;                    // 31:16 Reserved
    };

    union DC2_REG {
        Uint32  all;
        struct  DC2_BITS  bit;
    };

    struct DC3_BITS {                       // bits description
        Uint16 EPWM1:1;                     // 0 EPWM1
        Uint16 EPWM2:1;                     // 1 EPWM2
        Uint16 EPWM3:1;                     // 2 EPWM3
        Uint16 EPWM4:1;                     // 3 EPWM4
        Uint16 EPWM5:1;                     // 4 EPWM5
        Uint16 EPWM6:1;                     // 5 EPWM6
        Uint16 EPWM7:1;                     // 6 EPWM7
        Uint16 EPWM8:1;                     // 7 EPWM8
        Uint16 EPWM9:1;                     // 8 EPWM9
        Uint16 EPWM10:1;                    // 9 EPWM10
        Uint16 EPWM11:1;                    // 10 EPWM11
        Uint16 EPWM12:1;                    // 11 EPWM12
        Uint16 rsvd1:1;                     // 12 Reserved
        Uint16 rsvd2:1;                     // 13 Reserved
        Uint16 rsvd3:1;                     // 14 Reserved
        Uint16 rsvd4:1;                     // 15 Reserved
        Uint16 rsvd5:16;                    // 31:16 Reserved
    };

    union DC3_REG {
        Uint32  all;
        struct  DC3_BITS  bit;
    };

    struct DC4_BITS {                       // bits description
        Uint16 ECAP1:1;                     // 0 ECAP1
        Uint16 ECAP2:1;                     // 1 ECAP2
        Uint16 ECAP3:1;                     // 2 ECAP3
        Uint16 ECAP4:1;                     // 3 ECAP4
        Uint16 ECAP5:1;                     // 4 ECAP5
        Uint16 ECAP6:1;                     // 5 ECAP6
        Uint16 rsvd1:1;                     // 6 Reserved
        Uint16 rsvd2:1;                     // 7 Reserved
        Uint16 rsvd3:8;                     // 15:8 Reserved
        Uint16 rsvd4:16;                    // 31:16 Reserved
    };

    union DC4_REG {
        Uint32  all;
        struct  DC4_BITS  bit;
    };

    struct DC5_BITS {                       // bits description
        Uint16 EQEP1:1;                     // 0 EQEP1
        Uint16 EQEP2:1;                     // 1 EQEP2
        Uint16 EQEP3:1;                     // 2 EQEP3
        Uint16 rsvd1:1;                     // 3 Reserved
        Uint16 rsvd2:12;                    // 15:4 Reserved
        Uint16 rsvd3:16;                    // 31:16 Reserved
    };

    union DC5_REG {
        Uint32  all;
        struct  DC5_BITS  bit;
    };

    struct DC7_BITS {                       // bits description
        Uint16 SD1:1;                       // 0 SD1
        Uint16 SD2:1;                       // 1 SD2
        Uint16 rsvd1:1;                     // 2 Reserved
        Uint16 rsvd2:1;                     // 3 Reserved
        Uint16 rsvd3:1;                     // 4 Reserved
        Uint16 rsvd4:1;                     // 5 Reserved
        Uint16 rsvd5:1;                     // 6 Reserved
        Uint16 rsvd6:1;                     // 7 Reserved
        Uint16 rsvd7:8;                     // 15:8 Reserved
        Uint16 rsvd8:16;                    // 31:16 Reserved
    };

    union DC7_REG {
        Uint32  all;
        struct  DC7_BITS  bit;
    };

    struct DC8_BITS {                       // bits description
        Uint16 SCI_A:1;                     // 0 SCI_A
        Uint16 SCI_B:1;                     // 1 SCI_B
        Uint16 SCI_C:1;                     // 2 SCI_C
        Uint16 SCI_D:1;                     // 3 SCI_D
        Uint16 rsvd1:12;                    // 15:4 Reserved
        Uint16 rsvd2:16;                    // 31:16 Reserved
    };

    union DC8_REG {
        Uint32  all;
        struct  DC8_BITS  bit;
    };

    struct DC9_BITS {                       // bits description
        Uint16 SPI_A:1;                     // 0 SPI_A
        Uint16 SPI_B:1;                     // 1 SPI_B
        Uint16 SPI_C:1;                     // 2 SPI_C
        Uint16 rsvd1:1;                     // 3 Reserved
        Uint16 rsvd2:12;                    // 15:4 Reserved
        Uint16 rsvd3:1;                     // 16 Reserved
        Uint16 rsvd4:1;                     // 17 Reserved
        Uint16 rsvd5:14;                    // 31:18 Reserved
    };

    union DC9_REG {
        Uint32  all;
        struct  DC9_BITS  bit;
    };

    struct DC10_BITS {                      // bits description
        Uint16 I2C_A:1;                     // 0 I2C_A
        Uint16 I2C_B:1;                     // 1 I2C_B
        Uint16 rsvd1:14;                    // 15:2 Reserved
        Uint16 rsvd2:1;                     // 16 Reserved
        Uint16 rsvd3:1;                     // 17 Reserved
        Uint16 rsvd4:14;                    // 31:18 Reserved
    };

    union DC10_REG {
        Uint32  all;
        struct  DC10_BITS  bit;
    };

    struct DC11_BITS {                      // bits description
        Uint16 CAN_A:1;                     // 0 CAN_A
        Uint16 CAN_B:1;                     // 1 CAN_B
        Uint16 rsvd1:1;                     // 2 Reserved
        Uint16 rsvd2:1;                     // 3 Reserved
        Uint16 rsvd3:12;                    // 15:4 Reserved
        Uint16 rsvd4:16;                    // 31:16 Reserved
    };

    union DC11_REG {
        Uint32  all;
        struct  DC11_BITS  bit;
    };

    struct DC12_BITS {                      // bits description
        Uint16 McBSP_A:1;                   // 0 McBSP_A
        Uint16 McBSP_B:1;                   // 1 McBSP_B
        Uint16 rsvd1:14;                    // 15:2 Reserved
        Uint16 USB_A:2;                     // 17:16 Decides the capability of the USB_A Module
        Uint16 rsvd2:2;                     // 19:18 Reserved
        Uint16 rsvd3:12;                    // 31:20 Reserved
    };

    union DC12_REG {
        Uint32  all;
        struct  DC12_BITS  bit;
    };

    struct DC13_BITS {                      // bits description
        Uint16 uPP_A:1;                     // 0 uPP_A
        Uint16 rsvd1:1;                     // 1 Reserved
        Uint16 rsvd2:14;                    // 15:2 Reserved
        Uint16 rsvd3:16;                    // 31:16 Reserved
    };

    union DC13_REG {
        Uint32  all;
        struct  DC13_BITS  bit;
    };

    struct DC14_BITS {                      // bits description
        Uint16 ADC_A:1;                     // 0 ADC_A
        Uint16 ADC_B:1;                     // 1 ADC_B
        Uint16 ADC_C:1;                     // 2 ADC_C
        Uint16 ADC_D:1;                     // 3 ADC_D
        Uint16 rsvd1:12;                    // 15:4 Reserved
        Uint16 rsvd2:16;                    // 31:16 Reserved
    };

    union DC14_REG {
        Uint32  all;
        struct  DC14_BITS  bit;
    };

    struct DC15_BITS {                      // bits description
        Uint16 CMPSS1:1;                    // 0 CMPSS1
        Uint16 CMPSS2:1;                    // 1 CMPSS2
        Uint16 CMPSS3:1;                    // 2 CMPSS3
        Uint16 CMPSS4:1;                    // 3 CMPSS4
        Uint16 CMPSS5:1;                    // 4 CMPSS5
        Uint16 CMPSS6:1;                    // 5 CMPSS6
        Uint16 CMPSS7:1;                    // 6 CMPSS7
        Uint16 CMPSS8:1;                    // 7 CMPSS8
        Uint16 rsvd1:8;                     // 15:8 Reserved
        Uint16 rsvd2:16;                    // 31:16 Reserved
    };

    union DC15_REG {
        Uint32  all;
        struct  DC15_BITS  bit;
    };

    struct DC17_BITS {                      // bits description
        Uint16 rsvd1:1;                     // 0 Reserved
        Uint16 rsvd2:1;                     // 1 Reserved
        Uint16 rsvd3:1;                     // 2 Reserved
        Uint16 rsvd4:1;                     // 3 Reserved
        Uint16 rsvd5:12;                    // 15:4 Reserved
        Uint16 DAC_A:1;                     // 16 Buffered-DAC_A
        Uint16 DAC_B:1;                     // 17 Buffered-DAC_B
        Uint16 DAC_C:1;                     // 18 Buffered-DAC_C
        Uint16 rsvd6:1;                     // 19 Reserved
        Uint16 rsvd7:12;                    // 31:20 Reserved
    };

    union DC17_REG {
        Uint32  all;
        struct  DC17_BITS  bit;
    };

    struct DC18_BITS {                      // bits description
        Uint16 LS0_1:1;                     // 0 LS0_1
        Uint16 LS1_1:1;                     // 1 LS1_1
        Uint16 LS2_1:1;                     // 2 LS2_1
        Uint16 LS3_1:1;                     // 3 LS3_1
        Uint16 LS4_1:1;                     // 4 LS4_1
        Uint16 LS5_1:1;                     // 5 LS5_1
        Uint16 rsvd1:10;                    // 15:6 Reserved
        Uint16 rsvd2:16;                    // 31:16 Reserved
    };

    union DC18_REG {
        Uint32  all;
        struct  DC18_BITS  bit;
    };

    struct DC19_BITS {                      // bits description
        Uint16 LS0_2:1;                     // 0 LS0_2
        Uint16 LS1_2:1;                     // 1 LS1_2
        Uint16 LS2_2:1;                     // 2 LS2_2
        Uint16 LS3_2:1;                     // 3 LS3_2
        Uint16 LS4_2:1;                     // 4 LS4_2
        Uint16 LS5_2:1;                     // 5 LS5_2
        Uint16 rsvd1:10;                    // 15:6 Reserved
        Uint16 rsvd2:16;                    // 31:16 Reserved
    };

    union DC19_REG {
        Uint32  all;
        struct  DC19_BITS  bit;
    };

    struct DC20_BITS {                      // bits description
        Uint16 GS0:1;                       // 0 GS0
        Uint16 GS1:1;                       // 1 GS1
        Uint16 GS2:1;                       // 2 GS2
        Uint16 GS3:1;                       // 3 GS3
        Uint16 GS4:1;                       // 4 GS4
        Uint16 GS5:1;                       // 5 GS5
        Uint16 GS6:1;                       // 6 GS6
        Uint16 GS7:1;                       // 7 GS7
        Uint16 GS8:1;                       // 8 GS8
        Uint16 GS9:1;                       // 9 GS9
        Uint16 GS10:1;                      // 10 GS10
        Uint16 GS11:1;                      // 11 GS11
        Uint16 GS12:1;                      // 12 GS12
        Uint16 GS13:1;                      // 13 GS13
        Uint16 GS14:1;                      // 14 GS14
        Uint16 GS15:1;                      // 15 GS15
        Uint16 rsvd1:16;                    // 31:16 Reserved
    };

    union DC20_REG {
        Uint32  all;
        struct  DC20_BITS  bit;
    };

    struct PERCNF1_BITS {                   // bits description
        Uint16 ADC_A_MODE:1;                // 0 ADC_A mode setting bit
        Uint16 ADC_B_MODE:1;                // 1 ADC_B mode setting bit
        Uint16 ADC_C_MODE:1;                // 2 ADC_C mode setting bit
        Uint16 ADC_D_MODE:1;                // 3 ADC_D mode setting bit
        Uint16 rsvd1:12;                    // 15:4 Reserved
        Uint16 USB_A_PHY:1;                 // 16 USB_A_PHY
        Uint16 rsvd2:1;                     // 17 Reserved
        Uint16 rsvd3:14;                    // 31:18 Reserved
    };

    union PERCNF1_REG {
        Uint32  all;
        struct  PERCNF1_BITS  bit;
    };

    struct FUSEERR_BITS {                   // bits description
        Uint16 ALERR:5;                     // 4:0 Efuse Autoload Error Status
        Uint16 ERR:1;                       // 5 Efuse Self Test Error Status
        Uint16 rsvd1:10;                    // 15:6 Reserved
        Uint16 rsvd2:16;                    // 31:16 Reserved
    };

    union FUSEERR_REG {
        Uint32  all;
        struct  FUSEERR_BITS  bit;
    };

    struct CPU2RESCTL_BITS {                // bits description
        Uint16 RESET:1;                     // 0 CPU2 Reset Control bit
        Uint16 rsvd1:15;                    // 15:1 Reserved
        Uint16 KEY:16;                      // 31:16 Key Qualifier for writes to this register
    };

    union CPU2RESCTL_REG {
        Uint32  all;
        struct  CPU2RESCTL_BITS  bit;
    };

    struct RSTSTAT_BITS {                   // bits description
        Uint16 CPU2RES:1;                   // 0 CPU2 Reset Status bit
        Uint16 CPU2NMIWDRST:1;              // 1 Indicates whether a CPU2.NMIWD reset was issued to CPU2
        Uint16 CPU2HWBISTRST0:1;            // 2 Indicates whether a HWBIST reset was issued to CPU2
        Uint16 CPU2HWBISTRST1:1;            // 3 Indicates whether a HWBIST reset was issued to CPU2
        Uint16 rsvd1:12;                    // 15:4 Reserved
    };

    union RSTSTAT_REG {
        Uint16  all;
        struct  RSTSTAT_BITS  bit;
    };

    struct LPMSTAT_BITS {                   // bits description
        Uint16 CPU2LPMSTAT:2;               // 1:0 CPU2 LPM Status
        Uint16 rsvd1:14;                    // 15:2 Reserved
    };

    union LPMSTAT_REG {
        Uint16  all;
        struct  LPMSTAT_BITS  bit;
    };

    struct SYSDBGCTL_BITS {                 // bits description
        Uint16 BIT_0:1;                     // 0 Used in PLL startup. Only reset by POR.
        Uint16 rsvd1:15;                    // 15:1 Reserved
        Uint16 rsvd2:16;                    // 31:16 Reserved
    };

    union SYSDBGCTL_REG {
        Uint32  all;
        struct  SYSDBGCTL_BITS  bit;
    };

    static const Uint16 softpres_sz = 34;
    typedef Base::Tnarray<Uint16, softpres_sz> Softpres_regs;

    static const Uint16 cpusel_sz = 30;
    typedef Base::Tnarray<Uint32, cpusel_sz> Cpusel_regs;

    struct Devcfg::Registers {
        union   DEVCFGLOCK1_REG                  DEVCFGLOCK1;      // Lock bit for CPUSELx registers
        Uint16                                   rsvd1[6];         // Reserved
        union   PARTIDL_REG                      PARTIDL;          // Lower 32-bit of Device PART Identification Number
        union   PARTIDH_REG                      PARTIDH;          // Upper 32-bit of Device PART Identification Number
        Uint32                                   REVID;            // Device Revision Number
        Uint16                                   rsvd2[2];         // Reserved
        union   DC0_REG                          DC0;              // Device Capability: Device Information
        union   DC1_REG                          DC1;              // Device Capability: Processing Block Customization
        union   DC2_REG                          DC2;              // Device Capability: EMIF Customization
        union   DC3_REG                          DC3;              // Device Capability: Peripheral Customization
        union   DC4_REG                          DC4;              // Device Capability: Peripheral Customization
        union   DC5_REG                          DC5;              // Device Capability: Peripheral Customization
        Uint16                                   rsvd3[2];         // Reserved
        union   DC7_REG                          DC7;              // Device Capability: Peripheral Customization
        union   DC8_REG                          DC8;              // Device Capability: Peripheral Customization
        union   DC9_REG                          DC9;              // Device Capability: Peripheral Customization
        union   DC10_REG                         DC10;             // Device Capability: Peripheral Customization
        union   DC11_REG                         DC11;             // Device Capability: Peripheral Customization
        union   DC12_REG                         DC12;             // Device Capability: Peripheral Customization
        union   DC13_REG                         DC13;             // Device Capability: Peripheral Customization
        union   DC14_REG                         DC14;             // Device Capability: Analog Modules Customization
        union   DC15_REG                         DC15;             // Device Capability: Analog Modules Customization
        Uint16                                   rsvd4[2];         // Reserved
        union   DC17_REG                         DC17;             // Device Capability: Analog Modules Customization
        union   DC18_REG                         DC18;             // Device Capability: CPU1 Lx SRAM Customization
        union   DC19_REG                         DC19;             // Device Capability: CPU2 Lx SRAM Customization
        union   DC20_REG                         DC20;             // Device Capability: GSx SRAM Customization
        Uint16                                   rsvd5[38];        // Reserved
        union   PERCNF1_REG                      PERCNF1;          // Peripheral Configuration register
        Uint16                                   rsvd6[18];        // Reserved
        union   FUSEERR_REG                      FUSEERR;          // e-Fuse error Status register
        Uint16                                   rsvd7[12];        // Reserved
        Softpres_regs                            softpres;         // Peripheral Software Reset registers
        Uint16                                   rsvd12[50];       // Reserved
        Cpusel_regs                              cpusel;           // CPU Select register for common peripherals
        Uint16                                   rsvd16[46];       // Reserved
        union   CPU2RESCTL_REG                   CPU2RESCTL;       // CPU2 Reset Control Register
        union   RSTSTAT_REG                      RSTSTAT;          // Reset Status register for secondary C28x CPUs
        union   LPMSTAT_REG                      LPMSTAT;          // LPM Status Register for secondary C28x CPUs
        Uint16                                   rsvd17[6];        // Reserved
        union   SYSDBGCTL_REG                    SYSDBGCTL;        // System Debug Control register
    };

    //PRQA S 2176 --
    //#Unions used in HW register mapping in Texas Instruments' libraries.
    //PRQA S 2301 --
    //#Bit-fields are needed.
    //PRQA S 5050 --
    //#Identifiers will be kept by default
    //PRQA S 5051 --
    //#Identifiers will be kept by default
}
#endif
