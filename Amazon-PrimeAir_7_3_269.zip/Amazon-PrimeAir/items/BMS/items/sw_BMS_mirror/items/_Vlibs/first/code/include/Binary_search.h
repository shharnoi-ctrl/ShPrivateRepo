#ifndef BINARY_SEARCH_H_
#define BINARY_SEARCH_H_

#include <Mblock.h>

namespace Base
{

    namespace Binary_search_def
    {
        /// Binary search default less than comparator.
        /// \wi{17570}
        /// The default_less_than function shall return -1 if "a < b" , 0 if they are equal and 1 if "a > b" and false
        /// otherwise.
        /// \param[in] a First element to compare.
        /// \param[in] b Second element to compare.
        /// \return -1 if a<b,  1 if b<a, 0 in other case
        template <typename T, typename V>
        inline int32 default_compare(typename Base::JSF116_param<T>::type a,
                                     typename Base::JSF116_param<V>::type b)
        {
            return static_cast<int32>(a > b) - static_cast<int32>(a < b);
        }
    }

    /// This is a helper class to search in an already sorted.
    /// array of contiguous elements.
    template <typename T,
              typename V = T>
    struct Binary_search
    {
        /// Type for the comparation function used by ::search method.
        typedef int32 (*Cmp_func)(typename Base::JSF116_param<T>::type a, typename Base::JSF116_param<V>::type b);

        /// Binary search for an element.
        /// \wi{17679}
        /// The ::search method shall return the index of the element "val" in the sorted array of elements if it is
        /// found, or the size of the array of elements if it is not found.
        /// \pre This method assumes that all the elements in "sorted_data" are already sorted according to the
        /// cpmf template function.
        /// \param[in] sorted_data Sorted array of elements according to "cmpf" function.
        /// \param[in] val         Element to search.
        /// \return index of value if it is found or ::sorted_data.size() if not found.
        template<Cmp_func cmpf = &Binary_search_def::default_compare<T,V> >
        static Uint32 search(Base::Mblock<const T> sorted_data,
                             typename Base::JSF116_param<V>::type val);

    private:
        Binary_search();                                      ///< = delete
        Binary_search(const Binary_search& src);              ///< = delete
        Binary_search& operator=(const Binary_search& src);   ///< = delete
    };

    template <typename T, typename V>
    template<typename Binary_search<T,V>::Cmp_func cmp_f>
    Uint32 Binary_search<T,V>::search(Base::Mblock<const T> sorted_data,
                                      typename Base::JSF116_param<V>::type val)
    {
        Uint32 jmax = sorted_data.size();
        Uint32 jmin = 0;
        Uint32 res = jmax;
        while(jmin < jmax)
        {
            const Uint32 j = (jmax + jmin) >> 1U;
            const int32 cmp = cmp_f(val, sorted_data[j]);
            switch(cmp)
            {
                case -1:
                {
                    jmax = j;
                    break;
                }
                case 0:
                {
                    jmin = jmax; // force end
                    res = j;
                    break;
                }
                case 1:
                {
                    jmin = j + 1;
                    break;
                }
            }
        }
        return res;
    }
}
#endif
