///    \file Suiteref.h
///
///    \date 12 jun. 2017
///
///    \author  FJBurgos, jbm (at) embention.com
///    Company:  Embention
///
///    Suiteref class declaration.
///

#ifndef SUITEREF_H_
#define SUITEREF_H_

#include <Memmgr.h>
#include <Assertions.h>
#include <Ku16.h>
#include <Tnarray.h>

namespace Base
{

    template <typename T, Uint16 n>
    class Suiteref
    {
    public:
        class Iterator
        {
        public:
            explicit Iterator(Suiteref<T,n>& s);
            T* next();

        private:
            T** v_key;                      ///< Current key element
            const T* const* const vend;     ///< Last element

            Iterator(); ///< = delete
            Iterator(const Iterator& orig); ///< = delete
            Iterator& operator=(const Iterator& orig); ///< = delete
        };


        explicit Suiteref(T& elem0);
        Suiteref(T& elem0,T& elem1);
        Suiteref(T& elem0,
                 T& elem1,
                 T& elem2);
        Suiteref(T& elem0,
                 T& elem1,
                 T& elem2,
                 T& elem3);
        Suiteref(T& elem0,
                 T& elem1,
                 T& elem2,
                 T& elem3,
                 T& elem4);
        Suiteref(T& elem0,
                 T& elem1,
                 T& elem2,
                 T& elem3,
                 T& elem4,
                 T& elem5);
        Suiteref(T& elem0,
                 T& elem1,
                 T& elem2,
                 T& elem3,
                 T& elem4,
                 T& elem5,
                 T& elem6);
        Suiteref(T& elem0,
                 T& elem1,
                 T& elem2,
                 T& elem3,
                 T& elem4,
                 T& elem5,
                 T& elem6,
                 T& elem7);
        Suiteref(T& elem0,
                 T& elem1,
                 T& elem2,
                 T& elem3,
                 T& elem4,
                 T& elem5,
                 T& elem6,
                 T& elem7,
                 T& elem8);
        Suiteref(T& elem0,
                 T& elem1,
                 T& elem2,
                 T& elem3,
                 T& elem4,
                 T& elem5,
                 T& elem6,
                 T& elem7,
                 T& elem8,
                 T& elem9);
        Suiteref(T& elem0,
                 T& elem1,
                 T& elem2,
                 T& elem3,
                 T& elem4,
                 T& elem5,
                 T& elem6,
                 T& elem7,
                 T& elem8,
                 T& elem9,
                 T& elem10,
                 T& elem11);
        Suiteref(T& elem0,
                 T& elem1,
                 T& elem2,
                 T& elem3,
                 T& elem4,
                 T& elem5,
                 T& elem6,
                 T& elem7,
                 T& elem8,
                 T& elem9,
                 T& elem10,
                 T& elem11,
                 T& elem12);
        Suiteref(T& elem0,
                 T& elem1,
                 T& elem2,
                 T& elem3,
                 T& elem4,
                 T& elem5,
                 T& elem6,
                 T& elem7,
                 T& elem8,
                 T& elem9,
                 T& elem10,
                 T& elem11,
                 T& elem12,
                 T& elem13,
                 T& elem14,
                 T& elem15,
                 T& elem16,
                 T& elem17,
                 T& elem18);
        Suiteref(T& elem0,
                 T& elem1,
                 T& elem2,
                 T& elem3,
                 T& elem4,
                 T& elem5,
                 T& elem6,
                 T& elem7,
                 T& elem8,
                 T& elem9,
                 T& elem10,
                 T& elem11,
                 T& elem12,
                 T& elem13,
                 T& elem14,
                 T& elem15,
                 T& elem16,
                 T& elem17,
                 T& elem18,
                 T& elem19,
                 T& elem20,
                 T& elem21,
                 T& elem22,
                 T& elem23,
                 T& elem24);
        Suiteref(T& elem0,
                 T& elem1,
                 T& elem2,
                 T& elem3,
                 T& elem4,
                 T& elem5,
                 T& elem6,
                 T& elem7,
                 T& elem8,
                 T& elem9,
                 T& elem10,
                 T& elem11,
                 T& elem12,
                 T& elem13,
                 T& elem14,
                 T& elem15,
                 T& elem16,
                 T& elem17,
                 T& elem18,
                 T& elem19,
                 T& elem20,
                 T& elem21,
                 T& elem22,
                 T& elem23,
                 T& elem24,
                 T& elem25);
        ~Suiteref();

        T& get(Uint32 i);
        const T& get(Uint32 i)const;
        static Uint32 size();
        bool has_idx(Uint16 idx);
        Mblock<T*> to_mblock();

    private:
        Base::Tnarray<T*,n> v;

        Suiteref(); ///< = delete
        Suiteref(const Suiteref& orig); ///< = delete
        Suiteref& operator=(const Suiteref& orig); ///< = delete
    };

    template <typename T, Uint16 n>
    inline Suiteref<T,n>::Iterator::Iterator(Suiteref<T,n>& s) :
        v_key(s.v),
        vend(&s.v[n-1])
    {
    }

    template <typename T, Uint16 n>
    inline T* Suiteref<T,n>::Iterator::next()
    {
        return (v_key<=vend) ? *(v_key++) : static_cast<T*>(0);
    }

    template <typename T, Uint16 n>
    Suiteref<T,n>::Suiteref(T& elem0)
    {
        Assertions::Compile_time<n==1>();
        v[0]=&elem0;
    }

    template <typename T, Uint16 n>
    Suiteref<T,n>::Suiteref(T& elem0,T& elem1)
    {
        Assertions::Compile_time<n==Ku16::u2>();
        v[Ku16::u0]=&elem0;
        v[Ku16::u1]=&elem1;
    }

    template <typename T, Uint16 n>
    Suiteref<T,n>::Suiteref(T& elem0,
                            T& elem1,
                            T& elem2)
    {
        Assertions::Compile_time<n==Ku16::u3>();
        v[Ku16::u0]=&elem0;
        v[Ku16::u1]=&elem1;
        v[Ku16::u2]=&elem2;
    }

    template <typename T, Uint16 n>
    Suiteref<T,n>::Suiteref(T& elem0,
                            T& elem1,
                            T& elem2,
                            T& elem3)
    {
        Assertions::Compile_time<n==Ku16::u4>();
        v[Ku16::u0]=&elem0;
        v[Ku16::u1]=&elem1;
        v[Ku16::u2]=&elem2;
        v[Ku16::u3]=&elem3;
    }

    template <typename T, Uint16 n>
    Suiteref<T,n>::Suiteref(T& elem0,
                            T& elem1,
                            T& elem2,
                            T& elem3,
                            T& elem4)
    {
        Assertions::Compile_time<n==5>();
        v[0]=&elem0;
        v[1]=&elem1;
        v[2]=&elem2;
        v[3]=&elem3;
        v[4]=&elem4;
    }

    template <typename T, Uint16 n>
    Suiteref<T,n>::Suiteref(T& elem0,
                            T& elem1,
                            T& elem2,
                            T& elem3,
                            T& elem4,
                            T& elem5)
    {
        Assertions::Compile_time<n==Ku16::u6>();
        v[Ku16::u0]=&elem0;
        v[Ku16::u1]=&elem1;
        v[Ku16::u2]=&elem2;
        v[Ku16::u3]=&elem3;
        v[Ku16::u4]=&elem4;
        v[Ku16::u5]=&elem5;
    }

    template <typename T, Uint16 n>
    Suiteref<T,n>::Suiteref(T& elem0,
                            T& elem1,
                            T& elem2,
                            T& elem3,
                            T& elem4,
                            T& elem5,
                            T& elem6)
    {
        Assertions::Compile_time<n==Ku16::u7>();
        v[Ku16::u0]=&elem0;
        v[Ku16::u1]=&elem1;
        v[Ku16::u2]=&elem2;
        v[Ku16::u3]=&elem3;
        v[Ku16::u4]=&elem4;
        v[Ku16::u5]=&elem5;
        v[Ku16::u6]=&elem6;
    }

    template <typename T, Uint16 n>
    Suiteref<T,n>::Suiteref(T& elem0,
                            T& elem1,
                            T& elem2,
                            T& elem3,
                            T& elem4,
                            T& elem5,
                            T& elem6,
                            T& elem7)
    {
        Assertions::Compile_time<n==Ku16::u8>();
        v[Ku16::u0]=&elem0;
        v[Ku16::u1]=&elem1;
        v[Ku16::u2]=&elem2;
        v[Ku16::u3]=&elem3;
        v[Ku16::u4]=&elem4;
        v[Ku16::u5]=&elem5;
        v[Ku16::u6]=&elem6;
        v[Ku16::u7]=&elem7;
    }

    template <typename T, Uint16 n>
    Suiteref<T,n>::Suiteref(T& elem0,
                            T& elem1,
                            T& elem2,
                            T& elem3,
                            T& elem4,
                            T& elem5,
                            T& elem6,
                            T& elem7,
                            T& elem8)
    {
        Assertions::Compile_time<n==Ku16::u9>();
        v[Ku16::u0]=&elem0;
        v[Ku16::u1]=&elem1;
        v[Ku16::u2]=&elem2;
        v[Ku16::u3]=&elem3;
        v[Ku16::u4]=&elem4;
        v[Ku16::u5]=&elem5;
        v[Ku16::u6]=&elem6;
        v[Ku16::u7]=&elem7;
        v[Ku16::u8]=&elem8;
    }

    template <typename T, Uint16 n>
    Suiteref<T,n>::Suiteref(T& elem0,
                            T& elem1,
                            T& elem2,
                            T& elem3,
                            T& elem4,
                            T& elem5,
                            T& elem6,
                            T& elem7,
                            T& elem8,
                            T& elem9)
    {
        Assertions::Compile_time<n==Ku16::u10>();
        v[Ku16::u0]=&elem0;
        v[Ku16::u1]=&elem1;
        v[Ku16::u2]=&elem2;
        v[Ku16::u3]=&elem3;
        v[Ku16::u4]=&elem4;
        v[Ku16::u5]=&elem5;
        v[Ku16::u6]=&elem6;
        v[Ku16::u7]=&elem7;
        v[Ku16::u8]=&elem8;
        v[Ku16::u9]=&elem9;
    }

    template <typename T, Uint16 n>
    Suiteref<T,n>::Suiteref(T& elem0,
                            T& elem1,
                            T& elem2,
                            T& elem3,
                            T& elem4,
                            T& elem5,
                            T& elem6,
                            T& elem7,
                            T& elem8,
                            T& elem9,
                            T& elem10,
                            T& elem11)
    {
        Assertions::Compile_time<n==Ku16::u12>();
        v[Ku16::u0]=&elem0;
        v[Ku16::u1]=&elem1;
        v[Ku16::u2]=&elem2;
        v[Ku16::u3]=&elem3;
        v[Ku16::u4]=&elem4;
        v[Ku16::u5]=&elem5;
        v[Ku16::u6]=&elem6;
        v[Ku16::u7]=&elem7;
        v[Ku16::u8]=&elem8;
        v[Ku16::u9]=&elem9;
        v[Ku16::u10]=&elem10;
        v[Ku16::u11]=&elem11;
    }

    template <typename T, Uint16 n>
    Suiteref<T,n>::Suiteref(T& elem0,
                            T& elem1,
                            T& elem2,
                            T& elem3,
                            T& elem4,
                            T& elem5,
                            T& elem6,
                            T& elem7,
                            T& elem8,
                            T& elem9,
                            T& elem10,
                            T& elem11,
                            T& elem12)
    {
        Assertions::Compile_time<n==Ku16::u13>();
        v[Ku16::u0]=&elem0;
        v[Ku16::u1]=&elem1;
        v[Ku16::u2]=&elem2;
        v[Ku16::u3]=&elem3;
        v[Ku16::u4]=&elem4;
        v[Ku16::u5]=&elem5;
        v[Ku16::u6]=&elem6;
        v[Ku16::u7]=&elem7;
        v[Ku16::u8]=&elem8;
        v[Ku16::u9]=&elem9;
        v[Ku16::u10]=&elem10;
        v[Ku16::u11]=&elem11;
        v[Ku16::u12]=&elem12;
    }

    template <typename T, Uint16 n>
    Suiteref<T,n>::Suiteref(T& elem0,
                            T& elem1,
                            T& elem2,
                            T& elem3,
                            T& elem4,
                            T& elem5,
                            T& elem6,
                            T& elem7,
                            T& elem8,
                            T& elem9,
                            T& elem10,
                            T& elem11,
                            T& elem12,
                            T& elem13,
                            T& elem14,
                            T& elem15,
                            T& elem16,
                            T& elem17,
                            T& elem18)
    {
        Assertions::Compile_time<n==Ku16::u19>();
        v[Ku16::u0]=&elem0;
        v[Ku16::u1]=&elem1;
        v[Ku16::u2]=&elem2;
        v[Ku16::u3]=&elem3;
        v[Ku16::u4]=&elem4;
        v[Ku16::u5]=&elem5;
        v[Ku16::u6]=&elem6;
        v[Ku16::u7]=&elem7;
        v[Ku16::u8]=&elem8;
        v[Ku16::u9]=&elem9;
        v[Ku16::u10]=&elem10;
        v[Ku16::u11]=&elem11;
        v[Ku16::u12]=&elem12;
        v[Ku16::u13]=&elem13;
        v[Ku16::u14]=&elem14;
        v[Ku16::u15]=&elem15;
        v[Ku16::u16]=&elem16;
        v[Ku16::u17]=&elem17;
        v[Ku16::u18]=&elem18;
    }

    template <typename T, Uint16 n>
    Suiteref<T,n>::Suiteref(T& elem0,
                            T& elem1,
                            T& elem2,
                            T& elem3,
                            T& elem4,
                            T& elem5,
                            T& elem6,
                            T& elem7,
                            T& elem8,
                            T& elem9,
                            T& elem10,
                            T& elem11,
                            T& elem12,
                            T& elem13,
                            T& elem14,
                            T& elem15,
                            T& elem16,
                            T& elem17,
                            T& elem18,
                            T& elem19,
                            T& elem20,
                            T& elem21,
                            T& elem22,
                            T& elem23,
                            T& elem24)
    {
        Assertions::Compile_time<n==Ku16::u25>();
        v[Ku16::u0]=&elem0;
        v[Ku16::u1]=&elem1;
        v[Ku16::u2]=&elem2;
        v[Ku16::u3]=&elem3;
        v[Ku16::u4]=&elem4;
        v[Ku16::u5]=&elem5;
        v[Ku16::u6]=&elem6;
        v[Ku16::u7]=&elem7;
        v[Ku16::u8]=&elem8;
        v[Ku16::u9]=&elem9;
        v[Ku16::u10]=&elem10;
        v[Ku16::u11]=&elem11;
        v[Ku16::u12]=&elem12;
        v[Ku16::u13]=&elem13;
        v[Ku16::u14]=&elem14;
        v[Ku16::u15]=&elem15;
        v[Ku16::u16]=&elem16;
        v[Ku16::u17]=&elem17;
        v[Ku16::u18]=&elem18;
        v[Ku16::u19]=&elem19;
        v[Ku16::u20]=&elem20;
        v[Ku16::u21]=&elem21;
        v[Ku16::u22]=&elem22;
        v[Ku16::u23]=&elem23;
        v[Ku16::u24]=&elem24;
    }

    template <typename T, Uint16 n>
    Suiteref<T,n>::Suiteref(T& elem0,
                            T& elem1,
                            T& elem2,
                            T& elem3,
                            T& elem4,
                            T& elem5,
                            T& elem6,
                            T& elem7,
                            T& elem8,
                            T& elem9,
                            T& elem10,
                            T& elem11,
                            T& elem12,
                            T& elem13,
                            T& elem14,
                            T& elem15,
                            T& elem16,
                            T& elem17,
                            T& elem18,
                            T& elem19,
                            T& elem20,
                            T& elem21,
                            T& elem22,
                            T& elem23,
                            T& elem24,
                            T& elem25)
    {
        Assertions::Compile_time<n==Ku16::u26>();
        v[Ku16::u0]=&elem0;
        v[Ku16::u1]=&elem1;
        v[Ku16::u2]=&elem2;
        v[Ku16::u3]=&elem3;
        v[Ku16::u4]=&elem4;
        v[Ku16::u5]=&elem5;
        v[Ku16::u6]=&elem6;
        v[Ku16::u7]=&elem7;
        v[Ku16::u8]=&elem8;
        v[Ku16::u9]=&elem9;
        v[Ku16::u10]=&elem10;
        v[Ku16::u11]=&elem11;
        v[Ku16::u12]=&elem12;
        v[Ku16::u13]=&elem13;
        v[Ku16::u14]=&elem14;
        v[Ku16::u15]=&elem15;
        v[Ku16::u16]=&elem16;
        v[Ku16::u17]=&elem17;
        v[Ku16::u18]=&elem18;
        v[Ku16::u19]=&elem19;
        v[Ku16::u20]=&elem20;
        v[Ku16::u21]=&elem21;
        v[Ku16::u22]=&elem22;
        v[Ku16::u23]=&elem23;
        v[Ku16::u24]=&elem24;
        v[Ku16::u25]=&elem25;
    }


    template <typename T, Uint16 n>
    inline Suiteref<T,n>::~Suiteref()
    {
    }

    template <typename T, Uint16 n>
    inline T& Suiteref<T,n>::get(Uint32 i) //PRQA S 4211 #const
    {
        return *v[i];
    }

    template <typename T, Uint16 n>
    inline const T& Suiteref<T,n>::get(Uint32 i)const
    {
        return *v[i];
    }

    template <typename T, Uint16 n>
    inline Uint32 Suiteref<T,n>::size()
    {
        return n;
    }

    template <typename T, Uint16 n>
    inline bool Suiteref<T,n>::has_idx(Uint16 idx)
    {
        return idx<n;
    }

    template <typename T, Uint16 n>
    inline Mblock<T*> Suiteref<T,n>::to_mblock()
    {
        return v.to_mblock();
    }

} // namespace Base

#endif // SUITEREF_H_

