#ifndef GPIOIOCTL_H_
#define GPIOIOCTL_H_

#include <GPIOid.h>
#include <GPIOmux.h>
#include <GPIOtun.h>

#include <GPIO_fw.h>

namespace Dsp28335_ent
{
    struct GPIOioctl
    {
    public:
        enum Core_select    ///< Core control selection values
        {
            c1,     ///< CPU1 selected as master core
            cla1,   ///< CPU1's CLA1 selected as master core
            c2,     ///< CPU2 selected as master core
            cla2,   ///< CPU2's CLA1 selected as master core
            cm      ///< CM selected as master core (Only for 2838X)
        };

        static const GPIOtun gpio_input_cfg;
        static const GPIOtun gpio_output_cfg;

        /// Applies settings to some GPIO id.
        /// \param  id GPIO id to configure
        /// \param cfg GPIO settings
        static void apply(GPIOid id, const GPIOtun& cfg);

        /// Applies settings to some GPIO id.
        /// \param  id  GPIO id to configure
        /// \param  cfg GPIO settings
        /// \param  cs  Give ownership to core 2 if true
        static void apply(GPIOid id, const GPIOtun& cfg, Core_select cs);

        /// Applies settings to some GPIO id.
        template <GPIOid id,
                  GPIOtun::Dir d,
                  GPIOtun::Pullup p,
                  Muxfun m,
                  GPIOtun::Qsel q>
        static void apply();

        /// Apply mux to given GPIO
        static void apply_mux(GPIOid id, GPIOtun::Mux m);

        /// Configures as an input GPIO
        static void apply_input(GPIOid id);
        /// Configures as an output GPIO
        static void apply_output(GPIOid id);

        //This is a very specific method to setup D+ and D- pins for USB.
        //Those pins are not related with Mux and also can only be on pins 42 and 43.
        static void apply_usb_pins();

    private:

        bool is_valid() const;

        GPIOioctl(); ///< = delete
        GPIOioctl(const GPIOioctl& orig); ///< = delete
        GPIOioctl& operator=(const GPIOioctl& orig); ///< = delete
    };

    inline void GPIOioctl::apply(GPIOid id, const GPIOtun& cfg)
    {
        apply(id, cfg, c1);
    }

    template <GPIOid id,
              GPIOtun::Dir d,
              GPIOtun::Pullup p,
              Muxfun m,
              GPIOtun::Qsel q>
    inline void GPIOioctl::apply()
    {
        GPIOioctl::apply(id, GPIOtun::build(d,p,GPIOmux<id,m>::value,q));
    }

    inline void GPIOioctl::apply_input(GPIOid id)
    {
        apply(id, gpio_input_cfg);
    }

    inline void GPIOioctl::apply_output(GPIOid id)
    {
        apply(id, gpio_output_cfg);
    }
}
#endif
