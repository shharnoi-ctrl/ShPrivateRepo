#ifndef GPIOVALID_H_
#define GPIOVALID_H_

#include <Entypes.h>

namespace Dsp28335_ent
{
    extern bool is_gpioid_valid(Uint16 id);

}
#endif
