#include <Devcfg.h>
#include <Devcfg_regs.h>
#include <Asm.h>
#include <Hregmap.h>
#include <Ku16.h>
#include <Ku32.h>
#include <Tnarray.h>

namespace Dsp28335_ent
{
    void Devcfg::cpu2_reset_deactivate()
    {
        static const Uint32 varCPU2_deactivate_reset = 0xA5A50000UL;
        volatile Registers& regs(Hregmap::get<Registers, devcfg_regs_addr>());
        asm_eallow();
        regs.CPU2RESCTL.all = varCPU2_deactivate_reset;       // CPU2 reset is deactivated
        asm_edis();
    }
}
