#ifndef LOSSY_H__
#define LOSSY_H__

#include <Karray.h>
#include <Itunable.h>
#include <Endianness.h>
#include <Endian3.h>
#include <Ichecksum.h>
#include <Iendian16.h>
#include <Iendian32.h>
#include <Iendian64.h>
#include <U8pkmblock.h>
#include <U8pkmblock_k.h>
#include <U8istream.h>
#include <Lossy_error_fw.h>
#include <Real16.h>

namespace Base
{
    /// Data serialization and deserialization. Only should be used for serialize and deserialize configurables and
    /// in custom messages.
    class Lossy
    {
    public:

        /// Mutator traits for 8-bit data type.
        template <typename TYPE = Lossy>
        struct Mutator_traits8 : public type_is<TYPE>
        {
            /// Constant 8-bit to 16-bit block type.
            /// \wi{18015}
            /// Mutator_traits8 for Lossy structure shall provide a function to adapt an 8-bit constant memory block
            /// to a 16-bit memory block.
            /// \param[in] mb Data represented as a 8-bit constant memory block.
            /// \return Data represented as a 16-bit memory block.
            static inline Mblock_u16 adapt_data(const U8pkmblock_k& mb)
            {
                return Mblock_u16(const_cast<Uint16*>(mb.to_mblock().v), mb.size());
            }
            /// 8-bit to 16-bit block type.
            /// \wi{18016}
            /// Mutator_traits8 for Lossy structure shall provide a function to adapt an 8-bit memory block to a 16-bit
            /// memory block.
            /// \param[in] mb Data represented as a 8-bit memory block.
            /// \return Data represented as a 16-bit memory block.
            static inline Mblock_u16 adapt_data(const U8pkmblock& mb)  /// \return Data to build the mutator
            {
                return mb.to_mblock();
            }
            /// 8-bit Size Retriever.
            /// \wi{18017}
            /// Mutator_traits8 for Lossy structure shall provide a function to retrieve the 8-bit size of a given
            /// Lossy instance.
            /// \param[in] str Lossy instance being requested.
            /// \return Lossy 8-bit size.
            static inline Uint32 get_size(const Lossy& str)
            {
                return str.ceil_size_bytes();
            }
            /// 8-bit Position Setter.
            /// \wi{18018}
            /// Mutator_traits8 for Lossy structure shall provide a function to update the internal pointer of given
            /// Lossy instance assuming new size is being provided in 8-bit size.
            /// \param[out] str Lossy which size will be updated.
            /// \param[in] sz New size to be applied being provided in 8-bit size.
            static inline void set_pos(Lossy& str, Uint16 sz)
            {
                str.set_pos(Bitutils::bytes_to_bits(sz));
            }
        };
        /// Data traits for 8-bit data type.
        struct Data_traits8 : public type_is<Lossy>
        {
            /// 8-bit data from lossy to 16-bit block type.
            /// \wi{18019}
            /// Data_traits8 for Lossy structure shall be able to retrieve the stream of data of given Lossy instance
            /// represented as a 16-bit memory block.
            /// \param[in] str Lossy which data will be retrieved.
            /// \return Stream of data of given Lossy as a 16-bit memory block.
            static inline const Mblock_u16 get_data(const Lossy& str)
            {
                NWord* first = const_cast<Uint16*>(str.a_obj.first());
                return Mblock_u16(first, static_cast<Uint32>(str.a_obj.last() - first));
            }
            /// 8-bit Data Size updater.
            /// \wi{18020}
            /// Data_traits8 for Lossy structure shall be able to update the size of a given Lossy instance assuming
            /// given size is provided as a 8-bit size.
            /// \param[in, out] str Lossy instance which size will be updated.
            /// \param[in] sz 8-bit size to be incremented to current size.
            static inline void update_size(Lossy& str, Uint32 sz)
            {
                str.set_pos(str.get_pos() + Bitutils::bytes_to_bits(sz));
            }
            /// 8-bit Data Maximum Size Retriever.
            /// \wi{18021}
            /// Data_traits8 for Lossy structure shall be able to retrieve the maximum size allowed for a given Lossy
            /// instance in 8-bit size.
            /// \param[in] str Lossy which maximum size is being requested.
            /// \return 8-bit Maximum size allowed for given Lossy.
            static inline Uint16 get_max_size(Lossy& str)
            {
                return str.a_obj.size_max();
            }
            /// 8-bit Data Position Retriever.
            /// \wi{18022}
            /// Data_traits8 for Lossy structure shall be able to retrieve the internal Lossy pointer represented as
            /// a 8-bit pointer.
            /// \param[in] str Lossy which current position is being requested.
            /// \return Current 8-bit position for given Lossy instance.
            static inline Uint16 get_pos(const Lossy& str)
            {
                return Bitutils::bits_to_bytes(str.get_pos());
            }
        };
        /// Data traits for 16-bit data type.
        template <typename TYPE = Lossy>
        struct Mutator_traits16 : public type_is<TYPE>
        {
            /// Constant 16-bit to 16-bit Block Type.
            /// \wi{18023}
            /// Mutator_traits16 for Lossy structure shall provide a function to adapt an 16-bit constant memory block
            /// to a 16-bit memory block.
            /// \param[in] mb Data represented as a 16-bit constant memory block.
            /// \return Data represented as a 16-bit memory block.
            static inline Mblock_u16 adapt_data(const Mblock<const Uint16>& mb)
            {
                return Mblock_u16(const_cast<Uint16*>(mb.v), mb.size());
            }

            /// 16-bit to 16-bit Block Type.
            /// \wi{18024}
            /// Mutator_traits16 for Lossy structure shall provide a function to adapt an 16-bit memory block to a
            /// 16-bit memory block.
            /// \param[in] mb Data represented as a 16-bit memory block.
            /// \return Data represented as a 16-bit memory block.
            static inline Mblock_u16 adapt_data(Mblock_u16& mb)
            {
                return Mblock_u16(mb);
            }
            /// 16-bit Size Retriever.
            /// \wi{18025}
            /// Mutator_traits16 for Lossy structure shall provide a function to retrieve the 16-bit size of a given
            /// Lossy instance.
            /// \param[in] str Lossy instance being requested.
            /// \return Lossy 16-bit size.
            static inline Uint32 get_size(const Lossy& str)
            {
                return str.get_pos16();
            }
            /// 16-bit Position Setter.
            /// \wi{18026}
            /// Mutator_traits16 for Lossy structure shall provide a function to update the internal pointer of given
            /// Lossy instance assuming new size is being provided in 16-bit size.
            /// \param[out] str Lossy which size will be updated.
            /// \param[in] sz New size to be applied being provided in 16-bit size.
            static inline void set_pos(Lossy& str, Uint16 sz)
            {
                str.set_pos(Bitutils::words16_to_bits(sz));
            }
        };

        static const Uint16 strversion = 1;  ///< Serialization version.

        /// De/Serializer Constant Copy Constructor.
        /// \wi{5101}
        /// Lossy class shall build itself upon construction with another given Lossy constant instance.
        /// \param[in] other Constant Lossy instance used to build the new instance.
        explicit Lossy(const Lossy& other);
        /// De/Serializer Constructor from 16-bit block type.
        /// \wi{17980}
        /// Lossy class shall build itself upon construction with a given Memory Block of Uint16 type.
        /// \param[in] mb Memory block used to build internal stream of data.
        explicit Lossy(Mblock_u16 mb);
        /// De/Serializer Constructor with Given Pointer and Size.
        /// \wi{17981}
        /// Lossy class shall build itself upon construction with a given pointer to Uint16 data and size.
        /// \param[in] v0 Uint16 pointer used to initialize internal stream of data.
        /// \param[in] n0 Size used to initialize internal stream of data.
        Lossy(Uint16* v0, Uint32 n0);
        /// De/Serializer Constructor with Given Size and Memory Type.
        /// \wi{17982}
        /// Lossy class shall build itself upon construction with a given size and memory type where allocate the
        /// stream of data.
        /// \param[in] n0 Size of internal stream of data.
        /// \param[in] memtype Memory Type where allocate the internal stream of data.
        Lossy(Uint32 n0, Memmgr::Type memtype);
        /// De/Serializer Constructor with given Size and Allocator.
        /// \wi{17983}
        /// Lossy class shall build itself upon construction with a given size and memory allocator.
        /// \param[in] n0 Size of internal stream of data.
        /// \param[in] alloc Memory allocator where allocate the internal stream of data.
        Lossy(Uint32 n0, Allocator& alloc);

        /// De/Serializer Endianness Setter.
        /// \wi{4608}
        /// Lossy class shall be able to update its current internal endianness being used in the de/serialization.
        /// \param[in] type Endianness to be used in the de/serialization.
        void set_endian(Endianness type);
        /// De/Serializer Default Endianness Checker.
        /// \wi{5606}
        /// Lossy class shall be able to check if current internal endianness is the default one (Little-endian).
        /// \return True if current endianness being used is Little-endian, False otherwise.
        bool is_default_endian() const;

        /// De/Serializer Effective 16-bit Words Size Retriever.
        /// \wi{5106}
        /// Lossy class shall be able to retrieve the effective size de/serialized in 16-bit words.
        /// \return Current bit position (::x) in words.
        Uint32 ceil_size() const;
        
        /// De/Serializer Effective Byte Length Retriever.
        /// \wi{5104}
        /// Lossy class shall be able to retrieve the effective size de/serialized in bytes.
        /// \return Current bit position (::x) in bytes.
        Uint32 ceil_size_bytes() const;

        /// De/Serializer Alignment Checker.
        /// \wi{5107}
        /// Lossy class shall be able to check if the de/serialization is word-aligned.
        /// \return True if current bit position (::x) is word-aligned, False if not.
        bool is_aligned() const;
        /// De/Serializer Aligner.
        /// \wi{5108}
        /// Lossy class shall be able to align in words its internal de/serializer pointer (::x).
        void align();
        /// De/Serialize Byte Aligner.
        /// \wi{19551}
        /// Lossy class shall be able to align in bytes its internal de/serializer pointer (::x).
        void align_bytes();

        /// De/Serializer Bit Position Retriever.
        /// \wi{5109}
        /// Lossy class shall be able to retrieve its internal de/serializer pointer.
        /// \return Current bit position (::x).
        Uint32 get_pos() const;
        
        /// De/Serializer 8-bit Position Retriever.
        /// \wi{19552}
        /// Lossy class shall be able to retrieve its internal de/serializer pointer in bytes.
        /// \return Current position in bytes.
        Uint32 get_pos_bytes() const;
        /// De/Serializer 16-bit Position Retriever.
        /// \wi{5110}
        /// Lossy class shall be able to retrieve its internal de/serializer pointer in 16-bit words.
        /// \return Current bit position (::x) in 16-bit words.
        Uint32 get_pos16() const;
        
        /// De/Serializer Bit Position Setter.
        /// \wi{5111}
        /// Lossy class shall be able to set its internal de/serializer pointer to given one.
        /// \param[in] pos New bit position to be used.
        void set_pos(Uint32 pos);
        /// De/Serializer Byte Position Setter.
        /// \wi{17984}
        /// Lossy class shall be able to set its internal de/serializer pointer to given one in bytes.
        /// \param[in] pos New bit position to be used given bytes.
        void set_pos_bytes(Uint32 pos);

        /// De/Serializer Turn Back Bits.
        /// \wi{5112}
        /// Lossy class shall be able to turn back a given number of bits.
        /// \param[in] n0 Number of bits to turn back.
        void turnback_bits(Uint32 n0);
        /// De/Serializer Turn Back Bytes.
        /// \wi{5113}
        /// Lossy class shall be able to turn back a given number of bits.
        /// \param[in] n0 Number of bytes to turn back.
        void turnback_bytes(Uint32 n0);

        /// De/Serializer Bits Skipper.
        /// \wi{5116}
        /// Lossy class shall be able to skip a given number of bits.
        /// \param[in] n0 Number of bits to be skipped.
        void skip_bits(Uint32 n0);
        /// De/Serializer Bytes Skipper.
        /// \wi{5117}
        /// Lossy class shall be able to skip a given number of bytes.
        /// \param[in] n0 Number of bits to be skipped.
        void skip_bytes(Uint32 n0);
        /// De/Serializer 16-bit Words Skipper.
        /// \wi{5118}
        /// Lossy class shall be able to skip a given number of 16-bit words.
        /// \param[in] n0 Number of 16-bit words to be skipped.
        void skip_words(Uint32 n0);
        /// De/Serializer String 16 Skipper.
        /// \wi{17985}
        /// Lossy class shall be able to skip a read length of 16-bit words.
        /// \param[in] max_skip Maximum 16-bit words to be skipped, assigned by default to Ku16::uMAX.
        /// \return True if all read length has been skipped, False if read length was bigger than maximum allowed
        /// and only has been skipped the maximum allowed.
        bool skip_string16(const Uint16 max_skip = Ku16::uMAX);

        /// De/Serializer Unused Bits Retriever.
        /// \wi{5119}
        /// Lossy class shall be able to retrieve the available room in bits.
        /// \return Unused bits.
        Uint32 get_unused_bits() const;
        /// De/Serializer Unused Bytes Retriever.
        /// \wi{5103}
        /// Lossy class shall be able to retrieve the available room in bytes.
        /// \return Unused bytes.
        Uint32 get_unused_bytes() const;
        /// De/Serializer Unused 16-bit Words Retriever.
        /// \wi{5105}
        /// Lossy class shall be able to retrieve the available room in 16-bit words.
        /// \return Unused words.
        Uint32 get_unused_words() const;
        /// De/Serializer Restart Bit Position.
        /// \wi{5115}
        /// Lossy class shall be able to restart its internal (::x) de/serializer bit position.
        void reuse();

        /// 1-bit As Boolean Deserializer.
        /// \wi{4612}
        /// Lossy class shall be able to deserialize one bit from the internal stream of data and retrieve it as
        /// a boolean value.
        /// \param[out] b Read data as a boolean value.
        void get_bool1(bool& b);
        /// 16-bit as Boolean Deserializer.
        /// \wi{4482}
        /// Lossy class shall be able to deserialize 16 bits from the internal stream of data using the current
        /// Endianness and retrieve them as a boolean value.
        /// \param[out] b Read data as a boolean value.
        void get_bool16(bool& b);
        /// 32-bit Float Deserializer.
        /// \wi{4613}
        /// Lossy class shall be able to deserialize 32 bits from the internal stream of data using the current
        /// Endianness and retrieve them as a Real value.
        /// \param[out] r Read data as a Real value.
        void get_float(Real& r);

        /// 32-bit Float Deserializer Return By Value.
        /// \wi{20544}
        /// Lossy class shall be able to deserialize 32 bits from the internal stream of data using the current
        /// Endianness and retrieve them as a Real value returned by value.
        /// \return Read data as a Real value.
        Real get_float();

        /// Three 32-bit Floats Deserializer.
        /// \wi{4483}
        /// Lossy class shall be able to deserialize three 32-bit floats from the internal stream of data using the
        /// current Endianness and retrieve them into Real pointers.
        /// \param[out] r Read data as a pointer to three Real values.
        void get_float3(Real* r);
        /// Nine 32-bit Floats Deserializer.
        /// \wi{4485}
        /// Lossy class shall be able to deserialize nine 32-bit floats from the internal stream of data using the
        /// current Endianness and retrieve them into Real pointers.
        /// \param[out] r Read data as a pointer to nine Real values.
        void get_float9(Real* r);
        /// 8-bit Unsigned Integer Deserializer.
        /// \wi{4620}
        /// Lossy class shall be able to deserialize 8 bits from the internal stream of data and retrieve them as a
        /// 8-bit unsigned integer value.
        /// \param[out] val Read data as a 8-bit unsigned integer value.
        void get_uint8(Uint8& val);
        /// 8-bit Boolean Deserializer.
        /// \wi{17986}
        /// Lossy class shall be able to deserialize 8 bits from the internal stream of data and retrieve them as a
        /// boolean value.
        /// \param[out] b Read data as a boolean value.
        void get_bool8(bool& b);
        /// 8-bit Signed Integer Deserializer.
        /// \wi{5122}
        /// Lossy class shall be able to deserialize 8 bits from the internal stream of data and retrieve them as a
        /// 8-bit signed integer value.
        /// \param[out] val Read data as a 8-bit signed integer value.
        void get_int8(int8& val);
        /// 16-bit Unsigned Integer Deserializer.
        /// \wi{4621}
        /// Lossy class shall be able to deserialize 16 bits from the internal stream of data using the current
        /// Endianness and retrieve them as a 16-bit unsigned integer value.
        /// \param[out] val Read data as a 16-bit unsigned integer value.
        void get_uint16(Uint16& val);

        /// 16-bit Unsigned Integer Deserializer Return By Value.
        /// \wi{20545}
        /// Lossy class shall be able to deserialize 16 bits from the internal stream of data using the current
        /// Endianness and retrieve them as a 16-bit unsigned integer value.
        /// \return Read data as a 16-bit unsigned integer value returned by value.
        Uint16 get_uint16();

        /// 8-bit Enumerator Deserializer.
        /// \wi{5120}
        /// Lossy class shall be able to deserialize 8 bits from the internal stream of data and retrieve them as a
        /// 8-bit given enumerator type value.
        /// \param[out] en0 Read data as a 8-bit given enumerator type value.
        template <typename E>
        void get_enum8(E& en0);
        /// 16-bit Enumerator Deserializer.
        /// \wi{5121}
        /// Lossy class shall be able to deserialize 16 bits from the internal stream of data using the current
        /// Endianness and retrieve them as a 16-bit given enumerator type value of 1 byte size.
        /// \param[out] en0 Read data as a 16-bit given enumerator type value of 1 byte size.
        template <typename E>
        typename Enable_if<size_bytes_t<E>::value == Ku16::u1, void>::type
        get_enum16(E& en0);
        /// 16-bit Enumerator Deserializer.
        /// \wi{17987}
        /// Lossy class shall be able to deserialize 16 bits from the internal stream of data using the current
        /// Endianness and retrieve them as a 16-bit given enumerator type value of 2 bytes size.
        /// \param[out] en0 Read data as a 16-bit given enumerator type value of 2 bytes size.
        template <typename E>
        typename Enable_if<size_bytes_t<E>::value >= Ku16::u2, void>::type
        get_enum16(E& en0);

        /// 16-bit Signed Integer Deserializer.
        /// \wi{5123}
        /// Lossy class shall be able to deserialize 16 bits from the internal stream of data using the current
        /// Endianness and retrieve them as a 16-bit signed integer value.
        /// \param[out] i16 Read data as a 16-bit signed integer value.
        void get_int16(int16& i16);
        /// 32-bit Signed Integer Deserializer.
        /// \wi{4488}
        /// Lossy class shall be able to deserialize 32 bits from he internal stream of data using the current
        /// Endianness and retrieve them as a 32-bit signed integer value.
        /// \param[out] val Read data as a 32-bit signed integer value.
        void get_int32(int32& val);
        /// 32-bit Unsigned Integer Deserializer.
        /// \wi{4622}
        /// Lossy class shall be able to deserialize 32 bits from the internal stream of data using the current
        /// Endianness and retrieve them as a 32-bit unsigned integer value.
        /// \param[out] val Read data as a 32-bit unsigned integer value.
        void get_uint32(Uint32& val);
        /// 64-bit Unsigned Integer Deserializer.
        /// \wi{4624}
        /// Lossy class shall be able to deserialize 64 bits from the internal stream of data using the current
        /// Endianness and retrieve them as a 64-bit unsigned integer value.
        /// \param[out] val Read data as a 64-bit unsigned integer value.
        void get_uint64(Uint64& val);
        /// 64-bit Float Deserializer.
        /// \wi{4484}
        /// Lossy class shall be able to deserialize 64 bits from the internal stream of data using the current
        /// Endianness and retrieve them as a 64-bit float value.
        /// \param[out] r Read data as a 64-bit real value.
        void get_float64(Real64& r);
        /// 16-bit Float Deserializer.
        /// \wi{6498}
        /// Lossy class shall be able to deserialize 16 bits from the internal stream of data using the current
        /// Endianness and retrieve them as a 16-bit float value into a Real reference.
        /// \param[out] Read 16-bit real value represented as a Real value.
        void get_float16(Real& r);
        /// Unsigned Bits Deserializer (32 bits as maximum).
        /// \wi{4489}
        /// Lossy class shall be able to deserialize a given number of bits from the internal stream of data using the
        /// current Endianness and retrieve them as a 32-bit unsigned integer value.
        /// \param[out] val Read data as a 32-bit unsigned integer value.
        /// \param[in] nbits Number of bits to be deserialized.
        void get_ubits(Uint32& val, Uint16 nbits);
        /// Unsigned Bits Deserializer (64 bits as maximum).
        /// \wi{17988}
        /// Lossy class shall be able to deserialize a given number of bits from the internal stream of data using the
        /// current Endianness and retrieve them as a 64-bit unsigned integer value.
        /// \param[out] val Read data as a 64-bit unsigned integer value.
        /// \param[in] nbits Number of bits to be deserialized.
        void get_ubits(Uint64& val, Uint16 nbits);
        void get_ibits(int32& val, Uint16 nbits);
        /// Unsigned Bits as Float Deserializer.
        /// \wi{4487}
        /// Lossy class shall be able to deserialize a given number of bits from the internal stream of data using the
        /// current Endianness and retrieve them as a float value uncompressing it with received unsigned compression.
        /// \param[out] r Read data as a Real value.
        /// \param[in] nbits Number of bits to be deserialized.
        /// \param[in] rmin Minimum Real value allowed in the uncompression.
        /// \param[in] rmax Maximum Real value allowed in the uncompression.
        /// \param[in] umin Minimum Unsigned Integer value allowed in the uncompression.
        /// \param[in] umax Maximum Unsigned Integer value allowed in the uncompression.
        void get_float_ubits(Real& r,
                Uint16 nbits,
                Real rmin,
                Real rmax,
                Uint32 umin,
                Uint32 umax);
        /// Signed Bits as Float Deserializer.
        /// \wi{4486}
        /// Lossy class shall be able to deserialize a given number of bits from the internal stream of data using the
        /// current Endianness and retrieve them as a float value uncompressing it with received signed compression.
        /// \param[out] r Read data as a Real value.
        /// \param[in] nbits Number of bits to be deserialized.
        /// \param[in] rmin Minimum Real value allowed in the uncompression.
        /// \param[in] rmax Maximum Real value allowed in the uncompression.
        /// \param[in] imin Minimum Signed Integer value allowed in the uncompression.
        /// \param[in] imax Maximum Signed Integer value allowed in the uncompression.
        void get_float_ibits(Real& r,
                Uint16 nbits,
                Real rmin,
                Real rmax,
                int32 imin,
                int32 imax);
        /// Compressed Float Deserializer.
        /// \wi{17989}
        /// Lossy class shall be able to deserialize a number of bits computed with a given range from the internal
        /// stream of data using the current Endianness and retrieve them as a float value uncompressing it with
        /// received range of values and decimals.
        /// \param[out] r Read data as a Real value.
        /// \param[in] minval Minimum Real value allowed.
        /// \param[in] maxval Maximum Real value allowed.
        /// \param[in] decimals Desired decimals to represent the real value.
        void get_float(Real& r,
                       Real minval,
                       Real maxval,
                       Uint8 decimals);
        /// Compressed 8-bit Unsigned Integer Deserializer.
        /// \wi{17990}
        /// Lossy class shall be able to deserialize a number of bits computed with a given range from the internal
        /// stream of data using the correct Endianess and retrieve them as a Uint8 value uncompressing it with
        /// received range of values.
        /// \param[out] val Read data as Uint8 value.
        /// \param[in] minval Minimum Uint8 value allowed.
        /// \param[in] maxval Maximum Uint8 value allowed.
        void get_uint8(Uint8& val,
                       Uint8 minval,
                       Uint8 maxval);
        /// Compressed 16-bit Unsigned Integer Deserializer.
        /// \wi{17991}
        /// Lossy class shall be able to deserialize a number of bits computed with a given range from the internal
        /// stream of data using the correct Endianness and retrieve them as a Uint16 value uncompressing it with
        /// received range of values.
        /// \param[out] val Read data as Uint16 value.
        /// \param[in] minval Minimum Uint16 value allowed.
        /// \param[in] maxval Maximum Uint16 value allowed.
        void get_uint16(Uint16& val,
                        Uint16 minval,
                        Uint16 maxval);
        /// Compressed 32-bit Unsigned Integer Deserializer.
        /// \wi{17992}
        /// Lossy class shall be able to deserialize a number of bits computed with a given range from the internal
        /// stream of data using the correct Endianness and retrieve them as a Uint32 value uncompressing it with
        /// received range of values.
        /// \param[out] val Read data as Uint32 value.
        /// \param[in] minval Minimun Uint32 value allowed.
        /// \param[in] maxval Maximum Uint32 value allowed.
        void get_uint32(Uint32& val,
                        Uint32 minval,
                        Uint32 maxval);
        /// Array of 32-bit Float Deserializer.
        /// \wi{4614}
        /// Lossy class shall be able to deserialize a given number of 32-bit floats from the internal stream of data
        /// using the current Endianness and retrieve them into an array of floats.
        /// \param[out] val Array of 32-bit real values already read.
        /// \param[in] n0 Number of elements to be read.
        void get_n_float(Array<Real>& val, Uint32 n0);
        /// Block of 32-bit Float Deserializer.
        /// \wi{17993}
        /// Lossy class shall be able to deserialize a given number of 32-bit floats from the internal stream of data
        /// using the current Endianness and retrieve them into a block of floats.
        /// \param[out] mb Memory block of 32-bit real values already read.
        void get_n_float(Mblock<Real>& mb);
        /// Array of 8-bit Unsigned Integer Deserializer.
        /// \wi{4618}
        /// Lossy class shall be able to deserialize a given number of 8-bit unsigned integer elements from the
        /// internal stream of data and retrieve them into an Uint8 type array.
        /// \param[out] val Array of 8-bit unsigned integer values already read.
        /// \param[in] n0 Number of elements to be read.
        void get_n_uint8(Array<Uint8>&  val,Uint32 n0);
        /// 8-bit Unsigned Integer type Block Deserializer.
        /// \wi{17994}
        /// Lossy class shall be able to deserialize a given number of 8-bit unsigned integer elements from the
        /// internal stream of data and retrieve them into an U8pkmblock.
        /// \param[out] p U8pkmblock with values already read.
        void get_n_uint8(U8pkmblock& p);
        /// Array of 16-bit Unsigned Integer Deserializer.
        /// \wi{4616}
        /// Lossy class shall be able to deserialize a given number of 16-bit unsigned integer elements from the
        /// internal stream of data using the current Endianness and retrieve them into an Uint16 type array.
        /// \param[out] val Array of 16-bit unsigned integer values already read.
        /// \param[in] n0 Number of elements to be read.
        void get_n_uint16(Array<Uint16>& val,Uint32 n0);
        /// Array of 16-bit Unsigned Integer Deserializer (Intrinsic size).
        /// \wi{17995}
        /// Lossy class shall be able to deserialize an amount of 16-bit unsigned integer elements given into array
        /// size from the internal stream of data using the current Endianness and retrieve them into an Uint16 type
        /// array.
        /// \param[out] val Array of 16-bit unsigned integer values already read.
        void get_n_uint16(Array<Uint16>& val);
        /// Block of 16-bit Unsigned Integer Deserializer.
        /// \wi{17996}
        /// Lossy class shall be able to deserialize a given number of 16-bit Unsigned Integer elements from the
        /// internal stream of data and retrieve them into a Memory block of Uint16 type.
        /// \param[out] mb Memory block of Uint16 values already read.
        void get_n_uint16(Mblock<Uint16>& mb);
        /// Copy An Array of 16-bit Unsigned Integer Into Another Lossy Instance.
        /// \wi{17997}
        /// Lossy class shall be able to deserialize a given amount of 16-bit unsigned integer elements from the
        /// internal stream of data and retrieve them into another Lossy instance.
        /// \param[out] str Lossy instance where copy read data.
        /// \param[in] n0 Number of 16-bit Unsigned Integer data to be read and copied into received Lossy instance.
        void get_n_uint16(Lossy& str,Uint32 n0);
        /// Array of 32-bit Unsignded Integer Deserializer.
        /// \wi{4623}
        /// Lossy class shall be able to deserialize a given number of 32-bit unsigned integer elements from the
        /// internal stream of data using the current Endianness and retrieve them into an Uint32 type array.
        /// \param[out] val Array of 32-bit unsigned integer values already read.
        /// \param[in] n0 Number of elements to be read.
        void get_n_uint32(Array<Uint32>& val,Uint32 n0);
        /// Array of 64-bit Unsigned Integer Deserializer.
        /// \wi{4625}
        /// Lossy class shall be able to deserialize a given number of 64-bit unsigned integer elements from the
        /// internal stream of data using the current Endianness and retrieve them into an Uint64 type array.
        /// \param[out] val Array of 64-bit unsigned integer values already read.
        /// \param[in] n0 Number of elements to be read.
        void get_n_uint64(Array<Uint64>& val,Uint32 n0);


        /// Boolean Serializer as a 1-bit value.
        /// \wi{5588}
        /// Lossy class shall be able to serialize a boolean value adding 1 bit into the internal stream of data.
        /// \param[in] b Boolean value to be serialized.
        void put_bool1(bool b);
        /// Boolean Serializer as a 8-bit Value.
        /// \wi{17998}
        /// Lossy class shall be able to serialize a boolean value adding 8 bits into the internal stream of data.
        /// \param[in] b Boolean value to be serialized.
        void put_bool8(bool b);
        /// Boolean Serializer as a 16-bit value.
        /// \wi{4490}
        /// Lossy class shall be able to serialize a boolean value adding 16 bits into the internal stream of data
        /// using current Endianness.
        /// \param[in] b Boolean value to be serialized.
        void put_bool16(bool b);
        /// 32-bit Float Serializer.
        /// \wi{4494}
        /// Lossy class shall be able to serialize a 32-bit real value into the internal stream of data using current
        /// Endianness.
        /// \param[in] r 32-bit real value to be serialized.
        void put_float(Real r);
        /// 16-bit Float Serializer.
        /// \wi{6497}
        /// Lossy class shall be able to serialize a 16-bit real value into the internal stream of data using current
        /// Endianness.
        /// \param[in] r 32-bit real value to be converted to a 16-bit real value and serialized.
        void put_float16(Real r);
        /// Three 32-bit Floats Serializer.
        /// \wi{4496}
        /// Lossy class shall be able to serialize three 32-bit real values into the internal stream of data using
        /// current Endianness.
        /// \param[in] r Three real values represented as a constant pointer to the first element.
        void put_float3(const Real* r);
        /// Nine 32-bit Floats Serializer.
        /// \wi{4499}
        /// Lossy class shall be able to serialize nine 32-bit real values into the internal stream of data using
        /// current Endianness.
        /// \param[in] r Nine real values represented as a constant pointer to the first element.
        void put_float9(const Real* r);
        /// 8-bit Character Serializer.
        /// \wi{4492}
        /// Lossy class shall be able to serialize an 8-bit character into the internal stream of data.
        /// \param[in] val Character to be serialized.
        void put_char(char val);
        /// 8-bit Unsigned Integer Serializer.
        /// \wi{5590}
        /// Lossy class shall be able to serialize an 8-bit unsigned integer value into the internal stream of data.
        /// \param[in] val 8-bit Unsigned Integer value to be serialized.
        void put_uint8(Uint8 val);
        /// 8-bit Signed Integer Serializer.
        /// \wi{5124}
        /// Lossy class shall be able to serialize an 8-bit signed integer value into the internal stream of data.
        /// \param[in] val 8-bit Signed Integer value to be serialized.
        void put_int8(int8 val);
        /// 16-bit Signed Integer Serializer.
        /// \wi{5125}
        /// Lossy class shall be able to serialize a 16-bit signed integer value into the internal stream of data
        /// using current Endianness.
        /// \param[in] val 16-bit Signed Integer value to be serialized.
        void put_int16(int16 val);
        /// 16-bit Unsigned Integer Serializer.
        /// \wi{5592}
        /// Lossy class shall be able to serialize a 16-bit unsigned integer value into the internal stream of data
        /// using current Endianness.
        /// \param[in] val 16-bit Unsigned Integer value to be serialized.
        void put_uint16(Uint16 val);
        /// 32-bit Signed Integer Serializer.
        /// \wi{5126}
        /// Lossy class shall be able to serialize a 32-bit signed integer value into the internal stream of data
        /// using the current Endianness.
        /// \param[in] val 32-bit Signed Integer value to be serialized.
        void put_int32(int32 val);
        /// 32-bit Unsigned Integer Serializer.
        /// \wi{5594}
        /// Lossy class shall be able to serialize a 32-bit unsigned integer value into the internal stream of data
        /// using the current Endianness.
        /// \param[in] val 32-bit Unsigned Integer value to be serialized.
        void put_uint32(Uint32 val);
        /// 64-bit Unsigned Integer Serilizer.
        /// \wi{5597}
        /// Lossy class shall be able to serialize a 64-bit unsigned integer value into the internal stream of data
        /// using the current Endianness.
        /// \param[in] val 64-bit Unsigned Integer value to be serialized.
        void put_uint64(JSF116_Uint64 val);
        /// 64-bit Real Serializer.
        /// \wi{4497}
        /// Lossy class shall be able to serialize a 64-bit float value into the internal stream of data using the
        /// current Endianness.
        /// \param[in] r 64-bit Real value to be serialized.
        void put_float64(JSF116_Real64 r);
        /// Unsigned Integer Bits Serializer (Max 64 bits).
        /// \wi{4502}
        /// Lossy class shall be able to serialize a given amount of bits (64 as maximum) from an Unsigned Integer
        /// value into the internal stream of data using the current Endianness.
        /// \param[in] val Value to be serialized.
        /// \param[in] nbits Amount of bits to be serialized.
        void put_ubits(JSF116_Uint64 val, Uint16 nbits);
        /// Unsigned Integer Bits Serializer (Max 32 bits).
        /// \wi{19553}
        /// Lossy class shall be able to serialize a given amount of bits (32 as maximum) from an Unsigned Integer
        /// value into the internal stream of data using the current Endianness.
        /// \param[in] val Value to be serialized.
        /// \param[in] nbits Amount of bits to be serialized.
        inline void put_ubits(Uint32 val, Uint16 nbits)
        {
            endn->e32.put_uint32(val, a_obj.first(), x, nbits);
        }
        /// Signed Integer Bits Serializer (Max 32 bits).
        /// \wi{19554}
        /// Lossy class shall be able to serialize a given amount of bits (32 as maximum) from a Signed Integer value
        /// into the internal stream of data using the current Endianness.
        /// \param[in] val Value to be serialized.
        /// \param[in] nbits Amount of bits to be serialized.
        inline void put_ibits(int32 val, Uint16 nbits)
        {
            put_ubits(static_cast<Uint32>(val), nbits);
        }
        /// Unsigned Integer Bits Serializer (Max 16 bits).
        /// \wi{19555}
        /// Lossy class shall be able to serialize a given amount of bits (16 as maximum) from an Unsigned Integer
        /// value into the internal stream of data using the current Endianness.
        /// \param[in] val Value to be serialized.
        /// \param[in] nbits Amount of bits to be serialized.
        inline void put_ubits(Uint16 val, Uint16 nbits)
        {
            endn->e16.put_uint16(val, a_obj.first(), x, nbits);
        }
        /// Signed Integer Bits Serializer (Max 16 bits).
        /// \wi{19556}
        /// Lossy class shall be able to serialize a given amount of bits (16 as maximum) from a Signed Integer value
        /// into the internal stream of data using the current Endianness.
        /// \param[in] val Value to be serialized.
        /// \param[in] nbits Amount of bits to be serialized.
        inline void put_ibits(int16 val, Uint16 nbits)
        {
            put_ubits(static_cast<Uint16>(val), nbits);
        }

        /// Unsigned Float Bits Serializer.
        /// \wi{6319}
        /// Lossy class shall be able to serialize a given amount of bits from a real value into the internal stream
        /// of data using the current Endianness and compressing the value with given unsigned compression.
        /// \param[in] r Real value to be serialized.
        /// \param[in] nbits Number of bits from real value to be serialized (32 bits as maximum).
        /// \param[in] rmin Minimum real value allowed in the compression.
        /// \param[in] rmax Maximum real value allowed in the compression.
        /// \param[in] umin Minimum Unsigned Integer value allowed in the compression.
        /// \param[in] umax Maximum Unsigned Integer value allowed in the compression.
        void put_float_ubits(Real r,
                             Uint16 nbits,
                             Real rmin,
                             Real rmax,
                             Uint32 umin,
                             Uint32 umax);
        /// Signed Float Bits Serializer.
        /// \wi{6321}
        /// Lossy class shall be able to serialize a given amount of bits from a real value into the internal stream
        /// of data using the current Endianness and compressing the value with given signed compression.
        /// \param[in] r Real value to be serialized.
        /// \param[in] nbits Number of bits from real value to be serialized (32 bits as maximum).
        /// \param[in] rmin Minimum real value allowed in the compression.
        /// \param[in] rmax Maximum real value allowed in the compression.
        /// \param[in] imin Minimum Signed Integer value allowed in the compression.
        /// \param[in] imax Maximum Signed Integer value allowed in the compression.
        void put_float_ibits(Real r,
                             Uint16 nbits,
                             Real rmin,
                             Real rmax,
                             int32 imin,
                             int32 imax);
        /// Compressed Real Value Serializer.
        /// \wi{17999}
        /// Lossy class shall be able to serialize a computed amount of bits from a real value into the internal
        /// stream of data using the current Endianness and compressing the value with given range and decimals.
        /// \param[in] r Real value to be serialized.
        /// \param[in] minval Mimimum value allowed.
        /// \param[in] maxval Maximum value allowed.
        /// \param[in] decimals Number of desired decimals.
        void put_float(Real r,
                       Real minval,
                       Real maxval,
                       Uint8 decimals);
        /// Compressed 8-bit Unsigned Integer Serializer.
        /// \wi{18000}
        /// Lossy class shall be able to serialize a computed amount of bits from a 8-bit unsigned integer value into
        /// the internal stream of data using the current Endianness and compressing the value with given range.
        /// \param[in] val 8-bit unsigned integer value to be serialized.
        /// \param[in] minval Minimum value allowed.
        /// \param[in] maxval Maximum value allowed.
        void put_uint8(Uint8 val,
                       Uint8 minval,
                       Uint8 maxval);
        /// Compressed 16-bit Unsigned Integer Serializer.
        /// \wi{18001}
        /// Lossy class shall be able to serialize a computed amount of bits from a 16-bit unsigned integer value into
        /// the internal stream of data using the current Endianness and compressing the value with given range.
        /// \param[in] val 16-bit unsigned integer value to be serialized.
        /// \param[in] minval Minimum value allowed.
        /// \param[in] maxval Maximum value allowed.
        void put_uint16(Uint16 val,
                        Uint16 minval,
                        Uint16 maxval);
        /// Compressed 32-bit Unsigned Integer Serializer.
        /// \wi{18002}
        /// Lossy class shall be able to serialize a computed amount of bits from a 32-bit unsigned integer value into
        /// the internal stream of data using the current Endianness and compressing the value with given range.
        /// \param[in] val 32-bit unsigned integer value to be serialized.
        /// \param[in] minval Minimum value allowed.
        /// \param[in] maxval Maximum value allowed.
        void put_uint32(Uint32 val,
                        Uint32 minval,
                        Uint32 maxval);
        /// Chars Block Serilizer.
        /// \wi{6410}
        /// Lossy class shall be able serialize a block of char values as 8-bit values into the internal stream of
        /// data.
        /// \param[in] Memory block of chars to be serialized.
        void put_n_char(const Mblock<const char>& mb);
        /// 32-bit Float Array Serializer.
        /// \wi{5604}
        /// Lossy class shall be able to serialize an array of 32-bit real values into the internal stream of data
        /// using the current Endianness.
        /// \param[in] p Array of 32-bit values to be serialized.
        /// \param[in] n0 Number of elements to serialize.
        void put_n_float(const Karray<Real>& p,Uint32 n0);
        /// 32-bit Float Block Serializer.
        /// \wi{18003}
        /// Lossy class shall be able to serialize a block of 32-bit real values into the internal stream of data
        /// using the current Endianness.
        /// \param[in] p Memory Block of 32-bit values to be serialized.
        void put_n_float(const Mblock<const Real>& p);
        /// 8-bit Unsigned Integer Array Serializer.
        /// \wi{5602}
        /// Lossy class shall be able to serialize an array of 8-bit unsigned integer values into the internal stream
        /// of data.
        /// \param[in] p Array of 8-bit unsigned integer values to be serialized.
        /// \param[in] n0 Number of elements to serialize.
        void put_n_uint8(const Karray<Uint8>& p,Uint32 n0);
        /// 8-bit Unsigned Integer Block Serializer.
        /// \wi{18004}
        /// Lossy class shall be able to serialize an 8-bit unsigned integer values represented into a block into the
        /// internal stream of data.
        /// \param[in] mb 8-bit Memory Block to be serialized.
        void put_n_uint8(const U8pkmblock_k& mb);
        /// 16-bit Unsigned Integer Array Serializer.
        /// \wi{4500}
        /// Lossy class shall be able to serialize a 16-bit unsigned integer array into the internal stream of data
        /// using the current Endianness.
        /// \param[in] p 16-bit Unsigned Integer array to be serialized.
        void put_n_uint16(const Array<Uint16>& p);
        /// 16-bit Unsigned Integer Array Serializer with Given Size.
        /// \wi{18005}
        /// Lossy class shall be able to serialize a given size of a 16-bit unsigned integer array into the internal
        /// stream of data using the current Endianess.
        /// \param[in] p 16-bit Unsigned Integer array to be serialized.
        /// \param[in] n0 Number of elements to be serialized.
        void put_n_uint16(const Array<Uint16>& p,Uint32 n0);
        /// 16-bit Unsigned Integer Block Serializer.
        /// \wi{18006}
        /// Lossy class shall be able to serialize a 16-bit unsigned integer memory block into the internal stream
        /// of data using the current Endianness.
        /// \param[in] p 16-bit unsigned integer memory block to be serialized.
        void put_n_uint16(const Mblock<const Uint16>& p);
        /// Lossy Internal Buffer Copy As 16-bit Unsigned Integer Data.
        /// \wi{18007}
        /// Lossy class shall be able to copy the content of a given lossy into its internal stream of data as a
        /// 16-bit unsigned integer memory block using the current Endianness.
        /// \param[in] str Lossy where read the data.
        /// \param[in] n0 Number of 16-bit unsiged integer elements to be copied.
        void put_n_uint16(const Lossy& str, Uint32 n0);
        /// 32-bit Unsigned Integer Array Serializer.
        /// \wi{5595}
        /// Lossy class shall be able to serialize a 32-bit unsigned integer array into its internal stream of data
        /// using the current Endianness.
        /// \param[in] p 32-bit unsigned integer array to be serialized.
        /// \param[in] n0 Number of 32-bit unsigned integer elements to be serialized.
        void put_n_uint32(const Array<Uint32>& p,Uint32 n0);
        /// 64-bit Unsigned Integer Array Serializer.
        /// \wi{5598}
        /// Lossy class shall be able to serialize a 64-bit unsigned integer array into its internal stream of data
        /// using the current Endianness.
        /// \param[in] p 64-bit unsigned integer array to be serialized.
        /// \param[in] n0 Number of 64-bit unsigned integer elements to be serialized.
        void put_n_uint64(const Array<Uint64>& p,Uint32 n0);

        /// Checksum Computer and Serializer.
        /// \wi{4480}
        /// Lossy class shall be able to compute the checksum value for a portion of its internal stream of data and
        /// serialize it using a given Endianness.
        /// \param[in, out] ck Checksum to use and serialize.
        /// \param[in] bytes_back_from Bytes back to start computing (inclusive).
        /// \param[in] bytes_back_to Bytes back to end computing (exclusive).
        /// \param[in] endn Endianness used to serialize the computed checksum (independent of packet endianess).
        void put_ck(Ichecksum& ck,
                    Uint16 bytes_back_from,
                    Uint16 bytes_back_to,
                    Endianness endn);
        /// Checksum Serializer.
        /// \wi{18008}
        /// Lossy class shall be able to serialize a given checksum value following a given Endianness.
        /// \param[in] ck Checksum value to be serialized.
        /// \param[in] nbits Number of bits from checksum value to be serialized.
        /// \param[in] endn Endianness used in the serialization.
        void put_ck(Ichecksum::Tck ck, int16 nbits, Endianness endn);
        /// Checksum Deserializer and Checker.
        /// \wi{4479}
        /// Lossy class shall be able to compute and deserialize the checksum value for a portion of its internal
        /// stream of data.
        /// \param[in, out] ck Checksum to use.
        /// \param[in] bytes_back_from Bytes back to start computing (inclusive).
        /// \param[in] bytes_back_to Bytes back to end computing (exclusive).
        /// \param[in] endn Endianness used to serialize the computed checksum (independent of packet endianess).
        /// \return True if checksum matches value contained in internal stream of data.
        bool get_ck(Ichecksum& ck,
                    Uint16 bytes_back_from,
                    Uint16 bytes_back_to,
                    Endianness endn);

        /// Checksum Computer.
        /// \wi{4478}
        /// Lossy class shall be able to compute the checksum value for a portion of its internal stream of data.
        /// \param[in,out] ck Checksum to use.
        /// \param[in] bytes_back_from Bytes back to start computing (inclusive).
        /// \param[in] bytes_back_to Bytes back to end computing (exclusive).
        void compute_ck(Ichecksum& ck,
                        Uint16 bytes_back_from,
                        Uint16 bytes_back_to);
        /// Data Deserializer.
        /// \wi{4611}
        /// Lossy class shall be able to deserialize a given stream of data and copy it into its internal stream.
        /// \param[in, out] str Lossy_error which deserialize.
        void cset(Base::Lossy_error& str);
        /// Data Serializer.
        /// \wi{4610}
        /// Lossy class shall be able to serialize into a given stream of data its internal stream.
        /// \param[out] str Lossy where serialize the data.
        void cget(Base::Lossy& str)const;
        /// Number of Bits to Hold A Range Values.
        /// \wi{5128}
        /// Lossy class shall be able to retrieve the necessary number of bits to represent a value into a given range.
        /// \param[in] minval Minimum value.
        /// \param[in] maxval Maximum value.
        /// \return Necessary number of bits to represent a range.
        template<typename T>
        static Uint16 get_nbits_int(T minval,T maxval);
        /// Number of Bits to Hold A Range Values.
        /// \wi{5130}
        /// Lossy class shall be able to retrieve the necessary number of bits to represent a value into a given range.
        /// \param[in] minval Minimum value.
        /// \param[in] maxval Maximum value.
        /// \param[in] decimals Desired decimals used to represent the value.
        /// \return Necessary number of bits to represent a range.
        static Uint16 get_nbits_float(Real minval,
                                      Real maxval,
                                      Uint8 decimals);

        // Policies are defined in Tuntraits.h
        /// Generic Type Serializer.
        /// \wi{5133}
        /// Lossy class shall provide a function to serialize an object following a given policy.
        /// \param[in] a Element to be serialized.
        template <typename POLICY>
        void put_t(const typename POLICY::type& a);

        // Access methods to Array
        /// De/Serializer 16-bit Word Array Retriever.
        /// \wi{5134}
        /// Lossy class shall be able to retrieve a reference to its internal buffer.
        /// \return Reference to Lossy internal buffer.
        Array<NWord>& get_array();
        /// De/Serializer Constant 16-bit Word Array Retriever.
        /// \wi{18009}
        /// Lossy class shall be able to retrieve a constant reference to its internal buffer.
        /// \return Constant reference to Lossy internal buffer.
        const Array<NWord>& get_array() const;
        /// De/Serializer 16-bit Word Retriever.
        /// \wi{5135}
        /// Lossy class shall be able to access to a given element ID.
        /// \param[in] i Index of element being accessed.
        /// \return Reference to element in given index.
        NWord& operator[](Uint32 i);
        /// De/Serializer Constant 16-bit Word Retriever.
        /// \wi{18010}
        /// Lossy class shall be able to access to a given element ID in a constant way.
        /// \param[in] i Index of element being accessed.
        /// \return Constant reference to element in given index.
        const NWord& operator[](Uint32 i)const;
        /// De/Serializer Constant Volatile 16-bit Word Retriever.
        /// \wi{18011}
        /// Lossy class shall be able to access to a given element ID in a constant and volatile way.
        /// \param[in] i Index of element being accessed.
        /// \return Constant and volatile reference to element in given index.
        const volatile NWord& operator[](Uint32 i)const volatile;
        /// De/Serializer Copy From.
        /// \wi{5136}
        /// Lossy class shall be able to copy the buffer from a given instance into its internal buffer.
        /// \param[in] str0 Instance to be copied.
        void copy(const Lossy& str0);
        /// De/Serializer Copy From Given Pointer.
        /// \wi{18012}
        /// Lossy class shall be able to copy the data from a given pointer into its internal buffer.
        /// \param[in] v0 Pointer to first element to be copied.
        void copy(const Uint16* v0);

        /// De/Serializer First Element Access.
        /// \wi{5137}
        /// Lossy class shall be able to retrieve a pointer to the first element of its internal buffer.
        /// \return Pointer to the first element of its internal buffer.
        NWord* first();
        /// De/Serializer 16-bit Word Memory Block Retriever.
        /// \wi{5540}
        /// Lossy class shall be able to return all its internal buffer represented as a Memory Block.
        /// \return Memory Block (Mblock<NWord>) of its internal data buffer.
        Mblock<NWord> to_mblock();
        /// De/Serializer Constant 16-bit Word Memory Block Retriever.
        /// \wi{18013}
        /// Lossy class shall be able to return all its internal buffer represented as a constant Memory Block.
        /// \return Constant Memory Block (Mblock<const NWord>) of its internal data buffer.
        Mblock<const NWord> to_mblock() const;
        /// De/Serializer Used Constant Byte Packet Memory Block Retriever.
        /// \wi{6411}
        /// Lossy class shall be able to return a byte memory block with used data in bytes.
        /// \return U8pkmblock_k with Lossy used data.
        U8pkmblock_k used_mblock8() const;
        /// De/Serializer 16-bit Word Size Retriever.
        /// \wi{5138}
        /// Lossy class shall be able to retrieve all its internal buffer size.
        /// \return Buffer size.
        Uint32 size() const;
        /// De/Serializer Zeros Setter.
        /// \wi{5139}
        /// Lossy class shall be able to set all its internal data buffer to zeros.
        void zeros();
        /// De/Serializer Buffer Resize.
        /// \wi{5140}
        /// Lossy class shall be able to resize its internal buffer if it has room enough.
        /// \param[in] n0 New size.
        void resize(Uint32 n0);
        /// De/Serializer Write Availability.
        /// \wi{4491}
        /// Lossy class shall be able to check if there is room enough to write a given amount of bits.
        /// \param[in] bits Number of bits being requested to be written.
        /// \return True if there is room enough to write the given number of bits, False if not.
        bool check_wr_str(Uint32 bits);
        /// Constant Byte Packet Memory Block Deserializer.
        /// \wi{18014}
        /// Lossy class shall be able to deserialize a memory block of a given size in bytes from its internal stream
        /// of data.
        /// \param[in] sz_bytes Number of bytes being deserialized.
        /// \return 8-bit Memory Block deserialized.
        U8pkmblock_k get_mblock(Uint16 sz_bytes);

    private:
        Array<NWord> a_obj;     ///< Internal Array of Data.
        Uint32 x;               ///< Current bit position (internal de/serializer pointer).
        const Endian3* endn;    ///< Current endian being used.

        /// Bits To Contain a Given Value.
        /// \wi{4477}
        /// Lossy class shall be able to compute the number of bits needed to represent a given Unsigned Integer Value.
        /// \param[in] n0 Unsigned Integer Value being requested.
        /// \return Minimum number of bits needed to represent a given value.
        static Uint8 bits4(Uint64 n0);
        /// De/Serializer 32-bit Unsigned Integer from Float Converter.
        /// \wi{4481}
        /// Lossy class shall be able to convert a given 32-bit real value to a 32-bit unsigned integer value applying
        /// necessary exponent given by provided number of decimals.
        /// \param[in] z Real value to be converted.
        /// \param[in] decimals Number of decimals to represent given float (exponent size).
        /// \return 32-bit unsigned integer value with computed exponent.
        static Uint32 float_to_uint32(Real z, Uint8 decimals);

        Lossy(); ///< = delete
        Lossy& operator=(const Lossy& orig); ///< = delete
    };

    inline Uint32 Lossy::ceil_size()const
    {
        /// \alg
        /// - Compute ::x from bits to words with Bitutils::bits_to_words16.
        /// - IF computed size is into range [0, ::a_obj size], return the computed value, ELSE return ::a_obj size
        /// calling to Array<T>::size function.
        Uint32 n1 = Bitutils::bits_to_words16(x);
        return Assertions::runtime(n1<=a_obj.size())?n1:a_obj.size();
    }
    inline Uint32 Lossy::ceil_size_bytes()const
    {
        /// \alg
        /// - Return retrieved value by Bitutils::bits_to_bytes for ::x.
        return Bitutils::bits_to_bytes(x);
    }
    inline bool Lossy::is_aligned() const
    {
        /// \alg
        /// - IF the four least significant bits are 0 return True, ELSE return False.
        return (x&0xF) == 0;
    }
    inline void Lossy::align()
    {
        x = (((x + Ku16::u15) >> Ku16::u4) << Ku16::u4);
    }

    inline void Lossy::align_bytes()
    {
        x = (((x + Ku16::u7) >> Ku16::u3) << Ku16::u3);
    }

    inline Uint32 Lossy::get_pos()const
    {
        return x;
    }

    inline Uint32 Lossy::get_pos_bytes() const
    {
        return Bitutils::bits_to_bytes(get_pos());
    }

    inline Uint32 Lossy::get_pos16()const
    {
        /// \alg
        /// - Return Bitutils::bits_to_words16 retrieved value for ::x.
        return Bitutils::bits_to_words16(x);
    }
    inline void Lossy::set_pos(Uint32 pos)
    {
        /// \alg
        /// - Set ::x to received bit position.
        x = pos;
    }
    inline void Lossy::set_pos_bytes(Uint32 pos)
    {
        set_pos(Bitutils::bytes_to_bits(pos));
    }
    inline void Lossy::skip_bits(Uint32 n0)
    {
        /// \alg
        /// - Set ::x to \f$ ::x + nb \f$, being nb the number of bits to be skipped.
        x+=n0;
    }
    inline void Lossy::skip_bytes(Uint32 n0)
    {
        /// \alg
        /// - Call to ::skip_bits with Bitutils::bytes_to_bits retrieved value for given number of bytes.
        skip_bits(Bitutils::bytes_to_bits(n0));
    }
    inline void Lossy::skip_words(Uint32 n0)
    {
        /// \alg
        /// - Call to ::skip_bits with Bitutils::words16_to_bits retrieved value for given number of 16-bit words.
        skip_bits(Bitutils::words16_to_bits(n0));
    }
    inline Uint32 Lossy::get_unused_bits() const
    {
        /// \alg
        /// - Return ::a_obj size in bits, minus ::x.
        return Bitutils::words16_to_bits(a_obj.size()) - x;
    }
    inline Uint32 Lossy::get_unused_bytes() const
    {
        /// \alg
        /// - Return ::a_obj size in bytes, minus retrieved value by ::ceil_size_bytes.
        return Bitutils::words16_to_bytes(a_obj.size()) - ceil_size_bytes();
    }
    inline Uint32 Lossy::get_unused_words() const
    {
        /// \alg
        /// - Return ::a_obj size in words, minus retrieved value by ::ceil_size.
        return a_obj.size()-ceil_size();
    }
    inline void Lossy::reuse()
    {
        /// \alg
        /// - Set ::x to 0.
        x = 0;
    }

    template <typename E>
    inline void Lossy::get_enum8(E& en0)
    {
        //Enum size is platform dependent. We must guarantee it is at least 8bits
        Assertions::Compile_time<size_bytes_t<E>::value >= Ku16::u1>();
        Uint8 v = 0;
        get_uint8(v);
        en0 = static_cast<E>(v);
    }

    template <typename E>
    typename Enable_if<size_bytes_t<E>::value == Ku16::u1, void>::type
    inline Lossy::get_enum16(E& en0)
    {
        Uint16 v = 0;
        get_uint16(v);
        //Enum size is platform dependent. We must value fits in 8 bits.
        Assertions::runtime(v <= Ku16::u0xFF);
        en0 = static_cast<E>(v); //PRQA S 3100 #redundant cast for this instantiation
    }

    template <typename E>
    typename Enable_if<size_bytes_t<E>::value >= Ku16::u2, void>::type
    inline Lossy::get_enum16(E& en0)
    {
        //Enum size is platform dependent. We must guarantee it is at least 16bits
        Assertions::Compile_time<size_bytes_t<E>::value >= Ku16::u1>();
        Uint16 v = 0;
        get_uint16(v);
        en0 = static_cast<E>(v); //PRQA S 3100 #redundant cast for this instantiation
    }

    inline void Lossy::get_int16(int16& i16)
    {
        get_uint16(reinterpret_cast<Uint16&>(i16));
    }

    inline void Lossy::put_bool8(bool b)
    {
        put_uint8(static_cast<Uint8>(b));
    }

    inline void Lossy::put_bool16(bool b)
    {
        put_uint16(static_cast<Uint16>(b));
    }

    inline void Lossy::put_int8(int8 val)
    {
        put_uint8(reinterpret_cast<Uint8&>(val));
    }

    inline void Lossy::put_int16(int16 val)
    {
        put_uint16(reinterpret_cast<Uint16&>(val));
    }

    inline void Lossy::put_int32(int32 val)
    {
        put_uint32(reinterpret_cast<Uint32&>(val));
    }

    inline void Lossy::put_float(Real r)
    {
        put_uint32(*(reinterpret_cast<Uint32 *>(&r)));
    }

    inline void Lossy::put_float64(JSF116_Real64 r)
    {
        put_uint64(*(reinterpret_cast<Uint64 *>(const_cast<Real64 *>(&r))));
    }

    template<typename T>
    inline Uint16 Lossy::get_nbits_int(T minval,T maxval)
    {
        // note this method must hold coherence with get_uint16(Uint16&, Uint16 minval, Uint16 maxval)
        // and similar methods.
        return bits4(static_cast<Uint64>(maxval-minval));
    }

    inline Uint16 Lossy::get_nbits_float(Real minval,
                                         Real maxval,
                                         Uint8 decimals)
    {
        // note this method must hold coherence with get_float(Real& r,Real minval,Real maxval,Uint8 decimals)
        // and put_float (same parameters).
        return bits4(float_to_uint32(maxval-minval,decimals));
    }

    template <typename POLICY>
    inline void Lossy::put_t(const typename POLICY::type& a)
    {
        /// \alg
        /// - Call to elem2str function for given policy using as arguments the instance received and this Lossy
        /// instance.
        POLICY::elem2str(a,*this);
    }

    inline Array<NWord>& Lossy::get_array()
    {
        /// \alg
        /// - Return ::a_obj instance.
        return a_obj;
    }

    inline const Array<NWord>& Lossy::get_array() const
    {
        /// \alg
        /// - Return ::a_obj instance.
        return a_obj;
    }

    inline NWord& Lossy::operator[](Uint32 i)
    {
        return a_obj.operator[](i);
    }

    inline const NWord& Lossy::operator[](Uint32 i)const
    {
        return a_obj.operator[](i);
    }

    inline const volatile NWord& Lossy::operator[](Uint32 i)const volatile
    {
        return a_obj.operator[](i);
    }

    inline void Lossy::copy(const Lossy& str0)
    {
        /// \alg
        /// - Call to Array<T>::copy with ::a_obj object of given Lossy.
        a_obj.copy(str0.a_obj);
    }

    inline void Lossy::copy(const Uint16* v0)
    {
        /// \alg
        /// - Call to Array<T>::copy with given pointer.
        a_obj.copy(v0);
    }

    inline NWord* Lossy::first()
    {
        return a_obj.first();
    }

    inline Mblock<NWord> Lossy::to_mblock()
    {
        return a_obj.to_mblock();
    }

    inline Mblock<const NWord> Lossy::to_mblock() const
    {
        return a_obj.to_mblock();
    }

    inline U8pkmblock_k Lossy::used_mblock8() const
    {
        return U8pkmblock_k(a_obj.first(), ceil_size_bytes());
    }

    inline Uint32 Lossy::size() const
    {
        return a_obj.size();
    }

    inline void Lossy::zeros()
    {
        /// - Call to Array<T>::zeros for ::a_obj.
        a_obj.zeros();
    }

    inline void Lossy::resize(Uint32 n0)
    {
        /// \alg
        /// - Call to Array<T>::resize for ::a_obj with given parameter.
        a_obj.resize(n0);
    }

    inline bool Lossy::check_wr_str(Uint32 bits)
    {
        // check adding "bits" does fit in size_max() -> Max size in words.
        const bool res = (x+bits) <= (a_obj.size_max() << Ku16::u4);
        return res;
    }

    inline void Lossy::put_float16(Real r)
    {
        put_uint16(Real16(r).get_raw());
    }
}
#endif
