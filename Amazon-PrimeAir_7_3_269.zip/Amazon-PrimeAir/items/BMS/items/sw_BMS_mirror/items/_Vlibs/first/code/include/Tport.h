#ifndef TPORT_H_
#define TPORT_H_

#include <Itport.h>

namespace Base
{
    /// Port Traits. Implement Itport interface to wrap a device into this interface.
    template <typename RD,
              typename WR = RD,
              typename RDT = typename RD::type,
              typename WRT = typename WR::type>
    class Tport : public Itport<RDT,WRT>
    {
    public:
        typedef typename JSF116_param<WRT>::type JSF116_param_type; ///< Working type to write.
        typedef WRT type;                                           ///< Writer port type.

        /// Tport Constructor.
        /// \wi{5237}
        /// Tport class shall build itself upon construction with a given pair writer-reader items.
        /// \param[in] rd0 Reader.
        /// \param[in] wr0 Writer.
        Tport(RD& rd0, WR& wr0);

        /// Port Reader.
        /// \wi{5238}
        /// Tport class shall be able to read from the reader item.
        /// \param[out] element Read data.
        /// \return True if read action has been successful, False if not.
        virtual bool read(RDT& element);
        /// Port Writer.
        /// \wi{5239}
        /// Tport class shall be able to write into the writer item.
        /// \param[in] element Data to be written.
        /// \return True if write action has been successful, False if not.
        virtual bool write(JSF116_param_type element);
        /// Write Availability.
        /// \wi{5240}
        /// Tport class shall be able to identify if write action into writer item is available.
        /// \return True if write is available, False if not.
        virtual bool wr_available() const;
        /// Tport Stepper.
        /// \wi{16902}
        /// Tport class shall implement a void step function to be usable as Port_stats template parameter.
        inline void step()
        {
            /// \alg
            /// Do nothing.
        }

    private:
        RD& rd; ///< Reader item.
        WR& wr; ///< Writer item.

        Tport(); ///< = delete
        Tport(const Tport& orig); ///< = delete
        Tport& operator=(const Tport& orig); ///< = delete
    };


    template <typename RD,
              typename WR,
              typename RDT,
              typename WRT>
    inline Tport<RD,WR,RDT,WRT>::Tport(RD& rd0, WR& wr0) : rd(rd0),wr(wr0)
    {
    }

    template <typename RD,
              typename WR,
              typename RDT,
              typename WRT>
    inline bool Tport<RD,WR,RDT,WRT>::read(RDT& element)
    {
        /// \alg
        /// Call to RD::read function of Reader item (::rd) with received parameter and return its retrieved value
        return rd.read(element);
    }

    template <typename RD,
              typename WR,
              typename RDT,
              typename WRT>
    inline bool Tport<RD,WR,RDT,WRT>::write(JSF116_param_type element)
    {
        /// \alg
        /// Call to WR::write function of Writer item (::wr) with received parameter and return its retrieved value.
        return wr.write(element);
    }

    template <typename RD,
              typename WR,
              typename RDT,
              typename WRT>
    inline bool Tport<RD,WR,RDT,WRT>::wr_available() const
    {
        /// \alg
        /// Return the retrieved value by WR::wr_available of Writer item (::wr).
        return wr.wr_available();
    }
}
#endif
