#include <PLL.h>
#include <Asm.h>
#include <Cpusys.h>
#include <Devcfg.h>
#include <Hregmap.h>
#include <Ku16.h>
#include <Mutex.h>
#include <Timer.h>
#include <Watchdog.h>

namespace Dsp28335_ent
{
    namespace PLL
    {
        using namespace Ku16;

        enum Imult
        {
            imult_000 =   0,
            imult_001 =   1,
            imult_002 =   2,
            imult_003 =   3,
            imult_004 =   4,
            imult_005 =   5,
            imult_006 =   6,
            imult_007 =   7,
            imult_008 =   8,
            imult_009 =   9,
            imult_010 =  10,
            imult_011 =  11,
            imult_012 =  12,
            imult_013 =  13,
            imult_014 =  14,
            imult_015 =  15,
            imult_016 =  16,
            imult_017 =  17,
            imult_018 =  18,
            imult_019 =  19,
            imult_020 =  20,
            imult_021 =  21,
            imult_022 =  22,
            imult_023 =  23,
            imult_024 =  24,
            imult_025 =  25,
            imult_026 =  26,
            imult_027 =  27,
            imult_028 =  28,
            imult_029 =  29,
            imult_030 =  30,
            imult_031 =  31,
            imult_032 =  32,
            imult_033 =  33,
            imult_034 =  34,
            imult_035 =  35,
            imult_036 =  36,
            imult_037 =  37,
            imult_038 =  38,
            imult_039 =  39,
            imult_040 =  40,
            imult_041 =  41,
            imult_042 =  42,
            imult_043 =  43,
            imult_044 =  44,
            imult_045 =  45,
            imult_046 =  46,
            imult_047 =  47,
            imult_048 =  48,
            imult_049 =  49,
            imult_050 =  50,
            imult_051 =  51,
            imult_052 =  52,
            imult_053 =  53,
            imult_054 =  54,
            imult_055 =  55,
            imult_056 =  56,
            imult_057 =  57,
            imult_058 =  58,
            imult_059 =  59,
            imult_060 =  60,
            imult_061 =  61,
            imult_062 =  62,
            imult_063 =  63,
            imult_064 =  64,
            imult_065 =  65,
            imult_066 =  66,
            imult_067 =  67,
            imult_068 =  68,
            imult_069 =  69,
            imult_070 =  70,
            imult_071 =  71,
            imult_072 =  72,
            imult_073 =  73,
            imult_074 =  74,
            imult_075 =  75,
            imult_076 =  76,
            imult_077 =  77,
            imult_078 =  78,
            imult_079 =  79,
            imult_080 =  80,
            imult_081 =  81,
            imult_082 =  82,
            imult_083 =  83,
            imult_084 =  84,
            imult_085 =  85,
            imult_086 =  86,
            imult_087 =  87,
            imult_088 =  88,
            imult_089 =  89,
            imult_090 =  90,
            imult_091 =  91,
            imult_092 =  92,
            imult_093 =  93,
            imult_094 =  94,
            imult_095 =  95,
            imult_096 =  96,
            imult_097 =  97,
            imult_098 =  98,
            imult_099 =  99,
            imult_100 = 100,
            imult_101 = 101,
            imult_102 = 102,
            imult_103 = 103,
            imult_104 = 104,
            imult_105 = 105,
            imult_106 = 106,
            imult_107 = 107,
            imult_108 = 108,
            imult_109 = 109,
            imult_110 = 110,
            imult_111 = 111,
            imult_112 = 112,
            imult_113 = 113,
            imult_114 = 114,
            imult_115 = 115,
            imult_116 = 116,
            imult_117 = 117,
            imult_118 = 118,
            imult_119 = 119,
            imult_120 = 120,
            imult_121 = 121,
            imult_122 = 122,
            imult_123 = 123,
            imult_124 = 124,
            imult_125 = 125,
            imult_126 = 126,
            imult_127 = 127
        };


        /// The following are values that can be used by InitSysPll() & InitAuxPll() 
        /// to select SYSPLL/AUXPLL fractional multiplier
        enum Fmult
        {
            fmult_0     = 0,
            fmult_0pt25 = 1,
            fmult_0pt5  = 2,
            fmult_0pt75 = 3
        };

        /// The following are values that can be used by the
        /// InitSysPll() to select divsel for SYSPLL
        enum Pllclk
        {
            pllclk_by_01  =  0,
            pllclk_by_02  =  1,
            pllclk_by_04  =  2,
            pllclk_by_06  =  3,
            pllclk_by_08  =  4,
            pllclk_by_10  =  5,
            pllclk_by_12  =  6,
            pllclk_by_14  =  7,
            pllclk_by_16  =  8,
            pllclk_by_18  =  9,
            pllclk_by_20  = 10,
            pllclk_by_22  = 11,
            pllclk_by_24  = 12,
            pllclk_by_26  = 13,
            pllclk_by_28  = 14,
            pllclk_by_30  = 15,
            pllclk_by_32  = 16,
            pllclk_by_34  = 17,
            pllclk_by_36  = 18,
            pllclk_by_38  = 19,
            pllclk_by_40  = 20,
            pllclk_by_42  = 21,
            pllclk_by_44  = 22,
            pllclk_by_46  = 23,
            pllclk_by_48  = 24,
            pllclk_by_50  = 25,
            pllclk_by_52  = 26,
            pllclk_by_54  = 27,
            pllclk_by_56  = 28,
            pllclk_by_58  = 29,
            pllclk_by_60  = 30,
            pllclk_by_62  = 31,
            pllclk_by_64  = 32,
            pllclk_by_66  = 33,
            pllclk_by_68  = 34,
            pllclk_by_70  = 35,
            pllclk_by_72  = 36,
            pllclk_by_74  = 37,
            pllclk_by_76  = 38,
            pllclk_by_78  = 39,
            pllclk_by_80  = 40,
            pllclk_by_82  = 41,
            pllclk_by_84  = 42,
            pllclk_by_86  = 43,
            pllclk_by_88  = 44,
            pllclk_by_90  = 45,
            pllclk_by_92  = 46,
            pllclk_by_94  = 47,
            pllclk_by_96  = 48,
            pllclk_by_98  = 49,
            pllclk_by_100 = 50,
            pllclk_by_102 = 51,
            pllclk_by_104 = 52,
            pllclk_by_106 = 53,
            pllclk_by_108 = 54,
            pllclk_by_110 = 55,
            pllclk_by_112 = 56,
            pllclk_by_114 = 57,
            pllclk_by_116 = 58,
            pllclk_by_118 = 59,
            pllclk_by_120 = 60,
            pllclk_by_122 = 61,
            pllclk_by_124 = 62,
            pllclk_by_126 = 63
        };

        /// The following are values that can be used by the
        /// InitAuxPll() to select divsel for AUXPLL
        enum Auxpllrawclk
        {
            auxpllrawclk_by_1 = 0,
            auxpllrawclk_by_2 = 1,
            auxpllrawclk_by_4 = 2,
            auxpllrawclk_by_8 = 3
        };

        /// The following are values that can be used by
        /// InitSysPll() & InitAuxPll() to select clock source
        enum Clock_src
        {
            int_osc2 = 0,
            xtal_osc = 1,
            int_osc1 = 2,
            auxclkin = 4
        };


        //PRQA S 2176 ++
        //#Unions used in HW register mapping in Texas Instruments' libraries.
        //PRQA S 2301 ++
        //#Bit-fields are needed.
        //PRQA S 5050 ++
        //#Identifiers will be kept by default
        //PRQA S 5051 ++
        //#Identifiers will be kept by default

        struct CLKSEM_BITS {                    // bits description
            Uint16 SEM:2;                       // 1:0 Semaphore for CLKCFG Ownership by CPU1 or CPU2
            Uint16 rsvd1:14;                    // 15:2 Reserved
            Uint16 KEY:16;                      // 31:16 Key Qualifier for writes to this register
        };

        union CLKSEM_REG {
            Uint32  all;
            struct  CLKSEM_BITS  bit;
        };

        struct CLKCFGLOCK1_BITS {               // bits description
            Uint16 CLKSRCCTL1:1;                // 0 Lock bit for CLKSRCCTL1 register
            Uint16 CLKSRCCTL2:1;                // 1 Lock bit for CLKSRCCTL2 register
            Uint16 CLKSRCCTL3:1;                // 2 Lock bit for CLKSRCCTL3 register
            Uint16 SYSPLLCTL1:1;                // 3 Lock bit for SYSPLLCTL1 register
            Uint16 SYSPLLCTL2:1;                // 4 Lock bit for SYSPLLCTL2 register
            Uint16 SYSPLLCTL3:1;                // 5 Lock bit for SYSPLLCTL3 register
            Uint16 SYSPLLMULT:1;                // 6 Lock bit for SYSPLLMULT register
            Uint16 AUXPLLCTL1:1;                // 7 Lock bit for AUXPLLCTL1 register
            Uint16 rsvd1:1;                     // 8 Reserved
            Uint16 rsvd2:1;                     // 9 Reserved
            Uint16 AUXPLLMULT:1;                // 10 Lock bit for AUXPLLMULT register
            Uint16 SYSCLKDIVSEL:1;              // 11 Lock bit for SYSCLKDIVSEL register
            Uint16 AUXCLKDIVSEL:1;              // 12 Lock bit for AUXCLKDIVSEL register
            Uint16 PERCLKDIVSEL:1;              // 13 Lock bit for PERCLKDIVSEL register
            Uint16 rsvd3:1;                     // 14 Reserved
            Uint16 LOSPCP:1;                    // 15 Lock bit for LOSPCP register
            Uint16 rsvd4:16;                    // 31:16 Reserved
        };

        union CLKCFGLOCK1_REG {
            Uint32  all;
            struct  CLKCFGLOCK1_BITS  bit;
        };

        struct CLKSRCCTL1_BITS {                // bits description
            Uint16 OSCCLKSRCSEL:2;              // 1:0 OSCCLK Source Select Bit
            Uint16 rsvd1:1;                     // 2 Reserved
            Uint16 INTOSC2OFF:1;                // 3 Internal Oscillator 2 Off Bit
            Uint16 XTALOFF:1;                   // 4 Crystal (External) Oscillator Off Bit
            Uint16 WDHALTI:1;                   // 5 Watchdog HALT Mode Ignore Bit
            Uint16 rsvd2:10;                    // 15:6 Reserved
            Uint16 rsvd3:16;                    // 31:16 Reserved
        };

        union CLKSRCCTL1_REG {
            Uint32  all;
            struct  CLKSRCCTL1_BITS  bit;
        };

        struct CLKSRCCTL2_BITS {                // bits description
            Uint16 AUXOSCCLKSRCSEL:2;           // 1:0 AUXOSCCLK Source Select Bit
            Uint16 CANABCLKSEL:2;               // 3:2 CANA Bit Clock Source Select Bit
            Uint16 CANBBCLKSEL:2;               // 5:4 CANB Bit Clock Source Select Bit
            Uint16 rsvd1:2;                     // 7:6 Reserved
            Uint16 rsvd2:2;                     // 9:8 Reserved
            Uint16 rsvd3:6;                     // 15:10 Reserved
            Uint16 rsvd4:16;                    // 31:16 Reserved
        };

        union CLKSRCCTL2_REG {
            Uint32  all;
            struct  CLKSRCCTL2_BITS  bit;
        };

        struct CLKSRCCTL3_BITS {                // bits description
            Uint16 XCLKOUTSEL:3;                // 2:0 XCLKOUT Source Select Bit
            Uint16 rsvd1:13;                    // 15:3 Reserved
            Uint16 rsvd2:16;                    // 31:16 Reserved
        };

        union CLKSRCCTL3_REG {
            Uint32  all;
            struct  CLKSRCCTL3_BITS  bit;
        };

        struct SYSPLLCTL1_BITS {                // bits description
            Uint16 PLLEN:1;                     // 0 SYSPLL enable/disable bit
            Uint16 PLLCLKEN:1;                  // 1 SYSPLL bypassed or included in the PLLSYSCLK path
            Uint16 rsvd1:14;                    // 15:2 Reserved
            Uint16 rsvd2:16;                    // 31:16 Reserved
        };

        union SYSPLLCTL1_REG {
            Uint32  all;
            struct  SYSPLLCTL1_BITS  bit;
        };

        struct PLLMULT_BITS {                   // bits description
            Imult  IMULT:7;                     // 6:0 PLL Integer Multiplier
            Uint16 rsvd1:1;                     // 7 Reserved
            Fmult  FMULT:2;                     // 9:8 PLL Fractional Multiplier
            Uint16 rsvd2:6;                     // 15:10 Reserved
            Uint16 rsvd3:16;                    // 31:16 Reserved
        };

        union SYSPLLMULT_REG {
            Uint32  all;
            struct  PLLMULT_BITS  bit;
        };

        struct SYSPLLSTS_BITS {                 // bits description
            Uint16 LOCKS:1;                     // 0 SYSPLL Lock Status Bit
            Uint16 SLIPS:1;                     // 1 SYSPLL Slip Status Bit
            Uint16 rsvd1:14;                    // 15:2 Reserved
            Uint16 rsvd2:16;                    // 31:16 Reserved
        };

        union SYSPLLSTS_REG {
            Uint32  all;
            struct  SYSPLLSTS_BITS  bit;
        };

        struct AUXPLLCTL1_BITS {                // bits description
            Uint16 PLLEN:1;                     // 0 AUXPLL enable/disable bit
            Uint16 PLLCLKEN:1;                  // 1 AUXPLL bypassed or included in the AUXPLLCLK path
            Uint16 rsvd1:14;                    // 15:2 Reserved
            Uint16 rsvd2:16;                    // 31:16 Reserved
        };

        union AUXPLLCTL1_REG {
            Uint32  all;
            struct  AUXPLLCTL1_BITS  bit;
        };

        union AUXPLLMULT_REG {
            Uint32  all;
            struct  PLLMULT_BITS  bit;
        };

        struct AUXPLLSTS_BITS {                 // bits description
            Uint16 LOCKS:1;                     // 0 AUXPLL Lock Status Bit
            Uint16 SLIPS:1;                     // 1 AUXPLL Slip Status Bit
            Uint16 rsvd1:14;                    // 15:2 Reserved
            Uint16 rsvd2:16;                    // 31:16 Reserved
        };

        union AUXPLLSTS_REG {
            Uint32  all;
            struct  AUXPLLSTS_BITS  bit;
        };

        struct SYSCLKDIVSEL_BITS {              // bits description
            Pllclk PLLSYSCLKDIV:6;              // 5:0 PLLSYSCLK Divide Select
            Uint16 rsvd1:10;                    // 15:6 Reserved
            Uint16 rsvd2:16;                    // 31:16 Reserved
        };

        union SYSCLKDIVSEL_REG {
            Uint32  all;
            struct  SYSCLKDIVSEL_BITS  bit;
        };

        struct AUXCLKDIVSEL_BITS {              // bits description
            Auxpllrawclk AUXPLLDIV:2;                 // 1:0 AUXPLLCLK Divide Select
            Uint16 rsvd1:14;                    // 15:2 Reserved
            Uint16 rsvd2:16;                    // 31:16 Reserved
        };

        union AUXCLKDIVSEL_REG {
            Uint32  all;
            struct  AUXCLKDIVSEL_BITS  bit;
        };

        struct PERCLKDIVSEL_BITS {              // bits description
            Uint16 EPWMCLKDIV:2;                // 1:0 EPWM Clock Divide Select
            Uint16 rsvd1:2;                     // 3:2 Reserved
            Uint16 EMIF1CLKDIV:1;               // 4 EMIF1  Clock Divide Select
            Uint16 rsvd2:1;                     // 5 Reserved
            Uint16 EMIF2CLKDIV:1;               // 6 EMIF2 Clock Divide Select
            Uint16 rsvd3:9;                     // 15:7 Reserved
            Uint16 rsvd4:16;                    // 31:16 Reserved
        };

        union PERCLKDIVSEL_REG {
            Uint32  all;
            struct  PERCLKDIVSEL_BITS  bit;
        };

        struct XCLKOUTDIVSEL_BITS {             // bits description
            Uint16 XCLKOUTDIV:2;                // 1:0 XCLKOUT Divide Select
            Uint16 rsvd1:14;                    // 15:2 Reserved
            Uint16 rsvd2:16;                    // 31:16 Reserved
        };

        union XCLKOUTDIVSEL_REG {
            Uint32  all;
            struct  XCLKOUTDIVSEL_BITS  bit;
        };

        struct LOSPCP_BITS {                    // bits description
            Uint16 LSPCLKDIV:3;                 // 2:0 LSPCLK Divide Select
            Uint16 rsvd1:13;                    // 15:3 Reserved
            Uint16 rsvd2:16;                    // 31:16 Reserved
        };

        union LOSPCP_REG {
            Uint32  all;
            struct  LOSPCP_BITS  bit;
        };

        struct MCDCR_BITS {                     // bits description
            Uint16 MCLKSTS:1;                   // 0 Missing Clock Status Bit
            Uint16 MCLKCLR:1;                   // 1 Missing Clock Clear Bit
            Uint16 MCLKOFF:1;                   // 2 Missing Clock Detect Off Bit
            Uint16 OSCOFF:1;                    // 3 Oscillator Clock Off Bit
            Uint16 rsvd1:12;                    // 15:4 Reserved
            Uint16 rsvd2:16;                    // 31:16 Reserved
        };

        union MCDCR_REG {
            Uint32  all;
            struct  MCDCR_BITS  bit;
        };

        struct X1CNT_BITS {                     // bits description
            Uint16 X1CNT:10;                    // 9:0 X1 Counter
            Uint16 rsvd1:6;                     // 15:10 Reserved
            Uint16 rsvd2:16;                    // 31:16 Reserved
        };

        union X1CNT_REG {
            Uint32  all;
            struct  X1CNT_BITS  bit;
        };


        struct CLK_CFG_REGS
        {
            union   CLKSEM_REG                       CLKSEM;                       // Clock Control Semaphore Register
            union   CLKCFGLOCK1_REG                  CLKCFGLOCK1;                  // Lock bit for CLKCFG registers
            Uint16                                   rsvd1[4];                     // Reserved
            union   CLKSRCCTL1_REG                   CLKSRCCTL1;                   // Clock Source Control register-1
            union   CLKSRCCTL2_REG                   CLKSRCCTL2;                   // Clock Source Control register-2
            union   CLKSRCCTL3_REG                   CLKSRCCTL3;                   // Clock Source Control register-3
            union   SYSPLLCTL1_REG                   SYSPLLCTL1;                   // SYSPLL Control register-1
            Uint16                                   rsvd2[4];                     // Reserved
            union   SYSPLLMULT_REG                   SYSPLLMULT;                   // SYSPLL Multiplier register
            union   SYSPLLSTS_REG                    SYSPLLSTS;                    // SYSPLL Status register
            union   AUXPLLCTL1_REG                   AUXPLLCTL1;                   // AUXPLL Control register-1
            Uint16                                   rsvd3[4];                     // Reserved
            union   AUXPLLMULT_REG                   AUXPLLMULT;                   // AUXPLL Multiplier register
            union   AUXPLLSTS_REG                    AUXPLLSTS;                    // AUXPLL Status register
            union   SYSCLKDIVSEL_REG                 SYSCLKDIVSEL;                 // System Clock Divider Select register
            union   AUXCLKDIVSEL_REG                 AUXCLKDIVSEL;                 // Auxillary Clock Divider Select register
            union   PERCLKDIVSEL_REG                 PERCLKDIVSEL;                 // Peripheral Clock Divider Selet register
            union   XCLKOUTDIVSEL_REG                XCLKOUTDIVSEL;                // XCLKOUT Divider Select register
            Uint16                                   rsvd4[2];                     // Reserved
            union   LOSPCP_REG                       LOSPCP;                       // Low Speed Clock Source Prescalar
            union   MCDCR_REG                        MCDCR;                        // Missing Clock Detect Control Register
            union   X1CNT_REG                        X1CNT;                        // 10-bit Counter on X1 Clock
        };

        static const Uint32 clkcfg_a_regs_addr = 0x05D200UL;
        typedef Hregmap::Handler<CLK_CFG_REGS, clkcfg_a_regs_addr> Hclkcfg_a;

        //PRQA S 2176 --
        //#Unions used in HW register mapping in Texas Instruments' libraries.
        //PRQA S 2301 --
        //#Bit-fields are needed.
        //PRQA S 5050 --
        //#Identifiers will be kept by default
        //PRQA S 5051 --
        //#Identifiers will be kept by default

        /// SysIntOsc1Sel - This function switches to Internal Oscillator 1.
        static void SysIntOsc1Sel(void)
        {
            Hclkcfg_a clkcfg_a;
            asm_eallow();
            clkcfg_a.regs.CLKSRCCTL1.bit.OSCCLKSRCSEL = 2;     // Clk Src = INTOSC1
            clkcfg_a.regs.CLKSRCCTL1.bit.XTALOFF=1;            // Turn off XTALOSC
            asm_edis();
        }

        /// SysIntOsc2Sel - This function switches to Internal oscillator 2.
        static void SysIntOsc2Sel(void)
        {
            Hclkcfg_a clkcfg_a;
            asm_eallow();
            clkcfg_a.regs.CLKSRCCTL1.bit.INTOSC2OFF=0;         // Turn on INTOSC2
            clkcfg_a.regs.CLKSRCCTL1.bit.OSCCLKSRCSEL = 0;     // Clk Src = INTOSC2
            clkcfg_a.regs.CLKSRCCTL1.bit.XTALOFF=1;            // Turn off XTALOSC
            asm_edis();
        }

        /// SysXtalOscSel - This function switches to External CRYSTAL oscillator.
        static void SysXtalOscSel(void)
        {
            Hclkcfg_a clkcfg_a;
            asm_eallow();
            clkcfg_a.regs.CLKSRCCTL1.bit.XTALOFF=0;            // Turn on XTALOSC
            clkcfg_a.regs.CLKSRCCTL1.bit.OSCCLKSRCSEL = 1;     // Clk Src = XTAL
            asm_edis();
        }

        /// AuxIntOsc2Sel - This function switches to Internal oscillator 2.
        static void AuxIntOsc2Sel(void)
        {
            Hclkcfg_a clkcfg_a;
            asm_eallow();
            clkcfg_a.regs.CLKSRCCTL1.bit.INTOSC2OFF=0;         // Turn on INTOSC2
            clkcfg_a.regs.CLKSRCCTL2.bit.AUXOSCCLKSRCSEL = 0;  // Clk Src = INTOSC2
            asm_edis();
        }

        /// AuxXtalOscSel - This function switches to External CRYSTAL oscillator.
        static void AuxXtalOscSel(void)
        {
            Hclkcfg_a clkcfg_a;
            asm_eallow();
            clkcfg_a.regs.CLKSRCCTL1.bit.XTALOFF=0;            // Turn on XTALOSC
            clkcfg_a.regs.CLKSRCCTL2.bit.AUXOSCCLKSRCSEL = 1;  // Clk Src = XTAL
            asm_edis();
        }

        /// AuxAUXCLKOscSel - This function switches to AUXCLKIN (from a GPIO).
        static void AuxAuxClkSel(void)
        {
            Hclkcfg_a clkcfg_a;
            asm_eallow();
            clkcfg_a.regs.CLKSRCCTL2.bit.AUXOSCCLKSRCSEL = 2; // Clk Src = XTAL
            asm_edis();
        }


        //
        // InitSysPll - This function initializes the PLL registers.
        //
        // Note: The internal oscillator CANNOT be used as the PLL source if the
        // PLLSYSCLK is configured to frequencies above 194 MHz.
        //
        // Note: This function uses the Watchdog as a monitor for the PLL. The user
        // watchdog settings will be modified and restored upon completion.
        //
        void pll_sys_init(Clock_src clock_source,
                          Imult imult,
                          Fmult fmult,
                          Pllclk divsel)
        {
            Hclkcfg_a clkcfg_a;
            if((clock_source == clkcfg_a.regs.CLKSRCCTL1.bit.OSCCLKSRCSEL)    &&
               (imult        == clkcfg_a.regs.SYSPLLMULT.bit.IMULT)           &&
               (fmult        == clkcfg_a.regs.SYSPLLMULT.bit.FMULT)           &&
               (divsel       == clkcfg_a.regs.SYSCLKDIVSEL.bit.PLLSYSCLKDIV))
            {
                // Everything is set as required, so just return
                return;
            }

            if(clock_source != clkcfg_a.regs.CLKSRCCTL1.bit.OSCCLKSRCSEL)
            {
                switch (clock_source)
                {
                    case int_osc1:
                    {
                        SysIntOsc1Sel();
                        break;
                    }
                    case int_osc2:
                    {
                        SysIntOsc2Sel();
                        break;
                    }
                    case xtal_osc:
                    {
                        SysXtalOscSel();
                        break;
                    }
                    default:
                    {
                        break;
                    }
                }
            }

            Devcfg dc;
            asm_eallow();
            if(imult != clkcfg_a.regs.SYSPLLMULT.bit.IMULT ||
               fmult != clkcfg_a.regs.SYSPLLMULT.bit.FMULT)
            {
                Uint16 i;

                // This bit is reset only by POR

                //If watchdog is enabled, check here the SYSDBGCTL.bit.BIT_0 is == 1
                // and handle the PLL failure
                //
                // The user can optionally insert handler code here. This will only
                // be executed if a watchdog reset occurred after a failed system
                // PLL initialization. See your device user's guide for more
                // information.
                //
                // If the application has a watchdog reset handler, this bit should
                // be checked to determine if the watchdog reset occurred because
                // of the PLL.
                //
                // No action here will continue with retrying the PLL as normal.

                // Bypass PLL and set dividers to /1
                clkcfg_a.regs.SYSPLLCTL1.bit.PLLCLKEN = 0;
                asm_20NOP();
                clkcfg_a.regs.SYSCLKDIVSEL.bit.PLLSYSCLKDIV = pllclk_by_01;

                // Lock the PLL five times. This helps ensure a successful start.
                // Five is the minimum recommended number. The user can increase this
                // number according to allotted system initialization time.
                for(i = 0; i < 5; i++)
                {
                    // Turn off PLL
                    clkcfg_a.regs.SYSPLLCTL1.bit.PLLEN = 0;
                    asm_20NOP();

                    // Write multiplier, which automatically turns on the PLL
                    clkcfg_a.regs.SYSPLLMULT.all = ((static_cast<Uint32>(fmult) << 8U) | static_cast<Uint32>(imult));

                    // Wait for the SYSPLL lock counter
                    while(clkcfg_a.regs.SYSPLLSTS.bit.LOCKS != 1)
                    {
                        // Uncomment to service the watchdog
                        // ServiceDog();
                    }
                }
            }

            // Set divider to produce slower output frequency to limit current increase
            if(divsel != pllclk_by_126)
            {
                 clkcfg_a.regs.SYSCLKDIVSEL.bit.PLLSYSCLKDIV = static_cast<Pllclk>(divsel + 1);
            }
            else
            {
                 clkcfg_a.regs.SYSCLKDIVSEL.bit.PLLSYSCLKDIV = divsel;
            }

            //      *CAUTION*
            // It is recommended to use the following watchdog code to monitor the PLL
            // startup sequence. If your application has already cleared the watchdog
            // SCRS[WDOVERRIDE] bit this cannot be done. It is recommended not to clear
            // this bit until after the PLL has been initiated.

            Watchdog::Backup wd_bkp = Watchdog::backup();

            // Disable windowed functionality, reset counter
            Watchdog::disable_windowed();
            Watchdog::notify();

            // Disable global interrupts
            asm_eallow();
            Uint16 intStatus = __disable_interrupts();
            asm_edis();

            // Configure for watchdog reset and to run at max frequency
            Watchdog::setup_enabled(Watchdog::pres01);

            // This bit is reset only by power-on-reset (POR) and will not be cleared
            // by a WD reset
            dc.set_sysdbgctl(true);

            // Enable PLLSYSCLK is fed from system PLL clock
            asm_eallow();
            clkcfg_a.regs.SYSPLLCTL1.bit.PLLCLKEN = 1;

            // Delay to ensure system is clocking from PLL prior to clearing status bit
            asm_20NOP();

            // Clear bit
            dc.set_sysdbgctl(false);
            asm_edis();

            // Restore user watchdog, first resetting counter
            Watchdog::notify();
            Watchdog::restore(wd_bkp);

            // Restore state of ST1[INTM]. This was set by the __disable_interrupts()
            // intrinsic previously.
            asm_eallow();
            if(!(intStatus & 0x1))
            {
                asm_eint();
            }

            // Restore state of ST1[DBGM]. This was set by the __disable_interrupts()
            // intrinsic previously.
            if(!(intStatus & 0x2))
            {
                asm_DBGM();
            }

            // 200 PLLSYSCLK delay to allow voltage regulator to stabilize prior
            // to increasing entire system clock frequency.
            asm_200NOP();

            // Set the divider to user value
            clkcfg_a.regs.SYSCLKDIVSEL.bit.PLLSYSCLKDIV = divsel;
            asm_edis();
        }

        void pll_aux_init(Clock_src clock_source,
                          Imult imult,
                          Fmult fmult,
                          Auxpllrawclk divsel)
        {
            // Initialize the AUXPLL registers.
            //
            // Note: For this function to properly detect PLL startup,
            // SYSCLK >= 2*AUXPLLCLK after the AUXPLL is selected as the clocking source.
            //
            // Timer parameter is used to monitor a successful lock of the AUXPLL.

            Hclkcfg_a clkcfg_a;
            if(!((clock_source == clkcfg_a.regs.CLKSRCCTL2.bit.AUXOSCCLKSRCSEL) &&
               (imult        == clkcfg_a.regs.AUXPLLMULT.bit.IMULT)           &&
               (fmult        == clkcfg_a.regs.AUXPLLMULT.bit.FMULT)           &&
               (divsel       == clkcfg_a.regs.AUXCLKDIVSEL.bit.AUXPLLDIV)))
            {
                Base::Mutex m(true);
                Uint16 counter = 0;
                Uint16 started = 0;
                switch (clock_source)
                {
                    case int_osc2:
                    {
                        AuxIntOsc2Sel();
                        break;
                    }
                    case xtal_osc:
                    {
                        AuxXtalOscSel();
                        break;
                    }
                    case auxclkin:
                    {
                        AuxAuxClkSel();
                        break;
                    }
                    default:
                    {
                        break;
                    }
                }

                // Backup Timer 2 settings
                Cpusys cs;
                Uint16 t2_src = cs.get_tmr2clkctl_srcsel();
                Uint16 t2_prescale = cs.get_tmr2clkctl_prescale();

                // Configure Timer 2 for AUXPLL as source in known configuration
                cs.set_tmr2clkctl(u0x6, u0x0);  // Divide by 1
                const Real fifty_ns = 50E-9F;
                Timer t(Timer::timer2, fifty_ns, false); // 50ns, 20MHz -  Small PRD value to detect overflow

                // Set AUX Divide by 8 to ensure that AUXPLLCLK <= SYSCLK/2 while using
                // Timer 2
                static const Auxpllrawclk aux_pll_div = auxpllrawclk_by_8;
                static const Uint16 max_tries = 5;
                asm_eallow();
                clkcfg_a.regs.AUXCLKDIVSEL.bit.AUXPLLDIV = aux_pll_div;
                asm_edis();

                while((counter < max_tries) && (started == 0))
                {
                    asm_eallow();
                    clkcfg_a.regs.AUXPLLCTL1.bit.PLLEN = 0;    // Turn off AUXPLL
                    asm_20NOP();                               // Small delay for power down

                    // Set integer and fractional multiplier, which automatically turns on the PLL
                    clkcfg_a.regs.AUXPLLMULT.all = ((static_cast<Uint32>(fmult) << 8U) | static_cast<Uint32>(imult));

                    // Enable AUXPLL
                    clkcfg_a.regs.AUXPLLCTL1.bit.PLLEN = 1;
                    asm_edis();

                    // Wait for the AUXPLL lock counter
                    while(clkcfg_a.regs.AUXPLLSTS.bit.LOCKS != 1)
                    {
                        // Uncomment to service the watchdog
                        // ServiceDog()
                    }

                    // Enable AUXPLLCLK to be fed from AUX PLL
                    asm_eallow();
                    clkcfg_a.regs.AUXPLLCTL1.bit.PLLCLKEN = 1;
                    asm_20NOP();

                    // CPU Timer 2 will now be setup to be clocked from AUXPLLCLK. This is
                    // used to test that the PLL has successfully started.
                    t.reload();
                    t.set_running(true);

                    // Check to see timer is counting properly
                    static const Uint16 max_iters = 1000;
                    bool done = false;
                    for(Uint16 i = 0; (i < max_iters)&&(done==false); i++)
                    {
                        // Check overflow flag
                        if(t.is_ovf())
                        {
                            // Clear overflow flag
                            t.clear_ovf();

                            // Set flag to indicate PLL started and break out of for-loop
                            started = 1;
                            done = true;
                        }
                    }

                    // Stop timer
                    t.set_running(false);
                    counter++;
                    asm_edis();
                }

                if(started == 0)
                {
                    // AUX PLL may not have started. Reset multiplier to 0 (bypass PLL).
                    asm_eallow();
                    clkcfg_a.regs.AUXPLLMULT.all = 0;
                    asm_edis();

                    // The user should put some handler code here based on how this
                    // condition should be handled in their application.
                    Dsp28335_ent::asm_stop();
                }

                // Set divider to desired value
                asm_eallow();
                clkcfg_a.regs.AUXCLKDIVSEL.bit.AUXPLLDIV = divsel;
                asm_edis();

                // Restore Timer 2 configuration
                cs.set_tmr2clkctl(t2_src, t2_prescale);  // Divide by 1

                // Reload period value
                t.reload();
            }
            //else - > Everything is set as required
        }

        // ---

        void pll_sys_init()
        {
            pll_sys_init(xtal_osc, imult_020, fmult_0, pllclk_by_02);
        }

        void pll_aux_init()
        {
            //Set USB clk to 60Mhz (required by USB peripheral)
            pll_aux_init(xtal_osc, imult_012, fmult_0, auxpllrawclk_by_4);
        }
    }
}
