#ifndef SYSADDR_H_
#define SYSADDR_H_

#include <Address.h>

namespace Bsp
{
    /// Dynamic system address reference.
    /// \wi{13638}
    /// System shall provide a method to retrieve a reference to its dynamic system address.
    /// \rationale Only for multi-core platforms. Shall be implemented but only for the core which has write access to it.
    /// \return Reference to the dynamic system address.
    extern volatile Base::Address0& get_addr_location();

    /// Dynamic VSM Address Reference.
    /// \wi{16165}
    /// A function to retrieve a modifiable VSM address should be implemented in C1.
    /// \return A modifiable reference to the VSM address.
    extern volatile Base::Address0& get_vsmaddr();
    /// Constant VSM Address Reference.
    /// \wi{16166}
    /// A function to retrieve a constant VSM address should be implemented in both cores.
    /// \return A constant reference to the VSM address.
    extern const volatile Base::Address0& get_kvsmaddr();
    /// Constant VSM Address Reference.
    /// \wi{16167}
    /// A function to retreive a constant VSM address should be implemented in both cores.
    /// \return A constant reference to the VSM address.
    extern volatile const Base::Address0& vsmaddr();

    /// Dynamic system address constant reference.
    /// \wi{13639}
    /// System shall provide a method to retrieve a constant reference to its dynamic system address.
    /// \rationale Only for multi-core platforms. Shall be implemented on all core as read-only.
    /// \return Constant reference to dynamic system address.
    extern volatile const Base::Address0& get_addr_location_k();

    /// Dynamic system address value.
    /// \wi{7689}
    /// System shall provide the capability to retrieve its system address.
    /// \return Dynamic internal address.
    extern volatile const Base::Address0& sysaddr();

    /// Modify dynamic system address.
    /// \wi{8015}
    /// System shall provide the capability to modify its system address.
    /// \rationale Shall always be explicitly called to fix dynamic address for the first time.
    /// \param[in] addr0        System address value to be copied.
    extern void set_sysaddr(Base::Address addr0);
}

#endif
