#ifndef ISTEP_H__
#define ISTEP_H__

namespace Base
{
    /// Interface for real time tasks
    class Istep
    {
    public:
        virtual void step() = 0;

    protected:
        Istep();
        ~Istep();
    
    private:
        Istep(const Istep& orig); ///< = delete
        Istep& operator=(const Istep& orig); ///< = delete
    };

    inline Istep::Istep()
    {
    }

    inline Istep::~Istep() //PRQA S 2635 #destructor replaced with default
    {
    }

}

#endif

