#include <Reset.h>
#include <Asm.h>
#include <Cpusys.h>
#include <Hregister.h>
#include <Ipc.h>
#include <Mutex.h>
#include <System.h>

namespace Dsp28335_ent
{
   //IMPORTANT: There is a bug that makes the reset not work if JTAG is plugged. Seems to be related with EMU-BOOTCTRL
    void Reset::reset0()
    {
        Base::Mutex m(true);

        //We have detected that if we reboot directly the external RAM can be in non high impedance state,
        //that could lead to an incorrect boot sequence because D12 is tied to gpio072 which is used to select
        //the actual boot mode.
        //So we halt the CPU2 before perform the reset to avoid external RAM being accessed.
        Ipc::get_instance().send_reset_request_1to2_blocking();

        Cpusys cs;
        if(cs.is_jtag_connected()) // JTAG connected?
        {
            // Make reset boot from flash with JTAG connected, as explained in TI forum and
            // device datasheet (see CPU boot flow and boot modes).

            // this register is not provided by TI libraries
            static const Uint32 reg_emuboot_addr = 0xD00;
            static Base::Hregister<Uint16, Base::Mutator_rw, reg_emuboot_addr, 0, 16> reg_emuboot;

            asm_eallow();
            reg_emuboot.write(0xB5A); // Accessing a register that is not this is very obscure
            asm_edis();
        }

        while(true)
        {
            System::cpu_reset(); // never returns
        }
    }

    void Reset::reset() const
    {
        reset0();
    }
}
