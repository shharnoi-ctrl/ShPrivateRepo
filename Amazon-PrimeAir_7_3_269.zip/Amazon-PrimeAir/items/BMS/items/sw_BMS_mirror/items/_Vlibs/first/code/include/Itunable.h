#ifndef ITUNABLE_H_
#define ITUNABLE_H_

#include <Lossy_fw.h>
#include <Ideserializable.h>

namespace Base
{
    /// Synchronous interface for de/serializable objects
    class Itunable : public Ideserializable
    {
    public:
        /// description: This function is used to serialize the data from the data members of the class into the
        /// input parameter str.
        /// param str: Array of data, with the encoding format (big, little, mixed endian)
        virtual void cget(Lossy& str) const = 0;
    protected:
        ~Itunable(); ///< Base virtual destructor
    };

    inline Itunable::~Itunable() //PRQA S 2635 #destructor replaced with default
    {
    }
}
#endif
