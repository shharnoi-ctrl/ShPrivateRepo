#ifndef RANGEVARS_H_
#define RANGEVARS_H_

#include <Range.h>
#include <Irangevars.h>
#include <Tnarray.h>
#include <Assertions.h>

namespace Base
{
    /// Range of variables abstracion
    /// T shall be a Range (or simmilar class) having method get_idx() and value 'idx_not_found' defined.
    template<typename T, typename VART>
    class Rangevars : public Irangevars<typename T::type, VART>
    {
    public:
        typedef T type;         ///< Range type
        typedef VART vartype;   ///< Variables type

        Rangevars(); ///< Constructor
        
        virtual VART* get(typename T::type v);  ///< Retrieve the element associated with 'v' id
        
        virtual void zeros(); ///< Set all values to Zero

    private:
        Base::Tnarray<VART, T::size> values;    ///< Values for the range

        Rangevars(const Rangevars&); ///< = delete
        Rangevars operator=(const Rangevars&); ///< = delete
    };
    
    template<typename T, typename VART>
    inline Base::Rangevars<T, VART>::Rangevars()
    {
    }

    template<typename T, typename VART>
    VART* Rangevars<T, VART>::get(typename T::type v)
    {
        VART* res = 0;
        int32 idx = T::get_idx(v);
        if( idx != T::idx_not_found)
        {
            if(Assertions::runtime((idx >=0) && (idx < T::size)) )
            {
                res = &values[idx];
            }
        }
        return res;
    }

    template<typename T, typename VART>
    inline void Rangevars<T, VART>::zeros()
    {
        values.zeros();
    }
}
#endif
