#ifndef IVECTOR_H__
#define IVECTOR_H__

#include <Tmem.h>
#include <Mblock.h>

namespace Maverick
{

    template <typename T>
    class Ivector
    {
    public:
        explicit Ivector(T* v0);

        void init(T* v0);
        T& operator[](Uint16 i);
        const T& operator[](Uint16 i)const;

        template <Uint32 n>
        void zeros0();

        template <Uint32 n>
        void copy0(const T* v0);

        template <Uint32 n>
        void copy0(const Ivector& v0);

    protected:
        T* v;

    private:
        Ivector(); ///< = delete
        Ivector(const Ivector& src); ///< = delete
        Ivector& operator=(const Ivector& src); ///< = delete
    };

    template <typename T>
    inline Ivector<T>::Ivector(T* v0) : v(v0)
    {
    }

    template <typename T>
    inline void Ivector<T>::init(T* v0)
    {
        v=v0;
    }

    template <typename T>
    inline T& Ivector<T>::operator[](Uint16 i) //PRQA S 4211 #const
    {
        return v[i];
    }

    template <typename T>
    inline const T& Ivector<T>::operator[](Uint16 i)const
    {
        return v[i];
    }

    template <typename T>
    template <Uint32 n>
    inline void Ivector<T>::zeros0()
    {
        Base::Tmem::set<n*sizeof(T)>(v,0);
    }

    template <typename T>
    template <Uint32 n>
    inline void Ivector<T>::copy0(const T* v0)
    {
        Base::Tmem::cpy<n*sizeof(T)>(v,v0);
    }

    template <typename T>
    template <Uint32 n>
    inline void Ivector<T>::copy0(const Ivector<T>& v0)
    {
        copy0<n>(v0.v);
    }

}
#endif
