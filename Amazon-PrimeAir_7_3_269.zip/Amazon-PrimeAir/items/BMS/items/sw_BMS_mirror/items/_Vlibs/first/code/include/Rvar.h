#ifndef RVAR_H__
#define RVAR_H__

#include <Range.h>

namespace Base
{
    enum Rvar
    {
        v_ias    =   0, ///< Indicated Airspeed
        v_tas    =   1, ///< True Airspeed
        v_gs     =   2,
        v_hdg    =   3,
        v_fpa    =   4,
        v_bnk    =   5,
        v_yaw    =   6,
        v_pch    =   7,
        v_rll    =   8,
        v_sr     =   9, ///< (9) Route-guidance distance, tangential component
        v_height =  10, ///< (10) Route-guidance distance, horizontal component
        v_v      =  11, ///< (11) Route-guidance distance, perpendicular component
        v_p      =  12, ///< (12) p (x component angular velocity -body frame-)
        v_q      =  13, ///< (13) q (y component angular velocity -body frame-)
        v_r      =  14, ///< (14) r (z component angular velocity -body frame-)
        v_ax     =  15, ///< (15) Body X acceleration
        v_ay     =  16, ///< (16) Body Y acceleration
        v_az     =  17, ///< (17) Body Z acceleration
        v_rpm    =  18, ///< (18) RPM
        v_gslon  =  19, ///< (19) Longitudinal horizontal velocity.
        v_gslat  =  20, ///< (20) Lateral horizontal velocity.
        v_speed  =  21, ///< (21) Speed (module)
        v_nx           =  22, ///< (22) Load factor (body frame) x
        v_ny           =  23, ///< (23) Load factor (body frame) y
        v_nz           =  24, ///< (24) Load factor (body frame) z
        v_at           =  25, ///< (25) Tangential acceleration
        v_rho          =  26, ///< (26) Estimated air density at current altitude (kg/m3)

        v_coyaw        =  28, ///< (28) co-yaw
        v_copch        =  29, ///< (29) co-pitch
        v_corll        =  30, ///< (30) co-roll
        v_dp      =  31, ///< (31) Yaw acceleration
        v_dq      =  32, ///< (32) Pitch acceleration
        v_dr      =  33, ///< (33) Roll acceleration

        v_qbns    = 34,  ///< (34) First component of body to NED orientation quaternion
        v_qbni    = 35,  ///< (35) Second component of body to NED orientation quaternion
        v_qbnj    = 36,  ///< (36) Third component of body to NED orientation quaternion
        v_qbnk    = 37,  ///< (37) Fourth component of body to NED orientation quaternion

        v_rssi   =  40, ///< (40) RSSI from radio

        v_scia_rx_rate      =  42,  ///< (42) SCI-A Rx rate (4G / EXT UART in hwv >= 4.7)
        v_scia_tx_rate      =  43,  ///< (43) SCI-A Tx rate (4G / EXT UART in hwv >= 4.7)
        v_scib_rx_rate      =  44,  ///< (44) SCI-B Rx rate (LOS)
        v_scib_tx_rate      =  45,  ///< (45) SCI-B Tx rate (LOS)
        v_scic_rx_rate      =  46,  ///< (46) SCI-C Rx rate (RS485)
        v_scic_tx_rate      =  47,  ///< (47) SCI-C Tx rate (RS485)
        v_scid_rx_rate      =  48,  ///< (48) SCI-D Rx rate (RS232)
        v_scid_tx_rate      =  49,  ///< (49) SCI-D Tx rate (RS232)
        v_cana_tx_rate      =  50,  ///< (50) CAN-A Tx rate
        v_canb_tx_rate      =  51,  ///< (51) CAN-B Tx rate
        v_cana_tx_skip_rate =  52,  ///< (52) CAN-A Tx skip rate
        v_canb_tx_skip_rate =  53,  ///< (53) CAN-B Tx skip rate

        v_canfd_a_tx_rate   =  54,  ///< (54) CAN-FD-A Tx rate
        v_canfd_a_tx_skip_rate=55,  ///< (55) CAN-FD-A Tx skip rate

        v_yawrt = 56,   ///< (56)yaw rate
        v_pchrt = 57,   ///< (57)pitch rate
        v_rllrt = 58,   ///< (58)roll rate

        v_com0_parse_error  =  59,  ///< (59) COM0 parse error rate
        v_com1_parse_error  =  60,  ///< (60) COM1 parse error rate
        v_com2_parse_error  =  61,  ///< (61) COM2 parse error rate
        v_com3_parse_error  =  62,  ///< (62) COM3 parse error rate
        v_com4_parse_error  =  63,  ///< (63) COM4 parse error rate
        v_com5_parse_error  =  64,  ///< (64) COM5 parse error rate
        v_gnss_tow_ms_u32   =  65,  ///< (65) GNSS time of week in milliseconds as Uint32
        v_gnss_hours        =  66,  ///< (66) GNSS Hours of the current day
        v_gnss_minutes      =  67,  ///< (67) GNSS Minutes of the current hour
        v_gnss_seconds      =  68,  ///< (68) GNSS Seconds of the current minute

        v_gyr_bias_x        =  80,  ///< (80) Estimated gyroscope bias in x direction
        v_gyr_bias_y        =  81,  ///< (81) Estimated gyroscope bias in y direction
        v_gyr_bias_z        =  82,  ///< (82) Estimated gyroscope bias in z direction
        v_acc_bias_x        =  83,  ///< (83) Estimated accelerometer bias in x direction
        v_acc_bias_y        =  84,  ///< (84) Estimated accelerometer bias in y direction
        v_acc_bias_z        =  85,  ///< (85) Estimated accelerometer bias in z direction

        v_spie0_rx_rate      =  90, ///< (90) SPI expander port0 rx rate (SCI-E, hwv >= 4.7)
        v_spie0_tx_rate      =  91, ///< (91) SPI expander port0 tx rate (SCI-E, hwv >= 4.7)
        v_spie1_rx_rate      =  92, ///< (92) SPI expander port1 rx rate (SCI-F, hwv >= 4.7)
        v_spie1_tx_rate      =  93, ///< (93) SPI expander port1 tx rate (SCI-F, hwv >= 4.7)

        v_iasc   = 100,
        v_tasc   = 101,
        v_gsc    = 102,
        v_hdgc   = 103,
        v_fpac   = 104,
        v_bnkc   = 105,
        v_yawc   = 106,
        v_pchc   = 107,
        v_rllc   = 108,

        v_pc     = 112, ///< (112) Desired p (x component angular velocity -body frame-)
        v_qc     = 113, ///< (113) Desired q (y component angular velocity -body frame-)
        v_rc     = 114, ///< (114) Desired r (z component angular velocity -body frame-)
        v_axc    = 115, ///< (115) Body X guidance acceleration
        v_ayc    = 116, ///< (116) Body Y guidance acceleration
        v_azc    = 117, ///< (117) Body Z guidance acceleration
        v_rpmc   = 118, ///< (118) Desired RPM
        v_gslonc = 119, ///< (119) Desired longitudinal horizontal velocity.
        v_gslatc = 120, ///< (120) Desired lateral horizontal velocity.
        v_speedc = 121, ///< (121) Desired speed
        v_nxc          = 122, ///< (122) Guidance load factor (body frame) x
        v_nyc          = 123, ///< (123) Guidance load factor (body frame) y
        v_nzc          = 124, ///< (124) Guidance load factor (body frame) z
        v_atc          = 125, ///< (125) Desired tangential acceleration
        v_energyrateer = 126, ///< (126) Energy rate error
        v_energydister = 127, ///< (127) Energy distribution error
        v_coyawc       = 128, ///< (128) Desired co-yaw
        v_copchc       = 129, ///< (129) Desired co-pitch
        v_corllc       = 130, ///< (130) Desired co-roll

        
        mazd           = 134, ///< (134) Aerodynamic Desired Heading
        maz            = 135, ///< (135) Aerodynamic Heading
        dmaz           = 136, ///< (136) Aerodynamic Heading Error
        mfpad          = 137, ///< (137) Aerodynamic Desired Flight Path Angle
        mfpa           = 138, ///< (138) Aerodynamic Flight Path Angle
        dmfpa          = 139, ///< (139) Aerodynamic Flight Path Angle Error

        v_dclimb       = 140, ///< (140) Climb direction (start)
        v_ddescend     = 141, ///< (141) Descend direction
        v_dheadwind    = 142, ///< (142) Headwind direction
        v_dtailwind    = 143, ///< (143) Tailwind direction
        v_drunway      = 144, ///< (144) Runway direction
        v_dtrack_el    = 145, ///< (145) Elevation of tangent to current route at its closest point to desired position
        v_dtrack_az    = 146, ///< (146) Azimuth of tangent to current route at its closest point to desired position

        v_closest_obst_dist = 147, ///< (147) Signed distance to closest obstacle (negative means inside)
        v_obst_effect_dist  = 148, ///< (148) Distance at which the obstacles have an effect in the guidance

        v_vnorthc= 200, ///< (200) Desired north velocity
        v_veastc = 201, ///< (201) Desired east velocity
        v_vdownc = 202, ///< (202) Desired down velocity
        v_msl2dc   = 203, ///< (203) Desired over mean sea level 2D altitude.
        v_agl2dc   = 204, ///< (204) Desired above ground level 2D height.
        v_llh22dc  = 205, ///< (205) Desired 2D height WGS84.
        v_llh0c    = 206, ///< (206) Desired longitude.
        v_llh1c    = 207, ///< (207) Desired latitude.
        v_llh2c  = 208, ///< (208) Desired height WGS84
        v_mslc   = 209, ///< (209) Desired over mean sea level altitude.
        v_aglc   = 210, ///< (210) Desired above ground level height.

        v_gne    = 250, ///< (250) Guidance north position error
        v_gee    = 251, ///< (251) Guidance east position error
        v_gde    = 252, ///< (252) Guidance down position error

        v_pidnvc = 253, ///< (253) Guidance PID desired north velocity
        v_pidevc = 254, ///< (254) Guidance PID desired east velocity
        v_piddvc = 255, ///< (255) Guidance PID desired down velocity

        v_uvwc0  = 256, ///< (256) Desired longitudinal (body frame) velocity
        v_uvwc1  = 257, ///< (257) Desired lateral (body frame) velocity
        v_uvwc2  = 258, ///< (258) Desired vertical (body frame) velocity

        v_extypr0 = 259, ///< (259) External yaw
        v_extypr1 = 260, ///< (260) External pitch
        v_extypr2 = 261, ///< (261) External roll
        v_extpqr0 = 262, ///< (262) External roll rate
        v_extpqr1 = 263, ///< (263) External pitch rate
        v_extpqr2 = 264, ///< (264) External yaw rate
        v_extvn0  = 265, ///< (265) External velocity north
        v_extvn1  = 266, ///< (266) External velocity east
        v_extvn2  = 267, ///< (267) External velocity down
        v_extab0  = 268, ///< (268) External acceleration x body axis
        v_extab1  = 269, ///< (269) External acceleration y body axis
        v_extab2  = 270, ///< (270) External acceleration z body axis
        v_extgpstow  = 271, ///< (271) External GPS Time of Week


        v_tk     = 300, ///< (300) Time Since Hardware Start-Up
        v_sdused = 301, ///< (301) SD used size in bytes
        v_sdfree = 302, ///< (302) SD free size in bytes
        v_pdiff  = 303, ///< (303) Dynamic pressure
        v_pabs   = 304, ///< (304) Static pressure
        v_tboard = 305, ///< (305) Board temperature
        v_text   = 306, ///< (306) External temperature
        v_fbx0   = 307, ///< (307) Accelerometer body x
        v_fby0   = 308, ///< (308) Accelerometer body y
        v_fbz0   = 309, ///< (309) Accelerometer body z
        v_wbx0   = 310, ///< (310) Gyroscope body x
        v_wby0   = 311, ///< (311) Gyroscope body y
        v_wbz0   = 312, ///< (312) Gyroscope body z
        v_bbx    = 313, ///< (313) Magnetometer body x
        v_bby    = 314, ///< (314) Magnetometer body y
        v_bbz    = 315, ///< (315) Magnetometer body z

        v_mag0_raw0     = 322,  ///< (322) Magnetometer 0 raw measure X converted to SI
        v_mag0_raw1     = 323,  ///< (323) Magnetometer 0 raw measure Y converted to SI
        v_mag0_raw2     = 324,  ///< (324) Magnetometer 0 raw measure Z converted to SI
        v_mag0_temp     = 325,  ///< (325) Magnetometer 0 temperature
        v_mag1_raw0     = 326,  ///< (326) Magnetometer 2 raw measure X converted to SI
        v_mag1_raw1     = 327,  ///< (327) Magnetometer 2 raw measure Y converted to SI
        v_mag1_raw2     = 328,  ///< (328) Magnetometer 2 raw measure Z converted to SI
        v_mag1_temp     = 329,  ///< (329) Magnetometer 2 temperature
        v_imu0_raw_acc0 = 330,  ///< (330) IMU 0 raw accelerometer x measurement
        v_imu0_raw_acc1 = 331,  ///< (331) IMU 0 raw accelerometer y measurement
        v_imu0_raw_acc2 = 332,  ///< (332) IMU 0 raw accelerometer z measurement
        v_imu0_raw_gyr0 = 333,  ///< (333) IMU 0 raw gyroscope x measurement
        v_imu0_raw_gyr1 = 334,  ///< (334) IMU 0 raw gyroscope y measurement
        v_imu0_raw_gyr2 = 335,  ///< (335) IMU 0 raw gyroscope z measurement
        v_imu0_temp     = 336,  ///< (336) IMU 0 temperature measurement
        v_imu1_raw_acc0 = 337,  ///< (337) IMU 1 raw accelerometer x measurement
        v_imu1_raw_acc1 = 338,  ///< (338) IMU 1 raw accelerometer y measurement
        v_imu1_raw_acc2 = 339,  ///< (339) IMU 1 raw accelerometer z measurement
        v_imu1_raw_gyr0 = 340,  ///< (340) IMU 1 raw gyroscope x measurement
        v_imu1_raw_gyr1 = 341,  ///< (341) IMU 1 raw gyroscope y measurement
        v_imu1_raw_gyr2 = 342,  ///< (342) IMU 1 raw gyroscope z measurement
        v_imu1_temp     = 343,  ///< (343) IMU 1 temperature measurement
        v_stp1_raw      = 344,  ///< (344) Static pressure sensor 1 raw measurement
        v_stp1_temp     = 345,  ///< (345) Static pressure sensor 1 temperature
        v_qinf_raw      = 346,  ///< (346) Dynamic pressure sensor raw measurement
        v_qinf_temp     = 347,  ///< (347) Dynamic pressure sensor temperature
        v_stp0_raw      = 348,  ///< (348) Static pressure sensor 0 raw measurement (Digital HSC)
        v_stp0_temp     = 349,  ///< (349) Static pressure sensor 0 temperature (Digital HSC)
        v_vn300_freq    = 350,  ///< (350) Frequency of reception of Vectornav VN-300 messages
        v_vn300_rawacc0 = 351,  ///< (351) Raw Vectornav VN-300 accelerometer measurement x-axis
        v_vn300_rawacc1 = 352,  ///< (352) Raw Vectornav VN-300 accelerometer measurement y-axis
        v_vn300_rawacc2 = 353,  ///< (353) Raw Vectornav VN-300 accelerometer measurement z-axis
        v_vn300_rawgyr0 = 354,  ///< (354) Raw Vectornav VN-300 gyroscope measurement x-axis
        v_vn300_rawgyr1 = 355,  ///< (355) Raw Vectornav VN-300 gyroscope measurement y-axis
        v_vn300_rawgyr2 = 356,  ///< (356) Raw Vectornav VN-300 gyroscope measurement z-axis
        v_mag3_raw0     = 357,  ///< (357) Magnetometer 3 raw measure X converted to SI
        v_mag3_raw1     = 358,  ///< (358) Magnetometer 3 raw measure Y converted to SI
        v_mag3_raw2     = 359,  ///< (359) Magnetometer 3 raw measure Z converted to SI
        v_mag3_temp     = 360,  ///< (360) Magnetometer 3 temperature
        v_imu2_raw_acc0 = 361,  ///< (361) IMU 2 raw accelerometer x measurement
        v_imu2_raw_acc1 = 362,  ///< (362) IMU 2 raw accelerometer y measurement
        v_imu2_raw_acc2 = 363,  ///< (363) IMU 2 raw accelerometer z measurement
        v_imu2_raw_gyr0 = 364,  ///< (364) IMU 2 raw gyroscope x measurement
        v_imu2_raw_gyr1 = 365,  ///< (365) IMU 2 raw gyroscope y measurement
        v_imu2_raw_gyr2 = 366,  ///< (366) IMU 2 raw gyroscope z measurement
        v_imu2_temp     = 367,  ///< (367) IMU 2 temperature measurement
        v_stp2_raw      = 368,  ///< (368) Static pressure sensor 2 raw measurement
        v_stp2_temp     = 369,  ///< (369) Static pressure sensor 2 temperature
        v_mag4_raw0     = 370,  ///< (370) Magnetometer 4 raw measure X converted to SI
        v_mag4_raw1     = 371,  ///< (371) Magnetometer 4 raw measure Y converted to SI
        v_mag4_raw2     = 372,  ///< (372) Magnetometer 4 raw measure Z converted to SI
        v_mag4_temp     = 373,  ///< (373) Magnetometer 4 temperature
        v_mag5_raw0     = 374,  ///< (374) Magnetometer 5 raw measure X converted to SI
        v_mag5_raw1     = 375,  ///< (375) Magnetometer 5 raw measure Y converted to SI
        v_mag5_raw2     = 376,  ///< (376) Magnetometer 5 raw measure Z converted to SI
        v_mag5_temp     = 377,  ///< (377) Magnetometer 5 temperature
        v_mag6_raw0     = 378,  ///< (378) Magnetometer 6 raw measure X converted to SI
        v_mag6_raw1     = 379,  ///< (379) Magnetometer 6 raw measure Y converted to SI
        v_mag6_raw2     = 380,  ///< (380) Magnetometer 6 raw measure Z converted to SI
        v_mag6_temp     = 381,  ///< (381) Magnetometer 6 temperature
        // 382 reserved for regvars
        // 383 reserved for regvars
        // 384 reserved for regvars
        // 385 reserved for regvars
        v_imu3_raw_acc0 = 386,  ///< (386) IMU 3 raw accelerometer x measurement
        v_imu3_raw_acc1 = 387,  ///< (387) IMU 3 raw accelerometer y measurement
        v_imu3_raw_acc2 = 388,  ///< (388) IMU 3 raw accelerometer z measurement
        v_imu3_raw_gyr0 = 389,  ///< (389) IMU 3 raw gyroscope x measurement
        v_imu3_raw_gyr1 = 390,  ///< (390) IMU 3 raw gyroscope y measurement
        v_imu3_raw_gyr2 = 391,  ///< (391) IMU 3 raw gyroscope z measurement
        v_imu3_temp     = 392,  ///< (392) IMU 3 temperature measurement
        v_mag7_raw0     = 393,  ///< (393) Magnetometer 7 raw measure X converted to SI
        v_mag7_raw1     = 394,  ///< (394) Magnetometer 7 raw measure Y converted to SI
        v_mag7_raw2     = 395,  ///< (395) Magnetometer 7 raw measure Z converted to SI
        v_mag7_temp     = 396,  ///< (396) Magnetometer 7 temperature
        // 397 reserved for regvars
        // 398 reserved for regvars
        // 399 reserved for regvars
        v_pwr           = 400,  ///< (400) Power input
        v_pwr33         = 401,  ///< (401) Power 3.3V
        v_pwr5          = 402,  ///< (402) Power 5V
        v_pwr_arbreg    = 403,  ///< (403) Power in (arbiter regulator)
        v_pwr36         = 404,  ///< (404) Power 3.6V
        v_tempdsc       = 405,  ///< (405) DSC temperature
        v_ext_imu0_raw_acc0 = 406,  ///< (406) External IMU 0 raw accelerometer x measurement
        v_ext_imu0_raw_acc1 = 407,  ///< (407) External IMU 0 raw accelerometer y measurement
        v_ext_imu0_raw_acc2 = 408,  ///< (408) External IMU 0 raw accelerometer z measurement
        v_ext_imu0_raw_gyr0 = 409,  ///< (409) External IMU 0 raw gyroscope x measurement
        v_ext_imu0_raw_gyr1 = 410,  ///< (410) External IMU 0 raw gyroscope y measurement
        v_ext_imu0_raw_gyr2 = 411,  ///< (411) External IMU 0 raw gyroscope z measurement
        v_ext_imu0_temp     = 412,  ///< (412) External IMU 0 temperature measurement
        v_ext_imu1_raw_acc0 = 413,  ///< (413) External IMU 1 raw accelerometer x measurement
        v_ext_imu1_raw_acc1 = 414,  ///< (414) External IMU 1 raw accelerometer y measurement
        v_ext_imu1_raw_acc2 = 415,  ///< (415) External IMU 1 raw accelerometer z measurement
        v_ext_imu1_raw_gyr0 = 416,  ///< (416) External IMU 1 raw gyroscope x measurement
        v_ext_imu1_raw_gyr1 = 417,  ///< (417) External IMU 1 raw gyroscope y measurement
        v_ext_imu1_raw_gyr2 = 418,  ///< (418) External IMU 1 raw gyroscope z measurement
        v_ext_imu1_temp     = 419,  ///< (419) External IMU 1 temperature measurement
        v_ext_mag0_raw0     = 420,  ///< (420) External magnetometer 0 raw measurement X
        v_ext_mag0_raw1     = 421,  ///< (421) External magnetometer 0 raw measurement Y
        v_ext_mag0_raw2     = 422,  ///< (422) External magnetometer 0 raw measurement Z
        v_ext_mag0_temp     = 423,  ///< (423) External magnetometer 0 temperature
        v_ext_mag1_raw0     = 424,  ///< (424) External magnetometer 1 raw measurement X
        v_ext_mag1_raw1     = 425,  ///< (425) External magnetometer 1 raw measurement Y
        v_ext_mag1_raw2     = 426,  ///< (426) External magnetometer 1 raw measurement Z
        v_ext_mag1_temp     = 427,  ///< (427) External magnetometer 1 temperature
        v_ext_nav_yaw       = 428,  ///< (428) External navigation yaw [rad]
        v_ext_nav_pitch     = 429,  ///< (429) External navigation pitch [rad]
        v_ext_nav_roll      = 430,  ///< (430) External navigation roll [rad]
        v_ext_nav_p         = 431,  ///< (431) External navigation p (angular speed in x body axis) [rad/s]
        v_ext_nav_q         = 432,  ///< (432) External navigation q (angular speed in y body axis) [rad/s]
        v_ext_nav_r         = 433,  ///< (433) External navigation r (angular speed in z body axis) [rad/s]
        v_ext_nav_vn        = 434,  ///< (434) External navigation north velocity [m/s]
        v_ext_nav_ve        = 435,  ///< (435) External navigation east velocity [m/s]
        v_ext_nav_vd        = 436,  ///< (436) External navigation down velocity [m/s]
        v_ext_nav_ax        = 437,  ///< (437) External navigation x-body acceleration [m/s^2]
        v_ext_nav_ay        = 438,  ///< (438) External navigation y-body acceleration [m/s^2]
        v_ext_nav_az        = 439,  ///< (439) External navigation z-body acceleration [m/s^2]

        // from 440 to 449 reserved for external sensors / fast regvars in custom messages

        calib_eyaw = 450, ///< (450) Calibration Encoder YAW
        calib_eroll = 451, ///< (451) Calibration Encoder ROLL
        calib_epitch = 452, ///< (452) Calibration Encoder PITCH
        calib_dyaw = 453, ///< (453) Calibration Desired YAW
        calib_droll = 454, ///< (454) Calibration Desired ROLL
        calib_dpitch = 455, ///< (455) Calibration Desired PITCH
        calib_myaw = 456, ///< (456) Calibration Motor YAW
        calib_mroll = 457, ///< (457) Calibration Motor ROLL
        calib_mpitch = 458, ///< (458) Calibration Motor PITCH



        v_llh0      = 500, ///< (500) Longitude
        v_llh1      = 501, ///< (501) Latitude
        v_llh2      = 502, ///< (502) Height WGS84
        v_msl       = 503, ///< (503) Over mean sea level altitude.
        v_agl       = 504, ///< (504) Above ground level height.
        v_vnorth    = 505, ///< (505) North velocity
        v_veast     = 506, ///< (506) East velocity
        v_vdown     = 507, ///< (507) Down velocity
        v_ias_raw   = 508, ///< (508) IAS from sensor (should disappear soon)
        v_was0      = 509, ///< (509) Angle of attack (aerodynamic speed vs body attitude)
        v_was1      = 510, ///< (510) Sideslip (aerodynamic speed vs body attitude)
        v_gps0_msl  = 511, ///< (511) GPS 1 mean sea level (MSL)
        v_gps0_agl  = 512, ///< (512) GPS 1 above ground level (AGLevel)
        v_gps1_msl  = 513, ///< (513) GPS 2 mean sea level (MSL)
        v_gps1_agl  = 514, ///< (514) GPS 2 above ground level (AGLevel)

        // Transponder variables reserved until 599
        //  - Sagetech variables, used by block to parse variables for GPS Navigation Data Message
        v_mx_lng_dec    = 551,
        v_mx_lng_frc    = 552,
        v_mx_lat_dec    = 553,
        v_mx_lat_frc    = 554,
        v_mx_gnd_spd    = 555,
        v_mx_gnd_trk    = 556,

        // ADS-B Out variables
        v_adsbout_squawk = 560,

        v_t0     = 600, ///< (600) Temperature 0
        v_t1     = 601, ///< (601) Temperature 1
        v_t2     = 602, ///< (602) Temperature 2
        v_t3     = 603, ///< (603) Temperature 3

        v_np_e2  = 610, ///< (610) Variance of EKF estimated north position (m^2)
        v_ep_e2  = 611, ///< (611) Variance of EKF estimated east position (m^2)
        v_dp_e2  = 612, ///< (612) Variance of EKF estimated down position (m^2)
        v_nv_e2  = 613, ///< (613) Variance of EKF estimated north velocity ((m/s)^2)
        v_ev_e2  = 614, ///< (614) Variance of EKF estimated east velocity ((m/s)^2)
        v_dv_e2  = 615, ///< (615) Variance of EKF estimated down velocity ((m/s)^2)

        // Gimbal varialbes reserved until 662
        com_yaw      = 650, ///< (650) Gimbal command yaw
        com_pitch    = 651, ///< (651) Gimbal command pitch
        stick_yaw    = 652, ///< (652) Gimbal stick yaw
        stick_pitch  = 653, ///< (653) Gimbal stick yaw
        pitch_corr1  = 654, ///< (654) Gimbal pitch correction 1
        pitch_corr2  = 655, ///< (655) Gimbal pitch correction 2
        old_joint1   = 656, ///< (656) Gimbal old joint 1
        old_joint2   = 657, ///< (657) Gimbal old joint 2
        cos_yaw      = 658, ///< (658) Cos (gimbal yaw)
        sin_yaw      = 659, ///< (659) Sin (gimbal yaw)
        yaw_rad      = 660, ///< (660) Gimbal yaw radian
        yaw_out      = 661, ///< (661) Veronte Gimbal yaw output
        pitch_out    = 662, ///< (662) Veronte Gimbal pitch output
        g_reserved0  = 663, ///< (663) gimbal reserved
        g_reserved1  = 664, ///< (664) gimbal reserved
        g_reserved2  = 665, ///< (665) gimbal reserved
        roll_out     = 666, ///< (666) Veronte Gimbal roll output

        v_rpm0   = 700, ///< (700) RPM sensor 0
        v_rpm1   = 701, ///< (701) RPM sensor 1
        v_rpm2   = 702, ///< (702) RPM sensor 2
        v_rpm3   = 703, ///< (703) RPM sensor 3
        v_rpm4   = 704, ///< (704) RPM sensor 4
        v_rpm5   = 705, ///< (705) RPM sensor 5

        v_pid_dt   = 750, ///< (750) Selected controller time step
        v_pid_dfe  = 751, ///< (751) Selected controller derivative filtered error
        v_pid_pu   = 752, ///< (752) Selected controller proportional action
        v_pid_du   = 753, ///< (753) Selected controller derivative action
        v_pid_aw   = 754, ///< (754) Selected controller integral input
        v_pid_iu   = 755, ///< (755) Selected controller integral action
        v_pid_usat = 756, ///< (756) Selected controller anti-windup input
        v_pid_de   = 757, ///< (757) Selected controller derivative error


        v_pwm00  = 800, ///< (800) PWM  0 normalized pulse value
        v_pwm01  = 801, ///< (801) PWM  1 normalized pulse value
        v_pwm02  = 802, ///< (802) PWM  2 normalized pulse value
        v_pwm03  = 803, ///< (803) PWM  3 normalized pulse value
        v_pwm04  = 804, ///< (804) PWM  4 normalized pulse value
        v_pwm05  = 805, ///< (805) PWM  5 normalized pulse value
        v_pwm06  = 806, ///< (806) PWM  6 normalized pulse value
        v_pwm07  = 807, ///< (807) PWM  7 normalized pulse value
        v_pwm08  = 808, ///< (808) PWM  8 normalized pulse value
        v_pwm09  = 809, ///< (809) PWM  9 normalized pulse value
        v_pwm10  = 810, ///< (810) PWM 10 normalized pulse value
        v_pwm11  = 811, ///< (811) PWM 11 normalized pulse value
        v_pwm12  = 812, ///< (812) PWM 12 normalized pulse value
        v_pwm13  = 813, ///< (813) PWM 13 normalized pulse value
        v_pwm14  = 814, ///< (814) PWM 14 normalized pulse value
        v_pwm15  = 815, ///< (815) PWM 15 normalized pulse value
        v_pwm16  = 816, ///< (816) PWM 16 normalized pulse value
        v_pwm17  = 817, ///< (817) PWM 17 normalized pulse value
        v_pwm18  = 818, ///< (818) PWM 18 normalized pulse value
        v_pwm19  = 819, ///< (819) PWM 19 normalized pulse value
        v_pwm20  = 820, ///< (820) PWM 20 normalized pulse value
        v_pwm21  = 821, ///< (821) PWM 21 normalized pulse value
        v_pwm22  = 822, ///< (822) PWM 22 normalized pulse value
        v_pwm23  = 823, ///< (823) PWM 23 normalized pulse value


        v_stkr00 = 900, ///< (900) Stick channel 00 (raw, aligned to capture channels)
        v_stkr01 = 901, ///< (901) Stick channel 01 (raw, aligned to capture channels)
        v_stkr02 = 902, ///< (902) Stick channel 02 (raw, aligned to capture channels)
        v_stkr03 = 903, ///< (903) Stick channel 03 (raw, aligned to capture channels)
        v_stkr04 = 904, ///< (904) Stick channel 04 (raw, aligned to capture channels)
        v_stkr05 = 905, ///< (905) Stick channel 05 (raw, aligned to capture channels)
        v_stkr06 = 906, ///< (906) Stick channel 06 (raw, aligned to capture channels)
        v_stkr07 = 907, ///< (907) Stick channel 07 (raw, aligned to capture channels)
        v_stkr08 = 908, ///< (908) Stick channel 08 (raw, aligned to capture channels)
        v_stkr09 = 909, ///< (909) Stick channel 09 (raw, aligned to capture channels)
        v_stkr10 = 910, ///< (910) Stick channel 10 (raw, aligned to capture channels)
        v_stkr11 = 911, ///< (911) Stick channel 11 (raw, aligned to capture channels)
        v_stkr12 = 912, ///< (912) Stick channel 12 (raw, aligned to capture channels)
        v_stkr13 = 913, ///< (913) Stick channel 13 (raw, aligned to capture channels)
        v_stkr14 = 914, ///< (914) Stick channel 14 (raw, aligned to capture channels)
        v_stkr15 = 915, ///< (915) Stick channel 15 (raw, aligned to capture channels)

        v_stky00 = 1000, ///< (1000) Stick channel 00 (after transform, aligned with servos)
        v_stky01 = 1001, ///< (1001) Stick channel 01 (after transform, aligned with servos)
        v_stky02 = 1002, ///< (1002) Stick channel 02 (after transform, aligned with servos)
        v_stky03 = 1003, ///< (1003) Stick channel 03 (after transform, aligned with servos)
        v_stky04 = 1004, ///< (1004) Stick channel 04 (after transform, aligned with servos)
        v_stky05 = 1005, ///< (1005) Stick channel 05 (after transform, aligned with servos)
        v_stky06 = 1006, ///< (1006) Stick channel 06 (after transform, aligned with servos)
        v_stky07 = 1007, ///< (1007) Stick channel 07 (after transform, aligned with servos)
        v_stky08 = 1008, ///< (1008) Stick channel 08 (after transform, aligned with servos)
        v_stky09 = 1009, ///< (1009) Stick channel 09 (after transform, aligned with servos)
        v_stky10 = 1010, ///< (1010) Stick channel 10 (after transform, aligned with servos)
        v_stky11 = 1011, ///< (1011) Stick channel 11 (after transform, aligned with servos)
        v_stky12 = 1012, ///< (1012) Stick channel 12 (after transform, aligned with servos)
        v_stky13 = 1013, ///< (1013) Stick channel 13 (after transform, aligned with servos)
        v_stky14 = 1014, ///< (1014) Stick channel 14 (after transform, aligned with servos)
        v_stky15 = 1015, ///< (1015) Stick channel 15 (after transform, aligned with servos)
        v_stky16 = 1016, ///< (1016) Stick channel 16 (after transform, aligned with servos)
        v_stky17 = 1017, ///< (1017) Stick channel 17 (after transform, aligned with servos)
        v_stky18 = 1018, ///< (1018) Stick channel 18 (after transform, aligned with servos)
        v_stky19 = 1019, ///< (1019) Stick channel 19 (after transform, aligned with servos)
        v_stky20 = 1020, ///< (1020) Stick channel 20 (after transform, aligned with servos)
        v_stky21 = 1021, ///< (1021) Stick channel 21 (after transform, aligned with servos)
        v_stky22 = 1022, ///< (1022) Stick channel 22 (after transform, aligned with servos)
        v_stky23 = 1023, ///< (1023) Stick channel 23 (after transform, aligned with servos)
        v_stky24 = 1024, ///< (1024) Stick channel 24 (after transform, aligned with servos)
        v_stky25 = 1025, ///< (1025) Stick channel 25 (after transform, aligned with servos)
        v_stky26 = 1026, ///< (1026) Stick channel 26 (after transform, aligned with servos)
        v_stky27 = 1027, ///< (1027) Stick channel 27 (after transform, aligned with servos)
        v_stky28 = 1028, ///< (1028) Stick channel 28 (after transform, aligned with servos)
        v_stky29 = 1029, ///< (1029) Stick channel 29 (after transform, aligned with servos)
        v_stky30 = 1030, ///< (1030) Stick channel 30 (after transform, aligned with servos)
        v_stky31 = 1031, ///< (1031) Stick channel 31 (after transform, aligned with servos)

        v_ubs00  = 1050, ///< (1050) Control Output 01 before servo saturation
        v_ubs01  = 1051, ///< (1051) Control Output 02 before servo saturation
        v_ubs02  = 1052, ///< (1052) Control Output 03 before servo saturation
        v_ubs03  = 1053, ///< (1053) Control Output 04 before servo saturation
        v_ubs04  = 1054, ///< (1054) Control Output 05 before servo saturation
        v_ubs05  = 1055, ///< (1055) Control Output 06 before servo saturation
        v_ubs06  = 1056, ///< (1056) Control Output 07 before servo saturation
        v_ubs07  = 1057, ///< (1057) Control Output 08 before servo saturation
        v_ubs08  = 1058, ///< (1058) Control Output 09 before servo saturation
        v_ubs09  = 1059, ///< (1059) Control Output 10 before servo saturation
        v_ubs10  = 1060, ///< (1060) Control Output 11 before servo saturation
        v_ubs11  = 1061, ///< (1061) Control Output 12 before servo saturation
        v_ubs12  = 1062, ///< (1062) Control Output 13 before servo saturation
        v_ubs13  = 1063, ///< (1063) Control Output 14 before servo saturation
        v_ubs14  = 1064, ///< (1064) Control Output 15 before servo saturation
        v_ubs15  = 1065, ///< (1065) Control Output 16 before servo saturation
        v_ubs16  = 1066, ///< (1066) Control Output 17 before servo saturation
        v_ubs17  = 1067, ///< (1067) Control Output 18 before servo saturation
        v_ubs18  = 1068, ///< (1068) Control Output 19 before servo saturation
        v_ubs19  = 1069, ///< (1069) Control Output 20 before servo saturation
        //      ...                   reserved until 1099

        v_lidar01 = 1100, ///< (1100) Lidar 1 distance measure
        v_lidar02 = 1101, ///< (1101) Lidar 2 distance measure
        v_lidar03 = 1102, ///< (1102) Lidar 3 distance measure
        v_lidar04 = 1103, ///< (1103) Lidar 4 distance measure
        v_lidar05 = 1104, ///< (1104) Lidar 5 distance measure
        v_exrange01=1105, ///< (1105) External range sensor 1 measure
        v_exrange02=1106, ///< (1106) External range sensor 2 measure
        v_exrange03=1107, ///< (1107) External range sensor 3 measure
        v_exrange04=1108, ///< (1108) External range sensor 4 measure
        v_exrange05=1109, ///< (1109) External range sensor 5 measure


        v_routedev = 1200, ///< (1200) Route-Guidance route absolute distance
        v_radaralt = 1201, ///< (1201) Radar altimeter measure
        v_radarspd = 1202, ///< (1202) Radar speed
        v_ext_rot  = 1203, ///< (1203) External rotation for follow route
        v_min_tti  = 1204, ///< (1204) Closest time to impact with cmd obstacles

        v_uclk00 = 1300, ///< (1300) User clock 0 value
        v_uclk01 = 1301, ///< (1301) User clock 1 value
        v_uclk02 = 1302, ///< (1302) User clock 2 value
        v_uclk03 = 1303, ///< (1303) User clock 3 value
        v_uclk04 = 1304, ///< (1304) User clock 4 value
        v_uclk05 = 1305, ///< (1305) User clock 5 value
        v_uclk06 = 1306, ///< (1306) User clock 6 value
        v_uclk07 = 1307, ///< (1307) User clock 7 value
        v_uclk08 = 1308, ///< (1308) User clock 8 value
        v_uclk09 = 1309, ///< (1309) User clock 9 value

        // CEX Start
        v_cex_adc0_3_3          = 1320, ///< (1320) ADC0 3.3V input
        v_cex_adc1_3_3          = 1321, ///< (1321) ADC1 3.3V input
        v_cex_adc2_5            = 1322, ///< (1322) ADC2 5.0V input
        v_cex_adc3_5            = 1323, ///< (1323) ADC3 5.0V input
        v_cex_adc4_12           = 1324, ///< (1324) ADC4 12.0V input
        v_cex_adc5_12           = 1325, ///< (1325) ADC5 12.0V input
        v_cex_adc6_36           = 1326, ///< (1326) ADC6 36.0V input
        v_cex_adc7_36           = 1327, ///< (1327) ADC7 36.0V input
        v_cex_adc_vin1          = 1328, ///< (1328) ADC vIn 1
        v_cex_adc_vin2          = 1329, ///< (1329) ADC vIn 2
        v_cex_pcb_temp          = 1330, ///< (1330) PCB temperature (from ADC input)
        v_cex_hwv               = 1331, ///< (1331) voltage value to determine hardware version
        // CEX reserved to        1349
        // CEX End

        // 4XV Start
        v_arb_adc00 = 1350, ///< (1350) 4XV ADC0  converted value
        v_arb_adc01 = 1351, ///< (1351) 4XV ADC1  converted value
        v_arb_adc02 = 1352, ///< (1352) 4XV ADC2  converted value
        v_arb_adc03 = 1353, ///< (1353) 4XV ADC3  converted value
        v_arb_adc04 = 1354, ///< (1354) 4XV ADC4  converted value
        v_arb_adc05 = 1355, ///< (1355) 4XV ADC5  converted value
        v_arb_adc06 = 1356, ///< (1356) 4XV ADC6  converted value
        v_arb_adc07 = 1357, ///< (1357) 4XV ADC7  converted value
        v_arb_adc08 = 1358, ///< (1358) 4XV ADC8  converted value
        v_arb_adc09 = 1359, ///< (1359) 4XV ADC9  converted value
        v_arb_adc10 = 1360, ///< (1360) 4XV ADC10 converted value
        v_arb_adc11 = 1361, ///< (1361) 4XV ADC11 converted value
        v_arb_adc12 = 1362, ///< (1362) 4XV ADC12 converted value
        v_arb_adc13 = 1363, ///< (1363) 4XV ADC13 converted value
        v_arb_adc14 = 1364, ///< (1364) 4XV ADC14 converted value
        v_arb_adc15 = 1365, ///< (1365) 4XV ADC15 converted value

        v_arb_ap0_scr   = 1366,     //< 4XV AP0 Score
        v_arb_ap1_scr   = 1367,     //< 4XV AP1 Score
        v_arb_ap2_scr   = 1368,     //< 4XV AP2 Score
        v_arb_ap3_scr   = 1369,     //< 4XV AP External Score
        // 4XV reserved to
        // 4XV End    1399

        v_uvw0      = 1400, ///< (1400) Longitudinal (body frame) velocity
        v_uvw1      = 1401, ///< (1401) Lateral (body frame) velocity
        v_uvw2      = 1402, ///< (1402) Vertical (body frame) velocity
        v_qoo       = 1403, ///< (1403) Estimated dynamic pressure
        v_ussa_p0   = 1404, ///< (1404) Air pressure at sea level

        v_cappulse0 = 1450, ///< (1450) Captured pulse 1
        v_cappulse1 = 1451, ///< (1451) Captured pulse 2
        v_cappulse2 = 1452, ///< (1452) Captured pulse 3
        v_cappulse3 = 1453, ///< (1453) Captured pulse 4
        // v_cappulse4 = 1454, ///< (1454) Captured pulse 5
        // v_cappulse5 = 1455, ///< (1455) Captured pulse 6

        v_ext_nav_freq      = 1483, ///< (1483) External navigation frequency
        v_ext_imu0_acc_freq = 1484, ///< (1484) External IMU 0 accelerometer reception frequency
        v_ext_imu0_gyr_freq = 1485, ///< (1485) External IMU 0 gyroscope reception frequency
        v_ext_imu1_acc_freq = 1486, ///< (1486) External IMU 1 accelerometer reception frequency
        v_ext_imu1_gyr_freq = 1487, ///< (1487) External IMU 1 gyroscope reception frequency
        v_ext_mag0_freq     = 1488, ///< (1488) External magnetometer 0 reception frequency
        v_ext_mag1_freq     = 1489, ///< (1489) External magnetometer 1 reception frequency
        v_internest_raw_x   = 1490, ///< (1490) Internest x distance raw measurement.
        v_internest_raw_y   = 1491, ///< (1491) Internest y distance raw measurement.
        v_internest_raw_z   = 1492, ///< (1492) Internest z distance raw measurement.
        v_internest_raw_a   = 1493, ///< (1493) Internest angle raw measurement.
        v_internest_raw_sxy = 1494, ///< (1494) Internest xy standard deviation raw measurement.
        v_internest_raw_sz  = 1495, ///< (1495) Internest z standard deviation raw measurement.
        v_internest_raw_sa  = 1496, ///< (1496) Internest angle standard deviation raw measurement.
        v_internest_pos_freq = 1497, ///< (1497) Internest position update frequency

        v_gps0_tow      = 1500, ///< (1500) GPS 1 Time of week
        v_gps0_ecefx    = 1501, ///< (1501) GPS 1 ECEF Position X
        v_gps0_ecefy    = 1502, ///< (1502) GPS 1 ECEF Position Y
        v_gps0_ecefz    = 1503, ///< (1503) GPS 1 ECEF Position Z
        v_gps0_llh0     = 1504, ///< (1504) GPS 1 longitude
        v_gps0_llh1     = 1505, ///< (1505) GPS 1 latitude
        v_gps0_llh2     = 1506, ///< (1506) GPS 1 height above ellipsoid (WGS84)
        v_gps0_pdop     = 1509, ///< (1509) GPS 1 pdop (dilution of precision of position)
        v_gps0_acc      = 1510, ///< (1510) GPS 1 accuracy
        v_gps0_hacc     = 1511, ///< (1511) GPS 1 horizontal accuracy estimate
        v_gps0_vacc     = 1512, ///< (1512) GPS 1 vertical accuracy estimate
        v_gps0_vnn      = 1513, ///< (1513) GPS 1 Velocity North
        v_gps0_vne      = 1514, ///< (1514) GPS 1 Velocity East
        v_gps0_vnd      = 1515, ///< (1515) GPS 1 Velocity Down
        v_gps0_spdacc   = 1516, ///< (1516) GPS 1 speed accuracy estimate
        v_gps0_rllh0    = 1517, ///< (1517) GPS 1 related base longitude
        v_gps0_rllh1    = 1518, ///< (1518) GPS 1 related base latitude
        v_gps0_rllh2    = 1519, ///< (1519) GPS 1 related base WGS84 altitude
        v_gps0_raz      = 1520, ///< (1520) GPS 1 related base to rover azimuth
        v_gps0_relev    = 1521, ///< (1521) GPS 1 related base to rover elevation
        v_gps0_rdist    = 1522, ///< (1522) GPS 1 related base to rover distance
        v_gps0_racc     = 1523, ///< (1523) GPS 1 related base to rover accuracy
        v_gps0_svin_acc = 1524, ///< (1524) GPS 1 survey in accuracy
        v_gps0_rned0    = 1525, ///< (1525) GPS 1 related north
        v_gps0_rned1    = 1526, ///< (1526) GPS 1 related east
        v_gps0_rned2    = 1527, ///< (1527) GPS 1 related down
        v_gps0_pos_freq = 1528, ///< (1528) GPS 1 position freq message.
        v_gps0_jammind  = 1529, ///< (1529) GPS 1 CW jamming indicator
        v_gps0_vdop     = 1530, ///< (1530) GPS 1 Vertical DOP
        v_gps0_hdop     = 1531, ///< (1531) GPS 1 Horizontal DOP
        v_gps0_all      = 1532,
        // reserved until 1599 (GPS 1).


        v_gps1_tow      = 1600, ///< (1600) GPS 2 Time of week
        v_gps1_ecefx    = 1601, ///< (1601) GPS 2 ECEF Position X
        v_gps1_ecefy    = 1602, ///< (1602) GPS 2 ECEF Position Y
        v_gps1_ecefz    = 1603, ///< (1603) GPS 2 ECEF Position Z
        v_gps1_llh0     = 1604, ///< (1604) GPS 2 longitude
        v_gps1_llh1     = 1605, ///< (1605) GPS 2 latitude
        v_gps1_llh2     = 1606, ///< (1606) GPS 2 height above ellipsoid (WGS84)
        v_gps1_pdop     = 1609, ///< (1609) GPS 2 pdop (dilution of precision of position)
        v_gps1_acc      = 1610, ///< (1610) GPS 2 accuracy
        v_gps1_hacc     = 1611, ///< (1611) GPS 2 horizontal accuracy estimate
        v_gps1_vacc     = 1612, ///< (1612) GPS 2 vertical accuracy estimate
        v_gps1_vnn      = 1613, ///< (1613) GPS 2 Velocity North
        v_gps1_vne      = 1614, ///< (1614) GPS 2 Velocity East
        v_gps1_vnd      = 1615, ///< (1615) GPS 2 Velocity Down
        v_gps1_spdacc   = 1616, ///< (1616) GPS 2 speed accuracy estimate
        v_gps1_rllh0    = 1617, ///< (1617) GPS 2 related base longitude
        v_gps1_rllh1    = 1618, ///< (1618) GPS 2 related base latitude
        v_gps1_rllh2    = 1619, ///< (1619) GPS 2 related base WGS84 altitude
        v_gps1_raz      = 1620, ///< (1620) GPS 2 related base to rover azimuth
        v_gps1_relev    = 1621, ///< (1621) GPS 2 related base to rover elevation
        v_gps1_rdist    = 1622, ///< (1622) GPS 2 related base to rover distance
        v_gps1_racc     = 1623, ///< (1623) GPS 2 related base to rover accuracy
        v_gps1_svin_acc = 1624, ///< (1624) GPS 2 survey in accuracy
        v_gps1_rned0    = 1625, ///< (1625) GPS 2 related north
        v_gps1_rned1    = 1626, ///< (1626) GPS 2 related east
        v_gps1_rned2    = 1627, ///< (1627) GPS 2 related down
        v_gps1_pos_freq = 1628, ///< (1628) GPS 2 position freq message.
        v_gps1_jammind  = 1629, ///< (1629) GPS 2 CW jamming indicator
        v_gps1_vdop     = 1630, ///< (1630) GPS 2 Vertical DOP
        v_gps1_hdop     = 1631, ///< (1631) GPS 2 Horizontal DOP
        // reserved until 1699 (GPS 2).


        v_srv00   = 1700, ///< (1700) Servo 00 value
        v_srv31   = 1731, ///< (1731) Servo 31 value
        // reserved until 1799 for Servo 99 value


        v_ooi_d00  = 1800, ///< (1800) Distance to ooi 1
        v_ooi_Az00 = 1801, ///< (1801) Azimuth to ooi 1
        v_ooi_E00  = 1802, ///< (1802) Elevation to ooi 1
        v_ooi_d31  = 1893, ///< (1893) Distance to ooi 32
        v_ooi_Az31 = 1894, ///< (1894) Azimuth to ooi 32
        v_ooi_E31  = 1895, ///< (1895) Elevation to ooi 32

        // reserved until 1999


        v_rxper        = 2000,  ///< (2000) RX Packet Error Rate
        v_txper        = 2001,  ///< (2001) TX Packet Error Rate
        v_rxper_bri    = 2002,  ///< (2002) Internal RX baudrate used for RX PER
        v_rxper_bre    = 2003,  ///< (2003) Remote RX baudrate used for TX PER
        v_txper_bri    = 2004,  ///< (2004) Internal TX baudrate used for TX PER
        v_txper_bre    = 2005,  ///< (2005) Remote TX baudrate used for RX PER
        v_stick_rxrate = 2019,  ///< (2019) Stick reception ratio source.
        v_gpsok_time   = 2020,  ///< (2020) Time without losing GPS.


        // id range here preferred for vars in cpu1 (regvars)
        v_tunfreqrd0     = 2040, ///< (2040) Tunnel receive frequency producer 0
        v_tunfreqrd1     = 2041, ///< (2041) Tunnel receive frequency producer 1
        v_tunfreqrd2     = 2042, ///< (2042) Tunnel receive frequency producer 2
        v_tunfreqwr0     = 2043, ///< (2043) Tunnel send frequency consumer 0
        v_tunfreqwr1     = 2044, ///< (2044) Tunnel send frequency consumer 1
        v_tunfreqwr2     = 2045, ///< (2045) Tunnel send frequency consumer 2
        v_stepacq_tmax   = 2046, ///< (2046) (CPU1) Max duration of step in CIO.
        v_tskacq_dt      = 2047, ///< (2047) (CPU1) Acquisition task timestep.
        v_tskacq_dtmax   = 2048, ///< (2048) (CPU1) Acquisition task maximum timestep.
        v_tskxcmq_ravg   = 2049, ///< (2049) (CPU1) Cross core message queue CPU ratio.
        v_tskacq_ravg    = 2050, ///< (2050) (CPU1) Acquisition task average CPU ratio.
        v_tskacq_rmax    = 2051, ///< (2051) (CPU1) Acquisition task maximum CPU ratio.
        v_tskacq_tavg    = 2052, ///< (2052) (CPU1) Acquisition task average time.
        v_tskacq_tmax    = 2053, ///< (2053) (CPU1) Acquisition task maximum time.

        v_cio_t_max      = 2054, ///< (2054) (CPU1) CIO max time
        v_cio_t_avg      = 2055, ///< (2055) (CPU1) CIO average time
        v_tskxcmq_occ    = 2056, ///< (2056) (CPU1) Xcmq occupied percentage
        v_cio_freq       = 2057, ///< (2057) (CPU1) CIO running frequency (Veronte and MC)
        v_cio_freq_min   = 2058, ///< (2058) (CPU1) CIO minimum running frequency (MC)

        // try to make CPU1 variables contiguous to be able to use Regvars
        v_c2_low_freq   = 2092, ///< (2092) CPU2 Low priority current frequency.
        v_c2_low_fmin   = 2093, ///< (2093) CPU2 Low priority min frequency.
        v_tskc2_ravg    = 2094, ///< (2094) CPU2 average CPU ratio.
        v_tskc2_rmax    = 2095, ///< (2095) CPU2 maximum CPU ratio.
        v_tskc2_tavg    = 2096, ///< (2096) CPU2 average time.
        v_tskc2_tmax    = 2097, ///< (2097) CPU2 maximum time.
        v_tskc2_dtmax   = 2098, ///< (2098) CPU2 maximum period.
        v_stepc2_tmax   = 2099, ///< (2099) CPU2 Max duration of step in C2.

        v_accgyrx      = 2100, ///< (2100) ACC gyroscope X
        v_accgyry      = 2101, ///< (2101) ACC gyroscope Y
        v_accgyrz      = 2102, ///< (2102) ACC gyroscope Z
        v_anorth       = 2103, ///< (2103) Acceleration north
        v_aeast        = 2104, ///< (2104) Acceleration east
        v_adown        = 2105, ///< (2105) Acceleration down
        v_dem          = 2112, ///< (2112) Dem calibrated height delta.

        v_crvs         = 2200, ///< (2200) Curve length covered.
        v_crvsmax      = 2201, ///< (2201) Curve length.
        v_crvs2a       = 2202, ///< (2202) Curve length pending.
        v_crvu         = 2203, ///< (2203) Curve parameter covered.
        v_crvumax      = 2204, ///< (2204) Curve parameter range.
        v_crvu2a       = 2205, ///< (2205) Curve parameter pending.
        v_crv_hc       = 2206, ///< (2206) Curve horizontal curvature.


        // Temporary variables for debugging purposes
        v_reserved0    = 2250, ///< (2250) (Reserved) Accelerometer weight for attitude computation
        v_reserved1    = 2251, ///< (2251) (Reserved) Magnetometer weight for attitude computation
        v_reserved2    = 2252, ///< (2252) (Reserved) Estimated velocity derivative in navigation frame (north)
        v_reserved3    = 2253, ///< (2253) (Reserved) Estimated velocity derivative in navigation frame (east)
        v_reserved4    = 2254, ///< (2254) (Reserved) Estimated velocity derivative in navigation frame (down)
        v_reserved5    = 2255, ///< (2255) (Reserved) Estimated velocity derivative in navigation frame (down)
        v_reserved6    = 2256, ///< (2256) (Reserved) Estimated velocity derivative in navigation frame (down)
        v_reserved7    = 2257, ///< (2257) (Reserved) Estimated velocity derivative in navigation frame (down)
        v_reserved8    = 2258, ///< (2258) (Reserved) Estimated velocity derivative in navigation frame (down)
        v_reserved9    = 2259, ///< (2259) (Reserved) Estimated velocity derivative in navigation frame (down)
        // reserved until 2299


        v_gimbal0j0     = 2300, ///< (2300) Joint 1 of gimbal 1
        v_gimbal0j1     = 2301, ///< (2301) Joint 2 of gimbal 1
        v_gimbal0j2     = 2302, ///< (2302) Joint 3 of gimbal 1
        v_gimbal1j0     = 2303, ///< (2303) Joint 1 of gimbal 2
        v_gimbal1j1     = 2304, ///< (2304) Joint 2 of gimbal 2
        v_gimbal1j2     = 2305, ///< (2305) Joint 3 of gimbal 2

        v_hi_period         = 2330, ///< (2330) Control loop period
        v_hi_period_max     = 2331, ///< (2331) Control loop maximum period
        v_hi_duration       = 2332, ///< (2332) Control loop duration
        v_hi_duration_max   = 2333, ///< (2333) Control loop maximum duration
        v_hi_ratio          = 2334, ///< (2334) Control loop CPU usage ratio
        v_hi_ratio_max      = 2335, ///< (2335) Control loop maximum CPU usage ratio
        v_iph_u             = 2336, ///< (2336) U phase current [A]
        v_iph_v             = 2337, ///< (2337) V phase current [A]
        v_iph_w             = 2338, ///< (2338) W phase current [A]
        v_eangle            = 2339, ///< (2339) Electrical angle [rad]
        v_mangle            = 2340, ///< (2340) Mechanical angle [rad]
        v_mangle_rate       = 2341, ///< (2341) Mechanical angular speed [rad/s]
        v_manglec           = 2342, ///< (2342) Desired mechanical angle [rad]
        v_cpos_out          = 2343, ///< (2343) Position controller output
        v_mangle_ratec      = 2344, ///< (2344) Desired mechanical angular speed [rad]
        v_mangle_ratec_rlim = 2345, ///< (2345) Desired mechanical angular speed after speed limiter [rad/s]
        v_cspd_out          = 2346, ///< (2346) Speed controller output [A]
        v_clarke_ialpha     = 2347, ///< (2347) Alpha current [A]
        v_clarke_ibeta      = 2348, ///< (2348) Beta current [A]
        v_park_ids          = 2349, ///< (2349) Actual direct current [A]
        v_park_iqs          = 2350, ///< (2350) Actual quadrature current [A]
        v_park_idsc         = 2351, ///< (2351) Desired direct current [A]
        v_park_iqsc         = 2352, ///< (2352) Desired quadrature current [A]
        v_cid_out           = 2353, ///< (2353) Direct current controller output [V]
        v_ciq_out           = 2354, ///< (2354) Quadrature current controller output [V]
        v_iclarke_ialpha    = 2355, ///< (2355) Alpha voltage from current controller output [V]
        v_iclarke_ibeta     = 2356, ///< (2356) Beta voltage from current controller output [V]
        v_clarke_ialphac    = 2357, ///< (2357) Desired clarke alpha current
        v_clarke_ibetac     = 2358, ///< (2358) Desired clarke beta current
        v_svgen_ta          = 2359, ///< (2359) U phase space vector generator output
        v_svgen_tb          = 2360, ///< (2360) V phase space vector generator output
        v_svgen_tc          = 2361, ///< (2361) W phase space vector generator output
        v_pwm_a             = 2362, ///< (2362) U phase PWM duty cycle [0,1]
        v_pwm_b             = 2363, ///< (2363) V phase PWM duty cycle [0,1]
        v_pwm_c             = 2364, ///< (2364) W phase PWM duty cycle [0,1]
        v_rangle            = 2365, ///< (2365) Encoder raw angle
        v_output_freq       = 2366, ///< (2366) Stepper PWM frequency
        v_mangle_err        = 2367, ///< (2367) Mechanical angle error
        v_bemf_u            = 2368, ///< (2368) U phase Back-EMF [V]
        v_bemf_v            = 2369, ///< (2369) V phase Back-EMF [V]
        v_bemf_w            = 2370, ///< (2370) W phase Back-EMF [V]
        v_input_current     = 2371, ///< (2371) Input current DC side [A]
        v_input_cmd         = 2372, ///< (2372) Input normalized rate [-1,1]
        v_adc_in0           = 2373, ///< (2373) ADC in 1
        v_adc_in1           = 2374, ///< (2374) ADC in 2
        v_board_temp        = 2375, ///< (2375) Micro-controller temperature [K]
        v_power_temp        = 2376, ///< (2376) Power module temperature [K]
        v_ext_temp          = 2377, ///< (2377) Motor temperature [K]
        v_input_voltage     = 2378, ///< (2378) Input voltage DC-side [V]
        v_ihall_u           = 2379, ///< (2379) U hall current
        v_ihall_v           = 2380, ///< (2380) V hall current
        v_diff_angle        = 2381, ///< (2381) Difference virtual-estimator [rad]
        v_eangle_low        = 2382, ///< (2382) Low speed estimator angle [rad]
        v_eangle_high       = 2383, ///< (2383) High speed estimator angle [rad]
        v_speed_low         = 2384, ///< (2384) Low speed estimator speed [rad/s]
        v_speed_high        = 2385, ///< (2385) High speed estimator speed [rad/s]
        v_str_dc_curr       = 2386, ///< (2386) String DC current [A]
        v_vdc_filt          = 2387, ///< (2387) Filtered DC voltage (V)
        v_idc_filt          = 2388, ///< (2387) Filtered DC voltage (V)
        // reserved until 2399 for VMC

        v_u00     = 2400, ///< (2400) Control Output 01 after servo saturation
        v_u01     = 2401, ///< (2401) Control Output 02 after servo saturation
        v_u02     = 2402, ///< (2402) Control Output 03 after servo saturation
        v_u03     = 2403, ///< (2403) Control Output 04 after servo saturation
        v_u04     = 2404, ///< (2404) Control Output 05 after servo saturation
        v_u05     = 2405, ///< (2405) Control Output 06 after servo saturation
        v_u06     = 2406, ///< (2406) Control Output 07 after servo saturation
        v_u07     = 2407, ///< (2407) Control Output 08 after servo saturation
        v_u08     = 2408, ///< (2408) Control Output 09 after servo saturation
        v_u09     = 2409, ///< (2409) Control Output 10 after servo saturation
        v_u10     = 2410, ///< (2410) Control Output 11 after servo saturation
        v_u11     = 2411, ///< (2411) Control Output 12 after servo saturation
        v_u12     = 2412, ///< (2412) Control Output 13 after servo saturation
        v_u13     = 2413, ///< (2413) Control Output 14 after servo saturation
        v_u14     = 2414, ///< (2414) Control Output 15 after servo saturation
        v_u15     = 2415, ///< (2415) Control Output 16 after servo saturation
        v_u16     = 2416, ///< (2416) Control Output 17 after servo saturation
        v_u17     = 2417, ///< (2417) Control Output 18 after servo saturation
        v_u18     = 2418, ///< (2418) Control Output 19 after servo saturation
        v_u19     = 2419, ///< (2419) Control Output 20 after servo saturation
        //      ...                   reserved until 2449

        v_ic00    = 2450, ///< (2450) Inner controller output 1
        v_ic01    = 2451,
        v_ic02    = 2452,
        v_ic03    = 2453,
        v_ic04    = 2454,
        v_ic05    = 2455,
        v_ic06    = 2456,
        v_ic07    = 2457,
        v_ic08    = 2458,
        v_ic09    = 2459,
        v_ic10    = 2460,
        v_ic11    = 2461, ///< (2461) Inner controller output 12.
        v_ic12    = 2462, ///< (2462) Inner controller output 13.
        v_ic13    = 2463, ///< (2463) Inner controller output 14.
        v_ic14    = 2464, ///< (2464) Inner controller output 15.
        v_ic15    = 2465, ///< (2465) Inner controller output 16.
        v_ic16    = 2466, ///< (2466) Inner controller output 17.
        v_ic17    = 2467, ///< (2467) Inner controller output 18.
        v_ic18    = 2468, ///< (2468) Inner controller output 19.
        v_ic19    = 2469, ///< (2469) Inner controller output 20.
        //      ...                   reserved until 2499

        v_stku00  = 2500, ///< (2500) Stick channel projected to control variable u1
        v_stku01  = 2501, ///< (2501) Stick channel projected to control variable u2
        v_stku02  = 2502, ///< (2502) Stick channel projected to control variable u3
        v_stku03  = 2503, ///< (2503) Stick channel projected to control variable u4
        v_stku04  = 2504, ///< (2504) Stick channel projected to control variable u5
        v_stku05  = 2505, ///< (2505) Stick channel projected to control variable u6
        v_stku06  = 2506, ///< (2506) Stick channel projected to control variable u7
        v_stku07  = 2507, ///< (2507) Stick channel projected to control variable u8
        v_stku08  = 2508, ///< (2508) Stick channel projected to control variable u9
        v_stku09  = 2509, ///< (2509) Stick channel projected to control variable u10
        v_stku10  = 2510, ///< (2510) Stick channel projected to control variable u11 (continued).
        v_stku11  = 2511, ///< (2511) Stick channel projected to control variable u12
        v_stku12  = 2512, ///< (2512) Stick channel projected to control variable u13.
        v_stku13  = 2513, ///< (2513) Stick channel projected to control variable u14.
        v_stku14  = 2514, ///< (2514) Stick channel projected to control variable u15.
        v_stku15  = 2515, ///< (2515) Stick channel projected to control variable u16.
        v_stku16  = 2516, ///< (2516) Stick channel projected to control variable u17.
        v_stku17  = 2517, ///< (2517) Stick channel projected to control variable u18.
        v_stku18  = 2518, ///< (2518) Stick channel projected to control variable u19.
        v_stku19  = 2519, ///< (2519) Stick channel projected to control variable u20.
        //      ...                   reserved until 2599


        v_stkdu00 = 2600, ///< (2600) Delta stick channel projected to control variable u1 (with trim subtracted).
        v_stkdu01 = 2601, ///< (2601) Delta stick channel projected to control variable u2 (with trim subtracted).
        v_stkdu02 = 2602, ///< (2602) Delta stick channel projected to control variable u3 (with trim subtracted).
        v_stkdu03 = 2603, ///< (2603) Delta stick channel projected to control variable u4 (with trim subtracted).
        v_stkdu04 = 2604, ///< (2604) Delta stick channel projected to control variable u5 (with trim subtracted).
        v_stkdu05 = 2605, ///< (2605) Delta stick channel projected to control variable u6 (with trim subtracted).
        v_stkdu06 = 2606, ///< (2606) Delta stick channel projected to control variable u7 (with trim subtracted).
        v_stkdu07 = 2607, ///< (2607) Delta stick channel projected to control variable u8 (with trim subtracted).
        v_stkdu08 = 2608, ///< (2608) Delta stick channel projected to control variable u9 (with trim subtracted).
        v_stkdu09 = 2609, ///< (2609) Delta stick channel projected to control variable u10 (with trim subtracted).
        v_stkdu10 = 2610, ///< (2610) Delta stick channel projected to control variable u11 (with trim subtracted, continued).
        v_stkdu11 = 2611, ///< (2611) Delta stick channel projected to control variable u12 (with trim subtracted).
        v_stkdu12 = 2612, ///< (2612) Delta stick channel projected to control variable u13 (with trim subtracted).
        v_stkdu13 = 2613, ///< (2613) Delta stick channel projected to control variable u14 (with trim subtracted).
        v_stkdu14 = 2614, ///< (2614) Delta stick channel projected to control variable u15 (with trim subtracted).
        v_stkdu15 = 2615, ///< (2615) Delta stick channel projected to control variable u16 (with trim subtracted).
        v_stkdu16 = 2616, ///< (2616) Delta stick channel projected to control variable u17 (with trim subtracted).
        v_stkdu17 = 2617, ///< (2617) Delta stick channel projected to control variable u18 (with trim subtracted).
        v_stkdu18 = 2618, ///< (2618) Delta stick channel projected to control variable u19 (with trim subtracted).
        v_stkdu19 = 2619, ///< (2619) Delta stick channel projected to control variable u20 (with trim subtracted).
        //      ...                   reserved until 2699


        v_operation_00 = 2700, ///< (2700) Operation variable 1
        //      ... operation variables
        v_operation_39 = 2739, ///< (2739) Operation variable 39
        //      ...                       reserved until 2799


        v_wn      = 2800, ///< (2800) north wind velocity estimation
        v_we      = 2801, ///< (2801) east wind velocity estimation
        v_wd      = 2802, ///< (2802) down wind velocity estimation
        v_wPk00   = 2803, ///< (2803) wind velocity estimation uncertainty (element 0-0)
        v_wPk10   = 2804, ///< (2804) wind velocity estimation uncertainty (element 1-0)
        v_wPk20   = 2805, ///< (2805) wind velocity estimation uncertainty (element 2-0)
        v_wPk01   = 2806, ///< (2806) wind velocity estimation uncertainty (element 0-1)
        v_wPk11   = 2807, ///< (2807) wind velocity estimation uncertainty (element 1-1)
        v_wPk21   = 2808, ///< (2808) wind velocity estimation uncertainty (element 2-1)
        v_wPk02   = 2809, ///< (2809) wind velocity estimation uncertainty (element 0-2)
        v_wPk12   = 2810, ///< (2810) wind velocity estimation uncertainty (element 1-2)
        v_wPk22   = 2811, ///< (2811) wind velocity estimation uncertainty (element 2-2)
        v_wazi    = 2812, ///< (2812) wind azimuth.
        v_wnormxy = 2813, ///< (2813) wind velocity norm xy in North-East plane.
        v_hwn     = 2814, ///< (2814) Head wind velocity North
        v_hwe     = 2815, ///< (2815) Head wind velocity East
        v_hwd     = 2816, ///< (2816) Head wind velocity Down

        v_setup_00     = 2830, ///< (2830) Setup variable 1
        //      ... setup variables
        v_setup_63     = 2893, ///< (2893) Setup variable 64

        v_press_alt_qnh = 2900,     ///< (2900) pressure alt from actual QNH and sensor static press (former v_msl_raw)
        v_press_alt_qne = 2901,     ///< (2901) pressure alt ISA std setting Pref=1013.25  (former v_atc_msl)
        v_t_phase_cur   = 2902,     ///< (2902) Time since entering current phase
        v_dt_gnc        = 2903,     ///< (2903) Control timestep
        v_logbook_time     = 2904,  ///< (2904) Total flight Time (s)
        v_logbook_distance = 2905,  ///< (2905) Total flight Distance (m)
        v_navsim_freq      = 2906,  ///< (2906) Simulated navigation update frequency
        v_navext_freq   = 2907,     ///< (2907) External navigation update frequency
        v_t_phase_00    = 2908,     ///< (2908) Time spent within phase 0
        v_t_phase_01    = 2909,     ///< (2909) Time spent within phase 1
        v_t_phase_02    = 2910,     ///< (2910) Time spent within phase 2
        v_t_phase_03    = 2911,
        v_t_phase_04    = 2912,
        v_t_phase_05    = 2913,
        v_t_phase_06    = 2914,
        v_t_phase_07    = 2915,
        v_t_phase_08    = 2916,
        v_t_phase_09    = 2917,
        v_t_phase_10    = 2918,
        v_t_phase_11    = 2919,
        v_t_phase_12    = 2920,
        v_t_phase_13    = 2921,
        v_t_phase_14    = 2922,
        v_t_phase_15    = 2923,
        v_t_phase_16    = 2924,
        v_t_phase_17    = 2925,
        v_t_phase_18    = 2926,
        v_t_phase_19    = 2927,
        v_t_phase_20    = 2928,

        v_sim           = 3000, ///< (3000) Simulation variables
        // reserved until 3099


        v_user          = 3100, ///< (3100) User variables
        v_user19        = 3119, ///< (3119) User variable 20
        // Reserved for user variables
        v_user_last     = 4099, ///< (4099) User variable 20

        v_zero    = 4100,       ///< (4100) Zero
        v_none    = 4101,

        v_all     = 4102
    };

    inline bool is_valid(Rvar v)
    {
        return Range<Rvar, v_ias, v_all>::in_range(v);
    }

    /// @return True if the Rvar passed as argument can be written by the user, false if read-only
    bool user_writable(Rvar v);

    inline Rvar validate(Rvar v, Rvar def=v_none)
    {
        return is_valid(v) ? v : def;
    }
}
#endif
