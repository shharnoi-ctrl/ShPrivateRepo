///    \file Array_fw.h
///
///    \date 21 feb. 2018
///
///    \author  FJBurgos, jbm (at) embention.com
///    Company:  Embention
///
///    Array_fw class declaration.
///

#ifndef ARRAY_FW_H_
#define ARRAY_FW_H_

namespace Base
{

    template<typename T>
    class Array;

} // namespace Base

#endif // ARRAY_FW_H_
