#ifndef HPSET_H_
#define HPSET_H_

#include <Mblock.h>
#include <Bvar.h>
#include <Hbmapvar.h>
#include <Tcopy.h>
#include <Cptraits.h>
#include <Assertions.h>

namespace Bsp
{
    /// Bvar handler
    class Hbvar
    {
    public:
        class Range
        {
        public:
            /// Constructor with Given Parameters.
            /// \wi{18220}
            /// Range class shall build itself upon construction with its memory location range.
            /// \param[in] mb           Memory block.
            /// \param[in] from         Start range.
            /// \param[in] to_inclusive End range.
            Range(Base::Mblock<const volatile bool> mb,
                  Base::Bvar from,
                  Base::Bvar to_inclusive);

            /// Data Commiter.
            /// \wi{18221}
            /// Range class shall be able to copy the internal range data to its final memory allocation.
            void commit();

        private:
            /// Define Type_cp as a typedef representing a type capable of copying data between memory blocks
            /// of constant volatile bool and volatile bool types.
            typedef Base::Tcopy<Base::Cptraits::Array_memcpybool<
                Base::Mblock<const volatile bool>,
                Base::Mblock<volatile bool> > > Type_cp;
            /// Instantiate a Copy trait object which is able to write a memory block from a source to a destination.
            Type_cp cp;

            Range();                                ///< = delete;
            Range& operator=(const Range& orig);    ///< = delete
        };

        /// Hbvar Constructor.
        /// \wi{18222}
        /// Hbvar class shall build itself upon construction with given variable ID.
        /// \param[in] id0 Variable Index to be accessed (Base::Bvar).
        explicit Hbvar(Base::Bvar id0);

        /// Hbvar Variable Updater.
        /// \wi{7974}
        /// Hbvar class shall provide a method to set the value for a variable ID.
        /// \param[in] v0 Variable value to be set.
        void set(bool v0);

        /// Hbvar Variable Retriever.
        /// \wi{7970}
        /// Hrvar class shall provide a method to get the value for a variable ID.
        /// \return Variable value.
        bool get() const;

        /// Constant Volatile Reference Retriever.
        /// \wi{7967}
        /// Hbvar class shall be able to retrieve a constant and volatile 
        /// reference to a given Boolean variable ID value.
        /// \return Variable value reference.
        /// \pre This function will be implemented in all cores with read access to given memory block.
        const volatile bool& get_kref() const;

        /// Volatile Reference Retriever.
        /// \wi{18224}
        /// Hbvar class shall be able to retrieve a volatile reference to a given Boolean variable ID value.
        /// \return Variable reference from shared memory.
        /// \pre This function will be implemented in all cores with write access to given memory block.
        volatile bool& get_ref() const; 

        /// Constant Volatile Boolean Memory Block Retriever.
        /// \wi{18360} 
        /// Hbvar class shall be able to retrieve a constant and volatile memory block 
        /// from a given range of Boolean variable ID.
        /// \param[in] from Starting Boolean variable ID of the memory block.
        /// \param[in] to_inclusive Ending Boolean variable ID of the memory block.
        /// \return Variable value references to the specified range.
        /// \pre This function will be implemented in all cores with read access to the given memory block.
        static Base::Mblock<const volatile bool> get_kblock(Base::Bvar from, Base::Bvar to_inclusive);

        /// Volatile Boolean Memory Block Retriever.
        /// \wi{18361}
        /// Hbvar class shall be able to retrieve a volatile memory block 
        /// from a given range of Boolean variable IDs.
        /// \param[in] from Starting Boolean variable ID of the memory block.
        /// \param[in] to_inclusive Ending Boolean variable ID of the memory block.
        /// \return Variable value references to the specified range.
        /// \pre This function will be implemented in all cores with write access to the given memory block.
        static Base::Mblock<volatile bool> get_block(Base::Bvar from, Base::Bvar to_inclusive);

    private:
        const Base::Bvar id;

        // disabled
        Hbvar();                                ///< = delete
        Hbvar(const Hbvar& orig);               ///< = delete
        Hbvar& operator=(const Hbvar& orig);    ///< = delete
    };

    inline void Hbvar::Range::commit()
    {
        /// \alg
        ///  - Call to Tcopy::copy for ::cp, which bulks data from source memory block to destination memory block.
        cp.copy();
    }

}
#endif
