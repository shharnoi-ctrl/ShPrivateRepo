#ifndef MEMMGR_H__
#define MEMMGR_H__

#include <Allocator.h>

namespace Base
{
    /// Memory manager.
    /// The ::Base library shall provide the capability to manage the microcontroller's static memory.
    /// All requested memory is reserved and cannot be released. There are two types of memory being managed, 
    /// that which corresponds to external RAM memory and that which corresponds to the internal memory of 
    /// the microcontroller.
    /// Memory is requested using 'new_external' and 'new_internal'. If more memory is requested than available 
    /// in the manager while in debug mode, the program execution is halted.
    class Memmgr
    {
    public:
        enum Type
        {
            external     = 0,   ///< External memory Allocator index.
            internal     = 1    ///< Internal memory Allocator index.
        };
        static const Uint16 mem_type_max = 2;   ///< Number of memory allocators.

        /// Memory Manager Instance Retriever.
        /// \wi{5611}
        /// Memmgr class shall be able to retrieve the instance of the memory manager.
        /// \return Instance of the memory manager.
        /// \rat One object of Memmgr is needed to coordinate actions across the system.
        static Memmgr& get_instance();

        /// Memory Manager Allocator Addition.
        /// \wi{19467}
        /// Memmgr class shall provide the capability to add an Allocator to the memory manager list.
        /// \param[in] t        Memory type.
        /// \param[in] alloc    Allocator of the memory buffer.
        static void add_allocator(Type t, Allocator& alloc);

        /// Memory Manager Allocator Closer.
        /// \wi{5614}
        /// Memmgr class shall provide the capability to lock the memory allocation after the allocation stage.
        void close_allocation();

        /// Memory Manager Correct Allocator Checker.
        /// \wi{6232}
        /// Memmgr class shall provide the capability to check memory allocation on power-up after locking 
        /// the allocation.
        /// \return True if allocation has not failed in any point, False otherwise.
        bool get_alloc_ok() const;

        /// Memory Manager Allocator Retriever.
        /// \wi{5613}
        /// Memmgr class shall be able to retrieve the allocated memory from the system memory manager.
        /// \param[in] type0    Memory type.
        /// \return Allocator for given memory type.
        Allocator& get_allocator(Type type0);

    private:
        Allocator* allocators[mem_type_max];        ///< Array of pointers to internal and external allocators.
        bool init_stage;                            ///< True during initialization.

        /// Memory Manager Private Default Constructor.
        /// \wi{5612}
        /// Memmgr class shall build itself upon construction and initialize its internal members. It shall 
        /// be restricted to one 'single' instance of the class.
        /// \rat One object of Memmgr is needed to coordinate actions across the system.
        Memmgr();
        /// Memory Manager Private Constructor with Given Parameters.
        /// \wi{19484}
        /// Msg_data class shall build itself upon construction with external and internal Allocator instances.
        /// \param[in] internal_alloc       Internal memory Allocator.
        /// \param[in] external_alloc       External memory Allocator.
        /// \rat One object of Memmgr is needed to coordinate actions across the system.
        Memmgr(Allocator& internal_alloc, Allocator& external_alloc);

        Memmgr(const Memmgr& mgr0);                 ///< = delete.
        Memmgr& operator= (const Memmgr& copy);     ///< = delete.
    };

    inline bool Memmgr::get_alloc_ok() const
    {
        /// \alg
        /// - Return result of the bitwias AND operation between the NOT ::init_state, the retrieved value by 
        /// Allocator::get_alloc_ok for the internal memory Allocator, and the retrieved value by 
        /// Allocator::get_alloc_ok for the external memory Allocator.
        return (!init_stage) && (allocators[internal]->get_alloc_ok() && allocators[external]->get_alloc_ok());
    }
}
#endif
