#ifndef ENTYPES_H__
#define ENTYPES_H__

#include <stdint.h>

// Note: Texas instruments does not not define in stdint uint8_t nor int8_t, that's why
// both are defined without reference a type defined by stdint.

#ifndef __TMS320C2000__
#include <Entypes_arm.h>
#else
#include <Entypes_C2000.h>
#endif

#endif
