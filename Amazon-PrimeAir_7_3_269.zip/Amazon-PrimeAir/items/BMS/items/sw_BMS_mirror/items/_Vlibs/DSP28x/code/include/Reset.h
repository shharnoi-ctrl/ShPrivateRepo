#ifndef RESETIF_H_
#define RESETIF_H_

#include <Idisable.h>
#include <Ireset.h>

namespace Dsp28335_ent
{
    /// \brief Reboot the system safely.
    class Reset : public Base::Ireset
    {
    public:
        /// Reset Constructor.
        /// \wi{7774}
        /// Reset shall build itself upon contruction with the specified parameter.
        /// \param[in] idisable0    Disable interface.
        explicit Reset(Idisable& idisable0);

        /// Perform Reset.
        /// \wi{17629}
        /// Reset shall provide the capability to perform the system reset.
        static void reset0();
        /// Reset.
        /// \wi{7775}
        /// Reset shall provide the capability to implement a reset method defined in Ireset interface.
        virtual void reset() const;

    private:
        Idisable& idisable;     ///< Interface to disable peripherals.

        Reset();
        Reset(const Reset& orig); ///< = delete
        Reset& operator=(const Reset& orig); ///< = delete
    };

    inline Reset::Reset(Idisable& idisable0):
            idisable(idisable0)
    {
    }
}
#endif
