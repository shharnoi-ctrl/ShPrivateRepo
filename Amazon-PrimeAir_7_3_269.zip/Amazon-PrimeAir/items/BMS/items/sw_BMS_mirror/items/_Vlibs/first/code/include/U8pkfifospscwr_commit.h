#ifndef U8PKFIFOSPSCWR_COMMIT_H_
#define U8PKFIFOSPSCWR_COMMIT_H_

#include <U8pkmblock.h>
#include <Ttraits.h>

namespace Base
{
    /// The Base library shall provide a class to manage packed block of FIFO 
    /// SPSC bytes with commit/discard option for writes.
    class U8pkfifospscwr_commit : public type_is<Uint8>
    {
    public:
        /// Writer Packed Block of FIFO SPSC Bytes Constructor with Given Packed Block of Bytes.
        /// \wi{20739}
        /// U8pkfifospscwr_commit class shall build itself upon construction with packed block of bytes.
        /// \param[in] v U8pkmblock which is used to build U8pkfifospscwr_commit.
        explicit U8pkfifospscwr_commit(const U8pkmblock& v);

        /// Writer Packed Block of FIFO SPSC Bytes Constructor with Given FIFO Size and Memory Type.
        /// \wi{20740}
        /// U8pkfifospscwr_commit class shall build itself upon construction with FIFO size and memory type.
        /// \param[in] sz size of FIFO.
        /// \param[in] mtype Memory type where FIFO will be stored.
        U8pkfifospscwr_commit(Uint32 sz, Memmgr::Type mtype);

        /// Writer Packed Block of FIFO SPSC Bytes Writer.
        /// \wi{20741}
        /// U8pkfifospscwr_commit class shall provide the capability to write an element in temporary FIFO queue.
        /// \param[in] element The element to write.
        /// \return True if write has been possible, False otherwise.
        bool write(Uint8 element);

        /// Writer Packed Block of FIFO SPSC Bytes Reader.
        /// \wi{20742}
        /// U8pkfifospscwr_commit class shall provide the capability to read an element of commited FIFO queue.
        /// \param[out] element The element to read.
        /// \return True if read has been possible, False otherwise.
        bool read(Uint8& element);

        /// Writer Packed Block of FIFO SPSC Bytes Read Availability Checker.
        /// \wi{20743}
        /// U8pkfifospscwr_commit class shall provide the capability 
        /// to check if there are values to be read in the buffer.
        /// \return True if there are values to read, False otherwise.
        bool rd_available() const;

        /// Writer Packed Block of FIFO SPSC Bytes Write Availability Checker.
        /// \wi{20744}
        /// U8pkfifospscwr_commit class shall provide the capability 
        /// to check if there is a space to write in the buffer.
        /// \return True if there are space to write in buffer, False otherwise.
        bool wr_available() const;

        /// Writer Packed Block of FIFO SPSC Bytes Free Space Retriever.
        /// \wi{20745}
        /// U8pkfifospscwr_commit class shall provide the capability 
        /// to retrieve available free space.
        /// \return The number of free elements available to write.
        Uint32 wr_available_cnt() const;

        /// Writer Packed Block of FIFO SPSC Bytes Commit Write Pointer.
        /// \wi{20746}
        /// U8pkfifospscwr_commit class shall provide the capability 
        /// to commit write pointer to the public write index.
        void commit();

        /// Writer Packed Block of FIFO SPSC Bytes Discard Write Pointer.
        /// \wi{20747}
        /// U8pkfifospscwr_commit class shall provide the capability 
        /// to discard write pointer from the public write index.
        void discard();

    private:
        /// Writer Packed Block of FIFO SPSC Bytes Next Pointer Retriever.
        /// \wi{20748}
        /// U8pkfifospscwr_commit class shall provide the capability to retrieve the next pointer index.
        /// \param[in] prv Previous pointer index. 
        /// \return The next pointer index.
        Uint32 next(Uint32 prv) const;

        U8pkmblock v;   ///< Queue buffer.
        Uint32 rd;      ///< Read index.
        Uint32 wr;      ///< Write index.
        Uint32 wrp;     ///< Public write index (committed).

        U8pkfifospscwr_commit();                                                ///< = delete.
        U8pkfifospscwr_commit(const U8pkfifospscwr_commit& orig);               ///< = delete.
        U8pkfifospscwr_commit& operator=(const U8pkfifospscwr_commit& orig);    ///< = delete.
    };

    inline bool U8pkfifospscwr_commit::rd_available() const
    {
        /// \alg
        /// - If ::rd NOT equal to ::wrp return True, Else return False.
        return (rd != wrp);
    }

    inline bool U8pkfifospscwr_commit::wr_available() const
    {
        /// \alg
        /// - If ::rd NOT equal to retrieved value by ::next with ::wr return True, Else return False.
        return rd != next(wr);
    }

    inline Uint32 U8pkfifospscwr_commit::wr_available_cnt() const
    {
        /// \alg
        /// <ul>
        /// <li> If ::wr pointer is greater or equal to ::rd one: <ul>
        /// <li> Return ::wr-::rd. </ul>
        /// <li> Else: <ul>
        /// <li> Call U8pkmblock_k::size for ::v and add the retreived value with ::wr.
        /// <li> Subtract the previous computed value with ::rd and return the final computed count value. </ul>
        /// </ul>
        return (wr>=rd) ? wr-rd : wr+v.size()-rd;
    }

    inline Uint32 U8pkfifospscwr_commit::next(Uint32 prv) const
    {
        /// \alg
        /// <ul>
        /// <li> If given "prv" is greater than or equal to the retrieved queue buffer size by 
        /// U8pkmblock_k::size for ::v minus 1: <ul>
        /// <li> Return 0. </ul>
        /// <li> Else: <ul>
        /// <li> Return given "prv" + 1. </ul>
        /// </ul>
        return (prv>=(v.size()-1)) ? 0 : (prv+1);
    }

    inline void U8pkfifospscwr_commit::commit()
    {
        /// \alg
        /// - Assign ::wr to ::wrp.
        wrp = wr;
    }

    inline void U8pkfifospscwr_commit::discard()
    {
        /// \alg
        /// - Assign ::wrp to ::wr.
        wr = wrp;
    }
}
#endif
