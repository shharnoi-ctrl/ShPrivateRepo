#ifndef KSTRING_H__
#define KSTRING_H__

#include <Array.h>

namespace Base
{
    /// The Base library shall provide a structure to create and manipulate constant character strings. This
    /// structure shall only be used for literals, or equivalently to a 'const char*'. For modifiable text 
    /// strings, the Vstring structure must be used.
    /// \pre The stored string may not include a char '0' at the end, so stdlib methods (strlen, strcat, etc.)
    /// shall not be used to work with it.
    struct Kstring : protected Array<char>
    {
    public:
        /// Empty Constant Character String Retriever.
        /// \wi{5094}
        /// Kstring structure shall provide the capability to create an empty character string.
        /// \return Empty constant character string.
        static const Kstring& get_empty();

        const Array<char>& k; ///< Reference to access to all constant methods of the base Array.

        /// Constant Character String Constructor with Given String.
        /// \wi{5091}
        /// Kstring structure shall build itself upon construction with a string.
        /// \param[in] str      Character string.
        explicit Kstring(const char* str);

        /// Constant Character String Constructor with Given String and Size.
        /// \wi{20932}
        /// Kstring structure shall build itself upon construction with a string and its size.
        /// \param[in] str      Character string.
        /// \param[in] sz       Size of the string.
        explicit Kstring(const char* str, Uint32 sz);


        /// Constant Character String Copier Constructor.
        /// \wi{20933}
        /// Kstring structure shall build itslef upon contruction from another constant character string.
        /// \param[in] str      Kstring instance.
        Kstring(const Kstring& str);

        /// Constant Character String Length Retriever.
        /// \wi{5092}
        /// Kstring structure shall be able to retrieve the length of the string.
        /// \return Number of valid characters from the start to the end or the first 0.
        Uint32 length() const;
    
        /// Constant Character String Length of Given String Retriever.
        /// \wi{5093}
        /// Kstring structure shall provide the capability to obtain the length of a given string.
        /// \param[in] str      Character string from which to obtain the length.
        /// \param[in] max_len  Specifies max length to be checked (Default 0xFFFFFFFF).
        /// \return Number of valid characters from the start to the end or the first 0.
        static Uint32 strlen(const char* str, Uint32 max_len = 0xFFFFFFFF);

        /// Constant Character String Value Retriever.
        /// \wi{4467}
        /// Kstring structure shall be able to retrieve the char value at a given position.
        /// \param[in] index    Index from which to retrieve the char value.
        /// \return Char value if found, 0 otherwise.
        char char_at(Uint32 index) const;

    protected:
        /// Constant Character String Protected Constructor with Maximum Length and Memory Type.
        /// \wi{20934}
        /// Kstring structure shall build itself upon protected constructor with maximum length and
        /// memory type.
        /// \param[in] max_length   Maximum length.
        /// \param[in] type         Memory type.
        // This will be exclusively be called from Vstring. Used for creating with a given size.
        Kstring(Uint32 max_length, Memmgr::Type type);

    private:
        Kstring& operator=(const Kstring& src);     ///< = delete.
    };

    /// \alg
    /// - Array instance is initialized with given "str" and length of the given "str".
    /// - ::k is initialized with "this" instance.
    inline Kstring::Kstring(const char* str) :
        Array<char>( const_cast<char*>(str), strlen(str)),
        k(*this)
    {
    }

    /// \alg
    /// - Array instance is initialized with given "str" and with given "sz" If "str" is not a null pointer, zero 
    /// size otherwise.
    /// - ::k is initialized with "this" instance.
    inline Kstring::Kstring(const char* str, Uint32 sz) :
        Array<char>(const_cast<char*>(str), str ? sz : 0),
        k(*this)
    {
    }

    /// \alg
    /// - Array instance is initialized with pointer to the first element and size of the given "str".
    /// - ::k is initialized with "this" instance.
    inline Kstring::Kstring(const Kstring& str) :
        Array<char>(str.v, str.size()),
        k(*this)
    {
    }

    /// \alg
    /// - Array instance is initialized with given "max_length" and "type".
    /// - ::k is initialized with "this" instance.
    inline Kstring::Kstring(Uint32 max_length, Memmgr::Type type) :
        Array<char>(max_length, type),
        k(*this)
    {
    }

    inline Uint32 Kstring::length() const
    {
        /// \alg
        /// - Return retrieved value by ::strlen with ::v and ::n.
        return Kstring::strlen(v, n);
    }

    inline char Kstring::char_at(Uint32 index) const
    {
        /// \alg
        /// - Return element of Array at given "index" if "index" is lower than size of the Array, 0 otherwise.
        return (index<size()) ? operator[](index) : 0;
    }
}

#endif
