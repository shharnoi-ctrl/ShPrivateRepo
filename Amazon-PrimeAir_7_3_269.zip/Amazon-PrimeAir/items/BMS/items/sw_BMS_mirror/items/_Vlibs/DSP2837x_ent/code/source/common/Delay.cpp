#include <Delay.h>
#include <Ku16.h>
#include <Asm.h>

namespace Dsp28335_ent
{
    void Delay::ns_by_5(Uint16 ns5)
    {
        // This assumes main CPU is running at 200Mhz
        // ns5 is already in ACC
        asm_ALNOP();
    }

    void Delay::ns_by_50(Uint16 ns50)
    {
        // At 200Mhz, 10 cycles = 50ns
        while(ns50--)
        {
            asm_5NOP();    // 10 minus loop cycles (5)
        }
    }

    void Delay::us(Uint16 us)
    {
        //At 200Mhz 200cycles == 1us
        while(us--)
        {
            asm_195NOP();  //200 minus loop cicles
        }
    }

    void Delay::ms(Uint16 ms)
    {
        while(ms--)
        {
            us(Ku16::u1000);
        }
    }

    void Delay::ns_25()
    {
        //At 200Mhz 5 cycles == 25 ns
        ns_by_5(Ku16::u5);
    }
}
