#ifndef IRVECTOR3_FW_H__
#define IRVECTOR3_FW_H__

namespace Maverick
{
    class Irvector3;
}
#endif
