#include <SCIcfg.h>

#include <Enums.h>
#include <Kclk.h>
#include <Lossy_error.h>

namespace Dsp28335_ent
{
    SCIcfg SCIcfg::build(Uint32 spd0,
                   Length lng0,
                   Stop stp0,
                   Parity_bits par0,
                   bool use_addr_mode0)
    {
        SCIcfg cfg;
        cfg.speed         = spd0;
        cfg.length        = lng0;
        cfg.stop          = stp0;
        cfg.parity        = par0;
        cfg.use_addr_mode = use_addr_mode0;
        return cfg;
    }

    void SCIcfg::init()
    {
        static const Uint32 initial_speed = 115200;
        speed         = initial_speed;
        length        = SCIcfg::len_8;
        stop          = SCIcfg::stp_1;
        parity        = SCIcfg::par_dis;
        use_addr_mode = false;
    }

    bool SCIcfg::validate() const
    {

        static const Uint32 baudrate_max = Bsp::Kclk::get_lspclkfreq32()/8UL; // Maximum allowed baudrate
        static const Uint32 baudrate_min = 1 + baudrate_max/65536UL;          // Minimum allowed baudrate

        return Base::Enums::is_gtez(parity) && (parity < par_all) &&
               Base::Enums::is_gtez(length) && (length < len_all) &&
               Base::Enums::is_gtez(stop) && (stop < stp_all) &&
               (speed >= baudrate_min) && (speed <= baudrate_max);
    }

    void SCIcfg::cset(Base::Lossy_error& str)
    {
        str.get_uint32(speed);
        str.get_enum16(length);
        str.get_enum16(parity);
        str.get_enum16(stop);
        str.get_bool16(use_addr_mode);

        str.assrt(validate(), Base::err_sci);
    }

}
