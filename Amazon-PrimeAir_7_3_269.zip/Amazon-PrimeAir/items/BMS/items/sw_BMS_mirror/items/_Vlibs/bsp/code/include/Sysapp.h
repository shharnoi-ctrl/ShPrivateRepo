#ifndef SYSAPP_H_
#define SYSAPP_H_

#include <Entypes.h>

namespace Bsp
{
    /// System application identifiers
    // WARNING: modify both with Sysuid_utils::get_app_kstr definition
    enum Sysapp
    {
        sapp_none          =  0,  ///< (0) Undefined
        sapp_vbootloader   =  1,  ///< (1) Veronte Bootloader
        sapp_reserved      =  2,  ///< (2) Reserved
        sapp_uapp          =  3,  ///< (3) U-veronte application
        sapp_386_ccard     =  4,  ///< (4) 28388 Control card test.

        sapp_arb4xapp      =  6,  ///< (6) Arbiter app
        sapp_cex_lift_pwm  =  7,  ///< (7) CEX Lift PWM control board
        sapp_cex_jeti_tm   =  8,  ///< (8) CEX JETI telemetry board
        sapp_cex_v1_2      =  9,  ///< (9) CEX V1.2 board
        sapp_vmc_brushless = 10,  ///< (10) Veronte brushless controller
        sapp_vmc_stepper   = 11,  ///< (11) Veronte stepper controller
        sapp_cex_commex    = 12,  ///< (12) CEX commex board
        sapp_mc110         = 13,  ///< (13) MC110 brushless controller
        sapp_mc280         = 14,  ///< (14) MC280 brushless controller
        sapp_can_iso       = 15,  ///< (15) CAN Isolator
        sapp_cex2a         = 16,  ///< (16) CEX V2.0 board with Arincs
        sapp_cex2g         = 17,  ///< (17) CEX V2.0 board with GPIOs
        sapp_mc24          = 18,  ///< (18) MC24 brushless controller
        sapp_vsm           = 19,  ///< (19) Vehicle Specific Module
        sapp_mex           = 20,  ///< (20) MEX board
        sapp_mc_ipc        = 21,  ///< (21) MC IPC brushless controller
        sapp_reserved2     = 22,  ///< (22) Reserved
        sapp_mc110_v2      = 23,  ///< (23) MC110 v2 motor controller
        sapp_bms           = 24,  ///< (24) Battery Management System
        sapp_par           = 25,  ///< (25) Prime Air Recovery
        sapp_pam           = 26   ///< (26) Prime Air Monitor
    };

    static const Uint16 sysapp_all = sapp_mc110_v2 + 1U;    ///< Available Application types.
}
#endif
