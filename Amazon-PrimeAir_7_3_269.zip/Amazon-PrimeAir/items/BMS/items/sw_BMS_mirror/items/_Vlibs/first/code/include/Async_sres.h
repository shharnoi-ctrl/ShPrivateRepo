#ifndef ASYNC_SRES_H_
#define ASYNC_SRES_H_

namespace Base
{
    // Asynchronous "simple" return values for asynchronous methods
    enum Async_sres
    {
        asyncs_ongoing, ///< Last operation not finished.
        asyncs_done     ///< Last operation finished.
    };
}
#endif

