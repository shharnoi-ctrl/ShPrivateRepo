#include "../common/Default_isr.h" //PRQA S 1015

#include <Reset.h>
#include <Asm.h>

namespace Dsp28335_ent
{
    interrupt
    void Default_isr::isr()
    {
        asm_stop();
        Dsp28335_ent::Reset::reset0();
        for(;;)
        {
            ;
        }
    }
}
