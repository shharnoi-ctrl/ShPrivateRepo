#ifndef KU64_H_
#define KU64_H_

#include <Entypes.h>

namespace Ku64
{
    static const Uint64 u0=               static_cast<Uint64>(0);
    static const Uint64 u1=               static_cast<Uint64>(1);
    static const Uint64 u_max = static_cast<Uint64>(0xFFFFFFFFFFFFFFFF);
}

#endif
