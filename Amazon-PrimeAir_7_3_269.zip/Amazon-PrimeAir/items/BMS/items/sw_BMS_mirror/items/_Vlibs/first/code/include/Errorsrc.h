#ifndef ERRORSRC_H_
#define ERRORSRC_H_

namespace Base
{
    //PRQA S 1094 EOF # Allow lines with more than 120 chars for comments.
    /// Error source identifiers.
    /// \wi{13392}
    /// The ::Base library shall provide an ordered list of identifiers for each possible error, as: <ul>
    enum Errorsrc
    {
                                        /// <li> Basic errors (mainly for setup configurable):
                                        /// | Identifier | Content |
        err_ok                =   0,    /// | 0          | No errors detected |
        err_gpio              =   1,    /// | 1          | GPIOs function configuration |
        err_odt_pool_sz       =   2,    /// | 2          | Incorrect pool size in on-demand telemetry |
        err_telemetry_alloc   =   3,    /// | 3          | Could not allocate new telemetry vector |
        err_patch_type        =   4,    /// | 4          | Incorrect patch type |
        err_patch_needs_next  =   5,    /// | 5          | Selected type of patch needs a next |
        err_max_poly_evt      =   6,    /// | 6          | Maximum limit of polygon events reached |
        err_inside_evt_impl   =   7,    /// | 7          | The inside polygon event is not implemented in this version |
                                        /// | 8:9        | UNUSED |
        err_channelmgr        =  10,    /// | 10         | Channel manager configuration |
        err_blk_cmp_pdi       =  11,    /// | 11         | Incorrect deserialization of compiled block data |
        err_blk_cmp           =  12,    /// | 12         | Incorrect output in compiled block |
        err_blk_cmp_desc      =  13,    /// | 13         | Invalid pin description in compiled block |
                                        /// | 14         | UNUSED |
        err_sara              =  15,    /// | 15         | SARA sim type oor. |
        err_vblk_sensrtm      =  16,    /// | 16         | Block for SRTM sensor |
                                        /// | 17:22      | UNUSED |
        err_arcx              =  23,    /// | 23         | Arcade axis set of options. |
        err_msg8_consumer_hi  =  24,    /// | 24         | Custom message consumer cannot be used in HI unless it is an external sensor |
        err_can_consumer_hi   =  25,    /// | 25         | CAN Custom message consumer cannot be used in HI unless it is an external sensor |
        err_stg_ports         =  26,    /// | 26         | Not all available ports are being configured |
        err_modes             =  27,    /// | 27         | Stick configuration modes |
                                        /// | 28:40      | UNUSED |
        err_blkekfstp         =  41,    /// | 41         | Static pressure to EKF adapter block |
                                        /// | 42:44      | UNUSED |
        err_gnss_blocks       =  45,    /// | 45         | GNSS constellations configuration (more than allowed) |
                                        /// | 46         | UNUSED |
        err_cansuite_gpio     =  47,    /// | 47         | CAN suite gpio |
        err_vrng              =  48,    /// | 48         | Range sensors |
        err_fmset             =  50,    /// | 50         | Custom message set |
                                        /// | 51:53      | UNUSED |
        err_pwm               =  54,    /// | 54         | Pwm configuration |
                                        /// | 55:62      | UNUSED |
        err_sniffer           =  63,    /// | 63         | Sniffer wires configuration |
        err_sniffer_read_only =  64,    /// | 64         | Read-only variable selected in sniffer |
        err_fmsgc_read_only   =  65,    /// | 65         | Read-only variable selected in serial message consumer |
        err_canmsgc_read_only =  66,    /// | 66         | Read-only variable selected in CAN message consumer |
        err_vref_read_only    =  67,    /// | 67         | Read-only vref variable |
        err_obstacle          =  68,    /// | 68         | Incorrect type of obstacle. |
        err_obsense           =  69,    /// | 69         | Obstacle sensing mode or type oor. |
                                        /// | 70         | UNUSED |
        err_marks             =  71,    /// | 71         | Incorrect type of mark. |
        err_ext_nav_sen       =  72,    /// | 72         | Incorrect external navigation sensor configuration. |
                                        /// | 73         | UNUSED |
        err_fmsg_p            =  74,    /// | 74         | Custom message producers msg id oor. |
        err_fmsg_c            =  75,    /// | 75         | Custom message consumers process parser oor. |
        err_fmsgcan_c         =  76,    /// | 76         | CAN custom msg consumer msg id oor. |
        err_telem             =  77,    /// | 77         | Telemetry configuration |
        err_fmsg_p_sz         =  78,    /// | 78         | Custom message producer occupancy is higher than allowed |
        err_fmsg_c_sz         =  79,    /// | 79         | Custom message consumer occupancy is higher than allowed |
                                        /// | 80         | UNUSED |
        err_sci               =  81,    /// | 81         | SCI config error |
        err_events            =  82,    /// | 82         | Invalid event |
        err_actions           =  83,    /// | 83         | Actmgr - List of actions. |
        err_evact             =  84,    /// | 84         | Actmgr - List of related events and actions. |
        err_cmd_not_allowed   =  85,    /// | 85         | Commands not allowed |
                                        /// | 86         | UNUSED |
        err_xpc_can_in        =  87,    /// | 87         | XPC for CAN messages input filters size ok |
        err_xpc_can_out       =  88,    /// | 88         | XPC for CAN messages output filters size ok |
        err_xpc_can_ser       =  89,    /// | 89         | XPC for CAN messages serialtocan size ok |
        err_xpc_can_gpio      =  90,    /// | 90         | XPC for CAN messages virtual gpios size ok |
        err_xpc_can_map       =  91,    /// | 91         | XPC for CAN messages and check their priority and connections. |
        err_xpc_u8_map        =  92,    /// | 92         | XPC for u8 messages and check their priority and connections. |
        err_internest         =  93,    /// | 93         | Internest version in rage |
        err_internest1        =  94,    /// | 94         | Internest max_range_vbase in rage |
        err_internest2        =  95,    /// | 95         | Internest max_range_vexplore in rage |
        err_gravity_ext       =  96,    /// | 96         | Incorrect gravity extractor for AHRS configuration |
        err_u8pkrsarray_size  =  97,    /// | 97         | Incorrect size for U8pkrsarray |
                                        /// | 98:100     | UNUSED |
        err_ecap              = 101,    /// | 101        | Capture. |
                                        /// | 102:115    | UNUSED |
        err_cappulse          = 116,    /// | 116        | ECAP pulse consumers |
        err_i2cdevs           = 117,    /// | 117        | I2C external devices |
                                        /// | 118-119    | UNUSED |
        err_lossy_resize      = 120,    /// | 120        | Lossy resize error |
        err_rvector_resize    = 121,    /// | 121        | Rvector resize error |
        err_asciiparser       = 122,    /// | 122        | ASCII parser invalid configuration |
        err_telemetry_exceeded= 123,    /// | 123        | Telemetry size exceeded |
                                        /// | 122:131    | UNUSED |
        err_navsim_vars       = 132,    /// | 132        | Variables configured in simulated navigation exceed maximum allowed size |
                                        /// | 133:153    | UNUSED |
        err_hi_3210_rx_tout   = 154,    /// | 154        | HI-3210 rx cannot be configured |
        err_hi_3210_tx_tout   = 155,    /// | 155        | HI-3210 tx cannot be configured |
        err_arbiter_cfg       = 156,    /// | 156        | Arbiter production configurable invalid |
        err_can_arbiter_cfg   = 157,    /// | 157        | CAN Arbiter configuration has not consistency with production file or/and it is invalid |
                                        /// </li>

        // COMMAND ENUMS, update cset of Actions if this enum changes
                                        /// <li> Command errors:
                                        /// | Identifier | Content |
        err_cmd_rdvzset       = 176,    /// | 176        | Rendezvous command base_yaw oor |
                                        /// | 177:182    | UNUSED |
        err_cmd_taxiget       = 183,    /// | 183        | Taxi guidance request command. |
                                        /// | 184:187    | UNUSED |
        err_cmd_gtrack1       = 188,    /// | 188        | Invalid detour command |
        err_cmd_gtrack2       = 189,    /// | 189        | Invalid guidance block configuration. |
                                        /// | 190-191    | UNUSED |
        err_cmd_speed         = 192,    /// | 192        | Cruise speed command |
        err_cmd_gtrack        = 193,    /// | 193        | Invalid detour command |
        err_cmd_gtrkset       = 194,    /// | 194        | Track request command |
                                        /// | 195:207    | UNUSED |
        err_cmd_stksrcr       = 208,    /// | 208        | Get stick raw channels from selected source |
                                        /// | 209:211    | UNUSED |
        err_cmd_vtolset       = 212,    /// | 212        | VTOL request command |
        err_ini_nok           = 213,    /// | 213        | Cannot change to a phase different from INI with System BIT not OK and out of PDI mode. |
                                        /// | 214        | UNUSED |
        err_cmd_nav           = 215,    /// | 215        | Navigation command |
        err_cmd_gpio          = 218,    /// | 218        | GPIO command |
        err_cmd_gpio1         = 219,    /// | 219        | GPIO command |
        err_cmd_gpio2         = 220,    /// | 220        | GPIO command |
        err_cmd_gpio3         = 221,    /// | 221        | GPIO command |
        err_cmd_phase         = 222,    /// | 222        | Commanded phase is out of range |
        err_cmd_gimbal1       = 224,    /// | 224        | Gimbal commands |
        err_cmd_gimbal        = 225,    /// | 225        | Gimbal commands |
                                        /// | 226:234    | UNUSED |
        err_cmd_var           = 235,    /// | 235        | Variable set command |
                                        /// | 236:238    | UNUSED |
        err_reset             = 239,    /// | 239        | Reset CPU IRX |
                                        /// </li>

                                        /// <li> Other errors (mainly for setup configurable):
                                        /// | Identifier | Content |
        err_rtable_ttl        = 255,    /// | 255        | Invalid Routing table TTL |
        err_rtable_idx        = 256,    /// | 256        | Invalid Routing table index |
        err_acc2filt          = 257,    /// | 257        | Bosch IMU BMI088 (IMU2) Accelerometer filter |
        err_imu3_filter       = 258,    /// | 258        | ADIS16505 IMU filter not in range [0,6] |
        err_imu3_filter_bw    = 259,    /// | 259        | ADIS16505 IMU filter not compatible with Bandwidth limit |
        err_imu3_delta        = 260,    /// | 260        | ADIS16505 IMU invalid rate limit |
        err_imu2_delta        = 261,    /// | 261        | Bosch IMU BMI088 (IMU2) invalid rate limit |
                                        /// | 262:287    | UNUSED |
        err_cansuite_in       = 288,    /// | 288        | CAN suite producer for veronte |
        err_cansuite_out      = 289,    /// | 289        | CAN suite consumer for veronte |
        err_cfg_can           = 290,    /// | 290        | CAN cfg |
        err_resize_can_cex    = 291,    /// | 291        | CEX CAN cfg |
        err_resize_can_commex = 292,    /// | 292        | COMMEX CAN cfg |
        err_jeti_and_lift     = 293,    /// | 293        | Trying to configure jeti and lift (not enough memory) |
                                        /// | 294:499    | UNUSED |
        err_can_fd_arb_timing   = 498,  /// | 498        | Invalid timings for CAN-FD arbitration frame. |
        err_can_fd_data_timing  = 499,  /// | 499        | Invalid timings for CAN-FD data frame. |
        err_relf                = 500,  /// | 500        | Tried to set feature relative to invalid feature, or set relative an "absolute-only" feature |
        err_jid                 = 501,  /// | 501        | Invalid feature |
        err_canid               = 502,  /// | 502        | Invalid CAN id |
        err_cfgid_mode0         = 503,  /// | 503        | Invalid Cfgid PDI (number of PDIs does not match) |
        err_cfgid_mode1         = 504,  /// | 504        | Invalid Cfgid PDI mode |
        err_cmd_mgr             = 505,  /// | 505        | Expected command size does not match. |
        err_cmd_mgr1            = 506,  /// | 506        | Expected command size does not match. |
        err_cancfg              = 507,  /// | 507        | Invalid CAN configuration |
        err_decimator           = 508,  /// | 508        | Invalid decimator |
        err_sci_cfg             = 509,  /// | 509        | Invalid SCI configuration |
        err_field1              = 510,  /// | 510        | Maximum ID of real variable exceeded. |
        err_field2              = 511,  /// | 511        | Maximum ID of user variable exceeded. |
        err_field3              = 512,  /// | 512        | Maximum ID of bit variable exceeded. |
        err_field4              = 513,  /// | 513        | Maximum number of decimals for real variable exceeded. |
        err_field5              = 514,  /// | 514        | Overflow for real variable detected. |
        err_field6              = 515,  /// | 515        | Incorrect CRC field |
        err_field7              = 516,  /// | 516        | Field matcher number of bits outside range |
        err_field8              = 517,  /// | 517        | Field maximum skippable bits exceeded |
        err_field9              = 518,  /// | 518        | Maximum ID of real variable saved as string exceeded. |
        err_field10             = 519,  /// | 519        | Field type out of range. |
        err_flogic              = 520,  /// | 520        | Invalid event composition (Flogic). |
        err_flogic1             = 521,  /// | 521        | Invalid event composition (Flogic). |
        err_flogic2             = 522,  /// | 522        | Invalid event composition type. |
        err_fref                = 523,  /// | 523        | Invalid type of position reference. |
        err_irxtable            = 524,  /// | 524        | Invalid 3Dtable mode or vector is non-decreasing. |
        err_limit               = 525,  /// | 525        | Invalid limit event type. |
        err_lsm6ds3_cfg         = 526,  /// | 526        | Accelerometer/Gyroscope settings outside range. |
        err_pdi_ver             = 527,  /// | 527        | Incompatible PDI version, there are some PDI files in Veronte from a different version. Try migrating offline and uploading a complete migrated configuration. |
        err_rvarsensor          = 528,  /// | 528        | Id for Rvar out of range for Rvarsensor. |
        err_stickrawtrans0      = 529,  /// | 529        | K value in stick outside range [-100, 100] or 0. |
        err_stickrawtrans1      = 530,  /// | 530        | Maximum value read from stick for Configured range exceeded [4095]. |
        err_stickrawtrans2      = 531,  /// | 531        | Maximum value read from stick for Raw stick trim exceeded [4095] |
        err_stickrawtrans3      = 532,  /// | 532        | Invalid transformation type for stick. |
                                        /// | 533:535    | UNUSED |
        err_stickcfg3           = 536,  /// | 536        | Invalid destination of stick device data. |
        err_tllhcompressed      = 537,  /// | 537        | Longitude/Latitude outside range [-pi, pi]/[-0.5pi, 0.5pi]. |
        err_tunpatchset0        = 538,  /// | 538        | Patch selected as first has not been enabled. |
        err_tunpatchset1        = 539,  /// | 539        | Patch selected as next has not been enabled. |
        err_tunpatchset2        = 540,  /// | 540        | Patch type does not exist. |
        err_tunpatchset3        = 541,  /// | 541        | The route cannot have two consecutive patches of type point. |
        err_tunpatchset4        = 542,  /// | 542        | Patchtype orthodrome has not been enabled. |
        err_tunpatchset5        = 543,  /// | 543        | Patchtype arc has not been enabled. |
        err_tunpatchset6        = 544,  /// | 544        | Patchtype ellipse has not been enabled. |
        err_tunpatchset8        = 546,  /// | 546        | No patchtype has been enabled. |
        err_Ubxcfgnav5          = 547,  /// | 547        | Dynmodel out of range or incorrect UTC time. |
        err_Ubxcfgnavx5         = 548,  /// | 548        | Maximum acceptable AssistNow Autonomous orbit error outside range [5, 1000]. |
        err_Ubxcfgport          = 549,  /// | 549        | Port (for Ubx?) is neither SPI nor SCI. |
        err_Ubxcfgrate          = 550,  /// | 550        | Invalid Ublox configuration rate |
        err_Ubxcfgsbas          = 551,  /// | 551        | Maximum number of SBAS prioritized tracking channels exceeded [3]. |
        err_atunarray0          = 552,  /// | 552        | Invalid Tunarray index |
        err_atunarray1          = 553,  /// | 553        | Invalid Tunarray size |
        err_Ubxcfgtmode3        = 554,  /// | 554        | Error in receiver mode, neither enabled nor disabled. |
        err_Uclk                = 555,  /// | 555        | Invalid chrono event |
        err_Uvarsensor          = 556,  /// | 556        | Id for Uvar out of range for Uvarsensor, or desired frequency too low (<1Hz). |
        err_Uclkmgr             = 557,  /// | 557        | Maximum number of event user chronos exceeded |
        err_varinit0            = 558,  /// | 558        | Maximum array size exceeded on initial values for user variables. |
        err_varinit1            = 559,  /// | 559        | Initialized variable is unwritable. |
        err_vref0               = 560,  /// | 560        | Maximum ID of Rvar variable exceeded in Vref. |
        err_vref1               = 561,  /// | 561        | Maximum ID of Uvar variable exceeded in Vref. |
        err_vref2               = 562,  /// | 562        | Maximum ID of Bvar variable exceeded in Vref. |
        err_vref3               = 563,  /// | 563        | Invalid type of variable in Vref. |
        err_xclkcfg0            = 564,  /// | 564        | Period time non positive in event. |
        err_xclkcfg1            = 565,  /// | 565        | Invalid period mode. |
        err_xclkcfg2            = 566,  /// | 566        | Chrono position direction not correctly normalized. |
        err_xclkcfg3            = 567,  /// | 567        | Invalid type of chrono. |
        err_blk_batch           = 570,  /// | 570        | Maximum allowed block nesting depth exceeded [6] or incorrect number of inputs/outputs for block Patch. |
        err_blk_ifelse          = 571,  /// | 571        | Error in the connections for block if/else. |
        err_blk_switch          = 572,  /// | 572        | Error in the connections for block switch. |
        err_blk_switch0         = 573,  /// | 573        | Invalid switch/ifelse/phase block configuration. |
        err_blkmgr              = 574,  /// | 574        | Invalid block manager configuration. |
        err_pinmux              = 576,  /// | 576        | Invalid switch/ifelse/phase block output configuration. |
        err_blk_switchmap       = 577,  /// | 577        | Invalid mapping to cases in switch/phase block. |
                                        /// | 578        | UNUSED |
        err_accellimit          = 579,  /// | 579        | Envelope's falling or rising edge is out of accepted limits |
                                        /// | 580        | UNUSED |
        err_polygrp             = 581,  /// | 581        | Index of polygon for group outside of range. |
        err_polygon             = 582,  /// | 582        | Less than 3 polygon vertices. |
        err_circle              = 583,  /// | 583        | Circle radius is less than or equal to 0. |
        err_height              = 584,  /// | 584        | Height type is neither relative nor absolute. |
        err_heightabs           = 585,  /// | 585        | Invalid absolute height type. |
        err_rwy                 = 586,  /// | 586        | Invalid runway preferred type. |
        err_driver              = 588,  /// | 588        | Problem in Driver block configuration. |
        err_mwk                 = 592,  /// | 592        | Gyroscope measurement error. |
        err_opinctrl            = 593,  /// | 593        | Invalid PID controller input type. |
        err_pid                 = 594,  /// | 594        | Invalid PID integral configuration (tau must be >= 0).
        err_prediction          = 595,  /// | 595        | Error in the Model Prediction Control algorithm. Prediction Horizon out of range or zero diagonal matrix R. |
        err_sysid               = 596,  /// | 596        | Error ID for given pdi check. |
        err_tsched              = 597,  /// | 597        | Error ID for given pdi check. |
        err_dwma                = 598,  /// | 598        | Error ID for given pdi check. |
        err_iir                 = 599,  /// | 599        | Error ID for given pdi check. |
        err_butterworth         = 600,  /// | 600        | Error ID for given pdi check. |
        err_usre2               = 601,  /// | 601        | Error incorrect user sensor variance. |
                                        /// | 602        | UNUSED |
        err_ubxcfgtp5           = 603,  /// | 603        | Ublox time pulse configuration. |
        //TODO REMOVE securd mode for Vlibs#9631 
        err_cfgmgr_load_secure  = 604,  /// | 604        | Error loading secure mode. |
        err_cfgmgr_finit        = 605,  /// | 605        | Error PDI files. |
        err_cfgmgr_timeout      = 606,  /// | 606        | Error; timeout while loading PDIs. |
        err_invalidrotmat       = 607,  /// | 607        | Invalid rotation matrix (cannot be inverted) |
        err_flyto_setup         = 608,  /// | 608        | Error in fly to waypoint action |
        err_vblk_apsel          = 609,  /// | 609        | Invalid block AP selection configuration, channel exceeds maximum number |
        err_vblk_arcade_bounce  = 610,  /// | 610        | Error in the connections for block Arcade Bounce. |
        err_vblk_arcade_extend  = 611,  /// | 611        | Error in the connections for block Arcade Extend. |
        err_vblk_btor           = 612,  /// | 612        | Error in the connections for bool to real block. |
        err_vblk_bound          = 613,  /// | 613        | Error in the connections for block Bound. |
        err_rldcfg0             = 614,  /// | 614        | Invalid dynamic pressure EKF entrance configuration. |
        err_smoothvar           = 615,  /// | 615        | Smoother error. |
        err_ubx_tout0           = 616,  /// | 616        | Could not receive ACKs from UBlox. |
        err_ubx_tout1           = 617,  /// | 617        | Could not receive polling from Ublox. |
        err_ubx_nack            = 618,  /// | 618        | A Ublox configuration message was rejected by a Ublox device (GNSS). |
        err_guid_pid            = 619,  /// | 619        | Invalid type of guidance controller. |
        err_cmd_leg             = 620,  /// | 620        | Guidance uses an invalid runway or site. |
        err_mixarray            = 622,  /// | 622        | Error in mixarray construction (possibly there is not enough RAM memory to store all the blocks). |
        err_xrtable             = 623,  /// | 623        | Invalid number of entries for XrTable. |
        err_blk_varset          = 624,  /// | 624        | Block trying to write in an invalid variable, possibly the selected variable is not user writable. |
        err_tuntrait            = 625,  /// | 625        | Error trying to resize an array out of its maximum size. |
        err_asuite              = 626,  /// | 626        | Selected dynamic pressure sensor is not valid in this hardware version. |
        err_xpcmap              = 627,  /// | 627        | Invalid producer/consumer in I/O connections. |
        err_blk_arraysplit      = 628,  /// | 628        | Invalid block: array of less than 2 elements cannot be split. |
        err_blk_array           = 629,  /// | 629        | Bundle block error, it must have more than one input and the input sizes must be one. |
        err_vblk_varget         = 630,  /// | 630        | Invalid ID for block Read Real. |
        err_vblk_vec_ops        = 631,  /// | 631        | Error in either; Vector: Add, Subtract, Cross product or Matrix rotation. |
        err_autotune            = 633,  /// | 633        | Invalid maximum duration of autotuning process or invalid number of stages for FFT. |
        err_vblk_azeld1         = 634,  /// | 634        | Error in the connections for block azeld -> xyz. |
        err_vblk_azeld          = 635,  /// | 635        | Error in the connections for block xyz -> azeld. |
        err_vblk_dot            = 636,  /// | 636        | Error in the connections for block Dot Product. |
        err_vblk_enctrl         = 637,  /// | 637        | Error in the connections for block Energy Control or invalid conversion factor from speed difference to desired acceleration. |
        err_vblk_bnxb1          = 638,  /// | 638        | Error in the connections for block(s) AND/OR. |
        err_vblk_r1xr1          = 639,  /// | 639        | Error in the connections for block |x| or invalid subfunction for the block. |
        err_vblk_r2xr1          = 640,  /// | 640        | Error in the connections for block x+y or invalid subfunction for the block. |
        err_vblk_rnxr1          = 641,  /// | 641        | Error in the connections for block(s) Multiply/Add Elements/Norm or invalid subfunction for the block(s). |
        err_vblk_iir            = 642,  /// | 642        | Error in the connections for block IIR Filter or invalid parameters for the transfer function. |
        err_vblk_kmultvec       = 643,  /// | 643        | Error in the connections for block Scale. |
        err_vblk_manual         = 644,  /// | 644        | Error in the connections for block Manual or invalid stick control channel. |
        err_vblk_minmax         = 645,  /// | 645        | Error in the connections for block(s) Min/Max. |
        err_vblk_mix            = 646,  /// | 646        | Error in the connections for block MIX or invalid mix control channel. |
        err_vblk_movern         = 647,  /// | 647        | Error in the connections for block MIX Move. |
        err_vblk_not            = 648,  /// | 648        | Error in the connections for block NOT. |
        err_vblk_phase          = 649,  /// | 649        | Default case does not exist for block Phase Switch. |
        err_vblk_tsched         = 651,  /// | 651        | Error in the connections for block T-Sched PID. |
        err_vblk_pid            = 652,  /// | 652        | Invalid configuration or connection of a PID block. |
        err_vblk_poly           = 653,  /// | 653        | Error in the connections for block Polynomial. |
        err_vblk_posset         = 654,  /// | 654        | Error in the connections for block Write Feature or Fid is not user writable. |
        err_vblk_predictive     = 655,  /// | 655        | Error in the connections for block Predictive Control or number of elements for numerator/denominator unmatched to the expected input size. |
        err_vblk_ramp           = 656,  /// | 656        | Error in the connections for block Ramp or rise time/settling time less than (or equal to) 0 . |
        err_vblk_matvec         = 657,  /// | 657        | Error in the connections for block Linear Transformation or matrix size unmatched to the expected input size. |
        err_vblk_rtable3d       = 658,  /// | 658        | Error in the connections for block 3D Table Interpolation. |
        err_vblk_rtob           = 659,  /// | 659        | Error in the connections for block Real to Bool. |
        err_vblk_rtou           = 660,  /// | 660        | Error in the connections for block Real to Integer. |
        err_vblk_runwrap        = 661,  /// | 661        | Error in the connections for block [-pi,pi] Unwrap. |
        err_vblk_utor           = 662,  /// | 662        | Error in the connections for block Integer to Real. |
        err_vblk_relthis        = 663,  /// | 663        | Error in the connections for block Relative Vector. |
        err_cancfg1             = 664,  /// | 664        | Number of mailboxes dedicated to rx exceeds maximum [32] or the filter applied to mailbox subset exceeds maximum filter id. |
        err_stickvar_cfg        = 665,  /// | 665        | Decimate time is higher than the minimum period or number of stick virtual inputs exceeds maximum configured for block Virtual stick. |
        err_vblk_gimbal         = 666,  /// | 666        | Error in the connections for block Gimbal. |
        err_vblk_hysteresis     = 667,  /// | 667        | Error in the connections for block Hysteresis. |
        err_vblk_arctrim        = 668,  /// | 668        | Error in the connections for block Arc Trim or control vector unmatched to expected size. |
        err_blockprog           = 669,  /// | 669        | Incomplete set of LSB bits or with bit holes for execution mask or slot is not within the mask. |
        err_vblk_n2b            = 670,  /// | 670        | Error in the connections for block NED to Body/Body to NED. |
        err_vblk_pwm            = 671,  /// | 671        | Error in the connections for block PWM or PWM id exceeds maximum. |
        err_vblk_stick          = 672,  /// | 672        | Error in stick block, connections, dimensions of matrices or stick sources could be wrong. |
        err_vblk_u2s            = 673,  /// | 673        | Error in actuator block, connections or dimensions of matrices could be wrong. |
        err_vblk_interp         = 674,  /// | 674        | Error in vector interpolation block, connections or sizes could be wrong, also the points in the table must be sorted in increasing order of x. |
        err_vblk_ratelim        = 678,  /// | 678        | Error in the connections for block Rate limiter. |
        err_vblk_clock          = 679,  /// | 679        | Unable to reset the clock timer in block Clock. |
        err_vblk_mult_varget    = 680,  /// | 680        | Unable to initialize output vector or invalid variable id in block Read Multiple Reals. |
        err_vblk_mult_varset    = 681,  /// | 681        | Error in the connections for block Write Multiple Bits/Write Multiple Reals or input vector different from input variables or variable not user writable. |
        err_vblk_pid_static     = 682,  /// | 682        | Unable to subscribe autotune in block PID. |
        err_vblk_quatctrl       = 683,  /// | 683        | Set of configurable variables cannot be 0 or outside their range in block Quaternion Control. |
        err_vblk_senstp         = 685,  /// | 685        | Error in pressure sensor block, could be that the selected pressure sensor in invalid in the current hardware or that the configured variance is negative or zero. |
        err_vblk_sengnss        = 686,  /// | 686        | Error for block GNSS sensor. |
        err_vblk_ekfpos         = 687,  /// | 687        | Error for block EKF position. |
        err_vblk_ekfvel         = 688,  /// | 688        | Error for block EKF Velocity. |
        err_vblk_ekfmis         = 689,  /// | 689        | Error for block EKF Misalignment. |
        err_vblk_drnmis         = 690,  /// | 690        | Error for block EKF GNSS compass. |
        err_vblk_senrel         = 691,  /// | 691        | Error for block Relative position (Sensors). |
        err_vblk_ekfdem         = 692,  /// | 692        | Error for block EKF Terrain Height. |
        err_vblk_senmag         = 693,  /// | 693        | Error in magnetometer sensor block, the selected might be invalid in your current hardware or the configured variance is negative or zero. |
        err_mdg_gain            = 694,  /// | 694        | Error for block Madgwick Gain Computer. |
        err_vblk_senalt         = 696,  /// | 696        | Error for block Altimeter. |
        err_vblk_ekfalt         = 697,  /// | 697        | Error for block EKF Altitude. |
        err_vblk_ekfvdn         = 698,  /// | 698        | Error for block EKF Velocity Down. |
        err_vblk_nav            = 699,  /// | 699        | Error for block Navigation. |
        err_e2acc               = 700,  /// | 700        | Error for variance increment due to high acceleration. |
        err_vblk_ekfsplit       = 701,  /// | 701        | Error for block EKF Split. |
        err_vblk_fft            = 703,  /// | 703        | Error ID for block FFT. |
        err_vblk_ecu            = 705,  /// | 705        | Error ID for block ECU control. |
        err_vblk_fuzzy          = 706,  /// | 706        | Error ID for block Fuzzy Logic Controller. |
        err_vblk_guidance       = 707,  /// | 707        | Input of guidance block could not be connected. |
        err_vblk_sysid          = 709,  /// | 709        | Error ID for block System Identification. |
        err_cex_pwm             = 710,  /// | 710        | Error ID for CEX pwm arbitration, src ID greater than pulses array. |
        err_cex_esc_tm          = 711,  /// | 711        | Error ID for CEX ESC period |
        err_cex_mcu_tm          = 712,  /// | 712        | Error ID for CEX MCU period |
        err_vblk_climb          = 713,  /// | 713        | Incorrect climb block operation |
        err_vblk_leg            = 714,  /// | 714        | Incorrect leg block operation |
        err_flyto               = 715,  /// | 715        | Incorrect fly to command (non-existing patch) |
        err_vblk_approach       = 716,  /// | 716        | Incorrect approach block operation |
        err_vblk_yawing         = 717,  /// | 717        | Incorrect yawing block configuration |
        err_vblk_siggen         = 718,  /// | 718        | Incorrect signal generation configuration |
        err_vblk_pnav           = 719,  /// | 719        | Incorrect PNAV guidance configuration |
        err_vblk_genex          = 720,  /// | 720        | Incorrect GENEX guidance configuration |
        err_vblk_modpnav        = 721,  /// | 721        | Incorrect ModPNAV guidance configuration |
        err_blk_lib             = 722,  /// | 722        | Incorrect library |
        err_vblk_ewma           = 723,  /// | 723        | Incorrect EWMA block configuration |
        err_uarray_resize       = 724,  /// | 724        | Incorrect uarray resize |
        err_oprvar              = 725,  /// | 725        | Incorrect operation/setup rvar configuration |
        err_block_const         = 726,  /// | 726        | Error in block const |
        err_block_posget        = 727,  /// | 727        | Error in block posguet |
        err_block_pnavbase      = 728,  /// | 728        | Error in block pnav base |
        err_block_arcade0       = 729,  /// | 729        | Error in block arcade0 |
        err_unescape            = 730,  /// | 730        | Error in escape itport |
        err_initial_alignment   = 731,  /// | 731        | The internal AHRS or EKF navigation estimation algorithm could not compute an initial orientation. Try commanding an initial yaw or adding an automation to do so. |
        err_fft_block_disable   = 732,  /// | 732        | The FFT block is temporarily disabled in this version |
        err_vblk_acclim         = 733,  /// | 733        | Error in block acceleration limiter |
        err_ewma_avgvar         = 734,  /// | 734        | Error in EWMA average/variance time constants |
        err_sensor_fusion       = 735,  /// | 735        | Time constants for sensor fusion algorithm are incorrect |
        err_oprng               = 736,  /// | 736        | Error in operation range configuration |
        err_oprng_check         = 737,  /// | 737        | Error in operation range check |
        err_vgeoref             = 738,  /// | 738        | Error in vgeoref configuration |
        err_notch_filter        = 739,  /// | 739        | Incorrect notch filter parameters |
        err_notch_frequency     = 740,  /// | 740        | Incorrect notch filter frequency |
        err_geoid_version       = 741,  /// | 741        | Incorrect geoid version in SD |
        err_vblk_integrator     = 742,  /// | 742        | Error in the connections for block Integrator |
        err_vblk_derivative     = 743,  /// | 743        | Error in the connections for block Derivative |
        err_wrapper_ref         = 744,  /// | 744        | Incorrect envelope range (minimum must be less or equal than maximum) |
        err_sensor_fusion_sel   = 745,  /// | 745        | Selected gyroscopes or accelerometers are invalid in this hardware or the default sensor is not active |
        err_volume_id           = 746,  /// | 746        | Incorrect volume identifier |
        err_fload_missing       = 747,  /// | 747        | Detected missing file at fload blocking |
        err_hi_3210_rx_cfg      = 748,  /// | 748        | Incorrect HI-3210 RX configuration |
        err_mixer               = 749,  /// | 749        | Incorrect mixer block configuration or it does not fit in memory |
        err_scheduler_data      = 750,  /// | 750        | Incorrect data size for scheduler block |
        err_asc                 = 751,  /// | 751        | Incorrect configuration of ASC block |
        err_scheduler           = 752,  /// | 752        | Incorrect configuration of scheduler block |
        err_aacg                = 753,  /// | 753        | Incorrect data size for mixer block |
        err_mat2quat            = 754,  /// | 754        | Incorrect input to matrix to quaternion block |
        err_quat2mat            = 755,  /// | 755        | Incorrect input to quaternion to matrix |
        err_wrench_frame        = 756,  /// | 756        | Incorrect inputs to the wrench frame block |
        err_ffc_3d_block        = 757,  /// | 757        | Incorrect configuration of ffc3d block |
        err_srv_def_limits      = 758,  /// | 758        | A default position is not within X limits for servo actuator |
        err_pfield_file         = 759,  /// | 759        | Error in loading the saved fields |
        err_vblk_wind           = 760,  /// | 760        | Invalid configuration for wind estimation block |
        err_vblk_senqinf        = 761,  /// | 761        | Invalid configuration for dynamic pressure sensor block |
        err_vblk_code_size      = 762,  /// | 762        | External code block: Size greater than maximum allowed (64KW) |
        err_vblk_code_empty     = 763,  /// | 763        | External code block empty. No code has been loaded |
        err_vblk_code_ptr       = 764,  /// | 764        | External code block: Invalid pointer detected |
        err_vblk_code_inputs    = 765,  /// | 765        | External code block: Inputs read error |
        err_vblk_code_outputs   = 766,  /// | 766        | External code block: Outputs write error |
        err_vblk_ekfadapter     = 767,  /// | 767        | Incorrect configuration in custom EKF adapter|
        err_vblk_compiledsil    = 768,  /// | 768        | Tried to use the compiled code block on a SIL configuration |
        err_speed_cfg           = 769,  /// | 769        | Invalid route speed configuration |
        err_event_log           = 770,  /// | 770        | Invalid Event-Driven Log Fields configuration.
        err_onboard_log         = 771,  /// | 771        | Invalid On-Board Low Rate Log Fields configuration.
        err_fast_log            = 772,  /// | 772        | Invalid Fast Log Fields configuration.
        err_vblk_senimu         = 773,  /// | 773        | Invalid configuration for IMU sensor block |
        err_pa_blk_sched_mix    = 774,  /// | 774        | Invalid inputs in the scheduler to mixer adapter block|
                                        /// </li>

        // STANAG
        err_stg_user_var        = 800,  /// | 800        | User variable being used in a STANAG message is not user writeable |
        err_stg_vars_overlap    = 801,  /// | 801        | Some user variables being used in STANAG are overlaping others |
        err_stg_period          = 802,  /// | 802        | Some STANAG periodical message has been configured at not allowed frequency |
        err_stg_msg_memory      = 803,  /// | 803        | Veronte is not able to allocate all configured messages |
        err_stg_vehicle_cfg     = 804,  /// | 804        | The Vehicle Identifier Configuration is not correct |
        err_stg_engine_op_sts   = 805,  /// | 805        | The Engine Operation States Message configuration is not correct |
        err_stg_msg_register    = 806,  /// | 806        | STANAG Message registration is not being possible |
        err_stg_fmsgs_vec       = 807,  /// | 807        | STANAG custom message is not associated to a correct Fieldset |
        err_stg_msg_cfg         = 808,  /// | 808        | Some parameter into the STANAG message configuration is not valid |
        err_stg_usr_wr          = 809,  /// | 809        | Some STANAG Custom message receiver is not user writable |
        err_stg_kind            = 810,  /// | 810        | Some of STANAG configuration kinds is not valid |
        err_comp_subcomp_n      = 811,  /// | 811        | Component or subcomponent ID have a higher value than allowed |
                                        /// </li>
                                        /// <li> Specific errors:
                                        /// | Identifier | Content |
        err_arbitration         = 10000,/// | 10000       | Error ID for Arbitration cfg. |
        err_arbitration_can     = 10001,/// | 10001       | Error ID for Arbitration_can cfg. |
        err_arbitration_can1    = 10002,/// | 10002       | Error ID for Arbitration_can cfg. |
        err_arb_cfg0            = 10003,/// | 10003       | Error ID for Arb cfg preferred ap oor. |
        err_arb_cfg1            = 10004,/// | 10004       | Error ID for Arb cfg method oor(out of range). |
        err_arb_cfg2            = 10005,/// | 10005       | Error ID for Arb cfg tmin oor. |
        err_arb_cfg3            = 10006,/// | 10006       | Error ID for Arb cfg hysteresis oor. |
        err_ap_nvars            = 10007,/// | 10007       | Error ID for Autopilot  nvars oor. |
        err_apcfg_nvars         = 10008,/// | 10008       | Error ID for Autopilot cfg nvars oor. |
        err_jetibox             = 10009,/// | 10009       | Error ID for sci identifier of Jetibox cfg oor. |
        err_jetibox_fmsgcmd     = 10010,/// | 10010       | Error ID for jetibox fmsg cmd oor. |
        err_arb_init_time       = 10011,/// | 10011       | Error ID for Arbiter Power Init Time less than 0. |
                                        /// | 10012       | UNUSED |
        err_arb_varcfg          = 10013,/// | 10013       | Incorrect arbiter variable configuration |
                                        /// | 10014:15000 | UNUSED |
        err_hs_base_can_id      = 15000,/// | 15000       | High speed telemetry invalid Base CAN Id |
        err_hs_tm_nvars         = 15001,/// | 15001       | High speed telemetry number of variables too big |
                                        /// | 15002:19999 | UNUSED |
        err_vmc_motor           = 20000,/// | 20000       | Motor cfg is not valid |
        err_vmc_control_mode    = 20001,/// | 20001       | Control mode is invalid |
        err_vmc_encoder_nbits   = 20002,/// | 20002       | Number of bits for encoder is invalid. |
        err_mc_vmotor           = 20003,/// | 20003       | Virtual motor cfg invalid |
        err_mc_smo              = 20004,/// | 20004       | Slide Mode Observer cfg invalid |
        err_mc_control          = 20005,/// | 20005       | Control cfg invalid |
        err_mc_fault_detection  = 20006,/// | 20006       | Invalid fault detection limits |
        err_mangle_rate         = 20007,/// | 20007       | Invalid filter time constant |
        err_low_pll             = 20008,/// | 20008       | Invalid cut-off frequency |
        err_mc_main             = 20009,/// | 20009       | Invalid real time frequency |

        err_range_check         = 20010,/// | 20010       | Invalid range definition |
        err_ext_sens            = 20011,/// | 20011       | Invalid external sensor configuration |
        err_press_dev           = 20012,/// | 20012       | Invalid pressure sensor configuration |
        err_press_dps310        = 20014,/// | 20014       | Invalid pressure sensor DPS310 configuration |
        err_press_hsc           = 20015,/// | 20015       | Invalid pressure sensor HSC configuration |
        err_press_ms56          = 20016,/// | 20016       | Invalid pressure sensor MS561101 configuration |

        err_invalid_cal_table   = 20017,/// | 20017       | Invalid number of entries in calibration table |

        err_mag_lis3mdl         = 20018,/// | 20018       | Invalid magnetometer LIS3MDL configuration |
        err_mag_hscdtd          = 20019,/// | 20019       | Invalid magnetometer HSCDTD008A configuration |
        err_mag_mmc5883ma       = 20020,/// | 20020       | Invalid magnetometer MMC5883MA configuration |
        err_mag_rm3100          = 20021,/// | 20021       | Invalid magnetometer RM3100 configuration |

        err_ex_ussa76_cmd       = 20022,/// | 20022       | Invalid period of external USSA76 command
        err_gnc_model_dyn       = 20023,/// | 20023       | Error in deserialization and construction of GNC model dynamic class |
        err_gnc_model_dyn_set   = 20024,/// | 20024       | Error in deserialization and construction of GNC model dynamic set class |
        err_dyn_rtable_build_pdi= 20025,/// | 20025       | Error building a dynamic rtable from its PDI |
        err_dyn_multi_interp    = 20026,/// | 20026       | Error building a dynamic multi interpolator from its PDI |
                                        /// | 20018:31998 | UNUSED |
        err_cfgmr_length        = 31999,/// | 31999       | Unexpected size of PDI or command. |
        err_cfg_file            = 32000,//TODO remove
                                        /// | 32001:32767 | UNUSED |
                                        /// | 32768:65534 | Reserved |
        //Reserved offset of the number of configurables see Cfg::cfg_all.
        err_check_test          =0xFFFF /// | 65535       | Error ID for given pdi check. |
                                        /// </li>
    };
    /// <ul>
}
#endif
