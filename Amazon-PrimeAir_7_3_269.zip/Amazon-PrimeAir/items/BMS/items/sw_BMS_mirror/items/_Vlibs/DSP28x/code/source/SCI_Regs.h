#ifndef SCI_REGS_H_H
#define SCI_REGS_H_H

#include <SCI.h>
#include <Ku16.h>

namespace Dsp28335_ent
{
    //PRQA S 2301 ++
    //#Bit-fields are needed.
    //PRQA S 5051 ++
    //#Identifiers will be kept by default

    /// SCI Individual Register Bit Definitions
    struct Sciccr_bits {
        Uint16 SCICHAR:3;                   ///< 2:0 Character length control
        Uint16 ADDRIDLE_MODE:1;             ///< 3 ADDR/IDLE Mode control
        Uint16 LOOPBKENA:1;                 ///< 4 Loop Back enable
        Uint16 PARITYENA:1;                 ///< 5 Parity enable
        Uint16 PARITY:1;                    ///< 6 Even or Odd Parity
        Uint16 STOPBITS:1;                  ///< 7 Number of Stop Bits
        Uint16 rsvd1:8;                     ///< 15:8 Reserved
    };

    union Sciccr_reg {
        Uint16 all;
        Sciccr_bits bit;
    };

    /// SCICTL1 control register 1 bit definitions
    struct Scicctl1_bits {
        Uint16 RXENA:1;                     ///< 0 SCI receiver enable
        Uint16 TXENA:1;                     ///< 1 SCI transmitter enable
        Uint16 SLEEP:1;                     ///< 2 SCI sleep
        Uint16 TXWAKE:1;                    ///< 3 Transmitter wakeup method
        Uint16 rsvd1:1;                     ///< 4 Reserved
        Uint16 SWRESET:1;                   ///< 5 Software reset
        Uint16 RXERRINTENA:1;               ///< 6 Recieve __interrupt enable
        Uint16 rsvd2:9;                     ///< 15:7 Reserved
    };

    union Scictl1_reg {
        Uint16 all;
        Scicctl1_bits bit;
    };

    struct Scibaud_bits {
        Uint16 BAUD:8;                      ///< 7:0 SCI 16-bit baud selection Registers SCIHBAUD/SCILBAUD
        Uint16 rsvd1:8;                     ///< 15:8 Reserved
    };

    union Scibaud_reg {
        Uint16 all;
        Scibaud_bits bit;
    };

    /// SCICTL2 control register 2 bit definitions
    struct Scictl2_bits
    {
        Uint16 TXINTENA:1;                  ///< 0 Transmit __interrupt enable
        Uint16 RXBKINTENA:1;                ///< 1 Receiver-buffer break enable
        Uint16 rsvd1:4;                     ///< 5:2 Reserved
        Uint16 TXEMPTY:1;                   ///< 6 Transmitter empty flag
        Uint16 TXRDY:1;                     ///< 7 Transmitter ready flag
        Uint16 rsvd2:8;                     ///< 15:8 Reserved
    };

    union Scictl2_reg
    {
        Uint16 all;
        Scictl2_bits bit;
    };

    /// SCIRXST Receiver status register bit definitions
    struct Scirxst_bits
    {
        Uint16 rsvd1:1;                     ///< 0 Reserved
        Uint16 RXWAKE:1;                    ///< 1 Receiver wakeup detect flag
        Uint16 PE:1;                        ///< 2 Parity error flag
        Uint16 OE:1;                        ///< 3 Overrun error flag
        Uint16 FE:1;                        ///< 4 Framing error flag
        Uint16 BRKDT:1;                     ///< 5 Break-detect flag
        Uint16 RXRDY:1;                     ///< 6 Receiver ready flag
        Uint16 RXERROR:1;                   ///< 7 Receiver error flag
        Uint16 rsvd2:8;                     ///< 15:8 Reserved
    };

    union Scirxst_reg
    {
        Uint16 all;
        Scirxst_bits bit;
    };

    struct Scirxemu_bits
    {
        Uint16 ERXDT:8;                     ///< 7:0 Receive emulation buffer data
        Uint16 rsvd1:8;                     ///< 15:8 Reserved
    };

    union Scirxemu_reg
    {
        Uint16 all;
        Scirxemu_bits bit;
    };

    /// SCIRXBUF Receiver Data Buffer with FIFO bit definitions
    struct Scirxbuf_bits
    {
        Uint16 SAR:8;                       ///< 7:0 Receive Character bits
        Uint16 rsvd1:6;                     ///< 13:8 Reserved
        Uint16 SCIFFPE:1;                   ///< 14 Receiver error flag
        Uint16 SCIFFFE:1;                   ///< 15 Receiver error flag
    };

    union Scirxbuf_reg
    {
        Uint16 all;
        Scirxbuf_bits bit;
    };

    /// SCI FIFO Transmit register bit definitions
    struct Scitxbuf_bits
    {
        Uint16 TXDT:8;                      ///< 7:0 Transmit data buffer
        Uint16 rsvd1:8;                     ///< 15:8 Reserved
    };

    union Scitxbuf_reg
    {
        Uint16 all;
        Scitxbuf_bits bit;
    };

    /// SCI FIFO Transmit register bit definitions
    struct Scifftx_bits
    {
        Uint16 TXFFIL:5;                    ///< 4:0 Interrupt level
        Uint16 TXFFIENA:1;                  ///< 5 Interrupt enable
        Uint16 TXFFINTCLR:1;                ///< 6 Clear INT flag
        Uint16 TXFFINT:1;                   ///< 7 INT flag
        Uint16 TXFFST:5;                    ///< 12:8 FIFO status
        Uint16 TXFIFORESET:1;               ///< 13 FIFO reset
        Uint16 SCIFFENA:1;                  ///< 14 Enhancement enable
        Uint16 SCIRST:1;                    ///< 15 SCI reset rx/tx channels
    };

    union Scifftx_reg
    {
        Uint16 all;
        Scifftx_bits bit;
    };

    /// SCI FIFO recieve register bit definitions
    struct Sciffrx_bits
    {
        Uint16 RXFFIL:5;                    ///< 4:0 Interrupt level
        Uint16 RXFFIENA:1;                  ///< 5 Interrupt enable
        Uint16 RXFFINTCLR:1;                ///< 6 Clear INT flag
        Uint16 RXFFINT:1;                   ///< 7 INT flag
        Uint16 RXFFST:5;                    ///< 12:8 FIFO status
        Uint16 RXFIFORESET:1;               ///< 13 FIFO reset
        Uint16 RXFFOVRCLR:1;                ///< 14 Clear overflow
        Uint16 RXFFOVF:1;                   ///< 15 FIFO overflow
    };

    union Sciffrx_reg
    {
        Uint16 all;
        Sciffrx_bits bit;
    };

    /// SCI FIFO control register bit definitions
    struct Sciffct_bits
    {
        Uint16 FFTXDLY:8;                   ///< 7:0 FIFO transmit delay
        Uint16 rsvd1:5;                     ///< 12:8 Reserved
        Uint16 CDC:1;                       ///< 13 Auto baud mode enable
        Uint16 ABDCLR:1;                    ///< 14 Auto baud clear
        Uint16 ABD:1;                       ///< 15 Auto baud detect
    };

    union Sciffct_reg
    {
        Uint16 all;
        Sciffct_bits bit;
    };

    /// SCIPRI Priority control register bit definitions
    struct Scipri_bits
    {
        Uint16 rsvd1:3;                     ///< 2:0 Reserved
        Uint16 FREESOFT:2;                  ///< 4:3 Emulation modes
        Uint16 rsvd2:3;                     ///< 7:5 Reserved
        Uint16 rsvd3:8;                     ///< 15:8 Reserved
    };

    union Scipri_reg
    {
        Uint16 all;
        Scipri_bits bit;
    };

    /// SCI Register File
    struct SCI::Sci_regs  //PRQA S 1701,1702 #Register Access, not to disable constructors
    {
    public:
        union   Sciccr_reg                       SCICCR;                       ///< Communications control register
        union   Scictl1_reg                      SCICTL1;                      ///< Control register 1
        union   Scibaud_reg                      SCIHBAUD;                     ///< Baud rate (high) register
        union   Scibaud_reg                      SCILBAUD;                     ///< Baud rate (low) register
        union   Scictl2_reg                      SCICTL2;                      ///< Control register 2
        union   Scirxst_reg                      SCIRXST;                      ///< Recieve status register
        union   Scirxemu_reg                     SCIRXEMU;                     ///< Recieve emulation buffer register
        union   Scirxbuf_reg                     SCIRXBUF;                     ///< Recieve data buffer
        Uint16                                   rsvd1;                        ///< Reserved
        union   Scitxbuf_reg                     SCITXBUF;                     ///< Transmit data buffer
        union   Scifftx_reg                      SCIFFTX;                      ///< FIFO transmit register
        union   Sciffrx_reg                      SCIFFRX;                      ///< FIFO recieve register
        union   Sciffct_reg                      SCIFFCT;                      ///< FIFO control register
        Uint16                                   rsvd2[Ku16::u2];              ///< Reserved
        union   Scipri_reg                       SCIPRI;                       ///< SCI Priority control
    };

    //PRQA S 2301 --
    //#Bit-fields are needed.
    //PRQA S 5051 --
    //#Identifiers will be kept by default
}
#endif
