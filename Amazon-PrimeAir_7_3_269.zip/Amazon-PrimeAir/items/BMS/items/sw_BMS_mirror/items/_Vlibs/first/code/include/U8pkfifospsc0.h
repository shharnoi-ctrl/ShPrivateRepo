#ifndef U8PKFIFOSPSC0_H_
#define U8PKFIFOSPSC0_H_

#include <U8pkmblock.h>

namespace Base
{
    /// Class with external read and write pointer and reference to U8pkmblock.
    class U8pkfifospsc0
    {
    public:

        /// Byte SPSC FIFO Constructor.
        /// \wi{6438}
        /// U8pkfifospsc0 class shall build itself upon construction with the given parameters 
        /// memory block, read pointer, and write pointer.
        /// \param[in] buf0 Memory block.
        /// \param[in] rd0 Read pointer.
        /// \param[in] wr0 Write pointer.
        U8pkfifospsc0(U8pkmblock& buf0, Uint32& rd0, Uint32& wr0);

        //Access methods to U8pkfifospsc0.

        /// U8pkfifospsc0 Writer.
        /// \wi{6439}
        /// U8pkfifospsc0 class shall provide a method to write a given byte on queue if possible.
        /// \pre Non-blocking call as only writing pointer is updated.
        /// \param[in] element Byte to be written.
        /// \return True if the action has succeeded, False if not.
        bool write(Uint8 element);

        /// U8pkfifospsc0 Reader.
        /// \wi{6440}
        /// U8pkfifospsc0 class shall provide a method to read a byte from queue if possible.
        /// \pre Non-blocking call as only read pointer is updated.
        /// \param[in] element Byte reference where retrieve read value.
        /// \return True if the action has succeeded, False if not.
        bool read(Uint8& element);

        /// Read Availability Checker.
        /// \wi{6441}
        /// U8pkfifospsc0 class shall provide the capability to determine if there is a 
        /// new byte to read from the queue.
        /// \return True if read pointer is different from write pointer, False if not.
        bool rd_available() const;

        /// Write Availability Checker.
        /// \wi{6442}
        /// U8pkfifospsc0 class shall provide the capability to determine if a new byte 
        /// can be written into the queue.
        /// \return True if next write pointer is different from read pointer, False if not.
        bool wr_available() const;

        /// Available Reading Account Retriever.
        /// \wi{6443}
        /// U8pkfifospsc0 class shall provide the capability to retrieve the available 
        /// memory in bytes for reading from the queue. 
        /// \return The number of bytes available for reading.
        Uint32 rd_available_count() const;

        /// Available Writing Account Retreiver.
        /// \wi{6444}
        /// U8pkfifospsc0 class shall provide the capability to retrieve the available 
        /// memory in bytes for writing to the queue.
        /// \return The number of bytes available for writing.
        Uint32 wr_available_count() const;

    private:

        U8pkmblock& v;      ///< Queue buffer reference.
        Uint32& rd;         ///< Read index reference.
        Uint32& wr;         ///< Write index reference.

        /// Next Pointer from Given one Retriever.
        /// \wi{6445}
        /// U8pkfifospsc0 class shall provide a function to obtain the next pointer from the given previous pointer.
        /// \param[in] prv previous pointer.
        /// \return Next pointer from given previous one.
        Uint32 next(Uint32 prv) const;

        U8pkfifospsc0();                                      ///< = delete
        U8pkfifospsc0(const U8pkfifospsc0& orig);             ///< = delete
        U8pkfifospsc0& operator=(const U8pkfifospsc0& orig);  ///< = delete
    };

    inline bool U8pkfifospsc0::rd_available() const
    {
        /// \alg
        /// - Returns True if the read pointer is different from the write pointer, indicating that there is 
        /// data available to read, False otherwise.

        return (rd != wr);
    }

    inline Uint32 U8pkfifospsc0::rd_available_count() const
    {
        /// \alg
        /// - Return the available memory in bytes for reading from the queue.
        return (wr>=rd) ? wr-rd : wr+v.size()-rd;
    }

    inline bool U8pkfifospsc0::wr_available() const
    {
        /// \alg
        /// - Return the available memory in bytes for writing to the queue.
        return rd != next(wr);
    }

    inline Uint32 U8pkfifospsc0::wr_available_count() const
    {
        /// \alg
        /// - Return the available memory in bytes for writing to the queue.
        return v.size() - 1 - rd_available_count();
    }

    inline Uint32 U8pkfifospsc0::next(Uint32 prv) const
    {
        /// \alg
        /// - Return the next pointer from the given previous pointer.
        return (prv>=(v.size()-1)) ? 0 : (prv+1);
    }
}
#endif
