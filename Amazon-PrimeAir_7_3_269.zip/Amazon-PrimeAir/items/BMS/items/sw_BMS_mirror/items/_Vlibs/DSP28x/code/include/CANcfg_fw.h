#ifndef INCLUDE_CANCFG_FW_H_
#define INCLUDE_CANCFG_FW_H_

namespace Dsp28335_ent
{
    struct CANcfg;
}
#endif
