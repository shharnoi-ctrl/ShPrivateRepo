#ifndef INCLUDE_R64VAR_H_
#define INCLUDE_R64VAR_H_

#include <Range.h>

namespace Base
{
    enum R64var
    {
        r64_ext_sen_nav0_lon    = 0,  ///< (0) External sensor navigation 0 longitude (rad)
        r64_ext_sen_nav0_lat    = 1,  ///< (1) External sensor navigation 0 latitude (rad)
        r64_ext_sen_nav0_height = 2   ///< (2) External sensor navigation 0 WGS84 height (m)
    };
    static const Uint16 r64_all = 3U;

    inline bool is_valid(R64var v)
    {
        return Range<R64var, r64_ext_sen_nav0_lon, r64_ext_sen_nav0_height>::in_range(v);
    }
}
#endif
