#ifndef TNARRAY_H_
#define TNARRAY_H_

#include <Tnarray_fw.h>

#include <Mblock.h>
#include <Tmem.h>

namespace Base
{
    /// Static fixed size array POD wrapper
    template <typename T, Uint32 n>
    struct Tnarray
    {
        typedef T type;             ///< Type to use in fixed-size array.
        static const Uint32 sz = n; ///< Defined size for the fixed-size array.

        typedef typename JSF116_param<T>::type JSF116_param_elem_type;  ///< Defined JSF type.
        T v[n];                     ///< Fixed-size array.

        /// Fixed-size Array [] Operator.
        /// \wi{4941}
        /// Tnarray class shall provide the capability to retrieve a reference to the element at given index.
        /// \param[in] i    Index in the fixed-size array.
        /// \return         Reference to the element at given index.
        /// \pre            Assume that provided index is not out of bounds.
        T& operator[](Uint32 i);
        /// Fixed-size Array Const [] Operator.
        /// \wi{16848}
        /// Tnarray class shall provide the capability to retrieve a reference to the element at given index.
        /// \param[in] i    Index in the fixed-size array.
        /// \return         Const reference to the element at given index.
        /// \pre            Assume that provided index is not out of bounds.
        const T& operator[](Uint32 i)const;
        /// Fixed-size Array Volatile [] Operator.
        /// \wi{16849}
        /// Tnarray class shall provide the capability to retrieve a reference to the element at given index.
        /// \param[in] i    Index in the fixed-size array.
        /// \return         Volatile reference to the element at given index.
        /// \pre            Assume that provided index is not out of bounds.
        volatile T& operator[](Uint32 i) volatile;
        /// Fixed-size Array Const Volatile [] Operator.
        /// \wi{16850}
        /// Tnarray class shall provide the capability to retrieve a reference to the element at given index.
        /// \param[in] i    Index in the fixed-size array.
        /// \return         Const volatile reference to the element at given index.
        /// \pre            Assume that provided index is not out of bounds.
        const volatile T& operator[](Uint32 i)const volatile;

        /// Fixed-size Array First.
        /// \wi{4942}
        /// Tnarray class shall provide the capability to get a pointer to the first element in the fixed-size array.
        /// \return     Pointer to first element in the fixed-size array.
        T* first();
        /// Fixed-size Array First As Const.
        /// \wi{16851}
        /// Tnarray class shall provide the capability to get a pointer to the first element in the fixed-size array.
        /// \return     Const pointer to first element in the fixed-size array.
        const T* first() const;
        /// Fixed-size Array First As Volatile.
        /// \wi{16852}
        /// Tnarray class shall provide the capability to get a pointer to the first element in the fixed-size array.
        /// \return     Volatile pointer to first element in the fixed-size array.
        volatile T* first() volatile;
        /// Fixed-size Array First As Const Volatile.
        /// \wi{16853}
        /// Tnarray class shall provide the capability to get a pointer to the first element in the fixed-size array.
        /// \return     Const volatile pointer to first element in the fixed-size array.
        const volatile T* first() const volatile;

        /// Fixed-size Array Last.
        /// \wi{4943}
        /// Tnarray class shall provide the capability to get a pointer to the last element in the fixed-size array.
        /// \return     Pointer to last element in the fixed-size array.
        T* last();
        /// Fixed-size Array Last As Const.
        /// \wi{16854}
        /// Tnarray class shall provide the capability to get a pointer to the last element in the fixed-size array.
        /// \return     Const pointer to last element in the fixed-size array.
        const T* last() const;
        /// Fixed-size Array Last As Volatile.
        /// \wi{16855}
        /// Tnarray class shall provide the capability to get a pointer to the last element in the fixed-size array.
        /// \return     Volatile pointer to last element in the fixed-size array.
        volatile T* last() volatile;
        /// Fixed-size Array Last As Const Volatile.
        /// \wi{16856}
        /// Tnarray class shall provide the capability to get a pointer to the last element in the fixed-size array.
        /// \return     Const Volatile pointer to last element in the fixed-size array.
        const volatile T* last() const volatile;

        /// Fixed-size Array To Mblock.
        /// \wi{4944}
        /// Tnarray class shall provide the capability to return itself as a ::type memory block.
        /// \return     Mblock with the fixed-size array data.
        Mblock<T> to_mblock();
        /// Fixed-size Array To Const Mblock.
        /// \wi{16857}
        /// Tnarray class shall provide the capability to build and retrieve a mblock with the fixed-size array data.
        /// \return     Const mblock with the fixed-size array data.
        Mblock<const T> to_mblock() const;
        /// Fixed-size Array To Volatile Mblock.
        /// \wi{16858}
        /// Tnarray class shall provide the capability to build and retrieve a mblock with the fixed-size array data.
        /// \return     Volatile mblock with the fixed-size array data.
        Mblock<volatile T> to_mblock() volatile;
        /// Fixed-size Array To Const Volatile Mblock.
        /// \wi{16859}
        /// Tnarray class shall provide the capability to build and retrieve a mblock with the fixed-size array data.
        /// \return     Const volatile mblock with the fixed-size array data.
        Mblock<const volatile T> to_mblock() const volatile;

        /// Fixed-size Array Index Value Retriever.
        /// \wi{20194}
        /// Tnarray class shall be able to retrieve the value of the fixed-size array for a given index.
        /// \param[in] i    Index of the fixed-size array to be retrieved.
        /// \return Value for the given index.
        T& get(Uint16 i) const;
        /// Fixed-size Array Index Value Setter.
        /// \wi{20195}
        /// Tnarray class shall provide the capability to set the value of the fixed-size array for a given index.
        /// \param[in] i    Index where the value is stored.
        /// \param[in] t    Value to be stored.
        void set(Uint16 i, const T& t);
        /// Fixed-size Array Zeros.
        /// \wi{4945}
        /// Tnarray class shall provide the capability to initialize all the elements in the fixed-size array to zero.
        void zeros();

        /// Fixed-size Array Size.
        /// \wi{4946}
        /// Tnarray class shall provide the capability to provide the number of contained elements.
        /// \return     Number of contained elements.
        static Uint32 size();

        /// Fixed-size Array Copy.
        /// \wi{4947}
        /// Tnarray class shall provide the capability to copy from another static fixed-size array data
        /// structure to itself.
        /// \param[in] src    Data source.
        template <Uint32 n1>
        void copy(const Tnarray<T,n1>& src);

        /// Fixed-size Array Copy All.
        /// \wi{16860}
        /// Tnarray class shall provide the capability to copy all the elements from another fixed-size array data
        /// structure to itself.
        /// \param[in] src     Data source.
        void copy_all(const T* src);

        /// Fixed-size Array Copy.
        /// \wi{16861}
        /// Tnarray class shall provide the capability to copy from another fixed-size array data structure to itself.
        /// \param[in] src    Data source.
        template <typename ARRAY>
        void copy(const ARRAY& src);

        /// Fixed-size Array Copy.
        /// \wi{16862}
        /// Tnarray class shall provide the capability to copy from another fixed-size array data structure to itself.
        /// \param[in] src    Data source.
        template <typename ARRAY>
        void copy(const ARRAY& src) volatile;

        /// Fixed-size Array Init.
        /// \wi{4948}
        /// Tnarray class shall provide the capability to call the init method of all the fixed-size array elements.
        void init();

        /// Fixed-size Array Set All.
        /// \wi{4949}
        /// Tnarray class shall provide the capability to set all the elements in the fixed-size array
        /// to a specific value.
        /// \param[in] value    Value to set the elements to.
        void set_all(JSF116_param_elem_type value);

        /// Fixed-size Array Is Pointed By.
        /// \wi{4950}
        /// Tnarray class shall provide the capability to check if a pointer address is inside
        ///  the internal buffer of an fixed-size array.
        /// \return     False if provided address is out-of-bounds, else return true.
        bool is_pointed_by(const volatile void* const volatile addr) const volatile;
    };


    // workarround for TI compiler bug: segmentation fault of with the following main body
    //    Base::Tnarray<Uint16,0> aux
    //    aux.clear()

    template <typename T>
    struct Tnarray<T,0>
    {
        Mblock<T> to_mblock();
        Mblock<const T> to_mblock() const;
        Mblock<volatile T> to_mblock() volatile;
        Mblock<const volatile T> to_mblock() const volatile;

        void zeros();

        Uint32 size() const;
    };
    // end of workarround

    template <typename T, Uint32 n>
    inline T& Tnarray<T,n>::operator[](Uint32 i)
    {
        return v[i];
    }

    template <typename T, Uint32 n>
    inline const T& Tnarray<T,n>::operator[](Uint32 i)const
    {
        return v[i];
    }

    template <typename T, Uint32 n>
    inline volatile T& Tnarray<T,n>::operator[](Uint32 i) volatile
    {
        return v[i];
    }

    template <typename T, Uint32 n>
    inline const volatile T& Tnarray<T,n>::operator[](Uint32 i)const volatile
    {
        return v[i];
    }

    template <typename T, Uint32 n>
    inline T& Tnarray<T,n>::get(Uint16 i) const
    {
        return v[i];
    }

    template <typename T, Uint32 n>
    inline void Tnarray<T,n>::set(Uint16 i, const T& t)
    {
        v[i] = t;
    }

    template <typename T, Uint32 n>
    inline T* Tnarray<T,n>::first()
    {
        return v;
    }

    template <typename T, Uint32 n>
    inline const T* Tnarray<T,n>::first() const
    {
        return v;
    }

    template <typename T, Uint32 n>
    inline volatile T* Tnarray<T,n>::first() volatile
    {
        return v;
    }

    template <typename T, Uint32 n>
    inline const volatile T* Tnarray<T,n>::first() const volatile
    {
        return v;
    }

    template <typename T, Uint32 n>
    inline T* Tnarray<T,n>::last()
    {
        return &v[n-1];
    }

    template <typename T, Uint32 n>
    inline const T* Tnarray<T,n>::last() const
    {
        return &v[n-1];
    }

    template <typename T, Uint32 n>
    inline volatile T* Tnarray<T,n>::last() volatile
    {
        return &v[n-1];
    }

    template <typename T, Uint32 n>
    inline const volatile T* Tnarray<T,n>::last() const volatile
    {
        return &v[n-1];
    }

    template <typename T, Uint32 n>
    inline Mblock<T> Tnarray<T,n>::to_mblock()
    {
        return Mblock<T>(v,n);
    }

    template <typename T, Uint32 n>
    inline Mblock<const T> Tnarray<T,n>::to_mblock() const
    {
        return Mblock<const T>(v,n);
    }

    template <typename T, Uint32 n>
    inline Mblock<volatile T> Tnarray<T,n>::to_mblock() volatile
    {
        return Mblock<volatile T>(v,n);
    }

    template <typename T, Uint32 n>
    inline Mblock<const volatile T> Tnarray<T,n>::to_mblock() const volatile
    {
        return Mblock<const volatile T>(v,n);
    }

    template <typename T, Uint32 n>
    inline void Tnarray<T,n>::zeros()
    {
        Tmem::set<sizeof(v)>(v,0);
    }

    template <typename T, Uint32 n>
    inline Uint32 Tnarray<T,n>::size()
    {
        return n;
    }

    template <typename T, Uint32 n>
    template <Uint32 n1>
    inline void Tnarray<T,n>::copy(const Tnarray<T,n1>& src)
    {
        Tmem::cpy<sizeof(T) * Value_min<Uint32, n, n1>::value>(v, &src[0]);
    }

    template <typename T, Uint32 n>
    template <typename ARRAY>
    inline void Tnarray<T,n>::copy(const ARRAY& src)
    {
        Tmem::cpy_max<n*sizeof(T)>(v, &src[0],  src.size() * sizeof(T));
    }

    template <typename T, Uint32 n>
    inline void Tnarray<T,n>::copy_all(const T* src)
    {
        Tmem::cpy<n*sizeof(T)>(v, src);
    }


    template <typename T, Uint32 n>
    template <typename ARRAY>
    inline void Tnarray<T,n>::copy(const ARRAY& src) volatile
    {
        const_cast<Tnarray<T,n>*>(this)->copy(src);
    }

    template <typename T, Uint32 n>
    inline void Tnarray<T,n>::init()
    {
        for(Uint32 i=0; i<n; i++)
        {
            v[i].init();
        }
    }

    template <typename T, Uint32 n>
    inline void Tnarray<T,n>::set_all(JSF116_param_elem_type value)
    {
        for(T* vi = v; vi<&v[n]; ++vi)
        {
            *vi = value;
        }
    }

    /// \ return True if addr is inside buffer
    template <typename T, Uint32 n>
    inline bool Tnarray<T,n>::is_pointed_by(const volatile void* const volatile addr) const volatile
    {
        return (addr >= v) && (addr < (&v[n]) );
    }

    template <typename T>
    inline Mblock<T> Tnarray<T,0>::to_mblock() //PRQA S 4212 #JSF 69: Multiple definitions of the same function
    {
        return Mblock<T>(0,0);
    }

    template <typename T>
    inline Mblock<const T> Tnarray<T,0>::to_mblock() const //PRQA S 4212 #JSF 69: Multiple definitions of the
    {                                                      //                     same function
        return Mblock<const T>(0,0);
    }

    template <typename T>
    inline Mblock<volatile T> Tnarray<T,0>::to_mblock() volatile
    {
        return Mblock<volatile T>(0,0);
    }

    template <typename T>
    inline Mblock<const volatile T> Tnarray<T,0>::to_mblock() const volatile
    {
        return Mblock<const volatile T>(0,0);
    }

    template <typename T>
    inline void Tnarray<T,0>::zeros() //PRQA S 4212 #static
    {
    }

    template <typename T>
    inline Uint32 Tnarray<T,0>::size() const
    {
        return 0;
    }
}
#endif
