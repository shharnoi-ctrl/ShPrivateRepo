#include <GPIOioctl.h>
#include <GPIOid.h>
#include <GPIOvalid.h>
#include <Lossy.h>
#include <Ku16.h>
#include <Asm.h>
#include <Hregmap.h>

namespace Dsp28335_ent
{
    const GPIOtun GPIOioctl::gpio_input_cfg =
    {
        GPIOtun::dir_input, GPIOtun::pu_dis, GPIOmux16::mux_gpio, GPIOtun::qsel_async
    };

    const GPIOtun GPIOioctl::gpio_output_cfg =
    {
        GPIOtun::dir_output, GPIOtun::pu_dis, GPIOmux16::mux_gpio, GPIOtun::qsel_sync
    };

    namespace
    {
        static const Uint16 a2f_banks = 6;  // A to F banks

        struct Gpio_ctrl_regs_st        /// GPIO control for 32 GPIOs.
        {
            Uint32  ctrl;               ///< Qualification Sampling Period Control (1 bit groups)
            Uint32  qsel[Ku16::u2];     ///< Qualifier Select 1 Register (2 bit groups)
            Uint32  mux_reg[Ku16::u2];  ///< Mux Register  (2 bit groups)
            Uint32  dir;                ///< Direction Register (1 bit groups)
            Uint32  pud;                ///< Pull Up Disable Register (1 bit groups)
            Uint32  rsvd;               ///< Reserved
            Uint32  inv;                ///< Input Polarity Invert Registers (1 bit groups)
            Uint32  odr;                ///< Open Drain Output Register (1 bit groups)
            union
            {
                Uint32  rsvd5;          ///< Reserved
                Uint32  bamsel;         ///< Port B Analog Mode selection. Only not reserved for pin 42 and 43.
            };
            Uint32  rsvd2[Ku16::u5];    ///< Reserved
            Uint32  gmux[Ku16::u2];     ///< Peripheral Group Mux (2 bit groups)
            Uint32  rsvd3[Ku16::u2];    ///< Reserved
            Uint32  csel[Ku16::u4];     ///< Core Select Register (4 bit groups)
            Uint32  rsvd4[Ku16::u6];    ///< Reserved
            Uint32  lock;               ///< Lock Configuration Register (1 bit groups)
            Uint32  com_reg;            ///< Lock Commit Register (1 bit groups)
        };

        static const Uint32 gpio_ctrl_regs_addr = 0x007C00UL;
        typedef Base::Tnarray<Gpio_ctrl_regs_st, a2f_banks> Gpio_ctrl_regs; // Type for A to F banks
        typedef Hregmap::Handler<Gpio_ctrl_regs, gpio_ctrl_regs_addr> Hgpio_ctrl;
    }


    void GPIOioctl::apply_mux(GPIOid id, GPIOtun::Mux mux)
    {
        const Uint16 offset1 = id&0x1F;         // bit offset for registers with 1-bit groups
        const Uint16 offset2 = (id&0x0F)<<1;    // bit offset for registers with 2-bit groups
        const Uint16 bank = id>>5;              // bank index
        const Uint16 i2 = offset1>>4;           // register index for 2-bit register arrays
        const Uint32 mask1 = 0x1UL<<offset1;    // mask for registers with 1-bit groups
        const Uint32 mask2 = 0x3UL<<offset2;    // mask for registers with 2-bit groups

        Hgpio_ctrl hgpio;
        volatile Gpio_ctrl_regs_st& cregs = hgpio.regs[bank];

        // unlock
        asm_eallow();
        cregs.lock &= ~mask1;

        // mux func
        volatile Uint32& crdir = cregs.dir;
        volatile Uint32& crmux = cregs.mux_reg[i2];
        volatile Uint32& crgmux = cregs.gmux[i2];
        GPIOtun::Mux mux_prev = static_cast<GPIOtun::Mux>((((crgmux&mask2)>>offset2)<<2) | ((crmux&mask2)>>offset2));
        if(mux != mux_prev) // check if mux remain the same to avoid glitches
        {
            // To avoid glitches an intermediate state with mux=0 (GPIO) and DIR=input is used when switching
            // between 2 mux values.
            crdir &= ~mask2;                                        // input
            crmux  &= ~mask2;                                       // gpio

            const Uint32 gmux = (crgmux & ~mask2) | static_cast<Uint32>(mux >> Ku16::u2) << offset2;// still as input
            crgmux = gmux;

            const Uint32 nmux = (crmux & ~mask2) | (static_cast<Uint32>(mux) << offset2) & mask2;   // final mux
            crmux = nmux;
        }
        // lock
        cregs.lock |= mask1;
        asm_edis();
    }

    void GPIOioctl::apply(GPIOid id, const GPIOtun& cfg, Core_select cs)
    {
        if(Base::Assertions::runtime(cfg.is_valid() && is_gpioid_valid(id)))
        {
            // gereneral computations dependent on gpio id.
            const Uint16 offset1 = id&0x1F;         // bit offset for registers with 1-bit groups
            const Uint16 offset2 = (id&0x0F)<<1;    // bit offset for registers with 2-bit groups
            const Uint16 offset4 = (id&0x07)<<2;    // bit offset for registers with 4-bit groups
            const Uint16 bank = id>>5;              // bank index
            const Uint16 i2 = offset1>>4;           // register index for 2-bit register arrays
            const Uint16 i4 = offset1>>3;           // register index for 4-bit register arrays
            const Uint32 mask1 = 0x1UL<<offset1;    // mask for registers with 1-bit groups
            const Uint32 mask2 = 0x3UL<<offset2;    // mask for registers with 2-bit groups
            const Uint32 mask4 = 0xFUL<<offset4;    // mask for registers with 4-bit groups

            Hgpio_ctrl hgpio;
            volatile Gpio_ctrl_regs_st& cregs = hgpio.regs[bank];

            apply_mux(id, cfg.mux_sel);

            // unlock
            asm_eallow();
            cregs.lock &= ~mask1;
            volatile Uint32& crdir = cregs.dir;

            // cpu control to cpu1 1 (hardcoded, move to cfg if needed)
            volatile Uint32& csel = cregs.csel[i4];
            csel &= ~mask4; // makes csel = 0 = cpu1


            // direction
            switch(cfg.ioflag)
            {
                case GPIOtun::dir_input:
                {
                    crdir &= ~mask1;
                    break;
                }
                case GPIOtun::dir_output:
                {
                    crdir |= mask1;
                    break;
                }
                default:
                {
                    Bsp::warning();
                    break;
                }
            }

            // open drain : disabled by default (normal operation)
            // invert: non invert by default

            // pullup
            switch(cfg.pu)
            {
                case GPIOtun::pu_en:
                {
                    cregs.pud &= ~mask1;
                    break;
                }
                case GPIOtun::pu_dis:
                {
                    cregs.pud |= mask1;
                    break;
                }
                default:
                {
                    break;
                }
            }

            // qsel
            volatile Uint32& crqsel = cregs.qsel[i2];
            // note that q is already validated to be 0, 1, 2 or 3
            crqsel = (crqsel & ~mask2) | (static_cast<Uint32>(cfg.q) << offset2);

            // Core ownership
            const Uint32 mask = static_cast<Uint32>(cs) << offset4;
            cregs.csel[i4] &= ~mask;
            cregs.csel[i4] |=  mask;

            // lock
            cregs.lock |= mask1;
            asm_edis();
        }
    }

    void GPIOioctl::apply_usb_pins()
    {
        Hgpio_ctrl hgpio;
        volatile Gpio_ctrl_regs_st& cregs = hgpio.regs[1];
        const Uint32 mask = 0x0C00; //0b110000000000;
        //unlock
        asm_eallow();
        cregs.lock &= ~mask;
        //Set bit for usb data port (D- and D+)
        cregs.bamsel |= mask;
        // lock
        cregs.lock |= mask;
        asm_edis();
    }
}
