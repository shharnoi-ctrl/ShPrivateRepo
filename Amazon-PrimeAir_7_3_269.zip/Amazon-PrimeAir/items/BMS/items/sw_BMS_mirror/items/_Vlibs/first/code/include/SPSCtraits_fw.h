///    \file SPSCtraits_fw.h
///
///    \date 2 jul. 2018
///
///    \author  FJBurgos, jbm (at) embention.com
///    Company:  Embention
///
///    SPSCtraits_fw class declaration.
///

#ifndef SPSCTRAITS_FW_H_
#define SPSCTRAITS_FW_H_

namespace Base
{

    /// Traits used by Fifospsc0
    namespace SPSCtraits
    {
        /// reference no managed by fifo
        template <typename T>
        struct External;

        /// reference managed by fifo
        template <typename T>
        struct Internal_ref;

        /// internally instantiated and managed by fifo
        template <typename T>
        struct Internal;

    };

} // namespace Base

#endif // SPSCTRAITS_FW_H_
