#ifndef BITARRAY_H_
#define BITARRAY_H_

#include <Bitarray0.h>
#include <Bitarray_fw.h>
#include <Tnarray.h>
#include <Ttraits.h>
#include <U8pkmblock.h>

namespace Base
{
    /// Fixed-size array of bits.
    template<Uint16 sz0>
    struct Bitarray : Bitarray0<Tnarray<Uint16, bits_to_words16_c<sz0>::value> >
    {
        static const Uint16 sz = sz0;   ///< Bit array size in bits.
        /// Bit Array Size Retriever.
        /// \wi{4959}
        /// Bitarray class shall be able to retrieve its size in bits.
        /// \return Size in bits (::sz).
        Uint16 size() const;
        /// Bit Array Reset.
        /// \wi{4958}
        /// Bitarray class shall be able to set all its internal bits to zero.
        void zeros();
        /// Bit array Set.
        /// \wi{17858}
        /// Bitarray class shall be able to set all its internal bits to one.
        void set_all();

        /// Bit array Value Setter.
        /// \wi{17859}
        /// Bitarray class shall be able to set all its internal bits to a given value when bit 
        /// array size is lower or equals to 64 bits.
        /// \pre This function cannot be used for sizes higher than 64 bits.
        /// \param[in] data Data to be set.
        template <typename T = void>
        typename Enable_if<sz0 <= (Sizeof_bits<Uint64>::value), T>::type
        set_all(const Uint64& data);
        /// Bit Array Value Getter.
        /// \wi{17860}
        /// Bitarray class shall be able to retrieve all its internal bits as a value of a given
        /// type.
        /// \pre This function cannot be used for sizes higher than 64 bits.
        /// \return Bit array value compacted in a given type.
        template <typename T = Uint64>
        typename Enable_if<sz0 <= (Sizeof_bits<T>::value), T>::type
        get_all();

        /// Bit Array Mblock Retriever.
        /// \wi{4957}
        /// Bitarray class shall be able to retrieve the Bitarray Data as a Mblock of Uint16 type.
        /// \return Bitarray data in a Mblock_u16.
        Mblock_u16 to_raw_mblock();
        /// Bit Array Constant Mblock Retriever.
        /// \wi{17861}
        /// Bitarray class shall be able to retrieve the Bitarray Data as a constant Mblock of Uint16 type.
        /// \return Bitarray data in a constant Mblock_u16.
        Mblock<const Uint16> to_raw_mblock() const;
        /// Bit Array All Zeros Checker (Size <= 16).
        /// \wi{17862}
        /// Bitarray class shall be able to check if all its internal values are zeros.
        /// \pre This function cannot be used for sizes higher than 16 bits.
        /// \return True if all its values are zeros, False if not.
        template<Uint16 sz00 = sz0>
        typename Enable_if<sz00 <= 16U, bool>::type
        all_zeros() const
        {
            const Uint16 v16 = *const_cast<Uint16*>(Base_t::v.v);
            return (v16 == 0);
        }
        /// Bit Array All Zeros Checker (Size > 16 and <= 32).
        /// \wi{17863}
        /// Bitarray class shall be able to check if all its internal values are zeros.
        /// \pre This function cannot be used for sizes lower than 16 bits or higher than 32.
        /// \return True if all its internal values are zeros, False if not.
        template<Uint16 sz00 = sz0>
        typename Enable_if<(sz00 <= Sizeof_bits<Uint32>::value) && (sz00 > 16U), bool>::type
        all_zeros() const
        {
            const Uint32 v32 = *reinterpret_cast<Uint32*>(const_cast<Uint16*>(Base_t::v.v));
            return v32 == 0;
        }
        /// Bit Array All zeros Cheker (Size > 32).
        /// \wi{17864}
        /// Bitarray class shall be able to check if all its internal values are zeros.
        /// \pre This function cannot be used for sizes lower than than 32 bits.
        /// \return True if all its internal values are zeros, False if not. 
        template<Uint16 sz00 = sz0>
        typename Enable_if<(sz00 > Sizeof_bits<Uint32>::value), bool>::type
        all_zeros() const;
        /// Bit Array Or Operator.
        /// \wi{17865}
        /// Bitarray class shall provide the capability to performs an OR with provided Bitarray's bits values.
        /// \param[in] bits Bitarray to make the OR.
        void or_bits(const Bitarray<sz0>& bits);

        /// Bit Array AND Operator.
        /// \wi{20136}
        /// Bitarray class shall provide the capability to performs an AND with provided Bitarray bits values.
        /// \param[in] bits Bitarray to make the AND.
        void and_bits(const Bitarray<sz0>& bits);

        /// Bit Array Bits Counter.
        /// \wi{20137}
        /// Bitarray class shall be able to retrieve the total number of set bits.
        /// \return Total number of set bits in the array.
        Uint16 count_bits() const;

    private:
        typedef Bitarray0<Tnarray<Uint16, bits_to_words16_c<sz0>::value> > Base_t;
        static const Uint16 nwords = bits_to_words16_c<sz0>::value;    ///< Size in words
    };

    template<Uint16 sz0>
    inline Uint16 Bitarray<sz0>::size() const
    {
        return sz0;
    }

    template<Uint16 sz0>
    inline void Bitarray<sz0>::zeros()
    {
        Base_t::v.zeros();
    }

    template<Uint16 sz0>
    void Bitarray<sz0>::set_all()
    {
        Base_t::v.set_all(Ku16::uMAX);
    }

    template<Uint16 sz0>
    template <typename T>
    typename Enable_if<sz0 <= (Sizeof_bits<Uint64>::value), T>::type
    Bitarray<sz0>::set_all(const Uint64& data)
    {
        for(Uint16 i = 0; i < nwords; i++)
        {
            Base_t::v[i] = Bitutils::get_uint16(data, i);
        }
    }

    template<Uint16 sz0>
    template <typename T>
    typename Enable_if<sz0 <= (Sizeof_bits<T>::value), T>::type
    Bitarray<sz0>::get_all()
    {
        Uint64 ret = 0;
        for(Uint16 i = 0; i < nwords; i++)
        {
            Bitutils::set_uint16(Base_t::v[i], i, ret);
        }
        return ret;
    }

    template<Uint16 sz0>
    inline Mblock_u16 Bitarray<sz0>::to_raw_mblock()
    {
        return Base_t::v.to_mblock();
    }

    template<Uint16 sz0>
    inline Mblock<const Uint16> Bitarray<sz0>::to_raw_mblock() const
    {
        return Base_t::v.to_mblock();
    }

    template<Uint16 sz0>
    void Bitarray<sz0>::or_bits(const Bitarray<sz0>& bits)
    {
        for(Uint16 i=0; i<nwords; i++)
        {
            Base_t::v[i] |= bits.v[i];
        }
    }

    template<Uint16 sz0>
    void Bitarray<sz0>::and_bits(const Bitarray<sz0>& bits)
    {
        for(Uint16 i=0; i<nwords; i++)
        {
            Base_t::v[i] &= bits.v[i];
        }
    }

    template<Uint16 sz0>
    Uint16 Bitarray<sz0>::count_bits() const
    {
        // Variable precission SWAR algorithm
        Uint16 c = 0U;
        for(Uint16 i = 0; i<nwords; i++)
        {
            Uint16 n = Base_t::v[i];
            n -= ((n >> 1U) & 0x5555);
            n = (n & 0x3333) + ((n >> 2U) & 0x3333);
            n = (n + (n >> 4U)) & 0x0F0F;
            n += (n >> 8);
            c += (n & 0x00FF);
        }
        return c;
    }

    template<Uint16 sz0>
    template<Uint16 sz00>
    typename Enable_if<(sz00 > Sizeof_bits<Uint32>::value), bool>::type
    Bitarray<sz0>::all_zeros() const
    {
        const Uint64 *v64 = reinterpret_cast<Uint64*>(const_cast<Uint16*>(Base_t::v.v));
        const Uint16 size = static_cast<Uint16>(Rmath::ceilr(static_cast<Real>(sz0) / Sizeof_bits<Uint64>::value));
        bool ret = (*v64 == 0);
        for(Uint16 i = 1; (i < size) && ret; i++)
        {
            v64++;
            ret &= (*v64 == 0);
        }
        return ret;
    }
}

#endif
