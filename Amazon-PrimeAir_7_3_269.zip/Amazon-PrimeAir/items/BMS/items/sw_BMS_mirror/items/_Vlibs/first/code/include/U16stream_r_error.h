#ifndef U16STREAM_R_ERROR_H_
#define U16STREAM_R_ERROR_H_

#include <Error.h>
#include <U16stream_r.h>

namespace Base
{
    /// The Base library shall provide a class to handle Unsigned 16-bit sized stream reader with error control.
    class U16stream_r_error : public U16stream_r
    {
    public:
        /// The U16stream_r_error class shall provide a structure to handle 
        /// data traits for Unsigned 16-bit sized stream.
        struct Data_traits16 : public type_is<U16stream_r_error>
        {
            /// Data Traits Data Retriever.
            /// \wi{21031}
            /// Data_traits16 structure shall be able to retrieve data from a U16stream_r_error stream.
            /// \param[in] is  Constant reference to U16stream_r_error stream.  
            /// \return A constant memory block containing the data.
            static inline const Mblock<const Uint16> get_data(const U16stream_r_error& is)
            {
                
                /// \alg
                /// - Call U16stream_r::to_mblock_all for given "is" and access 
                /// the memory block with templated type Mblock::v. 
                /// - Call ::get_max_size with given "is". 
                /// - Construct ::Mblock with previous retrieved results as arguments and return the memory block.
                return Mblock<const Uint16>(is.to_mblock_all().v, is.get_max_size());
            }

            /// Data Traits Size Updater.
            /// \wi{21032}
            /// Data_traits16 structure shall be able to update the size of a U16stream_r_error stream.
            /// \param[in, out] is    Reference to U16stream_r_error stream.
            /// \param[in] sz    The size to update the stream position in 16-bit words.
            static inline void update_size(U16stream_r_error& is, Uint32 sz)
            {
                /// \alg
                /// - Call U16stream_r::get_pos for given "is" and add the retrived value with given "sz".
                /// - Call U16stream_r::set_pos for given "is" with the previous computed result.
                is.set_pos(is.get_pos() + sz);
            }

            /// Data Traits Maximum Size Retriever.
            /// \wi{21033}
            /// Data_traits16 structure shall be able to retrieve the maximum size of a U16stream_r_error stream.
            /// \param[in] is    Reference to U16stream_r_error stream.
            /// \return The maximum size of the stream in 16-bit words.
            static inline Uint16 get_max_size(U16stream_r_error& is)
            {
                /// \alg
                /// - Call Mblock::size on the U16stream_r::to_mblock_all 
                /// for given "is" and retun the retrieved result. 
                return is.to_mblock_all().size();
            }

            /// Data Traits Error Setter.
            /// \wi{21034}
            /// Data_traits16 structure shall be able to launch an assertion and associate and error id if necessary.
            /// \param[in, out] is    Reference to U16stream_r_error stream.
            /// \param[in] err   The error to set. 
            static inline void set_error(U16stream_r_error& is, const Error& err)
            {
                /// \alg
                /// - Call Error::is_ok with given "err".
                /// - Call Error::get_error with given "err".
                /// - Call ::assrt for given "is" with the previous retrieved results as arguments. 
                is.assrt(err.is_ok(), err.get_error());
            }

            /// Data Traits Position Retriever.
            /// \wi{21035}
            /// Data_traits16 structure shall be able to retrieve the current position of U16stream_r_error stream.
            /// \param[in] is    Constant reference to U16stream_r_error stream.
            /// \return The current read position within the stream in 16-bit words.
            static inline Uint16 get_pos(const U16stream_r_error& is)
            {
                /// \alg
                /// - Call U16stream_r::get_pos for given "is" and return the retrieved result. 
                return is.get_pos();
            }
        };

        /// U16stream Read Error Handler Constructor with Given Data Buffer.
        /// \wi{21036}
        /// U16stream_r_error class shall build itself upon construction with the provided parameter.
        /// \param[in] data0     16-bit stream memory block.
        explicit U16stream_r_error(const Mblock<Uint16>& data0);

        /// U16stream Read Error Handler Constructor with Constant Given Data Buffer.
        /// \wi{21037}
        /// U16stream_r_error class shall build itself upon construction with the constant provided parameter.
        /// \param[in] data0     Constant 16-bit stream memory block.
        explicit U16stream_r_error(const Mblock<const Uint16>& data0);

        /// U16stream Read Error Handler Assertion Checker. 
        /// \wi{21038}
        /// U16stream_r_error class shall be able to assert given error source when given check 
        /// is False and return received check.
        /// \param[in] ck     Boolean condition.
        /// \param[in] e_src  Error source to set.
        /// \return           Received boolean condition.
        bool assrt(bool ck, Errorsrc e_src);

        /// U16stream Read Error Handler PDI Errors Checker.
        /// \wi{21039}
        /// U16stream_r_error class shall be able to check if there are no PDI errors.
        /// \return True if there are no errors, otherwise False.
        bool is_ok() const;

        /// U16stream Read Error Handler PDI Failed Setter.
        /// \wi{21040}
        /// U16stream_r_error class shall be able to set the PDI as failed with the provided error code.
        /// \param[in] e_src  Error source indicating the reason for failure.
        void failed(Errorsrc e_src);

        /// U16stream Read Error Handler Error Retriever.
        /// \wi{21041}
        /// U16stream_r_error class shall be able to retrieve the current error object.
        /// \return Reference to the error object.
        Base::Error& get_error();

    private:
        Error err;              ///< Error code.
        U16stream_r_error();                                            ///< = delete.
        U16stream_r_error(const U16stream_r_error& orig);               ///< = delete.
        U16stream_r_error& operator=(const U16stream_r_error& orig);    ///< = delete.
    };

    /// \alg
    /// - ::U16stream_r is initialized with given parameter "mb".
    inline U16stream_r_error::U16stream_r_error(const Mblock<Uint16>& mb) :
        U16stream_r(mb)
    {
    }

    /// \alg
    /// - ::U16stream_r is initialized with given parameter "mb".
    inline U16stream_r_error::U16stream_r_error(const Mblock<const Uint16>& mb) :
        U16stream_r(mb)
    {
    }

    inline bool U16stream_r_error::assrt(bool ck, Errorsrc e_src)
    {
        /// \alg
        /// - Call Error::assrt for ::err with given "ck" and "e_src" and return the result. 
        return err.assrt(ck, e_src);
    }

    inline bool U16stream_r_error::is_ok() const
    {
        /// \alg
        /// - Call Error::is_ok for ::err and return the result. 
        return err.is_ok();
    }

    inline void U16stream_r_error::failed(Errorsrc e_src)
    {
        /// \alg
        /// - Call Error::is_ok failed ::err with given "e_src".
        err.failed(e_src);
    }

    inline Base::Error& U16stream_r_error::get_error()
    {
        /// \alg
        /// - Return ::err.
        return err;
    }
}
#endif
