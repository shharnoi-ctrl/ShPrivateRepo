#ifndef CAN_FD_REGS_H_
#define CAN_FD_REGS_H_

#include <Entypes.h>
#include <Ptr_cast.h>

namespace Dsp28335_ent
{
    namespace MCAN
    {
        enum Base_addr ///< MCAN base addresses.
        {
            mcana_base_addr = 0x00058000UL    ///< MCAN-A base address. Also the start of ram address.
        };


        enum Submodule_addrs ///< Sub-module base addresses
        {
            mcan_msg_mem    = 0x0000U,  ///< Message RAM.
            mcanss_regs     = 0x4400U,  ///< MCAN status registers.
            mcan_regs       = 0x4600U,  ///< MCAN registers.
            mcan_error_regs = 0x4800U   ///< MCAN error registers.
        };

        /// MCAN SS REGS offsets
        enum SS_regs
        {
            mcanss_pid                         = mcanss_regs + 0x00U,   ///<  PID  Register.
            mcanss_ctrl                        = mcanss_regs + 0x04U,   ///<  CTRL Register.
            mcanss_stat                        = mcanss_regs + 0x08U,   ///<  STAT Register.
            mcanss_ics                         = mcanss_regs + 0x0CU,   ///<  ICS  Register.
            mcanss_irs                         = mcanss_regs + 0x10U,   ///<  ICR  Register.
            mcanss_iecs                        = mcanss_regs + 0x14U,   ///<  IECS Register.
            mcanss_ie                          = mcanss_regs + 0x18U,   ///<  IS   Register.
            mcanss_ies                         = mcanss_regs + 0x1CU,   ///<  IES  Register.
            mcanss_eoi                         = mcanss_regs + 0x20U,   ///<  EOI  Register.
            mcanss_ext_ts_prescaler            = mcanss_regs + 0x24U,   ///<  EXT ts prescaler Register.
            mcanss_ext_ts_unserviced_intr_cntr = mcanss_regs + 0x28U    ///<  EXT ts unserviced conuter Register.
        };

        /// MCAN REGS offsets
        enum MCAN_regs
        {
            mcan_crel           = mcan_regs + 0x00UL,   ///< CREL Register.
            mcan_endn           = mcan_regs + 0x04UL,   ///< ENDN Register.
            mcan_cust           = mcan_regs + 0x08UL,   ///< CUST Register.
            mcan_dbtp           = mcan_regs + 0x0cUL,   ///< DBTP Register.
            mcan_test           = mcan_regs + 0x10UL,   ///< TEST Register.
            mcan_rwd            = mcan_regs + 0x14UL,   ///< RWD  Register.
            mcan_cccr           = mcan_regs + 0x18UL,   ///< CCCR Register.
            mcan_nbtp           = mcan_regs + 0x1cUL,   ///< NBTP Register.
            mcan_tscc           = mcan_regs + 0x20UL,   ///< TSCC Register.
            mcan_tscv           = mcan_regs + 0x24UL,   ///< TSCV Register.
            mcan_tocc           = mcan_regs + 0x28UL,   ///< TOCC Register.
            mcan_tocv           = mcan_regs + 0x2cUL,   ///< TOCV Register.
            mcan_ecr            = mcan_regs + 0x40UL,   ///< ECR  Register.
            mcan_psr            = mcan_regs + 0x44UL,   ///< PSR  Register.
            mcan_tdcr           = mcan_regs + 0x48UL,   ///< TDCR Register.
            mcan_ir             = mcan_regs + 0x50UL,   ///< IR   Register.
            mcan_ie             = mcan_regs + 0x54UL,   ///< IE   Register.
            mcan_ils            = mcan_regs + 0x58UL,   ///< ILS  Register.
            mcan_ile            = mcan_regs + 0x5cUL,   ///< ILE  Register.
            mcan_gfc            = mcan_regs + 0x80UL,   ///< GFC  Register.
            mcan_sidfc          = mcan_regs + 0x84UL,   ///< SIDFC Register.
            mcan_xidfc          = mcan_regs + 0x88UL,   ///< XIDFC Register.
            mcan_xidam          = mcan_regs + 0x90UL,   ///< XIDAM Register.
            mcan_hpms           = mcan_regs + 0x94UL,   ///< HPMS  Register.
            mcan_ndat1          = mcan_regs + 0x98UL,   ///< NDAT1 Register.
            mcan_ndat2          = mcan_regs + 0x9cUL,   ///< NDAT2 Register.
            mcan_rxf0c          = mcan_regs + 0xa0UL,   ///< RXF0C Register.
            mcan_rxf0s          = mcan_regs + 0xa4UL,   ///< RXF0S Register.
            mcan_rxf0a          = mcan_regs + 0xa8UL,   ///< RXFA  Register.
            mcan_rxbc           = mcan_regs + 0xacUL,   ///< RXBC  Register.
            mcan_rxf1c          = mcan_regs + 0xb0UL,   ///< RXF1C Register.
            mcan_rxf1s          = mcan_regs + 0xb4UL,   ///< RXF1S Register.
            mcan_rxf1a          = mcan_regs + 0xb8UL,   ///< RXF1A Register.
            mcan_rxesc          = mcan_regs + 0xbcUL,   ///< RXESC Register.
            mcan_txbc           = mcan_regs + 0xc0UL,   ///< TXBC  Register.
            mcan_txfqs          = mcan_regs + 0xc4UL,   ///< TXFQS Register.
            mcan_txesc          = mcan_regs + 0xc8UL,   ///< TXESC Register.
            mcan_txbrp          = mcan_regs + 0xccUL,   ///< TXBRP Register.
            mcan_txbar          = mcan_regs + 0xd0UL,   ///< TXBAR Register.
            mcan_txbcr          = mcan_regs + 0xd4UL,   ///< TXBCR Register.
            mcan_txbto          = mcan_regs + 0xd8UL,   ///< TXBTO Register.
            mcan_txbcf          = mcan_regs + 0xdcUL,   ///< TXBCF Register.
            mcan_txbtie         = mcan_regs + 0xe0UL,   ///< TXBTIE Register.
            mcan_txbcie         = mcan_regs + 0xe4UL,   ///< TXBCIE Register.
            mcan_txefc          = mcan_regs + 0xf0UL,   ///< TXEFC Register.
            mcan_txefs          = mcan_regs + 0xf4UL,   ///< TXEFS Register.
            mcan_txefa          = mcan_regs + 0xf8UL    ///< TXEFA Register.
        };

        union Frame_elem_id ///< Frame Element Header Data.
        {
            Uint32 all;         ///< 32 bit representation of the whole register.
            struct
            {
                Uint32 id:29;   ///< ID
                Uint32 rtr:1;   ///< RTR. Remote Transmission Request.
                Uint32 xtd:1;   ///< XTD. Extended Identifier(1) or standard(0).
                Uint32 esi:1;   ///< ESI. Error State Indicator.
            };
        };

        union Rx_frame_elem_format ///< Rx frame Element Format.
        {
            Uint32 all;         ///< 32 bit representation of the whole register.
            struct
            {
                Uint32 tstamp1:16;  ///< Rx timestamp.
                Uint32 dlc:4;       ///< DLC. Data Length Code.
                Uint32 brs:1;       ///< Bit Rate Switch enabled(1), disabled(0).
                Uint32 fdf:1;       ///< CAN-FD format(1), CAN20 format (0)
                Uint32 res2:2;      ///< Reserved
                Uint32 findex:7;    ///< Filter index.
                Uint32 anmf:1;      ///< Accepted Non Matching Frame
            };
        };

        union Tx_frame_elem_format ///< Tx frame Element Format.
        {
            Uint32 all;         ///< 32 bit representation of the whole register.
            struct
            {
                Uint32 res1:16; ///< Reserved
                Uint32 dlc:4;   ///< DLC. Data Length Code.
                Uint32 brs:1;   ///< Bit Rate Switch enabled(1), disabled(0).
                Uint32 fdf:1;   ///< CAN-FD format(1), CAN20 format (0)
                Uint32 res2:1;  ///< Reserved
                Uint32 efc:1;   ///< Event FIFO Control.
                Uint32 mm:8;    ///< Message marker.
            };
        };

        struct Msg_ram ///< Message RAM
        {
            static const Uint32 sz = 0x4400UL>>1;       ///< Size of this struct in 16bit words.
            static const Uint32 mcan_ram_sz = 4352UL;   ///< RAM size.
            Uint32 msg_ram[mcan_ram_sz];                ///< MSg RAM.
            Uint32 res[sz - mcan_ram_sz];               ///< Reserved
        };


        // MCAN Filters

        union Std_filter ///< MCAN Standard Filter Element.
        {
            struct
            {
                Uint32 sfid2:11;///< Standard Filter ID 2.
                Uint32 res1:5;  ///< Reserved
                Uint32 sfid1:11;///< Standard Filter ID 1.
                Uint32 sfec:3;  ///< Standard Filter Element Configuration.
                Uint32 sft:2;   ///< Standard Filter Type.
            };
            Uint32 all;         ///< 32 bit representation of the whole register.
        };

        union Ext_filter0 ///< MCAN Extended Filter Element 0.
        {
            struct
            {
                Uint32 efid1:29;///< Extended Filter ID 1.
                Uint32 efec:3;  ///< Extended Filter Element Configuration.
            };
            Uint32 all;         ///< 32 bit representation of the whole register.
        };

        union Ext_filter1 ///< MCAN Extended Filter Element 01.
        {
            struct
            {
                Uint32 efid2:29;///< Extended Filter ID 1.
                Uint32 res1:1;  ///< Reserved
                Uint32 eft:2;   ///< Extended Filter Type.
            };
            Uint32 all;         ///< 32 bit representation of the whole register.
        };

        // MCAN SS Registers  -----------------------------------------
        union SS_CTRL ///< MCAN Subsystem Control Register.
        {
            Uint32 all;                 ///< 32 bit representation of the whole register.
            struct
            {
                Uint32 res1:3;          ///< Reserved
                Uint32 dbgsusp_free:1;  ///< Debug Suspend Free Bit. Enables debug suspend.
                Uint32 wakeureqen:1;    ///< Wakeup Request Enable.
                Uint32 autowakeup:1;    ///< Automatic Wakeup Enable.
                Uint32 ext_ts_cntr_en:1;///< External Timestamp Counter Enable.
                Uint32 res2:24;         ///< Reserved
            };
        };

        union SS_STAT ///< MCAN Subsystem Status Register
        {
            Uint32 all;                 ///< 32 bit representation of the whole register.
            struct
            {
                Uint32 reset:1;         ///< Reset in progress(1).
                Uint32 mem_init_done:1; ///< Memory initialization finished (1).
                Uint32 enabled_fdoe:1;  ///< Flexible Datarate Operation Enable.
                Uint32 res:29;          ///< Reserved
            };
        };

        // MCAN Registers  -----------------------------------------
        union NBTP ///< MCAN Nominal Bit Timing and Prescaler Register
        {
            Uint32 all;             ///< 32 bit representation of the whole register.
            struct
            {
                Uint32 ntseg2:7;    ///< Nominal Time Segment After Sample Point [1, 127].
                Uint32 res1:1;      ///< Reserved
                Uint32 ntseg1:8;    ///< Nominal Time Segment Before Sample Point [1, 255].
                Uint32 nbrp:9;      ///< Nominal Bit Rate Prescaler [0, 511].
                Uint32 nsjw:7;      ///< Nominal Resynchronization Jump Width [0,127].
            };
        };

        union DBTP ///< MCAN Data Bit Timing and Prescaler Register
        {
            Uint32 all;             ///< 32 bit representation of the whole register.
            struct
            {
                Uint32 dsjw:4;      ///< Data Resynchronization Jump Width.
                Uint32 dtseg2:4;    ///< Data Time Segment After Sample Point [0, 15].
                Uint32 dtseg1:5;    ///< Data Time Segment Before Sample Point [0, 31].
                Uint32 res1:3;      ///< Reserved
                Uint32 dbrp:5;      ///< Data Bit Rate Prescaler [0, 31].
                Uint32 res2:2;      ///< Reserved
                Uint32 tdce:1;      ///< Transmitter Delay Compensation Enable.
                Uint32 res3:8;      ///< Reserved
            };
        };

        union RWD ///< MCAN RAM Watchdog
        {
            Uint32 all;         ///< 32 bit representation of the whole register.
            struct
            {
                Uint32 wdc:8;   ///< Watchdog Configuration.
                Uint32 wdv:8;   ///< Watchdog Value.
                Uint32 res1:16; ///< Reserved
            };
        };

        union CCCR ///< MCAN CC Control Register
        {
            Uint32 all;         ///< 32 bit representation of the whole register.
            struct
            {
                Uint32 init:1;  ///< Initialization.
                Uint32 cce:1;   ///< Configuration Change Enable.
                Uint32 asm0:1;  ///< Restricted Operation Mode.
                Uint32 csa:1;   ///< Clock Stop Acknowledge.
                Uint32 csr:1;   ///< Clock Stop Request.
                Uint32 mon:1;   ///< Bus Monitoring Mode.
                Uint32 dar:1;   ///< Disable Automatic Retransmission.
                Uint32 test:1;  ///< Test Mode Enable
                Uint32 fdoe:1;  ///< Flexible Datarate Operation Enable.
                Uint32 brse:1;  ///< Bit Rate Switch Enable.
                Uint32 res1:2;  ///< Reserved
                Uint32 pxhd:1;  ///< Protocol Exception Handling Disable.
                Uint32 efbi:1;  ///< Edge Filtering during Bus Integration.
                Uint32 txp:1;   ///< Transmit Pause.
                Uint32 niso:1;  ///< Non ISO Operation.
                Uint32 res2:16; ///< Reserved
            };
        };

        union ECR ///< MCAN Error Counter Register.
        {
            Uint32 all;         ///< 32 bit representation of the whole register.
            struct
            {
                Uint32 tec:8;   ///< Transmit Error Counter.
                Uint32 rec:8;   ///< Receive  Error Counter.
                Uint32 rp:1;    ///< Receive Error Passive
                Uint32 cel:8;   ///< CAN Error Logging.
                Uint32 res:7;   ///< Reserved
            };
        };

        union PSR ///< MCAN Protocol Status Register.
        {
            Uint32 all;         ///< 32 bit representation of the whole register.
            struct
            {
                Uint32 lec:3;   ///< Last Error Code.
                Uint32 act:2;   ///< Node Activity.
                Uint32 ps:1;    ///< Error passive.
                Uint32 ew:1;    ///< Warning status (0 no warning, 1 warning).
                Uint32 bo:1;    ///< Bus off status. (0 ok, 1 bus off).
                Uint32 dlec:3;  ///< Data Phase Last Error Code.
                Uint32 resi:1;  ///< ESI Flag of Last Received CAN FD Message.
                Uint32 rbrs:1;  ///< BRS Flag of Last Received CAN FD Message.
                Uint32 rfdf:1;  ///< Received a CAN FD Message.
                Uint32 pxe:1;   ///< Protocol Exception Event.
                Uint32 res1:1;  ///< Reserved
                Uint32 tvdc:7;  ///< Transmitter Delay Compensation Value.
                Uint32 res2:9;  ///< Reserved
            };
        };

        union TDCR ///< MCAN Transmitter Delay Compensation Register.
        {
            Uint32 all;         ///< 32 bit representation of the whole register.
            struct
            {
                Uint32 tdcf:7;  ///< Transmitter Delay Compensation Filter Window Length.
                Uint32 res1:1;  ///< Reserved
                Uint32 tdco:7;  ///<  Transmitter Delay Compensation Offset.
                Uint32 res2:1;  ///< Reserved
                Uint32 res3:16; ///< Reserved
            };
        };

        union GFC ///< MCAN Global Filter Configuration
        {
            Uint32 all;         ///< 32 bit representation of the whole register.
            struct
            {
                Uint32 rrfe:1;  ///< Reject Remote Frames Extended
                Uint32 rrfs:1;  ///< Reject Remote Frames Standard
                Uint32 anfe:2;  ///< Accept Non-matching Frames Extended
                Uint32 anfs:2;  ///< Accept Non-matching Frames Standard
                Uint32 res2:26; ///< Reserved
            };
        };

        union SIDFC ///< MCAN Standard ID Filter Configuration
        {
            Uint32 all;         ///< 32 bit representation of the whole register.
            struct
            {
                Uint32 res1:2;  ///< Reserved
                Uint32 flssa:14;///< Filter List Standard Start Address
                Uint32 lss:8;   ///< Filter List Standard Start Address
                Uint32 res2:8;  ///< Reserved
            };
        };

        union XIDFC ///< MCAN Extended ID Filter Configuration
        {
            Uint32 all;         ///< 32 bit representation of the whole register.
            struct
            {
                Uint32 res1:2;  ///< Reserved
                Uint32 flesa:14;///< Filter List Extended Start Address
                Uint32 lse:7;   ///< Filter List Extended Start Address
                Uint32 res2:9;  ///< Reserved
            };
        };

        union RXBC ///< MCAN Rx Buffer Configuration
        {
            Uint32 all;         ///< 32 bit representation of the whole register.
            struct
            {
                Uint32 res1:2;  ///< Reserved
                Uint32 rbsa:14; ///< Rx Buffer Start Address.
                Uint32 res2:16; ///< Reserved
            };
        };

        union RXFxC ///< MCAN Rx FIFO X Configuration.
        {
            Uint32 all;         ///< 32 bit representation of the whole register.
            struct
            {
                Uint32 res1:2;  ///< Reserved
                Uint32 fxsa:14; ///< Rx FIFO X Start Address (32-bit word address).
                Uint32 fxs:7;   ///< Rx FIFO X Size.
                Uint32 res2:1;  ///< Reserved
                Uint32 fxwm:7;  ///< Rx FIFO X Watermark.
                Uint32 fxom:1;  ///< FIFO X Mode: overwrite mode(1), blocking mode(0).
            };
        };

        union RXFxS ///< MCAN Rx FIFO 1 Status
        {
            Uint32 all;         ///< 32 bit representation of the whole register.
            struct
            {
                Uint32 fxfl:7;  ///< Rx FIFO X Fill Level. Number of elements stored in Rx FIFO 1, range 0 to 64.
                Uint32 res1:1;  ///< Reserved
                Uint32 fxgi:6;  ///< Rx FIFO X Get Index. Rx FIFO 1 read index pointer, range 0 to 63.
                Uint32 res2:2;  ///< Reserved
                Uint32 fxpi:6;  ///< Rx FIFO X Put Index. Rx FIFO 1 write index pointer, range 0 to 63.
                Uint32 res3:2;  ///< Reserved
                Uint32 fxf:1;   ///<  Rx FIFO X Full (1) / not full(0).
                Uint32 rfxl:1;  ///<  Rx FIFO X Message Lost.
                Uint32 res4:4;  ///< Reserved
                Uint32 dms:2;   ///<  Debug Message Status.
            };
        };

        union RXFxA ///< MCAN Rx FIFO X Acknowledge
        {
            Uint32 all;         ///< 32 bit representation of the whole register.
            struct
            {
                Uint32 fxai:6;  ///< Rx FIFO X Acknowledge Index
                Uint32 res1:26; ///< Reserved
            };
        };

        union RXESC ///< MCAN Rx Buffer / FIFO Element Size Configuration.
        {
            Uint32 all;         ///< 32 bit representation of the whole register.
            struct
            {
                Uint32 f0ds:3;  ///< Rx FIFO 0 Data Field Size.
                Uint32 res1:1;  ///< Reserved
                Uint32 f1ds:3;  ///< Rx FIFO 1 Data Field Size.
                Uint32 res2:1;  ///< Reserved
                Uint32 rbds:3;  ///< Rx Buffer Data Field Size.
                Uint32 res3:5;  ///< Reserved
                Uint32 res4:16; ///< Reserved
            };
        };

        union TXBC ///< MCAN Tx Buffer Configuration
        {
            Uint32 all;         ///< 32 bit representation of the whole register.
            struct
            {
                Uint32 res1:2;  ///< Reserved
                Uint32 tbsa:14; ///< Tx Buffers Start Address. Tx Buffers section in Message RAM (32-bit word address).
                Uint32 ndbt:6;  ///< NDTB R/WQ 0h Number of Dedicated Transmit Buffers.
                Uint32 res2:2;  ///< Reserved
                Uint32 tfqs:6;  ///< TFQS R/WQ 0h Transmit FIFO/Queue Size.
                Uint32 tfqm:1;  ///< TFQM R/WQ 0h Tx FIFO(0)/Queue Mode(1).
                Uint32 res3:1;  ///< Reserved
            };
        };

        union TXFQS ///< MCAN Tx FIFO / Queue Status
        {
            Uint32 all;         ///< 32 bit representation of the whole register.
            struct
            {
                Uint32 tffl:6;  ///< Tx FIFO Free Level. Number of consecutive free Tx FIFO elements.
                Uint32 res1:2;  ///< Reserved
                Uint32 tfgi:5;  ///< Tx FIFO Get Index. Tx FIFO read index pointer, range 0 to 31.
                Uint32 res2:3;  ///< Reserved
                Uint32 tfqp:5;  ///< Tx FIFO/Queue Put Index. Tx FIFO/Queue write index pointer, range 0 to 31.
                Uint32 tfqf:1;  ///< Tx FIFO/Queue Full (1), not full (0)
                Uint32 res3:10; ///< Reserved
            };
        };

        union TXESC ///< MCAN Tx Buffer Element Size Configuration
        {
            Uint32 all;         ///< 32 bit representation of the whole register.
            struct
            {
                Uint32 tbds:3;  ///< Tx Buffer Data Field Size (8,12,16,20,24,32,48,64)
                Uint32 res1:29; ///< Reserved
            };
        };

        struct TXBAR ///< MCAN Tx Buffer Add Request
        {
            Uint32 all;         ///< 32 bit representation of the whole register.
        };

        union TXEFC ///< MCAN Tx Event FIFO Configuration
        {
            Uint32 all;         ///< 32 bit representation of the whole register.
            struct
            {
                Uint32 res1:2;  ///< Reserved
                Uint32 efsa:14; ///< Event FIFO Start Address.
                Uint32 efs:6;   ///< Event FIFO Size.
                Uint32 res2:2;  ///< Reserved
                Uint32 efwm:6;  ///< Event FIFO Watermark.
                Uint32 res3:2;  ///< Reserved
            };
        };

        /// Read register at given address.
        /// \param addr Address of the register to read.
        /// \return Register value for given address.
        template<typename T>
        inline const T read_reg(size_t addr)
        {
            Base::Assertions::Compile_time<sizeof(T)==sizeof(Uint32)>();
            const T r = { Base::get_mem<Uint32>(addr) };
            return r;
        }

        /// Write register at given address-
        /// \param addr  Address of the register to write.
        /// \param value Value to write.
        inline void write_reg(size_t addr, Uint32 value)
        {
            Base::get_mem<Uint32>(addr) = value;
        }
    }
}
#endif
