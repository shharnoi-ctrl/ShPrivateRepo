#include <Emif1.h>
#include <Asm.h>
#include <Assertions.h>
#include <Hdual.h>
#include <Hregmap.h>

#include "Emif1_regs.h" //PRQA S 1015

namespace Dsp28335_ent
{
    //
    // values for async_csx_cr registers
    //
    enum Emif_async_asize
    {
        emif_async_asize_8  = 0,
        emif_async_asize_16 = 1,
        emif_async_asize_32 = 2
    };

    enum Emif_async_ta
    {
        emif_async_ta_1 = 0,
        emif_async_ta_2 = 1,
        emif_async_ta_3 = 2,
        emif_async_ta_4 = 3
    };

    enum Emif_async_rhold
    {
        emif_async_rhold_1 = 0,
        emif_async_rhold_2 = 1,
        emif_async_rhold_3 = 2,
        emif_async_rhold_4 = 3,
        emif_async_rhold_5 = 4,
        emif_async_rhold_6 = 5,
        emif_async_rhold_7 = 6,
        emif_async_rhold_8 = 7
    };

    enum Emif_async_rstrobe
    {
        emif_async_rstrobe_01 =  0,
        emif_async_rstrobe_02 =  1,
        emif_async_rstrobe_03 =  2,
        emif_async_rstrobe_04 =  3,
        emif_async_rstrobe_05 =  4,
        emif_async_rstrobe_06 =  5,
        emif_async_rstrobe_07 =  6,
        emif_async_rstrobe_08 =  7,
        emif_async_rstrobe_09 =  8,
        emif_async_rstrobe_10 =  9,
        emif_async_rstrobe_11 = 10,
        emif_async_rstrobe_12 = 11,
        emif_async_rstrobe_13 = 12,
        emif_async_rstrobe_14 = 13,
        emif_async_rstrobe_15 = 14,
        emif_async_rstrobe_16 = 15,
        emif_async_rstrobe_17 = 16,
        emif_async_rstrobe_18 = 17,
        emif_async_rstrobe_19 = 18,
        emif_async_rstrobe_20 = 19,
        emif_async_rstrobe_21 = 20,
        emif_async_rstrobe_22 = 21,
        emif_async_rstrobe_23 = 22,
        emif_async_rstrobe_24 = 23,
        emif_async_rstrobe_25 = 24,
        emif_async_rstrobe_26 = 25,
        emif_async_rstrobe_27 = 26,
        emif_async_rstrobe_28 = 27,
        emif_async_rstrobe_29 = 28,
        emif_async_rstrobe_30 = 29,
        emif_async_rstrobe_31 = 30,
        emif_async_rstrobe_32 = 31,
        emif_async_rstrobe_33 = 32,
        emif_async_rstrobe_34 = 33,
        emif_async_rstrobe_35 = 34,
        emif_async_rstrobe_36 = 35,
        emif_async_rstrobe_37 = 36,
        emif_async_rstrobe_38 = 37,
        emif_async_rstrobe_39 = 38,
        emif_async_rstrobe_40 = 39,
        emif_async_rstrobe_41 = 40,
        emif_async_rstrobe_42 = 41,
        emif_async_rstrobe_43 = 42,
        emif_async_rstrobe_44 = 43,
        emif_async_rstrobe_45 = 44,
        emif_async_rstrobe_46 = 45,
        emif_async_rstrobe_47 = 46,
        emif_async_rstrobe_48 = 47,
        emif_async_rstrobe_49 = 48,
        emif_async_rstrobe_50 = 49,
        emif_async_rstrobe_51 = 50,
        emif_async_rstrobe_52 = 51,
        emif_async_rstrobe_53 = 52,
        emif_async_rstrobe_54 = 53,
        emif_async_rstrobe_55 = 54,
        emif_async_rstrobe_56 = 55,
        emif_async_rstrobe_57 = 56,
        emif_async_rstrobe_58 = 57,
        emif_async_rstrobe_59 = 58,
        emif_async_rstrobe_60 = 59,
        emif_async_rstrobe_61 = 60,
        emif_async_rstrobe_62 = 61,
        emif_async_rstrobe_63 = 62,
        emif_async_rstrobe_64 = 63
    };

    enum Emif_async_rsetup
    {
        emif_async_rsetup_01 =  0,
        emif_async_rsetup_02 =  1,
        emif_async_rsetup_03 =  2,
        emif_async_rsetup_04 =  3,
        emif_async_rsetup_05 =  4,
        emif_async_rsetup_06 =  5,
        emif_async_rsetup_07 =  6,
        emif_async_rsetup_08 =  7,
        emif_async_rsetup_09 =  8,
        emif_async_rsetup_10 =  9,
        emif_async_rsetup_11 = 10,
        emif_async_rsetup_12 = 11,
        emif_async_rsetup_13 = 12,
        emif_async_rsetup_14 = 13,
        emif_async_rsetup_15 = 14,
        emif_async_rsetup_16 = 15
    };

    enum Emif_async_whold
    {
        emif_async_whold_1 = 0,
        emif_async_whold_2 = 1,
        emif_async_whold_3 = 2,
        emif_async_whold_4 = 3,
        emif_async_whold_5 = 4,
        emif_async_whold_6 = 5,
        emif_async_whold_7 = 6,
        emif_async_whold_8 = 7,
    };

    enum Emif_async_wstrobe
    {
        emif_async_wstrobe_01 =  0,
        emif_async_wstrobe_02 =  1,
        emif_async_wstrobe_03 =  2,
        emif_async_wstrobe_04 =  3,
        emif_async_wstrobe_05 =  4,
        emif_async_wstrobe_06 =  5,
        emif_async_wstrobe_07 =  6,
        emif_async_wstrobe_08 =  7,
        emif_async_wstrobe_09 =  8,
        emif_async_wstrobe_10 =  9,
        emif_async_wstrobe_11 = 10,
        emif_async_wstrobe_12 = 11,
        emif_async_wstrobe_13 = 12,
        emif_async_wstrobe_14 = 13,
        emif_async_wstrobe_15 = 14,
        emif_async_wstrobe_16 = 15,
        emif_async_wstrobe_17 = 16,
        emif_async_wstrobe_18 = 17,
        emif_async_wstrobe_19 = 18,
        emif_async_wstrobe_20 = 19,
        emif_async_wstrobe_21 = 20,
        emif_async_wstrobe_22 = 21,
        emif_async_wstrobe_23 = 22,
        emif_async_wstrobe_24 = 23,
        emif_async_wstrobe_25 = 24,
        emif_async_wstrobe_26 = 25,
        emif_async_wstrobe_27 = 26,
        emif_async_wstrobe_28 = 27,
        emif_async_wstrobe_29 = 28,
        emif_async_wstrobe_30 = 29,
        emif_async_wstrobe_31 = 30,
        emif_async_wstrobe_32 = 31,
        emif_async_wstrobe_33 = 32,
        emif_async_wstrobe_34 = 33,
        emif_async_wstrobe_35 = 34,
        emif_async_wstrobe_36 = 35,
        emif_async_wstrobe_37 = 36,
        emif_async_wstrobe_38 = 37,
        emif_async_wstrobe_39 = 38,
        emif_async_wstrobe_40 = 39,
        emif_async_wstrobe_41 = 40,
        emif_async_wstrobe_42 = 41,
        emif_async_wstrobe_43 = 42,
        emif_async_wstrobe_44 = 43,
        emif_async_wstrobe_45 = 44,
        emif_async_wstrobe_46 = 45,
        emif_async_wstrobe_47 = 46,
        emif_async_wstrobe_48 = 47,
        emif_async_wstrobe_49 = 48,
        emif_async_wstrobe_50 = 49,
        emif_async_wstrobe_51 = 50,
        emif_async_wstrobe_52 = 51,
        emif_async_wstrobe_53 = 52,
        emif_async_wstrobe_54 = 53,
        emif_async_wstrobe_55 = 54,
        emif_async_wstrobe_56 = 55,
        emif_async_wstrobe_57 = 56,
        emif_async_wstrobe_58 = 57,
        emif_async_wstrobe_59 = 58,
        emif_async_wstrobe_60 = 59,
        emif_async_wstrobe_61 = 60,
        emif_async_wstrobe_62 = 61,
        emif_async_wstrobe_63 = 62,
        emif_async_wstrobe_64 = 63
    };

    enum Emif_async_wsetup
    {
        emif_async_wsetup_01 =  0,
        emif_async_wsetup_02 =  1,
        emif_async_wsetup_03 =  2,
        emif_async_wsetup_04 =  3,
        emif_async_wsetup_05 =  4,
        emif_async_wsetup_06 =  5,
        emif_async_wsetup_07 =  6,
        emif_async_wsetup_08 =  7,
        emif_async_wsetup_09 =  8,
        emif_async_wsetup_10 =  9,
        emif_async_wsetup_11 = 10,
        emif_async_wsetup_12 = 11,
        emif_async_wsetup_13 = 12,
        emif_async_wsetup_14 = 13,
        emif_async_wsetup_15 = 14,
        emif_async_wsetup_16 = 15
    };

    enum Emif_async_ew
    {
        emif_async_ew_disable = 0,
        emif_async_ew_enable  = 1
    };

    enum Emif_async_ss
    {
        emif_async_ss_disable = 0,
        emif_async_ss_enable  = 1
    };

    //PRQA S 2176 --
    //#Unions used in HW register mapping in Texas Instruments' libraries.
    //PRQA S 2301 --
    //#Bit-fields are needed.
    //PRQA S 5050 --
    //#Identifiers will be kept by default
    //PRQA S 5051 --
    //#Identifiers will be kept by default

    Emif1::Emif1() :
            emif1_regs(get_emif1_regs()),
            emif1_cfg_regs(get_emif1_config_regs())
    {
    }

    Uint32 Emif1::get_async_cs2_cr()
    {
        return emif1_regs.ASYNC_CS2_CR.all;
    }

    void Emif1::set_async_cs2_cr_veronte4()
    {
        //Tested to 100 juntion 50
        emif1_regs.ASYNC_CS2_CR.bit.ASIZE    = emif_async_asize_16    ; // 16Bit Memory Interface
        emif1_regs.ASYNC_CS2_CR.bit.TA       = emif_async_ta_1        ; // Turn Around time in tics of Emif Clock
        emif1_regs.ASYNC_CS2_CR.bit.R_HOLD   = emif_async_rhold_1     ; // Read Hold time in tics of Emif Clock
        emif1_regs.ASYNC_CS2_CR.bit.R_STROBE = emif_async_rstrobe_04  ; // Read Strobe time in tics of Emif Clock
        emif1_regs.ASYNC_CS2_CR.bit.R_SETUP  = emif_async_rsetup_01   ; // Read Setup time in tics of Emif Clock
        emif1_regs.ASYNC_CS2_CR.bit.W_HOLD   = emif_async_whold_1     ; // Write Hold time in tics of Emif Clock
        emif1_regs.ASYNC_CS2_CR.bit.W_STROBE = emif_async_wstrobe_03  ; // Write Strobe time in tics of Emif Clock
        emif1_regs.ASYNC_CS2_CR.bit.W_SETUP  = emif_async_wsetup_01   ; // Write Setup time in tics of Emif Clock
        emif1_regs.ASYNC_CS2_CR.bit.EW       = emif_async_ew_disable  ; // Extended Wait Disable.
        emif1_regs.ASYNC_CS2_CR.bit.SS       = emif_async_ss_disable  ; // Strobe Select Mode Disable.
    }

    Uint32 Emif1::get_msel()
    {
        return emif1_cfg_regs.EMIF1MSEL.all;
    }

    inline void Emif1::assert_msel(Uint32 rd_expected)
    {
        Base::Assertions::runtime(emif1_cfg_regs.EMIF1MSEL.all == rd_expected);
    }

    void Emif1::set_msel(Uint32 msel0, Uint32 rd_expected)
    {
        asm_eallow();
        emif1_cfg_regs.EMIF1MSEL.all = msel0;
        asm_edis();
        assert_msel(rd_expected);
    }

    static const Uint64 msel_free_wr = 0x93A5CE70UL;
    static const Uint32 msel_free_rd =        0x0UL;
    static const Uint64 msel_cpu1_wr = 0x93A5CE71UL;
    static const Uint32 msel_cpu1_rd =        0x1UL;
    static const Uint32 msel_cpu2_wr = 0x93A5CE72UL;
    static const Uint32 msel_cpu2_rd =        0x2UL;

    void Emif1::cpu1_grab()
    {
        Hdual::assert_is_cpu1();
        set_msel(msel_cpu1_wr,msel_cpu1_rd);
    }

    void Emif1::cpu2_grab()
    {
        Hdual::assert_is_cpu2();
        set_msel(msel_cpu2_wr,msel_cpu2_rd);
    }

    void Emif1::ungrab()
    {
        set_msel(msel_free_wr, msel_free_rd);
    }

    void Emif1::assert_is_grabbed_by_cpu1()
    {
        assert_msel(msel_cpu1_rd);
    }

    void Emif1::lock()
    {
        asm_eallow();
        //Disable Access Protection (CPU_FETCH/CPU_WR/DMA_WR)
        emif1_cfg_regs.EMIF1ACCPROT0.all = 0x0;
        Base::Assertions::runtime(emif1_cfg_regs.EMIF1ACCPROT0.all == 0x0);

        // Commit the configuration related to protection. Till this bit remains set
        // content of EMIF1ACCPROT0 register can't be changed.
        emif1_cfg_regs.EMIF1COMMIT.all = 0x1;
        Base::Assertions::runtime(emif1_cfg_regs.EMIF1COMMIT.all == 0x1);

        // Lock the configuration so that EMIF1COMMIT register can't be changed any more.
        emif1_cfg_regs.EMIF1LOCK.all = 0x1;
        Base::Assertions::runtime(emif1_cfg_regs.EMIF1LOCK.all == 1);
        asm_edis();
    }
}
