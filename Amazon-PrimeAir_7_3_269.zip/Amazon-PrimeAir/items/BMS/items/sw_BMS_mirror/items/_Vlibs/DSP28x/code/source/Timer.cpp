//PRQA S 5051 EOF
//#Identifiers will be kept by default

#include <Timer.h>
#include <Kclk.h>
#include <Vtraits.h>
#include <Asm.h>

#include "Timer_Regs.h"

namespace Dsp28335_ent
{

    Timer::Timer(Id id0, Real period, bool start0) :
            id(id0),
            regs(get_regs(id))
    {
        /// \alg
        /// <ul>
        /// <li> Initialize internal ID (::id) with given one.
        /// <li> Initialize ::regs with retrieved value from ::get_regs function passing received timer ID.
        /// <li> Configure period calling to ::config with given period.
        /// <li> Call to ::set_running with given start0 value.
        /// </ul>
        config(period);
        set_running(start0);
    }

    void Timer::config(Real period)
    {
        static const Real max_prd_tics = static_cast<Real>(0xFFFFFFFFUL);
        Real prd_tics = Bsp::Kclk::get_sysclkfreq_r32()*period;
        if((prd_tics <= 0) || (prd_tics > max_prd_tics))
        {
            prd_tics=max_prd_tics;
        }

        // Initialize timer period:
        regs.PERIOD.all = static_cast<Uint32>(prd_tics);

        // Reload timer (set counter to period).
        regs.TCR.bit.TRB = 1;

        // Set pre-scale counter to divide by 1 (SYSCLKOUT):
        regs.TPR.all  = 0;
        regs.TPRH.all  = 0;

        // Initialize timer control register:
        regs.TCR.bit.SOFT = 0;
        regs.TCR.bit.FREE = 0;     // Timer Free Run Disabled
    }

    Real Timer::get_period() const
    {
        return static_cast<Real>(regs.PERIOD.all)*Bsp::Kclk::get_sysclkperiod_r32();
    }

    void Timer::config_irq(Isrptr p_isr)
    {
        if(p_isr)
        {
            regs.TCR.bit.TIE=0;
            pie_enable(id, p_isr);
            regs.TCR.bit.TIE=1;
        }
        else
        {
            regs.TCR.bit.TIE=0;
        }
    }

    void Timer::set_running(bool run)
    {
        regs.TCR.bit.TSS = !run;
    }

    bool Timer::is_running() const
    {
        return !regs.TCR.bit.TSS;
    }

    void Timer::reload()
    {
        regs.TCR.bit.TRB = 1;      // Reload period value
    }

    void Timer::clear_ovf()
    {
        regs.TCR.bit.TIF = 1;
    }

    bool Timer::is_ovf() const
    {
        return regs.TCR.bit.TIF;
    }

    Uint32 Timer::get() const
    {
        // Return the period minus the counter, as it is a downwards counter.
        return (regs.PERIOD.all - regs.TIM.all);
    }

    void Timer::start_task(Real freq, Isrptr cb)
    {
        config(1.0F/freq);
        config_irq(cb);
        set_running(true);
    }


} // namespace Dsp28335_ent

