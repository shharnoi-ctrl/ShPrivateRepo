#ifndef TUNTRAITS_FW_H_
#define TUNTRAITS_FW_H_

#include <Array_fw.h>
#include <Mblock_fw.h>

namespace Base
{

    namespace Tuntraits
    {
        /// Null object idiom: Ignore element.
        template <typename T>
        struct Null;

        template <typename T>
        struct Cxet;

        template <typename T>
        struct Cset_only;

        template <typename T>
        struct Cget_only;

        template <typename T>
        struct Lossy8;

        template <typename T>
        struct Lossy16;

        template <typename TRAIT, typename ARRAY>
        struct Resize;

        template <typename ARRAY>
        struct Resize16;

        template <typename CONTAINER_POLICY, typename CONTAINER_TYPE>
        struct Arraytun_nosize;

        template <typename CONTAINER_POLICY, typename SIZE_POLICY, typename ARRAY>
        struct Arraytun;

        template <typename CONTAINER_POLICY, typename CONTAINER_TYPE>
        struct Arraytun_size16;

        struct Lossy_float;

        struct Rv3_nosize;

        template <typename T,Uint16 sz>
        struct Tunarraymsk;

        template <typename T, typename CONTAINER_TYPE>
        struct Tbase
        {
            typedef Arraytun_size16<Cset_only<T>, CONTAINER_TYPE > Arraytun_sz16_t0;
            typedef Arraytun_nosize<Cset_only<T>, CONTAINER_TYPE > Arraytun_nosize_t0;
        };

        template <typename T, typename CONTAINER_TYPE>
        struct Tbase_cxet
        {
            typedef Arraytun_size16<Cxet<T>, CONTAINER_TYPE > Arraytun_sz16_t0;
            typedef Arraytun_nosize<Cxet<T>, CONTAINER_TYPE > Arraytun_nosize_t0;
        };

        template <typename T, typename CONTAINER_TYPE>
        struct T2
        {
            typedef typename Tbase<T, CONTAINER_TYPE>::Arraytun_sz16_t0   Arraytun_sz16;
            typedef typename Tbase<T, CONTAINER_TYPE>::Arraytun_nosize_t0 Arraytun_nosize;
        };

        template <typename T>
        struct T1
        {
            typedef typename Tbase<T, Array<T>  >::Arraytun_sz16_t0   Arraytun_sz16;
            typedef typename Tbase<T, Array<T>  >::Arraytun_nosize_t0 Arraytun_nosize;
            typedef typename Tbase<T, Mblock<T> >::Arraytun_sz16_t0   Mblocktun_sz16;
            typedef typename Tbase<T, Mblock<T> >::Arraytun_nosize_t0 Mblocktun_nosize;
        };
        template <typename T>
        struct T1_cxet
        {
            typedef typename Tbase_cxet<T, Array<T>  >::Arraytun_sz16_t0   Arraytun_sz16;
            typedef typename Tbase_cxet<T, Array<T>  >::Arraytun_nosize_t0 Arraytun_nosize;
            typedef typename Tbase_cxet<T, Mblock<T> >::Arraytun_sz16_t0   Mblocktun_sz16;
            typedef typename Tbase_cxet<T, Mblock<T> >::Arraytun_nosize_t0 Mblocktun_nosize;
        };
    }
}
#endif
