#ifndef MULTIRANGEVARS_H_
#define MULTIRANGEVARS_H_

#include <Rangevars.h>
#include <Listtoarray.h>
#include <Warning.h>

namespace Base
{
    /// List of Rangevalues abstraction. Used to have a collection of ranges for a given variable type.
    /// T shall be a Listtoarray object build from a set of Rangevars.
    template<typename T, Uint16 nranges>
    class Multirangevars
    {
    public:
        typedef typename T::vartype Vartype;
        static const Uint16 size = nranges;
        typedef Listtoarray<T, nranges> Tdata;  ///< Type for Listtoarray set of ranges

        explicit Multirangevars(Tdata& data);   ///< Constructor with given List of ranges

        Vartype& get(typename T::idtype v); ///< Get the variable associated with 'v'

        void zeros();

    private:
        Vartype null_value; ///< Null object, returned if the Id is not in range
        Tdata& data; ///< List of range-values objects, containing the values for all supported IDs

        Multirangevars(const Multirangevars&); ///< = delete
        Multirangevars operator=(const Multirangevars&); ///< = delete
    };

    template<typename T, Uint16 nranges>
    inline Multirangevars<T, nranges>::Multirangevars(Tdata& data0) : data(data0)
    {
    }

    template<typename T, Uint16 nranges>
    Multirangevars<T, nranges>::Vartype& Multirangevars<T, nranges>::get(typename T::idtype v)
    {
        Vartype* res = 0; // Result

        for(Uint16 i=0; (res==0) && (i<nranges); i++)
        {
            if(data.values[i] != 0)
            {
                res = data.values[i]->get(v);
            }
        }
        // If not found, warn and return reference to null_value.
        if(res == 0)
        {
            Bsp::warning();
            res = &null_value;  // Assign the null value to avoid invalid reference
        }
        return *res;
    }

    template<typename T, Uint16 nranges>
    inline void Multirangevars<T, nranges>::zeros()
    {
        for(Uint16 i=0; i < nranges; ++i)
        {
            data.values[i]->zeros();
        }
    }
}
#endif
