// FIXME JSF133
#ifndef TVECTOR_H__
#define TVECTOR_H__

#include <Rmath.h>
#include <Tarray.h>
#include <Tmatrix.h>
#include <Ttraits.h>

namespace Maverick
{
    /// Tvector.
    /// The ::Maverick library shall provide the capability to manage Vectors from Maverick::Tarray. 
    template <class T>
    class Tvector: public Tarray<T>
    {
    public:
        /// Tvector Constructor with Given Parameters.
        /// \wi{3269}
        /// Tvector class shall build itself upon construction with a memory block buffer.
        /// \param[in] mb       Memory block.
        template <typename T2>
        explicit Tvector(Base::Mblock<T2> mb);

        /// Tvector Constructor with Given Parameters.
        /// \wi{3270}
        /// Tvector class shall build itself upon construction with first Vector element and specific numbers of elements.
        /// \param[in] v0       Pointer to first Vector element.
        /// \param[in] n0       Number of elements.
        Tvector(T* v0,Uint16 n0);
        /// Tvector Constructor with Given Parameters.
        /// \wi{18193}
        /// Tvector class shall build itself upon construction with Vector size and memory type.
        /// \param[in] n0       Vector size.
        /// \param[in] memtype  Memory type.
        Tvector(Uint16 n0, Base::Memmgr::Type memtype);

        /// Tvector Constructor with Given Parameters.
        /// \wi{18194}
        /// Tvector class shall build itself upon construction with the specified number of elements and an allocator.
        /// \param[in] n0      Number of elements to allocate space for.
        /// \param[in] alloc   Allocator to be used for memory allocation.
        Tvector(Uint16 n0, Base::Allocator& alloc);

        /// Matrix Times Vector (As Pointer) Computer.
        /// \wi{3132}
        /// Tvector class shall provide the capability to compute the Matrix times Vector operation for the given 
        /// Matrix whose first element is pointed by x, that is result = a0*x.
        /// \rat Note that the dimensions of x or the result are not checked, the dimensions to perform the
        /// multiplication are obtained from the calling vector an the passed matrix and this method assumes that the
        /// dimensions are consistent.
        /// \param[in] a0       Matrix to multiply.
        /// \param[in] x        Pointer to first element in the vector to multiply.
        void matvec(const Tmatrix<T>& a0, const T* x);

        /// Matrix Times Vector Computer.
        /// \wi{17566}
        /// Tvector class shall provide the capability to compute the Matrix times Vector operation for the given 
        /// Matrix and Vector, that is result = a0*x.
        /// \rat Note that the dimensions of x or the result are not checked, the dimensions to perform the
        /// multiplication are obtained from the calling vector an the passed matrix and this method assumes that the
        /// dimensions are consistent.
        /// \param[in] a0       Matrix to multiply.
        /// \param[in] x        Vector to multiply.
        inline void matvec(const Tmatrix<T>& a0, const Tvector<T>& x)
        {
            /// \alg
            /// - Call Tvector<T>::matvec with the given Matrix and the pointer to the first element of the given
            /// Vector.
            matvec(a0, &x[0]);
        }

        /// Add Matrix Times Vector (As Pointer) Computer
        /// \wi{20449}
        /// Tvector class shall provide a method to compute the multiplication of the passed matrix times the vector
        /// whose first element is passed as argument, adding the result to the calling vector.
        /// \rat Note that the dimensions of x or the result are not checked, the dimensions to perform the
        /// multiplication are obtained from the calling vector an the passed matrix and this method assumes that the
        /// dimensions are consistent.
        /// \param[in] a0       Matrix to multiply.
        /// \param[in] x        Vector to multiply.
        void matvec_add(const Tmatrix<T>& a0, const T* x);

        /// Add Matrix Times Vector Computer
        /// \wi{20450}
        /// Tvector class shall provide a method to compute the multiplication of the passed matrix times a vector,
        /// adding the result to the calling vector.
        /// \rat Note that the dimensions of x or the result are not checked, the dimensions to perform the
        /// multiplication are obtained from the calling vector an the passed matrix and this method assumes that the
        /// dimensions are consistent.
        /// \param[in] a0       Matrix to multiply.
        /// \param[in] x        Vector to multiply.
        inline void matvec_add(const Tmatrix<T>& a0, const Tvector<T>& x)
        {
            /// \alg
            /// - Call Tvector<T>::matvec_add with the given Matrix and the pointer to the first element of the given
            /// Vector.
            matvec_add(a0, &x[0]);
        }

        /// Transpose Matrix Times Vector Computer.
        /// \wi{17565}
        /// Tvector class shall provide the capability to compute the Transpose Matrix times Vector operation for the given 
        /// Matrix and Vector, that is result = a0^T*x.
        /// \param[in] a0       Matrix to multiply.
        /// \param[in] x        Vector to multiply.
        void matTvec(const Tmatrix<T>& a0, const Tvector<T>& x);
        /// Euclidean Squared Norm Computer.
        /// \wi{3279}
        /// Tvector class shall provide the capability to compute the euclidean squared norm of its internal Vector.
        /// \return Euclidean squared norm value.
        T norm2()const;
        /// Dot Product Computer.
        /// \wi{3276}
        /// Tvector class shall provide the capability to compute the dot product for a provided Vector.
        /// \param[in] y1       Vector to compute the dot product.
        /// \return Dot product value.
        T dot(const Tvector<T>& y1) const;
        /// Element-Wise Vector Multiplication Computer.
        /// \wi{3277}
        /// Tvector class shall provide the capability to compute the multiplication of all the elements of its internal Vector.
        /// \return Element-Wise vector multiplication value.
        T mult() const;
        /// Element-Wise Vector Sum Computer.
        /// \wi{3289}
        /// Tvector class shall provide the capability to compute the sum of all the elements of its internal Vector.
        /// \return Element-Wise vector sum value.
        T accumulate() const;
        /// Euclidean Norm Computer.
        /// \wi{3278}
        /// Tvector class shall provide the capability to compute the euclidean norm of its internal Vector.
        /// \return Euclidean norm value.
        T norm22()const;
        /// Normilize Euclidean Squared Norm Computer.
        /// \wi{3280}
        /// Tvector class shall provide the capability to compute the normilize euclidean squared norm of its internal Vector.
        /// \return Normalize euclidean squared norm value.
        void norm2alize();
        /// Polynomial Evaluator.
        /// \wi{3281}
        /// Tvector class shall provide the capability to evaluate a polynomial for a provided polynomial order
        /// from its internal Vector elements as coeficients.
        /// \return Evaluated poliynomial defined as v[0] + v[1]*x + v[2]*x^2 + ... + v[n-1]*x^(n-1).
        T polynomial(T x) const;

    private:
        /// Polinomial Order Definition.
        enum Poly_order
        {
            non_poly = 0,           ///< No polynomial.
            poly0    = 1,           ///< Constant polynomial (order 0).
            poly1    = 2,           ///< Linear polynomial (order 1).
        };

        Tvector();                                 ///< = delete
        Tvector(const Tvector& src);               ///< = delete
        Tvector& operator=(const Tvector& src);    ///< = delete
    };

    template <class T>
    template <typename T2>
    inline Tvector<T>::Tvector(Base::Mblock<T2> mb) : Tarray<T>(mb)
    {
    }

    template <class T>
    inline Tvector<T>::Tvector(T* v0,Uint16 n0) : Tarray<T>(v0,n0)
    {
    }

    template <class T>
    inline Tvector<T>::Tvector(Uint16 n0, Base::Memmgr::Type memtype) : Tarray<T>(n0,memtype)
    {
    }

    template <class T>
    inline Tvector<T>::Tvector(Uint16 n0, Base::Allocator& alloc) : Tarray<T>(n0, alloc)
    {
    }

    template <class T>
    void Tvector<T>::matvec(const Tmatrix<T>& a0, const T* x)
    {
        /// \alg
        /// <ul>
        /// <li> Initialize a pointer to the first element of the give Matrix.
        const T* pA0 = &a0[0];
        /// <li> Retrieve Tmatrix<T>::cols value for the number of columns in the given Matrix.
        const Uint16 a0_cols = a0.cols();
        /// <li> Iterate over each element of the Vector.
        const Uint16 n = Base::Array<T>::n;
        const T* const pz = Base::Array<T>::vz;
        for (T* p = Base::Array<T>::v; p <= pz; ++p)
        {
            /// <ul>
            /// <li> Iterate over each column of the given Matrix.
            T s = 0;
            const T* pA = pA0;
            const T* px = x;
            for (Uint16 k = 0U; k < a0_cols; ++k)
            {
                /// <ul>
                /// <li> Compute the sum of products between the corresponding elements of the given Vector 
                /// and the given Matrix.
                s += (*pA)*(*px);
                /// <li> Increment pointers to move to the next elements of the given arrays.
                pA += n;
                ++px;
                /// </ul>
            }
            /// <li> Assign the computed sum to the current element of the Vector.
            *p = s;
            /// <li> Move to the next column of the given matrix.
            /// </ul>
            ++pA0;
        }
        /// </ul>
    }
    
    template <class T>
    void Tvector<T>::matvec_add(const Tmatrix<T>& a0, const T* x)
    {
        /// \alg
        /// <ul>
        /// <li> Initialize a pointer to the first element of the give Matrix.
        const T* pA0 = &a0[0];
        /// <li> Retrieve Tmatrix<T>::cols value for the number of columns in the given Matrix.
        const Uint16 a0_cols = a0.cols();
        /// <li> Iterate over each element of the Vector.
        const Uint16 n = Base::Array<T>::n;
        const T* const pz = Base::Array<T>::vz;
        for (T* p = Base::Array<T>::v; p <= pz; ++p)
        {
            /// <ul>
            /// <li> Iterate over each column of the given Matrix.
            T s = 0;
            const T* pA = pA0;
            const T* px = x;
            for (Uint16 k = 0U; k < a0_cols; ++k)
            {
                /// <ul>
                /// <li> Compute the sum of products between the corresponding elements of the given Vector
                /// and the given Matrix.
                s += (*pA)*(*px);
                /// <li> Increment pointers to move to the next elements of the given arrays.
                pA += n;
                ++px;
                /// </ul>
            }
            /// <li> Assign the computed sum to the current element of the Vector.
            *p += s;
            /// <li> Move to the next column of the given matrix.
            /// </ul>
            ++pA0;
        }
        /// </ul>
    }

    template <class T>
    void Tvector<T>::matTvec(const Tmatrix<T>& a0, const Tvector<T>& x)
    {
        /// \alg
        /// <ul>
        /// <li> Iterate over each element of the Vector.
        Uint16 c = 0;
        for (T* p = Base::Array<T>::v; p <= Base::Array<T>::vz; ++p)
        {
            /// <ul>
            /// <li> Retrieve Tmatrix<T>::coldot value for the current column index and the given Vector.
            *p = a0.coldot(c, x);
            /// <li> Increment column index.
            ++c;
            /// </ul>
        }
        /// <ul>
    }

    template <class T>
    inline T Tvector<T>::norm2()const
    {
        /// \alg
        /// - Return square value for the retrieved value by Tvector<T>::norm22.
        return Rmath::sqrtr(norm22());
    }

    template <class T>
    T Tvector<T>::dot(const Tvector<T>& y1) const
    {
        /// \alg
        /// <ul>
        /// <li> Iterate over each element of the Vector.
        T s=0;
        const T* p1=&y1[0];
        for(T* p = Base::Array<T>::v; p<=Base::Array<T>::vz; p++)
        {
            /// <ul>
            /// <li> Compute the sum of products by the corresponding element of the given Vector.
            s+=(*p)*(*p1);
            /// <li> Increment pointers to move to the next elements of the given arrays.
            p1++;
            /// </ul>
        }
        /// Return dot product value computed.
        return s;
        /// </ul>
    }

    template <class T>
    T Tvector<T>::mult() const
    {
        /// \alg
        /// <ul>
        /// <li> Iterate over each element of the Vector.
        T s = 1;
        for(const T* p=Base::Array<T>::v; p <= Base::Array<T>::vz; p++)
        {
            /// <ul>
            /// <li> Compute the product by the corresponding element of its Vector.
            s *= (*p);
            /// </ul>
        }
        /// Return element-wise multiplication value computed.
        return s;
        /// </ul>
    }

    template <class T>
    T Tvector<T>::accumulate() const
    {
        /// \alg
        /// <ul>
        /// <li> Iterate over each element of the Vector.
       T s = 0;
       for(const T* p=Base::Array<T>::v; p <= Base::Array<T>::vz; p++)
       {
            /// <ul>
            /// <li> Compute the sum by the corresponding element of its Vector.
           s += (*p);
            /// </ul>
       }
        /// Return accumulate value computed.
       return s;
        /// </ul>
    }

    template <class T>
    T Tvector<T>::norm22()const
    {
        /// \alg
        /// <ul>
        /// <li> Iterate over each element of the Vector.
        T s=0;
        for(const T* p=Base::Array<T>::v; p<=Base::Array<T>::vz; p++)
        {
            /// <ul>
            /// <li> Compute the sum of products by the same corresponding element of the given Vector.
            s+=(*p)*(*p);
            /// </ul>
        }
        /// Return normalized value computed.
        return s;
    }

    template <class T>
    void Tvector<T>::norm2alize()
    {
        /// \alg
        /// <ul>
        /// <li> Retrieve Tvector<T>::norm2 value.
        T V=norm2();
        /// <li> If retrieved value is greater that 0, normalize its Vector.
        if(V>0)
        {

            /// <ul>
            /// <li> Invert the retrieved norm value.
            V=Const::ONE/V;
            /// <li> Iterate over each element of the Vector.
            for(T* p=Base::Array<T>::v; p<=Base::Array<T>::vz; p++)
            {
                /// <ul>
                /// <li> Normalize the corresponding element of its Vector.
                (*p)*=V;
                /// </ul>
            }
            /// </ul>
        }
        /// </ul>
    }

    template <class T>
    T Tvector<T>::polynomial(T x) const
    {
        /// \alg
        /// <ul>
        /// <li> Depending on the received polynomial order:
        typename Base::Remove_const<T>::type result = 0;
        switch(static_cast<Poly_order>(Base::Array<T>::n))
        {
            /// <ul>
            /// <li> If ::Poly_order::non_poly:
            case non_poly:
            {
                /// <ul>
                /// <li> Do nothing.
                break;
                /// </ul>
            }
            /// <li> If ::Poly_order::poly0:
            case poly0:
            {
                /// <ul>
                /// <li> Set polynomial value to the value of the first element of its vector.
                result = *Base::Array<T>::v;
                break;
                /// </ul>
            }
            /// <li> If ::Poly_order::poly1:
            case poly1:
            {
                /// <ul>
                /// <li> Set polynomial value as v[0]+v[1]*x.
                result = *Base::Array<T>::v + x*(*Base::Array<T>::vz);
                break;
                /// </ul>
            }
            /// <li> Default polynomial order:
            default:
            {
                /// <ul>
                /// <li> Calculate polynomial value using Horner's method.
                /// <li> Set polynolial value as the last element of the Vector.
                result = *Base::Array<T>::vz;
                /// <li> Perform inverse iteration over each element of the Vector starting from the last-1 element.
                for(const T* vi = Base::Array<T>::vz-1; vi>=Base::Array<T>::v; --vi)
                {
                    /// <ul>
                    /// <li> Multiply the last polynomial value by the given order and add the value of the 
                    /// corresponding element of the Vector.
                    result = x*result + *vi;
                    /// </ul>
                }
                /// </ul>
            }
            /// </ul>
        }
        /// <li> Return evaluated polynomial value.
        return result;
        /// </ul>
    }
}

#endif
