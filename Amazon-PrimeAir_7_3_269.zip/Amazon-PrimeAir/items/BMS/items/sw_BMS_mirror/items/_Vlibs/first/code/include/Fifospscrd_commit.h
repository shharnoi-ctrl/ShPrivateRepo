#ifndef FIFOSPSCRD_COMMIT_H_
#define FIFOSPSCRD_COMMIT_H_

#include <Fifospsc0.h>
#include <Fifospscrd_commit_fw.h>

namespace Base
{
    /// FIFO with commit/discard option for reads. Uses an auxiliary FIFO with external pointers,
    /// transplating read state to externally visible FIFO on commit.
    template <typename T,
              template <typename> class RD = SPSCtraits::Internal,
              template <typename> class WR = SPSCtraits::Internal>
    class Fifospscrd_commit
    {

    public:
        typedef typename Base::Fifospsc0<T, RD, WR>::Rptr Rptr;
        typedef typename Base::Fifospsc0<T, RD, WR>::Wptr Wptr;

        /// FIFO SPSC Default Constructor.
        /// \wi{6242}
        /// Fifospscrd_commit class shall build itself upon construction to support commited readings.
        /// \param[in] v0 pointer to the first buffer element.
        /// \param[in] vz0 pointer to the last buffer element.
        /// \param[in] rd0 pointer to manage buffer readings.
        /// \param[in] wr0 pointer to manage buffer writings.
        Fifospscrd_commit(T* const v0,
                          T* const vz0,
                          Rptr rd0,
                          Wptr wr0);

        /// FIFO SPSC Data Element Reader.
        /// \wi{6245}
        /// Fifospscrd_commit class shall be able to read from its private FIFO without updating final read pointer.
        /// \param[out] element Element already read from the buffer.
        /// \return True if the read action has worked, otherwise False.
        template <typename T2=T, typename CPTRAIT = Cptraits::Operator<T,T2> >
        bool read(T2& element);

        /// FIFO SPSC Read Availablity Checker.
        /// \wi{6246}
        /// Fifospscrd_commit class shall be able to check if read action from private FIFO is available.
        /// \return True if the reading action is available, otherwise False.
        bool rd_available() const;

        /// FIFO SPSC Data Element Writer.
        /// \wi{6248}
        /// Fifospscrd_commit class shall be able to write an element into final FIFO.
        /// \param[in] element Element to write in the buffer.
        /// \return True if the write action has worked, otherwise False.
        template <typename T2=T, typename CPTRAIT = Cptraits::Operator<T2,T> >
        bool write(typename JSF116_param<T2>::type element);

        /// FIFO SPSC Write Availablity Checker.
        /// \wi{6249}
        /// Fifospscrd_commit class shall be able to check if write action in final FIFO is available.
        /// \return True if the writing action is available, otherwise False.
        bool wr_available() const;

        /// FIFO SPSC Buffer Commit.
        /// \wi{6243}
        /// Fifospscrd_commit class shall be able to commit the read pointer 
        /// used on its private FIFO to the final FIFO.
        void commit();

        /// FIFO SPSC Buffer Discard.
        /// \wi{6244}
        /// Fifospscrd_commit class shall be able to discard the private FIFO read pointer since last commit.
        void discard();

        /// FIFO SPSC Buffer Reset Read Pointer.
        /// \wi{6247}
        /// Fifospscrd_commit class shall be able to reset the read pointer of both FIFO queues.
        void reset();

        /// FIFO SPSC Buffer Next Element Pointer.
        /// \wi{6250}
        /// Fifospscrd_commit class shall be able to update the read pointer of final FIFO to the next one.
        void next();

    private:
        typedef Fifospsc0<T, RD, SPSCtraits::Add_reference_to_trait<WR>::template Template > Type_ff0_obj;
        Rptr rdaux;   ///< Temporary read pointer.
        Wptr wraux;   ///< Temporary write pointer.

        /// FIFO where visible changes happen (Final FIFO).
        Type_ff0_obj ff0_obj;
        /// FIFO where temporary writes happen (Private/Temporary FIFO).
        Fifospsc0<T, SPSCtraits::Internal_ref, SPSCtraits::External> ffprivate;

        Fifospscrd_commit();                                            ///< = delete.
        Fifospscrd_commit(const Fifospscrd_commit& orig);               ///< = delete.
        Fifospscrd_commit& operator=(const Fifospscrd_commit& orig);    ///< = delete.
    };

    template <typename T,
              template <typename> class RD,
              template <typename> class WR>
    Fifospscrd_commit<T,RD,WR>::Fifospscrd_commit(T* const v0,
                                                  T* const vz0,
                                                  Rptr rd0,
                                                  Wptr wr0):
        rdaux(rd0),
        wraux(wr0),
        ff0_obj(v0, vz0, rd0, wraux),
        ffprivate(v0, vz0, rdaux, const_cast<const T* const volatile&>(wraux))
    {
    }

    template <typename T,
              template <typename> class RD,
              template <typename> class WR>
    template <typename T2, typename CPTRAIT>
    inline bool Fifospscrd_commit<T,RD,WR>::read(T2& element)
    {
        /// \alg
        /// - Return retrieved boolean from Fifospsc0::read for ::ffprivate with the given instance "element". 
        return ffprivate.template read<T2, CPTRAIT>(element);
    }

    template <typename T,
              template <typename> class RD,
              template <typename> class WR>
    inline bool Fifospscrd_commit<T,RD,WR>::rd_available() const
    {
        /// \alg
        /// - Return retrieved boolean from Fifospsc0::rd_available for ::ffprivate. 
        return ffprivate.rd_available();
    }

    template <typename T,
              template <typename> class RD,
              template <typename> class WR>
    template <typename T2, typename CPTRAIT>
    inline bool Fifospscrd_commit<T,RD,WR>::write(typename JSF116_param<T2>::type element)
    {
        /// \alg
        /// - Return retrieved boolean from Fifospsc0::write for ::ff0_obj with the given instance "element". 
        return ff0_obj.template write<T2, CPTRAIT>(element);
    }

    template <typename T,
              template <typename> class RD,
              template <typename> class WR>
    inline bool Fifospscrd_commit<T,RD,WR>::wr_available() const
    {
        /// \alg
        /// - Return retrieved boolean from Fifospsc0::wr_available for ::ff0_obj. 
        return ff0_obj.wr_available();
    }

    template <typename T,
              template <typename> class RD,
              template <typename> class WR>
    inline void Fifospscrd_commit<T,RD,WR>::commit()
    {
        /// \alg
        /// - Call Fifospsc0::set_rd for ::ff0_obj with current read pointer instance ::rdaux.
        ff0_obj.set_rd(rdaux);
    }

    template <typename T,
              template <typename> class RD,
              template <typename> class WR>
    inline void Fifospscrd_commit<T,RD,WR>::discard()
    {
        /// \alg
        /// - Set ::rdaux value to retrieved value by Fifospsc0::get_rt for ::ff0_obj.
        rdaux = ff0_obj.get_rd();
    } 

    template <typename T,
              template <typename> class RD,
              template <typename> class WR>
    inline void Fifospscrd_commit<T,RD,WR>::reset()
    {
        /// \alg
        /// <ul>
        /// <li> Call Fifospsc0::get_v for ::ff0_obj to get the pointer to the first 
        /// buffer element and update current ::rdaux.
        rdaux = ff0_obj.get_v();
        /// <li> Call Fifospsc0::set_rd for ::ff0_obj and pass Fifospsc0::get_v to reset it, 
        /// it means set the read pointer of ::ff0_obj to the first element.
        ff0_obj.set_rd(ff0_obj.get_v());
        /// </ul>
    }

    template <typename T,
              template <typename> class RD,
              template <typename> class WR>
    inline void Fifospscrd_commit<T,RD,WR>::next()
    {
        /// \alg
        /// <ul>
        /// <li> Set type "aux" to 0.
        T aux = 0;
        /// <li> Call Fifospsc0::read for ::ff0_obj and pass "aux" as reference to shift the read pointer of ::ff0_obj.
        ff0_obj.read(aux);
        /// </ul>
    }
}

#endif
