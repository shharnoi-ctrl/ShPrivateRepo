#ifndef VECTOR_U8_H_
#define VECTOR_U8_H_

#include <U8pkmblock.h>
#include <U8pkmblock_k.h>

namespace Base
{
    /// Vector of Bytes with a maximum size.
    class Vector_u8
    {
    public:
        /// Build from given U8 memory block and set Vector size to its size.
        explicit Vector_u8(const U8pkmblock& mb);

        /// Build from given U16 memory block and set Vector size to its size.
        explicit Vector_u8(const Mblock_u16& mb16);

        /// Build from given size using given allocator to obtain memory and set the size to "max_size" parameter
        Vector_u8(Uint32 max_size, Allocator& al);

        /// Build from given size using given allocator to obtain memory and set the size to "size" parameter.
        /// "size" shall be <= "max_size"
        Vector_u8(Uint32 max_size, Allocator& al, Uint32 size);

        /// \return Vector data as memory block with current size (not max size)
        const U8pkmblock_k to_mblock8() const;

        /// \param n0   New deisred size
        /// \return     True if resize succeeded (n0 <= max_size)
        bool resize(Uint32 n0);

        /// \return     Current size
        Uint32 size() const;

        /// \return     Maximum vector size
        Uint32 size_max() const;

        /// Set element
        /// \param i     Index of the element to set
        /// \param value Desired value
        void set(Uint32 i, Uint8 value);

        /// Get element
        /// \param i    Index of the element to get
        /// \return     Element value
        Uint8 get(Uint32 i) const;

        /// Append value to the end of the vector and increment vector size by 1
        /// \return True if append succeeded
        bool append(Uint8 value);

        /// Copy given memory block into the vector starting no element 0 and set the size to the memory block size.
        /// \param mb   Memory block to copy data from
        void copy(const U8pkmblock_k& mb);

    private:
        U8pkmblock mb;  ///< Memory block with current size (max size is defined as size of mb)
        Uint32 sz;      ///< Current size

        Vector_u8(const Vector_u8&); ///< = delete
        Vector_u8& operator=(const Vector_u8&); ///< = delete
    };

    inline Vector_u8::Vector_u8(const U8pkmblock& mb0) : mb(mb0), sz(mb.size())
    {
    }

    inline Vector_u8::Vector_u8(const Mblock_u16& mb16) : mb(mb16), sz(mb.size())
    {
    }

    inline Vector_u8::Vector_u8(Uint32 max_size, Allocator& al) :
        mb(al.allocate(Bitutils::bytes_to_words16(max_size), sizeof(Uint16)), max_size), sz(mb.size())
    {
    }

    inline Vector_u8::Vector_u8(Uint32 max_size, Allocator& al, Uint32 size) :
        mb(al.allocate(Bitutils::bytes_to_words16(max_size), sizeof(Uint16)),
           Assertions::runtime(size<=max_size) ? size : max_size),
           sz(mb.size())
    {
    }

    inline const U8pkmblock_k Vector_u8::to_mblock8() const
    {
        return U8pkmblock_k(mb, sz);
    }

    inline Uint32 Vector_u8::size() const
    {
        return sz;
    }

    inline Uint32 Vector_u8::size_max() const
    {
        return mb.size();
    }

    inline void Vector_u8::set(Uint32 i, Uint8 value)
    {
        mb.set(i, value);
    }

    inline Uint8 Vector_u8::get(Uint32 i) const
    {
        return mb.get(i);
    }

    inline void Vector_u8::copy(const U8pkmblock_k& mb0)
    {
        mb.write(mb0);
    }
}
#endif
