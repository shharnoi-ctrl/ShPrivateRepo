#ifndef ENUMS_H_
#define ENUMS_H_

#include <Vtraits.h>

namespace Base
{
    namespace Enums
    {
        // NOTE: In many places, is_gtez is being used to check if a deserialized Enum is ok. For that task is better
        // to use Range class. I.E:
        //
        // Range<Endianness, endian_little, endian_big>::in_range(value);

        /// Template-based Signed Enumeration Greater than or Equal to Zero Checker. 
        /// \wi{5010}
        /// Enums library shall provide the capability to check if a deserialized signed enumerator is greater 
        /// than or equal to 0.
        /// \param[in] v    Enum value to check.
        /// \return True if given value is greater than or equal to 0, False otherwise.
        template <typename T>
        inline typename Enable_if< Is_signed<T>::value, bool>::type is_gtez(T v)
        {
            return v >= 0;
        }

        /// Template-based Unsigned Enumeration Greater than or Equal to Zero Checker.
        /// \wi{21326}
        /// Enums library shall provide the capability to check if a deserialized unsigned enumerator is greater 
        /// than or equal to 0.
        /// \param[in] v    Enum value to check. Not used as this function is used by unsigned values and it 
        /// will always be greater than 0.
        /// \return Always True.
        template <typename T>
        inline typename Enable_if<!Is_signed<T>::value, bool>::type is_gtez(T v)
        {
            return true;
        }
    }
}
#endif
