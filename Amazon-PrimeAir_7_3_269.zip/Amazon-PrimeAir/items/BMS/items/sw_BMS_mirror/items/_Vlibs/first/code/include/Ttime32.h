#ifndef TTIME32_H_
#define TTIME32_H_

#include <Entypes.h>
#include <Kclk.h>

namespace Base
{
    /// The Base library shall provides a class for lightweight, high-precision time measurement.
    /// - It uses tics with a precision of approximately 5 nanoseconds per tic and stores time in a 32-bit integer,
    /// allowing for a maximum range of about 10.5 seconds (signed).
    /// - This class is suitable for fast timing or profiling scenarios 
    /// where time intervals are known to be less than 10 seconds.
    class Ttime32
    {
    public:
        /// Tick Time 32-bit Default Constructor.
        /// \wi{6478}
        /// Ttime32 class shall build itself upon construction and initialize its internal members.
        /// \alg
        /// - ::tics is initialized with 0.
        inline Ttime32() : tics(0LL)
        {
        }
        
        /// Tick Time 32-bit Constructor with Given Time in Seconds.
        /// \wi{21535}
        /// Ttime32 class shall build itself upon construction and initialize 
        /// its internal attributes with given time in seconds.
        /// \param[in] seconds Time in seconds.
        /// \alg
        /// - ::tics is initialized with given parameter "seconds" multiplied by Bsp::Kclk::get_sysclkfreq_r32.
        inline explicit Ttime32(const Real seconds) : tics(static_cast<int32>(seconds*Bsp::Kclk::get_sysclkfreq_r32()))
        {
        }
        
        /// Tick Time 32-bit Constructor with Given Time in Tics.
        /// \wi{21536}
        /// Ttime32 class shall build itself upon construction and initialize 
        /// its internal attributes with given time in tics.  
        /// \param[in] tics0 Time in tics.
        /// \alg
        /// - ::tics is initialized with given parameter "tics0" 
        inline explicit Ttime32(const int32 tics0) : tics(tics0)
        {
        }
        
        /// Tick Time 32-bit Time in Tics Retriever.
        /// \wi{6479}
        /// Ttime32 class shall provide the capability to retrieve the time in tics. 
        /// \return Time in tics.
        inline int32 get_tics() const
        {
            /// \alg
            /// - Return ::tics.
            return tics;
        }
        
        /// Tick Time 32-bit Time in Seconds Retriever.
        /// \wi{6480}
        /// Ttime32 class shall provide the capability to retrieve the time in seconds. 
        /// \return Time in seconds.
        inline Real get_seconds() const
        {
            /// \alg
            /// - Return retrieved value by ::tics multiplied by Bsp::Kclk::get_sysclkperiod_r32.
            return static_cast<Real>(tics)*Bsp::Kclk::get_sysclkperiod_r32();
        }
        
        /// Tick Time 32-bit Tics Subtraction Operation.
        /// \wi{6481}
        /// Ttime32 class shall provide the capability to initialize the time 
        /// of CPU clock by subtracting this tics time with the given tics time.
        /// \param[in] t2 Ttime32 object to subtract the time. 
        /// \return A new Ttime32 object representing the difference in tics between this object and given t2.
        inline Ttime32 operator-(const Ttime32& t2) const
        {
            /// \alg
            /// - Return Ttime32 instance initialized with ::tics minus ::tics in given "t2".
            return Ttime32(tics-t2.tics);
        }
        
        /// Tick Time 32-bit Greater Than Comparison Operation.
        /// \wi{21537}
        /// Ttime32 class shall provide the capability to check if this tics time is greater than the given tics time.
        /// \param[in] t2 Ttime32 object to compare the time. 
        /// \return True if this tics time is greater than the given tics time, otherwise False.
        inline bool operator>(const Ttime32& t2) const
        {
            /// \alg
            /// - Return the comparison result of ::tics is greater than ::tics in given "t2". 
            return tics > t2.tics;
        }

        /// Tick Time 32-bit Less Than or Equal Comparison Operation.
        /// \wi{21538}
        /// Ttime32 class shall provide the capability to check if this tics 
        /// time is less than or equal to the given tics time.
        /// \param[in] t2 Ttime32 object to compare the time. 
        /// \return True if this tics time is less than or equal to the given tics time, otherwise False.
        inline bool operator<=(const Ttime32& t2) const
        {
            /// \alg
            /// - Return True if ::tics is less than or equal to ::tics in given "t2", False otherwise. 
            return tics <= t2.tics;
        }

        /// Tick Time 32-bit Division Operation. 
        /// \wi{21539}
        /// Ttime32 class shall provide the capability to divide this tics time by given tics time.
        /// \param[in] t2 Ttime32 object to divide by.
        /// \return Real division of this tics time by given tics time.
        inline Real operator/(const Ttime32& t2) const
        {
            /// \alg
            /// - Return the devision result of ::tics by ::tics in given "t2". 
            return static_cast<Real>(tics)/t2.tics;
        }
    private:
        int32 tics; ///< Time in tics of CPU clock.
    };
}
#endif
