#include <Hregmap.h>
#include <Asm.h>
#include <Cpusys.h>
#include <GPIOmux16.h>
#include <GPIO.h>
#include <GPIOv.h>
#include <GPIOdev.h>
#include <Delay.h>
#include <I2Cif.h>


namespace Dsp28335_ent
{

    void I2Cif::set_clk_enable()
    {
        // Enable clock for this peripheral
        Cpusys cs;
        cs.clk_enable((id == id_i2c_b) ? Cpusys::clk_i2cb : Cpusys::clk_i2ca);
    }

    volatile I2Cif::Regs& I2Cif::get_regs()
    {
        static const Uint32 i2ca_regs_addr = 0x7300UL;
        static const Uint32 i2cb_regs_addr = 0x7340UL;

        static volatile Regs& i2ca_regs = Hregmap::get<Regs, i2ca_regs_addr>();
        static volatile Regs& i2cb_regs = Hregmap::get<Regs, i2cb_regs_addr>();

        return (id == id_i2c_a) ? i2ca_regs : i2cb_regs;
    }

    void I2Cif::config_gpio(bool sync)
    {
        if(sync == false)
        {
            GPIOioctl::apply(static_cast<GPIOid>(clk_id),
                           GPIOtun::build(GPIOtun::dir_output,
                                          GPIOtun::pu_dis,
                                          GPIOmux16::mux_0,
                                          GPIOtun::qsel_async));
        }
        else
        {
            GPIOtun::Mux mux = (id==id_i2c_b) ? GPIOmux16::mux_6 : GPIOmux16::mux_1;

            GPIOioctl::apply( static_cast<GPIOid>(clk_id),
                            GPIOtun::build(GPIOtun::dir_output,
                                          GPIOtun::pu_dis,
                                          mux,
                                          GPIOtun::qsel_sync));
        }
    }

    void I2Cif::disable()
    {
        set_enabled(false);
        GPIOioctl::apply_input(clk_id);
        GPIOioctl::apply_input(sda.get_id());
        Delay::ns_by_50(Ku16::u1);
    }
}
