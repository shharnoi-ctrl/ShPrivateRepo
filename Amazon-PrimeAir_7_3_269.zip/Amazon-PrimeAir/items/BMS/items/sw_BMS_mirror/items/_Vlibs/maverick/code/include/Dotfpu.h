///    \file Dotfpu.h
///
///    \date 2 jul. 2018
///
///    \author  FJBurgos, jbm (at) embention.com
///    Company:  Embention
///
///    Dotfpu class declaration.
///

#ifndef DOTFPU_H_
#define DOTFPU_H_

#include <Entypes.h>

namespace Maverick
{

    Real dot_fpu(const Real* v0,
                 const Real* v1,
                 Uint16 n);

}  // namespace Maverick

#endif // DOTFPU_H_
