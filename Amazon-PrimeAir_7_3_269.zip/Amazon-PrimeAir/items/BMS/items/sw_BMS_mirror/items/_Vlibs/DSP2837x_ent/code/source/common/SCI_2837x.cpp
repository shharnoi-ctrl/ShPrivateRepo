#include <SCI.h>
#include <Hregmap.h>
#include <Assertions.h>
#include <Asm.h>
#include <Cpusys.h>

namespace Dsp28335_ent
{
    volatile SCI::Sci_regs& SCI::get_regs(SCI::Id id0)
    {
        // Enable SCI clock and select registers.
        static const Uint32 hw_addr_scia = 0x7200UL;
        volatile SCI::Sci_regs* result = &Hregmap::get<SCI::Sci_regs,hw_addr_scia>();

        Cpusys cs;
        switch(id0)
        {
            case scia:
            {
                cs.clk_enable(Cpusys::clk_scia);
                break;
            }
            case scib:
            {
                static const Uint32 hw_addr_scib = 0x7210UL;
                result = &Hregmap::get<SCI::Sci_regs,hw_addr_scib>();
                cs.clk_enable(Cpusys::clk_scib);
                break;
            }
            case scic:
            {
                static const Uint32 hw_addr_scic = 0x7220UL;
                result = &Hregmap::get<SCI::Sci_regs,hw_addr_scic>();
                cs.clk_enable(Cpusys::clk_scic);
                break;
            }
            case scid:
            {
                static const Uint32 hw_addr_scid = 0x7230UL;
                result = &Hregmap::get<SCI::Sci_regs,hw_addr_scid>();
                cs.clk_enable(Cpusys::clk_scid);
                break;
            }
        }
        return *result;
    }
}
