#ifndef IRANGEVARS_H_
#define IRANGEVARS_H_

namespace Base
{
    /// Interface for Rangevars implementations
    template<typename TID, typename VART>
    class Irangevars
    {
    public:
        typedef TID  idtype;    ///< Type of the id (key)
        typedef VART vartype;   ///< Type of the variable (value)

        virtual VART* get(TID v) = 0;   ///< Get pointer to variable if found, NULL if not found

        virtual void zeros() = 0; ///< Set all values to Zero
    };
}
#endif
