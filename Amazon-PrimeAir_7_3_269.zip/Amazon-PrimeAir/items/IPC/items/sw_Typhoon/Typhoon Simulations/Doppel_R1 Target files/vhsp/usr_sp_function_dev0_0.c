// generated using template: cop_main.template---------------------------------------------
/******************************************************************************************
**
**  Module Name: cop_main.c
**  NOTE: Automatically generated file. DO NOT MODIFY!
**  Description:
**            Main file
**
******************************************************************************************/
// generated using template: arm/custom_include.template-----------------------------------


#ifdef __cplusplus
#include <limits>

extern "C" {
#endif

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <stdint.h>
#include <complex.h>

// x86 libraries:
#include "../include/sp_functions_dev0.h"


#ifdef __cplusplus
}
#endif


// ----------------------------------------------------------------------------------------                // generated using template:generic_macros.template-----------------------------------------
/*********************** Macros (Inline Functions) Definitions ***************************/

// ----------------------------------------------------------------------------------------

#ifndef MAX
#define MAX(value, limit) (((value) > (limit)) ? (value) : (limit))
#endif
#ifndef MIN
#define MIN(value, limit) (((value) < (limit)) ? (value) : (limit))
#endif

// generated using template: VirtualHIL/custom_defines.template----------------------------

typedef unsigned char X_UnInt8;
typedef char X_Int8;
typedef signed short X_Int16;
typedef unsigned short X_UnInt16;
typedef int X_Int32;
typedef unsigned int X_UnInt32;
typedef unsigned int uint;
typedef double real;

// ----------------------------------------------------------------------------------------
// generated using template: custom_consts.template----------------------------------------

// arithmetic constants
#define C_SQRT_2                    1.4142135623730950488016887242097f
#define C_SQRT_3                    1.7320508075688772935274463415059f
#define C_PI                        3.1415926535897932384626433832795f
#define C_E                         2.7182818284590452353602874713527f
#define C_2PI                       6.283185307179586476925286766559f

//@cmp.def.start
//component defines































//@cmp.def.end


//-----------------------------------------------------------------------------------------
// generated using template: common_variables.template-------------------------------------
// true global variables



//@cmp.var.start
// variables
double _constant1__out = 0.15;
double _constant2__out = 0.17;
double _pmsm_machine_wrapper1__out;

double _pos_sin_gain__out;
double _pos_sin_gain1__out;
double _resolver_gain_constant1__out = -0.5;
double _resolver_gain1_constant1__out = 0.5;
double _resolver_gain2_constant1__out = -0.45;
double _resolver_gain3_constant1__out = 0.55;
double _sum1__out;
double _sum2__out;
double _trigonometric_function2__out;
double _trigonometric_function4__out;
double _trigonometric_function1__out;
double _trigonometric_function3__out;
double _product2__out;
double _product4__out;
double _product1__out;
double _product3__out;
double _resolver_gain1_gain1__out;
double _resolver_gain3_gain1__out;
double _resolver_gain_gain1__out;
double _resolver_gain2_gain1__out;
double _resolver_gain1_sum1__out;
double _resolver_gain3_sum1__out;
double _resolver_gain_sum1__out;
double _resolver_gain2_sum1__out;
//@cmp.var.end

//@cmp.svar.start
// state variables
double _pmsm_machine_wrapper1__model_load;
//@cmp.svar.end

//
// Tunable parameters
//
static struct Tunable_params {
} __attribute__((__packed__)) tunable_params;

void *tunable_params_dev0_cpu0_ptr = &tunable_params;

// Dll function pointers
#if defined(_WIN64)
#else
// Define handles for loading dlls
#endif








// generated using template: virtual_hil/custom_functions.template---------------------------------
void ReInit_user_sp_cpu0_dev0() {
#if DEBUG_MODE
    printf("\n\rReInitTimer");
#endif
    //@cmp.init.block.start
    _pmsm_machine_wrapper1__model_load = 0.0;
    HIL_OutAO(0x4000, 0.0f);
    HIL_OutAO(0x4001, 0.0f);
    HIL_OutAO(0x4002, 0.0f);
    HIL_OutAO(0x4003, 0.0f);
    //@cmp.init.block.end
}


// Dll function pointers and dll reload function
#if defined(_WIN64)
// Define method for reloading dll functions
void ReloadDllFunctions_user_sp_cpu0_dev0(void) {
    // Load each library and setup function pointers
}

void FreeDllFunctions_user_sp_cpu0_dev0(void) {
}

#else
// Define method for reloading dll functions
void ReloadDllFunctions_user_sp_cpu0_dev0(void) {
    // Load each library and setup function pointers
}

void FreeDllFunctions_user_sp_cpu0_dev0(void) {
}
#endif

void load_fmi_libraries_user_sp_cpu0_dev0(void) {
#if defined(_WIN64)
#else
#endif
}


void ReInit_sp_scope_user_sp_cpu0_dev0() {
    // initialise SP Scope buffer pointer
}
// generated using template: common_timer_counter_handler.template-------------------------

/*****************************************************************************************/
/**
* This function is the handler which performs processing for the timer counter.
* It is called from an interrupt context such that the amount of processing
* performed should be minimized.  It is called when the timer counter expires
* if interrupts are enabled.
*
*
* @param    None
*
* @return   None
*
* @note     None
*
*****************************************************************************************/

void TimerCounterHandler_0_user_sp_cpu0_dev0() {
#if DEBUG_MODE
    printf("\n\rTimerCounterHandler_0");
#endif
    //////////////////////////////////////////////////////////////////////////
    // Set tunable parameters
    //////////////////////////////////////////////////////////////////////////
    // Generated from the component: Constant1
    // Generated from the component: Constant2
    // Generated from the component: resolver_gain.Constant1
    // Generated from the component: resolver_gain1.Constant1
    // Generated from the component: resolver_gain2.Constant1
    // Generated from the component: resolver_gain3.Constant1
//////////////////////////////////////////////////////////////////////////
    // Output block
    //////////////////////////////////////////////////////////////////////////
    //@cmp.out.block.start
    // Generated from the component: PMSM.Machine Wrapper1
    _pmsm_machine_wrapper1__out = HIL_InFloat(0xc80000 + 32779);
    // Generated from the component: pos_sin_gain
    _pos_sin_gain__out = XIo_InFloat(0xfffc0000);
    // Generated from the component: pos_sin_gain1
    _pos_sin_gain1__out = XIo_InFloat(0xfffc0004);
    // Generated from the component: Sum1
    _sum1__out = _constant1__out + _pmsm_machine_wrapper1__out;
    // Generated from the component: Sum2
    _sum2__out = _constant2__out + _pmsm_machine_wrapper1__out;
    // Generated from the component: Trigonometric function2
    _trigonometric_function2__out = cos(_pmsm_machine_wrapper1__out);
    // Generated from the component: Trigonometric function4
    _trigonometric_function4__out = cos(_pmsm_machine_wrapper1__out);
    // Generated from the component: Trigonometric function1
    _trigonometric_function1__out = sin(_sum1__out);
    // Generated from the component: Trigonometric function3
    _trigonometric_function3__out = sin(_sum2__out);
    // Generated from the component: Product2
    _product2__out = (_trigonometric_function2__out * _pos_sin_gain__out);
    // Generated from the component: Product4
    _product4__out = (_trigonometric_function4__out * _pos_sin_gain1__out);
    // Generated from the component: Product1
    _product1__out = (_pos_sin_gain__out * _trigonometric_function1__out);
    // Generated from the component: Product3
    _product3__out = (_pos_sin_gain1__out * _trigonometric_function3__out);
    // Generated from the component: resolver_gain1.Gain1
    _resolver_gain1_gain1__out = 1.2 * _product2__out;
    // Generated from the component: resolver_gain3.Gain1
    _resolver_gain3_gain1__out = 1.22 * _product4__out;
    // Generated from the component: resolver_gain.Gain1
    _resolver_gain_gain1__out = 1.1 * _product1__out;
    // Generated from the component: resolver_gain2.Gain1
    _resolver_gain2_gain1__out = 1.11 * _product3__out;
    // Generated from the component: resolver_gain1.Sum1
    _resolver_gain1_sum1__out = _resolver_gain1_gain1__out + _resolver_gain1_constant1__out;
    // Generated from the component: resolver_gain3.Sum1
    _resolver_gain3_sum1__out = _resolver_gain3_gain1__out + _resolver_gain3_constant1__out;
    // Generated from the component: resolver_gain.Sum1
    _resolver_gain_sum1__out = _resolver_gain_gain1__out + _resolver_gain_constant1__out;
    // Generated from the component: resolver_gain2.Sum1
    _resolver_gain2_sum1__out = _resolver_gain2_gain1__out + _resolver_gain2_constant1__out;
    // Generated from the component: Resolver_cos
    HIL_OutAO(0x4000, (float)_resolver_gain1_sum1__out);
    // Generated from the component: Resolver_cos2
    HIL_OutAO(0x4001, (float)_resolver_gain3_sum1__out);
    // Generated from the component: Resolver_sin
    HIL_OutAO(0x4002, (float)_resolver_gain_sum1__out);
    // Generated from the component: Resolver_sin2
    HIL_OutAO(0x4003, (float)_resolver_gain2_sum1__out);
//@cmp.out.block.end
    //////////////////////////////////////////////////////////////////////////
    // Update block
    //////////////////////////////////////////////////////////////////////////
    //@cmp.update.block.start
    //@cmp.update.block.end
}
// ----------------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------------