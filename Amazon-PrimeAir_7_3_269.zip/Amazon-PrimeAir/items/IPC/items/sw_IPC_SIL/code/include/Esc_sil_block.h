#pragma once
#include <Entypes.h>
#include <Sil_data.h>
#include <Sil_io_esc.h>
#include <Ttime.h>
#include <Mc.h>
#include <Mc_control.h>
#include <ADC.h>

namespace Esc_so
{
    class Esc_sil_block
    {
    public:

        /// Default constructor
        Esc_sil_block();

        /// Main computation
        /// \param[in] t: simulated time (s)
        /// \param[in] inputs: ESC inputs
        /// \param[out] outputs: ESC outputs
        Real64 step(const Real64 t, const Esc_input& inputs, Esc_output& out);

        /// Return Control structure
        /// \ret ::c2 \a ctrl instance
        inline const MCxx::Control_foc_noenc& get_control() const
        {
            return c2->ctrl;
        }

        /// Initialize IPC C1 and C2 for provided ESC node identifier.
        /// \param[in] node_id0 Node identifer.
        void init(Uint16 node_id0);

        //// Return the most recent executed task
        /// \ret ::next \a task
        inline Base::Sil_data::Task_id get_next_task() const
        {
            return next.task;
        }

    private:
        static const Base::Ttime cio_hi_period_us;  ///< Desired CIO-HI period in microseconds.
        static const Base::Ttime cio_lo_period_us;  ///< Desired CIO-LO period in microseconds.
        static const Base::Ttime c2_hi_period_us;   ///< Desired C2 period in microseconds.
        static const Base::Ttime c2_lo_period_us;   ///< Desired C2 period in microseconds.
        Base::Ttime next_cio_hi_time;               ///< Next time that the cio_hi step needs to be executed.
        Base::Ttime next_cio_lo_time;               ///< Next time that the cio_lo step needs to be executed.
        Base::Ttime next_c2_hi_time;                ///< Next time that the c2 hi step needs to be executed.
        Base::Ttime next_c2_lo_time;                ///< Next time that the c2 lo step needs to be executed.

        MCxx::Mc* c1;                               ///< C1 instance, null at build-time.
        MCxx::Mc_control* c2;                       ///< C2 instance, null at build-time.

        /// Task data definition
        struct Min_task
        {
            Base::Sil_data::Task_id task;    ///< Task ID
            Base::Ttime time;                ///< Associated time
        };

        Esc_sil_block::Min_task next;        ///< Next task to be executed

        /// Find most priority task to be executed
        Min_task find_next_task() const;

        /// Tasks definition
        inline void step_cio_lo()
        {
            c1->bg_task();
        }

        inline void step_cio_hi()
        {
            c1->step_hi();
        }

        inline void step_c2_hi()
        {
            c2->step_hi();
        }

        inline void step_c2_lo()
        {
            c2->bg_task();
        }

        Esc_sil_block(const Esc_sil_block& obj) = delete;
        Esc_sil_block& operator=(const Esc_sil_block& obj) = delete;
    };
}
