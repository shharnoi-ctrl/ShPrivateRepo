/// @copyright Copyright 2024 Amazon.com, Inc. or its affiliates. All Rights Reserved.
/// The interface to the Amazon Electronic Speed Control (ESC) and Brushless DC (BLDC) motor
/// simulation.
///
/// Note: This interface must comply with C++-03 standards in order to support external vendors'
/// standards.

#ifndef AMZN_ESC_SIM_INTERFACE_H_INCLUDED
#define AMZN_ESC_SIM_INTERFACE_H_INCLUDED

#include <stdint.h>
#include <cstddef>

/// namespace amzn
namespace amzn {
/// namespace amzn::esc
namespace esc {
/// namespace amzn::esc::sim
namespace sim {

/// The interface to the Amazon Electronic Speed Control (ESC) and Brushless DC (BLDC) motor
/// simulation.
class Interface
{
public:
    /// A three-vector in the [A, B, C] axes.
    struct VectorABC
    {
        /// The A component.
        float a;

        /// The B component.
        float b;

        /// The C component.
        float c;
    };

    /// Configuration used by the Amazon ESC simulation.
    struct Configuration
    {
        /// An enumeration of standard configurations the module may be aware of.  Not all
        /// configurations must be supported by all simulations.
        enum Id
        {
            kIdUnknown = 0,       ///< Empty/none/unknown.
            kIdCustom,            ///< Custom.
            kIdCX3Typhoon,        ///< CX3 "Typhoon" HilSim-equivalent.
            kIdCX3Bloc10FullSim,  ///< CX3 BLOC-10 used in FullSim.
        };

        /// The type of configuration held in the structure.
        Id id;

        /// The duration of each "step" in the simulation.
        float dt_s;

        /// The motor's properties.
        struct Motor
        {
            /// Number of pole-pairs.
            uint32_t pole_pairs;

            /// Phase-to-neutral nominal coil resistance at 20degC (ohms).
            /// @note This component is adjusted inside the model as temperature changes.  To treat
            /// the motor's resistance as constant, lump the phase-to-neutral resistance together
            /// with the lead-wire resistance, as it is not temperature-compensated.
            float p2n_R_ohm;

            /// Phase-to-neutral coil inductance (H).
            float p2n_L_H;

            /// Phase-to-neutral back-EMF (Wb).
            /// @note This is in units of peak (not RMS) volts per electrical (not mechanical)
            /// radian per second (not RPM).
            float p2n_k_emf_Wb;

            /// The principal cogging torque.
            /// @note Typically needs to be greater than the motor's friction (the K1 term in the
            /// load) to be effective at aligning the motor, though not all motors actually have
            /// cogging torques large enough to overcome friction.
            float cogging_torque_N_m;

            /// The least-common-multiple between the motor's number of pole-pairs and stator teeth.
            /// Used for cogging-torque calculations.
            uint32_t poles_teeth_lcm;

            /// The moment-of-inertia of the armature (kg*m^2).
            float J_kg_m2;

            /// Structure to hold the coefficients for losses within the motor (inertia, friction,
            /// core-losses, etc.).
            /// - torque = K1*sign(omega) + K2*omega
            struct Losses
            {
                /// K1 coefficient (friction term).
                float K1_N_m;

                /// K2 coefficient (proportional term) ((N*m)/(rad/s)).
                float K2_N_m_s_per_rad;
            } losses;

            /// Thermal capacity.
            float C_J_per_K;
        } motor;

        /// The lead-wire, connectors, etc.
        struct LeadWire
        {
            /// Lead-wire resistance (ohms)
            /// @note This component is held constant even as the motor's temperature changes.
            float R_ohm;
        } lead_wire;

        /// The voltage inverter's properties.
        struct Inverter
        {
            /// Short-circuit impedance of the inverter
            /// @note Used as a bulk parameter to "fudge" currents during a short-circuit.
            float sc_Z_ohm;

            /// On-resistance of a single phase's switch (MOSFET, etc.).
            float Rds_ohm;

            /// Forward-drop of a single phase's switch (MOSFET, etc.).
            float Vsd_V;

            /// Inverter switching dead-time.
            float dead_time_s;

            /// Thermal capacity.
            float C_J_per_K;
        } inverter;

        /// Properties of the DC link.
        struct DcLink
        {
            /// Equivalent series resistance (ohms).
            float esr_ohm;

            /// Equivalent series inductance (henries).
            float esl_H;

            /// Total bulk capacitance (farads).
            float bulk_F;
        } dc_link;

        /// Properties of the power source (battery, rack-mount supply, etc.).
        struct Supply
        {
            /// Indicates the power source is bipolar, or not.
            /// - True: the supply can also act as a load/current-sink.
            /// - False: the supply cannot act as a load/current-sink.
            bool is_bipolar;

            /// The supply's nominal voltage.
            float nominal_V;

            /// The supply's initial voltage (typically whatever voltage the processor would
            /// first come out of reset at).
            float initial_V;

            /// The "soft start" ramp-up tau of the supply.
            float soft_start_tau_s;
        } supply;

        /// Misc. properties of the PCBA (filters, etc.).
        struct Pcba
        {
            /// Non-motor related power draw (watts)
            float house_load_W;

            /// Tau of the hardware filter on the supply-voltage sense ADC channel (seconds)
            float tau_dc_link_vmeas_s;

            /// Tau of the hardware filter on the supply-current sense ADC channel (seconds)
            float tau_dc_link_imeas_s;
        } pcba;
    };

    /// Commands/inputs to the Amazon ESC simulation.
    struct Command
    {
        /// Structure which holds electrical commands for state, voltages, etc.
        struct Electrical
        {
            /// Signal that the inverter is enabled, or not.
            /// - false: the inverter is disabled - all phases are "open circuit" and `motor_abc_V`
            /// is ignored.
            /// - true: the inverter is enabled - `motor_abc_V` indicates the effective voltage
            /// applied to each motor phase.
            bool inverter_enable;

            /// The effective [A, B, C] voltages applied to each motor phase when the inverter is
            /// enabled.
            VectorABC motor_abc_V;

            /// The supply voltage.
            float supply_V;
        } electrical;

        /// Structure to hold the coefficients for loads outside the motor (inertia, friction,
        /// viscous loads, etc.).
        /// - torque = k0 + k1*omega + k2*sign(omega)*omega^2
        /// - torque = k0 + omega*(k1 + k2*|omega|)
        struct Mechanical
        {
            /// Moment-of-inertia (kg*m^2).
            float J_kg_m2;

            /// "Constant" load term.
            float k0_N_m;

            /// "Linear" load term ((N*m)/(rad/s))
            float k1_N_m_s_per_rad;

            /// "Square" load term ((N*m)/(rad/s)^2)
            float k2_N_m_s2_per_rad2;
        } mechanical;

        /// Thermal properties which may change over time.
        struct Thermal
        {
            /// Ambient temperature.
            float ambient_degC;

            /// Thermal conductance of the motor (flowing into the free-stream atmosphere).
            float motor_C_W_per_K;

            /// Thermal conductance of the inverter (flowing into the free-stream atmosphere).
            float inverter_C_W_per_K;
        } thermal;

        /// Which fault, if any, is active.
        /// @note Not all faults are modeled by all simulations.
        enum Fault
        {
            kFaultNone  ///< kNone - No fault is active.
        } active_fault;
    };

    /// Outputs/state of the Amazon ESC simulation which are observable and can be directly
    /// measured.
    struct StateObservable
    {
        /// The motor's [A, B, C] electric phase-currents.
        VectorABC motor_abc_A;

        /// The DC-link electric current.
        float dc_link_A;

        /// The DC-link voltage.
        float dc_link_V;

        /// The inverter's [A, B, C] temperatures.
        VectorABC inverter_abc_degC;

        /// The motor's temperature.
        float motor_degC;
    };

    /// Outputs/state of the Amazon ESC simulation which are not observable - these can only be
    /// inferred indirectly and generally cannot be used directly by the controller.
    struct StateHidden
    {
        /// The motor's mechanical orientation.
        float motor_mech_theta_pirad;

        /// The motor's mechanical angular velocity.
        float motor_mech_omega_rad_per_s;

        /// The motor's electrical orientation.
        float motor_elec_theta_pirad;

        /// The motor's electrical angular velocity.
        float motor_elec_omega_rad_per_s;

        /// The motor's back-EMF
        VectorABC motor_back_emf_abc_V;
    };

    /// Total set of outputs/state from the Amazon ESC simulation (observable and hidden).
    struct State
    {
        /// The observable state - ideal values, without influence of filters, noise, etc.
        StateObservable ideal;

        /// The observable state - measurable values, which may include the influence of filters,
        /// noise, etc.
        StateObservable measured;

        /// The hidden state.
        StateHidden hidden;

        /// The number of iterations through the simulation.
        uint64_t iteration;
    };

#if 0
    // TODO: The simulation does not support dynamic configuration at this time.
    /// Get a read/write reference through which the simulation's configuration can be updated.
    /// Updating through this reference will change the behavior of the simulation.
    /// @return A read/write reference to the active configuration structure used by the simulation.
    virtual Configuration & UpdateConfiguration() = 0;
#endif

    /// Get a read-only reference through which the simulation's configuration.
    /// @return A reference to the active configuration structure used by the simulation.
    virtual const Configuration & AccessConfiguration() const = 0;

    /// Does the simulation appear to be configured?
    /// @retval true the configuration appears valid.
    /// @retval false the configuration appears invalid.
    virtual bool IsConfigured() const = 0;

#if 0
    // TODO: The simulation cannot be reset at this time - destruct and reconstruct it.
    /// Reset the simulation's state.
    /// @param state optional state to initialize with.
    virtual void Reset( const State & state = State{} ) = 0;
#endif

    /// Get a reference through which the simulation's command can be updated.
    /// @return A reference to the active command structure used by the simulation.
    virtual Command & UpdateCommand() = 0;

    /// Step the simulation forward in time.
    virtual void Step( void ) = 0;

    /// Get the simulation's state.
    /// @return a reference to the structure to the present state.
    virtual const State & AccessState() const = 0;

    /// Helper to identify if a simulation models a particular fault.
    /// @param fault the `Command::Fault` in question.
    /// @retval true the simulation supports the fault.
    /// @retval false the simulatino does not support the fault.
    virtual bool SupportsFault( Command::Fault fault ) const = 0;

    /// Default destructor.
    virtual ~Interface(){};
};

}  // namespace sim
}  // namespace esc
}  // namespace amzn

/**
 * Gets the "worst-case" size of the buffer needed to hold an instance of the simulation.  This
 * accounts for padding needed to ensure the instance is properly aligned.
 * @return the size of a buffer, in bytes, needed to hold an instance of the simulation, taking into
 * account target-platform alignment.
 */
extern "C" size_t amzn_esc_sim_sizeof( void );

/**
 * Factory to make an in-place instance of the simulation.
 *
 * @param configuration_id the configuration to be used by the instance.
 * @param buffer_ptr a pointer to the buffer in which the instance is to be created.  Must be large
 * enough to hold the instance, but alignment requirements (if any) are handled internally.
 * @param buffer_size the size of the buffer.
 * @return If the buffer was large enough to hold an instance, a pointer to the base of the instance
 * is returned.  If the buffer was not large enough, a null-pointer is returned.
 *
 * @note For proper cleanup, `amzn_esc_sim_destruct()` must be explicitly called when the
 * instance goes out of scope.  Smart-pointers are inappropriate here because the library did not
 * allocate the memory, and the smart-pointer would attempt to release it.
 */
extern "C" amzn::esc::sim::Interface * amzn_esc_sim_construct(
    amzn::esc::sim::Interface::Configuration::Id configuration_id,
    char * buffer_ptr,
    size_t buffer_size );

/**
 * Destroy a previously manufactured instance of the simulation
 * @param instance_ptr a pointer to the instance to be destroyed.
 */
extern "C" void amzn_esc_sim_destruct( amzn::esc::sim::Interface * instance_ptr );

#endif  // AMZN_ESC_SIM_INTERFACE_H_INCLUDED
