#pragma once
#include <stdint.h>
#include <Sincos.h>

extern "C"
{
    static const Uint16 sz = 3U;    ///< Number of phases

    /// The Ver_input_dll struct contains all the inputs for SIL. All of the inputs are optional.
    struct Esc_input
    {
        Real ac_currents_adc[sz];            ///< ADC voltage phase currents (V)
        Real vdc_adc;                        ///< ADC voltage for Vdc side (V)
        Real vmon_adc;                       ///< ADC voltage for monitoring voltage side (V)
        Real idc_adc;                        ///< ADC voltage for Idc side (V)
        Real motor_temp_adc;                 ///< ADC voltage for motor temperature side (V)
        Maverick::Sincos sincos_sensor1_adc; ///< ADC voltage for first sensor (V)
        Maverick::Sincos sincos_sensor2_adc; ///< ADC voltage for second sensor (V)
    };

    /// The Ver_output_dll struct contains all the outputs computed during the SIL step.
    struct Esc_output
    {
        float pwm_output[sz];    ///< Three phases pwm duty cycle voltage (V): duty * Vdc
    };
}
