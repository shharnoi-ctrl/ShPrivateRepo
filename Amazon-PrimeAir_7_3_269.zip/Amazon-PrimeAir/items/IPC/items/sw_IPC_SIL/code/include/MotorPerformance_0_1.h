// This is an AUTO-GENERATED Cyphal DSDL data type implementation. Curious? See https://opencyphal.org.
// You shouldn't attempt to edit this file.
//
// Checking this file under version control is not recommended unless it is used as part of a high-SIL
// safety-critical codebase. The typical usage scenario is to generate it as part of the build process.
//
// To avoid conflicts with definitions given in the source DSDL file, all entities created by the code generator
// are named with an underscore at the end, like foo_bar_().
//
// Generator:     nunavut-2.3.2.dev0 (serialization was enabled)
// Source file:   /local/p4clients/pkgbuild-jIxa9/workspace/src/AdnVehiclePropulsionSystemMessages/cyphal_dsdl/vsdk/message/adn/vehicle/propulsionsystem/MotorPerformance.0.1.dsdl
// Generated at:  2024-03-15 12:09:55.285405 UTC
// Is deprecated: no
// Fixed port-ID: None
// Full name:     vsdk.message.adn.vehicle.propulsionsystem.MotorPerformance
// Version:       0.1
//
// Platform
//     python_implementation:  CPython
//     python_version:  3.8.18
//     python_release_level:  final
//     python_build:  ('default', 'Mar 11 2024 06:41:50')
//     python_compiler:  GCC 7.5.0
//     python_revision:
//     python_xoptions:  {}
//     runtime_platform:  Linux-5.4.266-187.365.amzn2int.x86_64-x86_64-with
//
// Language Options
//     target_endianness:  little
//     omit_float_serialization_support:  False
//     enable_serialization_asserts:  False
//     enable_override_variable_array_capacity:  False
//     cast_format:  (({type}) {value})
//     std:  c11

#ifndef VSDK_MESSAGE_ADN_VEHICLE_PROPULSIONSYSTEM_MOTOR_PERFORMANCE_0_1_INCLUDED_
#define VSDK_MESSAGE_ADN_VEHICLE_PROPULSIONSYSTEM_MOTOR_PERFORMANCE_0_1_INCLUDED_

#include <serialization.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <EscState_0_1.h>

static_assert( NUNAVUT_SUPPORT_LANGUAGE_OPTION_TARGET_ENDIANNESS == 434322821,
              "/local/p4clients/pkgbuild-jIxa9/workspace/src/AdnVehiclePropulsionSystemMessages/cyphal_dsdl/vsdk/message/adn/vehicle/propulsionsystem/MotorPerformance.0.1.dsdl is trying to use a serialization library that was compiled with "
              "different language options. This is dangerous and therefore not allowed." );
static_assert( NUNAVUT_SUPPORT_LANGUAGE_OPTION_OMIT_FLOAT_SERIALIZATION_SUPPORT == 0,
              "/local/p4clients/pkgbuild-jIxa9/workspace/src/AdnVehiclePropulsionSystemMessages/cyphal_dsdl/vsdk/message/adn/vehicle/propulsionsystem/MotorPerformance.0.1.dsdl is trying to use a serialization library that was compiled with "
              "different language options. This is dangerous and therefore not allowed." );
static_assert( NUNAVUT_SUPPORT_LANGUAGE_OPTION_ENABLE_SERIALIZATION_ASSERTS == 0,
              "/local/p4clients/pkgbuild-jIxa9/workspace/src/AdnVehiclePropulsionSystemMessages/cyphal_dsdl/vsdk/message/adn/vehicle/propulsionsystem/MotorPerformance.0.1.dsdl is trying to use a serialization library that was compiled with "
              "different language options. This is dangerous and therefore not allowed." );
static_assert( NUNAVUT_SUPPORT_LANGUAGE_OPTION_ENABLE_OVERRIDE_VARIABLE_ARRAY_CAPACITY == 0,
              "/local/p4clients/pkgbuild-jIxa9/workspace/src/AdnVehiclePropulsionSystemMessages/cyphal_dsdl/vsdk/message/adn/vehicle/propulsionsystem/MotorPerformance.0.1.dsdl is trying to use a serialization library that was compiled with "
              "different language options. This is dangerous and therefore not allowed." );
static_assert( NUNAVUT_SUPPORT_LANGUAGE_OPTION_CAST_FORMAT == 2368206204,
              "/local/p4clients/pkgbuild-jIxa9/workspace/src/AdnVehiclePropulsionSystemMessages/cyphal_dsdl/vsdk/message/adn/vehicle/propulsionsystem/MotorPerformance.0.1.dsdl is trying to use a serialization library that was compiled with "
              "different language options. This is dangerous and therefore not allowed." );
static_assert( NUNAVUT_SUPPORT_LANGUAGE_OPTION_STD == 575908835,
              "/local/p4clients/pkgbuild-jIxa9/workspace/src/AdnVehiclePropulsionSystemMessages/cyphal_dsdl/vsdk/message/adn/vehicle/propulsionsystem/MotorPerformance.0.1.dsdl is trying to use a serialization library that was compiled with "
              "different language options. This is dangerous and therefore not allowed." );

#ifdef __cplusplus
extern "C" {
#endif

/// This type does not have a fixed port-ID. See https://forum.opencyphal.org/t/choosing-message-and-service-ids/889
#define vsdk_message_adn_vehicle_propulsionsystem_MotorPerformance_0_1_HAS_FIXED_PORT_ID_ false

// +-------------------------------------------------------------------------------------------------------------------+
// | vsdk.message.adn.vehicle.propulsionsystem.MotorPerformance.0.1
// +-------------------------------------------------------------------------------------------------------------------+
#define vsdk_message_adn_vehicle_propulsionsystem_MotorPerformance_0_1_FULL_NAME_             "vsdk.message.adn.vehicle.propulsionsystem.MotorPerformance"
#define vsdk_message_adn_vehicle_propulsionsystem_MotorPerformance_0_1_FULL_NAME_AND_VERSION_ "vsdk.message.adn.vehicle.propulsionsystem.MotorPerformance.0.1"

/// Extent is the minimum amount of memory required to hold any serialized representation of any compatible
/// version of the data type; or, on other words, it is the the maximum possible size of received objects of this type.
/// The size is specified in bytes (rather than bits) because by definition, extent is an integer number of bytes long.
/// When allocating a deserialization (RX) buffer for this data type, it should be at least extent bytes large.
/// When allocating a serialization (TX) buffer, it is safe to use the size of the largest serialized representation
/// instead of the extent because it provides a tighter bound of the object size; it is safe because the concrete type
/// is always known during serialization (unlike deserialization). If not sure, use extent everywhere.
#define vsdk_message_adn_vehicle_propulsionsystem_MotorPerformance_0_1_EXTENT_BYTES_                    22UL
#define vsdk_message_adn_vehicle_propulsionsystem_MotorPerformance_0_1_SERIALIZATION_BUFFER_SIZE_BYTES_ 22UL
static_assert(vsdk_message_adn_vehicle_propulsionsystem_MotorPerformance_0_1_EXTENT_BYTES_ >= vsdk_message_adn_vehicle_propulsionsystem_MotorPerformance_0_1_SERIALIZATION_BUFFER_SIZE_BYTES_,
              "Internal constraint violation");

typedef struct
{
    /// saturated uint16 can_node_id
    uint16_t can_node_id;

    /// saturated int16 commanded_rpm
    int16_t commanded_rpm;

    /// saturated int16 measured_rpm
    int16_t measured_rpm;

    /// saturated int16 input_current_cA
    int16_t input_current_cA;

    /// saturated uint10 input_voltage_dV
    uint16_t input_voltage_dV;

    /// saturated int20 commanded_iq_mA
    int32_t commanded_iq_mA;

    /// saturated int20 measured_iq_mA
    int32_t measured_iq_mA;

    /// saturated bool is_on_external_power
    bool is_on_external_power;

    /// vsdk.message.adn.vehicle.propulsionsystem.EscState.0.1 state
    vsdk_message_adn_vehicle_propulsionsystem_EscState_0_1 state;
} vsdk_message_adn_vehicle_propulsionsystem_MotorPerformance_0_1;

/// Serialize an instance into the provided buffer.
/// The lifetime of the resulting serialized representation is independent of the original instance.
/// This method may be slow for large objects (e.g., images, point clouds, radar samples), so in a later revision
/// we may define a zero-copy alternative that keeps references to the original object where possible.
///
/// @param obj      The object to serialize.
///
/// @param buffer   The destination buffer. There are no alignment requirements.
///                 @see vsdk_message_adn_vehicle_propulsionsystem_MotorPerformance_0_1_SERIALIZATION_BUFFER_SIZE_BYTES_
///
/// @param inout_buffer_size_bytes  When calling, this is a pointer to the size of the buffer in bytes.
///                                 Upon return this value will be updated with the size of the constructed serialized
///                                 representation (in bytes); this value is then to be passed over to the transport
///                                 layer. In case of error this value is undefined.
///
/// @returns Negative on error, zero on success.
static inline int8_t vsdk_message_adn_vehicle_propulsionsystem_MotorPerformance_0_1_serialize_(
    const vsdk_message_adn_vehicle_propulsionsystem_MotorPerformance_0_1* const obj, uint8_t* const buffer,  size_t* const inout_buffer_size_bytes)
{
    if ((obj == NULL) || (buffer == NULL) || (inout_buffer_size_bytes == NULL))
    {
        return -NUNAVUT_ERROR_INVALID_ARGUMENT;
    }
    const size_t capacity_bytes = *inout_buffer_size_bytes;
    if ((8U * (size_t) capacity_bytes) < 176UL)
    {
        return -NUNAVUT_ERROR_SERIALIZATION_BUFFER_TOO_SMALL;
    }
    // Notice that fields that are not an integer number of bytes long may overrun the space allocated for them
    // in the serialization buffer up to the next byte boundary. This is by design and is guaranteed to be safe.
    size_t offset_bits = 0U;
    {   // saturated uint16 can_node_id
        // Saturation code not emitted -- native representation matches the serialized representation.
        (void) memmove(&buffer[offset_bits / 8U], &obj->can_node_id, 2U);
        offset_bits += 16U;
    }
    {   // saturated int16 commanded_rpm
        // Saturation code not emitted -- native representation matches the serialized representation.
        (void) memmove(&buffer[offset_bits / 8U], &obj->commanded_rpm, 2U);
        offset_bits += 16U;
    }
    {   // saturated int16 measured_rpm
        // Saturation code not emitted -- native representation matches the serialized representation.
        (void) memmove(&buffer[offset_bits / 8U], &obj->measured_rpm, 2U);
        offset_bits += 16U;
    }
    {   // saturated int16 input_current_cA
        // Saturation code not emitted -- native representation matches the serialized representation.
        (void) memmove(&buffer[offset_bits / 8U], &obj->input_current_cA, 2U);
        offset_bits += 16U;
    }
    {   // saturated uint10 input_voltage_dV
        uint16_t _sat0_ = obj->input_voltage_dV;
        if (_sat0_ > 1023U)
        {
            _sat0_ = 1023U;
        }
        (void) memmove(&buffer[offset_bits / 8U], &_sat0_, 2U);
        offset_bits += 10U;
    }
    {   // saturated int20 commanded_iq_mA
        int32_t _sat1_ = obj->commanded_iq_mA;
        if (_sat1_ < -524288L)
        {
            _sat1_ = -524288L;
        }
        if (_sat1_ > 524287L)
        {
            _sat1_ = 524287L;
        }
        const int8_t _err0_ = nunavutSetIxx(&buffer[0], capacity_bytes, offset_bits, _sat1_, 20U);
        if (_err0_ < 0)
        {
            return _err0_;
        }
        offset_bits += 20U;
    }
    {   // saturated int20 measured_iq_mA
        int32_t _sat2_ = obj->measured_iq_mA;
        if (_sat2_ < -524288L)
        {
            _sat2_ = -524288L;
        }
        if (_sat2_ > 524287L)
        {
            _sat2_ = 524287L;
        }
        const int8_t _err1_ = nunavutSetIxx(&buffer[0], capacity_bytes, offset_bits, _sat2_, 20U);
        if (_err1_ < 0)
        {
            return _err1_;
        }
        offset_bits += 20U;
    }
    {   // saturated bool is_on_external_power
        if (obj->is_on_external_power)
        {
            buffer[offset_bits / 8U] = (uint8_t)(buffer[offset_bits / 8U] | (1U << (offset_bits % 8U)));
        }
        else
        {
            buffer[offset_bits / 8U] = (uint8_t)(buffer[offset_bits / 8U] & ~(1U << (offset_bits % 8U)));
        }
        offset_bits += 1U;
    }
    if (offset_bits % 8U != 0U)  // Pad to 8 bits. TODO: Eliminate redundant padding checks.
    {
        const uint8_t _pad0_ = (uint8_t)(8U - offset_bits % 8U);
        const int8_t _err2_ = nunavutSetUxx(&buffer[0], capacity_bytes, offset_bits, 0U, _pad0_);  // Optimize?
        if (_err2_ < 0)
        {
            return _err2_;
        }
        offset_bits += _pad0_;
    }
    {   // vsdk.message.adn.vehicle.propulsionsystem.EscState.0.1 state
        size_t _size_bytes0_ = 7UL;  // Nested object (max) size, in bytes.
        int8_t _err3_ = vsdk_message_adn_vehicle_propulsionsystem_EscState_0_1_serialize_(
            &obj->state, &buffer[offset_bits / 8U], &_size_bytes0_);
        if (_err3_ < 0)
        {
            return _err3_;
        }
        // It is assumed that we know the exact type of the serialized entity, hence we expect the size to match.
        offset_bits += _size_bytes0_ * 8U;  // Advance by the size of the nested object.
    }
    if (offset_bits % 8U != 0U)  // Pad to 8 bits. TODO: Eliminate redundant padding checks.
    {
        const uint8_t _pad1_ = (uint8_t)(8U - offset_bits % 8U);
        const int8_t _err4_ = nunavutSetUxx(&buffer[0], capacity_bytes, offset_bits, 0U, _pad1_);  // Optimize?
        if (_err4_ < 0)
        {
            return _err4_;
        }
        offset_bits += _pad1_;
    }
    // It is assumed that we know the exact type of the serialized entity, hence we expect the size to match.
    *inout_buffer_size_bytes = (size_t) (offset_bits / 8U);
    return NUNAVUT_SUCCESS;
}

/// Deserialize an instance from the provided buffer.
/// The lifetime of the resulting object is independent of the original buffer.
/// This method may be slow for large objects (e.g., images, point clouds, radar samples), so in a later revision
/// we may define a zero-copy alternative that keeps references to the original buffer where possible.
///
/// @param obj      The object to update from the provided serialized representation.
///
/// @param buffer   The source buffer containing the serialized representation. There are no alignment requirements.
///                 If the buffer is shorter or longer than expected, it will be implicitly zero-extended or truncated,
///                 respectively; see Specification for "implicit zero extension" and "implicit truncation" rules.
///
/// @param inout_buffer_size_bytes  When calling, this is a pointer to the size of the supplied serialized
///                                 representation, in bytes. Upon return this value will be updated with the
///                                 size of the consumed fragment of the serialized representation (in bytes),
///                                 which may be smaller due to the implicit truncation rule, but it is guaranteed
///                                 to never exceed the original buffer size even if the implicit zero extension rule
///                                 was activated. In case of error this value is undefined.
///
/// @returns Negative on error, zero on success.
static inline int8_t vsdk_message_adn_vehicle_propulsionsystem_MotorPerformance_0_1_deserialize_(
    vsdk_message_adn_vehicle_propulsionsystem_MotorPerformance_0_1* const out_obj, const uint8_t* buffer, size_t* const inout_buffer_size_bytes)
{
    if ((out_obj == NULL) || (inout_buffer_size_bytes == NULL) || ((buffer == NULL) && (0 != *inout_buffer_size_bytes)))
    {
        return -NUNAVUT_ERROR_INVALID_ARGUMENT;
    }
    if (buffer == NULL)
    {
        buffer = (const uint8_t*)"";
    }
    const size_t capacity_bytes = *inout_buffer_size_bytes;
    const size_t capacity_bits = capacity_bytes * (size_t) 8U;
    size_t offset_bits = 0U;
    // saturated uint16 can_node_id
    out_obj->can_node_id = nunavutGetU16(&buffer[0], capacity_bytes, offset_bits, 16);
    offset_bits += 16U;
    // saturated int16 commanded_rpm
    out_obj->commanded_rpm = nunavutGetI16(&buffer[0], capacity_bytes, offset_bits, 16);
    offset_bits += 16U;
    // saturated int16 measured_rpm
    out_obj->measured_rpm = nunavutGetI16(&buffer[0], capacity_bytes, offset_bits, 16);
    offset_bits += 16U;
    // saturated int16 input_current_cA
    out_obj->input_current_cA = nunavutGetI16(&buffer[0], capacity_bytes, offset_bits, 16);
    offset_bits += 16U;
    // saturated uint10 input_voltage_dV
    out_obj->input_voltage_dV = nunavutGetU16(&buffer[0], capacity_bytes, offset_bits, 10);
    offset_bits += 10U;
    // saturated int20 commanded_iq_mA
    out_obj->commanded_iq_mA = nunavutGetI32(&buffer[0], capacity_bytes, offset_bits, 20);
    offset_bits += 20U;
    // saturated int20 measured_iq_mA
    out_obj->measured_iq_mA = nunavutGetI32(&buffer[0], capacity_bytes, offset_bits, 20);
    offset_bits += 20U;
    // saturated bool is_on_external_power
    if (offset_bits < capacity_bits)
    {
        out_obj->is_on_external_power = (buffer[offset_bits / 8U] & (1U << (offset_bits % 8U))) != 0U;
    }
    else
    {
        out_obj->is_on_external_power = false;
    }
    offset_bits += 1U;
    offset_bits = (offset_bits + 7U) & ~(size_t) 7U;  // Align on 8 bits.
    // vsdk.message.adn.vehicle.propulsionsystem.EscState.0.1 state
    {
        size_t _size_bytes1_ = (size_t)(capacity_bytes - nunavutChooseMin((offset_bits / 8U), capacity_bytes));
        const int8_t _err5_ = vsdk_message_adn_vehicle_propulsionsystem_EscState_0_1_deserialize_(
            &out_obj->state, &buffer[offset_bits / 8U], &_size_bytes1_);
        if (_err5_ < 0)
        {
            return _err5_;
        }
        offset_bits += _size_bytes1_ * 8U;  // Advance by the size of the nested serialized representation.
    }
    offset_bits = (offset_bits + 7U) & ~(size_t) 7U;  // Align on 8 bits.
    *inout_buffer_size_bytes = (size_t) (nunavutChooseMin(offset_bits, capacity_bits) / 8U);
    return NUNAVUT_SUCCESS;
}

/// Initialize an instance to default values. Does nothing if @param out_obj is NULL.
/// This function intentionally leaves inactive elements uninitialized; for example, members of a variable-length
/// array beyond its length are left uninitialized; aliased union memory that is not used by the first union field
/// is left uninitialized, etc. If full zero-initialization is desired, just use memset(&obj, 0, sizeof(obj)).
static inline void vsdk_message_adn_vehicle_propulsionsystem_MotorPerformance_0_1_initialize_(vsdk_message_adn_vehicle_propulsionsystem_MotorPerformance_0_1* const out_obj)
{
    if (out_obj != NULL)
    {
        size_t size_bytes = 0;
        const uint8_t buf = 0;
        const int8_t err = vsdk_message_adn_vehicle_propulsionsystem_MotorPerformance_0_1_deserialize_(out_obj, &buf, &size_bytes);

        (void) err;
    }
}

#ifdef __cplusplus
}
#endif
#endif // VSDK_MESSAGE_ADN_VEHICLE_PROPULSIONSYSTEM_MOTOR_PERFORMANCE_0_1_INCLUDED_
