/// @copyright Copyright 2021-2022 Amazon.com, Inc. or its affiliates. All Rights Reserved.

/// @file
/// This file contains the declaration of components of the interface between firmware and
/// simulation environments

#pragma once
#include <cstdint>
#include <stddef.h>
#include <stdlib.h>
#include <vector>



/// @brief Container for a message; payload and message metadata.
struct MessageData
{
    /// Reserve bytes for the payload as a temporary mitigation to prevent
    /// reallocation if passed between code that uses incompatible new/delete
    /// implementations. The value is chosen as the biggest message we expect
    /// to see (GroundTruthState ~= 2000) plus a bit.
    /// TODO FWSIM-53 - Revisit FirmwareSimulation interface to mitigate for std::vector reallocations 
    constexpr static const size_t kMaxPayloadSizeBytes  = 3000;

    /// @brief Constructor to prepare the serialized_data vector
    /// @param message_length the length in bytes
    MessageData(size_t message_length) : 
        serialized_payload(message_length, 0),
        payload_size_bytes{ message_length},
        destination_node_id{0},
        source_node_id{0},
        priority{0},
        is_service{false},
        is_request{false},
        tail_byte{0},
        port_id{0},
        transport{0},
        is_valid{false}
    {}

    /// @brief Constructor to init to invalid. 
    MessageData() :
        serialized_payload(kMaxPayloadSizeBytes,0),
        payload_size_bytes{},
        destination_node_id{0},
        source_node_id{0},
        priority{0},
        is_service{false},
        is_request{false},
        tail_byte{0},
        port_id{0},
        transport{0},
        is_valid{false}
    {}

    /// Default destructor
    virtual ~MessageData() = default;

    /// Default copy constructor
    MessageData(const MessageData&) = default;

    /// Default move constructor
    MessageData(MessageData&&) = default;

    /// Default copy assignment 
    MessageData& operator=(const MessageData&) = default;

    /// default move assignment
    MessageData& operator=(MessageData&&) = default;

    /// The message payload. Vector chosen for maximum integration flexibility with Pybind11
    /// Most types require a copy when interacting with Python, but Pybind11 can `move` into a 
    /// vector.
    std::vector<uint8_t> serialized_payload;

    /// Size of the message data allocated to serialized_payload
    size_t payload_size_bytes;

    /// Destination Node ID required for Service messages.
    /// This value will be ignored if `is_service` != 0
    int32_t destination_node_id;

    /// Source Node ID required for all messages
    int32_t source_node_id;

    /// Required to recreate a the metadata accompanying the payload on a Transport.
    /// @{

    /// Priority values align with the Cyphal spec
    uint8_t priority;

    /// Required to be set for all messages.
    bool is_service;

    /// Set only for Service messages; ignored otherwise. 0 represents false, any finite value represents "true"
    bool is_request;

    /// Per Cyphal spec 4.2.2 the tail byte contains metadata describing the transfer.
    uint8_t tail_byte;

    /// @}

    /// Identifiers. Required to be able to choose how to deserialize a payload.
    uint16_t port_id;

    /// This is required so we know which bus the messages are on. Expected values match the enum
    /// underlying types in AdnABSPCommon and mapping will be done in the MainLoopApplicationSimulationt to
    /// map this properly for values understood by simulation.
    /// In most use-cases, the Firmware Simulation application shim-code will switch based on whether the string
    /// is "simulation" or not, assuming all other messages will be directed to its only message interface.
    /// However, should a system on multiple buses (i.e. if LIO becomes within scope for simulation), this
    /// field will be used to route the messages. This field is left as a string for flexbililty and to decouple
    /// the interface from VSDK etc, to ease integration in environments such as Simulink. Zero padded.
    uint8_t transport;

    /// Identifies whether this MessageData object contains valid data; true if so, false if the message is
    /// not valid for any reason e.g. to indicate that no message was copied into the structure.
    bool is_valid;
};


/// This interface represents all aspects of data exchange between a host simulation and the
/// firmware application.
class FirmwareSimulationDataExchange
{
public:
    /// default dtor
    virtual ~FirmwareSimulationDataExchange() = default;

    /// Send a message (vehicle or simulation) to the firmware application.
    /// @param msg the message to be sent to the firmware application
    /// @retval true The message was successfully passed to the firmware application
    /// @retval false An error occurred, such as a full queue.
    virtual bool PutMessage(const MessageData &msg) = 0;

    /// Poll the firmware to query whether it has a message ready. If a message is ready, allocate
    /// memory in the MessageData serialized_data and return it. Do not pre-allocate!
    /// @note It is expected to poll this function until it returns false.
    /// @param[out] msg the message data from the firmware application to be ingested into FullSim.
    /// @retval true There is a message ready and it has been successfully copied into `msg`
    /// @retval false There is no message ready.
    virtual bool GetMessage(MessageData &msg) = 0;
};
