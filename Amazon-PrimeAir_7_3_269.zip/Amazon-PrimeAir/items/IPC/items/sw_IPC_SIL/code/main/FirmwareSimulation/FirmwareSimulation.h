/// @copyright Copyright 2021-2022 Amazon.com, Inc. or its affiliates. All Rights Reserved.

/// @file 
/// This file contains the declaration of the interface between firmware and simulation envs.
/// Designed primarily for use with FullSim, it is intended to be general enough for other use also. 

#pragma once

#include "FirmwareSimulationDataExchange.h"
#include "FirmwareSimulationLifeCycle.h"

/// A interface between Firmware applications and simulation environments.
class FirmwareSimulation : public FirmwareSimulationLifeCycle, public FirmwareSimulationDataExchange
{
public:
    /// default dtor
    virtual ~FirmwareSimulation() = default;
};
 

extern "C" {
    /// This is the single `C` interface which is to be bound using dlsym from the Firmware application
    /// shared library. It returns a pointer to an instance of the FirmwareSimulation implementation. 
    /// The lifetime of this object is the responsibility of the caller. It must be deleted using 
    /// `delete` when no longer needed. 
    FirmwareSimulation * get_firmware_simulation_instance();
}