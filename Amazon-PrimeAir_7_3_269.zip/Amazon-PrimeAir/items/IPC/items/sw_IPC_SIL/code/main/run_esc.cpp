/**
 * @file
 * Freestanding example that links and runs the IPC
 * @copyright Copyright 2023 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 */
#include <dlfcn.h>
#include <algorithm>
#include <array>
#include <cstdlib>
#include <iostream>
#include <string>
#include <vector>

#include <vsdk/message/adn/simulation/GroundTruthState_0_1.h>
#include <vsdk/message/adn/simulation/propulsionsystem/GroundTruthRpm_0_1.h>
#include <vsdk/message/adn/vehicle/controlsystem/MotorRpmCommand_0_1.h>
#include <vsdk/message/adn/vehicle/controlsystem/RecoveryMotorRpmCommand_0_1.h>
#include <vsdk/message/adn/vehicle/propulsionsystem/MotorPerformance_0_1.h>

#include "FirmwareSimulation/FirmwareSimulation.h"

constexpr size_t kTransportStabA{ 2 };
constexpr size_t kTransportStabB{ 3 };
constexpr size_t kTransportSimulation{ kTransportStabA };

/// Helper class that packs a Concrete cyphal type into a FwSim 'MessageData' object
MessageData PackConcreteCyphalIntoMessageData(
    const uint8_t * serialized_msg_buffer,
    size_t expected_size,
    uint32_t port_id,
    uint32_t source_node_id,
    bool is_service,
    uint8_t transport)
{
    MessageData msg{ expected_size };
    std::copy(
        serialized_msg_buffer,
        serialized_msg_buffer + expected_size,
        msg.serialized_payload.begin() );

    msg.source_node_id = source_node_id;
    msg.is_service     = is_service;
    msg.port_id        = port_id;
    msg.transport      = transport;
    // TODO FWSIM-55 - Update transport value test in SimulationTransport
    msg.is_valid = true;
    return msg;
}

struct InstanceData
{
    int this_namespace             = LM_ID_NEWLM;
    void * dlm_handle              = nullptr;
    FirmwareSimulation * pfirmware = nullptr;
};

// take an InstanceData and open a lib
void OpenLib( InstanceData & esc, const char * pathname, int mask )
{
    esc.dlm_handle = dlopen( pathname, mask );  // Should be on the path
    assert( dlerror() == NULL );
    assert( esc.dlm_handle );
    auto get_instance_func_0 = reinterpret_cast<FirmwareSimulation * (*)()>(
        dlsym( esc.dlm_handle, "get_firmware_simulation_instance" ) );
    esc.pfirmware       = static_cast<FirmwareSimulation *>( get_instance_func_0() );
}

void CloseLib( InstanceData & esc )
{
    std::cout << "CloseLib " <<std::endl;
    if ( esc.pfirmware && esc.dlm_handle ) {
        delete esc.pfirmware;
        const auto ret = dlclose( esc.dlm_handle );
    }
}

// function that runs the simulation
int run(int argc, char *argv[]) {
    // load the firmware
    std::string firmware_path = argv[1];
    std::cout << "Loading firmware from " << firmware_path << std::endl;
    // First, we load the app from the library
    int mask = RTLD_LAZY | RTLD_DEEPBIND;
    
    /// the FirmwareSimulation implementation
    InstanceData esc_0;
    OpenLib( esc_0, firmware_path.c_str(), mask );

    // run the simulation
    std::cout << "Running simulation" << std::endl;

    // Init the firmware with some sample data
    const int node_id = 10;
    FirmwareInitData init_data_0
        = { node_id,  // Node ID
            { /* hash */ },
            {
                0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15  // UID
            },
            {
                16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31  // LRU
            },
            {
                32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47  // PCB
            } };
    // set them up the same; we have two here just to see if they interfere
    esc_0.pfirmware->Init( init_data_0 );

    vsdk_message_adn_vehicle_controlsystem_MotorRpmCommand_0_1 rpm_command_pr{};
    vsdk_message_adn_vehicle_controlsystem_RecoveryMotorRpmCommand_0_1 rpm_command_re{};
    // set a target-RPM
    rpm_command_pr.rpm_commands[node_id-10] =  2000;
    // indicate we should be enabled
    rpm_command_pr.motor_state_request.arm_intent
        = vsdk_message_adn_vehicle_controlsystem_MotorStateRequest_0_1_kArmIntentDisarmed;
    // indicate we should be in MEP-out (such that self-terminate is inhibited)
    rpm_command_pr.motor_state_request.enable_intent
        = vsdk_message_adn_vehicle_controlsystem_MotorStateRequest_0_1_kEnableIntentAllMotorsEnabled;
    rpm_command_pr.motor_state_request.disabled_motor
        = vsdk_message_adn_vehicle_controlsystem_MotorStateRequest_0_1_kDisabledMotorNone;
    rpm_command_re.rpm_command =  2000;
    // indicate we should be enabled
    rpm_command_re.motor_state_request.arm_intent
        = vsdk_message_adn_vehicle_controlsystem_MotorStateRequest_0_1_kArmIntentDisarmed;
    // indicate we should be in MEP-out (such that self-terminate is inhibited)
    rpm_command_re.motor_state_request.enable_intent
        = vsdk_message_adn_vehicle_controlsystem_MotorStateRequest_0_1_kEnableIntentAllMotorsEnabled;
    rpm_command_re.motor_state_request.disabled_motor
        = vsdk_message_adn_vehicle_controlsystem_MotorStateRequest_0_1_kDisabledMotorNone;
    rpm_command_re.motor_state_request.source =
            vsdk_message_adn_vehicle_controlsystem_MotorStateRequest_0_1_kSourceRecoveryLane;

    vsdk_message_adn_simulation_GroundTruthState_0_1 ground_truth_state {};
    ground_truth_state.motor_center_right_prop_torque_Nm = 1;
    ground_truth_state.motor_rear_right_prop_torque_Nm = 1;
    ground_truth_state.motor_front_right_prop_torque_Nm = 1;
    ground_truth_state.motor_center_left_prop_torque_Nm = 1;
    ground_truth_state.motor_rear_left_prop_torque_Nm = 1;
    ground_truth_state.motor_front_left_prop_torque_Nm = 1;
    uint8_t gts_buffer[vsdk_message_adn_simulation_GroundTruthState_0_1_EXTENT_BYTES_] = {0};
    size_t gts_serialized_size = vsdk_message_adn_simulation_GroundTruthState_0_1_EXTENT_BYTES_;
    if (vsdk_message_adn_simulation_GroundTruthState_0_1_serialize_(&ground_truth_state, gts_buffer, &gts_serialized_size) != 0) {
        return -1;
    }
    auto msg_gts_packed = PackConcreteCyphalIntoMessageData(
            gts_buffer, vsdk_message_adn_simulation_GroundTruthState_0_1_EXTENT_BYTES_, 998, 24, false, kTransportStabA);


    uint8_t rpm_command_buffer_pr[vsdk_message_adn_vehicle_controlsystem_MotorRpmCommand_0_1_EXTENT_BYTES_] = {};
    uint8_t rpm_command_buffer_re[vsdk_message_adn_vehicle_controlsystem_MotorRpmCommand_0_1_EXTENT_BYTES_] = {};
    size_t serialized_size_pr = vsdk_message_adn_vehicle_controlsystem_MotorRpmCommand_0_1_EXTENT_BYTES_;
    size_t serialized_size_re = vsdk_message_adn_vehicle_controlsystem_RecoveryMotorRpmCommand_0_1_EXTENT_BYTES_;
    if (vsdk_message_adn_vehicle_controlsystem_MotorRpmCommand_0_1_serialize_(&rpm_command_pr, rpm_command_buffer_pr, &serialized_size_pr) != 0) {
        return -1;
    }
    if (vsdk_message_adn_vehicle_controlsystem_RecoveryMotorRpmCommand_0_1_serialize_(&rpm_command_re, rpm_command_buffer_re, &serialized_size_re) != 0) {
        return -1;
    }

    auto msg_pri = PackConcreteCyphalIntoMessageData(
            rpm_command_buffer_pr, vsdk_message_adn_vehicle_controlsystem_MotorRpmCommand_0_1_EXTENT_BYTES_, 184, 24, false, kTransportStabA);
    auto msg_rec = PackConcreteCyphalIntoMessageData(
            rpm_command_buffer_re, vsdk_message_adn_vehicle_controlsystem_MotorRpmCommand_0_1_EXTENT_BYTES_, 240 + (node_id - 10), 31, false, kTransportStabB);



    uint64_t next_execute_ns = 0;
    static const int n_time_steps = 20000;
    // drain the queue of motor performance messages being sent from esc
    MessageData recv_msg_mp;
    MessageData recv_msg_gtrpm;
    MessageData recv_msg;
    bool received_mp  = false;
    bool received_gtrpm = false;
    for ( int i = 0; i < n_time_steps; i++ )
    {

        if(i>=n_time_steps/2)
        {
            rpm_command_pr.motor_state_request.arm_intent
                    = vsdk_message_adn_vehicle_controlsystem_MotorStateRequest_0_1_kArmIntentArmed;
            rpm_command_re.motor_state_request.arm_intent
                                = vsdk_message_adn_vehicle_controlsystem_MotorStateRequest_0_1_kArmIntentArmed;
            rpm_command_pr.rpm_commands[node_id-10] =  4000;
            rpm_command_re.rpm_command =  4000;
        }

        if(i==8000)
        {
            // send gts
            esc_0.pfirmware->PutMessage( msg_gts_packed );
        }

        if ( 0 == ( i % 10 ) )
        {
            vsdk_message_adn_vehicle_controlsystem_MotorRpmCommand_0_1_serialize_(&rpm_command_pr, rpm_command_buffer_pr, &serialized_size_pr);
            msg_pri = PackConcreteCyphalIntoMessageData(
                        rpm_command_buffer_pr, vsdk_message_adn_vehicle_controlsystem_MotorRpmCommand_0_1_EXTENT_BYTES_, 184, 24, false, kTransportStabA );

            vsdk_message_adn_vehicle_controlsystem_RecoveryMotorRpmCommand_0_1_serialize_(&rpm_command_re, rpm_command_buffer_re, &serialized_size_re);
            msg_rec = PackConcreteCyphalIntoMessageData(
                    rpm_command_buffer_re, vsdk_message_adn_vehicle_controlsystem_MotorRpmCommand_0_1_EXTENT_BYTES_, 240 + (node_id - 10), 31, false, kTransportStabB);

            esc_0.pfirmware->PutMessage( msg_pri );
            esc_0.pfirmware->PutMessage( msg_rec );
        }

        if(! esc_0.pfirmware->ExecuteAndScheduleNextExecutionInNs( next_execute_ns ) )
        {
            std::cout << "ExecuteAndScheduleNextExecutionInNs returned false" << std::endl;
            return -1;
        }
        assert( next_execute_ns == 1000000U );  // 1000000ns simulation step expected


        auto recv_ret = esc_0.pfirmware->GetMessage( recv_msg );
        if ( recv_ret && ( recv_msg.port_id == 421 ) )
        {
            // last known MP - copy it
            recv_msg_mp = recv_msg;
            received_mp = true;
        }
        else if ( recv_ret && ( recv_msg.port_id == ( 990 + node_id ) ) )
        {
            recv_msg_gtrpm = recv_msg;
            received_gtrpm = true;
        }
        else if ( recv_ret == false )
        {
            received_gtrpm = false;
        }

        // deserialize our last MotorPerformance message so we can print it
        vsdk_message_adn_vehicle_propulsionsystem_MotorPerformance_0_1 motorperformance;
            vsdk_message_adn_vehicle_propulsionsystem_MotorPerformance_0_1_initialize_(&motorperformance);
        size_t mp_serialized_size = recv_msg_mp.serialized_payload.size();
        if (vsdk_message_adn_vehicle_propulsionsystem_MotorPerformance_0_1_deserialize_(&motorperformance, recv_msg_mp.serialized_payload.data(), &mp_serialized_size) != 0) {
            std::cout << "Failed to deserialize MotorPerformance!" << std::endl;
            return -1;
        }

        // deserialize our GroundTruthRpm message so we can print it
        vsdk_message_adn_simulation_propulsionsystem_GroundTruthRpm_0_1 gtrpm;
        vsdk_message_adn_simulation_propulsionsystem_GroundTruthRpm_0_1_initialize_(&gtrpm);
        size_t gtrpm_serialized_size = recv_msg_gtrpm.serialized_payload.size();
        if (vsdk_message_adn_simulation_propulsionsystem_GroundTruthRpm_0_1_deserialize_(&gtrpm, recv_msg_gtrpm.serialized_payload.data(), &gtrpm_serialized_size) != 0) {
            std::cout << "Failed to deserialize GroundTruthRpm!" << std::endl;
            return -1;
        }

        std::cout << "Time step : " << i << std::endl;
        std::cout << "CAN Node ID: " << motorperformance.can_node_id << std::endl;
        std::cout << "Commanded RPM: " << motorperformance.commanded_rpm << std::endl;
        std::cout << "Measured RPM: " << motorperformance.measured_rpm << std::endl;
        std::cout << "Input Current (cA): " << motorperformance.input_current_cA << std::endl;
        std::cout << "Input Voltage (dV): " << motorperformance.input_voltage_dV << std::endl;
        std::cout << "Commanded IQ (mA): " << motorperformance.commanded_iq_mA << std::endl;
        std::cout << "Measured IQ (mA): " << motorperformance.measured_iq_mA << std::endl;
        std::cout << "Faults value: " << static_cast<int>(motorperformance.state.health.alerts_bitpacked_[node_id-10]) << std::endl;
        std::cout << "Ground Truth RPM: " << gtrpm.ground_truth_rpm << std::endl;
        std::cout << "\n" << std::endl;
    }

    assert( received_mp );
    assert( received_gtrpm );

    CloseLib(esc_0);
    std::cout << "Complete!" << std::endl;
    return 0;

}

int main(int argc, char *argv[]) {
    // run twice, loading and unloading the lib in between.
    std::cout << "Run 1" << std::endl;
    run(argc, argv);
    return 0;
}
