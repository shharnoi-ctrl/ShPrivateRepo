/// @copyright Copyright 2021-2022 Amazon.com, Inc. or its affiliates. All Rights Reserved.

/// @file 
/// This file contains the declaration of components of the interface between firmware and 
/// simulation environments
///
/// The customer usage is anticipated to be as the diagram:
/// @verbatim
///                 +--------------------------------------------------+
///                 |  Loaded and Executable                           |
///                 |--------------------------------------------------|
///                 |                                                  |
///                 |                                                  |
///                 |        +--------------------------------+        |
///                 |        |                                |        |
///                 |        |                                v        |
///  +------------+ |   +----+-----+     +----------+   +-----+-----+  |      +-----------+
///  |  dlmopen,  | |   |          |     |          |   |           |  |      |           |
///  |   dlsym,   +---->|  Init()  +---->|  Reset() +-->| Execute() |  +----->| dlclose() |
///  |  get inst* | |   |          |     |          |   |           |  |      |           |
///  +------------+ |   +----------+     +----------+   +-----+-----+  |      +-----------+
///                 |                          ^              |        |
///                 |                          |              |        |
///                 |                          +--------------+        |
///                 |                                                  |
///                 |                                                  |
///                 +--------------------------------------------------+
/// @endverbatim
/// 
/// @note It is the responsibility of the code which loads this firmware to ensure that it is 
/// properly destructed (i.e. `delete`) _before_ calling dlclose(). 

#pragma once

#include <cstdint>
#include <string>
#include <unordered_map>
#include <vector>

/// All the information not known at compile time to be shared with the firmware applications.
/// In the case of any breaking change, the major-version of the package will increment. 
struct FirmwareInitData
{
    /// Node ID is not known at compile time and will be provided at instantiation
    uint8_t node_id;

    /// The hash of the corresponding firmware build for the target hardware is not necessarily
    /// known at build time for this simulation target, so we let the simulation provide the
    /// expected hash so that this application can provide the expected values if queried.
    uint8_t PrimaryApplicationHash[32];

    /// UID is a per-PCBA quantity, and we allow the simulation to set it as desired. 
    uint8_t UID[16];

    /// LRU can be set to the as desired, allowing 'right' and 'wrong' cases to be tested. 
    uint8_t LRU[16]; 

    /// PCB can be set as desired for simulation.
    uint8_t PCB[16];

    /// Configuration data, can be used for PDI or any other optional inputs to be used
    std::unordered_map<std::string, std::vector<uint8_t>> configuration_data;

};

// The following size has been determined using a compiler in a Firmware environment. 
static_assert(sizeof(FirmwareInitData) == 144, "Unexpected FirmwareInitData size!");

/// This interface represents lifecycle actions; initialization, execution, reset. 
class FirmwareSimulationLifeCycle
{
public:
    /// default dtor
    virtual ~FirmwareSimulationLifeCycle() = default;

    /// Provide information necessary to run the firmware application that isn't known at compile
    /// time. Passed init_data will be latched on the first call & subsequent calls will be ignored,
    /// returning false. 
    /// @param init_data[in] information not known at compile time, such as Node ID. 
    /// @return true if the data is accepted, false otherwise. 
    virtual bool Init(const FirmwareInitData & init_data) = 0;
    
    /// Step the firmware application and schedule the next execution. Once it has set interval_ns to a value
    /// (typically in the range 1e6 to 1e9), it expects to be called again when that much simulated
    /// time has passed. 
    /// @param interval_ns the time interval in nano-seconds the firmware project expects to be called next at
    /// @return Returns false if there has been an exception/adn_abort in the application. True otherwise. 
    /// If false is returned, this method will not execute firmware code on subsequent calls and will continue
    /// to return false until `Reset` is called, or the instance of firmware code is destroyed and recreated. 
    virtual bool ExecuteAndScheduleNextExecutionInNs(uint64_t & interval_ns) = 0;

    /// If ExecuteAndScheduleNextExecutionInNs returns false, this method can be be used to query the
    /// problem. The format of text is not set in this contract, but it should be useful to identify the 
    /// cause of the failure. 
    /// @return a string giving details about the issue which occurred. It should return "" if no issue
    /// has yet occurred. 
    virtual std::string GetErrorString() = 0;
    
    /// A mechanism to 'power cycle' the firmware, used as part of the Configuration process 
    /// for some firmware projects. When this method returns, the firmware should be in a state
    /// as if it had just been instantiated and Init(..) called, but with EEPROM/flash data from
    /// before unchanged; this allows applications which require a power-cycle to load new config
    /// data to be sequenced correctly and transparently to FullSim.
    virtual void Reset() = 0; 
};