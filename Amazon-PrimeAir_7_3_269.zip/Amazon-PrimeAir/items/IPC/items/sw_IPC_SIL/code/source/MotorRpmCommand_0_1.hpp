//
// This is an AUTO-GENERATED Cyphal DSDL data type implementation. Curious? See https://opencyphal.org.
// You shouldn't attempt to edit this file.
//
// Checking this file under version control is not recommended since metadata in this header will change for each
// build invocation. TODO: add --reproducible option to prevent any volatile metadata from being generated.
//
// Generator:     nunavut-2.3.2.dev0 (serialization was enabled)
// Source file:   /local/p4clients/pkgbuild-WF0WN/workspace/src/AdnVehicleControlSystemMessages/cyphal_dsdl/vsdk/message/adn/vehicle/controlsystem/MotorRpmCommand.0.1.dsdl
// Generated at:  2024-03-15 20:26:54.161308 UTC
// Is deprecated: no
// Fixed port-ID: None
// Full name:     vsdk.message.adn.vehicle.controlsystem.MotorRpmCommand
// Type Version:  0.1
// Support
//    Support Namespace: nunavut.lang.cpp.support
//    Support Version:   (1, 0, 0)
// Template Set (package)
//    priority: 0
//    package:  nunavut.lang.cpp.templates
//    version:  (1, 0, 0)
// Platform
//     python_implementation:  CPython
//     python_version:  3.8.18
//     python_release_level:  final
//     python_build:  ('default', 'Mar 11 2024 06:41:50')
//     python_compiler:  GCC 7.5.0
//     python_revision:  
//     python_xoptions:  {}
//     runtime_platform:  Linux-5.4.266-187.365.amzn2int.x86_64-x86_64-with
// Language Options
//     target_endianness:  little
//     omit_float_serialization_support:  False
//     enable_serialization_asserts:  False
//     enable_override_variable_array_capacity:  False
//     std:  c++14
//     cast_format:  static_cast<{type}>({value})
//     variable_array_type_include:  "vsdk/core/util/FrameworkVector.h"
//     variable_array_type_template:  vsdk::core::util::FrameworkVector<{TYPE}, {REBIND_ALLOCATOR}>
//     variable_array_type_constructor_args:  vsdk::core::util::max_size_max_constructor_tag{{}}, {MAX_SIZE}
//     allocator_include:  "vsdk/core/util/FrameworkAllocator.h"
//     allocator_type:  vsdk::core::util::FrameworkAllocator
//     allocator_is_default_constructible:  True
//     ctor_convention:  uses-trailing-allocator
// Uses Language Features
//     Uses std_variant:no
#ifndef VSDK_MESSAGE_ADN_VEHICLE_CONTROLSYSTEM_MOTOR_RPM_COMMAND_0_1_HPP_INCLUDED
#define VSDK_MESSAGE_ADN_VEHICLE_CONTROLSYSTEM_MOTOR_RPM_COMMAND_0_1_HPP_INCLUDED

#include "nunavut/support/serialization.hpp"
#include "vsdk/core/util/FrameworkAllocator.h"
#include "vsdk/message/adn/vehicle/controlsystem/MotorStateRequest_0_1.hpp"
#include <array>
#include <cstdint>
#include <limits>

namespace vsdk
{
namespace message
{
namespace adn
{
namespace vehicle
{
namespace controlsystem
{
// +-------------------------------------------------------------------------------------------------------------------+
// | LANGUAGE OPTION ASSERTIONS
// |    These static assertions ensure that the header is being used with
// | Nunavut C++ serialization support that is compatible with the language
// | options in effect when that support code was generated.
// +-------------------------------------------------------------------------------------------------------------------+
static_assert( nunavut::support::options::target_endianness == 434322821,
              "/local/p4clients/pkgbuild-WF0WN/workspace/src/AdnVehicleControlSystemMessages/cyphal_dsdl/vsdk/message/adn/vehicle/controlsystem/MotorRpmCommand.0.1.dsdl "
              "is trying to use a serialization library that was compiled with "
              "different language options. This is dangerous and therefore not "
              "allowed." );
static_assert( nunavut::support::options::omit_float_serialization_support == 0,
              "/local/p4clients/pkgbuild-WF0WN/workspace/src/AdnVehicleControlSystemMessages/cyphal_dsdl/vsdk/message/adn/vehicle/controlsystem/MotorRpmCommand.0.1.dsdl "
              "is trying to use a serialization library that was compiled with "
              "different language options. This is dangerous and therefore not "
              "allowed." );
static_assert( nunavut::support::options::enable_serialization_asserts == 0,
              "/local/p4clients/pkgbuild-WF0WN/workspace/src/AdnVehicleControlSystemMessages/cyphal_dsdl/vsdk/message/adn/vehicle/controlsystem/MotorRpmCommand.0.1.dsdl "
              "is trying to use a serialization library that was compiled with "
              "different language options. This is dangerous and therefore not "
              "allowed." );
static_assert( nunavut::support::options::enable_override_variable_array_capacity == 0,
              "/local/p4clients/pkgbuild-WF0WN/workspace/src/AdnVehicleControlSystemMessages/cyphal_dsdl/vsdk/message/adn/vehicle/controlsystem/MotorRpmCommand.0.1.dsdl "
              "is trying to use a serialization library that was compiled with "
              "different language options. This is dangerous and therefore not "
              "allowed." );
static_assert( nunavut::support::options::std == 3161622713,
              "/local/p4clients/pkgbuild-WF0WN/workspace/src/AdnVehicleControlSystemMessages/cyphal_dsdl/vsdk/message/adn/vehicle/controlsystem/MotorRpmCommand.0.1.dsdl "
              "is trying to use a serialization library that was compiled with "
              "different language options. This is dangerous and therefore not "
              "allowed." );
static_assert( nunavut::support::options::cast_format == 1407868567,
              "/local/p4clients/pkgbuild-WF0WN/workspace/src/AdnVehicleControlSystemMessages/cyphal_dsdl/vsdk/message/adn/vehicle/controlsystem/MotorRpmCommand.0.1.dsdl "
              "is trying to use a serialization library that was compiled with "
              "different language options. This is dangerous and therefore not "
              "allowed." );
static_assert( nunavut::support::options::variable_array_type_include == 2812197107,
              "/local/p4clients/pkgbuild-WF0WN/workspace/src/AdnVehicleControlSystemMessages/cyphal_dsdl/vsdk/message/adn/vehicle/controlsystem/MotorRpmCommand.0.1.dsdl "
              "is trying to use a serialization library that was compiled with "
              "different language options. This is dangerous and therefore not "
              "allowed." );
static_assert( nunavut::support::options::variable_array_type_template == 1772747277,
              "/local/p4clients/pkgbuild-WF0WN/workspace/src/AdnVehicleControlSystemMessages/cyphal_dsdl/vsdk/message/adn/vehicle/controlsystem/MotorRpmCommand.0.1.dsdl "
              "is trying to use a serialization library that was compiled with "
              "different language options. This is dangerous and therefore not "
              "allowed." );
static_assert( nunavut::support::options::variable_array_type_constructor_args == 2027088755,
              "/local/p4clients/pkgbuild-WF0WN/workspace/src/AdnVehicleControlSystemMessages/cyphal_dsdl/vsdk/message/adn/vehicle/controlsystem/MotorRpmCommand.0.1.dsdl "
              "is trying to use a serialization library that was compiled with "
              "different language options. This is dangerous and therefore not "
              "allowed." );
static_assert( nunavut::support::options::allocator_include == 806196102,
              "/local/p4clients/pkgbuild-WF0WN/workspace/src/AdnVehicleControlSystemMessages/cyphal_dsdl/vsdk/message/adn/vehicle/controlsystem/MotorRpmCommand.0.1.dsdl "
              "is trying to use a serialization library that was compiled with "
              "different language options. This is dangerous and therefore not "
              "allowed." );
static_assert( nunavut::support::options::allocator_type == 3240006296,
              "/local/p4clients/pkgbuild-WF0WN/workspace/src/AdnVehicleControlSystemMessages/cyphal_dsdl/vsdk/message/adn/vehicle/controlsystem/MotorRpmCommand.0.1.dsdl "
              "is trying to use a serialization library that was compiled with "
              "different language options. This is dangerous and therefore not "
              "allowed." );
static_assert( nunavut::support::options::allocator_is_default_constructible == 1,
              "/local/p4clients/pkgbuild-WF0WN/workspace/src/AdnVehicleControlSystemMessages/cyphal_dsdl/vsdk/message/adn/vehicle/controlsystem/MotorRpmCommand.0.1.dsdl "
              "is trying to use a serialization library that was compiled with "
              "different language options. This is dangerous and therefore not "
              "allowed." );
static_assert( nunavut::support::options::ctor_convention == 1970806058,
              "/local/p4clients/pkgbuild-WF0WN/workspace/src/AdnVehicleControlSystemMessages/cyphal_dsdl/vsdk/message/adn/vehicle/controlsystem/MotorRpmCommand.0.1.dsdl "
              "is trying to use a serialization library that was compiled with "
              "different language options. This is dangerous and therefore not "
              "allowed." );


// +-------------------------------------------------------------------------------------------------------------------+
// | This implementation uses a minimal variant implementation that is forward-compatible with the same types generated
// | using the C++17 variant type in the standard library. This minimal variant implementation is limited in the
// | following ways:
// |    1. Supports only emplace and get_if.
// |    2. Only support access by index (see the IndexOf property of the VariantType).
// |    3. This object cannot be copy-constructed nor move-constructed.
// |    4. There is an O(n) lookup in this object's destructor and in the
// |       emplace method.
// |
// | The C++17 version of this object will define the same emplace and get_if wrappers so code written against this
// | version will be fully-forward compatible, but the C++17 version exposes the variant type directly allowing full
// | use of that standard library feature – it is therefore not backwards-compatible.
// +-------------------------------------------------------------------------------------------------------------------+
///
/// Copyright 2023 Amazon.com, Inc. or its affiliates. All Rights Reserved.
/// 
/// Command a series of Amazon motors using RPM as the reference
///
struct MotorRpmCommand_0_1 final
{
    using allocator_type = vsdk::core::util::FrameworkAllocator<void>;

    struct _traits_  // The name is surrounded with underscores to avoid collisions with DSDL attributes.
    {
        _traits_() = delete;
        /// This type does not have a fixed port-ID. See https://forum.opencyphal.org/t/choosing-message-and-service-ids/889
        static constexpr bool HasFixedPortID = false;

        static constexpr bool IsServiceType = false;

        /// Extent is the minimum amount of memory required to hold any serialized representation of any compatible
        /// version of the data type; or, on other words, it is the the maximum possible size of received objects of this type.
        /// The size is specified in bytes (rather than bits) because by definition, extent is an integer number of bytes long.
        /// When allocating a deserialization (RX) buffer for this data type, it should be at least extent bytes large.
        /// When allocating a serialization (TX) buffer, it is safe to use the size of the largest serialized representation
        /// instead of the extent because it provides a tighter bound of the object size; it is safe because the concrete type
        /// is always known during serialization (unlike deserialization). If not sure, use extent everywhere.
        static constexpr std::size_t ExtentBytes                  = 13UL;
        static constexpr std::size_t SerializationBufferSizeBytes = 13UL;
        static_assert(ExtentBytes >= SerializationBufferSizeBytes, "Internal constraint violation");
        static_assert(ExtentBytes < (std::numeric_limits<std::size_t>::max() / 8U), "This message is too large to be handled by the selected types");
        struct TypeOf
        {
            TypeOf() = delete;
            using rpm_commands = std::array<std::int16_t,6>;
            using motor_state_request = vsdk::message::adn::vehicle::controlsystem::MotorStateRequest_0_1;
        };
    };

    // Default constructor
    MotorRpmCommand_0_1() :
        rpm_commands{},
        motor_state_request{}
    {
    }

    // Allocator constructor
    explicit MotorRpmCommand_0_1(const allocator_type& allocator) :
        rpm_commands{},
        motor_state_request{allocator}
    {
        (void)allocator; // avoid unused param warning
    }
    
    // Initializing constructor
    MotorRpmCommand_0_1(
        const _traits_::TypeOf::rpm_commands& rpm_commands,
        const _traits_::TypeOf::motor_state_request& motor_state_request,
        const allocator_type& allocator = allocator_type()) :
        rpm_commands{rpm_commands},
        motor_state_request{motor_state_request, allocator}
    {
        (void)allocator; // avoid unused param warning
    }

    // Copy constructor
    MotorRpmCommand_0_1(const MotorRpmCommand_0_1&) = default;

    // Copy constructor with allocator
    MotorRpmCommand_0_1(const MotorRpmCommand_0_1& rhs, const allocator_type& allocator) :
        rpm_commands{rhs.rpm_commands},
        motor_state_request{rhs.motor_state_request, allocator}
    
    {
        (void)rhs;       // avoid unused param warning
        (void)allocator; // avoid unused param warning
    }

    // Move constructor
    MotorRpmCommand_0_1(MotorRpmCommand_0_1&&) = default;

    // Move constructor with allocator
    MotorRpmCommand_0_1(MotorRpmCommand_0_1&& rhs, const allocator_type& allocator) :
        rpm_commands{std::move(rhs.rpm_commands)},
        motor_state_request{std::move(rhs.motor_state_request), allocator}
    {
        (void)rhs;       // avoid unused param warning
        (void)allocator; // avoid unused param warning
    }

    // Copy assignment
    MotorRpmCommand_0_1& operator=(const MotorRpmCommand_0_1&) = default;

    // Move assignment
    MotorRpmCommand_0_1& operator=(MotorRpmCommand_0_1&&) = default;

    // Destructor
    ~MotorRpmCommand_0_1() = default;
    
    // +---------------------------------------------------------------------------------------------------------------+
    // | CONSTANTS
    // +---------------------------------------------------------------------------------------------------------------+
    ///
    /// The index of the rear-right motor in the RPM-command array.
    ///
    static constexpr std::uint8_t kMotorRearRightIndex = 0U;
    ///
    /// The index of the center-right motor in the RPM-command array.
    ///
    static constexpr std::uint8_t kMotorCenterRightIndex = 1U;
    ///
    /// The index of the front-right motor in the RPM-command array.
    ///
    static constexpr std::uint8_t kMotorFrontRightIndex = 2U;
    ///
    /// The index of the front-left motor in the RPM-command array.
    ///
    static constexpr std::uint8_t kMotorFrontLeftIndex = 3U;
    ///
    /// The index of the center-left motor in the RPM-command array.
    ///
    static constexpr std::uint8_t kMotorCenterLeftIndex = 4U;
    ///
    /// The index of the rear-left motor in the RPM-command array.
    ///
    static constexpr std::uint8_t kMotorRearLeftIndex = 5U;
    ///
    /// The number of motors on the aircraft.
    ///
    static constexpr std::uint8_t kNumMotors = 6U;
    
    // +----------------------------------------------------------------------+
    // | FIELDS
    // +----------------------------------------------------------------------+
    ///
    /// Array of RPM reference value commands for all motors on a vehicle.
    ///
    _traits_::TypeOf::rpm_commands rpm_commands;
    ///
    /// The requested motor state.
    ///
    _traits_::TypeOf::motor_state_request motor_state_request;
};


inline nunavut::support::SerializeResult serialize(const MotorRpmCommand_0_1& obj,
                                                   nunavut::support::bitspan out_buffer)
{
    const std::size_t capacity_bits = out_buffer.size();
    if ((static_cast<std::size_t>(capacity_bits)) < 104UL)
    {
        return -nunavut::support::Error::SerializationBufferTooSmall;
    }
    // Notice that fields that are not an integer number of bytes long may overrun the space allocated for them
    // in the serialization buffer up to the next byte boundary. This is by design and is guaranteed to be safe.
    {   // saturated int14[6] rpm_commands
        const std::size_t _origin0_ = out_buffer.offset();
        for (std::size_t _index1_ = 0U; _index1_ < 6UL; ++_index1_)
        {
            std::int16_t _sat0_ = obj.rpm_commands[_index1_];
            if (_sat0_ < -8192)
            {
                _sat0_ = -8192;
            }
            if (_sat0_ > 8191)
            {
                _sat0_ = 8191;
            }
            const auto _result3_ = out_buffer.setIxx(_sat0_, 14U);
            if(not _result3_){
                return -_result3_.error();
            }
            out_buffer.add_offset(14U);
        }
        // It is assumed that we know the exact type of the serialized entity, hence we expect the size to match.
        (void) _origin0_;
    }
    {
        const auto _result0_ = out_buffer.padAndMoveToAlignment(8U);
        if(not _result0_){
            return -_result0_.error();
        }
    }
    {   // vsdk.message.adn.vehicle.controlsystem.MotorStateRequest.0.1 motor_state_request
        std::size_t _size_bytes0_ = 2UL;  // Nested object (max) size, in bytes.
        auto _subspan0_ = out_buffer.subspan(0U, _size_bytes0_ * 8U);
        if(not _subspan0_){
            return -_subspan0_.error();
        }
        auto _err0_ = serialize(obj.motor_state_request, _subspan0_.value());
        if (not _err0_)
        {
            return _err0_;
        }
        _size_bytes0_ = _err0_.value();
        // It is assumed that we know the exact type of the serialized entity, hence we expect the size to match.
        out_buffer.add_offset(_size_bytes0_ * 8U);
        //
    }
    {
        const auto _result0_ = out_buffer.padAndMoveToAlignment(8U);
        if(not _result0_){
            return -_result0_.error();
        }
    }
    // It is assumed that we know the exact type of the serialized entity, hence we expect the size to match.
    return out_buffer.offset_bytes_ceil();
}

inline nunavut::support::SerializeResult deserialize(MotorRpmCommand_0_1& obj,
                                                     nunavut::support::const_bitspan in_buffer)
{
    const auto capacity_bits = in_buffer.size();
    // saturated int14[6] rpm_commands
    for (std::size_t _index4_ = 0U; _index4_ < 6UL; ++_index4_)
    {
        obj.rpm_commands[_index4_] = in_buffer.getI16(14U);
        in_buffer.add_offset(14U);
    }
    in_buffer.align_offset_to<8U>();
    // vsdk.message.adn.vehicle.controlsystem.MotorStateRequest.0.1 motor_state_request
    {
        std::size_t _size_bytes1_ = in_buffer.size() / 8U;
        {
            const auto _err1_ = deserialize(obj.motor_state_request, in_buffer.subspan());
            if(_err1_){
                _size_bytes1_ = _err1_.value();
            }else{
                return -_err1_.error();
            }
        }
        in_buffer.add_offset(_size_bytes1_ * 8U);  // Advance by the size of the nested serialized representation.
    }
    in_buffer.align_offset_to<8U>();
    auto _bits_got_ = std::min<std::size_t>(in_buffer.offset(), capacity_bits);
    return { static_cast<std::size_t>(_bits_got_ / 8U) };
}

} // namespace controlsystem
} // namespace vehicle
} // namespace adn
} // namespace message
} // namespace vsdk

#endif // VSDK_MESSAGE_ADN_VEHICLE_CONTROLSYSTEM_MOTOR_RPM_COMMAND_0_1_HPP_INCLUDED
