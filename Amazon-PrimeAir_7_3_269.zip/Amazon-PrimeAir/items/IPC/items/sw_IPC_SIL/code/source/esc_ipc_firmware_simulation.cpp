#include <FirmwareSimulation.h>
#include <FirmwareSimulationDataExchange.h>
#include <FirmwareSimulationLifeCycle.h>
#include <MotorPerformance_0_1.h>
#include <GroundTruthState_0_1.h>
#include <GroundTruthRpm_0_1.h>
#include <Esc_sil_block.h>
#include <Mc_freqs.h>
#include <Ttime.h>
#include <Kclk.h>
#include <CANhelper.h>
#include <CANframe.h>
#include <Cyphal.h>
#include <Ipc_ids.h>
#include <Default_cfg.h>
#include <interface.h>
#include <fstream>
#include <iomanip>
#include "serialization.hpp"
#include <Bitutils.h>
#include <cstdlib>

bool veronte_reset_request = false;

static const Uint32 gt_rpm_id = 0x1061CFFFUL;  /// Ground truth rpm ID message
static const size_t sz_motor_sim = 704;
static const Uint16 sot = 7;
static const Uint16 eot = 6;
static const Uint16 toggle = 5;
static const Uint16 tailbyte0 = Base::Bitutils::get_mask_1bit<Uint16>(sot) |
        Base::Bitutils::get_mask_1bit<Uint16>(eot)|Base::Bitutils::get_mask_1bit<Uint16>(toggle);

void change_tail_byte(uint8_t& tb)
{

    ++tb;
    if(tb==0)
    {
        tb = tailbyte0;
    }
}

namespace Esc_so
{
    namespace
    {
        bool is_spin_direction_positive( uint16_t node_id )
        {
            using namespace MCxx;
            bool is_positive = false;
            const Uint16 esc_id = node_id - Ipc_ids::node_id_rr_a;
            switch (esc_id)
            {
                // spin direction is positive.
                case Ipc_ids::kLeftRear:
                case Ipc_ids::kRightFront:
                case Ipc_ids::kLeftCenter:
                {
                    is_positive = true;
                    break;
                }
                // spin direction is 'negative'
                case Ipc_ids::kRightCenter:
                case Ipc_ids::kLeftFront:
                case Ipc_ids::kRightRear:
                {
                    is_positive = false;
                    break;
                }
                default:
                {
                    Bsp::warning();
                    // we should not be able to get here because we report a fail in init() if bad node id.
                    break;
                }
            }
            return is_positive;
        }

        void PrintHeader( const amzn::esc::sim::Interface::State &, std::ostream & out )
        {

            out << "state.measured.motor_abc_A.a, ";
            out << "state.measured.motor_abc_A.b, ";
            out << "state.measured.motor_abc_A.c, ";
            out << "state.measured.dc_link_A, ";
            out << "state.measured.dc_link_V, ";
            out << "state.hidden.motor_elec_omega_rad_per_s, ";
            out << "state.iteration" << std::endl;
        }

        void Print( const amzn::esc::sim::Interface::State & state, std::ostream & out )
        {
            out << std::fixed << std::setprecision( 3 );
            out << state.measured.motor_abc_A.a << ", ";
            out << state.measured.motor_abc_A.b << ", ";
            out << state.measured.motor_abc_A.c << ", ";
            out << state.measured.dc_link_A << ", ";
            out << state.measured.dc_link_V << ", ";
            out << state.hidden.motor_elec_omega_rad_per_s << ", ";
            out << state.iteration << std::endl;
        }

        void read_gt_rpm_message(Base::CANframe& data_msg,
                vsdk_message_adn_simulation_propulsionsystem_GroundTruthRpm_0_1 gtr_msg)
        {
            Base::Data_mutator<Base::Lossy::Mutator_traits8<>, Base::CANdata::CANdata_type::Data_traits8> m(data_msg.data.data);
            data_msg.id.extended = true;
            data_msg.id.id = gt_rpm_id;
            data_msg.data.data.resize(vsdk_message_adn_simulation_propulsionsystem_GroundTruthRpm_0_1_EXTENT_BYTES_);
            Base::Lossy& str(m.m);
            for(Uint8 i = 0; i < 8U; ++i)
            {
                str.put_uint8(gtr_msg.id.id[i]);
            }
            str.put_int16(static_cast<int16>(gtr_msg.ground_truth_rpm));          // In RPM
            str.put_int16(static_cast<int16>(gtr_msg.ground_truth_theta_e_deg));  // In deg
            Dsp28335_ent::CANhelper::get_canhelper(Base::canpid_fda).write(data_msg);
        }

    }

    class Esc_sim : public FirmwareSimulation
    {

    public:
        /// Default constructor
        Esc_sim();

        Esc_sil_block block;                  ///< Firmware ESC simulation block
        Real64 t;                             ///< Total simulated time (s)
        FirmwareInitData init_data_;          ///< Initial data (node)
        char buffer[sz_motor_sim];            ///< Buffer to create motor
        amzn::esc::sim::Interface* motor_sim; ///< Motor simulation
        Esc_input in;                         ///< ESC inputs
        Esc_output out;                       ///< ESC outputs
        uint64_t gt_rpm_timer;                ///< Ground Truth RPM timer
        uint8_t tb_rpm_a;                     ///< Tailbyte of RPM message
        uint8_t tb_rpm_b;                     ///< Tailbyte of RPM message

        std::ofstream state_file;             ///< Log file for motor simulation
        std::ofstream state_file_internal;    ///< Log file for internal variables

        bool ExecuteAndScheduleNextExecutionInNs(uint64_t & interval_ns) override
        {
            amzn::esc::sim::Interface::Command& command = motor_sim->UpdateCommand();
            const amzn::esc::sim::Interface::State& state = motor_sim->AccessState();

            // Output the GT Rpm if it's been 2ms
            if ( gt_rpm_timer == 0 )
            {
                vsdk_message_adn_simulation_propulsionsystem_GroundTruthRpm_0_1 gtr_msg{};
                // grab the proper data for the ground truth rpm
                const Real motor_mech_omega_rad_per_s
                    = state.hidden.motor_mech_omega_rad_per_s;
                const Real motor_speed_rpm
                    = motor_mech_omega_rad_per_s * ( 60.0F / 1.0F ) * ( 1.0F / 6.28318F );

                // make sure the sign is right.
                if ( is_spin_direction_positive(init_data_.node_id))
                {
                    gtr_msg.ground_truth_rpm = motor_speed_rpm;
                }
                else
                {
                    gtr_msg.ground_truth_rpm = motor_speed_rpm * -1;
                }

                // grab the proper data for the ground truth orientation

                // This value will be [-180deg...179deg].
                const auto motor_orientation_e_deg = static_cast<int16_t>(
                    state.hidden.motor_elec_theta_pirad
                    * ( 180.0F / 3.14159F ) );
                if ( motor_orientation_e_deg < 0 )
                {
                    // Shift to make it [0deg...359deg]
                    gtr_msg.ground_truth_theta_e_deg
                        = static_cast<uint16_t>( motor_orientation_e_deg + 360 );
                }
                else
                {
                    gtr_msg.ground_truth_theta_e_deg = static_cast<uint16_t>( motor_orientation_e_deg );
                }

                // Put into the firmware
                Base::CANframe data_msg;
                read_gt_rpm_message(data_msg, gtr_msg);
            }

            bool retval = true;
            uint64_t kSimulationTimeStepNs =  1000000ULL;
            interval_ns = kSimulationTimeStepNs;
            // End mainloop code
            const uint64_t adc_freq_hz    = static_cast<uint64_t>(MCxx::Mc_freqs::def_ctrl_rt_freq);
            const uint64_t adc_period_ns  = 1e9 / adc_freq_hz;
            const uint64_t isr_executions = interval_ns / adc_period_ns;
            // we don't want a remainder because we'd lose time
            assert( ( interval_ns % adc_period_ns ) == 0 );

            // Set inputs to the ESC to run it
            Real ac_currents_amps[3U] = {0.0F, 0.0F, 0.0F};
            Real dc_current_amp = 0.0F;
            Real vdv_v = 50.0F;

            static const Real r_shunt_ipc_ac = 6.48E-3F;   // IPC shunt resistance for AC currents (Ohm)
            static const Real r_shunt_ipc_dc = 6E-3F;      // Shunt resistance for Idc_inv (Ohm)
            static const Real v_bias_adc = 1.65F;          // Bias for ADC (V)
            static const Real v_max_adc = 3.3F;            // Max value for ADC (V)
            for ( size_t i = 0; i < isr_executions; ++i )
            {
                // Get the motor feedback
                ac_currents_amps[0U] = state.measured.motor_abc_A.a;
                ac_currents_amps[1U] = state.measured.motor_abc_A.b;
                ac_currents_amps[2U] = state.measured.motor_abc_A.c;
                dc_current_amp = state.measured.dc_link_A;
                Maverick::Sincos sc_pos(state.hidden.motor_mech_theta_pirad);
                sc_pos.c += v_bias_adc;
                sc_pos.s += v_bias_adc;

                // Update motor currents to ESC simulation
                in.ac_currents_adc[0U] = ac_currents_amps[0U] * r_shunt_ipc_ac + v_bias_adc;
                in.ac_currents_adc[1U] = ac_currents_amps[1U] * r_shunt_ipc_ac + v_bias_adc;
                in.ac_currents_adc[2U] = ac_currents_amps[2U] * r_shunt_ipc_ac + v_bias_adc;
                in.idc_adc =  dc_current_amp * r_shunt_ipc_dc + v_bias_adc;
                in.vdc_adc = vdv_v * v_max_adc / MCxx::Ipc_ids::max_vdc_ipc;
                in.vmon_adc = vdv_v * v_max_adc / MCxx::Ipc_ids::max_vdc_mon;
                in.motor_temp_adc = 0.306F; // Voltage corresponding to 25ºC
                in.sincos_sensor1_adc = sc_pos;
                in.sincos_sensor2_adc = sc_pos;

                // Execute ESC simulation
                t = block.step(t, in, out);


                // Run motor model
                // Update motor voltages
                command.electrical.motor_abc_V.a = out.pwm_output[0];
                command.electrical.motor_abc_V.b = out.pwm_output[1];
                command.electrical.motor_abc_V.c = out.pwm_output[2];
                command.electrical.supply_V = vdv_v;
                motor_sim->Step();


                // Print motor state
                //Print(motor_sim->AccessState(), state_file);

                // Get the internal state
                amzn::esc::sim::Interface::State internal_state;
                internal_state.measured.motor_abc_A.a = block.get_control().iph.get_iph_u();
                internal_state.measured.motor_abc_A.b = block.get_control().iph.get_iph_v();
                internal_state.measured.motor_abc_A.c = block.get_control().iph.get_iph_w();
                internal_state.measured.dc_link_A = block.get_control().vdc;
                internal_state.measured.dc_link_V = block.get_control().idc;
                internal_state.hidden.motor_elec_omega_rad_per_s = block.get_control().omegae;
                // Print internal state
                //Print( internal_state, state_file_internal );

            }

            // increment the counter
            gt_rpm_timer += interval_ns;
            if(gt_rpm_timer >= 2000000)
            {
                gt_rpm_timer = 0;
            }

            return retval;
        }


        bool Init(const FirmwareInitData & init_data) override
        {
            bool ret = true;
            if (( init_data.node_id < 10) || (init_data.node_id > 15))
            {
                ret = false;
            }
            if(ret)
            {
                init_data_ = init_data;
                block.init(init_data_.node_id);
            }
            return ret;
        }

        void Reset() override
        {
            /// Do nothing
        }

        std::string GetErrorString() override
        {
            std::string error = "";
            return error;
        }

        bool PutMessage(const MessageData& msg) override
        {

            if ( msg.port_id  == 998 )
            {
                vsdk_message_adn_simulation_GroundTruthState_0_1 gts_msg {};
                size_t gts_serialized_size = vsdk_message_adn_simulation_GroundTruthState_0_1_EXTENT_BYTES_;
                if (vsdk_message_adn_simulation_GroundTruthState_0_1_deserialize_(&gts_msg, msg.serialized_payload.data(), &gts_serialized_size) != 0) {
                    return false;
                }

                Real tq_Nm = 0.0F;
                // TODO FCLIB-13442 Add motor Moment of Inertia to GroundTruthState
                Real moi_kg_m2 = 0.0F;
                static const Real unit_N_m = 1.0F;
                static const Real unit_kg_m2 = 1.0F;
                // Torque is expressed by state manager as negative if a deceleration force on the
                // shaft, with no consideration of spin direction The motor model expects positive
                // torque to be an acceleration force in the 'positive' direction and negative
                // torque to be an acceleration force in the 'negative' direction.
                const int16_t spin_direction_tq_sign
                    = ( is_spin_direction_positive( init_data_.node_id ) ? -1 : 1 );

                switch ( init_data_.node_id )
                {
                    case 10:
                    {
                        // kRightRear
                        tq_Nm = spin_direction_tq_sign * gts_msg.motor_rear_right_prop_torque_Nm
                            * unit_N_m;
                        moi_kg_m2 = 3.0e-03 * unit_kg_m2;
                        break;
                    }
                    case 11:
                    {
                        // kRightCenter
                        tq_Nm = spin_direction_tq_sign * gts_msg.motor_center_right_prop_torque_Nm
                            * unit_N_m;
                        moi_kg_m2 = 2.8e-03 * unit_kg_m2;
                        break;
                    }
                    case 12:
                    {
                        // kRightFront
                        tq_Nm = spin_direction_tq_sign * gts_msg.motor_front_right_prop_torque_Nm
                            * unit_N_m;
                        moi_kg_m2 = 2.5e-03 * unit_kg_m2;
                        break;
                    }
                    case 13:
                    {
                        // kLeftFront
                        tq_Nm = spin_direction_tq_sign * gts_msg.motor_front_left_prop_torque_Nm
                            * unit_N_m;
                        moi_kg_m2 = 2.5e-03 * unit_kg_m2;
                        break;
                    }
                    case 14:
                    {
                        // kLeftCenter
                        tq_Nm = spin_direction_tq_sign * gts_msg.motor_center_left_prop_torque_Nm
                            * unit_N_m;
                        moi_kg_m2 = 2.8e-03 * unit_kg_m2;
                        break;
                    }
                    case 15:
                    {
                        // kLeftRear
                        tq_Nm = spin_direction_tq_sign * gts_msg.motor_rear_left_prop_torque_Nm
                            * unit_N_m;
                        moi_kg_m2 = 3.0e-03 * unit_kg_m2;
                        break;
                    }
                    default:
                    {
                        // do nothing - enum already set to unknown.
                        break;
                    }
                }

                // probably want to edge detect this but for now, if we receive any GTS, we
                // say all load is external from now on.
                auto & esc_command             = motor_sim->UpdateCommand();
                esc_command.mechanical.k0_N_m  = tq_Nm;
                esc_command.mechanical.J_kg_m2 = moi_kg_m2;
                auto v_free                    = std::sqrt(
                    std::pow( gts_msg.motor_rear_right_v_axial_m_per_s, 2 )
                    + std::pow( gts_msg.motor_rear_right_v_radial_m_per_s, 2 ) );
                auto dynamic_pressure_Pa = 0.5 * gts_msg.air_density_kg_per_m3 * v_free * v_free;
                // TODO Figure out where these magic numbers should come from. Right now they are
                // based on the late EmulatedScottyEsc's implementation
                Real h = static_cast<float>(
                    ( 0.005076 * dynamic_pressure_Pa ) + 2.3 );
                Real air_temperature_degK  = static_cast<float>(
                    gts_msg.air_temperature_K) ;
                esc_command.thermal.motor_C_W_per_K = h;
                esc_command.thermal.ambient_degC    = air_temperature_degK;
            }

            Base::CANframe data_msg;
			data_msg.id.extended = true;

			/// Check for ID from received message.
			const bool from_primary = (msg.port_id == MCxx::Ipc_ids::sub_id_pr);

			/// On case of Recovery RPM messages, there is 6 different IDs as for compact format.
			static const Uint16 max_rec = MCxx::Ipc_ids::sub_id_re +  MCxx::Ipc_ids::num_esc - Ku16::u1;
			typedef Base::Range<Uint16, MCxx::Ipc_ids::sub_id_re, max_rec> Range_recovery;

			/// If from primary or recovery:
			if(from_primary || Range_recovery::in_range(msg.port_id))
			{
				/// Serialize data.
				data_msg.data.data.resize(msg.payload_size_bytes+1);
				for(Uint8 i = 0; i < msg.payload_size_bytes; ++i)
				{
					const Uint8 data = msg.serialized_payload[i];
					data_msg.data.set(i, data);
				}

				/// Fix message ID to send.
				Dsp28335_ent::CANhelper* can_hdl = 0;
				Uint8* tb = 0;
				if(from_primary)
				{
					data_msg.id.id = (MCxx::Ipc_ids::sub_id_pr << Ku16::u8) | MCxx::Ipc_ids::node_id_pr | (0x106 << Ku16::u20);
					can_hdl = &Dsp28335_ent::CANhelper::get_canhelper(Base::canpid_fda);
					tb = &tb_rpm_a;
				}
				else
				{
					const Uint32 esc_sub_id = MCxx::Ipc_ids::sub_id_re + (init_data_.node_id - MCxx::Ipc_ids::node_id_rr_a);
					data_msg.id.id = (esc_sub_id << Ku16::u8) | MCxx::Ipc_ids::node_id_re | (0x106 << Ku16::u20);
					can_hdl = &Dsp28335_ent::CANhelper::get_canhelper(Base::canpid_b);
					tb = &tb_rpm_b;
				}

				// Copy (and increment) tail-byte.
				change_tail_byte(*tb);
				data_msg.data.set(msg.payload_size_bytes, *tb);

				/// Send the message through dedicated CAN-bus.
				can_hdl->write_sil(data_msg);
			}

			return true;
        }

        bool GetMessage(MessageData& msg) override
        {
            Base::CANframe data_msg;
            Dsp28335_ent::CANhelper::get_canhelper(Base::canpid_fda).read_sil(data_msg);
            bool ret = false;
            // Motor performance check with subject ID = 421 (motor performance)
            // and message type (bit 25).
            if(!Base::has_bit_set(data_msg.id.id, 25) &&
              (data_msg.id.id >> 8 & Cyphal::Full_id::msg_id_mask) == (Base::Stanag_msg_type::cyp_motor_perf & Cyphal::Full_id::msg_id_mask))
            {
                ret = true;
                const Uint8 sz = data_msg.data.get_length();
                msg.serialized_payload.resize(sz);
                for(Uint8 i = 0; i < sz; ++i)
                {
                    msg.serialized_payload[i] = data_msg.data.get(i);
                }
                msg.port_id = 421U;
            }

            // Ground truth RPM
            if(data_msg.id.id == gt_rpm_id)
            {
                ret = true;
                const Uint8 sz = data_msg.data.get_length();
                msg.serialized_payload.resize(sz);
                for(Uint8 i = 0; i < sz; ++i)
                {
                    msg.serialized_payload[i] = data_msg.data.get(i);
                }
                msg.port_id = (990 + init_data_.node_id);
            }
            msg.is_valid = ret;
            return ret;
        }

    };

    Esc_sim::Esc_sim():
            block(),
            t(0.0F),
            buffer(),
            motor_sim(amzn_esc_sim_construct(
                      amzn::esc::sim::Interface::Configuration::kIdCX3Typhoon, buffer, sizeof( buffer ) )),
            in(),
            out(),
            state_file(),
            gt_rpm_timer(0ULL),
            tb_rpm_a(tailbyte0),
            tb_rpm_b(tailbyte0)

            {
                motor_sim->UpdateCommand().electrical.inverter_enable = true;

                // Create a file to log the results.
                //state_file.open( "state.csv" );
                //PrintHeader( motor_sim->AccessState(), state_file );
                //state_file_internal.open( "state_internal.csv" );
                //PrintHeader( motor_sim->AccessState(), state_file_internal );
            }

}

extern "C" FirmwareSimulation * get_firmware_simulation_instance( void )
{
    return new Esc_so::Esc_sim();
}

bool reset_requested()
{
    return veronte_reset_request;
}
