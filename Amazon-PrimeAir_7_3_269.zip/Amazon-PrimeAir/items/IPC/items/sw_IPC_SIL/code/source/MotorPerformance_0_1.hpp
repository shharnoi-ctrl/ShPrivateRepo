//
// This is an AUTO-GENERATED Cyphal DSDL data type implementation. Curious? See https://opencyphal.org.
// You shouldn't attempt to edit this file.
//
// Checking this file under version control is not recommended since metadata in this header will change for each
// build invocation. TODO: add --reproducible option to prevent any volatile metadata from being generated.
//
// Generator:     nunavut-2.3.2.dev0 (serialization was enabled)
// Source file:   /local/p4clients/pkgbuild-jIxa9/workspace/src/AdnVehiclePropulsionSystemMessages/cyphal_dsdl/vsdk/message/adn/vehicle/propulsionsystem/MotorPerformance.0.1.dsdl
// Generated at:  2024-03-15 12:09:53.838912 UTC
// Is deprecated: no
// Fixed port-ID: None
// Full name:     vsdk.message.adn.vehicle.propulsionsystem.MotorPerformance
// Type Version:  0.1
// Support
//    Support Namespace: nunavut.lang.cpp.support
//    Support Version:   (1, 0, 0)
// Template Set (package)
//    priority: 0
//    package:  nunavut.lang.cpp.templates
//    version:  (1, 0, 0)
// Platform
//     python_implementation:  CPython
//     python_version:  3.8.18
//     python_release_level:  final
//     python_build:  ('default', 'Mar 11 2024 06:41:50')
//     python_compiler:  GCC 7.5.0
//     python_revision:  
//     python_xoptions:  {}
//     runtime_platform:  Linux-5.4.266-187.365.amzn2int.x86_64-x86_64-with
// Language Options
//     target_endianness:  little
//     omit_float_serialization_support:  False
//     enable_serialization_asserts:  False
//     enable_override_variable_array_capacity:  False
//     std:  c++14
//     cast_format:  static_cast<{type}>({value})
//     variable_array_type_include:  "vsdk/core/util/FrameworkVector.h"
//     variable_array_type_template:  vsdk::core::util::FrameworkVector<{TYPE}, {REBIND_ALLOCATOR}>
//     variable_array_type_constructor_args:  vsdk::core::util::max_size_max_constructor_tag{{}}, {MAX_SIZE}
//     allocator_include:  "vsdk/core/util/FrameworkAllocator.h"
//     allocator_type:  vsdk::core::util::FrameworkAllocator
//     allocator_is_default_constructible:  True
//     ctor_convention:  uses-trailing-allocator
// Uses Language Features
//     Uses std_variant:no
#ifndef VSDK_MESSAGE_ADN_VEHICLE_PROPULSIONSYSTEM_MOTOR_PERFORMANCE_0_1_HPP_INCLUDED
#define VSDK_MESSAGE_ADN_VEHICLE_PROPULSIONSYSTEM_MOTOR_PERFORMANCE_0_1_HPP_INCLUDED

#include "nunavut/support/serialization.hpp"
#include "vsdk/core/util/FrameworkAllocator.h"
#include "vsdk/message/adn/vehicle/propulsionsystem/EscState_0_1.hpp"
#include <cstdint>
#include <limits>

namespace vsdk
{
namespace message
{
namespace adn
{
namespace vehicle
{
namespace propulsionsystem
{
// +-------------------------------------------------------------------------------------------------------------------+
// | LANGUAGE OPTION ASSERTIONS
// |    These static assertions ensure that the header is being used with
// | Nunavut C++ serialization support that is compatible with the language
// | options in effect when that support code was generated.
// +-------------------------------------------------------------------------------------------------------------------+
static_assert( nunavut::support::options::target_endianness == 434322821,
              "/local/p4clients/pkgbuild-jIxa9/workspace/src/AdnVehiclePropulsionSystemMessages/cyphal_dsdl/vsdk/message/adn/vehicle/propulsionsystem/MotorPerformance.0.1.dsdl "
              "is trying to use a serialization library that was compiled with "
              "different language options. This is dangerous and therefore not "
              "allowed." );
static_assert( nunavut::support::options::omit_float_serialization_support == 0,
              "/local/p4clients/pkgbuild-jIxa9/workspace/src/AdnVehiclePropulsionSystemMessages/cyphal_dsdl/vsdk/message/adn/vehicle/propulsionsystem/MotorPerformance.0.1.dsdl "
              "is trying to use a serialization library that was compiled with "
              "different language options. This is dangerous and therefore not "
              "allowed." );
static_assert( nunavut::support::options::enable_serialization_asserts == 0,
              "/local/p4clients/pkgbuild-jIxa9/workspace/src/AdnVehiclePropulsionSystemMessages/cyphal_dsdl/vsdk/message/adn/vehicle/propulsionsystem/MotorPerformance.0.1.dsdl "
              "is trying to use a serialization library that was compiled with "
              "different language options. This is dangerous and therefore not "
              "allowed." );
static_assert( nunavut::support::options::enable_override_variable_array_capacity == 0,
              "/local/p4clients/pkgbuild-jIxa9/workspace/src/AdnVehiclePropulsionSystemMessages/cyphal_dsdl/vsdk/message/adn/vehicle/propulsionsystem/MotorPerformance.0.1.dsdl "
              "is trying to use a serialization library that was compiled with "
              "different language options. This is dangerous and therefore not "
              "allowed." );
static_assert( nunavut::support::options::std == 3161622713,
              "/local/p4clients/pkgbuild-jIxa9/workspace/src/AdnVehiclePropulsionSystemMessages/cyphal_dsdl/vsdk/message/adn/vehicle/propulsionsystem/MotorPerformance.0.1.dsdl "
              "is trying to use a serialization library that was compiled with "
              "different language options. This is dangerous and therefore not "
              "allowed." );
static_assert( nunavut::support::options::cast_format == 1407868567,
              "/local/p4clients/pkgbuild-jIxa9/workspace/src/AdnVehiclePropulsionSystemMessages/cyphal_dsdl/vsdk/message/adn/vehicle/propulsionsystem/MotorPerformance.0.1.dsdl "
              "is trying to use a serialization library that was compiled with "
              "different language options. This is dangerous and therefore not "
              "allowed." );
static_assert( nunavut::support::options::variable_array_type_include == 2812197107,
              "/local/p4clients/pkgbuild-jIxa9/workspace/src/AdnVehiclePropulsionSystemMessages/cyphal_dsdl/vsdk/message/adn/vehicle/propulsionsystem/MotorPerformance.0.1.dsdl "
              "is trying to use a serialization library that was compiled with "
              "different language options. This is dangerous and therefore not "
              "allowed." );
static_assert( nunavut::support::options::variable_array_type_template == 1772747277,
              "/local/p4clients/pkgbuild-jIxa9/workspace/src/AdnVehiclePropulsionSystemMessages/cyphal_dsdl/vsdk/message/adn/vehicle/propulsionsystem/MotorPerformance.0.1.dsdl "
              "is trying to use a serialization library that was compiled with "
              "different language options. This is dangerous and therefore not "
              "allowed." );
static_assert( nunavut::support::options::variable_array_type_constructor_args == 2027088755,
              "/local/p4clients/pkgbuild-jIxa9/workspace/src/AdnVehiclePropulsionSystemMessages/cyphal_dsdl/vsdk/message/adn/vehicle/propulsionsystem/MotorPerformance.0.1.dsdl "
              "is trying to use a serialization library that was compiled with "
              "different language options. This is dangerous and therefore not "
              "allowed." );
static_assert( nunavut::support::options::allocator_include == 806196102,
              "/local/p4clients/pkgbuild-jIxa9/workspace/src/AdnVehiclePropulsionSystemMessages/cyphal_dsdl/vsdk/message/adn/vehicle/propulsionsystem/MotorPerformance.0.1.dsdl "
              "is trying to use a serialization library that was compiled with "
              "different language options. This is dangerous and therefore not "
              "allowed." );
static_assert( nunavut::support::options::allocator_type == 3240006296,
              "/local/p4clients/pkgbuild-jIxa9/workspace/src/AdnVehiclePropulsionSystemMessages/cyphal_dsdl/vsdk/message/adn/vehicle/propulsionsystem/MotorPerformance.0.1.dsdl "
              "is trying to use a serialization library that was compiled with "
              "different language options. This is dangerous and therefore not "
              "allowed." );
static_assert( nunavut::support::options::allocator_is_default_constructible == 1,
              "/local/p4clients/pkgbuild-jIxa9/workspace/src/AdnVehiclePropulsionSystemMessages/cyphal_dsdl/vsdk/message/adn/vehicle/propulsionsystem/MotorPerformance.0.1.dsdl "
              "is trying to use a serialization library that was compiled with "
              "different language options. This is dangerous and therefore not "
              "allowed." );
static_assert( nunavut::support::options::ctor_convention == 1970806058,
              "/local/p4clients/pkgbuild-jIxa9/workspace/src/AdnVehiclePropulsionSystemMessages/cyphal_dsdl/vsdk/message/adn/vehicle/propulsionsystem/MotorPerformance.0.1.dsdl "
              "is trying to use a serialization library that was compiled with "
              "different language options. This is dangerous and therefore not "
              "allowed." );


// +-------------------------------------------------------------------------------------------------------------------+
// | This implementation uses a minimal variant implementation that is forward-compatible with the same types generated
// | using the C++17 variant type in the standard library. This minimal variant implementation is limited in the
// | following ways:
// |    1. Supports only emplace and get_if.
// |    2. Only support access by index (see the IndexOf property of the VariantType).
// |    3. This object cannot be copy-constructed nor move-constructed.
// |    4. There is an O(n) lookup in this object's destructor and in the
// |       emplace method.
// |
// | The C++17 version of this object will define the same emplace and get_if wrappers so code written against this
// | version will be fully-forward compatible, but the C++17 version exposes the variant type directly allowing full
// | use of that standard library feature – it is therefore not backwards-compatible.
// +-------------------------------------------------------------------------------------------------------------------+
///
/// Copyright 2022 Amazon.com, Inc. or its affiliates. All Rights Reserved.
/// 
/// This DSDL was created using the DSDL->Cyphal conversion tool.
/// 
/// High frequency data from an Amazon motor
///
struct MotorPerformance_0_1 final
{
    using allocator_type = vsdk::core::util::FrameworkAllocator<void>;

    struct _traits_  // The name is surrounded with underscores to avoid collisions with DSDL attributes.
    {
        _traits_() = delete;
        /// This type does not have a fixed port-ID. See https://forum.opencyphal.org/t/choosing-message-and-service-ids/889
        static constexpr bool HasFixedPortID = false;

        static constexpr bool IsServiceType = false;

        /// Extent is the minimum amount of memory required to hold any serialized representation of any compatible
        /// version of the data type; or, on other words, it is the the maximum possible size of received objects of this type.
        /// The size is specified in bytes (rather than bits) because by definition, extent is an integer number of bytes long.
        /// When allocating a deserialization (RX) buffer for this data type, it should be at least extent bytes large.
        /// When allocating a serialization (TX) buffer, it is safe to use the size of the largest serialized representation
        /// instead of the extent because it provides a tighter bound of the object size; it is safe because the concrete type
        /// is always known during serialization (unlike deserialization). If not sure, use extent everywhere.
        static constexpr std::size_t ExtentBytes                  = 22UL;
        static constexpr std::size_t SerializationBufferSizeBytes = 22UL;
        static_assert(ExtentBytes >= SerializationBufferSizeBytes, "Internal constraint violation");
        static_assert(ExtentBytes < (std::numeric_limits<std::size_t>::max() / 8U), "This message is too large to be handled by the selected types");
        struct TypeOf
        {
            TypeOf() = delete;
            using can_node_id = std::uint16_t;
            using commanded_rpm = std::int16_t;
            using measured_rpm = std::int16_t;
            using input_current_cA = std::int16_t;
            using input_voltage_dV = std::uint16_t;
            using commanded_iq_mA = std::int32_t;
            using measured_iq_mA = std::int32_t;
            using is_on_external_power = bool;
            using state = vsdk::message::adn::vehicle::propulsionsystem::EscState_0_1;
        };
    };

    // Default constructor
    MotorPerformance_0_1() :
        can_node_id{},
        commanded_rpm{},
        measured_rpm{},
        input_current_cA{},
        input_voltage_dV{},
        commanded_iq_mA{},
        measured_iq_mA{},
        is_on_external_power{},
        state{}
    {
    }

    // Allocator constructor
    explicit MotorPerformance_0_1(const allocator_type& allocator) :
        can_node_id{},
        commanded_rpm{},
        measured_rpm{},
        input_current_cA{},
        input_voltage_dV{},
        commanded_iq_mA{},
        measured_iq_mA{},
        is_on_external_power{},
        state{allocator}
    {
        (void)allocator; // avoid unused param warning
    }
    
    // Initializing constructor
    MotorPerformance_0_1(
        const _traits_::TypeOf::can_node_id& can_node_id,
        const _traits_::TypeOf::commanded_rpm& commanded_rpm,
        const _traits_::TypeOf::measured_rpm& measured_rpm,
        const _traits_::TypeOf::input_current_cA& input_current_cA,
        const _traits_::TypeOf::input_voltage_dV& input_voltage_dV,
        const _traits_::TypeOf::commanded_iq_mA& commanded_iq_mA,
        const _traits_::TypeOf::measured_iq_mA& measured_iq_mA,
        const _traits_::TypeOf::is_on_external_power& is_on_external_power,
        const _traits_::TypeOf::state& state,
        const allocator_type& allocator = allocator_type()) :
        can_node_id{can_node_id},
        commanded_rpm{commanded_rpm},
        measured_rpm{measured_rpm},
        input_current_cA{input_current_cA},
        input_voltage_dV{input_voltage_dV},
        commanded_iq_mA{commanded_iq_mA},
        measured_iq_mA{measured_iq_mA},
        is_on_external_power{is_on_external_power},
        state{state, allocator}
    {
        (void)allocator; // avoid unused param warning
    }

    // Copy constructor
    MotorPerformance_0_1(const MotorPerformance_0_1&) = default;

    // Copy constructor with allocator
    MotorPerformance_0_1(const MotorPerformance_0_1& rhs, const allocator_type& allocator) :
        can_node_id{rhs.can_node_id},
        commanded_rpm{rhs.commanded_rpm},
        measured_rpm{rhs.measured_rpm},
        input_current_cA{rhs.input_current_cA},
        input_voltage_dV{rhs.input_voltage_dV},
        commanded_iq_mA{rhs.commanded_iq_mA},
        measured_iq_mA{rhs.measured_iq_mA},
        is_on_external_power{rhs.is_on_external_power},
        state{rhs.state, allocator}
    
    {
        (void)rhs;       // avoid unused param warning
        (void)allocator; // avoid unused param warning
    }

    // Move constructor
    MotorPerformance_0_1(MotorPerformance_0_1&&) = default;

    // Move constructor with allocator
    MotorPerformance_0_1(MotorPerformance_0_1&& rhs, const allocator_type& allocator) :
        can_node_id{std::move(rhs.can_node_id)},
        commanded_rpm{std::move(rhs.commanded_rpm)},
        measured_rpm{std::move(rhs.measured_rpm)},
        input_current_cA{std::move(rhs.input_current_cA)},
        input_voltage_dV{std::move(rhs.input_voltage_dV)},
        commanded_iq_mA{std::move(rhs.commanded_iq_mA)},
        measured_iq_mA{std::move(rhs.measured_iq_mA)},
        is_on_external_power{std::move(rhs.is_on_external_power)},
        state{std::move(rhs.state), allocator}
    {
        (void)rhs;       // avoid unused param warning
        (void)allocator; // avoid unused param warning
    }

    // Copy assignment
    MotorPerformance_0_1& operator=(const MotorPerformance_0_1&) = default;

    // Move assignment
    MotorPerformance_0_1& operator=(MotorPerformance_0_1&&) = default;

    // Destructor
    ~MotorPerformance_0_1() = default;
    
    // +----------------------------------------------------------------------+
    // | FIELDS
    // +----------------------------------------------------------------------+
    ///
    /// FCLIB-12544: Temporary fix for Cyphal migration
    ///
    _traits_::TypeOf::can_node_id can_node_id;
    ///
    /// Most recent speed command sent to the motor in rpm
    ///
    _traits_::TypeOf::commanded_rpm commanded_rpm;
    ///
    /// Most recent measured speed of the motor in rpm
    ///
    _traits_::TypeOf::measured_rpm measured_rpm;
    ///
    /// Measured current into the motor in centiamps
    ///
    _traits_::TypeOf::input_current_cA input_current_cA;
    ///
    /// Measured voltage into the motor in decivolts
    ///
    _traits_::TypeOf::input_voltage_dV input_voltage_dV;
    ///
    /// Commanded motor quadrature current in milliamps
    ///
    _traits_::TypeOf::commanded_iq_mA commanded_iq_mA;
    ///
    /// Measured motor quadrature current in milliamps
    ///
    _traits_::TypeOf::measured_iq_mA measured_iq_mA;
    ///
    /// Is the ESC connected to external (IE "shore") power, or not?
    ///
    _traits_::TypeOf::is_on_external_power is_on_external_power;
    ///
    /// Current state (health, operational mode, etc.) of the ESC.
    ///
    _traits_::TypeOf::state state;
};


inline nunavut::support::SerializeResult serialize(const MotorPerformance_0_1& obj,
                                                   nunavut::support::bitspan out_buffer)
{
    const std::size_t capacity_bits = out_buffer.size();
    if ((static_cast<std::size_t>(capacity_bits)) < 176UL)
    {
        return -nunavut::support::Error::SerializationBufferTooSmall;
    }
    // Notice that fields that are not an integer number of bytes long may overrun the space allocated for them
    // in the serialization buffer up to the next byte boundary. This is by design and is guaranteed to be safe.
    {   // saturated uint16 can_node_id
        // Saturation code not emitted -- native representation matches the serialized representation.
        const auto _result3_ = out_buffer.setUxx(obj.can_node_id, 16U);
        if(not _result3_){
            return -_result3_.error();
        }
        out_buffer.add_offset(16U);
    }
    {   // saturated int16 commanded_rpm
        // Saturation code not emitted -- native representation matches the serialized representation.
        const auto _result3_ = out_buffer.setIxx(obj.commanded_rpm, 16U);
        if(not _result3_){
            return -_result3_.error();
        }
        out_buffer.add_offset(16U);
    }
    {   // saturated int16 measured_rpm
        // Saturation code not emitted -- native representation matches the serialized representation.
        const auto _result3_ = out_buffer.setIxx(obj.measured_rpm, 16U);
        if(not _result3_){
            return -_result3_.error();
        }
        out_buffer.add_offset(16U);
    }
    {   // saturated int16 input_current_cA
        // Saturation code not emitted -- native representation matches the serialized representation.
        const auto _result3_ = out_buffer.setIxx(obj.input_current_cA, 16U);
        if(not _result3_){
            return -_result3_.error();
        }
        out_buffer.add_offset(16U);
    }
    {   // saturated uint10 input_voltage_dV
        std::uint16_t _sat0_ = obj.input_voltage_dV;
        if (_sat0_ > 1023U)
        {
            _sat0_ = 1023U;
        }
        const auto _result3_ = out_buffer.setUxx(_sat0_, 10U);
        if(not _result3_){
            return -_result3_.error();
        }
        out_buffer.add_offset(10U);
    }
    {   // saturated int20 commanded_iq_mA
        std::int32_t _sat0_ = obj.commanded_iq_mA;
        if (_sat0_ < -524288L)
        {
            _sat0_ = -524288L;
        }
        if (_sat0_ > 524287L)
        {
            _sat0_ = 524287L;
        }
        const auto _result3_ = out_buffer.setIxx(_sat0_, 20U);
        if(not _result3_){
            return -_result3_.error();
        }
        out_buffer.add_offset(20U);
    }
    {   // saturated int20 measured_iq_mA
        std::int32_t _sat0_ = obj.measured_iq_mA;
        if (_sat0_ < -524288L)
        {
            _sat0_ = -524288L;
        }
        if (_sat0_ > 524287L)
        {
            _sat0_ = 524287L;
        }
        const auto _result3_ = out_buffer.setIxx(_sat0_, 20U);
        if(not _result3_){
            return -_result3_.error();
        }
        out_buffer.add_offset(20U);
    }
    {   // saturated bool is_on_external_power
        auto _result2_ = out_buffer.setBit(obj.is_on_external_power);
        if(not _result2_){
            return -_result2_.error();
        }
        out_buffer.add_offset(1UL);
    }
    {
        const auto _result0_ = out_buffer.padAndMoveToAlignment(8U);
        if(not _result0_){
            return -_result0_.error();
        }
    }
    {   // vsdk.message.adn.vehicle.propulsionsystem.EscState.0.1 state
        std::size_t _size_bytes0_ = 7UL;  // Nested object (max) size, in bytes.
        auto _subspan0_ = out_buffer.subspan(0U, _size_bytes0_ * 8U);
        if(not _subspan0_){
            return -_subspan0_.error();
        }
        auto _err0_ = serialize(obj.state, _subspan0_.value());
        if (not _err0_)
        {
            return _err0_;
        }
        _size_bytes0_ = _err0_.value();
        // It is assumed that we know the exact type of the serialized entity, hence we expect the size to match.
        out_buffer.add_offset(_size_bytes0_ * 8U);
        //
    }
    {
        const auto _result0_ = out_buffer.padAndMoveToAlignment(8U);
        if(not _result0_){
            return -_result0_.error();
        }
    }
    // It is assumed that we know the exact type of the serialized entity, hence we expect the size to match.
    return out_buffer.offset_bytes_ceil();
}

inline nunavut::support::SerializeResult deserialize(MotorPerformance_0_1& obj,
                                                     nunavut::support::const_bitspan in_buffer)
{
    const auto capacity_bits = in_buffer.size();
    // saturated uint16 can_node_id
    obj.can_node_id = in_buffer.getU16(16U);
    in_buffer.add_offset(16U);
    // saturated int16 commanded_rpm
    obj.commanded_rpm = in_buffer.getI16(16U);
    in_buffer.add_offset(16U);
    // saturated int16 measured_rpm
    obj.measured_rpm = in_buffer.getI16(16U);
    in_buffer.add_offset(16U);
    // saturated int16 input_current_cA
    obj.input_current_cA = in_buffer.getI16(16U);
    in_buffer.add_offset(16U);
    // saturated uint10 input_voltage_dV
    obj.input_voltage_dV = in_buffer.getU16(10U);
    in_buffer.add_offset(10U);
    // saturated int20 commanded_iq_mA
    obj.commanded_iq_mA = in_buffer.getI32(20U);
    in_buffer.add_offset(20U);
    // saturated int20 measured_iq_mA
    obj.measured_iq_mA = in_buffer.getI32(20U);
    in_buffer.add_offset(20U);
    // saturated bool is_on_external_power
    obj.is_on_external_power = in_buffer.getBit();
    in_buffer.add_offset(1U);
    in_buffer.align_offset_to<8U>();
    // vsdk.message.adn.vehicle.propulsionsystem.EscState.0.1 state
    {
        std::size_t _size_bytes1_ = in_buffer.size() / 8U;
        {
            const auto _err1_ = deserialize(obj.state, in_buffer.subspan());
            if(_err1_){
                _size_bytes1_ = _err1_.value();
            }else{
                return -_err1_.error();
            }
        }
        in_buffer.add_offset(_size_bytes1_ * 8U);  // Advance by the size of the nested serialized representation.
    }
    in_buffer.align_offset_to<8U>();
    auto _bits_got_ = std::min<std::size_t>(in_buffer.offset(), capacity_bits);
    return { static_cast<std::size_t>(_bits_got_ / 8U) };
}

} // namespace propulsionsystem
} // namespace vehicle
} // namespace adn
} // namespace message
} // namespace vsdk

#endif // VSDK_MESSAGE_ADN_VEHICLE_PROPULSIONSYSTEM_MOTOR_PERFORMANCE_0_1_HPP_INCLUDED
