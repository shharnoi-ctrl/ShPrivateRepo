#include <Esc_sil_block.h>

#include <Mc_control.h>
#include <Mc.h>
#include <Mc_freqs.h>
#include <Htimehelper.h>
#include <mc_pinout.h>
#include <Ipc.h>
#include <GPIOioctl.h>
#include <ADC_helper_2837x.h>

namespace
{
	using namespace Base;
	using namespace Dsp28335_ent;

    struct C1_main
    {
        static MCxx::Mc& get_instance()
        {
            static MCxx::Mc* mc_inst =
                    Base::Memmgr::get_instance().get_allocator(Base::Memmgr::internal).allocate_new<MCxx::Mc,
                    const MCxx::Mc_params&>(MCxx::p_mc);
            return *mc_inst;
        }
    };

    struct C2_main
    {
        static MCxx::Mc_control& get_instance()
        {
            static MCxx::Mc_control* mc_inst =
                    Base::Memmgr::get_instance().get_allocator(Base::Memmgr::internal).allocate_new<MCxx::Mc_control,
                    const MCxx::HWversion_id&, const MCxx::Mc_params&>(MCxx::HWversion_id::v_mc_ipc, MCxx::p_mc);
            return *mc_inst;
        }
    };

    /// Returns the closest microsecond to the provided time in seconds as an unsigned integer
    static inline Base::Ttime closest_tic(const Real64 t)
    {
        return Base::Ttime(static_cast<int64>(round(t * Bsp::Kclk::get_sysclkfreq_r64())));
    }

    /// Rounds to the closest microsecond
    static inline Real64 round_by_tics(const Real64 t)
    {
        return round(t * Bsp::Kclk::get_sysclkfreq_r64()) / Bsp::Kclk::get_sysclkfreq_r64();
    }

    Uint16 get_adc_raw_from_v(const Real v)
    {
        return static_cast<Uint16>(v * 4095.0F / 3.3F);
    }

    static const Uint32 n_pos_ids = 3U; ///< Number of position identification bits
    static const Base::Tnarray<Dsp28335_ent::GPIOid, n_pos_ids> pos_ids =
    {
        Dsp28335_ent::gpio_016,
        Dsp28335_ent::gpio_017,
        Dsp28335_ent::gpio_018
    };

    static const Uint32 n_brd_ids = 4U; ///< Number of board identification bits
    static const Base::Tnarray<Dsp28335_ent::GPIOid, n_brd_ids> brd_ids =
    {
        Dsp28335_ent::gpio_011,
        Dsp28335_ent::gpio_013,
        Dsp28335_ent::gpio_014,
        Dsp28335_ent::gpio_015
    };

    static const Dsp28335_ent::GPIOid gpio_shore_power = Dsp28335_ent::gpio_032;

    // Board revision IPC CX-3 DV Block 20
    static const Uint16 brd_id_cx3_dv_blk20 = 8U;

    /// Position ID value
    /// \wi{19687}
    /// mc_common library shall provide a method to read a set of Dsp28335_ent::GPIO as a unsigned integer,
    /// using the first GPIO in the list as the high significant bit and the latest as the low significant bit.
    /// \param[in] gpios: array of GPIOs to get the value
    Uint16 get_value_from_gpio(const Base::Mblock<const Dsp28335_ent::GPIOid>& gpios)
    {
        Uint16 val = 0U;
        for(Uint16 i = 0; i < gpios.sz; ++i)
        {
            val |= (static_cast<Uint16>(Dsp28335_ent::GPIO(gpios.v[i]).get()) << i);
        }
        return val;
    }

    void read_pos()
    {
        using namespace MCxx;

        if(get_value_from_gpio(brd_ids.to_mblock()) == brd_id_cx3_dv_blk20)
        {
            get_c1_sh_mem().is_ipc_board = true;
        }

        const Ipc_ids::Pos pos_val = static_cast<Ipc_ids::Pos>(get_value_from_gpio(pos_ids.to_mblock()));
        if(get_c1_sh_mem().is_ipc_board)
        {
            switch(pos_val)
            {
                case Ipc_ids::rr:
                {
                    get_c1_sh_mem().curr_esc_id = Ipc_ids::kRightRear;
                    break;
                }
                case Ipc_ids::cr:
                {
                    get_c1_sh_mem().curr_esc_id = Ipc_ids::kRightCenter;
                    break;
                }
                case Ipc_ids::fr:
                {
                    get_c1_sh_mem().curr_esc_id = Ipc_ids::kRightFront;
                    break;
                }
                case Ipc_ids::fl:
                {
                    get_c1_sh_mem().curr_esc_id = Ipc_ids::kLeftFront;
                    break;
                }
                case Ipc_ids::cl:
                {
                    get_c1_sh_mem().curr_esc_id = Ipc_ids::kLeftCenter;
                    break;
                }
                case Ipc_ids::rl:
                {
                    get_c1_sh_mem().curr_esc_id = Ipc_ids::kLeftRear;
                    break;
                }
                default:
                {
                    Bsp::warning();
                    break;
                }
            }
        }
    }

    static void set_map_adc()
    {
        static const Uint16 adc_ch_order1_sz = 1;
        const Tnarray<ADC::ADCchannel, adc_ch_order1_sz> adc_ch_order1 =
        {
            {
                MCxx::p_mc.adc_ch_iph_u       // AN-A2
            }
        };

        static const Uint16 adc_ch_order2_sz = 4;
        const Tnarray<ADC::ADCchannel, adc_ch_order2_sz> adc_ch_order2 =
        {
            {
				MCxx::p_mc.adc_ch_iph_v,      // AN-B2
				MCxx::p_mc.adc_ch_enc_sin_1,  // AN-B3
				MCxx::p_mc.adc_ch_enc_sin_2,  // AN-B0
				MCxx::p_mc.adc_ch_power_temp  // AN-B1
            }
        };

        static const Uint16 adc_ch_order3_sz = 3;
        const Tnarray<ADC::ADCchannel, adc_ch_order3_sz> adc_ch_order3 =
        {
            {
				MCxx::p_mc.adc_ch_iph_w,         // AN-C2
				MCxx::p_mc.adc_ch_dc_curr,       // AN-C3
				MCxx::p_mc.adc_ch_str_idc        // AN-C4
            }
        };


        static const Uint16 adc_ch_order4_sz = 5;
        const Tnarray<ADC::ADCchannel, adc_ch_order4_sz> adc_ch_order4 =
        {
            {
				MCxx::p_mc.adc_ch_vg_sen,   // AN-D2
				MCxx::p_mc.adc_ch_enc_cos_1,// AN-D3
				MCxx::p_mc.adc_ch_enc_cos_2,// AN-D0
				MCxx::p_mc.adc_ch_ext_temp, // AN-D1
				MCxx::p_mc.adc_ch_vg_ov     // AN-D4
            }
        };

        const Tnarray<const Mblock<const ADC::ADCchannel>, ADC::num_modules> sequences =
        {
             adc_ch_order1.to_mblock(),
             adc_ch_order2.to_mblock(),
             adc_ch_order3.to_mblock(),
             adc_ch_order4.to_mblock()
        };
        Dsp28335_ent::ADC_helper_2837x::set_map(sequences.to_mblock());
    }
}

namespace Esc_so
{

    const Base::Ttime Esc_sil_block::cio_hi_period_us(
            static_cast<Real64>(1/static_cast<Real64>(MCxx::Mc_freqs::acq_rt_freq)));  // Desired CIO-HI period in microseconds (1kHz).
    const Base::Ttime Esc_sil_block::cio_lo_period_us(static_cast<Real64>(0.001L));  // Desired CIO-LO period in microseconds (1kHz).
    const Base::Ttime Esc_sil_block::c2_hi_period_us(
            static_cast<Real64>(1/static_cast<Real64>(MCxx::Mc_freqs::def_ctrl_rt_freq)));  // Desired CIO-HI period in microseconds (1kHz).
    const Base::Ttime Esc_sil_block::c2_lo_period_us(static_cast<Real64>(0.001L));  // Desired CIO-LO period in microseconds (1kHz).

    Esc_sil_block::Esc_sil_block() :
        next_cio_hi_time(static_cast<int64>(0)),
        next_cio_lo_time(static_cast<int64>(0)),
        next_c2_hi_time(static_cast<int64>(0)),
        next_c2_lo_time(static_cast<int64>(0)),
        c1(0),
        c2(0),
        next()
    {
        Base::Sil_data::get_instance().current_task_id = Base::Sil_data::task_c1_hi;
    }


    Real64 Esc_sil_block::step(const Real64 t, const Esc_input& inputs, Esc_output& out)
    {
        // Compute number of microseconds
        const Base::Ttime t_us = closest_tic(t);

        // Set inputs
        using namespace Dsp28335_ent;
        ADC_helper_2837x::set_raw_value(c2->param.adc_ch_iph_u, get_adc_raw_from_v(inputs.ac_currents_adc[0]));
        ADC_helper_2837x::set_raw_value(c2->param.adc_ch_iph_v, get_adc_raw_from_v(inputs.ac_currents_adc[1]));
        ADC_helper_2837x::set_raw_value(c2->param.adc_ch_iph_w, get_adc_raw_from_v(inputs.ac_currents_adc[2]));
        ADC_helper_2837x::set_raw_value(c2->param.adc_ch_vg_sen, get_adc_raw_from_v(inputs.vdc_adc));
        ADC_helper_2837x::set_raw_value(c2->param.adc_ch_vg_ov, get_adc_raw_from_v(inputs.vmon_adc));
        ADC_helper_2837x::set_raw_value(c2->param.adc_ch_dc_curr, get_adc_raw_from_v(inputs.idc_adc));
        ADC_helper_2837x::set_raw_value(c2->param.adc_ch_enc_sin_1, get_adc_raw_from_v(inputs.sincos_sensor1_adc.s));
        ADC_helper_2837x::set_raw_value(c2->param.adc_ch_enc_cos_1, get_adc_raw_from_v(inputs.sincos_sensor1_adc.c));
        ADC_helper_2837x::set_raw_value(c2->param.adc_ch_enc_sin_2, get_adc_raw_from_v(inputs.sincos_sensor2_adc.s));
        ADC_helper_2837x::set_raw_value(c2->param.adc_ch_enc_cos_2, get_adc_raw_from_v(inputs.sincos_sensor2_adc.c));
        ADC_helper_2837x::set_raw_value(c2->param.adc_ch_ext_temp, get_adc_raw_from_v(inputs.motor_temp_adc));

        // Execute until the provided input time
        next = find_next_task();
        while (next.time <= t_us)
        {
            Bsp::Htimehelper::set_time_us(next.time);
            switch (next.task)
            {
                case Base::Sil_data::task_c1_hi:
                {
                    /// Execute CIO-HI
                    step_cio_hi();
                    next_cio_hi_time += cio_hi_period_us;
                    break;
                }
                case Base::Sil_data::task_c1_lo:
                {
                    /// Execute CIO-LO
                    step_cio_lo();
                    next_cio_lo_time += cio_lo_period_us;
                    break;
                }
                case Base::Sil_data::task_c2_hi:
                {
                    /// Execute C2 HI
                    step_c2_hi();
                    next_c2_hi_time += c2_hi_period_us;
                    break;
                }
                case Base::Sil_data::task_c2_lo:
                {
                    /// Execute C2 LO
                    step_c2_lo();
                    next_c2_lo_time += c2_lo_period_us;
                    break;
                }
                default:
                {
                    Bsp::warning();
                    break;
                }
            }
            next = find_next_task();
        }
        // Obtain the outputs
        out.pwm_output[0] = c2->ctrl.duty_u * c2->ctrl.vdc;
        out.pwm_output[1] = c2->ctrl.duty_v * c2->ctrl.vdc;
        out.pwm_output[2] = c2->ctrl.duty_w * c2->ctrl.vdc;

        // Update time in case it was not updated
        Bsp::Htimehelper::set_time_us(t_us);

        // Release shore-power as soon as FSM is not init.
        if(MCxx::get_c1_sh_mem().fsm_st != MCxx::FSM::init)
        {
            Dsp28335_ent::GPIO(gpio_shore_power).set_lo();
        }

        // Returns time of next step in seconds
        return next.time.get_seconds64();
    }

    Esc_sil_block::Min_task Esc_sil_block::find_next_task() const
    {
        Min_task ret;
        if (next_cio_hi_time <= next_cio_lo_time &&
            next_cio_hi_time <= next_c2_hi_time &&
            next_cio_hi_time <= next_c2_lo_time)
        {
            ret.task = Base::Sil_data::task_c1_hi;
            ret.time = next_cio_hi_time;
        }
        else if (next_cio_lo_time <= next_c2_hi_time &&
                   next_cio_lo_time <= next_c2_lo_time)
        {
            ret.task = Base::Sil_data::task_c1_lo;
            ret.time = next_cio_lo_time;
        }
        else if (next_c2_hi_time <= next_c2_lo_time)
        {
            ret.task = Base::Sil_data::task_c2_hi;
            ret.time = next_c2_hi_time;
        }
        else
        {
            ret.task = Base::Sil_data::task_c2_lo;
            ret.time = next_c2_lo_time;
        }

        return ret;
    }

    void Esc_sil_block::init(Uint16 node_id0)
    {
        using namespace MCxx::Ipc_ids;

        /// Compute ESC identifer to retrieve real position.
        uint8_t position = UINT8_MAX;
        const Uint16 esc_id = node_id0 - node_id_rr_a;
        switch(esc_id)
        {
            case kRightRear:
            {
                position = rr;
                break;
            }
            case kRightCenter:
            {
                position = cr;
                break;
            }
            case kRightFront:
            {
                position = fr;
                break;
            }
            case kLeftFront:
            {
                position = fl;
                break;
            }
            case kLeftCenter:
            {
                position = cl;
                break;
            }
            case kLeftRear:
            {
                position = rl;
                break;
            }
            default:
            {
                Bsp::warning();
                // do nothing - enum already set to unknown.
                break;
            }
        }

        /// Then fix GPIOs to dedicated position.
        Dsp28335_ent::GPIO(pos_ids[0]).set(position & 0x1 );
        Dsp28335_ent::GPIO(pos_ids[1]).set((position >> 1 ) & 0x1 );
        Dsp28335_ent::GPIO(pos_ids[2]).set((position >> 2 ) & 0x1 );
        Dsp28335_ent::GPIO(brd_ids[3]).set_hi(); // Set GPIO value to be the IPC CX-3 DV Block 20

        /// Read/set position ID.
        read_pos();

        /// Allocate C1.
        c1 = Base::Memmgr::get_instance().get_allocator(Base::Memmgr::internal).allocate_new<MCxx::Mc,
                const MCxx::Mc_params&>(MCxx::p_mc);

        /// Do this to avoid close allocation from C1
        Base::Sil_data::get_instance().current_task_id = Base::Sil_data::task_c2_hi;

        /// Allocate C2.
        c2 = Base::Memmgr::get_instance().get_allocator(Base::Memmgr::internal).allocate_new<MCxx::Mc_control,
                const MCxx::HWversion_id&, const MCxx::Mc_params&>(MCxx::HWversion_id::v_mc_ipc, MCxx::p_mc);

        // Compute dependant in C2
        c2->hal_init_ipc();
        // Call to post_init to set dependant variables
        c1->post_init_c2();
        // Configure ADC mapping (only SIL code)
        set_map_adc();
        // Inactive GFD for simulation
        MCxx::get_c2_sh_mem().has_ground_fault_protection = false;
        // Set IPC board
        MCxx::get_c1_sh_mem().is_ipc_board = true;
        // Set shore power present
        Dsp28335_ent::GPIO(gpio_shore_power).set_hi();
        // Set SSCB not faulted
        Dsp28335_ent::GPIO(MCxx::p_hal.gpio_sscb_nflt_in).set_hi();
        // Set PWR_REG not faulted
        Dsp28335_ent::GPIO(MCxx::p_hal.gpio_pg_3v3).set_hi();
    }
}
