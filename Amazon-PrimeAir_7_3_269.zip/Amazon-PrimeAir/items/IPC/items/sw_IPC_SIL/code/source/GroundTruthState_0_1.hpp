//
// This is an AUTO-GENERATED Cyphal DSDL data type implementation. Curious? See https://opencyphal.org.
// You shouldn't attempt to edit this file.
//
// Checking this file under version control is not recommended since metadata in this header will change for each
// build invocation. TODO: add --reproducible option to prevent any volatile metadata from being generated.
//
// Generator:     nunavut-2.3.2.dev0 (serialization was enabled)
// Source file:   /local/p4clients/pkgbuild-gBJTx/workspace/src/AdnSimulationIpsoMessages/cyphal_dsdl/vsdk/message/adn/simulation/GroundTruthState.0.1.dsdl
// Generated at:  2024-03-15 20:59:01.188355 UTC
// Is deprecated: no
// Fixed port-ID: None
// Full name:     vsdk.message.adn.simulation.GroundTruthState
// Type Version:  0.1
// Support
//    Support Namespace: nunavut.lang.cpp.support
//    Support Version:   (1, 0, 0)
// Template Set (package)
//    priority: 0
//    package:  nunavut.lang.cpp.templates
//    version:  (1, 0, 0)
// Platform
//     python_implementation:  CPython
//     python_version:  3.8.18
//     python_release_level:  final
//     python_build:  ('default', 'Mar 11 2024 06:41:50')
//     python_compiler:  GCC 7.5.0
//     python_revision:  
//     python_xoptions:  {}
//     runtime_platform:  Linux-5.4.266-187.365.amzn2int.x86_64-x86_64-with
// Language Options
//     target_endianness:  little
//     omit_float_serialization_support:  False
//     enable_serialization_asserts:  False
//     enable_override_variable_array_capacity:  False
//     std:  c++14
//     cast_format:  static_cast<{type}>({value})
//     variable_array_type_include:  "vsdk/core/util/FrameworkVector.h"
//     variable_array_type_template:  vsdk::core::util::FrameworkVector<{TYPE}, {REBIND_ALLOCATOR}>
//     variable_array_type_constructor_args:  vsdk::core::util::max_size_max_constructor_tag{{}}, {MAX_SIZE}
//     allocator_include:  "vsdk/core/util/FrameworkAllocator.h"
//     allocator_type:  vsdk::core::util::FrameworkAllocator
//     allocator_is_default_constructible:  True
//     ctor_convention:  uses-trailing-allocator
// Uses Language Features
//     Uses std_variant:no
#ifndef VSDK_MESSAGE_ADN_SIMULATION_GROUND_TRUTH_STATE_0_1_HPP_INCLUDED
#define VSDK_MESSAGE_ADN_SIMULATION_GROUND_TRUTH_STATE_0_1_HPP_INCLUDED

#include "nunavut/support/serialization.hpp"
#include "vsdk/core/util/FrameworkAllocator.h"
#include "vsdk/core/util/FrameworkVector.h"
#include "vsdk/message/MessageId_0_1.hpp"
#include "vsdk/message/adn/simulation/statemanager/ForceMomentComponents_0_1.hpp"
#include "vsdk/message/adn/vehicle/common/Matrix3x3_0_1.hpp"
#include "vsdk/message/adn/vehicle/common/RollPitchHeading_0_1.hpp"
#include "vsdk/message/adn/vehicle/common/Vector3_0_1.hpp"
#include "vsdk/message/adn/vehicle/common/Wgs84Location_0_1.hpp"
#include <cstdint>
#include <limits>

namespace vsdk
{
namespace message
{
namespace adn
{
namespace simulation
{
// +-------------------------------------------------------------------------------------------------------------------+
// | LANGUAGE OPTION ASSERTIONS
// |    These static assertions ensure that the header is being used with
// | Nunavut C++ serialization support that is compatible with the language
// | options in effect when that support code was generated.
// +-------------------------------------------------------------------------------------------------------------------+
static_assert( nunavut::support::options::target_endianness == 434322821,
              "/local/p4clients/pkgbuild-gBJTx/workspace/src/AdnSimulationIpsoMessages/cyphal_dsdl/vsdk/message/adn/simulation/GroundTruthState.0.1.dsdl "
              "is trying to use a serialization library that was compiled with "
              "different language options. This is dangerous and therefore not "
              "allowed." );
static_assert( nunavut::support::options::omit_float_serialization_support == 0,
              "/local/p4clients/pkgbuild-gBJTx/workspace/src/AdnSimulationIpsoMessages/cyphal_dsdl/vsdk/message/adn/simulation/GroundTruthState.0.1.dsdl "
              "is trying to use a serialization library that was compiled with "
              "different language options. This is dangerous and therefore not "
              "allowed." );
static_assert( nunavut::support::options::enable_serialization_asserts == 0,
              "/local/p4clients/pkgbuild-gBJTx/workspace/src/AdnSimulationIpsoMessages/cyphal_dsdl/vsdk/message/adn/simulation/GroundTruthState.0.1.dsdl "
              "is trying to use a serialization library that was compiled with "
              "different language options. This is dangerous and therefore not "
              "allowed." );
static_assert( nunavut::support::options::enable_override_variable_array_capacity == 0,
              "/local/p4clients/pkgbuild-gBJTx/workspace/src/AdnSimulationIpsoMessages/cyphal_dsdl/vsdk/message/adn/simulation/GroundTruthState.0.1.dsdl "
              "is trying to use a serialization library that was compiled with "
              "different language options. This is dangerous and therefore not "
              "allowed." );
static_assert( nunavut::support::options::std == 3161622713,
              "/local/p4clients/pkgbuild-gBJTx/workspace/src/AdnSimulationIpsoMessages/cyphal_dsdl/vsdk/message/adn/simulation/GroundTruthState.0.1.dsdl "
              "is trying to use a serialization library that was compiled with "
              "different language options. This is dangerous and therefore not "
              "allowed." );
static_assert( nunavut::support::options::cast_format == 1407868567,
              "/local/p4clients/pkgbuild-gBJTx/workspace/src/AdnSimulationIpsoMessages/cyphal_dsdl/vsdk/message/adn/simulation/GroundTruthState.0.1.dsdl "
              "is trying to use a serialization library that was compiled with "
              "different language options. This is dangerous and therefore not "
              "allowed." );
static_assert( nunavut::support::options::variable_array_type_include == 2812197107,
              "/local/p4clients/pkgbuild-gBJTx/workspace/src/AdnSimulationIpsoMessages/cyphal_dsdl/vsdk/message/adn/simulation/GroundTruthState.0.1.dsdl "
              "is trying to use a serialization library that was compiled with "
              "different language options. This is dangerous and therefore not "
              "allowed." );
static_assert( nunavut::support::options::variable_array_type_template == 1772747277,
              "/local/p4clients/pkgbuild-gBJTx/workspace/src/AdnSimulationIpsoMessages/cyphal_dsdl/vsdk/message/adn/simulation/GroundTruthState.0.1.dsdl "
              "is trying to use a serialization library that was compiled with "
              "different language options. This is dangerous and therefore not "
              "allowed." );
static_assert( nunavut::support::options::variable_array_type_constructor_args == 2027088755,
              "/local/p4clients/pkgbuild-gBJTx/workspace/src/AdnSimulationIpsoMessages/cyphal_dsdl/vsdk/message/adn/simulation/GroundTruthState.0.1.dsdl "
              "is trying to use a serialization library that was compiled with "
              "different language options. This is dangerous and therefore not "
              "allowed." );
static_assert( nunavut::support::options::allocator_include == 806196102,
              "/local/p4clients/pkgbuild-gBJTx/workspace/src/AdnSimulationIpsoMessages/cyphal_dsdl/vsdk/message/adn/simulation/GroundTruthState.0.1.dsdl "
              "is trying to use a serialization library that was compiled with "
              "different language options. This is dangerous and therefore not "
              "allowed." );
static_assert( nunavut::support::options::allocator_type == 3240006296,
              "/local/p4clients/pkgbuild-gBJTx/workspace/src/AdnSimulationIpsoMessages/cyphal_dsdl/vsdk/message/adn/simulation/GroundTruthState.0.1.dsdl "
              "is trying to use a serialization library that was compiled with "
              "different language options. This is dangerous and therefore not "
              "allowed." );
static_assert( nunavut::support::options::allocator_is_default_constructible == 1,
              "/local/p4clients/pkgbuild-gBJTx/workspace/src/AdnSimulationIpsoMessages/cyphal_dsdl/vsdk/message/adn/simulation/GroundTruthState.0.1.dsdl "
              "is trying to use a serialization library that was compiled with "
              "different language options. This is dangerous and therefore not "
              "allowed." );
static_assert( nunavut::support::options::ctor_convention == 1970806058,
              "/local/p4clients/pkgbuild-gBJTx/workspace/src/AdnSimulationIpsoMessages/cyphal_dsdl/vsdk/message/adn/simulation/GroundTruthState.0.1.dsdl "
              "is trying to use a serialization library that was compiled with "
              "different language options. This is dangerous and therefore not "
              "allowed." );


// +-------------------------------------------------------------------------------------------------------------------+
// | This implementation uses a minimal variant implementation that is forward-compatible with the same types generated
// | using the C++17 variant type in the standard library. This minimal variant implementation is limited in the
// | following ways:
// |    1. Supports only emplace and get_if.
// |    2. Only support access by index (see the IndexOf property of the VariantType).
// |    3. This object cannot be copy-constructed nor move-constructed.
// |    4. There is an O(n) lookup in this object's destructor and in the
// |       emplace method.
// |
// | The C++17 version of this object will define the same emplace and get_if wrappers so code written against this
// | version will be fully-forward compatible, but the C++17 version exposes the variant type directly allowing full
// | use of that standard library feature – it is therefore not backwards-compatible.
// +-------------------------------------------------------------------------------------------------------------------+
///
/// Copyright 2022 Amazon.com, Inc. or its affiliates. All Rights Reserved.
/// 
/// This DSDL was created using the DSDL->Cyphal conversion tool.
/// 
/// This message contains a snapshot of the ground-truth physics calculated at a
/// specific timestamp.
///
struct GroundTruthState_0_1 final
{
    using allocator_type = vsdk::core::util::FrameworkAllocator<void>;

    struct _traits_  // The name is surrounded with underscores to avoid collisions with DSDL attributes.
    {
        _traits_() = delete;
        /// This type does not have a fixed port-ID. See https://forum.opencyphal.org/t/choosing-message-and-service-ids/889
        static constexpr bool HasFixedPortID = false;

        static constexpr bool IsServiceType = false;

        /// Extent is the minimum amount of memory required to hold any serialized representation of any compatible
        /// version of the data type; or, on other words, it is the the maximum possible size of received objects of this type.
        /// The size is specified in bytes (rather than bits) because by definition, extent is an integer number of bytes long.
        /// When allocating a deserialization (RX) buffer for this data type, it should be at least extent bytes large.
        /// When allocating a serialization (TX) buffer, it is safe to use the size of the largest serialized representation
        /// instead of the extent because it provides a tighter bound of the object size; it is safe because the concrete type
        /// is always known during serialization (unlike deserialization). If not sure, use extent everywhere.
        static constexpr std::size_t ExtentBytes                  = 1003UL;
        static constexpr std::size_t SerializationBufferSizeBytes = 1003UL;
        static_assert(ExtentBytes >= SerializationBufferSizeBytes, "Internal constraint violation");
        static_assert(ExtentBytes < (std::numeric_limits<std::size_t>::max() / 8U), "This message is too large to be handled by the selected types");
        struct TypeOf
        {
            TypeOf() = delete;
            using id = vsdk::message::MessageId_0_1;
            using timestamp_us = std::int64_t;
            using v_vf_ned2vf_m_per_s = vsdk::message::adn::vehicle::common::Vector3_0_1;
            using v_ned_ned2vf_m_per_s = vsdk::message::adn::vehicle::common::Vector3_0_1;
            using ground_speed_m_per_s = float;
            using w_vf_ned2vf_rad_per_s = vsdk::message::adn::vehicle::common::Vector3_0_1;
            using a_vf_ned2vf_m_per_s2 = vsdk::message::adn::vehicle::common::Vector3_0_1;
            using wdot_vf_ned2vf_rad_per_s2 = vsdk::message::adn::vehicle::common::Vector3_0_1;
            using wgs84_location = vsdk::message::adn::vehicle::common::Wgs84Location_0_1;
            using altitude_agl_m = float;
            using altitude_msl_m = float;
            using vf_pseudo_altitude_hae_wgs84_m = float;
            using backyard_pseudo_altitude_hae_wgs84_m = float;
            using target_pseudo_altitude_hae_wgs84_m = float;
            using airspeed_true_m_per_s = float;
            using airspeed_indicated_m_per_s = float;
            using windspeed_ned_m_per_s = vsdk::message::adn::vehicle::common::Vector3_0_1;
            using R_vf_from_ned = vsdk::message::adn::vehicle::common::Matrix3x3_0_1;
            using rph_vf_from_ned = vsdk::message::adn::vehicle::common::RollPitchHeading_0_1;
            using dynamic_pressure_Pa = float;
            using static_pressure_Pa = float;
            using air_temperature_K = float;
            using air_density_kg_per_m3 = float;
            using actuator_forces_N = vsdk::message::adn::vehicle::common::Vector3_0_1;
            using actuator_moments_Nm = vsdk::message::adn::vehicle::common::Vector3_0_1;
            using aero_forces_N = vsdk::message::adn::vehicle::common::Vector3_0_1;
            using aero_moments_Nm = vsdk::message::adn::vehicle::common::Vector3_0_1;
            using vrs_thrust_per_propeller_N = vsdk::core::util::FrameworkVector<double, std::allocator_traits<allocator_type>::rebind_alloc<double>>;
            using motor_rear_right_rpm = float;
            using motor_rear_right_v_radial_m_per_s = float;
            using motor_rear_right_v_axial_m_per_s = float;
            using motor_rear_right_prop_torque_Nm = float;
            using motor_center_right_rpm = float;
            using motor_center_right_v_radial_m_per_s = float;
            using motor_center_right_v_axial_m_per_s = float;
            using motor_center_right_prop_torque_Nm = float;
            using motor_front_right_rpm = float;
            using motor_front_right_v_radial_m_per_s = float;
            using motor_front_right_v_axial_m_per_s = float;
            using motor_front_right_prop_torque_Nm = float;
            using motor_front_left_rpm = float;
            using motor_front_left_v_radial_m_per_s = float;
            using motor_front_left_v_axial_m_per_s = float;
            using motor_front_left_prop_torque_Nm = float;
            using motor_center_left_rpm = float;
            using motor_center_left_v_radial_m_per_s = float;
            using motor_center_left_v_axial_m_per_s = float;
            using motor_center_left_prop_torque_Nm = float;
            using motor_rear_left_rpm = float;
            using motor_rear_left_v_radial_m_per_s = float;
            using motor_rear_left_v_axial_m_per_s = float;
            using motor_rear_left_prop_torque_Nm = float;
            using rudderon_left_surface_deflection_rad = float;
            using rudderon_left_floating_shaft_angle_rad = float;
            using rudderon_left_shaft_angle_rad = float;
            using rudderon_right_surface_deflection_rad = float;
            using rudderon_right_floating_shaft_angle_rad = float;
            using rudderon_right_shaft_angle_rad = float;
            using elevon_left_surface_deflection_rad = float;
            using elevon_left_floating_shaft_angle_rad = float;
            using elevon_left_shaft_angle_rad = float;
            using elevon_right_surface_deflection_rad = float;
            using elevon_right_floating_shaft_angle_rad = float;
            using elevon_right_shaft_angle_rad = float;
            using landing_legs_touching_ground = vsdk::core::util::FrameworkVector<bool, std::allocator_traits<allocator_type>::rebind_alloc<bool>>;
            using force_moment_components = vsdk::message::adn::simulation::statemanager::ForceMomentComponents_0_1;
        };
    };

    // Default constructor
    GroundTruthState_0_1() :
        id{},
        timestamp_us{},
        v_vf_ned2vf_m_per_s{},
        v_ned_ned2vf_m_per_s{},
        ground_speed_m_per_s{},
        w_vf_ned2vf_rad_per_s{},
        a_vf_ned2vf_m_per_s2{},
        wdot_vf_ned2vf_rad_per_s2{},
        wgs84_location{},
        altitude_agl_m{},
        altitude_msl_m{},
        vf_pseudo_altitude_hae_wgs84_m{},
        backyard_pseudo_altitude_hae_wgs84_m{},
        target_pseudo_altitude_hae_wgs84_m{},
        airspeed_true_m_per_s{},
        airspeed_indicated_m_per_s{},
        windspeed_ned_m_per_s{},
        R_vf_from_ned{},
        rph_vf_from_ned{},
        dynamic_pressure_Pa{},
        static_pressure_Pa{},
        air_temperature_K{},
        air_density_kg_per_m3{},
        actuator_forces_N{},
        actuator_moments_Nm{},
        aero_forces_N{},
        aero_moments_Nm{},
        vrs_thrust_per_propeller_N{},
        motor_rear_right_rpm{},
        motor_rear_right_v_radial_m_per_s{},
        motor_rear_right_v_axial_m_per_s{},
        motor_rear_right_prop_torque_Nm{},
        motor_center_right_rpm{},
        motor_center_right_v_radial_m_per_s{},
        motor_center_right_v_axial_m_per_s{},
        motor_center_right_prop_torque_Nm{},
        motor_front_right_rpm{},
        motor_front_right_v_radial_m_per_s{},
        motor_front_right_v_axial_m_per_s{},
        motor_front_right_prop_torque_Nm{},
        motor_front_left_rpm{},
        motor_front_left_v_radial_m_per_s{},
        motor_front_left_v_axial_m_per_s{},
        motor_front_left_prop_torque_Nm{},
        motor_center_left_rpm{},
        motor_center_left_v_radial_m_per_s{},
        motor_center_left_v_axial_m_per_s{},
        motor_center_left_prop_torque_Nm{},
        motor_rear_left_rpm{},
        motor_rear_left_v_radial_m_per_s{},
        motor_rear_left_v_axial_m_per_s{},
        motor_rear_left_prop_torque_Nm{},
        rudderon_left_surface_deflection_rad{},
        rudderon_left_floating_shaft_angle_rad{},
        rudderon_left_shaft_angle_rad{},
        rudderon_right_surface_deflection_rad{},
        rudderon_right_floating_shaft_angle_rad{},
        rudderon_right_shaft_angle_rad{},
        elevon_left_surface_deflection_rad{},
        elevon_left_floating_shaft_angle_rad{},
        elevon_left_shaft_angle_rad{},
        elevon_right_surface_deflection_rad{},
        elevon_right_floating_shaft_angle_rad{},
        elevon_right_shaft_angle_rad{},
        landing_legs_touching_ground{},
        force_moment_components{}
    {
    }

    // Allocator constructor
    explicit GroundTruthState_0_1(const allocator_type& allocator) :
        id{allocator},
        timestamp_us{},
        v_vf_ned2vf_m_per_s{allocator},
        v_ned_ned2vf_m_per_s{allocator},
        ground_speed_m_per_s{},
        w_vf_ned2vf_rad_per_s{allocator},
        a_vf_ned2vf_m_per_s2{allocator},
        wdot_vf_ned2vf_rad_per_s2{allocator},
        wgs84_location{allocator},
        altitude_agl_m{},
        altitude_msl_m{},
        vf_pseudo_altitude_hae_wgs84_m{},
        backyard_pseudo_altitude_hae_wgs84_m{},
        target_pseudo_altitude_hae_wgs84_m{},
        airspeed_true_m_per_s{},
        airspeed_indicated_m_per_s{},
        windspeed_ned_m_per_s{allocator},
        R_vf_from_ned{allocator},
        rph_vf_from_ned{allocator},
        dynamic_pressure_Pa{},
        static_pressure_Pa{},
        air_temperature_K{},
        air_density_kg_per_m3{},
        actuator_forces_N{allocator},
        actuator_moments_Nm{allocator},
        aero_forces_N{allocator},
        aero_moments_Nm{allocator},
        vrs_thrust_per_propeller_N{vsdk::core::util::max_size_max_constructor_tag{}, 6, allocator},
        motor_rear_right_rpm{},
        motor_rear_right_v_radial_m_per_s{},
        motor_rear_right_v_axial_m_per_s{},
        motor_rear_right_prop_torque_Nm{},
        motor_center_right_rpm{},
        motor_center_right_v_radial_m_per_s{},
        motor_center_right_v_axial_m_per_s{},
        motor_center_right_prop_torque_Nm{},
        motor_front_right_rpm{},
        motor_front_right_v_radial_m_per_s{},
        motor_front_right_v_axial_m_per_s{},
        motor_front_right_prop_torque_Nm{},
        motor_front_left_rpm{},
        motor_front_left_v_radial_m_per_s{},
        motor_front_left_v_axial_m_per_s{},
        motor_front_left_prop_torque_Nm{},
        motor_center_left_rpm{},
        motor_center_left_v_radial_m_per_s{},
        motor_center_left_v_axial_m_per_s{},
        motor_center_left_prop_torque_Nm{},
        motor_rear_left_rpm{},
        motor_rear_left_v_radial_m_per_s{},
        motor_rear_left_v_axial_m_per_s{},
        motor_rear_left_prop_torque_Nm{},
        rudderon_left_surface_deflection_rad{},
        rudderon_left_floating_shaft_angle_rad{},
        rudderon_left_shaft_angle_rad{},
        rudderon_right_surface_deflection_rad{},
        rudderon_right_floating_shaft_angle_rad{},
        rudderon_right_shaft_angle_rad{},
        elevon_left_surface_deflection_rad{},
        elevon_left_floating_shaft_angle_rad{},
        elevon_left_shaft_angle_rad{},
        elevon_right_surface_deflection_rad{},
        elevon_right_floating_shaft_angle_rad{},
        elevon_right_shaft_angle_rad{},
        landing_legs_touching_ground{vsdk::core::util::max_size_max_constructor_tag{}, 6, allocator},
        force_moment_components{allocator}
    {
        (void)allocator; // avoid unused param warning
    }
    
    // Initializing constructor
    GroundTruthState_0_1(
        const _traits_::TypeOf::id& id,
        const _traits_::TypeOf::timestamp_us& timestamp_us,
        const _traits_::TypeOf::v_vf_ned2vf_m_per_s& v_vf_ned2vf_m_per_s,
        const _traits_::TypeOf::v_ned_ned2vf_m_per_s& v_ned_ned2vf_m_per_s,
        const _traits_::TypeOf::ground_speed_m_per_s& ground_speed_m_per_s,
        const _traits_::TypeOf::w_vf_ned2vf_rad_per_s& w_vf_ned2vf_rad_per_s,
        const _traits_::TypeOf::a_vf_ned2vf_m_per_s2& a_vf_ned2vf_m_per_s2,
        const _traits_::TypeOf::wdot_vf_ned2vf_rad_per_s2& wdot_vf_ned2vf_rad_per_s2,
        const _traits_::TypeOf::wgs84_location& wgs84_location,
        const _traits_::TypeOf::altitude_agl_m& altitude_agl_m,
        const _traits_::TypeOf::altitude_msl_m& altitude_msl_m,
        const _traits_::TypeOf::vf_pseudo_altitude_hae_wgs84_m& vf_pseudo_altitude_hae_wgs84_m,
        const _traits_::TypeOf::backyard_pseudo_altitude_hae_wgs84_m& backyard_pseudo_altitude_hae_wgs84_m,
        const _traits_::TypeOf::target_pseudo_altitude_hae_wgs84_m& target_pseudo_altitude_hae_wgs84_m,
        const _traits_::TypeOf::airspeed_true_m_per_s& airspeed_true_m_per_s,
        const _traits_::TypeOf::airspeed_indicated_m_per_s& airspeed_indicated_m_per_s,
        const _traits_::TypeOf::windspeed_ned_m_per_s& windspeed_ned_m_per_s,
        const _traits_::TypeOf::R_vf_from_ned& R_vf_from_ned,
        const _traits_::TypeOf::rph_vf_from_ned& rph_vf_from_ned,
        const _traits_::TypeOf::dynamic_pressure_Pa& dynamic_pressure_Pa,
        const _traits_::TypeOf::static_pressure_Pa& static_pressure_Pa,
        const _traits_::TypeOf::air_temperature_K& air_temperature_K,
        const _traits_::TypeOf::air_density_kg_per_m3& air_density_kg_per_m3,
        const _traits_::TypeOf::actuator_forces_N& actuator_forces_N,
        const _traits_::TypeOf::actuator_moments_Nm& actuator_moments_Nm,
        const _traits_::TypeOf::aero_forces_N& aero_forces_N,
        const _traits_::TypeOf::aero_moments_Nm& aero_moments_Nm,
        const _traits_::TypeOf::vrs_thrust_per_propeller_N& vrs_thrust_per_propeller_N,
        const _traits_::TypeOf::motor_rear_right_rpm& motor_rear_right_rpm,
        const _traits_::TypeOf::motor_rear_right_v_radial_m_per_s& motor_rear_right_v_radial_m_per_s,
        const _traits_::TypeOf::motor_rear_right_v_axial_m_per_s& motor_rear_right_v_axial_m_per_s,
        const _traits_::TypeOf::motor_rear_right_prop_torque_Nm& motor_rear_right_prop_torque_Nm,
        const _traits_::TypeOf::motor_center_right_rpm& motor_center_right_rpm,
        const _traits_::TypeOf::motor_center_right_v_radial_m_per_s& motor_center_right_v_radial_m_per_s,
        const _traits_::TypeOf::motor_center_right_v_axial_m_per_s& motor_center_right_v_axial_m_per_s,
        const _traits_::TypeOf::motor_center_right_prop_torque_Nm& motor_center_right_prop_torque_Nm,
        const _traits_::TypeOf::motor_front_right_rpm& motor_front_right_rpm,
        const _traits_::TypeOf::motor_front_right_v_radial_m_per_s& motor_front_right_v_radial_m_per_s,
        const _traits_::TypeOf::motor_front_right_v_axial_m_per_s& motor_front_right_v_axial_m_per_s,
        const _traits_::TypeOf::motor_front_right_prop_torque_Nm& motor_front_right_prop_torque_Nm,
        const _traits_::TypeOf::motor_front_left_rpm& motor_front_left_rpm,
        const _traits_::TypeOf::motor_front_left_v_radial_m_per_s& motor_front_left_v_radial_m_per_s,
        const _traits_::TypeOf::motor_front_left_v_axial_m_per_s& motor_front_left_v_axial_m_per_s,
        const _traits_::TypeOf::motor_front_left_prop_torque_Nm& motor_front_left_prop_torque_Nm,
        const _traits_::TypeOf::motor_center_left_rpm& motor_center_left_rpm,
        const _traits_::TypeOf::motor_center_left_v_radial_m_per_s& motor_center_left_v_radial_m_per_s,
        const _traits_::TypeOf::motor_center_left_v_axial_m_per_s& motor_center_left_v_axial_m_per_s,
        const _traits_::TypeOf::motor_center_left_prop_torque_Nm& motor_center_left_prop_torque_Nm,
        const _traits_::TypeOf::motor_rear_left_rpm& motor_rear_left_rpm,
        const _traits_::TypeOf::motor_rear_left_v_radial_m_per_s& motor_rear_left_v_radial_m_per_s,
        const _traits_::TypeOf::motor_rear_left_v_axial_m_per_s& motor_rear_left_v_axial_m_per_s,
        const _traits_::TypeOf::motor_rear_left_prop_torque_Nm& motor_rear_left_prop_torque_Nm,
        const _traits_::TypeOf::rudderon_left_surface_deflection_rad& rudderon_left_surface_deflection_rad,
        const _traits_::TypeOf::rudderon_left_floating_shaft_angle_rad& rudderon_left_floating_shaft_angle_rad,
        const _traits_::TypeOf::rudderon_left_shaft_angle_rad& rudderon_left_shaft_angle_rad,
        const _traits_::TypeOf::rudderon_right_surface_deflection_rad& rudderon_right_surface_deflection_rad,
        const _traits_::TypeOf::rudderon_right_floating_shaft_angle_rad& rudderon_right_floating_shaft_angle_rad,
        const _traits_::TypeOf::rudderon_right_shaft_angle_rad& rudderon_right_shaft_angle_rad,
        const _traits_::TypeOf::elevon_left_surface_deflection_rad& elevon_left_surface_deflection_rad,
        const _traits_::TypeOf::elevon_left_floating_shaft_angle_rad& elevon_left_floating_shaft_angle_rad,
        const _traits_::TypeOf::elevon_left_shaft_angle_rad& elevon_left_shaft_angle_rad,
        const _traits_::TypeOf::elevon_right_surface_deflection_rad& elevon_right_surface_deflection_rad,
        const _traits_::TypeOf::elevon_right_floating_shaft_angle_rad& elevon_right_floating_shaft_angle_rad,
        const _traits_::TypeOf::elevon_right_shaft_angle_rad& elevon_right_shaft_angle_rad,
        const _traits_::TypeOf::landing_legs_touching_ground& landing_legs_touching_ground,
        const _traits_::TypeOf::force_moment_components& force_moment_components,
        const allocator_type& allocator = allocator_type()) :
        id{id, allocator},
        timestamp_us{timestamp_us},
        v_vf_ned2vf_m_per_s{v_vf_ned2vf_m_per_s, allocator},
        v_ned_ned2vf_m_per_s{v_ned_ned2vf_m_per_s, allocator},
        ground_speed_m_per_s{ground_speed_m_per_s},
        w_vf_ned2vf_rad_per_s{w_vf_ned2vf_rad_per_s, allocator},
        a_vf_ned2vf_m_per_s2{a_vf_ned2vf_m_per_s2, allocator},
        wdot_vf_ned2vf_rad_per_s2{wdot_vf_ned2vf_rad_per_s2, allocator},
        wgs84_location{wgs84_location, allocator},
        altitude_agl_m{altitude_agl_m},
        altitude_msl_m{altitude_msl_m},
        vf_pseudo_altitude_hae_wgs84_m{vf_pseudo_altitude_hae_wgs84_m},
        backyard_pseudo_altitude_hae_wgs84_m{backyard_pseudo_altitude_hae_wgs84_m},
        target_pseudo_altitude_hae_wgs84_m{target_pseudo_altitude_hae_wgs84_m},
        airspeed_true_m_per_s{airspeed_true_m_per_s},
        airspeed_indicated_m_per_s{airspeed_indicated_m_per_s},
        windspeed_ned_m_per_s{windspeed_ned_m_per_s, allocator},
        R_vf_from_ned{R_vf_from_ned, allocator},
        rph_vf_from_ned{rph_vf_from_ned, allocator},
        dynamic_pressure_Pa{dynamic_pressure_Pa},
        static_pressure_Pa{static_pressure_Pa},
        air_temperature_K{air_temperature_K},
        air_density_kg_per_m3{air_density_kg_per_m3},
        actuator_forces_N{actuator_forces_N, allocator},
        actuator_moments_Nm{actuator_moments_Nm, allocator},
        aero_forces_N{aero_forces_N, allocator},
        aero_moments_Nm{aero_moments_Nm, allocator},
        vrs_thrust_per_propeller_N{vrs_thrust_per_propeller_N, allocator},
        motor_rear_right_rpm{motor_rear_right_rpm},
        motor_rear_right_v_radial_m_per_s{motor_rear_right_v_radial_m_per_s},
        motor_rear_right_v_axial_m_per_s{motor_rear_right_v_axial_m_per_s},
        motor_rear_right_prop_torque_Nm{motor_rear_right_prop_torque_Nm},
        motor_center_right_rpm{motor_center_right_rpm},
        motor_center_right_v_radial_m_per_s{motor_center_right_v_radial_m_per_s},
        motor_center_right_v_axial_m_per_s{motor_center_right_v_axial_m_per_s},
        motor_center_right_prop_torque_Nm{motor_center_right_prop_torque_Nm},
        motor_front_right_rpm{motor_front_right_rpm},
        motor_front_right_v_radial_m_per_s{motor_front_right_v_radial_m_per_s},
        motor_front_right_v_axial_m_per_s{motor_front_right_v_axial_m_per_s},
        motor_front_right_prop_torque_Nm{motor_front_right_prop_torque_Nm},
        motor_front_left_rpm{motor_front_left_rpm},
        motor_front_left_v_radial_m_per_s{motor_front_left_v_radial_m_per_s},
        motor_front_left_v_axial_m_per_s{motor_front_left_v_axial_m_per_s},
        motor_front_left_prop_torque_Nm{motor_front_left_prop_torque_Nm},
        motor_center_left_rpm{motor_center_left_rpm},
        motor_center_left_v_radial_m_per_s{motor_center_left_v_radial_m_per_s},
        motor_center_left_v_axial_m_per_s{motor_center_left_v_axial_m_per_s},
        motor_center_left_prop_torque_Nm{motor_center_left_prop_torque_Nm},
        motor_rear_left_rpm{motor_rear_left_rpm},
        motor_rear_left_v_radial_m_per_s{motor_rear_left_v_radial_m_per_s},
        motor_rear_left_v_axial_m_per_s{motor_rear_left_v_axial_m_per_s},
        motor_rear_left_prop_torque_Nm{motor_rear_left_prop_torque_Nm},
        rudderon_left_surface_deflection_rad{rudderon_left_surface_deflection_rad},
        rudderon_left_floating_shaft_angle_rad{rudderon_left_floating_shaft_angle_rad},
        rudderon_left_shaft_angle_rad{rudderon_left_shaft_angle_rad},
        rudderon_right_surface_deflection_rad{rudderon_right_surface_deflection_rad},
        rudderon_right_floating_shaft_angle_rad{rudderon_right_floating_shaft_angle_rad},
        rudderon_right_shaft_angle_rad{rudderon_right_shaft_angle_rad},
        elevon_left_surface_deflection_rad{elevon_left_surface_deflection_rad},
        elevon_left_floating_shaft_angle_rad{elevon_left_floating_shaft_angle_rad},
        elevon_left_shaft_angle_rad{elevon_left_shaft_angle_rad},
        elevon_right_surface_deflection_rad{elevon_right_surface_deflection_rad},
        elevon_right_floating_shaft_angle_rad{elevon_right_floating_shaft_angle_rad},
        elevon_right_shaft_angle_rad{elevon_right_shaft_angle_rad},
        landing_legs_touching_ground{landing_legs_touching_ground, allocator},
        force_moment_components{force_moment_components, allocator}
    {
        (void)allocator; // avoid unused param warning
    }

    // Copy constructor
    GroundTruthState_0_1(const GroundTruthState_0_1&) = default;

    // Copy constructor with allocator
    GroundTruthState_0_1(const GroundTruthState_0_1& rhs, const allocator_type& allocator) :
        id{rhs.id, allocator},
        timestamp_us{rhs.timestamp_us},
        v_vf_ned2vf_m_per_s{rhs.v_vf_ned2vf_m_per_s, allocator},
        v_ned_ned2vf_m_per_s{rhs.v_ned_ned2vf_m_per_s, allocator},
        ground_speed_m_per_s{rhs.ground_speed_m_per_s},
        w_vf_ned2vf_rad_per_s{rhs.w_vf_ned2vf_rad_per_s, allocator},
        a_vf_ned2vf_m_per_s2{rhs.a_vf_ned2vf_m_per_s2, allocator},
        wdot_vf_ned2vf_rad_per_s2{rhs.wdot_vf_ned2vf_rad_per_s2, allocator},
        wgs84_location{rhs.wgs84_location, allocator},
        altitude_agl_m{rhs.altitude_agl_m},
        altitude_msl_m{rhs.altitude_msl_m},
        vf_pseudo_altitude_hae_wgs84_m{rhs.vf_pseudo_altitude_hae_wgs84_m},
        backyard_pseudo_altitude_hae_wgs84_m{rhs.backyard_pseudo_altitude_hae_wgs84_m},
        target_pseudo_altitude_hae_wgs84_m{rhs.target_pseudo_altitude_hae_wgs84_m},
        airspeed_true_m_per_s{rhs.airspeed_true_m_per_s},
        airspeed_indicated_m_per_s{rhs.airspeed_indicated_m_per_s},
        windspeed_ned_m_per_s{rhs.windspeed_ned_m_per_s, allocator},
        R_vf_from_ned{rhs.R_vf_from_ned, allocator},
        rph_vf_from_ned{rhs.rph_vf_from_ned, allocator},
        dynamic_pressure_Pa{rhs.dynamic_pressure_Pa},
        static_pressure_Pa{rhs.static_pressure_Pa},
        air_temperature_K{rhs.air_temperature_K},
        air_density_kg_per_m3{rhs.air_density_kg_per_m3},
        actuator_forces_N{rhs.actuator_forces_N, allocator},
        actuator_moments_Nm{rhs.actuator_moments_Nm, allocator},
        aero_forces_N{rhs.aero_forces_N, allocator},
        aero_moments_Nm{rhs.aero_moments_Nm, allocator},
        vrs_thrust_per_propeller_N{rhs.vrs_thrust_per_propeller_N, allocator},
        motor_rear_right_rpm{rhs.motor_rear_right_rpm},
        motor_rear_right_v_radial_m_per_s{rhs.motor_rear_right_v_radial_m_per_s},
        motor_rear_right_v_axial_m_per_s{rhs.motor_rear_right_v_axial_m_per_s},
        motor_rear_right_prop_torque_Nm{rhs.motor_rear_right_prop_torque_Nm},
        motor_center_right_rpm{rhs.motor_center_right_rpm},
        motor_center_right_v_radial_m_per_s{rhs.motor_center_right_v_radial_m_per_s},
        motor_center_right_v_axial_m_per_s{rhs.motor_center_right_v_axial_m_per_s},
        motor_center_right_prop_torque_Nm{rhs.motor_center_right_prop_torque_Nm},
        motor_front_right_rpm{rhs.motor_front_right_rpm},
        motor_front_right_v_radial_m_per_s{rhs.motor_front_right_v_radial_m_per_s},
        motor_front_right_v_axial_m_per_s{rhs.motor_front_right_v_axial_m_per_s},
        motor_front_right_prop_torque_Nm{rhs.motor_front_right_prop_torque_Nm},
        motor_front_left_rpm{rhs.motor_front_left_rpm},
        motor_front_left_v_radial_m_per_s{rhs.motor_front_left_v_radial_m_per_s},
        motor_front_left_v_axial_m_per_s{rhs.motor_front_left_v_axial_m_per_s},
        motor_front_left_prop_torque_Nm{rhs.motor_front_left_prop_torque_Nm},
        motor_center_left_rpm{rhs.motor_center_left_rpm},
        motor_center_left_v_radial_m_per_s{rhs.motor_center_left_v_radial_m_per_s},
        motor_center_left_v_axial_m_per_s{rhs.motor_center_left_v_axial_m_per_s},
        motor_center_left_prop_torque_Nm{rhs.motor_center_left_prop_torque_Nm},
        motor_rear_left_rpm{rhs.motor_rear_left_rpm},
        motor_rear_left_v_radial_m_per_s{rhs.motor_rear_left_v_radial_m_per_s},
        motor_rear_left_v_axial_m_per_s{rhs.motor_rear_left_v_axial_m_per_s},
        motor_rear_left_prop_torque_Nm{rhs.motor_rear_left_prop_torque_Nm},
        rudderon_left_surface_deflection_rad{rhs.rudderon_left_surface_deflection_rad},
        rudderon_left_floating_shaft_angle_rad{rhs.rudderon_left_floating_shaft_angle_rad},
        rudderon_left_shaft_angle_rad{rhs.rudderon_left_shaft_angle_rad},
        rudderon_right_surface_deflection_rad{rhs.rudderon_right_surface_deflection_rad},
        rudderon_right_floating_shaft_angle_rad{rhs.rudderon_right_floating_shaft_angle_rad},
        rudderon_right_shaft_angle_rad{rhs.rudderon_right_shaft_angle_rad},
        elevon_left_surface_deflection_rad{rhs.elevon_left_surface_deflection_rad},
        elevon_left_floating_shaft_angle_rad{rhs.elevon_left_floating_shaft_angle_rad},
        elevon_left_shaft_angle_rad{rhs.elevon_left_shaft_angle_rad},
        elevon_right_surface_deflection_rad{rhs.elevon_right_surface_deflection_rad},
        elevon_right_floating_shaft_angle_rad{rhs.elevon_right_floating_shaft_angle_rad},
        elevon_right_shaft_angle_rad{rhs.elevon_right_shaft_angle_rad},
        landing_legs_touching_ground{rhs.landing_legs_touching_ground, allocator},
        force_moment_components{rhs.force_moment_components, allocator}
    
    {
        (void)rhs;       // avoid unused param warning
        (void)allocator; // avoid unused param warning
    }

    // Move constructor
    GroundTruthState_0_1(GroundTruthState_0_1&&) = default;

    // Move constructor with allocator
    GroundTruthState_0_1(GroundTruthState_0_1&& rhs, const allocator_type& allocator) :
        id{std::move(rhs.id), allocator},
        timestamp_us{std::move(rhs.timestamp_us)},
        v_vf_ned2vf_m_per_s{std::move(rhs.v_vf_ned2vf_m_per_s), allocator},
        v_ned_ned2vf_m_per_s{std::move(rhs.v_ned_ned2vf_m_per_s), allocator},
        ground_speed_m_per_s{std::move(rhs.ground_speed_m_per_s)},
        w_vf_ned2vf_rad_per_s{std::move(rhs.w_vf_ned2vf_rad_per_s), allocator},
        a_vf_ned2vf_m_per_s2{std::move(rhs.a_vf_ned2vf_m_per_s2), allocator},
        wdot_vf_ned2vf_rad_per_s2{std::move(rhs.wdot_vf_ned2vf_rad_per_s2), allocator},
        wgs84_location{std::move(rhs.wgs84_location), allocator},
        altitude_agl_m{std::move(rhs.altitude_agl_m)},
        altitude_msl_m{std::move(rhs.altitude_msl_m)},
        vf_pseudo_altitude_hae_wgs84_m{std::move(rhs.vf_pseudo_altitude_hae_wgs84_m)},
        backyard_pseudo_altitude_hae_wgs84_m{std::move(rhs.backyard_pseudo_altitude_hae_wgs84_m)},
        target_pseudo_altitude_hae_wgs84_m{std::move(rhs.target_pseudo_altitude_hae_wgs84_m)},
        airspeed_true_m_per_s{std::move(rhs.airspeed_true_m_per_s)},
        airspeed_indicated_m_per_s{std::move(rhs.airspeed_indicated_m_per_s)},
        windspeed_ned_m_per_s{std::move(rhs.windspeed_ned_m_per_s), allocator},
        R_vf_from_ned{std::move(rhs.R_vf_from_ned), allocator},
        rph_vf_from_ned{std::move(rhs.rph_vf_from_ned), allocator},
        dynamic_pressure_Pa{std::move(rhs.dynamic_pressure_Pa)},
        static_pressure_Pa{std::move(rhs.static_pressure_Pa)},
        air_temperature_K{std::move(rhs.air_temperature_K)},
        air_density_kg_per_m3{std::move(rhs.air_density_kg_per_m3)},
        actuator_forces_N{std::move(rhs.actuator_forces_N), allocator},
        actuator_moments_Nm{std::move(rhs.actuator_moments_Nm), allocator},
        aero_forces_N{std::move(rhs.aero_forces_N), allocator},
        aero_moments_Nm{std::move(rhs.aero_moments_Nm), allocator},
        vrs_thrust_per_propeller_N{std::move(rhs.vrs_thrust_per_propeller_N), allocator},
        motor_rear_right_rpm{std::move(rhs.motor_rear_right_rpm)},
        motor_rear_right_v_radial_m_per_s{std::move(rhs.motor_rear_right_v_radial_m_per_s)},
        motor_rear_right_v_axial_m_per_s{std::move(rhs.motor_rear_right_v_axial_m_per_s)},
        motor_rear_right_prop_torque_Nm{std::move(rhs.motor_rear_right_prop_torque_Nm)},
        motor_center_right_rpm{std::move(rhs.motor_center_right_rpm)},
        motor_center_right_v_radial_m_per_s{std::move(rhs.motor_center_right_v_radial_m_per_s)},
        motor_center_right_v_axial_m_per_s{std::move(rhs.motor_center_right_v_axial_m_per_s)},
        motor_center_right_prop_torque_Nm{std::move(rhs.motor_center_right_prop_torque_Nm)},
        motor_front_right_rpm{std::move(rhs.motor_front_right_rpm)},
        motor_front_right_v_radial_m_per_s{std::move(rhs.motor_front_right_v_radial_m_per_s)},
        motor_front_right_v_axial_m_per_s{std::move(rhs.motor_front_right_v_axial_m_per_s)},
        motor_front_right_prop_torque_Nm{std::move(rhs.motor_front_right_prop_torque_Nm)},
        motor_front_left_rpm{std::move(rhs.motor_front_left_rpm)},
        motor_front_left_v_radial_m_per_s{std::move(rhs.motor_front_left_v_radial_m_per_s)},
        motor_front_left_v_axial_m_per_s{std::move(rhs.motor_front_left_v_axial_m_per_s)},
        motor_front_left_prop_torque_Nm{std::move(rhs.motor_front_left_prop_torque_Nm)},
        motor_center_left_rpm{std::move(rhs.motor_center_left_rpm)},
        motor_center_left_v_radial_m_per_s{std::move(rhs.motor_center_left_v_radial_m_per_s)},
        motor_center_left_v_axial_m_per_s{std::move(rhs.motor_center_left_v_axial_m_per_s)},
        motor_center_left_prop_torque_Nm{std::move(rhs.motor_center_left_prop_torque_Nm)},
        motor_rear_left_rpm{std::move(rhs.motor_rear_left_rpm)},
        motor_rear_left_v_radial_m_per_s{std::move(rhs.motor_rear_left_v_radial_m_per_s)},
        motor_rear_left_v_axial_m_per_s{std::move(rhs.motor_rear_left_v_axial_m_per_s)},
        motor_rear_left_prop_torque_Nm{std::move(rhs.motor_rear_left_prop_torque_Nm)},
        rudderon_left_surface_deflection_rad{std::move(rhs.rudderon_left_surface_deflection_rad)},
        rudderon_left_floating_shaft_angle_rad{std::move(rhs.rudderon_left_floating_shaft_angle_rad)},
        rudderon_left_shaft_angle_rad{std::move(rhs.rudderon_left_shaft_angle_rad)},
        rudderon_right_surface_deflection_rad{std::move(rhs.rudderon_right_surface_deflection_rad)},
        rudderon_right_floating_shaft_angle_rad{std::move(rhs.rudderon_right_floating_shaft_angle_rad)},
        rudderon_right_shaft_angle_rad{std::move(rhs.rudderon_right_shaft_angle_rad)},
        elevon_left_surface_deflection_rad{std::move(rhs.elevon_left_surface_deflection_rad)},
        elevon_left_floating_shaft_angle_rad{std::move(rhs.elevon_left_floating_shaft_angle_rad)},
        elevon_left_shaft_angle_rad{std::move(rhs.elevon_left_shaft_angle_rad)},
        elevon_right_surface_deflection_rad{std::move(rhs.elevon_right_surface_deflection_rad)},
        elevon_right_floating_shaft_angle_rad{std::move(rhs.elevon_right_floating_shaft_angle_rad)},
        elevon_right_shaft_angle_rad{std::move(rhs.elevon_right_shaft_angle_rad)},
        landing_legs_touching_ground{std::move(rhs.landing_legs_touching_ground), allocator},
        force_moment_components{std::move(rhs.force_moment_components), allocator}
    {
        (void)rhs;       // avoid unused param warning
        (void)allocator; // avoid unused param warning
    }

    // Copy assignment
    GroundTruthState_0_1& operator=(const GroundTruthState_0_1&) = default;

    // Move assignment
    GroundTruthState_0_1& operator=(GroundTruthState_0_1&&) = default;

    // Destructor
    ~GroundTruthState_0_1() = default;
    
    // +----------------------------------------------------------------------+
    // | FIELDS
    // +----------------------------------------------------------------------+
    ///
    /// Required identifier for all input/output messages.
    ///
    _traits_::TypeOf::id id;
    ///
    /// The timestamp in microseconds at which the values in this packet were
    /// calculated.
    ///
    _traits_::TypeOf::timestamp_us timestamp_us;
    ///
    /// Velocity in the vehicle-fixed frame in meters per second.
    ///
    _traits_::TypeOf::v_vf_ned2vf_m_per_s v_vf_ned2vf_m_per_s;
    ///
    /// Velocity in the NED frame in meters per second.
    ///
    _traits_::TypeOf::v_ned_ned2vf_m_per_s v_ned_ned2vf_m_per_s;
    ///
    /// Ground speed in meters per second
    ///
    _traits_::TypeOf::ground_speed_m_per_s ground_speed_m_per_s;
    ///
    /// Angular velocity in the vehicle-fixed frame in radians per second.
    ///
    _traits_::TypeOf::w_vf_ned2vf_rad_per_s w_vf_ned2vf_rad_per_s;
    ///
    /// Acceleration in the vehicle-fixed frame in meters per second squared.
    ///
    _traits_::TypeOf::a_vf_ned2vf_m_per_s2 a_vf_ned2vf_m_per_s2;
    ///
    /// Angular acceleration in the vehicle-fixed frame in radians per second squared.
    ///
    _traits_::TypeOf::wdot_vf_ned2vf_rad_per_s2 wdot_vf_ned2vf_rad_per_s2;
    ///
    /// Latitude, longitude and height above the WGS84 ellipsoid.
    ///
    _traits_::TypeOf::wgs84_location wgs84_location;
    ///
    /// Altitude above ground in meters.
    ///
    _traits_::TypeOf::altitude_agl_m altitude_agl_m;
    ///
    /// Altitude above sea level in meters derived from pressure.
    ///
    _traits_::TypeOf::altitude_msl_m altitude_msl_m;
    ///
    /// Altitude above backyard, pseudo means C1 continuous (meters).
    ///
    _traits_::TypeOf::vf_pseudo_altitude_hae_wgs84_m vf_pseudo_altitude_hae_wgs84_m;
    ///
    /// Backyard ref altitude, height above ellipsoid (meters).
    ///
    _traits_::TypeOf::backyard_pseudo_altitude_hae_wgs84_m backyard_pseudo_altitude_hae_wgs84_m;
    ///
    /// Target point altitude, height above ellipsoid (meters).
    ///
    _traits_::TypeOf::target_pseudo_altitude_hae_wgs84_m target_pseudo_altitude_hae_wgs84_m;
    ///
    /// True airspeed in meters per second.
    ///
    _traits_::TypeOf::airspeed_true_m_per_s airspeed_true_m_per_s;
    ///
    /// Indicated airspeed in meters per second.
    ///
    _traits_::TypeOf::airspeed_indicated_m_per_s airspeed_indicated_m_per_s;
    ///
    /// Windspeed in the NED frame in meters per second.
    ///
    _traits_::TypeOf::windspeed_ned_m_per_s windspeed_ned_m_per_s;
    ///
    /// Rotation matrix that maps a vector into the vehicle-fixed frame from the NED
    /// frame.
    ///
    _traits_::TypeOf::R_vf_from_ned R_vf_from_ned;
    ///
    /// Roll-pitch-heading rotation to the vehicle-fixed frame from the NED frame.
    ///
    _traits_::TypeOf::rph_vf_from_ned rph_vf_from_ned;
    ///
    /// Dynamic pressure in pascals.
    ///
    _traits_::TypeOf::dynamic_pressure_Pa dynamic_pressure_Pa;
    ///
    /// Static pressure in pascals.
    ///
    _traits_::TypeOf::static_pressure_Pa static_pressure_Pa;
    ///
    /// Air temperature in Kelvin.
    ///
    _traits_::TypeOf::air_temperature_K air_temperature_K;
    ///
    /// Air density in kilograms per cubic meter.
    ///
    _traits_::TypeOf::air_density_kg_per_m3 air_density_kg_per_m3;
    ///
    /// Actuator forces acting on the vehicle in the VTOL frame
    ///
    _traits_::TypeOf::actuator_forces_N actuator_forces_N;
    ///
    /// Actuator moments acting on the vehicle in the VTOL frame
    ///
    _traits_::TypeOf::actuator_moments_Nm actuator_moments_Nm;
    ///
    /// Aero forces acting on the vehicle in the VTOL frame
    ///
    _traits_::TypeOf::aero_forces_N aero_forces_N;
    ///
    /// Aero moments acting on the vehicle in the VTOL frame
    ///
    _traits_::TypeOf::aero_moments_Nm aero_moments_Nm;
    ///
    /// Unsteady thrust deviation of each propeller. # The order follows the loading
    /// order in the simulator.json specification. FIXME: use static map for the
    /// ordering.
    ///
    _traits_::TypeOf::vrs_thrust_per_propeller_N vrs_thrust_per_propeller_N;
    ///
    /// The motor rear right rpm
    ///
    _traits_::TypeOf::motor_rear_right_rpm motor_rear_right_rpm;
    ///
    /// Freestream radial airspeed at the rear right propeller, in m/s. "Freestream" =
    /// "prop wash effects and other flow acceleration effects are NOT included. Angular
    /// velocity effects are included". "Radial" = "on the propeller plane & in absolute
    /// value". Non-negative by definition.
    ///
    _traits_::TypeOf::motor_rear_right_v_radial_m_per_s motor_rear_right_v_radial_m_per_s;
    ///
    /// Freestream axial airspeed at the rear right propeller, in m/s. "Freestream" =
    /// "prop wash effects and other flow acceleration effects are NOT included. Angular
    /// velocity effects are included". "Axial" = "along the propeller axis". Propeller
    /// axis is along the direction of positive thrust, i.e. axial airspeed is positive
    /// if flow goes into the propeller.
    ///
    _traits_::TypeOf::motor_rear_right_v_axial_m_per_s motor_rear_right_v_axial_m_per_s;
    ///
    /// The rear right propellor aerodynamic resistance torque, in N-m.
    ///
    _traits_::TypeOf::motor_rear_right_prop_torque_Nm motor_rear_right_prop_torque_Nm;
    ///
    /// The motor center right rpm
    ///
    _traits_::TypeOf::motor_center_right_rpm motor_center_right_rpm;
    ///
    /// Freestream radial airspeed at the center right propeller, in m/s. "Freestream"
    /// = "prop wash effects and other flow acceleration effects are NOT included.
    /// Angular velocity effects are included". "Radial" = "on the propeller plane & in
    /// absolute value". Non-negative by definition.
    ///
    _traits_::TypeOf::motor_center_right_v_radial_m_per_s motor_center_right_v_radial_m_per_s;
    ///
    /// Freestream axial airspeed at the center right propeller, in m/s. "Freestream"
    /// = "prop wash effects and other flow acceleration effects are NOT included.
    /// Angular velocity effects are included". "Axial" = "along the propeller axis".
    /// Propeller axis is along the direction of positive thrust, i.e. axial airspeed is
    /// positive if flow goes into the propeller.
    ///
    _traits_::TypeOf::motor_center_right_v_axial_m_per_s motor_center_right_v_axial_m_per_s;
    ///
    /// The center right propellor aerodynamic resistance torque, in N-m.
    ///
    _traits_::TypeOf::motor_center_right_prop_torque_Nm motor_center_right_prop_torque_Nm;
    ///
    /// The motor front right rpm
    ///
    _traits_::TypeOf::motor_front_right_rpm motor_front_right_rpm;
    ///
    /// Freestream radial airspeed at the front right propeller, in m/s. "Freestream"
    /// = "prop wash effects and other flow acceleration effects are NOT included.
    /// Angular velocity effects are included". "Radial" = "on the propeller plane & in
    /// absolute value". Non-negative by definition.
    ///
    _traits_::TypeOf::motor_front_right_v_radial_m_per_s motor_front_right_v_radial_m_per_s;
    ///
    /// Freestream axial airspeed at the front right propeller, in m/s. "Freestream" =
    /// "prop wash effects and other flow acceleration effects are NOT included. Angular
    /// velocity effects are included". "Axial" = "along the propeller axis". Propeller
    /// axis is along the direction of positive thrust, i.e. axial airspeed is positive
    /// if flow goes into the propeller.
    ///
    _traits_::TypeOf::motor_front_right_v_axial_m_per_s motor_front_right_v_axial_m_per_s;
    ///
    /// The front right propellor aerodynamic resistance torque, in N-m.
    ///
    _traits_::TypeOf::motor_front_right_prop_torque_Nm motor_front_right_prop_torque_Nm;
    ///
    /// The motor front left rpm
    ///
    _traits_::TypeOf::motor_front_left_rpm motor_front_left_rpm;
    ///
    /// Freestream radial airspeed at the front left propeller, in m/s. "Freestream" =
    /// "prop wash effects and other flow acceleration effects are NOT included. Angular
    /// velocity effects are included". "Radial" = "on the propeller plane & in absolute
    /// value". Non-negative by definition.
    ///
    _traits_::TypeOf::motor_front_left_v_radial_m_per_s motor_front_left_v_radial_m_per_s;
    ///
    /// Freestream axial airspeed at the front left propeller, in m/s. "Freestream" =
    /// "prop wash effects and other flow acceleration effects are NOT included. Angular
    /// velocity effects are included". "Axial" = "along the propeller axis". Propeller
    /// axis is along the direction of positive thrust, i.e. axial airspeed is positive
    /// if flow goes into the propeller.
    ///
    _traits_::TypeOf::motor_front_left_v_axial_m_per_s motor_front_left_v_axial_m_per_s;
    ///
    /// The front left propellor aerodynamic resistance torque, in N-m.
    ///
    _traits_::TypeOf::motor_front_left_prop_torque_Nm motor_front_left_prop_torque_Nm;
    ///
    /// The motor center left rpm
    ///
    _traits_::TypeOf::motor_center_left_rpm motor_center_left_rpm;
    ///
    /// Freestream radial airspeed at the center left propeller, in m/s. "Freestream"
    /// = "prop wash effects and other flow acceleration effects are NOT included.
    /// Angular velocity effects are included". "Radial" = "on the propeller plane & in
    /// absolute value". Non-negative by definition.
    ///
    _traits_::TypeOf::motor_center_left_v_radial_m_per_s motor_center_left_v_radial_m_per_s;
    ///
    /// Freestream axial airspeed at the center left propeller, in m/s. "Freestream" =
    /// "prop wash effects and other flow acceleration effects are NOT included. Angular
    /// velocity effects are included". "Axial" = "along the propeller axis". Propeller
    /// axis is along the direction of positive thrust, i.e. axial airspeed is positive
    /// if flow goes into the propeller.
    ///
    _traits_::TypeOf::motor_center_left_v_axial_m_per_s motor_center_left_v_axial_m_per_s;
    ///
    /// The center left propellor aerodynamic resistance torque, in N-m.
    ///
    _traits_::TypeOf::motor_center_left_prop_torque_Nm motor_center_left_prop_torque_Nm;
    ///
    /// The motor rear left rpm
    ///
    _traits_::TypeOf::motor_rear_left_rpm motor_rear_left_rpm;
    ///
    /// Freestream radial airspeed at the rear left propeller, in m/s. "Freestream" =
    /// "prop wash effects and other flow acceleration effects are NOT included. Angular
    /// velocity effects are included". "Radial" = "on the propeller plane & in absolute
    /// value". Non-negative by definition.
    ///
    _traits_::TypeOf::motor_rear_left_v_radial_m_per_s motor_rear_left_v_radial_m_per_s;
    ///
    /// Freestream axial airspeed at the rear left propeller, in m/s. "Freestream" =
    /// "prop wash effects and other flow acceleration effects are NOT included. Angular
    /// velocity effects are included". "Axial" = "along the propeller axis". Propeller
    /// axis is along the direction of positive thrust, i.e. axial airspeed is positive
    /// if flow goes into the propeller.
    ///
    _traits_::TypeOf::motor_rear_left_v_axial_m_per_s motor_rear_left_v_axial_m_per_s;
    ///
    /// The rear left propellor aerodynamic resistance torque, in N-m.
    ///
    _traits_::TypeOf::motor_rear_left_prop_torque_Nm motor_rear_left_prop_torque_Nm;
    ///
    /// The left rudderon deflection, [rad]
    ///
    _traits_::TypeOf::rudderon_left_surface_deflection_rad rudderon_left_surface_deflection_rad;
    ///
    /// The left rudderon shaft angle, IF it were unpowered. [rad]
    ///
    _traits_::TypeOf::rudderon_left_floating_shaft_angle_rad rudderon_left_floating_shaft_angle_rad;
    ///
    /// The left rudderon shaft angle, [rad]
    ///
    _traits_::TypeOf::rudderon_left_shaft_angle_rad rudderon_left_shaft_angle_rad;
    ///
    /// The right rudderon deflection, [rad]
    ///
    _traits_::TypeOf::rudderon_right_surface_deflection_rad rudderon_right_surface_deflection_rad;
    ///
    /// The right rudderon shaft angle, IF it were unpowered. [rad]
    ///
    _traits_::TypeOf::rudderon_right_floating_shaft_angle_rad rudderon_right_floating_shaft_angle_rad;
    ///
    /// The right rudderon shaft angle, [rad]
    ///
    _traits_::TypeOf::rudderon_right_shaft_angle_rad rudderon_right_shaft_angle_rad;
    ///
    /// The left elevon deflection, [rad]
    ///
    _traits_::TypeOf::elevon_left_surface_deflection_rad elevon_left_surface_deflection_rad;
    ///
    /// The left elevon shaft angle, IF it were unpowered. [rad]
    ///
    _traits_::TypeOf::elevon_left_floating_shaft_angle_rad elevon_left_floating_shaft_angle_rad;
    ///
    /// The left elevon shaft angle, [rad]
    ///
    _traits_::TypeOf::elevon_left_shaft_angle_rad elevon_left_shaft_angle_rad;
    ///
    /// The right elevon deflection, [rad]
    ///
    _traits_::TypeOf::elevon_right_surface_deflection_rad elevon_right_surface_deflection_rad;
    ///
    /// The right elevon shaft angle, IF it were unpowered. [rad]
    ///
    _traits_::TypeOf::elevon_right_floating_shaft_angle_rad elevon_right_floating_shaft_angle_rad;
    ///
    /// The right elevon shaft angle, [rad]
    ///
    _traits_::TypeOf::elevon_right_shaft_angle_rad elevon_right_shaft_angle_rad;
    ///
    /// One boolean per landing leg. True if leg is touching the ground, false
    /// otherwise. Legs with squat switches (if any) are populated first, and legs
    /// without squat switches (if any) are populated last.
    ///
    _traits_::TypeOf::landing_legs_touching_ground landing_legs_touching_ground;
    ///
    /// The force and moment components for each physics module that is modeled within
    /// the state manager. Each of the components is expressed in the vehicle fixed
    /// frame, and about the vehicle fixed frame origin.
    ///
    _traits_::TypeOf::force_moment_components force_moment_components;
};


inline nunavut::support::SerializeResult serialize(const GroundTruthState_0_1& obj,
                                                   nunavut::support::bitspan out_buffer)
{
    const std::size_t capacity_bits = out_buffer.size();
    if ((static_cast<std::size_t>(capacity_bits)) < 8024UL)
    {
        return -nunavut::support::Error::SerializationBufferTooSmall;
    }
    // Notice that fields that are not an integer number of bytes long may overrun the space allocated for them
    // in the serialization buffer up to the next byte boundary. This is by design and is guaranteed to be safe.
    {   // vsdk.message.MessageId.0.1 id
        std::size_t _size_bytes0_ = 8UL;  // Nested object (max) size, in bytes.
        auto _subspan0_ = out_buffer.subspan(0U, _size_bytes0_ * 8U);
        if(not _subspan0_){
            return -_subspan0_.error();
        }
        auto _err0_ = serialize(obj.id, _subspan0_.value());
        if (not _err0_)
        {
            return _err0_;
        }
        _size_bytes0_ = _err0_.value();
        // It is assumed that we know the exact type of the serialized entity, hence we expect the size to match.
        out_buffer.add_offset(_size_bytes0_ * 8U);
        //
    }
    {   // saturated int64 timestamp_us
        // Saturation code not emitted -- native representation matches the serialized representation.
        const auto _result3_ = out_buffer.setIxx(obj.timestamp_us, 64U);
        if(not _result3_){
            return -_result3_.error();
        }
        out_buffer.add_offset(64U);
    }
    {
        const auto _result0_ = out_buffer.padAndMoveToAlignment(8U);
        if(not _result0_){
            return -_result0_.error();
        }
    }
    {   // vsdk.message.adn.vehicle.common.Vector3.0.1 v_vf_ned2vf_m_per_s
        std::size_t _size_bytes0_ = 24UL;  // Nested object (max) size, in bytes.
        auto _subspan0_ = out_buffer.subspan(0U, _size_bytes0_ * 8U);
        if(not _subspan0_){
            return -_subspan0_.error();
        }
        auto _err0_ = serialize(obj.v_vf_ned2vf_m_per_s, _subspan0_.value());
        if (not _err0_)
        {
            return _err0_;
        }
        _size_bytes0_ = _err0_.value();
        // It is assumed that we know the exact type of the serialized entity, hence we expect the size to match.
        out_buffer.add_offset(_size_bytes0_ * 8U);
        //
    }
    {
        const auto _result0_ = out_buffer.padAndMoveToAlignment(8U);
        if(not _result0_){
            return -_result0_.error();
        }
    }
    {   // vsdk.message.adn.vehicle.common.Vector3.0.1 v_ned_ned2vf_m_per_s
        std::size_t _size_bytes0_ = 24UL;  // Nested object (max) size, in bytes.
        auto _subspan0_ = out_buffer.subspan(0U, _size_bytes0_ * 8U);
        if(not _subspan0_){
            return -_subspan0_.error();
        }
        auto _err0_ = serialize(obj.v_ned_ned2vf_m_per_s, _subspan0_.value());
        if (not _err0_)
        {
            return _err0_;
        }
        _size_bytes0_ = _err0_.value();
        // It is assumed that we know the exact type of the serialized entity, hence we expect the size to match.
        out_buffer.add_offset(_size_bytes0_ * 8U);
        //
    }
    {   // saturated float32 ground_speed_m_per_s
        // Saturation code not emitted -- assume the native representation of float32 is conformant.
        static_assert(NUNAVUT_PLATFORM_IEEE754_FLOAT, "Native IEEE754 binary32 required. TODO: relax constraint");
        auto _result4_ = out_buffer.setF32(obj.ground_speed_m_per_s);
        if(not _result4_){
            return -_result4_.error();
        }
        out_buffer.add_offset(32U);
    }
    {
        const auto _result0_ = out_buffer.padAndMoveToAlignment(8U);
        if(not _result0_){
            return -_result0_.error();
        }
    }
    {   // vsdk.message.adn.vehicle.common.Vector3.0.1 w_vf_ned2vf_rad_per_s
        std::size_t _size_bytes0_ = 24UL;  // Nested object (max) size, in bytes.
        auto _subspan0_ = out_buffer.subspan(0U, _size_bytes0_ * 8U);
        if(not _subspan0_){
            return -_subspan0_.error();
        }
        auto _err0_ = serialize(obj.w_vf_ned2vf_rad_per_s, _subspan0_.value());
        if (not _err0_)
        {
            return _err0_;
        }
        _size_bytes0_ = _err0_.value();
        // It is assumed that we know the exact type of the serialized entity, hence we expect the size to match.
        out_buffer.add_offset(_size_bytes0_ * 8U);
        //
    }
    {
        const auto _result0_ = out_buffer.padAndMoveToAlignment(8U);
        if(not _result0_){
            return -_result0_.error();
        }
    }
    {   // vsdk.message.adn.vehicle.common.Vector3.0.1 a_vf_ned2vf_m_per_s2
        std::size_t _size_bytes0_ = 24UL;  // Nested object (max) size, in bytes.
        auto _subspan0_ = out_buffer.subspan(0U, _size_bytes0_ * 8U);
        if(not _subspan0_){
            return -_subspan0_.error();
        }
        auto _err0_ = serialize(obj.a_vf_ned2vf_m_per_s2, _subspan0_.value());
        if (not _err0_)
        {
            return _err0_;
        }
        _size_bytes0_ = _err0_.value();
        // It is assumed that we know the exact type of the serialized entity, hence we expect the size to match.
        out_buffer.add_offset(_size_bytes0_ * 8U);
        //
    }
    {
        const auto _result0_ = out_buffer.padAndMoveToAlignment(8U);
        if(not _result0_){
            return -_result0_.error();
        }
    }
    {   // vsdk.message.adn.vehicle.common.Vector3.0.1 wdot_vf_ned2vf_rad_per_s2
        std::size_t _size_bytes0_ = 24UL;  // Nested object (max) size, in bytes.
        auto _subspan0_ = out_buffer.subspan(0U, _size_bytes0_ * 8U);
        if(not _subspan0_){
            return -_subspan0_.error();
        }
        auto _err0_ = serialize(obj.wdot_vf_ned2vf_rad_per_s2, _subspan0_.value());
        if (not _err0_)
        {
            return _err0_;
        }
        _size_bytes0_ = _err0_.value();
        // It is assumed that we know the exact type of the serialized entity, hence we expect the size to match.
        out_buffer.add_offset(_size_bytes0_ * 8U);
        //
    }
    {
        const auto _result0_ = out_buffer.padAndMoveToAlignment(8U);
        if(not _result0_){
            return -_result0_.error();
        }
    }
    {   // vsdk.message.adn.vehicle.common.Wgs84Location.0.1 wgs84_location
        std::size_t _size_bytes0_ = 24UL;  // Nested object (max) size, in bytes.
        auto _subspan0_ = out_buffer.subspan(0U, _size_bytes0_ * 8U);
        if(not _subspan0_){
            return -_subspan0_.error();
        }
        auto _err0_ = serialize(obj.wgs84_location, _subspan0_.value());
        if (not _err0_)
        {
            return _err0_;
        }
        _size_bytes0_ = _err0_.value();
        // It is assumed that we know the exact type of the serialized entity, hence we expect the size to match.
        out_buffer.add_offset(_size_bytes0_ * 8U);
        //
    }
    {   // saturated float32 altitude_agl_m
        // Saturation code not emitted -- assume the native representation of float32 is conformant.
        static_assert(NUNAVUT_PLATFORM_IEEE754_FLOAT, "Native IEEE754 binary32 required. TODO: relax constraint");
        auto _result4_ = out_buffer.setF32(obj.altitude_agl_m);
        if(not _result4_){
            return -_result4_.error();
        }
        out_buffer.add_offset(32U);
    }
    {   // saturated float32 altitude_msl_m
        // Saturation code not emitted -- assume the native representation of float32 is conformant.
        static_assert(NUNAVUT_PLATFORM_IEEE754_FLOAT, "Native IEEE754 binary32 required. TODO: relax constraint");
        auto _result4_ = out_buffer.setF32(obj.altitude_msl_m);
        if(not _result4_){
            return -_result4_.error();
        }
        out_buffer.add_offset(32U);
    }
    {   // saturated float32 vf_pseudo_altitude_hae_wgs84_m
        // Saturation code not emitted -- assume the native representation of float32 is conformant.
        static_assert(NUNAVUT_PLATFORM_IEEE754_FLOAT, "Native IEEE754 binary32 required. TODO: relax constraint");
        auto _result4_ = out_buffer.setF32(obj.vf_pseudo_altitude_hae_wgs84_m);
        if(not _result4_){
            return -_result4_.error();
        }
        out_buffer.add_offset(32U);
    }
    {   // saturated float32 backyard_pseudo_altitude_hae_wgs84_m
        // Saturation code not emitted -- assume the native representation of float32 is conformant.
        static_assert(NUNAVUT_PLATFORM_IEEE754_FLOAT, "Native IEEE754 binary32 required. TODO: relax constraint");
        auto _result4_ = out_buffer.setF32(obj.backyard_pseudo_altitude_hae_wgs84_m);
        if(not _result4_){
            return -_result4_.error();
        }
        out_buffer.add_offset(32U);
    }
    {   // saturated float32 target_pseudo_altitude_hae_wgs84_m
        // Saturation code not emitted -- assume the native representation of float32 is conformant.
        static_assert(NUNAVUT_PLATFORM_IEEE754_FLOAT, "Native IEEE754 binary32 required. TODO: relax constraint");
        auto _result4_ = out_buffer.setF32(obj.target_pseudo_altitude_hae_wgs84_m);
        if(not _result4_){
            return -_result4_.error();
        }
        out_buffer.add_offset(32U);
    }
    {   // saturated float32 airspeed_true_m_per_s
        // Saturation code not emitted -- assume the native representation of float32 is conformant.
        static_assert(NUNAVUT_PLATFORM_IEEE754_FLOAT, "Native IEEE754 binary32 required. TODO: relax constraint");
        auto _result4_ = out_buffer.setF32(obj.airspeed_true_m_per_s);
        if(not _result4_){
            return -_result4_.error();
        }
        out_buffer.add_offset(32U);
    }
    {   // saturated float32 airspeed_indicated_m_per_s
        // Saturation code not emitted -- assume the native representation of float32 is conformant.
        static_assert(NUNAVUT_PLATFORM_IEEE754_FLOAT, "Native IEEE754 binary32 required. TODO: relax constraint");
        auto _result4_ = out_buffer.setF32(obj.airspeed_indicated_m_per_s);
        if(not _result4_){
            return -_result4_.error();
        }
        out_buffer.add_offset(32U);
    }
    {
        const auto _result0_ = out_buffer.padAndMoveToAlignment(8U);
        if(not _result0_){
            return -_result0_.error();
        }
    }
    {   // vsdk.message.adn.vehicle.common.Vector3.0.1 windspeed_ned_m_per_s
        std::size_t _size_bytes0_ = 24UL;  // Nested object (max) size, in bytes.
        auto _subspan0_ = out_buffer.subspan(0U, _size_bytes0_ * 8U);
        if(not _subspan0_){
            return -_subspan0_.error();
        }
        auto _err0_ = serialize(obj.windspeed_ned_m_per_s, _subspan0_.value());
        if (not _err0_)
        {
            return _err0_;
        }
        _size_bytes0_ = _err0_.value();
        // It is assumed that we know the exact type of the serialized entity, hence we expect the size to match.
        out_buffer.add_offset(_size_bytes0_ * 8U);
        //
    }
    {
        const auto _result0_ = out_buffer.padAndMoveToAlignment(8U);
        if(not _result0_){
            return -_result0_.error();
        }
    }
    {   // vsdk.message.adn.vehicle.common.Matrix3x3.0.1 R_vf_from_ned
        std::size_t _size_bytes0_ = 72UL;  // Nested object (max) size, in bytes.
        auto _subspan0_ = out_buffer.subspan(0U, _size_bytes0_ * 8U);
        if(not _subspan0_){
            return -_subspan0_.error();
        }
        auto _err0_ = serialize(obj.R_vf_from_ned, _subspan0_.value());
        if (not _err0_)
        {
            return _err0_;
        }
        _size_bytes0_ = _err0_.value();
        // It is assumed that we know the exact type of the serialized entity, hence we expect the size to match.
        out_buffer.add_offset(_size_bytes0_ * 8U);
        //
    }
    {
        const auto _result0_ = out_buffer.padAndMoveToAlignment(8U);
        if(not _result0_){
            return -_result0_.error();
        }
    }
    {   // vsdk.message.adn.vehicle.common.RollPitchHeading.0.1 rph_vf_from_ned
        std::size_t _size_bytes0_ = 24UL;  // Nested object (max) size, in bytes.
        auto _subspan0_ = out_buffer.subspan(0U, _size_bytes0_ * 8U);
        if(not _subspan0_){
            return -_subspan0_.error();
        }
        auto _err0_ = serialize(obj.rph_vf_from_ned, _subspan0_.value());
        if (not _err0_)
        {
            return _err0_;
        }
        _size_bytes0_ = _err0_.value();
        // It is assumed that we know the exact type of the serialized entity, hence we expect the size to match.
        out_buffer.add_offset(_size_bytes0_ * 8U);
        //
    }
    {   // saturated float32 dynamic_pressure_Pa
        // Saturation code not emitted -- assume the native representation of float32 is conformant.
        static_assert(NUNAVUT_PLATFORM_IEEE754_FLOAT, "Native IEEE754 binary32 required. TODO: relax constraint");
        auto _result4_ = out_buffer.setF32(obj.dynamic_pressure_Pa);
        if(not _result4_){
            return -_result4_.error();
        }
        out_buffer.add_offset(32U);
    }
    {   // saturated float32 static_pressure_Pa
        // Saturation code not emitted -- assume the native representation of float32 is conformant.
        static_assert(NUNAVUT_PLATFORM_IEEE754_FLOAT, "Native IEEE754 binary32 required. TODO: relax constraint");
        auto _result4_ = out_buffer.setF32(obj.static_pressure_Pa);
        if(not _result4_){
            return -_result4_.error();
        }
        out_buffer.add_offset(32U);
    }
    {   // saturated float32 air_temperature_K
        // Saturation code not emitted -- assume the native representation of float32 is conformant.
        static_assert(NUNAVUT_PLATFORM_IEEE754_FLOAT, "Native IEEE754 binary32 required. TODO: relax constraint");
        auto _result4_ = out_buffer.setF32(obj.air_temperature_K);
        if(not _result4_){
            return -_result4_.error();
        }
        out_buffer.add_offset(32U);
    }
    {   // saturated float32 air_density_kg_per_m3
        // Saturation code not emitted -- assume the native representation of float32 is conformant.
        static_assert(NUNAVUT_PLATFORM_IEEE754_FLOAT, "Native IEEE754 binary32 required. TODO: relax constraint");
        auto _result4_ = out_buffer.setF32(obj.air_density_kg_per_m3);
        if(not _result4_){
            return -_result4_.error();
        }
        out_buffer.add_offset(32U);
    }
    {
        const auto _result0_ = out_buffer.padAndMoveToAlignment(8U);
        if(not _result0_){
            return -_result0_.error();
        }
    }
    {   // vsdk.message.adn.vehicle.common.Vector3.0.1 actuator_forces_N
        std::size_t _size_bytes0_ = 24UL;  // Nested object (max) size, in bytes.
        auto _subspan0_ = out_buffer.subspan(0U, _size_bytes0_ * 8U);
        if(not _subspan0_){
            return -_subspan0_.error();
        }
        auto _err0_ = serialize(obj.actuator_forces_N, _subspan0_.value());
        if (not _err0_)
        {
            return _err0_;
        }
        _size_bytes0_ = _err0_.value();
        // It is assumed that we know the exact type of the serialized entity, hence we expect the size to match.
        out_buffer.add_offset(_size_bytes0_ * 8U);
        //
    }
    {
        const auto _result0_ = out_buffer.padAndMoveToAlignment(8U);
        if(not _result0_){
            return -_result0_.error();
        }
    }
    {   // vsdk.message.adn.vehicle.common.Vector3.0.1 actuator_moments_Nm
        std::size_t _size_bytes0_ = 24UL;  // Nested object (max) size, in bytes.
        auto _subspan0_ = out_buffer.subspan(0U, _size_bytes0_ * 8U);
        if(not _subspan0_){
            return -_subspan0_.error();
        }
        auto _err0_ = serialize(obj.actuator_moments_Nm, _subspan0_.value());
        if (not _err0_)
        {
            return _err0_;
        }
        _size_bytes0_ = _err0_.value();
        // It is assumed that we know the exact type of the serialized entity, hence we expect the size to match.
        out_buffer.add_offset(_size_bytes0_ * 8U);
        //
    }
    {
        const auto _result0_ = out_buffer.padAndMoveToAlignment(8U);
        if(not _result0_){
            return -_result0_.error();
        }
    }
    {   // vsdk.message.adn.vehicle.common.Vector3.0.1 aero_forces_N
        std::size_t _size_bytes0_ = 24UL;  // Nested object (max) size, in bytes.
        auto _subspan0_ = out_buffer.subspan(0U, _size_bytes0_ * 8U);
        if(not _subspan0_){
            return -_subspan0_.error();
        }
        auto _err0_ = serialize(obj.aero_forces_N, _subspan0_.value());
        if (not _err0_)
        {
            return _err0_;
        }
        _size_bytes0_ = _err0_.value();
        // It is assumed that we know the exact type of the serialized entity, hence we expect the size to match.
        out_buffer.add_offset(_size_bytes0_ * 8U);
        //
    }
    {
        const auto _result0_ = out_buffer.padAndMoveToAlignment(8U);
        if(not _result0_){
            return -_result0_.error();
        }
    }
    {   // vsdk.message.adn.vehicle.common.Vector3.0.1 aero_moments_Nm
        std::size_t _size_bytes0_ = 24UL;  // Nested object (max) size, in bytes.
        auto _subspan0_ = out_buffer.subspan(0U, _size_bytes0_ * 8U);
        if(not _subspan0_){
            return -_subspan0_.error();
        }
        auto _err0_ = serialize(obj.aero_moments_Nm, _subspan0_.value());
        if (not _err0_)
        {
            return _err0_;
        }
        _size_bytes0_ = _err0_.value();
        // It is assumed that we know the exact type of the serialized entity, hence we expect the size to match.
        out_buffer.add_offset(_size_bytes0_ * 8U);
        //
    }
    {   // saturated float64[<=6] vrs_thrust_per_propeller_N
        if (obj.vrs_thrust_per_propeller_N.size() > 6)
        {
            return -nunavut::support::Error::SerializationBadArrayLength;
        }
        // Array length prefix: truncated uint8
        const auto _result3_ = out_buffer.setUxx(obj.vrs_thrust_per_propeller_N.size(), 8U);
        if(not _result3_){
            return -_result3_.error();
        }
        out_buffer.add_offset(8U);
        for (std::size_t _index2_ = 0U; _index2_ < obj.vrs_thrust_per_propeller_N.size(); ++_index2_)
        {
            // Saturation code not emitted -- assume the native representation of float64 is conformant.
            static_assert(NUNAVUT_PLATFORM_IEEE754_DOUBLE, "Native IEEE754 binary64 required. TODO: relax constraint");
            auto _result4_ = out_buffer.setF64(obj.vrs_thrust_per_propeller_N[_index2_]);
            if(not _result4_){
                return -_result4_.error();
            }
            out_buffer.add_offset(64U);
        }
    }
    {   // saturated float32 motor_rear_right_rpm
        // Saturation code not emitted -- assume the native representation of float32 is conformant.
        static_assert(NUNAVUT_PLATFORM_IEEE754_FLOAT, "Native IEEE754 binary32 required. TODO: relax constraint");
        auto _result4_ = out_buffer.setF32(obj.motor_rear_right_rpm);
        if(not _result4_){
            return -_result4_.error();
        }
        out_buffer.add_offset(32U);
    }
    {   // saturated float32 motor_rear_right_v_radial_m_per_s
        // Saturation code not emitted -- assume the native representation of float32 is conformant.
        static_assert(NUNAVUT_PLATFORM_IEEE754_FLOAT, "Native IEEE754 binary32 required. TODO: relax constraint");
        auto _result4_ = out_buffer.setF32(obj.motor_rear_right_v_radial_m_per_s);
        if(not _result4_){
            return -_result4_.error();
        }
        out_buffer.add_offset(32U);
    }
    {   // saturated float32 motor_rear_right_v_axial_m_per_s
        // Saturation code not emitted -- assume the native representation of float32 is conformant.
        static_assert(NUNAVUT_PLATFORM_IEEE754_FLOAT, "Native IEEE754 binary32 required. TODO: relax constraint");
        auto _result4_ = out_buffer.setF32(obj.motor_rear_right_v_axial_m_per_s);
        if(not _result4_){
            return -_result4_.error();
        }
        out_buffer.add_offset(32U);
    }
    {   // saturated float32 motor_rear_right_prop_torque_Nm
        // Saturation code not emitted -- assume the native representation of float32 is conformant.
        static_assert(NUNAVUT_PLATFORM_IEEE754_FLOAT, "Native IEEE754 binary32 required. TODO: relax constraint");
        auto _result4_ = out_buffer.setF32(obj.motor_rear_right_prop_torque_Nm);
        if(not _result4_){
            return -_result4_.error();
        }
        out_buffer.add_offset(32U);
    }
    {   // saturated float32 motor_center_right_rpm
        // Saturation code not emitted -- assume the native representation of float32 is conformant.
        static_assert(NUNAVUT_PLATFORM_IEEE754_FLOAT, "Native IEEE754 binary32 required. TODO: relax constraint");
        auto _result4_ = out_buffer.setF32(obj.motor_center_right_rpm);
        if(not _result4_){
            return -_result4_.error();
        }
        out_buffer.add_offset(32U);
    }
    {   // saturated float32 motor_center_right_v_radial_m_per_s
        // Saturation code not emitted -- assume the native representation of float32 is conformant.
        static_assert(NUNAVUT_PLATFORM_IEEE754_FLOAT, "Native IEEE754 binary32 required. TODO: relax constraint");
        auto _result4_ = out_buffer.setF32(obj.motor_center_right_v_radial_m_per_s);
        if(not _result4_){
            return -_result4_.error();
        }
        out_buffer.add_offset(32U);
    }
    {   // saturated float32 motor_center_right_v_axial_m_per_s
        // Saturation code not emitted -- assume the native representation of float32 is conformant.
        static_assert(NUNAVUT_PLATFORM_IEEE754_FLOAT, "Native IEEE754 binary32 required. TODO: relax constraint");
        auto _result4_ = out_buffer.setF32(obj.motor_center_right_v_axial_m_per_s);
        if(not _result4_){
            return -_result4_.error();
        }
        out_buffer.add_offset(32U);
    }
    {   // saturated float32 motor_center_right_prop_torque_Nm
        // Saturation code not emitted -- assume the native representation of float32 is conformant.
        static_assert(NUNAVUT_PLATFORM_IEEE754_FLOAT, "Native IEEE754 binary32 required. TODO: relax constraint");
        auto _result4_ = out_buffer.setF32(obj.motor_center_right_prop_torque_Nm);
        if(not _result4_){
            return -_result4_.error();
        }
        out_buffer.add_offset(32U);
    }
    {   // saturated float32 motor_front_right_rpm
        // Saturation code not emitted -- assume the native representation of float32 is conformant.
        static_assert(NUNAVUT_PLATFORM_IEEE754_FLOAT, "Native IEEE754 binary32 required. TODO: relax constraint");
        auto _result4_ = out_buffer.setF32(obj.motor_front_right_rpm);
        if(not _result4_){
            return -_result4_.error();
        }
        out_buffer.add_offset(32U);
    }
    {   // saturated float32 motor_front_right_v_radial_m_per_s
        // Saturation code not emitted -- assume the native representation of float32 is conformant.
        static_assert(NUNAVUT_PLATFORM_IEEE754_FLOAT, "Native IEEE754 binary32 required. TODO: relax constraint");
        auto _result4_ = out_buffer.setF32(obj.motor_front_right_v_radial_m_per_s);
        if(not _result4_){
            return -_result4_.error();
        }
        out_buffer.add_offset(32U);
    }
    {   // saturated float32 motor_front_right_v_axial_m_per_s
        // Saturation code not emitted -- assume the native representation of float32 is conformant.
        static_assert(NUNAVUT_PLATFORM_IEEE754_FLOAT, "Native IEEE754 binary32 required. TODO: relax constraint");
        auto _result4_ = out_buffer.setF32(obj.motor_front_right_v_axial_m_per_s);
        if(not _result4_){
            return -_result4_.error();
        }
        out_buffer.add_offset(32U);
    }
    {   // saturated float32 motor_front_right_prop_torque_Nm
        // Saturation code not emitted -- assume the native representation of float32 is conformant.
        static_assert(NUNAVUT_PLATFORM_IEEE754_FLOAT, "Native IEEE754 binary32 required. TODO: relax constraint");
        auto _result4_ = out_buffer.setF32(obj.motor_front_right_prop_torque_Nm);
        if(not _result4_){
            return -_result4_.error();
        }
        out_buffer.add_offset(32U);
    }
    {   // saturated float32 motor_front_left_rpm
        // Saturation code not emitted -- assume the native representation of float32 is conformant.
        static_assert(NUNAVUT_PLATFORM_IEEE754_FLOAT, "Native IEEE754 binary32 required. TODO: relax constraint");
        auto _result4_ = out_buffer.setF32(obj.motor_front_left_rpm);
        if(not _result4_){
            return -_result4_.error();
        }
        out_buffer.add_offset(32U);
    }
    {   // saturated float32 motor_front_left_v_radial_m_per_s
        // Saturation code not emitted -- assume the native representation of float32 is conformant.
        static_assert(NUNAVUT_PLATFORM_IEEE754_FLOAT, "Native IEEE754 binary32 required. TODO: relax constraint");
        auto _result4_ = out_buffer.setF32(obj.motor_front_left_v_radial_m_per_s);
        if(not _result4_){
            return -_result4_.error();
        }
        out_buffer.add_offset(32U);
    }
    {   // saturated float32 motor_front_left_v_axial_m_per_s
        // Saturation code not emitted -- assume the native representation of float32 is conformant.
        static_assert(NUNAVUT_PLATFORM_IEEE754_FLOAT, "Native IEEE754 binary32 required. TODO: relax constraint");
        auto _result4_ = out_buffer.setF32(obj.motor_front_left_v_axial_m_per_s);
        if(not _result4_){
            return -_result4_.error();
        }
        out_buffer.add_offset(32U);
    }
    {   // saturated float32 motor_front_left_prop_torque_Nm
        // Saturation code not emitted -- assume the native representation of float32 is conformant.
        static_assert(NUNAVUT_PLATFORM_IEEE754_FLOAT, "Native IEEE754 binary32 required. TODO: relax constraint");
        auto _result4_ = out_buffer.setF32(obj.motor_front_left_prop_torque_Nm);
        if(not _result4_){
            return -_result4_.error();
        }
        out_buffer.add_offset(32U);
    }
    {   // saturated float32 motor_center_left_rpm
        // Saturation code not emitted -- assume the native representation of float32 is conformant.
        static_assert(NUNAVUT_PLATFORM_IEEE754_FLOAT, "Native IEEE754 binary32 required. TODO: relax constraint");
        auto _result4_ = out_buffer.setF32(obj.motor_center_left_rpm);
        if(not _result4_){
            return -_result4_.error();
        }
        out_buffer.add_offset(32U);
    }
    {   // saturated float32 motor_center_left_v_radial_m_per_s
        // Saturation code not emitted -- assume the native representation of float32 is conformant.
        static_assert(NUNAVUT_PLATFORM_IEEE754_FLOAT, "Native IEEE754 binary32 required. TODO: relax constraint");
        auto _result4_ = out_buffer.setF32(obj.motor_center_left_v_radial_m_per_s);
        if(not _result4_){
            return -_result4_.error();
        }
        out_buffer.add_offset(32U);
    }
    {   // saturated float32 motor_center_left_v_axial_m_per_s
        // Saturation code not emitted -- assume the native representation of float32 is conformant.
        static_assert(NUNAVUT_PLATFORM_IEEE754_FLOAT, "Native IEEE754 binary32 required. TODO: relax constraint");
        auto _result4_ = out_buffer.setF32(obj.motor_center_left_v_axial_m_per_s);
        if(not _result4_){
            return -_result4_.error();
        }
        out_buffer.add_offset(32U);
    }
    {   // saturated float32 motor_center_left_prop_torque_Nm
        // Saturation code not emitted -- assume the native representation of float32 is conformant.
        static_assert(NUNAVUT_PLATFORM_IEEE754_FLOAT, "Native IEEE754 binary32 required. TODO: relax constraint");
        auto _result4_ = out_buffer.setF32(obj.motor_center_left_prop_torque_Nm);
        if(not _result4_){
            return -_result4_.error();
        }
        out_buffer.add_offset(32U);
    }
    {   // saturated float32 motor_rear_left_rpm
        // Saturation code not emitted -- assume the native representation of float32 is conformant.
        static_assert(NUNAVUT_PLATFORM_IEEE754_FLOAT, "Native IEEE754 binary32 required. TODO: relax constraint");
        auto _result4_ = out_buffer.setF32(obj.motor_rear_left_rpm);
        if(not _result4_){
            return -_result4_.error();
        }
        out_buffer.add_offset(32U);
    }
    {   // saturated float32 motor_rear_left_v_radial_m_per_s
        // Saturation code not emitted -- assume the native representation of float32 is conformant.
        static_assert(NUNAVUT_PLATFORM_IEEE754_FLOAT, "Native IEEE754 binary32 required. TODO: relax constraint");
        auto _result4_ = out_buffer.setF32(obj.motor_rear_left_v_radial_m_per_s);
        if(not _result4_){
            return -_result4_.error();
        }
        out_buffer.add_offset(32U);
    }
    {   // saturated float32 motor_rear_left_v_axial_m_per_s
        // Saturation code not emitted -- assume the native representation of float32 is conformant.
        static_assert(NUNAVUT_PLATFORM_IEEE754_FLOAT, "Native IEEE754 binary32 required. TODO: relax constraint");
        auto _result4_ = out_buffer.setF32(obj.motor_rear_left_v_axial_m_per_s);
        if(not _result4_){
            return -_result4_.error();
        }
        out_buffer.add_offset(32U);
    }
    {   // saturated float32 motor_rear_left_prop_torque_Nm
        // Saturation code not emitted -- assume the native representation of float32 is conformant.
        static_assert(NUNAVUT_PLATFORM_IEEE754_FLOAT, "Native IEEE754 binary32 required. TODO: relax constraint");
        auto _result4_ = out_buffer.setF32(obj.motor_rear_left_prop_torque_Nm);
        if(not _result4_){
            return -_result4_.error();
        }
        out_buffer.add_offset(32U);
    }
    {   // saturated float32 rudderon_left_surface_deflection_rad
        // Saturation code not emitted -- assume the native representation of float32 is conformant.
        static_assert(NUNAVUT_PLATFORM_IEEE754_FLOAT, "Native IEEE754 binary32 required. TODO: relax constraint");
        auto _result4_ = out_buffer.setF32(obj.rudderon_left_surface_deflection_rad);
        if(not _result4_){
            return -_result4_.error();
        }
        out_buffer.add_offset(32U);
    }
    {   // saturated float32 rudderon_left_floating_shaft_angle_rad
        // Saturation code not emitted -- assume the native representation of float32 is conformant.
        static_assert(NUNAVUT_PLATFORM_IEEE754_FLOAT, "Native IEEE754 binary32 required. TODO: relax constraint");
        auto _result4_ = out_buffer.setF32(obj.rudderon_left_floating_shaft_angle_rad);
        if(not _result4_){
            return -_result4_.error();
        }
        out_buffer.add_offset(32U);
    }
    {   // saturated float32 rudderon_left_shaft_angle_rad
        // Saturation code not emitted -- assume the native representation of float32 is conformant.
        static_assert(NUNAVUT_PLATFORM_IEEE754_FLOAT, "Native IEEE754 binary32 required. TODO: relax constraint");
        auto _result4_ = out_buffer.setF32(obj.rudderon_left_shaft_angle_rad);
        if(not _result4_){
            return -_result4_.error();
        }
        out_buffer.add_offset(32U);
    }
    {   // saturated float32 rudderon_right_surface_deflection_rad
        // Saturation code not emitted -- assume the native representation of float32 is conformant.
        static_assert(NUNAVUT_PLATFORM_IEEE754_FLOAT, "Native IEEE754 binary32 required. TODO: relax constraint");
        auto _result4_ = out_buffer.setF32(obj.rudderon_right_surface_deflection_rad);
        if(not _result4_){
            return -_result4_.error();
        }
        out_buffer.add_offset(32U);
    }
    {   // saturated float32 rudderon_right_floating_shaft_angle_rad
        // Saturation code not emitted -- assume the native representation of float32 is conformant.
        static_assert(NUNAVUT_PLATFORM_IEEE754_FLOAT, "Native IEEE754 binary32 required. TODO: relax constraint");
        auto _result4_ = out_buffer.setF32(obj.rudderon_right_floating_shaft_angle_rad);
        if(not _result4_){
            return -_result4_.error();
        }
        out_buffer.add_offset(32U);
    }
    {   // saturated float32 rudderon_right_shaft_angle_rad
        // Saturation code not emitted -- assume the native representation of float32 is conformant.
        static_assert(NUNAVUT_PLATFORM_IEEE754_FLOAT, "Native IEEE754 binary32 required. TODO: relax constraint");
        auto _result4_ = out_buffer.setF32(obj.rudderon_right_shaft_angle_rad);
        if(not _result4_){
            return -_result4_.error();
        }
        out_buffer.add_offset(32U);
    }
    {   // saturated float32 elevon_left_surface_deflection_rad
        // Saturation code not emitted -- assume the native representation of float32 is conformant.
        static_assert(NUNAVUT_PLATFORM_IEEE754_FLOAT, "Native IEEE754 binary32 required. TODO: relax constraint");
        auto _result4_ = out_buffer.setF32(obj.elevon_left_surface_deflection_rad);
        if(not _result4_){
            return -_result4_.error();
        }
        out_buffer.add_offset(32U);
    }
    {   // saturated float32 elevon_left_floating_shaft_angle_rad
        // Saturation code not emitted -- assume the native representation of float32 is conformant.
        static_assert(NUNAVUT_PLATFORM_IEEE754_FLOAT, "Native IEEE754 binary32 required. TODO: relax constraint");
        auto _result4_ = out_buffer.setF32(obj.elevon_left_floating_shaft_angle_rad);
        if(not _result4_){
            return -_result4_.error();
        }
        out_buffer.add_offset(32U);
    }
    {   // saturated float32 elevon_left_shaft_angle_rad
        // Saturation code not emitted -- assume the native representation of float32 is conformant.
        static_assert(NUNAVUT_PLATFORM_IEEE754_FLOAT, "Native IEEE754 binary32 required. TODO: relax constraint");
        auto _result4_ = out_buffer.setF32(obj.elevon_left_shaft_angle_rad);
        if(not _result4_){
            return -_result4_.error();
        }
        out_buffer.add_offset(32U);
    }
    {   // saturated float32 elevon_right_surface_deflection_rad
        // Saturation code not emitted -- assume the native representation of float32 is conformant.
        static_assert(NUNAVUT_PLATFORM_IEEE754_FLOAT, "Native IEEE754 binary32 required. TODO: relax constraint");
        auto _result4_ = out_buffer.setF32(obj.elevon_right_surface_deflection_rad);
        if(not _result4_){
            return -_result4_.error();
        }
        out_buffer.add_offset(32U);
    }
    {   // saturated float32 elevon_right_floating_shaft_angle_rad
        // Saturation code not emitted -- assume the native representation of float32 is conformant.
        static_assert(NUNAVUT_PLATFORM_IEEE754_FLOAT, "Native IEEE754 binary32 required. TODO: relax constraint");
        auto _result4_ = out_buffer.setF32(obj.elevon_right_floating_shaft_angle_rad);
        if(not _result4_){
            return -_result4_.error();
        }
        out_buffer.add_offset(32U);
    }
    {   // saturated float32 elevon_right_shaft_angle_rad
        // Saturation code not emitted -- assume the native representation of float32 is conformant.
        static_assert(NUNAVUT_PLATFORM_IEEE754_FLOAT, "Native IEEE754 binary32 required. TODO: relax constraint");
        auto _result4_ = out_buffer.setF32(obj.elevon_right_shaft_angle_rad);
        if(not _result4_){
            return -_result4_.error();
        }
        out_buffer.add_offset(32U);
    }
    {   // saturated bool[<=6] landing_legs_touching_ground
        if (obj.landing_legs_touching_ground.size() > 6)
        {
            return -nunavut::support::Error::SerializationBadArrayLength;
        }
        // Array length prefix: truncated uint8
        const auto _result3_ = out_buffer.setUxx(obj.landing_legs_touching_ground.size(), 8U);
        if(not _result3_){
            return -_result3_.error();
        }
        out_buffer.add_offset(8U);
        for (std::size_t _index2_ = 0U; _index2_ < obj.landing_legs_touching_ground.size(); ++_index2_)
        {
            auto _result2_ = out_buffer.setBit(obj.landing_legs_touching_ground[_index2_]);
            if(not _result2_){
                return -_result2_.error();
            }
            out_buffer.add_offset(1UL);
        }
    }
    {
        const auto _result0_ = out_buffer.padAndMoveToAlignment(8U);
        if(not _result0_){
            return -_result0_.error();
        }
    }
    {   // vsdk.message.adn.simulation.statemanager.ForceMomentComponents.0.1 force_moment_components
        std::size_t _size_bytes0_ = 384UL;  // Nested object (max) size, in bytes.
        auto _subspan0_ = out_buffer.subspan(0U, _size_bytes0_ * 8U);
        if(not _subspan0_){
            return -_subspan0_.error();
        }
        auto _err0_ = serialize(obj.force_moment_components, _subspan0_.value());
        if (not _err0_)
        {
            return _err0_;
        }
        _size_bytes0_ = _err0_.value();
        // It is assumed that we know the exact type of the serialized entity, hence we expect the size to match.
        out_buffer.add_offset(_size_bytes0_ * 8U);
        //
    }
    {
        const auto _result0_ = out_buffer.padAndMoveToAlignment(8U);
        if(not _result0_){
            return -_result0_.error();
        }
    }
    // It is assumed that we know the exact type of the serialized entity, hence we expect the size to match.
    return out_buffer.offset_bytes_ceil();
}

inline nunavut::support::SerializeResult deserialize(GroundTruthState_0_1& obj,
                                                     nunavut::support::const_bitspan in_buffer)
{
    const auto capacity_bits = in_buffer.size();
    // vsdk.message.MessageId.0.1 id
    {
        std::size_t _size_bytes1_ = in_buffer.size() / 8U;
        {
            const auto _err1_ = deserialize(obj.id, in_buffer.subspan());
            if(_err1_){
                _size_bytes1_ = _err1_.value();
            }else{
                return -_err1_.error();
            }
        }
        in_buffer.add_offset(_size_bytes1_ * 8U);  // Advance by the size of the nested serialized representation.
    }
    // saturated int64 timestamp_us
    obj.timestamp_us = in_buffer.getI64(64U);
    in_buffer.add_offset(64U);
    in_buffer.align_offset_to<8U>();
    // vsdk.message.adn.vehicle.common.Vector3.0.1 v_vf_ned2vf_m_per_s
    {
        std::size_t _size_bytes1_ = in_buffer.size() / 8U;
        {
            const auto _err1_ = deserialize(obj.v_vf_ned2vf_m_per_s, in_buffer.subspan());
            if(_err1_){
                _size_bytes1_ = _err1_.value();
            }else{
                return -_err1_.error();
            }
        }
        in_buffer.add_offset(_size_bytes1_ * 8U);  // Advance by the size of the nested serialized representation.
    }
    in_buffer.align_offset_to<8U>();
    // vsdk.message.adn.vehicle.common.Vector3.0.1 v_ned_ned2vf_m_per_s
    {
        std::size_t _size_bytes1_ = in_buffer.size() / 8U;
        {
            const auto _err1_ = deserialize(obj.v_ned_ned2vf_m_per_s, in_buffer.subspan());
            if(_err1_){
                _size_bytes1_ = _err1_.value();
            }else{
                return -_err1_.error();
            }
        }
        in_buffer.add_offset(_size_bytes1_ * 8U);  // Advance by the size of the nested serialized representation.
    }
    // saturated float32 ground_speed_m_per_s
    obj.ground_speed_m_per_s = in_buffer.getF32();
    in_buffer.add_offset(32U);
    in_buffer.align_offset_to<8U>();
    // vsdk.message.adn.vehicle.common.Vector3.0.1 w_vf_ned2vf_rad_per_s
    {
        std::size_t _size_bytes1_ = in_buffer.size() / 8U;
        {
            const auto _err1_ = deserialize(obj.w_vf_ned2vf_rad_per_s, in_buffer.subspan());
            if(_err1_){
                _size_bytes1_ = _err1_.value();
            }else{
                return -_err1_.error();
            }
        }
        in_buffer.add_offset(_size_bytes1_ * 8U);  // Advance by the size of the nested serialized representation.
    }
    in_buffer.align_offset_to<8U>();
    // vsdk.message.adn.vehicle.common.Vector3.0.1 a_vf_ned2vf_m_per_s2
    {
        std::size_t _size_bytes1_ = in_buffer.size() / 8U;
        {
            const auto _err1_ = deserialize(obj.a_vf_ned2vf_m_per_s2, in_buffer.subspan());
            if(_err1_){
                _size_bytes1_ = _err1_.value();
            }else{
                return -_err1_.error();
            }
        }
        in_buffer.add_offset(_size_bytes1_ * 8U);  // Advance by the size of the nested serialized representation.
    }
    in_buffer.align_offset_to<8U>();
    // vsdk.message.adn.vehicle.common.Vector3.0.1 wdot_vf_ned2vf_rad_per_s2
    {
        std::size_t _size_bytes1_ = in_buffer.size() / 8U;
        {
            const auto _err1_ = deserialize(obj.wdot_vf_ned2vf_rad_per_s2, in_buffer.subspan());
            if(_err1_){
                _size_bytes1_ = _err1_.value();
            }else{
                return -_err1_.error();
            }
        }
        in_buffer.add_offset(_size_bytes1_ * 8U);  // Advance by the size of the nested serialized representation.
    }
    in_buffer.align_offset_to<8U>();
    // vsdk.message.adn.vehicle.common.Wgs84Location.0.1 wgs84_location
    {
        std::size_t _size_bytes1_ = in_buffer.size() / 8U;
        {
            const auto _err1_ = deserialize(obj.wgs84_location, in_buffer.subspan());
            if(_err1_){
                _size_bytes1_ = _err1_.value();
            }else{
                return -_err1_.error();
            }
        }
        in_buffer.add_offset(_size_bytes1_ * 8U);  // Advance by the size of the nested serialized representation.
    }
    // saturated float32 altitude_agl_m
    obj.altitude_agl_m = in_buffer.getF32();
    in_buffer.add_offset(32U);
    // saturated float32 altitude_msl_m
    obj.altitude_msl_m = in_buffer.getF32();
    in_buffer.add_offset(32U);
    // saturated float32 vf_pseudo_altitude_hae_wgs84_m
    obj.vf_pseudo_altitude_hae_wgs84_m = in_buffer.getF32();
    in_buffer.add_offset(32U);
    // saturated float32 backyard_pseudo_altitude_hae_wgs84_m
    obj.backyard_pseudo_altitude_hae_wgs84_m = in_buffer.getF32();
    in_buffer.add_offset(32U);
    // saturated float32 target_pseudo_altitude_hae_wgs84_m
    obj.target_pseudo_altitude_hae_wgs84_m = in_buffer.getF32();
    in_buffer.add_offset(32U);
    // saturated float32 airspeed_true_m_per_s
    obj.airspeed_true_m_per_s = in_buffer.getF32();
    in_buffer.add_offset(32U);
    // saturated float32 airspeed_indicated_m_per_s
    obj.airspeed_indicated_m_per_s = in_buffer.getF32();
    in_buffer.add_offset(32U);
    in_buffer.align_offset_to<8U>();
    // vsdk.message.adn.vehicle.common.Vector3.0.1 windspeed_ned_m_per_s
    {
        std::size_t _size_bytes1_ = in_buffer.size() / 8U;
        {
            const auto _err1_ = deserialize(obj.windspeed_ned_m_per_s, in_buffer.subspan());
            if(_err1_){
                _size_bytes1_ = _err1_.value();
            }else{
                return -_err1_.error();
            }
        }
        in_buffer.add_offset(_size_bytes1_ * 8U);  // Advance by the size of the nested serialized representation.
    }
    in_buffer.align_offset_to<8U>();
    // vsdk.message.adn.vehicle.common.Matrix3x3.0.1 R_vf_from_ned
    {
        std::size_t _size_bytes1_ = in_buffer.size() / 8U;
        {
            const auto _err1_ = deserialize(obj.R_vf_from_ned, in_buffer.subspan());
            if(_err1_){
                _size_bytes1_ = _err1_.value();
            }else{
                return -_err1_.error();
            }
        }
        in_buffer.add_offset(_size_bytes1_ * 8U);  // Advance by the size of the nested serialized representation.
    }
    in_buffer.align_offset_to<8U>();
    // vsdk.message.adn.vehicle.common.RollPitchHeading.0.1 rph_vf_from_ned
    {
        std::size_t _size_bytes1_ = in_buffer.size() / 8U;
        {
            const auto _err1_ = deserialize(obj.rph_vf_from_ned, in_buffer.subspan());
            if(_err1_){
                _size_bytes1_ = _err1_.value();
            }else{
                return -_err1_.error();
            }
        }
        in_buffer.add_offset(_size_bytes1_ * 8U);  // Advance by the size of the nested serialized representation.
    }
    // saturated float32 dynamic_pressure_Pa
    obj.dynamic_pressure_Pa = in_buffer.getF32();
    in_buffer.add_offset(32U);
    // saturated float32 static_pressure_Pa
    obj.static_pressure_Pa = in_buffer.getF32();
    in_buffer.add_offset(32U);
    // saturated float32 air_temperature_K
    obj.air_temperature_K = in_buffer.getF32();
    in_buffer.add_offset(32U);
    // saturated float32 air_density_kg_per_m3
    obj.air_density_kg_per_m3 = in_buffer.getF32();
    in_buffer.add_offset(32U);
    in_buffer.align_offset_to<8U>();
    // vsdk.message.adn.vehicle.common.Vector3.0.1 actuator_forces_N
    {
        std::size_t _size_bytes1_ = in_buffer.size() / 8U;
        {
            const auto _err1_ = deserialize(obj.actuator_forces_N, in_buffer.subspan());
            if(_err1_){
                _size_bytes1_ = _err1_.value();
            }else{
                return -_err1_.error();
            }
        }
        in_buffer.add_offset(_size_bytes1_ * 8U);  // Advance by the size of the nested serialized representation.
    }
    in_buffer.align_offset_to<8U>();
    // vsdk.message.adn.vehicle.common.Vector3.0.1 actuator_moments_Nm
    {
        std::size_t _size_bytes1_ = in_buffer.size() / 8U;
        {
            const auto _err1_ = deserialize(obj.actuator_moments_Nm, in_buffer.subspan());
            if(_err1_){
                _size_bytes1_ = _err1_.value();
            }else{
                return -_err1_.error();
            }
        }
        in_buffer.add_offset(_size_bytes1_ * 8U);  // Advance by the size of the nested serialized representation.
    }
    in_buffer.align_offset_to<8U>();
    // vsdk.message.adn.vehicle.common.Vector3.0.1 aero_forces_N
    {
        std::size_t _size_bytes1_ = in_buffer.size() / 8U;
        {
            const auto _err1_ = deserialize(obj.aero_forces_N, in_buffer.subspan());
            if(_err1_){
                _size_bytes1_ = _err1_.value();
            }else{
                return -_err1_.error();
            }
        }
        in_buffer.add_offset(_size_bytes1_ * 8U);  // Advance by the size of the nested serialized representation.
    }
    in_buffer.align_offset_to<8U>();
    // vsdk.message.adn.vehicle.common.Vector3.0.1 aero_moments_Nm
    {
        std::size_t _size_bytes1_ = in_buffer.size() / 8U;
        {
            const auto _err1_ = deserialize(obj.aero_moments_Nm, in_buffer.subspan());
            if(_err1_){
                _size_bytes1_ = _err1_.value();
            }else{
                return -_err1_.error();
            }
        }
        in_buffer.add_offset(_size_bytes1_ * 8U);  // Advance by the size of the nested serialized representation.
    }
    // saturated float64[<=6] vrs_thrust_per_propeller_N
    {
        // Array length prefix: truncated uint8
    const std::size_t _size0_ = in_buffer.getU8(8U);
    in_buffer.add_offset(8U);
        if ( _size0_ > 6U)
        {
            return -nunavut::support::Error::SerializationBadArrayLength;
        }
        obj.vrs_thrust_per_propeller_N.reserve(_size0_);
        for (std::size_t _index5_ = 0U; _index5_ < _size0_; ++_index5_)
        {
            double _tmp0_ = double();
            _tmp0_ = in_buffer.getF64();
        in_buffer.add_offset(64U);
            obj.vrs_thrust_per_propeller_N.push_back(std::move(_tmp0_));
        }
    }
    // saturated float32 motor_rear_right_rpm
    obj.motor_rear_right_rpm = in_buffer.getF32();
    in_buffer.add_offset(32U);
    // saturated float32 motor_rear_right_v_radial_m_per_s
    obj.motor_rear_right_v_radial_m_per_s = in_buffer.getF32();
    in_buffer.add_offset(32U);
    // saturated float32 motor_rear_right_v_axial_m_per_s
    obj.motor_rear_right_v_axial_m_per_s = in_buffer.getF32();
    in_buffer.add_offset(32U);
    // saturated float32 motor_rear_right_prop_torque_Nm
    obj.motor_rear_right_prop_torque_Nm = in_buffer.getF32();
    in_buffer.add_offset(32U);
    // saturated float32 motor_center_right_rpm
    obj.motor_center_right_rpm = in_buffer.getF32();
    in_buffer.add_offset(32U);
    // saturated float32 motor_center_right_v_radial_m_per_s
    obj.motor_center_right_v_radial_m_per_s = in_buffer.getF32();
    in_buffer.add_offset(32U);
    // saturated float32 motor_center_right_v_axial_m_per_s
    obj.motor_center_right_v_axial_m_per_s = in_buffer.getF32();
    in_buffer.add_offset(32U);
    // saturated float32 motor_center_right_prop_torque_Nm
    obj.motor_center_right_prop_torque_Nm = in_buffer.getF32();
    in_buffer.add_offset(32U);
    // saturated float32 motor_front_right_rpm
    obj.motor_front_right_rpm = in_buffer.getF32();
    in_buffer.add_offset(32U);
    // saturated float32 motor_front_right_v_radial_m_per_s
    obj.motor_front_right_v_radial_m_per_s = in_buffer.getF32();
    in_buffer.add_offset(32U);
    // saturated float32 motor_front_right_v_axial_m_per_s
    obj.motor_front_right_v_axial_m_per_s = in_buffer.getF32();
    in_buffer.add_offset(32U);
    // saturated float32 motor_front_right_prop_torque_Nm
    obj.motor_front_right_prop_torque_Nm = in_buffer.getF32();
    in_buffer.add_offset(32U);
    // saturated float32 motor_front_left_rpm
    obj.motor_front_left_rpm = in_buffer.getF32();
    in_buffer.add_offset(32U);
    // saturated float32 motor_front_left_v_radial_m_per_s
    obj.motor_front_left_v_radial_m_per_s = in_buffer.getF32();
    in_buffer.add_offset(32U);
    // saturated float32 motor_front_left_v_axial_m_per_s
    obj.motor_front_left_v_axial_m_per_s = in_buffer.getF32();
    in_buffer.add_offset(32U);
    // saturated float32 motor_front_left_prop_torque_Nm
    obj.motor_front_left_prop_torque_Nm = in_buffer.getF32();
    in_buffer.add_offset(32U);
    // saturated float32 motor_center_left_rpm
    obj.motor_center_left_rpm = in_buffer.getF32();
    in_buffer.add_offset(32U);
    // saturated float32 motor_center_left_v_radial_m_per_s
    obj.motor_center_left_v_radial_m_per_s = in_buffer.getF32();
    in_buffer.add_offset(32U);
    // saturated float32 motor_center_left_v_axial_m_per_s
    obj.motor_center_left_v_axial_m_per_s = in_buffer.getF32();
    in_buffer.add_offset(32U);
    // saturated float32 motor_center_left_prop_torque_Nm
    obj.motor_center_left_prop_torque_Nm = in_buffer.getF32();
    in_buffer.add_offset(32U);
    // saturated float32 motor_rear_left_rpm
    obj.motor_rear_left_rpm = in_buffer.getF32();
    in_buffer.add_offset(32U);
    // saturated float32 motor_rear_left_v_radial_m_per_s
    obj.motor_rear_left_v_radial_m_per_s = in_buffer.getF32();
    in_buffer.add_offset(32U);
    // saturated float32 motor_rear_left_v_axial_m_per_s
    obj.motor_rear_left_v_axial_m_per_s = in_buffer.getF32();
    in_buffer.add_offset(32U);
    // saturated float32 motor_rear_left_prop_torque_Nm
    obj.motor_rear_left_prop_torque_Nm = in_buffer.getF32();
    in_buffer.add_offset(32U);
    // saturated float32 rudderon_left_surface_deflection_rad
    obj.rudderon_left_surface_deflection_rad = in_buffer.getF32();
    in_buffer.add_offset(32U);
    // saturated float32 rudderon_left_floating_shaft_angle_rad
    obj.rudderon_left_floating_shaft_angle_rad = in_buffer.getF32();
    in_buffer.add_offset(32U);
    // saturated float32 rudderon_left_shaft_angle_rad
    obj.rudderon_left_shaft_angle_rad = in_buffer.getF32();
    in_buffer.add_offset(32U);
    // saturated float32 rudderon_right_surface_deflection_rad
    obj.rudderon_right_surface_deflection_rad = in_buffer.getF32();
    in_buffer.add_offset(32U);
    // saturated float32 rudderon_right_floating_shaft_angle_rad
    obj.rudderon_right_floating_shaft_angle_rad = in_buffer.getF32();
    in_buffer.add_offset(32U);
    // saturated float32 rudderon_right_shaft_angle_rad
    obj.rudderon_right_shaft_angle_rad = in_buffer.getF32();
    in_buffer.add_offset(32U);
    // saturated float32 elevon_left_surface_deflection_rad
    obj.elevon_left_surface_deflection_rad = in_buffer.getF32();
    in_buffer.add_offset(32U);
    // saturated float32 elevon_left_floating_shaft_angle_rad
    obj.elevon_left_floating_shaft_angle_rad = in_buffer.getF32();
    in_buffer.add_offset(32U);
    // saturated float32 elevon_left_shaft_angle_rad
    obj.elevon_left_shaft_angle_rad = in_buffer.getF32();
    in_buffer.add_offset(32U);
    // saturated float32 elevon_right_surface_deflection_rad
    obj.elevon_right_surface_deflection_rad = in_buffer.getF32();
    in_buffer.add_offset(32U);
    // saturated float32 elevon_right_floating_shaft_angle_rad
    obj.elevon_right_floating_shaft_angle_rad = in_buffer.getF32();
    in_buffer.add_offset(32U);
    // saturated float32 elevon_right_shaft_angle_rad
    obj.elevon_right_shaft_angle_rad = in_buffer.getF32();
    in_buffer.add_offset(32U);
    // saturated bool[<=6] landing_legs_touching_ground
    {
        // Array length prefix: truncated uint8
    const std::size_t _size0_ = in_buffer.getU8(8U);
    in_buffer.add_offset(8U);
        if ( _size0_ > 6U)
        {
            return -nunavut::support::Error::SerializationBadArrayLength;
        }
        obj.landing_legs_touching_ground.reserve(_size0_);
        for (std::size_t _index5_ = 0U; _index5_ < _size0_; ++_index5_)
        {
            bool _tmp0_ = bool();
            _tmp0_ = in_buffer.getBit();
        in_buffer.add_offset(1U);
            obj.landing_legs_touching_ground.push_back(std::move(_tmp0_));
        }
    }
    in_buffer.align_offset_to<8U>();
    // vsdk.message.adn.simulation.statemanager.ForceMomentComponents.0.1 force_moment_components
    {
        std::size_t _size_bytes1_ = in_buffer.size() / 8U;
        {
            const auto _err1_ = deserialize(obj.force_moment_components, in_buffer.subspan());
            if(_err1_){
                _size_bytes1_ = _err1_.value();
            }else{
                return -_err1_.error();
            }
        }
        in_buffer.add_offset(_size_bytes1_ * 8U);  // Advance by the size of the nested serialized representation.
    }
    in_buffer.align_offset_to<8U>();
    auto _bits_got_ = std::min<std::size_t>(in_buffer.offset(), capacity_bits);
    return { static_cast<std::size_t>(_bits_got_ / 8U) };
}

} // namespace simulation
} // namespace adn
} // namespace message
} // namespace vsdk

#endif // VSDK_MESSAGE_ADN_SIMULATION_GROUND_TRUTH_STATE_0_1_HPP_INCLUDED
