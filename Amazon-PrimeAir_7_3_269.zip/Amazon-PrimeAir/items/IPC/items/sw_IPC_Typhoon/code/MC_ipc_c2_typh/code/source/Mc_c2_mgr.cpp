#include <mc_c2_mgr.h>

#include <mc_2838x_ccard.h>
#include <Mc_shared_memory.h>

namespace MCxx
{
    Mc_c2_mgr::Mc_c2_mgr() :
        mc_ctrl(get_c1_sh_mem().hwv,
                p_mc)
    {
    }

    void Mc_c2_mgr::start()
    {
        while(true)
        {
            mc_ctrl.bg_task();
        }
    }
}
