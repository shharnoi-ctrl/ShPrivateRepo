#include <Mc.h>
#include <mc_2838x_ccard.h>
#include <Ipc.h>

static const Uint32 g_app_size[1] = { 0x0030000 }; // Max app size (in bytes).
extern const Uint32 g_app_crc[1];

namespace Dsp28335_ent
{
    void init_sys_cpu1_0();
    void post_init_sys_cpu1(bool is_dual_core, bool emif1_for_c2);
}

extern "C"
{
    int _system_pre_init(void)  // PRQA S 5047 #Exception Rule 47
    {
        Dsp28335_ent::init_sys_cpu1_0(); // Init without EMIF.
        return 1;
    }

    // Post copy initialization. Here the ramfuncs have been already copied to RAM.
    int _system_post_cinit(void)    // PRQA S 5047 #Exception Rule 47
    {

        MCxx::get_c1_sh_mem(); // initialize shared memory to write into
        Dsp28335_ent::post_init_sys_cpu1(true, false);
        return 1;
    }
}

namespace MCxx
{
    /// External allocator memory size
    static const Uint32 mem_ext_sz = 59350;

    /// Internal allocator memory size
    static const Uint32 mem_int_sz  = 2214;

    #pragma RETAIN
    #pragma DATA_SECTION("MEMMGR_INT")
    Uint16 memmgr_int_buf[mem_int_sz];  ///< Memory buffer for internal memory allocator

    #pragma RETAIN
    #pragma DATA_SECTION("MEMMGR_EXT")
    Uint16 memmgr_ext_buf[mem_ext_sz];  ///< Memory buffer for external memory allocator
    // memory manager init ends here
}

void main()
{
    using namespace Dsp28335_ent;
    using namespace Base;

    // Force usage of the consts
    if((g_app_size[0] + g_app_crc[0] + 2) == 0)
    {
        Bsp::warning();
    }
    MCxx::Mc* mc_inst = Base::Memmgr::get_instance().get_allocator(Base::Memmgr::internal).allocate_new<MCxx::Mc>(MCxx::p_mc);

    /// <li> Unlock C2.
    Ipc::get_instance().cpu2_unlock();
    /// <li> Wait for C2 to finish initialization.
    Ipc::cpu1_wait_for_unlock();
    /// <li> Do post init C2 task
    mc_inst->post_init_c2();

    mc_inst->start();
}
