#include <Kclk.h>

namespace Bsp
{
    void Kclk::get_sys_xtal_cfg(Uint32& freq, bool& is_crystal)
    {
        static const Uint32 xtal_freq = 25000000UL;
        freq = xtal_freq;
        is_crystal = true;
    }
}
