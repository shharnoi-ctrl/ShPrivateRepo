#include <Bootloader.h>

#include <Default_cfg.h>
#include <Secure_CAN.h>
#include <Sysuid.h>
#include <GPIOdev.h>

namespace Vbootloader
{
    using namespace Base;
    using namespace Devices;
    using namespace Dsp28335_ent;

    void Bootloader::set_can_in_cfg(CANin_p::Config& in_cfg)
    {
        /// \alg
        /// Configure received input filter as:
        ///   - Port: CANport::can_all
        ///   - CAN filter: not extended
        ///   - CAN ID filter: 0x740 + current Node ID, not extended and with CANid::id_msk_std as mask.
        static const Uint32 base_rx_id = 0x740;
        const Uint32 id = Bsp::get_uid().phy;
        in_cfg.port = static_cast<CANport::Port>(CANport::can_all);
        in_cfg.filter.can_filter.id.extended = false;
        in_cfg.filter.can_filter.id.id = base_rx_id + id;
        in_cfg.filter.can_filter.msk = CANid::id_msk_std;
    }

    void Bootloader::set_can_cfg(CANin_p::Config& in_cfg,
                                 CANout_c::Config& out_cfg,
                                 SerialCAN::Config& sc_cfg)
    {
        /// \alg
        static const Uint32 base_tx_id = 0x700;
        const Uint32 id = Bsp::get_uid().phy;

        /// - Call to ::set_can_in_cfg with received "in_cfg".
        set_can_in_cfg(in_cfg);

        /// - Set CANout_c::Config::port of "out_cfg" at already updated value of CANin_p::Config::port.
        out_cfg.port = in_cfg.port;

        /// - Set SerialCAN::Config::timeout value to SerialCAN_consts::def_115K_timeout.
        sc_cfg.timeout = SerialCAN_consts::def_115K_timeout;
        /// - Set SerialCAN::Config::id::extended to false.
        sc_cfg.id.extended = false;
        /// - Set SerialCAN::Config::id::id to 0x700 + current Node ID.
        sc_cfg.id.id = base_tx_id + id;
    }

    void Bootloader::config_can(bool as_master)
    {
        CANcfg cfg_can = {0,0};

        Dsp28335_ent::GPIOdev::apply_can<mux_canfd_a, Dsp28335_ent::gpio_070, Dsp28335_ent::gpio_074>();
        GPIOioctl::apply_output(get_gpio_taba_en());
        GPIOioctl::apply_output(get_gpio_taba_nstb());
        GPIOioctl::apply_output(get_gpio_tabb_en());
        GPIOioctl::apply_output(get_gpio_tabb_nstb());

        // Default configuration of CAN admit only one RX configured on SER_CAN ID
        Midlevel::Default_cfg::set_default_can_500(cfg_can,
                                                   false,          // Without arbitration
                                                   as_master);     // As master (rx on 1301 and tx on 1302)

        // Override CAN id for serial-CAN
        CANin_p::Config can_in_cfg;
        set_can_in_cfg(can_in_cfg);

        CANcfg cancfg_stab = cfg_can;
        cancfg_stab.rx[0].flt = can_in_cfg.filter.can_filter;
        cancfg_stab.rx[0].sz = Midlevel::Default_cfg::def_nb_rx_mboxes;

        ///     <li> Construct Secure_CAN "stab_b" with Ver::GPIOname::gpio_tabb_en and
        /// Ver::GPIOname::gpio_tabb_nstb.
        ///      <li> Call Secure_CAN::enable_transceiver in "stab_b" with Halsuite::can_a.
        Secure_CAN stab_b(get_gpio_tabb_en(), get_gpio_tabb_nstb());
        if(Bsp::is_astro(static_cast<Bsp::Sysapp>(Bsp::get_uid().app)))
        {
            stab_b.enable_transceiver(hal.cana, Secure_CAN::cfg_open_commands);
            hal.cana.config(cancfg_stab);

            // Apply configuration to CAN B
            hal.canb.config(cfg_can);
        }
        else
        {
            // IPC
            stab_b.enable_transceiver(hal.canb, Secure_CAN::cfg_open_commands);
            hal.canb.config(cancfg_stab);
        }

        ///     <li> Construct Secure_CAN "stab_a" with Ver::GPIOname::gpio_taba_en and
        /// Ver::GPIOname::gpio_taba_nstb.
        ///      <li> Call Secure_CAN::enable_transceiver in "stab_a" with Halsuite::can_fd.
        Secure_CAN stab_a(get_gpio_taba_en(), get_gpio_taba_nstb());
        stab_a.enable_transceiver(hal.can_fd, Secure_CAN::cfg_open_commands);


        CAN_FD_cfg cfg;
        /// <li> Call Midlevel::Default_cfg::set_default_can_fd with "cfg",
        /// Dsp28335_ent::CAN_FD_cfg::Baudrate::bd_500K, Dsp28335_ent::CAN_FD_cfg::Baudrate::bd_2M, false and false.
        Midlevel::Default_cfg::set_default_can_fd(cfg,
                                                  CAN_FD_cfg::bd_500K,
                                                  CAN_FD_cfg::bd_2M,
                                                  false,
                                                  as_master);


        cfg.rx_cfg[0].flt = can_in_cfg.filter.can_filter;
        cfg.rx_cfg[0].sz = Midlevel::Default_cfg::def_nb_rx_mboxes;

        hal.can_fd.config(cfg);
    }
}
