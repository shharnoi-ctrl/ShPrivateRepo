#include <Halsuite_vboot.h>
#include <Sysapp.h>

#define TMS320F2838x

namespace Vbootloader
{
    using namespace Dsp28335_ent;

    void Halsuite::step_hi()
    {
        /// \alg
        scia_port.step();   /// - Call step for SCI-A
        scib_port.step();   /// - Call step for SCI-B
        scic_port.step();   /// - Call step for SCI-C
        scid_port.step();   /// - Call step for SCI-D

        cana.check_tx_tout();   /// Call CAN::check_tx_tout for ::cana.
        canb.check_tx_tout();   /// Call CAN::check_tx_tout for ::canb.
        can_fd.check_tx_tout(); /// Call CAN_FD::check_tx_tout for ::can_fd.
    }

    Halsuite::GPIOcfg Halsuite::get_cfg(GPIOfunc f, Bsp::Uid64 uid)
    {
        /// \alg
        /// ### Return the configuration based on the given functionality and AppId extracted from the Uid.
        ///     A warning will be throw if the AppId is not supported:
        using namespace Bsp;

        static const GPIOtun cfg_gpio_out = GPIOtun::build(GPIOtun::dir_output, GPIOtun::pu_dis, GPIOtun::Mux(0),
                                                           GPIOtun::qsel_sync);
        static const GPIOtun cfg_sci_tx   = GPIOtun::build(GPIOtun::dir_output, GPIOtun::pu_dis,  GPIOtun::Mux(6),
                                                           GPIOtun::qsel_sync);
        static const GPIOtun cfg_sci_rx   = GPIOtun::build(GPIOtun::dir_input,  GPIOtun::pu_dis,  GPIOtun::Mux(6),
                                                           GPIOtun::qsel_async);
        static const GPIOtun cfg_can_tx   = GPIOtun::build(GPIOtun::dir_output, GPIOtun::pu_en,  GPIOtun::Mux(3),
                                                           GPIOtun::qsel_sync);
        static const GPIOtun cfg_can_rx   = GPIOtun::build(GPIOtun::dir_input,  GPIOtun::pu_en,  GPIOtun::Mux(3),
                                                           GPIOtun::qsel_async);

        GPIOcfg res = { gpio_all, cfg_gpio_out, GPIOioctl::c1 };
        switch(f)
        {
            case f_led_red:
            {
                res.b.id = gpio_008; // Red LED.
                break;
            }
            case f_led_green:
            {
                res.b.id = gpio_009; // MCU alive LED.
                break;
            }
            case f_led_blue:
            {
                res.b.id = gpio_010;
                break;
            }
            case f_sci_a_tx:
            {
                res.b.cfg = cfg_sci_tx;
                res.b.cfg.mux_sel = GPIOtun::Mux(1);
                res.b.id  = gpio_029;
                break;
            }
            case f_sci_a_rx:
            {
                res.b.cfg = cfg_sci_rx;
                res.b.cfg.mux_sel = GPIOtun::Mux(1);
                res.b.id  = gpio_028;
                break;
            }
            case f_sci_c_tx:
            {
                res.b.cfg = cfg_sci_tx;
                res.b.id = gpio_056;
                break;
            }
            case f_sci_c_rx:
            {
                res.b.cfg = cfg_sci_rx;
                res.b.id = gpio_057;
                break;
            }
            case f_sci_d_tx:
            {
                res.b.cfg = cfg_sci_tx;
                res.b.id = gpio_142;
                break;
            }
            case f_sci_d_rx:
            {
                res.b.cfg = cfg_sci_rx;
                res.b.id = gpio_094;
                break;
            }
            case f_can_b_tx:
            {
                res.b.cfg = cfg_can_tx;
                res.b.cfg.mux_sel = GPIOtun::Mux(2);
                res.b.id = gpio_012;
                break;
            }
            case f_can_b_rx:
            {
                res.b.cfg = cfg_can_rx;
                res.b.cfg.mux_sel = GPIOtun::Mux(2);
                res.b.id = gpio_010;
                break;
            }
            case f_canfd_tx:
            {
                res.b.cfg = cfg_can_tx;
                res.b.cfg.mux_sel = GPIOtun::Mux(9);
                res.b.id = gpio_074;
                break;
            }
            case f_canfd_rx:
            {
                res.b.cfg = cfg_can_rx;
                res.b.cfg.mux_sel = GPIOtun::Mux(9);
                res.b.id = gpio_070;
                break;
            }
            default:
            {
                Bsp::warning();
                break;
            }
        }
        return res;
    }
}
