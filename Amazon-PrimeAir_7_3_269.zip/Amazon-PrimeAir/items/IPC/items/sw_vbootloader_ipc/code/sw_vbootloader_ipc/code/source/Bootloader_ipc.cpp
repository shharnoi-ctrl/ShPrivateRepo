#include <Bootloader.h>

#include <Bootloader_dual.h>

namespace Vbootloader
{
    Bootloader_dual& Bootloader_dual::build(Bldr_mgr::Params par, Base::IAddress_handler & addr_handler)
    {
        /// \alg
        /// - Build a static ::Bootloader_pa instance using received parameters and retrieve it.
        static Bootloader_dual bldr2(par, addr_handler);
        return bldr2;
    }

    GPIOid Bootloader::get_gpio_taba_en()
    {
        return Dsp28335_ent::gpio_033;
    }

    GPIOid Bootloader::get_gpio_taba_nstb()
    {
        return Dsp28335_ent::gpio_034;
    }

    GPIOid Bootloader::get_gpio_tabb_en()
    {
        return Dsp28335_ent::gpio_035;
    }

    GPIOid Bootloader::get_gpio_tabb_nstb()
    {
        return Dsp28335_ent::gpio_036;
    }
}
