#include <Address_handler.h>
#include <Bldr.h>
#include <Bldr_defs.h>
#include <Bootloader_dual.h>
#include <Delay.h>
#include <Halsuite_vboot.h>
#include <Ipc.h>
#include <Secure_CAN.h>
#include <Sysaddr.h>
#include <Sysuid.h>

#include <CAN_FD_cfg.h>
#include <Default_cfg.h>

#include <CM_CPU1_shared_types.h>

int main()
{
    using namespace Base;
    using namespace Vbootloader;
    using namespace Dsp28335_ent;

    static const Uint32 flash_start = 0x80000UL;                // Flash starting address
    static const Uint32 flash_size  = 0x40000UL;                // Flash size (in words)

    static const Uint32 bldr_start  = flash_start;              // Address where bootloader starts
    static const Uint32 bldr_size   = 0x10000UL;                // Bootloader max size (in words)
    static const Uint32 user_start  = bldr_start+bldr_size;     // Address where user code starts
    static const Uint32 user_size   = 0x40000UL-bldr_size;      // User code size (in words)

    // Force creation of the App bootloader header.
    /// <ul>
    /// <li> IF Base::App_blr_hdr::bld_hdr_mark in Base::App_blr_hdr_inst::instance, templated with ::app_crc,
    ///      ::app_size, Bsp::Sysapp::sapp_uapp and 0U, is not equal than Base::App_blr_hdr::hdr_bldr_mark_v, THEN:
    if(App_blr_hdr_inst<0, bldr_size, Bsp::sapp_uapp, 0U>::instance.bld_hdr_mark != Base::App_blr_hdr::hdr_bldr_mark_v)
    {
        /// <ul>
        /// <li> Do nothing.
        Bsp::warning();
        /// </ul>
    }

    const Bldr_mgr::Params par =
    {
        { bldr_start, words16_to_bytes_c<bldr_size>::value },    // Bootloader data block (in bytes)
        {
            3,
            {
                {
                    { user_start,    words16_to_bytes_c<user_size>::value }, // User data block in C1 (in bytes)
                    { flash_start,   words16_to_bytes_c<flash_size>::value}, // User data block in C2 (in bytes)
                    { cm_user_start, cm_user_size }                          // User data block in CM (in bytes)
                }
            }
        },
        { (1U << Vbootloader::Bldr_mgr::c1_core_index) | (1U << Vbootloader::Bldr_mgr::c2_core_index) }
    };

    // Build shared memory variables
    CPU1_CM_shared& shared_c1 = get_c1_writer();
    shared_c1.uid      = Bsp::get_uid();
    shared_c1.sys_addr = shared_c1.uid.phy;

    shared_c1.port_stg = Routing_table_data<0,0>::def_stg_port;
    shared_c1.port_cy  = Routing_table_data<0,0>::def_cyphal_port;

    shared_c1.port_cy  = Base::Routing_table_data<0,0>::def_cyphal_port;

    shared_c1.heartbeat_led_id = Dsp28335_ent::gpio_all; // No pin available

    // Start CM initialization
    Ipc::turn_off_cm();
//!! IS this needed ?
//     CM_helpers::cm_init_start(Halsuite::get_eth_cfg());

//    GPIOioctl::apply_output(static_cast<GPIOid>(shared_c1.heartbeat_led_id), GPIOioctl::cm);

    Ipc::set_cm_command(Bsp::bldr_force_bldr_cmd);
    Dsp28335_ent::Delay::ms(1);
    CM_helpers::cm_boot();
    Dsp28335_ent::Delay::ms(1);
    Ipc::set_cm_command(0); // Clear command

    Address_handler addr_handler(Bsp::sysaddr(), par.cores_managed, true);
    Bootloader_dual& bldr = Bootloader_dual::build(par, addr_handler);

    // End CM initialization: Flag to CM that C1 has finished initialization.
    CM_helpers::cm_init_end();
    bldr.run();
}
