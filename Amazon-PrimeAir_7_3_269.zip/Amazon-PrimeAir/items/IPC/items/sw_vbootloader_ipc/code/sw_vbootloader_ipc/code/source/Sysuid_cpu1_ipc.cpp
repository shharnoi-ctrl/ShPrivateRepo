#include <Sysuid.h>
#include <Sysapp.h>
#include <GPIO.h>
#include <Tnarray.h>
#include <Delay.h>

// Copied code
namespace MCxx
{
    /// Hardware Variant and version
    enum HWversion_id
    {
        v_unknown,      ///< Unknown (not computed).
        v_mc_25,        ///< MC25.
        v_mc_110,       ///< MC110.
        v_mc_110_v2,    ///< MC110 v2.
        v_mc_24,        ///< MC24.
        v_mc_ipc        ///< MC for IPC.
    };

    namespace Ipc_ids
    {
        /// Node ID for Right Rear motor for STAB-A
        static const Uint16 node_id_rr_a = 10U;

        /// Position IDs. This is used to identify who StationName it is according to actual
        /// hardware GPIOs value.
        enum Pos
        {
            rr = 3U, ///< Rear-right 0 position value
            cr = 2U, ///< Center-right 1 position value
            fr = 1U, ///< Front-right 2 position value
            fl = 7U, ///< Front-left 3 position value
            cl = 6U, ///< Center-left 4 position value
            rl = 5U  ///< Rear-left 5 position value
        };
    }
}

namespace Bsp
{
    namespace
    {
        using namespace Dsp28335_ent;

        static const Uint32 n_pos_ids = 3U; ///< Number of position identification bits
        static const Base::Tnarray<GPIOid, n_pos_ids> pos_ids =
        {
            {
                gpio_016,
                gpio_017,
                gpio_018
            }
        };

        static const Uint32 n_brd_ids = 4U; ///< Number of board identification bits
        static const Base::Tnarray<GPIOid, n_brd_ids> brd_ids =
        {
            {
                gpio_011,
                gpio_013,
                gpio_014,
                gpio_015
            }
        };

        // Board revision IPC CX-3 DV Block 20
        static const Uint16 brd_id_cx3_dv_blk20 = 8U;

        /// Position ID value
        /// \wi{19687}
        /// mc_common library shall provide a method to read a set of Dsp28335_ent::GPIO as a unsigned integer,
        /// using the first GPIO in the list as the high significant bit and the latest as the low significant bit.
        /// \param[in] gpios: array of GPIOs to get the value
        Uint16 get_value_from_gpio(const Base::Mblock<const GPIOid>& gpios)
        {
            Uint16 val = 0U;
            for(Uint16 i = 0; i < gpios.sz; ++i)
            {
                val |= (static_cast<Uint16>(GPIO(gpios.v[i]).get()) << i);
            }
            return val;
        }

        Uint16 get_node_id()
        {
            using namespace MCxx;
            static bool is_ipc_board = false;

            if(get_value_from_gpio(brd_ids.to_mblock()) == brd_id_cx3_dv_blk20)
            {
                is_ipc_board = true;
            }

            Uint16 node_id = Ipc_ids::node_id_rr_a;
            const Ipc_ids::Pos pos_val = static_cast<Ipc_ids::Pos>(get_value_from_gpio(pos_ids.to_mblock()));
            if(is_ipc_board)
            {
                switch(pos_val)
                {
                    case Ipc_ids::rr:
                    {
                        node_id = Ipc_ids::node_id_rr_a;
                        break;
                    }
                    case Ipc_ids::cr:
                    {
                        node_id = Ipc_ids::node_id_rr_a + Ku16::u1;
                        break;
                    }
                    case Ipc_ids::fr:
                    {
                        node_id = Ipc_ids::node_id_rr_a + Ku16::u2;
                        break;
                    }
                    case Ipc_ids::fl:
                    {
                        node_id = Ipc_ids::node_id_rr_a + Ku16::u3;
                        break;
                    }
                    case Ipc_ids::cl:
                    {
                        node_id = Ipc_ids::node_id_rr_a + Ku16::u4;
                        break;
                    }
                    case Ipc_ids::rl:
                    {
                        node_id = Ipc_ids::node_id_rr_a + Ku16::u5;
                        break;
                    }
                    default:
                    {
                        Bsp::warning();
                        break;
                    }
                }
            }
            return node_id;
        }

        /// UID Auxiliar Retriever.
        /// \wi{22753}
        /// Bsp::anonymous_namespace{Sysuid_cpu1_amz.cpp} shall be able to retrieve UID64 from OTP.
        /// \return UID64 retrieved from OTP.
        Uid64 get_uid_aux()
        {
            /// \alg
            // Ref: https://github.com/embention/Amazon-PrimeAir/issues/4536
            // This is needed to be able to properly read the gpio ids.
            Dsp28335_ent::Delay::ms(150);
            /// <ul>
            /// <li> Initialize a Uid64 "otp_uid" instance to a list with 0.
            Uid64 otp_uid = { 0 };
            /// <li> Assing Bsp::Sysapp::sapp_mc_ipc to Uid64::app in "otp_uid".
            otp_uid.app = Bsp::sapp_mc_ipc;
            /// <li> Assing MCxx::v_mc_ipc to Uid64::hwv in "otp_uid".
            otp_uid.hwv = MCxx::v_mc_ipc;
            /// <li> Assing the value C2 shared memory \a curr_esc_id +
            ///  MCxx::Ipc_ids::node_id_rr_a to Uid64::phy in "otp_uid".
            otp_uid.phy = get_node_id();
            /// <li> Return "otp_uid".
            return otp_uid;
            /// </ul>
        }
    }

    Uid64 get_uid(bool force_read)
    {
        static Uid64 otp_uid = get_uid_aux();
        if (force_read)
        {
            otp_uid = get_uid_aux();
        }
        return otp_uid;
    }
}
