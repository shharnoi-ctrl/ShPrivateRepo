#include "driverlib_cm/flash.h"
#include "driverlib_cm/sysctl.h"
#include "driverlib_cm/systick.h"

#include <Address_handler.h>
#include <Allocator.h>
#include <App_blrd_hdr.h>
#include <Bldr.h>
#include <Bldr_defs.h>
#include <Bld_mgr_2838xCM.h>
#include <GPIOid.h>

#include <CM_CPU1_shared_types.h>

// These are defined by the linker (see device linker command file)
extern uint16_t RamfuncsLoadStart;
extern uint16_t RamfuncsLoadSize;
extern uint16_t RamfuncsRunStart;
extern uint16_t RamfuncsLoadEnd;
extern uint16_t RamfuncsRunEnd;
extern uint16_t RamfuncsRunSize;

extern uint16_t constLoadStart;
extern uint16_t constLoadEnd;
extern uint16_t constLoadSize;
extern uint16_t constRunStart;
extern uint16_t constRunEnd;
extern uint16_t constRunSize;

#define DEVICE_FLASH_WAITSTATES 2

//*****************************************************************************
// Driver specific initialization code and macro.
//*****************************************************************************
//uint32_t systickPeriodValue = 125000UL; //1Khz @ 125Mhz
uint32_t systickPeriodValue = 62500UL;  //2Khz @ 125Mhz

//*****************************************************************************
void CM_init(void)
{
    // Disable the watchdog
    SysCtl_disableWatchdog();

    // Copy time critical code and flash setup code to RAM. This includes the
    // following functions: InitFlash();
    //
    // The RamfuncsLoadStart, RamfuncsLoadSize, and RamfuncsRunStart symbols
    // are created by the linker. Refer to the device .cmd file.
    // Html pages are also being copied from flash to ram.
    //
    memcpy(&RamfuncsRunStart, &RamfuncsLoadStart, (size_t)&RamfuncsLoadSize);
    memcpy(&constRunStart, &constLoadStart, (size_t)&constLoadSize);

    // Call Flash Initialization to setup flash waitstates. This function must
    // reside in RAM.
    Flash_initModule(FLASH0CTRL_BASE, FLASH0ECC_BASE, DEVICE_FLASH_WAITSTATES);

    // Sets the NVIC vector table offset address.
    Interrupt_setVectorTableOffset((uint32_t)vectorTableFlash);
}

//*****************************************************************************
// Memory Manager init starts here
/// General allocator memory size
static const Uint32 mem_sz  = 12000UL;
Uint16 memmgr_buf[mem_sz];
// memory manager init ends here


#include <driverlib_cm/gpio.h>
inline void toggle_led(int16_t led_gpio_id)
{
    if(led_gpio_id != -1)
    {
        GPIO_togglePin(led_gpio_id);
    }
}

extern "C" int _system_pre_init(void)
{
    static const uint32_t cmd_offset = 8U;
    const uint32_t cmd = *(reinterpret_cast<volatile uint32_t*>(IPC_CMTOCPU1_BASE) + cmd_offset);
    if(cmd != Bsp::bldr_force_bldr_cmd)
    {
        typedef void(*User_app)();
        const Uint32 addr = cm_user_start+1U; // Add 1 to the desired address to force ARM thumb mode.
        reinterpret_cast<User_app>(addr)(); // Call the user app code. Never returns.
    }
    return 1;
}

int16 heartbeat_led_id = -1; // Variable to store configured

// The interrupt handler for the SysTick interrupt.
extern "C" void SysTickIntHandler(void)
{
    static uint32_t cnt = 0;
    if(++cnt >= 1000UL)
    {
        cnt = 0;
        toggle_led(heartbeat_led_id);
    }
}

void main(void)
{
    using namespace Base;
    using namespace Dsp28335_ent;
    using namespace Vbootloader;

    // Force creation of the App bootloader header.
    /// <ul>
    /// <li> IF Base::App_blr_hdr::bld_hdr_mark in Base::App_blr_hdr_inst::instance, templated with ::app_crc,
    ///      ::app_size, Bsp::Sysapp::sapp_uapp and 0U, is not equal than Base::App_blr_hdr::hdr_bldr_mark_v, THEN:
    if(App_blr_hdr_inst<0, cm_bldr_size, Bsp::sapp_uapp, 0U>::instance.bld_hdr_mark != Base::App_blr_hdr::hdr_bldr_mark_v)
    {
        /// <ul>
        /// <li> Do nothing.
        Bsp::warning();
        /// </ul>
    }

    static Bitmask<Uint8> cores_managed;
    cores_managed.value = Ku8::u0;
    cores_managed.set(Vbootloader::Bldr_mgr::cm_core_index);

    // TODO use this from shared memory ?

    static Vbootloader::Bldr_mgr::Params par =
    {
        { cm_bldr_start, cm_bldr_size },    // Bootloader data block (in bytes)
        {
            3,
            {
                {
                    { 0, 0 },                       // Dummy C1 User Block (Not going to be used by CM).
                    { 0, 0 },                       // Dummy C2 User Block (Not going to be used by CM).
                    { cm_user_start, cm_user_size } // User data block in CM (in bytes)
                }
            }
        },
        cores_managed
    };


    // Initializing the CM. Loading the required functions to SRAM.
    CM_init();

    static Allocator alloc(memmgr_buf, mem_sz);

    Memmgr::get_instance().add_allocator(Memmgr::internal, alloc);
    Memmgr::get_instance().add_allocator(Memmgr::external, alloc);

    // Emb: Initialize shared RAM
    CM_CPU1_shared& cm_shared = get_cm_writer();

    // Flag startup finished
    IPC_setFlagLtoR(IPC_CM_L_CPU1_R, IPC_FLAG0);

    // Wait for C1 to finish startup
    IPC_waitForFlag(IPC_CM_L_CPU1_R, IPC_FLAG1);

    // Enable processor interrupts.
    Interrupt_enableInProcessor();

    const CPU1_CM_shared& shared( get_c1_reader() );
    heartbeat_led_id = shared.heartbeat_led_id;

    static const Uint16 buffer_sz = 4096U;
    static Uint8 data_buffer[buffer_sz];
    U8pkmblock buffer(data_buffer, buffer_sz);

    Vbootloader::Address_handler addr_handler(Bsp::sysaddr(), cores_managed, false);
    Vbootloader::Bld_mgr_2838xCM& bld_mgr = *alloc.allocate_new<Vbootloader::Bld_mgr_2838xCM>(buffer, par, addr_handler);

    // Add default routing for Stanag and Cyphal
    {
        Routing_table_entry e;

        // Stanag routing.
        e.dst_addr = Address0::build(Address0::broadcast);
        e.dst_mask = Address0::build(0); // 0.0.0.0
        e.ports.set(0); // C1 port

        bld_mgr.get_routing_table().get_routing_table_data().add_route(0, e);
    }

    // Add routing port
    bld_mgr.add_c1_port();

    SYSTICK_setPeriod(systickPeriodValue);
    SYSTICK_enableCounter();
    SYSTICK_registerInterruptHandler(SysTickIntHandler);
    SYSTICK_enableInterrupt();

    toggle_led(heartbeat_led_id);

    const Bldr_mgr::App_status sts = bld_mgr.check_app();
    cm_shared.cm_status = sts;

    while(true)
    {
        // Communications step
        bld_mgr.step();
    }
}
