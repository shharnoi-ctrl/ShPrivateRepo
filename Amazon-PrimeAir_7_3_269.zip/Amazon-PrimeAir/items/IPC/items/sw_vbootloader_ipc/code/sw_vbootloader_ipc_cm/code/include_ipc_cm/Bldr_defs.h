#include <Entypes.h>

static const Uint32 cm_bldr_start  = 0x200000UL;                   // Address where CM bootloader starts
static const Uint32 cm_bldr_size   =  0x20000UL;                   // CM bootloader max size (in bytes)
static const Uint32 cm_user_start  = cm_bldr_start + cm_bldr_size; // Address where CM user code starts
static const Uint32 cm_user_size   = 0x30000;                      // CM user code size (in bytes)
