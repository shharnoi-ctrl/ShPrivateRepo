#include <msg_crypto_hnd.h>

namespace Vbootloader
{
    using namespace Base;

    Msg_data::Ack_type Msg_crypto_hnd::Key_gen::on_rx(Rx_params& rx_p)
    {
        Base::Msg_data::Ack_type res = Msg_data::rejected;
        // TODO Generate key and store it internally.
        return res;
    }

    bool Msg_crypto_hnd::Key_gen::on_tx(Tx_params& tx_p)
    {
        bool res = false;
        // TODO Fill Generated key in response.
        return res;
    }

    Msg_data::Ack_type Msg_crypto_hnd::Sign::on_rx(Rx_params& rx_p)
    {
        Base::Msg_data::Ack_type res = Msg_data::rejected;
        // TODO read data to sign and store signed value internally.
        return res;
    }

    bool Msg_crypto_hnd::Sign::on_tx(Tx_params& tx_p)
    {
        bool res = false;
        // TODO Fill Generated signature in response.
        return res;
    }

}
