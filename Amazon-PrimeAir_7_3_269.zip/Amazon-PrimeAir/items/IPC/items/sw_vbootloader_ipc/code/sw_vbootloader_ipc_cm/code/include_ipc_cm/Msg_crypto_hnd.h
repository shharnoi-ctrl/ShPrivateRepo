#ifndef MSG_CRYPTO_HND_
#define MSG_CRYPTO_HND_

#include <Stanag_msg.h>

namespace Vbootloader
{
    class Msg_crypto_hnd
    {
    public:
        inline Stanag::Stanag_msg& get_key_gen_hdn()
        {
            return key_gen_hdn;
        }

        inline Stanag::Stanag_msg& get_sign_hdn()
        {
            return sign_hdn;
        }

    private:
        class Key_gen : public Stanag::Stanag_msg
        {
        public:
            /// STANAG Message Receiver Push.
            /// IStanag_msg_rx structure shall declare a pure virtual method for the push function to deserialize the
            /// information to be received. This method must be implemented in derived classes.
            /// \param[in] rx_p Push parameters.
            /// \return Acknowledgment type.
            virtual Base::Msg_data::Ack_type on_rx(Rx_params& rx_p);

            /// STANAG Message Transmitter Pull.
            /// \param tx_p Pull parameters used in the serialization.
            /// \return True if message should be sent, otherwise False.
            virtual bool on_tx(Tx_params& tx_p);
        private:
        };

        class Sign : public Stanag::Stanag_msg
        {
        public:
            /// STANAG Message Receiver Push.
            /// IStanag_msg_rx structure shall declare a pure virtual method for the push function to deserialize the
            /// information to be received. This method must be implemented in derived classes.
            /// \param[in] rx_p Push parameters.
            /// \return Acknowledgment type.
            virtual Base::Msg_data::Ack_type on_rx(Rx_params& rx_p);

            /// STANAG Message Transmitter Pull.
            /// \param tx_p Pull parameters used in the serialization.
            /// \return True if message should be sent, otherwise False.
            virtual bool on_tx(Tx_params& tx_p);
        private:
        };

        Key_gen key_gen_hdn;
        Sign sign_hdn;
    };
}
#endif
