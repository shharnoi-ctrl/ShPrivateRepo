#include <cpu1/CPU1_CM_shared.h>

#include <Routing_table_data.h>
#include <stdio.h>
#include <string.h> // For memset

namespace MCxx
{
    /// \alg
    /// CPU1_CM_shared class shall initialize its internal members as:
    /// <ul>
    ///     <li> ::udp_writer: is constructed with the retrieved value of Spkt_fifo::Reader::get_r_cnt
    /// in CM_CPU1_shared::udp_reader in "cm_shared".
    ///     <li> ::udp_reader: is constructed with the retrieved value of Spkt_fifo::Writer::get_data
    /// in CM_CPU1_shared::udp_writer in "cm_shared" and the retrieved value of Spkt_fifo::Writer::get_w_cnt
    /// in CM_CPU1_shared::udp_writer in "cm_shared".
    ///     <li> ::sys_addr: is initialized with 0. 
    ///     <li> ::uid: is initialized with the retrieved value by calling Bsp::Uid64::build_zero.
    ///     <li> ::eth_mac: is initialized with 0.
    ///     <li> ::ip_addr: is initialized with 0.
    ///     <li> ::net_mask: is initialized with 0.
    ///     <li> ::padding1: is initialized with 0.
    ///     <li> ::port_stg: is initialized with Base::Routing_table_data::def_stg_port
    /// in Base::Routing_table_data templated with 0, and 0.
    ///     <li> ::port_cy: is initialized Base::Routing_table_data::def_cyphal_port
    /// in Base::Routing_table_data templated with 0, and 0.
    /// </ul>
    CPU1_CM_shared::CPU1_CM_shared(const volatile CM_CPU1_shared& cm_shared) :
        udp_writer(cm_shared.udp_reader.get_r_cnt()),
        udp_reader(cm_shared.udp_writer.get_data(), cm_shared.udp_writer.get_w_cnt()),
        sys_addr(0),
        uid(Bsp::Uid64::build_zero()),
        eth_mac(0),
        ip_addr(0),
        net_mask(0),
        padding1(0),
        port_stg(Base::Routing_table_data<0,0>::def_stg_port),
        port_cy (Base::Routing_table_data<0,0>::def_cyphal_port)
    {
    }

    CPU1_CM_shared& get_shared_c1()
    {
        // this object shall be matched in linker for both CPUs
        /// \alg
        /// - Return the statically constructed CPU1_CM_shared with the retrieved value
        /// of calling ::get_shared_cm.
        static CPU1_CM_shared shared_cpu1_cm(get_shared_cm());
        return shared_cpu1_cm;
    }

    const volatile CM_CPU1_shared& get_shared_cm()
    {
        /// \alg
        /// - Return the value found in the pointer reinterpreted cast to const CM_CPU1_shared pointer of the address
        /// 0x00038000.
        static const uint32_t cm_address = 0x00038000; // Address for CMTOCPU1MSGRAM
        return *reinterpret_cast<const volatile CM_CPU1_shared*>(cm_address);
    }
}
