#ifndef GPIOID_IPC_H_
#define GPIOID_IPC_H_

#include <GPIOid.h>

namespace MCxx
{
    /// GPIO mapping for new MC_IPC nets
    namespace GPIOname
    {
        using namespace Dsp28335_ent;
        static const GPIOid gpio_led_bootload      = gpio_019; ///< OUT
        static const GPIOid gpio_led_debug         = gpio_020; ///< OUT
        static const GPIOid gpio_led_warning       = gpio_021; ///< OUT
        static const GPIOid gpio_led_notify        = gpio_099; ///< OUT
        static const GPIOid gpio_sscb_batt_pres    = gpio_023; ///< IN
        static const GPIOid gpio_hrtbeat2_out      = gpio_024; ///< OUT
        static const GPIOid gpio_int_hrtbeat_in    = gpio_030; ///< IN
        static const GPIOid gpio_boot1             = gpio_072; ///< OUT?
        static const GPIOid gpio_boot2             = gpio_084; ///< OUT?
    }
}
#endif
