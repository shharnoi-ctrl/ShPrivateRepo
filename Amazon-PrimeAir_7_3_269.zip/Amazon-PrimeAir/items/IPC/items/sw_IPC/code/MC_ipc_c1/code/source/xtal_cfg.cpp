#include <Kclk.h>

namespace Bsp
{   /// \reqs
    /// Crystal Configuration Retriever.
    /// \wi{17916}
    /// Bsp::Kclk::get_sys_xtal_cfg shall set the system's crystal/oscillator frequency into the given frequency (freq)
    /// and set the flag (is_crystal) to indicate if a crystal or a oscillator is being used.
    void Kclk::get_sys_xtal_cfg(Uint32& freq, bool& is_crystal)
    {
        static const Uint32 xtal_freq = 20000000UL;
        freq = xtal_freq;
        is_crystal = false;
    }
}
