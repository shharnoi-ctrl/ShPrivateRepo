#ifndef MC_C2_MGR_H_
#define MC_C2_MGR_H_

#include <Mc_control.h>

namespace MCxx
{
    /// The MCxx library shall provide a class to manage the Motor Controller operations on Core 2.
    class Mc_c2_mgr
    {
    public:
        /// Motor Controller Core 2 Manager Default Constructor.
        /// \wi{22986}
        /// Mc_c2_mgr class class shall build itself upon construction and initialize its internal members.
        Mc_c2_mgr();
        /// Start Core 2 Operations.
        /// \wi{22987}
        /// Mc_c2_mgr class shall implement a method to start and continuously run the background task of Mc_control.
        void start();

    private:
        Mc_control mc_ctrl; ///< Motor Controllers instance.
    };
}
#endif
