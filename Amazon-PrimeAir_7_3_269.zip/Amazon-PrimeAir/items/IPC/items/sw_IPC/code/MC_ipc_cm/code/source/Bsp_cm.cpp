#include <Sysaddr.h>

#include "cm/CM_CPU1_shared.h"

namespace Bsp
{
    volatile const Base::Address0& sysaddr()
    {
        static Base::Address0 sys_addr = Base::Address0::build(MCxx::get_shared_c1().sys_addr);
        return sys_addr;
    }

    Uid64 get_uid()
    {
        const Uid64 res = { MCxx::get_shared_c1().uid.all };
        return res;
    }
}
