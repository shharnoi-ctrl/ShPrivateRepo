#include "cm/CM_CPU1_shared.h"

#include <type_traits>

namespace MCxx
{
    CM_CPU1_shared::CM_CPU1_shared(const volatile CPU1_CM_shared& c1_shared) :
        udp_writer(c1_shared.udp_reader.get_r_cnt()),
        udp_reader(c1_shared.udp_writer.get_data(), c1_shared.udp_writer.get_w_cnt())
    {
        using namespace Base;

        /// Check that shared memory objects have no virtual methods.
        /// Due to "is_trivially_copyable" check, objects cannot have references nor copy operators.
        static_assert(std::is_trivially_copyable<CM_CPU1_shared>::value, "Error: One or more objects in CM_CPU1_shared are no trivially copyable.");
        static_assert(std::is_trivially_copyable<CPU1_CM_shared>::value, "Error: One or more objects in CPU1_CM_shared are no trivially copyable.");
    }

    const volatile CPU1_CM_shared& get_shared_c1()
    {
        static const uint32_t c1_address = 0x20080000; // Address for CPU1TOCMMSGRAM
        return *reinterpret_cast<const volatile CPU1_CM_shared*>(c1_address);
    }

    CM_CPU1_shared& get_shared_cm()
    {
        // this object shall be matched in linker for both CPUs
        static CM_CPU1_shared shared_cm_cpu1(*const_cast<const CPU1_CM_shared*>(&get_shared_c1()));
        return shared_cm_cpu1;
    }
}
