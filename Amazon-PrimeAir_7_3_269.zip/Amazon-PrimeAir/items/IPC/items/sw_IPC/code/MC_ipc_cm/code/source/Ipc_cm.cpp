#include <Address_handler_generic.h>
#include <Ipc_cm.h>

#include "cm/CM_CPU1_shared.h"

namespace MCxx
{
    using namespace Base;

    namespace
    {
        static const Uint16 ident_map_size = 64U;       ///< Number of addresses in "ident" map.
    }

    Ipc_cm::Ipc_cm(U8pkmblock buffer0) :
        rtable(),
        addr_tunnel(Bsp::sysaddr()),
        stg_suite(rtable, ident_map_size, addr_tunnel),
        cm_port(stg_suite.get_router(),
                get_shared_cm().udp_writer,
                get_shared_cm().udp_reader)
    {
        stg_suite.get_router().add_port(cm_port);
    }

    void Ipc_cm::step()
    {
        cm_port.step();
        stg_suite.step();
    }
}
