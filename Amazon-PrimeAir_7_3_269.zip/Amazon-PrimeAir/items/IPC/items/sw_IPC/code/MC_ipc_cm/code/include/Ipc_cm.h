#ifndef IPC_CM_H_
#define IPC_CM_H_

#include <Address_tunnel.h>
#include <cm/CM_CPU1_shared_types.h>
#include <Fifo_port.h>
#include <Routing_table_sc.h>
#include <Stanag_msg_forwarder.h>
#include <Stanag_suite_lite.h>

#include <Pkt_router_fw.h>

namespace MCxx
{
    class Ipc_cm
    {
    public:
        static const Uint16 num_rtables = 1U;           ///< Max number of routing tables.
        static const Uint16 num_tables_entries = 16U;   ///< Max number of routing entries per table.
        typedef Base::Routing_table_sc<num_rtables, num_tables_entries> Rtable_t; ///< Routing table type.

        explicit Ipc_cm(Base::U8pkmblock buffer0);

        /// Retrieve packet router.
        /// \return Packet router.
        inline Base::Pkt_router& get_router()
        {
            return stg_suite.get_router();
        }

        inline Rtable_t& get_routing_table()
        {
            return rtable;
        }

        void step();

    private:
        Rtable_t rtable;                                                ///< Routing table.
        Base::Address_tunnel addr_tunnel;                               ///< Address handler tunnel.
        Stanag::Stanag_suite_lite stg_suite;                            ///< Stanag suite.
        Base::Fifo_port<Spkt_fifo::Writer, Spkt_fifo::Reader> cm_port;  ///< Port to read and write messages from/to C1 core

        Ipc_cm(const Ipc_cm&); ///< = delete
        Ipc_cm& operator=(const Ipc_cm&); ///< = delete
    };
}
#endif
