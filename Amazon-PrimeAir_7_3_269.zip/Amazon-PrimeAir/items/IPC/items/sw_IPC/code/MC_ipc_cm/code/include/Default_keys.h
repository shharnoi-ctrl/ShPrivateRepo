#ifndef DEFAULT_KEYS_H_
#define DEFAULT_KEYS_H_

#include <Entypes.h>

namespace MCxx
{
    /// Default private key size.
    static const Uint16 prv_key_sz = 32U;
    /// Default private key size in words.
    static const Uint16 prv_key_wsz = (prv_key_sz + 1U)/2U;
    /// Default public key size.
    static const Uint16 pub_key_sz = 1U + prv_key_sz*2U;
    /// Default public key size in words.
    static const Uint16 pub_key_wsz = (pub_key_sz + 1U)/2U;
    /// Default Public key value.
    extern const Uint16 def_prv_key[prv_key_wsz];
    /// Default Public key value.
    extern const Uint16 def_pub_key[pub_key_wsz];
}

#endif
