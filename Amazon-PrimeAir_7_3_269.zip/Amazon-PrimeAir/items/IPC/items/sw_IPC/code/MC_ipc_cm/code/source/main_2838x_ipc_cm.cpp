#include <Allocator.h>
#include <App_blrd_hdr.h>
#include <CM_commands.h>
#include "cm/CM_CPU1_shared.h"
#include <Compute_hash.h>
#include <Default_keys.h>
#include "driverlib_cm/flash.h"
#include "driverlib_cm/sysctl.h"
#include "driverlib_cm/systick.h"
#include <Generate_keys.h>
#include <Mblock_s.h>
#include <Sign_hash.h>
#include <Sysapp.h>
#include <Sysver.h>
#include <Tnarray.h>
#include <Warning.h>

static const Uint32 app_start = 0x220000UL;     ///< App starting address
static const Uint32 app_max_size = 0x60000;     ///< Application size (0x80000 - BLDR size).
static const Uint32 app_crc  = 0x7d938c2c;      ///< Application CRC.

//*****************************************************************************
// The local time for the lwIP Library Abstraction layer, used to support the
// Host and lwIP periodic callback functions.
//*****************************************************************************
volatile uint32_t msTime=0;

// These are defined by the linker (see device linker command file)
extern uint16_t RamfuncsLoadStart;
extern uint16_t RamfuncsLoadSize;
extern uint16_t RamfuncsRunStart;
extern uint16_t RamfuncsLoadEnd;
extern uint16_t RamfuncsRunEnd;
extern uint16_t RamfuncsRunSize;

extern uint16_t constLoadStart;
extern uint16_t constLoadEnd;
extern uint16_t constLoadSize;
extern uint16_t constRunStart;
extern uint16_t constRunEnd;
extern uint16_t constRunSize;

#define DEVICE_FLASH_WAITSTATES 2

//*****************************************************************************
// Driver specific initialization code and macro.
//*****************************************************************************
//uint32_t systickPeriodValue = 125000UL; //1Khz @ 125Mhz
uint32_t systickPeriodValue = 62500UL;  //2Khz @ 125Mhz

//*****************************************************************************
void CM_init(void)
{
    // Disable the watchdog
    SysCtl_disableWatchdog();

    // Copy time critical code and flash setup code to RAM. This includes the
    // following functions: InitFlash();
    //
    // The RamfuncsLoadStart, RamfuncsLoadSize, and RamfuncsRunStart symbols
    // are created by the linker. Refer to the device .cmd file.
    // Html pages are also being copied from flash to ram.
    //
    memcpy(&RamfuncsRunStart, &RamfuncsLoadStart, (size_t)&RamfuncsLoadSize);
    memcpy(&constRunStart, &constLoadStart, (size_t)&constLoadSize);

    // Call Flash Initialization to setup flash waitstates. This function must
    // reside in RAM.
    Flash_initModule(FLASH0CTRL_BASE, FLASH0ECC_BASE, DEVICE_FLASH_WAITSTATES);

    // Sets the NVIC vector table offset address.
    Interrupt_setVectorTableOffset((uint32_t)vectorTableFlash);
}

//*****************************************************************************
// Memory Manager init starts here
/// General allocator memory size
static const Uint32 mem_sz  = 11080UL;
Uint16 memmgr_buf[mem_sz];
// memory manager init ends here

// The interrupt handler for the SysTick interrupt.
extern "C" void SysTickIntHandler(void)
{
}

void main(void)
{
    using namespace Base;
    using namespace MCxx;

    // Force creation of the App bootloader header.
    if(App_blr_hdr_inst<app_crc, app_max_size, Bsp::sapp_invalid, 2U>::instance.bld_hdr_mark != Base::App_blr_hdr::hdr_bldr_mark_v)
    {
        Bsp::warning();
    }

    // Initializing the CM. Loading the required functions to SRAM.
    CM_init();

    static Allocator alloc(memmgr_buf, mem_sz);

    Memmgr::get_instance().add_allocator(Memmgr::internal, alloc);
    Memmgr::get_instance().add_allocator(Memmgr::external, alloc);

    // Emb: Initialize shared RAM
    get_shared_cm();

    // Flag startup finished
    IPC_setFlagLtoR(IPC_CM_L_CPU1_R, IPC_FLAG0);

    // Wait for C1 to finish startup
    IPC_waitForFlag(IPC_CM_L_CPU1_R, IPC_FLAG1);

    // Enable processor interrupts.
    Interrupt_enableInProcessor();

    static const Uint16 buffer_sz = 4096U;
    static Uint8 data_buffer[buffer_sz];
    U8pkmblock buffer(data_buffer, buffer_sz);

    SYSTICK_setPeriod(systickPeriodValue);
    SYSTICK_enableCounter();
    SYSTICK_registerInterruptHandler(SysTickIntHandler);
    SYSTICK_enableInterrupt();

    const volatile CPU1_CM_shared& shared_c1(get_shared_c1());
    CM_CPU1_shared& shared_cm = get_shared_cm();

    shared_cm.ready = false;

    CM_commands actual_cmd = shared_c1.cm_cmd;
    switch(actual_cmd)
    {
        case comp_hash:
        {
            // Calculate SHA256 of the application area and put the result in shared memory
            const Base::Mblock_s m = { app_start, app_max_size };
            Crypto_arm::compute_hash(m, shared_cm.cmhash_data);
            break;
        }

        case gen_keys:
        {
            // Generate private and public key, then set keygen ready flag
            Crypto_arm::generate_keys(shared_cm.prv_key, shared_cm.pub_key);
            break;
        }

        case sign_chall:
        {
            // Sign the hash using the private key provided by C1 and share the result
            Crypto_arm::sign_hash(const_cast<const Base::Prv_key::Type&>(shared_c1.prv_key), const_cast<const Base::Sha256_data::Type&>(shared_c1.hash), shared_cm.signature);
            break;
        }
        case load_def_keys:
        {
            // Load the default keys to shared memory
            Tnarray<Uint16, prv_key_wsz> prv_key_arr;
            Tnarray<Uint16, pub_key_wsz> pub_key_arr;
            prv_key_arr.copy_all(def_prv_key);
            pub_key_arr.copy_all(def_pub_key);
            shared_cm.prv_key.copy(prv_key_arr);
            shared_cm.pub_key.copy(pub_key_arr);
            break;
        }
        default:
        {
            break;
        }
    }
    shared_cm.ready = true;

    while(true)
    {
    }
}
