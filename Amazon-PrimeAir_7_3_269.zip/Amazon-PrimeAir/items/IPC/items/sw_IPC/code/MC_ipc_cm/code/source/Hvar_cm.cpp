#include <Hbvar.h>
#include <Huvar.h>

/// Hvar class implementation.

namespace Bsp
{
    // BSP Hvar funcs implementation

    Hbvar::Hbvar(Base::Bvar id0) : id(Base::validate(id0))
    {
    }

    Huvar::Huvar(Base::Uvar id0) : id(Base::validate(id0))
    {
    }

    // Bvar
    bool Hbvar::get() const
    {
        // Just Always true an always false Vars supported
        return get_kref();
    }

    const volatile bool& Hbvar::get_kref() const
    {
        static const bool ret_true  = true;
        static const bool ret_false = false;
        const bool& res = (id == Base::kbit_ok) ? ret_true : ret_false;
        return res;
    }

    void Hbvar::set(bool v) //PRQA S 4211 #const
    {
        Bsp::warning();
    }

    // Uvar
    Uint16 Huvar::get() const
    {
        Bsp::warning();
        return 0;
    }

    void Huvar::set(Uint16 v) //PRQA S 4211 #const
    {
        //Ignore this
    }
}
