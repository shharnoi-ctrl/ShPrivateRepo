# Battery Management System (BMS) Architecture Report

## Executive Summary

The Battery Management System (BMS) is a critical component in Amazon Prime Air drones responsible for monitoring, controlling, and protecting battery packs. The system implements a hierarchical architecture with real-time and background processing capabilities, ensuring safe and efficient battery operation through comprehensive monitoring of cell voltages, temperatures, currents, and overall battery health.

## System Architecture Overview

The BMS follows a layered architecture with clear separation of concerns:

```mermaid
graph TB
    subgraph "Application Layer"
        BM[Battery Manager<br/>Central Controller]
        BS[BMS Suite<br/>Component Coordinator]
    end
    
    subgraph "Data Management Layer"
        BV[BMS_vars<br/>Data Access]
        BR[BMS Report<br/>Communication]
        BST[BMS Stats<br/>Statistics Engine]
    end
    
    subgraph "Feature Layer"
        CB[Cell Balancing]
        SOC[State of Charge]
        HM[Health Monitor]
        LM[Lifetime Manager]
    end
    
    subgraph "Hardware Interface Layer"
        AFE[AFE Suite<br/>Cell Monitoring]
        HAL[HAL Suite<br/>Hardware Abstraction]
        TEMP[Temperature Sensors]
        EEPROM[Non-Volatile Storage]
    end
    
    subgraph "Communication Layer"
        CAN[CAN Interface]
        UART[UART Interface]
        I2C[I2C Interface]
    end
    
    BM --> BS
    BS --> BV
    BS --> BR
    BS --> BST
    BS --> CB
    BS --> SOC
    BS --> HM
    BS --> LM
    BS --> AFE
    BS --> HAL
    AFE --> TEMP
    LM --> EEPROM
    HAL --> CAN
    HAL --> UART
    HAL --> I2C
    BR --> CAN
```

## Execution Model

The BMS implements a dual-priority task execution model to ensure both real-time responsiveness and comprehensive background processing:

```mermaid
graph LR
    subgraph "Interrupt Context (6 kHz)"
        ISR[Timer ISR] --> HP[High Priority Tasks]
        HP --> AFE_HI[AFE Communication]
        HP --> CAN_HI[CAN Transfers]
        HP --> UART_HI[UART Transfers]
        HP --> I2C_HI[I2C Arbitration]
    end
    
    subgraph "Main Loop (100 Hz)"
        ML[Main Loop] --> LP[Low Priority Tasks]
        LP --> SM[Step Manager]
        SM --> TASKS[Subsystem Tasks]
    end
    
    subgraph "Task Frequencies"
        F100[100 Hz Tasks<br/>Voltage Sampling<br/>SoC Computation]
        F10[10 Hz Tasks<br/>Temperature Sampling<br/>Cell Balancing]
        F5[5 Hz Tasks<br/>Statistics<br/>Health Monitoring]
        F1[1 Hz Tasks<br/>EEPROM Writing<br/>Telemetry]
    end
    
    SM --> F100
    SM --> F10
    SM --> F5
    SM --> F1
```

## Core Components

### 1. Battery Manager (Central Controller)

The Battery Manager serves as the system's central controller, orchestrating all BMS operations:

```mermaid
classDiagram
    class Battery_manager {
        +init()
        +step_hi()
        +bg_task()
        -suite: BMS_suite
        -smgr: Stepmgr
        -freq_checker: Frequency_checker
    }
    
    class BMS_suite {
        +step_hi()
        +step()
        -afes: AFE_suite
        -cbal: Cell_balancing
        -soc: SOC
        -hlt: Health_monitor
        -comm: BMS_report
        -stats: BMS_stats
    }
    
    class Stepmgr {
        +add(id, task)
        +step()
        -tasks: Task[]
    }
    
    Battery_manager --> BMS_suite
    Battery_manager --> Stepmgr
```

### 2. Data Flow Architecture

The system implements a comprehensive data flow from acquisition to reporting:

```mermaid
sequenceDiagram
    participant AFE as AFE Driver
    participant BV as BMS_vars
    participant BS as BMS_stats
    participant HM as Health Monitor
    participant BR as BMS_report
    participant EXT as External System
    
    AFE->>BV: Store Raw Measurements
    BV->>BS: Process Statistics
    BV->>HM: Monitor Health
    BS->>BV: Store Statistics
    HM->>BV: Store Alert Flags
    BV->>BR: Generate Reports
    BR->>EXT: Send Telemetry
```

## Alert System Architecture

The BMS implements a comprehensive alert system with pack-level and string-level monitoring:

```mermaid
graph TD
    subgraph "Alert System"
        AI[Alert Interface<br/>Ialert]
        AB[Alert Base<br/>Alert_it]
        
        subgraph "Pack Alerts"
            PA[Pack_alerts Manager]
            PA1[Imbalance Current]
            PA2[High PCBA Temp]
            PA3[Firmware Error]
            PA4[Low SoC]
        end
        
        subgraph "String Alerts"
            SA[String_alerts Manager]
            SA1[Cell Temperature]
            SA2[Cell Voltage]
            SA3[String Current]
            SA4[Sensor Validity]
        end
        
        AM[Alerts Manager]
        BM32[32-bit Bitmask]
    end
    
    AI --> AB
    AB --> PA1
    AB --> PA2
    AB --> PA3
    AB --> PA4
    AB --> SA1
    AB --> SA2
    AB --> SA3
    AB --> SA4
    PA --> AM
    SA --> AM
    AM --> BM32
```

### Alert Processing State Machine

```mermaid
stateDiagram-v2
    [*] --> Inactive
    Inactive --> Timing: Condition Met
    Timing --> Active: Timeout Expired
    Timing --> Inactive: Condition Cleared
    Active --> Inactive: Non-Latched & Cleared
    Active --> Latched: Latched Alert
    Latched --> Latched: Permanent
```

## AFE Driver Architecture

The Analog Front End driver interfaces with BQ79616 chips for battery monitoring:

```mermaid
graph TB
    subgraph "AFE Driver Stack"
        subgraph "Application Layer"
            AS[AFE_suite<br/>Multi-chip Coordinator]
            AA[AFE_app<br/>Single Chip Manager]
        end
        
        subgraph "Request Layer"
            BR[BQ_request<br/>Request Builder]
            BP[BQ_ping<br/>Hardware Signaling]
        end
        
        subgraph "Processing Layer"
            BM[BQ_meas<br/>Measurement Processing]
            BV[BQ_vars<br/>Variable Storage]
        end
        
        subgraph "Communication Layer"
            BPK[BQ_packet<br/>Protocol Handler]
            BD[BQ_driver<br/>UART Driver]
            BB[BQ_buffer<br/>Data Buffers]
        end
    end
    
    AS --> AA
    AA --> BR
    AA --> BP
    BR --> BM
    BM --> BV
    BR --> BPK
    BPK --> BD
    BD --> BB
```

## Hardware Abstraction Layer

The HAL provides unified access to hardware peripherals:

```mermaid
classDiagram
    class Halsuite {
        +i2ca: I2C_bms
        +i2cb: I2C_bms
        +uart1: Uart
        +uart2: Uart
        +can: Canbus
        +rtc: Int_rtc
        +watchdog: Kickdog
        +overlock: Gpio_pin
        +i2ca_arb: I2C_arbitrator
    }
    
    class GPIO_config {
        +nMCU_RESET: Gpio_pin
        +RX_EN: Gpio_pin
        +TX_EN: Gpio_pin
        +WAKE: Gpio_pin
        +LED_1: Gpio_pin
        +LED_2: Gpio_pin
    }
    
    class HWversion {
        +detect()
        +get_version()
        -gpio_pins: uint8
        -otp_version: uint8
    }
    
    Halsuite --> GPIO_config
    Halsuite --> HWversion
```

## Battery Management Features

### Cell Balancing System

```mermaid
graph LR
    subgraph "Cell Balancing Logic"
        CV[Cell Voltages] --> DIFF[Calculate Difference]
        DIFF --> THRESH{Difference > 30mV?}
        THRESH -->|Yes| CHECK{All cells > 3.3V?}
        CHECK -->|Yes| ENABLE[Enable Balancing]
        CHECK -->|No| DISABLE[Disable Balancing]
        THRESH -->|No| DISABLE
        ENABLE --> MON{Difference < 15mV?}
        MON -->|Yes| DISABLE
        MON -->|No| ENABLE
    end
```

### State of Charge Calculation

```mermaid
graph TD
    subgraph "SOC Computation"
        OCV[Open Circuit Voltage] --> LUT[Lookup Table]
        LUT --> SOC_OCV[OCV-based SOC]
        
        CURR[Current Measurement] --> CC[Coulomb Counting]
        TIME[Elapsed Time] --> CC
        CC --> SOC_CC[Coulomb Count SOC]
        
        SOC_OCV --> COMB[Combine Methods]
        SOC_CC --> COMB
        COMB --> SOC_STR[String SOC]
        
        SOC_STR --> MIN[Minimum]
        MIN --> SOC_PACK[Pack SOC]
    end
```

## System Initialization Sequence

```mermaid
sequenceDiagram
    participant BOOT as Bootloader
    participant PRE as Pre-Init
    participant HW as Hardware Init
    participant APP as Application
    participant BMS as BMS System
    
    BOOT->>PRE: Start System
    PRE->>PRE: Configure Clocks
    PRE->>PRE: Setup Memory
    PRE->>HW: Initialize Hardware
    HW->>HW: Detect HW Version
    HW->>HW: Configure GPIO
    HW->>HW: Setup Peripherals
    HW->>APP: Start Application
    APP->>BMS: Initialize BMS
    BMS->>BMS: Load Configuration
    BMS->>BMS: Start Tasks
    BMS->>BMS: Begin Monitoring
```

## Communication Architecture

The BMS supports multiple communication interfaces for different purposes:

```mermaid
graph TB
    subgraph "Communication Interfaces"
        subgraph "CAN Bus"
            CANRX[CAN RX] --> CANP[CAN Processing]
            CANP --> CANTX[CAN TX]
        end
        
        subgraph "UART Interfaces"
            UART1[UART1<br/>AFE Comm] --> AFE[AFE Devices]
            UART2[UART2<br/>Debug/Telemetry] --> EXT[External]
        end
        
        subgraph "I2C Interfaces"
            I2CA[I2C A] --> TEMP[Temperature Sensors]
            I2CB[I2C B] --> EEPROM[EEPROM Storage]
        end
    end
    
    subgraph "Message Types"
        BP[Battery Power<br/>10 Hz]
        BT[Battery Temperature<br/>1 Hz]
        BS[Battery Summary<br/>1 Hz]
    end
    
    CANP --> BP
    CANP --> BT
    CANP --> BS
```

## Lifetime Statistics Management

The system tracks long-term battery usage with redundant storage:

```mermaid
classDiagram
    class Lifetime_mgr {
        +save_stats()
        +load_stats()
        +update_stats()
        -cumulative_charge: uint32
        -cumulative_discharge: uint32
        -max_temperature: int16
        -min_temperature: int16
        -max_voltage: uint16
        -min_voltage: uint16
    }
    
    class EEPROM_24CS {
        +write()
        +read()
        +verify()
        -primary_page: Page
        -backup_page: Page
    }
    
    class Redundancy {
        +write_with_backup()
        +read_with_recovery()
        -crc_check()
    }
    
    Lifetime_mgr --> EEPROM_24CS
    EEPROM_24CS --> Redundancy
```

## Health Monitoring System

The health monitoring system provides comprehensive fault detection:

```mermaid
graph TD
    subgraph "Health Monitor"
        HM[Health Monitor] --> PA[Pack Alerts]
        HM --> SA[String Alerts]
        
        PA --> PAF{Pack Alert Flags}
        SA --> SAF{String Alert Flags}
        
        PAF --> DEC[Decision Logic]
        SAF --> DEC
        
        DEC --> ACT[Actions]
        ACT --> CHG[Disable Charger]
        ACT --> LOG[Log Event]
        ACT --> TEL[Send Telemetry]
        ACT --> NVM[Store in NVM]
    end
```

## Performance Characteristics

### Task Execution Timing

| Task Category | Frequency | Period | Priority | Typical Duration |
|--------------|-----------|---------|----------|-----------------|
| High Priority | 6 kHz | 167 μs | Interrupt | < 50 μs |
| Low Priority | 100 Hz | 10 ms | Background | < 5 ms |
| Sampling Tasks | 100 Hz | 10 ms | Normal | < 1 ms |
| Processing Tasks | 10 Hz | 100 ms | Normal | < 10 ms |
| Health Tasks | 5 Hz | 200 ms | Normal | < 20 ms |
| Communication | 1 Hz | 1 s | Low | < 50 ms |

### Memory Utilization

```mermaid
pie title Memory Allocation
    "Application Code" : 35
    "AFE Driver" : 20
    "Alert System" : 15
    "Communication" : 10
    "Statistics" : 8
    "Health Monitor" : 7
    "Lifetime Data" : 5
```

## System Reliability Features

### Fault Tolerance Mechanisms

1. **Redundant Data Storage**: Critical data stored in multiple EEPROM locations
2. **CRC Validation**: All communication packets include CRC checks
3. **Timeout Monitoring**: All operations have defined timeout periods
4. **Watchdog Timer**: System reset on task execution failures
5. **Alert Latching**: Critical alerts persist until manual intervention
6. **Graceful Degradation**: System continues operation with reduced functionality

### Safety Features

```mermaid
graph LR
    subgraph "Safety Mechanisms"
        OV[Over-Voltage Protection] --> DISC[Disconnect]
        UV[Under-Voltage Protection] --> DISC
        OC[Over-Current Protection] --> DISC
        OT[Over-Temperature Protection] --> DISC
        
        BAL[Cell Balancing] --> SAFE[Safe Operation]
        MON[Continuous Monitoring] --> SAFE
        VAL[Data Validation] --> SAFE
    end
```

## Configuration Parameters

### Key System Constants

| Parameter | Value | Description |
|-----------|-------|-------------|
| Number of Strings | Variable | Typically 2-4 strings |
| Cells per String | 14 | Fixed configuration |
| Max Cell Voltage | 4.28V | Charge termination |
| Min Cell Voltage | 2.8V | Discharge cutoff |
| Balance Threshold | 30mV | Start balancing |
| Balance Hysteresis | 15mV | Stop balancing |
| Max Charge Current | 20A | Per string limit |
| Max Discharge Current | 167A | Per string limit |

## System Integration Points

The BMS integrates with multiple vehicle systems:

```mermaid
graph TB
    subgraph "Vehicle Systems"
        FCS[Flight Control System]
        PMS[Power Management System]
        GCS[Ground Control Station]
        CHG[Charging System]
    end
    
    subgraph "BMS Interfaces"
        BMS[Battery Management System]
        CAN[CAN Interface]
        GPIO[GPIO Signals]
        TELEM[Telemetry]
    end
    
    FCS <--> CAN
    PMS <--> CAN
    GCS <--> TELEM
    CHG <--> GPIO
    
    CAN <--> BMS
    GPIO <--> BMS
    TELEM <--> BMS
```

## Conclusion

The Battery Management System implements a robust, hierarchical architecture designed for critical safety applications. The system's dual-priority execution model ensures real-time responsiveness while maintaining comprehensive monitoring capabilities. Through its layered design, comprehensive alert system, and multiple safety mechanisms, the BMS provides reliable battery management essential for drone operations.

Key architectural strengths include:
- Clear separation of concerns through modular design
- Comprehensive fault detection and handling
- Efficient resource utilization through multi-rate scheduling
- Robust communication with multiple redundancy mechanisms
- Extensive health monitoring and lifetime tracking capabilities

This architecture ensures safe, efficient, and reliable battery operation throughout the vehicle's operational lifetime.