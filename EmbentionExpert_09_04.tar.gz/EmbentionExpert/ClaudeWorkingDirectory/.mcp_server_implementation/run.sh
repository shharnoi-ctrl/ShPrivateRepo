#!/bin/bash
set -e

# Ensure uv is installed
if ! command -v uv > /dev/null; then
  echo "uv not found. Please install it first: pip install uv"
  exit 1
fi

# Check if Quarto is installed
if ! command -v quarto > /dev/null; then
  echo "Quarto not found. Please install it by running the appropriate command for your OS:"
  
  OS_TYPE="$(uname -s)"
  
  if [ "$OS_TYPE" = "Darwin" ]; then
    # macOS
    echo "  brew install quarto"
  elif [ "$OS_TYPE" = "Linux" ]; then
    # Ubuntu/Debian
    echo "  # 1. Download the latest Quarto .deb package"
    echo "  wget https://quarto.org/download/latest/quarto-linux-amd64.deb"
    echo "  # 2. Install the package"
    echo "  sudo apt install ./quarto-linux-amd64.deb"
    echo "  # 3. Verify installation"
    echo "  quarto --version"
  else
    echo "Unsupported OS: $OS_TYPE. Please install Quarto manually from https://quarto.org/docs/download/"
  fi

  exit 1
fi

# Get the directory this script is in
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Start the MCP server using uv's environment
uv run python "$SCRIPT_DIR/server.py"
