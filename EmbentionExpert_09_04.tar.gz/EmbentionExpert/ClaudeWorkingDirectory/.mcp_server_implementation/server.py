#!/usr/bin/env python3
import os
import sys
import tempfile
import subprocess
from pathlib import Path

from fastmcp import FastMCP

app = FastMCP("Markdown Report Generator")

@app.tool()
def generate_html_report(
    file_path: str,
    contents: str = None
) -> str:
    """
    Generate an HTML report from Markdown using Quarto.  Should be used whenever the user asks to produce an html report.
    This report has support for
    - Mermaid diagrams using fenced code blocks with mermaid
    - LaTeX math in Markdown using $...$ for inline or $$...$$ for display equations

    Args:
        file_path (str): If contents is provided: suggested filepath for the output report with no extension (eg. "./puppies_report").
                         If contents is not provided: path to an existing markdown file to process.
        contents (str, optional): Raw Markdown content to process and save to file. If not provided, content will be read from file_path.

    Returns:
        str: Path to the generated HTML file.
    """
    if not file_path:
        raise ValueError("Must provide a file_path.")
    
    input_path = Path(file_path)
    
    if contents is not None:
        # If contents is provided, save it to a new .md file
        base_name = input_path.stem
        dir_path = input_path.parent
        
        # Create the md file
        md_file = os.path.join(dir_path, base_name) + ".md"
        
        with open(md_file, "w", encoding="utf-8") as f:
            f.write(contents)
    else:
        # If contents is not provided, use the existing file
        if not input_path.exists():
            raise ValueError(f"File not found: {file_path}")
        
        # Use the existing file
        md_file = str(input_path)
        base_name = input_path.stem
        dir_path = input_path.parent
    
    # Replace mermaid with {mermaid} in the file
    subprocess.run(["sed", "-i.bak", "s/mermaid/{mermaid}/g", str(md_file)])
    
    # Convert .md to .qmd
    qmd_file = dir_path / f"{base_name}.qmd"
    os.rename(md_file, qmd_file)
    
    # Use quarto to render the .qmd file to HTML with embedded resources
    subprocess.run(["quarto", "render", str(qmd_file), "--to", "html", "--embed-resources"])
    
    # The output HTML file will be in the same directory
    html_file = dir_path / f"{base_name}.html"
    
    # Delete the temporary .qmd file
    os.remove(qmd_file)
    
    # If there's a backup file from sed, remove it
    bak_file = dir_path / f"{base_name}.qmd.bak"
    if bak_file.exists():
        os.remove(bak_file)
        
    bak_file = dir_path / f"{base_name}.md.bak"
    if bak_file.exists():
        os.rename(bak_file, md_file)

    return str(html_file)

if __name__ == "__main__":
    app.run()
