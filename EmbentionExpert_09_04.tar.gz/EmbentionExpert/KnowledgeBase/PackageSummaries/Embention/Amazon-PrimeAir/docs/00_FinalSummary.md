# Generated from:

- Amazon-PrimeAir/docs/02_System_Overview.md (2673 tokens)
- Amazon-PrimeAir/docs/06_Development_Environment_Setup.md (1639 tokens)
- Amazon-PrimeAir/docs/05_FULLSIM_Testing.md (2730 tokens)
- Amazon-PrimeAir/docs/04_HILSIM_Testing.md (2455 tokens)
- Amazon-PrimeAir/docs/03_Post_Flight_Analysis.md (1890 tokens)
- Amazon-PrimeAir/docs/02_Testing_Workflow.md (2433 tokens)
- Amazon-PrimeAir/docs/01_Complete_System_Documentation.md (3415 tokens)

---

# Amazon Prime Air Knowledge Base: System Overview and Architecture

## Introduction to the Knowledge Base

This document serves as the primary entry point to the Amazon Prime Air knowledge base, providing a comprehensive overview of the system architecture, development environment, testing workflows, and analysis tools. It is designed to help you understand the overall structure of the system and navigate to more detailed information in specific areas.

## System Architecture Overview

The Amazon Prime Air drone control system consists of three primary components that work together to provide a comprehensive environment for drone control, testing, and resource management:

1. **FULLSIM (Software-in-the-Loop)** - A simulation environment where all components are simulated in software, providing rapid iteration and basic validation
2. **HILSIM (Hardware-in-the-Loop)** - A simulation environment where actual hardware components (like flight controllers) are integrated into the simulation for more realistic testing
3. **Oasis** - A resource management platform that coordinates access to simulation resources and manages job execution

These components form an integrated ecosystem for developing, testing, and deploying drone control software, with specific workflows for each stage of the development process.

### Component Relationships and Interactions

The three primary components interact in a progressive workflow:

- **FULLSIM** serves as the first stage in the testing pipeline, allowing for rapid iteration and basic validation before proceeding to hardware testing
- **HILSIM** extends the simulation capabilities by incorporating actual hardware components, creating a hybrid environment for more realistic testing
- **Oasis** coordinates access to limited hardware resources and provides a structured workflow for test execution and analysis

## Development Environment

The development environment for Amazon Prime Air consists of two main components:

1. **Cloud Desktop** - A high-performance virtual machine (m7i.24xlarge) used for creating Brazil workspaces, running simulations, and executing tests
2. **Windows Laptop** - Used to access the Prime Air environment, typically through VS Code connected to the Cloud Desktop

For detailed setup instructions, see [Development Environment Setup](06_Development_Environment_Setup.md).

## Testing Workflow

The Amazon Prime Air testing workflow follows a progressive validation approach:

```
[Development] → [FULLSIM Testing] → [HILSIM Testing] → [Post-Flight Analysis]
```

This workflow ensures code quality and system reliability through increasingly realistic testing environments:

1. **FULLSIM Testing** - Software-in-the-loop simulation for initial validation
   - Fast execution (minutes to hours)
   - No hardware requirements
   - Detailed in [FULLSIM Testing](05_FULLSIM_Testing.md)

2. **HILSIM Testing** - Hardware-in-the-loop simulation for hardware validation
   - Moderate to slow execution (hours to days including setup)
   - Requires specialized Hilsim resources
   - Detailed in [HILSIM Testing](04_HILSIM_Testing.md)

3. **Post-Flight Analysis** - Comprehensive evaluation of test results
   - Data-driven evaluation of system performance
   - Uses telemetry processing and visualization tools
   - Detailed in [Post Flight Analysis](03_Post_Flight_Analysis.md)

For a comprehensive overview of the testing workflow, see [Testing Workflow](02_Testing_Workflow.md).

## Key System Components

### Oasis Platform

Oasis serves as the central management platform with the following capabilities:

- **Resource Management** - Shows status and availability of simulation hardware, allows reservation of resources
- **Job Management** - Supports execution, cloning, and modification of jobs on reserved resources
- **Configuration Management** - Supports deployment of software bundles and loading of configurations

### Software Release Process

The software release process follows a structured path:

1. **Development Branches** - DEV/SUPPORT branches contain current project work
2. **Release Stages**:
   - **Drop xx release** - Unstable, not fully tested software release
   - **DROPs Δ RC (Release Candidate)** - Stable release with functional increments
   - **DROPs Δ RTM (Release To Manufacturing)** - Verification status agreed with PA
3. **Release Assets** - SIL library (.so), TI binaries, changelog, PDI configuration

## Repository Structure

The system uses a structured repository approach:

- **EMB Organization Repositories** - Used for internal development
- **AMZ-PA Repository** - Provides access for AMZ-PA
- **Branch Structure**:
  - DEV/SUPPORT branches for current work
  - Support branches created after closing scope of functionality

## Navigation Guide to Knowledge Base

For more detailed information on specific topics, refer to the following documents:

1. [Complete System Documentation](01_Complete_System_Documentation.md) - Comprehensive overview of the entire system
2. [System Overview](02_System_Overview.md) - Detailed description of system architecture and components
3. [Testing Workflow](02_Testing_Workflow.md) - End-to-end testing process from development to analysis
4. [Post Flight Analysis](03_Post_Flight_Analysis.md) - Tools and techniques for analyzing flight data
5. [HILSIM Testing](04_HILSIM_Testing.md) - Hardware-in-the-loop simulation testing procedures
6. [FULLSIM Testing](05_FULLSIM_Testing.md) - Software-in-the-loop simulation testing procedures
7. [Development Environment Setup](06_Development_Environment_Setup.md) - Setup instructions for development environment

## System Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│                                                                 │
│                        Development Environment                  │
│                                                                 │
│  ┌───────────────┐                         ┌───────────────┐    │
│  │ Windows Laptop│◄────SSH/VS Code────────►│ Cloud Desktop │    │
│  └───────────────┘                         └───────────────┘    │
│                                                  │              │
└──────────────────────────────────────────────────┼──────────────┘
                                                   │
                                                   ▼
┌─────────────────────────────────────────────────────────────────┐
│                                                                 │
│                        Testing Pipeline                         │
│                                                                 │
│  ┌───────────────┐     ┌───────────────┐     ┌───────────────┐  │
│  │    FULLSIM    │────►│    HILSIM     │────►│  Post-Flight  │  │
│  │  (Software)   │     │  (Hardware)   │     │   Analysis    │  │
│  └───────────────┘     └───────────────┘     └───────────────┘  │
│                              │                                  │
└──────────────────────────────┼──────────────────────────────────┘
                               │
                               ▼
┌─────────────────────────────────────────────────────────────────┐
│                                                                 │
│                        Oasis Platform                           │
│                                                                 │
│  ┌───────────────┐     ┌───────────────┐     ┌───────────────┐  │
│  │   Resource    │     │      Job      │     │ Configuration │  │
│  │  Management   │     │   Management  │     │  Management   │  │
│  └───────────────┘     └───────────────┘     └───────────────┘  │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

## Conclusion

The Amazon Prime Air drone control system provides a comprehensive environment for drone control development, testing, and deployment. The integration of FULLSIM, HILSIM, and Oasis creates a powerful ecosystem that supports the entire development lifecycle, from initial software testing to hardware validation and release management.

This knowledge base is designed to help you navigate the system and find detailed information on specific components and processes. Start with the overview documents to understand the big picture, then dive into specific areas as needed.