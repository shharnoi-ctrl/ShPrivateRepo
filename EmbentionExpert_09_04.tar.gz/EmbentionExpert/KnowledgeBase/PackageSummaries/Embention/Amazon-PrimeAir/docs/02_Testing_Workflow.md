# Generated from:

- Amazon-PrimeAir/docs/05_FULLSIM_Testing.md (2730 tokens)
- Amazon-PrimeAir/docs/04_HILSIM_Testing.md (2455 tokens)
- Amazon-PrimeAir/docs/03_Post_Flight_Analysis.md (1890 tokens)

---

# Comprehensive Testing Workflow for Amazon Prime Air

This document provides a high-level overview of the complete testing workflow for Amazon Prime Air's embedded systems, from initial development through post-flight analysis. It synthesizes information from FULLSIM testing, HILSIM testing, and post-flight analysis to show how these components work together in a progressive validation framework.

## Testing Workflow Overview

The Amazon Prime Air testing workflow follows a progressive validation approach, moving from pure software simulation to hardware integration and finally to comprehensive post-flight analysis:

```
[Development] → [FULLSIM Testing] → [HILSIM Testing] → [Post-Flight Analysis]
```

This workflow ensures code quality and system reliability through increasingly realistic testing environments.

## 1. Initial Development Environment

Before entering the testing pipeline, developers set up their environment:

- **Cloud Desktop Setup**: Developers use Amazon Cloud Desktops with SSH access
- **Authentication Configuration**: Using `mwinit` for Amazon's internal systems
- **Repository Access**: Configuring SSH credentials for Embention's GitHub repositories:
  - Amazon-PrimeAir
  - Vlibs
  - sw_Veronte
- **Development Tools**: Installing required CLI tools like `adn-flights`

## 2. FULLSIM Testing (Software-in-the-Loop)

FULLSIM provides the first level of validation through a pure software simulation environment:

### Key Characteristics
- **Environment Type**: Software-in-the-loop simulation
- **Hardware Requirements**: None (runs entirely on development machines)
- **Execution Speed**: Fast (minutes to hours)
- **Primary Purpose**: Initial code validation and regression testing

### Workflow Steps
1. **Environment Setup**:
   - Create Brazil workspace with appropriate version set
   - Checkout required packages (AdnEmbRecoverySource, AdnVehicleControllersAlgorithms, etc.)
   - Build packages with feature branch

2. **Code Development**:
   - Make code changes to EMB code in AdnEmbRecoverySource
   - Rebuild using local build (`bb local`)

3. **Test Execution**:
   - Run individual tests to verify functionality
   - Use debugging tools including VSCode integration
   - Generate visualization plots for analysis

4. **Pre-Merge Validation**:
   - Run merge tests on feature branch
   - Address any test failures
   - Document test results in pull request

### Decision Point: FULLSIM Success
After successful FULLSIM testing, developers decide whether to:
- Proceed to HILSIM testing for higher-fidelity validation
- Iterate on development to address issues found in FULLSIM
- Complete the development cycle if changes are minor and FULLSIM validation is sufficient

## 3. HILSIM Testing (Hardware-in-the-Loop)

HILSIM builds upon FULLSIM by incorporating actual hardware components:

### Key Characteristics
- **Environment Type**: Hardware-in-the-loop simulation
- **Hardware Requirements**: Specialized Hilsim resources with actual flight controller hardware
- **Execution Speed**: Moderate to slow (hours to days including setup)
- **Primary Purpose**: Validate code behavior on actual hardware

### Workflow Steps
1. **Workspace Setup**:
   - Create source workspace tracking GNC team's Embention version set
   - Create build workspace tracking version set with desired tests

2. **Code Preparation**:
   - Checkout and build Embention code and utilities
   - Implement code modifications
   - Run release build to generate on-target artifacts

3. **Test Bundle Generation**:
   - Generate dryrun from local Embention artifacts
   - Create manifest machine and bundle
   - Wait for bundle signing completion

4. **HILSIM Test Execution**:
   - Reserve a Block 20 Hilsim environment
   - Configure and submit test job
   - Monitor test execution

### Decision Point: HILSIM Success
After HILSIM testing, developers decide whether to:
- Proceed to analyzing the flight data
- Iterate on development to address issues found in HILSIM
- Prepare for code integration if tests are successful

## 4. Post-Flight Analysis

Post-flight analysis provides comprehensive evaluation of test results:

### Key Characteristics
- **Analysis Type**: Data-driven evaluation of system performance
- **Tools Required**: Telemetry processing and visualization tools
- **Primary Purpose**: Detailed understanding of system behavior and performance

### Workflow Steps
1. **Data Access**:
   - Access flight logs through the completed job
   - Navigate to "Flights" section to view all available data

2. **Data Analysis**:
   - Examine console logs for system operations
   - Review vehicle logs for CAN bus communications
   - Visualize flight data through plots and animations

3. **Telemetry Processing**:
   - Process Embention telemetry data from PCAP files
   - Generate interactive visualizations using `plot_embention_telemetry.py`
   - Analyze key variables and system behavior

4. **Findings Documentation**:
   - Document observations and issues
   - Compare results with expected behavior
   - Prepare recommendations for improvements

### Decision Point: Analysis Findings
Based on post-flight analysis, developers decide whether to:
- Approve code for integration if performance meets requirements
- Identify specific issues requiring further development
- Request additional testing with modified parameters

## Common Patterns Across Testing Environments

Several key patterns and practices are consistent across the testing workflow:

### 1. Progressive Fidelity
The workflow moves from lower-fidelity, faster-executing environments to higher-fidelity, more realistic environments:
- FULLSIM: Pure software simulation
- HILSIM: Hardware-in-the-loop with actual flight controllers
- Post-Flight Analysis: Comprehensive evaluation of real system behavior

### 2. Consistent Configuration Management
All environments use similar configuration approaches:
- Knob overrides to configure test parameters
- Version control for code and test artifacts
- Bundle generation for deployment

### 3. Visualization and Debugging Tools
Similar tools are used across environments:
- Plot generation for data visualization
- Logging for system behavior tracking
- Debugging integrations for code inspection

### 4. Test Selection Strategy
Tests are selected based on:
- Test coverage requirements
- Previous test results
- Specific features being validated
- Risk assessment of code changes

## Key Decision Points in the Workflow

The testing workflow includes several critical decision points:

### 1. Initial Testing Approach
- **Decision**: Which testing environment to start with?
- **Factors**: Complexity of changes, risk level, hardware dependencies
- **Options**: Start with FULLSIM (most common) or go directly to HILSIM for hardware-specific changes

### 2. FULLSIM to HILSIM Transition
- **Decision**: When to move from FULLSIM to HILSIM testing?
- **Factors**: FULLSIM test results, confidence in software behavior, need for hardware validation
- **Options**: Proceed to HILSIM, iterate in FULLSIM, or complete development cycle

### 3. Test Coverage Determination
- **Decision**: Which tests to run in each environment?
- **Factors**: Code areas affected, critical functionality, regression risks
- **Options**: Run specific targeted tests or comprehensive test suites

### 4. Issue Resolution Path
- **Decision**: How to address issues found during testing?
- **Factors**: Issue severity, root cause location, development timeline
- **Options**: Immediate code fixes, workarounds, or acceptance with documented limitations

## Ensuring System Reliability

The complete testing workflow ensures system reliability through:

### 1. Multi-level Validation
- Software-only validation in FULLSIM
- Hardware integration testing in HILSIM
- Comprehensive data analysis post-flight

### 2. Regression Prevention
- Merge tests ensure new changes don't break existing functionality
- Automated test suites provide consistent validation
- Historical data comparison identifies performance regressions

### 3. Documentation and Knowledge Sharing
- Test results documented in pull requests
- Flight data preserved for future reference
- Analysis findings shared with development team

### 4. Continuous Improvement
- Test failures drive code improvements
- Analysis findings inform future development
- Testing tools and processes evolve based on experience

## Conclusion

The Amazon Prime Air testing workflow represents a comprehensive approach to ensuring code quality and system reliability for safety-critical embedded systems. By progressing from software-only testing through hardware integration to detailed post-flight analysis, the workflow provides multiple validation layers with increasing fidelity. This progressive approach allows developers to identify and address issues early while still providing thorough validation before deployment.

The integration of consistent tools, configuration management, and decision points throughout the workflow creates a robust framework that balances development speed with quality assurance. This comprehensive testing strategy is essential for the development of reliable autonomous flight systems where safety and performance are paramount.