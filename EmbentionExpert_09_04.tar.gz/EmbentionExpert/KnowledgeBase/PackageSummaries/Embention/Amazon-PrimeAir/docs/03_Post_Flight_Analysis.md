# Generated from:

- dev_manuals/emb_post_flight_analysis.md (1186 tokens)
- dev_manuals/code/telemetry/plot_embention_telemetry.py (2071 tokens)

## With context from:

- Amazon-PrimeAir/docs/04_HILSIM_Testing.md (2455 tokens)

---

# Post-Flight Analysis Tools and Processes

This document provides a comprehensive guide to accessing and analyzing flight data after HILSIM tests, including detailed explanations of available tools, data formats, and analysis techniques.

## Flight Data Access

After completing a HILSIM flight test, you can access the flight logs through the following process:

1. Select a completed job and click "**View simulations**" in the upper right corner of the page
2. Click on "**Flights**" to enter *Flights.adninfra.net*
3. Navigate to the "files" section to access all available flight data

**Note**: All data requires processing time before being displayed on this page, so there may be a delay between test completion and data availability.

## Available Data Types

### Console Logs

The `console_logs` directory contains various text files categorized by system component. These logs provide detailed information about system operations during the flight.

**Example**: To check Navigation status and sensor integration:
- Access `PRIMARY0-LIO-FASTBUS_vsdk.task.adn.vehicle.navigationandsensingsystem.Navigation_ParsedEntries.txt`

### Vehicle Logs

The `vehicle_logs` directory contains analysis of the different CAN buses on board, organized by producer and CAN frame.

**Example**: To examine Monitor messages on STAB-A (CAN-FD):
- Access `MONITOR_STAB_A_RECOVERY0_STAB_A.vlog`
- Inside you'll find all received messages parsed into easily analyzable CSV files

### Visualization Data

The `Visualization` section provides plotted data from various vehicle systems.

**Example**: Air data from the recovery compute can be visualized as graphs showing parameters like airspeed, altitude, and other flight metrics.

### Flight Animation

The `animation_state_estimate.html` file provides a 3D animation of the flight, allowing visual replay of the vehicle's movement and orientation throughout the test.

### Embention Telemetry

The `embention` folder contains the `telemetry.pcap` file, which stores all network traffic from the Astro board related to Recovery telemetry. This data requires additional processing to be visualized.

## Recovery Telemetry Analysis

### Automated Method

You can request VIPA team to generate telemetry visualizations from the PCAP file.

### Manual Processing Method

To manually process and visualize Recovery telemetry:

1. **Replay Network Traffic**:
   - Use *Packetplayer* (available in Embention PM) to replay network traffic from `telemetry.pcap`

2. **Gather Telemetry Data**:
   - Run the [Telemetry_app](https://github.com/embention/Amazon-PrimeAir/blob/feature/Amazon-PrimeAir/9388_pa_mk30/items/VCP/items/Telemetry_app/README.md) application
   - This processes the network traffic and generates CSV files containing the telemetry data

3. **Generate Visualizations**:
   - Run the `plot_embention_telemetry.py` script to create HTML files with interactive plots of the acquired telemetry
   - Note: Monitor, Recovery0, and Recovery1 session IDs are hardcoded in the script and may need modification if they change

## Telemetry Plotting Tool: `plot_embention_telemetry.py`

The `plot_embention_telemetry.py` script is a powerful tool for visualizing Embention telemetry data. It processes CSV files containing telemetry data and generates interactive HTML plots.

### Key Features

- Processes single CSV files or directories containing multiple CSV files
- Automatically identifies the compute source (Monitor, Recovery0, Recovery1) based on device ID
- Merges data from multiple CSV files when appropriate
- Trims leading data to reduce startup noise
- Generates interactive HTML plots with Plotly

### Usage Examples

```bash
# Basic usage with a single CSV file
python3 plot_embention_telemetry.py -t path/to/telemetry.csv -o output.html

# Process multiple CSV files
python3 plot_embention_telemetry.py -t file1.csv -t file2.csv -o output.html

# Process all CSV files in a directory
python3 plot_embention_telemetry.py -d telemetry_directory/ -o output.html

# Customize trim time (default is 60s)
python3 plot_embention_telemetry.py -t telemetry.csv -o output.html --trim-leading-data-by 30s

# Add flight ID for plot title
python3 plot_embention_telemetry.py -t telemetry.csv -o output.html -f FLIGHT123
```

### Command Line Options

```
usage: plot_embention_telemetry.py [-h] [-t TELEMETRY_CSV] [-d TELEMETRY_CSVS] -o OUTPUT
                                   [--trim-leading-data-by TRIM_LEADING_DATA_BY]
                                   [-f FLIGHT_ID]

options:
  -h, --help            show this help message and exit
  -t TELEMETRY_CSV, --telemetry-csv TELEMETRY_CSV
                        Path to CSV containing Embention Telemetry Vector data
  -d TELEMETRY_CSVS, --telemetry-csvs TELEMETRY_CSVS
                        Path to directory containing Embention Telemetry CSV data
  -o OUTPUT, --output OUTPUT
                        Path to the plot that will be written to disk
  --trim-leading-data-by TRIM_LEADING_DATA_BY
                        Length of time to trim leading data by (default: "60s")
  -f FLIGHT_ID, --flight-id FLIGHT_ID
                        Flight ID for plot title
```

## Technical Implementation Details

### Compute Identification

The script identifies the compute source (Monitor, Recovery0, Recovery1) using device IDs:
- Monitor: 94657053978
- Recovery0: 120426857753 (Navigation)
- Recovery1: 133311759643 (Controls)

### Data Processing Pipeline

1. **CSV Loading**: Reads CSV files using pandas with ISO-8859-1 encoding
2. **Column Sanitization**: Normalizes column names and removes empty columns
3. **Data Merging**: When multiple CSVs are provided, merges them using time-based alignment
4. **Data Transformation**: Converts from wide format (variables as columns) to long format (variable-value pairs)
5. **Time Trimming**: Removes initial data points to eliminate startup noise
6. **Visualization**: Creates interactive line plots with Plotly, color-coded by variable

### File Naming Conventions

The script can handle two file naming patterns:
1. Legacy pattern: `<device_id>_<ip>_Telemetry(_Complementary)?_(\d-\d)\.csv`
2. Directory-based inference: Files in directories named "recovery0", "recovery1", etc.

## Best Practices for Telemetry Analysis

1. **Trim Leading Data**: Always trim the first 30-60 seconds of telemetry data to eliminate startup noise and initialization artifacts

2. **Compare Multiple Flights**: When diagnosing issues, compare telemetry from problematic flights with successful flights to identify anomalies

3. **Focus on Key Variables**: Pay particular attention to:
   - State transitions
   - Control inputs and responses
   - Sensor readings and fusion results
   - Error flags and warnings

4. **Correlate with Console Logs**: Cross-reference telemetry data with console logs to get a complete picture of system behavior

5. **Check for Data Gaps**: Look for missing data points or unexpected discontinuities that might indicate communication issues

## Referenced Context Files

The following context file provided valuable information for this guide:
- `04_HILSIM_Testing.md`: Provided context on the HILSIM testing process that generates the flight data analyzed in this document