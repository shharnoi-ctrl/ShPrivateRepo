# Generated from:

- Amazon-PrimeAir/docs/02_System_Overview.md (2673 tokens)
- Amazon-PrimeAir/docs/06_Development_Environment_Setup.md (1639 tokens)
- Amazon-PrimeAir/docs/02_Testing_Workflow.md (2433 tokens)

---

# Comprehensive Overview of the Embention Drone Control System

## System Architecture Overview

The Embention drone control system is an integrated ecosystem for developing, testing, and deploying drone control software, consisting of three primary components:

1. **FULLSIM (Software-in-the-Loop)** - A pure software simulation environment for initial testing and validation
2. **HILSIM (Hardware-in-the-Loop)** - A hybrid simulation environment incorporating actual hardware components
3. **Oasis** - A central resource management platform that coordinates access to simulation resources and manages job execution

These components work together to provide a comprehensive development and testing pipeline for drone control systems, with specific workflows for each stage of the development process.

## Development Environment Setup

### Cloud Desktop Environment

A Cloud Desktop is essential for creating `brazil` workspaces needed for Prime Air development:

1. **Initial Setup**:
   - Access Cloud Desktop creation at https://builderhub.corp.amazon.com/app.html#/cloud-desktop/users/[your_amz_username]
   - Select "m7i.24xlarge" as the Host type for high computational resources
   - Select "ADN Systems Engineering" for the Fleet
   - Creation process takes 40-60 minutes

2. **Required Toolboxes**:
   ```bash
   # ADN Panda Tools
   toolbox registry add 's3://buildertoolbox-registry-adn-panda-tools-us-west-2/tools.json'
   toolbox install adn-panda-tools

   # ADN FullSim Tools (CX3 channel)
   toolbox registry add 's3://buildertoolbox-registry-adn-fullsim-tools-us-west-2/tools.json'
   toolbox install adn-fullsim-tools --channel cx3

   # ADN Simulation Tools
   toolbox registry add 's3://buildertoolbox-registry-adn-simulation-tools-us-west-2/tools.json'
   toolbox install adn-simulation-tools
   ```

3. **Authentication Setup**:
   - Generate RSA and ECDSA SSH keys
   - Add public keys to EMB GitHub account
   - Initialize Midway authentication with `mwinit -o`

### Windows Laptop Setup

An Amazon Windows laptop is required to access the Prime Air environment:

1. **Authentication Setup**:
   - Install `wssh` from https://w.amazon.com/bin/view/WSSH/
   - Generate RSA and ECDSA keys
   - Configure VS Code according to the guide
   - Initialize Midway authentication with `mwinit && mwinit -k C:\Users\<user>/.ssh/id_ecdsa.pub`

2. **Development Workflow**:
   - Connect to Cloud Desktop from Windows laptop using VS Code
   - Create/modify Brazil workspaces on Cloud Desktop
   - Run tests on Cloud Desktop
   - Use Tmux for long-running test sessions

## Complete Testing Workflow

The Amazon Prime Air testing workflow follows a progressive validation approach:

```
[Development] → [FULLSIM Testing] → [HILSIM Testing] → [Post-Flight Analysis]
```

### 1. Initial Development Environment

Before entering the testing pipeline, developers set up their environment:

- **Cloud Desktop Setup**: Developers use Amazon Cloud Desktops with SSH access
- **Authentication Configuration**: Using `mwinit` for Amazon's internal systems
- **Repository Access**: Configuring SSH credentials for Embention's GitHub repositories:
  - Amazon-PrimeAir
  - Vlibs
  - sw_Veronte
- **Development Tools**: Installing required CLI tools like `adn-flights`

### 2. FULLSIM Testing (Software-in-the-Loop)

FULLSIM provides the first level of validation through a pure software simulation environment:

#### Key Characteristics
- **Environment Type**: Software-in-the-loop simulation
- **Hardware Requirements**: None (runs entirely on development machines)
- **Execution Speed**: Fast (minutes to hours)
- **Primary Purpose**: Initial code validation and regression testing

#### Workflow Steps
1. **Environment Setup**:
   - Create Brazil workspace with appropriate version set
   - Checkout required packages (AdnEmbRecoverySource, AdnVehicleControllersAlgorithms, etc.)
   - Build packages with feature branch

2. **Code Development**:
   - Make code changes to EMB code in AdnEmbRecoverySource
   - Rebuild using local build (`bb local`)

3. **Test Execution**:
   - Run individual tests to verify functionality
   - Use debugging tools including VSCode integration
   - Generate visualization plots for analysis

4. **Pre-Merge Validation**:
   - Run merge tests on feature branch
   - Address any test failures
   - Document test results in pull request

#### Decision Point: FULLSIM Success
After successful FULLSIM testing, developers decide whether to:
- Proceed to HILSIM testing for higher-fidelity validation
- Iterate on development to address issues found in FULLSIM
- Complete the development cycle if changes are minor and FULLSIM validation is sufficient

### 3. HILSIM Testing (Hardware-in-the-Loop)

HILSIM builds upon FULLSIM by incorporating actual hardware components:

#### Key Characteristics
- **Environment Type**: Hardware-in-the-loop simulation
- **Hardware Requirements**: Specialized Hilsim resources with actual flight controller hardware
- **Execution Speed**: Moderate to slow (hours to days including setup)
- **Primary Purpose**: Validate code behavior on actual hardware

#### Workflow Steps
1. **Workspace Setup**:
   - Create source workspace tracking GNC team's Embention version set
   - Create build workspace tracking version set with desired tests

2. **Code Preparation**:
   - Checkout and build Embention code and utilities
   - Implement code modifications
   - Run release build to generate on-target artifacts

3. **Test Bundle Generation**:
   - Generate dryrun from local Embention artifacts
   - Create manifest machine and bundle
   - Wait for bundle signing completion

4. **HILSIM Test Execution**:
   - Reserve a Block 20 Hilsim environment through Oasis
   - Configure and submit test job
   - Monitor test execution

#### Decision Point: HILSIM Success
After HILSIM testing, developers decide whether to:
- Proceed to analyzing the flight data
- Iterate on development to address issues found in HILSIM
- Prepare for code integration if tests are successful

### 4. Post-Flight Analysis

Post-flight analysis provides comprehensive evaluation of test results:

#### Key Characteristics
- **Analysis Type**: Data-driven evaluation of system performance
- **Tools Required**: Telemetry processing and visualization tools
- **Primary Purpose**: Detailed understanding of system behavior and performance

#### Workflow Steps
1. **Data Access**:
   - Access flight logs through the completed job
   - Navigate to "Flights" section to view all available data

2. **Data Analysis**:
   - Examine console logs for system operations
   - Review vehicle logs for CAN bus communications
   - Visualize flight data through plots and animations

3. **Telemetry Processing**:
   - Process Embention telemetry data from PCAP files
   - Generate interactive visualizations using `plot_embention_telemetry.py`
   - Analyze key variables and system behavior

4. **Findings Documentation**:
   - Document observations and issues
   - Compare results with expected behavior
   - Prepare recommendations for improvements

## Oasis Platform Detailed Functionality

Oasis serves as the central management platform with the following capabilities:

### Resource Management
- **Resource Visibility**: Shows status and availability of simulation hardware
- **Resource Reservation**: Allows users to reserve resources for specific time periods
- **Resource Release**: Users can release resources when no longer needed

### Job Management
- **Job Execution**: Supports execution of jobs on reserved resources
- **Job Cloning**: Allows cloning of previous jobs for iterative testing
- **Job Modification**: Supports modification of job parameters (bundle deployment, test configuration)
- **Re-run Capability**: Supports re-running tests without redeploying bundles to save time

### Configuration Management
- **Bundle Deployment**: Supports deployment of software bundles to hardware
- **Configuration Loading**: Allows loading of configurations into hardware
- **Manual Modification**: Supports manual modification of firmware and PDI configurations

### Resource Reservation Process

1. Navigate to the Resources section in Oasis to view all simulation hardware
2. Check the status of resources (Available, Occupied, Reserved)
3. Select an available resource (e.g., hilsim-106)
4. Click "Actions" -> "Reserve" to reserve the resource
5. Select the time window for the reservation
6. Release the resource when no longer needed

### Job Execution Process

1. Select a resource to run a job on
2. Configure the job parameters
3. Execute the job on the selected resource
4. Monitor job execution through logs
5. Analyze results after job completion

### Job Cloning and Modification Process

1. Select a previous job
2. Click "Clone job" in the upper-right corner
3. Modify job parameters as needed (bundle, test configuration)
4. Execute the modified job
5. Compare results with the original job

## Software Release Process

The software release process follows a structured path:

1. **Development Branches**:
   - DEV/SUPPORT branches contain current project work
   - Support branches are created after closing scope of functionality

2. **Release Stages**:
   - **Drop xx release**: Unstable, not fully tested software release
   - **DROPs Δ RC (Release Candidate)**: Stable release with functional increments, may still have issues
   - **DROPs Δ RTM (Release To Manufacturing)**: Verification status to be agreed with PA

3. **Release Assets**:
   - SIL library (.so)
   - TI binaries
   - Changelog
   - PDI configuration and/or external flash image

## Common Patterns Across Testing Environments

Several key patterns and practices are consistent across the testing workflow:

### 1. Progressive Fidelity
The workflow moves from lower-fidelity, faster-executing environments to higher-fidelity, more realistic environments:
- FULLSIM: Pure software simulation
- HILSIM: Hardware-in-the-loop with actual flight controllers
- Post-Flight Analysis: Comprehensive evaluation of real system behavior

### 2. Consistent Configuration Management
All environments use similar configuration approaches:
- Knob overrides to configure test parameters
- Version control for code and test artifacts
- Bundle generation for deployment

### 3. Visualization and Debugging Tools
Similar tools are used across environments:
- Plot generation for data visualization
- Logging for system behavior tracking
- Debugging integrations for code inspection

### 4. Test Selection Strategy
Tests are selected based on:
- Test coverage requirements
- Previous test results
- Specific features being validated
- Risk assessment of code changes

## Ensuring System Reliability

The complete testing workflow ensures system reliability through:

### 1. Multi-level Validation
- Software-only validation in FULLSIM
- Hardware integration testing in HILSIM
- Comprehensive data analysis post-flight

### 2. Regression Prevention
- Merge tests ensure new changes don't break existing functionality
- Automated test suites provide consistent validation
- Historical data comparison identifies performance regressions

### 3. Documentation and Knowledge Sharing
- Test results documented in pull requests
- Flight data preserved for future reference
- Analysis findings shared with development team

### 4. Continuous Improvement
- Test failures drive code improvements
- Analysis findings inform future development
- Testing tools and processes evolve based on experience

## Development Tools and Utilities

### Tmux for Long-Running Sessions

Tmux is essential for maintaining terminal sessions during lengthy FullSim tests, preventing test termination due to connection issues.

#### Tmux Configuration

Increase history limit for better log retention:
```bash
echo 'set-option -g history-limit 10000' >> ~/.tmux.conf
tmux source-file ~/.tmux.conf
```

#### Useful Tmux Commands

- **Save terminal history to file**:
  ```bash
  tmux capture-pane -pS -50000 > output.txt
  ```

- **Scroll through terminal output**:
  1. Press `Ctrl+b`, then `[`
  2. Use standard navigation keys
  3. Press `q` to exit scroll mode

## Conclusion

The Embention drone control system provides a comprehensive environment for drone control development, testing, and deployment. The integration of FULLSIM, HILSIM, and Oasis creates a powerful ecosystem that supports the entire development lifecycle, from initial software testing to hardware validation and release management.

The system's structured workflows ensure efficient resource utilization, consistent testing procedures, and reliable software releases. The progressive testing approach, moving from FULLSIM to HILSIM, allows for thorough validation while minimizing risk and maximizing efficiency.

This integrated approach enables developers to create, test, and deploy drone control systems with confidence, ensuring that the final product meets all requirements and performs reliably in real-world conditions. The multi-level validation strategy, combined with comprehensive post-flight analysis, provides the necessary safeguards for developing safety-critical autonomous flight systems.