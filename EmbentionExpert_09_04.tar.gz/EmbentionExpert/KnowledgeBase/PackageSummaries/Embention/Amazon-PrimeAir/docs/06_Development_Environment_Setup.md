# Generated from:

- dev_manuals/emb_cloud_desktop_setup.md (647 tokens)
- dev_manuals/emb_amz_windows_setup.md (595 tokens)

---

# Amazon Prime Air Development Environment Setup Guide

This comprehensive guide details the setup process for Prime Air and Embedded systems development environments, covering both Cloud Desktop and Windows Laptop configurations.

## Cloud Desktop Environment Setup

### Initial Cloud Desktop Creation

A Cloud Desktop is essential for creating `brazil` workspaces needed for Prime Air (PA) development, particularly for FullSim and Hilsim testing.

1. Access the Cloud Desktop creation page at https://builderhub.corp.amazon.com/app.html#/cloud-desktop/users/[your_amz_username]
2. Select "Create" dropdown in the upper-right corner
3. Choose "Create my cloud dev desktop" under "For myself"
4. Select "m7i.24xlarge" as the Host type
   - This instance type provides high computational resources suitable for simulation workloads
   - Reference: https://aws.amazon.com/ec2/instance-types/ for instance specifications
5. Select "ADN Systems Engineering" for the Fleet
6. Keep all other options at their default values
7. Click "Create my Cloud Desktop"
   - **Note**: Creation process takes 40-60 minutes

### Brazil CLI Setup

After Cloud Desktop creation completes:

1. Follow the official Brazil CLI setup guide: https://builderhub.corp.amazon.com/docs/brazil/cli-guide/setup-clouddesk.html

### Required Toolboxes Installation

Install the following essential toolboxes for Prime Air development:

```bash
# ADN Panda Tools
toolbox registry add 's3://buildertoolbox-registry-adn-panda-tools-us-west-2/tools.json'
toolbox install adn-panda-tools

# ADN FullSim Tools (CX3 channel)
toolbox registry add 's3://buildertoolbox-registry-adn-fullsim-tools-us-west-2/tools.json'
toolbox install adn-fullsim-tools --channel cx3

# ADN Simulation Tools
toolbox registry add 's3://buildertoolbox-registry-adn-simulation-tools-us-west-2/tools.json'
toolbox install adn-simulation-tools
```

### Optional GUI Setup

For developers requiring a graphical interface:
- Follow the guide at: https://docs.hub.amazon.dev/dev-setup/clouddesktop-optional-gui-dcv/

### Prime Air and Embedded Access Configuration

Access to PA and EMB code repositories requires SSH key authentication:

1. Log in to your Cloud Desktop
2. Generate RSA keys:
   ```bash
   ssh-keygen -t rsa
   ```
   - Accept defaults by pressing Enter at each prompt
3. Generate ECDSA keys:
   ```bash
   ssh-keygen -t ecdsa
   ```
   - Accept defaults by pressing Enter at each prompt
4. View your RSA public key:
   ```bash
   cat ~/.ssh/id_rsa.pub
   ```
5. Copy the entire output and add it to your SSH keys in your EMB GitHub account
   - Reference: Video guide available at `./files/Adding_SSH_pub_ky_to_git_hub.webm`
6. Initialize Midway authentication:
   ```bash
   mwinit -o
   ```

#### Authentication Troubleshooting

If you encounter authentication issues, refer to the troubleshooting guide at:
https://docs.hub.amazon.dev/gitfarm/user-guide/troubleshooting-auth/

## Windows Laptop Setup

### Purpose and Workflow

An Amazon Windows laptop is required to:
- Access the Prime Air environment
- Develop and test PA-EMB code
- Test new PA features
- Modify EMB code
- Compile different Brazil workspaces

Development work is typically performed using VS Code connected to the Cloud Desktop.

### Windows Authentication Setup

To establish SSH connections with the Cloud Desktop:

1. Install `wssh` from https://w.amazon.com/bin/view/WSSH/
2. Generate RSA keys:
   ```bash
   ssh-keygen -t rsa
   ```
   - Accept defaults by pressing Enter at each prompt
3. Generate ECDSA keys:
   ```bash
   ssh-keygen -t ecdsa
   ```
   - Accept defaults by pressing Enter at each prompt
4. Configure VS Code according to the guide in `./docs/VS Code for ContainerBuild.pdf`
   - EMB developers can skip the "install Private Extensions on Cloud desktop" section as it's primarily for PA code development
5. Initialize Midway authentication with your ECDSA key:
   ```bash
   mwinit && mwinit -k C:\Users\<user>/.ssh/id_ecdsa.pub
   ```

### VS Code Connection Troubleshooting

If VS Code connection fails due to server misconfiguration:
1. Open a terminal on the Cloud Desktop via web browser
2. Remove the VS Code server configuration:
   ```bash
   rm -r ~/.vscode-server
   ```
3. Attempt to reconnect

For persistent Cloud Desktop/VS Code issues, contact Joe Rutland (@jrrutlan).

## Development Tools and Utilities

### Tmux for Long-Running Sessions

Tmux is essential for maintaining terminal sessions during lengthy FullSim tests, preventing test termination due to connection issues.

#### Tmux Configuration

Increase history limit for better log retention:
```bash
echo 'set-option -g history-limit 10000' >> ~/.tmux.conf
tmux source-file ~/.tmux.conf
```

#### Useful Tmux Commands

- **Save terminal history to file**:
  ```bash
  tmux capture-pane -pS -50000 > output.txt
  ```

- **Scroll through terminal output**:
  1. Press `Ctrl+b`, then `[`
  2. Use standard navigation keys
  3. Press `q` to exit scroll mode

- **Additional commands**: Reference the comprehensive cheat sheet at https://tmuxcheatsheet.com/

## Development Workflow Integration

### Cloud Desktop and Windows Laptop Interaction

1. **Initial Setup Flow**:
   - Configure Windows laptop with authentication tools
   - Create and configure Cloud Desktop
   - Establish secure connection between Windows and Cloud Desktop

2. **Typical Development Cycle**:
   - Connect to Cloud Desktop from Windows laptop using VS Code
   - Create/modify Brazil workspaces on Cloud Desktop
   - Run FullSim and Hilsim tests on Cloud Desktop
   - Use Tmux for long-running test sessions
   - Monitor and debug using Cloud Desktop resources

3. **Authentication Maintenance**:
   - Regularly renew Midway authentication using `mwinit`
   - Ensure SSH keys are properly configured in both environments

### Resource Management

The Cloud Desktop (m7i.24xlarge) provides significant computational resources for simulation and development tasks, while the Windows laptop serves primarily as an access point and local development environment.

## Referenced Context Files

The following context files provided valuable information for this summary:
- `dev_manuals/emb_cloud_desktop_setup.md`: Detailed the Cloud Desktop setup process, required toolboxes, and authentication configuration
- `dev_manuals/emb_amz_windows_setup.md`: Provided Windows laptop configuration steps, VS Code setup, and Tmux usage guidance