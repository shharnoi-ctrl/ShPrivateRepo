# Generated from:

- dev_manuals/emb_hilsim_test.md (2493 tokens)

## With context from:

- Amazon-PrimeAir/docs/06_Development_Environment_Setup.md (1639 tokens)
- Amazon-PrimeAir/docs/05_FULLSIM_Testing.md (2730 tokens)

---

# HILSIM Testing Guide: Hardware-in-the-Loop Simulation Environment

This document provides a comprehensive guide to HILSIM (Hardware-in-the-Loop Simulation) testing for Amazon Prime Air's embedded systems. HILSIM builds upon FULLSIM testing by incorporating actual hardware components, providing a more realistic testing environment.

## Prerequisites

These instructions have been validated on AL2 cloud machines:

1. **Authentication**: Ensure you have run `mwinit` to authenticate with Amazon's internal systems.

2. **Oasis CLI Installation**: The Oasis CLI is required for interacting with HILSIM resources.
   ```bash
   toolbox registry add 's3://buildertoolbox-registry-adn-simulation-tools-us-west-2/tools.json'
   toolbox install adn-simulation-tools
   toolbox update adn-simulation-tools
   ```

3. **Remove Deprecated Toolchains**: If you have `adn-fcm-tools` installed, remove it:
   ```bash
   toolbox uninstall adn-fcm-tools
   toolbox clean
   ```

4. **Reserve a Block 20 Hilsim** (Recommended): Reserve a dedicated HILSIM environment at [Oasis](https://oasis.primeair.amazon.dev/rc/Blk20HilsimDev/resources).
   - Select an available Hilsim without a user assigned
   - Under Actions, select "Reservations > Reserve"
   - This allows you to send Oasis jobs to your reserved Hilsim

## Workspace Setup

The HILSIM testing process requires two separate workspaces:

1. **Create Source Workspace**: This workspace tracks the GNC team's Embention version set.
   ```bash
   root=$PWD
   brazil ws create --name ws-emb-src -vs AdnCX3GNCControls/block20-build-emb
   ```

2. **Create Build Workspace**: This workspace tracks the version set with the tests you want to run.
   ```bash
   brazil ws create --name ws-emb-build -vs AdnCX3/principal-block20-env
   ```

## Modifying Embention Code

1. **Checkout Required Packages**: In the source workspace, checkout the Embention code and utilities:
   ```bash
   cd $root/ws-emb-src
   brazil ws use -p AdnEmbRecoverySource --latest
   brazil ws use -p AdnEmbToPaUtilities
   ```
   Note: `AdnEmbToPaUtilities` is not in common version sets, so `--latest` is omitted.

2. **Build Utilities**: Generate binaries needed for later steps:
   ```bash
   cd src/AdnEmbToPaUtilities && brazil-build
   ```

3. **Build Embention Code**: Pull and build the base Embention code:
   ```bash
   cd src/AdnEmbRecoverySource && brazil-build
   ```
   This takes approximately 13 minutes. By default, this builds the `feature/Amazon-PrimeAir/integration` branch. To build a specific branch, use `brazil-build -b <remote-branch>`.

4. **Make Code Changes**: Implement your desired code modifications.

5. **Release Build**: Run a release build to generate on-target artifacts:
   ```bash
   bb release
   ```
   This takes approximately 13 minutes. Once successful, proceed to the next step.

## Generating a Test Bundle

If you need to modify FullSim packages (e.g., AdnFullSim*TestFiles, AdnFullSimGisMissions), follow these steps:

1. **Checkout Test Packages**: In the build workspace, checkout the test packages you need to modify.

2. **Make Modifications**: Implement your changes to the test files.

3. **Create Bundle**: From the test files package, run:
   ```bash
   bb bundle --dryrun
   ```
   This takes 5-6 minutes.

4. **Save Bundle ID**: Note the `local-<uuid>` string that appears (e.g., `local-86bf2fe9eeca4387a835901caf26117b`). You'll need this later.

## Creating a Dryrun from Local Embention Artifacts

1. **Generate Dryrun**: Navigate to the `AdnEmbToPaUtilities` package in the source workspace:
   ```bash
   cd $root/ws-emb-src/src/AdnEmbToPaUtilities
   chmod +x bin/generate_dryrun_from_packaged_emb_artifacts.sh
   ./bin/generate_dryrun_from_packaged_emb_artifacts.sh -e $root/ws-emb-src -d $root/ws-emb-build
   ```
   This copies packaged on-target artifacts to the build workspace, commits them, and creates a dryrun build.

   For including other code changes (e.g., Primary lane or Fullsim changes), use:
   ```bash
   ./bin/generate_dryrun_from_packaged_emb_artifacts.sh -e $root/ws-emb-src -d $root/ws-emb-build --no-dryrun
   cd $root/ws-emb-build
   brazil ws dryrun
   ```

2. **Wait for Dryrun Completion**: The dryrun takes approximately 60 minutes to complete.

## Manifest Machine and Bundle Generation

1. **Generate Bundle**: After the dryrun completes, run:
   ```bash
   cd $root/ws-emb-src/src/AdnEmbToPaUtilities/
   chmod +x bin/generate_bundle_from_dryrun.sh
   ./bin/generate_bundle_from_dryrun.sh -b <dryrun_build_request_id>
   ```
   After about 5 minutes, you'll see output similar to:
   ```
   2025/03/21 23:26:39 Oasis Signing Job ID:    189468b3-ca1b-4c56-91d1-8f6b51238215
   2025/03/21 23:26:39 Oasis Signing Job Link:  https://prod-na.oasis.primeair.amazon.dev/rc/SoftwareSigning/jobs/189468b3-ca1b-4c56-91d1-8f6b51238215
   2025/03/21 23:26:39 Bundle ID:               dhentzen-70cb12a5-ef29-4774-8829-a5256288e51c
   ```
   **Save the Bundle ID** for use in the next step.

   The signing job takes 20-25 minutes to complete. Upon successful completion, you'll receive a Slack notification from ChirpBot.

2. **Alternative Bundle ID Retrieval**: If needed, find the Bundle ID by:
   - Opening the Oasis Signing Job Link
   - Going to "Logs"
   - Clicking "Job Logs" in the "GenerateInstallBundleTypeJob" row
   - Clicking "Logs" in the "GenerateBundle" row
   - Scrolling to the bottom where it says "Finished creating bundle <bundle-guid>"

## Running the HILSIM Test

### Option 1: Clone an Existing Job

1. Open the Oasis link and click "Clone Root Job" in the top right.

2. Configure the job:
   - Under "Where should the job run?", select your reserved Hilsim
   - In the Configuration pane:
     - Replace `#@ installerBundleVersion = 'bundle-id'` with your Bundle ID
     - If you modified Fullsim packages, replace `#@ testPackageVersion = 'local-uuid'` with your local UUID
   
3. Additional configuration options:
   - `testIterations`: Number of times tests are repeated
   - `knobsAndTestCommands`: Defines the knob set and pytest to run

4. Click "Submit Job" when ready.

### Option 2: Create a New Block 20 Fly Job

Follow the official documentation in `./docs/HILSim_testing_guide.pdf`.

### Running Additional Tests with the Same Bundle

To run another test with the same software bundle but different knobs/test commands:
1. Clone the `CollectAndRunFlights` sub-job of the `Fly` job
2. Update the configuration
3. Submit the job

This avoids re-deploying the same bundle again (assuming you have the Hilsim reserved).

## Embention Telemetry Configuration

The PA and EMB teams developed a tool to directly get EMB telemetry plots on HILSIM flights. To ensure telemetry works correctly:

### Method 1: Standard Approach
When following this guide, telemetry is configured to use "Last-Known-Good" settings. If you don't modify EMB telemetry configuration in your dryrun, you'll likely get the EMB telemetry plots.

### Method 2: Guaranteed Telemetry
For guaranteed telemetry display:

1. Execute step 4-1 to create an Oasis SoftwareSigning Job
2. Clone that job
3. Update these parameters:
   ```
   #@ ANALYSIS_MK30_BLK20_ALL_EMBENTION_CONFIG_version = 'dryrun_xyz'
   #@ ANALYSIS_MK30_BLK20_ALL_VSDK_PLATFORM_CONFIG_version = 'dryrun_xyz'
   ```
4. Modify the installer bundle path:
   ```
   #@ installerBundleS3Path = 'InstallerBundle/bertomes-dryrun_xyz'
   ```
5. Submit the job
6. Use the Bundle ID generated with that job (what you put in the installer bundle path)

## Additional Notes

- **Support**: For issues, reach out in the `#primeair-gnc-hilsim-helpline` Slack channel or contact the [Hilsim oncall](https://oncall.corp.amazon.com/#/view/primeair-hips/schedule).

- **IPC Support**: Standard Hilsims generally don't support IPCs and are primarily used for Monitor and Recovery testing. "ITV" Hilsims with IPCs are available only on-site in `SEA109` as they have IPCs with real motors and props.

- **Common Test Configuration**: The most common test used by the EMBENTION team is:
  ```
  #@ knobsPath = hilsim/H-9
  #@ testCommand = simulations/regression/test_blk20_outdoor_flights.py::test_hybrid_missions[Cx3IntegrationHilsimRuntime-recovery_switchover_hybrid]
  ```

## HILSIM vs. FULLSIM Comparison

HILSIM builds upon FULLSIM testing by incorporating actual hardware components:

1. **Hardware Integration**: 
   - FULLSIM: Pure software simulation with no physical hardware
   - HILSIM: Incorporates actual flight controller hardware (Veronte) in the loop

2. **Testing Environment**:
   - FULLSIM: Runs entirely on development machines
   - HILSIM: Requires specialized hardware setups (Hilsim resources)

3. **Deployment Process**:
   - FULLSIM: Direct code execution in simulation
   - HILSIM: Requires bundle generation and deployment to physical hardware

4. **Test Fidelity**:
   - FULLSIM: Good for initial validation
   - HILSIM: Higher fidelity, closer to real-world behavior

5. **Execution Time**:
   - FULLSIM: Faster test execution
   - HILSIM: Longer setup and execution times due to hardware interaction

## Referenced Context Files

The following context files provided valuable information for this guide:
- `06_Development_Environment_Setup.md`: Provided details on Cloud Desktop setup and authentication configuration
- `05_FULLSIM_Testing.md`: Provided context on the software-in-the-loop testing that precedes HILSIM testing