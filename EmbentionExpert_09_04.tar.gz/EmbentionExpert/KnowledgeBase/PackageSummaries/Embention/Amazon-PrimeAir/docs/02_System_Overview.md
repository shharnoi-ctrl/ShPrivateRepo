# Generated from:

- README.md (0 tokens)
- dev_manuals/README.md (106 tokens)
- dev_manuals/emb_oasis_brief_intro.md (667 tokens)
- procedures/pa-emb-processes/Readme.md (184 tokens)

---

# Comprehensive Overview of the Embention Drone Control System

## System Architecture Overview

The Embention drone control system consists of three primary components that work together to provide a comprehensive environment for drone control, testing, and resource management:

1. **FULLSIM (Software-in-the-Loop)** - A simulation environment where all components are simulated in software
2. **HILSIM (Hardware-in-the-Loop)** - A simulation environment where actual hardware components are integrated into the simulation
3. **Oasis** - A resource management platform that coordinates access to simulation resources and manages job execution

These components form an integrated ecosystem for developing, testing, and deploying drone control software, with specific workflows for each stage of the development process.

## Component Relationships and Interactions

### FULLSIM (Software-in-the-Loop)

FULLSIM provides a purely software-based simulation environment for testing drone control systems. It allows developers to:

- Test drone control algorithms without physical hardware
- Debug software components in isolation
- Validate system behavior before moving to hardware testing

The FULLSIM environment serves as the first stage in the testing pipeline, allowing for rapid iteration and basic validation before proceeding to hardware testing.

### HILSIM (Hardware-in-the-Loop)

HILSIM extends the simulation capabilities by incorporating actual hardware components. This creates a hybrid environment where:

- Physical hardware components (like flight controllers) interact with simulated environments
- Real-time behavior can be observed and tested
- Hardware-specific issues can be identified and resolved

HILSIM represents an intermediate step between pure software simulation and actual flight testing, providing a more realistic testing environment while still maintaining safety and control.

### Oasis Platform

Oasis serves as the central resource management and orchestration platform, providing:

- Resource reservation and allocation (particularly for HILSIM hardware)
- Job execution management
- Test configuration and deployment
- Results collection and analysis

Oasis coordinates access to limited hardware resources and provides a structured workflow for test execution and analysis.

## Key Workflows

### Development and Testing Workflow

The development and testing workflow follows a progressive path:

1. **FULLSIM Testing**:
   - Initial software testing in a pure software environment
   - Debugging and validation of basic functionality
   - Merging of FULLSIM tests to validate integrated behavior

2. **HILSIM Testing**:
   - Testing with actual hardware components
   - Validation of hardware-software interactions
   - More realistic testing of system behavior

3. **Post-Flight Analysis**:
   - Analysis of test results
   - Identification of issues and areas for improvement
   - Validation against requirements

### Oasis Resource Management Workflow

Oasis provides a structured workflow for resource management:

1. **Resource Reservation**:
   - Users can view available HILSIM resources
   - Resources can be reserved for specific time windows
   - Reserved resources are allocated exclusively to the reserving user

2. **Job Execution**:
   - Jobs can be configured and executed on reserved resources
   - Jobs can be cloned and modified for iterative testing
   - Results are collected and stored for analysis

3. **Bundle Deployment**:
   - Software bundles can be deployed to hardware resources
   - Configurations can be loaded and modified
   - Tests can be executed against deployed bundles

### Software Release Process

The software release process follows a structured path:

1. **Development Branches**:
   - DEV/SUPPORT branches contain current project work
   - Support branches are created after closing scope of functionality

2. **Release Stages**:
   - **Drop xx release**: Unstable, not fully tested software release
   - **DROPs Δ RC (Release Candidate)**: Stable release with functional increments, may still have issues
   - **DROPs Δ RTM (Release To Manufacturing)**: Verification status to be agreed with PA

3. **Release Assets**:
   - SIL library (.so)
   - TI binaries
   - Changelog
   - PDI configuration and/or external flash image

## Detailed Component Functionality

### FULLSIM Functionality

FULLSIM provides a comprehensive software simulation environment with the following capabilities:

- **Test Debugging**: Allows for detailed debugging of test scenarios
- **Test Merging**: Supports merging of test results for integrated validation
- **Cloud Desktop Configuration**: Can be configured to run in cloud environments
- **AMZ Windows Configuration**: Supports configuration for Windows environments

The FULLSIM environment serves as the foundation for initial testing and validation before moving to hardware-based testing.

### HILSIM Functionality

HILSIM extends simulation capabilities by incorporating hardware components:

- **Hardware Resources**: Multiple HILSIM resources (e.g., hilsim-106, hilsim-107, hilsim-109) available for testing
- **Resource Status Tracking**: Resources can be in various states (Available, Occupied, Reserved)
- **Test Execution**: Supports execution of tests on physical hardware
- **Configuration Management**: Allows for configuration of hardware components for testing

HILSIM provides a more realistic testing environment while still maintaining the safety and control of a simulation.

### Oasis Platform Functionality

Oasis serves as the central management platform with the following capabilities:

#### Resource Management
- **Resource Visibility**: Shows status and availability of simulation hardware
- **Resource Reservation**: Allows users to reserve resources for specific time periods
- **Resource Release**: Users can release resources when no longer needed

#### Job Management
- **Job Execution**: Supports execution of jobs on reserved resources
- **Job Cloning**: Allows cloning of previous jobs for iterative testing
- **Job Modification**: Supports modification of job parameters (bundle deployment, test configuration)
- **Re-run Capability**: Supports re-running tests without redeploying bundles to save time

#### Configuration Management
- **Bundle Deployment**: Supports deployment of software bundles to hardware
- **Configuration Loading**: Allows loading of configurations into hardware
- **Manual Modification**: Supports manual modification of firmware and PDI configurations

#### User Interface
- **Menu Switching**: Allows switching between different functional areas (e.g., Blk20HilsimDev, SoftwareSigning)
- **Job Filtering**: Supports filtering jobs by resource or requester ID
- **Detailed Logs**: Provides access to detailed logs of job execution

## System Integration Points

The Embention drone control system integrates its components through several key integration points:

1. **FULLSIM to HILSIM Transition**:
   - Test scenarios developed in FULLSIM can be transitioned to HILSIM
   - Results from FULLSIM testing inform HILSIM test configuration

2. **Oasis to HILSIM Integration**:
   - Oasis manages access to HILSIM resources
   - Oasis orchestrates job execution on HILSIM hardware
   - Oasis collects and stores results from HILSIM tests

3. **Software Release to Testing Integration**:
   - Software releases are deployed to testing environments through Oasis
   - Test results inform the progression through release stages

## Repository Structure

The system uses a structured repository approach:

- **EMB Organization Repositories**: Used for internal development
- **AMZ-PA Repository**: Provides access for AMZ-PA
- **Branch Structure**:
  - DEV/SUPPORT branches for current work
  - Support branches created after closing scope of functionality

## Testing and Validation Process

The testing and validation process follows a progressive approach:

1. **Initial FULLSIM Testing**:
   - Basic functionality testing
   - Algorithm validation
   - Software component integration testing

2. **HILSIM Testing**:
   - Hardware-software integration testing
   - Real-time behavior validation
   - Environmental response testing

3. **Post-Flight Analysis**:
   - Data collection and analysis
   - Performance evaluation
   - Issue identification and resolution

4. **Release Progression**:
   - Unstable releases (Drop xx)
   - Stable but not fully validated releases (DROPs Δ RC)
   - Manufacturing releases (DROPs Δ RTM)

## Oasis Detailed Workflow

### Resource Reservation Process

1. Navigate to the Resources section in Oasis to view all simulation hardware
2. Check the status of resources (Available, Occupied, Reserved)
3. Select an available resource (e.g., hilsim-106)
4. Click "Actions" -> "Reserve" to reserve the resource
5. Select the time window for the reservation
6. Release the resource when no longer needed

### Job Execution Process

1. Select a resource to run a job on
2. Configure the job parameters
3. Execute the job on the selected resource
4. Monitor job execution through logs
5. Analyze results after job completion

### Job Cloning and Modification Process

1. Select a previous job
2. Click "Clone job" in the upper-right corner
3. Modify job parameters as needed (bundle, test configuration)
4. Execute the modified job
5. Compare results with the original job

### Re-running Tests Without Redeployment

1. Navigate to the logs of "Block20CollectAndRunFlights" -> "RunFlight"
2. Click "Clone Current Job"
3. Execute the cloned job without redeploying the bundle
4. This saves time when the bundle is already deployed and configuration is correct

## Conclusion

The Embention drone control system provides a comprehensive environment for drone control development, testing, and deployment. The integration of FULLSIM, HILSIM, and Oasis creates a powerful ecosystem that supports the entire development lifecycle, from initial software testing to hardware validation and release management.

The system's structured workflows ensure efficient resource utilization, consistent testing procedures, and reliable software releases. The progressive testing approach, moving from FULLSIM to HILSIM, allows for thorough validation while minimizing risk and maximizing efficiency.

This integrated approach enables developers to create, test, and deploy drone control systems with confidence, ensuring that the final product meets all requirements and performs reliably in real-world conditions.