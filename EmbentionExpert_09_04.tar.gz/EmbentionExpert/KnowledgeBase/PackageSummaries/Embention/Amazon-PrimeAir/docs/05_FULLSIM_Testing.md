# Generated from:

- dev_manuals/emb_fullsim_test_debug.md (1331 tokens)
- dev_manuals/emb_merge_fullsim_test.md (455 tokens)

## With context from:

- Amazon-PrimeAir/docs/06_Development_Environment_Setup.md (1639 tokens)

---

# FULLSIM Testing Comprehensive Guide

This guide provides a detailed overview of FULLSIM testing for the Amazon Prime Air embedded systems, focusing on the software-in-the-loop simulation environment. It covers setup procedures, test execution workflows, debugging techniques, and merge testing requirements.

## FULLSIM Overview

FULLSIM is a software-in-the-loop simulation environment that allows testing of Embention (EMB) code in a controlled virtual environment. It enables developers to validate code changes before deployment to physical systems, ensuring reliability and safety of the Prime Air vehicle control systems.

## Prerequisites

Before starting FULLSIM testing, ensure you have:

- SSH access to an Amazon Cloud Desktop
- SSH credentials configured to access Embention's GitHub repositories:
  - Amazon-PrimeAir
  - Vlibs
  - sw_Veronte
- The `adn-flights` CLI installed on your Cloud Desktop (verify with `adn-flights -h`)
- If any prerequisites are missing, refer to the setup prerequisites documentation

## FULLSIM Environment Setup Process

### 1. Create and Configure Brazil Workspace

```bash
# Create a new Brazil workspace with the appropriate version set
brazil ws create --root emb_fullsim_ws --vs AdnCX3GNCControls/block20-build-emb
cd emb_fullsim_ws
root=$PWD

# Checkout the test files package
brazil ws use -p AdnFullSimMonitorRecoveryTestFiles --latest
```

### 2. Checkout Required Packages

```bash
# Checkout all necessary packages for FULLSIM testing
brazil ws use -p AdnEmbRecoverySource --latest
brazil ws use -p AdnVehicleControllersAlgorithms --latest
brazil ws use -p AdnVehicleRecoveryWrapperAlgorithms --latest
brazil ws use -p AdnVehicleMonitorWrapperAlgorithms --latest
```

### 3. Build Packages with Feature Branch

```bash
# Build the EMB recovery source with your feature branch
cd $root/src/AdnEmbRecoverySource
brazil-build -b <feature branch>

# Build the remaining packages
cd $root/src/AdnVehicleControllersAlgorithms && brazil-build
cd $root/src/AdnVehicleRecoveryWrapperAlgorithms && brazil-build
cd $root/src/AdnVehicleMonitorWrapperAlgorithms && brazil-build
cd $root/src/AdnFullSimMonitorRecoveryTestFiles && brazil-build
```

### 4. Make Code Changes

- Make your code changes to the EMB code in the `AdnEmbRecoverySource` package
- The code is located in the `git-hub/Amazon-PrimeAir` directory

### 5. Rebuild with Local Build

After making code changes, rebuild using local build to preserve your modifications:

```bash
bb local
```

## Test Execution Workflow

### Running Individual Tests

```bash
# Navigate to the test files directory
cd $root/src/AdnFullSimMonitorRecoveryTestFiles

# Execute the test environment
brazil-test-exec ipytest

# Run a specific test case
ipytest simulations/<path-to-your-test-file>.py::<name-of-your-test-case>
```

### Example Test Commands

```bash
# Example 1: Running a recovery switchover test with plot generation
brazil-test-exec ipytest
ipytest simulations/regression/test_cx3_recovery_switchover.py::test_cx3_recovery_switchover[20.0-id_10_1_hybrid_a_b_gps_land-PRIME_AIR-1-FullSimCX3_H-9.dv_knobs] --should-run-generate-parquet-plots=always --where-to-run-generate-parquet-plots=foreground

# Example 2: Running merge tests with FULLSIM only
cd $root/src/AdnFullSimMonitorRecoveryTestFiles
./bin/run_merge_tests.sh --fullsim-test-only
```

### Test Configuration

Tests use knob overrides to configure the simulation environment. Example configuration:

```python
# Set embention knobs.
override_knobs(
    {
        "adn.vehicle.recovery.control.use_embention_hardcoded_mission": True,
        "adn.vehicle.recovery.control.emb_hardcoded_mission_id": 1,
        "adn.vehicle.recovery.control.use_embention_recovery_wrapper": False,
        "adn.vehicle.recovery.control.use_embention_fullsim_wrapper_serialized": True,
        "adn.vehicle.recovery.navigation.use_embention_fullsim_wrapper_serialized": True,
    }
)
```

## Debugging Techniques

### Terminal Logging

To enable terminal logging for Hillsim tests:
1. Use `Emb_log.h` for logging
2. Set `DEBUG_MODE` to `true` in the header file at:
   `https://github.com/embention/Amazon-PrimeAir/blob/51e23515ba9802b4ea6efdaeeb2f08165afb590d/items/ASTRO/items/sw/sw_Astro/code/pa_blocks/code/include/Emb_log.h#L8`

### Plot Generation

Add flags to the ipytest command to generate visualization plots:

```bash
# For recovery plots
--should-run-generate-recovery-parquet-plots=always --where-to-run-generate-recovery-parquet-plots=foreground 

# For monitor plots
--should-run-generate-monitor-parquet-plots=always --where-to-run-generate-recovery-parquet-plots=foreground

# For all plots
--should-run-generate-parquet-plots=always --where-to-run-generate-parquet-plots=foreground
```

### VSCode Debugging Integration

VSCode can be used to debug EMB code during test execution:

1. **Enable Debug Mode in VSCode**
   - Open the debug panel in VSCode

2. **Configure Debug Settings**
   - Modify the `launch.json` file with the following configuration:
   ```json
   {
       "version": "0.2.0",
       "configurations": [
           {
               "name": "(gdb) Attach",
               "type": "cppdbg",
               "request": "attach",
               "program": "/lib64/ld-linux-x86-64.so.2",
               "MIMode": "gdb",
               "setupCommands": [
                   {
                       "description": "Enable pretty-printing for gdb",
                       "text": "-enable-pretty-printing",
                       "ignoreFailures": true
                   },
                   {
                       "description": "Set Disassembly Flavor to Intel",
                       "text": "-gdb-set disassembly-flavor intel",
                       "ignoreFailures": true
                   }
               ]
           },
       ]
   }
   ```

3. **Get Process ID**
   - In the `brazil-test-exec ipytest` console, run:
   ```python
   import os
   os.get_pid()
   ```

4. **Attach Debugger**
   - Attach the debugger to the console ID obtained in the previous step

5. **Run Test with Breakpoints**
   - Set breakpoints in the EMB code
   - Run the desired test
   - The debugger will pause execution at the breakpoints

## Merge Testing Requirements

### Pre-Merge Testing Process

Before merging code to integration branches (`feature/Amazon-PrimeAir/integration` or `feature/Amazon-PrimeAir/9388_pa_mk30`), FULLSIM tests must be run:

```bash
# Create a workspace for PR testing
brazil ws create --root pr_testing_ws_incremental -vs AdnCX3GNCControls/block20-build-emb
cd pr_testing_ws_incremental

# Checkout the test files package
brazil ws use -p AdnFullSimMonitorRecoveryTestFiles --latest 

# Run merge tests on your feature branch
./src/AdnFullSimMonitorRecoveryTestFiles/bin/run_merge_tests.sh my_feature_branch
```

### Handling Test Failures

If tests fail during merge testing:

1. Identify the failing test from the output
2. Rerun the specific failing test:
   ```bash
   cd src/AdnFullSimMonitorRecoveryTestFiles
   brazil-test-exec ipytest
   ipytest simulations/release/test_cx3_tam_fault_injection_embention_wrapper.py::test_cx3_tam_fault_injection_hybrid_embention_wrapper[EMBENTION_FWSIM-bc06bf3e-c10a-473a-9b19-96731efdfed7-FullSimCX3_H-9.dv_knobs] --use-beta-converter --should-run-generate-recovery-parquet-plots=always --should-run-generate-controls-parquet-plots=always --where-to-run-generate-recovery-parquet-plots=foreground 
   ```

3. Use tab completion to help with test path and feature selection
4. All available tests are located in `src/AdnFullSimMonitorRecoveryTestFiles/simulation/`

### Documentation Requirements

After running merge tests:
- Paste the FULLSIM test results as a comment in the associated pull request
- Include any relevant debugging information or test modifications made

## Key Packages and Their Relationships

### Core FULLSIM Packages

1. **AdnFullSimMonitorRecoveryTestFiles**
   - Contains test files and execution scripts
   - Provides the test harness for FULLSIM testing
   - Location of merge test scripts

2. **AdnEmbRecoverySource**
   - Contains the EMB code being tested
   - Primary location for code modifications
   - Interfaces with the Amazon-PrimeAir repository

3. **AdnVehicleControllersAlgorithms**
   - Implements vehicle control algorithms
   - Interfaces with EMB recovery code

4. **AdnVehicleRecoveryWrapperAlgorithms**
   - Provides wrappers for recovery algorithms
   - Bridges EMB code with the simulation environment

5. **AdnVehicleMonitorWrapperAlgorithms**
   - Implements monitoring functionality
   - Provides wrappers for system monitoring

### Package Interaction Flow

1. Test files in `AdnFullSimMonitorRecoveryTestFiles` initiate the simulation
2. The simulation environment loads code from `AdnEmbRecoverySource`
3. Wrapper packages (`AdnVehicleRecoveryWrapperAlgorithms` and `AdnVehicleMonitorWrapperAlgorithms`) provide interfaces between EMB code and the simulation
4. `AdnVehicleControllersAlgorithms` provides control algorithms used during simulation
5. Test results are collected and analyzed by the test harness

## Development and Testing Workflow

### Complete Workflow

1. **Setup Environment**
   - Create Brazil workspace
   - Checkout required packages
   - Build packages with feature branch

2. **Develop Code**
   - Make changes to EMB code in `AdnEmbRecoverySource`
   - Rebuild using local build (`bb local`)

3. **Test Changes**
   - Run individual tests to verify functionality
   - Debug using VSCode integration if needed
   - Generate plots to analyze results

4. **Prepare for Merge**
   - Run merge tests on feature branch
   - Address any test failures
   - Document test results in pull request

5. **Merge Code**
   - After successful testing, proceed with merge to integration branch

### Long-Running Test Management

For long-running tests, consider using tmux to maintain terminal sessions:

1. Increase history limit for better log retention:
   ```bash
   echo 'set-option -g history-limit 10000' >> ~/.tmux.conf
   tmux source-file ~/.tmux.conf
   ```

2. Save terminal history to file:
   ```bash
   tmux capture-pane -pS -50000 > output.txt
   ```

3. Scroll through terminal output:
   - Press `Ctrl+b`, then `[`
   - Use standard navigation keys
   - Press `q` to exit scroll mode

## Referenced Context Files

The following context files provided valuable information for this guide:
- `06_Development_Environment_Setup.md`: Provided details on Cloud Desktop setup, authentication configuration, and development tools that support the FULLSIM testing environment