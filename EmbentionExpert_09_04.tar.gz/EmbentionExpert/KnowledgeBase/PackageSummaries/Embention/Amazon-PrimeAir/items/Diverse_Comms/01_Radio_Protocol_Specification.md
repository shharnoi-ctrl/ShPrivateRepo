# Generated from:

- Amazon-PrimeAir/items/Diverse_Comms/02_Radio_Configuration_Scripts.md (4239 tokens)
- Amazon-PrimeAir/items/Diverse_Comms/02_Environmental_Test_Scripts.md (5070 tokens)
- Amazon-PrimeAir/items/Diverse_Comms/02_Final_and_RF_Test_Scripts.md (5783 tokens)

---

# Radio Communication Protocol and Configuration Specification

This document provides a comprehensive specification of the radio communication protocols and configuration parameters used across the analyzed scripts, focusing on the AT command set, S-register settings, telemetry packet structure, command mode entry requirements, and the two-phase configuration process.

## 1. AT Command Set Reference

The radio devices use a Hayes-compatible AT command set for configuration and control. The following commands are consistently used across all scripts:

| Command | Description | Usage | Parameters |
|---------|-------------|-------|------------|
| `+++` | Enter Command Mode | Switches the radio from data mode to command mode | None, but requires specific timing (see section 4) |
| `AT&F1` | Factory Reset (Type 1) | Resets all settings to factory defaults | None |
| `AT&F2` | Factory Reset (Type 2) | Alternative factory reset, used in final test scripts | None |
| `ATSxxx=y` | Set S-Register | Sets register number xxx to value y | xxx: register number, y: value |
| `AT&W` | Write Settings | Saves current settings to non-volatile memory | None |
| `ATA` | Answer/Exit Command Mode | Returns the radio to data mode | None |

### 1.1 Command Syntax and Formatting

- All commands (except `+++`) must be terminated with a carriage return (`\r`)
- Commands are case-insensitive
- Responses are typically returned after each command
- The `+++` command requires special timing (see section 4)

### 1.2 Command Usage Patterns

Two distinct command sequences are observed across the scripts:

**Initial Configuration Sequence:**
```
+++
AT&F1
ATS102=5
AT&W
ATA
```

**Full Configuration Sequence:**
```
+++
AT&F1/AT&F2
ATS108=21
ATS104=1000
ATS105=1/2
ATS102=5
ATS113=2
ATS103=2
ATS128=1/2/4
AT&W
ATA
```

## 2. S-Register Settings and Their Functions

S-registers are special memory locations that control various aspects of the radio's operation. The following S-registers are consistently configured across the scripts:

| Register | Values Used | Purpose | Description |
|----------|-------------|---------|-------------|
| S102 | 5 | RF Output Power | Controls the transmit power level of the radio. Value 5 appears to be a standard setting used across all frequency bands. |
| S103 | 2 | RF Protocol Options | Configures protocol-specific options for the radio communication. Value 2 is used consistently across all scripts. |
| S104 | 1000 | Network ID | Sets the network identifier for the radio network. This value (1000) is used to ensure radios communicate only with others on the same network. |
| S105 | 1, 2 | RF Packet Size/Mode | Controls the RF packet size or transmission mode. Value 1 is used for RF power measurement, while value 2 is used for telemetry testing. |
| S108 | 21 | RF Data Rate/Modulation | Sets the RF data rate and modulation scheme. Value 21 is used consistently across all scripts. |
| S113 | 2 | RF Channel/Frequency | Fine-tunes the RF channel or frequency settings within the selected band. Value 2 is used consistently. |
| S128 | 1, 2, 4 | Frequency Band Selection | Determines the primary frequency band of operation:<br>- Value 1: 900MHz band<br>- Value 2: 400MHz band<br>- Value 4: 896MHz band |

### 2.1 S-Register Configuration Patterns

The S-registers are configured in a specific order across all scripts:

1. S108 (RF data rate/modulation)
2. S104 (Network ID)
3. S105 (RF packet size/mode)
4. S102 (RF output power)
5. S113 (RF channel/frequency)
6. S103 (RF protocol options)
7. S128 (Frequency band selection)

This order suggests a dependency hierarchy where certain parameters must be set before others.

### 2.2 S-Register Value Variations

While most S-register values remain consistent across scripts, two notable variations exist:

1. **S105 Register:**
   - Value 1: Used in RF power measurement scripts
   - Value 2: Used in telemetry testing scripts
   
   This suggests S105 controls a mode setting that differs between continuous transmission (for power measurement) and packet-based transmission (for telemetry).

2. **S128 Register:**
   - Value 1: 900MHz band
   - Value 2: 400MHz band
   - Value 4: 896MHz band
   
   This is the primary differentiator between radio configurations for different frequency bands.

## 3. Telemetry Packet Structure and Binary Protocol

The radio communication uses a binary protocol for telemetry transmission. The packet structure is implemented through the `diverseComms` class.

### 3.1 Telemetry Packet Creation

```python
def create_telemetry_packet(self):
    return self.diverse_comms.makeTelemetry(
        int(time.time()),       # Timestamp (Unix epoch)
        "178650100F",           # Device ID (10 characters)
        20.727413983250234,     # Latitude (degrees)
        -156.10488400389238,    # Longitude (degrees)
        400.15,                 # Altitude (meters)
        27.2153185,             # Speed (m/s)
        1,                      # Status code
        0,                      # Battery level
        False,                  # Boolean flag
        0.823562                # Additional value
    )
```

### 3.2 Binary Packet Structure

Based on the code analysis, the telemetry packet has the following structure:

| Field | Size | Description |
|-------|------|-------------|
| Header | Variable | Packet identifier and type information |
| Timestamp | 4 bytes | Unix epoch time (seconds since Jan 1, 1970) |
| Device ID | 10 bytes | ASCII device identifier |
| Latitude | 8 bytes | Double-precision floating point (degrees) |
| Longitude | 8 bytes | Double-precision floating point (degrees) |
| Altitude | 4 bytes | Single-precision floating point (meters) |
| Speed | 4 bytes | Single-precision floating point (m/s) |
| Status | 1 byte | Integer status code |
| Battery | 1 byte | Battery level indicator |
| Flag | 1 byte | Boolean flag |
| Value | 4 bytes | Single-precision floating point (purpose varies) |
| CRC | 2 bytes | Cyclic Redundancy Check for packet validation |

### 3.3 CRC Validation

The protocol uses a 2-byte CRC (Cyclic Redundancy Check) appended to the end of each packet for validation:

```python
def compare_crc(self, sent_packet, received_packet):
    sent_crc = sent_packet[-2:]
    received_crc = received_packet[-2:]
    return sent_crc == received_crc
```

This CRC validation ensures packet integrity during transmission and reception.

### 3.4 Packet Parsing

The `diverseComms` class provides methods to parse binary telemetry packets into human-readable format:

```python
sended_message = self.diverse_comms.parseTelemetry(telemetry_packet)
received_message = self.diverse_comms.parseTelemetry(received_packet)
```

The parsed output includes all telemetry fields in a readable string format, which is then logged for analysis.

## 4. Command Mode Entry Sequence and Timing Requirements

The `+++` command to enter command mode has specific timing requirements that are critical for proper operation:

### 4.1 Command Mode Entry Timing

```python
if command == "+++":
    for element in command:
        ser.write(element.encode())
        time.sleep(0.5)
    time.sleep(2)
    response = ser.read(ser.in_waiting or 1)
```

The timing requirements are:
1. Each `+` character must be sent individually
2. A 500ms (0.5 second) delay must be observed between each character
3. After sending all three characters, a 2-second delay must be observed before reading the response
4. No carriage return is appended to this command

### 4.2 Guard Time Requirements

The special handling of the `+++` command implements what is known as "guard time" in Hayes-compatible modems:

1. **Pre-command guard time:** Not explicitly implemented but implied by the protocol
2. **Inter-character timing:** 500ms between each `+` character
3. **Post-command guard time:** 2 seconds after sending the complete `+++` sequence

This timing ensures the `+++` sequence is recognized as a command rather than data, even when embedded in a data stream.

### 4.3 Command Mode Response

After successful entry into command mode, the radio typically responds with "OK" or a similar acknowledgment. This response is read and logged:

```python
response = ser.read(ser.in_waiting or 1)
self.write_log_and_console(f"Command: {command} -> Response: {response.decode().strip()}")
```

## 5. Two-Phase Configuration Process with Baud Rate Changes

The radio configuration process occurs in two distinct phases with different baud rates:

### 5.1 Phase 1: Initial Configuration at 9600 baud

```python
# Configure communication speed
speed = 9600

# Use your COM ports
COM_port1 = "COM12"

# Modem config
ser = serial.Serial(COM_port1, speed, timeout=1)

at_commands_init = [
    "+++",          # Enter command mode
    "AT&F1",        # Factory reset
    "ATS102=5",     # Set S102 register (RF output power)
    "AT&W",         # Save settings
    "ATA"           # Answer call (exit command mode)
]

# Send each AT command
for command in at_commands_init:
    send_at_command(ser, command, delay)
ser.close()
```

This initial phase:
1. Opens a serial connection at 9600 baud
2. Enters command mode
3. Performs a factory reset
4. Sets only the S102 register (RF output power)
5. Saves this minimal configuration
6. Exits command mode
7. Closes the serial connection

### 5.2 Phase 2: Full Configuration at 19200 baud

```python
# Configure communication speed
speed = 19200

# Use your COM ports
COM_port1 = "COM12"

# Modem config
ser = serial.Serial(COM_port1, speed, timeout=1)

# List of AT commands to send
at_commands = [
    "+++",          # Enter command mode
    "AT&F1",        # Factory reset
    "ATS108=21",    # Set S108 register (RF data rate/modulation)
    "ATS104=1000",  # Set S104 register (network ID)
    "ATS105=1",     # Set S105 register (RF packet size/mode)
    "ATS102=5",     # Set S102 register (RF output power)
    "ATS113=2",     # Set S113 register (RF channel/frequency)
    "ATS103=2",     # Set S103 register (RF protocol options)
    "ATS128=X",     # Set S128 register (frequency band selection)
    "AT&W",         # Save settings
    "ATA"           # Answer call (exit command mode)
]

# Send each AT command
for command in at_commands:
    send_at_command(ser, command, delay)
```

This main configuration phase:
1. Opens a new serial connection at the higher 19200 baud rate
2. Enters command mode again
3. Performs another factory reset
4. Sets all required S-registers in sequence
5. Saves the complete configuration
6. Exits command mode

### 5.3 Purpose of the Two-Phase Approach

The two-phase configuration process serves several purposes:

1. **Baud Rate Transition:** The initial phase at 9600 baud likely establishes a known baseline configuration before switching to the higher 19200 baud rate.

2. **Minimal Initial Configuration:** The first phase sets only the essential S102 register (RF output power), which may be required for stable communication at the higher baud rate.

3. **Factory Default Synchronization:** Both phases begin with a factory reset, ensuring a known starting state before applying specific configurations.

4. **Reliability:** The two-phase approach increases reliability by first establishing basic communication before applying the full configuration.

### 5.4 Serial Port Configuration Parameters

Both phases use the following serial port configuration:

```python
ser = serial.Serial(COM_port1, speed, timeout=1)
```

- **Port:** COM12 (Windows COM port designation)
- **Baud Rate:** 9600 (Phase 1) or 19200 (Phase 2)
- **Timeout:** 1 second
- **Other Parameters:** Default values (not explicitly set)
  - Parity: None
  - Stop Bits: 1
  - Data Bits: 8
  - Flow Control: None

## 6. Radio Configuration Variations by Frequency Band

The primary difference between radio configurations for different frequency bands is the S128 register setting:

### 6.1 900MHz Band Configuration

```python
"ATS128=1",  # Set S128 register for 900MHz band
```

Used in:
- 900MHzRadioMaster.py
- LRU_900MHz_EnvironmentalTest_Basic.py
- LRU_900MHz_High_temperature.py
- LRU_900MHz_Low_Temperature.py
- LRU_900MHz_FinalTest.py
- 900MHz 27dBm.py

### 6.2 400MHz Band Configuration

```python
"ATS128=2",  # Set S128 register for 400MHz band
```

Used in:
- 400MHzRadioMaster.py

### 6.3 896MHz Band Configuration

```python
"ATS128=4",  # Set S128 register for 896MHz band
```

Used in:
- 896MHzRadioMaster.py

All other S-register settings remain consistent across frequency bands, suggesting that the S128 register is the primary determinant of the operating frequency band.

## 7. AT Command Response Handling

The scripts implement a consistent approach to handling AT command responses:

```python
def send_at_command(self, COM_port, command, delay=0.5):
    try:
        with serial.Serial(COM_port, self.speed, timeout=1) as ser:
            if command == "+++":
                # Special handling for +++ command
                for element in command:
                    ser.write(element.encode())
                    time.sleep(0.5)
                time.sleep(delay)
                response = ser.read(ser.in_waiting or 1)
            else:
                # Standard AT command handling
                ser.write((command + "\r").encode())
                time.sleep(delay)
                response = ser.read(ser.in_waiting or 1)
            
            # Log command and response
            self.write_log_and_console(f"Command: {command} -> Response: {response.decode().strip()}")
    except serial.SerialException as e:
        self.write_log_and_console(f"Serial connection error while sending AT command: {e}")
```

Key aspects of response handling:
1. After sending each command, the script waits for the specified delay
2. It then reads all available bytes from the serial buffer
3. If no bytes are available, it reads at least one byte
4. The response is decoded from bytes to a string
5. Whitespace is stripped from the response
6. Both the command and response are logged
7. Serial exceptions are caught and logged

## 8. Test Execution and Validation Methodology

The radio testing methodology follows a consistent pattern across all test scripts:

### 8.1 Configuration and Setup

1. Initialize power supply (5V, 4A)
2. Configure radio with appropriate AT commands
3. Perform power cycling before testing

### 8.2 Telemetry Testing

1. Create a telemetry packet with test data
2. Send the packet to the radio
3. Read back the received packet
4. Validate the packet using CRC comparison
5. Log the result (PASS/FAIL)
6. Repeat for the specified test duration

### 8.3 RF Power Testing

1. Configure radio for continuous transmission
2. Configure spectrum analyzer (center frequency, span, etc.)
3. Measure channel power and power density
4. Compare measured power against threshold (25 dBm)
5. Log the result (PASS/FAIL)

## 9. Integration with External Equipment

The radio testing scripts integrate with several external devices:

### 9.1 Power Supply Integration

```python
power_comntroller = PowerSupply(port="COM10")
power_comntroller.set_output_voltage(5)
power_comntroller.set_output_current(4)
power_comntroller.enable_output(True)
```

- Uses COM10 port for power supply control
- Sets 5V output voltage and 4A current limit
- Enables/disables output as needed during testing
- Monitors current consumption during telemetry testing

### 9.2 Spectrum Analyzer Integration

```python
instr = pyvisa.ResourceManager().open_resource('TCPIP::192.168.0.94::INSTR')
instr.write(':FREQuency:CENTer 922.84 MHz')
instr.write(':FREQuency:SPAN 2 MHz')
instr.write('[:SENSe]:POWer[:RF]:ATTenuation 30 dB')
instr.write(':INSTrument:MEASure CHPower')
instr.write('[:SENSe]:CHPower:BWIDth:INTegration 280kHz')
```

- Connects to spectrum analyzer via TCP/IP (192.168.0.94)
- Configures center frequency (922.84 MHz for 900MHz band)
- Sets 2 MHz span and 30 dB attenuation
- Configures channel power measurement with 280 kHz integration bandwidth
- Queries power measurements for validation

### 9.3 Camera Integration

```python
def waitForCameraSignal(self):
    signalRecived = False
    with serial.Serial(self.COM_port3, self.speed, timeout=1) as ser:
        while signalRecived == False:
            mensaje = "signal"
            ser.write(mensaje.encode('utf-8'))
            time.sleep(1)
            try:
                recibido = ser.read(len(mensaje)).decode('utf-8')
            except:
                recibido = None
            if recibido == mensaje:
                signalRecived = True
```

- Uses COM11 port for camera communication
- Implements a simple handshake protocol
- Sends "signal" message and waits for echo
- Synchronizes test execution with camera operation

## 10. Summary of Key Protocol Parameters

| Parameter | Value | Description |
|-----------|-------|-------------|
| **Communication Parameters** |
| Initial Baud Rate | 9600 | Used for initial configuration |
| Main Baud Rate | 19200 | Used for main configuration and testing |
| Serial Timeout | 1 second | Timeout for serial read operations |
| **Command Mode Entry** |
| Inter-character Delay | 500ms | Delay between each '+' character |
| Post-command Delay | 2 seconds | Delay after sending '+++' sequence |
| **Radio Configuration** |
| RF Output Power | S102=5 | Power level setting |
| Network ID | S104=1000 | Network identifier |
| RF Packet Size/Mode | S105=1/2 | 1 for power testing, 2 for telemetry |
| RF Data Rate | S108=21 | Data rate and modulation setting |
| RF Channel | S113=2 | Channel or frequency setting |
| RF Protocol Options | S103=2 | Protocol-specific options |
| Frequency Band | S128=1/2/4 | 1=900MHz, 2=400MHz, 4=896MHz |
| **Telemetry Protocol** |
| Packet Validation | 2-byte CRC | Located at end of packet |
| Device ID Format | 10 characters | Example: "178650100F" |
| Position Format | Double precision | Latitude and longitude in degrees |
| **Test Parameters** |
| Power Supply Voltage | 5V | Standard operating voltage |
| Power Supply Current | 4A | Maximum current limit |
| RF Power Threshold | 25 dBm | Minimum acceptable power output |
| Test Duration | 5 seconds | Default telemetry test duration |

This comprehensive specification documents the radio's programming interface and communication protocol as implemented across all the analyzed scripts, providing a complete reference for understanding and working with these radio devices.