# Generated from:

- artifacts/Final test script/LRU_900MHz_FinalTest.py (2230 tokens)
- artifacts/RF power mesurement scripts/900MHz 27dBm.py (1174 tokens)

## With context from:

- Amazon-PrimeAir/items/Diverse_Comms/03_Test_Dependencies.md (5021 tokens)

---

# High-Fidelity Analysis of Final Test and RF Power Measurement Scripts

This document provides a comprehensive analysis of the final test and RF power measurement scripts used for testing and validating 900MHz radio devices. The analysis focuses on the test execution pipeline, radio configuration, telemetry validation, RF power measurement methodology, and how these scripts integrate with the Test_Dependencies libraries.

## 1. LRU_900MHz_FinalTest.py - Final Test Script

The LRU_900MHz_FinalTest.py script implements a comprehensive final testing procedure for 900MHz radio devices, focusing on telemetry transmission and reception validation under controlled power conditions.

### 1.1 Environmental Test Script for PA Class

The `environmental_test_script_for_PA` class serves as the core testing framework with the following components:

#### 1.1.1 Initialization and Configuration

```python
def __init__(self, speed, COM_radio_port, COM_power_supply, delay, failure_counter, max_fauilure_count, log_path, power_controller):
    # Configure communication speed
    self.speed = speed

    # Use your COM ports
    self.COM_port1 = COM_radio_port
    self.COM_port2 = COM_power_supply

    # Delay read s
    self.delay = delay

    # Execution time
    self.duration = None

    # Initial failure counter, and maximum number of failures
    self.failure_counter = failure_counter
    self.max_failure_count = max_fauilure_count

    # Log file path, change if needed
    self.log_path = log_path
    cwd = os.getcwd()
    fullLogPath = f"{cwd}\\logs\\{self.log_path}"
    # Delete previous log
    if os.path.exists(fullLogPath):
        os.remove(fullLogPath)

    # Initialize diverseComms object
    self.diverse_comms = diverseComms()

    self.at_command = None
    self.power_controller = power_controller
```

The initialization process:
1. Sets up serial communication parameters (speed, ports)
2. Initializes test parameters (delay, duration, failure counters)
3. Configures logging with automatic cleanup of previous logs
4. Initializes the diverseComms protocol handler for telemetry
5. Stores a reference to the power controller for power supply management

#### 1.1.2 Logging Infrastructure

The class implements two logging methods:
```python
def write_log_and_console(self, message):
    print(message)
    cwd = os.getcwd()
    with open(f"{cwd}\\logs\\{self.log_path}", "a") as log_file:
        log_file.write(message + "\n")

def write_log(self, message):
    cwd = os.getcwd()
    with open(f"{cwd}\\logs\\{self.log_path}", "a") as log_file:
        log_file.write(message + "\n")
```

- `write_log_and_console`: Outputs messages to both console and log file
- `write_log`: Writes only to the log file (for non-interactive data)

#### 1.1.3 Radio Configuration via AT Commands

The script configures the radio using AT commands through a serial interface:

```python
def set_at_command(self, command):
    self.at_command = command

def configurate_radio(self):
    for command in self.at_command:
        self.send_at_command(self.COM_port1, command)

def configurate_power_supply(self):
    for command in self.at_command:
        self.send_at_command(self.COM_port2, command)

def send_at_command(self, COM_port, command, delay = 0.5):
    try:
        with serial.Serial(COM_port, self.speed, timeout=1) as ser:
            if command == "+++":
                for element in command:
                    ser.write(element.encode())
                    time.sleep(0.5)
                time.sleep(delay)
                response = ser.read(ser.in_waiting or 1)
                self.write_log_and_console(f"Command: {command} -> Response: {response.decode().strip()}")
            else:
                ser.write((command + "\r").encode())
                time.sleep(delay)
                response = ser.read(ser.in_waiting or 1)
                self.write_log_and_console(f"Command: {command} -> Response: {response.decode().strip()}")
    except serial.SerialException as e:
        self.write_log_and_console(f"Serial connection error while sending AT command: {e}")
```

Key aspects of the AT command handling:
1. Special handling for the `+++` command (command mode entry) with character-by-character transmission and longer delays
2. Standard commands are sent with carriage return appended
3. All responses are logged with their corresponding commands
4. Serial exceptions are caught and logged

#### 1.1.4 Telemetry Testing and Validation

The core test functionality creates telemetry packets, transmits them, and validates the received responses:

```python
def create_telemetry_packet(self):
    return self.diverse_comms.makeTelemetry(int(time.time()), "178650100F", 20.727413983250234,
                                            -156.10488400389238, 400.15, 27.2153185, 1, 0, False, 0.823562)

def compare_crc(self, sent_packet, received_packet):
    sent_crc = sent_packet[-2:]
    received_crc = received_packet[-2:]
    return sent_crc == received_crc

def start_test(self):
    end_test_time = time.time() + self.duration
    while time.time() < end_test_time:
        try:
            # Configure serial connection for both reading and writing ports
            with serial.Serial(self.COM_port1, self.speed, timeout=1) as ser:
                # Create telemetry packet
                telemetry_packet = self.create_telemetry_packet()

                # Write telemetry packet to serial port
                timestamp_sent = datetime.datetime.now()
                ser.write(telemetry_packet)

                # Read telemetry packet from serial port
                received_packet = bytearray()
                end_time = time.time() + self.delay
                while time.time() < end_time:
                    received_packet += ser.read(ser.in_waiting)
                    timestamp_received = datetime.datetime.now()
                    if len(received_packet) >= len(telemetry_packet):
                        break

                sended_message = self.diverse_comms.parseTelemetry(telemetry_packet)
                received_message = self.diverse_comms.parseTelemetry(received_packet)

                self.write_log_and_console(f"{timestamp_sent},sent,{sended_message}")
                # Check if received packet matches sent packet by comparing CRC
                if self.compare_crc(telemetry_packet, received_packet):
                    self.write_log_and_console(f"{timestamp_received},received,{received_message},PASS,{self.power_controller.get_output_current()}")
                else:
                    self.write_log_and_console(f"{timestamp_received},received,{received_message},FAIL,{self.power_controller.get_output_current()}")
                    self.failure_counter += 1

        except serial.SerialException as e:
            message = f"Serial connection error: {e}"
            self.write_log_and_console(message)
            self.failure_counter += 1

    self.write_log_and_console("*****************************************************************")
    if self.failure_counter != 0:
        self.write_log_and_console("Test: FAIL")
    else:
        self.write_log_and_console("Test: PASS")
```

The telemetry testing process:
1. Creates a telemetry packet with fixed test data (coordinates, altitude, speed, etc.)
2. Sends the packet to the radio device
3. Waits for a response with a configurable timeout
4. Parses both the sent and received packets using the diverseComms parser
5. Validates the response by comparing CRC checksums
6. Logs the result (PASS/FAIL) along with current power consumption data
7. Increments a failure counter if validation fails
8. Provides a final test result based on the failure counter

### 1.2 Main Test Execution Flow

The `main()` function orchestrates the complete test sequence:

```python
def main():
    #Initialize the power_controller and the test_script class with yout COM ports and configurations
    power_comntroller = PowerSupply(port="COM10")
    id_radio_scanned = input("Scann the serial number ")
    if not os.path.exists("logs"):
        os.makedirs("logs")
    test_script = environmental_test_script_for_PA(speed=19200, COM_radio_port="COM12",COM_power_supply="COM10" ,delay=0.5,
                                                   failure_counter=0, max_fauilure_count=50, log_path= f"{id_radio_scanned}.txt", power_controller=power_comntroller)

    test_script.write_log_and_console("*****************************************************************")
    test_script.write_log_and_console(f"Script name: {os.path.basename(__file__)}")
    test_script.write_log_and_console("Script version: 0.0.0")

    #Change the test duration
    test_duration = 5
    test_script.set_test_duration(test_duration)
    test_script.write_log_and_console(f"Test duration {test_duration} seconds")

    #Configurate your power controller
    power_comntroller.set_output_voltage(5)
    power_comntroller.set_output_current(4)
    power_comntroller.enable_output(True)

    # List of AT commands to send
    at_commands = [
        ":SYSTem:COMMunicate:RS232:BAUD?",
        ":APPLy CH1,5,5",  # Configure output 5V and current 5A
        ":OUTPut:STATe CH1,ON" #Activate output
    ]

    #Show the commands of the power supply
    test_script.write_log_and_console(f"Power Supply Configuration: ")
    for command in at_commands:
        time.sleep(1)
        test_script.write_log_and_console(command)

    time.sleep(1)

    test_script.write_log(f"Radio ID (input by keyboard) {id_radio_scanned}")

    # List of AT commands to send to AIR RADIO
    at_commands = [
        "+++",  # Enter command mode
        "AT&F2",  # Factory reset
        "ATS108=21",  # Set S108 register
        "ATS104=1000",  # Set S104 register
        "ATS105=2",  # Set S105 register
        "ATS102=5",  # Set S102 register
        "ATS113=2",  # Set S113 register
        "ATS103=2",  # Set S103 register
        "ATS128=1",  # Set S128 register
        "AT&W",  # Save settings
        "ATA"  # Answer call
    ]

    # Show commands for configurating the radio and configurate the radio
    test_script.set_at_command(at_commands)
    test_script.write_log_and_console(f"Radio configuration ")

    test_script.configurate_radio()
    test_script.write_log_and_console("*****************************************************************")

    time.sleep(2)
    power_comntroller.enable_output(False)
    time.sleep(2)

    power_comntroller.enable_output(True)
    time.sleep(2)
    #Start the tes
    test_script.start_test()

    #Desactivate the power supply
    power_comntroller.enable_output(False)
```

The main execution sequence:
1. Initializes the power supply controller for the COM10 port
2. Prompts for a radio serial number for test identification
3. Creates the test script instance with configuration parameters
4. Sets up logging with test metadata (script name, version)
5. Configures the power supply (5V, 4A)
6. Configures the radio with specific AT commands:
   - Factory reset (`AT&F2`)
   - Various S-register settings for radio parameters
   - Saving settings and answering call
7. Performs a power cycle (off/on) before starting the test
8. Executes the telemetry test for the specified duration
9. Disables the power supply when testing is complete

## 2. 900MHz 27dBm.py - RF Power Measurement Script

The 900MHz 27dBm.py script focuses on measuring and validating the RF output power of 900MHz radio devices using a spectrum analyzer.

### 2.1 Script Structure and Flow

The script follows a linear execution flow without class encapsulation:

1. User input and initialization
2. Power supply configuration
3. Radio configuration via AT commands
4. Spectrum analyzer configuration
5. Power measurement and validation

### 2.2 Initialization and Logging

```python
print("--Diverse Comms programming...--")
id_radio_scanned = input("Scann the serial number ")
if not os.path.exists("logs"):
    os.makedirs("logs")
def delete_previous_log():
    cwd = os.getcwd()
    fullLogPath = f"{cwd}\\logs\\{id_radio_scanned}.txt"
    # Delete previous log
    if os.path.exists(fullLogPath):
        os.remove(fullLogPath)
def write_log_and_console(filename, message):
    print(message)
    cwd = os.getcwd()

    with open(f"{cwd}\\logs\\{filename}", "a") as log_file:
        log_file.write(message + "\n")
```

The initialization process:
1. Prompts for a radio serial number for test identification
2. Creates a logs directory if it doesn't exist
3. Deletes any previous log file for the same radio ID
4. Sets up logging functions for both console and file output

### 2.3 Power Supply and Radio Configuration

```python
def configurate_powerSupply(power_controller):
    power_comntroller.set_output_voltage(5)
    power_comntroller.set_output_current(4)
    power_comntroller.enable_output(True)
    
def send_at_command(ser, command, delay=0.1):
    if command == "+++":
        for element in command:
            ser.write(element.encode())
            time.sleep(0.5)
        time.sleep(2)
        response = ser.read(ser.in_waiting or 1)
        write_log_and_console(f"{id_radio_scanned}.txt",f"Command: {command} -> Response: {response.decode().strip()}")
    else:
        ser.write((command + "\r").encode())
        time.sleep(delay)
        response = ser.read(ser.in_waiting or 1)
        write_log_and_console(f"{id_radio_scanned}.txt",f"Command: {command} -> Response: {response.decode().strip()}")

delete_previous_log()
power_comntroller = PowerSupply(port="COM10")
configurate_powerSupply(power_comntroller)
```

The script configures the power supply and radio in two phases:

1. **Initial configuration at 9600 baud**:
```python
# Configure communication speed
speed = 9600
COM_port1 = "COM12"
ser = serial.Serial(COM_port1, speed, timeout=1)

at_commands_init = [
    "+++",  # Enter command mode
    "AT&F1",  # Factory reset
    "ATS102=5",  # Set S102 register
    "AT&W",  # Save settings
    "ATA"  # Answer call
]

# Send each AT command
for command in at_commands_init:
    send_at_command(ser, command, delay)

ser.close()
```

2. **Secondary configuration at 19200 baud**:
```python
# Configure communication speed
speed = 19200
COM_port1 = "COM12"
ser = serial.Serial(COM_port1, speed, timeout=1)

# List of AT commands to send
at_commands = [
    "+++",  # Enter command mode
    "AT&F1",  # Factory reset
    "ATS108=21",  # Set S108 register
    "ATS104=1000",  # Set S104 register
    "ATS105=1",  # Set S105 register
    "ATS102=5",  # Set S102 register
    "ATS113=2",  # Set S113 register
    "ATS103=2",  # Set S103 register
    "ATS128=1",  # Set S128 register
    "AT&W",  # Save settings
    "ATA"  # Answer call
]

# Send each AT command
for command in at_commands:
    send_at_command(ser, command, delay)
```

Key differences in radio configuration between the two scripts:
1. The RF power measurement script uses `AT&F1` (vs `AT&F2` in the final test)
2. The RF script sets `ATS105=1` (vs `ATS105=2` in the final test)
3. The RF script performs an initial configuration at 9600 baud before switching to 19200 baud

### 2.4 RF Power Measurement Methodology

The script uses PyVISA to communicate with a spectrum analyzer for RF power measurements:

```python
instr = pyvisa.ResourceManager().open_resource('TCPIP::192.168.0.94::INSTR')
instr.write_termination = '\n'
instr.read_termination = '\n'
instr.timeout = 3000

# Enable color printing
instr.write(':FREQuency:CENTer 922.84 MHz') #Channel center frequency
instr.write(':FREQuency:SPAN 2 MHz') #Span
instr.write('[:SENSe]:POWer[:RF]:ATTenuation 30 dB') #Spectrum analyzer internal attenuator
instr.write(':DISPlay:WINDow:TRACe:Y:SCALe:RLEVel:OFFSet 31 dBm') #Screen reference offsets
instr.write(':DISPlay:WINDow:TRACe:Y[:SCALe]:RLEVel 35 dBm') #Reference level
instr.write(':DISPlay:WINDow:TRACe:Y:DLINe 7 dB') #Scale/DIV

instr.write(':INSTrument:MEASure CHPower')
instr.write('[:SENSe]:CHPower:BWIDth:INTegration 280kHz')
instr.write(':TRAC1:MODE MAXHold')
time.sleep(5)

CHpower = instr.query_ascii_values(':MEASure:CHPower:CHPower?')
write_log_and_console(f"{id_radio_scanned}.txt",f"CHpower = {CHpower[0]} dBm")

DENSity = instr.query_ascii_values(':MEASure:CHPower:DENSity?')
write_log_and_console(f"{id_radio_scanned}.txt",f"CHpower = {DENSity[0]} dBm/Hz")
```

The spectrum analyzer configuration:
1. Sets the center frequency to 922.84 MHz with a 2 MHz span
2. Configures the internal attenuator to 30 dB
3. Sets display parameters (reference level, offsets, scale)
4. Configures the channel power measurement with 280 kHz integration bandwidth
5. Sets trace mode to MAX Hold to capture peak power
6. Waits 5 seconds for stable measurements
7. Queries both channel power and power density measurements

### 2.5 Power Validation Against Thresholds

```python
if int(CHpower[0]) < 25:
    write_log_and_console(f"{id_radio_scanned}.txt","TEST FAIL")
else:
    write_log_and_console(f"{id_radio_scanned}.txt","TEST PASS")
power_comntroller.enable_output(False)
```

The validation process:
1. Compares the measured channel power against a 25 dBm threshold
2. Logs the test result as PASS or FAIL
3. Disables the power supply when testing is complete

## 3. Integration with Test_Dependencies Libraries

Both scripts leverage the Test_Dependencies libraries for power supply control and communication protocol handling:

### 3.1 libraryDP700.py Integration

The PowerSupply class from libraryDP700.py is used in both scripts to:
1. Control the power supply voltage and current settings
2. Enable/disable power output
3. Monitor current consumption during tests

In the final test script, the power controller is passed to the test class:
```python
power_comntroller = PowerSupply(port="COM10")
test_script = environmental_test_script_for_PA(..., power_controller=power_comntroller)
```

This allows the test script to monitor current consumption during telemetry validation:
```python
self.write_log_and_console(f"{timestamp_received},received,{received_message},PASS,{self.power_controller.get_output_current()}")
```

### 3.2 diverseCommsFormatParserV0.py Integration

The diverseComms class from diverseCommsFormatParserV0.py is used in the final test script to:
1. Create telemetry packets with test data
2. Parse received telemetry packets
3. Validate packet integrity through CRC checking

```python
# Initialize diverseComms object
self.diverse_comms = diverseComms()

# Create telemetry packet
telemetry_packet = self.create_telemetry_packet()

# Parse telemetry packets
sended_message = self.diverse_comms.parseTelemetry(telemetry_packet)
received_message = self.diverse_comms.parseTelemetry(received_packet)
```

The RF power measurement script does not use the diverseComms library as it focuses on RF characteristics rather than protocol validation.

## 4. Comparative Analysis of the Scripts

### 4.1 Purpose and Focus

| LRU_900MHz_FinalTest.py | 900MHz 27dBm.py |
|-------------------------|-----------------|
| Validates telemetry transmission and reception | Measures RF output power |
| Tests protocol integrity via CRC validation | Tests RF power against minimum threshold |
| Focuses on data communication reliability | Focuses on RF transmission characteristics |
| Uses loopback testing methodology | Uses spectrum analyzer for direct measurement |

### 4.2 Radio Configuration Differences

| Parameter | LRU_900MHz_FinalTest.py | 900MHz 27dBm.py |
|-----------|-------------------------|-----------------|
| Factory Reset | AT&F2 | AT&F1 |
| S105 Register | ATS105=2 | ATS105=1 |
| Initial Baud Rate | 19200 only | 9600, then 19200 |

These differences suggest the RF power measurement requires a specific radio configuration that differs from the final test configuration.

### 4.3 Test Methodology

| LRU_900MHz_FinalTest.py | 900MHz 27dBm.py |
|-------------------------|-----------------|
| Creates and sends telemetry packets | Configures radio for continuous transmission |
| Validates received packets via CRC | Measures power output via spectrum analyzer |
| Tests for protocol integrity | Tests for RF power compliance |
| Monitors current consumption | Does not monitor current during test |
| Performs power cycling during test | No power cycling during measurement |

### 4.4 Code Structure and Organization

| LRU_900MHz_FinalTest.py | 900MHz 27dBm.py |
|-------------------------|-----------------|
| Object-oriented with test class | Procedural with function definitions |
| Encapsulated test methods | Linear execution flow |
| Reusable test framework | Single-purpose script |
| More extensive error handling | Minimal error handling |

## 5. Complete Radio Testing Workflow

Based on the analysis of both scripts, a complete radio testing workflow would likely follow this sequence:

1. **Initial Programming and Configuration**
   - Program the radio with firmware (not shown in these scripts)
   - Configure basic radio parameters

2. **RF Power Measurement (900MHz 27dBm.py)**
   - Configure the radio for RF power testing
   - Measure output power using spectrum analyzer
   - Validate power meets minimum threshold (25 dBm)
   - This ensures the radio's transmitter is functioning correctly

3. **Final Functional Test (LRU_900MHz_FinalTest.py)**
   - Configure the radio for operational use
   - Test telemetry transmission and reception
   - Validate protocol integrity via CRC checking
   - Monitor current consumption during operation
   - This ensures the radio's communication protocol is functioning correctly

4. **Additional Tests (Not Shown)**
   - Sensitivity testing (receiver performance)
   - Environmental testing (temperature, vibration)
   - Regulatory compliance testing

The scripts represent two critical phases in a complete radio validation process, focusing on different aspects of radio performance:
- RF characteristics (power output)
- Protocol functionality (telemetry transmission/reception)

Together, they provide a comprehensive validation of both the radio's RF transmission capabilities and its data communication reliability.

## 6. Referenced Context Files

The following context files provided useful information for understanding the test scripts:

- **Test_Dependencies.md**: Provided details on the libraryDP700.py and diverseCommsFormatParserV0.py libraries used by both scripts. This helped understand how the power supply control and communication protocol parsing are implemented.

The Test_Dependencies.md file was particularly helpful in understanding:
1. The PowerSupply class interface and command execution pipeline
2. The diverseComms protocol structure and packet creation/parsing methods
3. The CRC validation mechanism used for packet integrity checking
4. The integration between hardware control and protocol validation