# Generated from:

- artifacts/Environmental_test_scripts/LRU_900MHz_EnvironmentalTest_Basic.py (2230 tokens)
- artifacts/Environmental_test_scripts/Basic/LRU_900MHz_EnvironmentalTest_Basic.py (2593 tokens)
- artifacts/Environmental_test_scripts/High Temperature/LRU_900MHz_High_temperature.py (2593 tokens)
- artifacts/Environmental_test_scripts/Low Temperature/LRU_900MHz_Low_Temperature.py (2593 tokens)

## With context from:

- Amazon-PrimeAir/items/Diverse_Comms/03_Test_Dependencies.md (5021 tokens)

---

# Environmental Test Scripts for 900MHz Radios: High-Fidelity Analysis

This analysis provides a comprehensive examination of the environmental test scripts for 900MHz radios, focusing on their evolution, test orchestration capabilities, execution flow, and integration with test dependencies.

## 1. The `environmental_test_script_for_PA` Class Structure and Evolution

The `environmental_test_script_for_PA` class serves as the core test orchestration framework across all script variants. This class has evolved from a basic implementation to more advanced versions with camera integration.

### 1.1 Class Initialization and Configuration

```python
def __init__(self, speed, COM_radio_port, COM_power_supply, delay, failure_counter, max_fauilure_count, log_path, power_controller, COM_camera=None):
    # Configure communication speed
    self.speed = speed

    # COM ports configuration
    self.COM_port1 = COM_radio_port
    self.COM_port2 = COM_power_supply
    self.COM_port3 = COM_camera  # Only in advanced versions

    # Test parameters
    self.delay = delay
    self.duration = None
    self.failure_counter = failure_counter
    self.max_failure_count = max_fauilure_count

    # Log file setup
    self.log_path = log_path
    cwd = os.getcwd()
    fullLogPath = f"{cwd}\\logs\\{self.log_path}"
    # Delete previous log
    if os.path.exists(fullLogPath):
        os.remove(fullLogPath)

    # Initialize dependencies
    self.diverse_comms = diverseComms()
    self.at_command = None
    self.power_controller = power_controller
```

### 1.2 Evolution from Basic to Advanced Scripts

The scripts show a clear evolution path:

1. **Original Basic Script** (`LRU_900MHz_EnvironmentalTest_Basic.py` in root directory):
   - No camera integration
   - Simpler logging without timestamps
   - No wait for camera signal functionality

2. **Advanced Basic Script** (`Basic/LRU_900MHz_EnvironmentalTest_Basic.py`):
   - Added camera integration via `COM_camera` parameter
   - Added `waitForCameraSignal()` method
   - Enhanced logging with timestamps
   - More structured test flow with camera synchronization

3. **Environmental Variant Scripts** (High/Low Temperature):
   - Identical structure to the advanced basic script
   - Organized in separate directories for different test conditions
   - Maintain the same core functionality but are positioned for different environmental test scenarios

### 1.3 Camera Integration Evolution

The addition of camera integration represents a significant advancement:

```python
def waitForCameraSignal(self):
    signalRecived = False
    with serial.Serial(self.COM_port3, self.speed, timeout=1) as ser:
        while signalRecived == False:
            mensaje = "signal"
            ser.write(mensaje.encode('utf-8'))
            time.sleep(1)
            try:
                recibido = ser.read(len(mensaje)).decode('utf-8')
            except:
                recibido = None
            if recibido == mensaje:
                signalRecived = True
```

This method:
1. Opens a serial connection to the camera
2. Repeatedly sends a "signal" message
3. Waits for an echo response from the camera
4. Only proceeds when the camera acknowledges with the same signal
5. Provides synchronization between test execution and camera operation

## 2. Test Orchestration Capabilities

The `environmental_test_script_for_PA` class provides comprehensive test orchestration capabilities through several key methods:

### 2.1 Logging and Reporting

```python
def write_log_and_console(self, message):
    print(message)
    cwd = os.getcwd()
    with open(f"{cwd}\\logs\\{self.log_path}", "a") as log_file:
        log_file.write(message + "\n")

def write_log(self, message):
    cwd = os.getcwd()
    with open(f"{cwd}\\logs\\{self.log_path}", "a") as log_file:
        log_file.write(message + "\n")
```

These methods:
- Support both console and file logging
- Create persistent test records in the logs directory
- In advanced versions, include timestamps with each log entry
- Maintain a complete audit trail of test execution

### 2.2 Radio Configuration

```python
def set_at_command(self, command):
    self.at_command = command

def configurate_radio(self):
    for command in self.at_command:
        self.send_at_command(self.COM_port1, command)
```

These methods:
- Store and execute AT command sequences for radio configuration
- Apply configuration settings sequentially
- Log each command and its response
- Handle special command formatting (e.g., the "+++" command mode entry)

### 2.3 Power Supply Control

```python
def configurate_power_supply(self):
    for command in self.at_command:
        self.send_at_command(self.COM_port2, command)
```

This method:
- Sends configuration commands to the power supply
- Uses the same AT command infrastructure as radio configuration
- Enables power cycling and supply parameter adjustment

### 2.4 Telemetry Testing

```python
def create_telemetry_packet(self):
    return self.diverse_comms.makeTelemetry(int(time.time()), "178650100F", 20.727413983250234,
                                            -156.10488400389238, 400.15, 27.2153185, 1, 0, False, 0.823562)

def compare_crc(self, sent_packet, received_packet):
    sent_crc = sent_packet[-2:]
    received_crc = received_packet[-2:]
    return sent_crc == received_crc
```

These methods:
- Create standardized telemetry packets for testing
- Validate received packets against sent packets using CRC comparison
- Provide the core functionality for radio communication testing

### 2.5 Test Duration Control

```python
def set_test_duration(self, test_duration):
    self.duration = int(test_duration)
```

This method:
- Sets the total test execution time
- Controls the test loop termination condition
- Allows for configurable test durations based on test requirements

## 3. Test Execution Flow

The test execution flow follows a consistent pattern across all script variants:

### 3.1 Initialization Phase

```python
# Initialize the power_controller and the test_script class
power_comntroller = PowerSupply(port="COM10")
id_radio_scanned = input("Scann the serial number ")
if not os.path.exists("logs"):
    os.makedirs("logs")
test_script = environmental_test_script_for_PA(speed=19200, COM_radio_port="COM12", COM_power_supply="COM10",
                                               delay=0.5, failure_counter=0, max_fauilure_count=50,
                                               log_path=f"{id_radio_scanned}.txt",
                                               power_controller=power_comntroller, COM_camera="COM11")
```

This phase:
1. Initializes the power supply controller
2. Prompts for radio serial number input
3. Creates the logs directory if it doesn't exist
4. Instantiates the test script with configuration parameters
5. Sets up communication ports, timing parameters, and failure tracking

### 3.2 Configuration Phase

```python
# Configurate your power controller
power_comntroller.set_output_voltage(5)
power_comntroller.set_output_current(4)
power_comntroller.enable_output(True)

# List of AT commands to send to AIR RADIO
at_commands = [
    "+++",  # Enter command mode
    "AT&F2",  # Factory reset
    "ATS108=21",  # Set S108 register
    "ATS104=1000",  # Set S104 register
    "ATS105=2",  # Set S105 register
    "ATS102=5",  # Set S102 register
    "ATS113=2",  # Set S113 register
    "ATS103=2",  # Set S103 register
    "ATS128=1",  # Set S128 register
    "AT&W",  # Save settings
    "ATA"  # Answer call
]

# Show commands for configurating the radio and configurate the radio
test_script.set_at_command(at_commands)
test_script.configurate_radio()
```

This phase:
1. Configures the power supply (5V, 4A)
2. Defines the AT command sequence for radio configuration
3. Applies the configuration to the radio
4. Logs each command and its response

### 3.3 Power Cycling and Camera Synchronization

In the advanced scripts:
```python
power_comntroller.enable_output(False)
test_script.waitForCameraSignal()
power_comntroller.enable_output(True)
```

This phase:
1. Disables power to the radio
2. Waits for a synchronization signal from the camera
3. Re-enables power to the radio
4. Ensures test conditions are properly documented with camera evidence

In all scripts, additional power cycling occurs:
```python
time.sleep(2)
power_comntroller.enable_output(False)
time.sleep(2)
power_comntroller.enable_output(True)
time.sleep(2)
```

### 3.4 Test Execution Phase

```python
def start_test(self):
    end_test_time = time.time() + self.duration
    while time.time() < end_test_time:
        try:
            # Configure serial connection for both reading and writing ports
            with serial.Serial(self.COM_port1, self.speed, timeout=1) as ser:
                # Create telemetry packet
                telemetry_packet = self.create_telemetry_packet()

                # Write telemetry packet to serial port
                timestamp_sent = datetime.datetime.now()
                ser.write(telemetry_packet)

                # Read telemetry packet from serial port
                received_packet = bytearray()
                end_time = time.time() + self.delay
                while time.time() < end_time:
                    received_packet += ser.read(ser.in_waiting)
                    timestamp_received = datetime.datetime.now()
                    if len(received_packet) >= len(telemetry_packet):
                        break

                sended_message = self.diverse_comms.parseTelemetry(telemetry_packet)
                received_message = self.diverse_comms.parseTelemetry(received_packet)

                self.write_log_and_console(f"{timestamp_sent},sent,{sended_message}")
                # Check if received packet matches sent packet by comparing CRC
                if self.compare_crc(telemetry_packet, received_packet):
                    self.write_log_and_console(
                        f"{timestamp_received},received,{received_message},PASS,{self.power_controller.get_output_current()}")
                else:
                    self.write_log_and_console(
                        f"{timestamp_received},received,{received_message},FAIL,{self.power_controller.get_output_current()}")
                    self.failure_counter += 1

        except serial.SerialException as e:
            message = f"Serial connection error: {e}"
            self.write_log_and_console(message)
            self.failure_counter += 1

    # Test completion reporting
    if self.failure_counter != 0:
        self.write_log_and_console("Test: FAIL")
    else:
        self.write_log_and_console("Test: PASS")
```

This phase:
1. Runs for the specified test duration
2. Creates and sends telemetry packets to the radio
3. Reads back the received packets
4. Validates packet integrity using CRC comparison
5. Logs success or failure for each packet exchange
6. Tracks the current drawn during each test step
7. Increments failure counter for any failed exchanges
8. Reports overall test pass/fail status at completion

### 3.5 Test Completion Phase

```python
# Desactivate the power supply
power_comntroller.enable_output(False)
```

This phase:
1. Disables power to the radio
2. Completes the test execution
3. Leaves the system in a safe state

## 4. AT Command Sequence for Radio Configuration

The scripts use a consistent AT command sequence to configure the 900MHz radios:

```python
at_commands = [
    "+++",          # Enter command mode (special handling with 0.5s delays between characters)
    "AT&F2",        # Factory reset to default configuration
    "ATS108=21",    # Set S108 register (RF data rate/modulation)
    "ATS104=1000",  # Set S104 register (network ID)
    "ATS105=2",     # Set S105 register (RF packet size)
    "ATS102=5",     # Set S102 register (RF output power)
    "ATS113=2",     # Set S113 register (RF channel/frequency)
    "ATS103=2",     # Set S103 register (RF protocol options)
    "ATS128=1",     # Set S128 register (serial interface options)
    "AT&W",         # Write settings to non-volatile memory
    "ATA"           # Answer/establish connection
]
```

The `send_at_command` method handles the special requirements for sending these commands:

```python
def send_at_command(self, COM_port, command, delay=0.5):
    try:
        with serial.Serial(COM_port, self.speed, timeout=1) as ser:
            if command == "+++":
                # Special handling for command mode entry
                for element in command:
                    ser.write(element.encode())
                    time.sleep(0.5)
                time.sleep(delay)
                response = ser.read(ser.in_waiting or 1)
            else:
                # Normal AT command handling
                ser.write((command + "\r").encode())  # Append carriage return
                time.sleep(delay)
                response = ser.read(ser.in_waiting or 1)
            
            # Log command and response
            self.write_log_and_console(f"Command: {command} -> Response: {response.decode().strip()}")

    except serial.SerialException as e:
        self.write_log_and_console(f"Serial connection error while sending AT command: {e}")
```

This method:
1. Handles the special case of "+++" command mode entry with character-by-character transmission
2. Appends carriage returns to standard AT commands
3. Waits for and captures command responses
4. Logs both commands and responses
5. Handles serial communication exceptions

## 5. Error Handling and Test Validation Methods

The scripts implement several error handling and validation mechanisms:

### 5.1 CRC Validation

```python
def compare_crc(self, sent_packet, received_packet):
    sent_crc = sent_packet[-2:]
    received_crc = received_packet[-2:]
    return sent_crc == received_crc
```

This method:
1. Extracts the CRC values from sent and received packets (last 2 bytes)
2. Compares them to validate packet integrity
3. Returns a boolean indicating match/mismatch

### 5.2 Serial Exception Handling

```python
try:
    # Serial communication code
except serial.SerialException as e:
    message = f"Serial connection error: {e}"
    self.write_log_and_console(message)
    self.failure_counter += 1
```

This pattern:
1. Catches serial communication exceptions
2. Logs the error details
3. Increments the failure counter
4. Allows the test to continue despite communication errors

### 5.3 Camera Signal Validation

```python
def waitForCameraSignal(self):
    signalRecived = False
    with serial.Serial(self.COM_port3, self.speed, timeout=1) as ser:
        while signalRecived == False:
            mensaje = "signal"
            ser.write(mensaje.encode('utf-8'))
            time.sleep(1)
            try:
                recibido = ser.read(len(mensaje)).decode('utf-8')
            except:
                recibido = None
            if recibido == mensaje:
                signalRecived = True
```

This method:
1. Implements a simple handshake protocol with the camera
2. Handles potential decoding exceptions
3. Continues until valid confirmation is received
4. Ensures test synchronization with camera operation

### 5.4 Test Pass/Fail Determination

```python
if self.failure_counter != 0:
    self.write_log_and_console("Test: FAIL")
else:
    self.write_log_and_console("Test: PASS")
```

This logic:
1. Uses a zero-tolerance approach to failures
2. Any communication error or CRC mismatch fails the test
3. Provides clear pass/fail status in the log

## 6. Integration with Test Dependencies

The scripts leverage two key dependency libraries:

### 6.1 Power Supply Control (`libraryDP700.py`)

```python
from dependencies.libraryDP700 import *

# In main():
power_comntroller = PowerSupply(port="COM10")
power_comntroller.set_output_voltage(5)
power_comntroller.set_output_current(4)
power_comntroller.enable_output(True)
```

The scripts use the PowerSupply class to:
1. Establish connection to the Rigol DP700 series power supply
2. Configure voltage (5V) and current (4A) limits
3. Control power cycling during the test
4. Monitor current draw during packet transmission/reception
5. Ensure safe power state at test completion

### 6.2 Communication Protocol (`diverseCommsFormatParserV0.py`)

```python
from dependencies.diverseCommsFormatParserV0 import diverseComms

# In __init__:
self.diverse_comms = diverseComms()

# In create_telemetry_packet:
return self.diverse_comms.makeTelemetry(int(time.time()), "178650100F", 20.727413983250234,
                                        -156.10488400389238, 400.15, 27.2153185, 1, 0, False, 0.823562)

# In start_test:
sended_message = self.diverse_comms.parseTelemetry(telemetry_packet)
received_message = self.diverse_comms.parseTelemetry(received_packet)
```

The scripts use the diverseComms class to:
1. Create standardized binary telemetry packets
2. Parse received binary packets into human-readable format
3. Generate consistent test data with timestamps, position, and status information
4. Support the CRC validation mechanism

## 7. Differences Between Test Variants

### 7.1 Basic vs. Advanced Basic

1. **Camera Integration**:
   - Original Basic: No camera integration
   - Advanced Basic: Added COM_camera parameter and waitForCameraSignal() method

2. **Timestamp Logging**:
   - Original Basic: Simple logging without timestamps
   - Advanced Basic: Each log entry includes datetime.datetime.now()

3. **Test Flow**:
   - Original Basic: Direct radio configuration and power cycling
   - Advanced Basic: Adds camera synchronization step between configuration and testing

### 7.2 Environmental Test Variants (High/Low Temperature)

The High Temperature and Low Temperature test scripts are identical to the Advanced Basic script in terms of code structure and functionality. The key differences are:

1. **File Organization**:
   - Scripts are organized in separate directories (High Temperature/Low Temperature)
   - This suggests they are intended to be run in different environmental chambers

2. **Intended Test Environment**:
   - High Temperature: Likely run in a high-temperature chamber (possibly 70-85°C)
   - Low Temperature: Likely run in a low-temperature chamber (possibly -40 to -20°C)

3. **Test Purpose**:
   - The scripts test the same radio functionality but under different environmental stresses
   - The camera integration suggests visual documentation of the test setup in these environments

## 8. Common Test Parameters Across All Variants

All script variants share these common test parameters:

1. **Communication Settings**:
   - Serial speed: 19200 baud
   - Radio port: COM12
   - Power supply port: COM10
   - Camera port (when applicable): COM11

2. **Power Supply Configuration**:
   - Output voltage: 5V
   - Output current: 4A

3. **Radio Configuration**:
   - Identical AT command sequence across all variants
   - Same register settings for RF parameters

4. **Test Duration**:
   - Default test duration: 5 seconds (configurable)

5. **Telemetry Data**:
   - Same test telemetry packet structure and content
   - Fixed test coordinates and parameters

## Referenced Context Files

The following context files provided useful information for understanding the test scripts:

- `Amazon-PrimeAir/items/Diverse_Comms/03_Test_Dependencies.md` - This file provided detailed information about the `libraryDP700.py` and `diverseCommsFormatParserV0.py` dependencies, explaining their functionality, interfaces, and how they support the test scripts through power supply control and binary communication protocol handling.