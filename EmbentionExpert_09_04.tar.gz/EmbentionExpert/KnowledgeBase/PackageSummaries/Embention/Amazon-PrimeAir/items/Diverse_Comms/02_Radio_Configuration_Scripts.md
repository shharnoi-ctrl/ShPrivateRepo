# Generated from:

- artifacts/P401-ENC config/900MHzRadioMaster.py (563 tokens)
- artifacts/P401-ENC config/400MHzRadioMaster.py (563 tokens)
- artifacts/P401-ENC config/896MHzRadioMaster.py (563 tokens)

---

# Radio Configuration Scripts Analysis

This document provides a comprehensive analysis of three radio configuration scripts for different frequency bands (900MHz, 400MHz, and 896MHz). These scripts are designed to configure radio devices through serial communication using AT commands.

## 1. Common Structure and Functionality

All three scripts (`900MHzRadioMaster.py`, `400MHzRadioMaster.py`, and `896MHzRadioMaster.py`) share an identical structure and core functionality:

### 1.1 Import Statements and Initial Output

```python
import serial
import time

print("--Diverse Comms programming...--")
```

All scripts begin by importing the necessary libraries (`serial` for serial communication and `time` for delays) and displaying an initial message indicating the start of the programming process.

### 1.2 AT Command Handling Function

```python
def send_at_command(ser, command, delay=0.1):
    """
    Send an AT command to the serial port and wait for the specified delay.

    :param ser: The serial port object
    :param command: The AT command to send
    :param delay: Time to wait after sending the command (in seconds)
    """
    if command == "+++":
        for element in command:
            ser.write(element.encode())
            time.sleep(0.5)
        time.sleep(2)
        response = ser.read(ser.in_waiting or 1)
        print(f"Command: {command} -> Response: {response.decode().strip()}")  # Print response
    else:
        ser.write((command + "\r").encode())  # Append carriage return and encode to bytes
        time.sleep(delay)  # Wait for the specified delay
        response = ser.read(ser.in_waiting or 1)  # Read available response
        print(f"Command: {command} -> Response: {response.decode().strip()}")  # Print response
```

This function handles sending AT commands to the radio device with special handling for the `+++` command:

- For the `+++` command (used to enter command mode):
  - Each character is sent individually with a 0.5-second delay between characters
  - After sending all characters, it waits for 2 seconds
  - This special handling is necessary because the `+++` command requires specific timing to be recognized

- For all other commands:
  - Appends a carriage return (`\r`) to the command
  - Encodes the command to bytes
  - Waits for the specified delay after sending
  - Reads any available response

- For all commands:
  - Prints both the command sent and the response received

### 1.3 Two-Phase Configuration Process

All scripts implement a two-phase configuration process:

#### Phase 1: Initial Configuration at 9600 baud
```python
# Delay read s
delay = 2

# Configure communication speed
speed = 9600

# Use your COM ports
COM_port1 = "COM12"

# Modem config
ser = serial.Serial(COM_port1, speed, timeout=1)

at_commands_init = [
    "+++",  # Enter command mode
    "AT&F1",  # Factory reset
    "ATS102=5",  # Set S102 register
    "AT&W",  # Save settings
    "ATA"  # Answer call
]

# Send each AT command
for command in at_commands_init:
    send_at_command(ser, command, delay)
ser.close()
```

This phase:
1. Sets up serial communication at 9600 baud
2. Enters command mode with `+++`
3. Performs a factory reset with `AT&F1`
4. Sets the S102 register to 5
5. Saves settings with `AT&W`
6. Exits command mode with `ATA`
7. Closes the serial connection

#### Phase 2: Main Configuration at 19200 baud
```python
# Configure communication speed
speed = 19200

# Use your COM ports
COM_port1 = "COM12"

# Modem config
ser = serial.Serial(COM_port1, speed, timeout=1)

# List of AT commands to send
at_commands = [
    "+++",  # Enter command mode
    "AT&F1",  # Factory reset
    "ATS108=21",  # Set S108 register
    "ATS104=1000",  # Set S104 register
    "ATS105=1",  # Set S105 register
    "ATS102=5",  # Set S102 register
    "ATS113=2",  # Set S113 register
    "ATS103=2",  # Set S103 register
    "ATS128=X",  # Set S128 register (X varies by script)
    "AT&W",  # Save settings
    "ATA"  # Answer call
]

# Send each AT command
for command in at_commands:
    send_at_command(ser, command, delay)

print("--Diverse Comms Successfully Programed--")

time.sleep(5)  # Sleep for 5 seconds

# Close the serial port
ser.close()
```

This phase:
1. Reopens the serial connection at a higher baud rate (19200)
2. Enters command mode with `+++`
3. Performs another factory reset with `AT&F1`
4. Sets multiple S-registers (S108, S104, S105, S102, S113, S103, S128)
5. Saves settings with `AT&W`
6. Exits command mode with `ATA`
7. Displays a success message
8. Waits for 5 seconds
9. Closes the serial connection

### 1.4 Common Configuration Parameters

All scripts use identical values for most S-registers:

| Register | Value | Present in All Scripts |
|----------|-------|------------------------|
| S102     | 5     | Yes                    |
| S108     | 21    | Yes                    |
| S104     | 1000  | Yes                    |
| S105     | 1     | Yes                    |
| S113     | 2     | Yes                    |
| S103     | 2     | Yes                    |

### 1.5 Serial Port Configuration

All scripts use:
- COM port: COM12
- Initial baud rate: 9600
- Secondary baud rate: 19200
- Timeout: 1 second

## 2. Specific Differences Between Scripts

The **only difference** between the three scripts is the value assigned to the S128 register in the second phase of configuration:

| Script File             | S128 Value |
|-------------------------|------------|
| 900MHzRadioMaster.py    | 1          |
| 400MHzRadioMaster.py    | 2          |
| 896MHzRadioMaster.py    | 4          |

This register appears to be the key parameter that determines the frequency band at which the radio operates:
- Value 1: 900MHz band
- Value 2: 400MHz band
- Value 4: 896MHz band

## 3. AT Command Structure and Special Handling

### 3.1 AT Command Types Used

The scripts use several types of AT commands:

| Command | Purpose | Usage |
|---------|---------|-------|
| `+++`   | Enter command mode | Special timing-sensitive command that requires character-by-character transmission with delays |
| `AT&F1` | Factory reset | Resets the radio to factory defaults |
| `ATSxxx=y` | Set S-register | Sets register number xxx to value y |
| `AT&W`  | Write settings | Saves the current settings to non-volatile memory |
| `ATA`   | Answer call | Exits command mode and returns to data mode |

### 3.2 Special Handling for `+++` Command

The `+++` command requires special handling due to its timing-sensitive nature:

```python
if command == "+++":
    for element in command:
        ser.write(element.encode())
        time.sleep(0.5)
    time.sleep(2)
    response = ser.read(ser.in_waiting or 1)
    print(f"Command: {command} -> Response: {response.decode().strip()}")
```

This implementation:
1. Sends each `+` character individually
2. Waits 0.5 seconds between each character
3. Waits an additional 2 seconds after sending all three characters
4. Reads and prints the response

This special handling is necessary because the Hayes command set (which AT commands are based on) requires specific timing for the `+++` escape sequence to be recognized as a command rather than data.

### 3.3 Standard AT Command Handling

All other AT commands are handled with a simpler approach:

```python
else:
    ser.write((command + "\r").encode())  # Append carriage return and encode to bytes
    time.sleep(delay)  # Wait for the specified delay
    response = ser.read(ser.in_waiting or 1)  # Read available response
    print(f"Command: {command} -> Response: {response.decode().strip()}")
```

This implementation:
1. Appends a carriage return (`\r`) to the command
2. Encodes the command to bytes
3. Sends the command
4. Waits for the specified delay (default 0.1 seconds, but scripts use 2 seconds)
5. Reads any available response
6. Prints both the command and response

## 4. Two-Phase Configuration Process Details

### 4.1 Phase 1: Initial Setup at 9600 baud

```python
at_commands_init = [
    "+++",  # Enter command mode
    "AT&F1",  # Factory reset
    "ATS102=5",  # Set S102 register
    "AT&W",  # Save settings
    "ATA"  # Answer call
]
```

This initial phase appears to be a minimal setup that:
1. Enters command mode
2. Resets the radio to factory defaults
3. Sets only one register (S102=5)
4. Saves this configuration
5. Returns to data mode

The purpose of this phase seems to be to establish a known baseline configuration before proceeding to the more detailed configuration in phase 2.

### 4.2 Phase 2: Main Configuration at 19200 baud

```python
at_commands = [
    "+++",  # Enter command mode
    "AT&F1",  # Factory reset
    "ATS108=21",  # Set S108 register
    "ATS104=1000",  # Set S104 register
    "ATS105=1",  # Set S105 register
    "ATS102=5",  # Set S102 register
    "ATS113=2",  # Set S113 register
    "ATS103=2",  # Set S103 register
    "ATS128=X",  # Set S128 register (X varies by script)
    "AT&W",  # Save settings
    "ATA"  # Answer call
]
```

This main configuration phase:
1. Operates at a higher baud rate (19200)
2. Performs another factory reset
3. Sets multiple S-registers that control various aspects of the radio's operation
4. Sets the frequency-specific S128 register
5. Saves the complete configuration
6. Returns to data mode

## 5. S-Register Configuration Analysis

The scripts configure several S-registers that control different aspects of the radio's operation:

| Register | Value | Likely Purpose |
|----------|-------|----------------|
| S102     | 5     | Communication parameters (set in both phases) |
| S108     | 21    | Power or transmission parameters |
| S104     | 1000  | Timing or buffer size parameter |
| S105     | 1     | Mode or feature enablement |
| S113     | 2     | Protocol or interface setting |
| S103     | 2     | Communication parameters |
| S128     | 1/2/4 | Frequency band selection (varies by script) |

The S128 register is the key differentiator between the scripts and appears to control the frequency band:
- S128=1: 900MHz band (900MHzRadioMaster.py)
- S128=2: 400MHz band (400MHzRadioMaster.py)
- S128=4: 896MHz band (896MHzRadioMaster.py)

## 6. Integration with Testing Framework

While the scripts don't explicitly reference a broader testing framework, several aspects suggest how they might integrate with one:

### 6.1 Standalone Operation

The scripts are designed to operate independently, with no external dependencies beyond the Python standard library and the `serial` module. This suggests they could be:
- Called directly from a test harness
- Executed as part of a test sequence
- Used for initial setup before other tests run

### 6.2 Consistent Port Configuration

All scripts use the same COM port (COM12), suggesting:
- A test setup where radios are connected to a consistent port
- A system where the port might be programmatically assigned or configured
- A test environment where different radios are swapped on the same port

### 6.3 Verbose Output

The scripts print detailed information about each command and response:
```python
print(f"Command: {command} -> Response: {response.decode().strip()}")
```

This verbose output would be useful for:
- Test logging
- Debugging configuration issues
- Verification of proper radio response
- Integration with a test reporting system

### 6.4 Success Indication

Each script ends with a success message:
```python
print("--Diverse Comms Successfully Programed--")
```

This could be used by a test framework to:
- Verify successful completion
- Log test results
- Trigger subsequent test steps

### 6.5 Consistent Structure

The identical structure of all three scripts suggests they might be:
- Generated from a template
- Part of a larger suite of similar configuration scripts
- Designed to be easily modified for additional radio types or frequencies

## 7. File-by-File Breakdown

### 7.1 900MHzRadioMaster.py

**Purpose**: Configure a radio device to operate in the 900MHz frequency band.

**Key Components**:
- `send_at_command()` function for AT command handling
- Two-phase configuration process (9600 baud → 19200 baud)
- Sets S128=1 to select the 900MHz band

**Workflow**:
1. Initial setup at 9600 baud with minimal configuration
2. Main configuration at 19200 baud with complete parameter set
3. Specific frequency selection via S128=1

### 7.2 400MHzRadioMaster.py

**Purpose**: Configure a radio device to operate in the 400MHz frequency band.

**Key Components**:
- Identical structure to 900MHzRadioMaster.py
- Sets S128=2 to select the 400MHz band

**Workflow**:
1. Initial setup at 9600 baud with minimal configuration
2. Main configuration at 19200 baud with complete parameter set
3. Specific frequency selection via S128=2

### 7.3 896MHzRadioMaster.py

**Purpose**: Configure a radio device to operate in the 896MHz frequency band.

**Key Components**:
- Identical structure to other scripts
- Sets S128=4 to select the 896MHz band

**Workflow**:
1. Initial setup at 9600 baud with minimal configuration
2. Main configuration at 19200 baud with complete parameter set
3. Specific frequency selection via S128=4

## 8. Detailed Command Sequence Analysis

### 8.1 Initial Configuration Sequence (9600 baud)

| Command | Purpose | Effect |
|---------|---------|--------|
| `+++` | Enter command mode | Switches radio from data mode to command mode |
| `AT&F1` | Factory reset | Resets all settings to factory defaults |
| `ATS102=5` | Set S102 register | Configures communication parameter (possibly baud rate or format) |
| `AT&W` | Write settings | Saves settings to non-volatile memory |
| `ATA` | Answer call | Exits command mode, returns to data mode |

### 8.2 Main Configuration Sequence (19200 baud)

| Command | Purpose | Effect |
|---------|---------|--------|
| `+++` | Enter command mode | Switches radio from data mode to command mode |
| `AT&F1` | Factory reset | Resets all settings to factory defaults |
| `ATS108=21` | Set S108 register | Configures power or transmission parameter |
| `ATS104=1000` | Set S104 register | Sets timing or buffer size parameter |
| `ATS105=1` | Set S105 register | Enables specific mode or feature |
| `ATS102=5` | Set S102 register | Configures communication parameter (same as in phase 1) |
| `ATS113=2` | Set S113 register | Sets protocol or interface parameter |
| `ATS103=2` | Set S103 register | Configures additional communication parameter |
| `ATS128=X` | Set S128 register | Selects frequency band (1=900MHz, 2=400MHz, 4=896MHz) |
| `AT&W` | Write settings | Saves all settings to non-volatile memory |
| `ATA` | Answer call | Exits command mode, returns to data mode |

## 9. Technical Implementation Details

### 9.1 Serial Communication Parameters

```python
ser = serial.Serial(COM_port1, speed, timeout=1)
```

- Port: COM12 (Windows COM port designation)
- Speed: 9600 baud (initial) / 19200 baud (main configuration)
- Timeout: 1 second (for read operations)
- No explicit parity, stop bits, or flow control (using defaults)

### 9.2 Command Timing

```python
# Delay read s
delay = 2
```

- Standard delay between commands: 2 seconds
- Special timing for `+++` command:
  - 0.5 seconds between each character
  - 2 seconds after sending all characters

### 9.3 Response Handling

```python
response = ser.read(ser.in_waiting or 1)
print(f"Command: {command} -> Response: {response.decode().strip()}")
```

- Reads all available bytes from the serial buffer
- Falls back to reading at least 1 byte if buffer is empty
- Decodes response from bytes to string
- Strips whitespace from response
- Prints both command and response

### 9.4 Error Handling

The scripts do not implement explicit error handling for:
- Failed commands
- Missing responses
- Serial port errors
- Unexpected responses

This suggests they are designed for use in a controlled environment where errors are unlikely or are handled by a parent process.

## 10. Conclusion

These three scripts provide a comprehensive system for configuring radio devices to operate at different frequency bands (900MHz, 400MHz, and 896MHz). They share an identical structure and differ only in the value assigned to the S128 register, which appears to control the frequency band selection.

The scripts implement a two-phase configuration process, first establishing a baseline configuration at 9600 baud and then applying a more detailed configuration at 19200 baud. They handle AT commands with appropriate timing considerations, especially for the timing-sensitive `+++` command used to enter command mode.

The consistent structure and verbose output suggest these scripts are designed to be part of a larger testing or configuration framework, where they might be used to prepare radio devices for subsequent testing or operation.