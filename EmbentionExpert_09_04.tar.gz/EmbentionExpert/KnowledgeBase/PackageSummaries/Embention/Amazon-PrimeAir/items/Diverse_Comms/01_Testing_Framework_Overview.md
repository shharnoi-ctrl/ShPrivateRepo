# Generated from:

- Amazon-PrimeAir/items/Diverse_Comms/02_Radio_Configuration_Scripts.md (4239 tokens)
- Amazon-PrimeAir/items/Diverse_Comms/03_Test_Dependencies.md (5021 tokens)
- Amazon-PrimeAir/items/Diverse_Comms/02_Environmental_Test_Scripts.md (5070 tokens)
- Amazon-PrimeAir/items/Diverse_Comms/02_Final_and_RF_Test_Scripts.md (5783 tokens)

---

# Comprehensive Radio Testing Framework Overview

This document provides a unified understanding of the radio testing framework based on the analysis of multiple components including configuration scripts, test dependencies, environmental test scripts, and final validation scripts.

## 1. Overall Testing Workflow Architecture

The radio testing framework implements a comprehensive validation pipeline that progresses through several distinct phases:

### 1.1 Testing Workflow Progression

1. **Initial Radio Configuration**
   - Configures radios for specific frequency bands (900MHz, 400MHz, 896MHz)
   - Uses AT command sequences to set operating parameters
   - Establishes baseline functionality before testing

2. **Environmental Testing**
   - Tests radio functionality under various environmental conditions
   - Includes high temperature, low temperature, and basic ambient testing
   - Validates telemetry transmission/reception with power cycling

3. **RF Power Measurement**
   - Measures RF output power using spectrum analyzer
   - Validates power meets minimum threshold requirements (25 dBm)
   - Ensures transmitter hardware is functioning correctly

4. **Final Functional Validation**
   - Performs comprehensive telemetry protocol validation
   - Validates data integrity through CRC checking
   - Confirms end-to-end system functionality

### 1.2 Shared Infrastructure Components

The testing framework relies on several core dependencies that provide consistent functionality across all test phases:

1. **Power Supply Control (libraryDP700.py)**
   - Provides programmatic control of Rigol DP700 series power supplies
   - Enables precise voltage/current control and monitoring
   - Supports power cycling for reset and recovery testing

2. **Communication Protocol (diverseCommsFormatParserV0.py)**
   - Implements binary protocol for telemetry, commands, and timing
   - Handles packet creation, parsing, and CRC validation
   - Supports multiple packet types with different payloads

3. **AT Command Interface**
   - Consistent mechanism for radio configuration across all scripts
   - Special handling for timing-sensitive commands (e.g., "+++")
   - Standardized command sequences for different radio types

4. **Logging and Reporting**
   - Comprehensive logging of commands, responses, and test results
   - Timestamped entries for test sequence reconstruction
   - Pass/fail determination based on validation criteria

## 2. Radio Configuration System

### 2.1 Configuration Methodology

The radio configuration scripts implement a two-phase configuration process:

1. **Initial Configuration (9600 baud)**
   - Enters command mode with "+++" (special timing)
   - Performs factory reset with AT&F1
   - Sets minimal parameters (S102=5)
   - Saves settings and exits command mode

2. **Main Configuration (19200 baud)**
   - Re-enters command mode
   - Performs another factory reset
   - Configures multiple S-registers for detailed operation
   - Sets frequency-specific parameters (S128)
   - Saves final configuration

### 2.2 Frequency Band Selection

The framework supports multiple frequency bands through the S128 register:

| S128 Value | Frequency Band | Script File |
|------------|---------------|-------------|
| 1 | 900MHz | 900MHzRadioMaster.py |
| 2 | 400MHz | 400MHzRadioMaster.py |
| 4 | 896MHz | 896MHzRadioMaster.py |

### 2.3 Common Radio Parameters

All radio configurations share these common parameters:

| Register | Value | Purpose |
|----------|-------|---------|
| S102 | 5 | RF output power |
| S108 | 21 | RF data rate/modulation |
| S104 | 1000 | Network ID |
| S105 | 1 or 2 | RF packet size (varies by test) |
| S113 | 2 | RF channel/frequency |
| S103 | 2 | RF protocol options |

## 3. Core Dependencies and Their Integration

### 3.1 Power Supply Control (libraryDP700.py)

The PowerSupply class provides a comprehensive interface for controlling Rigol DP700 series power supplies:

```python
# Initialization
power_controller = PowerSupply(port="COM10")

# Configuration
power_controller.set_output_voltage(5)
power_controller.set_output_current(4)

# Output control
power_controller.enable_output(True)  # Turn on
power_controller.enable_output(False) # Turn off

# Measurement
current = power_controller.get_output_current()
```

Key capabilities:
- Voltage and current setting with safety limits
- Output enable/disable for power cycling
- Current measurement during test execution
- Context management for safe resource handling

### 3.2 Communication Protocol (diverseCommsFormatParserV0.py)

The diverseComms class implements a binary protocol for various packet types:

```python
# Initialization
diverse_comms = diverseComms()

# Telemetry creation
telemetry_packet = diverse_comms.makeTelemetry(
    timestamp, serial_number, latitude, longitude, 
    altitude, ground_speed, phase_of_flight, 
    contingency, on_recovery, state_of_charge
)

# Packet parsing
parsed_data = diverse_comms.parseTelemetry(received_packet)

# CRC validation
is_valid = diverse_comms.compare_crc(sent_packet, received_packet)
```

Key capabilities:
- Multiple packet types (telemetry, idle, command, timing)
- Binary packing/unpacking with struct module
- CRC-16 validation for data integrity
- Comprehensive data formatting and scaling

### 3.3 Integration Between Components

The testing framework integrates these dependencies to create a complete test-and-measure system:

1. **Power Supply + Radio Configuration**
   - Power supply provides stable power during configuration
   - AT commands configure radio parameters
   - Power cycling resets radio between test phases

2. **Power Supply + Telemetry Testing**
   - Power supply enables current monitoring during transmission
   - Current measurements help identify abnormal power consumption
   - Power cycling tests radio recovery capabilities

3. **diverseComms + Test Validation**
   - Protocol parser creates standardized test packets
   - CRC validation ensures data integrity
   - Parsed telemetry provides human-readable test results

## 4. Environmental Testing Framework

### 4.1 Test Class Architecture

The `environmental_test_script_for_PA` class provides a reusable framework for environmental testing:

```python
test_script = environmental_test_script_for_PA(
    speed=19200, 
    COM_radio_port="COM12", 
    COM_power_supply="COM10",
    delay=0.5, 
    failure_counter=0, 
    max_fauilure_count=50,
    log_path=f"{id_radio_scanned}.txt",
    power_controller=power_controller, 
    COM_camera="COM11"  # Optional in advanced versions
)
```

Key components:
- Serial communication configuration
- Test parameters and failure tracking
- Logging infrastructure
- Power supply integration
- Optional camera integration

### 4.2 Test Execution Flow

All environmental tests follow a consistent execution flow:

1. **Initialization**
   - Set up power supply and test parameters
   - Configure logging with radio serial number
   - Initialize failure counters

2. **Radio Configuration**
   - Configure radio with AT commands
   - Verify command responses
   - Log configuration details

3. **Power Cycling**
   - Turn power off/on to reset radio
   - In advanced versions, synchronize with camera
   - Ensure stable power before testing

4. **Telemetry Testing**
   - Create and send telemetry packets
   - Receive and validate responses
   - Track success/failure based on CRC validation

5. **Result Reporting**
   - Log detailed test results
   - Report overall pass/fail status
   - Disable power supply when complete

### 4.3 Environmental Test Variants

The framework supports multiple environmental test scenarios:

1. **Basic Testing**
   - Ambient temperature conditions
   - Standard telemetry validation

2. **High Temperature Testing**
   - Elevated temperature environment
   - Camera integration for visual documentation
   - Same test methodology as basic testing

3. **Low Temperature Testing**
   - Reduced temperature environment
   - Camera integration for visual documentation
   - Same test methodology as basic testing

All variants use identical code structure but are organized in separate directories for different test environments.

## 5. RF Power Measurement System

### 5.1 Measurement Methodology

The RF power measurement script implements a specialized test flow:

1. **Radio Configuration**
   - Two-phase configuration (9600 → 19200 baud)
   - Specific settings for continuous transmission

2. **Spectrum Analyzer Setup**
   - Center frequency: 922.84 MHz
   - Span: 2 MHz
   - Integration bandwidth: 280 kHz
   - Trace mode: MAX Hold

3. **Power Measurement**
   - Channel power measurement
   - Power density measurement
   - 5-second stabilization period

4. **Validation**
   - Threshold comparison (25 dBm minimum)
   - Pass/fail determination
   - Result logging

### 5.2 Integration with PyVISA

The script uses PyVISA to communicate with the spectrum analyzer:

```python
instr = pyvisa.ResourceManager().open_resource('TCPIP::192.168.0.94::INSTR')
instr.write(':FREQuency:CENTer 922.84 MHz')
instr.write(':INSTrument:MEASure CHPower')
CHpower = instr.query_ascii_values(':MEASure:CHPower:CHPower?')
```

This enables:
- Remote instrument control
- Automated measurement configuration
- Programmatic result retrieval
- Integration with the testing framework

## 6. Final Validation Testing

### 6.1 Comprehensive Validation Approach

The final test script implements a thorough validation methodology:

1. **Radio Configuration**
   - Configures radio with operational parameters
   - Verifies command responses
   - Prepares for telemetry testing

2. **Telemetry Validation**
   - Creates telemetry packets with test data
   - Sends packets and captures responses
   - Validates data integrity via CRC
   - Monitors current consumption

3. **Pass/Fail Criteria**
   - Zero-tolerance approach to failures
   - Any CRC mismatch fails the test
   - Any communication error fails the test

### 6.2 Test Data and Parameters

The final test uses standardized test data:

```python
telemetry_packet = self.diverse_comms.makeTelemetry(
    int(time.time()),       # Current timestamp
    "178650100F",           # Serial number
    20.727413983250234,     # Latitude
    -156.10488400389238,    # Longitude
    400.15,                 # Altitude
    27.2153185,             # Ground speed
    1,                      # Phase of flight
    0,                      # Contingency
    False,                  # On recovery
    0.823562                # State of charge
)
```

This ensures:
- Consistent test conditions
- Reproducible results
- Comprehensive protocol testing

## 7. Common Patterns and Shared Infrastructure

### 7.1 AT Command Handling

All scripts implement consistent AT command handling:

```python
def send_at_command(self, COM_port, command, delay=0.5):
    try:
        with serial.Serial(COM_port, self.speed, timeout=1) as ser:
            if command == "+++":
                # Special handling for command mode entry
                for element in command:
                    ser.write(element.encode())
                    time.sleep(0.5)
                time.sleep(delay)
                response = ser.read(ser.in_waiting or 1)
            else:
                # Normal AT command handling
                ser.write((command + "\r").encode())
                time.sleep(delay)
                response = ser.read(ser.in_waiting or 1)
            
            # Log command and response
            self.write_log_and_console(f"Command: {command} -> Response: {response.decode().strip()}")
    except serial.SerialException as e:
        self.write_log_and_console(f"Serial connection error while sending AT command: {e}")
```

This pattern ensures:
- Proper timing for command mode entry
- Consistent command formatting
- Response capture and logging
- Error handling for communication issues

### 7.2 Logging Infrastructure

All scripts implement a consistent logging approach:

```python
def write_log_and_console(self, message):
    print(message)
    cwd = os.getcwd()
    with open(f"{cwd}\\logs\\{self.log_path}", "a") as log_file:
        log_file.write(message + "\n")
```

This provides:
- Dual output (console and file)
- Persistent test records
- Consistent formatting
- Centralized logging mechanism

### 7.3 Power Supply Configuration

All scripts use consistent power supply settings:

```python
power_controller.set_output_voltage(5)  # 5V output
power_controller.set_output_current(4)  # 4A current limit
power_controller.enable_output(True)    # Enable output
```

This ensures:
- Consistent power conditions across tests
- Safe operating parameters for the radio
- Sufficient current headroom for transmission

### 7.4 Serial Communication Parameters

All scripts use standardized serial parameters:

- Radio port: COM12
- Power supply port: COM10
- Camera port (when applicable): COM11
- Baud rate: 19200 (after initial configuration)
- Timeout: 1 second

## 8. Key Technical Concepts

### 8.1 AT Command Configuration

The radio configuration relies on the Hayes AT command set:

- **Command Mode Entry**: The `+++` sequence with specific timing requirements
- **Factory Reset**: `AT&F1` or `AT&F2` depending on test requirements
- **Register Configuration**: `ATSxxx=y` format for various parameters
- **Settings Storage**: `AT&W` to write settings to non-volatile memory
- **Command Mode Exit**: `ATA` to return to data mode

### 8.2 Telemetry Packet Structure

The telemetry protocol implements a structured binary format:

- **Timestamp**: 8-byte unsigned integer
- **Serial Number**: 5-byte identifier
- **Position**: Latitude/longitude as 8-byte doubles
- **Altitude**: 2-byte scaled integer (×10)
- **Ground Speed**: 1-byte scaled value (×5)
- **Status Flags**: Phase of flight, contingency, recovery status
- **Battery**: 1-byte scaled value (0-255)
- **CRC-16**: 2-byte checksum for validation

### 8.3 RF Power Measurement

The RF measurement system uses channel power measurement:

- **Center Frequency**: 922.84 MHz (for 900MHz radio)
- **Integration Bandwidth**: 280 kHz
- **Measurement Types**: Channel power and power density
- **Validation Threshold**: 25 dBm minimum power output
- **Instrument Control**: SCPI commands via PyVISA

### 8.4 Environmental Test Synchronization

Advanced environmental tests implement camera synchronization:

```python
def waitForCameraSignal(self):
    signalRecived = False
    with serial.Serial(self.COM_port3, self.speed, timeout=1) as ser:
        while signalRecived == False:
            mensaje = "signal"
            ser.write(mensaje.encode('utf-8'))
            time.sleep(1)
            try:
                recibido = ser.read(len(mensaje)).decode('utf-8')
            except:
                recibido = None
            if recibido == mensaje:
                signalRecived = True
```

This ensures:
- Visual documentation of test conditions
- Synchronized test execution
- Verification of environmental chamber status

## 9. Testing System Evolution

The testing framework shows clear evolution across multiple dimensions:

### 9.1 Script Complexity Evolution

1. **Basic Configuration Scripts**
   - Simple AT command sequences
   - Minimal error handling
   - Single-purpose functionality

2. **Basic Test Scripts**
   - Class-based architecture
   - Integrated power control
   - Telemetry validation

3. **Advanced Environmental Scripts**
   - Camera integration
   - Enhanced logging with timestamps
   - Synchronized test execution

4. **Specialized Measurement Scripts**
   - Instrument control integration
   - Precise RF measurement
   - Threshold-based validation

### 9.2 Test Coverage Evolution

The framework has evolved to cover multiple test dimensions:

1. **Functional Testing**
   - Basic radio configuration
   - Command response validation
   - Protocol functionality

2. **Environmental Testing**
   - Temperature extremes
   - Power cycling resilience
   - Long-duration operation

3. **RF Performance Testing**
   - Output power measurement
   - Frequency accuracy
   - Transmission characteristics

4. **Final System Validation**
   - End-to-end functionality
   - Protocol integrity
   - Power consumption monitoring

## 10. Conclusion: A Comprehensive Radio Testing System

The radio testing framework implements a complete validation pipeline for radio devices:

1. **Configuration Phase**
   - Configures radios for specific frequency bands
   - Sets operational parameters via AT commands
   - Establishes baseline functionality

2. **Environmental Testing Phase**
   - Tests under various temperature conditions
   - Validates telemetry with power cycling
   - Documents conditions with camera integration

3. **RF Measurement Phase**
   - Validates transmitter power output
   - Ensures compliance with minimum thresholds
   - Verifies RF characteristics

4. **Final Validation Phase**
   - Confirms end-to-end functionality
   - Validates protocol integrity
   - Ensures operational readiness

The system integrates power supply control, binary protocol handling, instrument control, and comprehensive logging to provide a robust and thorough testing framework for radio devices across multiple frequency bands and environmental conditions.