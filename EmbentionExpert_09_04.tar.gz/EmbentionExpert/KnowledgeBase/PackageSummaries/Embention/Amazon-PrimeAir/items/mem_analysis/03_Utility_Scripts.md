# Generated from:

- PA/scripts/utils/pie_chart_generator.py (878 tokens)
- PA/scripts/utils/demangled_helper.py (183 tokens)

## With context from:

- PackageSummaries/Amazon-PrimeAir/items/mem_analysis/04_Memory_Analysis_Core.md (4968 tokens)

---

# Memory Analysis Utility Classes: PieChartGenerator and DemangledHelper

This document provides a detailed analysis of the utility classes that support the memory analysis system, focusing on how they create visualizations of memory usage data and extract information from demangled files.

## PieChartGenerator Class

The `PieChartGenerator` class is responsible for creating pie chart visualizations of memory usage data. It is located in `PA/scripts/utils/pie_chart_generator.py` and provides static methods for generating pie charts from pandas DataFrames.

### Core Functionality

The class provides two main static methods:

1. `plot_pie_chart_base`: The foundational method that creates a basic pie chart from a DataFrame
2. `plot_pie_chart`: A higher-level method that calls `plot_pie_chart_base` twice - once for the original data and once for data grouped by library

### Method: `plot_pie_chart_base`

```python
@staticmethod
def plot_pie_chart_base(data, title, legend_title, output_image_path):
    """
    Receives a pandas DataFrame with two columns and plots a pie chart.

    Parameters:
    data (pd.DataFrame): A DataFrame with two columns:
        - First column: Categories/Labels
        - Second column: Corresponding numerical values
    """
```

#### Input Validation
The method performs several validation checks on the input data:
- Verifies that the DataFrame has exactly two columns
- Checks that the second column contains valid numeric values
- Handles exceptions with informative error messages

#### Data Processing
The method processes the input data in the following ways:
1. Sorts the data by values in descending order
2. Extracts labels (first column) and values (second column)
3. Prioritizes "FREE" memory entries by moving them to the top of the dataset:
   ```python
   free_mem_idx = class_names[class_names.str.contains("FREE")].index
   class_names = pd.concat([class_names[free_mem_idx], class_names.drop(free_mem_idx)])
   sizes = pd.concat([sizes[free_mem_idx], sizes.drop(free_mem_idx)])
   ```

#### Label Formatting
The method creates formatted labels for the pie chart:
1. Shows indices as labels for the first `N_LABELS` entries (default is 20)
2. For "FREE" memory entries, shows both the index and the name
3. Creates labels in the format `[index]` for top entries and empty strings for others

#### Visualization Creation
The method creates the pie chart using matplotlib:
1. Creates a figure with a size of 10x8 inches
2. Generates the pie chart with percentage labels and a 90-degree start angle
3. Adds a title to the chart
4. Creates a legend with detailed information for the top entries:
   ```python
   plt.legend(
       wedges[:N_LABELS], 
       [f"[{idx}] ({size} B) {name}" for idx, name, size in
                           zip(indices[:N_LABELS], class_names[:N_LABELS], sizes[:N_LABELS])],
       title=legend_title, 
       loc="center left", 
       bbox_to_anchor=(1, 0.5), 
       prop={'family':'monospace'}
   )
   ```
5. Ensures the pie chart is circular with `plt.axis('equal')`
6. Saves the chart as a PNG file at the specified output path
7. Prints a confirmation message when the chart is successfully saved

#### Error Handling
The method catches and reports any exceptions that occur during the chart generation process:
```python
try:
    # Chart generation code
except Exception as e:
    print(f"An error occurred: {e}")
```

### Method: `plot_pie_chart`

```python
@staticmethod
def plot_pie_chart(data, title, legend_title, output_image_path):
```

This method extends `plot_pie_chart_base` by creating two visualizations:

1. **Original Data Visualization**:
   - Calls `plot_pie_chart_base` with the original data
   - Creates a standard pie chart showing all individual memory allocations

2. **Library-Grouped Visualization**:
   - Extracts the first word from each string in the first column (assumed to be library/namespace names)
   - Groups the data by these first words and sums the corresponding numeric values
   - Calls `plot_pie_chart_base` with this grouped data
   - Creates a second pie chart showing memory usage aggregated by library
   - Appends "_lib" to the output filename for this second chart

```python
# Extract the first word from the string column
data['first_word'] = data[str_col].str.split("::").str[0]

# Group by the first word and sum the corresponding numeric values
merged_df = data.groupby('first_word', as_index=False)[num_col].sum()

# Create the library-grouped visualization
PieChartGenerator.plot_pie_chart_base(merged_df, title + " LIB", legend_title, output_image_path.split(".")[0] + "_lib.png")
```

## DemangledHelper Class

The `DemangledHelper` class is a utility for extracting specific information from demangled files. It is located in `PA/scripts/utils/demangled_helper.py` and provides static methods for finding and parsing elements in demangled output files.

### Core Functionality

The class currently provides one static method:

1. `find_first_map_elem_line`: Finds the first line in a file that starts with a specified element name and extracts numeric values from it

### Method: `find_first_map_elem_line`

```python
@staticmethod
def find_first_map_elem_line(file_path, elem_name):
```

#### Purpose
This method searches through a demangled file to find the first line that starts with a specified element name, then extracts and returns numeric values from that line.

#### File Processing
The method processes the input file line by line:
1. Opens the specified file in read mode
2. Iterates through each line with line numbers (starting from 1)
3. Checks if each line (after removing leading whitespace) starts with the specified element name

#### Data Extraction
When a matching line is found, the method:
1. Splits the line into elements (assumed to be whitespace-separated)
2. Extracts four numeric values from positions 1, 2, 3, and 4
3. Converts each value from hexadecimal to decimal and multiplies by 2
4. Returns these four values as a list

```python
elems = line.split()
return [int(elems[1], 16)*2, int(elems[2], 16)*2, int(elems[3], 16)*2, int(elems[4], 16)*2]
```

#### Error Handling
The method includes comprehensive error handling:
1. If no matching line is found, it prints a message and returns `None`
2. If the file is not found, it prints a specific error message
3. For any other exceptions, it prints a generic error message with the exception details

```python
try:
    # File processing code
except FileNotFoundError:
    print(f"Error: The file '{file_path}' was not found.")
except Exception as e:
    print(f"An error occurred: {e}")
```

## Integration with the Memory Analysis System

These utility classes are used by various scripts in the memory analysis system to:

1. **Extract Memory Information**:
   - `DemangledHelper` is used to extract specific memory allocation information from demangled files
   - It helps identify memory sections, sizes, and addresses in the compiled output

2. **Generate Visualizations**:
   - `PieChartGenerator` is used by multiple scripts to create pie chart visualizations of memory usage
   - It supports the creation of both detailed and library-grouped visualizations

3. **Support the Analysis Pipeline**:
   - These utilities are called by the scripts referenced in the main memory analysis workflow:
     - `generate_pie_chart_flash_raw.py`
     - `generate_pie_chart_ram_sections.py`
     - `generate_pie_chart_ram2.py`
     - `generate_pie_chart_external_ram.py`
     - `generate_pie_chart_internal_ram_c1.py`
     - `generate_pie_chart_internal_ram_c2.py`

## API Details

### PieChartGenerator API

#### Input Requirements
- **Data Format**: Requires a pandas DataFrame with exactly two columns
  - First column: Categories/labels (strings)
  - Second column: Corresponding numerical values
- **Title**: String for the chart title
- **Legend Title**: String for the legend title
- **Output Path**: File path where the PNG image will be saved

#### Visualization Features
- **Top Entries**: Shows the top 20 entries (configurable via `N_LABELS`) in the legend
- **FREE Memory Handling**: Prioritizes and specially labels FREE memory entries
- **Percentage Labels**: Shows percentage values on pie slices
- **Detailed Legend**: Includes index, size in bytes, and name for each top entry
- **Library Grouping**: Automatically creates a second visualization grouped by library/namespace

### DemangledHelper API

#### Input Requirements
- **File Path**: Path to the demangled file to be processed
- **Element Name**: String to search for at the beginning of lines

#### Output Format
- Returns a list of four integers when a matching line is found
- Returns `None` when no matching line is found or an error occurs

#### Error Reporting
- Provides specific error messages for common issues (file not found)
- Includes exception details for unexpected errors

## Error Handling and Edge Cases

Both utility classes include robust error handling to manage various edge cases:

### PieChartGenerator Error Handling
1. **Invalid DataFrame Format**: Checks for exactly two columns and raises a ValueError if not met
2. **Missing or Invalid Numeric Values**: Validates that the second column contains valid numeric values
3. **General Exception Handling**: Catches and reports any exceptions during chart generation

### DemangledHelper Error Handling
1. **File Not Found**: Specifically catches and reports FileNotFoundError
2. **No Matching Line**: Reports when no line starts with the specified element name
3. **General Exception Handling**: Catches and reports any other exceptions during file processing

## Usage Examples

### Using PieChartGenerator

```python
import pandas as pd
from utils.pie_chart_generator import PieChartGenerator

# Create a DataFrame with memory usage data
data = pd.DataFrame({
    'Component': ['FREE_MEMORY', 'Component1::Function1', 'Component2::Function2'],
    'Size': [1024, 512, 256]
})

# Generate pie charts
PieChartGenerator.plot_pie_chart(
    data=data,
    title="Memory Usage Analysis",
    legend_title="Memory Components",
    output_image_path="memory_usage.png"
)
# This will create two files:
# - memory_usage.png (detailed view)
# - memory_usage_lib.png (grouped by library)
```

### Using DemangledHelper

```python
from utils.demangled_helper import DemangledHelper

# Find memory information for a specific element
memory_info = DemangledHelper.find_first_map_elem_line(
    file_path="path/to/demangled_file.dem",
    elem_name=".bss"
)

if memory_info:
    start_addr, size, used, free = memory_info
    print(f"Section starts at: {start_addr}")
    print(f"Section size: {size} bytes")
    print(f"Used memory: {used} bytes")
    print(f"Free memory: {free} bytes")
else:
    print("Section not found or error occurred")
```

## Referenced Context Files

The following context file was helpful in understanding how these utility classes fit into the broader memory analysis system:

- `PackageSummaries/Amazon-PrimeAir/items/mem_analysis/04_Memory_Analysis_Core.md`: Provided an overview of the memory analysis system's architecture, workflow, and how various scripts interact to process memory data and generate visualizations.