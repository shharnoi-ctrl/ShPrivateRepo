# Generated from:

- PackageSummaries/Amazon-PrimeAir/items/mem_analysis/04_Memory_Analysis_Core.md (4968 tokens)
- PackageSummaries/Amazon-PrimeAir/items/mem_analysis/03_Data_Processing_Scripts.md (3510 tokens)
- PackageSummaries/Amazon-PrimeAir/items/mem_analysis/03_Utility_Scripts.md (2914 tokens)
- PackageSummaries/Amazon-PrimeAir/items/mem_analysis/02_RAM_Visualization_Scripts.md (4048 tokens)
- PackageSummaries/Amazon-PrimeAir/items/mem_analysis/02_Flash_Visualization_Scripts.md (4679 tokens)
- PackageSummaries/Amazon-PrimeAir/items/mem_analysis/01_Memory_Analysis_System.md (3450 tokens)

---

# Memory Analysis System: Comprehensive Overview

This document provides a high-level overview of the Memory Analysis System, which analyzes memory usage in the ASTRO software system across different CPUs and operating modes.

## System Architecture

The Memory Analysis System is a Python-based workflow that processes compiled outputs from TI Code Composer Studio (CCS) and Eclipse-based Software-In-the-Loop (SIL) executions to generate detailed memory usage reports and visualizations. The system architecture consists of:

1. **Core Orchestration Layer** (`main.py`): Coordinates the entire workflow from input processing to visualization generation
2. **Data Processing Layer**: Transforms raw memory data into structured formats
3. **Utility Layer**: Provides reusable functionality for data extraction and visualization
4. **Visualization Layer**: Generates visual representations of memory usage

```
┌─────────────────────────────────────────────────────────────────────────┐
│                           INPUT SOURCES                                 │
│  ┌───────────────────────────┐         ┌───────────────────────────┐    │
│  │   TI Code Composer Studio │         │   Eclipse SIL Execution   │    │
│  │   - .map files (6)        │         │   - CSV files (9)         │    │
│  └───────────────┬───────────┘         └───────────────┬───────────┘    │
└─────────────────────────────────────────────────────────────────────────┘
                   │                                     │
                   ▼                                     ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                        CORE ORCHESTRATION                               │
│  ┌───────────────────────────────────────────────────────────────────┐  │
│  │                           main.py                                 │  │
│  └───────────────────────────────────────────────────────────────────┘  │
└────────────────────────────────┬────────────────────────────────────────┘
                                 │
                                 ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                       DATA PROCESSING SCRIPTS                           │
│  ┌───────────────────────────┐         ┌───────────────────────────┐    │
│  │   demangled_extract.py    │         │   process_alloc_data.py   │    │
│  └───────────────┬───────────┘         └───────────────┬───────────┘    │
└─────────────────────────────────────────────────────────────────────────┘
                   │                                     │
                   ▼                                     ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                          UTILITY CLASSES                                │
│  ┌───────────────────────────┐         ┌───────────────────────────┐    │
│  │   PieChartGenerator       │         │   DemangledHelper         │    │
│  └───────────────┬───────────┘         └───────────────┬───────────┘    │
└─────────────────────────────────────────────────────────────────────────┘
                   │                                     │
                   ▼                                     ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                      VISUALIZATION SCRIPTS                              │
│  ┌───────────────────────┐  ┌───────────────────────┐  ┌───────────┐    │
│  │  Flash Memory Scripts │  │  RAM Memory Scripts   │  │  Other    │    │
│  └───────────┬───────────┘  └───────────┬───────────┘  └─────┬─────┘    │
└───────────────────────────────────────────────────────────────────────────┘
               │                           │                     │
               └───────────────┬───────────┴─────────────────────┘
                               ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                           OUTPUT PRODUCTS                               │
│  ┌───────────────────────────┐         ┌───────────────────────────┐    │
│  │   Visualizations          │         │   Processed Data Files    │    │
│  └───────────────────────────┘         └───────────────────────────┘    │
└─────────────────────────────────────────────────────────────────────────┘
```

## Key System Components

### 1. Core Workflow (`main.py`)

The main script orchestrates the entire analysis process through a sequence of steps:

1. **Directory Preparation**: Creates output directories for demangled files, RAM data, and visualizations
2. **Map File Demangling**: Processes `.map` files using TI demangler tool
3. **Memory Section Extraction**: Extracts specific memory sections from demangled files
4. **Allocation Data Processing**: Processes CSV files from SIL execution
5. **Visualization Generation**: Generates various pie charts for memory usage

For detailed implementation, see [04_Memory_Analysis_Core.md](04_Memory_Analysis_Core.md).

### 2. Data Processing Scripts

#### `demangled_extract.py`
Extracts specific memory sections (`.bss`, `.data`, `.text`, `.const`) from demangled map files and formats the data for further processing.

#### `process_alloc_data.py`
Processes raw memory allocation data from CSV files and categorizes them based on their module or subsystem (pa_blocks, cyphal, vpgnc, veronte, etc.).

For detailed implementation, see [03_Data_Processing_Scripts.md](03_Data_Processing_Scripts.md).

### 3. Utility Classes

#### `PieChartGenerator`
Creates pie chart visualizations of memory usage data, including both detailed and library-grouped views.

#### `DemangledHelper`
Extracts specific information from demangled files, particularly memory section sizes and addresses.

For detailed implementation, see [03_Utility_Scripts.md](03_Utility_Scripts.md).

### 4. Visualization Scripts

#### Flash Memory Visualization
- `generate_pie_chart_flash.py`: Visualizes flash memory usage from pre-processed data
- `generate_pie_chart_flash_raw.py`: Creates comprehensive flash memory visualizations from multiple sources

For detailed implementation, see [02_Flash_Visualization_Scripts.md](02_Flash_Visualization_Scripts.md).

#### RAM Memory Visualization
- `generate_pie_chart_internal_ram_c1.py`: Visualizes internal RAM usage for CPU1
- `generate_pie_chart_internal_ram_c2.py`: Visualizes internal RAM usage for CPU2
- `generate_pie_chart_external_ram.py`: Visualizes external RAM usage
- `generate_pie_chart_ram_sections.py`: Visualizes RAM section allocations
- `generate_pie_chart_ram2.py`: General-purpose RAM visualization

For detailed implementation, see [02_RAM_Visualization_Scripts.md](02_RAM_Visualization_Scripts.md).

## System Configuration

### Operating Modes
The system analyzes three operating modes:
- `par0`: Recovery 0
- `par1`: Recovery 1
- `pam`: Monitor

### CPU Configurations
Six CCS projects are analyzed, covering both CPUs in all three modes:
- `1x_cpu1_pam` (CPU1 Monitor mode)
- `1x_cpu1_par0` (CPU1 Recovery 0 mode)
- `1x_cpu1_par1` (CPU1 Recovery 1 mode)
- `1x_cpu2_pam` (CPU2 Monitor mode)
- `1x_cpu2_par0` (CPU2 Recovery 0 mode)
- `1x_cpu2_par1` (CPU2 Recovery 1 mode)

### Memory Types
The system analyzes different memory types:
- **Flash Memory**: Code (`.text`) and constant (`.const`) sections
- **External RAM**: Shared memory between CPUs
- **Internal RAM**: CPU-specific local memory
- **Dynamic Allocations**: Memory allocated during runtime

### Memory Sizes
Memory sizes are configured for different CPUs and memory types:
```python
TOTAL_RAM_PER_CPU = {
    ('cpu1', 'ext'): 152832,   # Bytes
    ('cpu2', 'ext'): 3072000,
    ('cpu2', 'int'): 32576
}
EXTERNAL_TOTAL_RAM = 4194304   # Bytes
```

## Key Features

### Multi-CPU Analysis
- Analyzes memory usage for both CPU1 and CPU2
- Handles different memory types (internal, external) for each CPU
- Provides CPU-specific visualizations

### Multi-Mode Analysis
- Analyzes three operating modes: par0, par1, and pam
- Generates separate visualizations for each mode
- Enables comparison across operating modes

### Comprehensive Memory Coverage
- **Flash Memory**: Code and constant sections
- **RAM Memory**: Data and uninitialized sections
- **Dynamic Allocations**: Runtime memory usage
- **Free Memory**: Unused memory visualization

### Memory Overflow Detection
- Detects and reports memory overflow conditions
- Includes overflow information in visualization titles
- Helps identify potential memory issues

### Hierarchical Visualization
- **Detailed View**: Individual memory allocations
- **Library-Grouped View**: Aggregated by library/module
- **Section View**: Memory usage by memory section

## Workflow Execution

### Prerequisites
1. **TI Compilation**:
   - Full compilation in Code Composer Studio to generate `.map` files for all six projects

2. **Eclipse Compilation and Execution**:
   - 32-bit compilation in Eclipse
   - Execution of SIL with instrumented `Allocator` class
   - Three separate executions: `AstroLinux_mon`, `AstroLinux_rec0`, and `AstroLinux_rec1`
   - Generation of nine CSV files with allocation data

### Analysis Execution
1. Update paths in `user_paths.py`
2. Execute `main.py`
3. Optional: Compile `mem_analysis.tex` to generate a PDF report

## Output Products

### Visualizations
- Pie charts showing memory usage by category/module
- Both detailed and library-grouped visualizations
- Separate visualizations for different memory types and CPUs

### Processed Data Files
- CSV files with categorized memory usage data
- Text files with sorted memory allocations

### Optional LaTeX Report
- Comprehensive PDF report combining all visualizations

## For More Detailed Information

- [01_Memory_Analysis_System.md](01_Memory_Analysis_System.md): Comprehensive system overview
- [02_Flash_Visualization_Scripts.md](02_Flash_Visualization_Scripts.md): Flash memory visualization details
- [02_RAM_Visualization_Scripts.md](02_RAM_Visualization_Scripts.md): RAM memory visualization details
- [03_Data_Processing_Scripts.md](03_Data_Processing_Scripts.md): Data processing implementation
- [03_Utility_Scripts.md](03_Utility_Scripts.md): Utility classes implementation
- [04_Memory_Analysis_Core.md](04_Memory_Analysis_Core.md): Core workflow implementation