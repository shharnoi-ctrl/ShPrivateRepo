# Generated from:

- PA/scripts/generate_pie_chart_flash.py (578 tokens)
- PA/scripts/generate_pie_chart_flash_raw.py (644 tokens)

## With context from:

- PackageSummaries/Amazon-PrimeAir/items/mem_analysis/03_Utility_Scripts.md (2914 tokens)
- PackageSummaries/Amazon-PrimeAir/items/mem_analysis/03_Data_Processing_Scripts.md (3510 tokens)

---

# Flash Memory Visualization Scripts Analysis

This document provides a detailed analysis of two scripts responsible for visualizing flash memory usage in the memory analysis system: `generate_pie_chart_flash.py` and `generate_pie_chart_flash_raw.py`. These scripts approach flash memory visualization differently but share common visualization techniques through the `PieChartGenerator` utility class.

## 1. Functional Behavior and Logic Comparison

### `generate_pie_chart_flash.py`

This script visualizes flash memory usage from a pre-processed CSV file that already contains categorized memory usage data.

#### Main Processing Workflow

1. **Input Handling**:
   - Takes three command-line arguments: `csv_path`, `output_path`, and `name`
   - The CSV file is expected to have memory categories and their sizes

2. **Data Loading and Processing**:
   - Reads the CSV file with comma (`,`) as delimiter
   - Assigns column names "Category" and "Size"
   - Extracts the total flash memory size from a row labeled "TOTAL_FLASH"
   - Excludes specific rows: "TOTAL_FLASH", "USED_FLASH", "TOTAL_COMPUTED"
   - Converts the "Size" column to numeric values

3. **Output Generation**:
   - Saves the processed data to a new CSV file named "flash_[name].csv"
   - Prints the total flash memory size and the sum of all categories
   - Generates a pie chart visualization using the `PieChartGenerator` utility

4. **Error Handling**:
   - Catches `FileNotFoundError` if the input file doesn't exist
   - Catches `ValueError` for specific validation errors
   - Catches general exceptions and provides error messages

```python
def generate_pie_chart(csv_path, output_path, name):
    try:
        # Read the CSV file with "=" as delimiter
        data = pd.read_csv(csv_path, header=None, sep=",", names=["Category", "Size"])

        # Ensure "TOTAL_FLASH" exists before accessing
        data_total_flash = data[data["Category"] == "TOTAL_FLASH"]
        if data_total_flash.empty:
            raise ValueError("Missing 'TOTAL_FLASH' row in CSV.")
        total_ram = data_total_flash.iloc[0, 1]  # Safe to access after check

        # Exclude specific rows
        exclude_rows = ["TOTAL_FLASH", "USED_FLASH", "TOTAL_COMPUTED"]
        data = data[~data["Category"].isin(exclude_rows)]

        # Validate that the CSV has at least two columns
        if data.shape[1] < 2:
            raise ValueError("The CSV file must have at least two columns.")

        # Convert the second column to numeric, handling errors
        data["Size"] = pd.to_numeric(data["Size"], errors="coerce")

        # Save to CSV
        output_csv_path = os.path.join(output_path, "flash_" + name + ".csv")
        data.to_csv(output_csv_path, index=False)

        print("Total flash: " + str(data_total_flash))
        print("sum: " + str(data['Size'].sum()))

        PieChartGenerator.plot_pie_chart(
            data=data, 
            title="FLASH " + name + " USAGE (Total FLASH: " + str(total_ram) + " bytes)",
            output_image_path=os.path.join(output_path, "flash_" + name + ".png"),
            legend_title="Sections (sizes in bytes)"
        )
    except FileNotFoundError:
        print(f"❌ Error: File not found at path {csv_path}")
    except ValueError as e:
        print(f"❌ Error: {e}")
    except Exception as e:
        print(f"❌ An unexpected error occurred: {e}")
```

### `generate_pie_chart_flash_raw.py`

This script takes a more complex approach by combining data from multiple sources to create a comprehensive flash memory usage visualization.

#### Main Processing Workflow

1. **Input Handling**:
   - Takes five command-line arguments: `dem_map_path`, `text_csv_path`, `const_csv_path`, `output_path`, and `name`
   - Requires a demangled map file and two CSV files containing text and constant section data

2. **Data Loading and Processing**:
   - Reads two CSV files (text and const) with semicolon (`;`) as delimiter
   - Assigns column names "Category" and "Size" to both datasets
   - Concatenates the two datasets into a single DataFrame
   - Uses `DemangledHelper` to extract the total flash memory size from the demangled map file
   - Calculates free flash memory by subtracting the sum of all categories from the total
   - Adds a new row for "FREE_FLASH" with the calculated free memory size
   - Excludes specific rows: "TOTAL_FLASH", "USED_FLASH", "TOTAL_COMPUTED"
   - Converts the "Size" column to numeric values

3. **Output Generation**:
   - Saves the processed data to a new CSV file named "flash_[name].csv"
   - Generates a pie chart visualization using the `PieChartGenerator` utility

4. **Error Handling**:
   - Catches `FileNotFoundError` if any input file doesn't exist
   - Catches `ValueError` for specific validation errors
   - Catches general exceptions and provides error messages

```python
def generate_pie_chart(dem_map_path, text_csv_path, const_csv_path, output_path, name):
    try:
        # Read the CSV file with "=" as delimiter
        text_data = pd.read_csv(text_csv_path, header=None, sep=";", names=["Category", "Size"])
        const_data = pd.read_csv(const_csv_path, header=None, sep=";", names=["Category", "Size"])
        data = pd.concat([text_data, const_data], ignore_index=True)

        # Append a new row with IRAM MEM
        FLASH_PRG = DemangledHelper.find_first_map_elem_line(dem_map_path, "FLASH_PRG")
        total_flash = FLASH_PRG[1]
        data = pd.concat([data, pd.DataFrame([{'Category': 'FREE_FLASH', 'Size': total_flash - data['Size'].sum()}])], ignore_index=True)

        # Exclude specific rows
        exclude_rows = ["TOTAL_FLASH", "USED_FLASH", "TOTAL_COMPUTED"]
        data = data[~data["Category"].isin(exclude_rows)]

        # Validate that the CSV has at least two columns
        if data.shape[1] < 2:
            raise ValueError("The CSV file must have at least two columns.")

        # Convert the second column to numeric, handling errors
        data["Size"] = pd.to_numeric(data["Size"], errors="coerce")

        # Save to CSV
        output_csv_path = os.path.join(output_path, "flash_" + name + ".csv")
        data.to_csv(output_csv_path, index=False)

        PieChartGenerator.plot_pie_chart(
            data=data, 
            title="FLASH " + name + " USAGE (Total FLASH: " + str(total_flash) + " bytes)",
            output_image_path=os.path.join(output_path, "flash_" + name + ".png"),
            legend_title="Sections (sizes in bytes)"
        )
    except FileNotFoundError:
        print(f"❌ Error: File not found at path {text_csv_path}")
    except ValueError as e:
        print(f"❌ Error: {e}")
    except Exception as e:
        print(f"❌ An unexpected error occurred: {e}")
```

### Key Differences in Approach

| Feature | `generate_pie_chart_flash.py` | `generate_pie_chart_flash_raw.py` |
|---------|-------------------------------|-----------------------------------|
| **Input Sources** | Single pre-processed CSV file | Demangled map file + two CSV files (text and const) |
| **Data Delimiter** | Comma (`,`) | Semicolon (`;`) |
| **Total Flash Size Source** | "TOTAL_FLASH" row in CSV | Extracted from demangled map file using `DemangledHelper` |
| **Free Flash Calculation** | Not calculated (assumed to be in input) | Calculated as `total_flash - data['Size'].sum()` |
| **Data Combination** | Uses pre-combined data | Combines text and const data from separate files |
| **Error Reporting** | Reports file path in error message | Reports only text_csv_path in error message |

## 2. Memory Calculation Methods

### `generate_pie_chart_flash.py`

This script relies on pre-calculated memory values from the input CSV file:

1. **Total Flash Memory**:
   - Extracted from a row labeled "TOTAL_FLASH" in the input CSV
   - No calculation is performed on this value

2. **Used Flash Memory**:
   - Implicitly represented by the sum of all category sizes
   - Printed to console but not used in visualization

3. **Free Flash Memory**:
   - Not explicitly calculated or visualized
   - Assumed to be included in the input CSV if needed

### `generate_pie_chart_flash_raw.py`

This script performs more complex memory calculations:

1. **Total Flash Memory**:
   - Extracted from the demangled map file using `DemangledHelper.find_first_map_elem_line()`
   - Specifically looks for the "FLASH_PRG" element and uses its second value (index 1)
   ```python
   FLASH_PRG = DemangledHelper.find_first_map_elem_line(dem_map_path, "FLASH_PRG")
   total_flash = FLASH_PRG[1]
   ```

2. **Used Flash Memory**:
   - Calculated as the sum of all sizes from the text and const sections
   - `data['Size'].sum()`

3. **Free Flash Memory**:
   - Explicitly calculated as the difference between total and used flash
   - Added as a new row in the DataFrame
   ```python
   data = pd.concat([data, pd.DataFrame([{'Category': 'FREE_FLASH', 'Size': total_flash - data['Size'].sum()}])], ignore_index=True)
   ```

## 3. Visualization Techniques

Both scripts use the `PieChartGenerator` utility class to create visualizations, but with slightly different parameters:

### Common Visualization Approach

Both scripts:

1. Call `PieChartGenerator.plot_pie_chart()` with similar parameters:
   ```python
   PieChartGenerator.plot_pie_chart(
       data=data, 
       title="FLASH " + name + " USAGE (Total FLASH: " + str(total_flash) + " bytes)",
       output_image_path=os.path.join(output_path, "flash_" + name + ".png"),
       legend_title="Sections (sizes in bytes)"
   )
   ```

2. Generate two pie charts (through the `plot_pie_chart` method):
   - A detailed pie chart showing all individual memory allocations
   - A library-grouped pie chart showing memory usage aggregated by library

3. Use consistent formatting:
   - Include the total flash size in the title
   - Use "Sections (sizes in bytes)" as the legend title
   - Save the output as PNG files

### Differences in Visualization

The main difference is in the data being visualized:

1. **`generate_pie_chart_flash.py`**:
   - Visualizes pre-processed data with categories already defined
   - Does not explicitly visualize free flash memory unless it's in the input

2. **`generate_pie_chart_flash_raw.py`**:
   - Combines data from multiple sources
   - Explicitly calculates and visualizes free flash memory
   - Provides a more comprehensive view of flash memory usage

## 4. Use of Utility Classes

### DemangledHelper Usage

1. **`generate_pie_chart_flash.py`**:
   - Imports but does not use the `DemangledHelper` class

2. **`generate_pie_chart_flash_raw.py`**:
   - Uses `DemangledHelper.find_first_map_elem_line()` to extract the total flash memory size from the demangled map file
   - Specifically looks for the "FLASH_PRG" element
   ```python
   FLASH_PRG = DemangledHelper.find_first_map_elem_line(dem_map_path, "FLASH_PRG")
   total_flash = FLASH_PRG[1]
   ```

### PieChartGenerator Usage

Both scripts use the `PieChartGenerator` class in the same way:

1. Call `PieChartGenerator.plot_pie_chart()` with similar parameters
2. Rely on the utility to create both detailed and library-grouped visualizations
3. Use the utility's error handling and formatting capabilities

## 5. Input and Output Formats

### `generate_pie_chart_flash.py`

**Input Format**:
- CSV file with comma (`,`) as delimiter
- No header
- Expected columns: Category and Size
- Must include a row labeled "TOTAL_FLASH" with the total flash memory size

**Output Format**:
- CSV file with the processed data (excluding specific rows)
- PNG files with pie chart visualizations (detailed and library-grouped)

### `generate_pie_chart_flash_raw.py`

**Input Format**:
- Demangled map file (`.dem`) containing memory section information
- Two CSV files with semicolon (`;`) as delimiter:
  - Text section data
  - Const section data
- No headers in CSV files
- Expected columns in CSV files: Category and Size

**Output Format**:
- CSV file with the combined and processed data (including FREE_FLASH)
- PNG files with pie chart visualizations (detailed and library-grouped)

## 6. Error Handling and Contingency Logic

Both scripts include similar error handling mechanisms:

### Common Error Handling

1. **Command-Line Argument Validation**:
   - Check if the correct number of arguments is provided
   - Exit with a usage message if arguments are missing

2. **Exception Handling**:
   - Catch `FileNotFoundError` if input files don't exist
   - Catch `ValueError` for specific validation errors
   - Catch general exceptions for unexpected errors
   - Print informative error messages

### Specific Error Handling in `generate_pie_chart_flash.py`

1. **TOTAL_FLASH Validation**:
   ```python
   data_total_flash = data[data["Category"] == "TOTAL_FLASH"]
   if data_total_flash.empty:
       raise ValueError("Missing 'TOTAL_FLASH' row in CSV.")
   ```

2. **Column Count Validation**:
   ```python
   if data.shape[1] < 2:
       raise ValueError("The CSV file must have at least two columns.")
   ```

### Specific Error Handling in `generate_pie_chart_flash_raw.py`

1. **Column Count Validation**:
   ```python
   if data.shape[1] < 2:
       raise ValueError("The CSV file must have at least two columns.")
   ```

2. **Implicit DemangledHelper Error Handling**:
   - Relies on `DemangledHelper.find_first_map_elem_line()` to handle errors in demangled file processing

## 7. Integration with Memory Analysis Workflow

Both scripts are part of the memory analysis workflow but serve different purposes:

### `generate_pie_chart_flash.py`

This script is likely used for visualizing pre-processed flash memory data, possibly from a summary or aggregated source. It's simpler and relies on pre-calculated values.

### `generate_pie_chart_flash_raw.py`

This script is used for creating a more comprehensive flash memory visualization by combining raw data from multiple sources. It's more complex and performs additional calculations.

The scripts are likely called by the main memory analysis workflow in different contexts:

1. `generate_pie_chart_flash.py` might be used for quick visualizations of pre-processed data
2. `generate_pie_chart_flash_raw.py` might be used for detailed analysis of raw memory data

## 8. Contribution to Overall Memory Analysis

### `generate_pie_chart_flash.py`

This script contributes to the memory analysis by:
1. Visualizing pre-processed flash memory usage data
2. Providing a simple way to generate pie charts from existing CSV files
3. Supporting the analysis of memory usage by category

### `generate_pie_chart_flash_raw.py`

This script contributes to the memory analysis by:
1. Combining data from multiple sources to create a comprehensive view of flash memory usage
2. Explicitly calculating and visualizing free flash memory
3. Using the demangled map file to determine the total flash memory size
4. Supporting the analysis of memory usage by category and library

## 9. Cross-Component Relationships

Both scripts interact with other components of the memory analysis system:

1. **Input Data Sources**:
   - `generate_pie_chart_flash.py` uses pre-processed CSV files
   - `generate_pie_chart_flash_raw.py` uses demangled map files and raw CSV files

2. **Utility Classes**:
   - Both scripts use `PieChartGenerator` for visualization
   - `generate_pie_chart_flash_raw.py` also uses `DemangledHelper` for extracting data from demangled files

3. **Output Consumers**:
   - The generated CSV and PNG files are likely used by other scripts or tools for further analysis or reporting

## 10. Parameters and Configuration

### `generate_pie_chart_flash.py`

**Command-Line Parameters**:
1. `csv_path`: Path to the input CSV file
2. `output_path`: Directory where output files will be saved
3. `name`: Name to be used in output file names and chart titles

**Configuration**:
- CSV delimiter: Comma (`,`)
- Excluded rows: "TOTAL_FLASH", "USED_FLASH", "TOTAL_COMPUTED"
- Output file naming: "flash_[name].csv" and "flash_[name].png"

### `generate_pie_chart_flash_raw.py`

**Command-Line Parameters**:
1. `dem_map_path`: Path to the demangled map file
2. `text_csv_path`: Path to the CSV file containing text section data
3. `const_csv_path`: Path to the CSV file containing const section data
4. `output_path`: Directory where output files will be saved
5. `name`: Name to be used in output file names and chart titles

**Configuration**:
- CSV delimiter: Semicolon (`;`)
- Excluded rows: "TOTAL_FLASH", "USED_FLASH", "TOTAL_COMPUTED"
- Output file naming: "flash_[name].csv" and "flash_[name].png"
- Free flash category name: "FREE_FLASH"

## 11. Referenced Context Files

The following context files were helpful in understanding how these scripts fit into the overall memory analysis system:

1. **03_Utility_Scripts.md**: Provided detailed information about the `PieChartGenerator` and `DemangledHelper` utility classes used by both scripts. This helped understand how the scripts leverage these utilities for data extraction and visualization.

2. **03_Data_Processing_Scripts.md**: Provided context about other data processing scripts in the memory analysis workflow, which helped understand how these visualization scripts fit into the larger system.

## 12. Conclusion

The `generate_pie_chart_flash.py` and `generate_pie_chart_flash_raw.py` scripts are important components of the memory analysis system, responsible for visualizing flash memory usage. They approach this task differently:

1. `generate_pie_chart_flash.py` provides a simpler approach, visualizing pre-processed data from a single CSV file.
2. `generate_pie_chart_flash_raw.py` provides a more comprehensive approach, combining data from multiple sources and explicitly calculating free flash memory.

Both scripts use the `PieChartGenerator` utility class to create detailed and library-grouped visualizations, but `generate_pie_chart_flash_raw.py` also uses the `DemangledHelper` utility to extract total flash memory size from demangled map files.

These scripts contribute to the overall memory analysis by providing visual representations of flash memory usage, which helps developers understand how memory is allocated and identify potential optimization opportunities.