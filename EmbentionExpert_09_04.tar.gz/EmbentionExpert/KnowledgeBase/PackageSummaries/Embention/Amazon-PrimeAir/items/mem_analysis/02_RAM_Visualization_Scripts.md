# Generated from:

- PA/scripts/generate_pie_chart_internal_ram_c1.py (658 tokens)
- PA/scripts/generate_pie_chart_internal_ram_c2.py (563 tokens)
- PA/scripts/generate_pie_chart_internal_ram_c2_IPC.py (823 tokens)
- PA/scripts/generate_pie_chart_external_ram.py (977 tokens)
- PA/scripts/generate_pie_chart_ram2.py (601 tokens)
- PA/scripts/generate_pie_chart_ram_sections.py (743 tokens)

## With context from:

- PackageSummaries/Amazon-PrimeAir/items/mem_analysis/03_Utility_Scripts.md (2914 tokens)
- PackageSummaries/Amazon-PrimeAir/items/mem_analysis/03_Data_Processing_Scripts.md (3510 tokens)

---

# RAM Usage Visualization Scripts Analysis

This document provides a comprehensive analysis of the scripts responsible for visualizing RAM usage in the system, focusing on how they handle different memory types and CPU cores.

## 1. Overview of RAM Visualization Scripts

The system includes several specialized scripts for visualizing RAM usage across different memory types and CPU cores:

| Script | Memory Type | CPU Core | Special Features |
|--------|-------------|----------|------------------|
| `generate_pie_chart_internal_ram_c1.py` | Internal RAM | C1/CPU1 | Handles IRAM and XCCPU1 memory |
| `generate_pie_chart_internal_ram_c2.py` | Internal RAM | C2/CPU2 | Handles IRAM memory |
| `generate_pie_chart_internal_ram_c2_IPC.py` | Internal RAM | C2/CPU2 | Handles IPC memory with BSS and data sections |
| `generate_pie_chart_external_ram.py` | External RAM | Both | Combines multiple data sources |
| `generate_pie_chart_ram2.py` | Generic RAM | Not specific | General-purpose visualization |
| `generate_pie_chart_ram_sections.py` | External RAM | Sections | Visualizes memory section allocations |

All scripts use the utility classes `PieChartGenerator` and `DemangledHelper` to create visualizations and extract memory information.

## 2. Internal RAM C1 Visualization (`generate_pie_chart_internal_ram_c1.py`)

### Functional Behavior and Logic

This script visualizes the internal RAM usage for CPU1/C1 by:

1. Reading a CSV file containing memory usage data with "=" as delimiter
2. Excluding specific rows like "TOTAL_RAM", "USED_RAM", etc.
3. Extracting IRAM and XCCPU1 memory information from the demangled map file
4. Calculating total RAM as the sum of IRAM and XCCPU1 memory
5. Adding XCCPU1 used memory as a new category
6. Calculating free RAM and adding it as a category
7. Detecting RAM overflow conditions and including this in the chart title
8. Generating a pie chart visualization and saving it as PNG
9. Saving the processed data as a CSV file

### Memory Calculation Method

```python
# Append a new row with IRAM MEM
IRAM = DemangledHelper.find_first_map_elem_line(dem_map_path, "IRAM")
XCCPU1 = DemangledHelper.find_first_map_elem_line(dem_map_path, "XCCPU1")
total_ram = IRAM[1] + XCCPU1[1]
data = pd.concat([data, pd.DataFrame([{'Category': 'XCCPU1 (used)', 'Size': XCCPU1[2]}])], ignore_index=True)
free_ram = total_ram - data['Size'].sum()
data = pd.concat([data, pd.DataFrame([{'Category': 'FREE_RAM', 'Size': max(0, free_ram)}])], ignore_index=True)
```

### Overflow Detection

The script detects RAM overflow by checking if the calculated free RAM is negative:

```python
title="INTERNAL " + name + " C1 RAM USAGE (Total RAM: " + str(total_ram) + " bytes)" +
      (" (Overflowed RAM: " + str(abs(free_ram)) + " bytes)" if free_ram < 0 else "")
```

### Error Handling

The script includes comprehensive error handling for:
- FileNotFoundError
- ValueError (for CSV format issues)
- General exceptions

## 3. Internal RAM C2 Visualization (`generate_pie_chart_internal_ram_c2.py`)

### Functional Behavior and Logic

This script visualizes the internal RAM usage for CPU2/C2 by:

1. Reading a CSV file containing memory usage data with "=" as delimiter
2. Excluding specific rows like "TOTAL_RAM", "USED_RAM", etc.
3. Extracting IRAM memory information from the demangled map file
4. Calculating free RAM as IRAM total minus the sum of all categories
5. Adding free RAM as a new category
6. Generating a pie chart visualization and saving it as PNG
7. Saving the processed data as a CSV file

### Memory Calculation Method

```python
# Append a new row with IRAM MEM
IRAM = DemangledHelper.find_first_map_elem_line(dem_map_path, "IRAM")
data = pd.concat([data, pd.DataFrame([{'Category': 'FREE_RAM', 'Size': IRAM[1] - data['Size'].sum()}])], ignore_index=True)
```

### Key Differences from C1 Script

1. Only uses IRAM memory (no XCCPU1)
2. Does not explicitly check for overflow conditions
3. Simpler memory calculation logic

## 4. Internal RAM C2 IPC Visualization (`generate_pie_chart_internal_ram_c2_IPC.py`)

### Functional Behavior and Logic

This script visualizes the internal RAM usage for CPU2/C2 with IPC (Inter-Process Communication) memory by:

1. Reading multiple CSV files (main, BSS, and data sections)
2. Concatenating all data vertically
3. Excluding specific rows like "TOTAL_RAM", "USED_RAM", etc.
4. Extracting IRAM memory information from the demangled map file
5. Calculating total RAM as IRAM plus GSRAM (passed as parameter)
6. For C1 configurations, adding CPU1TOCPU2RAM memory
7. Calculating free memory and detecting overflow conditions
8. Generating a pie chart visualization and saving it as PNG
9. Saving the processed data as a CSV file

### Memory Calculation Method

```python
# Append a new row with IRAM MEM
IRAM = DemangledHelper.find_first_map_elem_line(dem_map_path, "IRAM")
total_ram = IRAM[1] + int(total_gsram)
if "C1" in name:
    CPU1TOCPU2RAM = DemangledHelper.find_first_map_elem_line(dem_map_path, "CPU1TOCPU2RAM")
    total_ram += CPU1TOCPU2RAM[1]

free_memory = total_ram - data['Size'].sum()
```

### Overflow Detection

The script detects RAM overflow and adds a note to the title:

```python
title_extension = ""
if free_memory < 0:
    title_extension = " Missing " + str(-free_memory) + " bytes"
```

### Unique Features

1. Processes multiple input files (main CSV, BSS map, data map)
2. Handles GSRAM memory (passed as parameter)
3. Special handling for C1 configurations (adds CPU1TOCPU2RAM)
4. Prints detailed memory calculations for debugging

## 5. External RAM Visualization (`generate_pie_chart_external_ram.py`)

### Functional Behavior and Logic

This script visualizes the external RAM usage by:

1. Reading multiple CSV files (external memory sections, external allocator, BSS, and data)
2. Copying specific elements from the external memory sections file
3. Concatenating all data vertically
4. Extracting the total RAM value from the data
5. Excluding specific rows like "TOTAL_RAM", "USED_RAM", etc.
6. Calculating total RAM used and free RAM
7. Generating a pie chart visualization and saving it as PNG
8. Saving a sorted version of the data as a text file

### Memory Calculation Method

```python
# Calculate the sum of the 'Size' column
total_ram_used = data['Size'].sum()

# Append a new row with unasigned memory
data = pd.concat([data, pd.DataFrame([{'Category': 'FREE RAM', 'Size': total_ram - total_ram_used}])], ignore_index=True)
```

### Unique Features

1. Processes multiple input files from different sources
2. Copies specific elements from one file to another
3. Saves a sorted version of the data (descending by size)
4. Uses a different output format (text file with "=" separator)

## 6. Generic RAM Visualization (`generate_pie_chart_ram2.py`)

### Functional Behavior and Logic

This script provides a general-purpose RAM visualization by:

1. Reading a CSV file with "=" as delimiter
2. Saving a copy of the original data
3. Extracting the total RAM value if present
4. Excluding specific rows like "TOTAL_RAM", "USED_RAM", etc.
5. Generating a pie chart visualization and saving it as PNG
6. Saving a sorted version of the data as a text file

### Memory Calculation Method

Unlike the other scripts, this one doesn't calculate free memory or add new categories. It simply visualizes the data as provided:

```python
# Ensure "TOTAL_RAM" exists before accessing
data_total_ram = data[data["Category"] == "TOTAL_RAM"]
if not data_total_ram.empty:
    total_ram = data_total_ram.iloc[0, 1]  # Safe to access after check
```

### Unique Features

1. More general-purpose than the other scripts
2. Uses the file stem (basename without extension) as the chart title
3. Refers to categories as "Classes" in the legend title
4. Saves both the original and a sorted version of the data

## 7. RAM Sections Visualization (`generate_pie_chart_ram_sections.py`)

### Functional Behavior and Logic

This script visualizes external memory sections by:

1. Creating a DataFrame with the total RAM value
2. Extracting XCCPU2 and ERAM_CPU2 memory information from the demangled map file
3. Adding used and free memory for each section as separate categories
4. Calculating total RAM used and unassigned memory
5. Generating a pie chart visualization and saving it as PNG
6. Saving the processed data as a CSV file

### Memory Calculation Method

```python
# Append a new row with XCD2 MEM
XCCPU2 = DemangledHelper.find_first_map_elem_line(dem_map_path, "XCCPU2")
data = pd.concat([data, pd.DataFrame([{'Category': 'XCCPU2 (used)', 'Size': XCCPU2[2]}])], ignore_index=True)
data = pd.concat([data, pd.DataFrame([{'Category': 'XCCPU2 (free)', 'Size': XCCPU2[3]}])], ignore_index=True)

# Append a new row with ERAM_CPU2 MEM
ERAM_CPU2 = DemangledHelper.find_first_map_elem_line(dem_map_path, "ERAM_CPU2")
data = pd.concat([data, pd.DataFrame([{'Category': 'ERAM_CPU2 (used)', 'Size': ERAM_CPU2[2]}])], ignore_index=True)
data = pd.concat([data, pd.DataFrame([{'Category': 'ERAM_CPU2 (free)', 'Size': ERAM_CPU2[3]}])], ignore_index=True)
```

### Unique Features

1. Focuses specifically on memory sections rather than allocations
2. Shows both used and free memory for each section
3. Calculates unassigned memory as a separate category
4. Takes total RAM as a direct parameter rather than extracting it

## 8. Cross-Component Relationships

### Utility Class Usage

All scripts use the same utility classes:

1. **PieChartGenerator**: Used to create pie chart visualizations
   ```python
   PieChartGenerator.plot_pie_chart(
       data=data, 
       title="INTERNAL " + name + " C1 RAM USAGE (Total RAM: " + str(total_ram) + " bytes)",
       output_image_path=os.path.join(output_path, "internal_ram_" + name + ".png"),
       legend_title="Sections (sizes in bytes)"
   )
   ```

2. **DemangledHelper**: Used to extract memory information from demangled map files
   ```python
   IRAM = DemangledHelper.find_first_map_elem_line(dem_map_path, "IRAM")
   ```

### Data Flow Between Scripts

While each script operates independently, they share a common workflow:

1. Read input data from CSV files
2. Process and transform the data
3. Extract additional information from demangled map files
4. Calculate memory usage statistics
5. Generate visualizations
6. Save processed data for further analysis

The scripts are designed to be called by a master script or workflow that coordinates the overall memory analysis process.

## 9. Comparison of Memory Handling Approaches

### Internal RAM Handling

| Script | Memory Sections | Overflow Detection | Special Features |
|--------|----------------|-------------------|------------------|
| C1 | IRAM + XCCPU1 | Yes | Shows overflow in title |
| C2 | IRAM only | No | Simpler calculation |
| C2 IPC | IRAM + GSRAM + (CPU1TOCPU2RAM for C1) | Yes | Combines multiple data sources |

### External RAM Handling

| Script | Approach | Data Sources | Special Features |
|--------|----------|--------------|------------------|
| External RAM | Combines multiple sources | External sections, allocator, BSS, data | Saves sorted output |
| RAM Sections | Shows section breakdown | Demangled map file | Shows used/free per section |
| Generic RAM2 | Direct visualization | Single CSV | General-purpose approach |

### Free Memory Calculation

Each script calculates free memory differently:

1. **C1**: `free_ram = total_ram - data['Size'].sum()`
2. **C2**: `free_ram = IRAM[1] - data['Size'].sum()`
3. **C2 IPC**: `free_memory = total_ram - data['Size'].sum()`
4. **External RAM**: `free_ram = total_ram - total_ram_used`
5. **RAM Sections**: `unassigned = total_ram - total_ram_used`
6. **Generic RAM2**: Does not calculate free memory

## 10. Error Handling and Contingency Logic

All scripts include similar error handling patterns:

```python
try:
    # Main processing logic
except FileNotFoundError:
    print(f"❌ Error: File not found at path {csv_path}")
except ValueError as e:
    print(f"❌ Error: {e}")
except Exception as e:
    print(f"❌ An unexpected error occurred: {e}")
```

Key error handling includes:
1. File not found errors
2. CSV format validation
3. Data type conversion errors
4. General exception catching

## 11. Visualization Techniques

All scripts use the `PieChartGenerator` utility class to create pie charts with:

1. Consistent formatting and styling
2. Detailed legends showing sizes in bytes
3. Informative titles including total RAM size
4. Overflow or missing memory indicators when applicable

The visualizations provide a clear picture of:
1. Memory usage by category/section
2. Free vs. used memory
3. Memory overflow conditions
4. Relative size of different memory allocations

## 12. Command-Line Interface

All scripts follow a similar command-line interface pattern:

```python
if __name__ == "__main__":
    if len(sys.argv) != N:  # N varies by script
        print("Usage: python script.py <arg1> <arg2> ...")
    else:
        # Parse arguments and call main function
```

The number and meaning of arguments vary by script:
- Internal RAM scripts: 4-5 arguments
- External RAM script: 8 arguments
- RAM Sections script: 5 arguments
- Generic RAM2 script: 4 arguments

## 13. Output Files

Each script generates two types of output files:

1. **Visualization**: PNG file containing the pie chart
   ```
   output_image_path=os.path.join(output_path, "internal_ram_" + name + ".png")
   ```

2. **Data**: CSV or text file containing the processed data
   ```
   output_csv_path = os.path.join(output_path, "internal_ram_" + name + ".csv")
   data.to_csv(output_csv_path, index=False)
   ```

The naming convention typically includes:
- Memory type (internal_ram, external_ram)
- Configuration name (passed as parameter)
- File extension (.png, .csv, .txt)

## 14. Referenced Context Files

The following context files were helpful in understanding how these scripts fit into the broader memory analysis system:

1. **03_Utility_Scripts.md**: Provided details on the `PieChartGenerator` and `DemangledHelper` utility classes used by all scripts.
2. **03_Data_Processing_Scripts.md**: Explained how the input data is processed before being visualized by these scripts.

## 15. Summary of Key Differences

1. **Memory Types**:
   - Internal RAM scripts focus on CPU-specific internal memory
   - External RAM scripts handle shared external memory
   - Generic RAM2 script provides a general-purpose visualization

2. **CPU Cores**:
   - C1/CPU1 scripts handle the first CPU core's memory
   - C2/CPU2 scripts handle the second CPU core's memory
   - Some scripts handle memory shared between cores

3. **Data Sources**:
   - Some scripts read a single CSV file
   - Others combine data from multiple sources
   - Most extract additional information from demangled map files

4. **Memory Calculation**:
   - Different approaches to calculating total and free memory
   - Some scripts detect and report overflow conditions
   - Others focus on section-specific breakdowns

5. **Visualization Focus**:
   - Most scripts focus on memory usage by category
   - RAM Sections script focuses on memory section allocations
   - All provide pie chart visualizations with detailed legends

These scripts collectively provide a comprehensive view of RAM usage across different memory types and CPU cores, enabling detailed analysis of memory allocation and potential issues like overflow conditions.