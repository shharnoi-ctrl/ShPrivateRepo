# Generated from:

- PackageSummaries/Amazon-PrimeAir/items/mem_analysis/04_Memory_Analysis_Core.md (4968 tokens)
- PackageSummaries/Amazon-PrimeAir/items/mem_analysis/03_Data_Processing_Scripts.md (3510 tokens)
- PackageSummaries/Amazon-PrimeAir/items/mem_analysis/03_Utility_Scripts.md (2914 tokens)
- PackageSummaries/Amazon-PrimeAir/items/mem_analysis/02_RAM_Visualization_Scripts.md (4048 tokens)
- PackageSummaries/Amazon-PrimeAir/items/mem_analysis/02_Flash_Visualization_Scripts.md (4679 tokens)

---

# Comprehensive Memory Analysis Framework: System-Level Summary

## 1. System Architecture Overview

The memory analysis framework is a comprehensive Python-based system designed to analyze memory usage in the ASTRO embedded software system. It processes compiled outputs from TI Code Composer Studio (CCS) and Eclipse-based Software-In-the-Loop (SIL) executions to generate detailed memory usage reports and visualizations across different CPUs and operating modes.

The framework consists of four main component types:

1. **Core Orchestration Script** (`main.py`): Coordinates the entire workflow, from input processing to visualization generation
2. **Data Processing Scripts**: Transform raw memory data into structured formats for analysis
3. **Utility Classes**: Provide reusable functionality for data extraction and visualization
4. **Visualization Scripts**: Generate visual representations of memory usage across different memory types and CPUs

## 2. Complete Workflow: From Input to Output

The memory analysis framework follows a sequential workflow:

### Input Sources
1. **TI Code Composer Studio Outputs**:
   - `.map` files from six CCS projects (CPU1 and CPU2 across three operating modes)
   - Contain memory layout information, section sizes, and symbol addresses

2. **Eclipse SIL Execution Outputs**:
   - Nine CSV files with memory allocation data from instrumented `Allocator` class
   - Track dynamic memory allocations during software execution

### Processing Pipeline
1. **Directory Preparation**:
   - Create output directories for demangled files, RAM data, and visualizations

2. **Map File Demangling**:
   - Process `.map` files using TI demangler tool
   - Generate demangled (`.dem`) files with human-readable symbol names

3. **Memory Section Extraction**:
   - Extract specific memory sections (`.bss`, `.data`, `.text`, `.const`) from demangled files
   - Apply appropriate separators for downstream processing

4. **Allocation Data Processing**:
   - Process CSV files from SIL execution
   - Categorize memory allocations by module/subsystem

5. **Visualization Generation**:
   - Generate pie charts for flash memory usage
   - Generate pie charts for RAM sections
   - Generate pie charts for allocator usage
   - Generate pie charts for external RAM usage
   - Generate pie charts for internal RAM usage (CPU1 and CPU2)

### Output Products
1. **Visualizations**:
   - Pie charts showing memory usage by category/module
   - Both detailed and library-grouped visualizations
   - Separate visualizations for different memory types and CPUs

2. **Processed Data Files**:
   - CSV files with categorized memory usage data
   - Text files with sorted memory allocations

3. **Optional LaTeX Report**:
   - Comprehensive PDF report combining all visualizations (requires manual LaTeX compilation)

## 3. Component Relationships Diagram

```
┌─────────────────────────────────────────────────────────────────────────┐
│                           INPUT SOURCES                                 │
│                                                                         │
│  ┌───────────────────────────┐         ┌───────────────────────────┐    │
│  │   TI Code Composer Studio │         │   Eclipse SIL Execution   │    │
│  │   - .map files (6)        │         │   - CSV files (9)         │    │
│  └───────────────┬───────────┘         └───────────────┬───────────┘    │
└─────────────────────────────────────────────────────────────────────────┘
                   │                                     │
                   ▼                                     ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                        CORE ORCHESTRATION                               │
│                                                                         │
│  ┌───────────────────────────────────────────────────────────────────┐  │
│  │                           main.py                                 │  │
│  │  - Coordinates workflow execution                                 │  │
│  │  - Manages directory structure                                    │  │
│  │  - Calls processing and visualization scripts                     │  │
│  └───────────────────────────────────────────────────────────────────┘  │
└────────────────────────────────┬────────────────────────────────────────┘
                                 │
                                 ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                       DATA PROCESSING SCRIPTS                           │
│                                                                         │
│  ┌───────────────────────────┐         ┌───────────────────────────┐    │
│  │   demangled_extract.py    │         │   process_alloc_data.py   │    │
│  │   - Extracts memory       │         │   - Processes allocation  │    │
│  │     sections              │         │     data                  │    │
│  └───────────────┬───────────┘         └───────────────┬───────────┘    │
└─────────────────────────────────────────────────────────────────────────┘
                   │                                     │
                   ▼                                     ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                          UTILITY CLASSES                                │
│                                                                         │
│  ┌───────────────────────────┐         ┌───────────────────────────┐    │
│  │   PieChartGenerator       │         │   DemangledHelper         │    │
│  │   - Creates pie chart     │         │   - Extracts info from    │    │
│  │     visualizations        │         │     demangled files       │    │
│  └───────────────┬───────────┘         └───────────────┬───────────┘    │
└─────────────────────────────────────────────────────────────────────────┘
                   │                                     │
                   ▼                                     ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                      VISUALIZATION SCRIPTS                              │
│                                                                         │
│  ┌───────────────────────┐  ┌───────────────────────┐  ┌───────────┐    │
│  │  Flash Memory Scripts │  │  RAM Memory Scripts   │  │  Other    │    │
│  │  - flash.py          │  │  - ram2.py           │  │  Scripts   │    │
│  │  - flash_raw.py      │  │  - ram_sections.py   │  │           │    │
│  │                       │  │  - external_ram.py   │  │           │    │
│  │                       │  │  - internal_ram_c1.py│  │           │    │
│  │                       │  │  - internal_ram_c2.py│  │           │    │
│  └───────────┬───────────┘  └───────────┬───────────┘  └─────┬─────┘    │
└───────────────────────────────────────────────────────────────────────────┘
               │                           │                     │
               └───────────────┬───────────┴─────────────────────┘
                               ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                           OUTPUT PRODUCTS                               │
│                                                                         │
│  ┌───────────────────────────┐         ┌───────────────────────────┐    │
│  │   Visualizations          │         │   Processed Data Files    │    │
│  │   - Pie charts            │         │   - CSV files             │    │
│  │   - PNG format            │         │   - Text files            │    │
│  └───────────────────────────┘         └───────────────────────────┘    │
│                                                                         │
│  ┌───────────────────────────┐                                          │
│  │   LaTeX Report (Optional) │                                          │
│  │   - Comprehensive PDF     │                                          │
│  └───────────────────────────┘                                          │
└─────────────────────────────────────────────────────────────────────────┘
```

## 4. Key System Features

### Multi-CPU Analysis
- Analyzes memory usage for both CPU1 and CPU2
- Handles different memory types (internal, external) for each CPU
- Provides CPU-specific visualizations and reports

### Multi-Mode Analysis
- Analyzes three operating modes: par0 (Recovery 0), par1 (Recovery 1), and pam (Monitor)
- Generates separate visualizations for each mode
- Enables comparison of memory usage across different operating modes

### Comprehensive Memory Coverage
- **Flash Memory**: Analyzes code (.text) and constant (.const) sections
- **RAM Memory**: Analyzes data (.data) and uninitialized (.bss) sections
- **Dynamic Allocations**: Tracks memory allocated during runtime
- **Free Memory**: Calculates and visualizes unused memory

### Hierarchical Visualization
- **Detailed View**: Shows individual memory allocations
- **Library-Grouped View**: Aggregates memory usage by library/module
- **Section View**: Shows memory usage by memory section

### Memory Overflow Detection
- Detects and reports memory overflow conditions
- Includes overflow information in visualization titles
- Helps identify potential memory issues

## 5. Data Processing and Transformation

### Raw Data Processing
1. **Map File Processing**:
   - Demangler tool converts machine-readable symbols to human-readable format
   - `demangled_extract.py` extracts specific memory sections
   - Different separators are used for different section types

2. **Allocation Data Processing**:
   - `process_alloc_data.py` categorizes allocations by module/subsystem
   - Categories include: pa_blocks, cyphal, vpgnc, veronte, vblocks, dynamics, etc.
   - Standardizes naming conventions across different files

### Data Transformation
1. **Memory Size Calculation**:
   - Converts hexadecimal values to decimal
   - Multiplies by 2 to get size in bytes
   - Calculates free memory as total minus used

2. **Data Aggregation**:
   - Combines data from multiple sources
   - Groups by library/module for higher-level views
   - Sorts by size for better visualization

3. **Visualization Preparation**:
   - Formats labels and titles
   - Prioritizes "FREE" memory entries
   - Creates detailed legends with size information

## 6. Visualization Techniques

### Pie Chart Generation
- Uses `PieChartGenerator` utility class
- Creates both detailed and library-grouped visualizations
- Includes percentage labels on pie slices
- Provides detailed legends with size information

### Memory Type-Specific Visualizations
1. **Flash Memory**:
   - Combines .text and .const sections
   - Shows code and constant data usage

2. **External RAM**:
   - Combines multiple data sources
   - Shows shared memory usage

3. **Internal RAM**:
   - CPU-specific visualizations
   - Shows CPU-local memory usage

4. **RAM Sections**:
   - Shows memory usage by section
   - Includes both used and free memory per section

## 7. System Architecture Benefits

### Modularity
- Separate scripts for different memory types and visualization tasks
- Reusable utility classes for common functionality
- Easy to extend with new visualization types or memory analyses

### Flexibility
- Handles multiple CPUs and operating modes
- Processes different types of input data
- Generates various output formats

### Comprehensive Analysis
- Combines static (compiled) and dynamic (runtime) memory information
- Provides both detailed and high-level views
- Detects and reports memory issues

### Reproducibility
- Well-defined workflow from input to output
- Consistent naming conventions and directory structure
- Clear separation of processing and visualization steps

## 8. Conclusion

The memory analysis framework provides a comprehensive solution for analyzing memory usage in the ASTRO embedded software system. It processes compiled outputs and runtime allocation data to generate detailed visualizations and reports across different CPUs and operating modes.

The system's modular architecture, with separate components for data processing, utility functions, and visualization, makes it flexible and extensible. The comprehensive coverage of different memory types (flash, external RAM, internal RAM) and visualization approaches (detailed, library-grouped, section-based) provides valuable insights into memory usage patterns.

By detecting memory overflow conditions and visualizing free memory, the system helps identify potential memory issues and optimization opportunities. The consistent workflow and output formats make it a reliable tool for ongoing memory analysis and optimization efforts in the ASTRO embedded software development process.