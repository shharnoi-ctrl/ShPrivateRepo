# Generated from:

- PA/main.py (3484 tokens)
- PA/user_paths.py (35 tokens)
- readme.md (972 tokens)

---

# Memory Analysis System: Core Workflow and Architecture

This document provides a comprehensive analysis of the memory analysis system that processes compiled outputs from TI Code Composer Studio and Eclipse to generate memory usage reports across different CPUs and operating modes.

## System Overview

The memory analysis system is a Python-based workflow that analyzes memory usage in the ASTRO software system. It processes map files from TI Code Composer Studio (CCS) and memory allocation data from Eclipse-based Software-In-the-Loop (SIL) executions to generate detailed memory usage reports and visualizations.

## Directory Structure and Configuration

### Core Directories

The system operates with the following directory structure:

- **Working Directory**: Root directory of the memory analysis system (`PA/`)
- **Scripts Directory**: Contains processing scripts (`PA/scripts/`)
- **Output Directories** (created during execution):
  - `PA/demangled/`: Stores demangled output files
  - `PA/ram_data/`: Stores processed RAM allocation data
  - `PA/outputs/`: Stores final output files and visualizations
    - `PA/outputs/flash/`: Flash memory usage visualizations
    - `PA/outputs/allocators_<mode>/`: Allocator usage per PA mode
    - `PA/outputs/external_ram_<mode>/`: External RAM usage per PA mode
    - `PA/outputs/internal_ram_cpu1_<mode>/`: CPU1 internal RAM usage per PA mode
    - `PA/outputs/internal_ram_cpu2_<mode>/`: CPU2 internal RAM usage per PA mode

### Key Configuration Parameters

The system uses several configuration parameters defined in `main.py`:

1. **PA Modes**: Three operating modes are analyzed:
   ```python
   PA_MODES = ['par0', 'par1', 'pam']  # Recovery 0, Recovery 1, Monitor
   ```

2. **CCS Projects**: Six CCS projects are analyzed, covering both CPUs in all three modes:
   ```python
   CCS_PROJECT_AND_IDENTIFYING_NAME = [
       ('1x_cpu1_pam',  'cpu1_pam'),
       ('1x_cpu1_par0', 'cpu1_par0'),
       ('1x_cpu1_par1', 'cpu1_par1'),
       ('1x_cpu2_pam',  'cpu2_pam'),
       ('1x_cpu2_par0', 'cpu2_par0'),
       ('1x_cpu2_par1', 'cpu2_par1')
   ]
   ```

3. **Memory Sections**: Four memory sections are extracted from demangled files:
   ```python
   DEMANGLED_SECTIONS_AND_SEPARATORS = [
       ('.bss',    '='),
       ('.data',   '='),
       ('.text',   ';'),
       ('.const ', ';')
   ]
   ```

4. **Allocated RAM Files**: Nine CSV files from SIL execution are processed:
   ```python
   ALLOCATED_RAM_FILENAMES = [
       'pa_rec1_C1_ext.csv',
       'pa_rec1_C2_ext.csv',
       'pa_rec1_C2_int.csv',
       'pa_rec0_C1_ext.csv',
       'pa_rec0_C2_ext.csv',
       'pa_rec0_C2_int.csv',
       'pa_mon_C1_ext.csv',
       'pa_mon_C2_ext.csv',
       'pa_mon_C2_int.csv'
   ]
   ```

5. **RAM Size Configuration**: Memory sizes for different CPUs and memory types:
   ```python
   TOTAL_RAM_PER_CPU = {
       ('cpu1', 'ext'): 152832,   # Bytes
       ('cpu2', 'ext'): 3072000,
       ('cpu2', 'int'): 32576
   }
   EXTERNAL_TOTAL_RAM = 4194304   # Bytes
   ```

6. **External Tool Path**: Path to the TI demangler tool is defined in `user_paths.py`:
   ```python
   DEMANGLER_PATH = r'C:\Users\pgd4\scoop\apps\CodeComposerStudio\9.2.0.00013\ccs920\ccs\tools\compiler\ti-cgt-c2000_22.6.1.LTS\bin\dem2000.exe'
   ```

## Execution Pipeline

The memory analysis workflow consists of the following sequential steps:

### 1. Directory Preparation (`make_output_dirs`)

This function creates the necessary output directories for the analysis:
- Removes any existing output directories from previous executions
- Creates fresh directories for demangled files, RAM data, and output figures
- Creates subdirectories for different types of visualizations (flash, allocators, RAM)

```python
def make_output_dirs():
    # Remove directories from past executions
    if os.path.exists(OUTPUT_DEMANGLED_DIR):
        shutil.rmtree(OUTPUT_DEMANGLED_DIR)
    if os.path.exists(OUTPUT_RAM_DATA_DIR):
        shutil.rmtree(OUTPUT_RAM_DATA_DIR)
    if os.path.exists(OUTPUT_FIG_DIR):
        shutil.rmtree(OUTPUT_FIG_DIR)
    os.makedirs(OUTPUT_DEMANGLED_DIR)
    os.makedirs(OUTPUT_RAM_DATA_DIR)
    os.makedirs(os.path.join(OUTPUT_FIG_DIR, 'flash'))
    for pa_mode in PA_MODES:
        os.makedirs(os.path.join(OUTPUT_FIG_DIR, '_'.join(['allocators', pa_mode])))
        os.makedirs(os.path.join(OUTPUT_FIG_DIR, '_'.join(['external_ram', pa_mode])))
        os.makedirs(os.path.join(OUTPUT_FIG_DIR, '_'.join(['internal_ram_cpu1', pa_mode])))
        os.makedirs(os.path.join(OUTPUT_FIG_DIR, '_'.join(['internal_ram_cpu2', pa_mode])))
```

### 2. Demangling Map Files (`run_demangler`)

This function processes the map files from CCS projects:
- Locates the `.map` files for each CCS project in the `SW_ASTRO_DIR` directory
- Runs the TI demangler tool on each map file to produce demangled output (`.dem` files)
- Stores the demangled files in the `OUTPUT_DEMANGLED_DIR` directory

```python
def run_demangler():
    # Find .map of each CCS project in sw_Astro directory
    project_map_paths = [find_file(css_project + '.map', SW_ASTRO_DIR) for (css_project, name) in CCS_PROJECT_AND_IDENTIFYING_NAME]
    for ((css_project, name), map_path) in zip(CCS_PROJECT_AND_IDENTIFYING_NAME, project_map_paths):
        if not map_path is None:
            # Use an identifying name for the demangled output (to avoid '1x' of the CSS project)
            demangled_output_path = os.path.join(OUTPUT_DEMANGLED_DIR, name + '.dem')
            # Run the demangler process
            args_list = [DEMANGLER_PATH,
                         '--abi=eabi',
                         '--output=' + demangled_output_path,
                         map_path]
            subprocess.Popen(args_list).communicate()
        else:
            print('ERROR: Could not find the *.map file of project \"' + css_project + '\" to run the demangler.')
```

### 3. Extracting Memory Sections (`run_demangled_extract`)

This function extracts specific memory sections from the demangled files:
- Processes each demangled file to extract `.bss`, `.data`, `.text`, and `.const` sections
- Uses the `demangled_extract.py` script to perform the extraction
- Creates separate files for each section with appropriate separators

```python
def run_demangled_extract():
    for (section, separator) in DEMANGLED_SECTIONS_AND_SEPARATORS:
        for (css_project, name) in CCS_PROJECT_AND_IDENTIFYING_NAME:
            demangled_input_path = os.path.join(OUTPUT_DEMANGLED_DIR, name + '.dem')
            if os.path.isfile(demangled_input_path):
                script_path = os.path.join(SCRIPTS_DIR, 'demangled_extract.py')
                # Use an identifying name for the demangled sections output
                demangled_output_path = os.path.join(OUTPUT_DEMANGLED_DIR, name + section)
                args_list = ['python',
                             script_path,
                             section,
                             demangled_input_path,
                             demangled_output_path,
                             separator]
                subprocess.Popen(args_list).communicate()
```

### 4. Processing Allocated Memory Data (`run_process_alloc_data`)

This function processes the allocated memory files from SIL execution:
- Reads the CSV files generated by the instrumented `Allocator` class in the SIL execution
- Uses the `process_alloc_data.py` script to process each file
- Formats the filenames for consistency and stores the processed data in the `OUTPUT_RAM_DATA_DIR` directory

```python
def run_process_alloc_data():
    for allocated_ram_filename in ALLOCATED_RAM_FILENAMES:
        allocated_ram_input_path = os.path.join(SIL_EXEC_DIR, allocated_ram_filename)
        if os.path.isfile(allocated_ram_input_path):
            script_path = os.path.join(SCRIPTS_DIR, 'process_alloc_data.py')
            # Each allocated memory file is copied to OUTPUT_RAM_DATA_DIR by process_alloc_data.py, and used as inputs
            # in future steps. It is convenient to format these files names
            allocated_ram_output_filename = format_allocated_ram_filename(allocated_ram_filename)
            allocated_ram_output_path = os.path.join(OUTPUT_RAM_DATA_DIR, allocated_ram_output_filename)
            args_list = ['python',
                         script_path,
                         allocated_ram_input_path,
                         allocated_ram_output_path]
            subprocess.Popen(args_list).communicate()
```

### 5. Generating Flash Memory Charts (`run_generate_pie_chart_flash_raw`)

This function generates pie charts for flash memory usage:
- Uses the demangled files and extracted `.text` and `.const` sections
- Runs the `generate_pie_chart_flash_raw.py` script to create visualizations
- Outputs CSV data and SVG charts in the `OUTPUT_FIG_DIR/flash` directory

```python
def run_generate_pie_chart_flash_raw():
    for (css_project, name) in CCS_PROJECT_AND_IDENTIFYING_NAME:
        demangled_input_path = os.path.join(OUTPUT_DEMANGLED_DIR, name + '.dem')
        text_input_path = os.path.join(OUTPUT_DEMANGLED_DIR, name + '.text')
        const_input_path = os.path.join(OUTPUT_DEMANGLED_DIR, name + '.const')
        if os.path.isfile(demangled_input_path) and \
           os.path.isfile(text_input_path) and \
           os.path.isfile(const_input_path):
            script_path = os.path.join(SCRIPTS_DIR, 'generate_pie_chart_flash_raw.py')
            output_dir = os.path.join(OUTPUT_FIG_DIR, 'flash')
            args_list = ['python',
                         script_path,
                         demangled_input_path,
                         text_input_path,
                         const_input_path,
                         output_dir,
                         name]
            subprocess.Popen(args_list).communicate()
```

### 6. Generating RAM Sections Charts (`run_generate_pie_chart_ram_sections`)

This function generates pie charts for RAM memory sections:
- Processes demangled files to extract RAM section information
- Runs the `generate_pie_chart_ram_sections.py` script
- Creates visualizations for external memory sections
- In practice, this is only used for CPU2

```python
def run_generate_pie_chart_ram_sections(cpu):
    for (css_project, name) in CCS_PROJECT_AND_IDENTIFYING_NAME:
        if cpu in name:
            demangled_input_path = os.path.join(OUTPUT_DEMANGLED_DIR, name + '.dem')
            if os.path.isfile(demangled_input_path):
                script_path = os.path.join(SCRIPTS_DIR, 'generate_pie_chart_ram_sections.py')
                args_list = ['python',
                             script_path,
                             str(EXTERNAL_TOTAL_RAM),
                             demangled_input_path,
                             name,
                             OUTPUT_FIG_DIR]
                subprocess.Popen(args_list).communicate()
```

### 7. Generating Allocator Usage Charts (`run_generate_pie_chart_ram2`)

This function generates pie charts for allocator memory usage:
- Processes the allocated memory data files in `OUTPUT_RAM_DATA_DIR`
- Determines the total RAM size based on CPU and memory type
- Runs the `generate_pie_chart_ram2.py` script to create visualizations
- Outputs text data and SVG charts in the `OUTPUT_FIG_DIR/allocators_<mode>` directories

```python
def run_generate_pie_chart_ram2():
    for allocated_ram_filename in os.listdir(OUTPUT_RAM_DATA_DIR):
        allocated_ram_input_path = os.path.join(OUTPUT_RAM_DATA_DIR, allocated_ram_filename)
        # Get the corresponding RAM value in TOTAL_RAM_PER_CPU if the cpu and ram_type matches with the ones in allocated_ram_filename
        total_ram = [ram for ((cpu, ram_type), ram) in TOTAL_RAM_PER_CPU.items() if cpu in allocated_ram_filename and ram_type in allocated_ram_filename].pop()
        # Get the allocator output directory if the pa_mode matches with the one in allocated_ram_filename
        output_dir = os.path.join(OUTPUT_FIG_DIR, ['allocators_' + pa_mode for pa_mode in PA_MODES if pa_mode in allocated_ram_filename].pop())
        script_path = os.path.join(SCRIPTS_DIR, 'generate_pie_chart_ram2.py')
        args_list = ['python',
                     script_path,
                     allocated_ram_input_path,
                     output_dir,
                     str(total_ram)]
        subprocess.Popen(args_list).communicate()
```

### 8. Generating External RAM Charts (`run_generate_pie_chart_external_ram`)

This function generates pie charts for external RAM usage:
- Combines data from external memory sections, allocated memory, and demangled `.bss` and `.data` sections
- Runs the `generate_pie_chart_external_ram.py` script
- Creates visualizations for external RAM usage
- In practice, this is only used for CPU2 external memory

```python
def run_generate_pie_chart_external_ram(cpu, ram_type):
    for pa_mode in PA_MODES:
        name = '_'.join([cpu, pa_mode])
        external_memory_sections_path = os.path.join(OUTPUT_FIG_DIR, '_'.join(['external_memory_sections', name]) + '.csv')
        allocated_ram_path = os.path.join(OUTPUT_FIG_DIR, '_'.join(['allocators', pa_mode]), '_'.join([name, ram_type]) + '.txt')
        demangled_bss_section_path = os.path.join(OUTPUT_DEMANGLED_DIR, name + '.bss')
        demangled_data_section_path = os.path.join(OUTPUT_DEMANGLED_DIR, name + '.data')
        if os.path.isfile(external_memory_sections_path) and \
           os.path.isfile(allocated_ram_path) and \
           os.path.isfile(demangled_bss_section_path) and \
           os.path.isfile(demangled_data_section_path):
            script_path = os.path.join(SCRIPTS_DIR, 'generate_pie_chart_external_ram.py')
            output_dir = os.path.join(OUTPUT_FIG_DIR, '_'.join(['external_ram', pa_mode]))
            args_list = ['python',
                         script_path,
                         external_memory_sections_path,
                         allocated_ram_path,
                         demangled_bss_section_path,
                         demangled_data_section_path,
                         output_dir,
                         name,
                         str(EXTERNAL_TOTAL_RAM)]
            subprocess.Popen(args_list).communicate()
```

### 9. Generating Internal RAM Charts (`run_generate_pie_chart_internal_ram`)

This function generates pie charts for internal RAM usage:
- Processes allocated memory data and demangled files
- Uses different scripts for CPU1 and CPU2 (`generate_pie_chart_internal_ram_c1.py` and `generate_pie_chart_internal_ram_c2.py`)
- Creates visualizations for internal RAM usage for each CPU and PA mode

```python
def run_generate_pie_chart_internal_ram(cpu, ram_type, script):
    for pa_mode in PA_MODES:
        name = '_'.join([cpu, pa_mode])
        allocated_ram_path = os.path.join(OUTPUT_FIG_DIR, '_'.join(['allocators', pa_mode]), '_'.join([name, ram_type]) + '.txt')
        demangled_path = os.path.join(OUTPUT_DEMANGLED_DIR, name + '.dem')
        if os.path.isfile(allocated_ram_path) and \
           os.path.isfile(demangled_path):
            script_path = os.path.join(SCRIPTS_DIR, script)
            output_dir = os.path.join(OUTPUT_FIG_DIR, '_'.join(['internal_ram', name]))
            args_list = ['python',
                         script_path,
                         allocated_ram_path,
                         demangled_path,
                         output_dir,
                         name]
            subprocess.Popen(args_list).communicate()
```

## Main Execution Flow

The `main()` function orchestrates the entire workflow by calling each step in sequence:

```python
def main():
    print('\n### Step make_output_dirs')
    make_output_dirs()
    print('\n### Step run_demangler')
    run_demangler()
    print('\n### Step run_demangled_extract')
    run_demangled_extract()
    print('\n### Step run_process_alloc_data')
    run_process_alloc_data()
    print('\n### Step run_generate_pie_chart_flash_raw')
    run_generate_pie_chart_flash_raw()
    print('\n### Step run_generate_pie_chart_ram_sections')
    run_generate_pie_chart_ram_sections('cpu2')
    print('\n### Step run_generate_pie_chart_ram2')
    run_generate_pie_chart_ram2()
    print('\n### Step run_generate_pie_chart_external_ram')
    run_generate_pie_chart_external_ram('cpu2', 'ext')
    print('\n### Step run_generate_pie_chart_internal_ram_c2')
    run_generate_pie_chart_internal_ram('cpu2', 'int', 'generate_pie_chart_internal_ram_c2.py')
    print('\n### Step run_generate_pie_chart_internal_ram_c1')
    run_generate_pie_chart_internal_ram('cpu1', 'ext', 'generate_pie_chart_internal_ram_c1.py')
```

## Utility Functions

The system includes several utility functions to support the main workflow:

### 1. File Finder (`find_file`)

Recursively searches for a file in a directory:

```python
def find_file(name, search_dir):
    for root, dirs, files in os.walk(search_dir):
        if name in files:
            return os.path.join(root, name)
```

### 2. Filename Formatter (`format_allocated_ram_filename`)

Standardizes the naming of allocated RAM files:

```python
def format_allocated_ram_filename(filename):
    filename = filename.replace('pa_rec', 'par').replace('pa_mon', 'pam')
    filename = 'cpu1_' + filename.replace('C1_', '') if 'C1_' in filename else filename
    filename = 'cpu2_' + filename.replace('C2_', '') if 'C2_' in filename else filename
    return filename
```

## Environment Setup Requirements

According to the `readme.md`, the system requires:

1. **TI Compilation**:
   - Full compilation in Code Composer Studio to generate `.map` files for all six projects

2. **Eclipse Compilation and Execution**:
   - 32-bit compilation in Eclipse
   - Execution of SIL with instrumented `Allocator` class
   - Three separate executions: `AstroLinux_mon`, `AstroLinux_rec0`, and `AstroLinux_rec1`
   - Generation of nine CSV files with allocation data

3. **Analysis Execution**:
   - Update of paths in `user_paths.py`
   - Execution of `main.py`
   - Optional: LaTeX compilation of `mem_analysis.tex` to generate a PDF report

## Processing Scripts

The system uses several Python scripts in the `scripts` directory to process data and generate visualizations:

1. `demangled_extract.py`: Extracts specific memory sections from demangled files
2. `process_alloc_data.py`: Processes allocated memory data from SIL execution
3. `generate_pie_chart_flash_raw.py`: Generates flash memory usage visualizations
4. `generate_pie_chart_ram_sections.py`: Generates RAM section visualizations
5. `generate_pie_chart_ram2.py`: Generates allocator usage visualizations
6. `generate_pie_chart_external_ram.py`: Generates external RAM usage visualizations
7. `generate_pie_chart_internal_ram_c1.py`: Generates CPU1 internal RAM usage visualizations
8. `generate_pie_chart_internal_ram_c2.py`: Generates CPU2 internal RAM usage visualizations

## Referenced Context Files

The following context files were helpful in understanding the memory analysis system:

- `PA/main.py`: The main script that orchestrates the entire memory analysis workflow
- `PA/user_paths.py`: Contains the path to the TI demangler tool
- `readme.md`: Provides instructions for setting up the environment and running the analysis

## Conclusion

The memory analysis system is a comprehensive workflow that processes compiled outputs from TI Code Composer Studio and Eclipse to generate detailed memory usage reports and visualizations. It analyzes memory usage across different CPUs (CPU1 and CPU2) and operating modes (par0, par1, and pam) of the ASTRO software system. The system generates various visualizations for flash memory, external RAM, internal RAM, and allocator usage, providing a complete picture of memory utilization in the ASTRO system.