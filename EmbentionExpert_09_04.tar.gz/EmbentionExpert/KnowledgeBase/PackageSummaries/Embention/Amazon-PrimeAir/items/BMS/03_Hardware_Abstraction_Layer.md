# Generated from:

- items/sw_BMS/code/BMS/code/include/GPIO_config.h (911 tokens)
- items/sw_BMS/code/BMS/code/include/Halsuite_bms.h (848 tokens)
- items/sw_BMS/code/BMS/code/include/HWversion.h (274 tokens)
- items/sw_BMS/code/BMS/code/include/Xpccan_suite_bms.h (909 tokens)
- items/sw_BMS/code/BMS/code/include/Xpccan_trait_bms.h (566 tokens)
- items/sw_BMS/code/BMS/code/include/Xpcu8_suite_bms.h (389 tokens)
- items/sw_BMS/code/BMS/code/include/Xpcu8_trait_bms.h (657 tokens)
- items/sw_BMS/code/BMS/code/source/Halsuite_bms.cpp (2096 tokens)
- items/sw_BMS/code/BMS/code/source/HWversion.cpp (651 tokens)
- items/sw_BMS/code/BMS/code/source/Xpccan_suite_bms.cpp (747 tokens)
- items/sw_BMS/code/BMS/code/source/Xpcu8_suite_bms.cpp (855 tokens)
- items/sw_BMS/code/BMS-ccard/code/source/GPIO_ccard.cpp (778 tokens)
- items/sw_BMS/code/BMS-cpu1/code/source/GPIO_cpu1.cpp (608 tokens)

## With context from:

- PackageSummaries/Amazon-PrimeAir/items/BMS/05_BMS_Core_Architecture.md (3407 tokens)

---

# Hardware Abstraction Layer (HAL) of the BMS System

## 1. Functional Behavior and Logic

### GPIO Configuration System

The BMS system implements a comprehensive GPIO configuration system through the `GPIO_config` structure, which provides a centralized definition of all GPIO pins and their associated MUX configurations. This structure serves as a hardware abstraction layer that isolates the application code from the specific hardware pin assignments.

Key responsibilities:
- Defines constants for all GPIO pins used in the BMS system
- Provides MUX configuration constants for peripherals (CAN, SCI, I2C)
- Supports different hardware variants through separate implementation files

The GPIO configuration is implemented differently for different hardware variants:
- `GPIO_cpu1.cpp` - Implements pin mappings for the CPU1 hardware variant
- `GPIO_ccard.cpp` - Implements pin mappings for the CCARD hardware variant

### Halsuite Class: Unified Hardware Interface

The `Halsuite` class serves as the primary hardware abstraction layer for the BMS system, providing a unified interface to all hardware peripherals. It follows the singleton pattern to ensure a single point of access to hardware resources.

Key responsibilities:
- Initializes and configures all hardware peripherals
- Provides access to communication interfaces (CAN, SCI, I2C)
- Manages LED indicators for system status
- Handles hardware version detection
- Provides polling mechanism for communication peripherals
- Manages global interrupt enabling

The `Halsuite` constructor performs comprehensive hardware initialization:
1. Configures all LED GPIOs as outputs
2. Configures override MCU pin as output and sets it high
3. Configures charger output pin as output and sets it high
4. Configures BQ wake-up GPIOs as outputs
5. Configures MCAN-A (CAN FD) GPIOs
6. Configures all SCI (UART) GPIOs
7. Configures I2C-A GPIOs
8. Configures SCI-A for debug UART (115200 baud, 8-bit data, 1 stop bit, no parity)
9. Configures SCI-B, C, and D for BQ communication (1Mbps, 8-bit data, 2 stop bits, no parity)
10. Configures CAN-FD peripheral

### Hardware Version Detection

The `HWversion` class provides functionality to detect and manage hardware versions. It uses both GPIO pins and OTP (One-Time Programmable) memory to determine the hardware version.

Key responsibilities:
- Reads board revision ID from dedicated GPIOs
- Reads hardware version from OTP memory
- Reconciles hardware version information from both sources
- Provides a singleton interface to access the hardware version

Hardware version detection flow:
1. Configure board revision GPIOs as inputs
2. Read the state of the four board revision pins
3. If the pattern matches {1,0,0,0}, set hardware version to `v_bms`
4. Read the hardware version from OTP memory
5. If OTP version matches GPIO-derived version, use that version
6. Assert an error if the final hardware version is unknown

## 2. Control Flow and State Transitions

### Hardware Initialization Flow

The hardware initialization flow is managed by the `Halsuite` constructor:

1. **GPIO Configuration**:
   - Configure LED pins as outputs
   - Configure override MCU pin as output and set high
   - Configure charger output pin as output and set high
   - Configure BQ wake-up pins as outputs

2. **Communication Interface Configuration**:
   - Configure MCAN (CAN FD) pins with appropriate MUX settings
   - Configure SCI (UART) pins for all four interfaces
   - Configure I2C pins

3. **Peripheral Configuration**:
   - Configure SCI-A for debug UART (115200 baud)
   - Configure SCI-B, C, D for BQ communication (1Mbps)
   - Configure CAN-FD peripheral

4. **Interrupt Configuration**:
   - Enable global interrupts when `enable_global_isr()` is called
   - Enable real-time debug interrupts

### Hardware Version Detection Flow

The hardware version detection flow is implemented in `HWversion::get_hwversion()`:

1. Read board revision ID from GPIOs
2. If a valid board revision is detected:
   - Read UID from OTP memory
   - If UID hardware version matches board revision, use that version
3. Assert an error if the final hardware version is unknown
4. Return the detected hardware version

## 3. Inputs and Stimuli

### GPIO Inputs

The BMS system uses several GPIO pins as inputs:

- **Board Revision ID** (`brbdid0`, `brbdid1`, `brbdid2`, `brbdid3`): Used to identify the hardware version
- **Interlock** (`lock_over`): Used as an input for interlock status
- **BQ Fault Lines** (`bq1_fault`, `bq2_fault`, `bq3_fault`): Used to detect fault conditions from BQ chips
- **Power Good** (`power_good`): Used to detect power status
- **Charger Input** (`charger_in`): Used to detect charger status

These inputs are processed by configuring the pins as inputs and reading their state through the GPIO interface.

### Communication Inputs

The BMS system receives data through multiple communication interfaces:

- **CAN-FD** (`cana_fd`): Receives CAN frames through the MCAN peripheral
- **SCI (UART)** (`scia`, `scib`, `scic`, `scid`): Receives serial data through four UART interfaces
- **I2C** (`i2ca`): Receives I2C data through the I2C-A interface

These inputs are processed through the respective peripheral drivers and buffered through port buffers (for SCI) or managed through dedicated managers (for CAN and I2C).

## 4. Outputs and Effects

### GPIO Outputs

The BMS system uses several GPIO pins as outputs:

- **LED Indicators** (`led_notification`, `led_status`, `led_error`, `led_bootloader`, `led_debug`, `led_warning`): Used to indicate system status
- **Override MCU** (`overd_mcu`): Used to force powering MCU
- **Charger Output** (`charger_out`): Used to control the charger
- **BQ Wake-up Lines** (`bq1_wakeup`, `bq2_wakeup`, `bq3_wakeup`): Used to wake up BQ chips
- **CAN Termination** (`mcan_en`): Used to enable CAN termination

These outputs are controlled by configuring the pins as outputs and setting their state through the GPIO interface.

### Communication Outputs

The BMS system sends data through multiple communication interfaces:

- **CAN-FD** (`cana_fd`): Sends CAN frames through the MCAN peripheral
- **SCI (UART)** (`scia`, `scib`, `scic`, `scid`): Sends serial data through four UART interfaces
- **I2C** (`i2ca`): Sends I2C data through the I2C-A interface

These outputs are managed through the respective peripheral drivers and buffered through port buffers (for SCI) or managed through dedicated managers (for CAN and I2C).

## 5. Parameters and Configuration

### GPIO Configuration Parameters

The `GPIO_config` structure defines constants for all GPIO pins and MUX configurations:

| Parameter | Type | Description | Location |
|-----------|------|-------------|----------|
| `mcan_mux` | `GPIOtun::Mux` | CAN MUX configuration | `GPIO_config.h` |
| `mcan_tx` | `GPIOid` | MCAN-TX pin | `GPIO_config.h` |
| `mcan_rx` | `GPIOid` | MCAN-RX pin | `GPIO_config.h` |
| `mcan_en` | `GPIOid` | MCAN enable pin | `GPIO_config.h` |
| `mcan_stdby` | `GPIOid` | MCAN stand-by pin | `GPIO_config.h` |
| `scia_mux` | `GPIOtun::Mux` | SCI-A MUX configuration | `GPIO_config.h` |
| `scia_tx` | `GPIOid` | Debug UART TX pin | `GPIO_config.h` |
| `scia_rx` | `GPIOid` | Debug UART RX pin | `GPIO_config.h` |
| ... | ... | ... | ... |

### Communication Interface Configuration

The `Halsuite` constructor configures communication interfaces with specific parameters:

- **SCI-A (Debug UART)**:
  - Baud rate: 115200
  - Data length: 8 bits
  - Stop bits: 1
  - Parity: None

- **SCI-B, C, D (BQ Communication)**:
  - Baud rate: 1000000 (1Mbps)
  - Data length: 8 bits
  - Stop bits: 2
  - Parity: None

- **CAN-FD**:
  - Arbitration bit rate: 1Mbps
  - Data bit rate: 1Mbps
  - Automatic retransmission: Disabled
  - Bus monitoring: Disabled

### Buffer Sizes

The `Halsuite` class defines buffer sizes for communication interfaces:

- **SCI Port Buffers**: 64 bytes for each SCI port (`common_sci_sz`)

## 6. Error Handling and Contingency Logic

### Hardware Version Detection Error Handling

The `HWversion::get_hwversion()` method includes error handling for unknown hardware versions:

```cpp
Base::Assertions::runtime(hwv != v_unknown);
```

This assertion ensures that the system fails if the hardware version cannot be determined, preventing operation with unknown hardware.

### GPIO Configuration Safety

The GPIO configuration system uses type-safe constants and dedicated configuration methods to ensure correct pin configuration:

- `GPIOioctl::apply_output()`: Configures a pin as output with safe defaults
- `GPIOioctl::apply_input()`: Configures a pin as input with safe defaults
- `GPIOioctl::apply()`: Configures a pin with specific parameters

These methods ensure that pins are configured correctly and consistently across the system.

### Interrupt Safety

The `Halsuite::enable_global_isr()` method provides a controlled way to enable interrupts:

1. Enable Global interrupt INTM using `asm_eint()`
2. Enable Global realtime interrupt DBGM using `asm_ertm()`
3. Enable real-time debug interrupt with value 1 using `set_dbgier(1)`

This ensures that interrupts are enabled in the correct sequence and with the appropriate configuration.

## 7. File-by-File Breakdown

### GPIO_config.h

This header file defines the `GPIO_config` structure, which contains constants for all GPIO pins and MUX configurations used in the BMS system. It serves as a central repository for GPIO pin assignments, making it easy to adapt the code to different hardware variants.

Key elements:
- Constants for CAN-A FD (MCAN) pins and MUX
- Constants for SCI (UART) pins and MUX for all four interfaces
- Constants for LED indicator pins
- Constants for interlock and override pins
- Constants for I2C pins and MUX
- Constants for BQ wake-up and fault pins
- Constants for board revision ID pins
- Constants for charger control pins

### Halsuite_bms.h

This header file defines the `Halsuite` class, which serves as the primary hardware abstraction layer for the BMS system. It provides a unified interface to all hardware peripherals and manages their initialization and configuration.

Key elements:
- `Halsuite` class definition with hardware peripherals as member variables
- Type definitions for port buffers and other hardware-related types
- Method declarations for hardware initialization and management
- Singleton pattern implementation for global access to hardware resources

### HWversion.h

This header file defines the `HWversion` class and related enumerations for hardware version detection and management. It provides functionality to detect the hardware version from both GPIO pins and OTP memory.

Key elements:
- `HWversion_id` enumeration defining possible hardware versions
- `HWversion` class definition with static methods for hardware version detection
- Method declarations for hardware version retrieval

### Xpccan_suite_bms.h

This header file defines the `Xpccan_suite` class, which implements the cross-connect CAN stream producer/consumer functionality for the BMS system. It manages the flow of CAN frames between different components of the system.

Key elements:
- `Xpccan_suite` class definition with methods for task execution
- Type definitions for CAN producers and consumers
- Method declarations for high-priority and low-priority tasks
- Integration with the Cyphal communication system

### Xpccan_trait_bms.h

This header file defines the `Xpccan_trait` structure, which provides trait definitions for the `Xpccan_suite` class. It defines the types, sizes, and identifiers used in the CAN cross-connect system.

Key elements:
- Type definitions for CAN frame transfers
- Constants for transfer sizes and rates
- Enumeration of producer and consumer identifiers
- Transfer policy definitions

### Xpcu8_suite_bms.h

This header file defines the `Xpcu8_suite` structure, which implements the cross-connect byte stream producer/consumer functionality for the BMS system. It manages the flow of byte data between different components of the system.

Key elements:
- `Xpcu8_suite` structure definition with methods for task execution
- Integration with the AFE suite and Cyphal communication system
- Method declarations for high-priority and low-priority tasks

### Xpcu8_trait_bms.h

This header file defines the `Xpcu8_trait` structure, which provides trait definitions for the `Xpcu8_suite` class. It defines the types, sizes, and identifiers used in the byte stream cross-connect system.

Key elements:
- Type definitions for byte data transfers
- Constants for transfer sizes and rates
- Enumeration of producer and consumer identifiers
- Transfer policy definitions

### Halsuite_bms.cpp

This source file implements the `Halsuite` class, providing the hardware abstraction layer functionality for the BMS system. It initializes and configures all hardware peripherals and provides methods for hardware management.

Key elements:
- Implementation of the `Halsuite` constructor for hardware initialization
- Implementation of helper functions for GPIO configuration
- Implementation of the `enable_global_isr()` method for interrupt enabling
- Implementation of the `poll()` method for communication peripheral polling
- Implementation of the singleton pattern for global access

### HWversion.cpp

This source file implements the `HWversion` class, providing functionality for hardware version detection and management. It reads hardware version information from both GPIO pins and OTP memory.

Key elements:
- Implementation of the `get_hwversion()` method for hardware version retrieval
- Implementation of the `get_board_rev()` helper function for reading board revision from GPIOs
- Logic for reconciling hardware version information from different sources

### Xpccan_suite_bms.cpp

This source file implements the `Xpccan_suite` class, providing the cross-connect CAN stream producer/consumer functionality for the BMS system. It manages the flow of CAN frames between different components.

Key elements:
- Implementation of the `Xpccan_suite` constructor for initializing the CAN cross-connect system
- Implementation of the `step()` method for low-priority task execution
- Implementation of the `step_hi()` method for high-priority task execution
- Implementation of the `get_vars()` method for retrieving CAN rate variables

### Xpcu8_suite_bms.cpp

This source file implements the `Xpcu8_suite` structure, providing the cross-connect byte stream producer/consumer functionality for the BMS system. It manages the flow of byte data between different components.

Key elements:
- Implementation of the `Xpcu8_suite` constructor for initializing the byte stream cross-connect system
- Implementation of the `step()` method for low-priority task execution
- Implementation of the `step_hi()` method for high-priority task execution
- Configuration of producer/consumer bindings for data flow

### GPIO_ccard.cpp and GPIO_cpu1.cpp

These source files implement the `GPIO_config` structure for different hardware variants (CCARD and CPU1). They provide the specific pin assignments for each hardware variant.

Key elements:
- Implementation of GPIO pin constants for the specific hardware variant
- Implementation of MUX configuration constants for the specific hardware variant
- Comments indicating the physical pin numbers for reference

## 8. Cross-Component Relationships

### Hardware Abstraction Layer Integration

The `Halsuite` class integrates with other components through the singleton pattern:

```cpp
Halsuite& Halsuite::get_instance()
{
    static Halsuite hal;
    return hal;
}
```

This allows other components to access hardware resources through a single, globally accessible instance:

```cpp
Halsuite& hal = Halsuite::get_instance();
```

### Cross-Connect Producer/Consumer Architecture

The BMS system implements a cross-connect producer/consumer architecture for data transfer between components. This architecture is implemented through the `Xpccan_suite` and `Xpcu8_suite` classes.

#### CAN Frame Transfer

The `Xpccan_suite` class manages the transfer of CAN frames between producers and consumers:

1. Producers generate CAN frames (e.g., from input filters or Cyphal)
2. Consumers receive CAN frames (e.g., output filters)
3. The `Xpccan_suite` class binds producers to consumers and manages the transfer of frames

Producer-Consumer bindings for CAN frames:
- `Xpccan_trait::XP::cyphalcan_out` → `Xpccan_trait::XC::can_out_filt0` (high priority)

#### Byte Stream Transfer

The `Xpcu8_suite` class manages the transfer of byte streams between producers and consumers:

1. Producers generate byte streams (e.g., from SCI ports or AFE managers)
2. Consumers receive byte streams (e.g., SCI ports or AFE managers)
3. The `Xpcu8_suite` class binds producers to consumers and manages the transfer of data

Producer-Consumer bindings for byte streams:
- `Xpcu8_trait::XP::afe1` → `Xpcu8_trait::XC::scib` (high priority)
- `Xpcu8_trait::XP::scib` → `Xpcu8_trait::XC::afe1` (high priority)
- `Xpcu8_trait::XP::afe2` → `Xpcu8_trait::XC::scic` (high priority)
- `Xpcu8_trait::XP::scic` → `Xpcu8_trait::XC::afe2` (high priority)
- `Xpcu8_trait::XP::afe3` → `Xpcu8_trait::XC::scid` (high priority)
- `Xpcu8_trait::XP::scid` → `Xpcu8_trait::XC::afe3` (high priority)
- `Xpcu8_trait::XP::cyphal_p` → `Xpcu8_trait::XC::cyphal_c` (high priority)

### Hardware Version Integration

The hardware version detection system integrates with the rest of the BMS system through the `HWversion` class:

1. The `Halsuite` class includes a `hwv` member variable of type `HWversion_id`
2. This variable is initialized by calling `HWversion::get_hwversion()`
3. Other components can access the hardware version through the `Halsuite` instance

## 9. Referenced Context Files

The following context file provided useful information for understanding the BMS architecture:

- `05_BMS_Core_Architecture.md`: This file provided an overview of the BMS system architecture, including the role of the `Battery_manager` class as the central controller, the `BMS_suite` class as the component coordinator, and the task scheduling and execution model. It helped to understand how the hardware abstraction layer fits into the overall system architecture.

## Summary

The Hardware Abstraction Layer (HAL) of the BMS system provides a comprehensive interface to the underlying hardware, isolating the application code from the specific hardware details. It includes:

1. **GPIO Configuration System**: A centralized definition of all GPIO pins and their MUX configurations, with support for different hardware variants.

2. **Halsuite Class**: A unified interface to all hardware peripherals, implementing the singleton pattern for global access.

3. **Hardware Version Detection**: A system for detecting and managing hardware versions based on GPIO pins and OTP memory.

4. **Cross-Connect Producer/Consumer Architecture**: A flexible system for transferring data between components, implemented through the `Xpccan_suite` and `Xpcu8_suite` classes.

The HAL ensures that the BMS system can operate correctly on different hardware variants and provides a clean, consistent interface for accessing hardware resources. It handles hardware initialization, configuration, and management, allowing the application code to focus on higher-level functionality.