# Generated from:

- items/sw_BMS/code/BMS-ccard/code/source/Kclk_ccard.cpp (54 tokens)
- items/sw_BMS/code/BMS-ccard/code/source/main.cpp (347 tokens)
- items/sw_BMS/code/BMS-cpu1/code/source/Kclk_bms.cpp (56 tokens)
- items/sw_BMS/code/BMS-cpu1/code/source/main.cpp (338 tokens)
- items/sw_BMS/code/BMS-cpu1/code/source/Sysuid_cpu1_bms.cpp (121 tokens)
- items/sw_BMS/code/BMS/code/source/BMS_28386_cpu1_no_eram.cmd (1316 tokens)
- items/sw_BMS/code/BMS/code/source/tiiw.cpp (1002 tokens)

## With context from:

- PackageSummaries/Amazon-PrimeAir/items/BMS/03_Hardware_Abstraction_Layer.md (5111 tokens)

---

# System Initialization and Configuration Process for the BMS

## 1. Functional Behavior and Logic

### System Initialization Sequence

The BMS system follows a well-defined initialization sequence that consists of pre-initialization, memory setup, post-initialization, and application startup phases. This sequence ensures proper hardware configuration and memory management before the main application begins execution.

#### Pre-Initialization Phase

The system pre-initialization is handled by the `_system_pre_init()` function, which is a C function exported externally:

```cpp
extern "C" {
    int _system_pre_init(void)
    {
        Dsp28335_ent::init_sys_cpu1_0();
        return 1;
    }
}
```

This function is called automatically by the C runtime before any global constructors are invoked. It performs the following tasks:
- Calls `Dsp28335_ent::init_sys_cpu1_0()` to initialize the CPU1 core
- Returns 1 to indicate successful initialization and allow the C runtime to continue with global initialization

#### Post-Initialization Phase

After the C runtime has initialized global variables, the `_system_post_cinit()` function is called:

```cpp
extern "C" {
    int _system_post_cinit(void)
    {
        Dsp28335_ent::post_init_sys_cpu1_sc();
        return 1;
    }
}
```

This function is called after the copy initialization (cinit) phase, where initialized data is copied from flash to RAM. At this point:
- RAM functions (ramfuncs) have been copied from flash to RAM
- The function calls `Dsp28335_ent::post_init_sys_cpu1_sc()` to perform post-initialization tasks
- Returns 1 to indicate successful post-initialization

### Memory Management Initialization

The BMS system implements a dual-allocator approach for memory management, with separate allocators for internal and external memory. The memory buffers for these allocators are defined in the main source files:

```cpp
namespace BMS {
    // Memory Manager init starts here
    static const Uint32 memmgr_int_sz = 0x1000U;  // 4KB for internal memory
    static const Uint32 memmgr_ext_sz = 0x1000U;  // 4KB for external memory
    
    #pragma RETAIN
    #pragma DATA_SECTION("MEMMGR_INT")
    Uint16 memmgr_int_buf[memmgr_int_sz];  // Memory buffer for internal memory allocator

    #pragma RETAIN
    #pragma DATA_SECTION("MEMMGR_EXT")
    Uint16 memmgr_ext_buf[memmgr_ext_sz];  // Memory buffer for external memory allocator
}
```

Key aspects of the memory management initialization:
- Two memory buffers are allocated: `memmgr_int_buf` for internal memory and `memmgr_ext_buf` for external memory
- Each buffer is 0x1000 (4096) 16-bit words in size, totaling 8KB per buffer
- The buffers are placed in specific memory sections ("MEMMGR_INT" and "MEMMGR_EXT") using the `DATA_SECTION` pragma
- The `RETAIN` pragma ensures these buffers are not optimized away by the compiler

### System Clock Configuration

The system clock configuration is hardware-variant specific and is implemented in separate files for different hardware variants:

#### For BMS-ccard variant (Kclk_ccard.cpp):
```cpp
namespace Bsp {
    void Kclk::get_sys_xtal_cfg(Uint32& freq, bool& is_crystal)
    {
        static const Uint32 xtal_freq = 25000000UL;  // 25MHz
        freq = xtal_freq;
        is_crystal = true;
    }
}
```

#### For BMS-cpu1 variant (Kclk_bms.cpp):
```cpp
namespace Bsp {
    void Kclk::get_sys_xtal_cfg(Uint32& freq, bool& is_crystal)
    {
        static const Uint32 xtal_freq = 20000000UL;  // 20MHz
        freq = xtal_freq;
        is_crystal = true;
    }
}
```

The key differences between the hardware variants:
- BMS-ccard uses a 25MHz crystal oscillator
- BMS-cpu1 uses a 20MHz crystal oscillator
- Both variants use a crystal (not an RC oscillator) as indicated by `is_crystal = true`

### System Unique Identifier (UID) Retrieval

The system UID is retrieved from One-Time Programmable (OTP) memory and provides a unique identifier for the BMS system. The implementation is in `Sysuid_cpu1_bms.cpp`:

```cpp
namespace Bsp {
    namespace {
        // Retrieve UID64 from OTP
        Uid64 get_uid_aux()
        {
            Uid64 otp_uid = { 0 };
            // TODO: Determine this values depending on the hardware.
            otp_uid.app = Bsp::sapp_bms;
            otp_uid.phy = 12345;
            return otp_uid;
        }
    }

    Uid64 get_uid()
    {
        static const Uid64 otp_uid = get_uid_aux();
        return otp_uid;
    }
}
```

Key aspects of the UID retrieval:
- The `get_uid_aux()` function retrieves the UID from OTP memory
- Currently, it sets placeholder values: application type to `sapp_bms` and physical ID to 12345
- The `get_uid()` function caches the UID in a static variable for efficient retrieval
- The implementation includes a TODO note indicating that the actual values should be determined based on the hardware

### Application Integrity Check

The BMS system implements an application integrity check mechanism to verify the integrity of the application code. This is implemented in the main source files:

```cpp
static const Uint32 g_app_size[1] = { 0x0010000*2 }; // Total flash(0x40000) - bootloader(0x8000)
static const Uint32 g_app_crc[1]  = { 0x72bb9217 };

void main()
{
    if((g_app_size[0] + g_app_crc[0] == 0))
    {
        Bsp::warning();
    }
    
    // Continue with application startup...
}
```

Key aspects of the application integrity check:
- The application size is defined as 0x20000 (128KB), calculated as total flash size (0x40000) minus bootloader size (0x8000)
- The application CRC is a predefined value (0x72bb9217)
- During startup, the system checks if the sum of application size and CRC is zero
- If the sum is zero, it indicates a potential integrity issue, and the system calls `Bsp::warning()`
- This check helps detect corrupted application images or incorrect CRC values

### Main Application Startup

After successful initialization and integrity checks, the main application starts:

```cpp
void main()
{
    if((g_app_size[0] + g_app_crc[0] == 0))
    {
        Bsp::warning();
    }

    BMS::Battery_manager* bms = Base::Memmgr::get_instance().get_allocator(Base::Memmgr::internal).allocate_new<BMS::Battery_manager>();
    bms->start();
}
```

The main application startup sequence:
1. Perform application integrity check
2. Allocate a new `Battery_manager` instance using the internal memory allocator
3. Call the `start()` method on the `Battery_manager` instance to begin BMS operations

## 2. Control Flow and State Transitions

### System Initialization Flow

The system initialization follows this sequence:

1. **Pre-Initialization**:
   - System reset occurs
   - C runtime starts
   - `_system_pre_init()` is called
   - `Dsp28335_ent::init_sys_cpu1_0()` initializes CPU1
   - Global constructors are invoked

2. **Memory Initialization**:
   - Memory sections are initialized according to the linker command file
   - RAM functions are copied from flash to RAM
   - Memory buffers for allocators are set up in their designated sections

3. **Post-Initialization**:
   - `_system_post_cinit()` is called
   - `Dsp28335_ent::post_init_sys_cpu1_sc()` performs post-initialization tasks
   - System is ready for application startup

4. **Application Startup**:
   - `main()` function is called
   - Application integrity check is performed
   - `Battery_manager` instance is allocated
   - BMS operations begin with `bms->start()`

### Memory Initialization Flow

The memory initialization process follows this sequence:

1. Memory sections are defined in the linker command file
2. During system startup, the C runtime initializes these sections
3. The memory manager buffers (`memmgr_int_buf` and `memmgr_ext_buf`) are placed in their designated sections
4. The memory manager is initialized when first accessed in `main()`
5. The internal allocator is used to allocate the `Battery_manager` instance

### System Clock Configuration Flow

The system clock configuration process:

1. During system initialization, the clock system queries the hardware-specific implementation
2. `Kclk::get_sys_xtal_cfg()` is called to get the crystal frequency and type
3. The clock system configures the PLL and other clock-related hardware based on this information
4. Different hardware variants provide different implementations of `get_sys_xtal_cfg()`

### System UID Retrieval Flow

The system UID retrieval process:

1. When `Bsp::get_uid()` is called for the first time:
   - `get_uid_aux()` is called to retrieve the UID from OTP memory
   - The UID is stored in a static variable
2. Subsequent calls to `Bsp::get_uid()` return the cached UID

## 3. Inputs and Stimuli

### System Initialization Triggers

The system initialization process is triggered by:

- **System Reset**: When the system is powered on or reset, the initialization sequence begins automatically
- **Bootloader Handoff**: When the bootloader transfers control to the application, the initialization sequence begins

### Memory Management Inputs

The memory management system responds to:

- **Allocation Requests**: When components request memory allocation through `allocate_new<T>()`
- **Deallocation Requests**: When components release memory through `deallocate()`

### System Clock Configuration Inputs

The system clock configuration is influenced by:

- **Hardware Variant**: Different hardware variants provide different crystal frequencies
- **Crystal vs. RC**: The configuration indicates whether a crystal oscillator or RC oscillator is used

## 4. Outputs and Effects

### System Initialization Effects

The system initialization process produces the following effects:

- **CPU Configuration**: The CPU is configured with appropriate settings for the BMS application
- **Memory Setup**: Memory sections are initialized and RAM functions are copied to RAM
- **Clock Configuration**: The system clock is configured based on the hardware variant
- **Application Startup**: The `Battery_manager` instance is created and started

### Memory Management Effects

The memory management initialization produces:

- **Dual Allocators**: Two memory allocators are set up, one for internal memory and one for external memory
- **Memory Buffers**: Two 8KB buffers are allocated for memory management
- **Allocation Capability**: The system can allocate memory for components like `Battery_manager`

### System Clock Configuration Effects

The system clock configuration results in:

- **Clock Frequency**: The system clock is set to the appropriate frequency (20MHz or 25MHz)
- **PLL Configuration**: The PLL is configured based on the crystal frequency
- **Peripheral Clocks**: Peripheral clocks are derived from the system clock

## 5. Parameters and Configuration

### Memory Management Parameters

| Parameter | Value | Description | Location |
|-----------|-------|-------------|----------|
| `memmgr_int_sz` | 0x1000U | Size of internal memory buffer (4KB) | main.cpp |
| `memmgr_ext_sz` | 0x1000U | Size of external memory buffer (4KB) | main.cpp |
| `MEMMGR_INT` | Section | Memory section for internal allocator | BMS_28386_cpu1_no_eram.cmd |
| `MEMMGR_EXT` | Section | Memory section for external allocator | BMS_28386_cpu1_no_eram.cmd |

### System Clock Parameters

| Parameter | Value (BMS-ccard) | Value (BMS-cpu1) | Description | Location |
|-----------|------------------|------------------|-------------|----------|
| `xtal_freq` | 25000000UL | 20000000UL | Crystal frequency in Hz | Kclk_ccard.cpp, Kclk_bms.cpp |
| `is_crystal` | true | true | Indicates crystal oscillator use | Kclk_ccard.cpp, Kclk_bms.cpp |

### Application Integrity Parameters

| Parameter | Value | Description | Location |
|-----------|-------|-------------|----------|
| `g_app_size` | 0x20000 | Application size (128KB) | main.cpp |
| `g_app_crc` | 0x72bb9217 | Application CRC | main.cpp |

## 6. Error Handling and Contingency Logic

### Application Integrity Check

The application integrity check provides a basic error detection mechanism:

```cpp
if((g_app_size[0] + g_app_crc[0] == 0))
{
    Bsp::warning();
}
```

If the sum of application size and CRC is zero, indicating a potential integrity issue, the system calls `Bsp::warning()` to handle the error condition.

### System Initialization Error Handling

The system initialization functions (`_system_pre_init()` and `_system_post_cinit()`) return integer values to indicate success or failure:

- Return value of 1 indicates successful initialization
- Return value of 0 would indicate initialization failure (though this case is not implemented)

## 7. File-by-File Breakdown

### main.cpp (BMS-ccard and BMS-cpu1)

These files contain the main entry point and initialization code for the BMS system. They are nearly identical for both hardware variants.

Key elements:
- System pre-initialization and post-initialization functions
- Memory manager buffer definitions
- Application integrity check parameters
- Main application startup sequence

The only difference between the two variants is the presence of the `RETAIN` pragma in the BMS-ccard version, which ensures the memory buffers are not optimized away by the compiler.

### Kclk_ccard.cpp and Kclk_bms.cpp

These files implement the system clock configuration for different hardware variants.

Key elements:
- `get_sys_xtal_cfg()` function that provides crystal frequency and type
- Hardware-specific crystal frequency (25MHz for BMS-ccard, 20MHz for BMS-cpu1)

### Sysuid_cpu1_bms.cpp

This file implements the system unique identifier (UID) retrieval for the BMS-cpu1 variant.

Key elements:
- `get_uid_aux()` function that retrieves the UID from OTP memory
- `get_uid()` function that caches and returns the UID
- Placeholder values for application type and physical ID

### BMS_28386_cpu1_no_eram.cmd

This is the linker command file that defines the memory layout and section allocation for the BMS system.

Key elements:
- Memory definitions for flash and RAM
- Section allocations for program code, data, and special sections
- Memory manager section definitions
- Boot loader and file system allocations

The file defines the following memory regions:
- `FLASH_PRG`: Main program flash memory
- `FLASHFS`: Flash file system
- `BOOTLOADER`: Bootloader section
- `RAMLS_PRG`: RAM for functions that run from RAM
- `IRAM`: Internal RAM for data
- `DMABUF`: DMA buffer area

And the following special sections:
- `APP_SIZE`: Application size information
- `APP_CRC`: Application CRC
- `APP_VER`: Application version
- `MEMMGR_INT`: Internal memory manager buffer
- `MEMMGR_EXT`: External memory manager buffer

### tiiw.cpp

This file implements workarounds for C++ template instantiation issues with the TI compiler.

Key elements:
- Anonymous namespace to ensure content is never used
- `Tiiw_t` structure with a `never_used()` method
- Template instantiations for various classes used in the BMS system

The file uses two workarounds:
1. Workaround 2: Not explicitly described in the file
2. Workaround 3: Not explicitly described in the file

The purpose of this file is to force the compiler to instantiate templates that might otherwise not be instantiated, preventing linker errors.

## 8. Cross-Component Relationships

### System Initialization and Memory Management

The system initialization process sets up the memory management system:
- The linker command file defines memory sections for the memory manager buffers
- The main source files define the buffer sizes and allocate the buffers
- The `main()` function uses the memory manager to allocate the `Battery_manager` instance

### System Clock and Hardware Variants

The system clock configuration is hardware-variant specific:
- Different hardware variants provide different implementations of `Kclk::get_sys_xtal_cfg()`
- The clock system uses this information to configure the PLL and other clock-related hardware

### Application Integrity and Bootloader

The application integrity check is related to the bootloader:
- The application size is calculated based on the total flash size minus the bootloader size
- The application CRC is used by the bootloader to verify the integrity of the application
- The integrity check in `main()` provides an additional layer of verification

### Memory Layout and Linker Command File

The memory layout defined in the linker command file affects various components:
- The memory manager buffers are placed in specific sections
- RAM functions are copied from flash to RAM during initialization
- The bootloader and application have designated memory regions
- The flash file system has a dedicated region

## 9. Referenced Context Files

The following context file provided useful information for understanding the BMS hardware abstraction layer:

- `03_Hardware_Abstraction_Layer.md`: This file provided information about the hardware abstraction layer of the BMS system, including the `Halsuite` class, GPIO configuration, hardware version detection, and communication interfaces. It helped understand how the system initialization process fits into the overall hardware abstraction architecture.

## Memory Layout and Section Allocation

The BMS system uses a carefully designed memory layout defined in the linker command file (`BMS_28386_cpu1_no_eram.cmd`). This layout includes:

### Flash Memory Layout

```
Flash Memory:
+------------------+ 0x080000
|   Bootloader     |
|   (0x8000)       |
+------------------+ 0x088000
|   BEGIN (2)      |
+------------------+ 0x088002
|   APP_SIZE (2)   |
+------------------+ 0x088004
|   APP_CRC (2)    |
+------------------+ 0x088006
|   APP_VER (3)    |
+------------------+ 0x088009
|                  |
|   FLASH_PRG      |
|   (Application   |
|   Code)          |
|                  |
+------------------+ 
|   FLASHFS        |
|   (File System)  |
|   (0x8000)       |
+------------------+ 0x0C0000
```

### RAM Memory Layout

```
RAM Memory:
+------------------+ 0x008000
|   RAMLS_PRG      |
|   (RAM Functions)|
|   (0x3000)       |
+------------------+ 0x00B000
|                  |
|   IRAM           |
|   (Internal RAM) |
|                  |
|   MEMMGR_INT     |
|   MEMMGR_EXT     |
|                  |
+------------------+ 
|   DMABUF         |
|   (DMA Buffers)  |
|   (64 bytes)     |
+------------------+ 0x01D000
```

This memory layout ensures efficient use of the available memory resources and proper separation between different types of data and code.

## System Initialization and Configuration Summary

The BMS system initialization and configuration process is a well-structured sequence that prepares the hardware and memory for the main application. Key aspects include:

1. **Pre-Initialization**: The `_system_pre_init()` function initializes the CPU before global constructors are invoked.

2. **Memory Management**: The system uses a dual-allocator approach with separate buffers for internal and external memory.

3. **System Clock Configuration**: Different hardware variants use different crystal frequencies (20MHz for BMS-cpu1, 25MHz for BMS-ccard).

4. **Post-Initialization**: The `_system_post_cinit()` function performs additional initialization after RAM functions are copied to RAM.

5. **System UID Retrieval**: The system retrieves a unique identifier from OTP memory.

6. **Application Integrity Check**: The system verifies the integrity of the application code using size and CRC values.

7. **Memory Layout**: The linker command file defines a detailed memory layout with specific sections for different types of code and data.

8. **Template Instantiation Workarounds**: The system includes workarounds for C++ template instantiation issues with the TI compiler.

9. **Main Application Startup**: After successful initialization, the system allocates a `Battery_manager` instance and starts BMS operations.

This initialization and configuration process ensures that the BMS system starts in a well-defined state with all necessary resources properly configured.