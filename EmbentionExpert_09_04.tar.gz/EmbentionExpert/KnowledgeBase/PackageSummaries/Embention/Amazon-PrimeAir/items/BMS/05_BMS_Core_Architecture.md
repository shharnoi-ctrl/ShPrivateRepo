# Generated from:

- items/sw_BMS/code/BMS/code/include/BMS.h (812 tokens)
- items/sw_BMS/code/BMS/code/include/BMS_report.h (793 tokens)
- items/sw_BMS/code/BMS/code/include/BMS_steps.h (219 tokens)
- items/sw_BMS/code/BMS/code/include/BMS_stats.h (745 tokens)
- items/sw_BMS/code/BMS/code/include/BMS_suite.h (840 tokens)
- items/sw_BMS/code/BMS/code/include/BMS_traits.h (1420 tokens)
- items/sw_BMS/code/BMS/code/include/BMS_varmgr.h (671 tokens)
- items/sw_BMS/code/BMS/code/include/BMS_vars.h (2518 tokens)
- items/sw_BMS/code/BMS/code/include/BMS_vtrait.h (1034 tokens)
- items/sw_BMS/code/BMS/code/source/BMS.cpp (1843 tokens)
- items/sw_BMS/code/BMS/code/source/BMS_report.cpp (2401 tokens)
- items/sw_BMS/code/BMS/code/source/BMS_stats.cpp (1343 tokens)
- items/sw_BMS/code/BMS/code/source/BMS_suite.cpp (2094 tokens)
- items/sw_BMS/code/BMS/code/source/BMS_varmgr.cpp (211 tokens)
- items/sw_BMS/code/BMS/code/source/BMS_vars.cpp (801 tokens)
- items/sw_BMS/code/BMS/code/source/Hvar_bms.cpp (1041 tokens)

---

# BMS Core Architecture Overview

## System Organization and Philosophy

The Battery Management System (BMS) is designed as a comprehensive monitoring and control system for battery packs. It follows a hierarchical architecture with clear separation between high-priority (real-time) and low-priority (background) tasks. The system is organized around several key components that work together to provide complete battery management functionality.

The architecture employs a modular design with specialized components for different aspects of battery management:
- Core management and task scheduling
- Data acquisition and processing
- Health monitoring and diagnostics
- Communication and reporting
- Statistics computation
- Configuration and parameter management

## Battery_manager Class: The Central Controller

The `Battery_manager` class serves as the central controller for the entire BMS system. It manages the execution of both high-priority and low-priority tasks, coordinates peripheral interactions, and ensures proper system initialization.

### Key Responsibilities:
- **System Initialization**: Sets up hardware, initializes components, and prepares the system for operation
- **Task Scheduling**: Manages the execution of high-priority and low-priority tasks
- **Frequency Monitoring**: Ensures tasks are executed at their required frequencies
- **Resource Management**: Coordinates access to shared resources and peripherals

### Execution Model:

#### High-Priority (Real-Time) Tasks:
- Executed at 6000 Hz (6 kHz) to ensure reliable data acquisition
- Managed through the `step_hi()` method and triggered by timer interrupts
- Handles time-critical operations like peripheral polling and data acquisition
- Designed to complete quickly to maintain system responsiveness
- Monitored for timing violations through frequency checkers

#### Low-Priority (Background) Tasks:
- Executed at 100 Hz in the main loop through the `bg_task()` method
- Handles less time-critical operations like data processing and reporting
- Includes system monitoring, stack checking, and frequency metrics
- Coordinates the execution of various subsystem tasks through the `Stepmgr`

### Task Registration and Management:
The `Battery_manager` registers various subsystem tasks with the `Stepmgr` for scheduled execution:
```cpp
smgr.add(static_cast<Stepmgr::Id>(BMS_steps::step_xpcu8), suite.xu8);
smgr.add(static_cast<Stepmgr::Id>(BMS_steps::step_xpcan), suite.xcan);
smgr.add(static_cast<Stepmgr::Id>(BMS_steps::step_afe), suite.afes);
smgr.add(static_cast<Stepmgr::Id>(BMS_steps::step_lt_mgr), suite.lt_mgr);
smgr.add(static_cast<Stepmgr::Id>(BMS_steps::step_stats), suite.stats);
smgr.add(static_cast<Stepmgr::Id>(BMS_steps::step_comm), suite.comm);
```

## BMS_suite: The Component Coordinator

The `BMS_suite` class serves as a container and coordinator for all the major subsystems of the BMS. It integrates various components and manages their interactions to provide comprehensive battery management functionality.

### Key Components:
- **Hardware Abstraction Layer (HAL)**: Provides access to hardware peripherals
- **Variables Management**: Manages system variables through `BMS_vars`
- **AFE Suite**: Interfaces with Analog Front End devices for battery measurements
- **Temperature Sensing**: Monitors temperature through TMP112 sensors
- **Cell Balancing**: Manages cell balancing to ensure uniform charge
- **State of Charge (SOC)**: Computes battery state of charge
- **Health Monitoring**: Monitors system health through `Health_monitor`
- **Communication**: Manages CAN and UART communication through `Xpccan_suite` and `Xpcu8_suite`
- **Reporting**: Handles data reporting through `BMS_report`
- **Statistics**: Computes battery statistics through `BMS_stats`
- **Non-volatile Storage**: Manages EEPROM storage through `EEPROM_24CS`
- **Lifetime Management**: Tracks battery lifetime statistics through `Lifetime_mgr`

### Task Scheduling and Frequency Management:
The `BMS_suite` implements a multi-rate task scheduling system with different components running at different frequencies:

- **Sampling Tasks (100 Hz)**:
  - Voltage sampling
  - State of Charge computation

- **Processing Tasks (10 Hz)**:
  - Temperature sampling
  - Cell balancing
  - High-priority telemetry

- **Health Tasks (5 Hz)**:
  - Statistics computation
  - Health monitoring

- **Communication Tasks (1 Hz)**:
  - PCBA temperature sampling
  - EEPROM writing
  - Low-priority telemetry

Each task group is managed by a dedicated timeout that triggers the execution of the associated tasks at the specified frequency.

### Task Execution Flow:
The `step_hi()` method handles high-priority tasks:
```cpp
void BMS_suite::step_hi() {
    afes.step_hi();         // Send pending AFE requests
    xcan.step_hi();         // Perform CAN frame transfers
    xu8.step_hi();          // Perform byte data transfers
    hal.i2ca_arb.step();    // Bulk data from/to I2C peripherals
    
    // Set overlock GPIO based on balancing or busy status
    hal.overlock.set(cbal.is_balancing() || lt_mgr.is_busy());
}
```

The `step()` method handles low-priority tasks based on timeouts:
```cpp
void BMS_suite::step() {
    if(afes.check_config()) {
        // Sampling tasks (100 Hz)
        if(tout_smpl.expired() && afes.request_cv()) {
            soc.step();
            tout_smpl.start();
        }
        
        // Processing tasks (10 Hz)
        if(tout_proc.expired() && afes.request_ct()) {
            cbal.step();
            comm.push(BMS_report::msg_battery_power);
            stats.update();
            tout_proc.start();
        }
        
        // Health tasks (5 Hz)
        if(tout_hlth.expired()) {
            hlt.step();
            tout_hlth.start();
            // Handle charger control
        }
        
        // Communication tasks (1 Hz)
        if(tout_comm.expired()) {
            comm.push(BMS_report::msg_battery_temperature);
            comm.push(BMS_report::msg_battery_summary);
            lt_mgr.save_stats();
            tout_comm.start();
            // Handle charger control
        }
    }
}
```

## BMS_vars: The Data Access Layer

The `BMS_vars` class provides a centralized access point for all battery-related data. It serves as a singleton that manages access to various system variables, including cell voltages, temperatures, currents, and state of charge.

### Key Features:
- **Singleton Pattern**: Provides global access to battery data
- **Read-Only Access**: Ensures data integrity by providing read-only access to variables
- **Structured Data Organization**: Organizes data by string (battery string) and cell
- **Type-Safe Access**: Provides type-specific access methods for different variable types

### Data Organization:
The data is organized hierarchically:
- **Pack-Level Variables**: Variables that apply to the entire battery pack
- **String-Level Variables**: Variables specific to individual battery strings
- **Cell-Level Variables**: Variables specific to individual cells within a string

### Access Methods:
The class provides various methods to access different types of data:
```cpp
// String-level data access
bool get_com_ok(Uint16 str_id) const;
Uint16 get_cv(Uint16 str_id, Uint16 cell_id) const;
Real get_ct(Uint16 str_id, Uint16 cell_id) const;
Real get_sv(Uint16 str_id) const;
Real get_sc(Uint16 str_id) const;
Real get_st(Uint16 str_id) const;
Real get_soc(Uint16 str_id) const;

// Pack-level data access
Real get_soc() const;
Real get_tmp() const;

// Statistics access
Uint16 get_smv(Uint16 str_id) const;
Uint16 get_sdv(Uint16 str_id) const;
Uint16 get_sxv(Uint16 str_id) const;
Real get_smt(Uint16 str_id) const;
Real get_sxt(Uint16 str_id) const;

// System status flags
bool get_hwv_ini() const;
bool get_swv_ini() const;
bool get_sys_ini() const;
bool get_nvm_ok() const;
bool get_tmp_ok() const;
bool get_chg_en() const;
bool get_acq_ok() const;
bool get_low_ok() const;
```

## BMS_report: The Communication Interface

The `BMS_report` class handles the generation and transmission of battery data reports. It provides an interface for the application to push BMS report messages that are forwarded to the Cyphal data messaging support.

### Message Types:
- **Battery Power (10 Hz)**: Reports battery power-related data
- **Battery Temperature (1 Hz)**: Reports battery temperature data
- **Battery Summary (1 Hz)**: Reports comprehensive battery status data

### Message Flow:
1. The application calls `push()` with a message identifier
2. The message is queued in a FIFO buffer
3. The `step()` method processes queued messages and builds the appropriate reports
4. The reports are sent through the Cyphal TX manager

### Report Building:
Each report type has a dedicated building method:
- `build_bpow()`: Builds battery power reports with voltage, current, and SoC data
- `build_btmp()`: Builds battery temperature reports with cell and PCBA temperatures
- `build_bdsm()`: Builds comprehensive battery summary reports with all relevant data

## BMS_stats: The Statistics Engine

The `BMS_stats` class computes statistics from the whole battery pack and stores them in system variables. It processes cell voltage and temperature data to determine minimum, maximum, and median values.

### Key Features:
- **Iterative Processing**: Processes one string at a time to distribute computational load
- **Statistical Analysis**: Computes min, max, and median values for cell voltages and temperatures
- **Charger Control**: Uses statistics to determine when to enable or disable the charger

### Processing Flow:
1. The `update()` method is called to start the statistics update process
2. The `step()` method processes one string at a time
3. For each string, the `compute()` method calculates statistics
4. After all strings are processed, charger control logic is applied

### Charger Control Logic:
The charger is disabled if any cell voltage is outside the safe range:
```cpp
chg_en = (str_stat[i].cv_max > dis_chg_above) || (str_stat[i].cv_min < dis_chg_under);
```

## Data Flow and Component Relationships

The BMS system implements a comprehensive data flow architecture that connects all components:

1. **Data Acquisition**:
   - The `Battery_manager` triggers high-priority tasks at 6 kHz
   - The `BMS_suite` schedules AFE requests at different frequencies
   - The AFE suite acquires raw data from battery cells

2. **Data Processing**:
   - Raw data is processed and stored in system variables
   - The `BMS_vars` class provides access to processed data
   - The `BMS_stats` class computes statistics from the data

3. **Health Monitoring**:
   - The `Health_monitor` analyzes data to detect anomalies
   - Alerts are generated based on predefined thresholds
   - The system responds to health issues (e.g., disabling the charger)

4. **Reporting and Communication**:
   - The `BMS_report` class generates reports based on processed data
   - Reports are sent through the Cyphal communication system
   - External systems receive battery status information

5. **Lifetime Management**:
   - The `Lifetime_mgr` tracks battery usage statistics
   - Data is stored in non-volatile memory through the EEPROM
   - Long-term battery health is monitored and managed

## System Monitoring and Diagnostics

The BMS implements comprehensive monitoring and diagnostics:

- **Frequency Checking**: Ensures tasks run at their required frequencies
- **Stack Checking**: Monitors stack usage to prevent overflows
- **CPU Load Monitoring**: Tracks CPU usage and warns if it exceeds thresholds
- **Communication Monitoring**: Verifies data communication with battery strings
- **Hardware Monitoring**: Checks the status of hardware components (EEPROM, temperature sensors)

## Referenced Context Files

The following context files provided useful information for understanding the BMS architecture:

- None were provided in this analysis, as the FILES section contained all the necessary information.

## Conclusion

The BMS core architecture is built around a clear separation of concerns, with specialized components handling different aspects of battery management. The system uses a dual-priority execution model to ensure both real-time responsiveness and comprehensive background processing. The `Battery_manager` serves as the central controller, while the `BMS_suite` coordinates all subsystems. The `BMS_vars` provides a unified interface for accessing battery data, and the `BMS_report` handles communication with external systems. This architecture ensures reliable, efficient, and comprehensive battery management.