# Generated from:

- items/sw_BMS/code/BMS/code/include/BQ79616.h (9976 tokens)
- items/sw_BMS/code/BMS/code/include/BQ_buffer.h (846 tokens)
- items/sw_BMS/code/BMS/code/include/BQ_builder.h (492 tokens)
- items/sw_BMS/code/BMS/code/include/BQ_defs.h (1124 tokens)
- items/sw_BMS/code/BMS/code/include/BQ_driver.h (1059 tokens)
- items/sw_BMS/code/BMS/code/include/BQ_meas.h (1155 tokens)
- items/sw_BMS/code/BMS/code/include/BQ_packet.h (2982 tokens)
- items/sw_BMS/code/BMS/code/include/BQ_ping.h (507 tokens)
- items/sw_BMS/code/BMS/code/include/BQ_request.h (1648 tokens)
- items/sw_BMS/code/BMS/code/include/BQ_utils.h (429 tokens)
- items/sw_BMS/code/BMS/code/include/BQ_vars.h (242 tokens)
- items/sw_BMS/code/BMS/code/include/AFE_app.h (1828 tokens)
- items/sw_BMS/code/BMS/code/include/AFE_suite.h (1104 tokens)
- items/sw_BMS/code/BMS/code/source/BQ_buffer.cpp (332 tokens)
- items/sw_BMS/code/BMS/code/source/BQ_builder.cpp (225 tokens)
- items/sw_BMS/code/BMS/code/source/BQ_defs.cpp (1480 tokens)
- items/sw_BMS/code/BMS/code/source/BQ_driver.cpp (1055 tokens)
- items/sw_BMS/code/BMS/code/source/BQ_meas.cpp (2105 tokens)
- items/sw_BMS/code/BMS/code/source/BQ_packet.cpp (1767 tokens)
- items/sw_BMS/code/BMS/code/source/BQ_ping.cpp (631 tokens)
- items/sw_BMS/code/BMS/code/source/BQ_request.cpp (2937 tokens)
- items/sw_BMS/code/BMS/code/source/BQ_utils.cpp (125 tokens)
- items/sw_BMS/code/BMS/code/source/BQ_vars.cpp (322 tokens)
- items/sw_BMS/code/BMS/code/source/AFE_app.cpp (3945 tokens)
- items/sw_BMS/code/BMS/code/source/AFE_suite.cpp (928 tokens)

## With context from:

- PackageSummaries/Amazon-PrimeAir/items/BMS/05_BMS_Core_Architecture.md (3407 tokens)

---

# BQ79616 Analog Front End (AFE) Driver Implementation

## 1. Architecture Overview

The BQ79616 AFE driver implements a layered architecture to interface with the Texas Instruments BQ79616 Analog Front End chip, which is responsible for battery cell monitoring and balancing. The architecture consists of:

### 1.1 Communication Layer
- **BQ_buffer**: Manages data transfer buffers for communication with the BQ79616
- **BQ_packet**: Handles packet formatting, CRC calculation, and protocol implementation
- **BQ_driver**: Provides direct hardware control for SCI (UART) communication and GPIO signaling

### 1.2 Request Handling Layer
- **BQ_builder**: Abstract interface for building BQ requests
- **BQ_request**: Implements specific request types (configuration, measurements, cell balancing)
- **BQ_ping**: Manages hardware signaling for reset, wake-up, and communication clearing

### 1.3 Measurement Processing Layer
- **BQ_meas**: Processes raw measurements and converts them to appropriate units
- **BQ_vars**: Manages system variables for storing processed measurements
- **BQ_defs**: Defines constants, register addresses, and default configurations

### 1.4 Application Layer
- **AFE_app**: Manages a single BQ79616 chip, handling configuration, measurement, and balancing
- **AFE_suite**: Coordinates multiple AFE_app instances for multi-string battery packs

## 2. BQ79616 Register Structure and Communication Protocol

### 2.1 Register Organization

The BQ79616 registers are organized into three main categories:

1. **Shadow Registers** (`BQ79616::Shadow_registers`):
   - Default values loaded from OTP (One-Time Programmable) memory
   - Configuration registers for device behavior, cell monitoring, GPIO settings
   - Examples: `reg_dev_conf`, `reg_active_cell`, `reg_adc_conf1`, `reg_gpio_conf1`

2. **Read/Write Registers** (`BQ79616::RW_registers`):
   - Volatile registers for controlling device operation
   - Examples: `reg_control1`, `reg_adc_ctrl1`, `reg_bal_ctrl2`

3. **Read-Only Registers** (`BQ79616::RO_registers`):
   - Status and measurement registers
   - Examples: `reg_vcel16_hi`, `reg_gpio1_hi`, `reg_fault_summary`

### 2.2 Communication Protocol

The driver implements the BQ79616 UART communication protocol with the following characteristics:

1. **Packet Structure**:
   ```
   [Header (4 bytes)][Data (variable)][CRC (2 bytes)]
   ```
   - Header includes initialization byte, device address, and register address
   - Maximum write data size: 8 bytes
   - Maximum read data size: 128 bytes

2. **CRC Implementation**:
   - 16-bit CRC with polynomial 0xA001
   - Initial value: 0xFFFF
   - Input and output reflection enabled

3. **Request Types**:
   - Read requests: Request data from specific registers
   - Write requests: Write data to specific registers

4. **Hardware Signaling**:
   - Reset ping: 36ms low pulse followed by 75ms wait
   - Wake-up ping: 2.3ms low pulse followed by 8ms wait
   - Communication clear: 16μs low pulse followed by 1μs wait

## 3. Initialization and Configuration Sequence

The AFE driver implements a multi-stage initialization sequence:

1. **Hardware Reset**:
   - Sends a reset ping to force the BQ79616 into SHUTDOWN mode
   - Transitions to wake-up state

2. **Wake-up**:
   - Sends a wake-up ping to transition from SHUTDOWN to ACTIVE mode
   - Transitions to configuration state

3. **Configuration Check**:
   - Reads device configuration register to determine if OTP programming is needed
   - If configuration matches expected values, skips to TSREF configuration
   - Otherwise, proceeds with shadow register configuration

4. **Shadow Register Configuration**:
   - Configures device settings (MULTIDROP_EN, NFAULT_EN, TWO_STOP_EN, FCOMM_EN)
   - Sets active cell count (16 cells)
   - Configures ADC settings (13Hz low-pass filter for cell and bus-bar measurements)
   - Configures GPIO pins (GPIO1-6 as ADC inputs, GPIO7-8 as outputs)
   - Sets communication timeout (2 seconds)
   - Configures bus-bar pin location

5. **OTP Programming** (if needed):
   - Unlocks OTP programming through a sequence of register writes
   - Programs shadow registers to OTP page 1
   - Performs software reset to apply OTP settings
   - Verifies programming success

6. **TSREF Configuration**:
   - Enables TSREF LDO output for thermistor biasing
   - Waits 400μs for stabilization

7. **ADC Configuration**:
   - Enables digital low-pass filters for cell and bus-bar measurements
   - Configures main ADC for continuous operation
   - Starts ADC conversion

8. **Cell Balancing Configuration**:
   - Configures cell balancing timers (10 seconds per balancing cycle)
   - Sets duty cycle for switching between odd and even cells (5 seconds)
   - Does not start balancing (requires explicit command)

## 4. Measurement Sampling Process

### 4.1 Cell Voltage Sampling

The driver implements a two-sample approach for complete battery monitoring:

1. **Sample 1** (Cell Voltages and Basic Measurements):
   - Reads 16 cell voltages (16-bit values)
   - Reads bus-bar voltage
   - Reads TSREF voltage
   - Reads string current (from GPIO1)
   - Reads string temperature (from GPIO2)
   - Total data size: 40 bytes

2. **Sample 2** (Cell Temperatures via Multiplexed GPIOs):
   - Configures GPIO7-8 as multiplexer control outputs
   - For each multiplexer setting (0-3):
     - Sets GPIO7-8 to the multiplexer value
     - Reads GPIO3-6 for thermistor measurements
   - Total data size: 8 bytes

### 4.2 Measurement Processing

Raw measurements are processed by the `BQ_meas` class:

1. **Cell Voltage Processing**:
   - Converts ADC values to deci-millivolts using the formula:
     ```
     vcell_dmv = 0.01 * raw_value * 190.73
     ```
   - Adjusts cell 9 voltage based on bus-bar measurement
   - Accumulates cell voltages to calculate string voltage

2. **Temperature Processing**:
   - Converts ADC values to degrees using thermistor lookup table
   - Uses TSREF measurement as reference for thermistor calculations
   - Supports both string temperature and individual cell temperatures

3. **Current Processing**:
   - Converts ADC values to centi-amperes using the formula:
     ```
     string_ca = (152.59 * raw_value + 100 - 1E8) / 200
     ```
   - Implements auto-calibration with 100ms stabilization time

## 5. Cell Balancing Implementation

The driver supports both manual and automatic cell balancing:

### 5.1 Cell Balancing Configuration

- Each cell has a dedicated balancing control register (`reg_cb_cell1_ctrl` through `reg_cb_cell16_ctrl`)
- Balancing time can be configured from 10 seconds to 9.5 hours
- Duty cycle for switching between odd and even cells can be set from 5 seconds to 30 minutes

### 5.2 Balancing Control

1. **Start Balancing**:
   - Sets `AUTO_BAL` bit to enable automatic balancing
   - Sets `BAL_GO` bit to start the balancing process
   - Configures balancing action on completion (no action, sleep, or shutdown)

2. **Stop Balancing**:
   - Clears `BAL_GO` bit to stop the balancing process
   - Keeps `AUTO_BAL` bit set for future balancing operations

3. **Balancing Status**:
   - Monitors `reg_bal_stat` register for balancing status
   - Monitors `reg_cb_complete1` and `reg_cb_complete2` for completion status

## 6. Error Handling and Fault Management

The driver implements comprehensive error handling:

### 6.1 Communication Error Handling

- CRC validation for all received packets
- Communication timeout detection (2 seconds)
- Communication clear signaling for error recovery
- Packet format validation

### 6.2 Fault Detection

The BQ79616 provides extensive fault detection capabilities:

- Communication faults (`reg_fault_comm1`, `reg_fault_comm2`, `reg_fault_comm3`)
- System faults (`reg_fault_sys`)
- Protection faults (`reg_fault_prot1`, `reg_fault_prot2`)
- Voltage faults (`reg_fault_ov1`, `reg_fault_ov2`, `reg_fault_uv1`, `reg_fault_uv2`)
- Temperature faults (`reg_fault_ot`, `reg_fault_ut`)
- Power faults (`reg_fault_pwr1`, `reg_fault_pwr2`, `reg_fault_pwr3`)

### 6.3 Error Recovery

- Software reset capability via `SOFT_RESET` bit
- Hardware reset via reset ping
- Communication clear via COMM_CLR ping

## 7. Integration with BMS System

The AFE driver integrates with the broader BMS system through:

### 7.1 System Variables

- Cell voltages stored in `cell_voltage` array (16-bit values)
- Cell temperatures stored in `cell_temperature` array (floating-point values)
- String measurements (voltage, current, temperature) stored in dedicated variables
- Communication status flags for system monitoring

### 7.2 Task Scheduling

The driver operates within a dual-priority task system:

1. **High-Priority Tasks** (executed at 6kHz):
   - Communication handling via `step_hi()`
   - Hardware signaling for reset and wake-up
   - SCI peripheral data transfer

2. **Low-Priority Tasks** (executed at 100Hz):
   - Configuration and initialization via `step()`
   - Measurement request scheduling
   - Response parsing and data processing
   - Cell balancing control

### 7.3 Multi-String Support

The `AFE_suite` class coordinates multiple `AFE_app` instances for multi-string battery packs:

- Synchronizes measurement requests across all strings
- Manages configuration status for all AFEs
- Coordinates cell balancing operations
- Provides unified interface for BMS core components

## 8. Timing Parameters and Performance Considerations

### 8.1 Communication Timing

- SCI baud rate: 1 Mbps
- Reset ping duration: 36ms
- Wake-up ping duration: 2.3ms
- Communication clear duration: 16μs
- Response delay: 10 bit periods

### 8.2 Measurement Timing

- ADC sampling rate: 13Hz (77ms average)
- TSREF settling time: 400μs
- Current calibration time: 100ms
- Thermistor anti-aliasing filter: 4.3ms

### 8.3 Buffer Sizes

- Request cache: 5 packets
- Response buffer: Maximum 131 bytes (128 data + 3 overhead)
- Request buffer: Maximum 14 bytes (8 data + 6 overhead)

## 9. Cross-Component Relationships

### 9.1 Data Flow

1. **Request Building**:
   ```
   BQ_request → BQ_builder → BQ_packet → BQ_buffer → BQ_driver → SCI peripheral
   ```

2. **Response Processing**:
   ```
   SCI peripheral → BQ_driver → BQ_buffer → AFE_app → BQ_meas → BQ_vars → System variables
   ```

3. **Control Flow**:
   ```
   AFE_suite → AFE_app → BQ_driver → BQ_ping → GPIO peripheral
   ```

### 9.2 Component Dependencies

- `BQ_driver` depends on `BQ_buffer`, `BQ_ping`, and SCI peripheral
- `AFE_app` depends on `BQ_driver`, `BQ_meas`, and `BQ_request`
- `AFE_suite` depends on `AFE_app` and system variables
- `BQ_meas` depends on `BQ_vars` and system variables
- `BQ_packet` depends on `BQ_utils` for protocol definitions

## 10. Referenced Context Files

The following context files provided useful information:

- `BMS_traits.h`: Provided information about system variable organization
- `Hbvar.h`, `Huvar.h`, `Hrvar.h`: Provided interfaces for accessing system variables
- `U8pkfifospsc.h`, `U8pkfifospscwr_commit.h`: Provided FIFO buffer implementations
- `Port_buffer.h`: Provided peripheral interface abstractions
- `SCI_fw.h`: Provided SCI peripheral interface
- `GPIOpulse_action.h`: Provided GPIO control for signaling

## Summary

The BQ79616 AFE driver implements a comprehensive solution for battery cell monitoring and balancing. It features a layered architecture with clear separation of concerns, robust error handling, and efficient integration with the broader BMS system. The driver supports all key functions of the BQ79616 chip, including cell voltage measurement, temperature monitoring, and cell balancing, while providing a clean interface for the BMS application layer.