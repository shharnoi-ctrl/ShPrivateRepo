# Generated from:

- items/sw_BMS/code/BMS/code/include/Cell_balancing.h (763 tokens)
- items/sw_BMS/code/BMS/code/include/Health_monitor.h (852 tokens)
- items/sw_BMS/code/BMS/code/include/Lifetime.h (701 tokens)
- items/sw_BMS/code/BMS/code/include/Lifetime_mgr.h (1350 tokens)
- items/sw_BMS/code/BMS/code/include/Pack_lifetime.h (724 tokens)
- items/sw_BMS/code/BMS/code/include/SOC.h (998 tokens)
- items/sw_BMS/code/BMS/code/source/Cell_balancing.cpp (1467 tokens)
- items/sw_BMS/code/BMS/code/source/Health_monitor.cpp (941 tokens)
- items/sw_BMS/code/BMS/code/source/Lifetime.cpp (1302 tokens)
- items/sw_BMS/code/BMS/code/source/Lifetime_mgr.cpp (2693 tokens)
- items/sw_BMS/code/BMS/code/source/Pack_lifetime.cpp (1241 tokens)
- items/sw_BMS/code/BMS/code/source/SOC.cpp (1554 tokens)

## With context from:

- PackageSummaries/Amazon-PrimeAir/items/BMS/05_BMS_Core_Architecture.md (3407 tokens)
- PackageSummaries/Amazon-PrimeAir/items/BMS/04_AFE_Driver_Implementation.md (3357 tokens)

---

# Battery Management System (BMS) Core Subsystems Analysis

## 1. Cell Balancing System

The Cell Balancing subsystem is responsible for ensuring uniform charge across all cells in the battery pack to maximize capacity and extend battery life.

### 1.1 Architecture and Components

The cell balancing functionality is implemented through the `Cell_balancing` class, which:
- Manages balancing operations for multiple battery strings
- Interfaces with the AFE (Analog Front End) suite to control physical balancing circuits
- Implements decision logic for when to start and stop balancing
- Tracks balancing status through timeouts and state flags

The class uses a nested `String` structure to handle balancing operations for each individual battery string:

```cpp
class Cell_balancing: public Base::Istep {
public:
    struct String {
        explicit String(Uint16 str_id0);
        bool check_start();
        bool check_stop();
    private:
        const Uint16 id;
        BMS_vars& vars;
    };
    
    explicit Cell_balancing(AFE_suite& suite0);
    virtual void step();
    bool is_balancing() const;
    
private:
    AFE_suite& suite;
    Base::Bitmask<Uint16> afe_cb;
    Base::Array<Base::Timeout> tout_stp;
    Base::Array<String> str;
    void step0(Uint16 str_id0);
};
```

### 1.2 Cell Voltage Monitoring

The system continuously monitors cell voltages through the BMS_vars interface:

```cpp
const Uint16 curr_cv = vars.get_cv(id, i);  // Get cell voltage in deci-millivolts
```

Key voltage thresholds include:
- Maximum cell voltage for balancing: 3.3V (3300 centi-volts)
- Minimum voltage difference to start balancing: 30mV (300 deci-millivolts)
- Minimum voltage difference to stop balancing: 15mV (150 deci-millivolts)

### 1.3 Balancing Activation Logic

The system activates cell balancing when all of the following conditions are met:
1. String current is between -20A and +1.5A (-2000 to 150 centi-amperes)
2. Voltage difference between any two cells exceeds 30mV
3. All cell voltages are above 3.3V

```cpp
bool Cell_balancing::String::check_start() {
    bool start_needed = false;
    const Uint16 max_dcV = 300U;  // 30mV threshold
    const Real sc = vars.get_sc(id);
    start_needed = (sc >= min_cA) && (sc <= max_cA) && (vars.get_cv(id, 0) >= max_cV);
    if(start_needed) {
        for(Uint16 i=1; start_needed && (i<BMS_traits::nb_cell); i++) {
            const Uint16 curr_cv = vars.get_cv(id, i);
            const Real64 diff = curr_cv - vars.get_cv(id, i-1);
            start_needed &= (curr_cv >= max_cV) && (diff >= max_dcV);
        }
    }
    return start_needed;
}
```

### 1.4 Balancing Deactivation Logic

The system stops cell balancing when any of the following conditions occur:
1. String current is outside the range of -20A to +1.5A
2. Greatest voltage difference between any two cells falls below 15mV
3. Any cell voltage drops below 3.3V
4. The balancing timeout expires (5 seconds)

```cpp
bool Cell_balancing::String::check_stop() {
    bool stop_needed = false;
    const Uint16 min_dcV = 150U;  // 15mV threshold
    const Real sc = vars.get_sc(id);
    stop_needed = ((sc < min_cA) && (sc > max_cA)) || (vars.get_cv(id, 0) < max_cV);
    if(!stop_needed) {
        for(Uint16 i=1; !stop_needed && (i<BMS_traits::nb_cell); i++) {
            const Uint16 curr_cv = vars.get_cv(id, i);
            const Real64 diff = curr_cv - vars.get_cv(id, i-1);
            stop_needed |= (curr_cv < max_cV) || (diff < min_dcV);
        }
    }
    return stop_needed;
}
```

### 1.5 Balancing State Machine

The balancing system implements a state machine for each string:
1. Check if balancing is active for the string (using the `afe_cb` bitmask)
2. If active, check if stop conditions are met or timeout expired
3. If inactive, check if start conditions are met and timeout expired
4. Control balancing hardware through the AFE suite interface

```cpp
void Cell_balancing::step0(Uint16 str_id0) {
    Base::Timeout& tout0 = tout_stp.get(str_id0);
    String& str0 = str.get(str_id0);
    if(afe_cb.get(str_id0)) {
        if((str0.check_stop() || tout0.expired()) && suite.stop_cb(str_id0)) {
            tout0.set_timeout_s(cb_timer);
            afe_cb.clear(str_id0);
        }
    } else {
        if((str.get(str_id0).check_start() && tout0.expired()) && suite.start_cb(str_id0)) {
            tout0.set_timeout_s(cb_timer);
            afe_cb.set(str_id0);
        }
    }
}
```

### 1.6 Safety Mechanisms

The cell balancing system incorporates several safety mechanisms:
- Timeout-based control to prevent excessive balancing (5 seconds per cycle)
- Current limits to prevent balancing during high charge/discharge rates
- Voltage thresholds to prevent over-discharge during balancing
- Status tracking through the `is_balancing()` method for system monitoring

## 2. State of Charge (SOC) Calculation System

The SOC subsystem is responsible for estimating the remaining battery capacity as a percentage of its total capacity.

### 2.1 Architecture and Components

The SOC calculation is implemented through the `SOC` class, which:
- Manages SOC calculations for multiple battery strings
- Combines OCV (Open Circuit Voltage) and coulomb counting methods
- Tracks pack-level SOC based on individual string SOCs
- Operates as a low-priority task in the BMS system

```cpp
class SOC: public Base::Istep {
public:
    struct String {
        explicit String(Uint16 str_id0);
        void step();
        Real get_soc() const;
        static void step0(String& str0);
    private:
        enum State { st_ocv, st_cnt, st_end };
        static const Uint16 nb_samples = 100U;
        const Uint16 str_id;
        State state;
        Uint16 sample_it;
        bool ocv_ok;
        Uint32 ocv_sum;
        Base::Chrono32 dt_cr;
        volatile Real& string_soc;
        BMS_vars& vars;
        static Real interpolate_soc(Uint32 ocv_val);
    };
    
    SOC(Uint32 def_cap0);
    virtual void step();
    
private:
    static Uint32 nominal_capacity_mAh;
    Base::Array<String> afes;
    volatile Real& pack_soc;
};
```

### 2.2 OCV Method Implementation

The system first attempts to determine SOC using the Open Circuit Voltage (OCV) method:
1. Collects 100 voltage samples to ensure stable readings
2. Verifies that string current is below 1.5A during sampling
3. Calculates average voltage from the samples
4. Uses a lookup table to interpolate SOC from the average voltage

```cpp
void SOC::String::step() {
    const Real sc = BMS_varhdl::Rvar_t::get_var(str_id, BMS_traits::Rvar::str_sc);
    switch(state) {
        case st_ocv:
            ocv_sum += BMS_varhdl::Rvar_t::get_var(str_id, BMS_traits::Rvar::str_sv);
            ocv_ok &= (sc <= Const::ONE_HUNDRED_FIFTY);
            if((++sample_it) == nb_samples) {
                if(!ocv_ok) {
                    string_soc = Const::ZERO;
                    state = st_end;
                } else {
                    const Uint32 ocv_avr = ocv_sum / nb_samples;
                    string_soc = interpolate_soc(ocv_avr);
                    state = st_cnt;
                    dt_cr.tic();
                }
            }
            break;
        // ...
    }
}
```

The OCV lookup table contains 20 voltage breakpoints corresponding to SOC values from 0% to 100% in 5% increments:

```cpp
static const Base::Tnarray<Uint32, breakpoint_count> dmv_values = {
    535934U, 543788U, 553178U, 561606U, 569028U, 573900U, 577775U, 581741U, 586538U, 593088U,
    603222U, 613200U, 620610U, 627138U, 634384U, 643081U, 651028U, 655063U, 659994U, 675622U
};
```

### 2.3 Coulomb Counting Method

After establishing an initial SOC value using OCV, the system switches to coulomb counting:
1. Measures string current and elapsed time
2. Calculates charge/discharge amount using the formula: SOC[k] = SOC[k-1] - I[k]*(dt/C_rated)
3. Updates the SOC value based on the calculation

```cpp
case st_cnt:
    const Real64 last_soc = string_soc;
    const Real64 curr_soc = dt_cr.toc().get_seconds() * (sc * Const::TEN) / nominal_capacity_mAh;
    string_soc = last_soc - curr_soc;
    break;
```

### 2.4 Pack-Level SOC Determination

The system calculates the overall pack SOC by taking the minimum SOC value across all strings:

```cpp
void SOC::step() {
    afes.apply_all(String::step0);
    Real min_soc = afes.get(0).get_soc();
    for(Uint16 i=1; i<afes.size(); i++) {
        min_soc = Rfun::min<Real>(min_soc, afes.get(i).get_soc());
    }
    pack_soc = min_soc;
}
```

This approach ensures that the pack SOC represents the most conservative estimate, preventing over-discharge of any individual string.

### 2.5 Initialization and Configuration

The SOC system is initialized with the nominal battery capacity in mAh:

```cpp
SOC::SOC(Uint32 def_cap0):
    afes(BMS_traits::nb_str, Base::Memmgr::internal, Base::Rngit<Uint16>::build_count(0, BMS_traits::nb_str)),
    pack_soc(Bsp::Hrvar(BMS_varhdl::Rvar_t::get_var(BMS_traits::Rvar::pck_soc)).get_ref())
{
    pack_soc = Const::ZERO;
    nominal_capacity_mAh = def_cap0;
}
```

## 3. Health Monitoring System

The Health Monitoring subsystem is responsible for detecting, tracking, and responding to fault conditions in the battery system.

### 3.1 Architecture and Components

The health monitoring functionality is implemented through the `Health_monitor` class, which:
- Manages alert flags for both pack-level and string-level conditions
- Processes alerts through dedicated alert managers
- Handles permanent latching of critical alerts
- Provides serialization capabilities for reporting and persistence

```cpp
class Health_monitor {
public:
    struct String {
        Alerts_manager::Flags str_flgs;
        String_alerts str_prcs;
        explicit String(Uint16 str_id);
    };
    
    explicit Health_monitor(Uint16 nb_str);
    void step();
    void get_latched(Base::U8pkmblock_k& ltc_alt);
    void set_latched(Base::U8pkmblock& ltc_alt);
    void cget_pack(Base::U8ostream& ostr);
    void cget_str(Uint16 str_id, Base::U8ostream& ostr);
    
private:
    bool is_init;
    Base::Array<String> str_arr;
    Alerts_manager::Flags pck_flgs;
    Pack_alerts pck_prcs;
};
```

### 3.2 Alert Types and Categories

The system monitors several categories of alerts:

#### Pack-Level Alerts:
- Battery temperature boundary violations (`Pack_alerts::eps_batt_temp_bnd`)

#### String-Level Alerts:
- Low cell voltage runtime (`String_alerts::eps_batt_lo_cv_rt`)
- Low cell voltage power (`String_alerts::eps_batt_lo_cv_pw`)
- High cell voltage latched (`String_alerts::eps_batt_hi_cv_lt`)

### 3.3 Alert Processing

The health monitor processes alerts through dedicated alert managers:
1. Each string has its own alert flags and processing logic
2. Pack-level alerts are managed separately
3. The `step()` method triggers alert processing for all strings

```cpp
void Health_monitor::step() {
    if(is_init) {
        str_arr.apply_all(step0);
    }
}

static void step0(Health_monitor::String& str0) {
    str0.str_prcs.step();
}
```

### 3.4 Latched Alert Management

Critical alerts are permanently latched to ensure they persist across power cycles:

```cpp
void Health_monitor::get_latched(Base::U8pkmblock_k& ltc_alt) {
    const Base::Mblock<const Pack_alerts::Id>& pck_ltc_ids = get_pck_ltc_ids();
    Base::Bitmask<Uint8> bm_pck = Base::Bitmask<Uint8>::build(ltc_alt.get(0));
    for(Uint16 i=0; i<pck_ltc_ids.size(); i++) {
        pck_flgs.set(pck_ltc_ids[i], bm_pck.get(i));
    }
    
    const Base::Mblock<const String_alerts::Id>& str_ltc_ids = get_str_ltc_ids();
    const Uint16 nb_str = str_arr.size();
    for(Uint16 i=0; i<nb_str; i++) {
        Base::Bitmask<Uint8> bm_str = Base::Bitmask<Uint8>::build(ltc_alt.get(Ku16::u1+i));
        for(Uint16 j=0; j<str_ltc_ids.size(); j++) {
            str_arr.get(i).str_flgs.set(str_ltc_ids[j], bm_str.get(j));
        }
    }
    is_init = true;
}
```

### 3.5 Alert Reporting

The health monitor provides methods to serialize alert states for reporting:

```cpp
void Health_monitor::cget_pack(Base::U8ostream& ostr) {
    ostr.put_uint32_le(pck_flgs.value);
}

void Health_monitor::cget_str(Uint16 str_id, Base::U8ostream& ostr) {
    ostr.put_uint32_le(str_arr.get(str_id).str_flgs.value);
}
```

## 4. Lifetime Statistics Management System

The Lifetime Statistics subsystem is responsible for tracking and storing long-term battery usage data.

### 4.1 Architecture and Components

The lifetime statistics functionality is implemented through several classes:

- `Lifetime`: Stores statistics for a single battery string
- `Pack_lifetime`: Manages statistics for the entire battery pack
- `Lifetime_mgr`: Handles loading/saving statistics from/to non-volatile storage

```cpp
struct Lifetime {
    Uint32 cum_dchg_curr;              // Total discharge current (ampere hour)
    Uint32 cum_chg_curr;               // Total charge current (ampere hour)
    Base::Array<int16> max_tmp_cell;   // Maximum cell temperature (deci-degree)
    Base::Array<int16> min_tmp_cell;   // Minimum cell temperature (deci-degree)
    Uint16 max_str_volt;               // Maximum string voltage (centi-volt)
    Uint16 min_str_volt;               // Minimum string voltage (centi-volt)
    int32 max_dchr_curr;               // Maximum discharge current (centi-ampere)
    int32 max_chr_curr;                // Maximum charge current (centi-ampere)
    Base::Array<Uint16> max_cell_volt; // Maximum cell voltage (decimilli-volt)
    Base::Array<Uint16> min_cell_volt; // Minimum cell temperature (decimilli-volt)
    Uint16 histo_soc_gain;             // Histogram for number of significant charge events
    Uint8 latch_alert;                 // Bit flags to set the latching health alert
    
    explicit Lifetime(Uint16 nb_cell0);
    void cset(Base::U8istream& istr);
    void cget(Base::U8ostream& ostr);
    Uint32 get_total_size() const;
};
```

### 4.2 Tracked Statistics

The system tracks a comprehensive set of lifetime statistics:

1. **Cumulative Measurements**:
   - Total discharge current (ampere-hours)
   - Total charge current (ampere-hours)
   - Interlock cycle count

2. **Extreme Values**:
   - Maximum and minimum cell temperatures
   - Maximum and minimum string voltages
   - Maximum and minimum cell voltages
   - Maximum discharge and charge currents

3. **Usage Patterns**:
   - SOC gain histogram (charge events)
   - Latched alerts

### 4.3 Data Persistence

The `Lifetime_mgr` class handles saving and loading statistics to/from non-volatile storage:

```cpp
class Lifetime_mgr: public Base::Istep {
public:
    Lifetime_mgr(Base::Iblock_device& blk_dev0, Health_monitor& hlt_mon0);
    void save_stats();
    virtual void step();
    bool is_busy() const;
    
private:
    enum Status { op_idle, op_reading, op_writing };
    enum State { st_init, st_read, st_check, st_write, st_idle, st_error };
    
    static const Uint16 record_sec_idx = 10U;
    
    Base::Iblock_device& blk_dev;
    Pack_lifetime data;
    BMS_vars& vars;
    Status status;
    State state;
    State error_state;
    Base::U8pkmblock wk_mb;
    bool is_backup;
    Base::Chrono cr_call;
    bool lck_inc;
    Health_monitor& hlt_mon;
    
    // Helper methods
    bool next(bool res, State ok_val);
    void set_error();
    bool step_op();
    bool start_read(Uint16 rec_idx);
    bool start_write(Uint16 rec_idx);
    void start_write();
    void update_stats();
};
```

### 4.4 Storage Mechanism

The system uses a dual-record approach for reliability:
1. Main record stored at sector index 10
2. Backup record stored at sector index 11
3. Each record includes a CRC32 checksum for data integrity

```cpp
bool Pack_lifetime::check_and_set(Base::U8istream& istr) {
    const Uint32 received_crc = istr.get_uint32_le();
    istr.seek_end();
    Base::U8pkmblock_k data_mb(istr.to_mblock8(), sz_crc32, data_sz);
    Base::CRC32 crc32;
    crc32.update(data_mb);
    const bool ret = (crc32.get_value() == istr.get_uint32_le());
    if(ret) {
        Base::U8istream data_str(data_mb);
        for(Uint16 i=0; i<nb_str; i++) {
            str_lft.get(i).cset(data_str);
        }
        lck_cnt = data_str.get_uint32_le();
        for(Uint16 i=0; i<(Ku16::u1+nb_str); i++) {
            ltc_alt.set(i, data_str.get_uint8());
        }
    }
    return ret;
}
```

### 4.5 Statistics Update Process

The system periodically updates statistics based on current battery state:

```cpp
void Lifetime_mgr::update_stats() {
    if(!lck_inc) {
        lck_inc = true;
        data.lck_cnt++;
    }
    for(Uint16 i=0; i<BMS_traits::nb_str; i++) {
        Lifetime& lt = data.str_lft.get(i);
        const Real64 delta_sec = cr_call.toc_ttime().get_seconds64();
        static const Real64 ah_to_cas = 360000.0F; // (Amp/hour)(sec/hour)
        const int32 cur_dchg_curr = (vars.get_sc(i)*delta_sec)/ah_to_cas;
        lt.max_dchr_curr = Rfun::max<int32>(cur_dchg_curr, lt.max_dchr_curr);
        lt.max_chr_curr = Rfun::max<int32>(abs(cur_dchg_curr), lt.max_chr_curr);
        lt.cum_dchg_curr += cur_dchg_curr;
        lt.cum_chg_curr += abs(lt.cum_dchg_curr);
        
        for(Uint16 j=0; j<BMS_traits::nb_cell; j++) {
            static const Real deg_to_ddeg = Const::E10;
            const int16 cell_tmp = vars.get_ct(i, j) * deg_to_ddeg;
            lt.max_tmp_cell[j] = Rfun::max<int16>(cell_tmp, lt.max_tmp_cell.get(j));
            lt.min_tmp_cell[j] = Rfun::min<int16>(cell_tmp, lt.min_tmp_cell.get(j));
            
            const Uint16 cell_vlt = vars.get_cv(i, j);
            lt.max_cell_volt[j] = Rfun::max<int16>(cell_vlt, lt.max_cell_volt.get(j));
            lt.min_cell_volt[j] = Rfun::min<int16>(cell_vlt, lt.min_cell_volt.get(j));
        }
        
        const Uint16 string_vlt = vars.get_sv(i);
        lt.max_str_volt = Rfun::max<Uint16>(string_vlt, lt.max_str_volt);
        lt.min_str_volt = Rfun::min<Uint16>(string_vlt, lt.min_str_volt);
    }
    cr_call.tic();
}
```

### 4.6 State Machine for Storage Operations

The `Lifetime_mgr` implements a state machine for reliable storage operations:

1. **Initialization** (`st_init`): Wait for storage device initialization
2. **Read** (`st_read`): Read main or backup record
3. **Check** (`st_check`): Verify CRC and deserialize data
4. **Write** (`st_write`): Write updated data to storage
5. **Idle** (`st_idle`): Normal operation state
6. **Error** (`st_error`): Error handling state

```cpp
void Lifetime_mgr::step() {
    if(step_op()) {
        bool next_cond = false;
        switch(state) {
            case st_init:
                next_cond = blk_dev.is_init();
                next(next_cond, st_read);
                break;
            case st_read:
                next_cond = start_read(record_sec_idx + is_backup);
                if(!next(next_cond, st_check)) {
                    set_error();
                }
                break;
            case st_check:
                Base::U8istream istr(wk_mb);
                const bool is_valid = data.check_and_set(istr);
                if(!is_backup) {
                    if(is_valid) {
                        hlt_mon.get_latched(data.ltc_alt);
                        state = st_idle;
                    } else {
                        state = st_read;
                        is_backup = true;
                    }
                } else {
                    start_write();
                }
                break;
            // Additional states...
        }
    }
}
```

## 5. Subsystem Integration and Interactions

### 5.1 Integration with BMS Core

All four subsystems integrate with the BMS core architecture:
- They implement the `Istep` interface for task scheduling
- They access system variables through the `BMS_vars` singleton
- They operate within the dual-priority task system (high and low priority)

### 5.2 Cross-Subsystem Interactions

The subsystems interact in several ways:

1. **Cell Balancing and SOC**:
   - Cell balancing decisions consider SOC values
   - SOC calculation requires stable conditions (low current) that may be affected by balancing

2. **Health Monitoring and Lifetime Statistics**:
   - Latched alerts from Health Monitor are stored in Lifetime Statistics
   - Lifetime statistics may influence health assessments

3. **SOC and Lifetime Statistics**:
   - SOC calculation uses battery capacity that may degrade over time
   - Lifetime statistics track SOC-related events (charge cycles)

4. **Cell Balancing and Health Monitoring**:
   - Cell balancing helps prevent cell voltage imbalances that could trigger health alerts
   - Health alerts may disable cell balancing under certain conditions

### 5.3 Data Flow Between Subsystems

The primary data flow paths between subsystems are:

1. **AFE → SOC → Health Monitor**:
   - AFE provides voltage and current measurements
   - SOC calculates state of charge
   - Health Monitor evaluates SOC for potential alerts

2. **Health Monitor → Lifetime Manager**:
   - Health Monitor provides latched alerts
   - Lifetime Manager stores alerts in non-volatile memory

3. **BMS_vars → All Subsystems**:
   - Central repository for all battery measurements
   - Provides consistent data access for all subsystems

## 6. Referenced Context Files

The following context files provided useful information for understanding the BMS subsystems:

- **05_BMS_Core_Architecture.md**: Provided overview of the BMS system architecture, task scheduling, and component relationships
- **04_AFE_Driver_Implementation.md**: Provided details on the Analog Front End driver that interfaces with the battery cells

## Summary

The BMS system implements four key subsystems that work together to provide comprehensive battery management:

1. **Cell Balancing System**: Ensures uniform charge across cells through voltage monitoring and controlled discharge of higher-voltage cells, with safety mechanisms to prevent over-discharge.

2. **State of Charge Calculation**: Combines OCV method and coulomb counting to accurately estimate remaining battery capacity, with pack-level SOC determined by the minimum string SOC.

3. **Health Monitoring**: Detects and tracks fault conditions at both pack and string levels, with support for permanent latching of critical alerts.

4. **Lifetime Statistics Management**: Tracks comprehensive battery usage statistics and stores them in non-volatile memory with redundancy and data integrity checks.

These subsystems are tightly integrated with the BMS core architecture and with each other, sharing data through the central BMS_vars interface and operating within the dual-priority task scheduling system.