# Generated from:

- items/sw_BMS/code/BMS/code/include/Alerts_defs.h (8069 tokens)
- items/sw_BMS/code/BMS/code/include/Alerts_manager.h (250 tokens)
- items/sw_BMS/code/BMS/code/include/Ialert.h (86 tokens)
- items/sw_BMS/code/BMS/code/include/Pack_alerts.h (1039 tokens)
- items/sw_BMS/code/BMS/code/include/String_alerts.h (1497 tokens)
- items/sw_BMS/code/BMS/code/source/Alerts_defs.cpp (3758 tokens)
- items/sw_BMS/code/BMS/code/source/Alerts_manager.cpp (238 tokens)
- items/sw_BMS/code/BMS/code/source/Pack_alerts.cpp (255 tokens)
- items/sw_BMS/code/BMS/code/source/String_alerts.cpp (437 tokens)

## With context from:

- PackageSummaries/Amazon-PrimeAir/items/BMS/03_Battery_Management_Features.md (5953 tokens)

---

# BMS Alert System Architecture and Implementation

## 1. Alert System Architecture Overview

The BMS alert system is designed as a comprehensive monitoring framework for detecting, tracking, and responding to various battery conditions. The architecture follows an object-oriented design with several key components:

### 1.1 Core Components

1. **Alert Interface (`Ialert`)**
   - Defines the base interface for all alert types
   - Provides a virtual `check()` method that must be implemented by all alert types
   - Uses a protected destructor to prevent direct deletion through base pointers

2. **Generic Alert Handler (`Alert_it`)**
   - Base class for most alert implementations
   - Implements common alert behavior including timeout management and latching
   - Provides a template method pattern with `check()` calling the abstract `check0()`

3. **Specific Alert Types**
   - Multiple specialized alert classes derived from `Alert_it`
   - Each implements specific detection logic for different battery conditions
   - Examples include `Ubscrt` (imbalance string current), `Hiptrt` (high PCBA temperature), etc.

4. **Alert Managers**
   - `Alerts_manager`: Generic manager for processing collections of alerts
   - `Pack_alerts`: Manages alerts for the entire battery pack
   - `String_alerts`: Manages alerts for individual battery strings

### 1.2 Class Hierarchy

```
Ialert (Interface)
└── Alert_it (Abstract Base Class)
    ├── Ubscrt (Imbalance string current)
    ├── Hiptrt (High PCBA temperature)
    ├── Fweror (Firmware version error)
    ├── Hweror (Hardware version error)
    ├── Inierr (Initialization error)
    ├── Auterr (Authentication error)
    ├── Tmpinv (Invalid temperature data)
    ├── Tmpstl (Stale temperature measurement)
    ├── Loctto (Low cell temperature at take-off)
    ├── Loctch (Low cell temperature at charge)
    ├── Hictto (High cell temperature at take-off)
    ├── Hictch (High cell temperature at charge)
    ├── Hictrt (High cell temperature at run-time)
    ├── Losvrt (Low string voltage at run-time)
    ├── Hiscrt (High string current at run-time)
    ├── Locvrt (Low cell voltage at run-time)
    ├── Hicvto (High cell voltage at take-off)
    ├── Hicvch (High cell voltage at charge)
    ├── Ubcvrt (Imbalance cell voltage at run-time)
    ├── Loelto (Low SoC at take-off)
    ├── Loelds (Low SoC at descending)
    ├── Seninv (Invalid data sensor)
    ├── Curinv (Invalid current sensor)
    ├── Cvlinv (Invalid cell voltage measurement)
    ├── Senstl (Stale sensor measurement)
    ├── Loelln (Low SoC, landing needed)
    ├── Tmpbnd (Cell temperature boundary)
    ├── Nmelln (Nominal low-energy level)
    └── Hicvlt (High cell voltage latched)

Locvpw (Special case with nested alert types)
├── Pocurr (Positive current alert)
└── Necurr (Negative current alert)
```

### 1.3 Alert Management Structure

The alert system is organized into two main categories:

1. **Pack-level alerts** (`Pack_alerts`):
   - Managed by the `Pack_alerts` class
   - Monitor conditions affecting the entire battery pack
   - Examples: imbalance string current, high PCBA temperature, firmware errors

2. **String-level alerts** (`String_alerts`):
   - Managed by the `String_alerts` class
   - Monitor conditions affecting individual battery strings
   - Examples: cell temperature, cell voltage, string current, state of charge

## 2. Alert Interface and Base Implementation

### 2.1 Alert Interface (`Ialert`)

The `Ialert` interface defines the contract for all alert types:

```cpp
struct Ialert {
public:
    // Alert check generic method
    virtual bool check() = 0;

protected:
    ~Ialert();  // Protected destructor
};
```

This interface ensures that all alert types implement a `check()` method that returns a boolean indicating whether the alert condition is active.

### 2.2 Generic Alert Handler (`Alert_it`)

The `Alert_it` class provides a common implementation for most alerts:

```cpp
struct Alert_it: public Ialert {
public:
    // Constructor with timeout and latching parameters
    explicit Alert_it(Real delay, bool latched0 = false);

    // Implementation of the check method from Ialert
    virtual bool check();

protected:
    bool is_set;        // Alert flag
    Base::Timeout tout; // Working expiration timer
    bool latched;       // Latched flag

    // Abstract method for specific condition checking
    virtual bool check0() = 0;

private:
    Alert_it(const Alert_it& orig);            // = delete
    Alert_it& operator=(const Alert_it& orig); // = delete
};
```

Key features of `Alert_it`:

1. **State Tracking**:
   - `is_set`: Boolean flag indicating if the alert is currently active
   - `latched`: Boolean flag indicating if the alert should remain set once triggered

2. **Timeout Management**:
   - `tout`: Timer to ensure alert conditions persist for a minimum duration
   - Constructor takes a `delay` parameter specifying the required duration

3. **Template Method Pattern**:
   - `check()`: Implements common alert behavior
   - `check0()`: Abstract method for specific condition checking

The implementation of `check()` shows the alert activation logic:

```cpp
bool Alerts_defs::Alert_it::check() {
    const bool to_set = check0();  // Check specific condition
    if(!is_set) {
        if(to_set) {
            is_set = tout.expired();  // Set alert if condition persists for timeout duration
        }
        else {
            tout.start();  // Reset timeout if condition not met
        }
    }
    else {
        is_set = !latched && !to_set;  // Clear alert if not latched and condition cleared
    }
    return is_set;
}
```

This implementation provides:
- **Hysteresis**: Requires conditions to persist for a specified duration
- **Latching**: Option to permanently set alerts until system reset
- **Automatic clearing**: Non-latched alerts clear when conditions return to normal

## 3. Alert Types and Detection Logic

The BMS implements a comprehensive set of alert types for various battery conditions. Each alert type implements specific detection logic in its `check0()` method.

### 3.1 Pack-Level Alerts

#### 3.1.1 Imbalance String Current (`Ubscrt`)

Detects when current imbalance between strings exceeds a threshold:

```cpp
bool Alerts_defs::Ubscrt::check0() {
    static const Real curr_max = 1000.0F;   // 10 amperes
    const Real last_string_current = BMS_vars::get_instance().get_sc(nb_str-1);
    const Real first_string_current = BMS_vars::get_instance().get_sc(0);
    return ((last_string_current - first_string_current) > curr_max);
}
```

- **Timeout**: 500ms
- **Latched**: Yes (permanently set once triggered)
- **Threshold**: 10A difference between first and last string

#### 3.1.2 High PCBA Temperature (`Hiptrt`)

Detects when the PCBA temperature exceeds a safe threshold:

```cpp
bool Alerts_defs::Hiptrt::check0() {
    static const Real tmp_max = 70.0F;  // 70 degrees
    const Real pcba_tmp = BMS_vars::get_instance().get_tmp();
    return (pcba_tmp > tmp_max);
}
```

- **Timeout**: 2000ms
- **Latched**: Yes
- **Threshold**: 70°C

#### 3.1.3 Firmware and Hardware Errors

Several alerts detect system-level errors:

- **Firmware Error** (`Fweror`): Detects firmware application errors
- **Hardware Error** (`Hweror`): Detects hardware incompatibility with firmware
- **Initialization Error** (`Inierr`): Detects initialization failures
- **Authentication Error** (`Auterr`): Detects authentication failures

These alerts have no timeout (immediate triggering) and are typically latched.

#### 3.1.4 Temperature Monitoring Alerts

Alerts for PCBA temperature sensor issues:

- **Invalid Temperature** (`Tmpinv`): Detects when temperature readings are outside valid range (-10°C to 125°C)
- **Stale Temperature** (`Tmpstl`): Detects when temperature measurements are not being updated

Both have a 2000ms timeout and are not latched.

#### 3.1.5 Cell Temperature Boundary (`Tmpbnd`)

Detects when any cell temperature is outside the safe operating range:

```cpp
bool Alerts_defs::Tmpbnd::check0() {
    static const Real ct_min = -20.0F;
    static const Real ct_max = 80.0F;
    bool ret = false;
    BMS_vars& vars = BMS_vars::get_instance();
    for(Uint16 i=0; !ret && (i<BMS_traits::nb_cell); i++) {
        for(Uint16 j=0; !ret && (j<BMS_traits::nb_str); j++) {
            const Real curr_ct = vars.get_ct(j, i);
            ret |= ((curr_ct < ct_min) || (curr_ct > ct_max));
        }
    }
    return ret;
}
```

- **Timeout**: 2000ms
- **Latched**: Yes
- **Thresholds**: Below -20°C or above 80°C

#### 3.1.6 Nominal Low Energy Level (`Nmelln`)

Detects when the battery's state of charge is low enough to require landing:

```cpp
bool Alerts_defs::Nmelln::check0() {
    static const Real soc_min = 0.31F;
    static const Real soc_rcv = 0.35F;
    bool ret = false;
    const bool old_rec = record;
    for(Uint16 i=0; (record==old_rec) && (i<BMS_traits::nb_str); i++) {
        const Real curr_soc = BMS_vars::get_instance().get_sc(i);
        if(!record) {
            record = ret = (curr_soc < soc_min);
        }
        else {
            ret = (curr_soc <= soc_rcv);
            record = !ret;
        }
    }
    return ret;
}
```

- **Timeout**: 200ms
- **Latched**: No
- **Thresholds**: 
  - Trigger: SoC < 31%
  - Recovery: SoC > 35%
- **Hysteresis**: Implements state tracking to prevent oscillation

### 3.2 String-Level Alerts

#### 3.2.1 Cell Temperature Alerts

Multiple alerts monitor cell temperature under different conditions:

- **Low Cell Temperature at Take-off** (`Loctto`): Below -10°C
- **Low Cell Temperature at Charge** (`Loctch`): Below 15°C
- **High Cell Temperature at Take-off** (`Hictto`): Above 35°C
- **High Cell Temperature at Charge** (`Hictch`): Above 35°C
- **High Cell Temperature at Run-time** (`Hictrt`): Above 75°C

All have a 2000ms timeout, with `Hictrt` being latched.

#### 3.2.2 String Voltage and Current Alerts

Alerts for string-level electrical parameters:

- **Low String Voltage at Run-time** (`Losvrt`): Below 45.5V
- **High String Current at Run-time** (`Hiscrt`): Below -20A or above 167A

Both have a 500ms timeout, with `Hiscrt` being latched.

#### 3.2.3 Cell Voltage Alerts

Multiple alerts monitor cell voltage under different conditions:

- **Low Cell Voltage at Run-time** (`Locvrt`): When minimum cell voltage drops below a threshold
- **Low Cell Voltage Power Loss** (`Locvpw`): Special case with different thresholds based on current direction
- **High Cell Voltage at Take-off** (`Hicvto`): Above 4.25V
- **High Cell Voltage at Charge** (`Hicvch`): Above 4.28V
- **Imbalance Cell Voltage** (`Ubcvrt`): When voltage difference between cells exceeds 300mV
- **High Cell Voltage Latched** (`Hicvlt`): When maximum cell voltage exceeds 4.7V (permanently latched)

Most have a 500ms timeout, with `Locvrt` and `Hicvlt` being latched.

#### 3.2.4 State of Charge Alerts

Alerts for battery state of charge:

- **Low SoC at Take-off** (`Loelto`): Below 94%
- **Low SoC at Descending** (`Loelds`): Below 35% (recovers above 39%)
- **Low SoC Landing Needed** (`Loelln`): Below 28% (recovers above 31%)

These alerts implement hysteresis with different trigger and recovery thresholds.

#### 3.2.5 Sensor Validity Alerts

Alerts for sensor data validity:

- **Invalid Sensor Data** (`Seninv`): Temperature readings outside valid range
- **Invalid Current Data** (`Curinv`): Current readings outside valid range
- **Invalid Cell Voltage** (`Cvlinv`): Cell voltage readings above 4.9V
- **Stale Sensor Data** (`Senstl`): Sensor data not being updated

Most have a 500ms timeout and are not latched.

### 3.3 Special Case: Low Cell Voltage Power Loss (`Locvpw`)

The `Locvpw` alert uses a more complex implementation with nested alert types:

```cpp
struct Locvpw: public Ialert {
    // Constructor
    explicit Locvpw(Uint16 str_id0);
    
    // Check method implementation
    virtual bool check();

private:
    // Nested alert for positive current
    struct Pocurr: public Alert_it {
        explicit Pocurr(Uint16 str_id0);
        virtual bool check0();
    };
    
    // Nested alert for negative current
    struct Necurr: public Alert_it {
        explicit Necurr(Uint16 str_id0);
        virtual bool check0();
    };
    
    const Uint16 str_id;
    Pocurr pc;          // Positive current handler
    Necurr nc;          // Negative current handler
    bool is_set;        // Detection flag
    
    // Helper method for cell voltage checking
    static bool check_cv(Uint16 str_id, Uint16 lim);
};
```

This alert uses different thresholds and timeouts based on current direction:
- **Positive current** (discharge): 2.0V threshold, 500ms timeout
- **Negative current** (charge): 2.79V threshold, 3000ms timeout

The implementation shows how the alert combines these conditions:

```cpp
bool Alerts_defs::Locvpw::check() {
    static const Real curr_ref = 150.0F;  // 1.5 amps
    const Real sc = BMS_vars::get_instance().get_sc(str_id);
    bool ret = ((sc > curr_ref) && pc.check())
                  || ((sc < -curr_ref) && nc.check());
    is_set = ret;
    if(is_set) {
        ret = true; // ret always true once set
    }
    return ret;
}
```

## 4. Alert Management System

### 4.1 Alert Manager (`Alerts_manager`)

The `Alerts_manager` class provides a generic mechanism for processing collections of alerts:

```cpp
class Alerts_manager {
public:
    typedef Base::Bitmask<Uint32>   Flags;  // Type for flags, as 32-bit bitmask
    typedef Base::Mblock<Ialert*>   Procs;  // Type for array of alert processes
    
    Alerts_manager(Procs& procs0, Flags& flags0);
    void step();

private:
    bool step0(Uint16 idx);
    
    const Uint16      nb_procs; // Total number of processes
    Procs&            procs;    // Reference to processes to step on
    Flags&            flags;    // Reference to the bitmask for alert states
};
```

The `step()` method processes all alerts and updates the flags:

```cpp
void Alerts_manager::step() {
    for(Uint16 i=0; i<nb_procs; i++) {
        flags.set(i, procs[i]->check());
    }
}
```

### 4.2 Pack Alerts Manager (`Pack_alerts`)

The `Pack_alerts` class manages alerts for the entire battery pack:

```cpp
class Pack_alerts {
public:
    enum Id {  // Identifiers of health alerts for the whole battery pack
        eps_batt_ub_sc_rt,  // Imbalance string(s) current at run-time
        eps_batt_hi_pt_rt,  // High PCBA temperature
        eps_batt_fw_error,  // Firmware application error
        eps_batt_hw_error,  // Hardware incompatible with FW
        eps_batt_in_error,  // Initialization failed
        eps_batt_au_error,  // Authentication failed
        eps_batt_temp_inv,  // PCBA temperature data invalid
        eps_batt_temp_stl,  // PCBA temperature measurement invalid
        eps_batt_temp_bnd,  // Cell temperature boundary failure
        eps_batt_nm_el_ln,  // Nominal Low SoC to urgently initiate landing
        nb_alerts           // Total number of alerts for the whole pack
    };
    
    Pack_alerts(Uint16 nb_str, Alerts_manager::Flags& flags0);
    void step();

private:
    struct Processes {
        explicit Processes(Uint16 nb_str);
        Alerts_manager::Procs& get_procs();
        
        // Alert instances
        Alerts_defs::Ubscrt ub;     // Alert for imbalance string current
        Alerts_defs::Hiptrt pt;     // Alert for high PCBA temperature
        Alerts_defs::Fweror fw;     // Alert for firmware error
        Alerts_defs::Hweror hw;     // Alert for hardware error
        Alerts_defs::Inierr in;     // Alert for initialization error
        Alerts_defs::Auterr au;     // Alert for authentication error
        Alerts_defs::Tmpinv iv;     // Alert for invalid PCBA temperature data
        Alerts_defs::Tmpstl st;     // Alert for stale PCBA temperature measurement
        Alerts_defs::Tmpbnd tmpbnd; // Alert for temperature out of bounds
        Alerts_defs::Nmelln nmelln; // Alert for nominal low energy level
        
        Alerts_manager::Procs procs; // Array of alert processes
    };
    
    Processes       procs;  // Structure handling pack alerts
    Alerts_manager  almgr;  // Alerts manager
};
```

The `Pack_alerts` class:
1. Defines an enumeration of pack-level alert types
2. Creates instances of all pack-level alert classes
3. Registers these alerts with an `Alerts_manager`
4. Provides a `step()` method to process all alerts

### 4.3 String Alerts Manager (`String_alerts`)

The `String_alerts` class manages alerts for individual battery strings:

```cpp
class String_alerts {
public:
    enum Id {  // Definition of health alerts for a particular string
        eps_batt_lo_ct_to,  // Low cell(s) temperature at take-off
        eps_batt_lo_ct_ch,  // Low cell(s) temperature at charge
        eps_batt_hi_ct_to,  // High cell(s) temperature at take-off
        eps_batt_hi_ct_ch,  // High cell(s) temperature at charge
        eps_batt_hi_ct_rt,  // High cell(s) temperature at run-time
        eps_batt_lo_sv_rt,  // Low string voltage at run-time
        eps_batt_hi_sc_rt,  // High string current at run-time
        eps_batt_lo_cv_rt,  // High string voltage at run-time
        eps_batt_lo_cv_pw,  // Low cell(s) voltage, possible power loss
        eps_batt_hi_cv_to,  // High cell(s) voltage at take-off
        eps_batt_hi_cv_ch,  // High cell(s) voltage at charge
        eps_batt_ub_cv_rt,  // Imbalance cell(s) voltage at run-time
        eps_batt_lo_el_to,  // Low energy level at take-off
        eps_batt_lo_el_ds,  // Low energy level at descent
        eps_batt_sens_inv,  // Sensor(s) data invalid
        eps_batt_curr_inv,  // Current data invalid
        eps_batt_cvlt_inv,  // Cell voltage data invalid
        eps_batt_sens_stl,  // Sensor(s) measurement invalid
        eps_batt_lo_el_ln,  // Low energy level, urgent landing needed
        eps_batt_hi_cv_lt,  // High cell voltage, latched permanently
        nb_alerts           // Total number of alerts for a particular string
    };
    
    explicit String_alerts(Uint16 str_id, Alerts_manager::Flags& flags0);
    void step();

private:
    struct Processes {
        explicit Processes(Uint16 str_id);
        Alerts_manager::Procs& get_procs();
        
        // Alert instances (20 different alert types)
        Alerts_defs::Loctto loctto; // Alert for low cell temperature at take-off
        Alerts_defs::Loctch loctch; // Alert for low cell temperature at charge
        // ... (17 more alert instances)
        Alerts_defs::Hicvlt hicvlt; // Alert for high cell voltage, latched permanently
        
        Alerts_manager::Procs procs; // Array of alert processes
    };
    
    Processes       procs;  // Structure handling string alerts
    Alerts_manager  almgr;  // Alerts manager
};
```

The `String_alerts` class:
1. Defines an enumeration of string-level alert types
2. Creates instances of all string-level alert classes for a specific string
3. Registers these alerts with an `Alerts_manager`
4. Provides a `step()` method to process all alerts

## 5. Alert Processing Flow

### 5.1 Alert Initialization

1. **Alert Object Creation**:
   - Each alert type is instantiated with appropriate parameters
   - For pack alerts: `Pack_alerts::Processes` constructor creates all pack-level alerts
   - For string alerts: `String_alerts::Processes` constructor creates all string-level alerts

2. **Alert Registration**:
   - Alert objects are stored in an array of `Ialert*` pointers
   - Each alert is assigned a specific index corresponding to its enum value
   - The array is passed to an `Alerts_manager` instance

### 5.2 Alert Processing Cycle

1. **Periodic Processing**:
   - The `step()` method is called periodically on `Pack_alerts` and `String_alerts` instances
   - These methods delegate to their respective `Alerts_manager` instances

2. **Alert Checking**:
   - `Alerts_manager::step()` iterates through all registered alerts
   - For each alert, it calls the `check()` method
   - The result (true/false) is stored in the corresponding bit of the flags bitmask

3. **Alert Condition Evaluation**:
   - Each alert's `check()` method calls its specific `check0()` implementation
   - The `check0()` method evaluates the specific condition for that alert type
   - The base `check()` method handles timeout and latching behavior

4. **Flag Management**:
   - Alert states are stored in 32-bit bitmasks
   - Separate bitmasks are maintained for pack-level and string-level alerts
   - These bitmasks can be queried by other components of the BMS

### 5.3 Alert State Transitions

The alert system implements a state machine for each alert:

1. **Inactive State**:
   - `is_set` is false
   - When `check0()` returns true, the timeout timer starts
   - Alert remains inactive until the condition persists for the timeout duration

2. **Active State**:
   - `is_set` is true
   - For non-latched alerts, returns to inactive when `check0()` returns false
   - For latched alerts, remains active regardless of `check0()` result

3. **Hysteresis Implementation**:
   - Some alerts (like `Loelds` and `Loelln`) implement additional hysteresis
   - They use different thresholds for activation and deactivation
   - They maintain additional state variables to track transitions

## 6. Integration with Health Monitoring and Lifetime Statistics

### 6.1 Health Monitoring Integration

The alert system is a core component of the BMS health monitoring system:

1. **Alert Flag Access**:
   - The `Health_monitor` class maintains the alert flag bitmasks
   - It passes these bitmasks to the `Pack_alerts` and `String_alerts` constructors
   - It provides methods to query alert states for reporting and decision-making

2. **Alert Processing**:
   - The `Health_monitor::step()` method triggers alert processing
   - It calls `step()` on all `String_alerts` instances and the `Pack_alerts` instance

### 6.2 Lifetime Statistics Integration

The alert system integrates with the lifetime statistics system:

1. **Latched Alert Persistence**:
   - Critical latched alerts are stored in non-volatile memory
   - The `Lifetime_mgr` class manages loading and saving these alerts
   - The `Health_monitor` provides methods to get and set latched alerts

2. **Alert Serialization**:
   - The `Health_monitor::cget_pack()` and `cget_str()` methods serialize alert states
   - These serialized states can be included in telemetry or stored for analysis

## 7. Alert System Design Patterns

### 7.1 Object-Oriented Design Patterns

The alert system employs several design patterns:

1. **Template Method Pattern**:
   - Base class (`Alert_it`) implements common behavior in `check()`
   - Derived classes implement specific logic in `check0()`

2. **Strategy Pattern**:
   - Different alert types encapsulate different detection strategies
   - The `Alerts_manager` treats all alerts uniformly through the `Ialert` interface

3. **Composite Pattern**:
   - Individual alerts are composed into collections (`Pack_alerts` and `String_alerts`)
   - These collections are processed as a unit

4. **Facade Pattern**:
   - `Pack_alerts` and `String_alerts` provide simplified interfaces to complex alert processing
   - They hide the details of alert creation and management

### 7.2 Bitmask Management

The system uses bitmasks for efficient storage and manipulation of alert states:

1. **Flag Storage**:
   - 32-bit bitmasks store up to 32 alert states in a single integer
   - Separate bitmasks for pack-level and string-level alerts

2. **Flag Operations**:
   - `set(index, value)`: Sets or clears a specific bit
   - `get(index)`: Retrieves the state of a specific bit
   - `clear(index)`: Clears a specific bit

3. **Memory Efficiency**:
   - Compact representation of multiple boolean states
   - Efficient serialization for storage and communication

### 7.3 Alert Initialization and Registration

The alert system uses a registration pattern:

1. **Alert Creation**:
   - Alerts are created with appropriate parameters (timeout, latching behavior)
   - String-specific alerts are created with the string ID

2. **Alert Registration**:
   - Alerts are stored in arrays of `Ialert*` pointers
   - Each alert is assigned a specific index corresponding to its enum value

3. **Validation**:
   - Runtime assertions ensure all alert slots are filled
   - `Base::Assertions::runtime(alert_id==nb_alerts);`

## 8. Comprehensive Alert List and Parameters

### 8.1 Pack-Level Alerts

| Alert ID | Description | Timeout | Latched | Threshold |
|----------|-------------|---------|---------|-----------|
| eps_batt_ub_sc_rt | Imbalance string current | 500ms | Yes | >10A difference |
| eps_batt_hi_pt_rt | High PCBA temperature | 2000ms | Yes | >70°C |
| eps_batt_fw_error | Firmware error | 0ms | Yes | N/A |
| eps_batt_hw_error | Hardware error | 0ms | No | N/A |
| eps_batt_in_error | Initialization error | 0ms | No | N/A |
| eps_batt_au_error | Authentication error | 0ms | No | N/A |
| eps_batt_temp_inv | Invalid temperature data | 2000ms | No | <-10°C or >125°C |
| eps_batt_temp_stl | Stale temperature data | 2000ms | No | N/A |
| eps_batt_temp_bnd | Cell temperature boundary | 2000ms | Yes | <-20°C or >80°C |
| eps_batt_nm_el_ln | Nominal low energy level | 200ms | No | <31% SoC (recover >35%) |

### 8.2 String-Level Alerts

| Alert ID | Description | Timeout | Latched | Threshold |
|----------|-------------|---------|---------|-----------|
| eps_batt_lo_ct_to | Low cell temperature at take-off | 2000ms | No | <-10°C |
| eps_batt_lo_ct_ch | Low cell temperature at charge | 2000ms | No | <15°C |
| eps_batt_hi_ct_to | High cell temperature at take-off | 2000ms | No | >35°C |
| eps_batt_hi_ct_ch | High cell temperature at charge | 2000ms | No | >35°C |
| eps_batt_hi_ct_rt | High cell temperature at run-time | 2000ms | Yes | >75°C |
| eps_batt_lo_sv_rt | Low string voltage at run-time | 500ms | No | <45.5V |
| eps_batt_hi_sc_rt | High string current at run-time | 500ms | Yes | <-20A or >167A |
| eps_batt_lo_cv_rt | Low cell voltage at run-time | 200ms | Yes | <(max-400mV) |
| eps_batt_lo_cv_pw | Low cell voltage power loss | 500ms/3000ms | No | <2.0V (discharge), <2.79V (charge) |
| eps_batt_hi_cv_to | High cell voltage at take-off | 500ms | No | >4.25V |
| eps_batt_hi_cv_ch | High cell voltage at charge | 500ms | No | >4.28V |
| eps_batt_ub_cv_rt | Imbalance cell voltage | 500ms | No | >300mV difference |
| eps_batt_lo_el_to | Low SoC at take-off | 0ms | Yes | <94% |
| eps_batt_lo_el_ds | Low SoC at descending | 0ms | No | <35% (recover >39%) |
| eps_batt_sens_inv | Invalid sensor data | 2000ms | No | <-10°C or >125°C |
| eps_batt_curr_inv | Invalid current data | 500ms | No | <-70A or >420A |
| eps_batt_cvlt_inv | Invalid cell voltage | 500ms | No | >4.9V |
| eps_batt_sens_stl | Stale sensor data | 500ms | No | N/A |
| eps_batt_lo_el_ln | Low SoC landing needed | 0ms | No | <28% (recover >31%) |
| eps_batt_hi_cv_lt | High cell voltage latched | 500ms | Yes | >4.7V |

## Referenced Context Files

The following context file provided useful information for understanding how the alert system integrates with other BMS components:

- **03_Battery_Management_Features.md**: Provided information on how the alert system integrates with the Health Monitoring and Lifetime Statistics components of the BMS.

## Summary

The BMS alert system is a comprehensive framework for detecting, tracking, and responding to various battery conditions. It uses an object-oriented design with a base alert interface, a generic alert handler, and multiple specialized alert types. The system is organized into pack-level and string-level alerts, each managed by dedicated classes.

The alert processing flow includes initialization, periodic checking, condition evaluation, and flag management. Each alert implements specific detection logic with appropriate thresholds, timeouts, and latching behavior. The system integrates with the health monitoring and lifetime statistics components of the BMS.

The design employs several patterns including template method, strategy, composite, and facade. It uses bitmasks for efficient storage and manipulation of alert states. The alert initialization and registration process ensures that all alerts are properly created and assigned to their respective indices.

The comprehensive set of alerts covers a wide range of battery conditions including temperature, voltage, current, state of charge, and sensor validity. Each alert has specific parameters for timeout duration, latching behavior, and threshold values.