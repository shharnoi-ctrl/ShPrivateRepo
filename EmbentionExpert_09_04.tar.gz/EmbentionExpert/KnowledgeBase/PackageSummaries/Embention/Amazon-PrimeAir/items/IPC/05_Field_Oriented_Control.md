# Generated from:

- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/include/Control_foc_noenc.h (6234 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/source/Control_foc_noenc.cpp (21605 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/source/Control_foc_noenc_amz.cpp (1028 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/source/Control_foc_noenc_ver.cpp (8409 tokens)

## With context from:

- PackageSummaries/Amazon-PrimeAir/items/IPC/06_Motor_Control_State_Machine.md (4178 tokens)

---

# Field-Oriented Control (FOC) Implementation for Precise Motor Control

## 1. Control Architecture Overview

The Field-Oriented Control (FOC) implementation is encapsulated in the `Control_foc_noenc` class within the `MCxx` namespace. This class provides a sophisticated motor control algorithm that transforms three-phase currents into a rotating reference frame to achieve precise control of Permanent Magnet Synchronous Motors (PMSM).

### 1.1 Core Components and Transformations

The FOC algorithm consists of four main phases:

1. **Sensing Phase**: Reads phase currents, DC voltage, and position feedback
2. **Transformation Phase**: Applies Clarke and Park transformations to convert three-phase currents to a rotating reference frame
3. **Control Phase**: Implements PI controllers for current and speed control
4. **Output Phase**: Generates Space Vector PWM signals through inverse transformations

The key mathematical transformations include:

- **Clarke Transformation**: Converts three-phase currents (a,b,c) to a two-phase stationary reference frame (α,β)
- **Park Transformation**: Converts stationary frame (α,β) to rotating reference frame (d,q)
- **Inverse Park**: Converts control outputs from rotating frame back to stationary frame
- **Inverse Clarke**: Converts stationary frame back to three-phase voltages

### 1.2 Control Modes

The FOC implementation supports multiple control modes, each corresponding to a state in the Motor Controller Interface (MCI):

| Mode | Description | Primary Function |
|------|-------------|------------------|
| `off` | PWM disabled | `step_off()` |
| `calibration` | ADC calibration | `step_cal()` |
| `alignment` | Motor alignment | `step_alignment()` |
| `open_loop` | Open-loop startup | `step_openloop()` |
| `zero_rpm` | Zero speed control | `step_zero_rpm()` |
| `zero_current` | Zero current (windmill) | `step_zero_current()` |
| `rpm` | Speed control | `step_rpm()` |

## 2. Functional Behavior and Logic

### 2.1 Main Control Flow

The main execution flow is managed by the `step()` method, which selects the appropriate control mode based on the current MCI state:

```cpp
void Control_foc_noenc::step() {
    switch(st) {
        case MCI::off:
            step_off();
            break;
        case MCI::calibration:
            step_cal();
            break;
        case MCI::alignment:
            step_alignment();
            break;
        case MCI::open_loop:
            step_openloop();
            break;
        case MCI::zero_rpm:
            step_zero_rpm();
            break;
        case MCI::zero_current:
            step_zero_current();
            break;
        case MCI::rpm:
            step_rpm();
            break;
        default:
            asm_stop();
            break;
    }
}
```

Each control mode implements a specific sequence of operations tailored to its purpose, but most follow a common pattern:
1. Sense inputs (currents, voltages)
2. Process feedback (position, speed)
3. Execute control algorithms
4. Generate outputs (PWM duty cycles)
5. Check for faults

### 2.2 Speed Control Mode (`rpm`)

The speed control mode (`step_rpm()`) implements the complete FOC algorithm:

```cpp
void Control_foc_noenc::step_rpm() {
    step_sense();                // Read currents and voltages
    clarke1.step(iph.get_iph_u(), iph.get_iph_v(), iph.get_iph_w());  // Clarke transformation
    step_observer();             // Estimate rotor position and speed
    
    if(!c1_data.terminal_fault) {
        step_iqid_limiter();     // Calculate current limits
        step_speed();            // Speed PI control
        step_mtpa_lut();         // Maximum Torque Per Ampere calculation
        park1.step(clarke1.alpha, clarke1.beta, Sincos(flux_angle));  // Park transformation
        step_current();          // Current PI control
        step_output();           // Generate PWM outputs
    }
    
    check_health();              // Check for faults
}
```

### 2.3 Sensing and Measurement

The `step_sense()` method reads all required inputs:

```cpp
void Control_foc_noenc::step_sense() {
    iph.step();                  // Read phase currents
    
    // Read and filter DC voltage
    vdc = adc_voltage.get_sample_norm() * max_vdc;
    vdc_filt = Ewma0::compute(alpha_dc, vdc, vdc_filt);
    
    // Read secondary voltage (for overvoltage protection)
    vdc2 = adc_voltage2.get_sample_norm() * max_vdc2;
    
    // Read and filter DC current
    idc = (adc_dc_curr.get_sample_volts() - ical_idc) * r_shunt_dc;
    idc_filt = Ewma0::compute(alpha_dc, idc, idc_filt);
    
    // Update controller parameters if needed
    if(motor.alpha > 0.0F) {
        const Real r_by_l = motor.rs * motor.inv_ls;
        pi_iq.update_ti_1(r_by_l);
        pi_id.update_ti_1(r_by_l);
    }
    
    // Read position sensors
    sincos_sensor1.step();
    sincos_sensor2.step();
}
```

### 2.4 Position and Speed Estimation

The `step_observer()` method estimates rotor position and speed using a combination of techniques:

```cpp
void Control_foc_noenc::step_observer() {
    // Sliding Mode Observer for back-EMF estimation
    smo1.step();
    
    // Position sensor processing
    curr_estimator->step();
    const Real ls_eangle = curr_estimator->get_angle();
    const Real ls_omegae = curr_estimator->get_speed();
    
    // Filter low-speed estimate
    omegae_ls_filt = Ewma0::compute(alpha_speed, ls_omegae, omegae_ls_filt);
    
    // Calculate mixing ratio between low and high speed observers
    const Real p_hs = Rfun::clamp<Real>(
        ((Rmath::fabsr(omegae_ls_filt * motor.pp_1) - wmin_morph) / (wmax_morph - wmin_morph)),
        0.0F, 1.0F);
    const Real p_ls = 1.0F - p_hs;
    
    // High-speed observer (PLL)
    if(p_hs > 0.0F) {
        pll.step();
    } else {
        pll.reset(ls_eangle, ls_omegae);
    }
    
    const Real hs_eangle = pll.get_angle();
    const Real hs_omegae = pll.get_speed();
    
    // Filter high-speed estimate
    omegae_hs_filt = Ewma0::compute(alpha_speed, hs_omegae, omegae_hs_filt);
    
    // Combine estimates based on speed range
    omegae = p_hs * omegae_hs_filt + p_ls * omegae_ls_filt;
    omega = omegae * motor.pp_1;  // Convert electrical to mechanical speed
    
    // Calculate final flux angle with observer mixing
    const Real diff = Rfun::wrap2pi(hs_eangle - ls_eangle);
    flux_angle = Rfun::wrap2pi(p_hs * hs_eangle + p_ls * (hs_eangle - diff));
    
    // Set rotation direction flag
    is_inverted = (omegae < 0.0F);
    
    // Additional position compensation for sensorless mode
    step_position_sensorless();
}
```

### 2.5 Speed Control

The `step_speed()` method implements the speed PI controller:

```cpp
void Control_foc_noenc::step_speed() {
    // Rate-limit the desired velocity
    desired_vel += Rfun::clamp<Real>(
        spin_direction * input_rate - desired_vel,
        -max_delta_slew_rate,
        max_delta_slew_rate);
    
    // Update speed controller saturation limits
    pi_spd.update_sat(iq_min, iq_max);
    
    // Execute PI control with anti-windup
    pi_spd.step_aw(
        rt_period,
        desired_vel * motor.pp,  // Convert to electrical speed
        omegae,
        pi_iq.get_back_calculate_reference());
    
    // Update current limit flag
    current_limited = (spin_direction > 0.0F) ? 
        pi_spd.is_saturated_upper() : 
        pi_spd.is_saturated_lower();
}
```

### 2.6 Current Control

The `step_current()` method implements the d-q axis current controllers:

```cpp
void Control_foc_noenc::step_current() {
    // Calculate voltage saturation limit
    Real vsat = vdc * f_vdc * Const::ISQRT3;
    
    // D-axis current control
    pi_id.update_sat(-vsat, vsat);
    pi_id.step(rt_period, id, park1.ds);
    
    // Recalculate voltage limit for q-axis
    const Real vd = pi_id.get_out();
    vsat = Rmath::sqrtr(vsat * vsat - vd * vd);
    
    // Q-axis current control
    pi_iq.update_sat(-vsat, vsat);
    pi_iq.step(rt_period, iq, park1.qs);
    
    // Inverse Park transformation with angle advance
    ipark1.step(
        vd,
        pi_iq.get_out(),
        Sincos(flux_angle + num_advanced_angles * omegae * rt_period));
    
    // Inverse Clarke transformation
    i_clarke.step(ipark1.alpha, ipark1.beta);
}
```

### 2.7 Space Vector PWM Generation

The `step_output()` method generates the three-phase PWM signals:

```cpp
void Control_foc_noenc::step_output() {
    // Calculate zero-sequence component (third harmonic injection)
    const Real v_harm = -Const::ONEHALF * (
        Rfun::max<Real>(Rfun::max<Real>(i_clarke.a, i_clarke.b), i_clarke.c) +
        Rfun::min<Real>(Rfun::min<Real>(i_clarke.a, i_clarke.b), i_clarke.c));
    
    // Add zero-sequence component to each phase
    i_clarke.a += v_harm;
    i_clarke.b += v_harm;
    i_clarke.c += v_harm;
    
    // Calculate inverse of DC voltage (with protection)
    const Real i_vdc = (Rmath::fabsr(vdc) > 0.0F) ? 1.0F / vdc : 0.0F;
    
    // Calculate duty cycles
    duty_u = (i_clarke.a * i_vdc) + Const::ONEHALF;
    duty_v = (i_clarke.b * i_vdc) + Const::ONEHALF;
    duty_w = (i_clarke.c * i_vdc) + Const::ONEHALF;
    
    // Update PWM peripherals
    pwm1a.set(duty_u);
    pwm2a.set(duty_v);
    pwm3a.set(duty_w);
}
```

## 3. Control Modes in Detail

### 3.1 Calibration Mode

The calibration mode (`step_cal()`) performs ADC offset calibration:

```cpp
void Control_foc_noenc::step_cal() {
    if(!clk.ongoing()) {
        clk.tic();  // Start calibration timer
    }
    
    if(clk.toc() > tcal) {  // Calibration time elapsed
        clk.cancel();
        
        // Check phase current calibration values
        if(!Rfun::in_range<Real>(iph.get_iph_cal_u(), min_cal_offset, max_cal_offset)) {
            faults.set(f_cal_phu);
            faults.set(f_cal_fail);
        }
        
        if(!Rfun::in_range<Real>(iph.get_iph_cal_v(), min_cal_offset, max_cal_offset)) {
            faults.set(f_cal_phv);
            faults.set(f_cal_fail);
        }
        
        if(!Rfun::in_range<Real>(iph.get_iph_cal_w(), min_cal_offset, max_cal_offset)) {
            faults.set(f_cal_phw);
            faults.set(f_cal_fail);
        }
        
        // Check DC current calibration
        if(!Rfun::in_range<Real>(ical_idc, min_cal_offset, max_cal_offset)) {
            faults.set(f_cal_idc);
            faults.set(f_cal_fail);
        }
        
        // Signal calibration completion
        c2_data.init_complete = true;
        driver_ctrl.check_cal();
    }
    else {  // Calibration in progress
        iph.step_cal();  // Calibrate phase current sensors
        
        // Filter DC current calibration value
        ical_idc = Ewma0::compute(
            alpha_cal,
            adc_dc_curr.get_sample_volts(),
            ical_idc);
            
        driver_ctrl.step_cal();  // Calibrate driver
    }
}
```

### 3.2 Alignment Mode

The alignment mode (`step_alignment()`) establishes the initial rotor position:

```cpp
void Control_foc_noenc::step_alignment() {
    driver_ctrl.enable();  // Enable power stage
    
    if(!clk.ongoing()) {
        clk.tic();  // Start alignment timer
    }
    
    Real tclk = clk.toc();
    step_sense();  // Read sensors
    
    if(!critical_fault && !c2_data.aligment_complete) {
        if(is_sensored) {
            curr_estimator->step();  // Update position estimate
        }
        
        // Apply constant d-axis current to align rotor
        const Sincos sincos0(0.0F);
        ipark1.step(id0 * motor.rs, 0.0F, sincos0);
        i_clarke.step(ipark1.alpha, ipark1.beta);
        step_output();  // Generate PWM outputs
        
        if(tclk > t_align) {  // Alignment complete
            clk.cancel();
            
            // Update sensor alignment
            sincos_sensor1.update_alignment_error();
            sincos_sensor2.update_alignment_error();
            
            // Reset position estimator
            curr_estimator->reset();
            
            // Signal alignment completion
            c2_data.aligment_complete = true;
            step_alignment_complete();
        }
    }
    
    check_health();  // Check for faults
}
```

### 3.3 Open Loop Mode

The open loop mode (`step_openloop()`) performs controlled startup:

```cpp
void Control_foc_noenc::step_openloop() {
    step_sense();  // Read sensors
    
    if(!critical_fault && !c2_data.open_loop_complete) {
        vmotor.step();  // Update virtual motor model
        const Real openloop_omega = vmotor.get_speed();
        
        step_openloop_pimpl();  // Implementation-specific processing
        curr_estimator->step();  // Update position estimate
        
        // Update actual speed from estimator
        omega = curr_estimator->get_speed() * motor.pp_1;
        
        // Set desired velocity from virtual motor
        desired_vel = spin_direction * openloop_omega;
        
        // Accumulate speed error for direction detection
        open_loop_omega_acc_error += (omega - openloop_omega);
        ++open_loop_omega_count;
        
        // Apply current from virtual motor model
        ipark1.step(
            vmotor.get_start_iq() * motor.rs,
            0.0F,
            Sincos(vmotor.get_angle()));
            
        i_clarke.step(ipark1.alpha, ipark1.beta);
        step_output();  // Generate PWM outputs
        
        // Calibrate position sensors during rotation
        const Real dtheta = Rmath::fabsr(openloop_omega * rt_period);
        sincos_sensor1.step_cal(dtheta);
        sincos_sensor2.step_cal(dtheta);
        
        // Check if sensor calibration is complete
        if(sincos_sensor1.is_cal_complete() && sincos_sensor2.is_cal_complete()) {
            // Check for direction error
            const Real dir_error = open_loop_omega_acc_error /
                                  static_cast<Real>(open_loop_omega_count) /
                                  openloop_omega;
                                  
            if(Rmath::fabsr(dir_error) > k_direction_tolerance) {
                faults.set(f_spins_dir);  // Set direction error fault
            }
            
            step_openloop_complete();  // Handle completion
            reset();  // Reset control variables
            
            // Initialize position estimator with virtual motor state
            curr_estimator->reset(vmotor.get_mangle(), openloop_omega);
            
            // Signal open loop completion
            c2_data.open_loop_complete = true;
        }
    }
    
    check_health();  // Check for faults
}
```

### 3.4 Zero RPM Mode

The zero RPM mode (`step_zero_rpm()`) maintains the motor at standstill:

```cpp
void Control_foc_noenc::step_zero_rpm() {
    step_sense();  // Read sensors
    
    if(!critical_fault) {
        // Apply constant alpha current to hold position
        i_clarke.step(ialpha_zero_rpm * motor.rs, 0.0F);
        step_output();  // Generate PWM outputs
    }
    
    check_health();  // Check for faults
}
```

### 3.5 Zero Current Mode

The zero current mode (`step_zero_current()`) allows the motor to freewheel:

```cpp
void Control_foc_noenc::step_zero_current() {
    iq = 0.0F;  // Zero torque current
    id = 0.0F;  // Zero flux current
    
    step_sense();  // Read sensors
    
    // Clarke transformation of measured currents
    clarke1.step(iph.get_iph_u(), iph.get_iph_v(), iph.get_iph_w());
    
    step_observer();  // Update position and speed estimates
    
    if(!c1_data.terminal_fault) {
        // Park transformation to rotating frame
        park1.step(clarke1.alpha, clarke1.beta, Sincos(flux_angle));
        
        step_current();  // Current control (targeting zero)
        step_output();   // Generate PWM outputs
    }
    
    check_health();  // Check for faults
}
```

## 4. Current Limiting and Protection Features

### 4.1 Current Limiting

The `step_iqid_limiter()` method implements multiple current limiting strategies:

```cpp
void Control_foc_noenc::step_iqid_limiter() {
    // Basic current limits based on mode
    if(is_sensored) {
        limit_iq(iq_spin_break);
    }
    else {
        if(startup_passed) {
            limit_iq(iq_spin_break);
        }
        else {
            // Special limits for sensorless startup
            if(is_inverted) {
                iq_min = -iq_str_drive;
                iq_max = iq_str_break;
            }
            else {
                iq_min = -iq_str_break;
                iq_max = iq_str_drive;
            }
        }
    }
    
    // Overvoltage protection - limit regenerative current
    Real reg_ratio = 1.0F;
    if(limit_iq_reg) {
        reg_ratio = Rfun::clamp<Real>(
            1.0F - ((vdc - vdc_start_lim_reg) / (vdc_stop_reg - vdc_start_lim_reg)),
            0.0F, 1.0F);
            
        if(!regenerating) {
            reg_ratio = 0.0F;
        }
    }
    
    // Apply regenerative current limit
    if(is_inverted) {
        iq_max *= reg_ratio;
    }
    else {
        iq_min *= reg_ratio;
    }
    
    // Power limiting protection for undervoltage
    if(limit_pout) {
        Real iq_max_pout = 0.0F;
        
        // Calculate maximum current based on available power
        Rvector3 iqmax_by_vdc_steps(
            pout_max_uv_steps[step1],
            pout_max_uv_steps[step2],
            pout_max_uv_steps[step3]);
            
        // Scale by motor efficiency and speed
        iqmax_by_vdc_steps.scale(
            k_presumed_motor_efficiency / 
            (Const::THREEHALVES * 
             Rfun::max<Real>(Rmath::fabsr(omegae), k_low_speed_erad_per_s) * 
             motor.ke));
        
        // Select appropriate power limit based on voltage level
        if(vdc >= vdc_protect_steps[step3]) {
            iq_max_pout = iqmax_by_vdc_steps[step3];
        }
        else if(vdc >= vdc_protect_steps[step2]) {
            iq_max_pout = iqmax_by_vdc_steps[step2] + 
                         (iqmax_by_vdc_steps[step3] - iqmax_by_vdc_steps[step2]) *
                         (vdc - vdc_protect_steps[step2]) / 
                         (vdc_protect_steps[step3] - vdc_protect_steps[step2]);
        }
        else if(vdc >= vdc_protect_steps[step1]) {
            iq_max_pout = iqmax_by_vdc_steps[step1] + 
                         (iqmax_by_vdc_steps[step2] - iqmax_by_vdc_steps[step1]) *
                         (vdc - vdc_protect_steps[step1]) / 
                         (vdc_protect_steps[step2] - vdc_protect_steps[step1]);
        }
        else {
            iq_max_pout = iqmax_by_vdc_steps[step1];
        }
        
        // Apply power limit to current limits
        if(is_inverted) {
            iq_min = Rfun::max<Real>(iq_min, -iq_max_pout);
        }
        else {
            iq_max = Rfun::min<Real>(iq_max, iq_max_pout);
        }
    }
}
```

### 4.2 Maximum Torque Per Ampere (MTPA)

The `step_mtpa_lut()` method optimizes torque production:

```cpp
void Control_foc_noenc::step_mtpa_lut() {
    // Calculate optimal current angle based on speed and voltage
    Sincos sc(Rfun::sign(omegae) * 
              Rfun::clamp<Real>(
                  mtpa_coeff[coeff_a] +
                  mtpa_coeff[coeff_b] * Rmath::fabsr(omegae) +
                  mtpa_coeff[coeff_c] * vdc,
                  0.0F, max_angle_rad));
    
    // Get total current magnitude from speed controller
    const Real is = pi_spd.get_out();
    
    // Calculate d-q currents based on angle
    id = -sc.s * is;  // Negative d-axis current for MTPA
    iq = sc.c * is;   // Q-axis current for torque
    
    // Additional d-axis current for sensorless operation
    if(!is_sensored) {
        step_id_sensorless();
    }
    
    // Zero current during undervoltage
    static const Uint64 fail_uv_nl = (static_cast<Uint64>(1) << f_swuv_nl);
    if(faults.value & fail_uv_nl) {
        iq = 0.0F;
        id = 0.0F;
    }
}
```

### 4.3 Fault Detection

The `check_health()` method monitors system health:

```cpp
void Control_foc_noenc::check_health() {
    // Check driver health
    driver_ctrl.check_drv_health();
    
    // Run fault detection algorithms
    fault_det.step();
    
    // Determine critical and non-critical faults
    critical_fault = faults.value & msk_critical.value;
    ncritical_fault = faults.value & (~msk_critical.value);
    
    // Disable PWM if critical fault detected
    const bool disable_pwm = (critical_fault || c1_data.terminal_fault) && 
                            !c1_data.inhibit_termination;
    if(disable_pwm) {
        driver_ctrl.disable();
    }
    
    // Update overall health status
    health_check = (!critical_fault && !ncritical_fault);
}
```

## 5. Control Parameters and Configuration

### 5.1 Key Control Parameters

| Parameter | Description | Default Value | Units |
|-----------|-------------|---------------|-------|
| `id0` | Initial alignment flux current | 20.0 | A |
| `t_align` | Alignment time | 1.0 | s |
| `wmin_morph` | Lower limit for observer mixing | 0.022 * motor.max_rpm * RPM2RADS | rad/s |
| `wmax_morph` | Upper limit for observer mixing | 0.12 * motor.max_rpm * RPM2RADS | rad/s |
| `iq_spin_break` | Maximum regenerative current | 45.0 | A |
| `iq_str_drive` | Maximum driving current at startup | 40.0 | A |
| `iq_str_break` | Maximum regenerative current at startup | 45.0 | A |
| `alpha_dc` | DC bus filter gain | Mc_const::cutoff_dc * rt_period | - |
| `alpha_speed` | Speed filter gain | Mc_const::cutoff_speed * rt_period | - |
| `vdc_start_lim_reg` | Voltage threshold to start limiting regen | 71.0 | V |
| `vdc_stop_reg` | Voltage threshold to stop regeneration | 72.0 | V |
| `ialpha_zero_rpm` | Alpha current for zero speed mode | 20.0 | A |
| `num_advanced_angles` | Voltage vector angle advance | 1.5-2.0 | rad |

### 5.2 PI Controller Parameters

The FOC implementation uses three PI controllers:

1. **Speed Controller (`pi_spd`)**:
   - Output: q-axis current reference
   - Anti-windup with tracking from current controller

2. **D-axis Current Controller (`pi_id`)**:
   - Output: d-axis voltage
   - Dynamic saturation based on available voltage

3. **Q-axis Current Controller (`pi_iq`)**:
   - Output: q-axis voltage
   - Dynamic saturation based on remaining voltage after d-axis control

### 5.3 Observer Parameters

The position and speed estimation uses multiple observers:

1. **Sliding Mode Observer (`smo1`)**:
   - Estimates back-EMF for sensorless operation
   - Used as input to other observers

2. **Tangent PLL (`pll`)**:
   - High-speed position and speed estimation
   - Phase-locked loop based on back-EMF

3. **Position Sensors**:
   - Sin/Cos sensors for direct position measurement
   - Hall sensors as backup (in verification implementation)

## 6. Cross-Component Relationships

### 6.1 Interaction with Motor Controller Interface

The FOC implementation responds to the MCI state (`st`) to determine its operating mode:

```
MCI::off → step_off()
MCI::calibration → step_cal()
MCI::alignment → step_alignment()
MCI::open_loop → step_openloop()
MCI::zero_rpm → step_zero_rpm()
MCI::zero_current → step_zero_current()
MCI::rpm → step_rpm()
```

### 6.2 Shared Memory Interface

The FOC implementation interacts with shared memory between cores:

- **C1 to C2**:
  - `mci_st`: Current motor control interface state
  - `fsm_st`: Current FSM state
  - `terminal_fault`: Critical fault flag
  - `inhibit_termination`: Flag to prevent PWM disable on fault

- **C2 to C1**:
  - `init_complete`: Calibration completion flag
  - `aligment_complete`: Alignment completion flag
  - `open_loop_complete`: Open loop completion flag
  - `faults`: Fault flags
  - `msk_critical`: Critical fault mask

### 6.3 Hardware Interface

The FOC implementation interfaces with hardware through:

- **ADC Channels**:
  - `adc_voltage`: DC bus voltage
  - `adc_voltage2`: Secondary DC voltage (overvoltage)
  - `adc_dc_curr`: DC bus current
  - Phase current ADCs (via `iph`)

- **PWM Outputs**:
  - `pwm1a`: U-phase PWM
  - `pwm2a`: V-phase PWM
  - `pwm3a`: W-phase PWM
  - `fan_pwm`: Cooling fan control

- **Position Sensors**:
  - `sincos_sensor1`: Primary Sin/Cos sensor
  - `sincos_sensor2`: Secondary Sin/Cos sensor
  - Hall sensors (in verification implementation)

## 7. Implementation Variations

The FOC implementation includes two variations:

### 7.1 Amazon Implementation (`Control_foc_noenc_amz.cpp`)

The Amazon implementation provides:
- Minimal private implementation (`Pimpl`)
- Empty implementations of sensorless-specific methods
- Standard calibration thresholds

### 7.2 Verification Implementation (`Control_foc_noenc_ver.cpp`)

The verification implementation adds:
- Hall sensor support
- Additional observers (Arc-tangent observer, Low PLL)
- Cooling control
- Detailed MTPA implementation
- Sensorless operation enhancements

## 8. Control Flow Diagrams

### 8.1 Main FOC Control Flow

```
┌───────────────┐
│    step()     │
└───────┬───────┘
        │
        ▼
┌───────────────┐
│  Select mode  │
│  based on st  │
└───────┬───────┘
        │
        ▼
┌───────────────┐     ┌───────────────┐
│  step_sense() │────►│ step_observer()│
└───────┬───────┘     └───────┬───────┘
        │                     │
        ▼                     ▼
┌───────────────┐     ┌───────────────┐
│ step_speed()  │◄────┤step_iqid_limiter()
└───────┬───────┘     └───────────────┘
        │
        ▼
┌───────────────┐     ┌───────────────┐
│ step_mtpa_lut()│────►│ step_current()│
└───────────────┘     └───────┬───────┘
                              │
                              ▼
                      ┌───────────────┐
                      │ step_output() │
                      └───────┬───────┘
                              │
                              ▼
                      ┌───────────────┐
                      │check_health() │
                      └───────────────┘
```

### 8.2 Observer Mixing Strategy

```
                  ┌───────────────┐
                  │   smo1.step() │
                  └───────┬───────┘
                          │
                          ▼
          ┌───────────────────────────────┐
          │      curr_estimator->step()   │
          └───────────────┬───────────────┘
                          │
                          ▼
          ┌───────────────────────────────┐
          │ Calculate observer mix ratio  │
          │ p_hs based on speed range     │
          └───────────────┬───────────────┘
                          │
                ┌─────────┴─────────┐
                │                   │
                ▼                   ▼
    ┌───────────────────┐  ┌───────────────────┐
    │ Low speed range   │  │ High speed range  │
    │ p_hs = 0          │  │ p_hs > 0          │
    └─────────┬─────────┘  └─────────┬─────────┘
              │                      │
              ▼                      ▼
    ┌───────────────────┐  ┌───────────────────┐
    │ pll.reset()       │  │ pll.step()        │
    └─────────┬─────────┘  └─────────┬─────────┘
              │                      │
              └──────────┬───────────┘
                         │
                         ▼
             ┌───────────────────────┐
             │ Combine estimates:    │
             │ omegae = p_hs * high  │
             │        + p_ls * low   │
             └───────────┬───────────┘
                         │
                         ▼
             ┌───────────────────────┐
             │ Calculate flux_angle  │
             │ with phase correction │
             └───────────────────────┘
```

## 9. Referenced Context Files

The following context file provided valuable insights for understanding the FOC implementation:

- `06_Motor_Control_State_Machine.md`: Provided context on the state machine that controls the transitions between different motor control modes, helping to understand how the FOC implementation fits into the broader control architecture.