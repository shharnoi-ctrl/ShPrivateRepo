# Generated from:

- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/include/Control_input_mgr.h (3570 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/include/Control_input_mgr_ex.h (672 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/include/Input_source.h (2644 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/include/Motor_rpm_cmd.h (594 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/include/Motor_state_cmd.h (609 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/include/Source_selection.h (6878 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/source/Control_input_mgr.cpp (1557 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/source/Control_input_mgr_ex.cpp (758 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/source/Input_source.cpp (2169 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/source/Motor_rpm_cmd.cpp (526 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/source/Motor_state_cmd.cpp (112 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/source/Source_selection.cpp (12656 tokens)

## With context from:

- PackageSummaries/Amazon-PrimeAir/items/IPC/06_Motor_Control_State_Machine.md (4178 tokens)

---

# Command Input Management System Analysis

## 1. Source Selection State Machine

### 1.1 State Machine Architecture

The `Source_selection` class implements a sophisticated state machine that manages primary and recovery input sources for motor control commands. The state machine has seven distinct states:

| State | Description | Purpose |
|-------|-------------|---------|
| `st_initial` | Initial state | Starting state after power-up |
| `st_nominal` | Nominal state | Primary source is active and present |
| `st_loss_primary` | Loss of primary source | Primary source lost, deciding next action |
| `st_wait_for_recovery` | Wait for recovery | Waiting for valid RPM command from recovery source |
| `st_recovery` | Recovery source active | Recovery source is providing commands |
| `st_loss_recovery` | Loss of recovery source | Recovery source lost, deciding next action |
| `st_loss_comm` | Loss of communications | Both sources lost, system in failsafe mode |

### 1.2 State Transition Logic

The state machine implements the following key transitions:

1. **From Initial State**:
   - Transitions to `st_nominal` when Core 1 FSM state is in `test` mode

2. **From Nominal State**:
   - Transitions to `st_loss_primary` when primary source is no longer present
   - Transitions to `st_initial` when primary source is present but system is disarmed

3. **From Loss of Primary State**:
   - Transitions to `st_nominal` if primary source becomes present again
   - Transitions to `st_wait_for_recovery` if primary is absent but recovery is present and enabled
   - Transitions to `st_loss_comm` if primary times out or system is disarmed with no valid sources

4. **From Wait for Recovery State**:
   - Transitions to `st_recovery` when recovery source provides valid RPM command (> 100 RPM)
   - Transitions to `st_loss_comm` if recovery times out, system is disarmed, or wait timeout expires

5. **From Recovery State**:
   - Transitions to `st_loss_recovery` if recovery source is no longer present
   - Transitions to `st_loss_comm` if system is disarmed

6. **From Loss of Recovery State**:
   - Transitions to `st_recovery` if recovery source becomes present again
   - Transitions to `st_loss_comm` if recovery times out or system is disarmed

### 1.3 Timeout Management

The `Source_selection` class manages several critical timeouts:

- **Primary Disarm Timeout**: 500ms timeout that must elapse before a disarm command from primary is accepted
- **Wait for Recovery Timeout**: 17s maximum time to wait for valid recovery RPM command
- **Source Presence Timeouts**: Managed by `Input_source` class to determine when a source is considered lost

```cpp
static const Real k_primary_disarm_tout = 500.0F * Const::E1000;  // 500ms
static const int32 k_valid_rpm_recovery = 100;                    // Minimum valid RPM from recovery
static const Real k_wait_for_recovery_tout = 17.0F;               // Maximum wait time for recovery
```

### 1.4 Active Source Selection Logic

The state machine determines which source is active based on the current state:

- In `st_initial` and `st_nominal`: Primary source is active
- In `st_loss_primary`: Primary source is active (even though it's lost)
- In `st_wait_for_recovery`, `st_recovery`, and `st_loss_recovery`: Recovery source is active

The active source determines which RPM command is used for motor control, with special handling for the wait state:

```cpp
inline virtual int32 get_active_rpm() const
{
    return (st == st_wait_for_recovery) ? last_primary_rpm : active->get_rpm();
}
```

## 2. Input Source Management

### 2.1 Input Source Status Tracking

The `Input_source` class tracks the status of each command source (primary and recovery) with two key structures:

1. **Status Structure**:
   - `is_present`: Indicates if the source is currently present
   - `is_timed_out`: Indicates if the source has timed out

2. **Intent Structure**:
   - `rpm_command`: The actual RPM command value
   - `is_armed`: Whether the system is intended to be armed
   - `is_enabled`: Whether the system is intended to be enabled
   - `faults_are_allowed`: Whether the system is allowed to fault

### 2.2 Timeout Processing

Each `Input_source` manages two critical timeouts:

- **Present Timeout**: Time after which a source is considered not present if no messages received
- **Loss of Lane Timeout**: Time after which a source is considered timed out if no messages received

```cpp
void Input_source::step()
{
    const Base::Ttime d_time = timeout.toc_ttime();
    status.is_present = (d_time <= kIsPresentTimeOut);
    if (d_time > kLossOfLaneTimeOut)
    {
        intent.reset();
        if(!timeouts_inhibited)
        {
            status.is_timed_out = true;
        }
    }
}
```

### 2.3 Command Data Processing

When a command message is received, the `Input_source` updates its internal state:

```cpp
void Input_source::update_data(const Motor_rpm_cmd::RPM_data& data)
{
    timeout.tic();  // Reset timeout counter
    intent.rpm_command = data.input_rpm;
    intent.is_armed = (data.cmd_state.arm_intent == Motor_state_cmd::kArmIntentArmed);
    intent.is_enabled = (data.cmd_state.enable_intent == Motor_state_cmd::kEnableIntentAllMotorsEnabled);
    
    if(data.cmd_state.enable_intent == Motor_state_cmd::kEnableIntentMEPOut)
    {
        intent.faults_are_allowed = false;
        intent.is_enabled = (static_cast<Uint16>(curr_motor) != (data.cmd_state.disabled_motor - 1U));
    }
    else
    {
        intent.faults_are_allowed = true;
    }
}
```

## 3. Cyphal Protocol Message Processing

### 3.1 Motor RPM Command Processing

The `Motor_rpm_cmd` class deserializes Cyphal protocol messages containing RPM commands:

```cpp
void Motor_rpm_cmd::write(const Base::U8pkmblock_k& u8, bool all_cmd)
{
    Base::Lossy str(static_cast<Uint16*>((const_cast<void*>(u8.get_pt()))), u8.size());
    
    static const Uint16 nbits = 14U;
    static const Uint16 total_nbits = nbits * Ipc_ids::num_esc;
    
    const Uint16 skip_pre = all_cmd * nbits * static_cast<Uint16>(curr_esc);
    str.skip_bits(skip_pre);
    
    str.get_ibits(data.input_rpm, nbits);
    
    const Uint16 skip_post = all_cmd * (total_nbits - skip_pre - nbits);
    str.skip_bits(skip_post);
    
    str.align_bytes();
    st_proc.write(str);
}
```

This function:
1. Creates a bit stream from the received data
2. Skips bits for other ESCs if this is a multi-ESC command
3. Extracts the RPM command value (14 bits)
4. Processes the state command portion

### 3.2 Motor State Command Processing

The `Motor_state_cmd` class handles the state command portion of the message:

```cpp
void Motor_state_cmd::write(Base::Lossy& str)
{
    static const Uint16 nbits = 9;
    Command cmd;
    Uint32 aux = 0;
    str.get_ubits(aux, nbits);
    cmd.all = aux;
    if(hnd != 0)
    {
        hnd->state_cmd(cmd);
    }
}
```

The `Command` structure contains critical control bits:
- `enable_intent` (2 bits): Controls motor enabling
- `disabled_motor` (3 bits): Specifies which motor to disable in MEP-out mode
- `arm_intent` (2 bits): Controls arming/disarming
- `source` (2 bits): Indicates command source (primary/recovery)

Key command values include:
- `kArmIntentArmed = 2U`: Arm command
- `kArmIntentDisarmed = 1U`: Disarm command
- `kEnableIntentAllMotorsEnabled = 2U`: Enable all motors
- `kEnableIntentAllMotorsDisabled = 1U`: Disable all motors
- `kEnableIntentMEPOut = 3U`: MEP-out mode (selective motor disabling)

## 4. Control Input Manager

### 4.1 Control Input Manager Base Class

The `Control_input_mgr` class provides the base implementation for managing control inputs:

```cpp
class Control_input_mgr : public Icontrol_input, public Base::Itconsumer_can, public Base::Ideserializable
{
    // ...
    enum Control_src
    {
        s_failsafe  = 0, // Fail safe source
        s_PPM       = 1, // Pulse Position Modulation (PPM) source
        s_CAN       = 2  // Controller Area Network (CAN) source
    };
    // ...
}
```

It supports multiple input sources:
- CAN bus commands
- PPM (Pulse Position Modulation) signals
- Failsafe values

### 4.2 Control Input Manager Extended Class

The `Control_input_mgr_ex` class extends the base manager to handle Cyphal protocol messages:

```cpp
class Control_input_mgr_ex : public Cyphal::Cyphal_rx_hnd
{
public:
    Control_input_mgr_ex(const volatile Ipc_ids::StationName& curr_motor0,
                         Input_source& primary0, Input_source& recovery0);
    virtual bool on_rx(Cyphal::CyCAN_id cy_id, Base::U8istream& is);
    // ...
private:
    Motor_rpm_cmd rpm_cmd;
    Input_source& primary;
    Input_source& recovery;
    // ...
};
```

When a Cyphal message is received, it:
1. Determines if the message is from primary or recovery source
2. Deserializes the message using `Motor_rpm_cmd`
3. Routes the command to the appropriate `Input_source` (primary or recovery)

```cpp
bool Control_input_mgr_ex::on_rx(Cyphal::CyCAN_id cy_id, Base::U8istream& is)
{
    static const Uint16 sz = 12;
    const bool from_primary = (cy_id.msg.src_node == Ipc_ids::node_id_pr);
    rpm_cmd.write(Base::U8pkmblock_k(is.all_mblock8(), is.get_pos(), sz), from_primary);
    update_data(cy_id.msg.src_node);
    return true;
}

void Control_input_mgr_ex::update_data(const Uint32 node_id)
{
    const Motor_rpm_cmd::RPM_data& data = rpm_cmd.get_data();
    switch(node_id)
    {
        case Ipc_ids::node_id_pr:
            primary.update_data(data);
            break;
        case Ipc_ids::node_id_re:
            recovery.update_data(data);
            break;
        default:
            Bsp::warning();
            break;
    }
}
```

## 5. Arming and Disarming Logic

### 5.1 Arming Conditions

The system should arm when both primary and recovery sources are present and indicating arm intent:

```cpp
bool Source_selection::should_arm() const
{
    return (primary.is_present() && primary.is_intent_armed() &&
            recovery.is_present() && recovery.is_intent_armed());
}
```

### 5.2 Disarming Conditions

The system should disarm under any of these conditions:

```cpp
bool Source_selection::should_disarm() const
{
    const bool primary_intent_armed = primary.is_intent_armed();
    const bool recovery_intent_armed = recovery.is_intent_armed();
    
    return ((!primary_intent_armed && !recovery_intent_armed) ||
            (primary.is_present() && !primary_intent_armed && primary_disarm_request_elapsed) ||
            (!primary_intent_armed && recovery.is_tout()) ||
            (primary.is_tout() && !recovery_intent_armed));
}
```

Disarming occurs when:
1. Neither source intends to arm
2. Primary source is present, not intending to arm, and the disarm timeout has elapsed
3. Primary not intending to arm and recovery has timed out
4. Primary has timed out and recovery not intending to arm

## 6. Communication Status Management

### 6.1 Communication Nominal Status

The system tracks communication status for both primary and recovery sources:

```cpp
bool Source_selection::communication_nominal_primary() const
{
    const bool is_st_init = (st == st_initial);
    const bool is_st_nomn = (st == st_nominal);
    return (is_st_init || (is_st_nomn && primary.is_present()));
}

bool Source_selection::communication_nominal_recovery() const
{
    const bool is_st_init = (st == st_initial);
    return (is_st_init || recovery.is_present());
}
```

### 6.2 Communication Fault Detection

The system detects transient and persistent communication faults:

```cpp
bool Source_selection::communication_lost_transient() const
{
    const bool primary_is_transient = (!primary.is_present() && !primary.is_tout());
    const bool recovery_is_transient = (!recovery.is_present() && !recovery.is_tout());
    
    bool ret = false;
    if (primary.is_tout())
    {
        ret = recovery_is_transient;
    }
    else
    {
        ret = (primary_is_transient && recovery_is_transient);
    }
    
    return ret;
}

bool Source_selection::communication_fault() const
{
    const bool fsm_state_is_faulted = (st_loss_comm == st);
    const bool both_sources_are_faulted = (primary.is_tout() && recovery.is_tout());
    return (fsm_state_is_faulted || both_sources_are_faulted);
}
```

## 7. Redundancy and Failover Mechanisms

### 7.1 Source Failover Logic

The system implements a robust failover mechanism:

1. When primary source is lost, the system enters `st_loss_primary` state
2. If recovery source is present and enabled, system enters `st_wait_for_recovery` state
3. System waits for a valid RPM command (>100 RPM) from recovery source
4. If valid command received, system transitions to `st_recovery` state
5. If recovery source is lost or times out, system enters `st_loss_comm` state

### 7.2 Last Command Preservation

During failover, the system preserves the last valid command from primary:

```cpp
case st_nominal:
{
    active = &primary;
    last_primary_rpm = primary.get_rpm();
    // ...
}
```

This last command is used during the wait for recovery state:

```cpp
inline virtual int32 get_active_rpm() const
{
    return (st == st_wait_for_recovery) ? last_primary_rpm : active->get_rpm();
}
```

### 7.3 Fault Allowance Control

The system controls whether faults are allowed based on source status:

```cpp
inline virtual bool faults_allowed() const
{
    return (primary.faults_allowed() && !is_recovery_command());
}
```

Faults are only allowed when:
1. Primary source indicates faults are allowed
2. The active source is not the recovery source

## 8. System Integration

### 8.1 Interface with Motor Control FSM

The `Source_selection` class implements the `Icontrol_input` interface, providing:

- `should_arm()`: Determines if the system should arm
- `should_disarm()`: Determines if the system should disarm
- `get_active_rpm()`: Retrieves the active RPM command
- `communication_nominal()`: Checks if communications are nominal
- `communication_lost_transient()`: Checks for transient communication loss
- `communication_fault()`: Checks for communication faults
- `is_recovery_command()`: Checks if command is from recovery source
- `faults_allowed()`: Checks if faults are allowed
- `intent_enabled()`: Checks if the system should be enabled
- `arm_command()`: Checks for arm command

These methods are used by the motor control FSM to determine state transitions and fault handling.

### 8.2 Integration with Cyphal Protocol

The system integrates with the Cyphal protocol through:

1. `Control_input_mgr_ex`: Handles Cyphal message reception
2. `Motor_rpm_cmd`: Deserializes RPM command messages
3. `Motor_state_cmd`: Deserializes state command messages

This allows the system to receive commands from both primary and recovery sources over the Cyphal network.

## Referenced Context Files

The following context file provided valuable insights for understanding the command input management system:

- `06_Motor_Control_State_Machine.md`: Provided context on how the FSM interacts with the command input system, particularly how it uses the `should_arm()`, `should_disarm()`, and `intent_enabled()` methods to determine state transitions.

## Command Input Management System State Diagram

```
┌─────────────────────────────────────────────────────────────────────────────────────────────────┐
│                                                                                                 │
│                                  Primary Source Restored                                        │
│                                                                                                 │
▼                                                                                                 │
┌─────────┐    ┌─────────┐    ┌───────────────────────┐    ┌─────────────┐    ┌─────────┐        │
│ initial │───►│ nominal │◄───┤   loss_primary       │    │wait_recovery │───►│recovery │        │
└─────────┘    └─────────┘    │                      │───►│              │    └─────────┘        │
     │              │         └───────────────────────┘    └─────────────┘         │             │
     │              │                    │                        │                 │             │
     │              │                    │                        │                 │             │
     │              │                    ▼                        ▼                 ▼             │
     │              │         ┌───────────────────────┐    ┌─────────────┐    ┌─────────┐        │
     │              └────────►│     loss_comm        │◄───┤              │◄───┤loss_rec │        │
     │                        │                      │    │              │    └─────────┘        │
     └───────────────────────►└───────────────────────┘◄───└─────────────┘                       │
                                                                                                 │
                                                                                                 │
┌─────────────────────────────────────────────────────────────────────────────────────────────────┘
│
│  Legend:
│  -------
│  initial      - Initial state after power-up
│  nominal      - Primary source active and present
│  loss_primary - Primary source lost, deciding next action
│  wait_recovery - Waiting for valid RPM command from recovery
│  recovery     - Recovery source providing commands
│  loss_rec     - Recovery source lost, deciding next action
│  loss_comm    - Both sources lost, system in failsafe mode
└─────────────────────────────────────────────────────────────────────────────────────────────────┘
```