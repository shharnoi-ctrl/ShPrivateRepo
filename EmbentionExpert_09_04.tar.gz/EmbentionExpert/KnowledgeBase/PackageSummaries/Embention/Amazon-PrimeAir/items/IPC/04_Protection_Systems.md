# Generated from:

- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/include/Fault_detection.h (6872 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/include/Fault_detection_values.h (1248 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/include/Ground_fault.h (4588 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/include/Monitor_temperature.h (1351 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/include/Stall_manager_values.h (352 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/include/Stall_manager_impl.h (1270 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/include/Cooling.h (726 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/source/Fault_detection.cpp (6753 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/source/Ground_fault.cpp (4865 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/source/Monitor_temperature.cpp (1769 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/source/Stall_manager_impl.cpp (3286 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/source/Cooling.cpp (1252 tokens)

## With context from:

- PackageSummaries/Amazon-PrimeAir/items/IPC/06_Motor_Control_State_Machine.md (4178 tokens)
- PackageSummaries/Amazon-PrimeAir/items/IPC/05_Field_Oriented_Control.md (7141 tokens)

---

# Comprehensive Protection Systems in the Motor Controller

This document provides a detailed analysis of the protection systems implemented in the motor controller, focusing on fault detection, ground fault detection, stall management, temperature monitoring, and cooling control.

## 1. Fault Detection System Architecture

The `Fault_detection` class implements a comprehensive protection system that monitors various parameters to detect abnormal conditions and prevent system malfunction. It integrates multiple protection mechanisms that operate in parallel.

### 1.1 Core Protection Categories

| Protection Type | Description | Parameters | Response |
|-----------------|-------------|------------|----------|
| AC Overcurrent | Detects excessive current in motor phases | High/Mid/Low thresholds with weighted accumulation | Sets `f_swoc_ac` fault |
| DC Overcurrent | Detects excessive current in DC bus | Three threshold levels with different timeouts | Sets `f_swoc_dc` fault |
| Overvoltage | Detects excessive DC bus voltage | Threshold with timeout | Sets `f_sw_ov_cau` fault |
| Undervoltage (Latching) | Detects persistent low DC voltage | Threshold with timeout | Sets `f_swuv_l` fault |
| Undervoltage (Non-latching) | Detects transient low DC voltage | Upper/lower thresholds with hysteresis | Sets `f_swuv_nl` fault |
| Open DC | Detects open circuit in DC path | Voltage range and minimum current | Sets `f_open_dc` fault |
| Low Energy | Detects persistent low voltage | Threshold with timeout | Sets `f_low_energy` fault |
| RMS Imbalance | Detects current imbalance between phases | Minimum speed and imbalance ratio | Sets `f_rms_imb` fault |
| Ground Fault | Detects voltage asymmetry between measurements | Voltage difference threshold | Sets `f_asym_gfd` fault |
| Position Sensor Error | Detects inconsistency in position sensors | Signal comparison and sum of squares | Sets `f_posse` fault |

### 1.2 Fault Counter Mechanism

The `Fault_detection` class uses a `Fault_counter` structure to implement timeout-based fault detection:

```cpp
struct Fault_counter {
    Uint16 counter;                 // Current count value
    Uint16 max_counter;             // Maximum count before fault is triggered
    const Mc_all_fault fault_type;  // Associated fault type
    volatile Faults_t& faults;      // Reference to fault flags
    
    bool step(const bool fault_condition);
    void step_and_reset(const bool fault_condition);
};
```

This structure:
1. Increments a counter when a fault condition is detected
2. Sets the associated fault flag when the counter reaches its maximum value
3. Resets the counter when the fault condition clears (for non-latching faults)

### 1.3 AC Overcurrent Protection

The AC overcurrent protection uses a weighted accumulation system with three threshold levels:

```cpp
// Defined current weights for each AC current level
static const Base::Tnarray<Uint16, 3U> ac_weights = {{
    10000U, // 220 A (High)
    2000U,  // 190 A (Mid)
    100U    // 180 A (Low)
}};
```

The system:
1. Determines the maximum current across all three phases
2. Assigns a weight based on which threshold is exceeded
3. Accumulates weights until the threshold is reached
4. Resets accumulation after a specified timeout period

### 1.4 DC Overcurrent Protection

The DC overcurrent protection uses three threshold levels with different timeout periods:

```cpp
// Maximum counter values for DC current levels
static const Base::Tnarray<Uint16, 3U> dc_max_counter = {{
    20U,   // 250 A (1ms)
    40U,   // 200 A (2ms)
    200U   // 150 A (10ms)
}};
```

This implements a time-inverse characteristic where higher overcurrents trigger faster protection responses.

### 1.5 Voltage Protection

The system implements both overvoltage and undervoltage protection:

```cpp
static const Real voltage_limits_over_v = 75.0F;  // Overvoltage threshold (V)
static const Real voltage_limits_max_v = 72.0F;   // Maximum normal voltage (V)
static const Real voltage_limits_min_v = 36.0F;   // Minimum normal voltage (V)
static const Real voltage_limits_under_v = 34.0F; // Undervoltage threshold (V)
```

Undervoltage protection includes:
- Latching protection for persistent undervoltage
- Non-latching protection with hysteresis for transient undervoltage

### 1.6 RMS Imbalance Detection

The system monitors phase current imbalance to detect motor or inverter issues:

```cpp
// Filter phase currents
i_abs_u_f = Ewma0::compute(alpha_curr, i_abs_u, i_abs_u_f);
i_abs_v_f = Ewma0::compute(alpha_curr, i_abs_v, i_abs_v_f);
i_abs_w_f = Ewma0::compute(alpha_curr, i_abs_w, i_abs_w_f);

// Calculate imbalance parameter
const Real rms_min = Rfun::min<Real>(i_abs_u_f, Rfun::min<Real>(i_abs_v_f, i_abs_w_f));
const Real rms_max = Rfun::max<Real>(i_abs_u_f, Rfun::max<Real>(i_abs_v_f, i_abs_w_f));
Real cip_parameter = 0.0F;

if((rms_max > Fd_values::k_min_max_phase_rms) && 
   (Rmath::fabsr(omegac) >= min_rpm_rms) &&
   (Rmath::fabsr(omega) >= min_rpm_rms)) {
    cip_parameter = (rms_max - rms_min) / 
                    Rfun::max<Real>(rms_min, Fd_values::k_min_min_phase_rms);
}

// Check against threshold
rms_imbalance.step_and_reset(cip_parameter > Fd_values::k_default_cip_threshold);
```

This protection only activates above a minimum speed threshold and requires a minimum current level.

### 1.7 Ground Fault Detection

In-flight ground fault detection monitors the difference between two DC voltage measurements:

```cpp
// Filter voltage difference
vdc_diff = Maverick::Ewma0::compute(alpha_vdc_diff, 
                                   Rmath::fabsr(Const::ONEHALF * (vdc - vdc2)),
                                   vdc_diff);

// Check against threshold
gfd.step_and_reset(vdc_diff > Fd_values::vdc_diff);
```

This protection is only available on systems with dual voltage monitoring capability.

## 2. Ground Fault Detection State Machine

The `Ground_fault` class implements a dedicated state machine for detecting ground faults during system startup. This detection is critical for identifying insulation failures that could lead to hazardous conditions.

### 2.1 Ground Fault Detection States

| State | Description | Actions | Next State |
|-------|-------------|---------|------------|
| `k_initial` | Initial state | Initialize detection values | `k_close_ac_bottom_switches` or `k_wait_period_r5` or `k_wait_period_no_op` |
| `k_wait_period_r5` | Wait for R5 | Wait 250ms | `k_close_ac_bottom_switches` |
| `k_close_ac_bottom_switches` | Close AC side bottom MOSFETs | Enable PWM, wait 100ms | `k_first_measurement` |
| `k_first_measurement` | First Vgnd measurement | Measure ground voltage | `k_close_switch` |
| `k_close_switch` | Close grounding switch | Close 4kohm DC switch, wait 100ms | `k_second_measurement` |
| `k_second_measurement` | Second Vgnd measurement | Measure ground voltage | `k_result_analysis` |
| `k_result_analysis` | Analyze measurements | Compare measurements, determine fault status | `k_wait_period_r2` or `k_wait_period_r_all` |
| `k_wait_period_r2` | Wait for R2 | Wait 250ms | `k_wait_period_r_all` |
| `k_wait_period_no_op` | Wait for simulated motors | Wait 450ms | `k_wait_period_r_all` |
| `k_wait_period_r_all` | Wait for all ESCs | Wait 50ms | `k_complete` |
| `k_complete` | Completion state | Test complete | - |

### 2.2 Ground Fault Detection Algorithm

The ground fault detection algorithm:

1. Takes a first measurement of the ground voltage with AC bottom switches closed
2. Closes a 4kohm DC grounding switch
3. Takes a second measurement of the ground voltage
4. Compares the measurements to detect insulation failures

```cpp
// Analysis logic
if (Rfun::comp_real<Real>(vgnd_1st_V, vgnd_nom_V, vdiff_threshold_V) &&
   (vgnd_2nd_V < (vgnd_2nd_over_1st_ratio * vgnd_1st_V))) {
    gfd_failed = false;
} else {
    gfd_failed = true;
}
```

A ground fault is detected when:
- The first measurement deviates significantly from the nominal value, or
- The second measurement doesn't decrease sufficiently after closing the grounding switch

### 2.3 Synchronization Between ESCs

The state machine includes specific waiting periods to synchronize testing between multiple ESCs:

```cpp
// Wait 50ms for all ESCs to complete
static const Base::Ttime32 k_r_all_delay_s(50.0F * Const::E1000);
if(get_time_in_state() > k_r_all_delay_s) {
    next(k_complete);
}
```

This ensures that all ESCs complete their ground fault detection before proceeding to normal operation.

## 3. Stall Detection and Management

The `Stall_manager_impl` class implements stall detection and recovery logic to handle situations where the motor is unable to rotate despite being commanded to do so.

### 3.1 Stall Detection Parameters

```cpp
// Parameters for stall detection and management
Uint32 s_restart_attempts_to_allow = 0U;  // Maximum restart attempts
Uint32 s_maximum_restart_RPM = 999U;      // Maximum RPM for restart attempts
Real s_minimum_runtime_before_fast_retry_allowed_ms = 2.0F;  // Minimum runtime before fast retry
Real s_time_before_stall_alarm_ms = 0.75F;  // Time before declaring stall
Real s_time_before_stall_fast_restart_ms = 0.75F;  // Time before fast restart
Real s_time_before_stall_repeated_restart_ms = 2.0F;  // Time between repeated restarts
```

### 3.2 Stall Detection Logic

The stall detection algorithm monitors:
1. Whether the motor is current-limited (indicating it's trying to overcome resistance)
2. Whether the actual speed is below a threshold
3. How long this condition has persisted

```cpp
// Check if motor is stalled
if ((!is_current_limited) || (m_config.maximum_restart_RPM <= Rmath::fabsr(estimated_rpm))) {
    // Not stalled - motor is not current limited or is spinning above threshold
    m_is_spinning_normally = true;
    
    // Allow fast retry if we've been running normally for long enough
    if (m_config.minimum_runtime_before_fast_retry_allowed_ms < time_since_checkpoint_ms) {
        m_may_fast_retry = true;
        m_restart_attempt_count = 0;
    }
} else if (m_is_spinning_normally) {
    // Transition from normal to potential stall - mark checkpoint
    m_is_spinning_normally = false;
    m_checkpoint_ms = time_now_ms;
} else {
    // Potential stall condition persists
    if (m_config.time_before_stall_alarm_ms < time_since_checkpoint_ms) {
        // Stall confirmed - set fault
        c1_data.faults.set(f_pers_ctrl);
    }
    
    // Determine restart timing strategy
    const Base::Ttime retry_wait_ms = m_may_fast_retry ?
        m_config.time_before_stall_fast_restart_ms :
        m_config.time_before_stall_repeated_restart_ms;
    
    // Attempt restart if enough time has passed
    if (retry_wait_ms < time_since_checkpoint_ms) {
        if (m_restart_attempt_count < m_config.restart_attempts_allowed) {
            // Attempt restart
            c1_data.reset_ctrl_state = true;
            ++m_restart_attempt_count;
        } else {
            // Max attempts reached - set terminal fault
            static const Mc_all_fault invalid_fault = static_cast<Mc_all_fault>(48U);
            c1_data.faults.set(invalid_fault);
        }
        
        // Reset for next attempt
        m_may_fast_retry = false;
        m_checkpoint_ms = time_now_ms;
    }
}
```

### 3.3 Restart Strategy

The stall manager implements a progressive restart strategy:
1. Fast restart if the motor was previously running normally
2. Slower repeated restarts if initial restart attempts fail
3. Terminal fault after maximum restart attempts

This approach balances quick recovery from transient stalls with protection against persistent fault conditions.

## 4. Temperature Monitoring and Protection

The `Monitor_temperature` class provides temperature monitoring and protection for various system components.

### 4.1 Temperature Monitoring Configuration

```cpp
struct Config {
    Real max_rate;                // Maximum rate of change (K/s)
    Real stabilization_time;      // Sensor stabilization time (s)
    Real valid_threshold;         // Maximum time outside valid range (s)
    Real overtemp_threshold;      // Time before declaring overtemperature (s)
    Real max;                     // Maximum valid temperature (K)
    Real min;                     // Minimum valid temperature (K)
    Real caution_high_threshold;  // Caution temperature threshold (K)
};
```

### 4.2 Temperature Monitoring Algorithm

The temperature monitoring algorithm:
1. Checks if temperature readings are within valid range
2. Monitors rate of change to detect sensor failures
3. Tracks how long temperature exceeds thresholds
4. Declares overtemperature conditions after timeout periods

```cpp
bool Monitor_temperature::step() {
    if(!initialized) {
        // Initialize monitoring
        initialized = true;
        stabilization_tout.start();
        last_temperature_sl = meas_temp;
        last_valid_temperature = meas_temp;
    } else {
        // Check if temperature is in valid range
        const bool is_valid = Rfun::in_range<Real>(meas_temp, cfg.min, cfg.max);
        
        if (is_valid) {
            // Reset valid timeout
            valid_tout.start();
            
            // Check slew rate if sensor is stabilized
            if(stabilization_tout.expired()) {
                if(decimator.step()) {
                    recent_slew_rate = (meas_temp - last_temperature_sl) * desired_rate_calculate_slew_rate;
                    last_temperature_sl = meas_temp;
                }
            } else {
                // Sensor still stabilizing
                recent_slew_rate = 0.0F;
                last_temperature_sl = meas_temp;
            }
            
            // Update last valid temperature
            last_valid_temperature = meas_temp;
        }
        
        // Check for sensor failures
        const bool not_in_range = valid_tout.expired();
        const bool slew_rate_fail = (Rmath::fabsr(recent_slew_rate) > cfg.max_rate);
        is_alive = !(slew_rate_fail || not_in_range);
        
        // Check for overtemperature
        if(last_valid_temperature < cfg.caution_high_threshold) {
            overtemp_tout.start();
        }
        is_overtemp = overtemp_tout.expired();
    }
    
    return is_alive;
}
```

### 4.3 Temperature Protection Features

The temperature monitoring system provides:
1. Detection of sensor failures through range and slew rate checks
2. Overtemperature detection with configurable thresholds and timeouts
3. Sensor stabilization period to avoid false alarms during startup
4. Decimated slew rate calculation to reduce computational load

## 5. Cooling Control System

The `Cooling` class implements a proportional controller for cooling fan management based on temperature readings.

### 5.1 Cooling Control Parameters

```cpp
bool enable;      // Enable fan cooling
Real work_temp;   // Normal working temperature (K)
Real hi_temp;     // High temperature limit (K)
Real kp;          // Proportional gain
```

The proportional gain is calculated as:
```cpp
kp = 1.0F/(hi_temp - work_temp);
```

### 5.2 Cooling Control Algorithm

The cooling control algorithm:
1. Calculates temperature error above working temperature
2. Clamps error between 0 and maximum range
3. Applies proportional control to determine fan speed
4. Outputs PWM signal to control fan

```cpp
void Cooling::step(Real temp0) {
    if (enable) {
        // Calculate clamped error
        Real ep = temp0 - work_temp;
        ep = Rfun::clamp<Real>(ep, 0.0F, (hi_temp - work_temp));
        
        // Apply proportional control
        Real u_ctrl = Gnc::Ctrl_p::step(kp, ep);
        
        // Set PWM output
        pwm_fan.set(u_ctrl);
    }
}
```

### 5.3 Fan Control Enable/Disable

The cooling system provides methods to enable or disable the cooling fan:

```cpp
void Cooling::set_enable(bool enable0) {
    if(enable != enable0) {
        enable = enable0;
        pwm_fan.set_enabled(enable);
        pwm_fan.set(0);  // Initialize with zero duty cycle
    }
}
```

## 6. Protection System Integration

### 6.1 Fault Categories and Criticality

Faults are categorized as critical or non-critical:

- **Critical Faults**: Immediately disable PWM outputs and require system reset
  - Hardware failures
  - Ground faults
  - Severe overcurrent conditions
  - Persistent stalls

- **Non-Critical Faults**: May allow continued operation with limitations
  - Transient undervoltage
  - Overvoltage caution
  - RMS imbalance
  - Low energy

### 6.2 Protection System Initialization

The protection systems are initialized during system startup:

1. **Fault Detection**:
   - Filter time constants are calculated based on real-time period
   - Fault thresholds are loaded from configuration
   - Ground fault detection capability is determined based on hardware

2. **Temperature Monitoring**:
   - Timeout periods are configured
   - Valid temperature ranges are set
   - Stabilization period is started

3. **Cooling Control**:
   - Proportional gain is calculated
   - Fan is initially disabled

### 6.3 Protection System Execution Sequence

During normal operation, protection systems are executed in sequence:

1. **Fault Detection** (`fault_det.step()`):
   - Monitors electrical parameters
   - Sets fault flags when thresholds are exceeded

2. **Temperature Monitoring** (`monitor_temperature.step()`):
   - Monitors temperature sensors
   - Updates overtemperature status

3. **Cooling Control** (`cooling.step()`):
   - Adjusts cooling fan speed based on temperature

4. **Stall Management** (`stall_manager.step()`):
   - Monitors for stall conditions
   - Attempts restarts when needed

5. **Ground Fault Detection** (during startup):
   - Executes ground fault detection state machine
   - Sets fault flag if ground fault is detected

## 7. Cross-Component Relationships

### 7.1 Interaction with Motor Control Interface

The protection systems interact with the Motor Control Interface (MCI):

- **Fault Detection**:
  - Monitors MCI state to enable/disable specific protections
  - Sets fault flags that influence MCI state transitions

- **Ground Fault Detection**:
  - Uses MCI to control PWM outputs during testing
  - Influences MCI state transitions based on test results

- **Stall Management**:
  - Monitors MCI state to detect stall conditions
  - Can reset controller state to attempt recovery

### 7.2 Interaction with Finite State Machine

The protection systems interact with the Finite State Machine (FSM):

- **Fault Detection**:
  - Sets fault flags that may trigger FSM transitions to faulted state
  - Some protections are only active in specific FSM states

- **Ground Fault Detection**:
  - Executed during the test state of the FSM
  - Results influence transition to inactive or faulted state

- **Stall Management**:
  - Active primarily during the active state of the FSM
  - Can trigger FSM transitions through fault flags

### 7.3 Hardware Interface

The protection systems interface with hardware through:

- **ADC Channels**:
  - Phase current measurements
  - DC voltage measurements
  - Temperature sensor readings

- **GPIO**:
  - Ground fault detection switch control
  - Fan control output

- **PWM Outputs**:
  - Fan speed control
  - Motor phase control (disabled on critical faults)

## 8. Protection Parameters and Thresholds

### 8.1 Current Protection Parameters

| Parameter | Value | Description |
|-----------|-------|-------------|
| AC High Threshold | 220 A | Highest AC current threshold |
| AC Mid Threshold | 190 A | Middle AC current threshold |
| AC Low Threshold | 180 A | Lowest AC current threshold |
| DC High Threshold | 250 A | Highest DC current threshold (1ms) |
| DC Mid Threshold | 200 A | Middle DC current threshold (2ms) |
| DC Low Threshold | 150 A | Lowest DC current threshold (10ms) |

### 8.2 Voltage Protection Parameters

| Parameter | Value | Description |
|-----------|-------|-------------|
| Overvoltage Threshold | 75.0 V | Overvoltage protection threshold |
| Maximum Normal Voltage | 72.0 V | Maximum normal operating voltage |
| Minimum Normal Voltage | 36.0 V | Minimum normal operating voltage |
| Undervoltage Threshold | 34.0 V | Undervoltage protection threshold |
| Open DC High Threshold | 71.0 V | Upper threshold for open DC detection |
| Open DC Low Threshold | 37.0 V | Lower threshold for open DC detection |
| Low Energy Threshold | 46.0 V | Threshold for low energy detection |

### 8.3 Temperature Protection Parameters

| Parameter | Default | Description |
|-----------|---------|-------------|
| Max Rate | Configurable | Maximum temperature rate of change |
| Stabilization Time | Configurable | Sensor stabilization period |
| Valid Threshold | Configurable | Time outside valid range before fault |
| Overtemp Threshold | Configurable | Time above threshold before overtemp |
| Max Temperature | Configurable | Maximum valid temperature |
| Min Temperature | Configurable | Minimum valid temperature |
| Caution Threshold | Configurable | Temperature for caution indication |

## 9. Referenced Context Files

The following context files provided valuable insights for understanding the protection systems:

- `06_Motor_Control_State_Machine.md`: Provided context on how the protection systems integrate with the motor control state machine, particularly how faults influence state transitions.

- `05_Field_Oriented_Control.md`: Provided context on the motor control algorithm that the protection systems are safeguarding, helping to understand the operational parameters being monitored.

## Protection System Diagram

```
┌─────────────────────────────────────────────────────────────────────────┐
│                        Motor Controller Protection Systems               │
└───────────────────────────────────┬─────────────────────────────────────┘
                                    │
    ┌───────────────────────────────┼───────────────────────────────────┐
    │                               │                                   │
    ▼                               ▼                                   ▼
┌─────────────┐              ┌─────────────┐                     ┌─────────────┐
│Fault Detection│            │Temperature   │                     │Stall        │
│System        │            │Monitoring    │                     │Management   │
└──────┬──────┘            └──────┬──────┘                     └──────┬──────┘
       │                          │                                   │
       ▼                          ▼                                   ▼
┌──────────────┐           ┌──────────────┐                    ┌──────────────┐
│- AC Overcurrent│         │- Sensor Checks│                    │- Stall Detection│
│- DC Overcurrent│         │- Rate Checks  │                    │- Restart Logic  │
│- Overvoltage   │         │- Overtemp     │                    │- Fault Setting  │
│- Undervoltage  │         │  Detection    │                    └──────────────┘
│- Open DC       │         └──────┬──────┘
│- RMS Imbalance │                │
│- Ground Fault  │                ▼
└──────┬──────┘           ┌──────────────┐
       │                  │Cooling Control│
       │                  │- Fan Speed    │
       │                  │  Regulation   │
       │                  └──────────────┘
       ▼
┌──────────────┐
│Ground Fault  │
│Detection     │
│State Machine │
└──────────────┘
```