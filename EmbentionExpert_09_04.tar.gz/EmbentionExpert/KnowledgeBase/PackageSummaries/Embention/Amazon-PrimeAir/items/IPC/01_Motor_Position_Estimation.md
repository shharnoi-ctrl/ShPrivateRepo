# Generated from:

- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/include/Smobserver.h (2896 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/include/Speed_sincos.h (2609 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/include/Arctan_observer.h (1142 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/include/Low_pll.h (1082 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/include/Sincos_checker.h (1198 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/include/Virtualmotor.h (2184 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/source/Smobserver.cpp (1695 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/source/Smobserver_amz.cpp (995 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/source/Smobserver_ver.cpp (1339 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/source/Speed_sincos.cpp (661 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/source/Arctan_observer.cpp (499 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/source/Low_pll.cpp (943 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/source/Sincos_checker.cpp (1320 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/source/Virtualmotor.cpp (1824 tokens)

## With context from:

- PackageSummaries/Amazon-PrimeAir/items/IPC/05_Field_Oriented_Control.md (7141 tokens)

---

I'll provide a comprehensive analysis of the motor position and speed estimation techniques used in the system, focusing on the components you specified.

# Motor Position and Speed Estimation Techniques

## 1. Sliding Mode Observer (Smobserver)

The `Smobserver` class is a back-EMF estimator that provides the foundation for sensorless motor control by estimating the back-EMF in alpha-beta axes from voltages and currents.

### 1.1 Core Functionality

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│  Motor Voltages │     │  Motor Currents │     │  Motor Model    │
│  (alpha-beta)   │     │  (alpha-beta)   │     │  Parameters     │
└────────┬────────┘     └────────┬────────┘     └────────┬────────┘
         │                       │                       │
         └───────────────────────┼───────────────────────┘
                                 ▼
                       ┌─────────────────────┐
                       │  Sliding Mode       │
                       │  Observer           │
                       └───────────┬─────────┘
                                   │
                                   ▼
                       ┌─────────────────────┐
                       │  Back-EMF Estimate  │
                       │  (alpha-beta)       │
                       └─────────────────────┘
```

### 1.2 Implementation Details

The `Smobserver` has two implementations:

#### 1.2.1 Amazon Implementation (`Smobserver_amz.cpp`)

```cpp
void Smobserver::step() {
    // Filter back-EMF components
    const Real alpha_z = Mc_const::smo_wc_emf * rt_period;
    ea_eb.c = Maverick::Ewma0::compute(alpha_z, zalpha, ea_eb.c);
    ea_eb.s = Maverick::Ewma0::compute(alpha_z, zbeta, ea_eb.s);
    
    // Estimate stator currents using motor model
    const Real alpha_r_l = rt_period * motor.rs * motor.inv_ls;
    estialpha = Maverick::Ewma0::compute(alpha_r_l, 
                (valpha_prev - (motor.ls * zalpha + k_sigm * ea_eb.c)) * motor.inv_rs,
                estialpha);
    estibeta = Maverick::Ewma0::compute(alpha_r_l, 
               (vbeta_prev - (motor.ls * zbeta + k_sigm * ea_eb.s)) * motor.inv_rs,
               estibeta);
    
    // Calculate unfiltered back-EMF using sliding mode control
    zalpha = kslide * (estialpha - clarke1.alpha);
    zbeta = kslide * (estibeta - clarke1.beta);
    
    // Store voltage values for next iteration
    valpha_prev = volt1.alpha;
    vbeta_prev = volt1.beta;
}
```

#### 1.2.2 Verification Implementation (`Smobserver_ver.cpp`)

The verification implementation adds:
- Additional filtering stages for back-EMF
- Adaptive filter coefficient based on electrical speed
- Amplitude compensation for low speeds

```cpp
void Smobserver::step() {
    // First stage filtering (same as Amazon implementation)
    const Real alpha_r_l = rt_period * motor.rs * motor.inv_ls;
    estialpha = Maverick::Ewma0::compute(alpha_r_l, 
                (valpha_prev - (motor.ls * zalpha + k_sigm * data.zalpha_f)) * motor.inv_rs,
                estialpha);
    estibeta = Maverick::Ewma0::compute(alpha_r_l, 
               (vbeta_prev - (motor.ls * zbeta + k_sigm * data.zbeta_f)) * motor.inv_rs,
               estibeta);
    
    // Calculate unfiltered back-EMF
    zalpha = kslide * (estialpha - clarke1.alpha);
    zbeta = kslide * (estibeta - clarke1.beta);
    
    // First filter stage
    const Real alpha_z = Mc_const::smo_wc_emf * rt_period;
    data.zalpha_f = Maverick::Ewma0::compute(alpha_z, zalpha, data.zalpha_f);
    data.zbeta_f = Maverick::Ewma0::compute(alpha_z, zbeta, data.zbeta_f);
    
    // Second filter stage with adaptive coefficient
    const Real omega_e = Rmath::fabsr(omegae);
    const Real alpha = Rfun::max<Real>(Mc_const::wmin_sensorless * rt_period, omega_e * rt_period);
    data.ealpha_f = Maverick::Ewma0::compute(alpha, data.zalpha_f, data.ealpha_f);
    data.ebeta_f = Maverick::Ewma0::compute(alpha, data.zbeta_f, data.ebeta_f);
    
    // Amplitude compensation for low speeds
    static const Real comp0 = (Const::SQRT2 - 1.0F) / Mc_const::wmin_sensorless;
    Real g_comp = Rfun::clamp<Real>(omega_e, 0, Mc_const::wmin_sensorless);
    g_comp = g_comp * comp0 + 1.0F;
    
    // Final back-EMF values with compensation
    ea_eb.c = data.ealpha_f * g_comp;
    ea_eb.s = data.ebeta_f * g_comp;
    
    // Store voltage values for next iteration
    valpha_prev = volt1.alpha;
    vbeta_prev = volt1.beta;
}
```

### 1.3 Key Parameters

| Parameter | Description | Default Value | Unit |
|-----------|-------------|---------------|------|
| `kslide` | Sliding control gain | `Mc_const::smo_default_kslide` | V/A |
| `k_sigm` | Back-EMF feedback gain | `Mc_const::smo_default_k` | - |
| `smo_wc_emf` | Back-EMF filter cut-off frequency | - | rad/s |
| `wmin_sensorless` | Minimum speed for sensorless operation | - | rad/s |

## 2. Position and Speed Estimation Methods

### 2.1 Arctan Observer

The `Arctan_observer` class estimates electrical position and speed from the back-EMF using the arctangent function.

```cpp
void Arctan_observer::step() {
    // Get back-EMF components
    theta_est = bemf.get_sincos().get_angle();
    
    // Calculate speed using numerical derivative
    speed.step(theta_est);
    omega_est = speed.get_speed();
}
```

#### 2.1.1 Key Features

- Simple implementation using direct arctangent calculation
- Uses `Mangle_rate` for numerical differentiation of angle
- Always reports "ready" status (`is_ok()` returns true)
- Configurable time filter constant (`default_tau = 1.05E-5F`)

### 2.2 Low PLL Observer

The `Low_pll` class implements a Phase-Locked Loop for low-speed position and speed estimation.

```cpp
void Low_pll::step() {
    // Get back-EMF components
    const Maverick::Sincos ea_eb = bemf.get_sincos();
    
    // Calculate sine and cosine of estimated angle
    const Maverick::Sincos sc(theta_est);
    
    // Transform back-EMF to rotating frame
    park.step(ea_eb.c, ea_eb.s, sc);
    
    // Filter d-q components
    const Real alpha_f = filter_freq * rt_period;
    ed = Maverick::Ewma0::compute(alpha_f, park.ds, ed);
    eq = Maverick::Ewma0::compute(alpha_f, park.qs, eq);
    
    // Calculate observer terms
    const Real d_term = -k * ed * Rfun::sign(eq);
    const Real q_term = k * eq;
    
    // Update speed and position
    omega_est = d_term + q_term;
    theta_est = Rfun::wrap2pi(theta_est + rt_period * omega_est);
}
```

#### 2.2.1 Key Features

- Uses Park transformation to convert back-EMF to rotating frame
- Implements a PLL structure with d-q axis error terms
- Configurable filter frequency (`filter_freq0 = 5000.0F rad/s`)
- Observer gain (`k`) calculated as inverse of motor back-EMF constant

### 2.3 Speed_sincos (SIN/COS Sensor Processing)

The `Speed_sincos` class computes speed and angle from SIN/COS sensor signals.

```cpp
void Speed_sincos::step() {
    // Execute PLL algorithm with SIN/COS signals
    pll.step(cfg.sincos.get_sincos());
}

Real Speed_sincos::get_speed() const {
    // Convert electrical to mechanical speed
    return (pll.get_speed() * static_cast<Real>(cfg.npoles));
}

Real Speed_sincos::get_angle() const {
    // Convert electrical to mechanical angle
    return Rfun::wrap2pi(pll.get_angle() * static_cast<Real>(cfg.npoles));
}
```

#### 2.3.1 Key Features

- Uses `Tangent_pll_base` for position and speed estimation
- Converts between electrical and mechanical domains using pole pairs
- Integrates with `Isincos_checker` for signal validation
- Configurable PLL gains via `set_gains(k_pos, k_spd)`

## 3. Signal Validation (Sincos_checker)

The `Sincos_checker` class validates SIN/COS signals by checking trigonometric identity and comparing multiple sensors.

```cpp
void Sincos_checker::step() {
    // Get SIN/COS signals
    const Maverick::Sincos sc1 = sincos1.get_sincos();
    const Maverick::Sincos sc2 = sincos2.get_sincos();
    
    // Check each channel for trigonometric validity
    const bool sc1_faulted = posse1.step(sc1);
    const bool sc2_faulted = posse2.step(sc2);
    
    // Compare signals between sensors
    err_s = Maverick::Ewma0::compute(alpha_s2s,
                                    Rmath::fabsr(sc1.s - sc2.s), err_s);
    err_c = Maverick::Ewma0::compute(alpha_s2s,
                                    Rmath::fabsr(sc1.c - sc2.c), err_c);
    
    // Determine if signals match
    bool s2s_faulted = false;
    if((err_c < s2s_limit_low) && (err_s < s2s_limit_low)) {
        s2s_faulted = false;
    } else if((err_c > s2s_limit_up) || (err_s > s2s_limit_up)) {
        s2s_faulted = true;
    }
    
    // Accumulate fault counter if any check fails
    if(!is_faulted()) {
        if(sc1_faulted || sc2_faulted || s2s_faulted) {
            ++count;
        } else {
            count = 0U;
        }
    }
}
```

### 3.1 POSSE Channel Validation

Each SIN/COS signal is validated using the POSSE (Position Sensor Error) algorithm:

```cpp
bool Sincos_checker::Posse_channel::step(const Maverick::Sincos sc) {
    // Check sin²+cos²=1 identity
    err_sc = Maverick::Ewma0::compute(alpha_sc,
                                     Rmath::fabsr(sc.c * sc.c + sc.s * sc.s - 1.0F), 
                                     err_sc);
    
    // Determine fault status based on error thresholds
    if(err_sc < low_limit_sc) {
        is_faulted = false;
    } else if(err_sc > up_limit_sc) {
        is_faulted = true;
    }
    
    return is_faulted;
}
```

### 3.2 Key Parameters

| Parameter | Description | Default Value |
|-----------|-------------|---------------|
| `up_limit_sc0` | Upper limit for trigonometric check | 0.4F |
| `low_limit_sc0` | Lower limit for trigonometric check | 0.28F |
| `sc_t0` | Maximum counter for estimator error | 4000U |
| `s2s_limit_up0` | Maximum error between sensors | 0.3F |
| `s2s_limit_low0` | Minimum error between sensors | 0.2F |

## 4. Virtual Motor for Startup (Virtualmotor)

The `Virtualmotor` class generates angle and speed ramps for motor startup in open-loop mode.

```cpp
void Virtualmotor::step() {
    // Set speed based on direction
    speed = start_direction ? -max_spd : max_spd;
    
    // Update mechanical angle
    mangle = Rfun::wrap2pi(mangle + speed * rt_period);
    
    // Calculate electrical angle
    eangle = Rfun::wrap2pi(mangle * static_cast<Real>(pp));
}
```

### 4.1 Key Features

- Provides controlled ramp for open-loop startup
- Configurable maximum speed (`default_start_spd = 15.0F rad/s`)
- Configurable startup current (`def_start_iq = 75.0F A`)
- Bidirectional operation via `set_start_direction()`

## 5. Integration in Field-Oriented Control

The position and speed estimation components are integrated into the Field-Oriented Control (FOC) algorithm through the `step_observer()` method:

```cpp
void Control_foc_noenc::step_observer() {
    // Estimate back-EMF using Sliding Mode Observer
    smo1.step();
    
    // Get position and speed from current estimator
    curr_estimator->step();
    const Real ls_eangle = curr_estimator->get_angle();
    const Real ls_omegae = curr_estimator->get_speed();
    
    // Filter low-speed estimate
    omegae_ls_filt = Ewma0::compute(alpha_speed, ls_omegae, omegae_ls_filt);
    
    // Calculate mixing ratio between observers
    const Real p_hs = Rfun::clamp<Real>(
        ((Rmath::fabsr(omegae_ls_filt * motor.pp_1) - wmin_morph) / 
         (wmax_morph - wmin_morph)),
        0.0F, 1.0F);
    const Real p_ls = 1.0F - p_hs;
    
    // High-speed observer (PLL)
    if(p_hs > 0.0F) {
        pll.step();
    } else {
        pll.reset(ls_eangle, ls_omegae);
    }
    
    // Get high-speed estimates
    const Real hs_eangle = pll.get_angle();
    const Real hs_omegae = pll.get_speed();
    
    // Filter high-speed estimate
    omegae_hs_filt = Ewma0::compute(alpha_speed, hs_omegae, omegae_hs_filt);
    
    // Combine estimates based on speed range
    omegae = p_hs * omegae_hs_filt + p_ls * omegae_ls_filt;
    omega = omegae * motor.pp_1;  // Convert to mechanical speed
    
    // Calculate final flux angle with observer mixing
    const Real diff = Rfun::wrap2pi(hs_eangle - ls_eangle);
    flux_angle = Rfun::wrap2pi(p_hs * hs_eangle + p_ls * (hs_eangle - diff));
}
```

## 6. Observer Selection and Mixing Strategy

The system employs a sophisticated observer mixing strategy that combines different estimation techniques based on operating conditions:

### 6.1 Low-Speed Operation

At low speeds (below `wmin_morph`):
- The `curr_estimator` (which could be `Arctan_observer` or `Low_pll`) provides position and speed
- The high-speed PLL is reset to match the low-speed estimate

### 6.2 Transition Region

In the speed range between `wmin_morph` and `wmax_morph`:
- Both low and high-speed observers are active
- Their outputs are mixed with a ratio `p_hs` that increases with speed
- This ensures smooth transition between estimation methods

### 6.3 High-Speed Operation

At high speeds (above `wmax_morph`):
- The high-speed PLL provides position and speed
- The low-speed observer continues running but its output is not used

## 7. Filtering Techniques

The system employs several filtering techniques to improve estimation quality:

### 7.1 Exponentially Weighted Moving Average (EWMA)

The `Ewma0::compute()` function is used extensively for filtering:

```cpp
// Generic EWMA filter implementation
filtered_value = Ewma0::compute(alpha, new_value, previous_filtered_value);
```

Where:
- `alpha` is the filter coefficient (typically `cutoff_frequency * rt_period`)
- Higher `alpha` values result in faster response but more noise
- Lower `alpha` values provide more filtering but introduce lag

### 7.2 Adaptive Filtering

The verification implementation of `Smobserver` uses adaptive filtering:
- Filter coefficient varies with motor speed
- At low speeds, a minimum cutoff frequency is used (`wmin_sensorless`)
- At higher speeds, the cutoff frequency increases proportionally to speed
- This provides better noise rejection at low speeds while maintaining dynamic response at high speeds

### 7.3 Amplitude Compensation

To compensate for filter attenuation at low speeds:
- A compensation factor `g_comp` is calculated based on speed
- This factor increases the estimated back-EMF amplitude at low speeds
- The compensation approaches 1.0 (no effect) at higher speeds

## 8. System Integration Diagram

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│  Phase Currents │     │  Phase Voltages │     │  SIN/COS Sensors│
└────────┬────────┘     └────────┬────────┘     └────────┬────────┘
         │                       │                       │
         ▼                       ▼                       ▼
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│  Clarke         │     │  Sliding Mode   │     │  Sincos_checker │
│  Transformation │     │  Observer       │     │  (Validation)   │
└────────┬────────┘     └────────┬────────┘     └────────┬────────┘
         │                       │                       │
         │                       ▼                       │
         │             ┌─────────────────┐               │
         │             │  Back-EMF       │               │
         │             │  (alpha-beta)   │               │
         │             └────────┬────────┘               │
         │                      │                        │
         │                      ▼                        │
         │             ┌─────────────────────────────────┴────────┐
         │             │  Position & Speed Estimators            │
         │             │  - Arctan_observer (low speed)          │
         │             │  - Low_pll (low speed)                  │
         │             │  - Speed_sincos (sensor-based)          │
         │             │  - Virtualmotor (startup)               │
         │             └────────┬────────────────────────────────┘
         │                      │
         │                      ▼
         │             ┌─────────────────┐
         │             │  Observer       │
         │             │  Mixing Logic   │
         │             └────────┬────────┘
         │                      │
         │                      ▼
         │             ┌─────────────────┐
         │             │  Final Position │
         │             │  and Speed      │
         │             └────────┬────────┘
         │                      │
         ▼                      ▼
┌─────────────────────────────────────────┐
│  Field-Oriented Control                 │
│  - Park Transformation                  │
│  - Current Control                      │
│  - Space Vector PWM                     │
└─────────────────────────────────────────┘
```

## 9. Summary of Key Parameters

| Component | Parameter | Description | Typical Value |
|-----------|-----------|-------------|--------------|
| Smobserver | `kslide` | Sliding control gain | System-dependent |
| Smobserver | `k_sigm` | Back-EMF feedback gain | System-dependent |
| Smobserver | `smo_wc_emf` | Back-EMF filter cutoff | System-dependent |
| Low_pll | `filter_freq` | Filter pole frequency | 5000.0 rad/s |
| Low_pll | `k` | Observer gain | 1/motor.ke |
| Arctan_observer | `default_tau` | Time filter constant | 1.05E-5 s |
| Sincos_checker | `up_limit_sc` | Upper trigonometric check limit | 0.4 |
| Sincos_checker | `low_limit_sc` | Lower trigonometric check limit | 0.28 |
| Sincos_checker | `s2s_limit_up` | Upper sensor comparison limit | 0.3 |
| Sincos_checker | `s2s_limit_low` | Lower sensor comparison limit | 0.2 |
| Virtualmotor | `max_spd` | Maximum startup speed | 15.0 rad/s |
| Virtualmotor | `start_iq` | Startup current | 75.0 A |
| Observer Mixing | `wmin_morph` | Lower mixing threshold | ~2.2% of max_rpm |
| Observer Mixing | `wmax_morph` | Upper mixing threshold | ~12% of max_rpm |

This comprehensive analysis details how the motor control system uses multiple estimation techniques that work together to provide reliable position and speed information across the entire operating range, from startup to maximum speed, in both sensored and sensorless modes.