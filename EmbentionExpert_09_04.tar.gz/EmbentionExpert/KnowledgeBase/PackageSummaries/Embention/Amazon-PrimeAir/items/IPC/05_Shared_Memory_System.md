# Generated from:

- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/include/Mc_shared_memory_types.h (1812 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/include/Vars_mc.h (3268 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/include/cpu1/Mc_shared_memory.h (325 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/include/cpu2/Mc_shared_memory.h (106 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/include/pa/Mc_shared_priv.h (64 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/include/ver/Mc_shared_priv.h (677 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/source/Mc_shared_memory_types.cpp (2992 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/source/Vars_mc_common.cpp (1593 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/source/cpu1/Vars_mc_c1.cpp (1879 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/source/cpu1/Mc_shared_memory_c1.cpp (339 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/source/cpu2/Vars_mc_c2.cpp (1853 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/source/cpu2/Mc_shared_memory_c2.cpp (376 tokens)

## With context from:

- PackageSummaries/Amazon-PrimeAir/items/IPC/07_Motor_Controller_Architecture.md (2764 tokens)

---

# Shared Memory System for Cross-Core Communication in Motor Controller

## 1. Memory Ownership Model

The motor controller implements a structured shared memory system that enables communication between CPU1, CPU2, and CM cores. The ownership model is clearly defined with specific read/write permissions:

### 1.1 Core-Specific Memory Regions

```
CPU1 (C1_owned)                  CPU2 (C2_owned)
+------------------+             +------------------+
| varmgr_values_c1 |             | varmgr_values_c2 |
| hwv              |             | c2_load_st       |
| uid64            |             | motor_max_rpm    |
| lock_diag_writing|             | ffwr_diag        |
| ffrd_diag        |             | faults           |
| change_role      |             | msk_critical     |
| sync_enabled     |             | critical_fault   |
| sync1_duty       |             | pwm_mode         |
| pwm_shift        |             | enable_interleaving |
| mci_st           |             | init_complete    |
| fsm_st           |             | aligment_complete|
| faults           |             | open_loop_complete |
| inhibit_termination |          | st_after_alignment |
| terminal_fault   |             | input_deadband   |
| reset_ctrl_state |             | has_ground_fault_protection |
| curr_esc_id      |             | adc_vdc/vmon/str_temp |
| is_ipc_board     |             | c2_shared_priv   |
| c1_shared_priv   |             +------------------+
+------------------+
```

### 1.2 Access Permissions

- **CPU1-owned memory (C1_owned)**:
  - CPU1 has read/write access
  - CPU2 has read-only access
  - Implemented through `get_c1_sh_mem()` function

- **CPU2-owned memory (C2_owned)**:
  - CPU2 has read/write access
  - CPU1 has read-only access
  - Implemented through `get_c2_sh_mem()` function

### 1.3 Memory Addressing

The shared memory is implemented using specific memory addresses:
- CPU1 shared memory address is defined as 0x03A000 (accessed by CPU2)
- CPU2 shared memory address is defined as 0x03B000 (accessed by CPU1)

```cpp
// In CPU1 implementation
C1_owned& get_c1_sh_mem() {
    static C1_owned c1_mem;
    return c1_mem;
}

const volatile C2_owned& get_c2_sh_mem() {
    static C2_owned& c2_mem = *reinterpret_cast<C2_owned*>(reinterpret_cast<Uint32>(&c2_sh_addr));
    return c2_mem;
}

// In CPU2 implementation
const volatile C1_owned& get_c1_sh_mem() {
    static C1_owned& c1_mem = *reinterpret_cast<C1_owned*>(reinterpret_cast<Uint32>(&c1_sh_addr));
    return c1_mem;
}

C2_owned& get_c2_sh_mem() {
    static C2_owned c2_mem;
    return c2_mem;
}
```

## 2. Variable Management System

The shared memory system implements a sophisticated variable management system with three types of variables:

### 2.1 Variable Types

1. **Bvar (Boolean Variables)**
   - Boolean values for status flags, fault indicators, and system states
   - CPU1 owns 22 Bvars, CPU2 owns 38 Bvars

2. **Uvar (Unsigned Integer Variables)**
   - 16-bit unsigned integers for configuration parameters, state identifiers, etc.
   - CPU1 owns 18 Uvars, CPU2 owns 3 Uvars

3. **Rvar (Real Variables)**
   - Floating-point values for measurements, control parameters, etc.
   - CPU1 owns 24 Rvars, CPU2 owns 59 Rvars

### 2.2 Variable Storage Structure

Each core's variables are stored in a structured format:

```cpp
template<Uint16 nbvars, Uint16 ubvars, Uint16 rbvars>
struct Var_values {
    typedef Tnarray<bool,   nbvars> Tbvar_values;
    typedef Tnarray<Uint16, ubvars> Tuvar_values;
    typedef Tnarray<Real,   rbvars> Trvar_values;
    Tbvar_values bvar_values;  // Array storing Boolean variable values
    Tuvar_values uvar_values;  // Array storing Unsigned Integer variable values
    Trvar_values rvar_values;  // Array storing Real (floating-point) variable values
};

// Type definitions for each core's variables
typedef Var_values<nbvars_c1, nuvars_c1, nrvars_c1> Tvar_values_c1;  // CPU1 variables
typedef Var_values<nbvars_c2, nuvars_c2, nrvars_c2> Tvar_values_c2;  // CPU2 variables
```

### 2.3 Variable Access Methods

The system provides several methods to access variables across cores:

1. **Read-Write Access (Owner Core)**
   - `get_ref(Bvar id)`: Returns a reference to a boolean variable
   - `get_ref(Uvar id)`: Returns a reference to an unsigned integer variable
   - `get_ref(Rvar id)`: Returns a reference to a real variable

2. **Read-Only Access (Non-Owner Core)**
   - `get_kref(Bvar id)`: Returns a read-only reference to a boolean variable
   - `get_kref(Uvar id)`: Returns a read-only reference to an unsigned integer variable
   - `get_kref(Rvar id)`: Returns a read-only reference to a real variable

3. **Variable Lookup Mechanism**
   - Uses binary search to find variables by ID
   - Returns null reference with warning if variable ID is not found
   - Handles special cases like `kbit_ok` directly

```cpp
// Example of variable access implementation (for CPU1)
volatile bool& get_ref(Bvar id) {
    static volatile bool null_v;
    Uint32 idx = Base::Binary_search<Bvar>::search(bvar_ids, id);
    return Assertions::runtime(idx < bvar_ids.size()) ? bvar_values[idx] : null_v;
}

// Example of read-only access implementation (for both cores)
const volatile bool& get_kref(Bvar id) {
    static const volatile bool null_values[] = { false, true };
    const volatile bool* res = &null_values[0];
    if(id <= kbit_ok) {
        res = &null_values[id];
    } else {
        Uint32 idx = Base::Binary_search<Bvar>::search(bvar_ids_c1, id);
        if(idx < bvar_ids_c1.size()) {
            res = &bvar_values_c1[idx];
        } else {
            idx = Base::Binary_search<Bvar>::search(bvar_ids_c2, id);
            if(Assertions::runtime(idx < bvar_ids_c2.size())) {
                res = &bvar_values_c2[idx];
            }
        }
    }
    return *res;
}
```

## 3. Cross-Core FIFO Communication

The system implements a cross-core FIFO buffer mechanism for transferring diagnostic data between cores:

### 3.1 FIFO Buffer Structure

```
CPU1                             CPU2
+------------------+             +------------------+
| ffrd_diag        | <---------- | ffwr_diag        |
| (read end)       |             | (write end)      |
+------------------+             +------------------+
```

- CPU2 writes diagnostic data to `ffwr_diag` (size = 4 entries)
- CPU1 reads diagnostic data from `ffrd_diag`
- Data type is `IPC_diag` which contains diagnostic information

### 3.2 FIFO Implementation

The FIFO is implemented using two complementary classes:
- `Xcffwr<IPC_diag, ff_diag_size>`: Cross-core FIFO writer (used by CPU2)
- `Xcffrd<IPC_diag>`: Cross-core FIFO reader (used by CPU1)

This allows CPU2 to continuously record diagnostic data that CPU1 can read and process or transmit.

## 4. Private Shared Memory Regions

Each core also has private shared memory regions that are not directly accessible by the other core:

### 4.1 CPU1 Private Shared Memory

In the verification build (`ver`), CPU1's private shared memory contains configuration buffers:

```cpp
struct C1_private {
    struct Cfg_buffers {
        // Various tuning buffers with specific sizes
        Base::Tnarray<Uint16, mc_control_tun_sz> pdic_mc_control;
        Base::Tnarray<Uint16, ctrl_tun_sz> pdic_ctrl;
        Base::Tnarray<Uint16, sincos1_tun_sz> pdic_sincos1;
        Base::Tnarray<Uint16, smob_tun_sz> pdic_smob;
        Base::Tnarray<Uint16, arctanob_tun_sz> pdic_arctanob;
        Base::Tnarray<Uint16, pll_tun_sz> pdic_pll;
        Base::Tnarray<Uint16, pll_low_tun_sz> pdic_pll_low;
        Base::Tnarray<Uint16, fault_det_tun_sz> pdic_fault_det;
        Base::Tnarray<Uint16, vmotor_tun_sz> pdic_vmotor;
    };
    Cfg_buffers buffers;  // Configuration PDICs, to be used by C2
};
```

### 4.2 CPU2 Private Shared Memory

In the production build (`pa`), CPU2's private shared memory contains hash data for code verification:

```cpp
struct C2_private {
    Base::Sha256_data::Type c2hash_data;  // C2 code SHA256 result
};
```

## 5. Synchronization Mechanisms

The shared memory system includes several synchronization mechanisms:

### 5.1 Initialization Synchronization

- Both cores initialize their own memory regions
- CPU1 initializes first, then unlocks CPU2
- CPU2 waits for unlock, initializes, then signals back to CPU1

### 5.2 PWM Synchronization Control

Several shared variables control PWM synchronization between cores:
- `change_role`: Flag indicating a change in PWM sync role is needed
- `sync_enabled`: Flag indicating synchronization is enabled
- `sync1_duty`: Sync output duty to write when changing roles
- `pwm_shift`: Phase shift to use in slave mode
- `pwm_mode`: Indicates if this MC is generating PWM sync or using it

### 5.3 Fault Handling Synchronization

- `faults`: Fault status for each core
- `msk_critical`: Mask for critical errors
- `critical_fault`: Flag indicating a terminal fault
- `terminal_fault`: Critical fault from CPU1
- `inhibit_termination`: Flag indicating faults are not allowed

## 6. Memory Layout and Parameters

The shared memory system has specific layout parameters:

### 6.1 Variable Arrays

- CPU1 Boolean variables: 22 entries
- CPU2 Boolean variables: 38 entries
- CPU1 Unsigned variables: 18 entries
- CPU2 Unsigned variables: 3 entries
- CPU1 Real variables: 24 entries
- CPU2 Real variables: 59 entries

### 6.2 Diagnostic FIFO

- FIFO size: 4 entries (`ff_diag_size = 4`)
- Data type: `IPC_diag`

### 6.3 Configuration Buffers (Verification Build)

- Motor control tuning: 3 entries
- Control tuning: 112 entries
- SIN/COS tuning: 13 entries
- SMOB tuning: 4 entries
- Arctan object tuning: 2 entries
- PLL tuning: 4 entries
- Low frequency PLL tuning: 2 entries
- Fault detection tuning: 21 entries
- Motor voltage tuning: 5 entries

## 7. Error Handling Mechanisms

The shared memory system implements several error handling mechanisms:

### 7.1 Variable Access Validation

- Binary search to find variable IDs
- Runtime assertions to check if variable ID exists
- Warning messages when accessing non-existent variables
- Default/null values returned for invalid accesses

### 7.2 Fault Propagation

- Critical faults are shared between cores
- Mask for critical errors defines which faults are terminal
- Terminal faults trigger system shutdown

## 8. Core-Specific Implementation Details

### 8.1 CPU1 Implementation

- Owns and initializes `C1_owned` structure
- Accesses `C2_owned` structure through memory-mapped pointer
- Implements read-write access to CPU1 variables
- Implements read-only access to CPU2 variables
- Reads diagnostic data from FIFO

### 8.2 CPU2 Implementation

- Owns and initializes `C2_owned` structure
- Accesses `C1_owned` structure through memory-mapped pointer
- Implements read-write access to CPU2 variables
- Implements read-only access to CPU1 variables
- Writes diagnostic data to FIFO

## Referenced Context Files

The following context file provided valuable insights for understanding the dual-core architecture:

- `07_Motor_Controller_Architecture.md`: Provided overall context about the dual-core architecture, execution model, and inter-core communication mechanisms.

The shared memory system forms the backbone of the inter-core communication in the motor controller, enabling efficient data exchange while maintaining clear ownership boundaries. The variable management system provides a structured approach to sharing configuration parameters, status information, and diagnostic data between cores, while the cross-core FIFO mechanism enables efficient transfer of high-frequency diagnostic data.