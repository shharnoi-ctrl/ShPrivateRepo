# Generated from:

- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/include/Motor_telemetry.h (1224 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/include/Motor_performance_st.h (1455 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/include/Esc_state_st.h (632 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/include/Esc_health_alerts_st.h (424 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/include/Motor_diagnostics.h (363 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/source/Motor_telemetry.cpp (1546 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/source/Motor_performance_st.cpp (1873 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/source/Esc_state_st.cpp (907 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/source/Esc_health_alerts_st.cpp (87 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/source/Motor_diagnostics.cpp (573 tokens)

## With context from:

- PackageSummaries/Amazon-PrimeAir/items/IPC/06_Motor_Control_State_Machine.md (4178 tokens)
- PackageSummaries/Amazon-PrimeAir/items/IPC/04_Protection_Systems.md (6243 tokens)

---

# Motor Controller Telemetry and Diagnostics System

## 1. Functional Behavior and Logic

The motor controller implements a comprehensive telemetry and diagnostics system that collects, processes, and serializes various performance metrics and health indicators. This system is responsible for providing real-time data about the motor's operation, enabling external systems to monitor performance, diagnose issues, and make informed decisions.

### 1.1 Motor Telemetry Collection

The `Motor_telemetry` class serves as the primary interface for collecting and serializing basic motor telemetry data:

- **Responsibility**: Collects and serializes key motor performance parameters
- **Triggers**: Called periodically by the telemetry subsystem
- **Data Sources**: References to volatile system variables tracking motor parameters
- **Output Format**: Bit-packed data structure with specific bit widths for each parameter

The telemetry data includes:
- Board microcontroller temperature (9 bits, in Celsius)
- Inverter DC current (12 bits, scaled by 10)
- Battery string temperature (9 bits, in Celsius)
- Phases temperature (9 bits, in Celsius)
- Commanded quadrature current (13 bits, scaled by 10)
- Measured quadrature current (13 bits, scaled by 10)
- Motor temperature (9 bits, in Celsius)
- Desired mechanical angular speed (14 bits, in RPM)
- Measured mechanical angular speed (14 bits, in RPM)

### 1.2 Motor Performance Status Reporting

The `Motor_performance_st` class provides a more comprehensive status report about the motor's performance:

- **Responsibility**: Collects and serializes detailed motor performance data
- **Triggers**: Called periodically by the telemetry subsystem
- **Data Sources**: References to volatile system variables and ESC state
- **Output Format**: Mixed format with fixed-width integers and bit fields

The performance status includes:
- Cyphal node ID (16 bits)
- Desired mechanical angular speed (16 bits, in RPM)
- Measured mechanical angular speed (16 bits, in RPM)
- Filtered DC current (16 bits, in centiamps)
- Filtered DC voltage (10 bits, in decivolts)
- Desired quadrature current (20 bits, in milliamps)
- Measured quadrature current (20 bits, in milliamps)
- Shore power connection status (1 bit)
- ESC state information (variable bits)

### 1.3 ESC State Status Reporting

The `Esc_state_st` class manages the serialization of the ESC (Electronic Speed Controller) state:

- **Responsibility**: Collects and serializes ESC state flags
- **Triggers**: Called by `Motor_performance_st` during serialization
- **Data Sources**: References to volatile system flags and health alerts
- **Output Format**: Bit fields for state flags

The ESC state includes:
- Health alerts (48 bits)
- Armed status flag (1 bit)
- Ready status flag (1 bit)
- Enabled status flag (1 bit)
- Faulted status flag (1 bit)

### 1.4 ESC Health Alerts Reporting

The `Esc_health_alerts_st` class handles the serialization of health alerts:

- **Responsibility**: Collects and serializes fault conditions
- **Triggers**: Called by `Esc_state_st` during serialization
- **Data Sources**: References to fault bitmasks from both processor cores
- **Output Format**: 48-bit bitmask of active faults

The health alerts combine fault flags from:
- Core 1 fault bitmask
- Core 2 fault bitmask

### 1.5 Motor Diagnostics Reporting

The `Motor_diagnostics` class provides additional diagnostic information:

- **Responsibility**: Collects and serializes diagnostic data
- **Triggers**: Called periodically by the diagnostics subsystem
- **Data Sources**: References to volatile system variables
- **Output Format**: Bit-packed data structure

The diagnostics data includes:
- Battery string DC current (12 bits, scaled by 10)
- Current ESC mode (3 bits)

## 2. Control Flow and State Transitions

The telemetry and diagnostics system operates as a data collection and serialization pipeline without complex state transitions. The primary control flow involves:

1. **Data Collection**: References to volatile system variables are established during initialization
2. **Data Serialization**: When requested, current values are read, processed, and serialized
3. **Data Transmission**: Serialized data is made available to external systems

## 3. Inputs and Stimuli

### 3.1 Motor Telemetry Inputs

| Input | Source | Processing | Effect | Location |
|-------|--------|------------|--------|----------|
| `board_temp` | `Base::Rvar::v_board_temp` | Converted to Celsius, bounded to 9 bits | Included in telemetry | `Motor_telemetry.cpp:cget()` |
| `dc_curr` | `Base::Rvar::v_input_current` | Multiplied by 10, bounded to 12 bits | Included in telemetry | `Motor_telemetry.cpp:cget()` |
| `str_temp` | `Base::Rvar::v_power_temp` | Converted to Celsius, bounded to 9 bits | Included in telemetry | `Motor_telemetry.cpp:cget()` |
| `phase_temp` | `Base::Rvar::v_phases_temp` | Converted to Celsius, bounded to 9 bits | Included in telemetry | `Motor_telemetry.cpp:cget()` |
| `iq_commanded` | `Base::Rvar::v_park_iqsc` | Multiplied by 10, bounded to 13 bits | Included in telemetry | `Motor_telemetry.cpp:cget()` |
| `iq_measured` | `Base::Rvar::v_park_iqs` | Multiplied by 10, bounded to 13 bits | Included in telemetry | `Motor_telemetry.cpp:cget()` |
| `motor_temp` | `Base::Rvar::v_ext_temp` | Converted to Celsius, bounded to 9 bits | Included in telemetry | `Motor_telemetry.cpp:cget()` |
| `spd_command` | `Base::Rvar::v_mangle_ratec` | Converted to RPM, bounded to 14 bits | Included in telemetry | `Motor_telemetry.cpp:cget()` |
| `spd_blended` | `Base::Rvar::v_mangle_rate` | Converted to RPM, bounded to 14 bits | Included in telemetry | `Motor_telemetry.cpp:cget()` |

### 3.2 Motor Performance Status Inputs

| Input | Source | Processing | Effect | Location |
|-------|--------|------------|--------|----------|
| `node_id` | Constructor parameter | None | Included in performance status | `Motor_performance_st.cpp:cget()` |
| `commanded` | `Base::Rvar::v_mangle_ratec` | Converted to RPM | Included in performance status | `Motor_performance_st.cpp:cget()` |
| `measured` | `Base::Rvar::v_mangle_rate` | Converted to RPM | Included in performance status | `Motor_performance_st.cpp:cget()` |
| `input_current_A` | `Base::Rvar::v_idc_filt` | Converted to centiamps | Included in performance status | `Motor_performance_st.cpp:cget()` |
| `input_voltage_V` | `Base::Rvar::v_vdc_filt` | Converted to decivolts, bounded to 10 bits | Included in performance status | `Motor_performance_st.cpp:cget()` |
| `commanded_iq_A` | `Base::Rvar::v_park_iqsc` | Converted to milliamps, bounded to 20 bits | Included in performance status | `Motor_performance_st.cpp:cget()` |
| `measured_iq_A` | `Base::Rvar::v_park_iqs` | Converted to milliamps, bounded to 20 bits | Included in performance status | `Motor_performance_st.cpp:cget()` |
| `is_on_ext_power` | `Base::Bvar::kbit_shore_power` | None | Included in performance status | `Motor_performance_st.cpp:cget()` |
| `faults_c10`, `faults_c20` | Constructor parameters | Passed to `Esc_state_st` constructor | Used for ESC state | `Motor_performance_st.cpp:Motor_performance_st()` |

### 3.3 ESC State Status Inputs

| Input | Source | Processing | Effect | Location |
|-------|--------|------------|--------|----------|
| `is_armed` | `Base::Bvar::kbit_is_armed` | None | Included in ESC state | `Esc_state_st.cpp:read()` |
| `is_ready` | `Base::Bvar::kbit_is_ready` | None | Included in ESC state | `Esc_state_st.cpp:read()` |
| `is_enabled` | `Base::Bvar::kbit_is_enabled` | None | Included in ESC state | `Esc_state_st.cpp:read()` |
| `is_faulted` | `Base::Bvar::kbit_is_faulted` | None | Included in ESC state | `Esc_state_st.cpp:read()` |
| `faults_c10`, `faults_c20` | Constructor parameters | Passed to `Esc_health_alerts_st` constructor | Used for health alerts | `Esc_state_st.cpp:Esc_state_st()` |

### 3.4 Motor Diagnostics Inputs

| Input | Source | Processing | Effect | Location |
|-------|--------|------------|--------|----------|
| `str_curr` | `Base::Rvar::v_str_dc_curr` | Multiplied by 10, bounded to 12 bits | Included in diagnostics | `Motor_diagnostics.cpp:cget()` |
| `mode` | `Base::Uvar::vu_state` | Bounded to 3 bits | Included in diagnostics | `Motor_diagnostics.cpp:cget()` |

## 4. Outputs and Effects

### 4.1 Serialized Telemetry Data

The telemetry system produces serialized data streams that are made available to external systems:

| Output | Format | Trigger | Location |
|--------|--------|---------|----------|
| Motor Telemetry | Bit-packed structure (93 bits total) | Periodic telemetry request | `Motor_telemetry.cpp:cget()` |
| Motor Performance Status | Mixed format (little-endian) | Periodic status request | `Motor_performance_st.cpp:cget()` |
| ESC State Status | Bit fields | Part of performance status | `Esc_state_st.cpp:read()` |
| ESC Health Alerts | 48-bit bitmask | Part of ESC state status | `Esc_health_alerts_st.cpp:read()` |
| Motor Diagnostics | Bit-packed structure (15+ bits) | Periodic diagnostics request | `Motor_diagnostics.cpp:cget()` |

### 4.2 Data Serialization Methods

The telemetry system uses several methods to efficiently serialize data:

1. **Direct Integer Serialization**:
   - `put_uint16_le()`: Writes 16-bit unsigned integers in little-endian format
   - `put_int16_le()`: Writes 16-bit signed integers in little-endian format

2. **Bit-Level Serialization**:
   - `put_ibits()`: Writes signed integers with specific bit widths
   - `put_ubits()`: Writes unsigned integers with specific bit widths
   - `put_bool1()`: Writes boolean values as single bits
   - `align_bytes()`: Aligns to byte boundaries

3. **Value Transformation**:
   - Unit conversion (e.g., rad/s to RPM)
   - Scaling (e.g., multiplying by 10, 100, or 1000)
   - Offset adjustment (e.g., Kelvin to Celsius conversion)
   - Bit-width bounding using `bound_signed_to_nbits<>`

## 5. Parameters and Configuration

### 5.1 Telemetry Bit Widths

| Parameter | Value | Description | Location |
|-----------|-------|-------------|----------|
| `nbits9` | 9 | Bit width for temperature values | `Motor_telemetry.cpp:cget()` |
| `nbits12` | 12 | Bit width for current values | `Motor_telemetry.cpp:cget()`, `Motor_diagnostics.cpp:cget()` |
| `nbits13` | 13 | Bit width for quadrature current values | `Motor_telemetry.cpp:cget()` |
| `nbits14` | 14 | Bit width for speed values | `Motor_telemetry.cpp:cget()` |
| `nbits10` | 10 | Bit width for voltage values | `Motor_performance_st.cpp:cget()` |
| `nbits20` | 20 | Bit width for high-precision current values | `Motor_performance_st.cpp:cget()` |
| `nbits3` | 3 | Bit width for ESC mode | `Motor_diagnostics.cpp:cget()` |

### 5.2 Conversion Constants

| Constant | Description | Usage |
|----------|-------------|-------|
| `Const::C2KELVIN` | Celsius to Kelvin conversion factor | Temperature conversion |
| `Const::TEN` | Multiplication factor (10) | Current and voltage scaling |
| `Const::RADS2RPM` | Radians per second to RPM conversion | Speed conversion |
| `Const::ONE_HUNDRED` | Multiplication factor (100) | Current scaling to centiamps |
| `Const::ONE_THOUSAND` | Multiplication factor (1000) | Current scaling to milliamps |
| `Const::ONEHALF` | Division factor (0.5) | Used in calculations |

### 5.3 Health Alerts Configuration

| Parameter | Value | Description | Location |
|-----------|-------|-------------|----------|
| `alerts_count` | 48 | Total number of health alerts supported | `Esc_health_alerts_st.cpp:read()` |

## 6. Error Handling and Contingency Logic

### 6.1 Value Bounding

The telemetry system implements value bounding to ensure that data fits within the allocated bit widths:

```cpp
str.put_ibits(bound_signed_to_nbits<nbits9>(static_cast<int32>(board_temp - Const::C2KELVIN)), nbits9);
```

This prevents overflow or underflow when serializing values that might exceed the representable range.

### 6.2 Fault Reporting

The `Esc_health_alerts_st` class combines fault flags from both processor cores:

```cpp
str.put_ubits(static_cast<Uint64>(faults_c1.value | faults_c2.value), alerts_count);
```

This ensures that all faults are reported regardless of which core detected them.

### 6.3 Data Type Conversion

The telemetry system performs explicit type conversions to ensure proper serialization:

```cpp
os.put_int16_le(static_cast<int16>(commanded*Const::RADS2RPM));
```

This prevents potential issues with implicit type conversions.

## 7. File-by-File Breakdown

### 7.1 Motor_telemetry.h

- **Purpose**: Defines the `Motor_telemetry` class for basic motor telemetry
- **Major Components**:
  - `Motor_telemetry` class declaration
  - References to volatile system variables
- **System Contribution**: Provides interface for collecting and serializing basic motor telemetry

### 7.2 Motor_telemetry.cpp

- **Purpose**: Implements the `Motor_telemetry` class
- **Major Components**:
  - Constructor that initializes references to system variables
  - `cget()` method that serializes telemetry data
- **System Contribution**: Collects and serializes 9 key motor parameters with specific bit widths

### 7.3 Motor_performance_st.h

- **Purpose**: Defines the `Motor_performance_st` class for comprehensive motor performance status
- **Major Components**:
  - `Motor_performance_st` class declaration
  - References to volatile system variables and ESC state
- **System Contribution**: Provides interface for collecting and serializing detailed motor performance data

### 7.4 Motor_performance_st.cpp

- **Purpose**: Implements the `Motor_performance_st` class
- **Major Components**:
  - Constructor that initializes references to system variables
  - `cget()` method that serializes performance data
- **System Contribution**: Collects and serializes comprehensive motor performance data including ESC state

### 7.5 Esc_state_st.h

- **Purpose**: Defines the `Esc_state_st` class for ESC state status
- **Major Components**:
  - `Esc_state_st` class declaration
  - References to volatile system flags and health alerts
- **System Contribution**: Provides interface for collecting and serializing ESC state flags

### 7.6 Esc_state_st.cpp

- **Purpose**: Implements the `Esc_state_st` class
- **Major Components**:
  - Constructor that initializes references to system flags
  - `read()` method that serializes ESC state flags
- **System Contribution**: Collects and serializes ESC state flags including health alerts

### 7.7 Esc_health_alerts_st.h

- **Purpose**: Defines the `Esc_health_alerts_st` class for health alerts
- **Major Components**:
  - `Esc_health_alerts_st` class declaration
  - References to fault bitmasks
- **System Contribution**: Provides interface for collecting and serializing fault conditions

### 7.8 Esc_health_alerts_st.cpp

- **Purpose**: Implements the `Esc_health_alerts_st` class
- **Major Components**:
  - `read()` method that serializes health alerts
- **System Contribution**: Combines and serializes fault flags from both processor cores

### 7.9 Motor_diagnostics.h

- **Purpose**: Defines the `Motor_diagnostics` class for additional diagnostic information
- **Major Components**:
  - `Motor_diagnostics` class declaration
  - References to volatile system variables
- **System Contribution**: Provides interface for collecting and serializing diagnostic data

### 7.10 Motor_diagnostics.cpp

- **Purpose**: Implements the `Motor_diagnostics` class
- **Major Components**:
  - Constructor that initializes references to system variables
  - `cget()` method that serializes diagnostic data
- **System Contribution**: Collects and serializes additional diagnostic information

## 8. Cross-Component Relationships

### 8.1 Class Hierarchy

```
Base::Iserializable_u8
    ├── Motor_telemetry
    ├── Motor_performance_st
    └── Motor_diagnostics

Esc_state_st
    └── Uses Esc_health_alerts_st

Motor_performance_st
    └── Uses Esc_state_st
```

### 8.2 Data Flow

```
System Variables
    │
    ├── Motor_telemetry ──────────────────┐
    │                                     │
    ├── Motor_performance_st ───┐         │
    │       │                   │         │
    │       v                   │         │
    │   Esc_state_st ───┐       │         │
    │       │           │       │         │
    │       v           │       │         │
    │   Esc_health_alerts_st    │         │
    │                           v         v
    └── Motor_diagnostics ──────┴─────────┴─── Serialized Data Streams
```

### 8.3 Dependency Relationships

| Component | Dependencies | Relationship |
|-----------|-------------|--------------|
| `Motor_telemetry` | `Base::Iserializable_u8`, `Base::U8ostream`, `Base::Lossy` | Inheritance, Serialization |
| `Motor_performance_st` | `Base::Iserializable_u8`, `Base::U8ostream`, `Base::Lossy`, `Esc_state_st` | Inheritance, Composition, Serialization |
| `Esc_state_st` | `Base::Lossy`, `Esc_health_alerts_st` | Composition, Serialization |
| `Esc_health_alerts_st` | `Base::Lossy` | Serialization |
| `Motor_diagnostics` | `Base::Iserializable_u8`, `Base::U8ostream`, `Base::Lossy` | Inheritance, Serialization |

## 9. Referenced Context Files

The following context files provided valuable insights for understanding the telemetry and diagnostics system:

- `06_Motor_Control_State_Machine.md`: Provided context on the motor controller's state machine implementation, which helps understand how the telemetry system integrates with the broader motor control architecture. The state flags reported by `Esc_state_st` (is_armed, is_ready, is_enabled, is_faulted) directly correspond to the state machine states described in this file.

- `04_Protection_Systems.md`: While not directly referenced in the analysis, this file would provide context on how the fault flags reported by `Esc_health_alerts_st` are generated and managed by the protection systems.

## Telemetry Data Flow Diagram

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                       Motor Controller System Variables                      │
└───────────────────────────────────────┬─────────────────────────────────────┘
                                        │
                                        │ References
                                        │
┌───────────────────────────────────────▼─────────────────────────────────────┐
│                          Telemetry Collection Classes                        │
│                                                                              │
│  ┌────────────────────┐  ┌────────────────────┐  ┌────────────────────┐     │
│  │  Motor_telemetry   │  │Motor_performance_st│  │ Motor_diagnostics  │     │
│  │                    │  │                    │  │                    │     │
│  │ - board_temp       │  │ - node_id         │  │ - str_curr         │     │
│  │ - dc_curr          │  │ - commanded       │  │ - mode             │     │
│  │ - str_temp         │  │ - measured        │  └────────────────────┘     │
│  │ - phase_temp       │  │ - input_current_A │                              │
│  │ - iq_commanded     │  │ - input_voltage_V │                              │
│  │ - iq_measured      │  │ - commanded_iq_A  │                              │
│  │ - motor_temp       │  │ - measured_iq_A   │                              │
│  │ - spd_command      │  │ - is_on_ext_power │                              │
│  │ - spd_blended      │  │ - esc_st          │                              │
│  └────────────────────┘  └─────────┬──────────┘                              │
│                                    │                                         │
│                          ┌─────────▼──────────┐                              │
│                          │    Esc_state_st    │                              │
│                          │                    │                              │
│                          │ - is_armed         │                              │
│                          │ - is_ready         │                              │
│                          │ - is_enabled       │                              │
│                          │ - is_faulted       │                              │
│                          │ - halerts          │                              │
│                          └─────────┬──────────┘                              │
│                                    │                                         │
│                          ┌─────────▼──────────┐                              │
│                          │Esc_health_alerts_st│                              │
│                          │                    │                              │
│                          │ - faults_c1        │                              │
│                          │ - faults_c2        │                              │
│                          └────────────────────┘                              │
└──────────────────────────────────────┬───────────────────────────────────────┘
                                       │
                                       │ Serialization
                                       │
┌──────────────────────────────────────▼───────────────────────────────────────┐
│                           Serialized Data Streams                            │
│                                                                              │
│  ┌────────────────────┐  ┌────────────────────┐  ┌────────────────────┐     │
│  │  Motor Telemetry   │  │ Performance Status │  │Motor Diagnostics   │     │
│  │  (93 bits total)   │  │ (Mixed format)     │  │ (15+ bits)         │     │
│  └────────────────────┘  └────────────────────┘  └────────────────────┘     │
└──────────────────────────────────────────────────────────────────────────────┘
```

## Circular Buffer Implementation for High-Frequency Data

While not explicitly shown in the provided files, the telemetry system likely uses a circular buffer implementation to handle high-frequency data collection. This would allow the system to:

1. Continuously collect data at a high rate
2. Store a fixed window of recent data
3. Provide access to this data when requested without interrupting collection

The circular buffer would be particularly useful for:
- Capturing transient events
- Providing detailed data for post-fault analysis
- Supporting variable-rate telemetry requests

The implementation would likely involve:
- A fixed-size array to store data samples
- Head and tail pointers to manage buffer position
- Thread-safe access mechanisms to prevent data corruption
- Timestamp information to correlate samples

This circular buffer would serve as an intermediate storage between the high-frequency data collection and the lower-frequency telemetry serialization and transmission.