# Generated from:

- PackageSummaries/Amazon-PrimeAir/items/IPC/07_Motor_Controller_Architecture.md (2764 tokens)
- PackageSummaries/Amazon-PrimeAir/items/IPC/05_Shared_Memory_System.md (3254 tokens)
- PackageSummaries/Amazon-PrimeAir/items/IPC/04_IPC_Core_Components.md (3720 tokens)
- PackageSummaries/Amazon-PrimeAir/items/IPC/03_Hardware_Abstraction_Layer.md (3426 tokens)
- PackageSummaries/Amazon-PrimeAir/items/IPC/02_Communication_Interfaces.md (7273 tokens)
- PackageSummaries/Amazon-PrimeAir/items/IPC/06_Motor_Control_State_Machine.md (4178 tokens)
- PackageSummaries/Amazon-PrimeAir/items/IPC/05_Field_Oriented_Control.md (7141 tokens)
- PackageSummaries/Amazon-PrimeAir/items/IPC/01_Motor_Position_Estimation.md (4923 tokens)
- PackageSummaries/Amazon-PrimeAir/items/IPC/04_Protection_Systems.md (6243 tokens)
- PackageSummaries/Amazon-PrimeAir/items/IPC/03_Command_Input_Management.md (4750 tokens)
- PackageSummaries/Amazon-PrimeAir/items/IPC/03_Telemetry_and_Diagnostics.md (6048 tokens)
- PackageSummaries/Amazon-PrimeAir/items/IPC/03_Bootloader_System.md (5549 tokens)
- PackageSummaries/Amazon-PrimeAir/items/IPC/02_Cryptographic_System.md (4387 tokens)
- PackageSummaries/Amazon-PrimeAir/items/IPC/02_System_Identification.md (2855 tokens)
- PackageSummaries/Amazon-PrimeAir/items/IPC/02_Software_In_The_Loop_Simulation.md (8504 tokens)
- PackageSummaries/Amazon-PrimeAir/items/IPC/02_Cyphal_Message_Definitions.md (5377 tokens)
- PackageSummaries/Amazon-PrimeAir/items/IPC/01_Motor_Controller_System_Overview.md (2828 tokens)
- PackageSummaries/Amazon-PrimeAir/items/IPC/01_Security_and_Communication_Overview.md (3237 tokens)
- PackageSummaries/Amazon-PrimeAir/items/IPC/01_Testing_and_Simulation_Overview.md (5045 tokens)

---

# Amazon Prime Air Motor Controller System Overview

This document provides a comprehensive overview of the Amazon Prime Air motor controller system, serving as an entry point for understanding the software architecture, components, and functionality.

## System Architecture

The motor controller implements a sophisticated **dual-core architecture** using a TMS320F28335 DSP with two CPUs (CPU1 and CPU2) that work in tandem with a third ARM Cortex-M core (CM) to manage different aspects of motor control:

### Core Responsibilities

- **CPU1 (System Management Core)**
  - Handles communication interfaces (CAN, CAN-FD, SCI, SPI)
  - Manages system status and maintenance modes
  - Processes input commands with redundancy and failover capabilities
  - Implements the Finite State Machine (FSM) that governs overall system operation
  - Collects and transmits telemetry data

- **CPU2 (Real-time Control Core)**
  - Executes high-frequency motor control algorithms (5kHz)
  - Implements Field-Oriented Control (FOC) without encoder
  - Manages PWM generation for motor phases
  - Processes sensor data (SIN/COS position sensors)
  - Handles ADC sampling for current and voltage measurements

- **CM (Communication Manager Core)**
  - Handles cryptographic operations
  - Manages network communication
  - Provides secure boot capabilities
  - Supports key generation and management

This separation of responsibilities allows each core to focus on its specialized tasks, with CPU1 handling system-level operations, CPU2 dedicated to time-critical motor control functions, and CM managing security and communication.

## Inter-Processor Communication (IPC)

The cores communicate through a structured shared memory system with clear ownership boundaries:

### Memory Ownership Model
- **CPU1-owned memory (C1_owned)**: CPU1 has read/write access, CPU2 has read-only access
- **CPU2-owned memory (C2_owned)**: CPU2 has read/write access, CPU1 has read-only access
- **CPU1-CM shared memory**: Located at memory address 0x20080000
- **CM-CPU1 shared memory**: Located at memory address 0x00038000

### Variable Management System
The shared memory implements a sophisticated variable management system with three types of variables:
- **Bvar (Boolean Variables)**: Status flags, fault indicators, and system states
- **Uvar (Unsigned Integer Variables)**: Configuration parameters and state identifiers
- **Rvar (Real Variables)**: Measurements and control parameters

### Cross-Core FIFO Communication
A cross-core FIFO buffer mechanism enables efficient transfer of diagnostic data:
- CPU2 writes diagnostic data to `ffwr_diag`
- CPU1 reads diagnostic data from `ffrd_diag`
- This allows CPU2 to continuously record high-frequency diagnostic data (5kHz)

## Motor Control State Machine

The Finite State Machine (FSM) manages the operational states of the system:

### Primary State Hierarchy
- **init**: Initial power-up state
- **disarmed**: System initialized but not ready for operation
- **test**: Performing pre-operation tests
- **inactive**: System armed but not actively controlling motor
- **active**: System actively controlling motor
- **faulted**: System encountered critical fault

### Test Sequence State Machine
Within the `test` state, a nested state machine performs:
- **Ground Fault Detection**: Tests for insulation failures
- **Sin/Cos Alignment**: Calibrates position sensors with rotor
- **Sin/Cos Open Loop**: Validates sensor operation

### Motor Controller Interface States
The FSM manages the motor controller interface (MCI) state:
- **off**: PWM disabled
- **calibration**: Initial calibration mode
- **alignment**: Motor alignment mode
- **zero_current**: Zero current mode (windmill)
- **rpm**: Speed control mode

## Field-Oriented Control (FOC)

The Field-Oriented Control (FOC) algorithm provides precise control of the Permanent Magnet Synchronous Motor:

### Control Transformations
- **Clarke Transformation**: Converts three-phase currents to two-phase stationary frame
- **Park Transformation**: Converts stationary frame to rotating reference frame
- **Inverse Park/Clarke**: Converts control outputs back to three-phase voltages

### Position and Speed Estimation
The system implements a sophisticated position estimation strategy:
- **Sliding Mode Observer**: Estimates back-EMF
- **Position Sensors**: SIN/COS sensors for direct position measurement
- **Observer Mixing**: Combines low and high-speed estimates based on operating range

### Current Control
- Implements d-q axis current controllers with anti-windup
- Applies Maximum Torque Per Ampere (MTPA) optimization
- Implements Space Vector PWM with third harmonic injection

## Protection Systems

The motor controller implements comprehensive protection systems:

### Fault Detection System
Monitors various parameters to detect abnormal conditions:
- AC/DC Overcurrent protection with multiple thresholds
- Overvoltage and undervoltage protection
- RMS current imbalance detection
- Position sensor error detection
- Ground fault detection

### Ground Fault Detection
Implements a dedicated state machine for detecting ground faults during startup:
- Takes measurements with and without grounding switch closed
- Compares measurements to detect insulation failures
- Coordinates testing between multiple ESCs

### Stall Detection and Management
Implements stall detection and recovery logic:
- Detects when motor is unable to rotate despite being commanded
- Implements progressive restart strategy
- Sets terminal fault after maximum restart attempts

### Temperature Monitoring
Provides temperature monitoring and protection:
- Monitors board, phase, and motor temperatures
- Implements overtemperature detection with configurable thresholds
- Controls cooling fan based on temperature

## Command Input Management

The command input management system provides robust handling of control commands:

### Source Selection State Machine
Manages primary and recovery input sources:
- **st_nominal**: Primary source is active and present
- **st_loss_primary**: Primary source lost, deciding next action
- **st_wait_for_recovery**: Waiting for valid command from recovery
- **st_recovery**: Recovery source is providing commands
- **st_loss_comm**: Both sources lost, system in failsafe mode

### Redundancy and Failover
Implements robust failover mechanism:
- When primary source is lost, system can transition to recovery source
- During failover, preserves last valid command from primary
- Implements timeout management for source presence detection

## Communication Protocols

The system implements multiple communication protocols to ensure reliable and secure data exchange:

### CAN Communication
- **CAN-B**: Standard CAN communication
- **CAN-FD-A**: Higher bandwidth CAN-FD communication
- Producer-consumer architecture with priority-based message processing

### Cyphal Protocol
The system uses the Cyphal protocol for standardized communication:
- **Command Messages**: `MotorRpmCommand`, `RecoveryMotorRpmCommand`
- **Telemetry Messages**: `MotorPerformance`, `EscState`, `EscHealthAlerts`
- Bit-level optimization for efficient communication

## Security Architecture

The system implements a comprehensive security architecture:

### Secure Bootloader
- Validates application integrity and authenticity
- Implements secure firmware update capabilities
- Coordinates secure boot process across all cores

### Cryptographic System
- ECDSA key management for authentication
- Challenge-response authentication
- Secure boot authentication

### System Identification
- Hardware position detection through GPIO pins
- Unique 64-bit identifier (UID64) for each node
- Position-based node ID assignment

## Testing and Simulation

The system includes a comprehensive Software-in-the-Loop (SIL) simulation framework:

### SIL Framework Components
- **ESC Firmware Simulation**: Executes the actual ESC firmware code
- **Motor Physics Simulation**: Simulates the physical behavior of BLDC motors
- **Ground Truth State**: Provides reference information about the simulated system

### Closed-Loop Testing
- Simulates the complete feedback loop between ESC and motor
- Enables testing of control algorithms, fault detection, and performance
- Supports fault injection and environmental condition testing

## Further Information

For more detailed information about specific components, please refer to the following documents:

- [Motor Controller Architecture](07_Motor_Controller_Architecture.md): Detailed overview of the dual-core architecture
- [Shared Memory System](05_Shared_Memory_System.md): In-depth explanation of the shared memory architecture
- [IPC Core Components](04_IPC_Core_Components.md): Details on inter-processor communication mechanisms
- [Hardware Abstraction Layer](03_Hardware_Abstraction_Layer.md): Information about hardware abstraction and configuration
- [Motor Control State Machine](06_Motor_Control_State_Machine.md): Comprehensive explanation of the state machine
- [Field-Oriented Control](05_Field_Oriented_Control.md): Details on the motor control algorithm
- [Protection Systems](04_Protection_Systems.md): Information about fault detection and protection mechanisms
- [Command Input Management](03_Command_Input_Management.md): Details on command processing and redundancy
- [Telemetry and Diagnostics](03_Telemetry_and_Diagnostics.md): Information about status and performance reporting
- [Bootloader System](03_Bootloader_System.md): Details on the secure boot process
- [Cryptographic System](02_Cryptographic_System.md): Information about security features
- [System Identification](02_System_Identification.md): Details on node identification mechanisms
- [Communication Interfaces](02_Communication_Interfaces.md): Information about communication protocols
- [Cyphal Message Definitions](02_Cyphal_Message_Definitions.md): Details on message formats
- [Software-in-the-Loop Simulation](02_Software_In_The_Loop_Simulation.md): Information about testing and simulation

## System Integration

The motor controller's architecture represents a sophisticated design that effectively separates system management from real-time control functions while maintaining robust communication between components. The dual-core approach allows for optimal performance in both domains, with CPU1 handling system-level operations and CPU2 dedicated to time-critical motor control.

The shared memory system provides the foundation for inter-core communication, enabling efficient data exchange without compromising the real-time performance of the control algorithms. The hardware abstraction layer ensures consistent interface to hardware components regardless of the specific hardware variant.

The state machine governs the overall system operation, ensuring proper initialization, testing, and fault handling. The Field-Oriented Control algorithm provides precise motor control with sophisticated position estimation and current control strategies. The protection systems ensure safe operation by monitoring various parameters and implementing appropriate responses to abnormal conditions.

Together, these components form a cohesive architecture that delivers high-performance motor control with robust safety features and comprehensive monitoring capabilities.