# Generated from:

- items/sw_vbootloader_ipc/code/sw_vbootloader_ipc/code/source/Bootloader_pa.cpp (1165 tokens)
- items/sw_vbootloader_ipc/code/sw_vbootloader_ipc/code/source/bootloader_2838x_ipc.cmd (1327 tokens)
- items/sw_vbootloader_ipc/code/sw_vbootloader_ipc/code/source/Bootloader_ipc.cpp (192 tokens)
- items/sw_vbootloader_ipc/code/sw_vbootloader_ipc/code/source/Sysuid_cpu1_ipc.cpp (1401 tokens)
- items/sw_vbootloader_ipc/code/sw_vbootloader_ipc/code/source/Halsuite_2838x_ipc.cpp (1102 tokens)
- items/sw_vbootloader_ipc/code/sw_vbootloader_ipc/code/source/main.cpp (836 tokens)
- items/sw_vbootloader_ipc/code/sw_vbootloader_ipc_cm/code/include_ipc_cm/Bldr_defs.h (108 tokens)
- items/sw_vbootloader_ipc/code/sw_vbootloader_ipc_cm/code/include_ipc_cm/Msg_crypto_hnd.h (491 tokens)
- items/sw_vbootloader_ipc/code/sw_vbootloader_ipc_cm/code/source/Msg_crypto_hnd.cpp (214 tokens)
- items/sw_vbootloader_ipc/code/sw_vbootloader_ipc_cm/code/source/main_2838x_ipc_cm.cpp (1597 tokens)

## With context from:

- PackageSummaries/Amazon-PrimeAir/items/IPC/04_IPC_Core_Components.md (3720 tokens)

---

# Multi-Core Bootloader Architecture for TMS320F2838x Platform

## 1. Memory Layout and Core Partitioning

The TMS320F2838x platform bootloader implements a multi-core architecture spanning three processor cores: CPU1 (primary C28x core), CPU2 (secondary C28x core), and CM (ARM Cortex-M core). Each core has dedicated memory regions for bootloader and application code.

### 1.1 Memory Map

| Core | Bootloader Start | Bootloader Size | Application Start | Application Size |
|------|------------------|-----------------|-------------------|------------------|
| CPU1 | 0x80000 (flash_start) | 0x10000 (64KB) | 0x90000 (user_start) | 0x30000 (192KB) |
| CPU2 | 0x80000 (flash_start) | N/A (managed by CPU1) | 0x80000 (flash_start) | 0x40000 (256KB) |
| CM   | 0x200000 (cm_bldr_start) | 0x20000 (128KB) | 0x220000 (cm_user_start) | 0x30000 (192KB) |

### 1.2 RAM Allocation

The bootloader uses several RAM regions for execution:

```
// MM - Data
#define MM_DAT_START MM_START (0x140)
#define MM_DAT_SIZE  MM_SIZE (0x6C0)

// IRAM
#define LRAM_START 0x008000
#define LRAM_SIZE  0x005000
#define SRAM_START 0x00D000
#define SRAM_SIZE  0x010000

#define RAMFUNCS_START  (SRAM_START + SRAM_SIZE - RAMFUNCS_SZ)
#define RAMFUNCS_SZ     0x5700
```

### 1.3 Shared Memory Regions

The bootloader uses dedicated shared memory regions for inter-processor communication:

```
// CPU1-CM shared memory
#define CPUTOCMRAM  : origin = 0x039000, length = 0x000800  // CPU1 to CM
#define CMTOCPURAM  : origin = 0x038000, length = 0x000800  // CM to CPU1
```

## 2. Inter-Processor Communication Mechanism

### 2.1 Shared Memory Structures

The bootloader leverages the IPC system's shared memory structures for communication between cores:

#### 2.1.1 CPU1-CM Shared Memory

The `CPU1_CM_shared` structure (CPU1-owned, CM-readable) contains:
- System address and unique identifier
- Port configurations for STANAG and Cyphal protocols
- Heartbeat LED configuration
- Command flags for CM core

```cpp
// In main.cpp
CPU1_CM_shared& shared_c1 = get_c1_writer();
shared_c1.uid      = Bsp::get_uid();
shared_c1.sys_addr = shared_c1.uid.phy;
shared_c1.port_stg = Routing_table_data<0,0>::def_stg_port;
shared_c1.port_cy  = Routing_table_data<0,0>::def_cyphal_port;
shared_c1.heartbeat_led_id = Dsp28335_ent::gpio_all;
```

#### 2.1.2 CM-CPU1 Shared Memory

The `CM_CPU1_shared` structure (CM-owned, CPU1-readable) contains:
- CM bootloader status information
- Application status flags

### 2.2 IPC Flag Synchronization

The bootloader uses IPC flags for synchronization between cores:

```cpp
// CPU1 signals CM with commands
Ipc::set_cm_command(Bsp::bldr_force_bldr_cmd);
CM_helpers::cm_boot();
Ipc::set_cm_command(0); // Clear command

// CM signals CPU1 that it's ready
IPC_setFlagLtoR(IPC_CM_L_CPU1_R, IPC_FLAG0);

// CM waits for CPU1 to finish initialization
IPC_waitForFlag(IPC_CM_L_CPU1_R, IPC_FLAG1);
```

### 2.3 Command Processing

The CM core processes commands from CPU1 through the shared memory interface:

```cpp
// In CM bootloader
const uint32_t cmd = *(reinterpret_cast<volatile uint32_t*>(IPC_CMTOCPU1_BASE) + cmd_offset);
if(cmd != Bsp::bldr_force_bldr_cmd) {
    // Launch application if no bootloader command
    typedef void(*User_app)();
    const Uint32 addr = cm_user_start+1U; // Add 1 for ARM thumb mode
    reinterpret_cast<User_app>(addr)();
}
```

## 3. Node Identification and Configuration

### 3.1 Hardware Identification

The system uses GPIO pins to identify the node position and board type:

```cpp
// Position identification pins
static const Base::Tnarray<GPIOid, n_pos_ids> pos_ids = {
    {
        gpio_016,
        gpio_017,
        gpio_018
    }
};

// Board identification pins
static const Base::Tnarray<GPIOid, n_brd_ids> brd_ids = {
    {
        gpio_011,
        gpio_013,
        gpio_014,
        gpio_015
    }
};
```

### 3.2 Node ID Assignment

Node IDs are assigned based on the physical position of the board:

```cpp
Uint16 get_node_id() {
    // Check if this is an IPC board
    if(get_value_from_gpio(brd_ids.to_mblock()) == brd_id_cx3_dv_blk20) {
        is_ipc_board = true;
    }

    Uint16 node_id = Ipc_ids::node_id_rr_a;
    const Ipc_ids::Pos pos_val = static_cast<Ipc_ids::Pos>(get_value_from_gpio(pos_ids.to_mblock()));
    
    if(is_ipc_board) {
        switch(pos_val) {
            case Ipc_ids::rr: node_id = Ipc_ids::node_id_rr_a; break;
            case Ipc_ids::cr: node_id = Ipc_ids::node_id_rr_a + Ku16::u1; break;
            case Ipc_ids::fr: node_id = Ipc_ids::node_id_rr_a + Ku16::u2; break;
            case Ipc_ids::fl: node_id = Ipc_ids::node_id_rr_a + Ku16::u3; break;
            case Ipc_ids::cl: node_id = Ipc_ids::node_id_rr_a + Ku16::u4; break;
            case Ipc_ids::rl: node_id = Ipc_ids::node_id_rr_a + Ku16::u5; break;
            default: Bsp::warning(); break;
        }
    }
    return node_id;
}
```

### 3.3 System UID Generation

The system generates a unique identifier (UID) for each node:

```cpp
Uid64 get_uid_aux() {
    // Allow time for GPIO stabilization
    Dsp28335_ent::Delay::ms(150);
    
    Uid64 otp_uid = { 0 };
    otp_uid.app = Bsp::sapp_mc_ipc;
    otp_uid.hwv = MCxx::v_mc_ipc;
    otp_uid.phy = get_node_id();
    
    return otp_uid;
}
```

## 4. CAN Communication Configuration

### 4.1 CAN Interface Setup

The bootloader configures multiple CAN interfaces for communication:

```cpp
void Bootloader::config_can(bool as_master) {
    // Configure GPIO pins for CAN interfaces
    Dsp28335_ent::GPIOdev::apply_can<mux_canfd_a, Dsp28335_ent::gpio_070, Dsp28335_ent::gpio_074>();
    GPIOioctl::apply_output(get_gpio_taba_en());
    GPIOioctl::apply_output(get_gpio_taba_nstb());
    GPIOioctl::apply_output(get_gpio_tabb_en());
    GPIOioctl::apply_output(get_gpio_tabb_nstb());
    
    // Default CAN configuration
    Midlevel::Default_cfg::set_default_can_500(cfg_can, false, as_master);
    
    // Configure CAN filters
    CANin_p::Config can_in_cfg;
    set_can_in_cfg(can_in_cfg);
    
    // Apply configuration to appropriate CAN interfaces
    if(Bsp::is_astro(static_cast<Bsp::Sysapp>(Bsp::get_uid().app))) {
        // ASTRO configuration
        stab_b.enable_transceiver(hal.cana, Secure_CAN::cfg_open_commands);
        hal.cana.config(cancfg_stab);
        hal.canb.config(cfg_can);
    } else {
        // IPC configuration
        stab_b.enable_transceiver(hal.canb, Secure_CAN::cfg_open_commands);
        hal.canb.config(cancfg_stab);
    }
    
    // Configure CAN-FD interface
    stab_a.enable_transceiver(hal.can_fd, Secure_CAN::cfg_open_commands);
    Midlevel::Default_cfg::set_default_can_fd(cfg, CAN_FD_cfg::bd_500K, CAN_FD_cfg::bd_2M, false, as_master);
    cfg.rx_cfg[0].flt = can_in_cfg.filter.can_filter;
    cfg.rx_cfg[0].sz = Midlevel::Default_cfg::def_nb_rx_mboxes;
    hal.can_fd.config(cfg);
}
```

### 4.2 CAN ID Configuration

The bootloader configures CAN IDs based on the node ID:

```cpp
void Bootloader::set_can_in_cfg(CANin_p::Config& in_cfg) {
    static const Uint32 base_rx_id = 0x740;
    const Uint32 id = Bsp::get_uid().phy;
    in_cfg.port = static_cast<CANport::Port>(CANport::can_all);
    in_cfg.filter.can_filter.id.extended = false;
    in_cfg.filter.can_filter.id.id = base_rx_id + id;
    in_cfg.filter.can_filter.msk = CANid::id_msk_std;
}

void Bootloader::set_can_cfg(CANin_p::Config& in_cfg, CANout_c::Config& out_cfg, SerialCAN::Config& sc_cfg) {
    static const Uint32 base_tx_id = 0x700;
    const Uint32 id = Bsp::get_uid().phy;
    
    set_can_in_cfg(in_cfg);
    out_cfg.port = in_cfg.port;
    sc_cfg.timeout = SerialCAN_consts::def_115K_timeout;
    sc_cfg.id.extended = false;
    sc_cfg.id.id = base_tx_id + id;
}
```

## 5. CPU1 Bootloader Initialization and Execution Flow

### 5.1 CPU1 Bootloader Initialization

```cpp
int main() {
    // Define memory regions for bootloader and applications
    static const Uint32 flash_start = 0x80000UL;
    static const Uint32 flash_size  = 0x40000UL;
    static const Uint32 bldr_start  = flash_start;
    static const Uint32 bldr_size   = 0x10000UL;
    static const Uint32 user_start  = bldr_start+bldr_size;
    static const Uint32 user_size   = 0x40000UL-bldr_size;
    
    // Configure bootloader parameters
    const Bldr_mgr::Params par = {
        { bldr_start, words16_to_bytes_c<bldr_size>::value },
        {
            3,
            {
                {
                    { user_start, words16_to_bytes_c<user_size>::value },
                    { flash_start, words16_to_bytes_c<flash_size>::value},
                    { cm_user_start, cm_user_size }
                }
            }
        },
        { (1U << Vbootloader::Bldr_mgr::c1_core_index) | (1U << Vbootloader::Bldr_mgr::c2_core_index) }
    };
    
    // Initialize shared memory
    CPU1_CM_shared& shared_c1 = get_c1_writer();
    shared_c1.uid = Bsp::get_uid();
    shared_c1.sys_addr = shared_c1.uid.phy;
    shared_c1.port_stg = Routing_table_data<0,0>::def_stg_port;
    shared_c1.port_cy = Routing_table_data<0,0>::def_cyphal_port;
    shared_c1.heartbeat_led_id = Dsp28335_ent::gpio_all;
    
    // Initialize CM core
    Ipc::turn_off_cm();
    Ipc::set_cm_command(Bsp::bldr_force_bldr_cmd);
    Dsp28335_ent::Delay::ms(1);
    CM_helpers::cm_boot();
    Dsp28335_ent::Delay::ms(1);
    Ipc::set_cm_command(0);
    
    // Initialize address handler and bootloader
    Address_handler addr_handler(Bsp::sysaddr(), par.cores_managed, true);
    Bootloader_dual& bldr = Bootloader_dual::build(par, addr_handler);
    
    // Signal CM that CPU1 initialization is complete
    CM_helpers::cm_init_end();
    
    // Run bootloader
    bldr.run();
}
```

### 5.2 CPU1 Bootloader Memory Configuration

The CPU1 bootloader uses a custom linker command file (`bootloader_2838x_ipc.cmd`) that defines:

1. Memory regions for program and data
2. Special RAM sections for critical functions
3. Shared memory regions for inter-processor communication

```
MEMORY
{
PAGE 0:    /* Program Memory */
   RAMFUNCS    : origin = RAMFUNCS_START, length = RAMFUNCS_SZ

PAGE 1 :   /* Data Memory */
   BOOT_RSVD   : origin = 0x000000,        length = BOOT_RSVD_SZ
   RAMM_DAT    : origin = MM_DAT_START,    length = MM_DAT_SIZE
   RAML        : origin = LRAM_DATA_START, length = LRAM_DATA_SIZE
   RAMS        : origin = SRAM_DATA_START, length = SRAM_DATA_SIZE

   CPUTOCMRAM  : origin = 0x039000, length = 0x000800
   CMTOCPURAM  : origin = 0x038000, length = 0x000800
}
```

### 5.3 Critical Functions in RAM

The bootloader copies critical functions to RAM for faster execution:

```
.TI.ramfunc :
{
   -l F2838x_C28x_FlashAPI.lib
   -l crypto_c28.lib<sha256*.obj>
   -l DSP2837x_ent.lib<Flash_wr_2837x.obj>(.text)
   -l DSP2837x_ent.lib<Flash_wr_2837x.obj> (.bss:*sector_addresses*)
   -l DSP2837x_ent.lib<Flash_wr_2837x.obj>(.const)
   -l DSP2837x_ent.lib<Flash_2837x.obj>(.text:*init*)
   -l DSP2838x_ent.lib<Ipc_2838x.obj>(.text:*cpu2_get_ipc_param*)
   -l DSP2838x_ent.lib<Ipc_2838x.obj>(.text:*cpu2_set_ipc_result*)
   -l DSP2837x_ent.lib<Watchdog.obj> (.text:*setup_disabled*)
   -l DSP2838x_ent.lib<Sys_regs_2838x.obj>(.text)
   -l base.lib<CRC32.obj>(.const:*CRC32_table*)
   -l vbootloader.lib<Bldr_mgr.obj>(.data:*Bldr_mgr*data*)
   -l vbootloader.lib<Bldr_mgr_2838x_28377.obj>(.text:*func*)
   -l first.lib<Mutex.obj>(.text:*)
   -l DSP28x.lib<Warning.obj>(.text:*warning_assrt*)
   -l DSP28x.lib<Fsector.obj> (.text:*get_sectors*)
   -l DSP28x.lib<Fsector.obj> (.text:_*Maverick*Find*sorted*)
   -l vbootloader.lib<Bootloader_ecdsa.obj> (.text:*compute_bldr_hash*)
   -l vbootloader.lib<Bootloader.obj> (.text:*get_header*)
   -l rts2800_fpu64_eabi.lib<epilog28.asm.obj> (.text)
   Sysuid_cpu1*.obj(.text:*get_uid*)
} load=FLASH_PRG, run=RAMFUNCS, table(BINIT)
```

## 6. CM Bootloader Initialization and Execution Flow

### 6.1 CM Bootloader Initialization

```cpp
int main(void) {
    // Define memory regions for bootloader and application
    static Bitmask<Uint8> cores_managed;
    cores_managed.value = Ku8::u0;
    cores_managed.set(Vbootloader::Bldr_mgr::cm_core_index);
    
    static Vbootloader::Bldr_mgr::Params par = {
        { cm_bldr_start, cm_bldr_size },
        {
            3,
            {
                {
                    { 0, 0 },                       // Dummy C1 User Block
                    { 0, 0 },                       // Dummy C2 User Block
                    { cm_user_start, cm_user_size } // CM User Block
                }
            }
        },
        cores_managed
    };
    
    // Initialize CM core
    CM_init();
    
    // Initialize memory manager
    static Allocator alloc(memmgr_buf, mem_sz);
    Memmgr::get_instance().add_allocator(Memmgr::internal, alloc);
    Memmgr::get_instance().add_allocator(Memmgr::external, alloc);
    
    // Initialize shared memory
    CM_CPU1_shared& cm_shared = get_cm_writer();
    
    // Signal CPU1 that CM is ready
    IPC_setFlagLtoR(IPC_CM_L_CPU1_R, IPC_FLAG0);
    
    // Wait for CPU1 to finish initialization
    IPC_waitForFlag(IPC_CM_L_CPU1_R, IPC_FLAG1);
    
    // Enable interrupts
    Interrupt_enableInProcessor();
    
    // Get configuration from CPU1
    const CPU1_CM_shared& shared(get_c1_reader());
    heartbeat_led_id = shared.heartbeat_led_id;
    
    // Initialize bootloader manager
    static const Uint16 buffer_sz = 4096U;
    static Uint8 data_buffer[buffer_sz];
    U8pkmblock buffer(data_buffer, buffer_sz);
    
    Vbootloader::Address_handler addr_handler(Bsp::sysaddr(), cores_managed, false);
    Vbootloader::Bld_mgr_2838xCM& bld_mgr = *alloc.allocate_new<Vbootloader::Bld_mgr_2838xCM>(buffer, par, addr_handler);
    
    // Configure routing
    Routing_table_entry e;
    e.dst_addr = Address0::build(Address0::broadcast);
    e.dst_mask = Address0::build(0);
    e.ports.set(0);
    bld_mgr.get_routing_table().get_routing_table_data().add_route(0, e);
    
    // Add communication port
    bld_mgr.add_c1_port();
    
    // Configure SysTick for heartbeat
    SYSTICK_setPeriod(systickPeriodValue);
    SYSTICK_enableCounter();
    SYSTICK_registerInterruptHandler(SysTickIntHandler);
    SYSTICK_enableInterrupt();
    
    // Check application status
    const Bldr_mgr::App_status sts = bld_mgr.check_app();
    cm_shared.cm_status = sts;
    
    // Main loop
    while(true) {
        bld_mgr.step();
    }
}
```

### 6.2 CM Bootloader Early Initialization

The CM bootloader implements an early initialization function that checks for bootloader commands:

```cpp
extern "C" int _system_pre_init(void) {
    static const uint32_t cmd_offset = 8U;
    const uint32_t cmd = *(reinterpret_cast<volatile uint32_t*>(IPC_CMTOCPU1_BASE) + cmd_offset);
    if(cmd != Bsp::bldr_force_bldr_cmd) {
        typedef void(*User_app)();
        const Uint32 addr = cm_user_start+1U; // Add 1 for ARM thumb mode
        reinterpret_cast<User_app>(addr)(); // Call user app, never returns
    }
    return 1;
}
```

### 6.3 CM Core Initialization

The CM bootloader initializes the CM core hardware:

```cpp
void CM_init(void) {
    // Disable watchdog
    SysCtl_disableWatchdog();
    
    // Copy critical code to RAM
    memcpy(&RamfuncsRunStart, &RamfuncsLoadStart, (size_t)&RamfuncsLoadSize);
    memcpy(&constRunStart, &constLoadStart, (size_t)&constLoadSize);
    
    // Initialize flash with appropriate wait states
    Flash_initModule(FLASH0CTRL_BASE, FLASH0ECC_BASE, DEVICE_FLASH_WAITSTATES);
    
    // Set vector table address
    Interrupt_setVectorTableOffset((uint32_t)vectorTableFlash);
}
```

## 7. Application Launch Process

### 7.1 CPU1 Application Launch

The CPU1 bootloader checks the application header and launches the application if valid:

```cpp
// In Bootloader_dual::run()
// Check application header
if(App_blr_hdr_inst<app_crc, app_size, app_id, app_ver>::instance.bld_hdr_mark == App_blr_hdr::hdr_bldr_mark_v) {
    // Launch application
    typedef void(*User_app)();
    reinterpret_cast<User_app>(user_start)();
}
```

### 7.2 CM Application Launch

The CM bootloader checks for bootloader commands and launches the application if no command is present:

```cpp
extern "C" int _system_pre_init(void) {
    static const uint32_t cmd_offset = 8U;
    const uint32_t cmd = *(reinterpret_cast<volatile uint32_t*>(IPC_CMTOCPU1_BASE) + cmd_offset);
    if(cmd != Bsp::bldr_force_bldr_cmd) {
        typedef void(*User_app)();
        const Uint32 addr = cm_user_start+1U; // Add 1 for ARM thumb mode
        reinterpret_cast<User_app>(addr)(); // Call user app, never returns
    }
    return 1;
}
```

## 8. Error Handling and Recovery

### 8.1 Application Validation

The bootloader validates applications before launching them:

```cpp
// In Bld_mgr::check_app()
// Check application header
if(header.bld_hdr_mark != App_blr_hdr::hdr_bldr_mark_v) {
    return app_invalid;
}

// Check application CRC
if(compute_app_crc() != header.app_crc) {
    return app_corrupted;
}

return app_valid;
```

### 8.2 Heartbeat Monitoring

The CM bootloader implements a heartbeat mechanism for monitoring system health:

```cpp
extern "C" void SysTickIntHandler(void) {
    static uint32_t cnt = 0;
    if(++cnt >= 1000UL) {
        cnt = 0;
        toggle_led(heartbeat_led_id);
    }
}
```

### 8.3 Warning System

The bootloader implements a warning system for non-critical errors:

```cpp
// In various error conditions
Bsp::warning();
```

## 9. Cryptographic Operations

### 9.1 Cryptographic Message Handlers

The CM bootloader implements handlers for cryptographic operations:

```cpp
class Msg_crypto_hnd {
public:
    inline Stanag::Stanag_msg& get_key_gen_hdn() {
        return key_gen_hdn;
    }

    inline Stanag::Stanag_msg& get_sign_hdn() {
        return sign_hdn;
    }

private:
    class Key_gen : public Stanag::Stanag_msg {
        virtual Base::Msg_data::Ack_type on_rx(Rx_params& rx_p);
        virtual bool on_tx(Tx_params& tx_p);
    };

    class Sign : public Stanag::Stanag_msg {
        virtual Base::Msg_data::Ack_type on_rx(Rx_params& rx_p);
        virtual bool on_tx(Tx_params& tx_p);
    };

    Key_gen key_gen_hdn;
    Sign sign_hdn;
};
```

### 9.2 Key Generation

The CM bootloader can generate cryptographic keys (implementation placeholder):

```cpp
Msg_data::Ack_type Msg_crypto_hnd::Key_gen::on_rx(Rx_params& rx_p) {
    Base::Msg_data::Ack_type res = Msg_data::rejected;
    // TODO Generate key and store it internally.
    return res;
}

bool Msg_crypto_hnd::Key_gen::on_tx(Tx_params& tx_p) {
    bool res = false;
    // TODO Fill Generated key in response.
    return res;
}
```

### 9.3 Signature Generation

The CM bootloader can generate cryptographic signatures (implementation placeholder):

```cpp
Msg_data::Ack_type Msg_crypto_hnd::Sign::on_rx(Rx_params& rx_p) {
    Base::Msg_data::Ack_type res = Msg_data::rejected;
    // TODO read data to sign and store signed value internally.
    return res;
}

bool Msg_crypto_hnd::Sign::on_tx(Tx_params& tx_p) {
    bool res = false;
    // TODO Fill Generated signature in response.
    return res;
}
```

## 10. Integration with IPC System

### 10.1 Bootloader IPC Commands

The bootloader uses specific IPC commands for inter-processor communication:

```cpp
// CPU1 sends commands to CM
Ipc::set_cm_command(Bsp::bldr_force_bldr_cmd);
CM_helpers::cm_boot();
Ipc::set_cm_command(0); // Clear command

// CM checks for commands
const uint32_t cmd = *(reinterpret_cast<volatile uint32_t*>(IPC_CMTOCPU1_BASE) + cmd_offset);
if(cmd != Bsp::bldr_force_bldr_cmd) {
    // Launch application if no bootloader command
}
```

### 10.2 Bootloader Status Reporting

The CM bootloader reports its status to CPU1:

```cpp
// Check application status
const Bldr_mgr::App_status sts = bld_mgr.check_app();
cm_shared.cm_status = sts;
```

### 10.3 Routing Configuration

The CM bootloader configures routing for inter-processor communication:

```cpp
// Configure routing
Routing_table_entry e;
e.dst_addr = Address0::build(Address0::broadcast);
e.dst_mask = Address0::build(0);
e.ports.set(0);
bld_mgr.get_routing_table().get_routing_table_data().add_route(0, e);

// Add communication port
bld_mgr.add_c1_port();
```

## Referenced Context Files

The following context file provided valuable insights for understanding the IPC system:

- `04_IPC_Core_Components.md`: Provided detailed information about the Inter-Processor Communication (IPC) system architecture, shared memory structures, synchronization mechanisms, and communication protocols between CPU1, CPU2, and CM cores.

The multi-core bootloader architecture for the TMS320F2838x platform implements a sophisticated system for coordinating the boot process across three processor cores. It leverages shared memory, IPC flags, and hardware synchronization to ensure reliable initialization and application launching. The bootloader also includes features for application validation, cryptographic operations, and error handling to maintain system integrity.