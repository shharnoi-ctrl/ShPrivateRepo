# Generated from:

- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/include/pa/cm/Cy_key_provisioning.h (1002 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/include/pa/cm/Cm_handler.h (373 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/include_SIL/Compute_hash.h (101 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/source/Cm_handler_amz.cpp (454 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/source/Cy_key_provisioning_amz.cpp (1182 tokens)
- items/sw_IPC/code/MC_ipc_cm/code/include/Default_keys.h (159 tokens)
- items/sw_IPC/code/MC_ipc_cm/code/source/Default_keys.cpp (167 tokens)

## With context from:

- PackageSummaries/Amazon-PrimeAir/items/IPC/04_IPC_Core_Components.md (3720 tokens)
- PackageSummaries/Amazon-PrimeAir/items/IPC/03_Bootloader_System.md (5549 tokens)

---

# Cryptographic System for Secure Boot and Authentication

## 1. Key Provisioning Architecture

### 1.1 Key Provisioning Class Structure

The `Cy_key_provisioning` class implements a comprehensive key management system that handles ECDSA key pair generation, storage, and retrieval:

```cpp
class Cy_key_provisioning : public CyphalStanag_rx_hnd, public CyphalStanag_tx_hnd {
public:
    Cy_key_provisioning(const volatile Base::Prv_key::Type& private_key0,
                        const volatile Base::Pub_key::Type& public_key0,
                        const volatile Uint16& ready_flag0,
                        Uint64 node_id0);
    void init(MCxx::Suite_mc& smc);
    void cget(Base::U8ostream& os) const;
    virtual void notify(const Base::Msg_data& res_data);
    virtual Cyphal_stg_fields get_cyphal_flags();
    virtual Base::Msg_data::Ack_type on_rx_cy(Cyphal_stg_fields cyf, Rx_params& p);
    virtual bool on_tx_impl(Tx_params& tx_p);
    bool cm_generate_keys() const;
    bool save_keys_in_flash() const;
    bool read_keys_from_flash(Base::Key_pair& keys) const;
    inline Base::Key_pair get_actual_keys() const;

private:
    enum Status { success, failure };
    const volatile Base::Prv_key::Type& private_key;  // CM shared private key reference
    const volatile Base::Pub_key::Type& public_key;   // CM shared public key reference
    const volatile Uint16& ready_flag;                // CM shared key generation flag reference
    MCxx::Suite_mc* suite_mc;                         // Suite MC pointer
    Base::Key_pair actual_keys;                       // Actual Key Pair in RAM
    Uint64 node_id;                                   // Own node id
    Status result;                                    // Key generation status
    Uint16 key_id;                                    // The key location if available
};
```

### 1.2 Key Provisioning Process via Cyphal

The key provisioning process is triggered through a Cyphal message and follows these steps:

1. A Cyphal message is received by the `on_rx_cy` method
2. The system verifies that the device is not armed (safety check)
3. The system validates that the message is intended for this node by checking the target node ID
4. The CM core is requested to generate a new key pair via `cm_generate_keys()`
5. The generated keys are saved to flash memory via `save_keys_in_flash()`
6. The keys are read back from flash to RAM via `read_keys_from_flash()`
7. A response message is prepared and sent back to the requester

```cpp
Base::Msg_data::Ack_type Cy_key_provisioning::on_rx_cy(Cyphal_stg_fields cyf, Rx_params& p) {
    Base::Msg_data::Ack_type ret = Base::Msg_data::rejected;
    volatile const bool& is_armed = Bsp::Hbvar(Base::kbit_is_armed).get_kref();
    if(!is_armed) {
        Uint16 target_node_id = p.is.get_uint16_le();
        if(target_node_id == node_id) {
            // Generate the keys
            if(cm_generate_keys()) {
                result = success;
                // Copy the keys to FLASH
                save_keys_in_flash();
                // Update the actual keys
                read_keys_from_flash(actual_keys);
            }
            else {
                result = failure;
            }
            // Put the msg to send
            Base::Msg_data data(p.hdr.get_src(), Base::Stanag_msg_type::cyp_key_provision_resp, 0);
            p.msg_sender.send(data);
            ret = Base::Msg_data::received;
        }
    }
    return ret;
}
```

### 1.3 Response Message Format

When responding to a key provisioning request, the system sends back:

1. The node ID (16-bit)
2. The result status (8-bit: success or failure)
3. The public key size (8-bit)
4. The public key data (variable length)
5. The key ID (16-bit)

```cpp
void Cy_key_provisioning::cget(Base::U8ostream& os) const {
    // Put Node id
    os.put_uint16_le(node_id);
    // Result
    os.put_uint8(result);
    // Put public Key
    os.put_uint8(static_cast<Uint8>(Pub_key::sz_bytes));
    U8pkmblock mb_public_key(&actual_keys.pub, Pub_key::sz_bytes);
    os.put_mblock(mb_public_key);
    // Key ID
    os.put_uint16_le(key_id);
}
```

## 2. CM Core Cryptographic Operations

### 2.1 CM Handler Interface

The `Cm_handler` class provides an interface for requesting cryptographic operations from the CM core:

```cpp
class Cm_handler : public Cy_soft_conf_check::Icpu_handler {
public:
    explicit Cm_handler(Cyphal::Cy_key_provisioning& key_provider0);
    static bool cm_request(Base::CM_commands command);
    virtual bool sign(const Base::Mblock<Uint16>& data, Base::Mblock<Uint16>& signed_data);
    inline static bool gen_keys();
    inline virtual bool compute_hash();

private:
    Cyphal::Cy_key_provisioning& key_provider;  // Key provision reference
};
```

### 2.2 CM Command Types

The CM core can execute several types of cryptographic commands:

```cpp
enum CM_commands {
    comp_hash,      // Calculate SHA256 hash of application area
    gen_keys,       // Generate private and public keys
    sign_chall,     // Sign a hash using provided private key
    load_def_keys   // Load default keys to shared memory
};
```

### 2.3 CM Request Process

The `cm_request` method handles communication with the CM core:

1. Sets the command in shared memory
2. Boots the CM core if needed
3. Waits for the CM core to complete the operation
4. Turns off the CM core when done

```cpp
bool Cm_handler::cm_request(Base::CM_commands command) {
    bool ret = true;
    static const Real boot_timeout = 0.002F;
    static const Real action_timeout = 0.3F;

    // Set CM command
    MCxx::CPU1_CM_shared& shared_c1 = MCxx::get_shared_c1();
    shared_c1.cm_cmd = command;

    // Start CM initialization
    if(Dsp28335_ent::CM_helpers::cm_boot(boot_timeout)) {
        Dsp28335_ent::CM_helpers::cm_init_end();
        // Reset the timeout and set its time in seconds
        Base::Timeout tout(action_timeout);

        // Wait until task is completed
        while((MCxx::get_shared_cm().ready == 0) && ret) {
            ret = !tout.expired();
        }
        // Turn off the CM core
        Dsp28335_ent::Ipc::turn_off_cm();
    }
    else {
        ret = false;
    }
    return ret;
}
```

### 2.4 Key Generation Process

The key generation process is initiated by calling `gen_keys()`, which invokes the CM core to generate a new ECDSA key pair:

```cpp
inline static bool gen_keys() {
    return cm_request(Base::gen_keys);
}
```

The CM core generates the keys and stores them in the shared memory region, where they can be accessed by CPU1.

## 3. Challenge-Response Authentication System

### 3.1 Signature Generation Process

The `sign` method implements a challenge-response authentication mechanism:

1. Copies the current private key to shared memory
2. Copies the challenge data (hash) to shared memory
3. Requests the CM core to sign the challenge
4. Retrieves the signature from shared memory

```cpp
bool Cm_handler::sign(const Base::Mblock<Uint16>& data, Base::Mblock<Uint16>& signed_data) {
    bool ret = false;
    // Put the actual private key and the challenge into shared mem
    MCxx::CPU1_CM_shared& shared_c1 = MCxx::get_shared_c1();
    shared_c1.prv_key.copy(key_provider.get_actual_keys().prv);
    shared_c1.hash.copy(data);

    // Request the CM to sign the challenge
    ret = cm_request(Base::sign_chall);

    // Copy the result into signed_data
    signed_data.copy(MCxx::get_shared_cm().signature.to_mblock());
    return ret;
}
```

### 3.2 Hash Computation

The system can compute SHA256 hashes of memory regions:

```cpp
inline virtual bool compute_hash() {
    return cm_request(Base::comp_hash);
}
```

In the SIL (Software-in-the-Loop) implementation, the hash computation is stubbed:

```cpp
inline bool compute_hash(const Base::Mblock_s& app_mb, Base::Sha256_data::Type& digest) {
    return false;
}
```

## 4. Key Storage System

### 4.1 Flash Storage Implementation

The `save_keys_in_flash` method stores the generated keys in non-volatile flash memory:

```cpp
bool Cy_key_provisioning::save_keys_in_flash() const {
    bool ret = false;
    if(suite_mc != 0) {
        static Base::File_sync f_sync(suite_mc->get_f_pdi());
        if(f_sync.open(Ifile::Uid::build(MCxx::pdif_part, MCxx::keys_file), Base::Ifile::m_create)) {
            // Write the keys in keys_file
            const U8pkmblock_k data_pr(&private_key, Prv_key::sz_bytes);
            ret = Assertions::runtime(f_sync.write(data_pr) == data_pr.size());
            const U8pkmblock_k data_pb(&public_key, Pub_key::sz_bytes);
            ret &= Assertions::runtime(f_sync.write(data_pb) == data_pb.size());
            f_sync.close();

            // Save the file in flash
            ret &= suite_mc->flash.flash_cfg_save();
        }
    }
    return ret;
}
```

### 4.2 Key Retrieval from Flash

The `read_keys_from_flash` method retrieves the stored keys from flash memory:

```cpp
bool Cy_key_provisioning::read_keys_from_flash(Key_pair& keys) const {
    bool ret = false;
    if(suite_mc != 0) {
        static Base::File_sync f_sync(suite_mc->get_f_pdi());
        if(f_sync.open(Ifile::Uid::build(MCxx::pdif_part, MCxx::keys_file), Base::Ifile::m_read)) {
            // Read the keys from keys_file
            U8pkmblock data_pr(keys.prv.to_mblock());
            ret = Assertions::runtime(f_sync.read(data_pr) == data_pr.size());
            U8pkmblock data_pb(keys.pub.to_mblock());
            ret &= Assertions::runtime(f_sync.read(data_pb) == data_pb.size());
            f_sync.close();
        }
    }
    return ret;
}
```

### 4.3 Default Keys

The system includes default keys that can be used as fallback:

```cpp
// Default Private Key
const Uint16 def_prv_key[prv_key_wsz] = {
     0x7653, 0x9E2E, 0x8EF0, 0x7599, 0x20AA, 0x81F3, 0x8DE4, 0xAD0C,
     0x83B8, 0xE2AD, 0x33F0, 0x9DA3, 0x930B, 0xE5A2, 0xAB7B, 0x6A02
};

// Default Public Key
const Uint16 def_pub_key[pub_key_wsz] = {
     0x4B04,
     0xE1D0, 0x7812, 0xD169, 0x2B93, 0xBD9D, 0x6E0B, 0x204C, 0x733A,
     0x9029, 0xE9A3, 0x475C, 0x0683, 0x938A, 0x4687, 0xBE24, 0x0BDB,
     0x25A4, 0x248E, 0xB039, 0x0818, 0xE456, 0x327E, 0x6A04, 0xB064,
     0xA205, 0x8406, 0x31D9, 0x642C, 0x7A9F, 0x6F68, 0xA4E6, 0x00B5
};
```

## 5. Key Sizes and Data Structures

### 5.1 Key Size Constants

The system defines specific sizes for cryptographic keys:

```cpp
// Default private key size
static const Uint16 prv_key_sz = 32U;
// Default private key size in words
static const Uint16 prv_key_wsz = (prv_key_sz + 1U)/2U;
// Default public key size
static const Uint16 pub_key_sz = 1U + prv_key_sz*2U;
// Default public key size in words
static const Uint16 pub_key_wsz = (pub_key_sz + 1U)/2U;
```

### 5.2 Key Data Structures

The system uses several key-related data structures:

1. `Base::Prv_key::Type` - Private key type
2. `Base::Pub_key::Type` - Public key type
3. `Base::Key_pair` - Combined private and public key pair
4. `Base::Signature::Type` - ECDSA signature type
5. `Base::Sha256_data::Type` - SHA256 hash type

## 6. Cross-Core Communication for Cryptographic Operations

### 6.1 Shared Memory Structure for Cryptographic Operations

The CPU1-CM shared memory includes fields specifically for cryptographic operations:

```cpp
struct CPU1_CM_shared {
    // ...
    Base::Prv_key::Type prv_key;    // Private key for signing with CM core
    Base::Sha256_data::Type hash;    // Hash to sign with CM core
    Base::CM_commands cm_cmd;        // Execution mode for CM core
    // ...
};

struct CM_CPU1_shared {
    // ...
    Base::Sha256_data::Type cmhash_data;    // CM code SHA256 result
    Uint16 ready;                           // Ready flag
    Base::Prv_key::Type prv_key;            // ECDSA Private key
    Base::Pub_key::Type pub_key;            // ECDSA Public key
    Base::Signature::Type signature;        // Signature result
    // ...
};
```

### 6.2 Communication Flow for Key Generation

1. CPU1 sets `cm_cmd = gen_keys` in `CPU1_CM_shared`
2. CPU1 boots the CM core
3. CM core generates a new key pair
4. CM core stores the keys in `CM_CPU1_shared.prv_key` and `CM_CPU1_shared.pub_key`
5. CM core sets `ready = 1` in `CM_CPU1_shared`
6. CPU1 detects that `ready = 1` and reads the generated keys
7. CPU1 turns off the CM core

### 6.3 Communication Flow for Signature Generation

1. CPU1 copies the private key to `CPU1_CM_shared.prv_key`
2. CPU1 copies the challenge hash to `CPU1_CM_shared.hash`
3. CPU1 sets `cm_cmd = sign_chall` in `CPU1_CM_shared`
4. CPU1 boots the CM core
5. CM core signs the hash using the private key
6. CM core stores the signature in `CM_CPU1_shared.signature`
7. CM core sets `ready = 1` in `CM_CPU1_shared`
8. CPU1 detects that `ready = 1` and reads the signature
9. CPU1 turns off the CM core

## 7. System Identification and Node ID Management

### 7.1 Node ID Assignment

Each node in the system has a unique node ID that is used for addressing:

```cpp
Cy_key_provisioning::Cy_key_provisioning(const volatile Base::Prv_key::Type& private_key0,
                                         const volatile Base::Pub_key::Type& public_key0,
                                         const volatile Uint16& ready_flag0,
                                         Uint64 node_id0) :
    private_key(private_key0),
    public_key(public_key0),
    ready_flag(ready_flag0),
    suite_mc(0),
    node_id(node_id0),
    result(failure),
    key_id(0)
{
    actual_keys.prv.zeros();
    actual_keys.pub.zeros();
}
```

### 7.2 Node ID Verification

When receiving a key provisioning request, the system verifies that the request is intended for this node:

```cpp
Uint16 target_node_id = p.is.get_uint16_le();
if(target_node_id == node_id) {
    // Process the request
}
```

## 8. Error Handling and Safety Mechanisms

### 8.1 Armed State Check

The key provisioning system includes a safety check to prevent key changes when the system is armed:

```cpp
volatile const bool& is_armed = Bsp::Hbvar(Base::kbit_is_armed).get_kref();
if(!is_armed) {
    // Process key provisioning request
}
```

### 8.2 Operation Result Tracking

The system tracks the result of key generation operations:

```cpp
if(cm_generate_keys()) {
    result = success;
    // Additional operations
}
else {
    result = failure;
}
```

### 8.3 Timeout Handling

The CM request process includes timeout handling to prevent indefinite waiting:

```cpp
// Reset the timeout and set its time in seconds
Base::Timeout tout(action_timeout);

// Wait until task is completed
while((MCxx::get_shared_cm().ready == 0) && ret) {
    ret = !tout.expired();
}
```

### 8.4 Flash Write Verification

When saving keys to flash, the system verifies that the write operation was successful:

```cpp
ret = Assertions::runtime(f_sync.write(data_pr) == data_pr.size());
ret &= Assertions::runtime(f_sync.write(data_pb) == data_pb.size());
```

## 9. Integration with IPC Architecture

### 9.1 Shared Memory Access

The cryptographic system accesses shared memory through accessor functions:

```cpp
MCxx::CPU1_CM_shared& shared_c1 = MCxx::get_shared_c1();
const volatile MCxx::CM_CPU1_shared& shared_cm = MCxx::get_shared_cm();
```

### 9.2 CM Core Control

The system controls the CM core through helper functions:

```cpp
Dsp28335_ent::CM_helpers::cm_boot(boot_timeout);
Dsp28335_ent::CM_helpers::cm_init_end();
Dsp28335_ent::Ipc::turn_off_cm();
```

### 9.3 Initialization Process

The key provisioning system is initialized with references to shared memory variables:

```cpp
void Cy_key_provisioning::init(MCxx::Suite_mc& smc) {
    suite_mc = &smc;
    read_keys_from_flash(actual_keys);
}
```

## Referenced Context Files

The following context files provided valuable insights for understanding the cryptographic system:

1. `04_IPC_Core_Components.md`: Provided detailed information about the Inter-Processor Communication (IPC) system architecture, shared memory structures, and communication protocols between CPU1 and CM cores.

2. `03_Bootloader_System.md`: Provided information about the secure boot process, including application validation and cryptographic operations during the boot sequence.

The cryptographic system forms a critical security component of the multi-core architecture, enabling secure boot, authentication, and communication through ECDSA key pairs and signatures. The well-defined key provisioning process, cross-core communication for cryptographic operations, and secure key storage mechanisms ensure the integrity and authenticity of the system.