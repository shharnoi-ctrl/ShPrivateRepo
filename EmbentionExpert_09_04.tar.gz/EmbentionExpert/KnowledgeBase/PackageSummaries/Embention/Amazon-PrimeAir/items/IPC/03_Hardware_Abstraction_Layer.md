# Generated from:

- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/include/Halsuite_mc.h (6076 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/include/Icontrol_input.h (304 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/include/mc_28335.h (2003 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/include/HWversion.h (369 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/include/Partition_mc.h (232 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/include/Halsuite_params.h (2138 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/include/Halsuite_mc_ctrl.h (4016 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/include/Suite_mc.h (2600 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/include/mc_2838x_ccard.h (2118 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/include/pa/mc_pinout.h (2126 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/source/Halsuite_mc.cpp (8703 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/source/Suite_mc.cpp (8919 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/source/Halsuite_mc_ctrl.cpp (4933 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/source/HWversion.cpp (1392 tokens)

## With context from:

- PackageSummaries/Amazon-PrimeAir/items/IPC/07_Motor_Controller_Architecture.md (2764 tokens)

---

# Hardware Abstraction Layer (HAL) for Motor Controller Family

This comprehensive analysis details the architecture and implementation of the Hardware Abstraction Layer (HAL) for the Motor Controller family, focusing on the `Halsuite_mc` (for Core 1) and `Halsuite_mc_ctrl` (for Core 2) components.

## 1. Overall Architecture

The Motor Controller HAL is implemented as a dual-core system with clear separation of responsibilities:

### 1.1 Core 1 HAL (`Halsuite_mc`)

`Halsuite_mc` provides hardware abstraction for CPU1 (Core 1), focusing on:
- Communication interfaces (CAN, CAN-FD, SCI, SPI)
- GPIO management for status indicators and peripherals
- Hardware version detection and configuration
- PWM synchronization and control
- Peripheral polling and management

### 1.2 Core 2 HAL (`Halsuite_mc_ctrl`)

`Halsuite_mc_ctrl` provides hardware abstraction for CPU2 (Core 2), focusing on:
- Motor control PWM generation and configuration
- ADC sampling and configuration for motor current sensing
- GPIO management for motor driver control
- Fault detection inputs
- PWM synchronization for multi-controller operation

### 1.3 Shared Components

Both HAL implementations share:
- Hardware version identification (`HWversion`)
- Common parameter structures (`Halsuite_params`)
- Cross-core communication through shared memory

## 2. Hardware Version Detection and Management

The system supports multiple hardware variants through the `HWversion` class:

```cpp
enum HWversion_id {
    v_unknown,      // Unknown (not computed)
    v_mc_25,        // MC25
    v_mc_110,       // MC110
    v_mc_110_v2,    // MC110 v2
    v_mc_24,        // MC24
    v_mc_ipc        // MC for IPC
};
```

### 2.1 Hardware Version Detection Process

1. The system first checks if the hardware version is stored in the device UID
2. If not available, it reads an ADC channel (`hwversion_adc_ch`) to determine the hardware version
3. The ADC voltage is compared against reference values in `ref_values` array
4. The hardware version is stored in `HWversion::hwv` for future reference
5. The detected hardware version is shared with Core 2 through shared memory

### 2.2 Hardware-Specific Configuration

Based on the detected hardware version, the system configures:
- ADC reference voltage type:
  - `v_mc_24`: Internal reference
  - `v_mc_110_v2`: External 3.0V reference
  - `v_mc_ipc`: External 3.03V reference
  - Others: External 2.048V reference
- PWM dead time:
  - `v_mc_110` or `v_mc_110_v2`: 1μs
  - Others (including `v_mc_24`): 0.35μs
- SCI peripheral mapping (different for `v_mc_110_v2`)
- GPIO configurations and pin mappings

## 3. Core 1 HAL Implementation (`Halsuite_mc`)

### 3.1 Initialization Sequence

The `Halsuite_mc` constructor performs the following initialization steps:

1. Detects hardware version using `HWversion::get_hwversion()`
2. Initializes ADC with appropriate reference voltage
3. Configures timer (Timer2)
4. Sets up CAN terminators
5. Configures SPI for SD card with appropriate baudrate
6. Initializes CAN and CAN-FD peripherals
7. Sets up SCI ports with buffering
8. Configures ECAP peripherals for pulse capture
9. Initializes GPIO pins for monitoring voltage switches
10. Updates shared memory with hardware version information

### 3.2 Brushless Motor Initialization

The `init_brushless()` method configures hardware for brushless motor operation:

1. Configures GPIO pins for:
   - Driver fault detection
   - Phase error detection
   - Over-current detection
   - Power good signals
   - Trip PWM signals
   - Pre-charge status
   - LED indicators
   - CAN transceivers
   - Monitoring switches

2. Initializes PWM clock to operate at half the system frequency

3. Configures PWM GPIO pins for motor driver control

4. Sets up ECAP peripherals for synchronization inputs

5. Configures trip zone inputs for PWM protection

6. Sets up fan PWM and synchronization outputs

7. Initializes monitoring voltage switches

### 3.3 Communication Interface Management

The `poll()` method handles communication interface management:

1. Processes CAN and CAN-FD message reception
2. Checks for transmission timeouts on CAN interfaces
3. Manages SCI port buffering:
   - Transfers received data from hardware to buffers
   - Transfers outgoing data from buffers to hardware

### 3.4 PWM Control

The HAL provides methods to enable and disable PWM outputs:

- `enable_pwm()`: Configures GPIO pins for PWM functionality
- `disable_pwm()`: Reconfigures PWM pins as general-purpose GPIO
- `disable()`: Implements the `Idisable` interface to disable PWM outputs

## 4. Core 2 HAL Implementation (`Halsuite_mc_ctrl`)

### 4.1 Initialization

The `Halsuite_mc_ctrl` constructor initializes:

1. Hardware parameters based on detected version
2. ADC manager with appropriate reference voltage
3. PWM peripherals for three motor phases
4. Fan PWM peripheral
5. Synchronization PWM output
6. GPIO pins for:
   - Heartbeat output
   - Driver enable gate
   - Fault detection
   - Phase error detection
   - Over-current detection
   - Pre-charge control
   - Power good monitoring
   - LED indicators

### 4.2 Brushless Motor Control Initialization

The `init_brushless()` method configures the motor control hardware:

1. Configures PWM peripherals with:
   - Operating frequency (`pwm_freq`)
   - Dead time based on hardware version
   - ADC trigger divider (`adc_div`)
   - Interrupt generation configuration

2. For IPC hardware, configures shadow register reload

3. Sets up trip zone protection if trip input is available

4. Configures synchronization PWM output:
   - Sets frequency matching motor PWM
   - Configures duty cycle to nominal value
   - Sets phase shift for synchronization
   - Enables synchronization with PWM1

5. Configures fan PWM with separate frequency

6. Configures ADC for motor current sensing:
   - Sets acquisition window size based on hardware
   - Configures RC time constants for sampling
   - Sets up ADC channel sequence

7. Configures driver enable gate based on hardware version

### 4.3 PWM Control

The `enable_pwm()` method enables all motor control PWM outputs:
- Sets PWM modules to enabled state
- Configures default 50% duty cycle

### 4.4 Interrupt Management

The `enable_global_isr()` method enables global interrupts by:
- Clearing the INTM bit (enables maskable interrupts)
- Clearing the DBGM bit (enables real-time interrupts)
- Setting the debug interrupt enable register

## 5. PWM Synchronization Architecture

The system implements a sophisticated PWM synchronization scheme for multi-controller operation:

### 5.1 Synchronization Modes

The `Ipc_ids::PWM_sync_mode` enum defines synchronization roles:
- `m_leader`: Master controller generating synchronization signal
- `m_follower0`: First follower controller
- `m_follower1`: Second follower controller

### 5.2 Synchronization Mechanism

1. ECAP peripherals capture synchronization pulses:
   - `sync1_ecap`: Captures PWM synchronization signal
   - `sync2_ecap`: Captures heartbeat signal
   - `sync1_ecap_freq`: Measures synchronization frequency

2. Pulse measurement classes process captured signals:
   - `sync1_pulse`: Measures duty cycle of PWM sync signal
   - `sync2_pulse`: Measures duty cycle of heartbeat signal
   - `sync1_pulse_freq`: Measures frequency of sync signal

3. The `Suite_mc::step_interleaving()` method manages role transitions:
   - Detects when a leader should become a follower (degraded duty cycle)
   - Handles follower to leader transitions when previous ESC is not OK
   - Updates shared memory with synchronization parameters

### 5.3 Synchronization Parameters

- `sync1_duty`: Filtered duty cycle from PWM sync input
- `sync2_duty`: Filtered duty cycle from heartbeat input
- `sync1_freq`: Filtered frequency from PWM sync input
- `counter_receiv`: Counter to determine if first sync was received
- `prev_esc_ok`: Status of previous ESC

## 6. Hardware-Specific Parameters and Configurations

The system includes hardware-specific configurations for different variants:

### 6.1 MC28335 Configuration

Defined in `mc_28335.h`:
- ADC channel for hardware version detection: `ADC::adc14`
- ADC reference type: `ADC::internal`
- ECAP IDs and GPIO mappings
- GPIO configurations for:
  - Phase error detection
  - Driver enable
  - Fault detection
  - PWM outputs
  - Communication interfaces
  - LED indicators

### 6.2 MC2838x Configuration (Typhoon)

Defined in `mc_2838x_ccard.h`:
- ADC channel for hardware version: `ADC::adc12`
- ADC reference type: `ADC::external_3030`
- Extended ECAP configuration with 7 channels
- GPIO mappings for Typhoon hardware
- SPI configuration for SD card
- Communication interface pin assignments

### 6.3 PA Configuration

Defined in `mc_pinout.h`:
- Similar to Typhoon configuration but with different GPIO assignments
- Specialized configuration for PA hardware variant

## 7. Suite Management and Integration

The `Suite_mc` class integrates the HAL with higher-level functionality:

### 7.1 Components

- Time providers and file system management
- System time and session handling
- Reset management
- File communication
- Configuration synchronization
- Error handling
- CAN and SCI communication suites
- Pulse measurement for control inputs
- Configuration management
- Discovery protocols

### 7.2 Initialization

The `Suite_mc` constructor:
1. Initializes system time and session
2. Sets up file systems and communication
3. Configures error handling
4. Initializes CAN and SCI communication suites
5. Sets up pulse measurement for control inputs
6. Configures synchronization pulse measurement
7. Initializes configuration management
8. Registers components with the step manager
9. Configures message handlers

### 7.3 Execution Model

The `Suite_mc` class implements a multi-rate execution model:
- `step()`: Handles low-priority tasks (CAN/SCI processing, pulse measurement)
- `step_hi()`: Handles high-priority tasks (synchronization pulse processing)
- `step_interleaving()`: Manages PWM synchronization between controllers

## 8. Error Handling and Fault Management

The HAL implements several fault detection and handling mechanisms:

### 8.1 Hardware Fault Inputs

GPIO inputs for fault detection:
- Driver fault (`gpio_id_drv_fault`)
- Phase errors (`gpio_phaseu_err`, `gpio_phasev_err`, `gpio_phasew_err`)
- Over-current detection (`gpio_ocac_u`, `gpio_ocac_v`, `gpio_ocac_w`, `gpio_ocdc`)
- Ground fault detection (`gpio_gfd`)
- Power good signals (`gpio_pg_3v3`, `gpio_pg_15v`, `gpio_pg_1v2`, `gpio_pg_5v`)
- Trip PWM signal (`gpio_trip_pwm`)

### 8.2 PWM Protection

- Trip zone configuration for immediate PWM shutdown on fault
- PWM disable mechanism through `disable_pwm()` and `disable()` methods
- Cross-core signaling for fault propagation

## 9. Cross-Core Communication

The HAL uses shared memory for communication between cores:

### 9.1 Shared Memory Structure

- `C1_owned`: Memory owned by Core 1, readable by Core 2
- `C2_owned`: Memory owned by Core 2, readable by Core 1

### 9.2 Shared Parameters

- Hardware version (`hwv`)
- Synchronization parameters (`sync_enabled`, `sync1_duty`, `pwm_shift`)
- Role change flag (`change_role`)
- Interleaving enable flag (`enable_interleaving`)
- PWM mode (`pwm_mode`)

## 10. Referenced Context Files

The analysis incorporated information from:
- `07_Motor_Controller_Architecture.md`: Provided overall architectural context for the dual-core system

## Summary

The Hardware Abstraction Layer for the Motor Controller family implements a sophisticated dual-core architecture with clear separation of responsibilities between Core 1 (system management) and Core 2 (real-time motor control). The HAL provides comprehensive hardware abstraction, supporting multiple hardware variants through automatic detection and configuration. The system includes advanced features such as PWM synchronization for multi-controller operation, fault detection and handling, and efficient cross-core communication through shared memory. The modular design allows for hardware-specific configurations while maintaining a consistent interface for higher-level software components.