# Generated from:

- items/sw_IPC_SIL/code/include/GroundTruthState_0_1.h (20298 tokens)
- items/sw_IPC_SIL/code/include/serialization.h (6516 tokens)
- items/sw_IPC_SIL/code/include/interface.h (3361 tokens)
- items/sw_IPC_SIL/code/include/FirmwareSimulationLifeCycle.h (1414 tokens)
- items/sw_IPC_SIL/code/include/Sil_io_esc.h (267 tokens)
- items/sw_IPC_SIL/code/include/Esc_sil_block.h (733 tokens)
- items/sw_IPC_SIL/code/include/FirmwareSimulation.h (270 tokens)
- items/sw_IPC_SIL/code/include/FirmwareSimulationDataExchange.h (1378 tokens)
- items/sw_IPC_SIL/code/main/run_esc.cpp (3122 tokens)
- items/sw_IPC_SIL/code/source/Esc_sil_block.cpp (3588 tokens)
- items/sw_IPC_SIL/code/source/esc_ipc_firmware_simulation.cpp (5150 tokens)

## With context from:

- PackageSummaries/Amazon-PrimeAir/items/IPC/07_Motor_Controller_Architecture.md (2764 tokens)
- PackageSummaries/Amazon-PrimeAir/items/IPC/05_Field_Oriented_Control.md (7141 tokens)
- PackageSummaries/Amazon-PrimeAir/items/IPC/04_Protection_Systems.md (6243 tokens)

---

# Comprehensive Analysis of Software-in-the-Loop (SIL) Simulation Framework for ESC Testing

## 1. System Architecture Overview

The Software-in-the-Loop (SIL) simulation framework implements a closed-loop testing environment for Electronic Speed Controllers (ESCs). The architecture consists of several key components that work together to simulate the behavior of ESCs and motors in a controlled environment.

### 1.1 Core Components

The SIL framework is built around these primary components:

1. **Firmware Simulation Interface**: Provides a standardized interface between the firmware application and the simulation environment through the `FirmwareSimulation` class hierarchy.

2. **ESC Simulation Block**: Implemented in `Esc_sil_block` class, which simulates the ESC firmware's behavior including control algorithms, task scheduling, and I/O processing.

3. **Motor Simulation**: Implemented through the Amazon ESC simulation interface (`amzn::esc::sim::Interface`), which provides a physics-based model of the BLDC motor.

4. **Inter-Process Communication (IPC)**: Facilitates message exchange between the simulation components using a standardized `MessageData` structure.

5. **Cyphal Message Handling**: Processes standardized messages like `GroundTruthState`, `MotorRpmCommand`, and `MotorPerformance` for communication between components.

### 1.2 System Interaction Flow

The simulation implements a closed-loop architecture where:

1. Motor simulation outputs (currents, voltages, position feedback) are fed to the ESC simulation
2. ESC simulation processes these inputs and generates PWM outputs
3. PWM outputs are fed back to the motor simulation
4. The motor simulation updates its state based on these inputs
5. The cycle repeats at a fixed time step (typically 1ms)

```
┌─────────────────┐         ┌─────────────────┐
│                 │ Currents │                 │
│  Motor          ├────────►│  ESC            │
│  Simulation     │ Voltages │  Simulation    │
│  (Physics Model)│ Position │  (Firmware)    │
│                 │◄────────┤                 │
└─────────────────┘   PWM   └─────────────────┘
```

## 2. Firmware Simulation Interface

The firmware simulation interface provides a standardized way to interact with the ESC firmware in a simulation environment.

### 2.1 Interface Hierarchy

```
┌─────────────────────────┐
│ FirmwareSimulationLifeCycle │
└───────────────┬─────────┘
                │
┌───────────────▼─────────┐
│ FirmwareSimulationDataExchange │
└───────────────┬─────────┘
                │
┌───────────────▼─────────┐
│   FirmwareSimulation    │
└───────────────┬─────────┘
                │
┌───────────────▼─────────┐
│      Esc_sim           │
└─────────────────────────┘
```

### 2.2 Lifecycle Management

The `FirmwareSimulationLifeCycle` interface defines methods for managing the firmware's lifecycle:

```cpp
class FirmwareSimulationLifeCycle {
public:
    virtual ~FirmwareSimulationLifeCycle() = default;
    virtual bool Init(const FirmwareInitData & init_data) = 0;
    virtual bool ExecuteAndScheduleNextExecutionInNs(uint64_t & interval_ns) = 0;
    virtual std::string GetErrorString() = 0;
    virtual void Reset() = 0;
};
```

Key methods:
- `Init()`: Initializes the firmware with node ID and other configuration data
- `ExecuteAndScheduleNextExecutionInNs()`: Steps the firmware and schedules the next execution
- `Reset()`: Resets the firmware to its initial state
- `GetErrorString()`: Returns error information if execution fails

### 2.3 Data Exchange

The `FirmwareSimulationDataExchange` interface defines methods for exchanging messages:

```cpp
class FirmwareSimulationDataExchange {
public:
    virtual ~FirmwareSimulationDataExchange() = default;
    virtual bool PutMessage(const MessageData &msg) = 0;
    virtual bool GetMessage(MessageData &msg) = 0;
};
```

Key methods:
- `PutMessage()`: Sends a message to the firmware
- `GetMessage()`: Receives a message from the firmware

### 2.4 Message Structure

The `MessageData` structure encapsulates message data and metadata:

```cpp
struct MessageData {
    std::vector<uint8_t> serialized_payload;
    size_t payload_size_bytes;
    int32_t destination_node_id;
    int32_t source_node_id;
    uint8_t priority;
    bool is_service;
    bool is_request;
    uint8_t tail_byte;
    uint16_t port_id;
    uint8_t transport;
    bool is_valid;
};
```

This structure contains:
- Serialized message payload
- Message routing information (source/destination)
- Message type information (service/request)
- Transport information
- Validity flag

## 3. ESC Simulation Block Implementation

The `Esc_sil_block` class implements the core ESC simulation functionality, modeling the behavior of the dual-core ESC firmware.

### 3.1 Task Scheduling

The ESC simulation implements a multi-rate task scheduler that mimics the real-time behavior of the ESC firmware:

```cpp
struct Min_task {
    Base::Sil_data::Task_id task;    // Task ID
    Base::Ttime time;                // Associated time
};
```

Four main tasks are scheduled:
1. `cio_hi`: High-priority CIO task (1kHz)
2. `cio_lo`: Low-priority CIO task (1kHz)
3. `c2_hi`: High-priority C2 task (1kHz)
4. `c2_lo`: Low-priority C2 task (1kHz)

The scheduler determines which task to execute next based on their scheduled execution times:

```cpp
Esc_sil_block::Min_task Esc_sil_block::find_next_task() const {
    Min_task ret;
    if (next_cio_hi_time <= next_cio_lo_time &&
        next_cio_hi_time <= next_c2_hi_time &&
        next_cio_hi_time <= next_c2_lo_time) {
        ret.task = Base::Sil_data::task_c1_hi;
        ret.time = next_cio_hi_time;
    }
    else if (next_cio_lo_time <= next_c2_hi_time &&
             next_cio_lo_time <= next_c2_lo_time) {
        ret.task = Base::Sil_data::task_c1_lo;
        ret.time = next_cio_lo_time;
    }
    else if (next_c2_hi_time <= next_c2_lo_time) {
        ret.task = Base::Sil_data::task_c2_hi;
        ret.time = next_c2_hi_time;
    }
    else {
        ret.task = Base::Sil_data::task_c2_lo;
        ret.time = next_c2_lo_time;
    }
    return ret;
}
```

### 3.2 Main Execution Flow

The main execution flow is implemented in the `step()` method:

```cpp
Real64 Esc_sil_block::step(const Real64 t, const Esc_input& inputs, Esc_output& out) {
    // Convert time to microseconds
    const Base::Ttime t_us = closest_tic(t);
    
    // Set inputs from motor simulation
    ADC_helper_2837x::set_raw_value(...);
    
    // Execute tasks until the provided input time
    next = find_next_task();
    while (next.time <= t_us) {
        Bsp::Htimehelper::set_time_us(next.time);
        switch (next.task) {
            case Base::Sil_data::task_c1_hi:
                step_cio_hi();
                next_cio_hi_time += cio_hi_period_us;
                break;
            case Base::Sil_data::task_c1_lo:
                step_cio_lo();
                next_cio_lo_time += cio_lo_period_us;
                break;
            case Base::Sil_data::task_c2_hi:
                step_c2_hi();
                next_c2_hi_time += c2_hi_period_us;
                break;
            case Base::Sil_data::task_c2_lo:
                step_c2_lo();
                next_c2_lo_time += c2_lo_period_us;
                break;
            default:
                Bsp::warning();
                break;
        }
        next = find_next_task();
    }
    
    // Get outputs for motor simulation
    out.pwm_output[0] = c2->ctrl.duty_u * c2->ctrl.vdc;
    out.pwm_output[1] = c2->ctrl.duty_v * c2->ctrl.vdc;
    out.pwm_output[2] = c2->ctrl.duty_w * c2->ctrl.vdc;
    
    // Update time
    Bsp::Htimehelper::set_time_us(t_us);
    
    // Return time of next step
    return next.time.get_seconds64();
}
```

This method:
1. Converts simulation time to microseconds
2. Sets ADC inputs from the motor simulation
3. Executes tasks until the current simulation time
4. Updates PWM outputs for the motor simulation
5. Returns the time of the next scheduled task

### 3.3 Initialization

The `init()` method initializes the ESC simulation with a specific node ID:

```cpp
void Esc_sil_block::init(Uint16 node_id0) {
    // Compute ESC identifier to retrieve real position
    uint8_t position = UINT8_MAX;
    const Uint16 esc_id = node_id0 - node_id_rr_a;
    
    // Set GPIO values for position
    Dsp28335_ent::GPIO(pos_ids[0]).set(position & 0x1);
    Dsp28335_ent::GPIO(pos_ids[1]).set((position >> 1) & 0x1);
    Dsp28335_ent::GPIO(pos_ids[2]).set((position >> 2) & 0x1);
    
    // Read/set position ID
    read_pos();
    
    // Allocate C1 and C2 instances
    c1 = Base::Memmgr::get_instance().get_allocator(Base::Memmgr::internal).allocate_new<MCxx::Mc,
            const MCxx::Mc_params&>(MCxx::p_mc);
    c2 = Base::Memmgr::get_instance().get_allocator(Base::Memmgr::internal).allocate_new<MCxx::Mc_control,
            const MCxx::HWversion_id&, const MCxx::Mc_params&>(MCxx::HWversion_id::v_mc_ipc, MCxx::p_mc);
    
    // Initialize hardware abstraction
    c2->hal_init_ipc();
    c1->post_init_c2();
    set_map_adc();
    
    // Configure system
    MCxx::get_c2_sh_mem().has_ground_fault_protection = false;
    MCxx::get_c1_sh_mem().is_ipc_board = true;
    Dsp28335_ent::GPIO(gpio_shore_power).set_hi();
    Dsp28335_ent::GPIO(MCxx::p_hal.gpio_sscb_nflt_in).set_hi();
    Dsp28335_ent::GPIO(MCxx::p_hal.gpio_pg_3v3).set_hi();
}
```

This method:
1. Determines the ESC position based on node ID
2. Sets GPIO values to simulate hardware configuration
3. Allocates and initializes C1 and C2 instances
4. Configures ADC mapping and system parameters

## 4. Motor Simulation Integration

The motor simulation is implemented using the Amazon ESC simulation interface (`amzn::esc::sim::Interface`).

### 4.1 Interface Definition

The interface defines structures for configuration, commands, and state:

```cpp
class Interface {
public:
    struct VectorABC { float a; float b; float c; };
    
    struct Configuration {
        enum Id { kIdUnknown, kIdCustom, kIdCX3Typhoon, kIdCX3Bloc10FullSim };
        Id id;
        float dt_s;
        struct Motor { /* Motor parameters */ };
        struct LeadWire { /* Lead wire parameters */ };
        struct Inverter { /* Inverter parameters */ };
        struct DcLink { /* DC link parameters */ };
        struct Supply { /* Power supply parameters */ };
        struct Pcba { /* PCBA parameters */ };
    };
    
    struct Command {
        struct Electrical {
            bool inverter_enable;
            VectorABC motor_abc_V;
            float supply_V;
        } electrical;
        
        struct Mechanical {
            float J_kg_m2;
            float k0_N_m;
            float k1_N_m_s_per_rad;
            float k2_N_m_s2_per_rad2;
        } mechanical;
        
        struct Thermal {
            float ambient_degC;
            float motor_C_W_per_K;
            float inverter_C_W_per_K;
        } thermal;
        
        enum Fault { kFaultNone } active_fault;
    };
    
    struct StateObservable {
        VectorABC motor_abc_A;
        float dc_link_A;
        float dc_link_V;
        VectorABC inverter_abc_degC;
        float motor_degC;
    };
    
    struct StateHidden {
        float motor_mech_theta_pirad;
        float motor_mech_omega_rad_per_s;
        float motor_elec_theta_pirad;
        float motor_elec_omega_rad_per_s;
        VectorABC motor_back_emf_abc_V;
    };
    
    struct State {
        StateObservable ideal;
        StateObservable measured;
        StateHidden hidden;
        uint64_t iteration;
    };
    
    virtual const Configuration & AccessConfiguration() const = 0;
    virtual bool IsConfigured() const = 0;
    virtual Command & UpdateCommand() = 0;
    virtual void Step() = 0;
    virtual const State & AccessState() const = 0;
    virtual bool SupportsFault(Command::Fault fault) const = 0;
    virtual ~Interface(){};
};
```

### 4.2 Motor Simulation Integration in Esc_sim

The `Esc_sim` class integrates the motor simulation with the ESC simulation:

```cpp
Esc_sim::Esc_sim():
    block(),
    t(0.0F),
    buffer(),
    motor_sim(amzn_esc_sim_construct(
              amzn::esc::sim::Interface::Configuration::kIdCX3Typhoon, buffer, sizeof(buffer))),
    in(),
    out(),
    state_file(),
    gt_rpm_timer(0ULL),
    tb_rpm_a(tailbyte0),
    tb_rpm_b(tailbyte0)
{
    motor_sim->UpdateCommand().electrical.inverter_enable = true;
}
```

The motor simulation is constructed with the `kIdCX3Typhoon` configuration, which provides parameters for the CX3 "Typhoon" motor model.

### 4.3 Closed-Loop Simulation

The closed-loop simulation is implemented in the `ExecuteAndScheduleNextExecutionInNs()` method:

```cpp
bool Esc_sim::ExecuteAndScheduleNextExecutionInNs(uint64_t & interval_ns) {
    amzn::esc::sim::Interface::Command& command = motor_sim->UpdateCommand();
    const amzn::esc::sim::Interface::State& state = motor_sim->AccessState();
    
    // Output ground truth RPM if needed
    if (gt_rpm_timer == 0) {
        // Create and send ground truth RPM message
    }
    
    bool retval = true;
    uint64_t kSimulationTimeStepNs = 1000000ULL;
    interval_ns = kSimulationTimeStepNs;
    
    const uint64_t adc_freq_hz = static_cast<uint64_t>(MCxx::Mc_freqs::def_ctrl_rt_freq);
    const uint64_t adc_period_ns = 1e9 / adc_freq_hz;
    const uint64_t isr_executions = interval_ns / adc_period_ns;
    
    for (size_t i = 0; i < isr_executions; ++i) {
        // Get motor feedback
        Real ac_currents_amps[3U] = {
            state.measured.motor_abc_A.a,
            state.measured.motor_abc_A.b,
            state.measured.motor_abc_A.c
        };
        Real dc_current_amp = state.measured.dc_link_A;
        Maverick::Sincos sc_pos(state.hidden.motor_mech_theta_pirad);
        sc_pos.c += v_bias_adc;
        sc_pos.s += v_bias_adc;
        
        // Update ESC inputs
        in.ac_currents_adc[0U] = ac_currents_amps[0U] * r_shunt_ipc_ac + v_bias_adc;
        in.ac_currents_adc[1U] = ac_currents_amps[1U] * r_shunt_ipc_ac + v_bias_adc;
        in.ac_currents_adc[2U] = ac_currents_amps[2U] * r_shunt_ipc_ac + v_bias_adc;
        in.idc_adc = dc_current_amp * r_shunt_ipc_dc + v_bias_adc;
        in.vdc_adc = vdv_v * v_max_adc / MCxx::Ipc_ids::max_vdc_ipc;
        in.vmon_adc = vdv_v * v_max_adc / MCxx::Ipc_ids::max_vdc_mon;
        in.motor_temp_adc = 0.306F; // 25°C
        in.sincos_sensor1_adc = sc_pos;
        in.sincos_sensor2_adc = sc_pos;
        
        // Execute ESC simulation
        t = block.step(t, in, out);
        
        // Update motor commands
        command.electrical.motor_abc_V.a = out.pwm_output[0];
        command.electrical.motor_abc_V.b = out.pwm_output[1];
        command.electrical.motor_abc_V.c = out.pwm_output[2];
        command.electrical.supply_V = vdv_v;
        
        // Step motor simulation
        motor_sim->Step();
    }
    
    // Update timer
    gt_rpm_timer += interval_ns;
    if (gt_rpm_timer >= 2000000) {
        gt_rpm_timer = 0;
    }
    
    return retval;
}
```

This method:
1. Gets the current motor state
2. Converts motor outputs to ESC inputs
3. Steps the ESC simulation
4. Converts ESC outputs to motor inputs
5. Steps the motor simulation
6. Repeats for the specified number of iterations

## 5. Cyphal Message Processing

The SIL framework uses Cyphal messages for communication between components.

### 5.1 Message Types

Key message types include:

1. **GroundTruthState**: Contains comprehensive state information about the vehicle, including motor parameters
2. **MotorRpmCommand**: Contains RPM commands for motors
3. **RecoveryMotorRpmCommand**: Contains recovery RPM commands
4. **MotorPerformance**: Contains motor performance metrics
5. **GroundTruthRpm**: Contains ground truth RPM information

### 5.2 Message Handling in Esc_sim

The `Esc_sim` class implements message handling in the `PutMessage()` and `GetMessage()` methods:

```cpp
bool Esc_sim::PutMessage(const MessageData& msg) {
    if (msg.port_id == 998) {
        // Process GroundTruthState message
        vsdk_message_adn_simulation_GroundTruthState_0_1 gts_msg {};
        size_t gts_serialized_size = vsdk_message_adn_simulation_GroundTruthState_0_1_EXTENT_BYTES_;
        if (vsdk_message_adn_simulation_GroundTruthState_0_1_deserialize_(&gts_msg, msg.serialized_payload.data(), &gts_serialized_size) != 0) {
            return false;
        }
        
        // Extract torque and moment of inertia based on node ID
        Real tq_Nm = 0.0F;
        Real moi_kg_m2 = 0.0F;
        const int16_t spin_direction_tq_sign = (is_spin_direction_positive(init_data_.node_id) ? -1 : 1);
        
        switch (init_data_.node_id) {
            case 10: // kRightRear
                tq_Nm = spin_direction_tq_sign * gts_msg.motor_rear_right_prop_torque_Nm;
                moi_kg_m2 = 3.0e-03;
                break;
            // Other cases for different motors
        }
        
        // Update motor command parameters
        auto & esc_command = motor_sim->UpdateCommand();
        esc_command.mechanical.k0_N_m = tq_Nm;
        esc_command.mechanical.J_kg_m2 = moi_kg_m2;
        
        // Calculate and set thermal parameters
        auto v_free = std::sqrt(
            std::pow(gts_msg.motor_rear_right_v_axial_m_per_s, 2) +
            std::pow(gts_msg.motor_rear_right_v_radial_m_per_s, 2));
        auto dynamic_pressure_Pa = 0.5 * gts_msg.air_density_kg_per_m3 * v_free * v_free;
        Real h = static_cast<float>((0.005076 * dynamic_pressure_Pa) + 2.3);
        Real air_temperature_degK = static_cast<float>(gts_msg.air_temperature_K);
        esc_command.thermal.motor_C_W_per_K = h;
        esc_command.thermal.ambient_degC = air_temperature_degK;
    }
    
    // Process RPM command messages
    Base::CANframe data_msg;
    data_msg.id.extended = true;
    
    const bool from_primary = (msg.port_id == MCxx::Ipc_ids::sub_id_pr);
    static const Uint16 max_rec = MCxx::Ipc_ids::sub_id_re + MCxx::Ipc_ids::num_esc - Ku16::u1;
    typedef Base::Range<Uint16, MCxx::Ipc_ids::sub_id_re, max_rec> Range_recovery;
    
    if (from_primary || Range_recovery::in_range(msg.port_id)) {
        // Serialize data
        data_msg.data.data.resize(msg.payload_size_bytes + 1);
        for (Uint8 i = 0; i < msg.payload_size_bytes; ++i) {
            const Uint8 data = msg.serialized_payload[i];
            data_msg.data.set(i, data);
        }
        
        // Set message ID and CAN handler
        Dsp28335_ent::CANhelper* can_hdl = 0;
        Uint8* tb = 0;
        if (from_primary) {
            data_msg.id.id = (MCxx::Ipc_ids::sub_id_pr << Ku16::u8) | MCxx::Ipc_ids::node_id_pr | (0x106 << Ku16::u20);
            can_hdl = &Dsp28335_ent::CANhelper::get_canhelper(Base::canpid_fda);
            tb = &tb_rpm_a;
        } else {
            const Uint32 esc_sub_id = MCxx::Ipc_ids::sub_id_re + (init_data_.node_id - MCxx::Ipc_ids::node_id_rr_a);
            data_msg.id.id = (esc_sub_id << Ku16::u8) | MCxx::Ipc_ids::node_id_re | (0x106 << Ku16::u20);
            can_hdl = &Dsp28335_ent::CANhelper::get_canhelper(Base::canpid_b);
            tb = &tb_rpm_b;
        }
        
        // Set tail byte
        change_tail_byte(*tb);
        data_msg.data.set(msg.payload_size_bytes, *tb);
        
        // Send message
        can_hdl->write_sil(data_msg);
    }
    
    return true;
}

bool Esc_sim::GetMessage(MessageData& msg) {
    Base::CANframe data_msg;
    Dsp28335_ent::CANhelper::get_canhelper(Base::canpid_fda).read_sil(data_msg);
    bool ret = false;
    
    // Check for MotorPerformance message
    if (!Base::has_bit_set(data_msg.id.id, 25) &&
        (data_msg.id.id >> 8 & Cyphal::Full_id::msg_id_mask) == (Base::Stanag_msg_type::cyp_motor_perf & Cyphal::Full_id::msg_id_mask)) {
        ret = true;
        const Uint8 sz = data_msg.data.get_length();
        msg.serialized_payload.resize(sz);
        for (Uint8 i = 0; i < sz; ++i) {
            msg.serialized_payload[i] = data_msg.data.get(i);
        }
        msg.port_id = 421U;
    }
    
    // Check for GroundTruthRpm message
    if (data_msg.id.id == gt_rpm_id) {
        ret = true;
        const Uint8 sz = data_msg.data.get_length();
        msg.serialized_payload.resize(sz);
        for (Uint8 i = 0; i < sz; ++i) {
            msg.serialized_payload[i] = data_msg.data.get(i);
        }
        msg.port_id = (990 + init_data_.node_id);
    }
    
    msg.is_valid = ret;
    return ret;
}
```

These methods:
1. Process incoming messages (GroundTruthState, RPM commands)
2. Update motor simulation parameters based on message content
3. Forward messages to the ESC simulation via CAN interfaces
4. Extract outgoing messages (MotorPerformance, GroundTruthRpm) from the ESC simulation

### 5.3 Ground Truth RPM Generation

The `Esc_sim` class generates `GroundTruthRpm` messages based on the motor simulation state:

```cpp
if (gt_rpm_timer == 0) {
    vsdk_message_adn_simulation_propulsionsystem_GroundTruthRpm_0_1 gtr_msg{};
    
    // Get motor speed from simulation
    const Real motor_mech_omega_rad_per_s = state.hidden.motor_mech_omega_rad_per_s;
    const Real motor_speed_rpm = motor_mech_omega_rad_per_s * (60.0F / 1.0F) * (1.0F / 6.28318F);
    
    // Apply correct sign based on motor position
    if (is_spin_direction_positive(init_data_.node_id)) {
        gtr_msg.ground_truth_rpm = motor_speed_rpm;
    } else {
        gtr_msg.ground_truth_rpm = motor_speed_rpm * -1;
    }
    
    // Get motor orientation
    const auto motor_orientation_e_deg = static_cast<int16_t>(
        state.hidden.motor_elec_theta_pirad * (180.0F / 3.14159F));
    if (motor_orientation_e_deg < 0) {
        gtr_msg.ground_truth_theta_e_deg = static_cast<uint16_t>(motor_orientation_e_deg + 360);
    } else {
        gtr_msg.ground_truth_theta_e_deg = static_cast<uint16_t>(motor_orientation_e_deg);
    }
    
    // Send message to firmware
    Base::CANframe data_msg;
    read_gt_rpm_message(data_msg, gtr_msg);
}
```

This code:
1. Extracts motor speed and orientation from the motor simulation
2. Applies the correct sign based on motor position
3. Converts from radians to degrees for orientation
4. Creates and sends a `GroundTruthRpm` message

## 6. Main Simulation Execution Flow

The main simulation execution flow is implemented in the `run_esc.cpp` file.

### 6.1 Initialization

```cpp
// Load the firmware
std::string firmware_path = argv[1];
InstanceData esc_0;
OpenLib(esc_0, firmware_path.c_str(), RTLD_LAZY | RTLD_DEEPBIND);

// Initialize the firmware
const int node_id = 10;
FirmwareInitData init_data_0 = {
    node_id,  // Node ID
    { /* hash */ },
    { /* UID */ },
    { /* LRU */ },
    { /* PCB */ }
};
esc_0.pfirmware->Init(init_data_0);
```

This code:
1. Loads the ESC firmware from a shared library
2. Creates a `FirmwareInitData` structure with the node ID and other parameters
3. Initializes the firmware with the provided data

### 6.2 Message Setup

```cpp
// Create RPM command messages
vsdk_message_adn_vehicle_controlsystem_MotorRpmCommand_0_1 rpm_command_pr{};
vsdk_message_adn_vehicle_controlsystem_RecoveryMotorRpmCommand_0_1 rpm_command_re{};

// Set RPM command parameters
rpm_command_pr.rpm_commands[node_id-10] = 2000;
rpm_command_pr.motor_state_request.arm_intent = vsdk_message_adn_vehicle_controlsystem_MotorStateRequest_0_1_kArmIntentDisarmed;
rpm_command_pr.motor_state_request.enable_intent = vsdk_message_adn_vehicle_controlsystem_MotorStateRequest_0_1_kEnableIntentAllMotorsEnabled;
rpm_command_pr.motor_state_request.disabled_motor = vsdk_message_adn_vehicle_controlsystem_MotorStateRequest_0_1_kDisabledMotorNone;

rpm_command_re.rpm_command = 2000;
rpm_command_re.motor_state_request.arm_intent = vsdk_message_adn_vehicle_controlsystem_MotorStateRequest_0_1_kArmIntentDisarmed;
rpm_command_re.motor_state_request.enable_intent = vsdk_message_adn_vehicle_controlsystem_MotorStateRequest_0_1_kEnableIntentAllMotorsEnabled;
rpm_command_re.motor_state_request.disabled_motor = vsdk_message_adn_vehicle_controlsystem_MotorStateRequest_0_1_kDisabledMotorNone;
rpm_command_re.motor_state_request.source = vsdk_message_adn_vehicle_controlsystem_MotorStateRequest_0_1_kSourceRecoveryLane;

// Create ground truth state message
vsdk_message_adn_simulation_GroundTruthState_0_1 ground_truth_state {};
ground_truth_state.motor_center_right_prop_torque_Nm = 1;
ground_truth_state.motor_rear_right_prop_torque_Nm = 1;
ground_truth_state.motor_front_right_prop_torque_Nm = 1;
ground_truth_state.motor_center_left_prop_torque_Nm = 1;
ground_truth_state.motor_rear_left_prop_torque_Nm = 1;
ground_truth_state.motor_front_left_prop_torque_Nm = 1;
```

This code:
1. Creates RPM command messages for primary and recovery channels
2. Sets RPM command parameters (target RPM, arm state, enable state)
3. Creates a ground truth state message with motor torque values

### 6.3 Main Simulation Loop

```cpp
uint64_t next_execute_ns = 0;
static const int n_time_steps = 20000;
MessageData recv_msg_mp;
MessageData recv_msg_gtrpm;
MessageData recv_msg;
bool received_mp = false;
bool received_gtrpm = false;

for (int i = 0; i < n_time_steps; i++) {
    // Update RPM commands halfway through simulation
    if (i >= n_time_steps/2) {
        rpm_command_pr.motor_state_request.arm_intent = vsdk_message_adn_vehicle_controlsystem_MotorStateRequest_0_1_kArmIntentArmed;
        rpm_command_re.motor_state_request.arm_intent = vsdk_message_adn_vehicle_controlsystem_MotorStateRequest_0_1_kArmIntentArmed;
        rpm_command_pr.rpm_commands[node_id-10] = 4000;
        rpm_command_re.rpm_command = 4000;
    }
    
    // Send ground truth state at specific time step
    if (i == 8000) {
        esc_0.pfirmware->PutMessage(msg_gts_packed);
    }
    
    // Send RPM commands periodically
    if (0 == (i % 10)) {
        // Serialize and send primary RPM command
        vsdk_message_adn_vehicle_controlsystem_MotorRpmCommand_0_1_serialize_(&rpm_command_pr, rpm_command_buffer_pr, &serialized_size_pr);
        msg_pri = PackConcreteCyphalIntoMessageData(
            rpm_command_buffer_pr, vsdk_message_adn_vehicle_controlsystem_MotorRpmCommand_0_1_EXTENT_BYTES_, 184, 24, false, kTransportStabA);
        
        // Serialize and send recovery RPM command
        vsdk_message_adn_vehicle_controlsystem_RecoveryMotorRpmCommand_0_1_serialize_(&rpm_command_re, rpm_command_buffer_re, &serialized_size_re);
        msg_rec = PackConcreteCyphalIntoMessageData(
            rpm_command_buffer_re, vsdk_message_adn_vehicle_controlsystem_MotorRpmCommand_0_1_EXTENT_BYTES_, 240 + (node_id - 10), 31, false, kTransportStabB);
        
        esc_0.pfirmware->PutMessage(msg_pri);
        esc_0.pfirmware->PutMessage(msg_rec);
    }
    
    // Execute simulation step
    if (!esc_0.pfirmware->ExecuteAndScheduleNextExecutionInNs(next_execute_ns)) {
        std::cout << "ExecuteAndScheduleNextExecutionInNs returned false" << std::endl;
        return -1;
    }
    assert(next_execute_ns == 1000000U);  // 1ms simulation step expected
    
    // Receive messages from firmware
    auto recv_ret = esc_0.pfirmware->GetMessage(recv_msg);
    if (recv_ret && (recv_msg.port_id == 421)) {
        // Motor performance message
        recv_msg_mp = recv_msg;
        received_mp = true;
    } else if (recv_ret && (recv_msg.port_id == (990 + node_id))) {
        // Ground truth RPM message
        recv_msg_gtrpm = recv_msg;
        received_gtrpm = true;
    } else if (recv_ret == false) {
        received_gtrpm = false;
    }
    
    // Deserialize and print motor performance
    vsdk_message_adn_vehicle_propulsionsystem_MotorPerformance_0_1 motorperformance;
    vsdk_message_adn_vehicle_propulsionsystem_MotorPerformance_0_1_initialize_(&motorperformance);
    size_t mp_serialized_size = recv_msg_mp.serialized_payload.size();
    vsdk_message_adn_vehicle_propulsionsystem_MotorPerformance_0_1_deserialize_(&motorperformance, recv_msg_mp.serialized_payload.data(), &mp_serialized_size);
    
    // Deserialize and print ground truth RPM
    vsdk_message_adn_simulation_propulsionsystem_GroundTruthRpm_0_1 gtrpm;
    vsdk_message_adn_simulation_propulsionsystem_GroundTruthRpm_0_1_initialize_(&gtrpm);
    size_t gtrpm_serialized_size = recv_msg_gtrpm.serialized_payload.size();
    vsdk_message_adn_simulation_propulsionsystem_GroundTruthRpm_0_1_deserialize_(&gtrpm, recv_msg_gtrpm.serialized_payload.data(), &gtrpm_serialized_size);
    
    // Print simulation state
    std::cout << "Time step : " << i << std::endl;
    std::cout << "CAN Node ID: " << motorperformance.can_node_id << std::endl;
    std::cout << "Commanded RPM: " << motorperformance.commanded_rpm << std::endl;
    std::cout << "Measured RPM: " << motorperformance.measured_rpm << std::endl;
    std::cout << "Input Current (cA): " << motorperformance.input_current_cA << std::endl;
    std::cout << "Input Voltage (dV): " << motorperformance.input_voltage_dV << std::endl;
    std::cout << "Commanded IQ (mA): " << motorperformance.commanded_iq_mA << std::endl;
    std::cout << "Measured IQ (mA): " << motorperformance.measured_iq_mA << std::endl;
    std::cout << "Faults value: " << static_cast<int>(motorperformance.state.health.alerts_bitpacked_[node_id-10]) << std::endl;
    std::cout << "Ground Truth RPM: " << gtrpm.ground_truth_rpm << std::endl;
    std::cout << "\n" << std::endl;
}
```

This code:
1. Runs the simulation for a fixed number of time steps
2. Updates RPM commands halfway through the simulation
3. Sends ground truth state at a specific time step
4. Sends RPM commands periodically
5. Executes the simulation step
6. Receives and processes messages from the firmware
7. Deserializes and prints motor performance and ground truth RPM data

## 7. Error Handling and Safety Mechanisms

The SIL framework implements several error handling and safety mechanisms.

### 7.1 Execution Error Handling

The `ExecuteAndScheduleNextExecutionInNs()` method returns a boolean indicating success or failure:

```cpp
if (!esc_0.pfirmware->ExecuteAndScheduleNextExecutionInNs(next_execute_ns)) {
    std::cout << "ExecuteAndScheduleNextExecutionInNs returned false" << std::endl;
    return -1;
}
```

If execution fails, the simulation is terminated with an error code.

### 7.2 Message Validation

Messages are validated before processing:

```cpp
if (vsdk_message_adn_simulation_GroundTruthState_0_1_deserialize_(&gts_msg, msg.serialized_payload.data(), &gts_serialized_size) != 0) {
    return false;
}
```

If deserialization fails, the message is rejected.

### 7.3 Spin Direction Handling

The simulation accounts for different motor spin directions:

```cpp
const int16_t spin_direction_tq_sign = (is_spin_direction_positive(init_data_.node_id) ? -1 : 1);

// Apply correct sign based on motor position
if (is_spin_direction_positive(init_data_.node_id)) {
    gtr_msg.ground_truth_rpm = motor_speed_rpm;
} else {
    gtr_msg.ground_truth_rpm = motor_speed_rpm * -1;
}
```

This ensures that torque and RPM values have the correct sign based on the motor's position in the vehicle.

## 8. Conclusion

The Software-in-the-Loop (SIL) simulation framework provides a comprehensive environment for testing Electronic Speed Controllers (ESCs) in a closed-loop configuration. The framework integrates:

1. A firmware simulation interface that provides standardized methods for lifecycle management and data exchange
2. An ESC simulation block that models the behavior of the dual-core ESC firmware
3. A motor simulation that provides a physics-based model of the BLDC motor
4. Cyphal message processing for communication between components
5. A main simulation loop that orchestrates the interaction between these components

The closed-loop architecture allows for realistic testing of ESC firmware by simulating the complete feedback loop between the ESC and the motor. This enables validation of control algorithms, fault detection mechanisms, and performance characteristics in a controlled environment before deployment on actual hardware.

## Referenced Context Files

The following context files provided valuable insights for understanding the SIL simulation framework:

1. `07_Motor_Controller_Architecture.md`: Provided context on the dual-core architecture of the motor controller, which is simulated in the `Esc_sil_block` class.

2. `05_Field_Oriented_Control.md`: Provided context on the field-oriented control algorithm implemented in the motor controller, which is a key component of the ESC simulation.

3. `04_Protection_Systems.md`: Provided context on the protection systems implemented in the motor controller, which are simulated in the SIL framework.