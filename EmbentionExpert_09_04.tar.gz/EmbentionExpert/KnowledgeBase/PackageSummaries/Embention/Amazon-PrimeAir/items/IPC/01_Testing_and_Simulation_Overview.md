# Generated from:

- PackageSummaries/Amazon-PrimeAir/items/IPC/02_Software_In_The_Loop_Simulation.md (8504 tokens)

---

# Software-in-the-Loop (SIL) Simulation Framework for ESC Testing

## 1. Overview and Purpose

The Software-in-the-Loop (SIL) simulation framework provides a comprehensive virtual environment for testing Electronic Speed Controller (ESC) firmware without requiring physical hardware. This framework enables closed-loop testing of the complete motor control system by simulating both the ESC firmware and the physical behavior of brushless DC (BLDC) motors.

The primary purposes of the SIL framework are:

1. **Development and Testing**: Allows developers to test ESC firmware in a controlled environment before deployment on physical hardware
2. **Validation**: Enables validation of control algorithms, fault detection mechanisms, and performance characteristics
3. **Regression Testing**: Provides a platform for automated testing to ensure code changes don't introduce regressions
4. **Scenario Testing**: Facilitates testing of edge cases and failure modes that might be difficult or dangerous to test with physical hardware

## 2. System Architecture

The SIL framework implements a closed-loop architecture with several key components:

### 2.1 Core Components

```
┌─────────────────────────────────────────────────────────────────┐
│                      SIL Simulation Framework                   │
│                                                                 │
│  ┌───────────────┐        Cyphal Messages        ┌────────────┐ │
│  │               │◄──────────────────────────────┤            │ │
│  │  ESC Firmware │                              │  External   │ │
│  │  Simulation   │──────────────────────────────►│  Systems   │ │
│  │               │                              │            │ │
│  └───────┬───────┘                              └────────────┘ │
│          │                                                     │
│          │ PWM Signals                                         │
│          ▼                                                     │
│  ┌───────────────┐        Feedback Signals       ┌────────────┐ │
│  │               │◄──────────────────────────────┤            │ │
│  │  Motor        │                              │  Ground     │ │
│  │  Physics      │──────────────────────────────►│  Truth     │ │
│  │  Simulation   │                              │  State      │ │
│  │               │                              │            │ │
│  └───────────────┘                              └────────────┘ │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

1. **ESC Firmware Simulation**: Executes the actual ESC firmware code in a simulated environment
   - Implemented through the `Esc_sil_block` class
   - Simulates the dual-core architecture of the ESC
   - Processes inputs and generates PWM outputs

2. **Motor Physics Simulation**: Simulates the physical behavior of BLDC motors
   - Implemented through the Amazon ESC simulation interface (`amzn::esc::sim::Interface`)
   - Models electrical, mechanical, and thermal characteristics
   - Responds to PWM inputs and generates appropriate feedback signals

3. **Ground Truth State**: Provides reference information about the simulated system
   - Contains comprehensive state information about the vehicle and motors
   - Used to validate the behavior of the ESC firmware

4. **External Systems**: Simulate other components that interact with the ESC
   - Generate RPM commands
   - Process motor performance data
   - Simulate vehicle dynamics

### 2.2 Communication Interfaces

The components communicate through several interfaces:

1. **Cyphal Messages**: Standardized messages for high-level communication
   - `GroundTruthState`: Vehicle and motor state information
   - `MotorRpmCommand`: RPM commands for motors
   - `RecoveryMotorRpmCommand`: Recovery RPM commands
   - `MotorPerformance`: Motor performance metrics
   - `GroundTruthRpm`: Ground truth RPM information

2. **Direct Signal Exchange**: Low-level signals between ESC and motor
   - PWM signals from ESC to motor
   - Current, voltage, and position feedback from motor to ESC

## 3. Firmware Simulation Interface

The firmware simulation interface provides a standardized way to interact with the ESC firmware in a simulation environment.

### 3.1 Interface Hierarchy

The interface is structured as a hierarchy of classes:

```
┌─────────────────────────┐
│ FirmwareSimulationLifeCycle │
└───────────────┬─────────┘
                │
┌───────────────▼─────────┐
│ FirmwareSimulationDataExchange │
└───────────────┬─────────┘
                │
┌───────────────▼─────────┐
│   FirmwareSimulation    │
└───────────────┬─────────┘
                │
┌───────────────▼─────────┐
│      Esc_sim           │
└─────────────────────────┘
```

- `FirmwareSimulationLifeCycle`: Defines methods for managing the firmware's lifecycle
- `FirmwareSimulationDataExchange`: Defines methods for exchanging messages
- `FirmwareSimulation`: Combines both interfaces
- `Esc_sim`: Concrete implementation for ESC simulation

### 3.2 Key Interface Methods

The interface defines several key methods:

```cpp
// Lifecycle management
bool Init(const FirmwareInitData & init_data);
bool ExecuteAndScheduleNextExecutionInNs(uint64_t & interval_ns);
void Reset();
std::string GetErrorString();

// Data exchange
bool PutMessage(const MessageData &msg);
bool GetMessage(MessageData &msg);
```

These methods allow:
- Initializing the firmware with configuration data
- Executing the firmware and scheduling the next execution
- Resetting the firmware to its initial state
- Exchanging messages with the firmware

## 4. ESC Simulation Implementation

The ESC simulation is implemented in the `Esc_sil_block` class, which models the behavior of the dual-core ESC firmware.

### 4.1 Dual-Core Architecture Simulation

The ESC simulation models the dual-core architecture of the actual ESC hardware:

```
┌───────────────────────────────────────────────────────┐
│                   Esc_sil_block                       │
│                                                       │
│  ┌───────────────────┐       ┌───────────────────┐    │
│  │                   │       │                   │    │
│  │  Core 1 (CIO)     │       │  Core 2 (C2)      │    │
│  │  - I/O Processing │       │  - Control Logic  │    │
│  │  - Sensor Reading │       │  - FOC Algorithm  │    │
│  │  - Communication  │       │  - Protection     │    │
│  │                   │       │                   │    │
│  └───────────────────┘       └───────────────────┘    │
│                                                       │
└───────────────────────────────────────────────────────┘
```

- **Core 1 (CIO)**: Handles I/O processing, sensor reading, and communication
- **Core 2 (C2)**: Implements control logic, Field-Oriented Control (FOC) algorithm, and protection systems

### 4.2 Task Scheduling

The ESC simulation implements a multi-rate task scheduler that mimics the real-time behavior of the ESC firmware:

```cpp
struct Min_task {
    Base::Sil_data::Task_id task;    // Task ID
    Base::Ttime time;                // Associated time
};
```

Four main tasks are scheduled:
1. `cio_hi`: High-priority CIO task (1kHz)
2. `cio_lo`: Low-priority CIO task (1kHz)
3. `c2_hi`: High-priority C2 task (1kHz)
4. `c2_lo`: Low-priority C2 task (1kHz)

The scheduler determines which task to execute next based on their scheduled execution times, simulating the real-time behavior of the ESC firmware.

### 4.3 Main Execution Flow

The main execution flow is implemented in the `step()` method:

1. Convert simulation time to microseconds
2. Set ADC inputs from the motor simulation
3. Execute tasks until the current simulation time
4. Update PWM outputs for the motor simulation
5. Return the time of the next scheduled task

This approach ensures that the ESC simulation behaves like the real ESC firmware, executing tasks at the appropriate times and responding to inputs from the motor simulation.

## 5. Motor Physics Simulation

The motor simulation is implemented using the Amazon ESC simulation interface (`amzn::esc::sim::Interface`), which provides a physics-based model of BLDC motors.

### 5.1 Motor Model Components

The motor model includes several components:

```
┌───────────────────────────────────────────────────────┐
│                   Motor Simulation                    │
│                                                       │
│  ┌───────────────────┐       ┌───────────────────┐    │
│  │                   │       │                   │    │
│  │  Electrical Model │       │  Mechanical Model │    │
│  │  - Back EMF       │       │  - Inertia       │    │
│  │  - Phase Currents │       │  - Friction      │    │
│  │  - Inductance     │       │  - Load Torque   │    │
│  │                   │       │                   │    │
│  └───────────────────┘       └───────────────────┘    │
│                                                       │
│  ┌───────────────────┐       ┌───────────────────┐    │
│  │                   │       │                   │    │
│  │  Thermal Model    │       │  Fault Model      │    │
│  │  - Motor Temp     │       │  - Short Circuits │    │
│  │  - Inverter Temp  │       │  - Open Circuits  │    │
│  │  - Heat Transfer  │       │  - Sensor Faults  │    │
│  │                   │       │                   │    │
│  └───────────────────┘       └───────────────────┘    │
│                                                       │
└───────────────────────────────────────────────────────┘
```

1. **Electrical Model**: Simulates the electrical behavior of the motor
   - Back EMF generation
   - Phase currents
   - Inductance and resistance

2. **Mechanical Model**: Simulates the mechanical behavior of the motor
   - Moment of inertia
   - Friction
   - Load torque

3. **Thermal Model**: Simulates the thermal behavior of the motor
   - Motor temperature
   - Inverter temperature
   - Heat transfer

4. **Fault Model**: Simulates various fault conditions
   - Short circuits
   - Open circuits
   - Sensor faults

### 5.2 Motor Simulation Interface

The motor simulation interface defines structures for configuration, commands, and state:

```cpp
class Interface {
public:
    struct VectorABC { float a; float b; float c; };
    
    struct Configuration {
        enum Id { kIdUnknown, kIdCustom, kIdCX3Typhoon, kIdCX3Bloc10FullSim };
        Id id;
        float dt_s;
        struct Motor { /* Motor parameters */ };
        struct LeadWire { /* Lead wire parameters */ };
        struct Inverter { /* Inverter parameters */ };
        struct DcLink { /* DC link parameters */ };
        struct Supply { /* Power supply parameters */ };
        struct Pcba { /* PCBA parameters */ };
    };
    
    struct Command {
        struct Electrical {
            bool inverter_enable;
            VectorABC motor_abc_V;
            float supply_V;
        } electrical;
        
        struct Mechanical {
            float J_kg_m2;
            float k0_N_m;
            float k1_N_m_s_per_rad;
            float k2_N_m_s2_per_rad2;
        } mechanical;
        
        struct Thermal {
            float ambient_degC;
            float motor_C_W_per_K;
            float inverter_C_W_per_K;
        } thermal;
        
        enum Fault { kFaultNone } active_fault;
    };
    
    struct StateObservable {
        VectorABC motor_abc_A;
        float dc_link_A;
        float dc_link_V;
        VectorABC inverter_abc_degC;
        float motor_degC;
    };
    
    struct StateHidden {
        float motor_mech_theta_pirad;
        float motor_mech_omega_rad_per_s;
        float motor_elec_theta_pirad;
        float motor_elec_omega_rad_per_s;
        VectorABC motor_back_emf_abc_V;
    };
    
    struct State {
        StateObservable ideal;
        StateObservable measured;
        StateHidden hidden;
        uint64_t iteration;
    };
    
    virtual const Configuration & AccessConfiguration() const = 0;
    virtual bool IsConfigured() const = 0;
    virtual Command & UpdateCommand() = 0;
    virtual void Step() = 0;
    virtual const State & AccessState() const = 0;
    virtual bool SupportsFault(Command::Fault fault) const = 0;
    virtual ~Interface(){};
};
```

This interface provides methods for:
- Accessing motor configuration
- Updating motor commands
- Stepping the motor simulation
- Accessing motor state
- Checking fault support

### 5.3 Closed-Loop Integration

The motor simulation is integrated with the ESC simulation in a closed-loop configuration:

1. The ESC simulation generates PWM outputs based on its control algorithm
2. The motor simulation receives these PWM outputs as inputs
3. The motor simulation updates its state based on these inputs and its internal model
4. The motor simulation generates feedback signals (currents, voltages, position)
5. The ESC simulation receives these feedback signals as inputs
6. The cycle repeats

This closed-loop integration allows for realistic testing of the ESC firmware by simulating the complete feedback loop between the ESC and the motor.

## 6. Cyphal Message Communication

The SIL framework uses Cyphal messages for communication between components.

### 6.1 Key Message Types

1. **GroundTruthState**: Contains comprehensive state information about the vehicle and motors
   - Motor torques
   - Air density and temperature
   - Vehicle velocities

2. **MotorRpmCommand**: Contains RPM commands for motors
   - RPM setpoints
   - Arm/disarm state
   - Enable/disable state

3. **RecoveryMotorRpmCommand**: Contains recovery RPM commands
   - RPM setpoint
   - Arm/disarm state
   - Enable/disable state
   - Source information

4. **MotorPerformance**: Contains motor performance metrics
   - Commanded and measured RPM
   - Input current and voltage
   - Commanded and measured IQ
   - Health state

5. **GroundTruthRpm**: Contains ground truth RPM information
   - Actual motor RPM
   - Electrical angle

### 6.2 Message Flow

The message flow in the SIL framework follows this pattern:

```
┌───────────────┐     GroundTruthState     ┌───────────────┐
│               │◄─────────────────────────┤               │
│  ESC          │                         │  External      │
│  Simulation   │     MotorRpmCommand      │  Systems      │
│               │◄─────────────────────────┤               │
│               │                         │               │
│               │     MotorPerformance     │               │
│               ├─────────────────────────►│               │
│               │                         │               │
│               │     GroundTruthRpm       │               │
│               ├─────────────────────────►│               │
└───────────────┘                         └───────────────┘
```

1. External systems send `GroundTruthState` and `MotorRpmCommand` messages to the ESC simulation
2. The ESC simulation processes these messages and updates its internal state
3. The ESC simulation sends `MotorPerformance` and `GroundTruthRpm` messages back to external systems
4. External systems use these messages to monitor the behavior of the ESC

## 7. Simulation Execution Flow

The main simulation execution flow is implemented in the `run_esc.cpp` file.

### 7.1 Initialization

The simulation is initialized with the following steps:

1. Load the ESC firmware from a shared library
2. Create a `FirmwareInitData` structure with the node ID and other parameters
3. Initialize the firmware with the provided data
4. Create and initialize message structures for communication

### 7.2 Main Simulation Loop

The main simulation loop executes the following steps:

1. Update RPM commands based on the current simulation time
2. Send ground truth state at specific time steps
3. Send RPM commands periodically
4. Execute the simulation step
5. Receive and process messages from the firmware
6. Deserialize and process motor performance and ground truth RPM data
7. Print simulation state for monitoring
8. Repeat for the specified number of time steps

This loop simulates the behavior of the ESC firmware over time, allowing for observation of its response to different inputs and conditions.

## 8. Testing and Validation Capabilities

The SIL framework provides several capabilities for testing and validating the ESC firmware:

### 8.1 Functional Testing

The framework allows for testing of the ESC firmware's basic functionality:

- Motor control algorithm (Field-Oriented Control)
- RPM tracking
- Current and voltage regulation
- Sensor processing

### 8.2 Performance Testing

The framework enables evaluation of the ESC firmware's performance:

- RPM tracking accuracy
- Current control accuracy
- Response time to command changes
- Efficiency under different loads

### 8.3 Fault Injection and Recovery Testing

The framework supports testing of the ESC firmware's response to fault conditions:

- Over-current protection
- Over-voltage protection
- Over-temperature protection
- Sensor failure handling
- Communication loss handling

### 8.4 Environmental Condition Testing

The framework allows for testing under different environmental conditions:

- Different ambient temperatures
- Different load conditions
- Different power supply voltages
- Different airflow conditions

## 9. Benefits of the SIL Approach

The SIL approach offers several benefits for development, testing, and validation of the drone propulsion system:

### 9.1 Development Benefits

1. **Faster Development Cycles**: Developers can test changes without needing physical hardware
2. **Reduced Hardware Dependency**: Development can proceed even when hardware is unavailable
3. **Parallel Development**: Multiple developers can work on different aspects of the system simultaneously
4. **Early Integration Testing**: Integration issues can be identified and resolved earlier in the development process

### 9.2 Testing Benefits

1. **Comprehensive Testing**: The framework allows for testing of a wide range of scenarios
2. **Reproducible Tests**: Tests can be repeated with exactly the same inputs and conditions
3. **Automated Testing**: Tests can be automated and run as part of a continuous integration pipeline
4. **Edge Case Testing**: Extreme conditions that might be difficult or dangerous to test with physical hardware can be safely tested

### 9.3 Validation Benefits

1. **Systematic Validation**: The framework enables systematic validation of the ESC firmware against requirements
2. **Performance Optimization**: The impact of parameter changes on performance can be evaluated quickly
3. **Algorithm Comparison**: Different control algorithms can be compared under identical conditions
4. **Regression Prevention**: Changes can be validated to ensure they don't introduce regressions

## 10. Conclusion

The Software-in-the-Loop (SIL) simulation framework provides a comprehensive environment for testing Electronic Speed Controllers (ESCs) in a closed-loop configuration. By simulating both the ESC firmware and the physical behavior of BLDC motors, the framework enables realistic testing without requiring physical hardware.

The framework's key strengths include:

1. **High Fidelity**: The simulation accurately models the behavior of both the ESC firmware and the motor physics
2. **Closed-Loop Testing**: The framework enables testing of the complete feedback loop between the ESC and the motor
3. **Comprehensive Messaging**: The use of Cyphal messages allows for realistic communication between components
4. **Flexible Configuration**: The framework supports different motor models and ESC configurations
5. **Fault Injection**: The framework allows for testing of the ESC firmware's response to fault conditions

These capabilities make the SIL framework an invaluable tool for development, testing, and validation of the drone propulsion system, enabling faster development cycles, more comprehensive testing, and more systematic validation.