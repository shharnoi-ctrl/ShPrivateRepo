# Generated from:

- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/source/Sysuid_cpu1_amz.cpp (2542 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/source/cpu2/Sysuid_mc_c2.cpp (42 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/source_SIL/Sysuid.cpp (117 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/source_SIL/Uid_impl.cpp (34 tokens)

## With context from:

- PackageSummaries/Amazon-PrimeAir/items/IPC/03_Hardware_Abstraction_Layer.md (3426 tokens)

---

# System Identification Mechanisms Analysis

This analysis provides a comprehensive examination of the system identification mechanisms in the motor controller software, focusing on hardware version detection, node ID determination, and unique identifier (UID64) construction.

## 1. Unique Identifier (UID64) Structure and Generation

The system uses a 64-bit unique identifier (UID64) that combines multiple identification elements:

### 1.1 UID64 Structure

The `Uid64` structure contains three main components:
- `app`: Application type identifier (e.g., `Bsp::sapp_mc_ipc`)
- `hwv`: Hardware version identifier (e.g., `MCxx::v_mc_ipc`)
- `phy`: Physical node ID (derived from GPIO pins)

### 1.2 UID64 Generation Process

The `Bsp::get_uid()` function retrieves the system's unique identifier:

```cpp
Uid64 get_uid(bool force_read = false)
{
    static Uid64 otp_uid = get_uid_aux();
    if (force_read)
    {
        otp_uid = get_uid_aux();
    }
    return otp_uid;
}
```

Key characteristics:
- The UID is cached statically for performance
- The `force_read` parameter allows refreshing the cached value
- The actual generation happens in the `get_uid_aux()` function

### 1.3 UID64 Generation Implementation

The `get_uid_aux()` function constructs the UID64 by:
1. Creating an empty `Uid64` structure initialized to zero
2. Setting the application type to `Bsp::sapp_mc_ipc`
3. Setting the hardware version to `MCxx::v_mc_ipc`
4. Setting the physical node ID by calling `get_node_id()`
5. Returning the constructed UID64

```cpp
Uid64 get_uid_aux()
{
    Uid64 otp_uid = { 0 };
    otp_uid.app = Bsp::sapp_mc_ipc;
    otp_uid.hwv = MCxx::v_mc_ipc;
    otp_uid.phy = get_node_id();
    return otp_uid;
}
```

### 1.4 SIL (Software-In-the-Loop) Implementation

In the SIL environment, the UID generation is simplified:
- The physical ID is hardcoded to 12345
- The application type is still set to `sapp_mc_ipc`
- No hardware version is explicitly set

```cpp
// SIL implementation
Uid64 get_uid_aux()
{
    Uid64 otp_uid;
    otp_uid.phy = 12345;
    otp_uid.app = static_cast<Uint64>(sapp_mc_ipc);
    return otp_uid;
}
```

## 2. Node ID Determination

The node ID is a critical component that identifies the ESC's position in the drone. It is determined through GPIO pin readings.

### 2.1 GPIO Pin Configuration for Position Identification

Three GPIO pins are used to identify the ESC position:
```cpp
static const Uint32 n_pos_ids = 3U; // Number of position identification bits
static const Base::Tnarray<Dsp28335_ent::GPIOid, n_pos_ids> pos_ids =
{
    Dsp28335_ent::gpio_016,
    Dsp28335_ent::gpio_017,
    Dsp28335_ent::gpio_018
};
```

### 2.2 GPIO Pin Configuration for Board Identification

Four GPIO pins are used to identify the board type:
```cpp
static const Uint32 n_brd_ids = 4U; // Number of board identification bits
static const Base::Tnarray<Dsp28335_ent::GPIOid, n_brd_ids> brd_ids =
{
    Dsp28335_ent::gpio_011,
    Dsp28335_ent::gpio_013,
    Dsp28335_ent::gpio_014,
    Dsp28335_ent::gpio_015
};
```

### 2.3 GPIO Value Reading Mechanism

The `get_value_from_gpio()` function reads a set of GPIO pins and combines them into a single integer value:

```cpp
Uint16 get_value_from_gpio(const Base::Mblock<const Dsp28335_ent::GPIOid>& gpios)
{
    Uint16 val = 0U;
    for(Uint16 i = 0; i < gpios.sz; ++i)
    {
        val |= (static_cast<Uint16>(Dsp28335_ent::GPIO(gpios.v[i]).get()) << i);
    }
    return val;
}
```

Key aspects:
- Reads each GPIO pin in the provided array
- Shifts each bit to its appropriate position (LSB to MSB)
- Combines the bits using bitwise OR operations
- Returns the combined value as a 16-bit unsigned integer

### 2.4 Node ID Determination Process

The `get_node_id()` function determines the node ID based on the GPIO pin readings:

1. First checks if the board is an IPC board by comparing the board ID with `brd_id_cx3_dv_blk20` (value 8)
2. If it is an IPC board, sets `is_ipc_board` to true in shared memory
3. Initializes the node ID to `MCxx::Ipc_ids::node_id_rr_a` (Right Rear position)
4. Reads the position value from the position identification GPIO pins
5. If the board is an IPC board, maps the position value to the appropriate node ID and ESC position

```cpp
Uint16 get_node_id()
{
    using namespace MCxx;
    
    if(get_value_from_gpio(brd_ids.to_mblock()) == brd_id_cx3_dv_blk20)
    {
        get_c1_sh_mem().is_ipc_board = true;
    }
    
    Uint16 node_id = Ipc_ids::node_id_rr_a;
    const Ipc_ids::Pos pos_val = static_cast<Ipc_ids::Pos>(get_value_from_gpio(pos_ids.to_mblock()));
    
    if(get_c1_sh_mem().is_ipc_board)
    {
        switch(pos_val)
        {
            case Ipc_ids::rr:
                get_c1_sh_mem().curr_esc_id = Ipc_ids::kRightRear;
                node_id = Ipc_ids::node_id_rr_a;
                break;
            case Ipc_ids::cr:
                get_c1_sh_mem().curr_esc_id = Ipc_ids::kRightCenter;
                node_id = Ipc_ids::node_id_rr_a + Ku16::u1;
                break;
            case Ipc_ids::fr:
                get_c1_sh_mem().curr_esc_id = Ipc_ids::kRightFront;
                node_id = Ipc_ids::node_id_rr_a + Ku16::u2;
                break;
            case Ipc_ids::fl:
                get_c1_sh_mem().curr_esc_id = Ipc_ids::kLeftFront;
                node_id = Ipc_ids::node_id_rr_a + Ku16::u3;
                break;
            case Ipc_ids::cl:
                get_c1_sh_mem().curr_esc_id = Ipc_ids::kLeftCenter;
                node_id = Ipc_ids::node_id_rr_a + Ku16::u4;
                break;
            case Ipc_ids::rl:
                get_c1_sh_mem().curr_esc_id = Ipc_ids::kLeftRear;
                node_id = Ipc_ids::node_id_rr_a + Ku16::u5;
                break;
            default:
                Bsp::warning();
                break;
        }
    }
    
    return node_id;
}
```

## 3. ESC Position Mapping

The system maps GPIO pin combinations to specific ESC positions in the drone:

### 3.1 Position Enumeration

The `MCxx::Ipc_ids::Pos` enumeration defines the possible ESC positions:
- `rr`: Right Rear
- `cr`: Right Center
- `fr`: Right Front
- `fl`: Left Front
- `cl`: Left Center
- `rl`: Left Rear

### 3.2 Position to Node ID Mapping

The node ID is calculated by adding an offset to the base node ID (`node_id_rr_a`):
- Right Rear: `node_id_rr_a` (base value, no offset)
- Right Center: `node_id_rr_a + 1`
- Right Front: `node_id_rr_a + 2`
- Left Front: `node_id_rr_a + 3`
- Left Center: `node_id_rr_a + 4`
- Left Rear: `node_id_rr_a + 5`

### 3.3 Position to ESC ID Mapping

The ESC ID is stored in shared memory as an enumeration value:
- Right Rear: `Ipc_ids::kRightRear`
- Right Center: `Ipc_ids::kRightCenter`
- Right Front: `Ipc_ids::kRightFront`
- Left Front: `Ipc_ids::kLeftFront`
- Left Center: `Ipc_ids::kLeftCenter`
- Left Rear: `Ipc_ids::kLeftRear`

## 4. Cross-Core UID Sharing

The system shares the UID64 between CPU cores through shared memory:

### 4.1 CPU1 to CPU2 Sharing

CPU1 (Core 1) generates the UID64 and stores it in shared memory for CPU2 (Core 2) to access.

### 4.2 CPU2 Access Mechanism

CPU2 accesses the UID64 through the `get_uid_location()` function:

```cpp
volatile const Uid64& get_uid_location()
{
    return MCxx::get_c1_sh_mem().uid64;
}
```

This function returns a reference to the UID64 stored in the CPU1-owned shared memory, allowing CPU2 to access the same identifier without recalculating it.

## 5. Hardware Version Detection

While not directly shown in the provided files, the context file indicates that hardware version detection is performed through ADC readings:

### 5.1 ADC-Based Hardware Version Detection

1. The system reads an ADC channel (`hwversion_adc_ch`) to determine the hardware version
2. The ADC voltage is compared against reference values in a `ref_values` array
3. The detected hardware version is stored and shared with Core 2 through shared memory

### 5.2 Hardware Version Enumeration

The hardware versions are defined in the `HWversion_id` enumeration:
```cpp
enum HWversion_id {
    v_unknown,      // Unknown (not computed)
    v_mc_25,        // MC25
    v_mc_110,       // MC110
    v_mc_110_v2,    // MC110 v2
    v_mc_24,        // MC24
    v_mc_ipc        // MC for IPC
};
```

### 5.3 Hardware Version in UID64

The detected hardware version (`MCxx::v_mc_ipc` in the provided code) is incorporated into the UID64 structure as the `hwv` field.

## 6. System Identification Decision Tree

The complete system identification process follows this decision tree:

1. **Board Type Identification**:
   - Read 4 GPIO pins (gpio_011, gpio_013, gpio_014, gpio_015)
   - Determine if the board is an IPC board (value 8)
   - Set `is_ipc_board` flag in shared memory if applicable

2. **Position Identification**:
   - Read 3 GPIO pins (gpio_016, gpio_017, gpio_018)
   - Convert the reading to a position enumeration value

3. **Node ID Assignment**:
   - If not an IPC board, use default node ID
   - If an IPC board, map position to node ID using the switch statement
   - Store the corresponding ESC ID in shared memory

4. **Hardware Version Detection**:
   - Read ADC channel for hardware version
   - Compare with reference values
   - Determine hardware version

5. **UID64 Construction**:
   - Set application type (`app`)
   - Set hardware version (`hwv`)
   - Set physical node ID (`phy`)
   - Cache the result for future use

6. **Cross-Core Sharing**:
   - Store UID64 in shared memory
   - Provide access function for CPU2

## 7. Relationship Between Node ID and ESC Position

The system establishes a clear relationship between the node ID and the ESC's physical position in the drone:

| GPIO Value | Position Enum | ESC Position  | Node ID Offset | ESC ID in Shared Memory |
|------------|---------------|---------------|----------------|-------------------------|
| 0          | `rr`          | Right Rear    | 0              | `kRightRear`            |
| 1          | `cr`          | Right Center  | 1              | `kRightCenter`          |
| 2          | `fr`          | Right Front   | 2              | `kRightFront`           |
| 3          | `fl`          | Left Front    | 3              | `kLeftFront`            |
| 4          | `cl`          | Left Center   | 4              | `kLeftCenter`           |
| 5          | `rl`          | Left Rear     | 5              | `kLeftRear`             |

This mapping ensures that each ESC in the drone has a unique node ID that corresponds to its physical position, enabling proper coordination and control of the multi-ESC system.

## Referenced Context Files

The analysis incorporated information from:
- `03_Hardware_Abstraction_Layer.md`: Provided context about hardware version detection through ADC readings and the overall hardware abstraction architecture.