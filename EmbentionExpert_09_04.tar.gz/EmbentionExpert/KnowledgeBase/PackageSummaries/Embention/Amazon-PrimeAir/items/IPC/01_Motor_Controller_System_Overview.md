# Generated from:

- PackageSummaries/Amazon-PrimeAir/items/IPC/07_Motor_Controller_Architecture.md (2764 tokens)
- PackageSummaries/Amazon-PrimeAir/items/IPC/05_Shared_Memory_System.md (3254 tokens)
- PackageSummaries/Amazon-PrimeAir/items/IPC/04_IPC_Core_Components.md (3720 tokens)
- PackageSummaries/Amazon-PrimeAir/items/IPC/03_Hardware_Abstraction_Layer.md (3426 tokens)
- PackageSummaries/Amazon-PrimeAir/items/IPC/06_Motor_Control_State_Machine.md (4178 tokens)
- PackageSummaries/Amazon-PrimeAir/items/IPC/05_Field_Oriented_Control.md (7141 tokens)
- PackageSummaries/Amazon-PrimeAir/items/IPC/04_Protection_Systems.md (6243 tokens)
- PackageSummaries/Amazon-PrimeAir/items/IPC/03_Command_Input_Management.md (4750 tokens)
- PackageSummaries/Amazon-PrimeAir/items/IPC/03_Telemetry_and_Diagnostics.md (6048 tokens)

---

# Comprehensive Overview of the Motor Controller System

## 1. Dual-Core Architecture: Division of Responsibilities

The motor controller implements a sophisticated dual-core architecture using a TMS320F28335 DSP with two CPUs (CPU1 and CPU2) that work in tandem to manage different aspects of motor control:

### CPU1 (System Management Core)
- Handles communication interfaces (CAN, CAN-FD, SCI, SPI)
- Manages system status and maintenance modes
- Processes input commands with redundancy and failover capabilities
- Implements the Finite State Machine (FSM) that governs overall system operation
- Collects and transmits telemetry data
- Coordinates with CPU2 through shared memory

### CPU2 (Real-time Control Core)
- Executes high-frequency motor control algorithms (5kHz)
- Implements Field-Oriented Control (FOC) without encoder
- Manages PWM generation for motor phases
- Processes sensor data (SIN/COS position sensors)
- Handles ADC sampling for current and voltage measurements
- Implements protection systems for fault detection

This separation of responsibilities allows each core to focus on its specialized tasks, with CPU1 handling system-level operations and CPU2 dedicated to time-critical motor control functions.

## 2. Shared Memory System: Inter-Core Communication

The cores communicate through a structured shared memory system with clear ownership boundaries:

### Memory Ownership Model
- **CPU1-owned memory (C1_owned)**: CPU1 has read/write access, CPU2 has read-only access
- **CPU2-owned memory (C2_owned)**: CPU2 has read/write access, CPU1 has read-only access

### Variable Management System
The shared memory implements a sophisticated variable management system with three types of variables:
- **Bvar (Boolean Variables)**: Status flags, fault indicators, and system states
- **Uvar (Unsigned Integer Variables)**: Configuration parameters and state identifiers
- **Rvar (Real Variables)**: Measurements and control parameters

### Cross-Core FIFO Communication
A cross-core FIFO buffer mechanism enables efficient transfer of diagnostic data:
- CPU2 writes diagnostic data to `ffwr_diag`
- CPU1 reads diagnostic data from `ffrd_diag`
- This allows CPU2 to continuously record high-frequency diagnostic data (5kHz)

## 3. Hardware Abstraction Layer: Consistent Interface

The Hardware Abstraction Layer (HAL) provides a consistent interface to hardware components:

### Core 1 HAL (`Halsuite_mc`)
- Manages communication interfaces (CAN, SCI, SPI)
- Controls GPIO for status indicators
- Handles hardware version detection
- Configures system clocks and peripherals

### Core 2 HAL (`Halsuite_mc_ctrl`)
- Configures ADC for motor current and voltage sensing
- Manages PWM generation for motor control
- Handles sensor interfaces for position feedback
- Implements fault detection inputs

### Hardware Version Support
The system automatically detects and configures itself for different hardware variants:
- `v_mc_ipc`: IPC-enabled motor controller with Typhoon revision
- `v_mc_110_v2`: MC110 v2 hardware
- `v_mc_24`: MC24 hardware

## 4. State Machine: System Operation Management

The Finite State Machine (FSM) manages the operational states of the system:

### Primary State Hierarchy
- **init**: Initial power-up state
- **disarmed**: System initialized but not ready for operation
- **test**: Performing pre-operation tests
- **inactive**: System armed but not actively controlling motor
- **active**: System actively controlling motor
- **faulted**: System encountered critical fault

### Test Sequence State Machine
Within the `test` state, a nested state machine performs:
- **Ground Fault Detection**: Tests for insulation failures
- **Sin/Cos Alignment**: Calibrates position sensors with rotor
- **Sin/Cos Open Loop**: Validates sensor operation

### Motor Controller Interface States
The FSM manages the motor controller interface (MCI) state:
- **off**: PWM disabled
- **calibration**: Initial calibration mode
- **alignment**: Motor alignment mode
- **zero_current**: Zero current mode (windmill)
- **rpm**: Speed control mode

## 5. Field-Oriented Control: Precise Motor Control

The Field-Oriented Control (FOC) algorithm provides precise control of the Permanent Magnet Synchronous Motor:

### Control Transformations
- **Clarke Transformation**: Converts three-phase currents to two-phase stationary frame
- **Park Transformation**: Converts stationary frame to rotating reference frame
- **Inverse Park/Clarke**: Converts control outputs back to three-phase voltages

### Position and Speed Estimation
The system implements a sophisticated position estimation strategy:
- **Sliding Mode Observer**: Estimates back-EMF
- **Position Sensors**: SIN/COS sensors for direct position measurement
- **Observer Mixing**: Combines low and high-speed estimates based on operating range

### Current Control
- Implements d-q axis current controllers with anti-windup
- Applies Maximum Torque Per Ampere (MTPA) optimization
- Implements Space Vector PWM with third harmonic injection

## 6. Protection Systems: Safe Operation

The motor controller implements comprehensive protection systems:

### Fault Detection System
Monitors various parameters to detect abnormal conditions:
- AC/DC Overcurrent protection with multiple thresholds
- Overvoltage and undervoltage protection
- RMS current imbalance detection
- Position sensor error detection
- Ground fault detection

### Ground Fault Detection
Implements a dedicated state machine for detecting ground faults during startup:
- Takes measurements with and without grounding switch closed
- Compares measurements to detect insulation failures
- Coordinates testing between multiple ESCs

### Stall Detection and Management
Implements stall detection and recovery logic:
- Detects when motor is unable to rotate despite being commanded
- Implements progressive restart strategy
- Sets terminal fault after maximum restart attempts

### Temperature Monitoring
Provides temperature monitoring and protection:
- Monitors board, phase, and motor temperatures
- Implements overtemperature detection with configurable thresholds
- Controls cooling fan based on temperature

## 7. Command Input Management: Redundancy and Failover

The command input management system provides robust handling of control commands:

### Source Selection State Machine
Manages primary and recovery input sources:
- **st_nominal**: Primary source is active and present
- **st_loss_primary**: Primary source lost, deciding next action
- **st_wait_for_recovery**: Waiting for valid command from recovery
- **st_recovery**: Recovery source is providing commands
- **st_loss_comm**: Both sources lost, system in failsafe mode

### Redundancy and Failover
Implements robust failover mechanism:
- When primary source is lost, system can transition to recovery source
- During failover, preserves last valid command from primary
- Implements timeout management for source presence detection

### Arming and Disarming Logic
Implements secure arming/disarming conditions:
- System arms when both primary and recovery sources indicate arm intent
- System disarms under various conditions including source timeout

## 8. Telemetry System: Status and Performance Reporting

The telemetry system collects, processes, and serializes performance metrics and health indicators:

### Motor Telemetry Collection
Collects key motor performance parameters:
- Board and motor temperatures
- DC current and voltage
- Phase currents and temperatures
- Commanded and measured speeds
- Quadrature currents

### ESC State Reporting
Reports ESC state information:
- Armed/ready/enabled/faulted status flags
- Health alerts from both processor cores
- Fault conditions and diagnostic data

### Data Serialization
Implements efficient data serialization:
- Bit-packed structures for compact representation
- Mixed format with fixed-width integers and bit fields
- Value transformation including unit conversion and scaling

## System Integration: A Cohesive Architecture

The motor controller's architecture represents a sophisticated design that effectively separates system management from real-time control functions while maintaining robust communication between components. The dual-core approach allows for optimal performance in both domains, with CPU1 handling system-level operations and CPU2 dedicated to time-critical motor control.

The shared memory system provides the foundation for inter-core communication, enabling efficient data exchange without compromising the real-time performance of the control algorithms. The hardware abstraction layer ensures consistent interface to hardware components regardless of the specific hardware variant.

The state machine governs the overall system operation, ensuring proper initialization, testing, and fault handling. The Field-Oriented Control algorithm provides precise motor control with sophisticated position estimation and current control strategies. The protection systems ensure safe operation by monitoring various parameters and implementing appropriate responses to abnormal conditions.

The command input management system provides redundancy and failover capabilities, ensuring robust handling of control commands even in the presence of communication failures. The telemetry system provides comprehensive status and performance reporting, enabling external systems to monitor and diagnose the motor controller's operation.

Together, these components form a cohesive architecture that delivers high-performance motor control with robust safety features and comprehensive monitoring capabilities.