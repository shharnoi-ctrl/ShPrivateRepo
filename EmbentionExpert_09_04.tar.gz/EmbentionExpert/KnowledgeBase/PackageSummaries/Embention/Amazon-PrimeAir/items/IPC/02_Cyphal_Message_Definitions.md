# Generated from:

- items/sw_IPC_SIL/code/include/MotorRpmCommand_0_1.h (4110 tokens)
- items/sw_IPC_SIL/code/include/GroundTruthRpm_0_1.h (3635 tokens)
- items/sw_IPC_SIL/code/include/MotorStateRequest_0_1.h (4138 tokens)
- items/sw_IPC_SIL/code/include/EscHealthAlerts_0_1.h (5233 tokens)
- items/sw_IPC_SIL/code/include/RecoveryMotorRpmCommand_0_1.h (3837 tokens)
- items/sw_IPC_SIL/code/include/EscState_0_1.h (3969 tokens)
- items/sw_IPC_SIL/code/include/MotorPerformance_0_1.h (4651 tokens)
- items/sw_IPC_SIL/code/include/MessageId_0_1.h (2962 tokens)

## With context from:

- PackageSummaries/Amazon-PrimeAir/items/IPC/03_Command_Input_Management.md (4750 tokens)
- PackageSummaries/Amazon-PrimeAir/items/IPC/03_Telemetry_and_Diagnostics.md (6048 tokens)

---

# Cyphal Protocol Message Definitions for Drone Communication

This analysis examines the Cyphal protocol message definitions used for drone communication, focusing on their structure, serialization mechanisms, and role in the system's command processing and telemetry reporting.

## 1. Message Type Overview and Purpose

### 1.1 Command Messages

#### MotorRpmCommand (0.1)
- **Purpose**: Primary channel for commanding motor speed and operational state
- **Structure**:
  - `rpm_commands`: Array of six int14 values containing RPM commands for each motor
  - `motor_state_request`: Control structure for motor arming, enabling, and fault handling
- **Usage**: Sent from flight controller to motor controllers to set desired motor speeds and states
- **File**: `MotorRpmCommand_0_1.h`

#### RecoveryMotorRpmCommand (0.1)
- **Purpose**: Backup command channel for redundancy in case of primary channel failure
- **Structure**:
  - `rpm_command`: Single int14 value for RPM command (simpler than primary channel)
  - `motor_state_request`: Same control structure as in MotorRpmCommand
- **Usage**: Provides failover capability when primary command channel is lost
- **File**: `RecoveryMotorRpmCommand_0_1.h`

### 1.2 State and Telemetry Messages

#### GroundTruthRpm (0.1)
- **Purpose**: Provides simulation state information for motor speed and electrical angle
- **Structure**:
  - `id`: Message identifier (MessageId type)
  - `ground_truth_rpm`: int16 value representing actual motor speed
  - `ground_truth_theta_e_deg`: uint9 value representing electrical angle in degrees
- **Usage**: Used in simulation environments to report actual motor state
- **File**: `GroundTruthRpm_0_1.h`

#### MotorPerformance (0.1)
- **Purpose**: Comprehensive ESC status and performance metrics
- **Structure**:
  - `can_node_id`: uint16 identifier for the reporting node
  - `commanded_rpm`: int16 value of commanded motor speed
  - `measured_rpm`: int16 value of actual motor speed
  - `input_current_cA`: int16 value of input current in centiamps
  - `input_voltage_dV`: uint10 value of input voltage in decivolts
  - `commanded_iq_mA`: int20 value of commanded quadrature current in milliamps
  - `measured_iq_mA`: int20 value of measured quadrature current in milliamps
  - `is_on_external_power`: Boolean indicating external power connection
  - `state`: ESC state information (EscState type)
- **Usage**: Primary telemetry message for monitoring motor performance
- **File**: `MotorPerformance_0_1.h`

#### EscState (0.1)
- **Purpose**: Reports ESC operational state
- **Structure**:
  - `health`: Detailed health alerts (EscHealthAlerts type)
  - `is_armed`: Boolean indicating if ESC is armed
  - `is_ready`: Boolean indicating if ESC is ready for operation
  - `is_enabled`: Boolean indicating if ESC is enabled
  - `is_faulted`: Boolean indicating if ESC is in fault state
- **Usage**: Provides operational status of the ESC
- **File**: `EscState_0_1.h`

#### EscHealthAlerts (0.1)
- **Purpose**: Detailed health and fault conditions
- **Structure**:
  - `alerts`: 48-bit boolean array of specific fault conditions
- **Usage**: Reports detailed fault information for diagnostics and fault handling
- **File**: `EscHealthAlerts_0_1.h`

### 1.3 Supporting Types

#### MotorStateRequest (0.1)
- **Purpose**: Encapsulates motor control state commands
- **Structure**:
  - `enable_intent`: uint2 value indicating motor enable state
  - `disabled_motor`: uint3 value indicating which motor to disable (in MEP-out mode)
  - `arm_intent`: uint2 value indicating arming state
  - `source`: uint2 value indicating command source (primary/recovery)
- **Usage**: Used within command messages to control motor state
- **File**: `MotorStateRequest_0_1.h`

#### MessageId (0.1)
- **Purpose**: Generic message identifier
- **Structure**:
  - `id`: 8-byte array for message identification
- **Usage**: Used to identify message sources and types
- **File**: `MessageId_0_1.h`

## 2. Message Serialization and Deserialization

### 2.1 Serialization Architecture

All message types follow a consistent serialization pattern using the Nunavut serialization library:

1. **Buffer Management**:
   - Each message type defines its `EXTENT_BYTES` (maximum possible size)
   - Each message type defines its `SERIALIZATION_BUFFER_SIZE_BYTES` (typical size)
   - Buffer capacity is checked before serialization begins

2. **Serialization Methods**:
   - Each type implements a `serialize_` method that writes to a byte buffer
   - Each type implements a `deserialize_` method that reads from a byte buffer
   - Each type implements an `initialize_` method that sets default values

3. **Bit-Level Packing**:
   - Fields are packed at the bit level for maximum efficiency
   - Fields that aren't byte-aligned may overlap byte boundaries
   - Padding is added to align to byte boundaries when needed

### 2.2 Serialization Example (MotorRpmCommand)

```cpp
static inline int8_t vsdk_message_adn_vehicle_controlsystem_MotorRpmCommand_0_1_serialize_(
    const vsdk_message_adn_vehicle_controlsystem_MotorRpmCommand_0_1* const obj, 
    uint8_t* const buffer, 
    size_t* const inout_buffer_size_bytes)
{
    // Check arguments and buffer size
    if ((obj == NULL) || (buffer == NULL) || (inout_buffer_size_bytes == NULL))
    {
        return -NUNAVUT_ERROR_INVALID_ARGUMENT;
    }
    const size_t capacity_bytes = *inout_buffer_size_bytes;
    if ((8U * (size_t) capacity_bytes) < 104UL)
    {
        return -NUNAVUT_ERROR_SERIALIZATION_BUFFER_TOO_SMALL;
    }
    
    size_t offset_bits = 0U;
    
    // Serialize rpm_commands array (6 int14 values)
    {
        const size_t _origin0_ = offset_bits;
        for (size_t _index0_ = 0U; _index0_ < 6UL; ++_index0_)
        {
            int16_t _sat0_ = obj->rpm_commands[_index0_];
            // Saturate to int14 range
            if (_sat0_ < -8192) { _sat0_ = -8192; }
            if (_sat0_ > 8191) { _sat0_ = 8191; }
            // Write to buffer
            const int8_t _err0_ = nunavutSetIxx(&buffer[0], capacity_bytes, offset_bits, _sat0_, 14U);
            if (_err0_ < 0) { return _err0_; }
            offset_bits += 14U;
        }
    }
    
    // Pad to byte boundary
    if (offset_bits % 8U != 0U)
    {
        const uint8_t _pad0_ = (uint8_t)(8U - offset_bits % 8U);
        const int8_t _err1_ = nunavutSetUxx(&buffer[0], capacity_bytes, offset_bits, 0U, _pad0_);
        if (_err1_ < 0) { return _err1_; }
        offset_bits += _pad0_;
    }
    
    // Serialize nested motor_state_request
    {
        size_t _size_bytes0_ = 2UL;
        int8_t _err2_ = vsdk_message_adn_vehicle_controlsystem_MotorStateRequest_0_1_serialize_(
            &obj->motor_state_request, &buffer[offset_bits / 8U], &_size_bytes0_);
        if (_err2_ < 0) { return _err2_; }
        offset_bits += _size_bytes0_ * 8U;
    }
    
    // Final padding to byte boundary
    if (offset_bits % 8U != 0U)
    {
        const uint8_t _pad1_ = (uint8_t)(8U - offset_bits % 8U);
        const int8_t _err3_ = nunavutSetUxx(&buffer[0], capacity_bytes, offset_bits, 0U, _pad1_);
        if (_err3_ < 0) { return _err3_; }
        offset_bits += _pad1_;
    }
    
    // Update buffer size
    *inout_buffer_size_bytes = (size_t) (offset_bits / 8U);
    return NUNAVUT_SUCCESS;
}
```

### 2.3 Deserialization Example (MotorRpmCommand)

```cpp
static inline int8_t vsdk_message_adn_vehicle_controlsystem_MotorRpmCommand_0_1_deserialize_(
    vsdk_message_adn_vehicle_controlsystem_MotorRpmCommand_0_1* const out_obj, 
    const uint8_t* buffer, 
    size_t* const inout_buffer_size_bytes)
{
    // Check arguments
    if ((out_obj == NULL) || (inout_buffer_size_bytes == NULL) || 
        ((buffer == NULL) && (0 != *inout_buffer_size_bytes)))
    {
        return -NUNAVUT_ERROR_INVALID_ARGUMENT;
    }
    
    // Handle empty buffer case
    if (buffer == NULL) { buffer = (const uint8_t*)""; }
    
    const size_t capacity_bytes = *inout_buffer_size_bytes;
    const size_t capacity_bits = capacity_bytes * (size_t) 8U;
    size_t offset_bits = 0U;
    
    // Deserialize rpm_commands array
    for (size_t _index1_ = 0U; _index1_ < 6UL; ++_index1_)
    {
        out_obj->rpm_commands[_index1_] = nunavutGetI16(&buffer[0], capacity_bytes, offset_bits, 14);
        offset_bits += 14U;
    }
    
    // Align to byte boundary
    offset_bits = (offset_bits + 7U) & ~(size_t) 7U;
    
    // Deserialize nested motor_state_request
    {
        size_t _size_bytes1_ = (size_t)(capacity_bytes - nunavutChooseMin((offset_bits / 8U), capacity_bytes));
        const int8_t _err4_ = vsdk_message_adn_vehicle_controlsystem_MotorStateRequest_0_1_deserialize_(
            &out_obj->motor_state_request, &buffer[offset_bits / 8U], &_size_bytes1_);
        if (_err4_ < 0) { return _err4_; }
        offset_bits += _size_bytes1_ * 8U;
    }
    
    // Align to byte boundary
    offset_bits = (offset_bits + 7U) & ~(size_t) 7U;
    
    // Update consumed buffer size
    *inout_buffer_size_bytes = (size_t) (nunavutChooseMin(offset_bits, capacity_bits) / 8U);
    return NUNAVUT_SUCCESS;
}
```

## 3. Motor Command Processing

### 3.1 Motor RPM Command Structure

The `MotorRpmCommand` message contains commands for all six motors in a single message:

```
┌───────────────────────────────────────────────────────────────────────────────┐
│                           MotorRpmCommand (104 bits)                          │
├───────────────────────────────────────────────────────────────────────────────┤
│ rpm_commands[0] │ rpm_commands[1] │ rpm_commands[2] │ rpm_commands[3] │ ...   │
│    (14 bits)    │    (14 bits)    │    (14 bits)    │    (14 bits)    │       │
├─────────────────┴─────────────────┴─────────────────┴─────────────────┴───────┤
│                         motor_state_request (16 bits)                         │
│  enable_intent  │ disabled_motor  │   arm_intent    │     source      │ pad   │
│    (2 bits)     │    (3 bits)     │    (2 bits)     │    (2 bits)     │(7bits)│
└───────────────────────────────────────────────────────────────────────────────┘
```

The motor indices are defined as constants:
- `kMotorRearRightIndex = 0`
- `kMotorCenterRightIndex = 1`
- `kMotorFrontRightIndex = 2`
- `kMotorFrontLeftIndex = 3`
- `kMotorCenterLeftIndex = 4`
- `kMotorRearLeftIndex = 5`

### 3.2 Recovery Command Structure

The `RecoveryMotorRpmCommand` message is simpler, containing a single RPM command:

```
┌───────────────────────────────────────────────────────────────────────────────┐
│                      RecoveryMotorRpmCommand (32 bits)                        │
├───────────────────────────────────────────────────────────────────────────────┤
│     rpm_command     │                 padding                  │              │
│      (14 bits)      │                 (2 bits)                 │              │
├─────────────────────┴─────────────────────────────────────────┴──────────────┤
│                         motor_state_request (16 bits)                         │
│  enable_intent  │ disabled_motor  │   arm_intent    │     source      │ pad   │
│    (2 bits)     │    (3 bits)     │    (2 bits)     │    (2 bits)     │(7bits)│
└───────────────────────────────────────────────────────────────────────────────┘
```

### 3.3 Motor State Request Structure

The `MotorStateRequest` component is critical for controlling motor state:

```
┌───────────────────────────────────────────────────────────────────────────────┐
│                         MotorStateRequest (16 bits)                           │
├───────────────────────────────────────────────────────────────────────────────┤
│  enable_intent  │ disabled_motor  │   arm_intent    │     source      │ pad   │
│    (2 bits)     │    (3 bits)     │    (2 bits)     │    (2 bits)     │(7bits)│
└───────────────────────────────────────────────────────────────────────────────┘
```

Key control values include:

**enable_intent (2 bits)**:
- `kEnableIntentAllMotorsDisabled = 1`: Disable all motors
- `kEnableIntentAllMotorsEnabled = 2`: Enable all motors
- `kEnableIntentMEPOut = 3`: MEP-out mode (selective motor disabling)

**disabled_motor (3 bits)** - Used with MEP-out mode:
- `kDisabledMotorNone = 0`: No motors disabled
- `kDisabledMotorRearRight = 1` through `kDisabledMotorRearLeft = 6`: Specific motor to disable

**arm_intent (2 bits)**:
- `kArmIntentDisarmed = 1`: Disarm command
- `kArmIntentArmed = 2`: Arm command

**source (2 bits)**:
- `kSourcePrimaryLane = 1`: Command from primary lane
- `kSourceRecoveryLane = 2`: Command from recovery lane

## 4. Telemetry Reporting

### 4.1 Motor Performance Structure

The `MotorPerformance` message provides comprehensive ESC status:

```
┌───────────────────────────────────────────────────────────────────────────────┐
│                         MotorPerformance (176 bits)                           │
├───────────────────────────────────────────────────────────────────────────────┤
│    can_node_id    │   commanded_rpm   │    measured_rpm    │                  │
│     (16 bits)     │     (16 bits)     │     (16 bits)      │                  │
├───────────────────┼───────────────────┼────────────────────┤                  │
│ input_current_cA  │ input_voltage_dV  │      padding       │                  │
│     (16 bits)     │     (10 bits)     │      (6 bits)      │                  │
├───────────────────┴───────────────────┴────────────────────┤                  │
│                    commanded_iq_mA (20 bits)               │                  │
├───────────────────────────────────────────────────────────┤                  │
│                    measured_iq_mA (20 bits)                │                  │
├───────────────────────────────────────────────────────────┼──────────────────┤
│ is_on_external_power │               padding               │                  │
│       (1 bit)        │              (7 bits)               │                  │
├─────────────────────┴───────────────────────────────────────────────────────┤
│                             state (56 bits)                                  │
└───────────────────────────────────────────────────────────────────────────────┘
```

### 4.2 ESC State Structure

The `EscState` message provides operational state information:

```
┌───────────────────────────────────────────────────────────────────────────────┐
│                             EscState (56 bits)                                │
├───────────────────────────────────────────────────────────────────────────────┤
│                           health (48 bits)                                    │
├───────────────────────────────────────────────────────────────────────────────┤
│ is_armed │ is_ready │ is_enabled │ is_faulted │         padding               │
│ (1 bit)  │ (1 bit)  │  (1 bit)   │  (1 bit)   │         (4 bits)              │
└───────────────────────────────────────────────────────────────────────────────┘
```

### 4.3 ESC Health Alerts Structure

The `EscHealthAlerts` message provides detailed fault information:

```
┌───────────────────────────────────────────────────────────────────────────────┐
│                          EscHealthAlerts (48 bits)                            │
├───────────────────────────────────────────────────────────────────────────────┤
│                             alerts (48 bits)                                  │
└───────────────────────────────────────────────────────────────────────────────┘
```

The 48 alert bits represent specific fault conditions, including:
- `kStringSscbFaultIndex = 0`: String SSCB fault
- `kPowerSourceUnidentifiedIndex = 1`: Power source unidentified
- `kMotorOverTemperatureIndex = 5`: Motor over temperature
- `kMotorPositionSensorCalibrationFailedIndex = 6`: Motor position sensor calibration failed
- `kMotorSpinDirectionInvalidIndex = 7`: Motor spin direction invalid
- `kLowEnergyIndex = 10`: Low energy
- `kDcOvervoltageIndex = 11`: DC overvoltage
- `kMcuOvertemperatureIndex = 12`: MCU overtemperature
- `kInverterOvertemperatureIndex = 13`: Inverter overtemperature
- `kRpmFollowIndex = 14`: RPM follow error
- `kEstimatorErrorIndex = 15`: Estimator error
- And many others (total of 48 defined alerts)

## 5. System Integration and Usage

### 5.1 Command Processing Flow

The command processing flow in the system follows this pattern:

1. **Command Reception**:
   - Primary commands received via `MotorRpmCommand` messages
   - Recovery commands received via `RecoveryMotorRpmCommand` messages

2. **Command Deserialization**:
   - Messages are deserialized using the `deserialize_` methods
   - RPM values and motor state requests are extracted

3. **Command Source Selection**:
   - System determines whether to use primary or recovery commands
   - Selection based on source presence, timeouts, and state machine logic

4. **Command Execution**:
   - Selected RPM commands are applied to motor controllers
   - Motor state requests (arm/enable/disable) are processed

### 5.2 Telemetry Reporting Flow

The telemetry reporting flow follows this pattern:

1. **Data Collection**:
   - Motor controllers collect performance data
   - ESC state and health information is gathered

2. **Message Serialization**:
   - Data is serialized into `MotorPerformance` messages
   - ESC state and health alerts are included

3. **Message Transmission**:
   - Serialized messages are transmitted over the Cyphal network
   - Messages are received by monitoring systems

4. **Data Analysis**:
   - Received telemetry is analyzed for performance monitoring
   - Health alerts are processed for fault detection and handling

### 5.3 Redundancy and Fault Tolerance

The message definitions support robust redundancy and fault tolerance:

1. **Dual Command Channels**:
   - Primary channel (`MotorRpmCommand`) for normal operation
   - Recovery channel (`RecoveryMotorRpmCommand`) for failover

2. **MEP-Out Mode**:
   - Allows selective disabling of motors (`kEnableIntentMEPOut`)
   - Specific motor to disable indicated by `disabled_motor` field

3. **Comprehensive Health Reporting**:
   - 48 distinct health alerts for detailed fault diagnosis
   - Fault categorization for appropriate response

4. **Command Source Tracking**:
   - Commands tagged with source information (`kSourcePrimaryLane` or `kSourceRecoveryLane`)
   - Allows system to track command provenance

## 6. Message Size and Efficiency Analysis

### 6.1 Message Size Comparison

| Message Type | Size (bytes) | Bit Efficiency Features |
|--------------|--------------|-------------------------|
| MotorRpmCommand | 13 | Packed 14-bit RPM values, compact state encoding |
| RecoveryMotorRpmCommand | 4 | Single RPM value, same state encoding |
| GroundTruthRpm | 12 | Includes message ID (8 bytes) |
| MotorPerformance | 22 | Comprehensive data with precise field sizing |
| EscState | 7 | Compact boolean flags with health alerts |
| EscHealthAlerts | 6 | Bit-packed boolean array for 48 alerts |

### 6.2 Bit-Level Optimization

The message definitions employ several bit-level optimizations:

1. **Right-Sized Fields**:
   - RPM values use 14 bits (range -8192 to 8191)
   - Voltage uses 10 bits (range 0 to 1023)
   - Current uses variable precision (16 or 20 bits) based on requirements

2. **Bit Packing**:
   - Boolean values packed as individual bits
   - Small enumerations use minimal bits (2-3 bits)
   - Arrays of booleans packed into bit arrays

3. **Saturation Logic**:
   - Values are saturated to fit within allocated bit widths
   - Prevents overflow/underflow during serialization

## 7. Conclusion

The Cyphal protocol message definitions provide a comprehensive, efficient, and robust communication framework for drone motor control and monitoring. Key aspects include:

1. **Command Structure**:
   - Primary and recovery command channels
   - Detailed motor state control
   - Support for normal and degraded operation modes

2. **Telemetry Structure**:
   - Comprehensive performance reporting
   - Detailed health and fault information
   - Efficient bit-level encoding

3. **Serialization Mechanisms**:
   - Consistent serialization/deserialization patterns
   - Bit-level packing for efficiency
   - Robust error handling

4. **System Integration**:
   - Support for redundancy and failover
   - Detailed fault reporting
   - Source tracking for command provenance

These message definitions form the foundation of the drone's communication architecture, enabling reliable command and control while providing comprehensive telemetry for monitoring and diagnostics.