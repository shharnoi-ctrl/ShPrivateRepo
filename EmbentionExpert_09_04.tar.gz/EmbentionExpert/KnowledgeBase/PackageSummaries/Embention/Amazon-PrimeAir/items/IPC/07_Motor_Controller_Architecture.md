# Generated from:

- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/include/Mc.h (3035 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/include/Mc_control.h (2276 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/source/main_mc_c1.cpp (1088 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/source/main_mc_c2.cpp (997 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/source/Mc.cpp (4807 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/source/Mc_control.cpp (4597 tokens)

---

# Comprehensive Overview of Motor Controller's Dual-Core Architecture

## 1. Architectural Overview

The motor controller implements a sophisticated dual-core architecture utilizing a TMS320F28335 DSP with two CPUs (CPU1 and CPU2) that work in tandem to manage different aspects of motor control. This architecture separates system management from real-time control functions, allowing for efficient task distribution and improved performance.

### 1.1 Core Responsibilities

#### CPU1 (System Management)
- Handles communication interfaces (CAN, SCI, etc.)
- Manages system status and maintenance modes
- Processes input commands and routing
- Handles background tasks and low-priority operations
- Manages the overall system state through a finite state machine
- Coordinates with CPU2 through shared memory and IPC mechanisms

#### CPU2 (Real-time Control)
- Executes high-frequency motor control algorithms
- Performs field-oriented control (FOC) without encoder
- Manages PWM generation and synchronization
- Handles ADC sampling and processing
- Implements motor current control loops
- Processes sensor data (SIN/COS position sensors)
- Records diagnostic data for analysis

## 2. Initialization Sequence

The initialization process follows a carefully orchestrated sequence to ensure proper setup of both cores and their communication channels.

### 2.1 CPU1 Initialization

1. **Pre-initialization (`_system_pre_init`)**
   - Calls `Dsp28335_ent::init_sys_cpu1_0()` to set up initial system settings
   - Initializes CPU1 without EMIF (External Memory Interface)

2. **Post Copy Initialization (`_system_post_cinit`)**
   - Initializes shared memory for inter-core communication via `MCxx::get_c1_sh_mem()`
   - Calls `Dsp28335_ent::post_init_sys_cpu1(true, false)` to complete CPU1 setup
   - Parameters indicate dual-core operation with EMIF1 not configured for CPU2

3. **Main Initialization (`main`)**
   - Creates the main `Mc` instance using internal memory allocation
   - Unlocks CPU2 execution via `Ipc::cpu2_unlock()`
   - Waits for CPU2 to complete initialization with `Ipc::cpu1_wait_for_unlock()`
   - Calls `mc_inst->post_init_c2()` to perform post-initialization tasks after CPU2 is ready
   - Starts the main execution loop with `mc_inst->start()`

### 2.2 CPU2 Initialization

1. **Pre-initialization (`_system_pre_init`)**
   - Calls `Dsp28335_ent::init_sys_cpu2_0()` to set up initial system settings for CPU2

2. **Post Copy Initialization (`_system_post_cinit`)**
   - Calls `Dsp28335_ent::post_init_sys_cpu2()` to complete CPU2 setup

3. **Main Initialization (`main`)**
   - Waits for CPU1 to unlock execution with `Ipc::cpu2_wait_for_unlock()`
   - Creates the `Mc_c2_mgr` instance for CPU2 control
   - Signals CPU1 that initialization is complete with `Ipc::cpu1_unlock()`
   - Starts the control execution loop with `mc_c2->start()`

## 3. Inter-Core Communication

The dual-core architecture relies on several mechanisms for communication between CPU1 and CPU2:

### 3.1 Shared Memory

The system uses a structured shared memory approach to exchange data between cores:

```
CPU1 (C1_owned)                  CPU2 (C2_owned)
+------------------+             +------------------+
| ffrd_diag        | <---------- | ffwr_diag        |
| fsm_st           | ----------> | (reads state)    |
| sync_enabled     | ----------> | (reads config)   |
| pwm_shift        | ----------> | (reads config)   |
| sync1_duty       | ----------> | (reads config)   |
| change_role      | ----------> | (reads flag)     |
+------------------+             +------------------+
```

- Global shared RAM (GSRAM) is partitioned between the cores:
  - 14 blocks owned by CPU1
  - 2 blocks owned by CPU2
  - Total of 16 blocks available

- Cross-core data structures include:
  - Diagnostic data buffers (`ffrd_diag`/`ffwr_diag`)
  - Configuration parameters
  - State information
  - Control commands

### 3.2 IPC Mechanisms

The cores use Inter-Processor Communication (IPC) mechanisms for synchronization and signaling:

1. **Flags and Interrupts**
   - `Ipc::cpu2_unlock()` and `Ipc::cpu1_unlock()` for initialization synchronization
   - `Ipc::set_flag()` for signaling between cores
   - Interrupt handlers for specific actions:
     - `ipc_isr_disable()`: Handles PWM disable requests from CPU2 to CPU1
     - `ipc_isr_enable()`: Handles PWM enable requests from CPU2 to CPU1

2. **Cross-Core Queues**
   - `Xcffrd` (cross-core FIFO read) and `Xcwr0` (cross-core write) for data transfer
   - Used primarily for diagnostic data exchange

## 4. Execution Model

The system implements a multi-rate execution model with different task frequencies for each core.

### 4.1 CPU1 Execution

1. **High-Priority Task (`step_hi`)**
   - Triggered by interrupt
   - Polls peripherals
   - Processes input manager data
   - Executes high-priority suite tasks
   - Runs state machine step
   - Monitors execution time for performance metrics
   - Frequency defined by `rt_freq` (real-time frequency)

2. **Background Task (`bg_task`)**
   - Runs in an infinite loop
   - Monitors frequency metrics
   - Checks stack integrity
   - Executes low-priority suite tasks
   - Processes system manager steps
   - Updates system variables
   - Target frequency of 10Hz (`bg_freq`)

### 4.2 CPU2 Execution

1. **High-Priority Task (`step_hi`)**
   - Triggered by ADC completion interrupt
   - Executes the main control algorithm (`ctrl.step()`)
   - Records diagnostic variables
   - Updates motor temperature calculations
   - Handles PWM synchronization
   - Monitors execution time
   - Frequency defined by `rt_freq` (configurable through PDI)

2. **Background Task (`bg_task`)**
   - Runs in an infinite loop
   - Monitors frequency metrics
   - Checks stack integrity
   - Executes low-priority control tasks
   - Updates system variables
   - Computes motor temperature
   - Manages LED indicators for system status

## 5. Hardware Abstraction and Configuration

The architecture implements a layered approach to hardware abstraction:

### 5.1 CPU1 Hardware Abstraction

- `Halsuite_mc` provides hardware abstraction for CPU1
- Manages communication interfaces (CAN, SCI, SPI)
- Handles GPIO for status indicators
- Configures system clocks and peripherals

### 5.2 CPU2 Hardware Abstraction

- `Halsuite_mc_ctrl` provides hardware abstraction for CPU2
- Configures ADC for motor current and voltage sensing
- Manages PWM generation for motor control
- Handles sensor interfaces (SIN/COS position sensors)

### 5.3 Hardware Configuration

The system supports different hardware versions with specific initialization:
- `v_mc_ipc`: IPC-enabled motor controller with Typhoon revision
- `v_mc_110_v2`: MC110 v2 hardware
- Configuration includes ADC channel mapping, PWM settings, and sensor interfaces

## 6. Motor Control Implementation

The motor control functionality is primarily implemented on CPU2:

### 6.1 Control Algorithm

- Field-Oriented Control (FOC) without encoder (`Control_foc_noenc`)
- SIN/COS position sensors for rotor position feedback
- Current control loops for Id and Iq
- Speed control with slew rate limiting
- Fault detection and protection mechanisms

### 6.2 Diagnostic Data Collection

- High-frequency diagnostic data recording (5000Hz target)
- Data includes:
  - DC bus voltage and current
  - Motor phase currents
  - Id/Iq command values
  - Estimated mechanical speed and position
  - String DC current

## 7. Synchronization and Timing

The architecture implements precise timing and synchronization mechanisms:

### 7.1 PWM Synchronization

- Support for leader/follower configuration
- Phase shift control for interleaved operation
- Configurable through PDI parameters

### 7.2 Task Timing Monitoring

- Both cores monitor execution time of high-priority tasks
- Calculates average and maximum CPU utilization
- Implements assertions to ensure real-time constraints are met
- Maximum CPU ratio threshold of 92%

## 8. Fault Handling and Safety

The dual-core architecture enhances system safety through redundancy and separation:

### 8.1 Fault Detection

- CPU2 implements motor-specific fault detection
- CPU1 manages system-level fault handling
- Ground fault protection available on supported hardware

### 8.2 Fault Response

- Critical faults trigger immediate PWM disable
- Non-critical faults allow continued operation with limitations
- Visual indication through LED status (alive/error)
- State machine transitions to faulted state when necessary

## 9. Design Patterns and Architectural Decisions

Several key design patterns and architectural decisions are evident in the implementation:

### 9.1 Singleton Pattern

Both `Mc` and `Mc_control` classes implement singleton patterns to ensure single instances control each core.

### 9.2 Separation of Concerns

- Clear separation between system management (CPU1) and real-time control (CPU2)
- Hardware abstraction layers isolate hardware-specific code
- Communication interfaces are abstracted from core functionality

### 9.3 Producer-Consumer Pattern

The cross-core communication implements a producer-consumer pattern for diagnostic data exchange.

### 9.4 State Machine

A finite state machine (`Fsm`) manages the overall system state and transitions.

## 10. Referenced Context Files

The following context files provided valuable insights for understanding the dual-core architecture:

- `Mc.h`: Defines the main CPU1 controller class structure and interfaces
- `Mc_control.h`: Defines the CPU2 controller class for real-time motor control
- `main_mc_c1.cpp`: Contains the initialization sequence and main loop for CPU1
- `main_mc_c2.cpp`: Contains the initialization sequence and main loop for CPU2
- `Mc.cpp`: Implements the CPU1 controller functionality
- `Mc_control.cpp`: Implements the CPU2 controller functionality

## Conclusion

The motor controller's dual-core architecture represents a sophisticated design that effectively separates system management from real-time control functions. This separation allows for optimal performance in both domains while maintaining robust inter-core communication through shared memory and IPC mechanisms. The initialization sequence ensures proper setup and synchronization between cores, while the execution model supports different task frequencies appropriate for each core's responsibilities. This architecture provides a solid foundation for implementing advanced motor control algorithms with high reliability and performance.