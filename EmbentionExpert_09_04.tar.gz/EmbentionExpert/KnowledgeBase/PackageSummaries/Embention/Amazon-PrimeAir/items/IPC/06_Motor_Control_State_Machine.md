# Generated from:

- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/include/Fsm.h (2682 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/include/Fsm_states.h (133 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/source/Fsm.cpp (734 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/source/Fsm_amz.cpp (7158 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/source/Fsm_ver.cpp (1535 tokens)

## With context from:

- PackageSummaries/Amazon-PrimeAir/items/IPC/07_Motor_Controller_Architecture.md (2764 tokens)

---

# Finite State Machine (FSM) Implementation for Motor Controller Operation

## 1. FSM Architecture Overview

The motor controller implements a hierarchical state machine that manages the operational states of the system. This FSM is responsible for coordinating the transition between different operational modes, handling fault conditions, and ensuring proper initialization and testing sequences before motor operation.

### 1.1 Primary State Hierarchy

The FSM defines six main states that represent the operational lifecycle of the motor controller:

| State | Description | Entry Conditions | Exit Conditions |
|-------|-------------|------------------|-----------------|
| `init` | Initial power-up state | System power-on | Successful initialization or terminal fault |
| `disarmed` | System initialized but not ready for operation | Successful initialization from `init` | Ready to arm or terminal fault |
| `test` | Performing pre-operation tests | System ready to arm from `disarmed` | Tests complete or terminal fault |
| `inactive` | System armed but not actively controlling motor | Test completion or disarming from `active` | Ready to activate, disarm command, or terminal fault |
| `active` | System actively controlling motor | Intent enabled from `inactive` | Intent disabled or terminal fault |
| `faulted` | System encountered critical fault | Terminal fault from any state | System reset required |

### 1.2 State Transition Logic

The FSM implements a comprehensive set of transition rules that determine when the system moves between states:

```
From any state → faulted: When terminal_fault is true
init → disarmed: When initialization completes successfully
disarmed → test: When should_arm() returns true
test → inactive: When test sequence completes successfully
inactive → disarmed: When should_disarm() returns true
inactive → active: When intent_enabled() returns true
active → inactive: When intent_enabled() returns false
```

### 1.3 Motor Controller Interface States

The FSM also manages the motor controller interface (MCI) state, which determines the control mode of the motor:

| MCI State | Description | When Used |
|-----------|-------------|-----------|
| `off` | PWM disabled | During disarmed and faulted states |
| `calibration` | Initial calibration mode | During initialization |
| `alignment` | Motor alignment mode | During test sequence |
| `zero_current` | Zero current mode | During inactive state |
| `rpm` | Speed control mode | During active state |

## 2. Test Sequence State Machine

Within the `test` state, the FSM implements a nested state machine that performs a series of tests to ensure the system is ready for operation:

### 2.1 Test Sequence States

| Test State | Description | Purpose |
|------------|-------------|---------|
| `initial` | Starting state | Prepares for test sequence |
| `gfd` | Ground Fault Detection | Tests for insulation failures |
| `sin_cos_al` | Sin/Cos Alignment | Calibrates position sensors with rotor |
| `sin_cos_ol` | Sin/Cos Open Loop | Validates sensor operation in open loop |
| `finished` | Test completion | Indicates successful test completion |

### 2.2 Test Sequence Transitions

```
initial → gfd: When start_test flag is set
gfd → sin_cos_al: When GFD completes successfully
gfd → faulted: When GFD detects a ground fault
sin_cos_al → sin_cos_ol: When alignment completes successfully
sin_cos_ol → finished: When open loop test completes successfully
```

### 2.3 Test Sequence Implementation

The test sequence is implemented in the `step_test()` method, which handles the progression through the test states:

1. **Ground Fault Detection (GFD)**:
   - Uses the `Ground_fault` class to detect insulation failures
   - Sets fault `f_hi_imp_gfd` if a ground fault is detected
   - Transitions to `sin_cos_al` if successful

2. **Sin/Cos Sensor Alignment**:
   - Sets MCI state to `alignment`
   - Enables PWM for motor control
   - Waits for `aligment_complete` flag from C2
   - Transitions to `sin_cos_ol` when complete

3. **Sin/Cos Open Loop Test**:
   - Sets input speed to the rate-limited command value
   - Waits for `open_loop_complete` flag from C2
   - Transitions to `finished` when complete

## 3. FSM Implementation Details

### 3.1 Core FSM Class Structure

```cpp
class Fsm {
public:
    explicit Fsm(Mc& motor_controller0);
    void step();

private:
    volatile FSM::State& st;         // Current FSM state
    volatile MCI::State& mci_st;     // Motor Controller Interface state
    Mc& motor_controller;            // Reference to motor controller
    volatile Real& input_speed;      // Input speed command
    Data& data;                      // Private implementation data
    const volatile C2_owned& c2_data;// Shared memory from C2
    volatile C1_owned& c1_data;      // Shared memory from C1
    Faults_t all_faults;             // Combined C1 and C2 faults
    
    // Test sequence state
    enum Test { initial = 0, gfd = 1, sin_cos_al = 2, sin_cos_ol = 3, finished = 4 };
    Test st_test;
    
    // State handling methods
    void step_init();
    void step_test();
    void check_active_faults();
    bool enabled_rpm() const;
    void set_input_rpm() const;
};
```

### 3.2 FSM Initialization

The FSM constructor initializes the state machine with references to shared memory and system components:

```cpp
Fsm::Fsm(Mc& motor_controller0):
    st(get_c1_sh_mem().fsm_st),
    mci_st(get_c1_sh_mem().mci_st),
    motor_controller(motor_controller0),
    input_speed(Bsp::Hrvar(Base::v_mangle_ratec).get_ref()),
    st_test(Fsm::initial),
    data(*Base::Memmgr::get_instance().get_allocator(Base::Memmgr::internal).
         allocate_new<Fsm::Data>(motor_controller)),
    c2_data(get_c2_sh_mem()),
    c1_data(get_c1_sh_mem())
{
    mci_st = MCI::calibration;
    motor_controller.hal.disable_pwm();
    input_speed = 0.0F;
}
```

### 3.3 Main FSM Step Function

The `step()` method is the core of the FSM implementation, handling state transitions and executing state-specific logic:

```cpp
void Fsm::step() {
    // Update communication fault status
    // ...
    
    // Calculate terminal fault condition
    const Faults_t all_faults = {c1_data.inhibit_termination ?
                                0ULL : (c2_data.faults.value | c1_data.faults.value)};
    c1_data.terminal_fault = all_faults.value & c2_data.msk_critical.value;
    
    // State machine logic
    switch(st) {
        case FSM::init:
            step_init();
            break;
        case FSM::disarmed:
            // Handle disarmed state
            // ...
            break;
        case FSM::test:
            // Handle test state
            // ...
            break;
        case FSM::inactive:
            // Handle inactive state
            // ...
            break;
        case FSM::active:
            // Handle active state
            // ...
            break;
        case FSM::faulted:
            // Handle faulted state
            // ...
            break;
        default:
            Bsp::warning();
            break;
    }
    
    // Update status flags
    // ...
}
```

## 4. Fault Handling and Status Management

### 4.1 Fault Detection and Processing

The FSM integrates fault detection from multiple sources:

1. **Communication Faults**:
   - `f_comm_a`: Primary communication channel fault
   - `f_comm_b`: Recovery communication channel fault
   - `f_comm_trans`: Transient communication fault
   - `f_comm_pers`: Persistent communication fault

2. **Command Source Faults**:
   - `f_cmd_rec_lane`: Command from recovery lane

3. **Hardware Faults**:
   - `f_hi_imp_gfd`: Ground fault detected
   - `f_vi_init`: Voltage inverter initialization failure

### 4.2 Terminal Fault Determination

Terminal faults are determined by combining C1 and C2 faults and applying a critical fault mask:

```cpp
const Faults_t all_faults = {c1_data.inhibit_termination ?
                            0ULL : (c2_data.faults.value | c1_data.faults.value)};
c1_data.terminal_fault = all_faults.value & c2_data.msk_critical.value;
```

The `inhibit_termination` flag allows certain operational modes to suppress fault termination.

### 4.3 System Status Flags

The FSM updates several system status flags that reflect the current operational state:

```cpp
// Status flags
static volatile bool& is_armed = Bsp::Hbvar(Base::kbit_is_armed).get_ref();
is_armed = (st >= FSM::test) && (st <= FSM::active);

static volatile bool& is_ready = Bsp::Hbvar(Base::kbit_is_ready).get_ref();
is_ready = (st >= FSM::inactive) && (st <= FSM::active);

static volatile bool& is_active = Bsp::Hbvar(Base::kbit_is_enabled).get_ref();
is_active = (st == FSM::active);

static volatile bool& is_faulted = Bsp::Hbvar(Base::kbit_is_faulted).get_ref();
is_faulted = (st == FSM::faulted);

static volatile bool& is_wr_reset_allowed = Bsp::Hbvar(Base::kbit_is_wr_reset_allowed).get_ref();
is_wr_reset_allowed = !is_armed;
```

These flags provide a simplified interface for other components to determine the system's operational status.

## 5. State Transition Diagrams

### 5.1 Main FSM State Transitions

```
                  ┌───────────────────────────────────────────────────────────────────┐
                  │                                                                   │
                  │                Terminal Fault (from any state)                    │
                  ▼                                                                   │
┌─────────┐    ┌─────────┐    ┌─────────┐    ┌─────────┐    ┌─────────┐    ┌─────────┐
│  init   │───►│disarmed │───►│  test   │───►│inactive │───►│ active  │    │ faulted │
└─────────┘    └─────────┘    └─────────┘    └─────────┘    └─────────┘    └─────────┘
                    ▲                             │              │
                    │                             │              │
                    └─────────────────────────────┘              │
                                                                 │
                    ┌─────────────────────────────────────────────┘
                    │
                    ▼
```

### 5.2 Test Sequence State Transitions

```
┌─────────┐    ┌─────────┐    ┌───────────┐    ┌───────────┐    ┌─────────┐
│ initial │───►│   gfd   │───►│ sin_cos_al│───►│ sin_cos_ol│───►│finished │
└─────────┘    └─────────┘    └───────────┘    └───────────┘    └─────────┘
                    │
                    │
                    ▼
               ┌─────────┐
               │ faulted │
               └─────────┘
```

## 6. Speed Command Processing

### 6.1 Speed Command Validation

The FSM includes logic to validate speed commands and determine when the motor should be active:

```cpp
bool Fsm::enabled_rpm() const {
    return (Rmath::fabsr(input_speed) / (static_cast<Real>(c2_data.motor_max_rpm) * Const::RPM2RADS)
            > c2_data.input_deadband);
}
```

This function determines if the commanded speed is above the minimum threshold (deadband) required to activate the motor.

### 6.2 Speed Command Limiting

The FSM ensures that speed commands are within the configured limits:

```cpp
void Fsm::set_input_rpm() const {
    input_speed = Rfun::clamp<Real>(
            static_cast<Real>(motor_controller.input_mgr->get_active_rpm()) * Const::RPM2RADS,
           -static_cast<Real>(c2_data.motor_max_rpm) * Const::RPM2RADS,
            static_cast<Real>(c2_data.motor_max_rpm) * Const::RPM2RADS);
}
```

This function retrieves the commanded RPM from the input manager, converts it to radians per second, and clamps it to the configured maximum speed in both directions.

## 7. Implementation Variations

The FSM implementation includes two variations:

### 7.1 Amazon Implementation (`Fsm_amz.cpp`)

The Amazon implementation includes:
- Comprehensive test sequence with ground fault detection
- Detailed fault handling for communication and hardware faults
- Support for command source selection and validation
- Inhibitable fault termination for certain operational modes

### 7.2 Verification Implementation (`Fsm_ver.cpp`)

The verification implementation provides:
- Simplified state machine logic for testing and verification
- Basic fault handling without the full test sequence
- Minimal private data structure
- Simplified state transitions

## 8. Cross-Component Relationships

The FSM interacts with several other components in the motor controller system:

### 8.1 Motor Controller Interface

- The FSM controls the motor controller interface state (`mci_st`)
- Transitions between control modes (off, calibration, alignment, zero_current, rpm)
- Enables/disables PWM output through `motor_controller.hal.enable_pwm()` and `disable_pwm()`

### 8.2 Input Manager

- Retrieves command inputs through `motor_controller.input_mgr`
- Checks arm/disarm commands via `should_arm()` and `should_disarm()`
- Validates communication status through `communication_nominal_primary()` and `communication_nominal_recovery()`
- Determines command source via `is_recovery_command()`

### 8.3 Shared Memory

- Reads state information from C2 (`c2_data`)
- Updates state information in C1 (`c1_data`)
- Manages fault flags and status indicators
- Coordinates test sequence completion flags

## 9. Referenced Context Files

The following context file provided valuable insights for understanding the FSM implementation:

- `07_Motor_Controller_Architecture.md`: Provided context on the dual-core architecture and how the FSM fits into the overall system design, particularly how it interacts with the motor control state machine and handles fault conditions.

## State Diagram: Complete FSM with Test Sequence

```
┌─────────────────────────────────────────────────────────────────────────────────────────────────┐
│                                                                                                 │
│                                  Terminal Fault (from any state)                                │
│                                                                                                 │
▼                                                                                                 │
┌─────────┐    ┌─────────┐    ┌───────────────────────────────────────────────┐    ┌─────────┐    │
│  init   │───►│disarmed │───►│                    test                       │───►│inactive │    │
└─────────┘    └─────────┘    │  ┌─────────┐ ┌─────┐ ┌─────────┐ ┌─────────┐  │    └─────────┘    │
                              │  │ initial │►│ gfd │►│sin_cos_al│►│sin_cos_ol│  │        │        │
                              │  └─────────┘ └─────┘ └─────────┘ └─────────┘  │        │        ┌─────────┐
                              │                 │                     │        │        └───────►│ active  │
                              │                 │                     ▼        │                 └─────────┘
                              │                 │               ┌─────────┐   │                      │
                              │                 │               │ finished │   │                      │
                              │                 │               └─────────┘   │                      │
                              │                 ▼                             │                      │
                              └───────────────────────────────────────────────┘                      │
                                                │                                                    │
                                                │                                                    │
                                                ▼                                                    ▼
                                           ┌─────────┐                                         ┌─────────┐
                                           │ faulted │◄────────────────────────────────────────┤ faulted │
                                           └─────────┘                                         └─────────┘
```