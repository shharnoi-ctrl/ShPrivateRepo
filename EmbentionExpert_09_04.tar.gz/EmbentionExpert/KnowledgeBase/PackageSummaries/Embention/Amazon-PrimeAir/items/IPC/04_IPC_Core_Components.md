# Generated from:

- items/sw_IPC/code/MC_ipc_c1/code/include/Gpioid_ipc.h (213 tokens)
- items/sw_IPC/code/MC_ipc_c1/code/source/CPU1_CM_shared.cpp (641 tokens)
- items/sw_IPC/code/MC_ipc_c2/code/include/Mc_c2_mgr.h (182 tokens)
- items/sw_IPC/code/MC_ipc_cm/code/include/Ipc_cm.h (372 tokens)
- items/sw_IPC/code/MC_ipc_cm/code/source/CM_CPU1_shared.cpp (319 tokens)
- items/sw_IPC/code/MC_ipc_cm/code/source/main_2838x_ipc_cm.cpp (1449 tokens)
- items/sw_IPC/code/MC_ipc_cm/code/source/Ipc_cm.cpp (172 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/include/Ipc_ids.h (1550 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/include/IPC_diag_data.h (2072 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/source/cpu2/IPC_diag_data.cpp (1082 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/include/pa/cm/CM_CPU1_shared_types.h (997 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/include/pa/cm/CM_CPU1_shared.h (75 tokens)
- items/sw_IPC_SIL/items/_SWMC/items/sw_mc/mc_common/code/include/pa/cpu1/CPU1_CM_shared.h (211 tokens)

## With context from:

- PackageSummaries/Amazon-PrimeAir/items/IPC/05_Shared_Memory_System.md (3254 tokens)

---

# Inter-Processor Communication (IPC) System Between CPU1, CPU2, and CM Cores

## 1. IPC System Architecture Overview

The Motor Controller system implements a comprehensive Inter-Processor Communication (IPC) architecture that enables data exchange and coordination between three processing cores:

1. **CPU1** - Primary control processor
2. **CPU2** - Secondary processor for motor control operations
3. **CM** - Communication Manager core (ARM-based)

The IPC system uses multiple mechanisms for cross-core communication:

- **Shared memory regions** with defined ownership boundaries
- **Cross-core FIFOs** for packet-based communication
- **Diagnostic data buffers** for telemetry and monitoring
- **Command/response mechanisms** for coordinated operations
- **Hardware synchronization signals** via GPIO pins

## 2. Shared Memory Structure and Organization

### 2.1 CPU1-CM Shared Memory

The system implements bidirectional shared memory between CPU1 and CM cores with clearly defined ownership:

#### 2.1.1 CPU1_CM_shared (CPU1-owned, CM-readable)

Located at memory address **0x20080000** (CPU1TOCMMSGRAM), this structure contains:

```cpp
struct CPU1_CM_shared {
    Spkt_fifo::Writer udp_writer;   // Packet FIFO Writer (to CM)
    Spkt_fifo::Reader udp_reader;   // Packet FIFO Reader (from CM)
    Base::Address0::Id_t sys_addr;  // System address
    Bsp::Uid64 uid;                 // 64-bit unique identifier
    Uint64 eth_mac;                 // Ethernet MAC address (2 highest bytes unused)
    Uint32 ip_addr;                 // IP address
    Uint32 net_mask;                // IP network mask
    Uint32 padding1;                // Padding
    Uint16 port_stg;                // UDP port for STANAG messages
    Uint16 port_cy;                 // UDP port for Cyphal messages
    Base::Prv_key::Type prv_key;    // Private key for signing with CM core
    Base::Sha256_data::Type hash;   // Hash to sign with CM core
    Base::CM_commands cm_cmd;       // Execution mode for CM core
    Uint16 padding2[3];             // Padding
};
```

#### 2.1.2 CM_CPU1_shared (CM-owned, CPU1-readable)

Located at memory address **0x00038000** (CMTOCPU1MSGRAM), this structure contains:

```cpp
struct CM_CPU1_shared {
    Spkt_fifo::Writer udp_writer;           // Packet FIFO Writer (to CPU1)
    Spkt_fifo::Reader udp_reader;           // Packet FIFO Reader (from CPU1)
    Base::Sha256_data::Type cmhash_data;    // CM code SHA256 result
    Uint16 ready;                           // Ready flag
    Base::Prv_key::Type prv_key;            // ECDSA Private key
    Base::Pub_key::Type pub_key;            // ECDSA Public key
    Base::Signature::Type signature;        // Signature result
};
```

### 2.2 CPU1-CPU2 Shared Memory

As detailed in the context file, CPU1 and CPU2 also share memory regions with defined ownership:

- **C1_owned**: CPU1-owned memory at address 0x03A000 (accessed by CPU2)
- **C2_owned**: CPU2-owned memory at address 0x03B000 (accessed by CPU1)

Each region contains various variables, status flags, and configuration parameters.

### 2.3 Packet-Based Communication FIFOs

The system implements bidirectional packet-based communication using shared FIFOs:

```cpp
static const uint16_t fifo_sz = 2;                                  // FIFO size
typedef Base::Fifo_shared<Base::Spkt_buffer, fifo_sz> Spkt_fifo;    // Packet FIFO type
```

Each shared memory region contains:
- A Writer endpoint for sending packets
- A Reader endpoint for receiving packets

This enables bidirectional message passing between cores.

## 3. Diagnostic Data Flow

### 3.1 IPC Diagnostic Buffer Structure

The system implements a circular buffer for diagnostic data collection and sharing:

```cpp
struct IPC_diag {
    Uint16 inverter_dcbus_dV;      // Inverter DC bus voltage (10bit) V_DC [0, 1023] dV
    int16  inverter_dcbus_dA;      // Inverter DC bus current (12bit) I_DC [-2048, 2047] dA
    int16  motor_phase_a_dA;       // Motor phase current A (13bit) I_a [-4096, 4095] dA
    int16  motor_phase_b_dA;       // Motor phase current B (13bit) I_b [-4096, 4095] dA
    int16  motor_phase_c_dA;       // Motor phase current C (13bit) I_c [-4096, 4095] dA
    int16  motor_el_Iq_cmd_dA;     // Motor electrical_Iq commanded (13bit) I_q [-4096, 4095] dA
    int16  motor_el_Id_cmd_dA;     // Motor electrical_Id commanded(13bit) I_d [-4096, 4095] dA
    int16  motor_est_mech_rpm;     // Motor estimated mechanical speed (14bit) [-8192, 8191] RPM
    Uint16 motor_est_el_pos_deg;   // Motor estimated electrical position (9bit) [0, 359] degrees
    int16  motor_slr_lim_rpm;      // Commanded mechanical speed, slew-rate limited (14bit) [-8192, 8191] RPM
    int16  string_dc_current_dA;   // String DC current (12bit) [-2048, 2047] dA
};
```

### 3.2 Diagnostic Buffer Management

The diagnostic data is managed through a circular buffer implementation:

```cpp
class IPC_diag_buffer {
    Uint16 wr_idx;  // Next element to write index [0, diag_sz]
    Uint16 wr_cnt;  // Write counter [0, diag_sz]
    Uint16 rd_cnt;  // Read counter
    
    // Methods for reading/writing diagnostic data
    IPC_diag& get_next_wr();
    const IPC_diag* get_next_rd();
};
```

### 3.3 Diagnostic Buffer Memory Layout

The diagnostic buffer is split across two memory regions due to memory fragmentation:

```cpp
namespace IPC_diag_priv {
    static const Uint16 diag_sz0 = 440;         // Size of buffer in local RAM
    static const Uint16 diag_sz1 = 710;         // Size of buffer in GS RAM
    static const Uint16 diag_sz  = diag_sz0 + diag_sz1; // Total size: 1150 elements
    Base::Tnarray<IPC_diag, diag_sz0> diag0;    // Buffer in local RAM
    Base::Tnarray<IPC_diag, diag_sz1> diag1;    // Buffer in GS RAM
}
```

This provides storage for 1150 diagnostic data points, equivalent to 230ms of data at 5kHz sampling rate.

### 3.4 Diagnostic Data Flow Path

1. CPU2 collects motor control diagnostic data
2. CPU2 writes data to the diagnostic buffer using `get_next_wr()`
3. CPU1 reads data from the buffer using `get_next_rd()`
4. CPU1 processes or transmits the diagnostic data

## 4. CM Core Command Processing

### 4.1 Command Types

The CM core can execute several types of commands from CPU1:

```cpp
enum CM_commands {
    comp_hash,      // Calculate SHA256 hash of application area
    gen_keys,       // Generate private and public keys
    sign_chall,     // Sign a hash using provided private key
    load_def_keys   // Load default keys to shared memory
};
```

### 4.2 Command Processing Flow

1. CPU1 sets the command in `shared_c1.cm_cmd`
2. CPU1 signals CM core via IPC flag (`IPC_setFlagLtoR(IPC_CM_L_CPU1_R, IPC_FLAG0)`)
3. CM core processes the command based on the command type:
   - `comp_hash`: Calculates SHA256 hash of application area
   - `gen_keys`: Generates private and public keys
   - `sign_chall`: Signs a hash using the provided private key
   - `load_def_keys`: Loads default keys to shared memory
4. CM core sets `shared_cm.ready = true` to indicate completion
5. CPU1 can then read the results from the shared memory

### 4.3 CM Core Initialization Sequence

```cpp
// CM core initialization sequence
CM_init();                                      // Initialize CM core
get_shared_cm();                                // Initialize shared RAM
IPC_setFlagLtoR(IPC_CM_L_CPU1_R, IPC_FLAG0);    // Signal CPU1 that CM is ready
IPC_waitForFlag(IPC_CM_L_CPU1_R, IPC_FLAG1);    // Wait for CPU1 to finish startup
```

## 5. Synchronization Mechanisms

### 5.1 IPC Flags

The system uses IPC flags for synchronization between cores:

```cpp
// CM core signals CPU1 that it's ready
IPC_setFlagLtoR(IPC_CM_L_CPU1_R, IPC_FLAG0);

// CM core waits for CPU1 to finish startup
IPC_waitForFlag(IPC_CM_L_CPU1_R, IPC_FLAG1);
```

### 5.2 Ready Flags

The CM core uses a ready flag to indicate command completion:

```cpp
shared_cm.ready = false;  // Clear ready flag before processing
// Process command...
shared_cm.ready = true;   // Set ready flag when done
```

### 5.3 Hardware Synchronization via GPIO

The system uses GPIO pins for hardware-level synchronization:

```cpp
namespace MCxx::GPIOname {
    static const GPIOid gpio_hrtbeat2_out      = gpio_024; // OUT
    static const GPIOid gpio_int_hrtbeat_in    = gpio_030; // IN
}
```

These pins implement heartbeat signals between cores to monitor each other's operational status.

## 6. Network Communication Path

### 6.1 Packet Routing Architecture

The CM core implements a packet routing system for network communication:

```cpp
class Ipc_cm {
    Rtable_t rtable;                                                // Routing table
    Base::Address_tunnel addr_tunnel;                               // Address handler tunnel
    Stanag::Stanag_suite_lite stg_suite;                            // Stanag suite
    Base::Fifo_port<Spkt_fifo::Writer, Spkt_fifo::Reader> cm_port;  // Port to read/write messages from/to C1
};
```

### 6.2 Communication Flow

1. CPU1 writes packets to `CPU1_CM_shared.udp_writer`
2. CM core reads packets from `CM_CPU1_shared.udp_reader`
3. CM core processes packets through its routing system
4. CM core writes response packets to `CM_CPU1_shared.udp_writer`
5. CPU1 reads response packets from `CPU1_CM_shared.udp_reader`

### 6.3 Network Configuration

Network configuration parameters are stored in the shared memory:

```cpp
Uint64 eth_mac;    // Ethernet MAC address
Uint32 ip_addr;    // IP address
Uint32 net_mask;   // IP network mask
Uint16 port_stg;   // UDP port for STANAG messages
Uint16 port_cy;    // UDP port for Cyphal messages
```

## 7. Memory Mapping Relationships

### 7.1 Memory Address Mapping

The system uses specific memory addresses for shared regions:

| Region | Address | Description |
|--------|---------|-------------|
| CPU1TOCMMSGRAM | 0x20080000 | CPU1 to CM shared memory |
| CMTOCPU1MSGRAM | 0x00038000 | CM to CPU1 shared memory |
| CPU1TOCPU2 | 0x03A000 | CPU1 to CPU2 shared memory |
| CPU2TOCPU1 | 0x03B000 | CPU2 to CPU1 shared memory |

### 7.2 Memory Access Methods

Each core accesses shared memory through specific accessor functions:

```cpp
// In CPU1:
CPU1_CM_shared& get_shared_c1();                // Get CPU1-owned shared memory
const volatile CM_CPU1_shared& get_shared_cm();  // Get CM-owned shared memory

// In CM:
const volatile CPU1_CM_shared& get_shared_c1();  // Get CPU1-owned shared memory
CM_CPU1_shared& get_shared_cm();                 // Get CM-owned shared memory
```

### 7.3 Memory Size Constraints

The system includes compile-time checks to ensure memory structures have consistent sizes across cores:

```cpp
struct CPU1_CM_shared_size_check {
    static void check() {
        static const Uint32 fifo_sz = size_bytes_t<Spkt_fifo::Writer>::value;
        static const Uint32 hash_size = size_bytes_t<Base::Sha256_data::Type>::value;
        static const Uint32 prv_size = size_bytes_t<Base::Prv_key::Type>::value;
        static const Uint32 pub_size = size_bytes_t<Base::Pub_key::Type>::value;
        static const Uint32 sign_size = size_bytes_t<Base::Signature::Type>::value;

        Base::Size_check<CPU1_CM_shared, fifo_sz + 120U>();
        Base::Size_check<CM_CPU1_shared, fifo_sz + 14U + hash_size + prv_size + pub_size + sign_size>();
    }
};
```

## 8. Fault Reporting and Handling

### 8.1 Fault Detection

The system implements fault detection mechanisms across cores:

- CPU2 detects motor control faults
- CPU1 detects system-level faults
- CM core detects communication faults

### 8.2 Fault Propagation

Faults are propagated between cores through shared memory:

```cpp
// In shared memory
struct C1_owned {
    // ...
    faults;            // Fault status from CPU1
    terminal_fault;    // Critical fault from CPU1
    // ...
};

struct C2_owned {
    // ...
    faults;            // Fault status from CPU2
    msk_critical;      // Mask for critical errors
    critical_fault;    // Flag indicating a terminal fault
    // ...
};
```

### 8.3 Fault Handling Flow

1. Core detects a fault condition
2. Fault is recorded in shared memory
3. Other cores read fault status from shared memory
4. System responds according to fault severity:
   - Non-critical faults: Logged and reported
   - Critical faults: System shutdown initiated

## 9. ESC Station Identification System

The system includes a mechanism for identifying ESC (Electronic Speed Controller) stations:

```cpp
enum StationName {
    kRightRear   = 0U,    // Right-rear. (Node_id = 10) 5
    kRightCenter = 1U,    // Right-center.(Node_id = 11) 3
    kRightFront  = 2U,    // Right-front.(Node_id = 12) 1
    kLeftFront   = 3U,    // Left-front.(Node_id = 13) 0
    kLeftCenter  = 4U,    // Left-center.(Node_id = 14) 2
    kLeftRear    = 5U     // Left-rear. (Node_id = 15) 4
};
```

This identification system is used for routing motor control commands to the appropriate ESC.

## Referenced Context Files

The following context file provided valuable insights for understanding the shared memory system:

- `05_Shared_Memory_System.md`: Provided detailed information about the shared memory architecture between CPU1 and CPU2, variable management system, and cross-core FIFO communication.

The IPC system forms the backbone of the multi-core motor controller architecture, enabling efficient data exchange, command processing, and fault handling across the three processing cores. The well-defined memory ownership boundaries, synchronization mechanisms, and communication protocols ensure reliable operation in this distributed processing environment.