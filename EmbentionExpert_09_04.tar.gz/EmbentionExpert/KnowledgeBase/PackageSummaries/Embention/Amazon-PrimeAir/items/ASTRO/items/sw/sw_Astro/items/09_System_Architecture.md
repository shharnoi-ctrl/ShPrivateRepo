# Generated from:

- _sw_Veronte/code/veronte/code/include/Veronte.h (1882 tokens)
- _sw_Veronte/code/veronte/code/source/Veronte.cpp (7801 tokens)
- _sw_Veronte/code/veronte/code/source/Veronte_dsp.cpp (1975 tokens)
- _sw_Veronte/code/veronte/code/include/Veronte_fs.h (625 tokens)
- _sw_Veronte/code/veronte/code/source/pa/Veronte_amz.cpp (2736 tokens)
- _sw_Veronte/code/veronte/code/source/ver/Veronte_ver.cpp (2185 tokens)
- _sw_Veronte/code/veronte/code/source_SIL/Veronte_SIL.cpp (2034 tokens)
- _sw_Veronte/code/veronte/code/include/Hsys.h (905 tokens)
- _sw_Veronte/code/veronte/code/source/Hsys.cpp (495 tokens)
- _sw_Veronte/code/veronte/code/source/cpu1/Hsys_cpu1.cpp (154 tokens)
- _sw_Veronte/code/veronte/code/include/common/System_variant.h (258 tokens)
- _sw_Veronte/code/veronte/code/include/common/HWversion.h (284 tokens)
- _sw_Veronte/code/veronte/code/include/common/Code_hash.h (104 tokens)
- _sw_Veronte/code/veronte/code/include/common/HWrev_pa.h (87 tokens)
- _sw_Veronte/code/veronte/code/include/pa/System_defs.h (75 tokens)
- _sw_Veronte/code/veronte/code/include/Reset_ver.h (168 tokens)
- _sw_Veronte/code/veronte/code/source/Reset_ver_pa.cpp (91 tokens)

---

# Veronte System Architecture

This document provides a comprehensive summary of the Veronte system architecture, focusing on the main Veronte class, system initialization flow, cross-core communication mechanisms, boot mode initialization state machine, and system variants.

## 1. Main Veronte Class Structure

The `Veronte` class serves as the main container class for the system, instantiating and managing core components across the system. It's designed to operate in a multi-core environment with CPU1, CPU2, and CM (Communications Manager) cores.

### 1.1 Key Components

The `Veronte` class contains numerous member variables that represent different subsystems:

```cpp
// Core system components
Base::Session&              ss;             // Session info
DFS2::DFS2_fs&              dfs2_fsd;       // File system descriptor
Base::Xcfilesvc&            xcfilesv;       // Cross-core file service
Rtable_ver                  rtable;         // Routing table
Midlevel::Comstats          com_stats;      // Communication statistics
Stanag::Stanag_suite        stg_suite;      // STANAG protocol suite

// Cross-core communication
Base::Fifo_port<Ver::Spkt_fifo::Writer,
                Ver::Spkt_fifo::Reader> cm_port;  // Port for CM core communication

// Hardware and telemetry
Base::Stepper<Halsuite>     hal_step;       // Hardware abstraction layer stepper
Tmsuite                     tm;             // Telemetry suite
Midlevel::Irxfw::Fw         irx_fw;         // IRX forwarding to CPU2
Midlevel::Cmdmgr            cmd;            // Command manager
Base::Actmgr                actm;           // Action manager

// Logging and file management
Logbook                     lbook;          // Logbook
Licmgr                      lic;            // License manager
Media::Discovery            discover;       // Discovery protocol
Maps_updater                maps_updt;      // Map partition update mechanism
Vfspermission               vfsperm;        // File system permissions
Media::Filecom              fcom;           // File communications manager
Base::Bootlog               bootlog;        // Boot command handler
Reset_ver                   reset_hnd;      // Reset platform handler
Media::Maint_mode_bl        mmode;          // Maintenance mode manager
Midlevel::Sysreset          sysreset;       // Reset handler
Media::HformatSD            format_sd;      // Format SD command handler

// System monitoring and management
Vcfchecker                  vfreqchecker;   // Communication frequency checker
Rtaskio                     rt;             // CIO real-time task
Midlevel::Sniffer           sniff;          // Veronte sniffer
Base::Xcpktrd               xpkr;           // Cross-core packet reader
ADCsuite                    adc_suite;      // ADC suite
Bitmgr                      bitm;           // Bit manager for PBIT, CBIT

// Logging components
Media::Logctrl              fdperiodic;     // Log manager for periodic logs
Media::Logctrl              fdevent;        // Log manager for event logs
Media::Logctrl              lmgr_xcffastsvc;// Log manager for fast logs
Media::Fdr                  file_dat_rec;   // File data recording

// Private implementation
Veronte_pimpl&              impl;           // Reference to private implementation
```

### 1.2 Private Implementation Pattern

The `Veronte` class uses the PIMPL (Pointer to Implementation) pattern through the `Veronte_pimpl` struct, which contains system variant-specific implementations:

- For standard Veronte variant (`var_ver`):
  - GPIO configuration
  - STANAG joystick
  - Atmospheric parameters transmitter
  - Navigation handlers
  - STANAG configurable messages manager

- For Astro/PA variant:
  - Cyphal message ID generator
  - Software configuration check components
  - Maintenance action handlers
  - Diverse communications components

## 2. System Initialization Flow

### 2.1 Constructor Initialization

The `Veronte` constructor initializes all subsystems in a specific order:

1. Basic system components (session, file system)
2. Cross-core file service
3. Routing table from cross-core data
4. Communication statistics
5. STANAG protocol suite
6. CM port for cross-core communication
7. Hardware abstraction layer
8. Telemetry and command management
9. Logging and file management systems
10. System monitoring components

After initialization, it:
1. Registers steps in the Step Manager for execution scheduling
2. Registers commands in the Command Manager
3. Registers cross-core configuration components
4. Sets up IRX forwarding to CPU2
5. Configures STANAG message handlers
6. Initializes the logbook and license checking

### 2.2 Boot Mode Initialization

The `boot_mode_init` method implements a state machine that coordinates the boot process across multiple cores:

```cpp
void Veronte::boot_mode_init(bool force_maintenance)
{
    // Start in maintenance state unless overridden
    const Evar<Loadst> c2_loadst(Base::vu_cfg_loadst);
    Loadst last_lst = lst_maintenance;
    if(!force_maintenance) {
        last_lst = bootlog.load();
    }
    
    // Synchronize with CPU2
    Hsys::set_loadst_requested(last_lst);                     // Sync 1
    Dsp28335_ent::Ipc::cpu1_wait_for_unlock();                // Sync 2
    
    // Process cross-core file service while waiting for CPU2
    while(!lst_is_done(c2_loadst.get())) {                    // Sync 3
        Base::Stepmgr::get_instance().run(Stepmgr::step_xcfile);
    }
    
    // Get load state and continue initialization
    last_lst = c2_loadst.get();
    Hsys::set_loadst_requested(lst_ongoing);
    Xcfgmgr::get_instance().step();
    maps_updt.init();
    
    Dsp28335_ent::Ipc::cpu2_unlock();                         // Sync 4
    Dsp28335_ent::Ipc::cpu1_wait_for_unlock();                // Sync 4.1
    
    // Check PDI correctness
    const bool c1_normal = Bsp::Hbvar(kbit_pdi).get();
    const bool c2_maintenance = (last_lst == lst_maintenance);
    
    if(!c1_normal && !c2_maintenance) {
        // PDI not correct and not in maintenance mode
        Bsp::set_sysaddr(Address(Bsp::get_uid().phy));
        last_lst = lst_failed;
        Hsys::set_loadst_requested(last_lst);                 // Sync 5
        while(c2_loadst.get()!=lst_failed) {}                 // Sync 6
        Xcfgmgr::get_instance().step();
    } else {
        Hsys::set_loadst_requested(last_lst);                 // Sync 5
    }
    
    // Start real-time tasks based on boot mode
    const bool is_normal = (last_lst == lst_normal);
    rt.start(is_normal);
    rt.get_xpcu8_suite().config_fmsgs(vfreqchecker.get(fmset));
    fcom.add_resource(static_cast<Uint8>(pdif_part), fcom_file);
    
    if(is_normal) {
        // Normal mode initialization
        Pfields non_volfields(fdperiodic, periodiclogs_part, dfs2_fsd, 
                             Hxcfield::get_kfstrpfields());
        non_volfields.restore_fields();
        config_gpio();
    } else {
        // Maintenance mode initialization
        fcom.add_resource(static_cast<Uint8>(eventlogs_part), fcom_file);
        fcom.add_resource(static_cast<Uint8>(periodiclogs_part), fcom_file);
        fcom.add_resource(static_cast<Uint8>(fastlogs_part), fcom_file);
        fcom.add_resource(static_cast<Uint8>(gravitational_part), fcom_file);
        fcom.add_resource(static_cast<Uint8>(magneticfield_part), fcom_file);
        fcom.add_resource(static_cast<Uint8>(geoide_part), fcom_file);
        fcom.add_resource(static_cast<Uint8>(client_part), fcom_file);
        
        if(last_lst == lst_maintenance) {
            maintenance_actions();
            config_gpio();
        }
    }
    
    post_cfg_read(is_normal);
    bootlog.save(last_lst);
    
    Halsuite::get_instance().can_fd.clear_rx_mbs();
    Halsuite::get_instance().enable_global_isr();
    Halsuite::get_instance().post_init(is_normal);
}
```

### 2.3 Boot Mode State Machine

The boot process follows a state machine with synchronization points between CPU1 and CPU2:

1. **Initial State**:
   - Start in maintenance mode unless overridden
   - Load boot state from bootlog if not forcing maintenance

2. **Sync 1**: CPU1 sets load state for CPU2 to read

3. **Sync 2**: CPU1 waits for CPU2 to reach its load configuration point

4. **Sync 3**: While waiting for CPU2 to complete loading:
   - Process cross-core file service to allow CPU2's ConfigManager to load PDIs

5. **Load Configuration**:
   - Get final load state from CPU2
   - Set system to "ongoing" load state
   - Load CPU1's PDIs from shared memory

6. **Sync 4**: Unlock CPU2 to continue execution

7. **Sync 4.1**: Wait for CPU2 to update system variables

8. **PDI Validation**:
   - Check if PDI is correct
   - If PDI incorrect and not in maintenance mode:
     - Set system address to physical address
     - Set load state to failed
     - Wait for CPU2 to acknowledge failure (Sync 6)
     - Reload PDIs

9. **System Initialization**:
   - Start real-time tasks based on boot mode
   - Configure communication components
   - Initialize file system resources

10. **Mode-Specific Initialization**:
    - Normal mode: Restore persistent fields, configure GPIO
    - Maintenance mode: Add additional file system resources, perform maintenance actions

11. **Final Initialization**:
    - Configure STANAG ports
    - Save boot state to bootlog
    - Enable interrupts
    - Complete hardware initialization

### 2.4 SIL (Software-In-Loop) Implementation

For simulation environments, the boot process is implemented as an explicit state machine:

```cpp
enum Cpu1_init_state {
    c1_sync0,  // Initial state
    c1_sync1,  // Wait for CPU2 unlock
    c1_sync2,  // Process cross-core file service
    c1_sync3,  // Load configuration and continue
    c1_sync4   // Completed state
};
```

The SIL implementation breaks the boot process into discrete steps that can be executed incrementally in a simulation environment, maintaining the same synchronization points with CPU2.

## 3. Cross-Core Communication Mechanisms

The Veronte system operates across multiple cores (CPU1, CPU2, and CM) with several mechanisms for inter-core communication:

### 3.1 Shared Memory Structures

The system uses shared memory regions for cross-core data exchange:

```cpp
// CPU1-CM shared data
CPU1_CM_shared::udp_writer  // Writer for CM core
CPU1_CM_shared::udp_reader  // Reader from CM core

// CPU1-CPU2 shared data
Xc::Xcd_cpu1  // CPU1 cross-core data
Xc::Xcd_cpu2  // CPU2 cross-core data
```

### 3.2 Cross-Core File Service

The `Xcfilesvc` component provides file system access across cores:

```cpp
DFS2::File fd_xcfilesvc;  // File descriptor for cross-core file support
Base::Xcfilesvc& xcfilesv; // Cross-core file service
```

This allows one core to access files managed by another core, particularly important during boot when CPU2 needs to load PDIs through CPU1's file system.

### 3.3 FIFO Ports

The system uses FIFO (First-In-First-Out) ports for message passing between cores:

```cpp
Base::Fifo_port<Ver::Spkt_fifo::Writer, Ver::Spkt_fifo::Reader> cm_port;
```

This port connects CPU1 to the CM core for communication packet exchange.

### 3.4 Cross-Core Packet Reader

The `Xcpktrd` component reads packets from other cores:

```cpp
Base::Xcpktrd xpkr;  // Cross-core packet reader
```

### 3.5 IRX Forwarding

The `Irxfw` component forwards specific message types to CPU2:

```cpp
Midlevel::Irxfw::Fw irx_fw;  // IRX forwarding to CPU2
```

Messages registered with `irx_fw.add()` are automatically forwarded to CPU2 for processing.

### 3.6 Synchronization Mechanisms

The cores synchronize using IPC (Inter-Process Communication) primitives:

```cpp
Dsp28335_ent::Ipc::cpu1_wait_for_unlock();  // CPU1 waits for CPU2
Dsp28335_ent::Ipc::cpu2_unlock();           // CPU1 unlocks CPU2
```

These primitives ensure proper sequencing during boot and operation.

## 4. System Variants and Hardware Versions

The Veronte system supports multiple variants and hardware versions:

### 4.1 System Variants

```cpp
enum Id {
    var_unk,    // Unknown/Not computed
    var_ver,    // Standard Veronte variant
    var_bcs,    // BCS variant
    var_adsb,   // ADSB variant
    var_rid     // Remote ID variant
};
```

### 4.2 Hardware Versions

```cpp
enum Id {
    vunknown,   // Unknown/Not computed
    v4_0,       // Veronte 4.0
    v4_5,       // Veronte 4.5
    v4_7,       // Veronte 4.7
    v4_8,       // Veronte 4.8
    v4_10,      // Veronte 4.10
    v4_12       // Veronte 4.12
};
```

### 4.3 PA/Astro Hardware Revisions

```cpp
enum Revision {
    ev1     = 0x01, // Main EV1
    ev1_res = 0x02, // Revision EV1
    ev2     = 0x05, // Main EV2
    dv1     = 0x0B, // Revision DV1
    iaw     = 0x0C  // Revision IAW
};
```

### 4.4 Application Types

The system supports different application types:

```cpp
// From Bsp::get_uid().app
sapp_uapp    // U-Veronte application
sapp_pam     // PA Monitor application
sapp_par_nav // PA Recovery/Navigation application
```

## 5. File System Organization

The Veronte file system is organized into partitions for different purposes:

```cpp
enum fs_partition {
    pdif_part           = 0,  // Partition for PDIF files
    ramlogs_part        = 1,  // (Fictitious) partition for RAM files
    eventlogs_part      = 2,  // Partition for event logs
    periodiclogs_part   = 3,  // Partition for periodic logs
    fastlogs_part       = 4,  // Partition for fast logs
    reserved_part       = 5,  // Reserved partition
    gravitational_part  = 6,  // Partition for gravitational field files
    magneticfield_part  = 7,  // Partition for magnetic field files
    geoide_part         = 8,  // Partition for geoid altitudes files
    hgt1_part           = 9,  // Partition for HGT 1" files
    hgt3_part           = 10, // Partition for HGT 3" files
    client_part         = 11  // Partition for custom SRTM client files
};
```

The system supports different SD card sizes with varying numbers of partitions:
- 128GB SD card: 12 partitions
- 8GB SD card: 5 partitions
- Flash memory: 1 partition

Special files are stored in the PDIF partition:
```cpp
enum special_files {
    maps_update_file              = 1989, // File for map partitions update semaphore
    ram_logs_header_tmp_file      = 1990, // RAM logs file
    event_logs_header_tmp_file    = 1991, // Event logs file
    periodic_logs_header_tmp_file = 1992, // Periodic logs file
    fast_logs_header_tmp_file     = 1993, // Fast logs file
    tmpfile                       = 1994, // Temporary file
    flog                          = 1995, // Flight log file
    lic4                          = 1996, // License file
    lcobl                         = 1997, // Last booting list copy file
    lastbl                        = 1998  // Last booting list file
};
```

## 6. System Reset Mechanism

The system provides a reset mechanism through the `Reset_ver` class:

```cpp
class Reset_ver : public Base::Ireset {
public:
    Reset_ver();
    virtual void reset() const;
};
```

The reset implementation:
1. Informs the SUC (System Under Control) about the imminent reboot via `Arbiter::reset()`
2. Performs CPU reset via `Dsp28335_ent::Reset::reset0()`

## 7. System Load States

The system uses several load states to track boot progress:

```cpp
// From Base::Loadst enum
lst_maintenance  // Maintenance mode
lst_normal       // Normal operation mode
lst_ongoing      // Loading in progress
lst_failed       // Loading failed
lst_secure       // Secure bootloader mode
```

These states are used to coordinate the boot process across cores and determine the initialization path.

## 8. Cross-Component Relationships

### 8.1 Core Relationships

```
CPU1 <---> CPU2 <---> CM
  |          |         |
  v          v         v
File System  Navigation Communications
Telemetry    Control   External I/O
Hardware     Mission   
Monitoring   Planning
```

### 8.2 Main Component Interactions

```
                  +-------------+
                  |   Veronte   |
                  +------+------+
                         |
         +---------------+---------------+
         |               |               |
+--------v-------+ +-----v------+ +------v-------+
| File System    | | Hardware   | | Communication|
| - DFS2_fs      | | - Halsuite | | - Stanag_suite|
| - Xcfilesvc    | | - ADCsuite | | - cm_port    |
| - Maps_updater | | - GPIOapply| | - Comstats   |
+----------------+ +------------+ +--------------+
         |               |               |
+--------v-------+ +-----v------+ +------v-------+
| Logging        | | Monitoring | | Command & Ctrl|
| - Logbook      | | - Bitmgr   | | - Cmdmgr     |
| - Logctrl      | | - Sniffer  | | - Actmgr     |
| - Fdr          | | - Rtaskio  | | - Irxfw      |
+----------------+ +------------+ +--------------+
```

## 9. System Initialization Sequence Diagram

```
CPU1                                CPU2
  |                                   |
  |-- Set initial load state -------->|  (Sync 1)
  |                                   |
  |<-- Wait for CPU2 unlock ----------|  (Sync 2)
  |                                   |
  |-- Process cross-core file ------->|
  |   service while waiting           |
  |                                   |
  |<-- Signal load complete ----------|  (Sync 3)
  |                                   |
  |-- Set ongoing state ------------->|
  |-- Load CPU1 PDIs                  |
  |-- Initialize maps                 |
  |                                   |
  |-- Unlock CPU2 ------------------>|  (Sync 4)
  |                                   |
  |<-- Wait for system vars update ---|  (Sync 4.1)
  |                                   |
  |-- Check PDI correctness           |
  |   If not correct:                 |
  |   - Set failed state ------------>|  (Sync 5)
  |   - Wait for CPU2 ack ----------->|  (Sync 6)
  |   - Reload PDIs                   |
  |   Else:                           |
  |   - Set final state ------------->|  (Sync 5)
  |                                   |
  |-- Start RT tasks                  |
  |-- Configure system                |
  |-- Mode-specific initialization    |
  |-- Save boot state                 |
  |-- Enable interrupts               |
  |                                   |
```

## 10. Referenced Context Files

The following context files provided valuable information for understanding the Veronte system architecture:

1. `Veronte.h` - Defined the main Veronte class structure and interfaces
2. `Veronte.cpp` - Implemented the constructor and initialization logic
3. `Veronte_dsp.cpp` - Implemented the boot mode initialization state machine
4. `Veronte_fs.h` - Defined the file system organization
5. `Veronte_amz.cpp` - Implemented PA/Astro variant-specific functionality
6. `Veronte_ver.cpp` - Implemented standard Veronte variant-specific functionality
7. `Veronte_SIL.cpp` - Implemented the simulation-specific boot process
8. `Hsys.h` and `Hsys.cpp` - Defined system data handling interfaces
9. `System_variant.h` - Defined system variants
10. `HWversion.h` - Defined hardware versions
11. `Reset_ver_pa.cpp` - Implemented system reset functionality