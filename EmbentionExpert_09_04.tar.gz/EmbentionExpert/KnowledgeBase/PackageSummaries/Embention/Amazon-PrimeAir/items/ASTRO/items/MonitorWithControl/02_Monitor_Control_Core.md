# Generated from:

- items/sw_MonitorWithControl/code/main2/code/source/Blockfactory_pac.cpp (2959 tokens)

---

# Blockfactory Implementation Analysis

## 1. System Architecture and Core Components

The Blockfactory implementation serves as a central orchestration mechanism for control systems with primary and recovery capabilities. It manages the switchover between these systems and handles control execution flow.

### Key Components

- **Blockfactory Class**: Main class that initializes and manages the control system components
- **Data Structure**: Internal structure containing all working components and state
- **Control Builder**: Manages the control system implementation
- **Recovery Wrapper Control System Object (RWCSO)**: Manages inputs and outputs for the recovery system
- **Switchover Mechanism**: Logic to transition between primary and recovery systems
- **Profiling System**: Performance monitoring for control execution

## 2. Switchover Mechanism Between Primary and Recovery Systems

The switchover mechanism is a safety-critical component that manages transitions between primary and recovery control systems.

### Switchover Implementation

```cpp
void step_switch_over()
{
    static const volatile Real& user_clk = Bsp::Hrvar(Pa_system_vars::ctr_user_clk).get_kref();
    if(user_clk > 0.0F)
    {
        static Base::Timeout out(user_clk);
        if (out.expired())
        {
            // Update switchover output GPIOs
            static Dsp28335_ent::GPIO g_alert(Ver::get_gpio_switch_alert());
            static Dsp28335_ent::GPIO g_nalert(Ver::get_gpio_switch_nalert());
            g_alert.set_hi();
            g_nalert.set_lo();
            has_switchover_been_signalled_to_primary.set(true);
            has_switchover_been_signalled_to_recovery.set(true);
        }
    }
}
```

### Switchover State Variables

- `has_switchover_been_signalled_to_primary`: Indicates if primary system has been notified of switchover
- `has_switchover_been_signalled_to_recovery`: Indicates if recovery system has been notified of switchover

### Switchover GPIO Signals

- `g_alert`: GPIO signal for switchover alert
- `g_nalert`: Inverted GPIO signal for switchover alert

### Switchover Behavior by System Type

The switchover behavior varies based on system type:
- **EV1 Systems**: Both switchover and control steps are executed
- **Monitor Systems**: Only switchover step is executed
- **Other Systems**: Control step is executed, and switchover signals are read from GPIO feedback

## 3. Control Execution Flow and Performance Profiling

The control execution flow is managed through the `step_control()` method with integrated performance profiling.

### Control Flow Implementation

```cpp
void step_control()
{
    ctrl_profiling.tic();

    // Read inputs
    ctrl_in_profiling.tic();
    rwcso_input.step();
    ctrl_in_profiling.toc();

    // Execute Recovery Wrapper Control System object
    control.step(rwcso_input, rwcso_output);

    // Publish outputs
    rwcso_output.step();

    ctrl_profiling.toc();
}
```

### Performance Profiling Components

- `ctrl_in_profiling`: Measures input reading performance
  - Tracks maximum time: `Pa_system_vars::ctr_input_max`
  - Tracks average time: `Pa_system_vars::ctr_input_avg`

- `ctrl_profiling`: Measures overall control execution performance
  - Tracks maximum time: `Pa_system_vars::ctr_time_max`
  - Tracks average time: `Pa_system_vars::ctr_time_avg`

### Control Execution Sequence

1. Start overall profiling timer
2. Start input profiling timer
3. Read inputs via `rwcso_input.step()`
4. Stop input profiling timer
5. Execute control step via `control.step(rwcso_input, rwcso_output)`
6. Publish outputs via `rwcso_output.step()`
7. Stop overall profiling timer

## 4. System Type Detection Logic and Behavior Differences

The system implements different behaviors based on the system type, detected through the UID.

### System Type Detection

```cpp
const Bsp::Uid64 uid = Bsp::get_uid();
const bool is_ev1 = (uid.res <= Ku32::u2);
if(is_ev1)
{
    data.step_switch_over();
    data.step_control();
}
else
{
    const bool is_mon = (uid.app == Bsp::sapp_pam);
    if(is_mon)
    {
        data.step_switch_over();
    }
    else
    {
        static Dsp28335_ent::GPIO feedback(Ver::get_gpio_switch_fb());
        const bool signaled = feedback.get();
        data.has_switchover_been_signalled_to_primary.set(!signaled);
        data.has_switchover_been_signalled_to_recovery.set(signaled);
        data.step_control();
    }
}
```

### System Types and Behaviors

1. **EV1 Systems** (`uid.res <= Ku32::u2`):
   - Executes both switchover and control steps
   - Manages switchover timing internally

2. **Monitor Systems** (`uid.app == Bsp::sapp_pam`):
   - Executes only the switchover step
   - Responsible for signaling switchover to other systems

3. **Other Systems** (neither EV1 nor Monitor):
   - Reads switchover signal from GPIO feedback
   - Updates switchover state variables based on GPIO input
   - Executes control step
   - Does not manage switchover timing

## 5. Memory Management Strategies

The implementation employs several memory management strategies to ensure efficient operation.

### Memory Allocation Types

- **Internal Volatile Memory**: 
  ```cpp
  Base::Mblock<Uint16> mem_volatile;  // 14000 units of Uint16
  ```
  Used for temporary calculations and working memory

- **External Memory Allocation**:
  ```cpp
  data(*Base::Memmgr::get_instance().get_allocator(Base::Memmgr::external).allocate_new<Blockfactory::Data>(uav0, irxfw_parser))
  ```
  Used for persistent data structures

- **Internal Memory Allocation**:
  ```cpp
  dummy(*Base::Memmgr::get_instance().get_internal_allocator().allocate_new<Uint16>())
  ```
  Used for small, frequently accessed data

### Memory Usage for Mission Plan Data

- Mission plan data is stored in a dedicated structure
- File transfer mechanism is provided for mission data:
  ```cpp
  cyphal_file_mgr(mission_plan_data.data.to_mblock(), file_path.to_mblock(), mission_plan_data.mission_sz)
  ```

### Scheduler Memory Management

The implementation configures scheduler tables with complex memory management:
```cpp
Pa_scheduler::get_instance().cset(
        str,
        Base::Memmgr::get_instance().get_allocator(Base::Memmgr::external),
        uav0.mit[0],
        uav0.mit[1],
        data.mem_volatile);
```

## 6. Communication Interfaces with Other System Components

The Blockfactory implements extensive communication interfaces with other system components.

### Message Handlers

The system registers multiple message handlers for different message types:

```cpp
irxfw_parser.add_rx_hdl(Base::Stanag_msg_type::cyp_pa_mission_readiness, data.rwcso_input.get_msg_mission_readiness());
irxfw_parser.add_rx_hdl(Base::Stanag_msg_type::cyp_pa_diverse_comms_command_contingency, data.rwcso_input.get_msg_command_contingency());
irxfw_parser.add_rx_hdl(Base::Stanag_msg_type::cyp_pa_command_contingency_wrapper, data.rwcso_input.get_msg_command_contingency());
irxfw_parser.add_rx_hdl(Base::Stanag_msg_type::cyp_file_transfer, data.cyphal_file_mgr);
irxfw_parser.add_tx_hdl(Base::Stanag_msg_type::cyp_file_transfer, data.cyphal_file_mgr);
irxfw_parser.add_rx_hdl(Base::Stanag_msg_type::cyp_pa_upload_mission_plan_wrapper_rec, data.rwcso_input.get_msg_mission_plan_upload_metadata());
irxfw_parser.add_rx_hdl(Base::Stanag_msg_type::cyp_motor_rpm_cmd_a, data.rpm_tunnel);
irxfw_parser.add_rx_hdl(Base::Stanag_msg_type::cyp_motor_spin_dir_test_init, data.mon_motor_spin_test_init);
irxfw_parser.add_rx_hdl(Base::Stanag_msg_type::cyp_motor_spin_dir_test_result, data.mon_motor_spin_test_rcv);
irxfw_parser.add_rx_hdl(Base::Stanag_msg_type::cyp_maintenance_action_req, data.maint_action);
irxfw_parser.add_tx_hdl(Base::Stanag_msg_type::cyp_maintenance_action_res, data.maint_action);
```

### Message Types Handled

1. **Mission Control Messages**:
   - `cyp_pa_mission_readiness`
   - `cyp_pa_diverse_comms_command_contingency`
   - `cyp_pa_command_contingency_wrapper`
   - `cyp_pa_upload_mission_plan_wrapper_rec`

2. **File Transfer Messages**:
   - `cyp_file_transfer` (both rx and tx)

3. **Motor Control Messages**:
   - `cyp_motor_rpm_cmd_a`
   - `cyp_motor_spin_dir_test_init`
   - `cyp_motor_spin_dir_test_result`

4. **Maintenance Messages**:
   - `cyp_maintenance_action_req`
   - `cyp_maintenance_action_res`

### GPIO Communication

The system uses GPIO pins for hardware-level communication:
- `Ver::get_gpio_switch_alert()`: Alert signal for switchover
- `Ver::get_gpio_switch_nalert()`: Inverted alert signal for switchover
- `Ver::get_gpio_switch_fb()`: Feedback signal for switchover status

## 7. Safety-Critical Aspects

Several safety-critical aspects are evident in the implementation:

### Switchover Mechanism Safety

- **Dual Signaling**: Uses both normal and inverted GPIO signals (`g_alert` and `g_nalert`) to ensure reliable signaling
- **State Tracking**: Maintains explicit state variables for switchover signaling
- **Timeout-Based Triggering**: Uses a timeout mechanism to control switchover timing
- **System Type Awareness**: Adapts behavior based on system type to ensure proper coordination

### Performance Monitoring

- **Execution Time Tracking**: Monitors both maximum and average execution times
- **Separate Input Profiling**: Specifically profiles input reading operations
- **Overall Control Profiling**: Profiles the entire control execution cycle

### Redundancy

- **Primary and Recovery Systems**: Implements both primary and recovery control systems
- **Recovery Wrapper**: Uses a dedicated wrapper for the recovery control system
- **Input/Output Management**: Separate managers for inputs and outputs to ensure clean interfaces

### Motor Control Safety

- **Motor Spin Direction Testing**: Implements specific handlers for motor spin direction testing
- **RPM Command Tunneling**: Provides a tunneling mechanism for RPM commands between stabilizers

## 8. File-by-File Breakdown

### Blockfactory_pac.cpp

This file implements the Blockfactory class and its internal Data structure.

**Key Components**:
- `Blockfactory` class: Main orchestration class
- `Blockfactory::Data` struct: Contains all internal components and state
- Memory management for volatile and persistent data
- System type detection and behavior differentiation
- Switchover mechanism implementation
- Control execution flow with performance profiling
- Communication interface registration

**Main Methods**:
- `Blockfactory::Blockfactory()`: Constructor that initializes all components
- `Blockfactory::post_pdi_load()`: Builds the control system after PDI loading
- `Blockfactory::step_pre_gnc()`: Executes pre-GNC steps including switchover and control
- `Blockfactory::step_gnc()`: GNC step (currently empty)
- `Data::step_switch_over()`: Implements the switchover mechanism
- `Data::step_control()`: Implements the control execution flow

## 9. Cross-Component Relationships

### Control Flow Relationships

```
Blockfactory::step_pre_gnc()
  ├── Data::step_switch_over() [for EV1 and Monitor systems]
  │     └── GPIO signaling for switchover
  └── Data::step_control() [for EV1 and non-Monitor systems]
        ├── rwcso_input.step() [Read inputs]
        ├── control.step(rwcso_input, rwcso_output) [Execute control]
        └── rwcso_output.step() [Publish outputs]
```

### Memory Management Relationships

```
Blockfactory
  ├── External Memory Allocator
  │     └── Blockfactory::Data
  └── Data
        ├── Internal Memory Allocator
        │     └── dummy
        └── Internal Volatile Memory
              └── mem_volatile
```

### Communication Relationships

```
Blockfactory
  ├── irxfw_parser [Message handling]
  │     ├── RX Handlers
  │     │     ├── Mission Control Messages
  │     │     ├── File Transfer Messages
  │     │     ├── Motor Control Messages
  │     │     └── Maintenance Messages
  │     └── TX Handlers
  │           ├── File Transfer Messages
  │           └── Maintenance Response Messages
  └── GPIO Communication
        ├── Switch Alert Signal
        ├── Switch Inverted Alert Signal
        └── Switch Feedback Signal
```

## Safety-Critical Behavior During Switchover Events

The implementation ensures reliable operation during switchover events through several mechanisms:

1. **Timeout-Based Triggering**: Switchover is triggered based on a timeout mechanism using `user_clk`, ensuring it occurs at a controlled time.

2. **Dual GPIO Signaling**: Uses both normal (`g_alert`) and inverted (`g_nalert`) GPIO signals to ensure reliable signaling and detection of signal failures.

3. **State Tracking**: Maintains explicit state variables (`has_switchover_been_signalled_to_primary` and `has_switchover_been_signalled_to_recovery`) to track switchover status.

4. **System Type Adaptation**: Different system types (EV1, Monitor, Other) have different roles in the switchover process:
   - EV1 systems manage both switchover and control
   - Monitor systems only manage switchover
   - Other systems read switchover signals and execute control accordingly

5. **Performance Monitoring**: Continuously monitors execution times to ensure the system operates within expected performance parameters during switchover events.

6. **Clean Input/Output Separation**: Uses separate managers for inputs and outputs to ensure clean interfaces during switchover transitions.

7. **Recovery Wrapper**: Implements a dedicated wrapper for the recovery control system to ensure proper isolation and transition.

8. **Mission Plan Data Preservation**: Ensures mission plan data is preserved and accessible during switchover events.

9. **Motor Control Safety**: Implements specific handlers for motor control during maintenance and testing operations, which may occur during or after switchover events.

10. **Maintenance Action Support**: Provides mechanisms for maintenance actions that may be required during or after switchover events.