# Generated from:

- _sw_Veronte/code/vpgnc/code/include/Posfix.h (1320 tokens)
- _sw_Veronte/code/vpgnc/code/source/Posfix.cpp (404 tokens)
- _sw_Veronte/code/vpgnc/code/include/Gnssdata.h (242 tokens)
- _sw_Veronte/code/vpgnc/code/source/Gnssdata.cpp (256 tokens)
- _sw_Veronte/code/vpgnc/code/include/Gravity_extractor.h (1097 tokens)
- _sw_Veronte/code/vpgnc/code/source/Gravity_extractor.cpp (1052 tokens)
- _sw_Veronte/code/vpgnc/code/include/Rains.h (2098 tokens)
- _sw_Veronte/code/vpgnc/code/source/Rains.cpp (5116 tokens)
- _sw_Veronte/code/vpgnc/code/include/Rains_fw.h (74 tokens)

## With context from:

- PackageSummaries/Embention/Amazon-PrimeAir/items/ASTRO/items/sw/sw_Astro/items/06_VPGNC_Core.md (7671 tokens)

---

# Navigation Algorithms and State Estimation in VPGNC Framework

This comprehensive analysis details the navigation algorithms and state estimation components in the VPGNC framework, focusing on position fix management, GNSS data handling, gravity vector extraction, and the Error-State Extended Kalman Filter implementation.

## 1. Posfix Class: Position Fix Management

The `Posfix` class manages position fix bit computation based on different navigation sources. It serves as a centralized mechanism to determine and report the validity of position information.

### 1.1 Core Components and Responsibilities

```
+----------------+         +----------------+
|    Posfix      |-------->| System BIT     |
| (Position Fix  |         | Handlers       |
|  Management)   |         |                |
+----------------+         +----------------+
       |                          |
       v                          v
+----------------+         +----------------+
| Navigation     |         | Position Fix   |
| Source         |         | Status         |
| Selection      |         | Tracking       |
+----------------+         +----------------+
```

The `Posfix` class:
- Manages the general position fix BIT (Base::kbit_gpsnav)
- Interfaces with multiple navigation source BITs
- Provides methods to select the active navigation source
- Tracks the duration of valid position fixes

### 1.2 Member Variables

```cpp
Base::Chrono time_having_navigation_ok_chrono; // Timer for navigation validity tracking
Bsp::Hbvar navig_ok;     // Handler for general position fix BIT
const Bsp::Hbvar navekfnok;    // Handler for internal EKF position fix BIT
const Bsp::Hbvar navsimok;     // Handler for IRX simulation position fix BIT
const Bsp::Hbvar navextvcpok;  // Handler for IRX external navigation position fix BIT
const Bsp::Hbvar navextvarok;  // Handler for external variables navigation position fix BIT
const Bsp::Hbvar navextvn300;  // Handler for VN300 position fix BIT
const Bsp::Hbvar navextsen;    // Handler for external navigation sensor position fix BIT
```

### 1.3 Constructor Implementation

The constructor initializes all the BIT handlers to read from the fix bits corresponding to each navigation source:

```cpp
Posfix::Posfix() :
        time_having_navigation_ok_chrono(),
        navig_ok(Base::kbit_gpsnav),
        navekfnok(Base::kbit_insnav),
        navsimok(Base::kbit_simnav),
        navextvcpok(Base::kbit_extnav),
        navextvarok(Base::kbit_extnavvar),
        navextvn300(Base::kbit_extnavvn300),
        navextsen(Base::kbit_ext_nav)
{
}
```

### 1.4 Navigation Source Selection Methods

The class provides six methods to select different navigation sources:

1. **Internal EKF Navigation**:
   ```cpp
   void step_ekf() {
       set_navigation_ok(!navekfnok.get());
   }
   ```
   Sets the general position fix BIT to the negated value of the internal EKF position fix BIT.

2. **IRX Simulation Navigation**:
   ```cpp
   void step_sim() {
       set_navigation_ok(navsimok.get());
   }
   ```
   Sets the general position fix BIT to the value of the IRX simulation position fix BIT.

3. **IRX External Navigation**:
   ```cpp
   void step_ext() {
       set_navigation_ok(navextvcpok.get());
   }
   ```
   Sets the general position fix BIT to the value of the IRX external navigation position fix BIT.

4. **External Variables Navigation**:
   ```cpp
   void step_ext_var() {
       set_navigation_ok(navextvarok.get());
   }
   ```
   Sets the general position fix BIT to the value of the external variables navigation position fix BIT.

5. **VN300 Navigation**:
   ```cpp
   void step_ext_vn300() {
       set_navigation_ok(navextvn300.get());
   }
   ```
   Sets the general position fix BIT to the value of the VN300 position fix BIT.

6. **External Navigation Sensor**:
   ```cpp
   void step_ext_sen() {
       set_navigation_ok(navextsen.get());
   }
   ```
   Sets the general position fix BIT to the value of the external navigation sensor position fix BIT.

### 1.5 Position Fix Status Tracking

The `set_navigation_ok` method manages the position fix status and tracks the duration of valid position fixes:

```cpp
void Posfix::set_navigation_ok(const bool navigation_ok) {
    const bool old_navigation_ok = navig_ok.get();
    if(old_navigation_ok != navigation_ok) {
        if(navigation_ok) {
            time_having_navigation_ok_chrono.tic();
        } else {
            time_having_navigation_ok_chrono.cancel();
        }
    }
    navig_ok.set(navigation_ok);
    static Bsp::Hrvar time_having_navigation_ok(Base::v_gpsok_time);
    time_having_navigation_ok.set(time_having_navigation_ok_chrono.toc());
}
```

This method:
1. Checks if the navigation status is changing
2. If changing to valid, starts a timer
3. If changing to invalid, cancels the timer
4. Updates the general position fix BIT
5. Updates the system variable tracking the duration of valid position fixes

## 2. Gnssdata Class: GNSS Data Management

The `Gnssdata` class manages GNSS data sharing between CPU cores, specifically handling MSL (Mean Sea Level) and AGL (Above Ground Level) altitude information.

### 2.1 Core Components and Responsibilities

```
+----------------+         +----------------+
|   Gnssdata     |-------->| Cross-Core     |
| (GNSS Data     |         | Data Sharing   |
|  Management)   |         |                |
+----------------+         +----------------+
       |                          |
       v                          v
+----------------+         +----------------+
| GNSS Data      |         | MSL and AGL    |
| Synchronization|         | Calculation    |
+----------------+         +----------------+
```

The `Gnssdata` class:
- Monitors GNSS position updates from CIO (Communication Input/Output)
- Extracts MSL and AGL altitude information
- Publishes this information to system variables
- Implements the `Base::Istep` interface for periodic execution

### 2.2 Member Variables

```cpp
Bsp::Hrvar gnss0_msl;  // GNSS0 Mean Sea Level altitude
Bsp::Hrvar gnss0_agl;  // GNSS0 Above Ground Level altitude
Bsp::Hrvar gnss1_msl;  // GNSS1 Mean Sea Level altitude
Bsp::Hrvar gnss1_agl;  // GNSS1 Above Ground Level altitude
Base::Dsync::Reader hrd0;  // For GNSS0 Sync to detect position measurement update from CIO
Base::Dsync::Reader hrd1;  // For GNSS1 Sync to detect position measurement update from CIO
```

### 2.3 Constructor Implementation

The constructor initializes the system variable handlers:

```cpp
Gnssdata::Gnssdata() :
    gnss0_msl(Base::v_gps0_msl),
    gnss0_agl(Base::v_gps0_agl),
    gnss1_msl(Base::v_gps1_msl),
    gnss1_agl(Base::v_gps1_agl)
{
}
```

### 2.4 GNSS Data Processing

The `step` method processes GNSS data updates:

```cpp
void Gnssdata::step() {
    //GNSS Data share between cores
    if(!hrd0.is_valid()) {
        hrd0 = gnss_msl_agl(Base::Meas::mgps_int0, gnss0_msl, gnss0_agl);
    }

    if(!hrd1.is_valid()) {
        hrd1 = gnss_msl_agl(Base::Meas::mgps_int1, gnss1_msl, gnss1_agl);
    }
}
```

This method:
1. Checks if the GNSS0 reader is valid
2. If not, processes GNSS0 data and updates MSL/AGL variables
3. Checks if the GNSS1 reader is valid
4. If not, processes GNSS1 data and updates MSL/AGL variables

### 2.5 MSL and AGL Calculation

The `gnss_msl_agl` method calculates MSL and AGL altitudes from GNSS position data:

```cpp
Base::Dsync::Reader Gnssdata::gnss_msl_agl(Base::Meas::Meas_gps sen, Bsp::Hrvar& msl_id, Bsp::Hrvar& agl_id) {
    Base::Mposition p;
    Geo::Apos hpos;
    Base::Dsync::Reader hrd = Ver::Hmeas::get_kmeas().pos[sen].read(p);
    hpos.set_llh(p.pos_llh);
    Real msl = 0.0F;
    Real agl = 0.0F;
    hpos.get_ah(msl, agl);
    msl_id.set(msl);
    agl_id.set(agl);
    return hrd;
}
```

This method:
1. Reads position data from the specified GNSS sensor
2. Converts the position to a geographic position object
3. Extracts MSL and AGL altitudes
4. Updates the corresponding system variables
5. Returns the reader for synchronization tracking

## 3. Gravity_extractor Class: Gravity Vector Extraction

The `Gravity_extractor` class extracts the estimated gravity acceleration vector from accelerometer measurements by removing the dynamic acceleration component.

### 3.1 Core Components and Responsibilities

```
+----------------+         +----------------+
| Gravity_extractor|------->| Dynamic        |
| (Gravity Vector |        | Acceleration    |
|  Extraction)    |        | Removal         |
+----------------+         +----------------+
       |                          |
       v                          v
+----------------+         +----------------+
| Mode-Specific  |         | Estimated      |
| Processing     |         | Gravity Vector |
| Algorithms     |         | Output         |
+----------------+         +----------------+
```

The `Gravity_extractor` class:
- Processes accelerometer and gyroscope measurements
- Removes dynamic acceleration components based on the configured mode
- Provides the estimated gravity vector for attitude estimation algorithms
- Supports multiple operating modes for different vehicle types

### 3.2 Member Variables and Enumerations

```cpp
enum Mode {
    m_disabled    = 0U,  // (0) No dynamic acceleration correction done
    m_vbx_heading = 1U,  // (1) Most of the velocity is in the x-body axis direction (fixed wing)
    m_full        = 2U   // (2) Dynamic acceleration externally computed
};

const Maverick::Irvector3& fb;    // Accelerometer measurement in body axis [m/s^2]
const Maverick::Irvector3& pqr;   // Gyroscope measurement with corrected bias in body axis [rad/s]
Mode mode;                        // Mode of operation
Base::Vref vbx_ref;               // Estimated velocity x-body axis [m/s]
Base::Vref dax;                   // Dynamic acceleration in x-body axis [m/s^2]
Base::Vref day;                   // Dynamic acceleration in y-body axis [m/s^2]
Base::Vref daz;                   // Dynamic acceleration in z-body axis [m/s^2]
Maverick::Rvector3 gb;            // Estimated gravity from accelerometer measurements in body axis [m/s^2]
```

### 3.3 Constructor Implementation

The constructor initializes the class with references to sensor measurements:

```cpp
Gravity_extractor::Gravity_extractor(const Maverick::Irvector3& fb0,
                                     const Maverick::Irvector3& pqr0) :
    fb(fb0),
    pqr(pqr0),
    mode(m_disabled)
{
}
```

### 3.4 Gravity Vector Extraction Algorithm

The `step` method implements the gravity vector extraction algorithm:

```cpp
void Gravity_extractor::step() {
    gb.copy(fb);
    switch (mode) {
        case m_vbx_heading: {
            const Real vbx = vbx_ref.kget();
            gb[Ku16::u1] -= vbx * pqr[Ku16::u2];
            gb[Ku16::u2] += vbx * pqr[Ku16::u1];
            break;
        }
        case m_full: {
            gb[Ku16::u0] -= dax.kget();
            gb[Ku16::u1] -= day.kget();
            gb[Ku16::u2] -= daz.kget();
            break;
        }
        default: {
            break;
        }
    }
}
```

This method implements three different algorithms based on the configured mode:

1. **Disabled Mode (m_disabled)**:
   - No correction is applied
   - The gravity vector is set directly to the accelerometer measurement

2. **X-Body Heading Mode (m_vbx_heading)**:
   - Used for fixed-wing aircraft where most velocity is along the x-body axis
   - Applies the correction: gb = fb + (0, -vbx·ωz, vbx·ωy)
   - This is equivalent to gb = fb + vb × ωb with y and z components of vb set to zero

3. **Full Mode (m_full)**:
   - Used when dynamic acceleration is externally computed
   - Applies the correction: gb = fb - (dax, day, daz)
   - The dynamic acceleration components are provided externally

### 3.5 Configuration Management

The `cset` method deserializes the configuration from a PDI:

```cpp
void Gravity_extractor::cset(Base::Lossy_error& str) {
    str.get_enum16(mode);
    switch (mode) {
        case m_disabled: {
            break;
        }
        case m_vbx_heading: {
            vbx_ref.cset(str);
            break;
        }
        case m_full: {
            dax.cset(str);
            day.cset(str);
            daz.cset(str);
            break;
        }
        default: {
            str.failed(Base::err_gravity_ext);
            break;
        }
    }
}
```

This method:
1. Reads the operating mode from the configuration
2. Based on the mode, reads additional configuration parameters:
   - For m_vbx_heading: Reads the estimated x-body velocity reference
   - For m_full: Reads the dynamic acceleration components
3. Validates the mode and reports an error if invalid

## 4. Rains Class: Error-State Extended Kalman Filter

The `Rains` class implements an Error-State Extended Kalman Filter (EKF) for navigation state estimation, providing both a full EKF for complete navigation and a reduced EKF for vertical-only navigation.

### 4.1 Core Components and Responsibilities

```
+----------------+         +----------------+         +----------------+
|     Rains      |-------->|  Full EKF      |-------->|  State Vector  |
| (Error-State   |         | (with position |         | [drn dvn mis   |
|  EKF)          |         |  fix)          |         |  dfb dwb]      |
+----------------+         +----------------+         +----------------+
       |                          |                          |
       v                          v                          v
+----------------+         +----------------+         +----------------+
| Reduced EKF    |         | Measurement    |         | Covariance     |
| (vertical-only)|         | Processing     |         | Management     |
+----------------+         +----------------+         +----------------+
```

The `Rains` class:
- Implements a full 15-state Error-State EKF when position fix is available
- Falls back to a reduced 2-state vertical-only EKF when position fix is lost
- Processes various sensor measurements (GPS, magnetometer, etc.)
- Manages state covariance and process noise
- Provides corrections for position, velocity, attitude, and sensor biases

### 4.2 State Vector and Covariance Structure

The EKF state vector consists of:
- `drn`: Position error in NED frame [3 components]
- `dvn`: Velocity error in NED frame [3 components]
- `mis`: Misalignment (attitude error) [3 components]
- `dfb`: Accelerometer bias error [3 components]
- `dwb`: Gyroscope bias error [3 components]

The covariance matrix is stored in block form for efficiency:
```cpp
Maverick::Rmatrix3 P00;  // Position-Position covariance
Maverick::Rmatrix3 P01;  // Position-Velocity covariance
Maverick::Rmatrix3 P02;  // Position-Misalignment covariance
Maverick::Rmatrix3 P03;  // Position-Gyro bias covariance
Maverick::Rmatrix3 P04;  // Position-Accel bias covariance
Maverick::Rmatrix3 P11;  // Velocity-Velocity covariance
Maverick::Rmatrix3 P12;  // Velocity-Misalignment covariance
Maverick::Rmatrix3 P13;  // Velocity-Gyro bias covariance
Maverick::Rmatrix3 P14;  // Velocity-Accel bias covariance
Maverick::Rmatrix3 P22;  // Misalignment-Misalignment covariance
Maverick::Rmatrix3 P23;  // Misalignment-Gyro bias covariance
Maverick::Rmatrix3 P24;  // Misalignment-Accel bias covariance
Maverick::Rmatrix3 P33;  // Gyro bias-Gyro bias covariance
Maverick::Rmatrix3 P34;  // Gyro bias-Accel bias covariance
Maverick::Rmatrix3 P44;  // Accel bias-Accel bias covariance
```

### 4.3 Constructor Implementation

The constructor initializes the EKF with references to the navigation body and memory management:

```cpp
Rains::Rains(Vpunav& body0, Base::Memmgr::Type memtype):
    body(body0),
    ak(nxmax, memtype),
    Qagl(1),
    gpsok(Logicfsm::unknown),
    gpsok_long_time(FOUR),
    ins_timeout(ins_lic_timeout),
    Pk0(nxmax + 1U, nxmax + 1U, Base::Memmgr::external),
    drn_v(&ak[Gnc::Xrains::drn0]),
    dvn_v(&ak[Gnc::Xrains::dvn0]),
    mis_v(&ak[Gnc::Xrains::mis0]),
    dwb_v(&ak[Gnc::Xrains::dwb0]),
    dfb_v(&ak[Gnc::Xrains::dfb0]),
    inverse_ok(Base::kbit_inverse),
    xfull(false),
    obfuscated(false),
    npe2(Base::v_np_e2),
    epe2(Base::v_ep_e2),
    dpe2(Base::v_dp_e2),
    nve2(Base::v_nv_e2),
    eve2(Base::v_ev_e2),
    dve2(Base::v_dv_e2)
{
    // Initialize vectors and matrices
    ldat.R.zeros();
    ak.zeros();
    ldat.y.zeros();
    
    inverse_ok.set(true);
    
    Pk0.zeros();
    Qnfb.zeros();
    Qnwb.zeros();
    Qdwb.zeros();
    Qdfb.zeros();
    x3.P.zeros();
}
```

### 4.4 Position Fix Management

The `compute_posfix` method manages the transition between full and reduced EKF based on position fix status:

```cpp
void Rains::compute_posfix(const Gnc::Irainsld::Rawposvel& pv) {
    // Check position fix validity
    const bool fix_ok = pv.pos_fix_ok();
    static Bsp::Hbvar hfix(Base::kbit_ekfnav);
    hfix.set(fix_ok);
    
    // Process state transitions based on fix status
    switch (gpsok.step(fix_ok)) {
        case Logicfsm::neg_edge:  // Lost position fix
        {
            pfull_to_p3();  // Convert full covariance to reduced covariance
            xfull = false;  // Switch to reduced EKF
            ins_timeout.start();  // Start INS timeout
            obfuscated = false;
            break;
        }
        case Logicfsm::pos_edge:  // Gained position fix
        {
            pk_reset();  // Reset covariance matrix
            init_pos_vel(pv);  // Initialize position and velocity
            xfull = true;  // Switch to full EKF
            break;
        }
        case Logicfsm::neg_level:  // No position fix for extended period
        {
            if ((!obfuscated) && (!body.permission_pfix()) && ins_timeout.expired()) {
                body.obfuscate_pos2d();  // Obfuscate position for security
                obfuscated = true;
            }
            break;
        }
        default:
        {
            break;
        }
    }
}
```

This method:
1. Checks if the position fix is valid
2. Updates the EKF navigation bit
3. Processes state transitions based on fix status:
   - When losing fix: Converts to reduced EKF and starts timeout
   - When gaining fix: Resets covariance and initializes position/velocity
   - When in extended INS mode: Obfuscates position if timeout expired

### 4.5 Full EKF Prediction Step

The `predict_full` method implements the time update (prediction) step for the full EKF:

```cpp
void Rains::predict_full(Real dt) {
    // State transition matrix components
    const Maverick::Rmatrix3& Lnb = body.get_Lnb();
    Amw.scalecp(dt, Lnb);  // Amw = Lnb*dt
    
    // Compute Avm = skewm(fndt)
    const Maverick::Irvector3& fb = body.sen.get_fb();
    v3a.matvec(Amw, fb);  // fndt = Lnbdt * fb
    Avm.skewm(v3a);
    
    // Update position-position covariance
    m3a.sum_mt(P01, P01);
    m3a.lincmb_add(dt, P11);
    P00.lincmb_add(dt, m3a);
    P00.set_symmetricl();
    
    // Update position-velocity covariance
    b0.matmatT(P12, Avm);    // b0 = B21, reused later
    b4.matmatT(P14, Amw);    // b4 = B41
    m3a.sum(P11, b0);        // b0 = B21
    m3a.add(b4);            // b4 = B41
    P01.lincmb_add(dt, m3a);
    m3a.matmatT(P02, Avm);
    P01.add(m3a);
    m3a.matmatT(P04, Amw);
    P01.add(m3a);
    
    // Update remaining covariance blocks
    // [extensive matrix operations omitted for brevity]
    
    // Add process noise
    // Q in dvn nonzero from accelerometer noise
    Real dt2 = dt*dt;
    v3a.lincmb(dt2, Qnfb);
    m3a.zeros();
    m3a.set_diag(v3a);
    m3a.matthis(Lnb);
    const Maverick::Rmatrix3& Lbn = body.get_Lbn();
    m3a.thismat(Lbn);
    P11.add(m3a);
    
    // Q in drn nonzero (trapezoidal integral formula)
    m3a.scale(Const::ONEHALF*dt);
    P01.add(m3a);
    m3a.scale(Const::ONEHALF*dt);
    P00.add(m3a);
    
    // Q in mis nonzero from gyro noise
    v3a.lincmb(dt2, Qnwb);
    m3a.zeros();
    m3a.set_diag(v3a);
    m3a.matthis(Lnb);
    m3a.thismat(Lbn);
    P22.add(m3a);
    
    // Q in gyro bias random walk
    P33.element_add(u0, u0, dt2*Qdwb[pos_x]);
    P33.element_add(u1, u1, dt2*Qdwb[pos_y]);
    P33.element_add(u2, u2, dt2*Qdwb[pos_z]);
    
    // Q in acc. bias random walk
    P44.element_add(u0, u0, dt2*Qdfb[pos_x]);
    P44.element_add(u1, u1, dt2*Qdfb[pos_y]);
    P44.element_add(u2, u2, dt2*Qdfb[pos_z]);
}
```

This method:
1. Computes the state transition matrix components
2. Updates all blocks of the covariance matrix
3. Adds process noise to the covariance matrix:
   - Accelerometer noise affecting velocity states
   - Velocity noise propagating to position states
   - Gyroscope noise affecting attitude states
   - Random walk noise for gyroscope and accelerometer biases

### 4.6 Full EKF Measurement Update

The `load_full` method implements the measurement update step for the full EKF:

```cpp
void Rains::load_full() {
    // Compute H*P (measurement model * covariance)
    HP.drn.matmat(ldat.H.drn, P00);
    HP.drn.matmatT_add(ldat.H.dvn, P01);
    HP.drn.matmatT_add(ldat.H.mis, P02);
    HP.drn.matmatT_add(ldat.H.dwb, P03);
    HP.drn.matmatT_add(ldat.H.dfb, P04);
    
    // [Additional HP computations omitted for brevity]
    
    // Compute innovation covariance S = HPH' + R
    s_mat.matmatT(HP.drn, ldat.H.drn);
    s_mat.matmatT_add(HP.dvn, ldat.H.dvn);
    s_mat.matmatT_add(HP.mis, ldat.H.mis);
    s_mat.matmatT_add(HP.dwb, ldat.H.dwb);
    s_mat.matmatT_add(HP.dfb, ldat.H.dfb);
    s_mat.add_diag(ldat.R);  // Add measurement noise
    
    // Compute inverse of innovation covariance
    compute_is_mat();
    
    // Compute Kalman gain K = PH'S^-1
    K.drn.matTmat(HP.drn, is_mat);
    K.dvn.matTmat(HP.dvn, is_mat);
    K.mis.matTmat(HP.mis, is_mat);
    K.dwb.matTmat(HP.dwb, is_mat);
    K.dfb.matTmat(HP.dfb, is_mat);
    
    // Update state vector with measurement
    drn_v.matvec(K.drn, ldat.y);
    dvn_v.matvec(K.dvn, ldat.y);
    mis_v.matvec(K.mis, ldat.y);
    dwb_v.matvec(K.dwb, ldat.y);
    dfb_v.matvec(K.dfb, ldat.y);
    
    // Update covariance P = P - KHP
    P00.matmat_sub(K.drn, HP.drn);
    P01.matmat_sub(K.drn, HP.dvn);
    P02.matmat_sub(K.drn, HP.mis);
    P03.matmat_sub(K.drn, HP.dwb);
    P04.matmat_sub(K.drn, HP.dfb);
    
    // [Additional covariance update operations omitted for brevity]
    
    // Compute misalignment rotation matrix
    preLhb.euler321abc2L01(mis_v[Ku16::u2], mis_v[Ku16::u1], mis_v[Ku16::u0]);
}
```

This method:
1. Computes the product of the measurement model and covariance matrix
2. Computes the innovation covariance (S = HPH' + R)
3. Computes the inverse of the innovation covariance
4. Computes the Kalman gain (K = PH'S^-1)
5. Updates the state vector with the measurement
6. Updates the covariance matrix (P = P - KHP)
7. Computes the misalignment rotation matrix from the attitude error state

### 4.7 Reduced EKF Implementation

The reduced EKF operates when position fix is lost, focusing only on vertical position and velocity:

```cpp
void Rains::step_min(Real dt) {
    ak.zeros();
    
    // Update covariance P = APAt + Q
    Real p12dt = dt*x3.P.get(0, 1);
    Real p22dt = dt*x3.P.get(1, 1);
    Real p23dt = dt*x3.P.get(1, 2);
    x3.P.element_add(0, 0, p22dt*dt+TWO*p12dt);
    x3.P.element_add(0, 1, p22dt);
    x3.P.element_add(1, 0, p22dt);
    
    // Add process noise
    const Irmatrix3& Lnb = body.get_Lnb();
    Real dt2 = dt*dt;
    Real Qvz = dt2*(
            Qnfb[0]*Lnb.get(2,0)*Lnb.get(2,0) +
            Qnfb[1]*Lnb.get(2,1)*Lnb.get(2,1) +
            Qnfb[2]*Lnb.get(2,2)*Lnb.get(2,2) );
    x3.P.element_add(0, 0, Qvz*dt2*Const::ONEFOURTH);
    x3.P.element_add(0, 1, Qvz*dt*Const::ONEHALF);
    x3.P.element_add(1, 0, Qvz*dt*Const::ONEHALF);
    x3.P.element_add(1, 1, Qvz);
}

void Rains::load_min() {
    static const Gnc::Xrains::Xis x0 = Gnc::Xrains::drn2;
    static const Gnc::Xrains::Xis x1 = Gnc::Xrains::dvn2;
    
    hfull_to_h3();
    
    // Compute innovation covariance S = HPH' + R
    x3.HP.matmat(x3.H, x3.P);
    s_mat.matmatT(x3.HP, x3.H);
    s_mat.add_diag(ldat.R);
    
    // Compute inverse of innovation covariance
    compute_is_mat();
    
    // Compute Kalman gain K = PH'S^-1
    x3.K.matTmat(x3.HP, is_mat);
    
    // Update state vector with measurement
    x3.a.matvec(x3.K, ldat.y);
    ak[x0] = x3.a[u0];
    ak[x1] = x3.a[u1];
    
    // Update covariance P = P - KHP
    x3.P.matmat_sub(x3.K, x3.HP);
}
```

These methods:
1. Update the reduced covariance matrix with the state transition model
2. Add process noise based on accelerometer measurements
3. Compute the innovation covariance and its inverse
4. Compute the Kalman gain
5. Update the vertical position and velocity states
6. Update the reduced covariance matrix

### 4.8 AGL Estimation

The `Rains` class also includes a separate first-order EKF for AGL (Above Ground Level) estimation:

```cpp
void Rains::step_agl(const Real dt) {
    const Real GSdt = Rfun::max<Real>(body.get_GS(), 1.0F)*dt;
    aglest.predict(Qagl*GSdt*GSdt);
}

void Rains::load_agl() {
    aglest.set_x(0.0F);  // Incremental filter
    aglest.update(ldat.y[0], ldat.R[0]);
}
```

These methods:
1. Predict the AGL state with process noise scaled by ground speed
2. Update the AGL state with measurements

### 4.9 Position and Velocity Initialization

The `init_pos_vel` method initializes position and velocity states from GNSS measurements:

```cpp
void Rains::init_pos_vel(const Gnc::Irainsld::Rawposvel& pv) {
    static const Maverick::Rvector3 zeros(0.0F, 0.0F, 0.0F);
    if (x3.P.get(0, 0) > (TWO*pv.get_vpe2())) {
        // Assign full position and velocity state (3D)
        body.init_rv_3d(pv.get_pos(), pv.vel_fix_ok() ? pv.get_vel() : zeros);
    } else {
        // Assign only horizontal position and velocity state (2D)
        body.init_rv_2d(pv.get_pos(), pv.vel_fix_ok() ? pv.get_vel() : zeros);
    }
}
```

This method:
1. Compares the vertical position uncertainty in the EKF with the GNSS vertical position uncertainty
2. If the EKF uncertainty is higher, initializes full 3D position and velocity
3. Otherwise, initializes only horizontal position and velocity, preserving the vertical component

### 4.10 Variance Reporting

The `commit_variances` method updates system variables with the current state uncertainties:

```cpp
void Rains::commit_variances() {
    if (xfull) {
        npe2.set(P00.get(Ku16::u0, Ku16::u0));
        epe2.set(P00.get(Ku16::u1, Ku16::u1));
        dpe2.set(P00.get(Ku16::u2, Ku16::u2));
        nve2.set(P11.get(Ku16::u0, Ku16::u0));
        eve2.set(P11.get(Ku16::u1, Ku16::u1));
        dve2.set(P11.get(Ku16::u2, Ku16::u2));
    } else {
        npe2.set(-1.0F);
        epe2.set(-1.0F);
        dpe2.set(x3.P.get(Ku16::u0, Ku16::u0));
        nve2.set(-1.0F);
        eve2.set(-1.0F);
        dve2.set(x3.P.get(Ku16::u1, Ku16::u1));
    }
}
```

This method:
1. If using the full EKF, updates all position and velocity variance variables
2. If using the reduced EKF, updates only vertical position and velocity variance variables, setting others to -1

## 5. Integration and Data Flow

### 5.1 Navigation State Estimation Flow

The navigation state estimation process follows this sequence:

1. **Sensor Data Processing**:
   - IMU measurements (accelerometer, gyroscope) are processed
   - GNSS measurements are processed when available
   - External navigation sources are integrated when configured

2. **Gravity Vector Extraction**:
   - `Gravity_extractor` removes dynamic acceleration from accelerometer measurements
   - The resulting gravity vector is used for attitude estimation

3. **Position Fix Management**:
   - `Posfix` determines the validity of position information
   - The selected navigation source provides position and velocity data

4. **EKF State Estimation**:
   - `Rains` performs prediction and update steps
   - Full EKF operates when position fix is available
   - Reduced EKF operates when position fix is lost
   - AGL estimation runs in parallel

5. **State Correction Application**:
   - EKF corrections are applied to position, velocity, attitude, and sensor biases
   - The corrected state is used for navigation and control

### 5.2 Cross-Component Interactions

```
+----------------+         +----------------+         +----------------+
|    Vpunav      |-------->|     Rains      |-------->|     Posfix     |
| (Navigation)   |         |     (EKF)      |         | (Position Fix) |
+----------------+         +----------------+         +----------------+
       |                          |                          |
       v                          v                          v
+----------------+         +----------------+         +----------------+
| Gravity_extractor|        |    Gnssdata    |         | System        |
| (Dynamic Accel  |        | (GNSS Data     |         | Variables      |
|  Removal)       |        |  Management)   |         |                |
+----------------+         +----------------+         +----------------+
```

Key interactions include:

1. **Vpunav and Rains**:
   - `Vpunav` provides sensor data to `Rains`
   - `Rains` provides state corrections to `Vpunav`
   - `Vpunav` applies corrections and updates dependent variables

2. **Vpunav and Gravity_extractor**:
   - `Vpunav` provides accelerometer and gyroscope data to `Gravity_extractor`
   - `Gravity_extractor` provides the estimated gravity vector to attitude estimation algorithms

3. **Rains and Posfix**:
   - `Rains` uses position fix status from `Posfix` to determine EKF mode
   - `Posfix` uses EKF status from `Rains` to update position fix bits

4. **Gnssdata and System Variables**:
   - `Gnssdata` processes GNSS measurements and updates system variables
   - These variables are used by other components for navigation and control

### 5.3 Error Handling and Robustness

The navigation system includes several mechanisms for error handling and robustness:

1. **Position Fix Loss Handling**:
   - Seamless transition from full to reduced EKF
   - Preservation of vertical state estimation
   - Position obfuscation after extended INS operation

2. **Measurement Validation**:
   - Innovation covariance scaling for outlier measurements
   - Adaptive measurement noise based on measurement quality

3. **Numerical Stability**:
   - Matrix inversion validation
   - Covariance symmetry enforcement
   - Fallback mechanisms when matrix operations fail

4. **External Navigation Integration**:
   - Multiple navigation sources supported
   - Priority-based source selection
   - Smooth transitions between sources

## 6. Key Algorithms and Mathematical Models

### 6.1 Error-State Extended Kalman Filter

The Error-State EKF differs from a standard EKF in that it estimates errors in the navigation state rather than the state itself. This approach has several advantages:
- Smaller linearization errors
- Better numerical stability
- More efficient computation

The filter operates in two modes:
1. **Full EKF (15 states)**: When position fix is available
   - Position error (3 states)
   - Velocity error (3 states)
   - Attitude error (3 states)
   - Accelerometer bias error (3 states)
   - Gyroscope bias error (3 states)

2. **Reduced EKF (2 states)**: When position fix is lost
   - Vertical position error (1 state)
   - Vertical velocity error (1 state)

### 6.2 Gravity Vector Extraction

The gravity vector extraction algorithm removes dynamic acceleration from accelerometer measurements using one of three approaches:

1. **No Correction** (m_disabled):
   - gb = fb
   - Used when dynamic accelerations are negligible

2. **X-Body Heading Correction** (m_vbx_heading):
   - gb = fb + (0, -vbx·ωz, vbx·ωy)
   - Used for fixed-wing aircraft
   - Assumes most velocity is along the x-body axis

3. **Full Correction** (m_full):
   - gb = fb - (dax, day, daz)
   - Used when dynamic acceleration is externally computed
   - Provides the most accurate gravity vector

### 6.3 Position Fix Management

The position fix management algorithm uses a state machine to track position fix status:

1. **Negative Edge** (losing fix):
   - Convert full covariance to reduced covariance
   - Switch to reduced EKF
   - Start INS timeout

2. **Positive Edge** (gaining fix):
   - Reset covariance matrix
   - Initialize position and velocity
   - Switch to full EKF

3. **Negative Level** (extended INS operation):
   - Obfuscate position if timeout expired and no permission
   - Continue operating in reduced EKF mode

## 7. Referenced Context Files

The following context file provided valuable information for understanding the VPGNC framework:

- `06_VPGNC_Core.md` - Provided overview of the VPGNC framework core components, including the Vpu class, Vpunav class, and variable management classes. This helped establish the broader context in which the navigation algorithms and state estimation components operate.

This file helped establish the relationship between the navigation components analyzed in this document and the broader VPGNC framework, particularly regarding the Vpunav class that integrates these components.