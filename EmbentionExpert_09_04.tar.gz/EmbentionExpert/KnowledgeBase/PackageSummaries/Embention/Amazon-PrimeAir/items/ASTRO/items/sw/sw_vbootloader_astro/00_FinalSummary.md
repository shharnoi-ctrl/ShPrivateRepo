# Generated from:

- PackageSummaries/Amazon-PrimeAir/items/ASTRO/items/sw/sw_vbootloader_astro/04_Bootloader_Core_Architecture.md (2297 tokens)
- PackageSummaries/Amazon-PrimeAir/items/ASTRO/items/sw/sw_vbootloader_astro/02_Hardware_Abstraction_Layer.md (3301 tokens)
- PackageSummaries/Amazon-PrimeAir/items/ASTRO/items/sw/sw_vbootloader_astro/03_Memory_Layout_Configuration.md (2769 tokens)
- PackageSummaries/Amazon-PrimeAir/items/ASTRO/items/sw/sw_vbootloader_astro/02_Storage_Management.md (1722 tokens)
- PackageSummaries/Amazon-PrimeAir/items/ASTRO/items/sw/sw_vbootloader_astro/02_Build_Configuration.md (3348 tokens)
- PackageSummaries/Amazon-PrimeAir/items/ASTRO/items/sw/sw_vbootloader_astro/02_Testing_Framework.md (5056 tokens)
- PackageSummaries/Amazon-PrimeAir/items/ASTRO/items/sw/sw_vbootloader_astro/01_System_Architecture_Overview.md (4312 tokens)

---

# Astro Bootloader System: Knowledge Graph Overview

## System Architecture Overview

The Astro bootloader is a sophisticated multi-core bootloader system designed for the Amazon Prime Air platform. It operates on a heterogeneous computing architecture with three distinct processor cores:

1. **C1 (Core 1)** - TI C2000 DSP: Main bootloader execution, application verification, security enforcement
2. **C2 (Core 2)** - TI C2000 DSP: Secondary processing, managed by C1
3. **CM (Cortex-M)** - ARM Cortex-M: Network communication, Ethernet interface, lwIP TCP/IP stack

The system implements a secure boot process with ECDSA signature verification, comprehensive hardware abstraction, and sophisticated inter-core communication mechanisms. It supports firmware updates over multiple interfaces and includes robust error recovery capabilities.

## Core Components

### Multi-Core Architecture
- **Hierarchical Class Structure**: `Bootloader` (base) → `Bootloader_dual` (intermediate) → `Bootloader_astro` (implementation)
- **Factory Pattern**: Singleton instance creation through `Bootloader_dual::build()`
- **Memory Architecture**: Different addressing schemes (16-bit word for DSP, 8-bit byte for ARM)
- **Inter-Core Communication**: Shared memory regions and IPC mechanisms

### Hardware Abstraction Layer
- **Hardware Identification**: GPIO-based detection of hardware variants and application types
- **Peripheral Configuration**: Comprehensive mapping of functional requirements to hardware-specific settings
- **Ethernet MII Configuration**: Dedicated configuration for CM core network communication

### Storage Management
- **Flash Interface**: SPI-C communication at 12.5MHz through MX66L driver
- **File System**: DFS2 (Dual File System 2) with 2000 files, 8 sectors per descriptor, 120 sectors per file
- **Partition Structure**: PDIF (Portable Data Interchange Format) partition type

### Security Features
- **Secure Boot**: DCSM configuration, application verification, ECDSA signature verification
- **Security Components**: Specialized libraries for both DSP and ARM cores
- **Secure Communication**: Protected CAN interfaces and encrypted external communication

### Build System
- **Hierarchical Configuration**: JSON-based build definitions for both cores
- **Core-Specific Builds**: Separate toolchains and configurations for DSP and ARM
- **Memory Layout**: Carefully coordinated memory regions and shared communication areas

## Detailed Information Links

For more detailed information on specific aspects of the system, refer to:

1. [Bootloader Core Architecture](04_Bootloader_Core_Architecture.md) - Core class structure, initialization sequence, and main execution flow
2. [Hardware Abstraction Layer](02_Hardware_Abstraction_Layer.md) - Hardware identification, GPIO configuration, and peripheral management
3. [Memory Layout Configuration](03_Memory_Layout_Configuration.md) - Memory maps, addressing schemes, and inter-processor communication regions
4. [Storage Management](02_Storage_Management.md) - DFS2 file system implementation and flash memory interface
5. [Build Configuration](02_Build_Configuration.md) - Build system structure, dependencies, and target configurations
6. [Testing Framework](02_Testing_Framework.md) - Comprehensive test suite with 21 test cases for validation

## Boot Sequence

1. **System Security Setup**: DCSM configuration and security key setup
2. **Parameter Configuration**: Memory regions and core management bitmap setup
3. **Shared Memory Setup**: Initialization of CPU1-CM shared memory structure
4. **CM Core Initialization**: Configuration and booting of the CM core
5. **Address Handler Setup**: Creation of Address_handler with system configuration
6. **Bootloader Instantiation**: Creation of bootloader instance through factory method
7. **Application Verification**: Validation of application headers and signatures
8. **Application Loading**: Loading of verified applications to appropriate cores

## Memory Architecture

```
C1 (DSP) Memory:                    CM (ARM) Memory:
- FLASH: 0x80000-0xBFFFF            - FLASH: 0x200000-0x27FFFF
  - Bootloader: 64KB                  - Bootloader: 128KB
  - Application: 192KB                - Application: 384KB
- RAM: RAMM, RAML, RAMS, RAMFUNCS   - RAM: C0RAM, C1RAM, ESRAM

Inter-Core Communication:
- CPUTOCMRAM: C1 to CM (0x039000-0x0397FF)
- CMTOCPURAM: CM to C1 (0x038000-0x0387FF)
```

This knowledge graph provides a comprehensive overview of the Astro bootloader system, with links to more detailed information on specific components and aspects of the architecture.