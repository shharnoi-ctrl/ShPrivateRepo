# Generated from:

- _sw_Veronte/code/veronte/code/include/cpu1/CPU1_CM_shared.h (208 tokens)
- _sw_Veronte/code/veronte/code/source/cpu1/CPU1_CM_shared.cpp (672 tokens)
- _sw_Veronte/code/veronte/code/include/cm/CM_CPU1_shared_types.h (953 tokens)
- _sw_Veronte/code/veronte/code/include/cm/CM_CPU1_shared.h (74 tokens)
- _sw_Veronte/code/veronte/code/source_SIL/CM_CPU1_shared.cpp (107 tokens)
- _sw_Veronte/code/veronte/code/include/cpu1/Xcdprivate.h (220 tokens)
- _sw_Veronte/code/veronte/code/include/cpu2/Xcdprivate.h (154 tokens)
- _sw_Veronte/code/veronte/code/include_SIL/Xcdprivate.h (109 tokens)
- _sw_Veronte/code/veronte/code/include_SIL/CM_CPU1_shared_types.h (615 tokens)
- _sw_Veronte/code/veronte/code/include_SIL/Fifo_shared_cm_cpu1.h (145 tokens)
- _sw_Veronte/code/veronte/code/source_SIL/Fifo_shared_cm_cpu1.cpp (78 tokens)
- _sw_Veronte/code/veronte/code/include/Xapsel_cpu1.h (64 tokens)
- _sw_Veronte/code/veronte/code/include/Xapsel_cpu2.h (209 tokens)
- _sw_Veronte/code/veronte/code/source/Xapsel_cpu2.cpp (72 tokens)
- _sw_Veronte/code/main1/code/source/Memm_cpu1_2837x.cpp (105 tokens)
- _sw_Veronte/code/main1/code/source/Memm_cpu1_2838x.cpp (122 tokens)
- _sw_Veronte/code/veronte/code/source/pa/Memm_cfg_amz.cpp (98 tokens)
- _sw_Veronte/code/veronte/code/source/ver/Memm_cfg_ver_2837x.cpp (98 tokens)
- _sw_Veronte/code/veronte/code/source/ver/Memm_cfg_ver_2838x.cpp (98 tokens)

## With context from:

- PackageSummaries/Embention/Amazon-PrimeAir/items/ASTRO/items/sw/sw_Astro/items/09_System_Architecture.md (5081 tokens)
- PackageSummaries/Embention/Amazon-PrimeAir/items/ASTRO/items/sw/sw_Astro/items/08_Multi_Core_Execution.md (6182 tokens)

---

# Cross-Core Communication and Shared Memory Architecture in the Veronte System

This document provides a comprehensive analysis of the cross-core communication mechanisms and shared memory architecture in the Veronte system, focusing on how data is shared between CPU1, CPU2, and the Communications Manager (CM).

## 1. Shared Memory Architecture Overview

The Veronte system employs a multi-core architecture with three distinct processing cores (CPU1, CPU2, and CM) that communicate through dedicated shared memory regions. The shared memory architecture is designed to facilitate efficient data exchange between cores while maintaining clear ownership boundaries.

### 1.1 Memory Layout and Organization

The shared memory is organized into distinct regions with specific addresses:

| Memory Region | Base Address | Description |
|---------------|--------------|-------------|
| CPU1-CM Shared | 0x00038000 | Communication between CPU1 and CM (CMTOCPU1MSGRAM) |
| CPU1-CPU2 Shared | Not explicitly defined | Cross-core data between CPU1 and CPU2 |

Each shared memory region has clear ownership semantics:
- CPU1 owns and writes to `CPU1_CM_shared` structures
- CM owns and writes to `CM_CPU1_shared` structures
- CPU1 owns and writes to `Xcd_cpu1` structures
- CPU2 owns and writes to `Xcd_cpu2` structures

### 1.2 Memory Allocation Configuration

The system defines specific memory sections for different purposes:

```cpp
// CPU1 memory allocation (2837x processor)
const Uint64 memmgr_int_buf_sz =    16UL;
const Uint64 memmgr_ext_buf_sz = 72260UL;
#pragma DATA_SECTION("MEMMGR_INT")
Uint16 memmgr_int_buf[memmgr_int_buf_sz];
#pragma DATA_SECTION("MEMMGR_EXT")
Uint16 memmgr_ext_buf[memmgr_ext_buf_sz];

// CPU1 memory allocation (2838x processor)
const Uint64 memmgr_all_sz     = 0x11E00UL;
const Uint64 memmgr_int_buf_sz = 2UL;
const Uint64 memmgr_ext_buf_sz = memmgr_all_sz - memmgr_int_buf_sz;
#pragma DATA_SECTION("MEMMGR_INT")
Uint16 memmgr_int_buf[memmgr_int_buf_sz];
#pragma DATA_SECTION("MEMMGR_EXT")
Uint16 memmgr_ext_buf[memmgr_ext_buf_sz];

// PA/Astro variant memory allocation
const Uint64 memmgr_int_buf_sz = 0x3E00UL;
const Uint64 memmgr_ext_buf_sz = 1500UL*1024UL;  // 1.5MB
#pragma DATA_SECTION("MEMMGR_INT")
Uint16 memmgr_int_buf[memmgr_int_buf_sz];
#pragma DATA_SECTION("MEMMGR_EXT")
Uint16 memmgr_ext_buf[memmgr_ext_buf_sz];
```

These memory sections are used by the memory manager to allocate memory for various system components, including shared memory structures.

## 2. CPU1-CM Shared Memory Structures

### 2.1 CPU1_CM_shared Structure (Owned by CPU1)

This structure contains data that CPU1 writes and CM reads:

```cpp
struct CPU1_CM_shared {
    // Communication FIFOs
    Spkt_fifo::Writer udp_writer;   // Packet FIFO Writer (to CM)
    Spkt_fifo::Reader udp_reader;   // Packet FIFO Reader (from CM)

    // System identification
    Base::Address0::Id_t sys_addr;  // System address
    Bsp::Uid64 uid;                 // 64-bit unique identifier

    // Network configuration
    Uint64 eth_mac;                 // Ethernet MAC address (two highest bytes not used)
    Uint32 ip_addr;                 // IP address
    Uint32 net_mask;                // IP network mask
    Uint32 padding1;                // Padding for alignment

    // Communication ports
    Uint16 port_stg;                // UDP port for STANAG messages
    Uint16 port_cy;                 // UDP port for Cyphal messages

    // Multicast configuration
    Subjects_type subjects;         // Subject IDs to subscribe in multicast (max 12)
    Uint16 multicast_node_id;       // Multicast node ID
    Uint16 reserved;                // Reserved field for memory alignment
};
```

The `CPU1_CM_shared` structure is initialized in its constructor:

```cpp
CPU1_CM_shared::CPU1_CM_shared(const volatile CM_CPU1_shared& cm_shared) :
    udp_writer(cm_shared.udp_reader.get_r_cnt()),
    udp_reader(cm_shared.udp_writer.get_data(), cm_shared.udp_writer.get_w_cnt()),
    sys_addr(0),
    uid(Bsp::Uid64::build_zero()),
    eth_mac(0),
    ip_addr(0),
    net_mask(0),
    padding1(0),
    port_stg(Base::Routing_table_data<0,0>::def_stg_port),
    port_cy(Base::Routing_table_data<0,0>::def_cyphal_port),
    multicast_node_id(0U),
    reserved(0U)
{
    subjects.resize(0U);
}
```

### 2.2 CM_CPU1_shared Structure (Owned by CM)

This structure contains data that CM writes and CPU1 reads:

```cpp
struct CM_CPU1_shared {
    // Communication FIFOs
    Spkt_fifo::Writer udp_writer;   // Packet FIFO Writer (to CPU1)
    Spkt_fifo::Reader udp_reader;   // Packet FIFO Reader (from CPU1)
    
    // CM code verification
    Base::Sha256_data::Type cmhash_data;    // CM code SHA256 hash result
    
    // Communication statistics
    Uint32 udp_tx_cnt;              // Number of UDP messages sent
    Uint32 udp_rx_cnt;              // Number of UDP messages received
    Uint32 udp_rx_disc_cnt;         // Number of UDP messages discarded on reception
};
```

### 2.3 Size Verification

The system includes a static size check to ensure memory layout consistency across different processor architectures:

```cpp
struct CPU1_CM_shared_size_check {
    static void check() {
        static const Uint32 fifo_sz = size_bytes_t<Spkt_fifo::Writer>::value;
        static const Uint16 subjects_sz = size_bytes_t<CPU1_CM_shared::Subjects_type>::value;
        static const Uint32 hash_size = size_bytes_t<Base::Sha256_data::Type>::value;
        
        // Verify CPU1_CM_shared is exactly fifo_sz + 52U + subjects_sz bytes
        Base::Size_check<CPU1_CM_shared, fifo_sz + 52U + subjects_sz>();
        
        // Verify CM_CPU1_shared is exactly fifo_sz + 24U + hash_size bytes
        Base::Size_check<CM_CPU1_shared, fifo_sz + 24U + hash_size>();
    }
};
```

## 3. Shared Memory Access Mechanisms

### 3.1 CPU1-CM Shared Memory Access

The system provides accessor functions to retrieve references to the shared memory structures:

```cpp
// In CPU1 context
CPU1_CM_shared& get_shared_c1() {
    // This object is statically constructed with the retrieved value from get_shared_cm()
    static CPU1_CM_shared shared_cpu1_cm(get_shared_cm());
    return shared_cpu1_cm;
}

const CM_CPU1_shared& get_shared_cm() {
    // Return the value at the fixed address 0x00038000 (CMTOCPU1MSGRAM)
    static const uint32_t cm_address = 0x00038000;
    return *reinterpret_cast<const CM_CPU1_shared*>(cm_address);
}

// In CM context
const volatile CPU1_CM_shared& get_shared_c1();  // Declaration only
CM_CPU1_shared& get_shared_cm();                 // Declaration only
```

### 3.2 Software-In-Loop (SIL) Implementation

For simulation environments, the shared memory is implemented using regular memory structures:

```cpp
// SIL implementation of shared memory
class Fifo_shared_cm_cpu1 {
public:
    static Fifo_shared_cm_cpu1& get_instance();

    Base::Tnarray<Base::Spkt_buffer, fifo_sz> buffer;
    Uint16 r_count;
    Uint16 w_count;

private:
    Fifo_shared_cm_cpu1();
};

Fifo_shared_cm_cpu1::Fifo_shared_cm_cpu1() :
    r_count(0),
    w_count(0)
{
    buffer.zeros();
}

Fifo_shared_cm_cpu1& Fifo_shared_cm_cpu1::get_instance() {
    static Fifo_shared_cm_cpu1 fifo;
    return fifo;
}

// SIL implementation of CM_CPU1_shared
CM_CPU1_shared::CM_CPU1_shared(const Fifo_shared_cm_cpu1& fifo) :
    udp_writer(fifo.r_count),
    udp_reader(fifo.buffer, fifo.w_count)
{
}

const CM_CPU1_shared& get_shared_cm() {
    static CM_CPU1_shared obj(Fifo_shared_cm_cpu1::get_instance());
    return obj;
}
```

## 4. CPU1-CPU2 Cross-Core Data Structures

### 4.1 Cross-Core Data Types

The system defines cross-core data types for communication between CPU1 and CPU2:

```cpp
// In CPU1 context
namespace Xc {
    typedef             Xcd_cpu1        Xcd_cpu1_type;
    typedef volatile    Xcd_cpu2        Xcd_cpu2_type;

    extern Xcd_cpu1_type&       get_xcd_cpu1();
    extern Xcd_cpu2_type&       get_xcd_cpu2();
}

// In CPU2 context
namespace Xc {
    typedef volatile    Xcd_cpu1        Xcd_cpu1_type;
    typedef             Xcd_cpu2        Xcd_cpu2_type;

    extern Xcd_cpu1_type&       get_xcd_cpu1();
    extern Xcd_cpu2_type&       get_xcd_cpu2();
}
```

Note the use of `volatile` qualifiers to indicate memory that is written by another core.

### 4.2 Autopilot Selection Data Structures

The system includes specialized structures for autopilot selection data:

```cpp
// AP selection data for CPU1
struct Xapsel_cpu1 {
    Base::Tnarray<Real, Xapsel_cpu2::max_real_vars> consens_reals;
};

// AP selection data for CPU2
struct Xapsel_cpu2 {
    static const Uint16 max_real_vars = 20U;           // Maximum number of real variables for consensus
    Base::Bitmask<Uint32> msk_reals;                   // Mask of consensus reals in use
    Base::Tnarray<Real, max_real_vars> consens_reals;  // Real variables used for the 4x consensus

    void init() {
        msk_reals.value = 0U;
        consens_reals.zeros();
    }
};
```

## 5. Shared Memory Communication Mechanisms

### 5.1 FIFO-Based Packet Communication

The primary mechanism for data exchange between cores is through FIFO (First-In-First-Out) packet buffers:

```cpp
// Define FIFO size and type
static const uint16_t fifo_sz = 2;                                  // FIFO size
typedef Base::Fifo_shared<Base::Spkt_buffer, fifo_sz> Spkt_fifo;    // Packet FIFO type
```

Each core has both a writer and reader FIFO:

```cpp
// In CPU1_CM_shared (CPU1 to CM)
Spkt_fifo::Writer udp_writer;   // Packet FIFO Writer (to CM)
Spkt_fifo::Reader udp_reader;   // Packet FIFO Reader (from CM)

// In CM_CPU1_shared (CM to CPU1)
Spkt_fifo::Writer udp_writer;   // Packet FIFO Writer (to CPU1)
Spkt_fifo::Reader udp_reader;   // Packet FIFO Reader (from CPU1)
```

### 5.2 FIFO Initialization

The FIFOs are initialized to create a circular communication pattern:

```cpp
// CPU1_CM_shared constructor
CPU1_CM_shared::CPU1_CM_shared(const volatile CM_CPU1_shared& cm_shared) :
    // Initialize writer with reader's count from CM
    udp_writer(cm_shared.udp_reader.get_r_cnt()),
    // Initialize reader with writer's data and count from CM
    udp_reader(cm_shared.udp_writer.get_data(), cm_shared.udp_writer.get_w_cnt()),
    // Other initializations...
{
    // ...
}
```

This initialization creates a circular reference where:
1. CPU1's writer is connected to CM's reader
2. CPU1's reader is connected to CM's writer
3. CM's writer is connected to CPU1's reader
4. CM's reader is connected to CPU1's writer

### 5.3 Communication Statistics

The CM core maintains communication statistics in the shared memory:

```cpp
// In CM main loop
shared_cm.udp_tx_cnt = udp_p.get_tx_packet_count();
shared_cm.udp_rx_cnt = udp_p.get_rx_packet_count();
shared_cm.udp_rx_disc_cnt = udp_p.get_rx_packet_disc_count();
```

CPU1 periodically reads these statistics and publishes them to system variables:

```cpp
void Vmain_cpu1::publish_cm_vars() {
    static Var<Uvar>::Wdif tx_cnt(vu_udp_tx_pkts);
    static Var<Uvar>::Wdif rx_cnt(vu_udp_rx_pkts);
    static Var<Uvar>::Wdif rx_disc_cnt(vu_udp_rx_disc_pkts);
    static const CM_CPU1_shared& shared_cm = get_shared_cm();
    static Var<Uvar>::Wdif c1_cm_tx_lost(vu_c1_to_cm_lost_pkts);

    if(cm_p_tout.expired()) {
        cm_p_tout.start_lap();
        tx_cnt.set(static_cast<Uint16>(shared_cm.udp_tx_cnt));
        rx_cnt.set(static_cast<Uint16>(shared_cm.udp_rx_cnt));
        rx_disc_cnt.set(static_cast<Uint16>(shared_cm.udp_rx_disc_cnt));

        Uint16 c1_cm_tx_loss;
        Real c1_cm_tx_err_rate;
        ver.get_cm_port().get_pkt_loss(c1_cm_tx_loss, c1_cm_tx_err_rate);
        c1_cm_tx_lost.set(c1_cm_tx_loss);
    }
}
```

## 6. Shared Memory Initialization Process

### 6.1 CPU1-CM Shared Memory Initialization

The initialization of shared memory between CPU1 and CM follows these steps:

1. **CPU1 Initialization**:
   ```cpp
   // Build shared memory variables
   CPU1_CM_shared& shared_c1 = get_shared_c1();
   shared_c1.uid = Bsp::get_uid();
   shared_c1.sys_addr = shared_c1.uid.phy;
   shared_c1.eth_mac = 0xA863F2000000 | (shared_c1.uid.phy & mask24);

   // Configure IP and ports based on application type
   if(Bsp::is_astro(app_id)) {
       Bsp::get_ip_cfg_pa(shared_c1.uid, shared_c1.ip_addr, shared_c1.net_mask);
       shared_c1.subjects.append(Base::Stanag_msg_type::cyp_maintenance_action_req - Base::Stanag_msg_type::stg_cyphal_msg);
       shared_c1.subjects.append(Base::Stanag_msg_type::cyp_pa_command_contingency_wrapper - Base::Stanag_msg_type::stg_cyphal_msg);
   } else {
       Bsp::get_ip_cfg(shared_c1.uid, shared_c1.ip_addr, shared_c1.net_mask);
   }
   ```

2. **CM Initialization**:
   ```cpp
   // Calculate SHA256 hash of application area
   uint32_t hash_result[8];
   SHA256_calculateHash((uint32_t*)APP_START, (APP_END - APP_START) / 4, hash_result);
   
   // Copy hash to shared memory
   memcpy(shared_cm.cmhash_data.data, hash_result, sizeof(hash_result));
   
   // Initialize communication statistics
   shared_cm.udp_tx_cnt = 0;
   shared_cm.udp_rx_cnt = 0;
   shared_cm.udp_rx_disc_cnt = 0;
   ```

### 6.2 CPU1-CPU2 Cross-Core Data Initialization

The initialization of cross-core data between CPU1 and CPU2 is part of the boot process:

```cpp
// In CPU2's Xapsel_cpu2::init()
void Xapsel_cpu2::init() {
    msk_reals.value = 0U;
    consens_reals.zeros();
}
```

## 7. Cross-Core Communication Flow

### 7.1 CPU1-CM Communication Flow

The communication flow between CPU1 and CM follows this pattern:

1. **CPU1 to CM**:
   - CPU1 writes network configuration to `CPU1_CM_shared`
   - CPU1 writes packets to `CPU1_CM_shared.udp_writer`
   - CM reads network configuration from `CPU1_CM_shared`
   - CM reads packets from `CPU1_CM_shared.udp_reader`

2. **CM to CPU1**:
   - CM writes communication statistics to `CM_CPU1_shared`
   - CM writes packets to `CM_CPU1_shared.udp_writer`
   - CPU1 reads communication statistics from `CM_CPU1_shared`
   - CPU1 reads packets from `CM_CPU1_shared.udp_reader`

### 7.2 CPU1-CPU2 Communication Flow

The communication flow between CPU1 and CPU2 follows this pattern:

1. **CPU1 to CPU2**:
   - CPU1 writes to `Xcd_cpu1` structure
   - CPU2 reads from `Xcd_cpu1` structure (with `volatile` qualifier)

2. **CPU2 to CPU1**:
   - CPU2 writes to `Xcd_cpu2` structure
   - CPU1 reads from `Xcd_cpu2` structure (with `volatile` qualifier)

3. **Autopilot Selection Data**:
   - CPU1 reads/writes to `Xapsel_cpu1.consens_reals`
   - CPU2 reads/writes to `Xapsel_cpu2.consens_reals`
   - The `consens_reals` arrays are used for consensus algorithms between the cores

## 8. Memory Access Patterns and Synchronization

### 8.1 Volatile Qualifiers

The system uses `volatile` qualifiers to indicate memory that can be modified by another core:

```cpp
// In CPU1 context
typedef             Xcd_cpu1        Xcd_cpu1_type;  // CPU1 owns this
typedef volatile    Xcd_cpu2        Xcd_cpu2_type;  // CPU2 owns this

// In CPU2 context
typedef volatile    Xcd_cpu1        Xcd_cpu1_type;  // CPU1 owns this
typedef             Xcd_cpu2        Xcd_cpu2_type;  // CPU2 owns this
```

### 8.2 Synchronization Mechanisms

The system uses several synchronization mechanisms:

1. **IPC Flags**:
   ```cpp
   // CPU1 signals to CM that initialization is complete
   IPC_setFlagLtoR(IPC_CM_L_CPU1_R, IPC_FLAG0);

   // CM waits for CPU1 to finish startup
   IPC_waitForFlag(IPC_CM_L_CPU1_R, IPC_FLAG1);
   ```

2. **Busy-Wait Loops**:
   ```cpp
   // CPU1 waits for CPU2 to complete loading
   while(!lst_is_done(c2_loadst.get())) {
       Base::Stepmgr::get_instance().run(Stepmgr::step_xcfile);
   }
   ```

3. **Explicit Synchronization Points**:
   ```cpp
   // CPU1-CPU2 synchronization
   Hsys::set_loadst_requested(last_lst);                 // Sync 1
   Dsp28335_ent::Ipc::cpu1_wait_for_unlock();           // Sync 2
   Dsp28335_ent::Ipc::cpu2_unlock();                    // Sync 4
   Dsp28335_ent::Ipc::cpu1_wait_for_unlock();           // Sync 4.1
   ```

### 8.3 Timing Considerations

The system includes mechanisms to avoid simultaneous access to shared memory:

```cpp
// In CPU2 main loop
// Force a desynchronization between C1 and C2 to avoid read-write at the exact same time
Uint32 us_delay = 100U;
Dsp28335_ent::Delay::us(us_delay);
```

## 9. Cross-Core Communication Diagram

```
+----------------+                  +----------------+
|     CPU1       |                  |      CM        |
|                |                  |                |
| +------------+ |                  | +------------+ |
| |CPU1_CM_shared|<---------------->| |CM_CPU1_shared| |
| +------------+ |                  | +------------+ |
|                |                  |                |
+-------^--------+                  +----------------+
        |
        v
+----------------+
|     CPU2       |
|                |
| +------------+ |
| | Xcd_cpu2   |<|
| +------------+ |
|                |
| +------------+ |
| | Xapsel_cpu2| |
| +------------+ |
|                |
+----------------+
```

## 10. Memory Layout and Size Constraints

### 10.1 Memory Size Requirements

The shared memory structures have specific size requirements:

```cpp
// CPU1_CM_shared size = fifo_sz + 52U + subjects_sz bytes
// CM_CPU1_shared size = fifo_sz + 24U + hash_size bytes

// Where:
// fifo_sz = size of Spkt_fifo::Writer
// subjects_sz = size of CPU1_CM_shared::Subjects_type
// hash_size = size of Base::Sha256_data::Type
```

### 10.2 Memory Alignment

The structures include padding and reserved fields to ensure proper memory alignment:

```cpp
// In CPU1_CM_shared
Uint32 padding1;    // Padding for alignment
Uint16 reserved;    // Reserved field for memory alignment
```

## 11. Referenced Context Files

The following context files provided valuable information for understanding the cross-core communication mechanisms:

1. `09_System_Architecture.md` - Provided overview of the Veronte system architecture, including cross-core communication mechanisms and boot sequence
2. `08_Multi_Core_Execution.md` - Detailed the multi-core execution architecture, initialization sequences, and inter-core communication

## 12. Summary of Key Findings

1. **Shared Memory Organization**:
   - CPU1-CM shared memory is located at address 0x00038000 (CMTOCPU1MSGRAM)
   - CPU1-CPU2 shared memory uses cross-core data structures with clear ownership semantics
   - Memory structures include FIFO buffers for packet exchange

2. **Communication Mechanisms**:
   - FIFO-based packet exchange for bulk data transfer
   - Direct memory access for configuration and status information
   - Volatile qualifiers to indicate memory that can be modified by another core

3. **Initialization Process**:
   - CPU1 initializes network configuration in shared memory
   - CM calculates and stores SHA256 hash of its application code
   - CPU2 initializes autopilot selection data

4. **Synchronization Mechanisms**:
   - IPC flags for signaling between cores
   - Busy-wait loops for coordination
   - Explicit timing delays to avoid simultaneous access

5. **Memory Access Patterns**:
   - Clear ownership boundaries with each core responsible for specific memory regions
   - Read-only access to memory owned by other cores
   - Careful initialization to create circular references for FIFO communication

The Veronte system's shared memory architecture demonstrates a well-designed approach to multi-core communication with clear ownership boundaries, efficient data exchange mechanisms, and careful synchronization to avoid race conditions.