# Generated from:

- pa_blocks/code/include/Text_logger.h (40 tokens)
- pa_blocks/code/include/Text_logger_fw.h (27 tokens)
- pa_blocks/code/include/Emb_log.h (770 tokens)
- pa_blocks/code/include/Debug_printf.h (159 tokens)
- pa_blocks/code/source/Text_logger.cpp (39 tokens)
- pa_blocks/code/source/Debug_printf.cpp (74 tokens)

---

# Drone Logging and Debugging Facilities

This document provides a comprehensive summary of the drone's logging and debugging facilities, focusing on how the system logs information and provides debugging capabilities. The system includes text logging, emulation, and debug utilities with various logging levels and mechanisms.

## 1. Functional Behavior and Logic

### Text Logger System

The system implements a simple singleton text logger through the `Text_logger` class:

- **Implementation**: Located in `pa_blocks/code/include/Text_logger.h` and `pa_blocks/code/source/Text_logger.cpp`
- **Access Pattern**: Accessed via singleton pattern through `Text_logger::get_instance()`
- **Functionality**: The implementation is minimal in the provided files, suggesting it may be a placeholder or that the actual logging functionality is implemented elsewhere

### Debug Printf System

A file-based debug logging system that writes to text files:

- **Implementation**: Located in `pa_blocks/code/include/Debug_printf.h` and `pa_blocks/code/source/Debug_printf.cpp`
- **Access Pattern**: Accessed via singleton pattern through `Debug_printf::get_instance()`
- **Output Files**: 
  - Primary output file: `jss4_debug_pritf.txt`
  - Secondary output file: `jss4_debug_pritf2.txt`
- **Usage**: Accessed through macros `EMB_DEBUG_PRINTF` and `EMB_DEBUG_PRINTF2`
- **Log Format**: Includes filename, line number, and custom message

### Embedded Logging System (Emb_log)

A comprehensive conditional logging system with multiple severity levels:

- **Implementation**: Located in `pa_blocks/code/include/Emb_log.h`
- **Conditional Compilation**: Only active when `DEBUG_MODE` is true
- **Origin**: Based on AdnVsdkConsoleLogging (https://code.amazon.com/packages/AdnVsdkConsoleLogging)
- **Severity Levels**: INFO, WARN, ERROR
- **Log Format**: `[Level] | [Filename]([Line]) | [Message]`

## 2. Control Flow and State Transitions

### Logging Activation Flow

The embedded logging system has a conditional activation flow:

1. System checks if `DEBUG_MODE` is defined and true
2. If true, logging macros expand to functional implementations
3. If false, logging macros expand to empty statements (no-ops)

### Log Message Generation Flow

When a log message is generated through the embedded logging system:

1. The appropriate macro is called (e.g., `EMB_LOG_INFO`)
2. The macro expands to call `_LOG_MSG` with the appropriate level
3. `_LOG_MSG` formats the message with metadata and calls the printf function pointer
4. Console is flushed to ensure message visibility

## 3. Inputs and Stimuli

### Debug Printf Input

- **Input**: Stream operators (`<<`) with message content
- **Processing**: Content is written to the specified output file
- **Effect**: Creates a log entry with filename and line number
- **Location**: `Debug_printf.h` defines the macros that handle this input

### Embedded Log Input

- **Input**: Format string and variable arguments (printf-style)
- **Processing**: Formatted according to log level and metadata
- **Effect**: Prints to console with appropriate formatting
- **Location**: `Emb_log.h` defines the macros that handle this input

## 4. Outputs and Effects

### Debug Printf Output

- **Primary Output File**: `jss4_debug_pritf.txt`
- **Secondary Output File**: `jss4_debug_pritf2.txt`
- **Format**: `\n[Filename]-L[Line]: [Message]`
- **Persistence**: File-based, persists across program runs unless files are cleared

### Embedded Log Output

- **Output**: Console (stdout)
- **Format**: `[Level] | [Filename]([Line]) | [Message]`
- **Persistence**: Console-based, typically not persisted unless redirected
- **Flushing**: Immediate flush after each log message to ensure visibility

## 5. Parameters and Configuration

### Debug Mode Configuration

- **Parameter**: `DEBUG_MODE` macro
- **Default**: `false` if not defined
- **Effect**: Controls whether embedded logging is active or disabled
- **Location**: Can be defined externally or overridden before including `Emb_log.h`

### Printf Interception Configuration

- **Parameter**: `EmbConsoleLogInterceptionInterface::printf_ptr()`
- **Default**: `std::printf`
- **Effect**: Allows redirection of log output to custom handlers
- **Location**: Defined in `Emb_log.h`

### Console Flush Configuration

- **Parameter**: `EMB_CONSOLE_FLUSH` macro
- **Default**: `{fflush(stdout);}`
- **Effect**: Controls how the console is flushed after logging
- **Location**: Can be defined externally or uses default in `Emb_log.h`

## 6. Error Handling and Contingency Logic

### Throttled Logging

- **Trigger**: Rapid, repetitive log messages
- **Detection**: Time-based throttling using `std::chrono`
- **Response**: Limits log frequency to specified minimum period
- **Location**: `_LOG_MSG_THROTTLED` macro in `Emb_log.h`

### One-time Logging

- **Trigger**: Potentially repetitive log messages that should only appear once
- **Detection**: Static boolean flag tracks if message has been logged
- **Response**: Only logs the first occurrence, ignores subsequent calls
- **Location**: `EMB_LOG_*_ONCE` macros in `Emb_log.h`

### Null Logging in Release Mode

- **Trigger**: `DEBUG_MODE` is false
- **Detection**: Compile-time conditional
- **Response**: All logging macros expand to no-ops, eliminating any runtime overhead
- **Location**: Conditional compilation in `Emb_log.h`

## 7. File-by-File Breakdown

### Text_logger.h

- **Purpose**: Declares the Text_logger class interface
- **Major Components**: 
  - `Text_logger` struct with static `get_instance()` method
- **Contribution**: Provides a singleton access point for text logging

### Text_logger_fw.h

- **Purpose**: Forward declaration of the Text_logger struct
- **Major Components**: 
  - Forward declaration of `Text_logger` struct
- **Contribution**: Allows other files to reference Text_logger without including the full header

### Text_logger.cpp

- **Purpose**: Implements the Text_logger singleton
- **Major Components**: 
  - Implementation of `get_instance()` method
- **Contribution**: Creates and returns the singleton instance of Text_logger

### Emb_log.h

- **Purpose**: Provides a comprehensive logging system with multiple severity levels
- **Major Components**: 
  - Conditional compilation based on `DEBUG_MODE`
  - Log level macros (INFO, WARN, ERROR)
  - Throttled and one-time logging variants
  - Printf interception mechanism
- **Contribution**: Core logging functionality with rich features and minimal overhead

### Debug_printf.h

- **Purpose**: Declares file-based debug logging functionality
- **Major Components**: 
  - `Debug_printf` class with singleton pattern
  - `EMB_DEBUG_PRINTF` and `EMB_DEBUG_PRINTF2` macros
  - File path extraction macro (`__FILENAME__`)
- **Contribution**: Provides persistent file-based logging capability

### Debug_printf.cpp

- **Purpose**: Implements the Debug_printf singleton
- **Major Components**: 
  - Implementation of `get_instance()` method
  - Constructor that initializes output files
- **Contribution**: Creates and configures the file streams for debug logging

## 8. Cross-Component Relationships

### Logging System Integration

| Component | Interacts With | Interaction Type |
|-----------|---------------|-----------------|
| Text_logger | Unknown (minimal implementation) | Unknown |
| Debug_printf | File system | Writes to output files |
| Emb_log | Console (stdout) | Writes to console |
| Emb_log | EmbConsoleLogInterceptionInterface | Uses printf function pointer |

### Macro Dependencies

- `EMB_DEBUG_PRINTF` and `EMB_DEBUG_PRINTF2` depend on `Debug_printf::get_instance()`
- All `EMB_LOG_*` macros depend on `_LOG_MSG` or variants
- `_LOG_MSG` depends on `EmbConsoleLogInterceptionInterface::printf_ptr()`

## 9. Detailed Logging Features

### Embedded Logging Levels

1. **INFO Level**
   - Macro: `EMB_LOG_INFO(fmt, ...)`
   - Purpose: General information messages
   - Variants:
     - `EMB_LOG_INFO_THROTTLED(prd, fmt, ...)`: Rate-limited info logging
     - `EMB_LOG_INFO_ONCE(fmt, ...)`: One-time info logging

2. **WARN Level**
   - Macro: `EMB_LOG_WARN(fmt, ...)`
   - Purpose: Warning messages for potential issues
   - Variants:
     - `EMB_LOG_WARN_ONCE(fmt, ...)`: One-time warning logging

3. **ERROR Level**
   - Macro: `EMB_LOG_ERROR(fmt, ...)`
   - Purpose: Error messages for actual problems
   - Variants:
     - `EMB_LOG_ERROR_ONCE(fmt, ...)`: One-time error logging

### Throttling Mechanism

The throttling mechanism uses C++ standard library's chrono facilities:

```cpp
static std::chrono::time_point<std::chrono::system_clock> last_log_time_ms{};
const std::chrono::time_point<std::chrono::system_clock> current_time_ms = std::chrono::system_clock::now();
if (std::chrono::duration_cast<std::chrono::milliseconds>(current_time_ms - last_log_time_ms).count() >= min_period_ms) {
    last_log_time_ms = current_time_ms;
    _LOG_MSG(level, fmt, ## __VA_ARGS__);
}
```

This ensures logs are only emitted if the specified minimum period (in milliseconds) has elapsed since the last log.

### Printf Interception

The system allows for custom printf handlers through a static function pointer:

```cpp
struct EmbConsoleLogInterceptionInterface {
    static printf_like_ptr_type& printf_ptr() {
        static printf_like_ptr_type printf_ptr_ = std::printf;
        return printf_ptr_;
    }
};
```

This enables:
- Redirection of logs to custom handlers
- Filtering or transformation of log messages
- Integration with external logging systems

## 10. Performance Considerations

### Debug Mode Conditional Compilation

- When `DEBUG_MODE` is false, all embedded logging macros expand to empty statements
- This eliminates any runtime overhead from logging in release builds
- No function calls, string formatting, or I/O operations occur

### File-based Logging Performance

- `Debug_printf` keeps files open for the duration of the program
- Each log message requires:
  - File system write operations
  - Potential file system synchronization
  - String formatting operations

### Console Logging Performance

- Each embedded log message when `DEBUG_MODE` is true requires:
  - String formatting operations
  - Console output operations
  - Explicit console flushing

### Throttling for Performance

- Throttled logging variants reduce the performance impact of high-frequency events
- Static time tracking adds minimal overhead compared to full logging operations
- Particularly useful for recurring conditions or high-frequency loops

## 11. Implementation Details

### Debug Printf Implementation

The `Debug_printf` class is implemented as a singleton with file streams:

```cpp
Debug_printf& Debug_printf::get_instance()
{
    static Debug_printf ret;
    return ret;
}

Debug_printf::Debug_printf() :
    out_file("jss4_debug_pritf.txt"),
    out_file2("jss4_debug_pritf2.txt")
{
}
```

The constructor initializes two output files with fixed filenames.

### Embedded Log Macro Implementation

The core logging macro is implemented as:

```cpp
#define _LOG_MSG(level, fmt, ...) { \
    if (EmbConsoleLogInterceptionInterface::printf_ptr()) { EmbConsoleLogInterceptionInterface::printf_ptr()(EMB_LOG_METADATA_FMT fmt "\n", EMB_LOG_METADATA(level), ## __VA_ARGS__); EMB_CONSOLE_FLUSH;} \
}
```

This checks for a valid printf function pointer, calls it with the formatted message and metadata, and flushes the console.

## Summary

The drone's logging and debugging facilities provide a comprehensive set of tools for development, debugging, and runtime monitoring. The system includes:

1. A file-based debug logging system (`Debug_printf`) for persistent logs
2. A console-based embedded logging system (`Emb_log`) with multiple severity levels
3. A simple text logger interface (`Text_logger`) with minimal implementation
4. Support for throttled and one-time logging to reduce noise
5. Conditional compilation to eliminate logging overhead in release builds
6. Printf interception for custom log handling

These facilities enable effective debugging, monitoring, and analysis of the drone's behavior during development and operation, with mechanisms to control performance impact in production environments.