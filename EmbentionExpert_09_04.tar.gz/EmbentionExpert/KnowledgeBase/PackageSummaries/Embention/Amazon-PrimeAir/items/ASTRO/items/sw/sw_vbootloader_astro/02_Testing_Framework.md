# Generated from:

- code/test/bin_generator.py (1109 tokens)
- code/test/bldr_test_plan.py (19961 tokens)
- code/test/emb_software_updater.py (6005 tokens)
- code/test/env_setup.py (2572 tokens)
- code/test/logger.py (388 tokens)
- code/test/version.py (466 tokens)
- code/test/README.md (1119 tokens)

## With context from:

- PackageSummaries/Amazon-PrimeAir/items/ASTRO/items/sw/sw_vbootloader_astro/04_Bootloader_Core_Architecture.md (2297 tokens)

---

# Astro Bootloader Testing Framework: Comprehensive Analysis

## 1. System Overview

The Astro bootloader testing framework is a comprehensive suite of Python scripts designed to validate the functionality, security, and reliability of the Astro bootloader system. The framework implements a structured test plan with 21 distinct test cases that cover various aspects of bootloader operation, including nominal functionality, error handling, security verification, and mode transitions.

### Core Components

1. **Test Plan Implementation (`bldr_test_plan.py`)**
   - Implements 21 test cases defined in the bootloader test plan
   - Provides a structured framework for test execution and validation
   - Uses a decorator pattern to standardize test setup, execution, and reporting

2. **Binary File Management**
   - `bin_generator.py`: Extracts and organizes bootloader and application binaries
   - `env_setup.py`: Processes release packages and prepares test environment

3. **Communication Interface (`emb_software_updater.py`)**
   - Abstracts communication with target devices via SSH/SFTP
   - Implements command interface for bootloader operations
   - Handles CAN bus and UDP communication protocols

4. **Support Utilities**
   - `version.py`: Version comparison and management
   - `logger.py`: Structured logging with color-coded output

## 2. Test Plan Architecture

The test plan is implemented as a class (`TestPlan`) that encapsulates all test cases and supporting functionality. Each test case is implemented as a method decorated with `@test_case(n)` to provide consistent setup and reporting.

### Test Case Structure

Each test case follows a consistent pattern:
1. **Setup**: Prepare the device for testing (e.g., put into bootloader mode)
2. **Test Execution**: Perform the specific test operations
3. **Validation**: Verify the expected outcomes
4. **Cleanup**: Return the device to a known state

### Test Categories

The test cases cover several key categories:

1. **Nominal Operation Tests** (Tests 1-4)
   - Factory load of bootloader and applications
   - Upgrade and downgrade scenarios
   - Version verification

2. **Error Handling Tests** (Tests 5-13)
   - Interrupted installation recovery
   - Invalid binary detection
   - Signature verification

3. **Security Tests** (Tests 11-13, 18-20)
   - Boot-time authentication
   - Header schema verification
   - Signature validation

4. **Mode Transition Tests** (Tests 14-16)
   - Bootloader to application transitions
   - CAN bus configuration during transitions
   - Power cycle recovery

5. **Endurance Test** (Test 21)
   - 1000 cycles of mode transitions to verify reliability

## 3. Binary File Management

### Binary Generator (`bin_generator.py`)

This component is responsible for extracting and organizing bootloader and application binaries from the project structure:

```python
CONFIG = {
    "bdlr_astro": [
        ("items/ASTRO/items/sw/sw_vbootloader_astro/code/sw_vbootloader_astro/code/project/vpgen_ccs/2838x/smart.bin", "smart0.bin"),
        ("items/ASTRO/items/sw/sw_vbootloader_astro/code/sw_vbootloader_astro_cm/code/project/vpgen_ccs_arm/2838x_arm/smart.bin", "smart2.bin"),
    ],
    # Additional configuration for IPC bootloader and signing
}
```

Key functions:
- `find_project_root()`: Locates the project root directory
- `copy_file()` and `copy_directory()`: Handle file operations
- `run_batch()`: Executes batch files for binary signing
- `main()`: Orchestrates the binary extraction and organization process

### Environment Setup (`env_setup.py`)

Handles the preparation of the test environment by processing release packages:

```python
def process_zip_file(zip_path, origin):
    """
    Process a zip file given its path and the origin ('new' or 'old').
    For fw products, search for an internal zip and extract its content.
    For pdi products, extract the content directly into their corresponding folders.
    """
```

Key functions:
- `parse_filename()`: Extracts product, version, and date from filenames
- `process_directory()`: Processes the raw_files directory structure
- `validate_products()`: Ensures consistency between "new" and "old" versions
- `copy_tools()`: Copies required tools (PDI coder/loader) to the test environment

## 4. Communication Interface

The `emb_software_updater.py` module provides a comprehensive interface for communicating with target devices:

### Command Structure

Commands are implemented as enum classes with associated data classes for parsing responses:

```python
class Command(Enum):
    # Retrieve bootloader information
    @dataclass
    class GetInfo:
        bldr_version: Version
        app_version: Version
        # Parsing logic...
    
    get_info = "get_info"
    
    # Additional commands...
```

### Communication Methods

- `send_command()`: Sends commands to the target device via SSH
- `transfer_file()`: Uploads files to the target device via SFTP
- `stdout_to_status()`: Parses command output to determine status

### Status Handling

The framework uses an enum-based status system to represent command results:

```python
class Status(Enum):
    SUCCESS = 0
    FAILURE = -1
    BAD_ARGUMENT = -2
    # Additional status codes...
```

## 5. Test Case Implementation

### Test Case 1: Nominal Factory Load Bootloader

Verifies the basic bootloader loading process:

```python
@test_case(1)
def test1(self):
    """Test Case 1: Nominal Factory Load Bootloader"""
    # Verify bootloader mode
    res = self.cmd_system_status()
    if res.parsed_stdout.mode != emb_su.Command.SystemStatus.Mode.bootloader:
        self.fail(f"Compute should be in 'bootloader' mode but is in '{res.parsed_stdout.mode.value}'")
    
    # Verify apps not present
    expected_not_present = emb_su.Command.GetAppCheckStatus.Status.app_not_present
    expected_app_status = emb_su.Command.GetAppCheckStatus(
        expected_not_present, expected_not_present, expected_not_present
    )
    self._check_app_status(expected_app_status)
    
    # Verify bootloader version
    res = self.cmd_get_info()
    if res.parsed_stdout.bldr_version == self.expected_bldr_version:
        logger.info(f"Got correct bootloader version {res.parsed_stdout.bldr_version}")
    else:
        self.fail(f"Expected bootloader version {self.expected_bldr_version} but got {res.parsed_stdout.bldr_version}")
```

### Error Handling Tests

Tests 5-7 verify recovery from interrupted installations:

```python
def _install_wrong_binary(self, core: emb_su.Options.Core):
    # Generate a wrong binary (truncated, wrong core, or modified signature)
    wrong_bin_path = self._generate_wrong_binary(core)
    
    # Try to install the binary (expected to fail)
    remote_bin_path = emb_su.EmbUpdater.bin_temp_path + f"smart{core.value}.bin"
    self.updater.transfer_file(wrong_bin_path, remote_bin_path)
    res = self.cmd_software_install(core, remote_bin_path, expected_fail=True)
    
    # Verify failure and error status
    if res.status != emb_su.Status.RESPONSE_INVALID:
        self.fail(f"Installation must fail with response {emb_su.Status.RESPONSE_INVALID.name}")
    
    # Check app status reports expected error
    expected_failed = self._generate_expected_failed_app_status_1(core)
    expected_app_status = self._generate_app_status_vec_with_xfail(core, expected_failed)
    self._check_app_status(expected_app_status)
    
    # Additional test steps...
```

### Security Tests

Tests 11-13 and 18-20 verify security features:

```python
@test_case(11)
def test11(self):
    """Test Case 11: Boot Time Authentication: C1 with invalid signature"""
    self._install_wrong_binary(emb_su.Options.Core.C1)
```

The `_install_wrong_binary` method handles different types of binary modifications based on the test number:

```python
def _generate_wrong_binary(self, core: emb_su.Options.Core) -> Path:
    if self.test_num in (5, 6, 7):
        # Generate a truncated binary (95% of data removed)
        original_bin_path = self.main_path / f"{self.compute.as_file}/smart{core.value}.bin"
        wrong_bin_path = truncate_and_corrupt_file(original_bin_path, 0.95, 0)
    elif self.test_num in (8, 9, 10):
        # Use a binary for a different core
        wrong_bin_core = self.choose_random_different_core(core)
        wrong_bin_path = self.main_path / f"{self.compute.as_file}/smart{wrong_bin_core.value}.bin"
    elif self.test_num in (11, 12, 13):
        # Modify the signature
        original_bin_path = self.main_path / f"{self.compute.as_file}/smart{core.value}.bin"
        wrong_bin_path = modify_signature(original_bin_path)
    elif self.test_num in (18, 19, 20):
        # Modify the header
        original_bin_path = self.main_path / f"{self.compute.as_file}/smart{core.value}.bin"
        wrong_bin_path = modify_header(original_bin_path)
    return wrong_bin_path
```

### Endurance Test

Test 21 performs 1000 cycles of mode transitions:

```python
@test_case(21)
def test21(self):
    """Test Case 21?: App/Bootloader Transition Endurance Test"""
    for i in range(1000):
        iter_str = f"Iteration {i + 1}"
        self.show_info(f"[{iter_str}] Step 1: Restart")
        self.cmd_restart()
        
        # Toggle between mission and maintenance modes
        if not self.compute.is_ipc:
            self.show_info(f"[{iter_str}] Step 2: Swap Mode (Mission/Mainteinance)")
            res = self.cmd_system_status()
            if res.parsed_stdout.mode == emb_su.Command.SystemStatus.Mode.normal:
                self.cmd_system_reset(emb_su.Options.Mode.MAINT)
            elif res.parsed_stdout.mode == emb_su.Command.SystemStatus.Mode.maintenance:
                self.cmd_system_reset(emb_su.Options.Mode.MISSION)
        
        # Return to bootloader
        self.show_info(f"[{iter_str}] Step 3: Perform Mode Transition to Bootloader")
        self.cmd_system_reset(emb_su.Options.Mode.BOOTLOADER)
```

## 6. Binary File Manipulation

The framework includes several functions for manipulating binary files to test error handling:

### Truncation and Corruption

```python
def truncate_and_corrupt_file(file_path, truncate_ratio, random_data_length_bytes):
    """
    Truncate the last fraction of a file and append random bytes.
    Each appended byte is guaranteed to differ from the original at the same position.
    """
    path = Path(file_path)
    file_size = path.stat().st_size
    truncated_length = max(int(file_size * (1 - truncate_ratio)), 1)
    
    output = path.with_name(f"{path.stem}_corrupted{path.suffix}")
    
    with path.open("rb") as src, output.open("wb") as dst:
        # Copy the first truncated_length bytes
        remaining = truncated_length
        while remaining > 0:
            chunk = src.read(min(8192, remaining))
            if not chunk: break
            dst.write(chunk)
            remaining -= len(chunk)
        
        # Generate and write random bytes that differ from original
        original_suffix = src.read(random_data_length_bytes)
        for i in range(random_data_length_bytes):
            orig = original_suffix[i] if i < len(original_suffix) else None
            rand_byte = random.randint(0, 255)
            if orig is not None:
                while rand_byte == orig:
                    rand_byte = random.randint(0, 255)
            dst.write(bytes([rand_byte]))
    
    return output
```

### Signature Modification

```python
def modify_signature(file_path: str) -> Path:
    """
    Copy <file_path> to <stem>_signature_modified<suffix>, overwrite
    the signature byte at offset 72, update CRC32 at offset 12,
    and return the path to the modified file.
    """
    original = Path(file_path)
    modified = original.with_name(original.stem + "_signature_modified" + original.suffix)
    
    _modify_byte_at_offset(original, modified, offset=32 + 40)
    crc = update_file_crc32(str(modified))
    logger.info(f"Updated CRC32 (offset 12) in {modified.name}: 0x{crc:08X}")
    return modified
```

### Header Modification

```python
def modify_header(file_path: str) -> Path:
    """
    Copy <file_path> to <stem>_header_modified<suffix>, overwrite
    the header byte at offset 11, update CRC32 at offset 12,
    and return the path to the modified file.
    """
    original = Path(file_path)
    modified = original.with_name(original.stem + "_header_modified" + original.suffix)
    
    _modify_byte_at_offset(original, modified, offset=11)
    crc = update_file_crc32(str(modified))
    logger.info(f"Updated CRC32 (offset 12) in {modified.name}: 0x{crc:08X}")
    return modified
```

### CRC32 Update

```python
def update_file_crc32(file_path: str, crc_offset: int = 12) -> int:
    """
    Compute CRC32 of the file excluding the four bytes at crc_offset,
    write the CRC32 (little-endian) back at that offset, and return it.
    """
    path = Path(file_path)
    data = path.read_bytes()
    before = data[:crc_offset]
    after = data[crc_offset + 4:]
    
    # Compute CRC32 over everything but the old CRC placeholder
    crc_value = zlib.crc32(before + after) & 0xFFFFFFFF
    
    # Pack into little-endian 4 bytes and rebuild file contents
    crc_bytes = crc_value.to_bytes(4, byteorder="little")
    new_data = before + crc_bytes + after
    
    path.write_bytes(new_data)
    return crc_value
```

## 7. PDI Installation

The framework includes functionality to install PDI (Platform Description Information) files:

```python
def install_pdi(self) -> bool:
    """
    Encode and upload the PDI for the target compute.
    Returns True on success, False on any failure.
    """
    if self.compute.is_ipc:
        self.fail("Cannot install PDI for IPCs")
    
    pdi_dir = self.main_path / f"pdi_{self.compute.value}"
    coder_jar = self.main_path / "tools/pdi-coder-7.1.3-all.jar"
    loader_jar = self.main_path / "tools/pdi-loader-7.1.9-all.jar"
    bin_dir = pdi_dir / "bin"
    xsd_dir = pdi_dir / "xsd"
    
    # Create directories
    bin_dir.mkdir(parents=True, exist_ok=True)
    xsd_dir.mkdir(parents=True, exist_ok=True)
    
    # Execute PDI encoding and loading commands
    commands = [
        ["java", "-jar", str(coder_jar), "-p2b", "-p", str(pdi_dir), "-o", str(bin_dir), "-x", str(xsd_dir)],
        ["java", "-jar", str(loader_jar), "-u", "-a", str(self.compute.id), "-p", str(bin_dir)]
    ]
    
    for cmd in commands:
        cmd_str = " ".join(cmd)
        try:
            subprocess.run(cmd_str, shell=True, check=True)
        except subprocess.CalledProcessError as e:
            self.fail(f"Error during command execution: {e}")
    
    return True
```

## 8. CAN Bus Monitoring

The framework includes functionality to monitor CAN bus traffic:

```python
def capture_can_stab_a(self):
    """
    Capture CAN frames on interface can_stab_a remotely for 5 seconds
    and log only those lines that begin with 'can_stab_a' followed by a
    3-digit hexadecimal ID starting with '7'.
    """
    logger.info("Check CAN_STAB_A")
    cmd = "candump can_stab_a"
    
    _stdin, stdout, stderr = self.updater.ssh_client.exec_command(cmd)
    channel = stdout.channel
    start = time.time()
    out_chunks = []
    
    # Read until 5 seconds pass or the process exits
    while True:
        if channel.recv_ready():
            out_chunks.append(channel.recv(4096).decode())
        
        if stderr.channel.recv_stderr_ready():
            err = stderr.channel.recv_stderr(4096).decode().strip()
            if err:
                self.fail(f"`{cmd}` failed:\n{err}")
        
        if channel.exit_status_ready():
            break
        
        if time.time() - start >= 5.0:
            logger.info("5 second timeout reached, stopping capture")
            channel.close()
            break
        
        time.sleep(0.1)
    
    output = "".join(out_chunks).strip()
    pattern = re.compile(r"^\s*can_stab_a\s+7[0-9A-Fa-f]{2}\b")
    filtered = [ln for ln in output.splitlines() if pattern.match(ln)]
    
    if filtered:
        logger.info("Filtered CAN messages (ID starts with 7):\n%s", "\n".join(filtered))
    else:
        self.fail("No matching CAN messages found")
```

## 9. CAN ID Mapping

The framework includes a mapping of CAN IDs for different compute types:

```python
class CAN_IDs(Enum):
    ESC0 = "0A"
    ESC1 = "0B"
    ESC2 = "0C"
    ESC3 = "0D"
    ESC4 = "0E"
    ESC5 = "0F"
    Monitor = "16"
    Recovery0 = "1C"
    Recovery1 = "1F"
```

This mapping corresponds to the following CAN channel configuration:

```
+-----------+-----------+---------------+---------------+
| COMPUTE   | DEVICE ID | RX CHANNEL ID | TX CHANNEL ID |
+-----------+-----------+---------------+---------------+
| ESC0      | 0x0A      | 0x70A         | 0x74A         |
| ESC1      | 0x0B      | 0x70B         | 0x74B         |
| ESC2      | 0x0C      | 0x70C         | 0x74C         |
| ESC3      | 0x0D      | 0x70D         | 0x74D         |
| ESC4      | 0x0E      | 0x70E         | 0x74E         |
| ESC5      | 0x0F      | 0x70F         | 0x74F         |
| Monitor   | 0x16      | 0x716         | 0x756         |
| Recovery0 | 0x1C      | 0x71C         | 0x75C         |
| Recovery1 | 0x1F      | 0x71F         | 0x75F         |
+-----------+-----------+---------------+---------------+
```

## 10. Mode Transition Management

The framework includes functionality to manage mode transitions and wait for them to complete:

```python
def wait_for_mode_change(self, expected_mode: emb_su.Command.SystemStatus.Mode = None):
    MAX_SYS_STATUS_ITERATIONS = 10
    ADDITIONAL_SUCCESS = 1  # Sometimes needed for extra delay
    success_count = 0
    
    for i in range(MAX_SYS_STATUS_ITERATIONS):
        logger.trace(f"Waiting... ({i+1}/{MAX_SYS_STATUS_ITERATIONS})")
        # Send system_status until not getting a timeout
        res = self.updater.send_command(
            emb_su.Command.system_status,
            {
                emb_su.Options.compute: self.compute,
                emb_su.Options.transport: emb_su.Options.Transport.UDP,
            },
            expected_fail=True,
        )
        
        if res.status == emb_su.Status.SUCCESS:
            if expected_mode is None:
                if success_count >= ADDITIONAL_SUCCESS:
                    # Extra delay to avoid warnings
                    time.sleep(8)
                    logger.trace(f"Done waiting")
                    break
                success_count += 1
            else:
                if res.parsed_stdout.mode == expected_mode:
                    logger.info(f"Status got expected mode: {res.parsed_stdout.mode}")
                    if success_count >= ADDITIONAL_SUCCESS:
                        logger.trace(f"Done waiting")
                        break
                    success_count += 1
                else:
                    logger.warning(
                        "Got unexpected mode:\n"
                        f"expected {expected_mode.name} but got {res.parsed_stdout.mode.name}\n"
                        "Continue waiting for correct mode..."
                    )
        elif res.status == emb_su.Status.TIMEOUT:
            continue
        else:
            self.fail(f"Got error during waiting: {res.status.name}")
    else:
        self.fail(str(res.status.name))
```

## Referenced Context Files

The analysis was informed by the following context file:
- `04_Bootloader_Core_Architecture.md`: Provided information about the Astro bootloader architecture, including class hierarchy, initialization sequence, memory management, and security features.

This context helped understand the bootloader's internal structure that the test framework is designed to validate.