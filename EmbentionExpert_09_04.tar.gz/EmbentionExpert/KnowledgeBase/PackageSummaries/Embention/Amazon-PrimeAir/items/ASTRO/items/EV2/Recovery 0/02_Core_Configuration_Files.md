# Generated from:

- items/pdi_Recovery0/setup/ver_spdif_fmset.xml (11979 tokens)
- items/pdi_Recovery0/setup/ver_spdif_cfgmgr.xml (11573 tokens)
- items/pdi_Recovery0/setup/ver_spdif_amz_lights.xml (24431 tokens)
- items/pdi_Recovery0/setup/ver_spdif_tm.xml (5902 tokens)
- items/pdi_Recovery0/setup/ver_spdif_amz_rec_param.xml (3199 tokens)
- items/pdi_Recovery0/setup/ver_spdif_muvar.xml (3519 tokens)
- items/pdi_Recovery0/setup/ver_spdif_mrvar.xml (6107 tokens)
- items/pdi_Recovery0/setup/ver_spdif_pk0.xml (3407 tokens)
- items/pdi_Recovery0/operation/ver_opdif_tmcompl.xml (4425 tokens)

---

# Recovery System Configuration Analysis

This document provides a comprehensive analysis of the core configuration files for the Amazon Recovery System. The analysis focuses on the Field Measurement Set (FMSET), Configuration Manager, Amazon Lights Configuration, Telemetry Configuration, Amazon Recovery Parameters, Measurement Unit Variables, Measurement Real Variables, PK0 Configuration, and Telemetry Completion.

## 1. Field Measurement Set (FMSET) Configuration

### Overview
The FMSET configuration (file: `items/pdi_Recovery0/setup/ver_spdif_fmset.xml`) defines the data structure for field measurements in the recovery system. It specifies how data is encoded, transmitted, and validated.

### Key Components

#### Data Structure
The FMSET is organized into multiple `str-tunarray-element` blocks, each representing a different data packet or message type. Each element contains:

1. **Fields**: Defines the data fields within the packet
2. **Endianness**: Specifies byte order (all set to 1, indicating little-endian)
3. **Time**: Defines timing parameters (values include 1.0, 0.01, -1.0, 1.1)
4. **Offset**: Timing offset (all set to 0.0)

#### Field Types
The FMSET uses several field types for data encoding:

1. **Matchers (`type=8`)**: Used for packet identification and validation
   - Fixed values for packet headers (e.g., 89, 193, 204, 170, 85, 102, 153)
   - Mask values (typically 255 for full byte comparison)
   - Dynamic matchers that reference other fields (is_dyn=1)

2. **Real Values**:
   - Unsigned bits (`type=5`, real-ubits): For values like altitude_hae (ID 3238)
   - Signed bits (`type=6`, real-ibits): For RPM measurements (IDs 3100-3105)

3. **Integer Values**:
   - 16-bit unsigned integers (`type=2`, uinteger16): For status codes and IDs

4. **Bit Fields (`type=3`)**: For boolean flags and state indicators

5. **Checksums (`type=7`)**: For data integrity verification
   - CRC parameters defined (polynomial, start value, reflection settings)
   - Different CRC configurations for different packet types

6. **Skip Fields (`type=9`)**: For padding and alignment

7. **Array Fields (`type=22`)**: For variable-length data

#### Data Packet Structure
The FMSET defines several packet types, each with a specific structure:

1. **Header Packet** (matcher value 89):
   - Contains basic system status information
   - Includes fields for system state and configuration
   - Uses 16-bit CRC with polynomial 40961

2. **Telemetry Packet** (matcher value 193):
   - Contains RPM measurements (IDs 3100-3105)
   - Includes system state information
   - 14-bit signed values for RPM data

3. **Status Packets** (matcher values 204, 170):
   - Contains system status information
   - Includes timestamp data (IDs 1151-1154)
   - Uses 16-bit CRC with polynomial 54277

4. **Command Packets** (matcher values 85, 102, 153):
   - Contains command and control information
   - Includes timestamp data (ID 3237)
   - Dynamic matchers for flight ID verification

### Data Flow
The FMSET configuration establishes a communication protocol with:
- Regular status updates (time=1.0)
- High-frequency telemetry (time=0.01)
- Event-driven messages (time=-1.0)
- Command acknowledgments (time=1.1)

### Checksum Mechanisms
Two distinct CRC algorithms are used:
1. **CRC-16 with polynomial 40961**: Used for header packets
   - Reflects both input and output
   - Start value 65535

2. **CRC-16 with polynomial 54277**: Used for status and command packets
   - No reflection
   - Start value 0

## 2. Configuration Manager (CFGMGR)

### Overview
The Configuration Manager file (`items/pdi_Recovery0/setup/ver_spdif_cfgmgr.xml`) defines the operational modes for the recovery system.

### Structure
The file contains a large array of mode settings, all currently set to 0. This appears to be a placeholder or default configuration with 500+ elements, each with a mode value of 0.

### Functionality
The Configuration Manager likely serves as a central repository for system modes and states. The uniform setting of all modes to 0 suggests:
1. A default/safe configuration
2. A template that gets populated during system initialization
3. A reset state for the recovery system

## 3. Amazon Lights Configuration

### Overview
The Amazon Lights Configuration (`items/pdi_Recovery0/setup/ver_spdif_amz_lights.xml`) defines the behavior of the vehicle's lighting system, which is critical for visibility and signaling during recovery operations.

### Components

#### Register Configuration
The configuration begins with register settings:
- Register 128: Value 56 (likely a control register)
- Register 0: Value 96 (possibly main control)
- Various other registers (1-130) with specific values

#### Light States
The configuration defines light patterns for both left and right sides:

1. **Light State Definition**:
   - Each light state contains 20 phase values and 20 width values
   - 13 different light states are defined for each side (left and right)
   - States include different patterns for different flight phases or alerts

2. **Phase and Width Values**:
   - Phase values determine timing (0-255)
   - Width values determine duration or intensity (0-255)
   - Special patterns include values like 45, 71, 97 for specific sequences

#### Sequences
The configuration includes 10 different light sequences:
1. Each sequence contains 10 steps
2. Each step references a light state for left and right sides
3. Sequences appear to be designed for different flight modes or alerts

### Light Patterns
Several distinct patterns can be identified:
1. **Standard Pattern** (states 0, 1): Regular operation
2. **Alert Pattern** (states 2, 3): Warning or caution
3. **Emergency Pattern** (states 5, 6): Critical situations
4. **Landing Pattern** (states 8, 9): Approach and landing
5. **Special Patterns** (states 10, 11): Specific operations

## 4. Telemetry Configuration

### Overview
The Telemetry Configuration (`items/pdi_Recovery0/setup/ver_spdif_tm.xml`) defines what data is collected and transmitted during recovery operations.

### Structure

#### Telemetry Packets
The configuration defines two telemetry packets:

1. **System Status Packet**:
   - Contains 32 fields
   - Includes ID 1019 (Lights Status)
   - Contains navigation performance metrics (IDs 3200-3229)
   - Enabled (enable=1)
   - Transmission period of 0.1 seconds
   - Addressed to UAV ID 2

2. **Navigation Packet**:
   - Contains 33 fields
   - Includes navigation data (IDs 2047-2053)
   - Contains bit flags for system status (IDs 402, 401, 403)
   - Enabled (enable=1)
   - Transmission period of 0.05 seconds (higher frequency)
   - Addressed to UAV ID 2

### Data Types
The telemetry configuration uses several data types:
1. **32-bit Floating Point** (type=0): For most navigation and status values
2. **16-bit Unsigned Integer** (type=2): For status codes and counters
3. **Bit Fields** (type=3): For boolean flags and state indicators

### Telemetry Parameters
Key parameters being monitored include:
1. Navigation performance metrics (max/avg values)
2. System status flags
3. Position and velocity data
4. Estimation quality metrics

## 5. Amazon Recovery Parameters

### Overview
The Amazon Recovery Parameters file (`items/pdi_Recovery0/setup/ver_spdif_amz_rec_param.xml`) contains the core configuration parameters for the recovery system's behavior.

### Key Parameters

#### System Configuration
- **Switchover Control**:
  - `is_switchover_enabled`: 1 (enabled)
  - `enable_preflight_switchover_test`: 0 (disabled)
  - `enable_preflight_health_checks`: 0 (disabled)
  
- **Motor Control**:
  - `dt_to_arm_motors_after_mrs_s`: 5.0 seconds
  - `dt_to_disarm_after_in_air_motors_disabled_low_rpm_s`: 0.0 seconds

- **Wind Estimation**:
  - `use_cx3_wind_estimates`: 1 (enabled)
  - `latch_ias_threshold_m_per_s`: 25.0 m/s

#### Recovery Control Configuration Parameters (RCCP)
- **Recovery Mode Phase Function (RMPF)**:
  - Ground detection: `altitude_agl_on_ground_vf_origin_m`: 0.48m
  - Takeoff thresholds:
    - `pretakeoff_to_takeoff_agl_threshold_m`: 1.0m
    - `pretakeoff_to_takeoff_velocity_threshold_m_per_s`: 0.5m/s
    - `pretakeoff_to_takeoff_acceleration_threshold_m_per_s2`: 2.6m/s²
  - Landing thresholds:
    - `land_threshold_vel_m_per_s`: 0.25m/s
    - `land_threshold_vel_cmd_m_per_s`: 0.75m/s
    - `land_threshold_vel_cmd_timeout_s`: 2.0s

- **Bounding Box Protection**:
  - `enable_bounding_box_protection`: 1 (enabled)
  - `bounding_box_logging_dt_s`: 1.0s
  - `use_mission_bounding_box_dimensions`: 0 (disabled)
  - Box dimensions:
    - `bounding_box_half_length_m`: 5.0m
    - `bounding_box_half_width_m`: 5.0m
    - `bounding_box_half_height_m`: 10.0m

#### Navigation Configuration
- **GNSS Settings**:
  - `use_receiver_pvt`: 1 (enabled)
  - `use_gnss_A_true_B_false`: 0 (use GNSS B)
  - Accuracy thresholds:
    - `max_vert_pos_accuracy_m`: 25.0m
    - `max_horiz_pos_accuracy_m`: 15.0m

- **Sensor Configuration**:
  - IMU to vehicle frame transformation matrix defined
  - Antenna positions defined
  - Laser position and orientation defined

- **Air Data**:
  - `dynpres_lpf_tau_s`: 0.6168s (low-pass filter time constant)
  - `dynpres_use_probe_left_true_right_false`: 1 (use left probe)

#### Control System Configuration
- **Attitude Control**:
  - `use_attitude_contingency_mode_blending`: 1 (enabled)
  - `attitude_contingency_mode_blending_total_time_s`: 2.0s
  - Weathervaning:
    - `is_weathervaning_enabled`: 1 (enabled)
    - `tas_awv_min_engaged_m_per_s`: 2.0m/s
    - `tas_awv_max_rate_m_per_s`: 3.0m/s
    - `yaw_rate_max_awv_rad_per_s`: 0.7854rad/s (~45°/s)

- **Mixer Configuration**:
  - `enable_state_reset`: 0 (disabled)
  - `use_actuator_hysteresis_override`: 0 (disabled)
  - `use_scheduler_contingency_mode_blending`: 1 (enabled)
  - `scheduler_contingency_mode_blending_total_time_s`: 2.0s
  - Vehicle parameters:
    - `num_motors`: 6
    - `num_control_surfaces`: 0

#### Safety Parameters
- **Track Spline Limits**:
  - `max_attitude_tracking_error_rad`: 3.1415 (π radians)
  - `max_angular_rate_magnitude_rad_per_s`: 3.1415 (π rad/s)
  - `max_horizontal_tracking_error_m`: 9999.0m
  - `max_vertical_tracking_error_m`: 99.0m
  - `max_vtol_horizontal_tracking_error_m`: 10.0m
  - `max_vtol_vertical_tracking_error_m`: 5.0m
  - `max_vertical_speed_m_per_s`: 10.0m/s
  - `max_vtol_agl_m`: 20.0m

- **Wind Monitoring**:
  - `wind_gust_threshold_m_per_s`: 12.8m/s
  - `wind_gust_counter_threshold`: 3
  - `enable_wind_threshold_monitor_to_command_skip_delivery`: 1 (enabled)

## 6. Measurement Unit Variables (MUVAR)

### Overview
The Measurement Unit Variables file (`items/pdi_Recovery0/setup/ver_spdif_muvar.xml`) defines the integer variables used in the system and their descriptions.

### Structure
The file contains a mapping of variable IDs to descriptive names:

#### System Control Variables (1000-1017)
- ID 1000: "Enable (Propeller)"
- ID 1001: "Disable mode (Propeller)"
- ID 1002: "Arm (Propeller)"
- ID 1003: "Source (Propeller)"
- ID 1019: "Lights Status"

#### Status Variables (1100-1137)
- ID 1100: "enacted_contingency"
- ID 1101: "mission_state"
- ID 1102: "phase_of_flight"
- ID 1103: "battery_pack_state"
- ID 1108: "status_code"
- ID 1109: "flags_status_idle"
- ID 1113: "flags_status_isc"

#### Communication Variables (1114-1127)
- ID 1114: "flight_id_low"
- ID 1115: "flight_id_high"
- ID 1118: "reply_to_request_id_low"
- ID 1119: "reply_to_request_id_high"
- ID 1120: "request_id_rcv_low"
- ID 1121: "request_id_rcv_high"
- ID 1124: "dcomms_rssi"
- ID 1125: "dcomms_temp"
- ID 1126: "flight_monitor_connection_st_low"
- ID 1127: "flight_monitor_connection_st_high"

#### Navigation Variables (1128-1137)
- ID 1128: "h_pos_vel_st_dcomms"
- ID 1129: "v_pos_vel_st_dcomms"
- ID 1130: "agl_st_dcomms"
- ID 1131: "evasive_man_phase_dcomms"
- ID 1137: "speed_change_mode"

#### Velocity and Position Variables (1146-1154)
- ID 1146: "ground_velocity_north"
- ID 1147: "ground_velocity_east"
- ID 1148: "wind_velocity_north"
- ID 1149: "wind_velocity_east"
- ID 1150: "Initializer imu measurements count"
- ID 1151-1154: "timestamp_tai_millis_*" (timestamp components)

## 7. Measurement Real Variables (MRVAR)

### Overview
The Measurement Real Variables file (`items/pdi_Recovery0/setup/ver_spdif_mrvar.xml`) defines the floating-point variables used in the system.

### Structure
The file maps variable IDs to descriptive names:

#### RPM Measurements (3100-3105)
- ID 3100: "RPM 1"
- ID 3101: "RPM 2"
- ID 3102: "RPM 3"
- ID 3103: "RPM 4"
- ID 3104: "RPM 5"
- ID 3105: "RPM 6"

#### Navigation Performance Metrics (3200-3229)
- IDs 3200-3229: Various navigation performance metrics
  - "full_nav_max/avg"
  - "mlogctrl_max/avg"
  - "nav_pre_max/avg"
  - "nav_step_max/avg"
  - "nav_post_max/avg"
  - "est_beg_max/avg"
  - "covprop_max/avg"
  - "input_meas_max/avg"
  - "est_end_max/avg"
  - "covprop_full_max/avg"
  - "in_vel_max/avg"
  - "in_pos_max/avg"
  - "in_stp_max/avg"
  - "in_lidar_max/avg"
  - "in_dynpres_max/avg"

#### Position Variables (3232-3238)
- ID 3232: "latitude"
- ID 3233: "longitude"
- ID 3237: "timestamp_tai_millis_rec"
- ID 3238: "altitude_hae"

#### Navigation Scale Parameters (3244-3247)
- ID 3244: "rec_nav_scale_sigma_pos_horizontal"
- ID 3245: "rec_nav_scale_sigma_pos_vertical"
- ID 3246: "rec_nav_scale_sigma_vel"
- ID 3247: "rec_nav_gnss_agreement_threshold"

#### Other Variables
- ID 1483: "v_ext_nav_freq"

## 8. PK0 Configuration

### Overview
The PK0 Configuration file (`items/pdi_Recovery0/setup/ver_spdif_pk0.xml`) defines a matrix structure, likely for a Kalman filter or other state estimation algorithm.

### Structure
The file contains a 16x16 matrix with all elements initialized to 0.0. This appears to be a covariance matrix or state transition matrix that gets populated during system operation.

## 9. Telemetry Completion Configuration

### Overview
The Telemetry Completion Configuration (`items/pdi_Recovery0/operation/ver_opdif_tmcompl.xml`) defines additional telemetry data to be collected during recovery operations.

### Structure
The file defines a single telemetry packet with 50 fields, including:
- Real floating-point values (type=0)
- Bit flags (type=3)
- 16-bit unsigned integers (type=2)

### Configuration
- Enabled (enable=1)
- Transmission period of 0.1 seconds
- Addressed to UAV ID 2

### Data Fields
The packet includes various system parameters:
- Navigation data (IDs 2094, 2095, 2050, 2051)
- System status flags (IDs 16, 73, 8, 111, 200, 90, 102, 117, 58)
- Control parameters (IDs 504, 1513, 3110, 346, 1505, 1101, 387, 390)

## 10. System Integration and Data Flow

### Data Flow Architecture
The recovery system's configuration establishes a comprehensive data flow:

1. **Sensor Data Collection**:
   - RPM measurements from motors (IDs 3100-3105)
   - Position data (latitude, longitude, altitude)
   - System status information

2. **Data Processing**:
   - Navigation state estimation (likely using PK0 matrix)
   - Wind estimation (using CX3 estimates)
   - System state determination

3. **Control Outputs**:
   - Motor commands (6 motors)
   - Light pattern control
   - Recovery mode selection

4. **Telemetry Transmission**:
   - Regular status updates (0.1s period)
   - High-frequency navigation data (0.05s period)
   - Event-driven status messages

### Communication Protocol
The system uses a structured communication protocol:
1. **Packet Identification**: Using matcher fields with specific values
2. **Data Encoding**: Using various field types (real, integer, bit)
3. **Data Integrity**: Using CRC checksums with different polynomials
4. **Timing Control**: Using different periods for different data types

### Recovery Modes and States
The system appears to have several operational modes:
1. **Normal Operation**: Standard flight control
2. **Recovery Mode**: Activated during contingencies
3. **Landing Mode**: Special parameters for approach and landing
4. **Contingency Modes**: Various failure handling states

### Safety Features
Multiple safety mechanisms are implemented:
1. **Bounding Box Protection**: Spatial limits for operation
2. **Wind Monitoring**: Gust detection and response
3. **Tracking Error Limits**: Maximum allowable deviations
4. **Motor Health Monitoring**: RPM checks and thresholds

## 11. Key Insights and Relationships

1. **Integrated Sensor Fusion**:
   - The system combines GNSS, IMU, and air data
   - Position accuracy thresholds are defined (15m horizontal, 25m vertical)
   - Wind estimation uses multiple sources

2. **Adaptive Control**:
   - Contingency mode blending with 2.0s transition time
   - Weathervaning enabled for wind alignment
   - Different control parameters for different flight phases

3. **Comprehensive Monitoring**:
   - Performance metrics for navigation components
   - Status flags for various subsystems
   - Telemetry at multiple frequencies

4. **Recovery-Specific Features**:
   - Six-motor configuration
   - Specialized light patterns for different states
   - Detailed phase-of-flight detection logic

5. **Configuration Hierarchy**:
   - Core parameters in Amazon Recovery Parameters
   - Variable definitions in MUVAR and MRVAR
   - Communication protocol in FMSET
   - Telemetry definitions in TM and TMCOMPL

This comprehensive configuration enables the recovery system to monitor vehicle state, detect anomalies, and execute appropriate recovery actions while maintaining communication with ground systems.