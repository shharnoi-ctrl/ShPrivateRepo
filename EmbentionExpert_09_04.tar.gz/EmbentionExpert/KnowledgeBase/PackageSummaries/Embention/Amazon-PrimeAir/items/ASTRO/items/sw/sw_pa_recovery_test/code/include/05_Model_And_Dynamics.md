# Generated from:

- Model_pa_test.h (6906 tokens)
- Model_dynamic_pa_test.h (23633 tokens)
- Gnc_model_set_pa_test.h (1322 tokens)
- body_transformation_pa_test.h (409 tokens)
- pa_VehicleConstants.h (1360 tokens)
- pa_EnvironmentConstants.h (400 tokens)

## With context from:

- Amazon-PrimeAir/items/ASTRO/items/sw/sw_pa_recovery_test/code/include/06_Math_Utilities.md (5549 tokens)

---

# Vehicle Model and Dynamics Components Analysis

This analysis focuses on the vehicle model and dynamics components of the drone system, examining state space models, parameter handling, transformations, and input/output behaviors.

## 1. Model Testing Framework

### 1.1 Model_pa_test Class

`Model_pa_test` is a template class that extends `Model_dynamic` to provide testing capabilities for state space models:

```cpp
template <Uint32 SZ, Uint32 NI_MAX>
class Model_pa_test : public Model_dynamic
```

Key features:
- Template parameters for state size (`SZ`) and maximum number of interpolation points (`NI_MAX`)
- Constructor that takes an allocator, memory block, and model parameters
- Input limiting functionality
- State reset capabilities

#### 1.1.1 Constructor

```cpp
Model_pa_test(Base::Allocator& alloc,
              Base::Mblock<Uint16> mem_volatile,
              const State_space_model_params& model_params);
```

The constructor initializes:
- External allocator reference
- Volatile memory block for temporary calculations
- Base class with model parameters

#### 1.1.2 Input Limiting

```cpp
void limit_input(const Maverick::Rvector& u,
                 const Maverick::Rvector& u_min,
                 const Maverick::Rvector& u_max,
                 const Maverick::Rvector& u_rate_min,
                 const Maverick::Rvector& u_rate_max,
                 Maverick::Rvector& u_limit);
```

This method enforces constraints on input values and rates, which is critical for:
- Preventing actuator saturation
- Ensuring physical feasibility of commands
- Protecting hardware from excessive control demands

#### 1.1.3 State Management

```cpp
void reset() { Model::reset_state(); }
void set_initial_state(Maverick::Rvector& v) { u_state_initial.copy(v); }
```

These methods provide control over the model's state:
- `reset()`: Resets the model state to initial conditions
- `set_initial_state()`: Sets the initial state vector for future resets

### 1.2 Model_pa_tester Class

This class provides a comprehensive test suite for the `Model_pa_test` class:

```cpp
class Model_pa_tester
{
public:
    static const Uint16 nx_max0 = 5U;  // Maximum state dimension
    static const Uint16 nu0 = 3U;      // Number of inputs
    static const Uint16 ny0 = 1U;      // Number of outputs
    static const Uint16 ni_max0 = 5U;  // Maximum interpolation points
    static const Uint16 nx0 = 5U;      // Actual state dimension
    static const Uint16 ni = 5U;       // Actual interpolation points
    
    // Test methods
    bool test_1() through bool test_11();
    bool step();
}
```

The tester includes:
- Constants defining model dimensions
- Helper methods for comparison and assertion
- 11 test methods that validate different aspects of model behavior
- A `step()` method that runs all tests sequentially

#### 1.2.1 Test Utility Methods

```cpp
template <typename T> inline T tsign(T in);
template <typename T> inline T tabs(T in);
template <typename T> inline bool EXPECT_NEAR(T v1, T v2, T crit);
template <typename T> inline bool EXPECT_EQ(T v1, T v2);
inline bool EXPECT_TRUE(bool X);
inline bool EXPECT_FALSE(bool X);
```

These methods provide:
- Sign determination (`tsign`)
- Absolute value calculation (`tabs`)
- Near-equality testing with tolerance (`EXPECT_NEAR`)
- Exact equality testing (`EXPECT_EQ`)
- Boolean assertion testing (`EXPECT_TRUE`, `EXPECT_FALSE`)

#### 1.2.2 Test Coverage

The test suite covers:
1. Model naming (test_1)
2. Input limit initialization (test_2)
3. Input limiting with zero rate limits (test_3)
4. Input limiting with small values (test_4)
5. Input limiting with values exceeding limits (test_5)
6. Input limiting with invalid limits (test_6)
7. State reset functionality (test_7)
8. State reset with small values (test_8)
9. State reset with bounding (test_9)
10. State reset with selective bounding (test_10)
11. State reset with inverted bounds (test_11)

## 2. Dynamic Model Testing

### 2.1 Model_dynamic_pa_test Class

This class extends `Model_dynamic` to provide testing capabilities for dynamic models:

```cpp
class Model_dynamic_pa_test : public Model_dynamic
{
public:
    Model_dynamic_pa_test(Base::Allocator& alloc,
                         const State_space_model_params& Model_dynamic_params);
    
    // State access and modification methods
    void set_y_state(std::vector<Real> y);
    void set_u_state(std::vector<Real> u);
    void set_x_state(std::vector<Real> x);
    void set_states(std::vector<Real> x, std::vector<Real> u, std::vector<Real> y);
    
    // Configuration methods
    void set_is_output_initialized(const bool flag);
    void set_is_state_update_enabled_along_axes(const Rvector& in);
    void set_is_state_update_enabled_along_axes(bool r);
    void set_is_state_update_enabled_along_axes(const std::vector<Real>& in);
    void set_interpolation_point_state(const Real interp);
    
    // Getter methods
    bool get_is_output_initialized();
    void get_is_state_update_enabled_along_axes(Rvector& r);
    const Real get_interpolation_point_state();
    bool is_output_state_reset_enabled();
    Rvector& get_x_state();
    Rvector& get_y_state();
    Rvector& get_u_state();
    Rmatrix& get_a_matrix();
    Rmatrix& get_b_matrix();
    Rmatrix& get_c_matrix();
    Rmatrix& get_d_matrix();
    Antiwindup_logic_type::Type get_antiwindup_logic();
    
    // Model execution methods
    bool Run(const Rvector& u, Real interpolation_point, Rvector& y);
    bool Run(const Rvector& u, const Real interpolation_point, const Rvector& previous_y_saturated, Rvector& y);
    bool RunAntiWindupLogic(const Rvector& u, const Real interpolation_point, const Rvector& previous_y_saturated);
    // Additional Run methods with input limiting
};
```

This class provides:
- Direct access to internal model states and matrices
- Methods to configure model behavior
- Multiple variants of the `Run` method for different execution scenarios
- Anti-windup logic testing

### 2.2 Model_dynamic_pa_tester Class

This class provides a comprehensive test suite for the `Model_dynamic_pa_test` class:

```cpp
class Model_dynamic_pa_tester
{
public:
    static const Uint16 nx_max0 = 5U;  // Maximum state dimension
    static const Uint16 nu0 = 3U;      // Number of inputs
    static const Uint16 ny0 = 1U;      // Number of outputs
    static const Uint16 ni_max0 = 5U;  // Maximum interpolation points
    static const Uint16 nx0 = 5U;      // Actual state dimension
    static const Uint16 ni = 5U;       // Actual interpolation points
    const Real crit = 1.0E-3F;         // Comparison tolerance
    
    // Test methods
    bool test_1() through bool test_22();
    bool step();
}
```

The tester includes:
- Constants defining model dimensions
- Helper methods for comparison and assertion
- 22 test methods that validate different aspects of dynamic model behavior
- A `step()` method that runs all tests sequentially

#### 2.2.1 Test Coverage

The test suite covers:
1. Basic model functionality (test_1)
2. Uninitialized model behavior (test_2)
3. State resizing (test_3)
4. Disabling state updates (test_4)
5. State copying between models (test_5)
6. Anti-windup logic with no saturation (test_6)
7. Anti-windup logic with saturation on all axes (test_7)
8. Anti-windup logic with single-axis saturation and detrimental state update (test_8)
9. Anti-windup logic with single-axis saturation and beneficial state update (test_9)
10. Anti-windup logic with non-injective state-to-output mapping (test_10)
11. Anti-windup logic with unequal state and output dimensions (test_11)
12. Anti-windup logic with zero state update (test_12)
13. State reset to specific output (invalid case) (test_13)
14. State reset to specific output (disabled case) (test_14)
15. Zero state initialization (test_15)
16. Disabling state updates along all axes (test_16)
17. Disabling state updates along X axis (test_17)
18. Disabling state updates along Y axis (test_18)
19. Input limit override (test_19)
20. State reset result validity (test_20)
21. State reset for prescribed output (not supported) (test_21)
22. Model properties (test_22)

### 2.3 Test_tstate_space_model_params Structure

This structure extends `Tstate_space_model_params` to provide testing capabilities:

```cpp
template <Uint16 NX_MAX, Uint16 NU, Uint16 NY, Uint16 NI_MAX>
struct Test_tstate_space_model_params : public Tstate_space_model_params<NX_MAX, NU, NY, NI_MAX>
{
    explicit Test_tstate_space_model_params(const Uint16 nentries);
    Test_tstate_space_model_params();
};
```

This structure allows:
- Creating test model parameters with a specified number of entries
- Default construction for simple test cases

## 3. Model Set Testing

### 3.1 Gnc_model_set_pa_test Class

This class tests the `Gnc_model_set` class, which manages a collection of models:

```cpp
class Gnc_model_set_pa_test
{
public:
    Gnc_model_set_pa_test();
    bool step();
    
    // Test utility methods
    template <typename T> inline T tsign(T in);
    template <typename T> inline T tabs(T in);
    template <typename T> inline bool EXPECT_NEAR_EMB(T v1, T v2, T crit);
    template <typename T> inline bool EXPECT_EQ_EMB(T v1, T v2);
    inline bool EXPECT_TRUE_EMB(bool X);
    inline bool EXPECT_FALSE_EMB(bool X);
    
    Base::Allocator& alloc_ext;
    Model_set_state state;
    Gnc_model_set uut;  // Unit under test
    
    // Test methods
    void set_size(Gnc_model_set& ms, const uint16_t sz);
    bool test_1() through bool test_13();
};
```

This class tests:
- Model set initialization
- Model addition and removal
- Model access and execution
- State management across multiple models

### 3.2 Gnc_model_set_pa_test_factory Class

This class implements the `Ifactory<Model>` interface to create test models:

```cpp
class Gnc_model_set_pa_test_factory : public Base::Ifactory<Model>
{
public:
    typedef Tstate_space_model_params<5U, 3U, 1U, 5U> Type;
    Type controller;
    
    Gnc_model_set_pa_test_factory(Base::Allocator& alloc0);
    Model_dynamic* build(const Uint16 e, Base::Allocator& alloc) override;
    
    Base::Mblock<Uint16> mem_volatile;
    Base::Allocator& alloc_ext;
    uint16_t idx = 0U;
};
```

This factory:
- Creates model parameters with predefined matrices
- Implements the `build` method to create `Model_dynamic` instances
- Modifies model parameters based on the index to create different models

## 4. Body Transformations

### 4.1 Body_transformations_pa_tester Class

This class extends `Gnc_body_transformations` to provide testing capabilities:

```cpp
class Body_transformations_pa_tester : public Gnc_body_transformations
{
public:
    Body_transformations_pa_tester(const Gnc_transformation::Build_params& vtol_from_bul,
                                 const Gnc_transformation::Build_params& vf_from_bul,
                                 const Base::Rv3& t_bul_bul2vf_m);
    
    // Accessor methods for transformations
    const Gnc_transformation& get_vtol_from_bul() const;
    const Gnc_transformation& get_vf_from_bul() const;
    const Gnc_transformation& get_bul_from_vtol() const;
    const Gnc_transformation& get_vf_from_vtol() const;
    const Gnc_transformation& get_bul_from_vf() const;
    const Gnc_transformation& get_vtol_from_vf() const;
    
    // Methods to create transformations with center of gravity offsets
    Gnc_transformation::Build_params get_vf_cg_from_vf(const Maverick::Rvector3& p_bul_bul2cg_m) const;
    Gnc_transformation::Build_params get_vf_from_vf_cg(const Maverick::Rvector3& p_bul_bul2cg_m) const;
    Gnc_transformation::Build_params get_vtol_cg_from_vf(const Maverick::Rvector3& p_bul_bul2cg_m) const;
    Gnc_transformation::Build_params get_vtol_cg_from_vtol(const Maverick::Rvector3& p_bul_bul2cg_m) const;
    Gnc_transformation::Build_params get_vtol_from_vtol_cg(const Maverick::Rvector3& p_bul_bul2cg_m) const;
};
```

This class provides:
- Access to internal transformations between different coordinate frames
- Methods to create transformations that account for center of gravity offsets

### 4.2 Body_transformations_pa_test Class

This class tests the `Body_transformations_pa_tester` class:

```cpp
class Body_transformations_pa_test
{
public:
    bool step();
    bool Test_1();
};
```

This class tests:
- Transformation creation and composition
- Coordinate frame conversions
- Center of gravity offset handling

## 5. Coordinate Frames and Transformations

The system uses several coordinate frames:

### 5.1 Builder Frame (BUL)

The builder frame is the reference frame used during vehicle construction:
- Origin typically at a convenient reference point on the vehicle
- Axes aligned with the vehicle's physical structure
- Used as the common reference for other frames

### 5.2 Vehicle Frame (VF)

The vehicle frame is the primary control frame:
- Origin typically at the vehicle's center of gravity
- X-axis pointing forward
- Y-axis pointing to the right
- Z-axis pointing down
- Used for control algorithms and dynamics calculations

For the MK30 drone:
```cpp
// Rotation from builder frame to vehicle frame
constexpr std::array<std::array<double, 3U>, 3U> R_vf_from_bul{
    {{-1.0000000000e+00, 0.0000000000e+00, 0.0000000000e+00},
     {0.0000000000e+00, 1.0000000000e+00, 0.0000000000e+00},
     {0.0000000000e+00, 0.0000000000e+00, -1.0000000000e+00}}
};

// Translation from builder frame to vehicle frame measured in builder frame
constexpr std::array<double, 3U> t_bul_bul2vf_m {
    0.0000000000e+00, 0.0000000000e+00, 0.0000000000e+00
};
```

### 5.3 VTOL Frame

The VTOL (Vertical Take-Off and Landing) frame is used for vertical flight control:
- Origin typically at the vehicle's center of gravity
- X-axis aligned with the thrust vector during vertical flight
- Used for control during vertical flight phases

For the MK30 drone:
```cpp
// Rotation from builder frame to the VTOL frame
constexpr std::array<std::array<double, 3U>, 3U> R_vtol_from_bul{
    {{-2.8669176363e-01, 0.0000000000e+00, -9.5802287690e-01},
     {0.0000000000e+00, 1.0000000000e+00, 0.0000000000e+00},
     {9.5802287690e-01, 0.0000000000e+00, -2.8669176363e-01}}
};

// Translation from builder frame to VTOL frame measured in builder frame
constexpr std::array<double, 3U> t_bul_bul2vtol_m{
    0.0000000000e+00, 0.0000000000e+00, 0.0000000000e+00
};
```

### 5.4 Center of Gravity Frame

The center of gravity frame is offset from other frames to account for the vehicle's mass distribution:
- Origin at the vehicle's center of gravity
- Axes aligned with the reference frame
- Used for dynamics calculations

For the MK30 drone:
```cpp
// Translation from builder frame to CG measured in builder frame
constexpr std::array<double, 3U> t_bul_bul2ncg_m{
    -6.5700000000e-02, 0.0000000000e+00, 5.3800000000e-02
};
```

### 5.5 Airprobe Frames

The airprobe frames are used for air data measurements:
- Left and right airprobes have their own coordinate frames
- Used for airspeed and angle of attack measurements

For the MK30 drone:
```cpp
// Rotation from builder frame to the left airprobe frame
constexpr std::array<std::array<double, 3U>, 3U> R_left_probe_from_bul{
    {{-9.4138634529e-01, -1.5189779674e-01, -3.0119563119e-01},
     {1.5929508301e-01, -9.8723101477e-01, 0.0000000000e+00},
     {-2.9734966862e-01, -4.7978983072e-02, 9.5356236909e-01}}
};

// Translation from builder frame to left airprobe measured in builder frame
constexpr std::array<double, 3U> t_bul_bul2left_probe_m{
    -4.4631500000e-01, -1.8265400000e-01, -2.0002100000e-01
};
```

## 6. State Space Model Parameters

### 6.1 State_space_model_params Class

This class defines parameters for state space models:

```cpp
class State_space_model_params
{
public:
    State_space_model_params(Uint16 nx_max, Uint16 nu, Uint16 ny, Uint16 ni_max, 
                            Uint16 nx, Uint16 ni, Base::Xrtable<10U, 10U>& abcd_data);
    
    // Model parameters
    Real model_frequency_hz;
    Maverick::Rvector input_lower_bounds;
    Maverick::Rvector input_upper_bounds;
    Maverick::Rvector input_rate_lower_bounds;
    Maverick::Rvector input_rate_upper_bounds;
    Maverick::Rvector initial_output;
    Antiwindup_logic_type::Type antiwindup_logic_type;
};
```

This class stores:
- Model dimensions (state, input, output, interpolation points)
- Model execution frequency
- Input bounds and rate limits
- Initial output values
- Anti-windup logic type
- State space matrices (A, B, C, D) in an `Xrtable`

### 6.2 Tstate_space_model_params Template

This template extends `State_space_model_params` with compile-time dimensions:

```cpp
template <Uint16 NX_MAX, Uint16 NU, Uint16 NY, Uint16 NI_MAX>
struct Tstate_space_model_params : public State_space_model_params
{
    // Methods to set state space matrices
    void set_a(const Real a[NI_MAX][NX_MAX][NX_MAX]);
    void set_b(const Real b[NI_MAX][NX_MAX][NU]);
    void set_c(const Real c[NI_MAX][NY][NX_MAX]);
    void set_d(const Real d[NI_MAX][NY][NU]);
    void set_breakpoints(const Real breakpoints[NI_MAX]);
};
```

This template provides:
- Type-safe methods to set state space matrices
- Compile-time dimension checking
- Methods to set interpolation breakpoints

## 7. Vehicle Physical Parameters

The system includes physical parameters for different drone models:

### 7.1 MK30 Drone

```cpp
namespace mk30 {
    // Mass properties
    constexpr double min_mass_kg = 3.4500000000e+01;
    constexpr double nominal_mass_kg = 3.6125000000e+01;
    constexpr double max_mass_kg = 3.7750000000e+01;
    
    // Moment of inertia
    constexpr std::array<double, 6> J_nominal_bul_kg_m2{
        5.9650000000e+00, 6.0800000000e+00, 4.7900000000e+00,
        0.0000000000e+00, -9.1000000000e-01, 0.0000000000e+00
    };
}
```

### 7.2 MK30EV Drone

```cpp
namespace mk30ev {
    // Mass properties
    constexpr double min_mass_kg = 3.7000000000e+01;
    constexpr double nominal_mass_kg = 3.8500000000e+01;
    constexpr double max_mass_kg = 4.0000000000e+01;
    
    // Moment of inertia
    constexpr std::array<double, 6> J_nominal_bul_kg_m2{
        5.9650000000e+00, 6.0800000000e+00, 4.7900000000e+00,
        0.0000000000e+00, -7.8500000000e-01, 0.0000000000e+00
    };
}
```

## 8. Environmental Constants

The system includes environmental constants for dynamics calculations:

```cpp
namespace environment_constants {
    // Gravity
    constexpr double kGravityAccelMPerS2 = 9.80665;
    
    // Earth parameters
    constexpr double kEarthRadiusM = 6378137;
    
    // Air properties
    constexpr double kAirDensityMeanSeaLevelKgPerM3 = 1.225;
    constexpr double kMaxAirDensityKgPerM3 = 1.319;
    constexpr double kMinAirDensityKgPerM3 = 1.040;
    
    // Standard atmosphere parameters
    constexpr double kRIdealGasConstantJPerMolK = 8.31446261815324;
    constexpr double kMolarMassDryAirKgPerMol = 0.028964917;
    constexpr double kLapseRateKPerM = -0.0065;
    constexpr double kStaticPressureStandardDaySeaLevelPa = 101325;
    
    // Viscosity and temperature
    constexpr double kSutherlandRefDynamicViscosityKgPerMS = 1.716E-5;
    constexpr double kRefTemperatureK = 273.15;
    constexpr double kTemperatureStandardDaySeaLevelK = 288.15;
    constexpr double kSutherlandTemperatureK = 110.4;
    constexpr double kOperationalEnvelopeMinTemperatureK = 263.15;
    constexpr double kOperationalEnvelopeMaxTemperatureK = 313.15;
}
```

These constants are used for:
- Gravity compensation in dynamics models
- Atmospheric density calculations
- Temperature-dependent air property calculations
- Conversion between coordinate systems

## 9. Key Insights and Relationships

### 9.1 Model Hierarchy

The system uses a hierarchical model structure:
1. `Model` is the base class for all models
2. `Model_dynamic` extends `Model` with state space dynamics
3. `Model_pa_test` and `Model_dynamic_pa_test` extend these classes for testing
4. `Gnc_model_set` manages collections of models

### 9.2 State Space Representation

The system uses a standard state space representation:
- x̄(k+1) = A·x̄(k) + B·ū(k)
- ȳ(k) = C·x̄(k) + D·ū(k)

Where:
- x̄ is the state vector
- ū is the input vector
- ȳ is the output vector
- A, B, C, D are the state space matrices

### 9.3 Input Limiting

Input limiting is a critical feature that:
1. Enforces absolute bounds on inputs (u_min, u_max)
2. Enforces rate limits on inputs (u_rate_min, u_rate_max)
3. Prevents actuator saturation and damage
4. Ensures control commands remain within physical capabilities

### 9.4 Anti-Windup Logic

The system supports different anti-windup strategies:
1. `RESET_STATE`: Resets the state when output saturation occurs
2. `FREEZE_STATE_SINGLE_AXIS`: Freezes state updates along axes where saturation occurs

These strategies prevent integral windup in controllers, which can cause:
- Delayed response when coming out of saturation
- Overshoot and oscillation
- Degraded control performance

### 9.5 Coordinate Frame Relationships

The coordinate frames form a transformation graph:
```
                  ┌─────────┐
                  │   BUL   │
                  └─────────┘
                      │
          ┌───────────┴───────────┐
          │                       │
    ┌─────────┐             ┌─────────┐
    │   VF    │             │  VTOL   │
    └─────────┘             └─────────┘
          │                       │
    ┌─────────┐             ┌─────────┐
    │  VF_CG  │             │ VTOL_CG │
    └─────────┘             └─────────┘
```

Each transformation includes:
- A rotation matrix (R)
- A translation vector (t)
- Methods to transform positions, velocities, and accelerations

### 9.6 Testing Approach

The testing framework uses a systematic approach:
1. Unit tests for individual model components
2. Integration tests for model combinations
3. Validation against expected behavior
4. Edge case testing for boundary conditions
5. Error case testing for invalid inputs

## 10. Conclusion

The vehicle model and dynamics components provide a comprehensive framework for representing the drone's physical behavior. The state space models capture the system dynamics, while the coordinate transformations enable calculations in different reference frames. The input limiting and anti-windup logic ensure that control commands remain within physical constraints, preventing actuator saturation and improving control performance.

The testing framework validates all aspects of the model behavior, ensuring that the dynamics representation accurately reflects the physical system. By providing access to internal model states and parameters, the testing classes enable thorough validation of the model's behavior under various conditions.

The system's modular design allows for different drone models with varying physical parameters, while maintaining a consistent interface for control algorithms. This flexibility enables the same control architecture to be used across different drone variants with minimal modification.

## Referenced Context Files

- **06_Math_Utilities.md**: Provided information about mathematical utilities and linear algebra operations used in the model implementations, including rotation representations and transformations.