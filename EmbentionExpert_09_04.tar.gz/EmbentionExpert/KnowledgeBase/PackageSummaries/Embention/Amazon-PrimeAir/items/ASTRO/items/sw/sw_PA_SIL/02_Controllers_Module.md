# Generated from:

- code/PA_SIL_controllers/include/Emb_controllers_wrapper.h (886 tokens)
- code/PA_SIL_controllers/include/Mixer_wrapper.h (191 tokens)
- code/PA_SIL_controllers/source/Mixer_wrapper.cpp (1358 tokens)
- code/PA_SIL_controllers/source/Emb_controllers_wrapper.cpp (3435 tokens)

---

# Controllers Module Architecture and Functionality

This analysis provides a comprehensive overview of the PA_SIL_controllers module, focusing on its architecture, components, and functionality within the broader SIL (Software-In-the-Loop) framework.

## 1. Overall Architecture

The PA_SIL_controllers module implements a control system that processes inputs to generate control outputs for a vehicle, likely an aircraft or drone with multiple motors. The system follows a modular design with two primary components:

1. **Emb_controllers_wrapper**: The main interface to the SIL framework that handles initialization, execution scheduling, and message passing.
2. **Mixer_wrapper**: A component responsible for allocating forces and torques to individual motor commands.

## 2. Emb_controllers_wrapper Component

### 2.1 Core Functionality

The `Emb_controllers_wrapper` class serves as the primary interface between the SIL framework and the embedded controllers. It implements the `FirmwareSimulation` interface, providing methods for:

- Initialization with configuration data
- Execution scheduling
- Message handling
- Error reporting
- System reset

### 2.2 Interface Implementation

```cpp
class Emb_controllers_wrapper : public FirmwareSimulation {
public:
    Emb_controllers_wrapper();
    virtual bool Init(const FirmwareInitData& init_data);
    virtual bool ExecuteAndScheduleNextExecutionInNs(uint64_t& interval_ns);
    virtual std::string GetErrorString();
    virtual void Reset();
    virtual bool PutMessage(const MessageData& msg);
    virtual bool GetMessage(MessageData& msg);
    // ...
};
```

### 2.3 Initialization Process

The initialization process (`Init` method) handles:
- Loading configuration data from PDI (Parameter Data Items)
- Setting up recovery parameters
- Preparing the control system for execution

### 2.4 Execution Cycle

The execution cycle runs at 64Hz (15.625ms intervals) and performs these steps:
1. Updates the system time
2. Processes inputs through the control system
3. Clears processed inputs
4. Schedules the next execution
5. Updates reset allowance status

```cpp
bool Emb_controllers_wrapper::ExecuteAndScheduleNextExecutionInNs(uint64_t& interval_ns) {
    data.get()->control.build_if_needed();
    Bsp::Htimehelper::set_time_us(Base::Ttime(static_cast<double>(simulation_time_ns) * 1.0E-9));
    Pa_blocks::Recovery_wrapper_control_system_object::Input& input = data.get()->rwcso_input;
    input.timestamp_monontonic_ns = simulation_time_ns;
    data.get()->control.step(data.get()->rwcso_input, data.get()->rwcso_output);
    data.get()->rwcso_input.state_estimate.clear();
    interval_ns = static_cast<uint64_t>(15.625F * Const::E1000 * Const::FROM_NANO);
    simulation_time_ns += interval_ns;
    data.get()->update_reset_allowed();
    return true;
}
```

### 2.5 Message Handling

The wrapper handles various message types through the `PutMessage` and `GetMessage` methods:

#### Input Messages (`PutMessage`):
- State estimates
- Controller commands
- Battery status
- Contingency commands
- Mission reset commands
- Motor performance data
- Mission readiness messages
- Mission plan data
- Switch-over signals

#### Output Messages (`GetMessage`):
- Motor RPM commands for each motor (6 motors)
- Mode transition allowance
- Controller telemetry
- Recovery telemetry
- Alerts
- Mission readiness signals
- On-ground controller information
- Pre-flight check telemetry

### 2.6 Internal Data Structure

The wrapper maintains a complex internal data structure (`Data`) that includes:
- Mixer component
- Memory allocation for volatile data
- Hardware variables for switchover signaling
- Mission planning components
- Control system builder
- Message parsing and generation components
- Input/output structures for the recovery control system
- Command FIFOs for mode transitions
- Timing components

## 3. Mixer_wrapper Component

### 3.1 Core Functionality

The `Mixer_wrapper` class is responsible for allocating high-level force and torque commands to individual motor outputs. It implements the control allocation algorithm that maps desired forces and torques to specific motor commands.

### 3.2 Interface

```cpp
class Mixer_wrapper {
public:
    struct Inputs {
        Msg::ControlSystem::Controllers::ForcesAndTorquesRequest forces_and_torques_request;
    };

    struct Outputs {
        Msg::ControlSystem::Controllers::Mixer_return mixer_return;
        Msg::ControlSystem::ActuatorSetpoints actuator_setpoints;
        bool success;
    };

    Mixer_wrapper();
    bool step(const Inputs& in, Outputs& out, std::vector<Emb_wrapper_serial_message>& out_msgs);
};
```

### 3.3 Force and Torque Allocation

The mixer takes force and torque requests in 6 dimensions (Fx, Fy, Fz, L, M, N) and allocates them to individual motor commands:

```cpp
fm_vtol_request_N_and_N_m[0] = in.forces_and_torques_request.fx_N;
fm_vtol_request_N_and_N_m[1] = in.forces_and_torques_request.fy_N;
fm_vtol_request_N_and_N_m[2] = in.forces_and_torques_request.fz_N;
fm_vtol_request_N_and_N_m[3] = in.forces_and_torques_request.l_N_m;
fm_vtol_request_N_and_N_m[4] = in.forces_and_torques_request.m_N_m;
fm_vtol_request_N_and_N_m[5] = in.forces_and_torques_request.n_N_m;
```

### 3.4 Scheduling Data Processing

The mixer also processes scheduling data that affects the allocation algorithm:
- Acceleration commands
- Feedforward acceleration
- Air density
- Dynamic pressure

```cpp
Pa_scheduler::Inputs in_sheduler;
in_sheduler.a_cmd_x_trimncg_ned2trimncg_m_per_s2 = in.forces_and_torques_request.scheduling_data.a_lf_cmd_x_trimncg_m_per_s2;
in_sheduler.a_cmd_z_trimncg_ned2trimncg_m_per_s2 = in.forces_and_torques_request.scheduling_data.a_lf_cmd_z_trimncg_m_per_s2;
in_sheduler.a_ff_x_grtraj_m_per_s2 = in.forces_and_torques_request.scheduling_data.a_ff_cmd_x_grtraj_m_per_s2;
in_sheduler.a_ff_z_grtraj_m_per_s2 = in.forces_and_torques_request.scheduling_data.a_ff_cmd_z_grtraj_m_per_s2;
in_sheduler.air_density_kg_per_m3 = in.forces_and_torques_request.scheduling_data.air_density_kg_per_m3;
in_sheduler.dynamic_pressure_Pa = in.forces_and_torques_request.scheduling_data.dynamic_pressure_Pa;
```

### 3.5 Allocation Algorithm

The mixer uses a sophisticated allocation algorithm implemented in the `Mixer_allocator` class:

1. It tracks previous actuator commands for continuity
2. Processes the force/torque requests through the scheduler
3. Performs the allocation using the `mixer_allocator.step()` method
4. Populates the output structure with the allocation results

```cpp
previous_actuator_cmd.copy(Singleton::get_instance().actuator_allocator_object.get_state().mixer_state.last_actuators_set_points.motor_commanded_rpm.v);

Singleton::get_instance().mixer_allocator.step(previous_actuator_cmd, fm_vtol_request_N_and_N_m, scheduled_data);

const Pa_blocks::Mixer_allocator::Allocation_results& out_mixer = Singleton::get_instance().mixer_allocator.get_out();
```

### 3.6 Output Processing

The mixer outputs:
1. Predicted forces and torques that will be achieved
2. Motor commands in RPM for each of the 6 motors
3. Success status of the allocation algorithm

```cpp
out.mixer_return.fx_N = out_mixer.fm_vtol_predict_N_and_N_m[0];
out.mixer_return.fy_N = out_mixer.fm_vtol_predict_N_and_N_m[1];
out.mixer_return.fz_N = out_mixer.fm_vtol_predict_N_and_N_m[2];
out.mixer_return.l_N_m = out_mixer.fm_vtol_predict_N_and_N_m[3];
out.mixer_return.m_N_m = out_mixer.fm_vtol_predict_N_and_N_m[4];
out.mixer_return.n_N_m = out_mixer.fm_vtol_predict_N_and_N_m[5];

for (Uint16 i = 0; i < 6; i++) {
    out.actuator_setpoints.motor_commanded_rpm[i] = krpm2_2_rpm(out_mixer.actuators[i]);
}

out.success = (out_mixer.solve_status == Cqp::Results::success);
```

### 3.7 Singleton Pattern for Resource Management

The mixer uses a singleton pattern to manage shared resources:
- Scheduler initialization
- Mixer allocator
- Actuator allocator parameters
- Actuator allocator object
- Scheduler configuration

```cpp
struct Singleton {
    static Singleton& get_instance() {
        static Singleton ret;
        return ret;
    }
    bool scheduler_initialized;
    Pa_blocks::Mixer_allocator mixer_allocator;
    Pa_blocks::Vsdk_actuatorallocator_params vsdk_actuatorallocator_params;
    Pa_blocks::Actuator_allocator_object actuator_allocator_object;
    Conf_pa_scheduler_fullsim sch_configurator;
    // ...
};
```

## 4. Key Algorithms and Data Structures

### 4.1 Control Allocation Algorithm

The control allocation algorithm appears to be a constrained quadratic programming (CQP) solver, as indicated by the `Cqp::Results::success` status check. This suggests an optimization-based approach to allocate forces and torques while respecting actuator constraints.

### 4.2 Motor Command Conversion

The system converts from squared krpm to rpm using a sign-preserving square root function:

```cpp
Real krpm2_2_rpm(const Real rotor_speeds_krpm2) {
    const Real sgn = Rfun::sign(rotor_speeds_krpm2);
    return 1000.0F * sgn * Rmath::sqrtr(Rmath::fabsr(rotor_speeds_krpm2));
}
```

### 4.3 Message Handling Data Structures

The system uses a variety of message types for communication:
- `ForcesAndTorquesRequest`: Input forces and torques
- `Mixer_return`: Predicted achievable forces and torques
- `ActuatorSetpoints`: Motor commands
- Various telemetry and status messages

### 4.4 Scheduler

The `Pa_scheduler` component selects and evaluates the appropriate scheduler based on flight conditions. This likely involves gain scheduling or control mode selection based on the current flight regime.

```cpp
Pa_blocks::Pa_scheduler::get_instance().pick_scheduler_and_evaluate(rotor, in_sheduler);
const Pa_blocks::Pa_scheduler::Outputs& scheduled_data = Pa_blocks::Pa_scheduler::get_instance().get_outputs();
```

### 4.5 Recovery System Integration

The system includes recovery functionality, with specific handling for:
- Recovery mode transitions
- Recovery motor commands
- Recovery telemetry
- Recovery alerts
- Recovery mission readiness

## 5. Integration with SIL Framework

### 5.1 Firmware Simulation Interface

The module integrates with the SIL framework through the `FirmwareSimulation` interface, which is exposed via a C-style function:

```cpp
extern "C" {
    FirmwareSimulation* get_firmware_simulation_instance() {
        static FirmwareSimulation* ret = new Wrapper::Emb_controllers_wrapper();
        return ret;
    }
}
```

### 5.2 Message Passing

The system uses a message-passing architecture for communication with other components in the SIL framework:
- `PutMessage`: Receives messages from other components
- `GetMessage`: Sends messages to other components

### 5.3 Execution Scheduling

The SIL framework calls `ExecuteAndScheduleNextExecutionInNs` to run the controller at specific time intervals, with the controller requesting the next execution time.

## 6. Vehicle Configuration

Based on the code, the vehicle appears to be a hexacopter (6 motors) with the following motor arrangement:
1. Rear right
2. Center right
3. Front right
4. Front left
5. Center left
6. Rear left

This configuration allows for control in all 6 degrees of freedom (3 forces and 3 torques).

## 7. Control Flow Summary

1. The SIL framework initializes the controller with configuration data
2. At each execution step (64Hz):
   - The controller receives input messages (state estimates, commands, etc.)
   - The control system processes these inputs to generate force and torque requests
   - The mixer allocates these forces and torques to individual motor commands
   - The controller outputs messages with motor commands and telemetry
3. The SIL framework schedules the next execution based on the controller's request

## 8. Key Components and Their Relationships

```
SIL Framework
    |
    v
Emb_controllers_wrapper
    |
    |-- Control_builder
    |       |
    |       v
    |   Recovery_wrapper_control_system_object
    |       |
    |       v
    |-- Mixer_wrapper
    |       |
    |       |-- Pa_scheduler
    |       |       |
    |       |       v
    |       |-- Mixer_allocator
    |               |
    |               v
    |           Actuator_allocator_object
    |
    |-- Message Handling (PutMessage/GetMessage)
```

This architecture provides a comprehensive control system that processes inputs, generates control commands, and allocates those commands to individual actuators while maintaining communication with the broader simulation environment.