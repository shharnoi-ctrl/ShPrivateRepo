# Generated from:

- code/viis_to_xml.py (3321 tokens)

---

# VIIS to XML Converter Tool Analysis

## Overview and Purpose

The VIIS to XML converter is a Python tool designed to transform hardware configuration data from an Excel Interface Control Document (ICD) into a structured XML format. This XML output is used to configure hardware components, specifically for an "AMZ Lights" system. The tool serves as a bridge between human-readable configuration data in Excel and machine-readable XML that can be consumed by the target hardware system.

The primary workflow consists of:
1. Loading and parsing an Excel ICD file containing configuration data
2. Extracting global settings, state definitions for left and right sides, and sequence definitions
3. Validating the data for consistency and completeness
4. Transforming the data into a structured XML format
5. Writing the XML output to a file named 'ver_spdif_amz_lights.xml'

## Input Excel ICD Structure

The tool expects an Excel file with specific sheets that contain configuration data:

1. **Global settings**: Contains register-value pairs and descriptions for global configuration
   - Data starts at row 4
   - Column 1: Register address (in hex)
   - Column 2: Register value
   - Column 3: Description of the setting

2. **State Data Left**: Contains state definitions for the left side
   - Row 3: Column titles (state names)
   - Column 1: Register addresses
   - Columns 3+: Values for each state
   - Each column from 3 onwards represents a different state

3. **State Data Right**: Contains state definitions for the right side
   - Structure identical to "State Data Left"
   - Must have the same number of states as "State Data Left"

4. **Macro States**: Contains sequence definitions
   - Rows 8-19: Sequence names and enumerations
     - Column 1: Sequence name
     - Column 2: Sequence enumeration value
   - Rows 21+: Sequence state definitions
     - Column 1: Sequence name
     - Columns 2+: State names in sequence order

## Validation Logic

The tool implements several validation checks to ensure data consistency:

1. **File format validation**: Ensures the input file is an Excel (.xlsx) file
   ```python
   if (sys.argv[1].split(".")[-1] != "xlsx"):
       sys.exit("Expected L4 ICD xlsx file as argument!")
   ```

2. **Description validation**: Ensures every global setting has a description
   ```python
   assert len(data) <= len(desc), "A description must be present for every global data setting"
   ```

3. **State count validation**: Ensures left and right sides have the same number of states
   ```python
   assert len(state_data_left) == len(state_data_right), "Left and right sides do not have the same number of states"
   ```

4. **Sequence state validation**: Ensures every state referenced in a sequence is defined for both left and right sides
   ```python
   for sequence_key in sequences:
       for state_key in sequences[sequence_key]['states']:
           assert state_key in left_states_catalogue, f"State {state_key} not defined for left side"
           assert state_key in right_states_catalogue, f"State {state_key} not defined for right side"
   ```

5. **Register validation**: Checks if registers in global settings are supported
   ```python
   if reg not in kRegisterDict.keys():
       # This register is not supported, discard
       print(f" - Entry {hex(reg)} not supported")
       continue
   ```

## XML Output Structure

The generated XML has the following structure:

```xml
<entry-amz-lights>
    <id>486</id>
    <filename>amz_lights.bin</filename>
    <version>
        <major>7</major>
        <minor>1</minor>
        <revision>1</revision>
    </version>
    <data>
        <config>
            <!-- Global register configurations -->
            <str-tunarray-element str-tunarray-key="0">
                <reg>register_address</reg>
                <value>register_value</value>
            </str-tunarray-element>
            <!-- More register configurations... -->
        </config>
        <light-states-left>
            <!-- Left side state definitions -->
            <str-tunarray-element str-tunarray-key="0">
                <phases>
                    <!-- Phase values -->
                </phases>
                <widths>
                    <!-- Width values -->
                </widths>
            </str-tunarray-element>
            <!-- More state definitions... -->
        </light-states-left>
        <light-states-right>
            <!-- Right side state definitions (same structure as left) -->
        </light-states-right>
        <sequences>
            <!-- Sequence definitions -->
            <str-tunarray-element str-tunarray-key="0">
                <!-- State references for this sequence -->
                <str-tunarray-element str-tunarray-key="0">
                    <left>left_state_index</left>
                    <right>right_state_index</right>
                </str-tunarray-element>
                <!-- More state references... -->
            </str-tunarray-element>
            <!-- More sequence definitions... -->
        </sequences>
    </data>
</entry-amz-lights>
```

## Key Data Transformations

### 1. Register Handling

The tool maintains a dictionary (`kRegisterDict`) mapping register addresses to symbolic names:

```python
kRegisterDict = {
    0x00: 'kMtpCfg',
    0x01: 'kOutCtrl',
    # ... many more register definitions
}
```

When processing global settings, register addresses are converted to their symbolic names:
```python
reg_name = kRegisterDict[reg]
global_data.append((reg_name, value, description, reg))
```

### 2. State Name Normalization

State names from the Excel file are normalized to create consistent identifiers:
```python
def name_to_key_value(name):
    kCharsToRemove = ['_', '-', '(', ')', '[', ']']
    for char in kCharsToRemove:
        name = name.replace(char, ' ')
    name_capped = string.capwords(name)
    return ''.join(filter(str.isalnum, name_capped))
```

This function:
1. Removes special characters like underscores, hyphens, and brackets
2. Capitalizes words
3. Removes any remaining non-alphanumeric characters

### 3. State Data Organization

States are organized into a catalogue structure for easy lookup:
```python
def catalogue_states(state_entries):
    states = {}
    idx = 0
    for state_entry in state_entries:
        state_name_key = state_entry["key"]
        state = {}
        state["decl"] = state_entry["decl"]
        state["idx"] = str(idx)
        for data in state_entry["data"]:
            reg = literal_eval(data[0])
            state[reg] = data[1]
        states[state_name_key] = state
        idx += 1
    return states
```

This creates a dictionary where:
- Keys are normalized state names
- Values are dictionaries containing:
  - "decl": The state declaration (e.g., "kIndicationState0")
  - "idx": The state index
  - Register addresses mapped to their values

### 4. Phase and Width Register Handling

The tool specifically handles phase and width registers, which are organized in specific ranges:
```python
kPhaseRegStart = 0x15
kPwRegStart = 0x29
kPwRegEnd = 0x3D
```

When writing states to XML, these registers are processed separately:
```python
def write_states_to_xml(states, light_states_xml):
    for state_name_key in states:
        state = states[state_name_key]
        state_et = add_tun_array(light_states_xml, state['idx'])
        phases_et = ET.SubElement(state_et, 'phases')
        widths_et = ET.SubElement(state_et, 'widths')
        
        # Process phase registers
        j = 0
        for reg in range(kPhaseRegStart, kPwRegStart):
            phase_entry_et = add_tun_array(phases_et, j)
            phase_entry_et.text = str(state[reg])
            j += 1
            
        # Process width registers
        j = 0
        for reg in range(kPwRegStart, kPwRegEnd):
            widths_entry_et = add_tun_array(widths_et, j)
            widths_entry_et.text = str(state[reg])
            j += 1
```

### 5. Sequence Construction

Sequences are constructed by referencing state indices for both left and right sides:
```python
def write_sequences_to_xml(sequences, left_states, right_states, sequences_xml):
    idx_seq = 0
    for sequence_name_key in sequences.keys():
        sequence = sequences[sequence_name_key]
        sequence_states = sequence['states']
        ind_seq_xml = add_tun_array(sequences_xml, idx_seq)
        idx_seq += 1
        
        idx_state = 0
        for state in sequence_states:
            ind_seq_ids_xml = add_tun_array(ind_seq_xml, idx_state)
            left_id_xml = ET.SubElement(ind_seq_ids_xml, 'left')
            left_id_xml.text = left_states[state]["idx"]
            right_id_xml = ET.SubElement(ind_seq_ids_xml, 'right')
            right_id_xml.text = right_states[state]["idx"]
            idx_state += 1
```

This creates a sequence structure where each step references the appropriate state index for both left and right sides.

### 6. Hexadecimal to uint8 Conversion

Register values are converted from hexadecimal strings to uint8 values:
```python
def hex_to_uint8(hex_str):
    integer_value = int(hex_str, 16)
    uint8_value = struct.unpack('B', struct.pack('B', integer_value))[0]
    return uint8_value
```

This ensures values are properly constrained to the 0-255 range.

## Error Handling and Edge Cases

1. **Missing or TBD Values**: The tool skips entries with "TBD" or None values
   ```python
   if val == "TBD" or val is None:
       continue
   ```

2. **Unsupported Registers**: Registers not in the `kRegisterDict` are identified and skipped
   ```python
   if reg not in kRegisterDict.keys():
       print(f" - Entry {hex(reg)} not supported")
       continue
   ```

3. **Sequence Definition Validation**: Sequences without enumeration values are skipped
   ```python
   if sequence_enum == "TBD" or sequence_enum is None:
       continue
   ```

4. **Sequence Name Validation**: Sequence state definitions without matching enumeration entries are skipped
   ```python
   if not sequence_key in sequences.keys():
       print(f"Sequence name {sequence_name} not found in enumerated list, skipping defintion")
       continue
   ```

5. **State Reference Validation**: The tool validates that all states referenced in sequences exist in both left and right state catalogues
   ```python
   assert state_key in left_states_catalogue, f"State {state_key} not defined for left side"
   assert state_key in right_states_catalogue, f"State {state_key} not defined for right side"
   ```

## Conclusion

The VIIS to XML converter is a specialized tool for transforming hardware configuration data from an Excel ICD format to a structured XML format. It handles register configurations, state definitions for left and right sides, and sequence definitions. The tool includes comprehensive validation to ensure data consistency and completeness, and performs specific transformations to normalize state names, organize register values, and construct proper XML output. The resulting XML file provides a complete hardware configuration that maps directly to the requirements specified in the Excel ICD.