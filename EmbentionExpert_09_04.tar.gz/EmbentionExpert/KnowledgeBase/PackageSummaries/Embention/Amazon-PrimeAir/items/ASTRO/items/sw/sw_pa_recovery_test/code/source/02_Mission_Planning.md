# Generated from:

- Mission_plan_utilities.cpp (3150 tokens)
- Test_mission_plan.cpp (11747 tokens)
- Test_mission_utilities.cpp (16531 tokens)
- Recovery_mission_data_processor_test.cpp (197 tokens)
- Test_recovery_mission_data_processor.cpp (8084 tokens)
- Land_manager_pa_test.cpp (9105 tokens)

---

# Mission Planning System: High-Fidelity Semantic Knowledge Graph

## 1. Mission Plan Utilities Overview

The mission planning system provides a comprehensive framework for managing, manipulating, and processing mission plans. The system is built around the `Mission_plan` class, which encapsulates mission data including routes, maneuvers, actions, and environmental parameters.

### 1.1 Mission Plan Structure

A mission plan consists of:

- **Initial Plan**: The primary mission path containing a sequence of mission steps
- **Alternate Plans**: Alternative routes that can be taken in specific scenarios (e.g., return home)
- **Coordinate Reference System (CRS)**: Defines the projection used for coordinate transformations
- **Environment Data**: Contains atmospheric conditions like pressure and temperature
- **Flight ID**: Unique identifier for the mission

Each mission plan contains several types of actions:
- **Takeoff Action**: Defines how the aircraft initiates flight
- **Markerless Delivery Action**: Specifies package delivery parameters
- **Marker Land Action**: Landing using visual markers
- **GPS Land Action**: Landing using GPS coordinates

### 1.2 Mission Plan Utilities Functions

The `Mission_plan_utilities` namespace provides functions to manipulate mission plans:

```cpp
// Clear specific components of a mission plan
void clear_initial_plan(Mission_plan& mission_plan)
void clear_coordinate_reference_system(Mission_plan& mission_plan)
void clear_projection_point(Mission_plan& mission_plan)
void clear_projection_point_data(Mission_plan& mission_plan, bool clear_latitude, bool clear_longitude)
void clear_environment(Mission_plan& mission_plan)
void clear_environment_data(Mission_plan& mission_plan, bool clear_static_pressure, bool clear_static_temperature)
void clear_mission_steps(Mission_plan& mission_plan, Mission_plan_type::Type plan_type)
void clear_takeoff_action_data(Mission_plan& mission_plan, bool clear_initial_tracking_point, bool clear_initial_velocity, bool clear_ground_point, bool clear_bounding_volume)
void clear_markerless_delivery_action_data(Mission_plan& mission_plan, bool clear_target_point, bool clear_minimum_search_altitude_point, bool clear_outbound_initial_tracking_point)
void clear_action(Mission_plan& mission_plan, Mission_plan_action_type::Type action_type, Mission_plan_type::Type plan_type)

// Retrieve specific actions from a mission plan
Takeoff_action get_takeoff_action(const Mission_plan& mission_plan)
Markerless_delivery_action get_markerless_delivery_action(const Mission_plan& mission_plan)
```

These utilities allow for precise manipulation of mission plan components, enabling testing and validation of mission plan processing.

## 2. Mission Plan Data Processing

### 2.1 Mission Plan Validation

The system includes comprehensive validation of mission plans:

```cpp
bool is_mission_plan_valid(const Mission_plan& mission_plan)
bool is_initial_plan_valid(const Initial_plan& initial_plan)
bool is_alternate_plan_valid(const Initial_plan& initial_plan, const Alternate_plan& alternate_plan)
bool is_mission_step_an_action(const Mission_step& mission_step)
bool is_takeoff_action_valid(const Takeoff_action& takeoff_action)
bool is_markerless_delivery_action_valid(const Markerless_delivery_action& markerless_delivery_action)
bool is_marker_land_action_valid(const Marker_land_action& marker_land_action)
bool is_gps_land_action_valid(const Gps_land_action& gps_land_action)
```

Validation ensures that:
- All required fields are present
- Coordinate systems are properly defined
- Actions have necessary parameters
- Mission steps follow a logical sequence
- The total number of steps doesn't exceed system limits

### 2.2 Mission Plan Deserialization

The system deserializes mission plans from binary data:

```cpp
bool deserialize_mission(const Mission_plan_data& mission_plan_data, 
                        const Upload_mission_plan_wrapper& mission_plan_upload_metadata,
                        Mission_plan& mission_plan)
```

This process includes:
1. Validating the mission plan data is populated
2. Checking the wrapper message checksum
3. Verifying the metadata checksum
4. Confirming the metadata version and encoding
5. Deserializing the binary data into a structured mission plan

### 2.3 Route and Maneuver Generation

The system generates routes and maneuvers from mission plans:

```cpp
bool parse_route_maneuvers(const Mission_plan& mission_plan, 
                          const Uint32 route_id,
                          Command_route_entry& command_route_entry)
```

This function:
1. Validates the mission plan
2. Determines the route type (takeoff to delivery, delivery to landing, return home)
3. Extracts initial conditions for the route
4. Parses mission steps into maneuvers
5. Packages the maneuvers into a command route entry

## 3. Mission Plan Testing Framework

The system includes extensive testing to ensure mission plan functionality:

### 3.1 Mission Plan Construction and Validity Tests

```cpp
bool test_1()  // ConstructorTest
bool test_2()  // ValidityTest
```

These tests verify:
- Mission plan construction from messages and other mission plans
- Validity checks for various mission plan components
- Behavior when required components are missing

### 3.2 Mission Plan Data Extraction Tests

```cpp
bool test_3()  // get_lla_ned_originSuccess
bool test_4()  // get_lla_ned_originFailure
bool test_5()  // GetLlaGroundPointSuccess
bool test_6()  // GetLlaGroundPointFailure
bool test_7()  // GetBoundingVolumeDataSuccess
bool test_8()  // GetBoundingVolumeDataFailure
bool test_9()  // get_environment_valuesSuccess
bool test_10() // get_environment_valuesFailure
```

These tests verify extraction of:
- NED (North-East-Down) origin coordinates
- Ground point coordinates
- Bounding volume data
- Environmental values (pressure, temperature)

### 3.3 Mission Action Parameter Tests

```cpp
bool test_11() // GetTakeoffParametersSuccess
bool test_12() // GetTakeoffParametersFailure
bool test_13() // GetBackyardExitLocationSuccess
bool test_14() // GetBackyardExitLocationFailure
bool test_15() // get_marker_landing_information
```

These tests verify extraction of:
- Takeoff parameters (initial tracking point, velocity, altitude)
- Delivery action parameters (backyard exit location)
- Marker landing information

### 3.4 Mission Utilities Tests

```cpp
bool test_1()  // IsMissionStepAnAction
bool test_2()  // IsTakeoffActionValid
bool test_3()  // IsMarkerlessDeliveryActionValid
bool test_4()  // is_marker_land_action_valid
bool test_5()  // IsGpsLandActionValid
bool test_6()  // is_initial_plan_valid
bool test_7()  // is_alternate_plan_valid
```

These tests verify:
- Action type identification
- Action validity checks
- Plan validity checks

### 3.5 Route and Maneuver Generation Tests

```cpp
bool test_17() // parse_mission_stepSuccess
bool test_18() // parse_mission_stepFailure
bool test_19() // ParseInitialPlanMissionStepsSuccess
bool test_20() // ParseInitialPlanMissionStepsFailure
bool test_21() // parse_alternate_plan_mission_stepsSuccess
bool test_22() // parse_alternate_plan_mission_stepsFailure
bool test_23() // parse_route_maneuversSuccess
bool test_24() // parse_route_maneuversFailure
```

These tests verify:
- Parsing mission steps into maneuvers
- Generating routes from initial and alternate plans
- Handling of invalid mission steps and plans

## 4. Recovery Mission Data Processor

The `Recovery_mission_data_processor` is responsible for processing mission plans and generating route commands:

### 4.1 Core Functionality

```cpp
bool run(const Input& input, Output& output, Log_data& log_data)
```

This function:
1. Checks if the mission plan data is populated
2. Deserializes the mission plan
3. Extracts mission parameters (NED origin, environment values)
4. Generates command route entries for each route type
5. Populates return home contingency plan (RHCP) data
6. Sets the mission as successfully processed

### 4.2 Command Route Entry Generation

```cpp
bool package_command_route_entry(const Mission_plan& mission_plan,
                                const Mission_utilities::Route_type route_type,
                                const Uint32 return_home_route_idx,
                                Command_route_entry& command_route_entry)
```

This function:
1. Determines the route ID based on route type
2. Extracts initial conditions for the route
3. Parses mission steps into maneuvers
4. Sets the flight ID and route ID

### 4.3 RHCP Maneuver Range Data

The processor generates RHCP (Return Home Contingency Plan) maneuver range data:

```cpp
bool populate_rhcp_maneuver_range_data(const Mission_plan& mission_plan, Output& output)
```

This maps nominal maneuver IDs to RHCP route IDs, enabling the system to determine which RHCP to use if a maneuver fails.

## 5. Land Manager

The `Land_manager` controls the landing process:

### 5.1 Landing States

The land manager operates in several modes:
- `SLOW_DOWN_TO_HOVER`: Decelerates the aircraft to hover
- `FAST_DESCENT`: Rapid descent from altitude
- `SLOW_DESCENT`: Controlled descent near the ground
- `SLOW_DESCENT_LANDING_ATTITUDE`: Final approach with landing attitude

### 5.2 Control Modes

For each landing state, the land manager sets appropriate control modes:
- Horizontal control: Position, Velocity, or Position with Fixed Attitude
- Vertical control: Position or Velocity

### 5.3 Landing Parameters

The land manager tracks and controls:
- Altitude latching
- Yaw command latching
- Horizontal position latching
- Deceleration filters
- Attitude leveling filters

### 5.4 Descent Control

The land manager uses a maneuver coordinate (`mc_landing`) to generate a smooth descent profile:
- Fast descent rate at high altitudes
- Transition to slow descent rate near the ground
- Controlled deceleration with acceleration and jerk limits

### 5.5 Landing Attitude Control

During landing, the land manager:
- Maintains level roll (0 degrees)
- Sets a specific pitch angle for landing
- Latches the yaw angle to maintain heading

## 6. Mission Plan Integration with Trajectory Generation

The mission planning system integrates with the trajectory generation system through:

### 6.1 Route Generation

1. Mission plans are parsed into routes with maneuvers
2. Each route has initial conditions (position, velocity)
3. Routes are assigned unique IDs for tracking

### 6.2 Maneuver Types

The system supports several maneuver types:
- `hover_vtol_maneuver`: Stationary hover
- `straight_vtol_maneuver`: Linear movement in VTOL mode
- `straight_wbf_maneuver`: Linear movement in wing-borne flight
- `roll_wbf_maneuver`: Rolling maneuver in wing-borne flight
- `turn_wbf_maneuver`: Turning maneuver in wing-borne flight

### 6.3 Route Types

The system defines several route types:
- `route_type_takeoff_to_delivery`: From takeoff to delivery point
- `route_type_delivery_to_landing`: From delivery point to landing
- `route_type_takeoff_to_landing`: Direct from takeoff to landing
- `route_type_return_home`: Return to home location

### 6.4 Route ID Management

```cpp
bool route_type_from_route_id(const Uint32 route_id, Route_type& route_type)
bool route_id_from_route_type(const Route_type route_type, const Uint32 alternate_plan_id, Uint32& route_id)
Uint32 route_id_from_alternate_plan_id(const Uint32 alternate_plan_id)
Uint32 alternate_plan_id_from_rhcp_route_id(const Uint32 route_id)
```

These functions map between route types, route IDs, and alternate plan IDs, enabling the system to track and manage routes.

## 7. Error Handling and Recovery

### 7.1 Invalid State Handling

The system handles invalid states through:
- Default values for invalid parameters
- Explicit validity checks before operations
- Fallback behaviors when data is missing

### 7.2 Mission Recovery

The `Recovery_mission_data_processor` provides mission recovery capabilities:

```cpp
bool is_mission_plan_successfully_processed() const
```

This tracks whether a mission plan has been successfully processed, allowing the system to:
1. Avoid reprocessing already processed plans
2. Detect and handle processing failures
3. Maintain mission state across system restarts

### 7.3 RHCP (Return Home Contingency Plan)

The system maintains RHCP data to handle contingencies:

```cpp
struct Rhcp_maneuver_range_data
{
    Uint32 route_id;
    Uint32 start_maneuver_id;
    Uint32 end_maneuver_id;
};
```

This maps ranges of nominal maneuver IDs to RHCP route IDs, enabling the system to:
1. Determine which RHCP to use if a maneuver fails
2. Transition smoothly to the appropriate return home route
3. Maintain mission safety in off-nominal conditions

## Referenced Context Files

The following context files provided useful information for understanding the mission planning system:

1. **Mission_plan_utilities.h** - Defined the interface for mission plan manipulation functions
2. **Mission_utilities.h** - Provided utility functions for mission plan processing
3. **Test_macros.h** - Contained testing macros used in the test files
4. **Unit_test_mission_v3.h** - Defined test mission generation functions
5. **Mission_bounding_box_data.h** - Defined the structure for mission bounding box data
6. **Vsdk_log.h** - Provided logging functionality

## Conclusion

The mission planning system provides a comprehensive framework for defining, validating, and executing flight missions. It includes:

1. A structured mission plan format with initial and alternate plans
2. Utilities for manipulating and validating mission plans
3. Functions for generating routes and maneuvers from mission plans
4. A recovery processor for handling mission plan data
5. A land manager for controlling the landing process
6. Extensive testing to ensure system reliability

This system enables the definition of complex flight missions with multiple routes, contingency plans, and precise control over takeoff, delivery, and landing actions.