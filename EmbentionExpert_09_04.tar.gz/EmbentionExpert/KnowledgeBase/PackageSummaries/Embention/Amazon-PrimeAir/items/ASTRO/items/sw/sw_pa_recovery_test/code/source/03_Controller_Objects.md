# Generated from:

- Controller_object_wrapper_test.cpp (241 tokens)
- Controller_Status_test.cpp (6265 tokens)
- ControllersObject_emb_test.cpp (9247 tokens)
- Recovery_controller_telemetry_msg_test.cpp (13233 tokens)
- Recovery_wrapper_control_system_object_test.cpp (1543 tokens)
- Cqp_pa_test.cpp (35162 tokens)
- Cm_pa_test.cpp (2766 tokens)
- SwitchBlender_pa_test.cpp (3860 tokens)

---

# Controller Object Wrapper Architecture and Testing

This document provides a comprehensive analysis of the controller objects implementation and testing in the system, focusing on the controller wrapper architecture, status handling, telemetry, and recovery systems.

## 1. Controller Object Wrapper Architecture

### 1.1 Controller Object Wrapper

The `Controller_object_wrapper` class serves as a wrapper for the controller system, providing an interface for stepping through controller execution:

```cpp
class Controller_object_wrapper {
public:
    Controller_object_wrapper(const std::string& cloud_desktop_in_file_name,
                             const std::string& cloud_desktop_out_file_name,
                             const std::string& out_csv_file_name);
    
    bool step();
    
private:
    std::ifstream in_file;
    std::ofstream cloud_desktop_out_file;
    std::ofstream out_csv_file;
    Controller_object_wrapper controller_object_wrapper;
};
```

The wrapper processes input messages from files, passes them to the controller, and collects output messages:

```cpp
bool Controller_object_wrapper::step() {
    std::vector<Wrapper::Emb_wrapper_serial_message> in_msgs;
    std::vector<Wrapper::Emb_wrapper_serial_message> out_msgs;

    if (!in_file.eof()) {
        in_file >> in_msgs;
        controller_object_wrapper.step(in_msgs, out_msgs);
    }
    return true;
}
```

### 1.2 Recovery Wrapper Control System Object

The `Recovery_wrapper_control_system_object` extends the controller wrapper functionality for recovery scenarios:

```cpp
class Recovery_wrapper_control_system_object {
public:
    Recovery_wrapper_control_system_object(
        Base::Allocator& alloc_external,
        Base::Mblock<Uint16>& mem_volatile,
        const Vsdk_recovery_params& param,
        const Mission_param& m_param,
        const Controllers_param& ctrl_param,
        const Pa_scheduler& mk30_scheduler,
        const bool& has_switchover_been_signalled_to_primary,
        const bool& has_switchover_been_signalled_to_recovery,
        const Mission_plan& mission_plan,
        const Mission_plan_data& mission_plan_data);
        
    bool run(const Input& input, Output& output);
    
    // Motor state management methods
    void set_motor_state_request(
        const Recovery_controls_command_processor::Output& rccp_output,
        const Real64 current_time_s,
        Motor_rpm_cmd::Motor_state_request& motor_state_request);
        
    bool all_motors_armed();
    bool all_motors_enabled();
    bool all_motors_low_rpm();
    bool is_valid();
};
```

The recovery wrapper manages motor states during recovery operations, with specific logic for arming, enabling, and monitoring motor RPMs.

## 2. Controller Status Handling

### 2.1 Controller Status Testing

The `Controller_Status_test` class tests the controller status reporting functionality:

```cpp
class Controller_Status_tester : public Controllers_object {
public:
    Controller_Status_tester(const Vsdk_controllers_params& param, 
                            const Controllers_param& controllers_param0);
    
    bool run(const Input& input, Output& output);
    const Controllers_state& GetState() const;
    void SetState(Controllers_state& state);
    bool IsSpecificationValid();
};
```

The controller status tests verify:

1. Controller initialization with valid/invalid parameters
2. Status reporting during different controller modes (INIT, GROUND_IDLE, TAKEOFF, etc.)
3. Command sequence ID tracking
4. Position and velocity command reporting

### 2.2 Status Reporting

The controller reports its status through the `controllers_status` message, which includes:

- Current controller mode (INIT, GROUND_IDLE, TAKEOFF, LAND, TRACK_SPLINE)
- Degradation level (NOMINAL or degraded states)
- Position and velocity commands
- Route tracking data
- Command sequence IDs

Example status fields:
```cpp
// Position and velocity command reporting
ret &= compare_data(cqp_results->solution[i_component], static_cast<Real64>(0.25), "solution", Cqp::positive_zero);
ret &= compare_data(land_latitude_rad, out.controllers_status.back().message.position_and_velocity_command.latitude_command_rad);
ret &= compare_data(land_longitude_rad, out.controllers_status.back().message.position_and_velocity_command.longitude_command_rad);
ret &= compare_data(static_cast<Real>(state_estimate.altitude_hae_wgs84_m), out.controllers_status.back().message.position_and_velocity_command.altitude_hae_wgs84_commanded_m);
```

## 3. Controller Telemetry

### 3.1 Recovery Controller Telemetry

The system implements comprehensive telemetry for the recovery controller through the `Recovery_controller_telemetry_msg` class:

```cpp
class Recovery_controller_telemetry_msg_test {
public:
    bool test0_serialization_deserialization();
    
private:
    // Telemetry component checks
    bool check_Recovery_controller_telemetry_deserialization(Recovery_controller_telemetry& obj);
    bool check_Controllers_telemetry(Controllers_telemetry& obj);
    bool check_Sep_telemetry(Sep::Telemetry& obj);
    bool check_Tcg_telemetry(Tcg::Telemetry& obj);
    bool check_Aacg_telemetry(Aacg::Telemetry& obj);
    bool check_Asc_telemetry(Asc::Telemetry& obj);
    bool check_Tsc_telemetry(Tsc::Telemetry& obj);
    bool check_Forces_and_torques_request_telemetry(Forces_and_torques_request::Telemetry& obj);
    // Additional telemetry component checks...
};
```

The telemetry system captures detailed information about:

1. **Controllers Telemetry**:
   - Sep (State Estimation and Prediction)
   - Tcg (Trajectory Command Generator)
   - Aacg (Attitude and Acceleration Command Generator)
   - Asc (Attitude Stabilization Controller)
   - Tsc (Trajectory Stabilization Controller)
   - Forces and torques requests

2. **Mixer Telemetry**:
   - Mixer return values
   - Saturation status

3. **Recovery Control Command Processor (RCCP) Log Data**:
   - Recovery mission phase of flight
   - Mission data processing
   - Route construction
   - Tracking processor data

4. **State Machine Logs**:
   - Recovery state machine logs
   - State machines telemetry

### 3.2 Telemetry Data Validation

The telemetry system includes extensive validation to ensure data integrity:

```cpp
bool Recovery_controller_telemetry_msg_test::check_Sep_telemetry(Sep::Telemetry& obj) {
    bool ret = true;
    // Expected data
    Base::Rv4 exp_q_trim0ncg_from_vtolncg = {{0.998697F, 5.84827e-21F, 0.0510376F, -1.71385e-20F}};
    Base::Rv4 exp_q_est_vtolncg_from_ned = {{0.997477F, 0.0479499F, -0.0522555F, 0.00323345F}};
    // Additional expected values...
    
    // Comparison
    ret = compare_attribute(obj.q_trim0ncg_from_vtolncg, exp_q_trim0ncg_from_vtolncg, replay_comparison_tol);
    ret = compare_attribute(obj.q_est_vtolncg_from_ned, exp_q_est_vtolncg_from_ned, replay_comparison_tol);
    // Additional comparisons...
    
    return ret;
}
```

## 4. Constrained Quadratic Programming (CQP) Approach

### 4.1 CQP Implementation

The system uses Constrained Quadratic Programming (CQP) for optimal control allocation:

```cpp
class Cqp {
public:
    struct Results {
        enum Status {
            success,
            infeasible,
            max_iterations_reached
        };
        
        Status status;
        R64vector solution;
        Base::Array<Constraint> active_set;
    };
    
    struct Constraint {
        enum Type {
            lower_bound,
            upper_bound,
            equality,
            inequality
        };
        
        Type type;
        Uint16 index;
    };
    
    Cqp(const R64matrix& G, 
        const R64vector& a, 
        const R64matrix& A_eq, 
        const R64vector& b_eq,
        const R64matrix& A_ineq, 
        const R64vector& b_ineq,
        const R64vector& lb, 
        const R64vector& ub,
        Base::Allocator& alloc_volatile);
        
    void step();
    const Results& get_out() const;
};
```

The CQP solver handles:

1. Unconstrained optimization
2. Bound constraints (upper and lower)
3. Equality constraints
4. Inequality constraints
5. Feasibility checking

### 4.2 CQP Testing

The `Cqp_pa_test` class provides extensive testing for the CQP implementation:

```cpp
class Cqp_pa_test {
public:
    bool step();
    
private:
    // Test cases
    bool CQPTest_solve_UNCONSTRAINE();
    bool CQPTest_solve_INVALID_BOUNDS();
    bool CQPTest_solve_UPPER_BOUND();
    bool CQPTest_solve_LOWER_BOUND();
    bool CQPTest_solve_ALL_BOUND();
    bool CQPTest_solve_SINGLE_COMPONENT_EQUALITY();
    bool CQPTest_solve_ALL_COMPONENT_EQUALITY();
    bool CQPTest_solve_TWO_COMPONENTS_EQUALITY();
    bool CQPTest_solve_HYPERPLANE_EQUALITY();
    bool CQPTest_solve_INFEASIBLE_HYPERPLANE_EQUALITIES();
    bool CQPTest_solve_SINGLE_COMPONENT_INFEASIBLE_EQUALITY();
    bool CQPTest_solve_FEASIBLE_RANDOM_JACOBIAN();
    bool CQPTest_solve_SINGLE_COMPONENT_INEQUALITY_UPPER_BOUND();
    bool CQPTest_solve_SINGLE_COMPONENT_INEQUALITY_LOWER_BOUND();
    bool CQPTest_solve_HYPERPLANE_INEQUALITY();
    bool CQPTest_solve_INFEASIBLE_HYPERPLANE_INEQUALITIES();
    bool CQPTest_solve_HYPERPLANE_INEQUALITY_AND_EQUALITY();
    bool CQPTest_solve_FEASIBLE_RANDOM_INEQUALITIES();
    bool CQPTest_solve_INFINITE_DOMAIN_WITH_REDUNDANT_INEQUALITIES();
    // Additional test cases...
    
    // Helper methods
    Real64 compute_norm(const R64matrix& H);
    void suffle(int* v, int sz);
    void chol_solve_matrix(Tcholesky<Real64>& chol, const R64matrix& a, R64matrix& x);
    bool check_slack_variables(const R64vector& x,
                              const Base::Array<Cqp::Constraint>& active_set,
                              const R64matrix& A_eq,
                              const R64vector& b_eq,
                              const R64matrix& A_ineq,
                              const R64vector& b_ineq,
                              const R64vector& lb,
                              const R64vector& ub, 
                              Uint32 m = M);
};
```

The tests verify:
1. Correct solution for unconstrained problems
2. Handling of invalid bounds
3. Proper application of upper and lower bounds
4. Correct handling of equality constraints
5. Proper management of inequality constraints
6. Detection of infeasible problems
7. Handling of redundant constraints

## 5. Controller Manager Functionality

### 5.1 Controller Manager Implementation

The Controller Manager (`Cm`) coordinates controller modes and commands:

```cpp
class Cm {
public:
    Cm(const Common_controller_params& common_param,
       const Vsdk_common_params& vsdk_common_param,
       const Param& vsdk_param,
       const Param& param);
       
    bool step(const Input& input, Output& output);
    Modes_and_commands set_default_modes_and_commands();
    const State& get_state() const;
    
private:
    struct State {
        Takeoff_manager takeoff_manager;
        Land_manager land_manager;
        // Additional state components...
    };
    
    State state_;
    // Additional members...
};
```

The Controller Manager:
1. Determines controller modes based on rotor health status
2. Manages takeoff and landing operations
3. Controls integrator modes
4. Handles position and velocity commands

### 5.2 Controller Manager Testing

The `Cm_pa_test` class tests the Controller Manager functionality:

```cpp
class Cm_pa_test {
public:
    bool step();
    
private:
    bool Test_1(); // SetDefaultModesAndCommands
    bool Test_2(); // DetermineModesAndCommands_SetControllerMode
    bool Test_3(); // DetermineModesAndCommands_Takeoff
    bool Test_4(); // DetermineModesAndCommands_Landing
    
    // Test data structures
    struct Constr_data {
        Constr_data();
        Common_controller_params common;
        Vsdk_common_params vdsk_common_param;
        Cm::Param vsdk_param;
        Cm::Param param;
    };
    
    struct Input_data {
        Input_data();
        Commands_processor::State commands_processor;
        State_machines_state state_machine;
        Rotors_health_status_msg rotors_health_status;
        Controllers_state_estimate state_estimate;
        Sep::Output sep_output;
        Waypoint wp_previous_ned_ned2pos;
        Drone_mission_phase_notification drone_mission_phase_notification;
        Phase_of_flight tracked_phase_of_flight;
        Cm::Input input;
    };
    
    struct Output_data {
        Cm::Output output;
    };
    
    Constr_data ctr;
    Input_data in;
    Output_data out;
};
```

The tests verify:
1. Default modes and commands setting
2. Controller mode determination based on rotor health
3. Takeoff command handling
4. Landing command handling

## 6. Switch Blending for Smooth Transitions

### 6.1 Switch Blender Implementation

The `Switch_blender` class provides smooth transitions between different control signals:

```cpp
class Switch_blender {
public:
    struct Blending_mode {
        enum Type {
            ONE_SIDED,
            TWO_SIDED
        };
    };
    
    struct Interpolation_mode {
        enum Type {
            LINEAR,
            SMOOTH
        };
    };
    
    struct Limiting_mode {
        enum Type {
            TIME_LIMITED,
            RATE_LIMITED
        };
    };
    
    struct Angle_wrapping_mode {
        enum Type {
            DISABLED,
            ENABLED
        };
    };
    
    struct Params {
        Real max_time_limit_s;
        Real blending_rate_limit;
        Interpolation_mode::Type interpolation_mode;
        Limiting_mode::Type limiting_mode;
        Blending_mode::Type blending_mode;
        Angle_wrapping_mode::Type angle_wrapping_mode;
        Real time_step_s;
    };
    
    Switch_blender(const Params& params, const Uint16 num_signals, Base::Allocator& alloc);
    Real run(const Maverick::Rvector& input_signals, const Uint16 selected_signal_index);
    
    struct State_ {
        Uint16 blending_to_signal_index;
        Uint16 blending_from_signal_index;
        Real linear_blending_remaining;
        Real signal_difference_to_minus_from;
    };
    
    State_ state_;
};
```

The Switch Blender supports:
1. One-sided and two-sided blending modes
2. Linear and smooth interpolation
3. Time-limited and rate-limited transitions
4. Optional angle wrapping for angular signals

### 6.2 Switch Blender Testing

The `SwitchBlender_pa_test` class tests the Switch Blender functionality:

```cpp
class SwitchBlender_pa_test {
public:
    bool step();
    
private:
    bool step_core(const std::string base_directory);
    bool run_case(const uint32_t dk, const Real dt, const std::string filename);
    void set_default_state();
    void update_params(Switch_blender::Blending_mode::Type blending_mode,
                      bool angle_wrapping_mode,
                      Switch_blender::Interpolation_mode::Type interpolation_mode,
                      Real blending_rate_limit,
                      Real time_step_s,
                      Switch_blender::Limiting_mode::Type limiting_mode,
                      Real max_time_limit_s);
    bool check_inputs();
    bool check_states();
    bool check_outputs();
    void read_expected(std::ifstream & ifs);
    
    // Test data structures and constants
    enum class TestSignalIndex { RED = 0, GREEN = 1, BLUE = 2 };
    static const Real crit;
    static const Switch_blender::Blending_mode::Type blending_modes[2];
    static const Switch_blender::Interpolation_mode::Type interpolation_modes[2];
    static const Switch_blender::Limiting_mode::Type limiting_modes[2];
    static const Switch_blender::Angle_wrapping_mode::Type angle_wrapping_modes[2];
    static Real sign;
    
    // Additional test components...
};
```

The tests verify:
1. Correct blending between signals
2. Proper handling of different blending modes
3. Correct interpolation behavior
4. Appropriate limiting of transition rates
5. Proper angle wrapping when enabled

## 7. Controller Object Embedded Testing

### 7.1 Controllers Object Tester

The `ControllersObjectTester_emb` class provides embedded testing for the Controllers Object:

```cpp
class ControllersObjectTester_emb : public Controllers_object {
public:
    ControllersObjectTester_emb(const Pa_blocks::Vsdk_controllers_params& param);
    
    bool run(const Pa_blocks::Controllers_object::Input& input, Pa_blocks::Controllers_object::Output& output);
    const Pa_blocks::Controllers_state& GetState() const;
    void SetState(Pa_blocks::Controllers_state& state);
    bool IsPbitParameterConfigurationSelfConsistent();
    
    // Force and moment handling methods
    void ApplyGainToForceAndMoment(const Maverick::Irvector3& pafd_body,
                                 const Maverick::Irquat& q_trim_from_vtol,
                                 Maverick::Irvector3& force_command_body_N,
                                 Maverick::Irvector3& torque_command_body_N_m) const;
    void RemoveForceMomentGain(const Maverick::Irquat& q_trim_from_vtol,
                             Maverick::Irvector3& force_command_body_N,
                             Maverick::Irvector3& torque_command_body_N_m) const;
                             
    // Additional testing methods
    void SetActuatorHealthStatus(const Input& input);
    Rotor_failure_case::Type GetRotorFailureCaseFromHealthStatus(const Rotors_health_status_msg& health_status);
    Real GetFxGain() const;
    Real GetFyGain() const;
    Real GetFzGain() const;
    Real GetLGain() const;
    Real GetMGain() const;
    Real GetNGain() const;
    bool is_state_reset_allowed_test();
    bool is_specification_valid_();
};
```

### 7.2 Embedded Tests

The `ControllersObject_test_emb` class implements embedded tests for the Controllers Object:

```cpp
class ControllersObject_test_emb {
public:
    bool step();
    
private:
    bool Test_1(); // ControllersObjectConstructionDefaultParameters
    bool Test_2(); // ControllersObjectConstructionDefinedParameters
    bool Test_3(); // GainInjection
    bool Test_4(); // ControllersObjectFrequencyParamValidity
    bool Test_5(); // ControllersObjectSlewRateTrimAngle
    bool Test_6(); // SafetyPinLogic
    bool Test_7(); // CommandSeqId
    bool Test_8(); // RunOnlyWithNavInitialized
    bool Test_9(); // VerifyAllowedStateResetRecovery
};
```

The embedded tests verify:
1. Controller object construction with default and defined parameters
2. Force and moment gain injection and removal
3. Parameter validity checking
4. Slew rate limiting for trim angles
5. Safety pin logic for motor disarming
6. Command sequence ID handling
7. Navigation initialization requirements
8. State reset recovery functionality

## 8. Key Interfaces and Error Handling

### 8.1 Controller Object Interface

The Controllers Object provides a standardized interface for controller operations:

```cpp
class Controllers_object {
public:
    struct Input {
        Base::Array<Base::Msg<Controllers_state_estimate>> state_estimate;
        Base::Array<Base::Msg<Mixer_return>> mixer_return;
        Base::Array<Base::Msg<Mixer_allocation_data>> mixer_allocation_data;
        Base::Array<Base::Msg<Paal_health_summary>> paal_health_summary;
        // Additional input messages...
    };
    
    struct Output {
        Base::Array<Base::Msg<Forces_and_torques_request>> forces_and_torques_request;
        Base::Array<Base::Msg<Controllers_status>> controllers_status;
        Base::Array<Base::Msg<Mixer_reset_command>> mixer_reset_command;
        // Additional output messages...
    };
    
    bool step(const Input& input, Output& output);
    bool is_specification_valid();
    const Controllers_state& get_state() const;
};
```

### 8.2 Error Handling Mechanisms

The controller system implements several error handling mechanisms:

1. **Parameter Validation**:
   ```cpp
   bool Controllers_object::is_specification_valid() {
       // Check controller frequency
       if (param_.common.controller_frequency_hz <= 0.0F) {
           return false;
       }
       // Additional parameter checks...
       return true;
   }
   ```

2. **Power-On Built-In Test (PBIT)**:
   ```cpp
   bool ControllersObjectTester_emb::IsPbitParameterConfigurationSelfConsistent() {
       return power_on_built_in_test_.is_parameter_configuration_self_consistent();
   }
   ```

3. **State Machine Status Checking**:
   ```cpp
   // Check that we are in GROUND_IDLE
   ret &= (Pa_blocks::State_machines_state::Mode::Controllers_mode::GROUND_IDLE == out.controllers_status.back().message.state_machines_state.mode.controllers_mode);
   
   // Degradation should always be nominal
   ret &= (Pa_blocks::State_machines_state::Degradation_level::NOMINAL == out.controllers_status.back().message.state_machines_state.degradation_level);
   ```

4. **Navigation Initialization Checking**:
   ```cpp
   // NAV not initialized
   Controllers_state_estimate state_estimate;
   state_estimate.is_initialized_roll_pitch = false;
   state_estimate.is_initialized_roll_pitch_heading = false;
   controllers_input.state_estimate.emplace_back();
   controllers_input.state_estimate.back().message = state_estimate;
   
   // Check that controller preserves previous commands when NAV not initialized
   ret &= (controller_state.last_forces_and_torques_request.fx_N == forces_and_torques_request.message.fx_N);
   ```

5. **Rotor Health Monitoring**:
   ```cpp
   // MEP out R1
   in.rotors_health_status.rotor_rear_right_inoperative = true;
   in.rotors_health_status.rotor_center_right_inoperative = false;
   // Additional rotor status settings...
   ret &= cm.step(in.input, out.output);
   ret &= (out.output.modes_and_commands.controller_mode == Controller_mode::DEGRADED_R1R6);
   ```

## 9. System Integration

### 9.1 Controller Interaction with Mixer

The controller interacts with the mixer component to generate motor commands:

```cpp
// Set the mixer return
Pa_blocks::Controllers_object::Mixer_return mixer_return;
controllers_input.mixer_return.emplace_back();
controllers_input.mixer_return.back().message = mixer_return;

// Set the mixer allocation data
Pa_blocks::Mixer_allocation_data mixer_allocation_data;
controllers_input.mixer_allocation_data.emplace_back();
controllers_input.mixer_allocation_data.back().message = mixer_allocation_data;

// Controller generates forces and torques requests for the mixer
const Pa_blocks::Forces_and_torques_request& forces_and_torques_request = 
    controllers_output.forces_and_torques_request.back().message;
```

The mixer telemetry is also captured:

```cpp
bool Recovery_controller_telemetry_msg_test::check_Mixer_telemetry(Mixer_telemetry& obj) {
    bool ret = true;
    bool exp_is_saturated = false;
    
    ret &= check_Mixer_return_telemetry(obj.mixer_return);
    ret &= compare_attribute(obj.is_saturated, exp_is_saturated);
    
    return ret;
}
```

### 9.2 Controller Interaction with State Estimation

The controller relies on state estimation for position, velocity, and attitude information:

```cpp
// Set the state estimate
Pa_blocks::Controllers_state_estimate state_estimate;
state_estimate.is_initialized_roll_pitch = true;
state_estimate.is_initialized_roll_pitch_heading = true;
state_estimate.is_onground = false;
state_estimate.latitude_rad = latitude_rad;
state_estimate.longitude_rad = longitude_rad;
state_estimate.altitude_hae_wgs84_m = altitude_hae_wgs84_m + take_off_agl;
state_estimate.altitude_agl_m = take_off_agl;
state_estimate.v_ned_ned2vf_m_per_s[0] = 0;
state_estimate.v_ned_ned2vf_m_per_s[1] = 0;
state_estimate.v_ned_ned2vf_m_per_s[2] = 0;

controllers_input.state_estimate.emplace_back();
controllers_input.state_estimate.back().message = state_estimate;
```

### 9.3 Controller Interaction with Command Processor

The controller processes various commands:

```cpp
// Take off command
Pa_blocks::Commands_processor::Takeoff_command take_off_command;
take_off_command.controller_cmd_seq_id = 1;
take_off_command.initial_tracking_point.ll.lat = latitude_rad;
take_off_command.initial_tracking_point.ll.lon = longitude_rad;
take_off_command.initial_tracking_point.h = altitude_hae_wgs84_m + take_off_agl;
take_off_command.takeoff_agl_m = take_off_agl;
in.takeoff_command.emplace_back();
in.takeoff_command.back().message = take_off_command;

// Land command
Pa_blocks::Commands_processor::Land_command land_command;
land_command.controller_cmd_seq_id = 30;
land_command.latitude_rad = land_latitude_rad;
land_command.longitude_rad = land_longitude_rad;
land_command.use_backyard_frame = false;
land_command.land_type = Pa_blocks::Land_command_params::Land_type::POSITION_COMMANDED;
in.land_command.emplace_back();
in.land_command.back().message = land_command;

// Route command
Pa_blocks::Commands_processor::Route_command_and_control route_command_and_control;
route_command_and_control.controller_cmd_seq_id = 10;
route_command_and_control.route.lla_ned_origin.ll.lat = state_estimate.latitude_rad;
route_command_and_control.route.lla_ned_origin.ll.lon = state_estimate.longitude_rad;
route_command_and_control.route.maneuvers.resize(0);
route_command_and_control.route.maneuvers.append(hm);
route_command_and_control.route.id = 1;
route_command_and_control.route.status = Pa_blocks::Route_msg::Status::status_generated;
in.route_command_and_control.emplace_back();
in.route_command_and_control.back().message = route_command_and_control;
```

## Referenced Context Files

The following context files provided valuable insights for understanding the controller system:

1. **Controller_object_wrapper_test.cpp** - Demonstrated the controller object wrapper interface and testing approach
2. **Controller_Status_test.cpp** - Showed how controller status reporting is tested
3. **ControllersObject_emb_test.cpp** - Provided embedded testing for the controller object
4. **Recovery_controller_telemetry_msg_test.cpp** - Illustrated the telemetry system structure and validation
5. **Recovery_wrapper_control_system_object_test.cpp** - Showed recovery wrapper functionality and motor state management
6. **Cqp_pa_test.cpp** - Demonstrated the constrained quadratic programming implementation and testing
7. **Cm_pa_test.cpp** - Illustrated controller manager functionality and testing
8. **SwitchBlender_pa_test.cpp** - Showed the switch blending mechanism for smooth transitions