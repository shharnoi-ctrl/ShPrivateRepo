# Generated from:

- src/AdnVehicleRecoveryWrapperAlgorithms/algorithm/RecoveryGnssProcessor/src/RecoveryGnssProcessorObject.hpp (172 tokens)
- src/AdnVehicleRecoveryWrapperAlgorithms/algorithm/RecoveryGnssProcessor/src/RecoveryGnssProcessorObject.cc (1421 tokens)

---

# RecoveryGnssProcessor Component Analysis

## 1. Functional Behavior and Logic

The RecoveryGnssProcessorObject is a component responsible for processing GNSS (Global Navigation Satellite System) data for vehicle recovery systems. It serves as a wrapper around a PVT (Position, Velocity, Time) model that processes two types of GNSS data:

1. Navigation messages (`gnss_nav_msg`)
2. Raw GNSS measurements (`raw_meas_gnss`)

### Key Responsibilities

- Initialize the PVT model
- Process navigation messages from satellites
- Process raw GNSS measurements
- Generate position and velocity solutions
- Provide logging data for debugging and analysis

### Processing Flow

The component follows this general workflow:

1. Initialize the PVT model during construction
2. When `run()` is called:
   - Check if there's any input data (navigation messages or raw measurements)
   - Process each navigation message individually
   - Process each raw measurement
   - Generate position/velocity solutions when possible
   - Populate output structures with results and logging data

## 2. Control Flow and State Transitions

The RecoveryGnssProcessorObject implements a sequential processing model:

| Input Type | Processing Step | Output Generation | Location |
|------------|----------------|-------------------|----------|
| Navigation Messages | Process each message individually through PVT model | Log PVT output after each message | run() method |
| Raw Measurements | Process each measurement through PVT model | Log PVT output after all measurements | run() method |
| Final State | Extract position/velocity solution | Generate PVT solution if successful | run() method |

The component maintains state implicitly through the PVT model it wraps, but doesn't explicitly manage its own state (the `setState()` and `getState()` methods are empty).

## 3. Inputs and Stimuli

### Navigation Messages
- Received as: `input.gnss_nav_msg` (vector of message envelopes)
- Each message contains:
  - Satellite ID (svid)
  - Navigation data words (dwrd)
- Processing trigger: `PVT_model_U.process_nav_msg = true`
- Location: Processed in the first loop in `run()`

### Raw GNSS Measurements
- Received as: `input.raw_meas_gnss` (vector of message envelopes)
- Each measurement contains:
  - Multiple satellite measurements (meas_per_sv)
  - Receiver time of week (receiver_tow_s)
  - Week number (week)
- Processing trigger: `PVT_model_U.process_raw_msg = true`
- Location: Processed in the second loop in `run()`

## 4. Outputs and Effects

### PVT Solution
- Generated when: `PVT_model_Y.is_success` is true
- Contains:
  - Position (latitude, longitude, altitude) in `lla_rrm`
  - Velocity (north, east, down) in `v_ned_ned2ant_m_per_s`
  - Accuracy metrics (vertical, horizontal, speed)
  - Fix type (3 for position+velocity fix, 1 otherwise)
  - Timing information (week, time of week)
- Output location: `output.pvt_solution`

### Logging Data
- PVT Input Logs:
  - For navigation messages: Includes satellite ID and raw navigation message data
  - For raw measurements: Includes the complete raw GNSS measurement data
- PVT Output Logs:
  - Position and velocity data
  - Success flags
  - Satellite usage information (which satellites were used for position/velocity)
- Output location: `output.pvt_log_data`

## 5. Parameters and Configuration

The component is initialized with:
- `param`: Configuration parameters (not detailed in the provided code)
- `platform`: Platform abstraction layer for hardware interaction

The PVT model is initialized during construction with `PVT_model_initialize()`.

## 6. Error Handling and Contingency Logic

- **Empty Input Handling**: If both input vectors are empty, the function returns immediately with `vsdk::Status::Success`
- **Solution Validity Check**: Before populating the PVT solution output, the code checks `ssp_out.is_success` to ensure a valid solution was obtained
- **Fix Type Determination**: Sets the fix type to 3 if position and velocity are fixed (`pos_vel_fix` is true), otherwise sets it to 1

## 7. File-by-File Breakdown

### RecoveryGnssProcessorObject.hpp
- Defines the `RecoveryGnssProcessorObject` class that inherits from `RecoveryGnssProcessorObjectInterface`
- Declares the public interface:
  - Constructor taking parameters and platform abstraction
  - Empty state management methods
  - `run()` method for processing inputs and generating outputs
  - Helper method `PopulatePvtOutputLogData()` for logging

### RecoveryGnssProcessorObject.cc
- Implements the `RecoveryGnssProcessorObject` class
- Includes the PVT model header (`PVT_model.h`)
- Defines helper function `CopyVsdkInputToRawInput()` to convert VSDK raw measurements to PVT model input format
- Implements the main processing logic in `run()`
- Implements `PopulatePvtOutputLogData()` to extract PVT model output data for logging

## 8. Cross-Component Relationships

### External Dependencies
- **PVT_model**: The core navigation algorithm that processes GNSS data and generates position/velocity solutions
  - Accessed through global variables: `PVT_model_U` (input), `PVT_model_Y` (output)
  - Functions: `PVT_model_initialize()`, `PVT_model_step()`

### Data Flow
1. Input data flows from `Input` struct to PVT model inputs
2. PVT model processes the data internally
3. Results flow from PVT model outputs to `Output` struct

### Interface Implementation
- Inherits from `RecoveryGnssProcessorObjectInterface`
- Implements the required interface methods:
  - `setState()` (empty implementation)
  - `getState()` (empty implementation)
  - `run()` (main processing logic)

## 9. Detailed Processing Logic

### Navigation Message Processing
For each navigation message:
1. Extract satellite ID (svid)
2. Create a log entry for the input
3. Set up the PVT model input:
   - Set the satellite ID
   - Copy the navigation data words
   - Set `process_nav_msg = true` and `process_raw_msg = false`
4. Run the PVT model with `PVT_model_step()`
5. Create a log entry for the output
6. Populate the log with PVT output data

### Raw Measurement Processing
For each raw measurement:
1. Create a log entry for the input
2. Set up the PVT model input:
   - Copy all raw measurement data using `CopyVsdkInputToRawInput()`
   - Set `process_nav_msg = false` and `process_raw_msg = true`
3. Run the PVT model with `PVT_model_step()`
4. Store the raw measurement in the log

### Position/Velocity Solution Generation
After processing all inputs:
1. Log the final PVT output
2. Check if a valid solution was obtained (`is_success`)
3. If valid:
   - Create a new PVT solution output
   - Copy position (latitude, longitude, altitude)
   - Copy velocity (north, east, down)
   - Copy accuracy metrics
   - Set the fix type based on `pos_vel_fix`
   - Set timing information (week, time of week)
   - Set the solution timestamp

## 10. Data Transformation Details

### Raw Measurement Conversion
The `CopyVsdkInputToRawInput()` function performs a detailed field-by-field copy from the VSDK raw measurement format to the PVT model input format:
- Satellite-specific measurements:
  - Signal strength (cn0_dbhz)
  - Carrier phase measurements (cp_meas_cycle, cp_stdev_cycle)
  - Doppler measurements (do_meas_hz, do_stdev_hz)
  - GNSS ID and satellite ID (gnssid, svid)
  - Validity flags (is_cp_valid, is_do_valid, is_pr_valid)
  - Lock time (locktime_ms)
  - Pseudorange measurements (pr_meas_m, pr_stdev_m)
  - Signal ID (sigid)
- Overall measurement data:
  - Number of measurements (num_meas)
  - Receiver time of week (receiver_tow_s)
  - Week number (week_raw)

### Output Log Population
The `PopulatePvtOutputLogData()` function copies data from the PVT model output to the log structure:
- Success flags (is_success, pos_vel_fix)
- Position data (lla_receiver_rrm)
- Velocity data (v_n_e2receiver_mps)
- Satellite usage information (is_used_sv_pos, is_used_sv_vel)

## 11. Timing and Synchronization

- The component uses the trigger timestamp from the input (`input.vsdk_trigger_timestamp_monotonic_ns()`) to timestamp the output solution
- The component processes navigation messages and raw measurements sequentially, not in parallel
- Each processing step is synchronous, with the PVT model being stepped for each input

## 12. Performance Considerations

- The component processes each navigation message individually, which could be inefficient if there are many messages
- The raw measurement processing is more efficient, with a single PVT model step after all measurements are copied
- No explicit performance optimizations are visible in the code

## Summary

The RecoveryGnssProcessorObject is a wrapper component that interfaces with a PVT model to process GNSS data for vehicle recovery systems. It handles two types of GNSS data (navigation messages and raw measurements), processes them through the PVT model, and generates position/velocity solutions when possible. The component also provides extensive logging capabilities for debugging and analysis.

The processing flow is sequential and synchronous, with navigation messages processed individually and raw measurements processed as a batch. The component relies heavily on the underlying PVT model for the actual navigation calculations, serving primarily as an adapter between the VSDK data structures and the PVT model interface.