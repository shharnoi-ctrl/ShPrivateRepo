# Generated from:

- code/sw_vbootloader_astro/code/source_astro/bootloader_2838x_astro.cmd (1282 tokens)
- code/sw_vbootloader_astro/code/source_astro/cmd/app_hdr_c1.cmd (90 tokens)
- code/sw_vbootloader_astro/code/source_astro/source/smart.hcmd (150 tokens)
- code/sw_vbootloader_astro_cm/code/source/2838x_flash_astro_cm_lwip.cmd (778 tokens)
- code/sw_vbootloader_astro_cm/code/source/cmd/app_hdr_cm.cmd (90 tokens)
- code/sw_vbootloader_astro_cm/code/source/smart.hcmd (128 tokens)

## With context from:

- PackageSummaries/Amazon-PrimeAir/items/ASTRO/items/sw/sw_vbootloader_astro/04_Bootloader_Core_Architecture.md (2297 tokens)

---

# Memory Layout and Linker Configuration Analysis for Astro Bootloader System

## 1. Memory Architecture Overview

The Astro bootloader system operates on a multi-core platform with two distinct processor architectures:
- **C1 (DSP)**: Texas Instruments C2000 DSP core using 16-bit addressing
- **CM (ARM)**: ARM Cortex-M core using 8-bit addressing

This dual-architecture system requires specialized memory configurations for each core, with careful coordination of shared memory regions for inter-processor communication.

## 2. C1 (DSP) Memory Configuration

### 2.1 Memory Map

The C1 core uses a memory map divided into two pages:
- **PAGE 0**: Program Memory (code execution)
- **PAGE 1**: Data Memory (variables and data storage)

```
Memory Map (C1 DSP):
- FLASH: Starts at 0x80000, total size 0x40000 words
- BOOTLOADER: 0x80000 - 0x8FFFF (0x10000 words)
- APPLICATION: 0x90000 - 0xBFFFF (0x30000 words)
- RAM: Multiple regions including RAMM, RAML, RAMS
- RAMFUNCS: Special RAM region for functions executed from RAM
```

### 2.2 RAM Organization

The C1 core's RAM is organized into several distinct regions:
- **BOOT_RSVD**: 0x000000 - 0x00013F (0x140 bytes), reserved for boot ROM
- **RAMM_DAT**: 0x000140 - 0x0007FF (MM_SIZE bytes), on-chip RAM block M0-M1
- **RAML**: 0x008000 - 0x00CFFF (0x5000 bytes), Local RAM
- **RAMS**: 0x00D000 - 0x01783F (0x10000 - RAMFUNCS_SZ bytes), Shared RAM
- **RAMFUNCS**: 0x017840 - 0x01DFFF (0x57C0 bytes), RAM for functions loaded from flash

### 2.3 Inter-Processor Communication Regions

Two dedicated memory regions facilitate communication between C1 and CM cores:
- **CPUTOCMRAM**: 0x039000 - 0x0397FF (0x800 bytes), C1 to CM communication
- **CMTOCPURAM**: 0x038000 - 0x0387FF (0x800 bytes), CM to C1 communication

## 3. CM (ARM) Memory Configuration

### 3.1 Memory Map

The CM core uses a different memory architecture with its own flash and RAM regions:

```
Memory Map (CM ARM):
- FLASH: Starts at 0x200000, total size 0x80000 bytes
- BOOTLOADER: 0x200000 - 0x21FFFF (0x20000 bytes)
- APPLICATION: 0x220000 - 0x27FFFF (0x60000 bytes)
- RAM: Multiple regions including C0RAM, C1RAM, ESRAM
```

### 3.2 RAM Organization

The CM core's RAM is organized into several regions:
- **C1RAM**: 0x1FFFC000 - 0x1FFFDFFF (0x2000 bytes)
- **C0RAM**: 0x1FFFE000 - 0x1FFFFFFF (0x2000 bytes)
- **BOOT_RSVD**: 0x20000000 - 0x200000FF (0x100 bytes), reserved for boot ROM stack
- **ESRAM**: 0x20000100 - 0x20013FFF (0x13F00 bytes), main RAM region

### 3.3 Inter-Processor Communication Regions

Multiple message RAM regions facilitate communication between cores:
- **CPU1TOCMMSGRAM**: 0x20080000 - 0x20080FFF (0x1000 bytes), C1 to CM
- **CMTOCPU1MSGRAM**: 0x20082000 - 0x20082FFF (0x1000 bytes), CM to C1
- **CPU2TOCMMSGRAM0**: 0x20084000 - 0x200847FF (0x800 bytes), C2 to CM (region 0)
- **CPU2TOCMMSGRAM1**: 0x20084800 - 0x20084FFF (0x800 bytes), C2 to CM (region 1)
- **CMTOCPU2MSGRAM0**: 0x20086000 - 0x200867FF (0x800 bytes), CM to C2 (region 0)
- **CMTOCPU2MSGRAM1**: 0x20086800 - 0x20086FFF (0x800 bytes), CM to C2 (region 1)

## 4. Addressing Scheme Differences

A critical difference between the two cores is their addressing scheme:

- **C1 (DSP)**: Uses 16-bit word addressing with `SIZE_FACTOR = 2`
  - Memory addresses in linker files refer to 16-bit words
  - When converting to byte addresses (for binary images), addresses are multiplied by 2

- **CM (ARM)**: Uses 8-bit byte addressing with `SIZE_FACTOR = 1`
  - Memory addresses in linker files already refer to bytes
  - No conversion needed when creating binary images

This difference is explicitly defined in the respective header files:
```
// C1 (DSP)
#define SIZE_FACTOR     2           // Size factor to apply to byte counts

// CM (ARM)
#define SIZE_FACTOR     1           // Size factor to apply to byte counts
```

## 5. Application Headers

### 5.1 C1 (DSP) Application Header

The C1 application header (`app_hdr_c1.cmd`) defines:
- Flash starting address: 0x80000
- Total flash size: 0x40000 words
- Bootloader region: 0x80000 - 0x8FFFF (0x10000 words)

### 5.2 CM (ARM) Application Header

The CM application header (`app_hdr_cm.cmd`) defines:
- Flash starting address: 0x200000
- Total flash size: 0x80000 bytes
- Bootloader region: 0x200000 - 0x21FFFF (0x20000 bytes)

### 5.3 ECDSA Bootloader Header

Both cores include a bootloader header with ECDSA signature verification (`bldr_hdr_ecdsa.cmd`), though its contents are not provided in the files.

## 6. Section Allocation

### 6.1 C1 (DSP) Section Allocation

The C1 core allocates memory sections as follows:

- **Program Memory (PAGE 0)**:
  - RAMFUNCS: Functions executed from RAM
  - FPUTABLES: FPU Tables in Boot ROM
  - RESET: Reset vector

- **Data Memory (PAGE 1)**:
  - BOOT_RSVD: Reserved for boot ROM
  - RAMM_DAT: On-chip RAM for data
  - RAML: Local RAM for stack, sysmem, and data
  - RAMS: Shared RAM for BSS section
  - CPUTOCMRAM/CMTOCPURAM: Inter-processor communication

- **Special Sections**:
  - SHARED_RAM: Dedicated section for CPU1-CM shared data
  - .TI.ramfunc: Functions loaded from flash to RAM for execution
  - MEMMGR_INT/MEMMGR_EXT: Memory manager configuration

### 6.2 CM (ARM) Section Allocation

The CM core allocates memory sections as follows:

- **Flash Sections**:
  - .resetisr: Reset interrupt service routine
  - .vftable: Vector table in flash
  - .text: Code
  - .cinit: Initialized data tables
  - .pinit: Initialization tables
  - .switch: Switch statement tables
  - .init_array: Constructors
  - .econst: Constants

- **RAM Sections**:
  - .vtable: Vector table in RAM
  - .stack: Stack in C0RAM
  - .ebss: Uninitialized data in C1RAM
  - .esysmem: System memory in C1RAM
  - .data: Initialized data in ESRAM
  - .bss: Uninitialized data in ESRAM
  - .const: Constants loaded from flash to ESRAM

- **Special Sections**:
  - SHARED_RAM: Dedicated section for CM-CPU1 shared data
  - .TI.ramfunc: Functions loaded from flash to RAM for execution
  - MEMMGR_INT/MEMMGR_EXT: Memory manager configuration

## 7. RAM Functions Mechanism

Both cores implement a RAM functions mechanism that loads specific functions from flash to RAM for faster execution:

### 7.1 C1 (DSP) RAM Functions

The C1 core loads the following components into the RAMFUNCS region:
- Flash API library functions
- SHA-256 cryptographic functions
- Flash write and initialization functions
- IPC communication functions
- Watchdog setup functions
- System register access functions
- CRC32 table and functions
- Bootloader manager data and functions
- Mutex functions
- Warning and sector management functions
- ECDSA hash computation functions

These functions are:
1. Defined in the `.TI.ramfunc` section
2. Loaded from FLASH_PRG
3. Executed from RAMFUNCS
4. Transferred using the BINIT table

### 7.2 CM (ARM) RAM Functions

The CM core loads the following components into RAM:
- Flash API library functions
- Flash write functions and constants

These functions are:
1. Defined in the `.TI.ramfunc` section
2. Loaded from FLASH_PRG
3. Executed from ESRAM
4. Tracked using load/run start/size/end symbols

## 8. Binary Image Generation

The binary images for both cores are generated using the `smart.hcmd` files:

### 8.1 C1 (DSP) Binary Image

```
APPLICATION_BINARY:
org = 0x100000,  /* In bytes */
len =  0x20000,  /* In bytes */
romwidth = 16,   /* no influence because romwidth > 8 */
fill = 0xFFFF
```

The C1 binary image:
- Starts at byte address 0x100000 (corresponds to word address 0x80000)
- Has a length of 0x20000 bytes (0x10000 words)
- Uses 16-bit ROM width
- Fills unused space with 0xFFFF

### 8.2 CM (ARM) Binary Image

```
APPLICATION_BINARY:
org = 0x200000,  /* In bytes */
len =  0x20000,  /* In bytes */
romwidth = 8,    /* no influence because romwidth > 8 */
fill = 0xFFFFFFFF
```

The CM binary image:
- Starts at byte address 0x200000
- Has a length of 0x20000 bytes
- Uses 8-bit ROM width
- Fills unused space with 0xFFFFFFFF

## 9. Memory Manager Configuration

Both cores implement memory manager configuration through dedicated sections:

### 9.1 C1 (DSP) Memory Manager

```c
MEMMGR_INT : {Memmgr_int_cmd = .;} > RAMS, SIZE(Memmgr_int_sz), PAGE = 1, ALIGN(4)
MEMMGR_EXT : {Memmgr_ext_cmd = .;} > RAMS, SIZE(Memmgr_ext_sz), PAGE = 1, ALIGN(4)
```

The memory manager sections are placed in RAMS (shared RAM) with specific sizes defined by `Memmgr_int_sz` and `Memmgr_ext_sz`.

### 9.2 CM (ARM) Memory Manager

```c
MEMMGR_INT : {_Memmgr_int_cmd = .;} > ESRAM, SIZE(_Memmgr_int_sz)
MEMMGR_EXT : {_Memmgr_ext_cmd = .;} > ESRAM, SIZE(_Memmgr_ext_sz)
```

The memory manager sections are placed in ESRAM with specific sizes defined by `_Memmgr_int_sz` and `_Memmgr_ext_sz`.

## 10. Inter-Processor Communication Implementation

The inter-processor communication is implemented through dedicated shared memory regions:

### 10.1 C1 (DSP) Shared Memory

```c
SHARED_RAM :
{
    CPU1_CM_shared.obj (.bss:shared_cpu1_cm*)
} > CPUTOCMRAM
```

The C1 core places the `shared_cpu1_cm` BSS section from the `CPU1_CM_shared.obj` object file in the CPUTOCMRAM region.

### 10.2 CM (ARM) Shared Memory

```c
SHARED_RAM :
{
    CM_CPU1_shared.obj (.bss:shared_cm_cpu1*)
} > CMTOCPU1MSGRAM
```

The CM core places the `shared_cm_cpu1` BSS section from the `CM_CPU1_shared.obj` object file in the CMTOCPU1MSGRAM region.

This bidirectional shared memory setup enables the cores to exchange data and synchronize operations.

## 11. Key Differences Between C1 and CM Memory Architectures

1. **Addressing**: C1 uses 16-bit word addressing, CM uses 8-bit byte addressing
2. **Flash Location**: C1 flash starts at 0x80000, CM flash starts at 0x200000
3. **RAM Organization**: C1 uses RAMM/RAML/RAMS, CM uses C0RAM/C1RAM/ESRAM
4. **Section Allocation**: C1 uses PAGE 0/1 distinction, CM doesn't
5. **Binary Image**: C1 uses 16-bit ROM width, CM uses 8-bit ROM width
6. **Memory Size**: CM has larger flash (0x80000 bytes vs 0x40000 words)

## Referenced Context Files

- `PackageSummaries/Amazon-PrimeAir/items/ASTRO/items/sw/sw_vbootloader_astro/04_Bootloader_Core_Architecture.md` - Provided context about the overall bootloader architecture, core components, initialization sequence, and inter-core communication mechanisms.