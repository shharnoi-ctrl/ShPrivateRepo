# Generated from:

- Mixer_TestVector.cpp (2715 tokens)
- Mixer_allocator_test.cpp (12693 tokens)

---

# Comprehensive Summary of the Mixer System

## 1. Functional Behavior and Logic

The mixer system is responsible for converting control signals (wrench requests) into actuator commands. It plays a critical role in the flight control system by allocating the desired forces and moments to the available actuators.

### Mixer Allocator Core Functionality

The `Mixer_allocator` class is the central component that:
- Takes wrench requests (forces and moments) in the vehicle frame
- Converts these requests to actuator commands (rotor speeds in krpm²)
- Handles actuator constraints and failures
- Implements prioritization schemes for wrench components
- Applies hysteresis to prevent rapid actuator oscillations

The system operates with two main prioritization schemes:
1. **Hard Prioritization**: Enforces strict hierarchy of wrench components
2. **Soft Prioritization**: Uses weighted optimization to balance all components

### Allocation Process

The allocation process follows these steps:
1. Receive wrench requests in the vehicle frame
2. Transform requests to the allocation frame using quaternion rotation
3. Apply prioritization scheme (hard or soft)
4. Solve the constrained optimization problem
5. Apply hysteresis to prevent oscillations near constraints
6. Output actuator commands and predicted achievable wrench

## 2. Control Flow and State Transitions

### Mixer Allocation Workflow

The mixer allocation process is implemented in the `step()` method of the `Mixer_allocator` class:

```
Mixer_allocator::step(previous_actuator_cmd, fm_vtol_request_N_and_N_m, scheduled_data)
```

| Input | Description | Source |
|-------|-------------|--------|
| previous_actuator_cmd | Previous actuator commands | Output from previous step |
| fm_vtol_request_N_and_N_m | Requested forces and moments | Flight controller |
| scheduled_data | Allocation parameters | Pa_scheduler |

The allocation process involves several state transitions:

1. **Parameter Validation**: Checks if allocation parameters are valid
2. **Frame Transformation**: Rotates wrench requests to allocation frame
3. **Constraint Setup**: Sets up equality and inequality constraints
4. **Optimization**: Solves the quadratic programming problem
5. **Hysteresis Application**: Applies hysteresis to actuator commands
6. **Output Generation**: Produces actuator commands and predicted wrench

### Hysteresis Behavior

The mixer implements hysteresis to prevent actuator oscillations near constraints:

- When an actuator would be commanded to a value below a minimum threshold (but above zero), it is instead commanded to the hysteresis value
- This prevents rapid on/off cycling of actuators
- The hysteresis threshold is configurable via `scheduled_data.allocation_parameters.hysteresis_krpm`

As seen in the `HysteresisCheck()` test:
```cpp
// Check if hysteresis bound was reached
ret &= compare_data(allocation_results->actuators[0], scheduled_data.allocation_parameters.hysteresis_krpm, "actuators 0");
```

## 3. Inputs and Stimuli

### Primary Inputs

1. **Wrench Requests (`fm_vtol_request_N_and_N_m`)**: 
   - 6-component vector containing forces and moments [Fx, Fy, Fz, Mx, My, Mz]
   - Defined in the vehicle frame
   - Units: Newtons (N) for forces, Newton-meters (N·m) for moments
   - Location: Passed to `Mixer_allocator::step()`

2. **Previous Actuator Commands (`previous_actuator_cmd`)**:
   - Vector of previous actuator commands
   - Used for continuity and hysteresis
   - Units: krpm² (kilo-RPM squared)
   - Location: Passed to `Mixer_allocator::step()`

3. **Scheduler Outputs (`scheduled_data`)**:
   - Contains allocation parameters from the scheduler
   - Includes actuator constraints, prioritization scheme, and other parameters
   - Location: Passed to `Mixer_allocator::step()`

### Scheduler Parameters

The `Pa_scheduler::Outputs` structure contains critical allocation parameters:

1. **Actuator Jacobian (`dfm_dactuator_vtol_N_and_N_m_from_krpm2_and_rad`)**: 
   - Maps actuator commands to wrench effects
   - Used in the optimization problem

2. **Wrench Priorities (`wrench_priorities`)**: 
   - Defines prioritization scheme for wrench components
   - `-1` indicates soft prioritization
   - `0-5` indicates hard prioritization level (lower number = higher priority)

3. **Actuator Constraints**:
   - `upper_bound` and `lower_bound`: Actuator command limits
   - `actuator_failed`: Boolean array indicating failed actuators

4. **Hysteresis Parameter**:
   - `hysteresis_krpm`: Threshold for hysteresis behavior

5. **Air Density Parameters**:
   - `air_density_kg_per_m3`: Current air density
   - `reference_air_density_kg_per_m3`: Reference air density for scaling

## 4. Outputs and Effects

### Primary Outputs

The `Mixer_allocator` produces an `Allocation_results` structure containing:

1. **Actuator Commands (`actuators`)**:
   - Vector of actuator commands
   - Units: krpm² (kilo-RPM squared)
   - Used to control motor speeds
   - Accessible via `uut.get_out().actuators`

2. **Predicted Wrench (`fm_vtol_predict_N_and_N_m`)**:
   - 6-component vector of achievable forces and moments
   - May differ from requested wrench if constraints prevent exact achievement
   - Units: Newtons (N) for forces, Newton-meters (N·m) for moments
   - Accessible via `uut.get_out().fm_vtol_predict_N_and_N_m`

3. **Wrench Component Exactness (`wrench_component_exact`)**:
   - Boolean array indicating which wrench components were achieved exactly
   - Used to determine if prioritization was successful
   - Accessible via `uut.get_out().wrench_component_exact`

4. **Solve Status (`solve_status`)**:
   - Indicates success or failure of the optimization
   - Value from `Maverick::Cqp::Results` enum
   - Accessible via `uut.get_out().solve_status`

5. **Solve Parameters (`solve_parameters`)**:
   - Contains matrices and vectors used in the optimization
   - Used for sensitivity analysis and debugging
   - Includes `ET`, `C`, `a`, and `active_constraints`

### Effects on Vehicle Behavior

The mixer's outputs directly control the vehicle's actuators, which in turn:
- Generate thrust and torque
- Control vehicle attitude and position
- Respond to external disturbances
- Manage transitions between flight modes

## 5. Parameters and Configuration

### Key Configuration Parameters

1. **Wrench Prioritization Scheme**:
   - Hard prioritization: `wrench_priorities` set to integers 0-5
   - Soft prioritization: `wrench_priorities` set to -1
   - Location: `scheduled_data.allocation_parameters.wrench_priorities`

2. **Actuator Constraints**:
   - Upper bounds: `scheduled_data.allocation_parameters.upper_bound`
   - Lower bounds: `scheduled_data.allocation_parameters.lower_bound`
   - Target values: `scheduled_data.allocation_parameters.actuator_target`

3. **Hysteresis Parameter**:
   - Value: `scheduled_data.allocation_parameters.hysteresis_krpm`
   - Typical value: 0.5 krpm²
   - Used to prevent actuator oscillations

4. **Air Density Parameters**:
   - Current: `scheduled_data.allocation_parameters.air_density_kg_per_m3`
   - Reference: `scheduled_data.allocation_parameters.reference_air_density_kg_per_m3`
   - Used to scale actuator effectiveness with altitude

5. **Regularization Coefficient**:
   - Value: `scheduled_data.allocation_parameters.regularization_coefficient`
   - Typical value: 1e-3
   - Required when number of actuators > 6

### Unit Conversions

The system uses several unit conversions:

1. **krpm² to RPM**:
   ```cpp
   Real krpm2_2_rpm(const Real rotor_speeds_krpm2)
   {
       const Real sgn = (rotor_speeds_krpm2 >= 0) ? 1 : -1;
       return 1000.0F * sgn * Rmath::sqrtr(Rmath::fabsr(rotor_speeds_krpm2));
   }
   ```

2. **RPM to krpm²**:
   ```cpp
   Real rpm_2_krpm2(const Real rotor_speeds_rpm)
   {
       const Real sgn = (rotor_speeds_rpm >= 0) ? 1 : -1;
       return sgn * Rmath::powr((Rmath::fabsr(rotor_speeds_rpm) / 1000.0F), 2);
   }
   ```

## 6. Error Handling and Contingency Logic

### Actuator Failure Handling

The mixer can handle actuator failures through the `actuator_failed` parameter:
- Failed actuators are constrained to their target values
- The optimization redistributes commands to remaining actuators
- Wrench components may not be achievable if too many actuators fail

### Optimization Failure Handling

If the optimization fails to find a solution:
- The `solve_status` will indicate the failure reason
- The system will use the best available solution
- Tests verify that the solver succeeds under various conditions

### Constraint Handling

When actuator constraints prevent achieving the requested wrench:
- Hard prioritization: Higher priority components are satisfied first
- Soft prioritization: All components are balanced according to weights
- The `wrench_component_exact` array indicates which components were achieved exactly

## 7. File-by-File Breakdown

### Mixer_TestVector.cpp

This file implements test vectors for the mixer system:

- **Purpose**: Validates mixer behavior using pre-recorded input/output pairs
- **Key Classes**:
  - `Mixer_TestVector`: Main test class that runs test vectors
  - `Input_data`: Holds input data from CSV files
  - `Expected_data`: Holds expected output data from CSV files
- **Key Methods**:
  - `step()`: Runs a single test step
  - `TestVector()`: Runs a complete test vector
  - `compare_mixer_data()`: Compares actual outputs to expected outputs
- **Test Types**:
  - `vtol`: VTOL flight mode test
  - `hybrid`: Hybrid flight mode test

The file contains utility functions for:
- Loading data from CSV files
- Converting between RPM and krpm²
- Comparing vectors with tolerance

### Mixer_allocator_test.cpp

This file implements unit tests for the mixer allocator:

- **Purpose**: Tests specific behaviors of the mixer allocator
- **Key Tests**:
  - `HysteresisCheck()`: Tests hysteresis behavior
  - `SingleValidActuatorAllocationHardPrioritization()`: Tests hard prioritization
  - `SingleValidActuatorAllocationSoftPrioritization()`: Tests soft prioritization
- **Test Utilities**:
  - `compute_actuator_sensivity_to_wrench_request_finite_diff()`: Computes sensitivity using finite differences
  - `compute_actuator_sensivity_to_wrench_request()`: Computes sensitivity analytically
  - `fm_b2n()`: Transforms wrench from body to NED frame

The file contains detailed validation of:
- Optimization correctness
- Sensitivity analysis
- Constraint handling
- Hysteresis behavior

## 8. Cross-Component Relationships

### Mixer and Scheduler Interaction

The mixer depends on the scheduler for allocation parameters:
```
Pa_scheduler::Outputs scheduled_data;
Mixer_allocator uut(alloc_volatile);
uut.step(previous_actuator_cmd, fm_vtol_request_N_and_N_m, scheduled_data);
```

The scheduler determines:
- Which actuators are available
- What constraints apply
- Which prioritization scheme to use
- How to handle different flight regimes

### Mixer and Flight Controller Interaction

The flight controller provides wrench requests to the mixer:
```
Rvector fm_vtol_request_N_and_N_m(6, Base::Memmgr::external);
// Set wrench request values
uut.step(previous_actuator_cmd, fm_vtol_request_N_and_N_m, scheduled_data);
```

The mixer provides feedback to the flight controller:
- Achievable wrench (`fm_vtol_predict_N_and_N_m`)
- Which components were achieved exactly (`wrench_component_exact`)

### Memory Management

The system uses a custom memory management system:
```cpp
Base::Allocator& alloc_volatile(Base::Memmgr::get_instance().get_allocator(Base::Memmgr::external));
Mixer_allocator uut(alloc_volatile);
```

This allows for efficient memory allocation and deallocation in a real-time system.

## 9. Testing Approach

### Test Vector Methodology

The `Mixer_TestVector` class implements a test vector approach:
1. Load input and expected output data from CSV files
2. Run the mixer with the input data
3. Compare the actual output to the expected output
4. Save results to output CSV files

This allows for regression testing and validation against known-good data.

### Unit Testing

The `Mixer_allocator_test` class implements unit tests for specific behaviors:
1. Set up test conditions with specific parameters
2. Run the mixer with controlled inputs
3. Verify outputs against expected values
4. Test edge cases and failure modes

### Sensitivity Analysis

The tests include sensitivity analysis to verify the mixer's behavior:
```cpp
// Using the linear maps, compare the analytic sensitivity to a finite difference
Rmatrix d_actuator_d_fm_vtol_request_analytic(NumActuators, NumWrenchComponents, Base::Memmgr::external);
compute_actuator_sensivity_to_wrench_request(scheduled_data, *allocation_results, d_actuator_d_fm_vtol_request_analytic);

Rmatrix dactuator_dfm_vtol_requestFiniteDifference(Pa_scheduler::num_actuators, 6, Base::Memmgr::external);
const bool finite_difference_sensitivity_second =
    compute_actuator_sensivity_to_wrench_request_finite_diff(
        fm_vtol_request_N_and_N_m,
        scheduled_data,
        dactuator_dfm_vtol_requestFiniteDifference);
```

This verifies that the mixer's response to changes in wrench requests is correct and consistent.

## 10. Optimization Techniques

### Quadratic Programming

The mixer uses quadratic programming to solve the allocation problem:
- Objective function: Minimize deviation from requested wrench and target actuator values
- Constraints: Actuator limits and failed actuator constraints
- Solution: Optimal actuator commands that best achieve the requested wrench

### Hard Prioritization

Hard prioritization implements a hierarchical approach:
1. Solve for highest priority components first
2. Fix those solutions and solve for next priority level
3. Continue until all components are addressed or constraints prevent further optimization

This is implemented when `wrench_priorities` contains values 0-5.

### Soft Prioritization

Soft prioritization uses weights to balance all components:
- All components are optimized simultaneously
- Weights determine relative importance
- Solution minimizes weighted sum of errors

This is implemented when `wrench_priorities` contains all -1 values.

### Hysteresis Implementation

The hysteresis implementation prevents actuator oscillations:
```cpp
// Check if hysteresis bound was reached
ret &= compare_data(allocation_results->actuators[0], scheduled_data.allocation_parameters.hysteresis_krpm, "actuators 0");
```

When an actuator would be commanded to a value below the hysteresis threshold, it is instead commanded to exactly the threshold value.

## 11. Performance Considerations

### Computational Efficiency

The mixer must solve a constrained optimization problem in real-time:
- Uses efficient quadratic programming algorithms
- Leverages matrix operations for performance
- Implements sensitivity analysis for predictable behavior

### Memory Management

The system uses custom memory allocation:
```cpp
Base::Allocator& alloc_volatile(Base::Memmgr::get_instance().get_allocator(Base::Memmgr::external));
```

This allows for efficient memory usage in a real-time embedded system.

### Numerical Stability

The system includes several techniques for numerical stability:
- Regularization coefficient for over-actuated systems
- Tolerance parameters for comparisons
- Air density scaling for consistent behavior at different altitudes

## Referenced Context Files

The following context files were helpful in understanding the mixer system:

1. **Pa_scheduler_tables.h**: Provided definitions for scheduler outputs and allocation parameters
2. **Mixer_wrapper.h**: Helped understand the interface between the mixer and other components
3. **Mixer_allocator.h**: Contained the core class definitions and interfaces for the mixer allocator
4. **Cqp.h**: Provided definitions for the quadratic programming solver used by the mixer

These files contributed to understanding the overall architecture, interfaces, and dependencies of the mixer system.