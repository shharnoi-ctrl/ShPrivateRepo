# Generated from:

- Amazon-PrimeAir/items/ASTRO/items/Monitor/07_System_Architecture.md (3174 tokens)
- Amazon-PrimeAir/items/ASTRO/items/Monitor/06_Communication_Interfaces.md (7524 tokens)
- Amazon-PrimeAir/items/ASTRO/items/Monitor/05_Sensor_Processing.md (6777 tokens)
- Amazon-PrimeAir/items/ASTRO/items/Monitor/04_Navigation_Systems.md (6458 tokens)
- Amazon-PrimeAir/items/ASTRO/items/Monitor/02_Block_Libraries.md (3387 tokens)
- Amazon-PrimeAir/items/ASTRO/items/Monitor/02_Variable_Management.md (3559 tokens)
- Amazon-PrimeAir/items/ASTRO/items/Monitor/02_PPM_Systems.md (3791 tokens)
- Amazon-PrimeAir/items/ASTRO/items/Monitor/02_Lighting_Systems.md (3974 tokens)
- Amazon-PrimeAir/items/ASTRO/items/Monitor/03_Operation_Configuration.md (5629 tokens)
- Amazon-PrimeAir/items/ASTRO/items/Monitor/02_Arc_Trim_Operations.md (5002 tokens)
- Amazon-PrimeAir/items/ASTRO/items/Monitor/01_System_Integration.md (5376 tokens)

---

# Amazon Prime Air PDI Monitor System Overview

This document provides a comprehensive overview of the Amazon Prime Air PDI (Payload Delivery Interface) Monitor system, serving as the primary reference for understanding this software system.

## System Purpose and Overview

The PDI Monitor is a sophisticated monitoring and control system designed for Amazon Prime Air delivery drones. It serves as a critical safety and operational component that:

1. Monitors the drone's systems, sensors, and operational parameters
2. Processes navigation data and mission plans
3. Manages communication across multiple interfaces
4. Ensures safe operation through comprehensive monitoring and failsafe mechanisms
5. Controls the Payload Deployment System (PDS) for package delivery

The system operates in two distinct modes:
- **Mission Mode**: Full monitoring system is active with navigation monitoring, mission plan processing, and safety monitoring
- **Maintenance Mode**: Limited functionality with basic maintenance operations and configuration capabilities

## System Architecture

The PDI Monitor uses a modular, component-based architecture centered around a factory pattern:

### Core Components

- **Blockfactory**: Central architectural component that creates and manages functional blocks
- **Monitor_builder**: Constructs the monitoring system at runtime based on configuration
- **Input/Output Managers**: Handle data flow into and out of the monitoring system
- **Mission Plan Components**: Process and validate mission plans
- **PDS Manager**: Controls the Payload Deployment System for package delivery

### Execution Flow

The system operates in a cyclic execution pattern:

1. **Pre-GNC Step**:
   - Update drone mode system variable
   - Execute monitor step function
   - Process PDS door commands based on monitor state
   - Execute PDS manager in appropriate mode

2. **GNC Step**: Currently empty in implementation, suggesting primary work happens in pre-GNC phase

### Memory Management

The system uses structured memory management:
- Internal allocator for volatile memory (14,000 bytes)
- External allocator for persistent structures
- Careful resource allocation for monitoring blocks

## Communication Interfaces

The PDI Monitor implements a multi-layered communication architecture:

### Physical Interfaces

- **Serial Communication**: Four interfaces (SCIA, SCIB, SCIC, SCID) with different baudrates
- **CAN Bus**: Dual CAN buses (CANA, CANB) operating at 500 kbps with specific message filtering
- **GPIO and PWM**: Digital I/O and PWM outputs for direct control and sensing
- **Enhanced Capture Modules**: Six ECAP modules for timing-critical input capture

### Protocol Support

- **Cyphal Communication**: For file transfers, mission plans, maintenance actions
- **NMEA Protocol**: For GPS/GNSS data processing
- **UBX Protocol**: For u-blox GNSS receiver communication
- **PPM Protocol**: For control input processing

### Cross-Component Communication

- **Cross-Process Communication (XPCU8)**: Data exchange between processes
- **Cross-Process Capture (XPECAP)**: Sharing captured timing data
- **System Variables**: Centralized state sharing mechanism

## Sensor Processing System

The PDI Monitor incorporates comprehensive sensor processing:

### Sensor Types

- **IMUs**: Four IMUs with different configurations for motion sensing
- **Gyroscopes**: Multiple dedicated gyroscopes organized into a "gyroscope suite"
- **Accelerometers**: Multiple accelerometer channels organized into an "accelerometer suite"
- **Magnetometers**: At least 8 magnetometer configurations
- **External Sensors**: Additional accelerometers, gyroscopes, and magnetometers

### Processing Pipeline

1. **Raw Data Acquisition**: From various sensors
2. **Data Validation**: Using configurable thresholds
3. **Filtering**: Multi-stage noise reduction
4. **Linear Parameter Scaling**: Calibration and alignment
5. **Sensor Fusion**: Combining multiple sensor inputs
6. **Attitude Estimation**: Using complementary or similar filter

### Error Handling

- **Non-Valid Sample Management**: Configurable thresholds for sensor rejection
- **Maximum Delta Thresholds**: Limits on changes between consecutive samples
- **Adaptive Variance Estimation**: Automatic weighting based on sensor reliability

## Navigation Systems

The navigation system provides positioning, guidance, and control capabilities:

### GNSS Configuration

- **Dual-GNSS Architecture**: Primary (UBX0) and secondary (UBX1) receivers
- **Multi-Constellation Support**: GPS, GLONASS, Galileo, BeiDou, QZSS, and SBAS
- **Different Update Rates**: UBX0 at 4Hz, UBX1 at 2Hz

### Georeferencing

- **Automatic Georeferencing**: Enabled with 0.2 unit margin
- **Automatic Magnetic Field Calibration**: For heading determination

### Kalman Filtering

- **GPS Validation Time**: 5.0 seconds before data is trusted
- **Process Noise Parameters**: For optimal sensor fusion

### Route Tracking

- **Predefined Routes**: From mission planning
- **Arc Trim Parameters**: Four sets of parameters for optimizing curved flight paths
- **Position and Heading Tracking**: Relative to route waypoints

## Block Library System

The PDI Monitor uses a modular block library system:

- **32 Block Libraries**: Numbered from 00 to 31, each providing specific functionality
- **Consistent Structure**: Each library follows the same format and versioning
- **Factory Pattern**: Blocks are created and managed by the Blockfactory
- **Builder Integration**: Monitor_builder assembles blocks into functional systems

## Variable Management System

The system uses a comprehensive variable management approach:

### Variable Types

- **Unsigned Integer Variables (MUVAR)**: For discrete states and enumerated values
- **Real Variables (MRVAR)**: For continuous numerical values
- **Configuration Variables**: For system parameters

### Organization

- **ID-Based Structure**: Variables organized by ID ranges (1000-1999, 3100-3147, etc.)
- **Functional Categories**: Motor control, controller modes, RPM monitoring, performance timing
- **Relationships**: Hierarchical relationships between related variables

## PPM System

The Pulse Position Modulation system processes control signals:

- **Four Identical Modules**: PPM0, PPM1, PPM2, PPM3
- **Strict Timing Parameters**: For signal validation and processing
- **Adaptive Filtering**: Balances responsiveness with stability
- **Channel Configuration**: 16 channels per module, 12 active

## Lighting Systems

The PDI Monitor controls two lighting subsystems:

- **UA Lights**: Basic aircraft lighting with simple configuration
- **AMZ Lights**: Advanced system with complex patterns and sequences
  - Register-based control
  - 13 distinct light states for left and right sides
  - 11 sequences with 10 steps each

## Operational Configuration

The system uses XML configuration files for operational parameters:

- **Obstacle Management**: For defining obstacles to avoid
- **Polygon Management**: For geofencing and safety boundaries
- **Waypoint Navigation**: For route following
- **Position Initialization**: For setting initial position
- **ADS-B Parameters**: For transponder behavior
- **Telemetry Configuration**: For data transmission
- **Arc Trim Parameters**: For optimizing curved flight paths

## Safety and Redundancy Features

The PDI Monitor implements multiple safety mechanisms:

- **Sensor Redundancy**: Multiple IMUs, dual GNSS, multiple magnetometers
- **Geofencing**: Prevents operation outside safe areas
- **Signal Validation**: Rejects invalid sensor data and control signals
- **Monitoring Subsystems**: Continuously verify system performance
- **PDS Management**: Vetted commands for payload deployment

## System Integration

The PDI Monitor demonstrates sophisticated integration of specialized subsystems:

- **Hierarchical Component Structure**: Clear organization of components
- **Producer-Consumer Data Flow**: Well-defined data paths
- **Redundancy with Fusion**: Multiple components with intelligent fusion
- **Mode-Based Behavior**: Component behavior changes based on system mode
- **Configuration-Driven Assembly**: System structure determined by configuration files

## Summary

The Amazon Prime Air PDI Monitor system is a sophisticated monitoring and control system for autonomous delivery drones. It combines sensor processing, navigation, communication, and safety monitoring into a cohesive architecture that ensures reliable and safe operation. The system's modular design, redundant components, and comprehensive monitoring capabilities make it well-suited for safety-critical autonomous operations.

For more detailed information on specific subsystems, please refer to the individual documentation files in this knowledge base.