# Generated from:

- items/pdi_Monitor/setup/ver_spdif_ppm2.xml (1138 tokens)
- items/pdi_Monitor/setup/ver_spdif_ppm3.xml (1138 tokens)
- items/pdi_Monitor/setup/ver_spdif_ppm1.xml (1138 tokens)
- items/pdi_Monitor/setup/ver_spdif_ppm0.xml (1137 tokens)

## With context from:

- Amazon-PrimeAir/items/ASTRO/items/Monitor/07_System_Architecture.md (3174 tokens)
- Amazon-PrimeAir/items/ASTRO/items/Monitor/06_Communication_Interfaces.md (7524 tokens)

---

# PDI Monitor Pulse Position Modulation (PPM) System Analysis

## 1. PPM System Overview

The PDI Monitor implements a comprehensive Pulse Position Modulation (PPM) system consisting of four identical PPM modules (PPM0, PPM1, PPM2, and PPM3). Each module is configured through dedicated XML configuration files that define signal processing parameters, channel configurations, and filtering mechanisms. The PPM system is a critical component for processing control signals in the PDI Monitor architecture.

### 1.1 PPM Module Identification

Each PPM module is uniquely identified within the system:

| Module | ID | Filename | Version |
|--------|----|-----------|--------------------|
| PPM0   | 9  | ppm0.bin | 7.1.1 |
| PPM1   | 18 | ppm1.bin | 7.1.1 |
| PPM2   | 19 | ppm2.bin | 7.1.1 |
| PPM3   | 30 | ppm3.bin | 7.1.1 |

All four modules share the same version (7.1.1), indicating they were developed and maintained as part of the same system release.

## 2. PPM Signal Processing Configuration

### 2.1 Pulse Detection Parameters

All four PPM modules share identical pulse detection parameters, which define how the system identifies and validates incoming PPM signals:

```xml
<puls_pol>0</puls_pol>
<vguard>0.004</vguard>
<puls_min>2.5E-4</puls_min>
<puls_max>5.0E-4</puls_max>
<valid_min>8.0E-4</valid_min>
<valid_max>0.0022</valid_max>
<pos_min>9.0E-4</pos_min>
<pos_max>0.0021</pos_max>
```

These parameters define the precise timing characteristics for PPM signal processing:

| Parameter | Value | Purpose |
|-----------|-------|---------|
| puls_pol | 0 | Pulse polarity (0 = active low) |
| vguard | 0.004 (4ms) | Guard time between valid frames |
| puls_min | 0.00025 (250μs) | Minimum valid pulse width |
| puls_max | 0.0005 (500μs) | Maximum valid pulse width |
| valid_min | 0.0008 (800μs) | Minimum valid channel time |
| valid_max | 0.0022 (2.2ms) | Maximum valid channel time |
| pos_min | 0.0009 (900μs) | Minimum position value |
| pos_max | 0.0021 (2.1ms) | Maximum position value |

These timing parameters establish a strict protocol for PPM signal validation:
1. Pulses must be between 250-500μs in width to be recognized
2. Channel times must fall between 800μs and 2.2ms to be considered valid
3. Position values are mapped within the 900μs to 2.1ms range
4. A 4ms guard time separates valid frames

### 2.2 Channel Configuration

Each PPM module is configured to handle 16 channels:

```xml
<ch_num>16</ch_num>
<chmsk>4095</chmsk>
<fmsk>4294967295</fmsk>
```

| Parameter | Value | Purpose |
|-----------|-------|---------|
| ch_num | 16 | Number of channels per PPM module |
| chmsk | 4095 (0x00000FFF) | Channel mask (12 bits active) |
| fmsk | 4294967295 (0xFFFFFFFF) | Frame mask (all 32 bits active) |

The channel mask (4095 = 0x00000FFF) indicates that only the first 12 channels (of the 16 defined) are actively monitored, as 4095 in binary is 111111111111 (12 bits set to 1).

### 2.3 Filtering and Glitch Logic

Each PPM module implements filtering and glitch logic to ensure signal integrity:

```xml
<fgl>
    <delta_min>0.0</delta_min>
    <delta_max>1000.0</delta_max>
    <delta_min_alpha>1.0</delta_min_alpha>
    <delta_max_alpha>0.02</delta_max_alpha>
</fgl>
```

This configuration establishes a dynamic filtering mechanism:

| Parameter | Value | Purpose |
|-----------|-------|---------|
| delta_min | 0.0 | Minimum acceptable change |
| delta_max | 1000.0 | Maximum acceptable change |
| delta_min_alpha | 1.0 | Filter coefficient for minimum changes |
| delta_max_alpha | 0.02 | Filter coefficient for maximum changes |

This implements an adaptive filter where:
- Small changes (near delta_min) pass through with minimal filtering (alpha = 1.0)
- Large changes (near delta_max) are heavily filtered (alpha = 0.02)
- Changes between these extremes use a proportionally scaled alpha value

This filtering approach prevents sudden jumps in control signals while still allowing legitimate changes to pass through at an appropriate rate.

## 3. Channel-Specific Configuration

### 3.1 Channel Trim and Type Settings

Each of the 16 channels in each PPM module has identical configuration:

```xml
<ch01>
    <trim>0</trim>
    <type-choice>
        <direct>
            <type>0</type>
        </direct>
    </type-choice>
</ch01>
```

This pattern repeats for all 16 channels (ch01 through ch16) with the same values:

| Parameter | Value | Purpose |
|-----------|-------|---------|
| trim | 0 | No trim adjustment applied |
| type | 0 | Direct mapping (no transformation) |

The consistent use of direct mapping (type 0) across all channels indicates that the PPM system passes through the raw signal values without applying any mathematical transformations or curves.

### 3.2 Stick Capture Configuration

Each PPM module includes an empty stick capture configuration:

```xml
<stick_cap>
    <stick-cap-entry/>
</stick_cap>
```

This empty configuration suggests that stick capture functionality (likely for recording control stick movements) is defined in the system but not actively configured in these modules.

## 4. PPM System Integration with Communication Architecture

### 4.1 Relationship to Pulse Capture System

The PPM modules likely interface with the pulse capture system defined in `ver_spdif_pulse.xml`, which configures four pulse capture channels:

```xml
<cap-pulse-1>
    <type>0</type>
    <t2v>
        <!-- 5 time-to-value mapping points, all zeroed -->
    </t2v>
    <tout>1.0</tout>
</cap-pulse-1>
```

The four pulse capture channels align with the four PPM modules, suggesting a direct relationship where:
1. The pulse capture system detects and times the raw pulses
2. The PPM modules interpret these pulses according to the PPM protocol
3. The resulting channel values are made available to the rest of the system

### 4.2 Integration with Enhanced Capture Modules

The PPM system likely utilizes the Enhanced Capture (ECAP) modules defined in `ver_spdif_ecap.xml`:

```xml
<ecap1>
    <enable>1</enable>
    <gpio-id>100</gpio-id>
    <wrap>3</wrap>
    <trigger1>0</trigger1>
    <trigger2>1</trigger2>
    <trigger3>0</trigger3>
    <trigger4>1</trigger4>
</ecap1>
```

The ECAP modules are configured with alternating trigger patterns (0-1-0-1) which is ideal for capturing the rising and falling edges of PPM signals. The system has six ECAP modules, with four likely dedicated to the four PPM inputs.

### 4.3 Cross-Process Capture Integration

The PPM system integrates with the cross-process capture system defined in `ver_spdif_xpecap.xml`:

```xml
<str-tunarray-element>
    <producer>0</producer>
    <consumer>0</consumer>
    <group>0</group>
    <enable-bvar>1</enable-bvar>
</str-tunarray-element>
```

This configuration establishes four producer-consumer pairs that likely correspond to the four PPM modules, allowing the captured PPM data to be shared across process boundaries within the system.

## 5. PPM Signal Flow and Processing

Based on the configuration files and system architecture, the PPM signal flow can be reconstructed:

### 5.1 Signal Acquisition Path

1. **Physical Input**: PPM signals enter through GPIO pins mapped to ECAP modules
2. **Edge Detection**: ECAP modules capture rising and falling edges with timestamps
3. **Pulse Width Validation**: System validates pulses against puls_min (250μs) and puls_max (500μs)
4. **Channel Time Measurement**: Time between consecutive pulses is measured and validated against valid_min (800μs) and valid_max (2.2ms)
5. **Position Mapping**: Channel times are mapped to position values between pos_min (900μs) and pos_max (2.1ms)
6. **Frame Validation**: Complete frames are validated using the vguard (4ms) parameter

### 5.2 Signal Processing Path

1. **Filtering**: The adaptive filter applies varying levels of filtering based on the magnitude of change
2. **Channel Masking**: The chmsk parameter (4095) limits active monitoring to the first 12 channels
3. **Direct Mapping**: Channel values are passed through without transformation (type 0)
4. **Cross-Process Sharing**: Processed values are shared across process boundaries via XPECAP

### 5.3 Output Utilization

The processed PPM signals are likely used for:
1. **Control Input**: Providing control inputs to the flight control system
2. **Monitoring**: Allowing the PDI Monitor to verify control signal integrity
3. **Failsafe Detection**: Detecting signal loss or corruption for safety measures
4. **Telemetry**: Including control positions in system telemetry

## 6. PPM Module Relationships and Patterns

### 6.1 Identical Configuration Pattern

All four PPM modules share identical configuration parameters, suggesting:
1. **Redundancy**: Multiple PPM inputs provide redundancy for critical control signals
2. **Multiple Controllers**: Support for multiple control inputs (e.g., primary and backup controllers)
3. **Distributed Control**: Different PPM modules may control different aspects of the system

### 6.2 Channel Grouping Pattern

The channel mask (4095 = 0x00000FFF) activates only the first 12 channels of each 16-channel module, suggesting:
1. **Standard RC Protocol**: Alignment with standard RC protocols that typically use 8-12 channels
2. **Reserved Channels**: The last 4 channels may be reserved for future expansion
3. **Functional Grouping**: Channels may be grouped by function (e.g., primary controls, auxiliary functions)

### 6.3 Integration with System Architecture

The PPM system integrates with the broader PDI Monitor architecture:
1. **Input Processing**: Part of the input processing chain described in the System Architecture
2. **Monitoring Subsystem**: Contributes to the monitoring capabilities of the PDI Monitor
3. **Safety-Critical Path**: Likely part of the safety-critical control path

## 7. PPM Configuration Implications

### 7.1 Signal Quality Requirements

The tight timing constraints in the PPM configuration indicate strict signal quality requirements:
- Pulse width tolerance: 250-500μs (±250μs or 50% variation)
- Channel time tolerance: 800-2200μs (±700μs or ~43% variation)
- Position value range: 900-2100μs (1200μs range, standard for RC servos)

These constraints ensure that only clean, valid PPM signals are processed by the system.

### 7.2 Filtering Strategy

The adaptive filtering strategy reveals a sophisticated approach to signal processing:
- Fast response to small changes (alpha = 1.0)
- Significant damping of large changes (alpha = 0.02)
- Protection against signal spikes and noise
- Preservation of control fidelity for small movements

This strategy balances responsiveness with stability in the control system.

### 7.3 Channel Capacity

The system's configuration for 16 channels per module (with 12 active) provides:
- Total theoretical capacity: 64 channels across all modules
- Total active capacity: 48 channels across all modules
- Significant headroom for complex control schemes

This capacity exceeds typical RC systems (which usually offer 8-12 channels), suggesting advanced control capabilities.

## 8. File-by-File Breakdown

### 8.1 ver_spdif_ppm0.xml

This file defines the configuration for PPM module 0 (ID: 9):
- Contains complete signal processing parameters
- Defines 16 channels with direct mapping
- Establishes filtering and glitch logic
- Sets channel mask to 4095 (first 12 channels active)

### 8.2 ver_spdif_ppm1.xml

This file defines the configuration for PPM module 1 (ID: 18):
- Identical configuration to PPM0
- Maintains consistent signal processing parameters
- Uses the same channel configuration and filtering logic

### 8.3 ver_spdif_ppm2.xml

This file defines the configuration for PPM module 2 (ID: 19):
- Identical configuration to PPM0 and PPM1
- Maintains system-wide consistency in PPM processing

### 8.4 ver_spdif_ppm3.xml

This file defines the configuration for PPM module 3 (ID: 30):
- Identical configuration to the other PPM modules
- Completes the set of four PPM processors

## 9. Cross-Component Relationships

### 9.1 PPM and Pulse Capture

The PPM system relates to the pulse capture system:
- Four PPM modules align with four pulse capture channels
- Both systems share timing-based signal processing
- Pulse capture provides raw timing data that PPM modules interpret

### 9.2 PPM and ECAP

The PPM system utilizes the ECAP modules:
- ECAP provides hardware-level edge detection
- PPM modules process the timing data from ECAP
- Six ECAP modules support the four PPM modules with additional capacity

### 9.3 PPM and Cross-Process Communication

The PPM system integrates with cross-process communication:
- XPECAP configuration enables sharing PPM data across processes
- Four producer-consumer pairs align with the four PPM modules
- Enables system-wide access to PPM-derived control signals

## 10. PPM System in the Overall Architecture

The PPM system serves as a critical input processing component within the PDI Monitor architecture:

1. **Input Layer**: PPM modules process raw control signals from external controllers
2. **Signal Validation**: Strict timing parameters ensure signal integrity
3. **Filtering Layer**: Adaptive filtering provides clean control signals
4. **Distribution Layer**: Cross-process communication shares processed signals
5. **Monitoring Function**: Enables monitoring of control inputs for safety and telemetry

The PPM system exemplifies the PDI Monitor's approach to signal processing: rigorous validation, sophisticated filtering, and comprehensive integration with other system components.

## 11. Conclusion

The PDI Monitor's PPM system implements a robust, redundant approach to processing Pulse Position Modulation signals. With four identical modules, strict timing parameters, and adaptive filtering, the system ensures reliable control signal processing while maintaining signal integrity. The consistent configuration across all modules suggests a systematic approach to control signal handling, with redundancy built into the design.

The PPM system integrates seamlessly with other components of the PDI Monitor architecture, including pulse capture, enhanced capture modules, and cross-process communication. This integration enables system-wide access to processed control signals while maintaining the isolation necessary for safety-critical systems.

The sophisticated filtering strategy, with its adaptive approach to signal changes, reveals a design philosophy that balances responsiveness with stability—a critical consideration for control systems in autonomous or remotely operated vehicles.