# Generated from:

- _sw_Veronte/code/main1/code/include/Vmain_cpu1.h (956 tokens)
- _sw_Veronte/code/main1/code/source/Vmain_cpu1.cpp (1871 tokens)
- _sw_Veronte/code/main1/code/source/main_cpu1.cpp (2892 tokens)
- _sw_Veronte/code/main2/code/include/Vmain_cpu2.h (938 tokens)
- _sw_Veronte/code/main2/code/source/Vmain_cpu2.cpp (3079 tokens)
- _sw_Veronte/code/main2/code/source/main_cpu2.cpp (804 tokens)
- _sw_Veronte/code/main_cm/code/include/v1xv_cm.h (371 tokens)
- _sw_Veronte/code/main_cm/code/source/main_2838x_cm.cpp (1682 tokens)
- _sw_Veronte/code/main_cm/code/source/v1xv_cm.cpp (172 tokens)
- _sw_Veronte/code/main_cm/code/source/CM_CPU1_shared.cpp (336 tokens)
- _sw_Veronte/code/main_cm/code/source/Bsp_cm.cpp (89 tokens)
- _sw_Veronte/code/main_cm/code/source/Hvar_cm.cpp (230 tokens)
- _sw_Veronte/code/coreSIL/code/source/Vmain_cpu1.cpp (2064 tokens)
- _sw_Veronte/code/coreSIL/code/source/Vmain_cpu2.cpp (1978 tokens)

## With context from:

- PackageSummaries/Embention/Amazon-PrimeAir/items/ASTRO/items/sw/sw_Astro/items/09_System_Architecture.md (5081 tokens)

---

# Multi-Core Execution Architecture in the Veronte System

This document provides a detailed analysis of the multi-core execution architecture in the Veronte system, focusing on CPU1, CPU2, and CM (Communications Manager) cores. It explains the initialization sequences, main execution loops, and inter-core communication mechanisms.

## 1. System Architecture Overview

The Veronte system employs a multi-core architecture with three distinct processing cores:

1. **CPU1** - Primary control core responsible for system initialization, hardware management, and low-priority tasks
2. **CPU2** - Real-time processing core handling time-critical operations and navigation functions
3. **CM** - Communications Manager core dedicated to network communications and protocol handling

These cores operate in parallel with synchronized initialization sequences and communicate through shared memory structures.

## 2. CPU1 Core Architecture

### 2.1 CPU1 Initialization Sequence

The CPU1 initialization sequence follows these steps:

```
1. System pre-initialization (_system_pre_init)
   - Configure GPIO outputs for LEDs
   - Initialize system memory with appropriate size
   - Initialize memory ranges to wipe

2. System post-copy initialization (_system_post_cinit)
   - Initialize shared memory for cross-core communication

3. Main CPU1 initialization (main)
   - Verify application bootloader header
   - Build shared memory variables for CM communication
   - Configure system address and Ethernet MAC address
   - Set up IP configuration based on application type
   - Configure communication ports
   - Start CM initialization
   - Initialize Vmain_cpu1 instance
   - Signal to CM that CPU1 has finished initialization
   - Enter main execution loop
```

The CPU1 initialization process includes critical steps for setting up shared memory structures that will be used for inter-core communication:

```cpp
// Build shared memory variables
CPU1_CM_shared& shared_c1 = get_shared_c1();
shared_c1.uid = Bsp::get_uid();
shared_c1.sys_addr = shared_c1.uid.phy;
shared_c1.eth_mac = 0xA863F2000000 | (shared_c1.uid.phy & mask24);

// Configure IP and ports based on application type
if(Bsp::is_astro(app_id)) {
    Bsp::get_ip_cfg_pa(shared_c1.uid, shared_c1.ip_addr, shared_c1.net_mask);
    shared_c1.subjects.append(Base::Stanag_msg_type::cyp_maintenance_action_req - Base::Stanag_msg_type::stg_cyphal_msg);
    shared_c1.subjects.append(Base::Stanag_msg_type::cyp_pa_command_contingency_wrapper - Base::Stanag_msg_type::stg_cyphal_msg);
} else {
    Bsp::get_ip_cfg(shared_c1.uid, shared_c1.ip_addr, shared_c1.net_mask);
}
```

### 2.2 CPU1 Main Execution Loop

The CPU1 main execution loop is implemented in the `Vmain_cpu1::step()` method, which is called continuously from the `main()` function:

```cpp
void Vmain_cpu1::step() {
    static Stpmgrhelper stphelper;
    
    Type_avg::Scoped s(stats); // RAII for statistics tracking
    
    // Update statistics
    proc_t_max = stats.stats.get_data().dt_max;
    proc_t_avg = stats.stats.get_data().dt_avg;
    
    // Compute frequency metrics
    freq_metric.count();
    cio_freq = freq_metric.step();
    
    // Core operations
    Dsp28335_ent::Watchdog::notify();
    Arbiter::get_instance().call_cio();
    stphelper.step();
    Hstats::set_xcmqwr(Hxcff::get_xcmqwr().avg_stats_get_ratio());
    
    // Check stack integrity
    if(stchk_bit.get() && !Base::Assertions::runtime(stchk.check())) {
        stchk_bit.set(false);
    }
    
    // Publish CM variables to system variables
    publish_cm_vars();
    
    // Toggle green LED for heartbeat
    gled.step();
}
```

The `Stpmgrhelper` class manages low-priority tasks and tracks execution statistics:

```cpp
void Stpmgrhelper::step() {
    // Execute step manager tasks
    mgr.step();
    
    // Update metrics
    const Base::Stepmgr::Stats& sts = mgr.get_stats();
    tmax = sts.max_time;
    idmax = sts.max_id;
}
```

### 2.3 CPU1 Communication with CM

CPU1 periodically publishes CM variables to system variables through the `publish_cm_vars()` method:

```cpp
void Vmain_cpu1::publish_cm_vars() {
    static Var<Uvar>::Wdif tx_cnt(vu_udp_tx_pkts);
    static Var<Uvar>::Wdif rx_cnt(vu_udp_rx_pkts);
    static Var<Uvar>::Wdif rx_disc_cnt(vu_udp_rx_disc_pkts);
    static const CM_CPU1_shared& shared_cm = get_shared_cm();
    static Var<Uvar>::Wdif c1_cm_tx_lost(vu_c1_to_cm_lost_pkts);

    if(cm_p_tout.expired()) {
        cm_p_tout.start_lap();
        tx_cnt.set(static_cast<Uint16>(shared_cm.udp_tx_cnt));
        rx_cnt.set(static_cast<Uint16>(shared_cm.udp_rx_cnt));
        rx_disc_cnt.set(static_cast<Uint16>(shared_cm.udp_rx_disc_cnt));

        Uint16 c1_cm_tx_loss;
        Real c1_cm_tx_err_rate;
        ver.get_cm_port().get_pkt_loss(c1_cm_tx_loss, c1_cm_tx_err_rate);
        c1_cm_tx_lost.set(c1_cm_tx_loss);
    }
}
```

## 3. CPU2 Core Architecture

### 3.1 CPU2 Initialization Sequence

The CPU2 initialization sequence follows these steps:

```
1. System pre-initialization (_system_pre_init)
   - Initialize CPU2 system
   - Set red LED high

2. System post-copy initialization (_system_post_cinit)
   - Post-initialize CPU2 system

3. Main CPU2 initialization (main)
   - Verify application bootloader header
   - Calculate SHA256 hash of application area
   - Initialize Vmain_cpu2 instance
   - Enter main execution loop
```

The `Vmain_cpu2` constructor performs these initialization steps:

```cpp
Vmain_cpu2::Vmain_cpu2() :
    pre(),
    waddr(),
    remain(c2_stats.get_clk(), Ver::Hxcfg::get_xcfg().freq.read_unsafe().period_gnc, Const::ONEFOURTH),
    vpu(*Base::Memmgr::get_instance().get_allocator(Base::Memmgr::external).allocate_new<Vpgnc::Vpu,
        const Uint32>(blocks_alloc_size, remain)),
    dt_stats(stats_dt0),
    stchk_bit(Base::kbit_stack_c2),
    dummy_write_ext(reinterpret_cast<Uint16*>(Base::Memmgr::get_instance().get_allocator(Base::Memmgr::external).allocate_one(1U)))
{
    vpu.boot_mode_init();
    static Base::Stepmgr& steps = Base::Stepmgr::get_instance();
    steps.add(Base::Stepmgr::step_clock, tvar);
    stchk_bit.set(true);

    {
        Base::Feature fnull;
        Bsp::Hfvar(Base::c_null).get(fnull);
    }
    Ver::Copystep::step(); // Needs to be called before closing memory allocation.
    Base::Memmgr::get_instance().close_allocation();

    // Set hw address in system variable
    Bsp::Huvar(Base::vu_hw_addr).set(Ver::Hsys::get_khwaddr().id);
    // Set system addres in system variables
    Bsp::Huvar(Base::vu_sys_addr_h).set(Base::Bitutils::get_u32_h(Ver::Hsys::get_ksysaddr().id));
    Bsp::Huvar(Base::vu_sys_addr_l).set(Base::Bitutils::get_u32_l(Ver::Hsys::get_ksysaddr().id));
}
```

### 3.2 CPU2 Main Execution Loop

The CPU2 main execution loop is implemented in the `Vmain_cpu2::step()` method, which is called continuously from the `main()` function:

```cpp
void Vmain_cpu2::step() {
    using Maverick::Ewma0;
    static const Real cfg_dt_margin = 6.0E-6F;   // Maximum allowed delay is 6us
    static const volatile Real& cfg_period = Ver::Hxcfg::get_xcfg().freq.read_unsafe().period_gnc;
    static const Real act_period = cfg_period - cfg_dt_margin;
    static Stpmgrhelper steps;
    static const Uint32 led_dec_v = 15UL;
    Dsp28335_ent::GPIO red_led(Ver::get_gpio_led_red_id());
    Dsp28335_ent::GPIOtoggler<Dsp28335_ent::GPIO> led_tgl(red_led, led_dec_v);

    // Force a desynchronization between C1 and C2 to avoid read-write at the exact same time.
    Uint32 us_delay = 100U;
    Dsp28335_ent::Delay::us(us_delay);
    
    while(true) {
        {
            Type_stats::Scoped s(c2_stats); // RAII, measure this method (computes at destroy).
            step_stats(cfg_period);
            Ver::Copystep::step(); // Copy system variables "owned" by CPU1 in CPU2 owned memory.
            c2_deadman_step();
            
            //Check stack
            if(stchk_bit.get() && !Base::Assertions::runtime(stchk.check())) {
                stchk_bit.set(false);
            }
            
            vpu.step();
            steps.step();
            reset_step();
            led_tgl.step();
            vpu.step_xqrd(act_period - c2_stats.toc()); // always at least 1 step
        }
        
        // Wait until period is complete for precise timing
        while(c2_stats.toc() < act_period) {
            // Busy wait for timing precision
        }
    }
}
```

The CPU2 execution loop is designed for precise timing, with these key features:

1. **Timing Control**: Uses a busy-wait loop to ensure precise execution periods
2. **Statistics Tracking**: Monitors execution time and CPU usage
3. **Cross-Core Variable Copying**: Copies variables from CPU1 to CPU2 memory
4. **Deadman Counter**: Increments a counter to indicate CPU2 is alive
5. **Stack Checking**: Verifies stack integrity
6. **VPU Processing**: Executes the Veronte Processing Unit step
7. **Reset Handling**: Checks for reset requests from CPU1

### 3.3 CPU2 Reset Handling

CPU2 includes a mechanism to handle reset requests from CPU1:

```cpp
void Vmain_cpu2::reset_step() {
    if(Dsp28335_ent::Ipc::is_reset_request()) {
        // Disable PWM outputs before reset
        vpu.pwm_suite0.disable_and_wait_off();

        // First try to Write on ERAM to force data bus and to link external buffer.
        *memmgr_ext_buf = Ku16::uMAX;

        Dsp28335_ent::GPIO boot_mode_pin1(Dsp28335_ent::gpio_072);
        Dsp28335_ent::GPIO boot_mode_pin0(Dsp28335_ent::gpio_084);

        // Wait until boot mode pins are 1
        Base::Timeout tout(0.1F);
        while(!(boot_mode_pin1.get() && boot_mode_pin0.get()) && !(tout.expired())) {
            // Write on ERAM to force data bus (and GPIO 72) to high impedance state
            *dummy_write_ext = Ku16::uMAX;
        }
        
        if(tout.expired()) {
            Dsp28335_ent::Ipc::send_nack_reset_request_2to1();   // Nack for CPU1
        } else {
            Dsp28335_ent::Ipc::send_ack_reset_request_2to1();    // Acknowledge for CPU1
            while(true) {
                // Infinite loop waiting for reset
            }
        }
    }
}
```

### 3.4 CPU2 Statistics Tracking

CPU2 tracks various performance metrics:

```cpp
void Vmain_cpu2::step_stats(Real max_dt) {
    static Bsp::Hrvar step_ravg(Base::v_tskc2_ravg);  // C2 average CPU ratio
    static Bsp::Hrvar step_rmax(Base::v_tskc2_rmax);  // C2 maximum CPU ratio
    static Bsp::Hrvar step_tavg(Base::v_tskc2_tavg);  // C2 average time
    static Bsp::Hrvar step_tmax(Base::v_tskc2_tmax);  // C2 maximum time
    static Bsp::Hrvar hdt(Base::v_dt_gnc);            // C2 period
    static Bsp::Hrvar hdt_max(Base::v_tskc2_dtmax);   // C2 maximum period
    static Bsp::Hbvar hok(Base::kbit_gnc_step_mis);   // C2 bit OK
    
    const Base::CPUrc_all::Data& c2_stats_computed = c2_stats.stats.get_data();
    step_ravg.set(c2_stats_computed.ratio_avg);
    step_rmax.set(c2_stats_computed.ratio_max);
    step_tavg.set(c2_stats_computed.dt_avg);
    step_tmax.set(c2_stats_computed.dt_max);
    
    const Base::Rtaskrc::Data& dt_stats_computed = dt_stats.compute(max_dt);
    hdt.set(dt_stats_computed.dt);
    hdt_max.set(dt_stats_computed.dt_max);
    hok.set(dt_stats_computed.dt <= max_dt);
}
```

## 4. CM (Communications Manager) Core Architecture

### 4.1 CM Initialization Sequence

The CM initialization sequence follows these steps:

```
1. CM initialization (CM_init)
   - Disable watchdog
   - Copy critical code to RAM
   - Initialize flash wait states
   - Set interrupt vector table

2. Main CM initialization (main)
   - Verify application bootloader header
   - Initialize memory manager
   - Initialize shared RAM
   - Calculate SHA256 hash of application area
   - Signal startup finished to CPU1
   - Wait for CPU1 to finish startup
   - Enable processor interrupts
   - Configure network parameters from shared memory
   - Initialize V1xv_cm instance
   - Initialize UDP_comm_suite
   - Configure routing tables
   - Set up SysTick timer and interrupt
   - Enter main execution loop
```

### 4.2 CM Main Execution Loop

The CM main execution loop is relatively simple:

```cpp
while(true) {
    // Communications step
    v1x.step();
    comms->step();

    // Update shared memory counters
    shared_cm.udp_tx_cnt = udp_p.get_tx_packet_count();
    shared_cm.udp_rx_cnt = udp_p.get_rx_packet_count();
    shared_cm.udp_rx_disc_cnt = udp_p.get_rx_packet_disc_count();
}
```

Additionally, the CM core uses a SysTick interrupt handler for high-priority tasks:

```cpp
void SysTickIntHandler(void) {
    static uint32_t cnt = 0;
    if(++cnt >= 1000UL) {
        cnt = 0;
        toggle_led(led_gpio_id);
    }
    lwIPTimer(1);   // Call the lwIP timer handler (with 1ms increment)
    comms->step_hi();
}
```

### 4.3 CM Communication Components

The CM core uses several components for communication:

1. **V1xv_cm**: Manages routing tables and packet forwarding
   ```cpp
   V1xv_cm::V1xv_cm(U8pkmblock buffer0) :
       rtable(),
       addr_tunnel(Bsp::sysaddr()),
       stg_suite(rtable, ident_map_size, addr_tunnel),
       cm_port(stg_suite.get_router(),
               get_shared_cm().udp_writer,
               get_shared_cm().udp_reader)
   {
       stg_suite.get_router().add_port(cm_port);
   }
   
   void V1xv_cm::step() {
       cm_port.step();
       stg_suite.step();
   }
   ```

2. **UDP_comm_suite**: Handles UDP communication
   ```cpp
   const UDP_comm_suite::Params comm_par = {
       mac,
       32, // IP/Address map size
       shared.port_stg,
       shared.port_cy,
       {
           shared.ip_addr,
           shared.net_mask,
           gateway_addr,
           false
       },
       shared.subjects.to_mblock(),
       shared.multicast_node_id
   };
   
   comms = alloc.allocate_new<UDP_comm_suite>(comm_par, v1x.get_router());
   ```

## 5. Inter-Core Communication Mechanisms

### 5.1 Shared Memory Structures

The cores communicate primarily through shared memory structures:

#### 5.1.1 CPU1-CM Shared Memory

```cpp
// CPU1 to CM shared memory structure
struct CPU1_CM_shared {
    Bsp::Uid64 uid;                  // System unique identifier
    Uint32 sys_addr;                 // System address
    Uint64 eth_mac;                  // Ethernet MAC address
    Uint32 ip_addr;                  // IP address
    Uint32 net_mask;                 // Network mask
    Uint16 port_stg;                 // STANAG port
    Uint16 port_cy;                  // Cyphal port
    Uint16 multicast_node_id;        // Multicast node ID
    Base::Tnarray<Uint16, 16> subjects; // Subjects to subscribe
    Spkt_fifo::Writer udp_writer;    // Writer for UDP packets
    Spkt_fifo::Reader udp_reader;    // Reader for UDP packets
};

// CM to CPU1 shared memory structure
struct CM_CPU1_shared {
    Spkt_fifo::Writer udp_writer;    // Writer for UDP packets
    Spkt_fifo::Reader udp_reader;    // Reader for UDP packets
    volatile Uint32 udp_tx_cnt;      // UDP transmit packet count
    volatile Uint32 udp_rx_cnt;      // UDP receive packet count
    volatile Uint32 udp_rx_disc_cnt; // UDP receive discarded packet count
};
```

### 5.2 Inter-Process Communication (IPC)

The cores use IPC mechanisms for synchronization:

```cpp
// CPU1 signals to CM that initialization is complete
IPC_setFlagLtoR(IPC_CM_L_CPU1_R, IPC_FLAG0);

// CM waits for CPU1 to finish startup
IPC_waitForFlag(IPC_CM_L_CPU1_R, IPC_FLAG1);

// CPU1-CPU2 synchronization
Dsp28335_ent::Ipc::cpu1_wait_for_unlock();
Dsp28335_ent::Ipc::cpu2_unlock();
Dsp28335_ent::Ipc::send_ack_reset_request_2to1();
```

### 5.3 FIFO Ports

FIFO ports are used for message passing between cores:

```cpp
// CM port for communication with CPU1
Base::Fifo_port<Ver::Spkt_fifo::Writer, Ver::Spkt_fifo::Reader> cm_port;

// In V1xv_cm constructor
cm_port(stg_suite.get_router(),
        get_shared_cm().udp_writer,
        get_shared_cm().udp_reader)
```

## 6. Initialization Synchronization Sequence

The initialization sequence across all three cores follows this pattern:

```
CPU1                          CPU2                          CM
  |                             |                            |
  |-- Initialize hardware ------>                            |
  |-- Initialize shared memory ->                            |
  |                             |                            |
  |-- Start CM initialization -->                            |
  |                             |                            |-- Initialize hardware
  |                             |                            |-- Initialize shared RAM
  |                             |                            |-- Signal startup finished --> CPU1
  |<-- Wait for CPU1 to finish --                            |
  |                             |                            |
  |-- Initialize Vmain_cpu1      |                            |
  |-- Signal CM initialization done --> CM                   |
  |                             |                            |-- Enable interrupts
  |                             |                            |-- Configure network
  |                             |                            |-- Initialize communication
  |                             |                            |
  |-- Set load state ----------->                            |
  |<-- Wait for CPU2 unlock -----                            |
  |                             |-- Initialize Vmain_cpu2     |
  |                             |-- Wait for address to be    |
  |                             |   read in CPU1              |
  |                             |-- Unlock CPU1 ------------->|
  |                             |                            |
  |-- Process cross-core file -->                            |
  |   service while waiting      |                            |
  |                             |                            |
  |<-- Signal load complete -----                            |
  |                             |                            |
  |-- Set ongoing state -------->                            |
  |-- Load CPU1 PDIs             |                            |
  |-- Initialize maps            |                            |
  |                             |                            |
  |-- Unlock CPU2 -------------->|                            |
  |                             |                            |
  |<-- Wait for system vars -----                            |
  |                             |                            |
  |-- Enter main loop            |-- Enter main loop          |-- Enter main loop
  |                             |                            |
```

## 7. Main Execution Loop Timing

### 7.1 CPU1 Loop Timing

CPU1 operates in a continuous loop without explicit timing constraints, focusing on:
- Low-priority tasks
- System monitoring
- Cross-core communication
- Hardware management

### 7.2 CPU2 Loop Timing

CPU2 operates with precise timing constraints:
- Fixed execution period defined by `cfg_period` (typically in the millisecond range)
- Busy-wait loop to ensure precise timing
- Maximum allowed delay of 6μs (`cfg_dt_margin`)
- Execution statistics tracking to monitor timing violations

### 7.3 CM Loop Timing

CM operates with two timing mechanisms:
1. **Main loop**: Continuous execution without explicit timing constraints
2. **SysTick interrupt**: Fixed 0.5ms period (2kHz @ 125MHz) for high-priority tasks

## 8. Cross-Component Relationships

```
+-------------+         +-------------+         +-------------+
|    CPU1     |<------->|    CPU2     |<------->|     CM      |
+-------------+         +-------------+         +-------------+
| Vmain_cpu1  |         | Vmain_cpu2  |         | V1xv_cm     |
| - System    |         | - VPU       |         | - UDP_comm  |
| - Hardware  |         | - Navigation|         | - Routing   |
| - File sys  |         | - Control   |         | - Network   |
+-------------+         +-------------+         +-------------+
       ^                       ^                       ^
       |                       |                       |
       v                       v                       v
+-----------------------------------------------------|
|                  Shared Memory                       |
| - CPU1_CM_shared                                     |
| - CM_CPU1_shared                                     |
| - System variables                                   |
+-----------------------------------------------------+
```

## 9. Software-In-Loop (SIL) Implementation

The SIL implementation modifies the execution architecture to work in a simulation environment:

### 9.1 CPU1 SIL Implementation

```cpp
void Vmain_cpu1::step() {
    Base::Sil_data& sil_data = Base::Sil_data::get_instance();
    switch (get_boot_cpu1_flag().step(sil_data.boot_cpu1_done)) {
        case Base::Logicfsm::neg_level:
            // Initial state - boot mode initialization
            ver.boot_mode_init(force_maintenance);
            break;
            
        case Base::Logicfsm::pos_edge:
            // Transition state - finalize initialization
            Base::Memmgr::get_instance().close_allocation();
            sil_data.cpu1_ready = true;
            break;
            
        case Base::Logicfsm::pos_level:
            // Normal operation state - regular step execution
            // [Regular step code as in hardware implementation]
            break;
    }
}
```

### 9.2 CPU2 SIL Implementation

```cpp
void Vmain_cpu2::step() {
    Base::Sil_data& sil_data = Base::Sil_data::get_instance();
    switch (get_boot_cpu2_flag().step(sil_data.boot_cpu2_done)) {
        case Base::Logicfsm::neg_level:
            // Initial state - boot mode initialization
            vpu.boot_mode_init();
            break;
            
        case Base::Logicfsm::pos_edge:
            // Transition state - finalize initialization
            Base::Memmgr::get_instance().close_allocation();
            sil_data.cpu2_ready = true;
            break;
            
        case Base::Logicfsm::pos_level:
            // Normal operation state - regular step execution
            // [Regular step code as in hardware implementation]
            break;
    }
}
```

The SIL implementation uses a state machine to explicitly control the initialization sequence, allowing the simulation to step through the boot process incrementally.

## 10. Memory Management

Each core has its own memory allocation strategy:

### 10.1 CPU1 Memory

```cpp
const Uint64 memmgr_all_sz = 0x10B60UL;
const Uint64 memmgr_int_buf_sz = 1UL;
const Uint64 memmgr_ext_buf_sz = memmgr_all_sz - memmgr_int_buf_sz;

#pragma DATA_SECTION("MEMMGR_INT")
Uint16 memmgr_int_buf[memmgr_int_buf_sz];

#pragma DATA_SECTION("MEMMGR_EXT")
Uint16 memmgr_ext_buf[memmgr_ext_buf_sz];
```

### 10.2 CPU2 Memory

```cpp
const Uint64 memmgr_int_cpu2_buf_sz = 0x3000UL;
const Uint64 memmgr_ext_cpu2_buf_sz = 600UL*1024UL;

#pragma DATA_SECTION("MEMMGR_INT")
Uint16 memmgr_int_cpu2_buf[memmgr_int_cpu2_buf_sz];

#pragma DATA_SECTION("MEMMGR_EXT")
Uint16 memmgr_ext_cpu2_buf[memmgr_ext_cpu2_buf_sz];
```

### 10.3 CM Memory

```cpp
static const Uint32 mem_sz = 11000UL;
Uint16 memmgr_buf[mem_sz];
```

## 11. Referenced Context Files

The following context files provided valuable information for understanding the multi-core execution architecture:

1. `09_System_Architecture.md` - Provided overview of the Veronte system architecture, including cross-core communication mechanisms and boot sequence