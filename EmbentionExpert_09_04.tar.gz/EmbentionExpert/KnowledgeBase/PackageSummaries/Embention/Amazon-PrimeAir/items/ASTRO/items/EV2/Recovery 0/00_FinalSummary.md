# Generated from:

- Amazon-PrimeAir/items/ASTRO/items/EV2/Recovery 0/04_Sensor_Calibration_System.md (4221 tokens)
- Amazon-PrimeAir/items/ASTRO/items/EV2/Recovery 0/03_IMU_And_Sensor_Configuration.md (7086 tokens)
- Amazon-PrimeAir/items/ASTRO/items/EV2/Recovery 0/02_Block_Libraries_And_Execution_Framework.md (5333 tokens)
- Amazon-PrimeAir/items/ASTRO/items/EV2/Recovery 0/02_Hardware_IO_Configuration.md (3291 tokens)
- Amazon-PrimeAir/items/ASTRO/items/EV2/Recovery 0/03_Communication_Interfaces.md (7580 tokens)
- Amazon-PrimeAir/items/ASTRO/items/EV2/Recovery 0/02_Navigation_And_Positioning.md (5574 tokens)
- Amazon-PrimeAir/items/ASTRO/items/EV2/Recovery 0/02_Vehicle_Configuration.md (3982 tokens)
- Amazon-PrimeAir/items/ASTRO/items/EV2/Recovery 0/02_Mission_And_Event_Management.md (2568 tokens)
- Amazon-PrimeAir/items/ASTRO/items/EV2/Recovery 0/02_Environment_And_Atmospheric.md (2104 tokens)
- Amazon-PrimeAir/items/ASTRO/items/EV2/Recovery 0/02_Core_Configuration_Files.md (4519 tokens)
- Amazon-PrimeAir/items/ASTRO/items/EV2/Recovery 0/01_System_Integration_Overview.md (4676 tokens)
- Amazon-PrimeAir/items/ASTRO/items/EV2/Recovery 0/01_Recovery_System_Operational_Modes.md (5000 tokens)
- Amazon-PrimeAir/items/ASTRO/items/EV2/Recovery 0/01_Sensor_Fusion_And_Navigation_Pipeline.md (5093 tokens)

---

# Amazon Prime Air Recovery System: Knowledge Tree Overview

## System Architecture Overview

The Amazon Prime Air Recovery System is a sophisticated flight control and recovery platform designed for autonomous operation with robust redundancy, comprehensive sensor integration, and multi-modal communication capabilities. The system follows a modular architecture with clear separation between sensor processing, navigation, mission management, and hardware I/O components.

### Core Architectural Layers

1. **Sensor Processing Layer**
   - Sensor calibration system
   - IMU and sensor configuration
   - Environmental modeling

2. **Core Processing Layer**
   - Block libraries and execution framework
   - Navigation and positioning
   - Mission and event management

3. **Communication Layer**
   - CAN bus interfaces
   - GNSS receivers
   - Radio communication systems

4. **Hardware Interface Layer**
   - GPIO configuration
   - PWM device control
   - Pulse capture

5. **Configuration Management Layer**
   - Vehicle configuration
   - Core configuration files
   - Amazon-specific parameters

### Key Architectural Patterns

The system implements several important architectural patterns:

1. **Multi-Layer Redundancy**: Redundancy at multiple levels, from sensors to communication paths to processing algorithms, ensuring robust operation even when components fail.

2. **Modular Extensibility**: Block-based processing framework and event-action architecture allow for flexible extension and reconfiguration without changing core components.

3. **Event-Driven Architecture**: Events defined as system stimuli, actions defined as system responses, and mappings connect events to appropriate actions.

4. **Hierarchical Configuration**: Core parameters, subsystem-specific parameters, and operational parameters organized in a logical structure.

## Sensor Fusion and Navigation Pipeline

The recovery system implements a sophisticated sensor fusion approach that combines data from multiple sensors to provide robust navigation performance:

### Sensor Hardware Architecture

- **Multiple IMUs**: Four distinct IMUs with different configurations:
  - IMU0/IMU1: Primary/redundant with identical configurations (±4g accel, ±12 deg/s gyro)
  - IMU2: Backup with different parameters (±2g accel)
  - IMU3: Tertiary with minimal configuration

- **Dual GNSS Receivers**:
  - UBX0: 4Hz update rate, configured for primary navigation
  - UBX1: 2Hz update rate, configured as backup

- **Multiple Magnetometers**:
  - 7 standard magnetometers
  - 1 reserve magnetometer
  - 2 extended magnetometers

### Sensor Fusion Algorithm

The core of the navigation system is a sophisticated sensor fusion algorithm:

1. **Kalman Filter Implementation**:
   - Integrates position, velocity, attitude, and sensor bias states
   - Process noise parameters tuned for optimal performance
   - GPS validation requires 5.0 seconds of consistent data

2. **Complementary Filter for Attitude**:
   - Beta=0.025 (proportional gain)
   - Zeta=0.003 (integral gain)
   - Beta0=10.0 (initial proportional gain for rapid convergence)

3. **Sensor Weighting and Variance Estimation**:
   - Dynamic variance estimation with time constants tau_v=2.0 and tau_s2=20.0
   - Initial variance=1.0, minimum variance=1.0E-4

For more details, see [Sensor Fusion And Navigation Pipeline](01_Sensor_Fusion_And_Navigation_Pipeline.md).

## Operational Modes and Contingency Handling

The recovery system implements sophisticated operational modes and contingency handling mechanisms:

### Recovery Mode Phase Function (RMPF)

- **Ground Phase**: Detected when altitude AGL < 0.48m
- **Takeoff Phase**: Triggered when altitude > 1.0m, vertical velocity > 0.5m/s, and acceleration > 2.6m/s²
- **Landing Phase**: Triggered when vertical velocity < 0.25m/s or commanded velocity < 0.75m/s for > 2.0s

### Contingency Detection and Handling

1. **Detection Mechanisms**:
   - Position accuracy monitoring (thresholds: 15.0m horizontal, 25.0m vertical)
   - Tracking error monitoring
   - Wind monitoring (gust threshold: 12.8m/s)
   - System health monitoring through built-in tests

2. **Response Mechanisms**:
   - Switchover to backup components (enabled)
   - Bounding box protection (5.0m half-length/width, 10.0m half-height)
   - Weathervaning (orients vehicle into wind)
   - Mode blending with 2.0s transition time

For more details, see [Recovery System Operational Modes](01_Recovery_System_Operational_Modes.md).

## Hardware and Communication Interfaces

### Hardware I/O Configuration

- **GPIO Configuration**: 16 PWM GPIO pins and 4 general-purpose I/O pins, all configured as outputs
- **PWM Device Configuration**: 8 PWM channels at 50Hz with 900-2100μs pulse width range
- **Pulse Capture**: 4 capture channels with timeout value of 1.0 second
- **Enhanced Capture**: 6 ECAP channels configured to trigger on both rising and falling edges

### Communication Interfaces

1. **CAN Bus Network**:
   - Three CAN interfaces (CAN A, CAN B, CAN FD A) operating at 500 kbps
   - Extensive message filtering for proper routing

2. **GNSS Communication**:
   - UBX proprietary protocol for u-blox receivers
   - NMEA 0183 standard messages
   - RTCM differential corrections (currently disabled)

3. **Radio Communication**:
   - Amazon Radio system (8 channels, 450-470MHz)
   - SARA cellular module (currently disabled)
   - Iridium satellite communication (currently disabled)

For more details, see [Hardware IO Configuration](02_Hardware_IO_Configuration.md) and [Communication Interfaces](03_Communication_Interfaces.md).

## Sensor Calibration and Configuration

### Sensor Calibration System

The recovery system employs an extensive sensor calibration framework:

1. **Temperature-Dependent Calibration**:
   - Different calibration sets for different temperature ranges
   - Temperature hysteresis to prevent oscillation between calibration sets

2. **Calibration Application Process**:
   - Bias correction (subtract bias vector)
   - Scale and cross-axis correction (apply 3x3 calibration matrix)
   - Default identity matrices and zero biases as fallbacks

For more details, see [Sensor Calibration System](04_Sensor_Calibration_System.md).

### IMU and Sensor Configuration

The sensor configuration system defines:

1. **IMU Hardware Configuration**:
   - Four distinct IMUs with different parameters
   - IMU geometry and positioning relative to vehicle

2. **Sensor Suite Configurations**:
   - Gyroscope and accelerometer suites enabled
   - Default sensors defined (sensor 0 for both)
   - Variance estimation parameters configured

3. **Filtering Options**:
   - Various filter types defined but currently disabled
   - Notch, Butterworth, and IIR filters available

For more details, see [IMU And Sensor Configuration](03_IMU_And_Sensor_Configuration.md).

## Execution Framework and Mission Management

### Block Libraries and Execution Framework

The recovery system implements a modular execution framework:

1. **Block Libraries**: 32 separate block libraries that serve as containers for functional blocks
2. **Scheduler-Interpreter Configuration**: 24 scheduler-interpreter pairs (4 schedulers × 6 interpreters)
3. **Frequency Manager**: Controls timing with acquisition at 1010Hz and GNC at 500Hz

For more details, see [Block Libraries And Execution Framework](02_Block_Libraries_And_Execution_Framework.md).

### Mission and Event Management

The system implements an event-driven architecture:

1. **Event Types**:
   - ISC DComms cmd received
   - Contingency command
   - OK to deliver command
   - Contingency response

2. **Action Types**:
   - Send response
   - Send contingency cyphal message
   - Send ISC Cyphal msg
   - DComms response
   - Cyphal contingency

3. **Event-Action Mappings**: Connect specific events to appropriate actions

For more details, see [Mission And Event Management](02_Mission_And_Event_Management.md).

## Vehicle and Environment Configuration

### Vehicle Configuration

- **Vehicle Identification**: Tail number "RP78190080", UAV address 4278190080
- **Subsystem Configuration**: 32 subsystems with identical default configurations
- **Built-In Test Configuration**: MBIT tests defined for critical systems (GPS, IMU, LIDAR, state estimation)

For more details, see [Vehicle Configuration](02_Vehicle_Configuration.md).

### Environment and Atmospheric Configuration

- **US76 Extended Atmosphere Model**: Provides atmospheric property calculations every 60 seconds
- **Field String Configurations**: Define how data is formatted and transmitted
- **Meta Configurations**: Provide system-level settings

For more details, see [Environment And Atmospheric](02_Environment_And_Atmospheric.md).

## Core Configuration Files

The recovery system's core configuration includes:

1. **Field Measurement Set (FMSET)**: Defines data structure for field measurements
2. **Configuration Manager**: Defines operational modes
3. **Amazon Lights Configuration**: Defines behavior of the vehicle's lighting system
4. **Telemetry Configuration**: Defines data collection and transmission
5. **Amazon Recovery Parameters**: Contains core configuration parameters

For more details, see [Core Configuration Files](02_Core_Configuration_Files.md).

## System Integration Overview

The recovery system demonstrates several notable architectural features:

1. **Multi-Layer Redundancy**: Redundancy at multiple levels ensures robust operation even when components fail.
2. **Modular Extensibility**: Block-based processing and event-action architecture allow for flexible extension.
3. **Comprehensive Sensor Integration**: Multiple sensor types with sophisticated calibration, validation, and fusion.
4. **Adaptive Control**: Control system adapts to different flight phases and conditions.
5. **Distributed Processing**: Processing distributed across multiple processors with well-defined interfaces.
6. **Hierarchical Configuration**: Configuration organized in a logical structure.
7. **Safety-First Design**: Multiple safety mechanisms ensure safe operation in challenging conditions.

For more details, see [System Integration Overview](01_System_Integration_Overview.md).

# System Architecture Summary

The Amazon Prime Air Recovery System represents a sophisticated integration of multiple subsystems into a cohesive whole, capable of autonomous operation with robust redundancy and comprehensive monitoring. Its architecture balances modularity with tight integration, enabling complex behaviors while maintaining system reliability.

The system is designed with multiple layers of redundancy, from duplicate sensors to alternative communication paths, ensuring continued operation even when components fail. The modular, event-driven architecture allows for flexible reconfiguration and extension without changing core components.

The sensor fusion approach combines data from multiple IMUs, GNSS receivers, and magnetometers to provide robust navigation performance, with sophisticated calibration and validation mechanisms. The operational modes and contingency handling ensure safe operation in various conditions, with smooth transitions between modes and appropriate responses to anomalies.

The hardware and communication interfaces provide comprehensive connectivity, with multiple CAN buses, GNSS receivers, and radio systems. The execution framework enables flexible processing with block libraries and scheduler-interpreter pairs, while the mission management system provides event-driven control.

Overall, the recovery system demonstrates a well-designed approach to autonomous flight control and recovery, with a focus on safety, reliability, and adaptability.