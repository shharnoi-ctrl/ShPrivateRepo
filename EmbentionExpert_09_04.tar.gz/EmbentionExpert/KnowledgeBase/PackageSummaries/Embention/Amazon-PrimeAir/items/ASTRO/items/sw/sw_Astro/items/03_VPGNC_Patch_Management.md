# Generated from:

- _sw_Veronte/code/vpgnc/code/include/Patchset.h (2176 tokens)
- _sw_Veronte/code/vpgnc/code/source/Patchset.cpp (1811 tokens)
- _sw_Veronte/code/vpgnc/code/include/Patchset_fw.h (24 tokens)
- _sw_Veronte/code/vpgnc/code/include/Patchsets.h (1058 tokens)
- _sw_Veronte/code/vpgnc/code/source/ver/Patchsets.cpp (779 tokens)
- _sw_Veronte/code/vpgnc/code/include/Spatchset.h (926 tokens)
- _sw_Veronte/code/vpgnc/code/source/Spatchset.cpp (900 tokens)
- _sw_Veronte/code/vpgnc/code/include/Tpatchset.h (2872 tokens)
- _sw_Veronte/code/vpgnc/code/source/Tpatchset.cpp (2064 tokens)
- _sw_Veronte/code/vpgnc/code/include/Tpatchset_fw.h (24 tokens)
- _sw_Veronte/code/vpgnc/code/include/Tunpatchset.h (656 tokens)
- _sw_Veronte/code/vpgnc/code/source/Tunpatchset.cpp (1337 tokens)
- _sw_Veronte/code/vpgnc/code/include/Patchtypes.h (1407 tokens)
- _sw_Veronte/code/vpgnc/code/source/Patchtypes.cpp (1455 tokens)
- _sw_Veronte/code/vpgnc/code/include_FPA/Patchtypes.h (1448 tokens)
- _sw_Veronte/code/vpgnc/code/include/Patchsetcfg.h (291 tokens)
- _sw_Veronte/code/vpgnc/code/source/Patchsetcfg.cpp (23 tokens)
- _sw_Veronte/code/vpgnc/code/include/Patchsetcfg_fw.h (30 tokens)

## With context from:

- PackageSummaries/Embention/Amazon-PrimeAir/items/ASTRO/items/sw/sw_Astro/items/06_VPGNC_Core.md (7671 tokens)

---

# Patchset System in VPGNC Framework: Navigation Route Management

This document provides a comprehensive analysis of the Patchset system in the VPGNC framework, which manages navigation routes composed of connected path segments (patches).

## 1. Patchset Class Hierarchy and Core Components

The Patchset system is built around several key classes that work together to manage navigation routes:

```
+----------------+         +----------------+         +----------------+
|    Patchset    |<--------|   Spatchset    |<--------|   Tpatchset    |
| (Navigation    |         | (Thread-safe   |         | (Serializable  |
|  Controller)   |         |  Patch Access) |         |  Patch Data)   |
+----------------+         +----------------+         +----------------+
        |                          |                          |
        v                          v                          v
+----------------+         +----------------+         +----------------+
|     Gcurve     |         |  Patchdata     |         |     Patch      |
| (Guidance      |         | (Consistent    |         | (Individual    |
|  Curve)        |         |  Patch Data)   |         |  Path Segment) |
+----------------+         +----------------+         +----------------+
```

### 1.1 Patchset Class

The `Patchset` class is the central controller for navigating along connected path segments. It manages:

- Current active patch selection
- Projection modes (2D, 3D, 2.5D)
- Patch transitions
- Finding the closest patch
- Tracking navigation progress

```cpp
class Patchset {
public:
    // Projection types
    enum Prjtype {
        prj_3d  = 0, // 3D projection (3D point inside curve with less 3D distance)
        prj_2d  = 1, // 2D projection (2D point inside curve with less 2D distance)
        prj_2d5 = 2, // 2.5D projection (3D point inside curve with less 2D distance)
        prj_num = 3
    };
    
    // Core navigation methods
    bool current_check();
    bool flyto(int16 id);
    bool flyto_next();
    void on_focus(const Geo::Apos& pos, const Maverick::Irvector3& v0);
    void path_compute(const Patchsetcfg& pcfg, const Geo::Apos& pos, 
                     Maverick::Irvector3& d, Maverick::Irvector3& t);
    
    // Closest patch finding
    void compute_closest(const Geo::Apos& pos);
    Real flyto_closest();
    bool is_closest_found() const;
    
    // Status methods
    bool is_finished() const;
    bool is_patch_changed() const;
    void clear_patch_changed();
    
    // Getters
    int16 get_current() const;
    const Base::Trackst& get_tst() const;
    const Spatchset::Patchdata& get_current_patch() const;
    const Icurve::On_focus_out& get_on_focus_data() const;
    
protected:
    // Constructor
    Patchset(const Tpatchset& sp0, Base::Patchid& last_achieved0, 
            Uint16 id0, Prjtype prj0, Uint16 prj_allowed_msk0,
            Airframe_action_wp_publish& aac_publish0);
    
    // Internal methods
    void set_patch_changed();
    void set_current_patch(const int16 idx);
    void refresh_current();
    void refresh_first();
    
private:
    // Helper class for finding closest patch
    class Findclosest {
        // Implementation details
    };
    
    // Member variables
    Base::Patchid& last_achieved;
    Base::Trackst tst;
    Spatchset syncps;
    Gcurve current_curve;
    Prjtype prj;
    const Uint16 prj_allowed_msk;
    bool patch_changed;
    Icurve::On_focus_out of_out;
    Findclosest find_closest;
    Airframe_action_wp_publish& aac_publish;
};
```

### 1.2 Spatchset Class

The `Spatchset` class provides thread-safe access to patch data, protecting against concurrent modifications:

```cpp
class Spatchset {
public:
    // Data structure for consistent patch information
    struct Patchdata {
        bool enabled;
        Uint16 idx;
        int16 next;
        Base::Fid f0;
        Patch_cfg cfg;
        Base::Fid next_f0;
        Base::Optional<Airframe_action_wp_data> aac_wp;
        
        Patchdata();
        bool has_next() const;
    };
    
    explicit Spatchset(const Tpatchset& ps0);
    
    // Thread-safe access methods
    int16 set_curve_safe(const int16 patch_idx);
    const Patchdata& get_curve_safe() const;
    Uint32 get_num_patches() const;
    
private:
    const Tpatchset& ps;
    Patchdata pd_cache;
};
```

### 1.3 Tpatchset Class

The `Tpatchset` class stores the serializable data for a complete set of patches (route):

```cpp
struct Tpatchset {
public:
    static const Uint16 no_next = 0xFFFF;
    static const Uint16 max_cset_elems = 20U;
    
    // Constructor
    Tpatchset(const Base::Fid f0, const Base::Fid fz,
             const Uint16 max_loi_wps = 0U,
             const Uint16 max_aac_wps = 0U,
             const Uint16 max_vsp_wps = 0U,
             const Uint16 max_cont_wps = 0U);
    
    // Patch creation methods
    void set_point(const Uint16 i, const Base::Feature p0, 
                  const Uint16 next, const Speed_cfg& speed_cfg);
    void set_line(const Uint16 i, const Base::Feature from, 
                 const Uint16 next, const Speed_cfg& speed_cfg);
    void set_orthodrome(const Uint16 i, const Base::Feature from, 
                       const Uint16 next, const Speed_cfg& speed_cfg);
    void set_arc(const Uint16 i, const Base::Feature from, 
                const Real rk0, const Real rk1, const Uint16 nturns0, 
                const Uint16 next, const Speed_cfg& speed_cfg);
    void set_ellipse(const Uint16 i, const Base::Feature center, 
                    const Base::Polarparams::Turn_direction turn0, 
                    const Real rotation0, const Real a0, const Real b0, 
                    const Speed_cfg& speed_cfg);
    void set_stanag_wp(const Uint16 i, const Base::Feature from, 
                      const Uint16 next, const Wp_altitude& altitude, 
                      const Speed_cfg& speed_cfg, const UA_pos_wp_data& pos_wp);
    
    // Waypoint data methods
    bool set_wp_loiter(const Uint16 i, const Stanag::UA_loiter_wp_data& loi);
    bool set_wp_airframe_action(const Uint16 i, const Airframe_action_wp_data& aac);
    bool set_wp_vehicle_spec(const Uint16 i, const Vehicle_spec_wp_data& vsp);
    bool set_wp_contingency(const Uint16 i, const Def_contingency_data& dcd);
    void get_wp_airframe_action(const Uint16 i, Base::Optional<Airframe_action_wp_data>& aac) const;
    
    // Route management
    void set_first(const int16 first0);
    int16 get_first() const;
    void clear_masks();
    void update_feature(const Uint16 i, const Base::Feature p0);
    
private:
    Base::Dsync sync;
    int16 first;
    Base::Tunarray_async<Patch, true> patches;
    
    Base::Tunarray<Stanag::UA_loiter_wp_data> loi_wps;
    Base::Tunarray<Airframe_action_wp_data> aac_wps;
    Base::Tunarray<Vehicle_spec_wp_data> vsp_wps;
    Base::Tunarray<Def_contingency_data> cont_wps;
    
    friend class Spatchset;
    friend class Tunpatchset;
    friend class Altitude_updater;
};
```

### 1.4 Tunpatchset Class

The `Tunpatchset` class handles serialization and deserialization of patchset data:

```cpp
class Tunpatchset {
public:
    explicit Tunpatchset(Tpatchset& ps0);
    
    // Serialization methods
    Base::Async_sres cset(Base::Lossy_error& str);
    Base::Async_sres cget(Base::Lossy& str) const;
    
private:
    Tpatchset& ps;
    
    // Asynchronous states
    enum Astate {
        ast_first,
        ast_patches,
        ast_validate
    };
    Astate ast;
    Uint16 curr_validation_idx;
    
    Base::Async_sres validate(Base::Error& err);
};
```

### 1.5 Patch Class

The `Patch` class represents an individual path segment in a route:

```cpp
struct Patch {
public:
    static const int16 next_null = -1;
    
    Bsp::Hfvar idx;      // Handler for starting waypoint
    int16 next;          // Next patch
    Patch_cfg cfg;       // Configuration of the patch
    
    explicit Patch(const Base::Fid idx0);
    
    bool has_next() const;
    bool needs_next() const;
    
    void cset(Base::Lossy_error& str);
    void cget(Base::Lossy& str) const;
};
```

### 1.6 Patch_cfg Class

The `Patch_cfg` class defines the configuration for a patch:

```cpp
struct Patch_cfg {
    enum Type {
        p_point      = 0,  // Point type
        p_line       = 1,  // Line type (also Stanag)
        p_orthodrome = 2,  // Orthodrome type
        p_arc        = 3,  // Arc type
        p_ellipse    = 4   // Ellipse type
    };
    static const Uint16 n_types = 5U;
    
    union Type_cfg {
        Arcparams arc;
        Ellipseparams ellipse;
        Stanag_params stanag;
    };
    
    Wp_altitude altitude;
    Speed_cfg speed_cfg;
    Type type;
    Type_cfg type_cfg;
    
    void cset(Base::Lossy_error& str);
    void cget(Base::Lossy& str) const;
};
```

## 2. Patch Types and Geometry

The Patchset system supports five different types of path segments:

### 2.1 Point Patch (p_point)

A simple waypoint with no inherent path. Used primarily as:
- Endpoints for other patch types
- Starting points for ellipses
- Hover points

```
    *
   Point
```

### 2.2 Line Patch (p_line)

A straight line between two waypoints in a flat Earth model:

```
    *-----------*
   Start       End
```

### 2.3 Orthodrome Patch (p_orthodrome)

A great circle path between two waypoints, accounting for Earth's curvature:

```
    *~~~~~~~~~~~*
   Start       End
```

### 2.4 Arc Patch (p_arc)

A curved path defined by:
- Starting point
- Control point parameters (rk0, rk1)
- Number of turns (nturns)
- Ending point

```
      *
     /
    /
   *     *
  Start  End
```

### 2.5 Ellipse Patch (p_ellipse)

An elliptical path defined by:
- Center point
- Turn direction (clockwise/counterclockwise)
- Rotation angle
- Semi-major axis (a)
- Semi-minor axis (b)

```
      *
     / \
    *   *
     \ /
      *
```

## 3. Projection Types

The Patchset system supports three different projection modes for calculating the vehicle's position relative to the path:

### 3.1 3D Projection (prj_3d)

- Projects the vehicle's 3D position onto the path
- Considers full 3D distance
- Used for accurate altitude tracking

### 3.2 2D Projection (prj_2d)

- Projects the vehicle's 2D position onto the path
- Ignores altitude differences
- Used when horizontal tracking is more important than vertical

### 3.3 2.5D Projection (prj_2d5)

- Projects the vehicle's 3D position onto the path
- Uses 2D distance for projection calculation
- Combines aspects of both 2D and 3D projection

## 4. Key Workflows

### 4.1 Navigating a Route

1. **Route Initialization**:
   - A `Tpatchset` is created with patch data
   - A `Patchset` is created to manage navigation
   - The first patch is set as the current patch

2. **Current Patch Validation**:
   ```cpp
   bool Patchset::current_check() {
       // On first load or if current patch deleted, select patch configured as first
       if(!syncps.get_curve_safe().enabled) {
           set_current_patch(tst.current.patch_id);
       }
       return syncps.get_curve_safe().enabled;
   }
   ```

3. **Path Computation**:
   ```cpp
   void Patchset::path_compute(const Patchsetcfg& pcfg,
                              const Geo::Apos& pos,
                              Maverick::Irvector3& d,
                              Maverick::Irvector3& t) {
       if(current_curve.g_curve) {
           if(prj==prj_3d) {
               current_curve.g_curve->compute(pos,d,t,tst.cst);
           }
           else { // 2D, 2.5D
               current_curve.g_curve->compute2d(pos,d,t,tst.cst);
           }
       }
   }
   ```

4. **Patch Transition**:
   ```cpp
   bool Patchset::flyto_next() {
       last_achieved = tst.current;
       bool result = syncps.get_curve_safe().has_next();
       if(result) {
           result = flyto(syncps.get_curve_safe().next);
           if (tst.current.patch_id == tst.lap_start_pt) {
               ++tst.current_lap;
           }
       }
       return result;
   }
   ```

5. **Route Completion Check**:
   ```cpp
   bool Patchset::is_finished() const {
       const Spatchset::Patchdata& curve = syncps.get_curve_safe();
       return (tst.cst.is_achieved() && (!curve.has_next())) || 
              (curve.cfg.type == Patch_cfg::p_ellipse);
   }
   ```

### 4.2 Finding the Closest Patch

The `Findclosest` inner class implements an iterative algorithm to find the closest patch to the vehicle's current position:

1. **Initialization**:
   ```cpp
   Patchset::Findclosest::Findclosest(const Tpatchset& ps0, const Prjtype& prj0) :
       syncps(ps0),
       prj(prj0),
       scan_idx(0),
       work_min_dist2(Const::MAX),
       work_closest_patch_idx(-1),
       min_dist2(Const::MAX),
       closest_patch_idx(-1)
   {
   }
   ```

2. **Iterative Computation**:
   ```cpp
   void Patchset::Findclosest::compute_closest(const Geo::Apos& pos) {
       // Scan closest patch (one patch per step)
       if (syncps.set_curve_safe(scan_idx) == scan_idx) {
           const Spatchset::Patchdata& pdata = syncps.get_curve_safe();
           ccurve.set(pdata);
           if (pdata.enabled && ccurve.g_curve) {
               Maverick::Rvector3 d;
               Maverick::Rvector3 t;
               Base::Curvst cst;
               if (prj==prj_3d) {
                   ccurve.g_curve->compute(pos,d,t,cst);
               }
               else { // 2D, 2.5D
                   ccurve.g_curve->compute2d(pos,d,t,cst);
               }
               push(d.norm22xy(), pdata.has_next() ? pdata.next : scan_idx);
           }
       }
       
       // Increase index for next iteration
       scan_idx++;
       if (scan_idx >= syncps.get_num_patches()) {
           flush();
           scan_idx = 0;
       }
   }
   ```

3. **Flying to Closest Patch**:
   ```cpp
   Real Patchset::flyto_closest() {
       flyto(find_closest.get_closest_patch_idx());
       return find_closest.get_mindist2();
   }
   ```

### 4.3 Setting the Current Patch

The `set_current_patch` method handles patch selection and associated actions:

```cpp
void Patchset::set_current_patch(const int16 idx) {
    // Reset curve state
    tst.cst.reset();
    
    // Set patch ID and refresh
    tst.current.patch_id = idx;
    refresh_current();
    
    // Skip point patches that have a next patch
    if ((syncps.get_curve_safe().cfg.type == Patch_cfg::p_point) &&
        (syncps.get_curve_safe().has_next())) {
        tst.current.patch_id = syncps.get_curve_safe().next;
        refresh_current();
    }
    
    // Execute airframe actions if present
    if (syncps.get_curve_safe().aac_wp.is_present()) {
        aac_publish.publish(syncps.get_curve_safe().aac_wp.value);
    }
}
```

### 4.4 Thread-Safe Patch Access

The `Spatchset::set_curve_safe` method ensures consistent patch data access even during concurrent modifications:

```cpp
int16 Spatchset::set_curve_safe(const int16 patch_idx) {
    // Create reader to detect changes in sync
    Base::Dsync::Reader rd(ps.sync);
    
    // Create local patch data
    Patchdata pd;
    
    // Set patch index
    pd.idx = ps.patches.is_enabled(patch_idx) ? patch_idx : ps.first;
    
    // Set enabled flag
    pd.enabled = ps.patches.is_enabled(pd.idx);
    
    // If enabled, copy patch data
    if (pd.enabled) {
        const Patch& p = ps.patches[pd.idx];
        
        // Copy patch data
        pd.f0 = p.idx.get_id();
        pd.cfg = p.cfg;
        
        // Set next patch
        pd.next = (p.has_next() && ps.patches.is_enabled(p.next)) ? 
                  p.next : Patch::next_null;
        
        // Handle next patch data
        if (pd.has_next()) {
            pd.next_f0 = ps.patches[pd.next].idx.get_id();
            ps.get_wp_airframe_action(pd.next, pd.aac_wp);
        }
        else {
            // If patch requires next but doesn't have one, change to point
            if (p.needs_next()) {
                pd.cfg.type = Patch_cfg::p_point;
            }
            pd.aac_wp.clear();
        }
    }
    
    // Update cache if data was not modified during read
    if (rd.is_valid()) {
        pd_cache = pd;
    }
    
    return pd_cache.idx;
}
```

### 4.5 Patchset Validation

The `Tunpatchset::validate` method ensures the consistency of a deserialized patchset:

```cpp
Base::Async_sres Tunpatchset::validate(Base::Error& str) {
    static const Uint16 max_validation_steps = 20;
    Base::Async_sres res = Base::asyncs_ongoing;
    const Uint16 psz = ps.patches.size();
    const Uint16 max = Rfun::min<Uint16>(curr_validation_idx + max_validation_steps, psz);
    
    // Validate patches
    bool enabled_patches_found = false;
    while (curr_validation_idx < max) {
        if (ps.patches.is_enabled(curr_validation_idx)) {
            enabled_patches_found = true;
            const Patch& pch = ps.patches[curr_validation_idx];
            
            // Next patch shall be enabled
            if (pch.has_next()) {
                str.assrt(ps.patches.is_enabled(pch.next), Base::err_tunpatchset1);
                
                // Points should only lead to ellipses
                if (pch.cfg.type == Patch_cfg::p_point) {
                    str.assrt(ps.patches[pch.next].cfg.type == Patch_cfg::p_ellipse, 
                             Base::err_tunpatchset3);
                }
                
                // Ellipses should not have next patches
                str.assrt(pch.cfg.type != Patch_cfg::p_ellipse, Base::err_tunpatchset4);
            }
            
            // Patch type must be valid
            str.assrt(pch.cfg.type < Patch_cfg::n_types, Base::err_tunpatchset2);
        }
        ++curr_validation_idx;
    }
    
    // First patch must be enabled if any patches are enabled
    if (enabled_patches_found) {
        str.assrt(ps.patches.is_enabled(ps.first), Base::err_tunpatchset0);
    }
    
    // Return done when all patches validated
    if(curr_validation_idx >= psz) {
        res = Base::asyncs_done;
    }
    
    return res;
}
```

## 5. Patchsets Class: Route Management

The `Patchsets` class manages different types of routes for various flight phases:

```cpp
class Patchsets {
public:
    Patchsets(Media::Cfgmgr& cfg,
             const Vpunav& uav0,
             Tpatchset& route0,
             Guidance& guid0,
             Track& track0,
             Base::Patchid& last_achieved0,
             Airframe_action_wp_publish& aac_publish0);
    
    bool fly_to_wp(const int16 wp);
    void set_cane(const Loiter_data& data);
    void set_hover(const Hover_data& data);
    void set_speed_cmd(const Speedcmd& cmd);
    Gtrack& get_patchset(const Uint16 id);
    
private:
    Approach approach;           // Set of curves for landing
    Climb climb_set;             // Set of curves for climbing
    Route route;                 // Set of curves for cruise
    Taxi curv_taxi;              // Set of curves for taxi
    Vtol set_vtol;               // Set of curves for VTOL
    Rendezvous rendezvous;       // Set of curves for rendezvous
    
    Gtrack landing;              // Gtrack for landing
    Gtrack climbing;             // Gtrack for climbing
    Gtrack cruise;               // Gtrack for cruise
    Gtrack taxiing;              // Gtrack for taxiing
    Gtrack vtoling;              // Gtrack for vtoling
    Gtrack rendezvousing;        // Gtrack for rendezvousing
    
    Base::Suiteref<Gtrack,Track::ps_detour> gtracks;  // Set of Gtracks
};
```

The constructor initializes all route types and registers them with the configuration manager:

```cpp
Patchsets::Patchsets(Media::Cfgmgr& cfg,
                    const Vpunav& uav0,
                    Tpatchset& route0,
                    Guidance& guid0,
                    Track& track0,
                    Base::Patchid& last_achieved0,
                    Airframe_action_wp_publish& aac_publish0) :
    approach(uav0, last_achieved0, aac_publish0),
    climb_set(uav0, last_achieved0, aac_publish0),
    route(route0, uav0, last_achieved0, aac_publish0),
    curv_taxi(uav0, last_achieved0, aac_publish0),
    set_vtol(uav0, last_achieved0, aac_publish0),
    rendezvous(uav0, last_achieved0, aac_publish0),
    landing(approach, track0, uav0, guid0),
    climbing(climb_set, track0, uav0, guid0),
    cruise(route, track0, uav0, guid0),
    taxiing(curv_taxi, track0, uav0, guid0),
    vtoling(set_vtol, track0, uav0, guid0),
    rendezvousing(rendezvous, track0, uav0, guid0),
    gtracks(landing, climbing, cruise, taxiing, vtoling, rendezvousing)
{
    // Register commands and PDIs with configuration manager
    cfg.add_cmd(Base::Cfg::cfg_cmd_flyto, cruise.get_flyto_operation_cmd_tun());
    cfg.add_cmd(Base::Cfg::cfg_cmd_flyto_setup, cruise.get_flyto_setup_cmd_tun());
    cfg.add_cmd(Base::Cfg::cfg_cmd_lndget, approach.get_cmd_lndget());
    cfg.add_cmd(Base::Cfg::cfg_cmd_cmbget, climb_set.get_cmd_cmbget());
    cfg.add_cmd(Base::Cfg::cfg_cmd_rdvzget, rendezvous.get_cmd_rdvzget());
    cfg.add_cmd(Base::Cfg::cfg_cmd_taxiget, curv_taxi.get_cmd_taxiget());
    cfg.add_cmd(Base::Cfg::cfg_cmd_vtolget, set_vtol.get_cmd_vtolget());
    cfg.add(Base::Cfg::cfg_troute, route);
    cfg.add(Base::Cfg::cfg_flyto_setup_map, cruise.get_flyto_setup_map());
    cfg.add(Base::Cfg::cfg_oprwy, Geo::Rwymgr::get_instance());
}
```

## 6. Integration with Airframe Actions

The Patchset system integrates with airframe actions through the `Airframe_action_wp_publish` class:

1. **Storing Airframe Actions**:
   ```cpp
   bool Tpatchset::set_wp_airframe_action(const Uint16 i, const Airframe_action_wp_data& aac) {
       bool ret = false;
       if ((i < patches.size()) && aac.validate()) {
           const Base::Optional<Uint16> first_disabled_idx = aac_wps.find_first_disabled();
           if (first_disabled_idx.present) {
               aac_wps.set_enabled(first_disabled_idx.value, true);
               aac_wps[first_disabled_idx.value] = aac;
               patches[i].cfg.type_cfg.stanag.aac_wp_idx = first_disabled_idx.value;
               ret = true;
           }
       }
       return ret;
   }
   ```

2. **Retrieving Airframe Actions**:
   ```cpp
   void Tpatchset::get_wp_airframe_action(const Uint16 i, 
                                         Base::Optional<Airframe_action_wp_data>& aac) const {
       const Uint16 idx = patches[i].cfg.type_cfg.stanag.aac_wp_idx;
       aac.present = (i < patches.size()) &&
                    (idx != Stanag_params::disabled_idx) &&
                    (aac_wps.is_enabled(idx));
       if (aac.present) {
           aac.value = aac_wps[idx];
       }
   }
   ```

3. **Executing Airframe Actions**:
   ```cpp
   void Patchset::set_current_patch(const int16 idx) {
       // ... other code ...
       
       // Execute airframe actions if present
       if (syncps.get_curve_safe().aac_wp.is_present()) {
           aac_publish.publish(syncps.get_curve_safe().aac_wp.value);
       }
   }
   ```

## 7. Patchsetcfg: Configuration Interface

The `Patchsetcfg` class provides a generic interface for patch-specific configuration:

```cpp
class Patchsetcfg {
public:
    // Returns the typed pointer to a concrete patchset configuration
    template <typename T>
    const T* get() const;

protected:
    template <typename T>
    explicit Patchsetcfg(const T& param);
    ~Patchsetcfg();

private:
    const void* p;
    const Uint16 type;
};
```

This allows different patch types to have specialized configuration parameters while maintaining a common interface.

## 8. Summary

The Patchset system in the VPGNC framework provides a comprehensive solution for managing navigation routes composed of connected path segments. Key features include:

1. **Flexible Path Types**: Support for points, lines, orthodromes, arcs, and ellipses
2. **Multiple Projection Modes**: 2D, 3D, and 2.5D projections for different navigation needs
3. **Thread-Safe Access**: Protection against concurrent modifications
4. **Closest Path Finding**: Ability to find and navigate to the closest path segment
5. **Airframe Action Integration**: Support for executing actions at waypoints
6. **Specialized Route Types**: Different route types for various flight phases (cruise, landing, climbing, etc.)
7. **Validation**: Comprehensive validation of route consistency

The system's modular design allows for efficient navigation along complex routes while maintaining thread safety and data consistency.