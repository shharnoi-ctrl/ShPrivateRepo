# Generated from:

- Amazon-PrimeAir/items/ASTRO/items/sw/sw_vbootloader_astro/code/03_Bootloader_Core.md (4045 tokens)
- Amazon-PrimeAir/items/ASTRO/items/sw/sw_vbootloader_astro/code/02_Memory_Layout_Configuration.md (3308 tokens)
- Amazon-PrimeAir/items/ASTRO/items/sw/sw_vbootloader_astro/code/02_Hardware_Abstraction_Layer.md (5008 tokens)
- Amazon-PrimeAir/items/ASTRO/items/sw/sw_vbootloader_astro/code/02_Build_System_Configuration.md (2587 tokens)
- Amazon-PrimeAir/items/ASTRO/items/sw/sw_vbootloader_astro/code/02_Testing_Framework.md (3711 tokens)

---

# Astro Bootloader System Architecture Overview

## 1. System Architecture Overview

The Astro bootloader is a sophisticated dual-core bootloader system designed for the TI TMS320F2838x microcontroller, which features a C28x DSP (CPU1) and an ARM Cortex-M (CM) core. The bootloader provides a secure, reliable mechanism for initializing the system, verifying and loading application firmware, and supporting firmware updates across both processor cores.

### 1.1 Core Architecture Components

The bootloader architecture consists of the following major components:

1. **Dual-Core Bootloader Implementation**
   - CPU1 (C28x DSP) bootloader: Primary bootloader that initializes the system
   - CM (ARM Cortex-M) bootloader: Secondary bootloader that handles communication tasks

2. **Memory Management System**
   - Separate memory spaces for each core with defined boundaries
   - Shared memory regions for inter-processor communication
   - Flash memory partitioning for bootloader and application code

3. **Hardware Abstraction Layer (HAL)**
   - Peripheral interface abstraction
   - GPIO configuration system
   - System identity determination

4. **Security Framework**
   - Secure boot implementation with ECDSA signature verification
   - Device Control Security Module (DCSM) integration
   - Secure CAN communication

5. **Communication Interfaces**
   - SPI for flash memory access
   - CAN for bootloader commands and firmware updates
   - Ethernet (on CM core) for network communication
   - Inter-processor communication mechanisms

6. **File System Support**
   - DFS2 file system for flash storage
   - Partition management for firmware storage

## 2. Boot Sequence and Initialization

### 2.1 System Startup Flow

The boot sequence follows these steps:

1. **CPU1 Bootloader Initialization**
   - CPU1 bootloader starts execution from flash address 0x80000 (word addressing)
   - Verifies bootloader header integrity
   - Initializes hardware peripherals (GPIO, SPI, CAN)
   - Configures memory layout and shared memory regions

2. **System Identity Determination**
   - Reads hardware configuration pins to determine:
     - Application type (Monitor, Recovery with Navigation, Recovery with Control)
     - Hardware version
     - Node ID for network communication

3. **CM Core Initialization**
   - CPU1 initializes shared memory with configuration data (UID, IP address, MAC address)
   - CPU1 boots the CM core with a bootloader command
   - CM bootloader starts execution from flash address 0x200000 (byte addressing)
   - CM reads configuration from shared memory
   - CM initializes Ethernet interface

4. **Application Verification and Loading**
   - Both bootloaders check for valid application images in their respective memory regions
   - Verify signatures and integrity of application images
   - If valid, load and execute applications; otherwise, remain in bootloader mode

### 2.2 Inter-Core Communication

The bootloader implements a robust inter-core communication mechanism:

1. **Shared Memory Regions**
   - CPU1 to CM: CPUTOCMRAM (0x039000-0x039800)
   - CM to CPU1: CMTOCPU1MSGRAM (0x20082000-0x20083000)

2. **Shared Data Structure**
   - `CPU1_CM_shared` structure contains:
     - Device UID and system address
     - Ethernet MAC address and IP configuration
     - Communication ports
     - Heartbeat LED configuration

3. **IPC Commands**
   - Commands sent between cores using IPC mechanisms
   - Boot commands to control core startup
   - Status information exchange

## 3. Memory Architecture

### 3.1 Memory Layout

The memory architecture is carefully designed to accommodate both cores with their different addressing schemes:

#### CPU1 (C28x) Memory Map (16-bit word addressing)
- **Flash Memory**: 0x080000-0x0C0000
  - Bootloader: 0x080000-0x090000 (0x10000 words)
  - Application: 0x090000-0x0C0000 (0x30000 words)
- **RAM Regions**:
  - RAMM_DAT: 0x000140-0x000800
  - RAML: 0x008000-0x00D000
  - RAMS: 0x00D000-0x01D000
  - RAMFUNCS: 0x01D000-0x01D7C0 (functions running from RAM)
- **IPC Memory**:
  - CMTOCPURAM: 0x038000-0x038800
  - CPUTOCMRAM: 0x039000-0x039800

#### CM (Cortex-M) Memory Map (8-bit byte addressing)
- **Flash Memory**: 0x200000-0x280000
  - Bootloader: 0x200000-0x220000 (0x20000 bytes)
  - Application: 0x220000-0x250000 (0x30000 bytes)
- **RAM Regions**:
  - C1RAM: 0x1FFFC000-0x1FFFE000 (8KB)
  - C0RAM: 0x1FFFE000-0x20000000 (8KB)
  - ESRAM: 0x20000100-0x20014000
- **IPC Memory**:
  - CPU1TOCMMSGRAM: 0x20080000-0x20081000
  - CMTOCPU1MSGRAM: 0x20082000-0x20083000

### 3.2 Memory Section Allocation

The bootloader uses specific memory section allocations for optimal performance:

1. **Code Sections**
   - `.text`, `.cinit`, `.pinit`, `.switch`, `.const`: Placed in flash memory
   - `.resetisr`, `.vftable`: Special sections for reset vectors and interrupt tables

2. **Data Sections**
   - `.stack`: Placed in local RAM (RAML for CPU1, C0RAM for CM)
   - `.data`, `.bss`: Placed in appropriate RAM regions
   - `.sysmem`: System memory placed in RAM

3. **Special Sections**
   - `.TI.ramfunc`: Functions that run from RAM for better performance
   - `SHARED_RAM`: Shared data between CPU1 and CM
   - `MEMMGR_INT` and `MEMMGR_EXT`: Memory manager sections

## 4. Hardware Abstraction Layer

### 4.1 Peripheral Interface Abstraction

The HAL provides a clean interface to hardware peripherals:

1. **SCI (Serial Communication Interface)**
   - Four SCI ports (A, B, C, D) with configurable pins
   - Periodic processing through the `step_hi()` method

2. **CAN (Controller Area Network)**
   - Three CAN interfaces: CAN-A, CAN-B, and CAN-FD
   - Transmission timeout checking
   - Secure CAN configuration with transceiver control

3. **SPI (Serial Peripheral Interface)**
   - SPI-C interface for flash memory communication
   - Configurable speed, data width, and mode

4. **GPIO (General Purpose Input/Output)**
   - Comprehensive GPIO configuration system
   - Pin multiplexing for various functions
   - Core assignment for GPIO control

### 4.2 System Identity Determination

The HAL includes a system for determining device identity:

1. **Hardware Configuration Pins**
   - GPIO pins for hardware revision detection (4-bit value)
   - Configuration pins for application type determination

2. **Application Types**
   - Monitor (sapp_pam): Node ID 22
   - Recovery with Navigation (sapp_par_nav): Node ID 28
   - Recovery with Control (sapp_par_ctrl): Node ID 31

3. **Hardware Revisions**
   - EV1: 0x01
   - EV1_RES: 0x02
   - EV2: 0x05
   - DV1: 0x11

### 4.3 Ethernet Configuration

The CM core includes Ethernet support with:

1. **MII Interface Configuration**
   - Complete pin mapping for Ethernet MII interface
   - MDIO, data, control, and clock signals

2. **Network Configuration**
   - MAC address derived from device UID
   - IP address and network mask configuration
   - Communication ports for different protocols

## 5. Security Framework

### 5.1 Secure Boot Implementation

The bootloader implements secure boot mechanisms:

1. **ECDSA Signature Verification**
   - Verification of application signatures before loading
   - Rejection of applications with invalid signatures

2. **Device Control Security Module (DCSM)**
   - Security zone configuration
   - Security key management
   - JTAG access control

3. **Binary Integrity Verification**
   - CRC32 checksum verification
   - Header schema validation
   - Core binary verification

### 5.2 Secure CAN Communication

The bootloader implements secure CAN communication:

1. **Transceiver Control**
   - GPIO pins for transceiver enable/standby control
   - Secure transceiver configuration

2. **CAN Filtering**
   - ID-based filtering for incoming messages
   - Port-specific configuration

3. **Command Authentication**
   - Verification of command sources
   - Command validation

## 6. File System and Storage

### 6.1 Flash Memory Management

The bootloader includes flash memory management:

1. **SPI Flash Interface**
   - SPI-C communication with flash memory
   - Chip select control via GPIO

2. **MX66L Flash Driver**
   - Driver for MX66L flash memory
   - Read, write, and erase operations

### 6.2 DFS2 File System

The bootloader implements the DFS2 file system:

1. **Partition Configuration**
   - Single PDIF partition with 2,000 files
   - 120 sectors per file (~117 MB total)
   - 8 sectors for file descriptors

2. **Circular Buffer Behavior**
   - Circular buffer enabled for continuous logging
   - Automatic management of oldest files

## 7. Communication Interfaces

### 7.1 CAN Communication

The bootloader implements CAN communication for commands and updates:

1. **CAN Configuration**
   - Three CAN interfaces with different roles
   - 500 Kbps standard baudrate
   - 2 Mbps data baudrate for CAN-FD

2. **Message Filtering**
   - ID-based filtering for incoming messages
   - Node ID incorporated into message IDs

3. **SerialCAN Protocol**
   - Timeout configuration for reliable communication
   - Command and response formatting

### 7.2 Ethernet Communication (CM Core)

The CM core implements Ethernet communication:

1. **LWIP Stack Integration**
   - Lightweight IP stack for network communication
   - UDP protocol support for bootloader commands

2. **Network Configuration**
   - MAC address derived from device UID
   - IP address and network mask configuration
   - Port configuration based on application type

### 7.3 Inter-Processor Communication

The bootloader implements robust IPC mechanisms:

1. **Shared Memory**
   - Dedicated regions for bi-directional communication
   - Structured data exchange

2. **Command Interface**
   - Boot commands for core control
   - Status information exchange
   - Configuration data sharing

## 8. Build and Testing System

### 8.1 Build System

The bootloader uses a sophisticated build system:

1. **JSON-Based Configuration**
   - Hierarchical configuration files
   - Support for multiple targets and platforms

2. **Dual-Core Build Support**
   - Separate builds for C28x and ARM cores
   - Shared code and libraries where appropriate

3. **Library Dependencies**
   - Core-specific libraries for each processor
   - Common libraries for shared functionality

### 8.2 Testing Framework

The bootloader includes a comprehensive testing framework:

1. **Test Plan Implementation**
   - 21 test cases covering various aspects of bootloader functionality
   - Structured approach with clear steps and verification points

2. **Binary Manipulation Tools**
   - Tools for creating corrupted or modified binaries
   - CRC32 manipulation for testing integrity checks

3. **Version Management**
   - Semantic versioning support
   - Version comparison and verification

4. **Communication Interface**
   - Interface to the embedded software updater
   - Command execution and response handling

## 9. Key Design Patterns and Architectural Decisions

### 9.1 Class Hierarchy and Inheritance

The bootloader uses a hierarchical class structure:

1. **Bootloader Base Classes**
   - `Bootloader` base class with common functionality
   - `Bootloader_dual` for dual-core management
   - `Bootloader_astro` for Astro-specific implementation

2. **Factory Method Pattern**
   - `Bootloader_dual::build` factory method for creating bootloader instances
   - Ensures single instance creation and proper initialization

### 9.2 Hardware Abstraction and Dependency Injection

The bootloader implements hardware abstraction:

1. **Interface-Based Design**
   - `Base::IAddress_handler` interface for address handling
   - `Base::Tport` template for communication port abstraction

2. **Dependency Injection**
   - Constructor-based injection of dependencies
   - Parameterized configuration for flexibility

### 9.3 Memory Management Strategy

The bootloader employs a careful memory management strategy:

1. **Different Addressing Schemes**
   - C28x uses 16-bit word addressing
   - CM uses 8-bit byte addressing
   - Conversion between schemes using templates

2. **RAM Function Execution**
   - Critical functions loaded from flash but executed from RAM
   - Improves performance for time-sensitive operations

### 9.4 Security-First Design

The bootloader prioritizes security in its design:

1. **Defense in Depth**
   - Multiple security layers (DCSM, signatures, CRC)
   - Secure communication channels

2. **Fail-Secure Approach**
   - Rejection of invalid applications
   - Secure default configurations

## 10. Conclusion

The Astro bootloader is a sophisticated dual-core bootloader system that provides secure, reliable initialization and firmware update capabilities for the TI TMS320F2838x microcontroller. Its architecture addresses the challenges of managing multiple cores with different architectures, ensuring secure boot and communication, and providing robust firmware update mechanisms.

Key strengths of the architecture include:

1. **Dual-Core Support**: Comprehensive management of both C28x and ARM cores
2. **Security Integration**: Multiple layers of security for boot and communication
3. **Flexible Communication**: Multiple interfaces for commands and updates
4. **Robust Testing**: Comprehensive testing framework for validation
5. **Hardware Abstraction**: Clean interfaces to hardware peripherals
6. **Memory Management**: Careful handling of different addressing schemes
7. **Inter-Core Communication**: Robust mechanisms for core coordination

This architecture provides a solid foundation for the Astro platform, ensuring reliable operation and secure updates throughout the system's lifecycle.