# Generated from:

- _sw_Veronte/code/vblocks/code/include/Blk_varget.h (1453 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_varset.h (980 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_varset.cpp (tokens unknown)
- _sw_Veronte/code/vblocks/code/include/Blk_mult_varget.h (1797 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_mult_varset.h (1481 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_not.h (562 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_not.cpp (138 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_siggen.h (685 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_siggen.cpp (930 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_clock.h (788 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_clock.cpp (669 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_ramp.h (753 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_ramp.cpp (707 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_scheduler.h (772 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_scheduler.cpp (628 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_phase.h (601 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_phase.cpp (449 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_sysid.h (549 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_sysid.cpp (683 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_compiled.h (525 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_compiled.cpp (503 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_genex.h (291 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_genex.cpp (554 tokens)

## With context from:

- PackageSummaries/Embention/Amazon-PrimeAir/items/ASTRO/items/sw/sw_Astro/items/04_VBlocks_Core.md (5729 tokens)

---

# VBlocks Library: Utility and Helper Blocks

This document provides a comprehensive analysis of the utility and helper blocks in the VBlocks library, focusing on how they provide common functionality for system development. These blocks serve as fundamental building blocks for creating more complex control systems.

## 1. Variable Access Blocks

The VBlocks library provides blocks for getting and setting system variables of different types. These blocks allow reading from and writing to system variables that can be used across the entire system.

### 1.1 Variable Getter Blocks

#### 1.1.1 `Blk_varget` - System Variable Retriever

```cpp
template <typename VARTYPE, typename VARID, typename VARHANDLER>
class Blk_varget : public Blocks::Iblock
```

This templated class provides functionality to read values from system variables:

- **Purpose**: Retrieves values from system variables to be used by other blocks
- **Template Parameters**:
  - `VARTYPE`: Type of the variable (Real, Uint16, bool)
  - `VARID`: Enumeration type for variable identifiers
  - `VARHANDLER`: Handler class for accessing variables

**Key Methods**:
- `step()`: Reads the current value from the system variable into the output buffer
- `get_out(Uint16 i)`: Returns a pointer to the output pin if i=0, null otherwise
- `cset(Base::Lossy_error& str, Blocks::Iblock::Csetpm& params)`: Deserializes configuration from PDI, setting up the connection to the system variable

**PDI Structure**:
```
Type    | Name | Content           | Range
--------|------|-------------------|------------------
Uint16  | id   | Variable identifier| Valid identifiers
```

**Common Specializations**:
- `Blk_rvarget`: Real variable getter
- `Blk_uvarget`: Uint16 variable getter
- `Blk_bvarget`: Boolean variable getter

#### 1.1.2 `Blk_mult_varget` - Multiple System Variable Retriever

```cpp
template <typename VARTYPE, typename VARID, typename VARHANDLER>
class Blk_mult_varget: public Blocks::Iblock
```

This block reads a set of consecutive system variables and outputs them as a single vector:

- **Purpose**: Retrieves multiple consecutive system variables in a single operation
- **Template Parameters**: Same as `Blk_varget`

**Key Methods**:
- `step()`: Copies a block of consecutive system variables into the output vector
- `get_out(Uint16 i)`: Returns a pointer to the output vector if i=0, null otherwise
- `cset(Base::Lossy_error& str, Iblock::Csetpm& params)`: Deserializes configuration and sets up connections to the system variables

**PDI Structure**:
```
Type    | Name | Content                   | Range
--------|------|---------------------------|------------------
Uint16  | id   | Start variable identifier | Valid identifiers
Uint16  | n    | Number of variables       | [1-32]
```

**Common Specializations**:
- `Blk_mult_rvarget`: Multiple real variable getter

### 1.2 Variable Setter Blocks

#### 1.2.1 `Blk_varset` - System Variable Setter

```cpp
template <typename VARTYPE, typename VARID, typename VARHANDLER>
class Blk_varset : public Blocks::Iblock
```

This templated class provides functionality to write values to system variables:

- **Purpose**: Writes input values to system variables
- **Template Parameters**: Same as `Blk_varget`

**Key Methods**:
- `step()`: Writes the input value to the system variable
- `cset(Base::Lossy_error& str, Blocks::Iblock::Csetpm& params)`: Deserializes configuration and sets up connections

**PDI Structure**:
```
Type        | Name | Content           | Range
------------|------|-------------------|------------------
Pin_address | in   | Input address     | -
Uint16      | id   | Variable identifier| Valid identifiers
```

**Common Specializations**:
- `Blk_rvarset`: Real variable setter
- `Blk_uvarset`: Uint16 variable setter
- `Blk_bvarset`: Boolean variable setter

#### 1.2.2 `Blk_mult_varset` - Multiple System Variable Setter

```cpp
template <typename VARTYPE, typename VARID, typename VARHANDLER>
class Blk_mult_varset : public Blocks::Iblock
```

This block writes a vector of values to a set of consecutive system variables:

- **Purpose**: Writes multiple consecutive system variables in a single operation
- **Template Parameters**: Same as `Blk_varget`

**Key Methods**:
- `step()`: Copies the input vector to a block of consecutive system variables
- `cset(Base::Lossy_error& str, Blocks::Iblock::Csetpm& params)`: Deserializes configuration and sets up connections

**PDI Structure**:
```
Type        | Name | Content                   | Range
------------|------|---------------------------|------------------
Pin_address | in   | Input address             | -
Uint16      | id   | Start variable identifier | Valid identifiers
Uint16      | n    | Number of variables       | [1-32]
```

**Common Specializations**:
- `Blk_mult_rvarset`: Multiple real variable setter
- `Blk_mult_bvarset`: Multiple boolean variable setter

## 2. Logical Operation Blocks

### 2.1 `Blk_not` - Boolean NOT Operation

```cpp
class Blk_not : public Blocks::Iblock
```

This block computes the boolean negation of its input:

- **Purpose**: Performs logical NOT operation on a boolean input
- **Inputs**: One boolean value
- **Outputs**: One boolean value (the logical negation of the input)

**Key Methods**:
- `step()`: Computes the boolean negation of the input and stores it in the output
- `get_out(Uint16 i)`: Returns a pointer to the output if i=0, null otherwise
- `cset(Base::Lossy_error& str, Csetpm& params)`: Deserializes configuration and sets up connections

**PDI Structure**:
```
Type        | Name   | Content       | Range
------------|--------|---------------|-------
Pin_address | inputs | Boolean input | -
```

**Implementation**:
```cpp
inline void Blk_not::step()
{
    out.val = !in.read();
}
```

## 3. Signal Generation Blocks

### 3.1 `Blk_siggen` - Signal Generator

```cpp
class Blk_siggen : public Blocks::Iblock
```

This block generates periodic wave signals of various types:

- **Purpose**: Generates periodic signals for testing or control purposes
- **Signal Types**:
  - Sine wave
  - Pulse (square) wave
  - Triangular wave
  - Sawtooth wave
- **Outputs**: One real value representing the generated signal

**Key Methods**:
- `on_focus()`: Called when the block becomes active, sets a flag to initialize timing
- `step()`: Generates the signal value based on the current time and configuration
- `get_out(Uint16 i)`: Returns a pointer to the output if i=0, null otherwise
- `cset(Base::Lossy_error& str, Csetpm& params)`: Deserializes configuration

**PDI Structure**:
```
Type   | Name  | Content                                | Range
-------|-------|----------------------------------------|------------------
Uint16 | type  | Type of signal                         | 0-Sine, 1-Pulse, 2-Triangle, 3-Sawtooth
Real   | f     | Signal frequency in Hertz              | >= 0
Real   | gain  | Gain (peak value) of generated signal  | -
Real   | duty  | Duty cycle (ratio of up time)          | (0,1)
```

**Implementation Details**:
- The block calculates the signal value based on the elapsed time since initialization
- For sine waves, it uses `Rmath::sinr(Const::PI2*x)`
- For pulse waves, it outputs 1.0 when x <= duty, otherwise 0.0
- For triangle waves, it implements a triangular function
- For sawtooth waves, it outputs x directly
- All outputs are scaled by the gain parameter

## 4. Timing Blocks

### 4.1 `Blk_clock` - Clock Timer

```cpp
class Blk_clock : public Blocks::Iblock
```

This block measures elapsed time:

- **Purpose**: Calculates time since last reset or between steps
- **Inputs**: Optional boolean reset input
- **Outputs**: One real value representing the elapsed time in seconds

**Key Methods**:
- `step()`: Updates the time value based on the current time and reset conditions
- `on_focus()`: Resets the clock if configured to do so
- `get_out(Uint16 i)`: Returns a pointer to the time output if i=0, null otherwise
- `cset(Base::Lossy_error& str, Csetpm& params)`: Deserializes configuration

**PDI Structure**:
```
Type        | Name           | Content                                    | Range
------------|----------------|--------------------------------------------|-----------
Pin_address | reset          | Input reset pin address                    | -
Bool16      | on_focus_reset | True if clock reset on on_focus            | [true/false]
Bool16      | period         | True if measuring time between steps       | [true/false]
```

**Implementation Details**:
- Uses a `Base::Chrono` object to track time
- Can be reset by an input signal or when `on_focus()` is called
- Can measure either:
  - Time since last reset (when period=false)
  - Time between step calls (when period=true)

### 4.2 `Blk_ramp` - Ramp Generator

```cpp
class Blk_ramp : public Blocks::Iblock
```

This block generates a ramp output signal from an initial value to a final value over a configured time:

- **Purpose**: Creates smooth transitions between values
- **Inputs**: Initial value and final value
- **Outputs**: One real value representing the current point in the transition
- **States**:
  - `fxs_init`: Initial state
  - `fxs_wait`: State before ramp starts
  - `fxs_ramp`: State during ramp transition
  - `fxs_done`: Ramp finished, final value achieved

**Key Methods**:
- `on_focus()`: Resets the ramp to its initial state
- `step()`: Updates the output value based on the current state and elapsed time
- `get_out(Uint16 i)`: Returns a pointer to the output if i=0, null otherwise
- `cset(Base::Lossy_error& str, Csetpm& params)`: Deserializes configuration

**PDI Structure**:
```
Type        | Name   | Content                  | Range
------------|--------|--------------------------|-------
Pin_address | u0_cfg | Initial value input pin  | -
Pin_address | uf     | Final output             | -
Real        | dt     | Time to wait before ramp | -
Real        | tf     | Time of ramp             | -
```

**Implementation Details**:
- Uses a `Base::Chrono` object to track time
- Can wait for a specified time before starting the ramp
- Linearly interpolates between initial and final values during the ramp period
- Maintains the final value after the ramp is complete

## 5. Advanced Utility Blocks

### 5.1 `Blk_scheduler` - Multi-Dimensional Interpolation

```cpp
class Blk_scheduler : public Blocks::Iblock
```

This block performs N-dimensional interpolation of an array of 32-bit floats:

- **Purpose**: Interpolates values from multi-dimensional tables
- **Inputs**: Interpolation point (vector of coordinates)
- **Outputs**: Interpolated data (vector of values)

**Key Methods**:
- `step()`: Performs interpolation at the current input point
- `get_out(Uint16 i)`: Returns a pointer to the interpolated data if i=0, null otherwise
- `cset(Base::Lossy_error& str, Csetpm& params)`: Deserializes configuration

**PDI Structure**:
```
Type                   | Name           | Content                                    | Range
-----------------------|----------------|--------------------------------------------|---------
Dyn_multi_interpolator | mi             | Dynamic multi interpolator instance        | -
Pin_address            | interp_point   | Input with the point for the interpolation | -
```

**Implementation Details**:
- Uses a `Dyn_multi_interpolator` to perform the actual interpolation
- The interpolation data is stored in a tunable parameter
- The input must be an array of reals with size equal to the number of dimensions
- The output is an array of interpolated values

### 5.2 `Blk_phase` - Phase-Based Execution

```cpp
class Blk_phase : public Blocks::Blk_switch0
```

This block executes different sets of blocks depending on the global "Phase" variable:

- **Purpose**: Switches between different block sets based on the current system phase
- **Inputs**: None (uses global Phase variable)
- **Outputs**: Depends on the contained blocks

**Key Methods**:
- `step()`: Executes the block set corresponding to the current phase
- `cset(Base::Lossy_error& str, Iblock::Csetpm& params)`: Deserializes configuration
- `check_num_cases(const Uint16 ncases0)`: Checks consistency of configured cases

**PDI Structure**:
```
Type              | Name    | Content                                        | Range
------------------|---------|------------------------------------------------|-------
Blocks::Switchmap | map     | Map from selection number to case number       | -
Uint16            | defcase | Default case when selection not found in map   | -
Blocks::Blk_switch0 | data  | Data of the switch                             | -
```

**Implementation Details**:
- Inherits from `Blocks::Blk_switch0` which provides the basic switching functionality
- Uses a `Blocks::Switchmap` to map from phase values to case numbers
- Reads the current phase from the system variable `Base::vu_phase`
- Executes the `on_focus` function of contained blocks when the phase changes

### 5.3 `Blk_sysid` - System Identification

```cpp
class Blk_sysid : public Blocks::Iblock
```

This block identifies the coefficients of a transfer function that represents a dynamic system:

- **Purpose**: Finds transfer function coefficients based on system inputs and outputs
- **Inputs**: System input and output signals
- **Outputs**: Numerator and denominator coefficients of the identified transfer function

**Key Methods**:
- `step()`: Updates the system identification algorithm with new input/output data
- `get_out(Uint16 i)`: Returns a pointer to either numerator (i=0) or denominator (i=1) coefficients
- `cset(Base::Lossy_error& str, Blocks::Iblock::Csetpm& params)`: Deserializes configuration

**PDI Structure**:
```
Type                  | Name                       | Content                                        |  Range
----------------------|----------------------------|------------------------------------------------|--------
Blocks::Pin_ptr<Real> | System output pin          | Output of the system to identify               |   -
Blocks::Pin_ptr<Real> | System input pin           | Input of the system to identify                |   -
Vblocks::Sysid        | System identifier wrapper  | Wrapper of the system identification algorithm |   -
```

**Implementation Details**:
- Uses the Recursive Least Squares (RLS) algorithm
- Continuously updates the transfer function coefficients as new data arrives
- Outputs the coefficients as two separate vectors (numerator and denominator)

### 5.4 `Blk_compiled` - External Compiled Code

```cpp
class Blk_compiled : public Blocks::Iblock
```

This block executes external compiled code loaded into itself:

- **Purpose**: Allows integration of externally compiled code into the block system
- **Inputs**: Defined by the external code
- **Outputs**: Defined by the external code

**Key Methods**:
- `on_focus()`: Called when the block becomes active, executes input manager step
- `step()`: Executes the external code with current inputs
- `on_blur()`: Called when the block becomes inactive, executes input manager step
- `get_out(Uint16 i)`: Returns a pointer to the specified output
- `cset(Base::Lossy_error& str, Csetpm& params)`: Deserializes configuration

**Implementation Details**:
- Uses an `Ext_block_funcs` handler to interface with the external code
- Uses `Ext_inputs_mgr` and `Ext_outputs_mgr` to manage inputs and outputs
- Provides a standardized interface for external code to interact with the block system

### 5.5 `Blk_genex` - Generalized Vector Explicit Guidance

```cpp
class Blk_genex : public Blk_pnav_base
```

This block computes proportional navigation guidance acceleration:

- **Purpose**: Provides guidance acceleration commands for achieving a desired impact direction
- **Inputs**: Target position
- **Outputs**: Acceleration commands in body axis

**Key Methods**:
- `compute_pn()`: Computes the proportional navigation guidance acceleration
- `cset(Base::Lossy_error& str, Csetpm& params)`: Deserializes configuration

**PDI Structure**:
```
Type        | Name    | Content             | Range
------------|---------|---------------------|-------
Pin_address | target  | Target position     | -
Real        | max_acc | Maximum acceleration| >0
Real        | n       | Proportional factor | >0
Rvector3    | ih      | Impact direction    | -
```

**Implementation Details**:
- Inherits from `Blk_pnav_base` which provides common navigation functionality
- Implements the Generalized Vector Explicit Guidance (GENEX) algorithm
- Calculates acceleration commands based on current position, velocity, and desired impact direction
- Uses a proportional factor `n` to adjust the guidance behavior

## 6. Cross-Component Relationships

### 6.1 Variable Access Block Relationships

The variable getter and setter blocks interact with system variables through handler classes:

```
Blk_varget/Blk_varset
       |
       v
  VARHANDLER
       |
       v
System Variables
```

These handlers (like `Bsp::Hrvar`, `Bsp::Huvar`, `Bsp::Hbvar`) provide access to the actual system variables.

### 6.2 Block Input/Output Relationships

Blocks communicate with each other through pin connections:

```
Block A
   |
   v
Pin_ptr (input)
   |
   v
Block B
```

The `Pin_ptr` class provides a mechanism for blocks to read values from other blocks' outputs.

### 6.3 Block and System Time Relationship

Timing blocks like `Blk_clock` and `Blk_ramp` interact with the system time:

```
System Time
     |
     v
Base::Chrono
     |
     v
Blk_clock/Blk_ramp
```

The `Base::Chrono` class provides a consistent interface for measuring elapsed time.

## 7. Common Implementation Patterns

### 7.1 Block Construction Pattern

Most utility blocks follow a similar construction pattern:

1. Default constructor initializes member variables
2. `cset` method deserializes configuration from PDI
3. `step` method performs the block's main functionality
4. `get_out` method provides access to the block's outputs

### 7.2 Error Handling Pattern

Blocks use a consistent error handling pattern in their `cset` methods:

1. Deserialize configuration parameters
2. Perform validation checks
3. Set up connections and allocate resources
4. Call `str.assrt()` with a boolean condition and error code

### 7.3 Template Specialization Pattern

Many blocks use template specialization to handle different data types:

```cpp
template <typename VARTYPE, typename VARID, typename VARHANDLER>
class Blk_varget { /* ... */ };

typedef Blk_varget<Real, Base::Rvar, Bsp::Hrvar> Blk_rvarget;
typedef Blk_varget<Uint16, Base::Uvar, Bsp::Huvar> Blk_uvarget;
typedef Blk_varget<bool, Base::Bvar, Bsp::Hbvar> Blk_bvarget;
```

This allows the same block implementation to work with different data types.

## 8. Referenced Context Files

The following context files provided useful information for understanding the utility blocks:

- `09_System_Architecture.md`: Provided context about the overall system architecture and how blocks fit into it

## 9. Summary

The VBlocks library provides a rich set of utility and helper blocks that serve as fundamental building blocks for creating complex control systems:

1. **Variable Access Blocks**: Allow reading from and writing to system variables
   - `Blk_varget`/`Blk_varset`: Single variable access
   - `Blk_mult_varget`/`Blk_mult_varset`: Multiple variable access

2. **Logical Operation Blocks**: Perform logical operations
   - `Blk_not`: Boolean negation

3. **Signal Generation Blocks**: Generate various types of signals
   - `Blk_siggen`: Generates sine, pulse, triangle, and sawtooth waves

4. **Timing Blocks**: Measure and control timing
   - `Blk_clock`: Measures elapsed time
   - `Blk_ramp`: Generates smooth transitions

5. **Advanced Utility Blocks**: Provide specialized functionality
   - `Blk_scheduler`: Multi-dimensional interpolation
   - `Blk_phase`: Phase-based execution
   - `Blk_sysid`: System identification
   - `Blk_compiled`: External code execution
   - `Blk_genex`: Guidance acceleration calculation

These utility blocks provide common functionality that can be reused across different applications, making system development more efficient and maintainable. They follow consistent patterns for construction, error handling, and template specialization, making them easy to understand and use.