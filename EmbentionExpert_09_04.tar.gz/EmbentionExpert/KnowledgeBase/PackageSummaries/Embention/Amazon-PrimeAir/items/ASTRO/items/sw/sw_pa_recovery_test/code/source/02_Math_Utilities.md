# Generated from:

- Math_utilities_test.cpp (6017 tokens)
- Polynomial_pa_test.cpp (1814 tokens)
- Real16_amz_test.cpp (512 tokens)
- utilities_type_conversion_test.cpp (1018 tokens)

---

# Mathematical Utility Functions Summary

This document provides a comprehensive overview of the mathematical utility functions implemented in the system, focusing on numerical operations, polynomial functions, and type conversions that support various control system calculations.

## 1. Core Mathematical Operations

### 1.1 Factorial Calculation

The system implements a factorial function in the `Rfun` namespace that calculates the factorial of unsigned integers:

```cpp
Uint32 Rfun::factorial(Uint16 n)
```

- Takes a `Uint16` input parameter (cannot be negative)
- Returns a `Uint32` result
- Correctly calculates factorials from 0! (=1) to 12! (=479001600)
- Values tested: 0! through 12!

### 1.2 Clamping and Limiting Functions

```cpp
template<typename T>
T Rfun::clamp(T value, T min, T max)
```

- Restricts a value to be within specified minimum and maximum bounds
- If value < min, returns min
- If value > max, returns max
- If min ≤ value ≤ max, returns value unchanged
- Works with floating-point values (Real type)

### 1.3 Sign Function

```cpp
Real Rfun::sign(Real value)
```

- Returns +1.0 if value ≥ 0
- Returns -1.0 if value < 0
- Special case: sign(0.0) returns +1.0

### 1.4 Arithmetic with Saturation

```cpp
Real Rfun::addWithMaxSaturation(Real a, Real b)
```

- Adds two values with saturation at maximum value
- Implementation details not fully specified in the test file

### 1.5 Trigonometric Functions with Extended Domain

```cpp
Real Rfun::asinw(Real value)
```
- Extended arc sine function that handles values outside [-1, 1]
- If value < -1.0, returns asin(-1.0)
- If value > 1.0, returns asin(1.0)
- Otherwise, returns standard asin(value)

```cpp
Real Rfun::acosw(Real value)
```
- Extended arc cosine function that handles values outside [-1, 1]
- If value < -1.0, returns acos(-1.0)
- If value > 1.0, returns acos(1.0)
- Otherwise, returns standard acos(value)

## 2. Interpolation Functions

### 2.1 Linear Interpolation Parameter

```cpp
template<typename T>
T Rfun::interpolation_parameter(T x, T x_min, T x_max)
```

- Calculates normalized position of x between x_min and x_max
- Returns 0.0 if x ≤ x_min
- Returns 1.0 if x ≥ x_max
- Returns (x - x_min) / (x_max - x_min) if x_min < x < x_max
- Special case: if x_min = x_max, returns 0.0
- Special case: if x_min > x_max, returns -1.0

### 2.2 Linear Interpolation with Clipping

```cpp
template<typename T>
T Rfun::interpolation_with_clipping(T x, T x_min, T x_max, T y_min, T y_max, T min_delta_x)
```

- Performs linear interpolation between (x_min, y_min) and (x_max, y_max)
- Clips input x to the range [x_min, x_max]
- Returns y_min if x ≤ x_min
- Returns y_max if x ≥ x_max
- Returns y_min + (x - x_min) * (y_max - y_min) / (x_max - x_min) otherwise
- Special handling when x_max and x_min are very close (within min_delta_x)
- Special handling when x_min > x_max (returns y_min)

## 3. Root Finding and Zero-Finding Algorithms

The system implements a robust scalar zero-finding algorithm through the `Maverick::Find_scalar_zero_interval` class, which is used to find roots of scalar functions.

### 3.1 Base Class Interface

```cpp
class Maverick::Find_scalar_zero_interval {
public:
    Find_scalar_zero_interval(const Real& tol_f0, const Real& tol_x0);
    virtual Real f(Real x) const = 0;
    bool find(Real x_min, Real x_max, Real& x_zero);
};
```

- Abstract base class that requires derived classes to implement the `f(x)` function
- `find` method searches for x where f(x) = 0 within the interval [x_min, x_max]
- Returns the root in the `x_zero` output parameter
- Returns boolean indicating success or failure
- Uses tolerance parameters:
  - `tol_f`: Function value tolerance (how close to zero is acceptable)
  - `tol_x`: Parameter value tolerance (how precise the x value needs to be)

### 3.2 Boundary Conditions and Edge Cases

The root-finding algorithm handles several edge cases:

1. When x_min > x_max:
   - Returns false (failure)
   - Sets x_zero to either x_min or x_max depending on implementation

2. When x_max and x_min are too close (within numerical precision):
   - Returns false (failure)
   - Sets x_zero to an approximate value

3. When the function has no zero in the interval:
   - Returns true if a boundary value is close enough to zero
   - Returns the boundary value (either x_min or x_max)

4. When the function has multiple zeros:
   - Returns the first zero found

### 3.3 Test Cases and Function Examples

The test suite includes several function implementations for testing the root-finding algorithm:

1. Simple linear functions: `f(x) = x`
2. Quadratic functions: `f(x) = -x * (x - 1.0F)`, `f(x) = x * x`, `f(x) = (x - 1.0F) * x`
3. Complex mathematical functions:
   - `f(x) = sqrt(x) - cos(x)`
   - `f(x) = 3.0 * (x + 1.0) * (x - 0.5) * (x - 1.0)`
   - `f(x) = x^3 - 7.0 * x^2 + 14.0 * x - 6.0`
   - `f(x) = exp(x) - x^2 + 3.0 * x - 2.0`
   - `f(x) = x^2 - 4.0 * x + 4 - log(x)`
   - `f(x) = PI + 5.0 * sin(x / 2) - x`
   - `f(x) = 5^(-x) - x`
   - `f(x) = 2.0 * x * cos(2.0 * x) - (x - 2)^2`

## 4. Polynomial Functions

The system implements a comprehensive polynomial class for evaluating and manipulating polynomials up to 7th degree.

### 4.1 Polynomial Class Interface

```cpp
class Polynomial {
public:
    enum class Der_coeffs { orig, d1, d2, d3, d4 };
    
    Polynomial();
    Polynomial(const Polynomial& other);
    Polynomial& operator=(const Polynomial& other);
    
    void set_coeffs(const Base::Tnarrayresz<Real, 8U>& coeffs);
    void set_initial(Real initial_value);
    bool get_valid() const;
    
    Real eval_der(Real x, Der_coeffs der) const;
    Real eval_integral_1(Real x, Real y0) const;
};
```

### 4.2 Polynomial Functionality

1. **Initialization and Configuration**:
   - Default constructor creates an invalid polynomial
   - Can be initialized with an array of 8 coefficients (for 0th to 7th degree terms)
   - Initial value (constant term) can be modified after construction
   - Copy constructor and assignment operator provided

2. **Evaluation**:
   - `eval_der(x, der)`: Evaluates the polynomial or its derivatives at point x
     - `Der_coeffs::orig`: Original polynomial p(x)
     - `Der_coeffs::d1`: First derivative p'(x)
     - `Der_coeffs::d2`: Second derivative p''(x)
     - `Der_coeffs::d3`: Third derivative p'''(x)
     - `Der_coeffs::d4`: Fourth derivative p''''(x)
   - `eval_integral_1(x, y0)`: Evaluates the definite integral from 0 to x, with initial value y0
   - All evaluation functions limit x to non-negative values (x ≥ 0)

3. **Validation**:
   - `get_valid()`: Returns whether the polynomial has been properly initialized
   - Invalid polynomials return 0 for all evaluations

### 4.3 Polynomial Implementation Details

- Polynomial is represented as: p(x) = c₀ + c₁x + c₂x² + c₃x³ + c₄x⁴ + c₅x⁵ + c₆x⁶ + c₇x⁷
- Derivatives are calculated by applying standard differentiation rules:
  - First derivative: p'(x) = c₁ + 2c₂x + 3c₃x² + 4c₄x³ + 5c₅x⁴ + 6c₆x⁵ + 7c₇x⁶
  - Higher derivatives follow the same pattern
- Integral is calculated as: ∫p(x)dx = c₀x + c₁x²/2 + c₂x³/3 + c₃x⁴/4 + c₄x⁵/5 + c₅x⁶/6 + c₆x⁷/7 + c₇x⁸/8 + y₀

## 5. Half-Precision Floating Point Operations

The system implements half-precision (16-bit) floating point support through the `Real16_amz` class.

### 5.1 Half-Precision Class Interface

```cpp
class Real16_amz {
public:
    Real value;  // 32-bit floating point representation
    
    Uint16 convert_to_half_precision() const;
    static Real convert_to_single_precision(Uint16 half_precision_value);
};
```

### 5.2 Half-Precision Conversion

1. **Single to Half Precision**:
   - `convert_to_half_precision()`: Converts the internal 32-bit float to a 16-bit half-precision representation
   - Handles sign bit, exponent, and mantissa conversion
   - Properly handles special cases (zero, infinity, NaN)
   - Range limitations: Valid range is approximately ±65504

2. **Half to Single Precision**:
   - `convert_to_single_precision()`: Static method that converts a 16-bit half-precision value to a 32-bit float
   - Reconstructs sign, exponent, and mantissa
   - Properly handles special cases

### 5.3 Half-Precision Format Details

The IEEE 754 half-precision format consists of:
- 1 sign bit (bit 15)
- 5 exponent bits (bits 10-14)
- 10 mantissa bits (bits 0-9)

The implementation correctly handles the bit-level operations required for these conversions, including:
- Sign bit extraction and application
- Exponent bias adjustment (exponent is stored with a bias of 15)
- Mantissa normalization and denormalization
- Special values like zero

## 6. Utility Functions for Rotor Speed Conversions

The system includes specialized functions for converting between different representations of rotor speeds:

```cpp
Real krpm2_2_rpm(const Real rotor_speeds_krpm2)
```
- Converts from squared kiloRPM to RPM
- Preserves sign: sgn(output) = sgn(input)
- Formula: rpm = 1000 * sgn(krpm2) * sqrt(|krpm2|)

```cpp
Real rpm_2_krpm2(const Real rotor_speeds_rpm)
```
- Converts from RPM to squared kiloRPM
- Preserves sign: sgn(output) = sgn(input)
- Formula: krpm2 = sgn(rpm) * (|rpm| / 1000)²

## 7. Comparison Functions

The system includes specialized comparison functions for floating-point values:

```cpp
bool Rfun::comp_real(Real a, Real b, Real tolerance)
```
- Compares two Real values with a specified tolerance
- Returns true if |a - b| < tolerance
- Used extensively in testing to account for floating-point precision issues

## 8. Testing Methodology

The test suite employs several strategies to validate the mathematical functions:

### 8.1 Factorial Testing
- Tests all factorials from 0! to 12!
- Compares against pre-computed values

### 8.2 Clamping Function Testing
- Tests upper and lower saturation cases
- Tests values within limits
- Tests with both integer and floating-point values

### 8.3 Interpolation Testing
- Tests edge cases where x_min > x_max
- Tests edge cases where x_max ≈ x_min (within tolerance)
- Tests nominal cases with systematic sampling across the input range

### 8.4 Trigonometric Function Testing
- Tests extended domain functions (asinw, acosw) with values inside and outside [-1, 1]
- Systematically samples the input range with small increments

### 8.5 Root Finding Testing
- Tests with functions having known roots
- Tests edge cases (x_min > x_max, x_max ≈ x_min)
- Tests functions with no roots in the interval
- Tests with different tolerance values

### 8.6 Polynomial Testing
- Tests construction, copying, and assignment
- Tests evaluation of polynomials and their derivatives
- Tests integration
- Uses random coefficient generation for thorough testing

### 8.7 Half-Precision Testing
- Tests round-trip conversion (float → half → float)
- Tests with values across the representable range
- Tests special cases (zero)
- Verifies bit-level representation

## 9. Numerical Considerations

The implementation addresses several numerical considerations:

1. **Tolerance Management**:
   - Functions accept tolerance parameters to control precision requirements
   - Default tolerances defined in `Comparison_constants` (e.g., `k_near_eq_tol`)

2. **Domain Limiting**:
   - Functions like `asinw` and `acosw` extend standard functions to handle out-of-domain inputs
   - Polynomial evaluation limits x to non-negative values

3. **Edge Case Handling**:
   - Special handling for cases where denominators approach zero
   - Special handling for functions with discontinuities

4. **Precision Limitations**:
   - Half-precision floating point has limited range (±65504) and precision (10 bits mantissa)
   - Tests account for expected precision loss in conversions

## Referenced Context Files

The following context files provided useful information for understanding the mathematical utilities:

1. `Math_aux.h` - Contains auxiliary mathematical functions referenced in tests
2. `Rfun.h` - Contains core mathematical utility functions including clamp, sign, and interpolation
3. `Rmath.h` - Contains mathematical operations like sqrt, pow, exp, sin, cos
4. `Comparison_constants.h` - Defines tolerance constants used in floating-point comparisons
5. `Const.h` - Contains mathematical constants like PI