# Generated from:

- items/pdi_Monitor/operation/ver_opdif_obstacle.xml (70 tokens)
- items/pdi_Monitor/operation/ver_opdif_polymgr.xml (189 tokens)
- items/pdi_Monitor/operation/ver_opdif_flyto-setup-map.xml (58 tokens)
- items/pdi_Monitor/operation/ver_opdif_fmgr.xml (63 tokens)
- items/pdi_Monitor/operation/ver_opdif_runway.xml (62 tokens)
- items/pdi_Monitor/operation/ver_opdif_init_pos.xml (125 tokens)
- items/pdi_Monitor/operation/ver_opdif_adsbdyn.xml (86 tokens)
- items/pdi_Monitor/operation/ver_opdif_oppos.xml (142 tokens)
- items/pdi_Monitor/operation/ver_opdif_tmcompl.xml (5029 tokens)
- items/pdi_Monitor/operation/ver_opdif_marks.xml (50 tokens)
- items/pdi_Monitor/operation/ver_opdif_rrefs.xml (50 tokens)
- items/pdi_Monitor/operation/ver_opdif_evt-wp-groups.xml (56 tokens)
- items/pdi_Monitor/operation/ver_opdif_mgeocage.xml (83 tokens)
- items/pdi_Monitor/operation/ver_opdif_troute.xml (66 tokens)

## With context from:

- Amazon-PrimeAir/items/ASTRO/items/Monitor/07_System_Architecture.md (3174 tokens)
- Amazon-PrimeAir/items/ASTRO/items/Monitor/04_Navigation_Systems.md (6458 tokens)

---

# PDI Monitor Operational Configuration Analysis

## 1. Overview of Operational Configuration Files

The PDI Monitor system uses a set of XML configuration files to define its operational behavior. These files establish parameters for obstacle management, polygon management, waypoint navigation, runway configuration, position initialization, ADS-B parameters, telemetry, and geofencing. Each file follows a consistent structure with an entry identifier, filename, version information, and data content specific to its function.

## 2. Version Control and File Structure

All operational configuration files share a common versioning structure:
```xml
<version>
    <major>7</major>
    <minor>1</minor>
    <revision>1</revision>
</version>
```

This indicates that all operational files are at version 7.1.1, suggesting a coordinated release or update cycle for the entire operational configuration set. Each file is also assigned a unique ID number and binary filename for storage and reference.

## 3. Obstacle Management Configuration

### 3.1 Obstacle Definition File (ver_opdif_obstacle.xml)

```xml
<entry-obstacle>
    <id>68</id>
    <filename>obstacle.bin</filename>
    <data>
        <polygons/>
        <cylinders/>
        <spheres/>
    </data>
</entry-obstacle>
```

This file defines the obstacle configuration for the PDI Monitor system with the following characteristics:
- ID: 68
- Empty collections for polygons, cylinders, and spheres
- Currently no obstacles are defined in the system
- The structure supports three geometric obstacle types: polygons (likely 2D areas), cylinders (vertical obstacles with height), and spheres (3D volumetric obstacles)

## 4. Polygon Management Configuration

### 4.1 Polygon Manager File (ver_opdif_polymgr.xml)

```xml
<entry-polymgr>
    <id>21</id>
    <filename>polymgr.bin</filename>
    <data>
        <volumeOp/>
        <polygons/>
        <circles/>
        <spheres/>
        <groups/>
        <geoCage>
            <geoIdx>
                <contingency>0</contingency>
                <emergency>0</emergency>
                <emergencyMargin>0</emergencyMargin>
                <prohibited>0</prohibited>
            </geoIdx>
            <geoDist>
                <cont-dist>0.0</cont-dist>
                <emer-dist>0.0</emer-dist>
                <emer-mar-dist>0.0</emer-mar-dist>
            </geoDist>
        </geoCage>
    </data>
</entry-polymgr>
```

The polygon manager configuration defines:
- ID: 21
- Empty collections for volumeOp, polygons, circles, spheres, and groups
- A geoCage configuration with:
  - All index values (contingency, emergency, emergencyMargin, prohibited) set to 0
  - All distance values (cont-dist, emer-dist, emer-mar-dist) set to 0.0
- This suggests a geofencing capability with different severity levels (contingency, emergency, prohibited) that is currently not active

## 5. Waypoint Navigation Configuration

### 5.1 Flyto Setup Map (ver_opdif_flyto-setup-map.xml)

```xml
<entry-flyto-setup-map>
    <id>22</id>
    <filename>flyto-setup-map.bin</filename>
    <data/>
</entry-flyto-setup-map>
```

This file defines the flyto setup map with:
- ID: 22
- Empty data section
- The file likely supports waypoint navigation configuration but is currently empty

### 5.2 Flight Manager Configuration (ver_opdif_fmgr.xml)

```xml
<entry-fmgr>
    <id>79</id>
    <filename>fmgr.bin</filename>
    <data>
        <genericOp/>
        <specifiedOp/>
    </data>
</entry-fmgr>
```

The flight manager configuration includes:
- ID: 79
- Empty genericOp and specifiedOp sections
- These sections likely define generic and mission-specific flight operations

### 5.3 Trajectory Route Configuration (ver_opdif_troute.xml)

```xml
<entry-troute>
    <id>67</id>
    <filename>troute.bin</filename>
    <data>
        <first>65535</first>
        <patches/>
    </data>
</entry-troute>
```

The trajectory route configuration defines:
- ID: 67
- First waypoint ID set to 65535 (likely a special value indicating "not set" or "invalid")
- Empty patches collection
- This file would normally contain trajectory route information but is currently empty

### 5.4 Event Waypoint Groups (ver_opdif_evt-wp-groups.xml)

```xml
<entry-evt-wp-groups>
    <id>70</id>
    <filename>evt-wp-groups.bin</filename>
    <data/>
</entry-evt-wp-groups>
```

This file defines event waypoint groups with:
- ID: 70
- Empty data section
- The file would normally contain waypoint groups associated with specific events

### 5.5 Route Marks Configuration (ver_opdif_marks.xml)

```xml
<entry-rmark>
    <id>71</id>
    <filename>marks.bin</filename>
    <data/>
</entry-rmark>
```

The route marks configuration includes:
- ID: 71
- Empty data section
- This file would normally contain route markers or significant points

### 5.6 Route References Configuration (ver_opdif_rrefs.xml)

```xml
<entry-rrefs>
    <id>5</id>
    <filename>rrefs.bin</filename>
    <data/>
</entry-rrefs>
```

The route references configuration defines:
- ID: 5
- Empty data section
- This file would normally contain reference points for routes

## 6. Runway Configuration

### 6.1 Runway Definition File (ver_opdif_runway.xml)

```xml
<entry-oprwy>
    <id>29</id>
    <filename>runway.bin</filename>
    <data>
        <runways/>
        <spots/>
    </data>
</entry-oprwy>
```

The runway configuration includes:
- ID: 29
- Empty runways and spots collections
- This file would normally contain runway definitions and landing spot information

## 7. Position Initialization Configuration

### 7.1 Initial Position Configuration (ver_opdif_init_pos.xml)

```xml
<entry-init-pos>
    <id>11</id>
    <filename>init_pos.bin</filename>
    <data>
        <wrt-choice>
            <wrt-choice-abs>
                <wrt>65535</wrt>
                <pos>
                    <lon>0</lon>
                    <lat>0</lat>
                    <alt>0</alt>
                </pos>
            </wrt-choice-abs>
        </wrt-choice>
    </data>
</entry-init-pos>
```

The initial position configuration defines:
- ID: 11
- Position initialization using absolute coordinates
- Reference ID (wrt) set to 65535 (likely a special value indicating "not set" or "global reference")
- Position coordinates all set to 0 (longitude, latitude, altitude)
- This suggests that the system initializes at coordinates 0,0,0 which is likely a placeholder

### 7.2 Operational Position Configuration (ver_opdif_oppos.xml)

```xml
<entry-oppos>
    <id>118</id>
    <filename>oppos.bin</filename>
    <data>
        <feature>
            <wrt-choice>
                <wrt-choice-abs>
                    <wrt>65535</wrt>
                    <pos>
                        <lon>0</lon>
                        <lat>0</lat>
                        <alt>0</alt>
                    </pos>
                </wrt-choice-abs>
            </wrt-choice>
        </feature>
    </data>
</entry-oppos>
```

The operational position configuration includes:
- ID: 118
- Feature position using absolute coordinates
- Reference ID (wrt) set to 65535 (likely a special value indicating "not set" or "global reference")
- Position coordinates all set to 0 (longitude, latitude, altitude)
- Similar to the initial position, this appears to be a placeholder configuration

## 8. ADS-B Configuration

### 8.1 ADS-B Dynamic Configuration (ver_opdif_adsbdyn.xml)

```xml
<entry-adsb-dynamic>
    <id>296</id>
    <filename>adsbdyn.bin</filename>
    <data>
        <ctl_mode>0</ctl_mode>
        <squawk>0</squawk>
        <intent>0</intent>
        <custom>65535</custom>
    </data>
</entry-adsb-dynamic>
```

The ADS-B dynamic configuration defines:
- ID: 296
- Control mode set to 0 (likely disabled or automatic)
- Squawk code set to 0 (transponder code)
- Intent code set to 0 (aircraft intent)
- Custom value set to 65535 (likely a special value indicating "not set")
- This suggests that ADS-B functionality is present but not actively configured

## 9. Telemetry Configuration

### 9.1 Telemetry Completion Configuration (ver_opdif_tmcompl.xml)

```xml
<entry-tm-compl>
    <id>72</id>
    <filename>tmcompl.bin</filename>
    <data>
        <str-tunarray-element>
            <fields>
                <!-- 60 data field definitions -->
            </fields>
            <enable>1</enable>
            <periode>0.1</periode>
            <address>
                <uav>2</uav>
            </address>
        </str-tunarray-element>
    </data>
</entry-tm-compl>
```

The telemetry completion configuration is the most complex file, defining:
- ID: 72
- A single telemetry array element with:
  - 60 data fields of various types (real-float32, bit, uinteger16)
  - Each field has a type, ID, and sometimes scale or min/max values
  - Telemetry enabled (enable: 1)
  - Transmission period of 0.1 seconds (10Hz)
  - UAV address set to 2
- This configuration defines what telemetry data is transmitted, how often, and to where

The telemetry fields include a mix of:
- Real-float32 values (type 0): 38 fields
- Bit values (type 3): 19 fields
- Uinteger16 values (type 2): 3 fields

Notable field IDs include:
- Navigation-related: 3, 6, 7, 8 (likely position/velocity)
- Status-related: 8, 9, 10, 12, 16, 17 (likely system status bits)
- Sensor-related: 346-392 (likely sensor readings)
- Control-related: 1100-1101 (likely control inputs/outputs)
- System parameters: 1300-1303, 1504-1515, 2050-2095, 3100-3110

## 10. Geofencing Configuration

### 10.1 Manual Geocage Configuration (ver_opdif_mgeocage.xml)

```xml
<entry-mgeocage>
    <id>146</id>
    <filename>mgeocage.bin</filename>
    <data>
        <data>
            <polygonType>0</polygonType>
            <auxPolygon>0</auxPolygon>
        </data>
    </data>
</entry-mgeocage>
```

The manual geocage configuration defines:
- ID: 146
- Polygon type set to 0 (likely a default or disabled state)
- Auxiliary polygon set to 0 (likely a default or disabled state)
- This configuration complements the geoCage section in the polygon manager file

## 11. Operational Configuration Integration Analysis

### 11.1 Navigation System Integration

Based on the operational configuration files and context information, the PDI Monitor's navigation system integrates with the operational configuration in several ways:

1. **Position Initialization**:
   - The `init_pos.xml` file defines the initial position for the system
   - Currently set to 0,0,0 coordinates, likely a placeholder
   - The system would use this as a starting point for navigation

2. **Waypoint Navigation**:
   - Multiple files support waypoint navigation:
     - `flyto-setup-map.xml` (currently empty)
     - `fmgr.xml` with genericOp and specifiedOp sections (currently empty)
     - `troute.xml` with first waypoint and patches (currently minimal)
     - `evt-wp-groups.xml` for event-triggered waypoints (currently empty)
     - `marks.xml` for route markers (currently empty)
     - `rrefs.xml` for route references (currently empty)
   - These files would normally contain waypoints, routes, and navigation parameters
   - The empty state suggests either a default configuration or that these are populated dynamically

3. **Runway Configuration**:
   - The `runway.xml` file would define runways and landing spots
   - Currently empty, suggesting either no runways defined or dynamic configuration

4. **Operational Position**:
   - The `oppos.xml` file defines operational position features
   - Currently set to 0,0,0 coordinates, likely a placeholder

### 11.2 Geofencing and Safety Integration

The operational configuration includes several files related to geofencing and safety:

1. **Obstacle Management**:
   - The `obstacle.xml` file would define obstacles to avoid
   - Currently empty, suggesting no static obstacles defined

2. **Polygon Management**:
   - The `polymgr.xml` file defines polygons, circles, spheres, and groups
   - Includes a geoCage configuration with contingency, emergency, and prohibited zones
   - Currently all values are 0, suggesting no active geofencing

3. **Manual Geocage**:
   - The `mgeocage.xml` file defines manual geocage parameters
   - Currently set to 0, suggesting no active manual geocage

These files would work together to define safe operating areas and obstacles to avoid. The current empty state suggests either a default configuration or that these are populated dynamically during operation.

### 11.3 Communication and Telemetry Integration

The operational configuration includes files related to communication and telemetry:

1. **ADS-B Configuration**:
   - The `adsbdyn.xml` file defines ADS-B parameters
   - Currently minimal configuration with control mode, squawk, and intent all set to 0

2. **Telemetry Configuration**:
   - The `tmcompl.xml` file defines detailed telemetry parameters
   - 60 data fields of various types
   - Enabled with a 10Hz transmission rate
   - UAV address set to 2

The telemetry configuration is the most detailed and active part of the operational configuration, suggesting that while navigation and geofencing may be minimal, the system is actively transmitting telemetry data.

## 12. Operational Configuration Patterns

Several patterns emerge from analyzing the operational configuration files:

### 12.1 Empty Configuration Pattern

Many configuration files contain empty data sections or minimal values:
- `obstacle.xml`: Empty polygons, cylinders, and spheres
- `polymgr.xml`: Empty volumeOp, polygons, circles, spheres, and groups
- `flyto-setup-map.xml`: Empty data section
- `fmgr.xml`: Empty genericOp and specifiedOp sections
- `runway.xml`: Empty runways and spots
- `evt-wp-groups.xml`: Empty data section
- `marks.xml`: Empty data section
- `rrefs.xml`: Empty data section

This pattern suggests that:
1. The system may be in a default or initial state
2. These configurations may be populated dynamically during operation
3. The system may rely on other mechanisms for these functions

### 12.2 Position Reference Pattern

Multiple files use a similar pattern for position references:
- `init_pos.xml` and `oppos.xml` both use:
  ```xml
  <wrt-choice>
      <wrt-choice-abs>
          <wrt>65535</wrt>
          <pos>
              <lon>0</lon>
              <lat>0</lat>
              <alt>0</alt>
          </pos>
      </wrt-choice-abs>
  </wrt-choice>
  ```

This pattern suggests:
1. A consistent approach to position referencing
2. The use of absolute coordinates with a global reference (65535)
3. A placeholder state with all coordinates set to 0

### 12.3 Hierarchical Safety Configuration Pattern

The geofencing and safety configuration uses a hierarchical approach:
- `polymgr.xml` defines a geoCage with multiple severity levels:
  - contingency
  - emergency
  - emergencyMargin
  - prohibited
- Each level has associated distance parameters
- `mgeocage.xml` provides additional manual geocage parameters

This pattern suggests a multi-layered approach to geofencing with different response levels based on proximity to boundaries.

### 12.4 Detailed Telemetry Pattern

Unlike other configuration files, the telemetry configuration is detailed and active:
- 60 specific data fields defined
- Enabled with a 10Hz transmission rate
- Specific UAV address

This pattern suggests that while other configurations may be minimal, telemetry is a critical function that is actively configured.

## 13. Relationship to System Architecture

Based on the context file information, the operational configuration files relate to the PDI Monitor system architecture in several ways:

1. **Monitor Builder Integration**:
   - The operational configuration files likely provide parameters for the Monitor Builder component
   - The Monitor Builder would use these configurations to construct the monitoring system at runtime

2. **Mission Mode vs. Maintenance Mode**:
   - The empty state of many configuration files may relate to the system's dual-mode operation
   - In maintenance mode, many monitoring functions are not built
   - The configurations may be populated differently in mission mode

3. **Safety and Recovery Features**:
   - The geofencing and obstacle configurations align with the safety and recovery features mentioned in the architecture
   - The currently empty state may indicate that these are dynamically configured during operation

4. **Communication Architecture**:
   - The telemetry configuration aligns with the message-based communication architecture
   - The detailed telemetry fields suggest integration with the system's internal and external communication mechanisms

## 14. Relationship to Navigation Systems

Based on the context file information, the operational configuration files relate to the PDI Monitor navigation systems in several ways:

1. **Position Initialization**:
   - The `init_pos.xml` file would provide initial position data to the navigation system
   - This would integrate with the georeferencing system described in the navigation context

2. **Dual-GNSS Architecture**:
   - While not directly configured in these files, the navigation context describes a dual-GNSS architecture
   - The position initialization and operational position configurations would work with this architecture

3. **Route Tracking**:
   - The various route and waypoint files would integrate with the route tracking and mission planning capabilities described in the navigation context
   - The `troute.xml` file in particular would relate to the route tracking functionality

4. **Georeferencing Integration**:
   - The position reference pattern using `wrt-choice-abs` would integrate with the georeferencing system
   - The value 65535 for the reference (wrt) likely corresponds to a global reference frame

## 15. Comprehensive Operational Configuration Summary

| File | ID | Purpose | Current State | Integration Points |
|------|----|---------|--------------|--------------------|
| obstacle.xml | 68 | Define obstacles to avoid | Empty | Safety systems, Navigation |
| polymgr.xml | 21 | Manage polygons and geofencing | Empty with geoCage structure | Safety systems, Geofencing |
| flyto-setup-map.xml | 22 | Configure waypoint navigation | Empty | Navigation, Mission planning |
| fmgr.xml | 79 | Manage flight operations | Empty | Navigation, Mission execution |
| runway.xml | 29 | Define runways and landing spots | Empty | Navigation, Landing systems |
| init_pos.xml | 11 | Initialize position | 0,0,0 coordinates | Navigation, Georeferencing |
| adsbdyn.xml | 296 | Configure ADS-B parameters | Minimal values | Communication, Air traffic |
| oppos.xml | 118 | Define operational positions | 0,0,0 coordinates | Navigation, Mission execution |
| tmcompl.xml | 72 | Configure telemetry | 60 fields, 10Hz, enabled | Communication, Monitoring |
| marks.xml | 71 | Define route markers | Empty | Navigation, Mission planning |
| rrefs.xml | 5 | Define route references | Empty | Navigation, Mission planning |
| evt-wp-groups.xml | 70 | Define event waypoint groups | Empty | Navigation, Event handling |
| mgeocage.xml | 146 | Configure manual geocage | Minimal values | Safety systems, Geofencing |
| troute.xml | 67 | Define trajectory routes | First=65535, empty patches | Navigation, Mission execution |

## 16. Conclusion

The PDI Monitor operational configuration files define a comprehensive set of parameters for system operation, including obstacle management, polygon management, waypoint navigation, runway configuration, position initialization, ADS-B parameters, telemetry, and geofencing. 

The current state of these files shows a pattern of minimal or empty configurations for most functions, with the exception of telemetry which is detailed and enabled. This suggests either a default/initial state or a system that relies on dynamic configuration during operation.

The configuration files follow consistent patterns for versioning, position referencing, and hierarchical safety configuration. They integrate with the system architecture through the Monitor Builder component and support both mission and maintenance modes of operation.

The navigation-related configurations would integrate with the dual-GNSS architecture and georeferencing system described in the navigation context, while the safety and geofencing configurations would support the safety and recovery features mentioned in the system architecture.

Overall, these operational configuration files provide a flexible framework for defining the PDI Monitor system's behavior, with particular emphasis on telemetry and monitoring capabilities.

## Referenced Context Files

- `Amazon-PrimeAir/items/ASTRO/items/Monitor/07_System_Architecture.md` - Provided context on the overall PDI Monitor system architecture, including the Monitor Builder component, operational modes, and safety features.

- `Amazon-PrimeAir/items/ASTRO/items/Monitor/04_Navigation_Systems.md` - Provided context on the navigation systems, including the dual-GNSS architecture, georeferencing system, and route tracking capabilities.