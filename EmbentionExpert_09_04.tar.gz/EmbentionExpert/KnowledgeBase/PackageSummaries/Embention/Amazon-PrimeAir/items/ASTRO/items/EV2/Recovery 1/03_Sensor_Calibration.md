# Generated from:

- items/pdi_Recovery1/installation/ver_ipdif_gyrocal.xml (1045 tokens)
- items/pdi_Recovery1/installation/ver_ipdif_calmag0.xml (191 tokens)
- items/pdi_Recovery1/installation/ver_ipdif_calmag2.xml (191 tokens)
- items/pdi_Recovery1/installation/ver_ipdif_calmag3.xml (191 tokens)
- items/pdi_Recovery1/installation/ver_ipdif_calmag4.xml (191 tokens)
- items/pdi_Recovery1/installation/ver_ipdif_calmag5.xml (191 tokens)
- items/pdi_Recovery1/installation/ver_ipdif_calmag6.xml (191 tokens)
- items/pdi_Recovery1/installation/ver_ipdif_calmag7.xml (192 tokens)
- items/pdi_Recovery1/installation/ver_ipdif_extcalacc0.xml (193 tokens)
- items/pdi_Recovery1/installation/ver_ipdif_extcalacc1.xml (193 tokens)
- items/pdi_Recovery1/installation/ver_ipdif_extcalgyr0.xml (193 tokens)
- items/pdi_Recovery1/installation/ver_ipdif_extcalgyr1.xml (193 tokens)
- items/pdi_Recovery1/installation/ver_ipdif_extcalmag0.xml (193 tokens)
- items/pdi_Recovery1/installation/ver_ipdif_extcalmag1.xml (193 tokens)
- items/pdi_Recovery1/installation/ver_ipdif_acclbu.xml (106 tokens)
- items/pdi_Recovery1/production/ver_ppdif_calacc0.xml (191 tokens)
- items/pdi_Recovery1/production/ver_ppdif_calacc1.xml (191 tokens)
- items/pdi_Recovery1/production/ver_ppdif_calacc2.xml (191 tokens)
- items/pdi_Recovery1/production/ver_ppdif_calacc3.xml (191 tokens)
- items/pdi_Recovery1/production/ver_ppdif_calgyr0.xml (191 tokens)
- items/pdi_Recovery1/production/ver_ppdif_calgyr1.xml (191 tokens)
- items/pdi_Recovery1/production/ver_ppdif_calgyr2.xml (191 tokens)
- items/pdi_Recovery1/production/ver_ppdif_calgyr3.xml (191 tokens)
- items/pdi_Recovery1/production/ver_ppdif_calmag_res.xml (192 tokens)
- items/pdi_Recovery1/production/ver_ppdif_calstp0.xml (112 tokens)
- items/pdi_Recovery1/production/ver_ppdif_calstp1.xml (112 tokens)
- items/pdi_Recovery1/production/ver_ppdif_calstp2.xml (112 tokens)
- items/pdi_Recovery1/production/ver_ppdif_calqinf.xml (112 tokens)
- items/pdi_Recovery1/setup/ver_spdif_mcal.xml (77 tokens)
- items/pdi_Recovery1/setup/ver_spdif_varqinf.xml (198 tokens)
- items/pdi_Recovery1/setup/ver_spdif_varstp.xml (198 tokens)

---

# PDI Recovery1 Sensor Calibration System Analysis

## 1. System Overview

The PDI Recovery1 system employs an extensive sensor calibration framework to transform raw sensor measurements into accurate, calibrated values. The calibration system covers multiple sensor types including gyroscopes, accelerometers, magnetometers, and step counters, with support for temperature compensation across different operating conditions.

The calibration files are organized into three main directories:
- `/installation/` - Contains installation-specific calibration files
- `/production/` - Contains production calibration parameters
- `/setup/` - Contains setup and configuration parameters for the calibration system

All calibration files follow a consistent versioning scheme (major.minor.revision) with the current version being 7.3.1 across all files.

## 2. Calibration File Structure and Format

### 2.1 Common XML Structure

All calibration files follow a similar XML structure:

```xml
<entry-[sensortype]>
    <id>[numeric identifier]</id>
    <filename>[binary filename]</filename>
    <version>
        <major>7</major>
        <minor>3</minor>
        <revision>1</revision>
    </version>
    <data>
        <!-- Sensor-specific calibration parameters -->
    </data>
</entry-[sensortype]>
```

### 2.2 File Naming Convention

The calibration files follow a consistent naming pattern:
- `cal[sensortype][index].bin` - Standard calibration files
- `extcal[sensortype][index].bin` - Extended calibration files
- `[sensortype]lbu.bin` - Backup calibration files

Where:
- `[sensortype]` can be: acc (accelerometer), gyr (gyroscope), mag (magnetometer), stp (step counter), qinf (quaternion inference)
- `[index]` is a numeric identifier (0, 1, 2, etc.) representing different sensor instances

## 3. Sensor Calibration Parameters

### 3.1 Common Calibration Parameters

Most sensor calibration files contain the following parameters:

#### 3.1.1 Temperature Compensation

```xml
<temp_hyst>[temperature hysteresis value]</temp_hyst>
```

The temperature hysteresis parameter (`temp_hyst`) defines the temperature change threshold that triggers recalibration. Values observed:
- 0.5 degrees for some sensors (calmag0, calacc0, calacc1, calgyr0, calgyr1)
- 1.0 degrees for most sensors (calmag2-7, extcalacc0-1, extcalgyr0-1, extcalmag0-1, calacc2-3, calgyr2-3)
- 0.0 degrees for step counters and quaternion inference (calstp0-2, calqinf)

#### 3.1.2 Calibration Matrix

For accelerometers, gyroscopes, and magnetometers, a 3x3 calibration matrix is used:

```xml
<a00>1.0</a00> <a10>0.0</a10> <a20>0.0</a20>
<a01>0.0</a01> <a11>1.0</a11> <a21>0.0</a21>
<a02>0.0</a02> <a12>0.0</a12> <a22>1.0</a22>
```

This matrix transforms raw sensor readings into calibrated values, correcting for scaling, cross-axis sensitivity, and alignment errors. All files currently use identity matrices (no correction).

#### 3.1.3 Bias Vector

For accelerometers, gyroscopes, and magnetometers, a bias vector is defined:

```xml
<b0>0.0</b0>
<b1>0.0</b1>
<b2>0.0</b2>
```

This vector represents the zero-offset correction for each axis. All files currently use zero bias (no correction).

#### 3.1.4 Temperature Reference

```xml
<temp>[temperature value]</temp>
```

The temperature at which the calibration parameters were measured. Values observed:
- 320.0 degrees for many production sensors (calacc0-2, calgyr0-2)
- 1.0 degrees for some magnetometers (calmag2-6)
- 0.0 degrees for other sensors (calmag7, calacc3, calgyr3, calmag_res)

### 3.2 Sensor-Specific Calibration Parameters

#### 3.2.1 Gyroscope Calibration (gyrocal.bin)

The gyroscope calibration file (`ver_ipdif_gyrocal.xml`) has a unique structure with coefficients c0-c7 for each axis:

```xml
<c0>
    <x>
        <bias>0.0</bias>
        <scale-factor>0.0</scale-factor>
        <variance>0.0</variance>
    </x>
    <y>...</y>
    <z>...</z>
</c0>
<!-- Similar structure for c1-c7 -->
```

This suggests a polynomial or multi-coefficient calibration model for gyroscopes, potentially for different temperature ranges or operating conditions.

#### 3.2.2 Step Counter Calibration (calstp0-2.bin)

Step counter calibration files use a different parameter structure:

```xml
<str-tunarray-element>
    <x>0.0</x>
    <y1>0.0</y1>
    <y2>0.0</y2>
</str-tunarray-element>
```

This likely represents a simple linear or piecewise calibration curve for step detection thresholds.

#### 3.2.3 Quaternion Inference Calibration (calqinf.bin)

The quaternion inference calibration uses the same structure as step counters:

```xml
<str-tunarray-element>
    <x>0.0</x>
    <y1>0.0</y1>
    <y2>0.0</y2>
</str-tunarray-element>
```

This suggests a similar calibration approach for quaternion-based orientation calculations.

## 4. Calibration Transformation Process

Based on the calibration parameters, the transformation from raw to calibrated sensor values follows this process:

1. **Temperature Measurement**: The system measures the current temperature.

2. **Temperature Hysteresis Check**: If the temperature change exceeds the `temp_hyst` threshold since the last calibration, recalibration is triggered.

3. **Bias Correction**: Raw sensor values are adjusted by subtracting the bias vector:
   ```
   [x_unbiased]   [x_raw]   [b0]
   [y_unbiased] = [y_raw] - [b1]
   [z_unbiased]   [z_raw]   [b2]
   ```

4. **Scale and Cross-Axis Correction**: The unbiased values are multiplied by the calibration matrix:
   ```
   [x_calibrated]   [a00 a01 a02]   [x_unbiased]
   [y_calibrated] = [a10 a11 a12] × [y_unbiased]
   [z_calibrated]   [a20 a21 a22]   [z_unbiased]
   ```

5. **Temperature Compensation**: For gyroscopes, additional temperature-dependent corrections may be applied using the c0-c7 coefficients.

## 5. Sensor Types and Instances

### 5.1 Accelerometers

The system includes multiple accelerometer instances:
- Primary accelerometers: calacc0, calacc1, calacc2, calacc3
- Extended accelerometers: extcalacc0, extcalacc1
- Backup accelerometer: acclbu

### 5.2 Gyroscopes

The system includes multiple gyroscope instances:
- Primary gyroscopes: calgyr0, calgyr1, calgyr2, calgyr3
- Extended gyroscopes: extcalgyr0, extcalgyr1
- Main gyroscope calibration: gyrocal

### 5.3 Magnetometers

The system includes multiple magnetometer instances:
- Primary magnetometers: calmag0, calmag2, calmag3, calmag4, calmag5, calmag6, calmag7
- Extended magnetometers: extcalmag0, extcalmag1
- Resonant magnetometer: calmag_res

### 5.4 Other Sensors

- Step counters: calstp0, calstp1, calstp2
- Quaternion inference: calqinf

## 6. Configuration and Setup Parameters

### 6.1 Manual Calibration Configuration (mcal.bin)

The `mcal.bin` file contains parameters for manual calibration:

```xml
<map>
    <tmeas>0.0</tmeas>
    <save_xcal>0</save_xcal>
</map>
```

- `tmeas`: Measurement temperature (currently 0.0)
- `save_xcal`: Flag to save extended calibration (currently disabled)

### 6.2 Variable Configuration (varstp.bin, varqinf.bin)

These files define runtime variable configurations for step counters and quaternion inference:

```xml
<rvar0>
    <enable>0</enable>
    <rvar_id>4100</rvar_id>
    <min_value>-3.4028235E38</min_value>
    <max_value>3.4028235E38</max_value>
    <max_delta>3.4028235E38</max_delta>
    <max_count_nv>0</max_count_nv>
</rvar0>
<rvar1>...</rvar1>
```

- `enable`: Flag to enable the variable (currently disabled)
- `rvar_id`: Variable identifier (4100)
- `min_value`/`max_value`: Valid range limits
- `max_delta`: Maximum allowed change
- `max_count_nv`: Maximum count for non-valid values

## 7. Calibration Patterns and Observations

### 7.1 Default Calibration Values

All calibration files currently use default or identity values:
- Bias vectors are all zeros: `<b0>0.0</b0> <b1>0.0</b1> <b2>0.0</b2>`
- Calibration matrices are all identity matrices
- Gyroscope coefficients (c0-c7) are all zeros

This suggests that either:
1. The files contain placeholder values to be replaced during actual calibration
2. The system is in an uncalibrated state
3. The calibration process has not yet been performed

### 7.2 Temperature Compensation Strategy

The system employs temperature-based calibration with different hysteresis thresholds:
- Critical sensors use tighter hysteresis (0.5 degrees)
- Secondary sensors use wider hysteresis (1.0 degrees)
- Some sensors have no temperature compensation (0.0 degrees)

### 7.3 Sensor Redundancy

The system employs multiple instances of each sensor type, suggesting redundancy for fault tolerance or sensor fusion:
- 4 primary accelerometers
- 4 primary gyroscopes
- 7 primary magnetometers
- Extended and backup sensors for critical measurements

## 8. Calibration System Architecture

Based on the file organization and parameters, the PDI Recovery1 calibration system appears to follow this architecture:

1. **Layered Calibration**:
   - Installation-specific calibration (`/installation/`)
   - Production calibration (`/production/`)
   - Runtime configuration (`/setup/`)

2. **Sensor Fusion**:
   - Multiple sensor instances for each measurement type
   - Quaternion inference for orientation estimation
   - Step counters for motion detection

3. **Adaptive Calibration**:
   - Temperature-dependent parameter selection
   - Hysteresis to prevent frequent recalibration
   - Extended calibration capabilities

4. **Fault Tolerance**:
   - Backup sensors (acclbu)
   - Multiple redundant sensors
   - Variable validation limits

## 9. File-by-File Breakdown

### 9.1 Installation Files

#### 9.1.1 ver_ipdif_gyrocal.xml
- ID: 249
- Purpose: Main gyroscope calibration with polynomial coefficients
- Structure: Contains c0-c7 coefficients for each axis (x,y,z)
- Parameters: bias, scale-factor, variance for each coefficient

#### 9.1.2 ver_ipdif_calmag0.xml through ver_ipdif_calmag7.xml
- IDs: 113, 272, 273, 263, 269, 356, 365
- Purpose: Magnetometer calibration for 7 different magnetometer instances
- Structure: Temperature hysteresis and 3x3 calibration matrix with bias vector
- Parameters: temp_hyst, temp, b0-b2, a00-a22

#### 9.1.3 ver_ipdif_extcalacc0.xml, ver_ipdif_extcalacc1.xml
- IDs: 162, 163
- Purpose: Extended accelerometer calibration
- Structure: Temperature hysteresis and 3x3 calibration matrix with bias vector
- Parameters: temp_hyst, temp, b0-b2, a00-a22

#### 9.1.4 ver_ipdif_extcalgyr0.xml, ver_ipdif_extcalgyr1.xml
- IDs: 164, 165
- Purpose: Extended gyroscope calibration
- Structure: Temperature hysteresis and 3x3 calibration matrix with bias vector
- Parameters: temp_hyst, temp, b0-b2, a00-a22

#### 9.1.5 ver_ipdif_extcalmag0.xml, ver_ipdif_extcalmag1.xml
- IDs: 166, 167
- Purpose: Extended magnetometer calibration
- Structure: Temperature hysteresis and 3x3 calibration matrix with bias vector
- Parameters: temp_hyst, temp, b0-b2, a00-a22

#### 9.1.6 ver_ipdif_acclbu.xml
- ID: 277
- Purpose: Backup accelerometer calibration
- Structure: 3x3 calibration matrix only (no temperature compensation)
- Parameters: a00-a22

### 9.2 Production Files

#### 9.2.1 ver_ppdif_calacc0.xml through ver_ppdif_calacc3.xml
- IDs: 109, 110, 259, 361
- Purpose: Production calibration for 4 accelerometer instances
- Structure: Temperature hysteresis and 3x3 calibration matrix with bias vector
- Parameters: temp_hyst, temp, b0-b2, a00-a22

#### 9.2.2 ver_ppdif_calgyr0.xml through ver_ppdif_calgyr3.xml
- IDs: 111, 112, 260, 362
- Purpose: Production calibration for 4 gyroscope instances
- Structure: Temperature hysteresis and 3x3 calibration matrix with bias vector
- Parameters: temp_hyst, temp, b0-b2, a00-a22

#### 9.2.3 ver_ppdif_calmag_res.xml
- ID: 367
- Purpose: Calibration for resonant magnetometer
- Structure: Temperature hysteresis and 3x3 calibration matrix with bias vector
- Parameters: temp_hyst, temp, b0-b2, a00-a22

#### 9.2.4 ver_ppdif_calstp0.xml through ver_ppdif_calstp2.xml
- IDs: 264, 265, 266
- Purpose: Calibration for 3 step counter instances
- Structure: Simple x, y1, y2 calibration curve
- Parameters: temp_hyst, x, y1, y2

#### 9.2.5 ver_ppdif_calqinf.xml
- ID: 267
- Purpose: Calibration for quaternion inference
- Structure: Simple x, y1, y2 calibration curve
- Parameters: temp_hyst, x, y1, y2

### 9.3 Setup Files

#### 9.3.1 ver_spdif_mcal.xml
- ID: 133
- Purpose: Manual calibration configuration
- Structure: Simple key-value pairs
- Parameters: tmeas, save_xcal

#### 9.3.2 ver_spdif_varqinf.xml, ver_spdif_varstp.xml
- IDs: 66, 65
- Purpose: Runtime variable configuration for quaternion inference and step counters
- Structure: Two runtime variables with validation parameters
- Parameters: enable, rvar_id, min_value, max_value, max_delta, max_count_nv

## 10. Calibration Transformation Logic

The calibration system transforms raw sensor readings into calibrated values using this process:

1. **Temperature Measurement and Selection**:
   ```
   if |current_temp - last_calibration_temp| > temp_hyst:
       select_calibration_parameters_for_current_temp()
   ```

2. **Bias Correction**:
   ```
   x_unbiased = x_raw - b0
   y_unbiased = y_raw - b1
   z_unbiased = z_raw - b2
   ```

3. **Matrix Transformation**:
   ```
   x_calibrated = a00*x_unbiased + a01*y_unbiased + a02*z_unbiased
   y_calibrated = a10*x_unbiased + a11*y_unbiased + a12*z_unbiased
   z_calibrated = a20*x_unbiased + a21*y_unbiased + a22*z_unbiased
   ```

4. **For Gyroscopes (Additional Processing)**:
   ```
   x_final = x_calibrated + apply_coefficients(c0...c7, temp, x)
   y_final = y_calibrated + apply_coefficients(c0...c7, temp, y)
   z_final = z_calibrated + apply_coefficients(c0...c7, temp, z)
   ```

5. **For Step Counters and Quaternion Inference**:
   ```
   output = interpolate(x, y1, y2, input)
   ```

## 11. Sensor Accuracy and Reliability Implications

### 11.1 Temperature Compensation

The temperature compensation system is critical for sensor accuracy across different operating conditions:

- Different sensors have different temperature hysteresis thresholds (0.0, 0.5, 1.0 degrees)
- Some sensors are calibrated at high temperatures (320.0 degrees)
- Others are calibrated at low temperatures (0.0, 1.0 degrees)

This suggests that the system operates across a wide temperature range and requires different calibration strategies for different sensors.

### 11.2 Sensor Redundancy

The multiple instances of each sensor type enhance reliability through:

- Fault detection by comparing readings across sensors
- Improved accuracy through sensor fusion
- Backup capabilities if primary sensors fail

### 11.3 Default Calibration Values

The current default calibration values (identity matrices, zero biases) suggest:

- The system may require in-field calibration before operation
- The calibration files may be templates to be populated during commissioning
- The system may have a self-calibration capability not reflected in these files

## 12. Summary of Calibration Parameters

### 12.1 Temperature Hysteresis Values

| Sensor Type | Hysteresis Value | File Location |
|-------------|------------------|---------------|
| Magnetometer (calmag0) | 0.5 | installation/ver_ipdif_calmag0.xml |
| Magnetometer (calmag2-7) | 1.0 | installation/ver_ipdif_calmag2-7.xml |
| Extended Accelerometer | 1.0 | installation/ver_ipdif_extcalacc0-1.xml |
| Extended Gyroscope | 1.0 | installation/ver_ipdif_extcalgyr0-1.xml |
| Extended Magnetometer | 1.0 | installation/ver_ipdif_extcalmag0-1.xml |
| Accelerometer (calacc0-1) | 0.5 | production/ver_ppdif_calacc0-1.xml |
| Accelerometer (calacc2-3) | 1.0 | production/ver_ppdif_calacc2-3.xml |
| Gyroscope (calgyr0-1) | 0.5 | production/ver_ppdif_calgyr0-1.xml |
| Gyroscope (calgyr2-3) | 1.0 | production/ver_ppdif_calgyr2-3.xml |
| Resonant Magnetometer | 1.0 | production/ver_ppdif_calmag_res.xml |
| Step Counter | 0.0 | production/ver_ppdif_calstp0-2.xml |
| Quaternion Inference | 0.0 | production/ver_ppdif_calqinf.xml |

### 12.2 Calibration Temperature References

| Sensor Type | Reference Temperature | File Location |
|-------------|----------------------|---------------|
| Magnetometer (calmag0) | 320.0 | installation/ver_ipdif_calmag0.xml |
| Magnetometer (calmag2-6) | 1.0 | installation/ver_ipdif_calmag2-6.xml |
| Magnetometer (calmag7) | 0.0 | installation/ver_ipdif_calmag7.xml |
| Extended Accelerometer | 0.0 | installation/ver_ipdif_extcalacc0-1.xml |
| Extended Gyroscope | 0.0 | installation/ver_ipdif_extcalgyr0-1.xml |
| Extended Magnetometer | 0.0, 1.0 | installation/ver_ipdif_extcalmag0-1.xml |
| Accelerometer (calacc0-2) | 320.0 | production/ver_ppdif_calacc0-2.xml |
| Accelerometer (calacc3) | 0.0 | production/ver_ppdif_calacc3.xml |
| Gyroscope (calgyr0-2) | 320.0 | production/ver_ppdif_calgyr0-2.xml |
| Gyroscope (calgyr3) | 0.0 | production/ver_ppdif_calgyr3.xml |
| Resonant Magnetometer | 0.0 | production/ver_ppdif_calmag_res.xml |

## 13. Conclusion

The PDI Recovery1 sensor calibration system employs a comprehensive approach to ensure accurate sensor readings across different operating conditions. The system uses:

1. **Temperature-dependent calibration** with different hysteresis thresholds for different sensors
2. **Multiple sensor instances** for redundancy and improved accuracy
3. **Bias correction and matrix transformation** to convert raw readings to calibrated values
4. **Specialized calibration for different sensor types** (gyroscopes, accelerometers, magnetometers, step counters)
5. **Layered calibration files** (installation, production, setup) for different stages of system deployment

The current calibration files contain default values (identity matrices, zero biases), suggesting that actual calibration parameters would be determined during system commissioning or through a self-calibration process.