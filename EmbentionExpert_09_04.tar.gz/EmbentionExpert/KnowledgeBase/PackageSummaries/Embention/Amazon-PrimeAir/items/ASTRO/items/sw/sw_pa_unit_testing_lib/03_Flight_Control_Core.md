# Generated from:

- include/controllers/Ttcg_unit_test.h (1699 tokens)
- include/controllers/Waca_unit_test.h (716 tokens)
- include/controllers/Sep_unit_test.h (380 tokens)
- include/controllers/Cm_pa_unit_test.h (536 tokens)
- include/controllers/Aee_unit_test.h (164 tokens)
- include/controllers/mixer_unit_test.h (230 tokens)
- include/controllers/Controller_Status_unit_test.h (213 tokens)
- include/controllers/Tsc_unit_test.h (1247 tokens)
- include/controllers/State_machines_unit_test.h (1015 tokens)
- include/controllers/Tcg_unit_test.h (1010 tokens)
- include/controllers/Asc_unit_test.h (427 tokens)
- include/controllers/Atcg_unit_test.h (1356 tokens)
- include/controllers/Afc_unit_test.h (389 tokens)
- include/controllers/Aacg_unit_test.h (523 tokens)
- source/controllers/Aee_unit_test.cpp (5481 tokens)
- source/controllers/Waca_unit_test.cpp (12014 tokens)
- source/controllers/mixer_unit_test.cpp (10488 tokens)
- source/controllers/Ttcg_unit_test.cpp (53118 tokens)
- source/controllers/State_machines_unit_test.cpp (9951 tokens)
- source/controllers/Tsc_unit_test.cpp (7169 tokens)
- source/controllers/Atcg_unit_test.cpp (16067 tokens)
- source/controllers/Aacg_unit_test.cpp (2265 tokens)
- source/controllers/Asc_unit_test.cpp (907 tokens)
- source/controllers/Controller_Status_unit_test.cpp (5157 tokens)
- source/controllers/Afc_unit_test.cpp (1253 tokens)
- source/controllers/Tcg_unit_test.cpp (10529 tokens)
- source/controllers/Cm_pa_unit_test.cpp (2317 tokens)

---

# Drone Flight Control System: Comprehensive Summary

## Controller Hierarchy and System Architecture

The drone flight control system is organized as a hierarchical control system with multiple specialized controllers working together to maintain stable flight across different flight phases. The system is designed with redundancy in mind, featuring primary and recovery lanes that can switch over in case of failures.

### High-Level Controller Structure

1. **Command Management (Cm)** - Determines flight modes and commands
2. **Trajectory Command Generation (Tcg)** - Generates trajectory commands
   - **Trajectory Tracking Command Generator (Ttcg)** - Generates position/velocity commands
   - **Attitude Tracking Command Generator (Atcg)** - Generates attitude commands
   - **Wind-Aware Command Adapter (Waca)** - Adjusts commands for wind conditions
3. **Trajectory Stabilization Controller (Tsc)** - Stabilizes trajectory tracking
4. **Attitude Stabilization Controller (Asc)** - Stabilizes attitude
   - **Attitude Feedback Controller (Afc)** - Provides attitude feedback control
5. **Attitude Error Estimator (Aee)** - Estimates attitude errors
6. **Acceleration Allocation Command Generator (Aacg)** - Allocates acceleration commands
7. **Mixer Allocator** - Allocates motor commands based on desired forces and moments

### State Machines

The system uses state machines to manage mode transitions between:
- **Takeoff** - Controls vertical ascent from ground
- **Land** - Manages descent and landing procedures
- **Track Spline** - Follows trajectory waypoints
- **Integrators** - Manages when integrators are active/inactive

## Phase of Flight Management

The system operates in four distinct flight phases:

1. **VTOL (Vertical Takeoff and Landing)** - Used during hover, takeoff, and landing
2. **Outbound Transition** - Transition from VTOL to WBF
3. **WBF (Wing-Borne Flight)** - Forward flight using wing lift
4. **Inbound Transition** - Transition from WBF back to VTOL

Phase transitions are managed by the `update_phase_of_flight()` function in the Ttcg controller, which evaluates current flight conditions to determine when to switch phases.

## Trajectory Tracking Command Generator (Ttcg)

The Ttcg is responsible for generating position, velocity, and acceleration commands by tracking routes composed of maneuvers.

### Key Components:

- **Route Management** - Stores and manages routes with multiple maneuvers
- **Maneuver Tracking** - Tracks progress through individual maneuvers
- **Closest Point Lookup** - Finds the closest point on the trajectory to the current position
- **Phase of Flight Management** - Determines and manages flight phase transitions

### Transition Management:

#### Outbound Transition (VTOL to WBF):
```
1. Detect when aircraft is at a VTOL-to-WBF transition point
2. Create acceleration profile to increase speed
3. Track acceleration profile until reaching WBF speed
4. Switch to WBF phase when transition complete
```

#### Inbound Transition (WBF to VTOL):
```
1. Detect when aircraft is approaching a WBF-to-VTOL transition point
2. Create two-stage deceleration profile:
   a. High-speed segment: Decelerate to critical speed
   b. Low-speed segment: Decelerate to hover
3. Track deceleration profile until reaching hover
4. Switch to VTOL phase when transition complete
```

## Wind-Aware Command Adapter (Waca)

Waca adjusts trajectory commands to account for wind conditions, ensuring accurate tracking in varying wind environments.

### Key Functions:

1. **Airspeed Command Management**:
   - Sets appropriate airspeed commands based on flight phase
   - Manages airspeed during transitions between flight phases
   - Handles special cases for recovery and return-home routes

2. **Airspeed Modulation**:
   - Adjusts airspeed to maintain schedule when ahead/behind planned position
   - Uses closed-loop control with deadzone logic to avoid oscillations
   - Considers route start time offsets in calculations

3. **Wind-Aware Waypoint Adjustment**:
   - Adjusts waypoints to account for wind effects
   - Ensures consistent ground track despite varying wind conditions

## Attitude Controllers

### Attitude Tracking Command Generator (Atcg)

Generates attitude commands based on the current flight phase:

1. **VTOL Mode**: 
   - Maintains level attitude with heading aligned to velocity vector
   - Implements weathervaning to align with wind direction when appropriate

2. **WBF Mode**:
   - Generates bank commands for turns
   - Maintains appropriate pitch for efficient forward flight

3. **Transition Modes**:
   - Manages smooth attitude changes during phase transitions
   - Uses hysteresis logic to prevent oscillations

### Attitude Stabilization Controller (Asc)

Stabilizes the aircraft's attitude by:
- Processing attitude errors from the Attitude Error Estimator (Aee)
- Generating appropriate angular velocity commands
- Using the Attitude Feedback Controller (Afc) to generate angular acceleration commands

### Attitude Error Estimator (Aee)

Computes attitude errors by:
- Separating errors into tilt and clock components
- Providing pseudo-axis-angle representation for control

## Motor Mixer

The mixer allocates motor commands based on desired forces and moments:

1. **Force/Moment Allocation**:
   - Converts desired forces and moments to actuator commands
   - Handles actuator constraints and saturation
   - Implements priority-based allocation when not all commands can be satisfied

2. **Hysteresis Management**:
   - Prevents motor oscillations near zero thrust
   - Ensures smooth transitions between motor states

3. **Failure Handling**:
   - Adapts allocation when rotors fail
   - Maintains maximum possible control authority

## State Machines

### Mode State Machine

Manages transitions between controller modes:
- **UNINITIALIZED** → **PBIT** → **ON_GROUND** → **TAKEOFF** → **TRACK_SPLINE** → **LAND**

The state machine implementation in `State_machines_unit_test.cpp` shows detailed logic for mode transitions:

```cpp
// Mode transitions are evaluated based on conditions like:
// - Command received (takeoff, land, track_spline)
// - Vehicle state (on ground, altitude, velocity)
// - PBIT status (passed/failed)
```

### Takeoff State Machine

Controls the takeoff sequence:
- **ON_GROUND** → **INITIAL_CLIMB** → **POSITION_HOLD** → **COMPLETE**

The takeoff state machine handles:
- Initial vertical climb from ground
- Transition to position hold at a safe altitude
- Completion when target altitude is reached with low velocity

Key transition conditions include:
- `EvalTakeoffOnGround()` - Checks if vehicle is on ground
- `EvalTakeoffAbovePositionHoldAltitude()` - Checks if above minimum safe altitude
- `EvalTakeoffAboveCompleteAltitude()` - Checks if target altitude is reached

### Land State Machine

Manages the landing sequence:
- **FAST_DESCENT** → **SLOW_DESCENT** → **TOUCH_DOWN** → **ON_GROUND**

The landing state machine includes:
- Initial fast descent from cruise altitude
- Transition to slow descent when near ground
- Special handling for landing from different flight phases
- Weathervaning during descent to align with wind

### Integrator State Machine

Controls when integrators are active:
- **FORCE_OFF** → **FORCE_ON** → **NORMAL**

Integrator state is determined by:
- Current controller mode
- Whether vehicle is on ground
- Special conditions requiring integrator reset

## Error Handling and Recovery

The system implements several error handling mechanisms:

1. **Lane Switchover**:
   - Primary and recovery lanes run in parallel
   - System can switch to recovery lane if primary lane fails
   - `initialize_after_switchover()` ensures smooth transition between lanes

2. **Route Management**:
   - Handles invalid or missing routes
   - Manages partial route updates
   - Supports return-home contingency routes

3. **Performance-Critical Paths**:
   - Closest point lookup algorithm optimized for performance
   - Efficient transition management to minimize computational load
   - Optimized motor allocation for real-time performance

### Lane Switchover Handling

The system includes specific logic to handle switchover between primary and recovery lanes:

```cpp
// From Tsc_unit_test.cpp
bool Tsc_unit_test::test05_InitializeAfterSwitchover_SwitchoverInVtol()
{
    // When switchover occurs in VTOL mode:
    // 1. Reset switch blenders to appropriate tracking mode
    // 2. Initialize controller states based on current attitude
    // 3. Ensure smooth transition without control discontinuities
}
```

```cpp
// From State_machines_unit_test.cpp
bool State_machines_unit_test::Test39_Recovery_TrackSplineStateMachine_Reinitialization()
{
    // When recovery lane takes control:
    // 1. Reinitialize track spline state machine to DEPARTURE_RECOVERY
    // 2. Reset state machine flags
    // 3. Transition to NOMINAL state after stability is verified
}
```

## Performance-Critical Components

1. **Closest Point Lookup** - Efficiently finds the closest point on trajectory
2. **Motor Allocation Algorithm** - Real-time allocation of motor commands
3. **Phase Transition Logic** - Ensures smooth transitions between flight phases
4. **Wind Compensation** - Rapidly adapts to changing wind conditions

## System Integration

The controllers work together in a cascaded structure:
1. Ttcg generates position/velocity commands
2. Tsc converts position/velocity errors to acceleration commands
3. Atcg converts acceleration commands to attitude commands
4. Asc/Afc convert attitude errors to angular acceleration commands
5. Mixer converts force/moment commands to motor outputs

This hierarchical structure allows for specialized control at each level while maintaining overall system stability and performance across all flight phases.

## Trajectory Stabilization Controller (Tsc)

The Tsc is responsible for converting position and velocity errors into acceleration commands:

1. **Position-to-Velocity Control**:
   - Horizontal and vertical controllers process position errors
   - Generates velocity commands to reduce position error

2. **Velocity-to-Acceleration Control**:
   - Processes velocity errors to generate acceleration commands
   - Handles different tracking modes (groundspeed vs. airspeed)

3. **Tracking Mode Management**:
   - Switches between groundspeed and airspeed tracking based on flight phase
   - Uses blending to ensure smooth transitions between modes

4. **Switchover Handling**:
   - Reinitializes controller states during lane switchover
   - Adapts to current flight phase and vehicle state

## Acceleration Allocation Command Generator (Aacg)

The Aacg transforms acceleration commands from the velocity frame to the trim frame:

1. **Frame Transformation**:
   - Converts acceleration commands between reference frames
   - Accounts for vehicle attitude and trim conditions

2. **Fixed Attitude Mode**:
   - Special handling for takeoff with fixed attitude
   - Ensures proper acceleration commands during critical flight phases

3. **Contingency Handling**:
   - Supports attitude contingency mode blending
   - Provides graceful degradation during abnormal conditions

## Referenced Context Files

The following context files provided valuable information:
- `include/controllers/Ttcg_unit_test.h` - Detailed trajectory tracking controller tests
- `include/controllers/Waca_unit_test.h` - Wind-aware command adapter functionality
- `include/controllers/Atcg_unit_test.h` - Attitude command generation tests
- `include/controllers/State_machines_unit_test.h` - Mode transition logic
- `include/controllers/mixer_unit_test.h` - Motor allocation algorithms
- `source/controllers/Ttcg_unit_test.cpp` - Implementation details of trajectory tracking
- `source/controllers/Waca_unit_test.cpp` - Wind adaptation implementation
- `source/controllers/mixer_unit_test.cpp` - Force/moment allocation implementation
- `source/controllers/State_machines_unit_test.cpp` - State machine implementation details
- `source/controllers/Tsc_unit_test.cpp` - Trajectory stabilization controller tests
- `source/controllers/Atcg_unit_test.cpp` - Attitude command generation implementation
- `source/controllers/Aacg_unit_test.cpp` - Acceleration allocation tests
- `source/controllers/Asc_unit_test.cpp` - Attitude stabilization controller tests
- `source/controllers/Controller_Status_unit_test.cpp` - Controller status reporting
- `source/controllers/Afc_unit_test.cpp` - Attitude feedback controller tests
- `source/controllers/Tcg_unit_test.cpp` - Trajectory command generation tests
- `source/controllers/Cm_pa_unit_test.cpp` - Command management tests