# Generated from:

- code/vpgen/projects.json (52 tokens)
- code/vpgen/projects0.json (855 tokens)
- code/vpgen/vpgen.bat (25 tokens)
- items/_Vlibs.submoduleinfo (43 tokens)

## With context from:

- PackageSummaries/Amazon-PrimeAir/items/ASTRO/items/sw/sw_vbootloader_astro/04_Bootloader_Core_Architecture.md (2297 tokens)
- PackageSummaries/Amazon-PrimeAir/items/ASTRO/items/sw/sw_vbootloader_astro/03_Memory_Layout_Configuration.md (2769 tokens)

---

# Astro Bootloader Build System Configuration Analysis

## 1. Hierarchical JSON Configuration Architecture

The Astro bootloader build system employs a hierarchical JSON configuration approach that defines build parameters, dependencies, and targets. This architecture consists of multiple interconnected JSON files that form a complete build specification.

### 1.1 Configuration File Hierarchy

```
projects.json
├── projects0.json
└── ../../items/_Vlibs/vpgen/projects.json (included via json_include)
```

The system uses a JSON inclusion mechanism to create a layered configuration:

- **projects.json**: Root configuration file that includes other JSON files
- **projects0.json**: Primary configuration file containing Astro-specific build definitions
- **_Vlibs/vpgen/projects.json**: Library-level configuration included from the _Vlibs submodule

This hierarchical approach allows for:
- Separation of project-specific and library-level configurations
- Reuse of common build definitions across projects
- Modular organization of build parameters

### 1.2 Configuration Structure

The JSON configuration files follow a consistent structure with these top-level sections:

```json
{
  "json_include": [],       // Files to include
  "code_defs": {},          // Generated header file constants
  "code_path": "",          // Base path for code
  "ccFlags": {},            // Compiler flags
  "lnFlags": {},            // Linker flags
  "toolChain": {},          // Toolchain configurations
  "libs": {},               // Library definitions
  "exe": {}                 // Executable targets
}
```

This structure provides a comprehensive framework for defining all aspects of the build process, from compiler settings to executable targets.

## 2. Code Definitions and Constants

The build system can generate header files with constants defined in the configuration:

```json
"code_defs": {
  "../base/code/include/generated/base_consts.h": {
    "spkt_max_data_size": "1030U"
  }
}
```

This mechanism:
- Creates the file `../base/code/include/generated/base_consts.h`
- Defines the constant `spkt_max_data_size` with value `1030U`
- Allows configuration-driven constants to be used in the code
- Enables changing constants without modifying source files

## 3. Dual-Core Executable Targets

The Astro bootloader system consists of two primary executable targets, each targeting a different processor core:

### 3.1 C28x DSP Core Target: Vbootloader_2838x_astro

```json
"Vbootloader_2838x_astro": {
  "path": "sw_vbootloader_astro/code",
  "headers": [
    "include", 
    "../../sw_vbootloader_astro_cm/code/include_astro",
    "../../../items/_Vlibs/sw_vbootloader_cm/code/include"
  ],
  "sources": [
    "source_astro",
    "../../../items/_Vlibs/DSP28x/code/source/DSP28x_CodeStartBranch.asm",
    "../../../items/_Vlibs/DSP2837x_ent/code/source/common/Kclk.cpp",
    "../../../items/_Vlibs/vbootloader/code/source/src_c2000/Sysaddr_bldr_c2000.cpp",
    "../../../items/_Vlibs/vbootloader/code/source/src_specific/Bldr_mgr_with_cm.cpp", 
    "../../../items/_Vlibs/vbootloader/code/source/src_dual"
  ],
  "hcmd": "../../../source_astro",
  "lnFlags": "lnFlags4kstack",
  "smart": "smart.bin",
  "config": {
    "2838x": {
      "dependencies": [
        "bsp", "first", "base", "FPU", "maverick", "media", "midlevel", 
        "vbootloader/2838x_ecdsa", "DSP28x", "DSP2838x_ent/cpu1_2838x", 
        "DSP2837x_ent/cpu1_2838x", "FlashAPI_F2838xD", "stanag", "DFS2", 
        "devices", "crypto_c28"
      ],
      "excludeSources": [
        "source_astro/cmd",
        "../../../items/_Vlibs/vbootloader/code/source/src_dual/Bootloader_emb.cpp"
      ],
      "libSearchPaths": [
        "source_astro/cmd",
        "../../../items/_Vlibs/DSP28x/code/source/cmd",
        "../../../items/_Vlibs/ti/code/FlashAPI_F2838xD/lib"
      ],
      "libs": ["F2838x_C28x_FlashAPI.lib"]
    }
  }
}
```

This target:
- Builds the bootloader for the C28x DSP core
- Uses source files from multiple locations including local and library paths
- Includes DSP-specific components like `DSP28x_CodeStartBranch.asm` and `Kclk.cpp`
- Depends on numerous libraries including security components (`vbootloader/2838x_ecdsa`, `crypto_c28`)
- Utilizes the TI Flash API library (`F2838x_C28x_FlashAPI.lib`)
- Excludes certain source files from the build
- Uses a 4K stack configuration (`lnFlags4kstack`)

### 3.2 Cortex-M ARM Core Target: Vbootloader_2838x_astro_cm

```json
"Vbootloader_2838x_astro_cm": {
  "path": "sw_vbootloader_astro_cm/code",
  "headers": [
    "include_astro",
    "../../../items/_Vlibs/sw_vbootloader_cm/code/include"
  ],
  "sources": [
    "source",
    "../../../items/_Vlibs/sw_vbootloader_cm/code/source/Bld_mgr_2838xCM.cpp",
    "../../../items/_Vlibs/sw_vbootloader_cm/code/source/CM_CPU1_shared.cpp",
    "../../../items/_Vlibs/sw_vbootloader_cm/code/source/main_2838x_cm.cpp",
    "../../../items/_Vlibs/sw_vbootloader_cm/code/source/startup_ccs.c",
    "../../sw_vbootloader_astro_cm/code/source/2838x_flash_astro_cm_lwip.cmd"
  ],
  "hcmd": "../../..",
  "lnFlags": "lnFlags4kstack",
  "smart": "smart.bin",
  "config": {
    "2838x_arm": {
      "type": "2838x_arm",
      "dependencies": [
        "bsp/2838x_arm", "first/2838x_arm", "base/2838x_arm", "FPU/2838x_arm", 
        "maverick/2838x_arm", "FlashAPI_F2838xD_CM/2838x_arm", "stanag/2838x_arm",
        "vbootloader/2838x_ecdsa_arm", "DSP2838x_cm/2838x_arm", "lwip/2838x_arm", 
        "DSP2838x_eth_cm/2838x_arm", "crypto/2838x_arm"
      ],
      "excludeSources": ["source/cmd"],
      "libSearchPaths": [
        "source/cmd",
        "../../../items/_Vlibs/DSP28x/code/source/cmd",
        "../../../items/_Vlibs/ti/code/FlashAPI_F2838xD_CM/lib"
      ],
      "libs": ["F2838x_CM_FlashAPI.lib"]
    }
  }
}
```

This target:
- Builds the bootloader for the Cortex-M ARM core
- Includes ARM-specific components like `startup_ccs.c` and `main_2838x_cm.cpp`
- Depends on ARM-specific versions of libraries (indicated by `/2838x_arm` suffix)
- Includes networking capabilities through `lwip/2838x_arm` and `DSP2838x_eth_cm/2838x_arm`
- Uses the ARM-specific Flash API library (`F2838x_CM_FlashAPI.lib`)
- Includes a linker command file specifically for the ARM core with lwIP support (`2838x_flash_astro_cm_lwip.cmd`)

## 4. Security Components

The build configuration includes several security-related components:

### 4.1 ECDSA Signature Verification

Both cores include ECDSA (Elliptic Curve Digital Signature Algorithm) components:
- C28x DSP: `vbootloader/2838x_ecdsa` dependency
- Cortex-M ARM: `vbootloader/2838x_ecdsa_arm` dependency

These components provide secure boot capabilities by verifying digital signatures of firmware images before execution.

### 4.2 Cryptographic Libraries

Both cores include cryptographic libraries:
- C28x DSP: `crypto_c28` dependency
- Cortex-M ARM: `crypto/2838x_arm` dependency

These libraries likely provide:
- Hash functions (SHA-256)
- Encryption/decryption algorithms
- Key management utilities
- Secure storage mechanisms

## 5. Network Capabilities

The Cortex-M ARM core includes networking capabilities through:

### 5.1 lwIP TCP/IP Stack

The ARM core depends on `lwip/2838x_arm`, which is the lightweight IP (lwIP) TCP/IP stack. This provides:
- TCP/IP protocol implementation
- Socket API
- Network interface management
- DHCP client functionality
- DNS resolution

### 5.2 Ethernet Driver

The ARM core also includes `DSP2838x_eth_cm/2838x_arm`, which is the Ethernet driver for the F2838x device. This provides:
- Ethernet MAC and PHY interface
- Packet transmission and reception
- Link status monitoring
- Hardware acceleration features

### 5.3 Ethernet Configuration

The linker command file `2838x_flash_astro_cm_lwip.cmd` specifically includes lwIP support, indicating that the ARM core is responsible for network communication in the system.

## 6. Build Process

### 6.1 vpgen Script Execution

The build process is initiated by the `vpgen.bat` script:

```batch
cd ..\..\items\_Vlibs\vpgen 
python vpgen.py ..\..\..\code\vpgen\projects.json
cd ..\..\..\code\vpgen
```

This script:
1. Changes directory to the vpgen tool location
2. Executes the Python-based vpgen tool with the projects.json file as input
3. Returns to the original directory

### 6.2 vpgen Tool Operation

The vpgen tool:
1. Parses the hierarchical JSON configuration
2. Resolves all includes and dependencies
3. Generates build files for the specified toolchain
4. Creates header files with defined constants
5. Sets up the build environment for both C28x DSP and Cortex-M ARM targets

### 6.3 Build File Generation

The vpgen tool likely generates:
- Makefiles or project files for the build system
- Compiler and linker command files
- Generated header files with constants
- Build scripts for both cores

## 7. Submodule Management

The Astro bootloader relies on the `_Vlibs` submodule, which contains shared libraries and components:

```
fd71c59c08701697cfb71bbc0ee066b5449ffe5e items/ASTRO/items/sw/sw_vbootloader_astro/items/_Vlibs (remotes/origin/feature/Amazon-PrimeAir/red-label-1-release-9-gfd71c59c087)
```

This submodule:
- Is pinned to a specific commit (`fd71c59c087...`)
- Belongs to the Amazon PrimeAir feature branch
- Contains shared libraries used by both cores
- Provides common functionality like Flash API, cryptography, and bootloader components

## 8. Memory Layout and Configuration

The build system defines memory layouts for both cores:

### 8.1 C28x DSP Memory Layout

Based on the context files, the C28x DSP core uses:
- Flash starting at 0x80000 (word address)
- Total flash size of 0x40000 words
- Bootloader region: 0x80000 - 0x8FFFF (0x10000 words)
- Application region: 0x90000 - 0xBFFFF (0x30000 words)
- Various RAM regions including RAMM, RAML, RAMS

### 8.2 Cortex-M ARM Memory Layout

The Cortex-M ARM core uses:
- Flash starting at 0x200000 (byte address)
- Total flash size of 0x80000 bytes
- Bootloader region: 0x200000 - 0x21FFFF (0x20000 bytes)
- Application region: 0x220000 - 0x27FFFF (0x60000 bytes)
- RAM regions including C0RAM, C1RAM, ESRAM

### 8.3 Inter-Processor Communication

The memory layout includes dedicated regions for inter-processor communication:
- CPUTOCMRAM: C1 to CM communication
- CMTOCPURAM: CM to C1 communication
- Various message RAM regions for communication between cores

## 9. Build System Dependencies

The build system relies on several key dependencies:

### 9.1 Core Libraries

Both cores depend on common libraries:
- `bsp`: Board Support Package
- `first`: Likely initialization code
- `base`: Base functionality
- `FPU`: Floating Point Unit support
- `maverick`: Unknown functionality
- `stanag`: STANAG protocol implementation

### 9.2 Hardware-Specific Libraries

Each core has hardware-specific dependencies:
- C28x DSP: `DSP28x`, `DSP2838x_ent/cpu1_2838x`, `DSP2837x_ent/cpu1_2838x`
- Cortex-M ARM: `DSP2838x_cm/2838x_arm`

### 9.3 Flash API Libraries

Both cores include Flash API libraries for flash memory operations:
- C28x DSP: `FlashAPI_F2838xD` and `F2838x_C28x_FlashAPI.lib`
- Cortex-M ARM: `FlashAPI_F2838xD_CM/2838x_arm` and `F2838x_CM_FlashAPI.lib`

## 10. Conclusion: Integrated Dual-Core Bootloader Architecture

The Astro bootloader build system creates a sophisticated dual-core bootloader with:

1. **Coordinated Core Operation**:
   - C28x DSP core handling main system control
   - Cortex-M ARM core managing network communication

2. **Comprehensive Security Features**:
   - ECDSA signature verification for secure boot
   - Cryptographic libraries for secure operations
   - Secure memory management

3. **Network Connectivity**:
   - lwIP TCP/IP stack on the ARM core
   - Ethernet driver for network communication
   - Configurable network parameters

4. **Flexible Build Configuration**:
   - Hierarchical JSON configuration
   - Dependency management
   - Generated constants and headers

5. **Shared Library Architecture**:
   - Common functionality in _Vlibs submodule
   - Core-specific implementations where needed
   - Coordinated memory layout for inter-core communication

This build system creates a secure, network-capable bootloader that leverages the strengths of both the C28x DSP and Cortex-M ARM cores in the TI F2838x device.

## Referenced Context Files

The following context files provided valuable information for this analysis:

1. **04_Bootloader_Core_Architecture.md** - Provided details about the bootloader architecture, core components, initialization sequence, and inter-core communication mechanisms.

2. **03_Memory_Layout_Configuration.md** - Provided information about the memory layout for both cores, addressing schemes, and inter-processor communication regions.