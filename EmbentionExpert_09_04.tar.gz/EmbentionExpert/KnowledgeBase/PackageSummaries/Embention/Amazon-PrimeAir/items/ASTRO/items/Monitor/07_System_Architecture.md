# Generated from:

- items/pdi_Monitor/setup/ver_spdif_blocks.xml (181 tokens)
- items/pdi_Monitor/setup/ver_spdif_cfgmgr.xml (11573 tokens)
- items/pdi_Monitor/setup/ver_spdif_mblocks.xml (58 tokens)
- items/pdi_Monitor/setup/ver_spdif_mbit.xml (1763 tokens)
- items/pdi_Monitor/setup/ver_spdif_stg_subsystem.xml (2237 tokens)
- items/pdi_Monitor/setup/ver_spdif_vehicle_ident.xml (858 tokens)
- items/pdi_Monitor/setup/ver_spdif_fmset.xml (2915 tokens)
- items/pdi_Monitor/setup/ver_spdif_pk0.xml (3407 tokens)
- items/pdi_Monitor/setup/ver_spdif_compiled_block0_exe.xml (67 tokens)
- items/pdi_Monitor/setup/ver_spdif_compiled_block0_io.xml (102 tokens)
- items/pdi_Monitor/setup/ver_spdif_maction.xml (122 tokens)
- items/pdi_Monitor/setup/ver_spdif_mfmgr.xml (57 tokens)
- items/pdi_Monitor/setup/ver_spdif_mcal.xml (77 tokens)
- items/pdi_Monitor/setup/ver_spdif_evact.xml (50 tokens)
- items/pdi_Monitor/setup/ver_spdif_arcx.xml (49 tokens)
- items/pdi_Monitor/setup/ver_spdif_chklist.xml (52 tokens)
- items/pdi_Monitor/setup/ver_spdif_mdev.xml (86 tokens)
- items/pdi_Monitor/setup/ver_spdif_pdi_mode.xml (63 tokens)
- items/pdi_Monitor/setup/ver_spdif_mmodes.xml (51 tokens)
- items/pdi_Monitor/setup/ver_spdif_m4xow.xml (62 tokens)
- items/pdi_Monitor/setup/ver_spdif_freqmgr.xml (75 tokens)
- items/pdi_Monitor/setup/ver_spdif_events.xml (51 tokens)
- items/pdi_Monitor/setup/ver_spdif_limits.xml (51 tokens)
- items/pdi_Monitor/setup/ver_spdif_cbitcfg.xml (68 tokens)
- items/pdi_Monitor/setup/ver_spdif_stg_mcfg.xml (53 tokens)
- items/pdi_Monitor/setup/ver_spdif_mmission.xml (53 tokens)
- items/pdi_Monitor/setup/ver_spdif_mexvar.xml (58 tokens)
- items/pdi_Monitor/setup/ver_spdif_metaop.xml (58 tokens)
- items/pdi_Monitor/setup/ver_spdif_stg_mset.xml (53 tokens)
- items/pdi_Monitor/setup/ver_spdif_sniffer.xml (52 tokens)
- items/pdi_Monitor/setup/ver_spdif_mevent.xml (311 tokens)
- items/pdi_Monitor/setup/ver_spdif_mname.xml (57 tokens)
- items/pdi_Monitor/setup/ver_spdif_oprrng.xml (51 tokens)
- items/pdi_Monitor/setup/ver_spdif_mcheck.xml (156 tokens)
- items/pdi_Monitor/setup/ver_spdif_mxplane.xml (76 tokens)
- items/pdi_Monitor/setup/ver_spdif_mevact.xml (58 tokens)
- items/sw_Monitor/code/main2/code/source/Blockfactory_pam.cpp (2921 tokens)

---

# PDI Monitor System Architecture Analysis

## 1. System Overview

The PDI Monitor system is a specialized monitoring subsystem that operates within a larger avionics framework. Based on the analyzed files, it appears to be a critical component responsible for system monitoring, mission data processing, and safety-critical operations in what appears to be an unmanned aerial vehicle (UAV) or similar autonomous system.

## 2. Core Architecture Components

### 2.1 Blockfactory

The `Blockfactory` class serves as the central architectural component of the PDI Monitor system. It acts as a factory for creating and managing various functional blocks that make up the monitoring system.

Key responsibilities:
- Initializes and manages the entire monitoring subsystem
- Coordinates communication between different components
- Handles system state transitions
- Manages resource allocation for monitoring blocks

### 2.2 Monitor Builder

The `Monitor_builder` class is responsible for constructing the monitoring system at runtime. It:
- Assembles the monitoring components based on configuration
- Validates the build process
- Provides access to the constructed monitoring subsystems
- Manages the lifecycle of monitoring components

### 2.3 Input/Output Managers

The system uses specialized input and output managers to handle data flow:

#### Input Managers:
- `Mon_input_manager`: Handles general monitoring inputs
- `Mon_nav_input_manager`: Processes navigation-specific inputs
- `Mmdp_input_manager`: Manages mission data processing inputs

#### Output Managers:
- `Mon_output_manager`: Handles monitoring outputs, alerts, and log data

## 3. Operational Modes

The PDI Monitor system operates in two distinct modes:

### 3.1 Mission Mode

When the system is in mission mode:
- The full monitoring system is built and activated
- Navigation monitoring is enabled
- Mission plan processing is active
- Safety monitoring and alerts are operational
- PDS (Payload Deployment System) commands are processed

### 3.2 Maintenance Mode

When the system is in maintenance mode:
- The full monitoring system is not built ("monitor" never gets built)
- Only basic maintenance operations are performed
- The PDS manager operates in maintenance mode
- Configuration can be modified through maintenance actions

The mode is tracked in the `mon_drone_mode` system variable, which is updated during each processing cycle.

## 4. Initialization Sequence

The initialization sequence follows these steps:

1. **Constructor Phase**:
   - Allocate memory for internal components
   - Initialize mission plan and mission data structures
   - Set up communication handlers
   - Initialize site configuration
   - Create the monitor builder object
   - Initialize navigation position and rotation matrices
   - Register maintenance action handlers

2. **Post-PDI Load Phase**:
   - Build the monitoring system using the monitor builder
   - If build is successful, register additional communication handlers
   - Set up DGNSS correction handlers
   - Register mission reset command handlers
   - Set up on-ground controller info handlers
   - Register recovery mission readiness handlers

## 5. Execution Flow

The system operates in a cyclic execution pattern:

### 5.1 Pre-GNC Step
1. Update the drone mode system variable
2. Execute the monitor step function
3. If monitor is built successfully:
   - Get PDS door command from monitor
   - Execute PDS manager in mission mode with the command
4. If monitor is not built:
   - Execute PDS manager in maintenance mode

### 5.2 GNC Step
The GNC step appears to be empty in the current implementation, suggesting that the monitoring system's primary work happens in the pre-GNC phase.

## 6. Component Relationships

The system uses a hierarchical component structure:

```
Blockfactory
├── Monitor_builder
│   ├── Mon_input_manager
│   ├── Mon_nav_input_manager
│   ├── Blk_pa_mon
│   └── Blk_pa_mon_nav
├── Mission_plan
├── Mission_plan_data
├── Cy_file_transfer
├── Mmdp_input_manager
├── Site_config
├── Cy_maint_action
└── Pds_manager
```

## 7. Communication Architecture

The system uses a message-based communication architecture:

1. **Cyphal Communication**:
   - File transfers (`cyp_file_transfer`)
   - Mission plan uploads (`cyp_pa_upload_mission_plan_wrapper_mon`)
   - Maintenance actions (`cyp_maintenance_action_req`, `cyp_maintenance_action_res`)
   - DGNSS corrections (`cyp_dgnss_correct_dcomms`, `cyp_dgnss_correct`)
   - Mission reset commands (`cyp_pa_mission_reset_command`)
   - On-ground controller info (`cyp_onground_controller_info`)
   - Recovery mission readiness (`cyp_pa_recovery_mission_readiness`)

2. **Internal Communication**:
   - Direct function calls between components
   - Shared data structures
   - System variables for state sharing

## 8. Configuration Management

The system uses a configuration management approach with several components:

1. **Site Configuration**:
   - Managed by the `Site_config` class
   - Can be set and retrieved through maintenance actions

2. **System Configuration**:
   - Recovery parameters (`cfg_amz_rec_param`)
   - Monitor parameters (`cfg_amz_mon_param`)

3. **XML Configuration Files**:
   - Various XML files define system parameters, blocks, modes, and other configuration elements
   - These files appear to be loaded during system initialization

## 9. State Transitions

The system transitions between states based on:

1. **Mode Changes**:
   - Transitions between mission and maintenance modes
   - Mode is tracked in the `mon_drone_mode` system variable

2. **Build Status**:
   - The monitor build status determines whether the system operates in full monitoring mode
   - If build fails, the system operates in a limited capacity

## 10. Safety and Recovery Features

The system includes several safety and recovery features:

1. **PDS Management**:
   - The PDS (Payload Deployment System) is managed differently in mission vs. maintenance modes
   - Commands to the PDS are vetted by the monitor before execution

2. **Recovery Mission Readiness**:
   - The system processes recovery mission readiness messages
   - This suggests a capability to enter recovery modes when needed

3. **Mission Reset**:
   - The system can process mission reset commands
   - This allows for recovery from mission anomalies

## 11. Memory Management

The system uses a structured memory management approach:

1. **Allocators**:
   - Internal allocator for volatile memory
   - External allocator for persistent structures

2. **Memory Blocks**:
   - Fixed-size memory block for volatile operations (`mem_volatile_sz = 14000`)
   - Allocated memory for mission data and other structures

## 12. File-by-File Breakdown

### 12.1 Configuration Files

The system uses numerous XML configuration files:

- `ver_spdif_blocks.xml`: Defines program blocks and steps
- `ver_spdif_cfgmgr.xml`: Configuration manager settings with mode definitions
- `ver_spdif_mblocks.xml`: Defines monitoring blocks
- `ver_spdif_mbit.xml`: Defines monitoring bits with IDs and descriptions
- `ver_spdif_stg_subsystem.xml`: Subsystem configuration
- `ver_spdif_vehicle_ident.xml`: Vehicle identification information
- `ver_spdif_fmset.xml`: Field set definitions for data processing
- `ver_spdif_pdi_mode.xml`: PDI mode configuration
- `ver_spdif_freqmgr.xml`: Frequency manager settings for acquisition and GNC

### 12.2 Implementation Files

- `Blockfactory_pam.cpp`: Main implementation of the Blockfactory class that orchestrates the PDI Monitor system

## 13. Key Subsystems

### 13.1 Mission Planning

The system includes components for mission planning and execution:
- `Mission_plan`: Manages the current mission plan
- `Mission_plan_data`: Stores mission data
- `Cy_file_transfer`: Handles file transfers for mission data
- `Mmdp_input_manager`: Processes mission data inputs

### 13.2 Navigation Monitoring

Navigation monitoring is a key function:
- `Mon_nav_input_manager`: Processes navigation inputs
- `Blk_pa_mon_nav`: Navigation monitoring block
- Navigation position and rotation tracking

### 13.3 PDS Management

The Payload Deployment System (PDS) is managed differently based on mode:
- In mission mode: Commands are vetted by the monitor
- In maintenance mode: Basic maintenance operations are performed

### 13.4 Maintenance Actions

The system supports maintenance actions:
- Setting and retrieving site configuration
- Other maintenance operations through the `Cy_maint_action` class

## 14. System State and Mode Transitions

The system state transitions can be visualized as:

```
                  ┌───────────────────┐
                  │    System Boot    │
                  └─────────┬─────────┘
                            │
                            ▼
                  ┌───────────────────┐
                  │  Constructor Init │
                  └─────────┬─────────┘
                            │
                            ▼
                  ┌───────────────────┐
                  │   Post PDI Load   │
                  └─────────┬─────────┘
                            │
                            ▼
           ┌────────────────┴───────────────┐
           │                                │
           ▼                                ▼
┌────────────────────┐            ┌──────────────────┐
│   Mission Mode     │◄───────────┤ Maintenance Mode │
│ (Monitor Built)    │            │ (Monitor Not     │
└────────┬───────────┘            │     Built)       │
         │                        └──────────────────┘
         │
         ▼
┌────────────────────┐
│  Cyclic Execution  │
│  - Monitor Step    │
│  - PDS Management  │
└────────────────────┘
```

## 15. Conclusion

The PDI Monitor system is a sophisticated monitoring and safety subsystem designed for autonomous vehicle operations. It features a flexible architecture that adapts to different operational modes, robust configuration management, and comprehensive monitoring capabilities. The system is built around a factory pattern that constructs monitoring components based on configuration, with clear separation between mission and maintenance operations.

The architecture supports both normal mission operations and maintenance activities, with appropriate safety measures and recovery capabilities. The system's modular design allows for extension and customization while maintaining core monitoring functionality.