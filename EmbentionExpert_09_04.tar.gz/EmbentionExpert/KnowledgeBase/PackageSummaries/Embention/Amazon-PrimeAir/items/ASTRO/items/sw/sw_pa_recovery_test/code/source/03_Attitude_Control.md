# Generated from:

- AttitudeTrajectoryCommandGenerator_Unit_Test.cpp (17209 tokens)
- Aacg_pa_test.cpp (3395 tokens)
- Aacg_pa_test_vec.cpp (7241 tokens)

---

# Attitude Control System: ATCG and AACG Components

This document provides a comprehensive summary of the Attitude Trajectory Command Generator (ATCG) and Attitude Acceleration Command Generator (AACG) components of the attitude control system, based on the provided source files.

## 1. Attitude Trajectory Command Generator (ATCG)

The ATCG is responsible for generating attitude commands based on trajectory information. It handles the transition between different flight modes and provides appropriate attitude references.

### 1.1 Core Functionality

The ATCG generates three key quaternion outputs:
- `q_vel_from_ned`: Attitude command for velocity frame relative to NED frame
- `q_pos_from_ned`: Attitude command for position frame relative to NED frame
- `q_grtraj_from_ned`: Attitude command for gravity-compensated trajectory frame relative to NED frame

### 1.2 Flight Mode Handling

The ATCG handles different flight modes through a blending mechanism:
- **VTOL Mode**: Used for low-speed flight, prioritizing vertical takeoff/landing capabilities
- **WBF Mode**: Used for high-speed flight, prioritizing wing-borne flight characteristics
- **Intermediate Mode**: Blends between VTOL and WBF modes based on airspeed

### 1.3 Weathervaning Logic

The ATCG implements a weathervaning system that aligns the vehicle with the relative wind direction:

```
run_vtol_hysteresis_logic(v_ne_wind2pos_m_per_s, heading_cmd_no_weathervaning_rad, land_mode)
```

This function:
- Determines if VTOL hysteresis should be enabled based on airspeed
- Updates the low-speed velocity reference vector (`x_vel_lowspeed_hysteresis_ned`)
- Handles special cases for landing modes
- Applies rate limiting to prevent abrupt attitude changes

### 1.4 Attitude Generation Methods

#### 1.4.1 Velocity Frame Attitude

```
vel_from_ned_attitude(input, attitude_logic_interp_param, q_vel_from_ned)
```

This method:
- Computes the velocity frame attitude based on the current flight mode
- For VTOL mode: Uses the hysteresis-based velocity reference
- For WBF mode: Aligns with the air-relative velocity vector
- For intermediate speeds: Blends between VTOL and WBF attitudes

#### 1.4.2 Position Frame Attitude

```
pos_from_ned_attitude(input, q_vel_from_ned, attitude_logic_interp_param, q_pos_from_ned)
```

This method:
- Computes the position frame attitude based on the current flight mode
- For VTOL mode: Uses the velocity frame attitude
- For WBF mode: Aligns with the ground-relative velocity vector
- For intermediate speeds: Blends between VTOL and WBF attitudes

#### 1.4.3 Gravity-Compensated Trajectory Frame Attitude

```
gr_traj_from_ned_attitude(input, q_vel_from_ned, attitude_logic_interp_param, q_grtraj_from_ned)
```

This method:
- Computes the gravity-compensated trajectory frame attitude
- Accounts for acceleration commands and gravity compensation
- Blends between VTOL and WBF attitudes based on airspeed

### 1.5 State Management

The ATCG maintains internal state variables:
- `is_vel_frame_initialized`: Tracks if the velocity frame has been initialized
- `is_vtol_hysteresis_enabled`: Indicates if VTOL hysteresis logic is active
- `x_vel_lowspeed_hysteresis_ned`: Stores the low-speed velocity reference vector

### 1.6 Frame Transformations

The ATCG handles multiple reference frames:
- NED (North-East-Down): Global reference frame
- VTOLNCG: VTOL navigation control frame
- TRIM0NCG: Trim navigation control frame
- VEL: Velocity-aligned frame
- POS: Position-aligned frame
- GRTRAJ: Gravity-compensated trajectory frame

## 2. Attitude Acceleration Command Generator (AACG)

The AACG transforms acceleration commands from the velocity frame to the trim frame and generates appropriate attitude commands for the vehicle.

### 2.1 Core Functionality

The AACG processes acceleration commands and generates:
- High-frequency acceleration commands in the TRIM0NCG frame
- Low-frequency acceleration commands in the TRIMNCG frame
- Feedforward angular velocity commands
- Attitude commands for the TRIM0NCG frame

### 2.2 Input Processing

The AACG takes as input:
- Low-frequency acceleration commands in velocity frame
- High-frequency acceleration commands in velocity frame
- Current attitude estimates
- Dynamic pressure and air density information
- Vehicle mode information

### 2.3 Control Modes

The AACG supports different control modes:
- `POSITION_WITH_FIXED_ATTITUDE`: Uses a fixed attitude command
- `POSITION`: Uses trajectory-derived attitude commands
- Special handling for `TAKEOFF` and `LAND` modes

### 2.4 Acceleration Command Processing

The AACG transforms acceleration commands between frames:
- Transforms low-frequency commands from velocity frame to trim frame
- Transforms high-frequency commands from velocity frame to trim frame
- Computes feedforward angular velocity commands for smooth transitions

### 2.5 Failure Handling

The AACG processes rotor health status information:
- Detects failed or windmilling rotors
- Adjusts control strategy based on the health status
- Supports different failure types (healthy, floating, etc.)

## 3. Testing Methodology

### 3.1 ATCG Unit Tests

The ATCG is tested through a comprehensive set of unit tests:

1. `test_VtolHysteresisLogicFixedDirection`: Tests the VTOL hysteresis logic with a fixed direction
2. `test_VelFromNedAttitudeWbf`: Tests the wing-borne flight attitude generation
3. `test_PosFromNedAttitudeVtol`: Tests the VTOL position frame attitude generation
4. `test_PosFromNedAttitudeWbf`: Tests the WBF position frame attitude generation
5. `test_PosFromNedAttitudeIntermediateSpeed`: Tests blending between VTOL and WBF attitudes
6. `test_GrTrajFromNedAttitudeIntermediateSpeed`: Tests gravity-compensated trajectory frame attitude generation
7. `test_VtolHysteresisLogicNoWeathervaning`: Tests VTOL hysteresis without weathervaning
8. `test_VtolHysteresisLogicNoWeathervaningFixedAttitude`: Tests VTOL hysteresis with fixed attitude
9. `test_VtolHysteresisLogicWeathervaningSlowDescentLand`: Tests weathervaning during slow descent landing
10. `test_UpdateVelXFromNedRateLimited`: Tests rate-limited updates to the velocity reference

### 3.2 ATCG MATLAB Tests

The ATCG is also tested against MATLAB reference implementations:

1. `matlab_test0_VtolHysteresisEngaged`: Tests VTOL hysteresis engagement
2. `matlab_test1_VtolHysteresisRateLimit`: Tests VTOL hysteresis rate limiting
3. `matlab_test2_WbfAttitudeNoAcceleration`: Tests WBF attitude without acceleration
4. `matlab_test3_Example1aVtolConstWinds`: Tests VTOL mode with constant winds
5. `matlab_test4_Example1cWbfConstWinds`: Tests WBF mode with constant winds
6. `matlab_test5_Example1eItConstWinds`: Tests intermediate mode with constant winds
7. `matlab_test6_Example1gOtConstWinds`: Tests another mode with constant winds
8. `matlab_test7_VtolHoverDiagonalAscentHover`: Tests VTOL hover and diagonal ascent
9. `matlab_test8_WbfSTurn`: Tests WBF S-turn maneuver

### 3.3 AACG Tests

The AACG is tested through:

1. Basic functionality tests with different control modes
2. Tests with different rotor health statuses
3. Vector tests comparing against reference outputs

## 4. Quaternion Operations

Both components make extensive use of quaternion operations for attitude representation and manipulation:

- Quaternion multiplication for combining rotations
- Quaternion conjugation for inverse rotations
- SLERP (Spherical Linear Interpolation) for blending attitudes
- Conversion between quaternions and rotation matrices

Example quaternion operations:
```cpp
// Quaternion multiplication
q_trim_from_vtol_conj.copy(q_trim_from_vtol);
q_trim_from_vtol_conj.conjugate();

// Quaternion-based vector rotation
q_trim_from_vtol_conj.b2n(longitudinal_plane_normal_trim, longitudinal_plane_normal_vtol);

// Quaternion interpolation
Pa_irquat::quaternion_slerp(q_vtol_grtraj_from_ned, q_wbf_grtraj_from_ned, attitude_logic_interp_param, q_exp_grtraj_from_ned);
```

## 5. Frame Transformations

The system performs numerous frame transformations:

### 5.1 Key Reference Frames

- **NED**: North-East-Down global reference frame
- **VTOLNCG**: VTOL navigation control frame
- **TRIM0NCG**: Trim navigation control frame (zero trim)
- **VEL**: Velocity-aligned frame
- **POS**: Position-aligned frame
- **GRTRAJ**: Gravity-compensated trajectory frame

### 5.2 Transformation Methods

```cpp
// Transform from NED to velocity frame
uut->vel_from_ned_attitude(in.input, attitude_logic_interp_param, out.output.q_vel_from_ned);

// Transform from velocity frame to position frame
uut->pos_from_ned_attitude(in.input, out.output.q_vel_from_ned, attitude_logic_interp_param, out.output.q_pos_from_ned);

// Transform acceleration commands
Maverick::Rvector3 a_ned_m_per_s2;
a_ned_m_per_s2.copy(a_ned_ned2pos_m_per_s2);
a_ned_m_per_s2.vecsub(g_m_per_s2);
```

## 6. Integration with Other Control Components

The ATCG and AACG integrate with other control components:

- The ATCG provides attitude commands to the AACG
- The AACG provides acceleration commands to the Mixer
- Both components interact with the state machine to handle different flight modes
- The components use parameters from the `Controllers_param_mk30` configuration

## 7. Parameter Configuration

Both components are configured through parameter structures:

### 7.1 ATCG Parameters

```cpp
// MK30EV Params
common_param_0.controller_frequency_hz = 100.0;
common_param_0.r_vtol_from_bul[Ku16::u0] = -2.8669176363e-01;
// ... additional parameters ...
```

### 7.2 AACG Parameters

The AACG uses parameters from:
- `Pa_blocks::Vsdk_controllers_params::get_instance().aacg`
- `Controllers_param_mk30::get_instance().aacg`
- `Pa_blocks::Pa_scheduler::get_instance()`

## 8. Validation Approach

The validation approach includes:

1. **Unit Testing**: Testing individual functions with controlled inputs
2. **MATLAB Comparison**: Comparing outputs with MATLAB reference implementations
3. **Vector Testing**: Testing with pre-recorded input/output vectors
4. **Mode Testing**: Testing behavior in different flight modes
5. **Failure Testing**: Testing behavior with different rotor health statuses

## 9. Performance Considerations

The code includes several performance optimizations:

- Pre-computed rotation matrices and quaternions
- Efficient vector operations
- Hysteresis mechanisms to prevent oscillations
- Rate limiting to ensure smooth transitions

## Referenced Context Files

The following context files provided useful information for understanding the system:
- `AttitudeTrajectoryCommandGenerator_Unit_Test.cpp`: Detailed test cases for the ATCG
- `Aacg_pa_test.cpp`: Basic test cases for the AACG
- `Aacg_pa_test_vec.cpp`: Vector-based tests for the AACG