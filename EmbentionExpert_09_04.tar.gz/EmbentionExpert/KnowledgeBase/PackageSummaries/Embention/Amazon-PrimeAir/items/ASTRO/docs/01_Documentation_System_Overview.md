# Generated from:

- Amazon-PrimeAir/items/ASTRO/docs/03_Polarion_Workitem_Core.md (3002 tokens)
- Amazon-PrimeAir/items/ASTRO/docs/02_Polarion_Workitem_Type_Handlers.md (3128 tokens)
- Amazon-PrimeAir/items/ASTRO/docs/02_Data_Conversion_Utilities.md (3417 tokens)
- Amazon-PrimeAir/items/ASTRO/docs/02_Build_Tools.md (2166 tokens)

---

# Comprehensive Documentation Generation System Overview

## System Purpose and Architecture

The documentation generation system is a sophisticated toolchain designed to extract information from Polarion work items and transform it into structured documentation in LaTeX format. The system supports the development process by automatically generating various types of documentation including requirements specifications, test cases, traceability matrices, and diagrams.

The system follows a modular architecture with specialized components for different work item types and conversion processes. It is organized into multiple project directories (ASTRO-PRQChecklists, ASTRO-VS, SDD-VS) that contain identical scripts, suggesting a standardized approach to documentation generation across different project components.

## Key Components and Their Relationships

### 1. Polarion Work Item Core (polarion_workitem.py)

This is the foundation of the system, responsible for:
- Connecting to Polarion via web service API
- Retrieving work items based on specific queries
- Processing raw work items into structured objects
- Generating LaTeX content for requirements (PR, HLR, LLR)
- Handling diagram extraction and processing

The core component establishes the basic pattern for work item extraction that is extended by specialized handlers.

### 2. Specialized Work Item Handlers

Four specialized handlers extend the core functionality to process specific types of work items:

- **Test Case Handler (polarion_workitem_tc.py)**:
  - Extracts test case descriptions
  - Parses descriptions with special markers (##)
  - Generates LaTeX itemized lists for different test types

- **Traceability Document Handler (polarion_workitem_td.py)**:
  - Generates traceability matrices between different work item types
  - Implements complex relationship handling
  - Creates bidirectional relationship mappings
  - Validates requirement relationships

- **Test Steps Handler (polarion_workitem_ts.py)**:
  - Extracts test steps from test cases
  - Outputs raw text files for further processing
  - Integrates with HTML-to-CSV conversion

- **Test Results Handler (polarion_workitem_tr.py)**:
  - Extracts test results and formats them as LaTeX
  - Handles attachments (downloading PDFs)
  - Reports non-passing test results

### 3. Data Conversion Utilities

Two utilities transform data between different formats:

- **HTML to LaTeX Converter (htmltocsv.py)**:
  - Processes HTML tables with special markers
  - Converts HTML content to LaTeX format
  - Handles special characters and acronyms

- **CSV to LaTeX Converter (csvtolatex.py)**:
  - Transforms CSV data into LaTeX table format
  - Supports customizable styling options
  - Creates tables suitable for inclusion in documents

### 4. Code Visualization Tools

- **Doxygen Call Graph Generator (_run_callgraph.bat)**:
  - Configures and executes Doxygen to generate call graphs
  - Creates visual representations of code relationships
  - Complements text-based documentation with structural diagrams

## Data Flow and Workflow

The complete documentation generation workflow follows these steps:

1. **Work Item Extraction**:
   - The core system and specialized handlers query Polarion for specific work items
   - Each handler focuses on different work item types (requirements, test cases, etc.)
   - Work items are filtered based on type, status, and relationships

2. **Data Processing**:
   - Raw work items are processed into structured objects
   - Special fields (descriptions, attachments) receive custom processing
   - Relationships between work items are mapped and validated

3. **Format Conversion**:
   - HTML content is converted to LaTeX using htmltocsv.py
   - CSV data is transformed into LaTeX tables using csvtolatex.py
   - Diagrams and attachments are downloaded and saved in appropriate formats

4. **LaTeX Document Generation**:
   - Each component generates LaTeX files for its specific domain
   - Files are written to standardized locations
   - Special formatting is applied based on content type

5. **Code Visualization** (parallel process):
   - Doxygen analyzes source code to generate call graphs
   - Visual representations complement text-based documentation

## System Integration Points

The system integrates several technologies and components:

1. **Polarion Integration**:
   - Uses Polarion web service API to retrieve work items
   - Constructs specific queries based on work item types
   - Downloads attachments for diagrams and test results

2. **LaTeX Document System**:
   - All components ultimately produce LaTeX output
   - Uses standardized formatting for different content types
   - Supports complex document structures with cross-references

3. **External Tools**:
   - Doxygen for code visualization
   - Web browser for viewing generated documentation
   - Possibly LaTeX compiler (not shown in provided files) for final PDF generation

4. **Common Libraries**:
   - Tools.polarionWebService for Polarion connectivity
   - Tools.workItemLib for work item processing
   - Tools.acronyms for acronym handling
   - parseTexLib for text formatting and conversion

## Project Structure Insights

The system is organized into multiple project directories with identical scripts, suggesting:

1. **Independent Components**: Each project component (ASTRO-PRQChecklists, ASTRO-VS, SDD-VS) operates independently with its own set of tools.

2. **Standardized Approach**: The identical implementation across directories indicates a standardized documentation process.

3. **Common Work Item Backbone**: All handlers operate on work items linked to a specific work item (VER-4014), creating a unified documentation set.

4. **Documentation-Centric Workflow**: The system supports a comprehensive documentation process that covers requirements, design, testing, and traceability.

## Types of Documentation Generated

The system generates several types of documentation:

1. **Requirements Documentation**:
   - Product Requirements (PR.tex)
   - High-Level Requirements (HLR.tex)
   - Low-Level Requirements (LLR.tex)
   - PDI Requirements (PDIR.tex)

2. **Design Documentation**:
   - Software Algorithms (SW_Algorithms.tex)
   - Software Diagrams (SW_Diagrams.tex)
   - Diagram images (figures/*.png)

3. **Test Documentation**:
   - Test Cases (categorized by test type)
   - Test Steps (in text and CSV formats)
   - Test Results (with attachments)

4. **Traceability Documentation**:
   - Requirements traceability matrices
   - Test coverage matrices
   - Design-to-implementation mappings

5. **Code Structure Visualization**:
   - Function call graphs
   - Class diagrams (via Doxygen)

## System Purpose and Value

The documentation generation system serves several important purposes in the development process:

1. **Automation of Documentation Tasks**: Reduces manual effort in creating and maintaining documentation.

2. **Consistency Across Documents**: Ensures uniform formatting and structure across all documentation.

3. **Traceability**: Maintains relationships between requirements, design, and test artifacts.

4. **Verification Support**: Helps verify that all requirements are properly tested and implemented.

5. **Process Compliance**: Supports compliance with development standards that require specific documentation.

6. **Knowledge Transfer**: Creates comprehensive documentation that helps new team members understand the system.

The system's value lies in its ability to automatically generate up-to-date, consistent documentation directly from work items in Polarion, ensuring that documentation accurately reflects the current state of the project and reducing the manual effort required to maintain documentation.

## Conclusion

The documentation generation system is a comprehensive toolchain that extracts information from Polarion work items and transforms it into structured LaTeX documentation. It follows a modular architecture with specialized components for different work item types and conversion processes. The system supports the development process by automatically generating various types of documentation, ensuring consistency, traceability, and compliance with development standards.