# Generated from:

- items/pdi_Recovery0/installation/ver_ipdif_gyrocal.xml (1045 tokens)
- items/pdi_Recovery0/installation/ver_ipdif_calmag0.xml (191 tokens)
- items/pdi_Recovery0/installation/ver_ipdif_calmag2.xml (191 tokens)
- items/pdi_Recovery0/installation/ver_ipdif_calmag3.xml (191 tokens)
- items/pdi_Recovery0/installation/ver_ipdif_calmag4.xml (191 tokens)
- items/pdi_Recovery0/installation/ver_ipdif_calmag5.xml (191 tokens)
- items/pdi_Recovery0/installation/ver_ipdif_calmag6.xml (191 tokens)
- items/pdi_Recovery0/installation/ver_ipdif_calmag7.xml (192 tokens)
- items/pdi_Recovery0/installation/ver_ipdif_extcalacc0.xml (193 tokens)
- items/pdi_Recovery0/installation/ver_ipdif_extcalacc1.xml (193 tokens)
- items/pdi_Recovery0/installation/ver_ipdif_extcalgyr0.xml (193 tokens)
- items/pdi_Recovery0/installation/ver_ipdif_extcalgyr1.xml (193 tokens)
- items/pdi_Recovery0/installation/ver_ipdif_extcalmag0.xml (193 tokens)
- items/pdi_Recovery0/installation/ver_ipdif_extcalmag1.xml (193 tokens)
- items/pdi_Recovery0/installation/ver_ipdif_acclbu.xml (106 tokens)
- items/pdi_Recovery0/production/ver_ppdif_calacc0.xml (191 tokens)
- items/pdi_Recovery0/production/ver_ppdif_calacc1.xml (191 tokens)
- items/pdi_Recovery0/production/ver_ppdif_calacc2.xml (191 tokens)
- items/pdi_Recovery0/production/ver_ppdif_calacc3.xml (191 tokens)
- items/pdi_Recovery0/production/ver_ppdif_calgyr0.xml (191 tokens)
- items/pdi_Recovery0/production/ver_ppdif_calgyr1.xml (191 tokens)
- items/pdi_Recovery0/production/ver_ppdif_calgyr2.xml (191 tokens)
- items/pdi_Recovery0/production/ver_ppdif_calgyr3.xml (191 tokens)
- items/pdi_Recovery0/production/ver_ppdif_calstp0.xml (112 tokens)
- items/pdi_Recovery0/production/ver_ppdif_calstp1.xml (112 tokens)
- items/pdi_Recovery0/production/ver_ppdif_calstp2.xml (112 tokens)
- items/pdi_Recovery0/production/ver_ppdif_calmag_res.xml (192 tokens)
- items/pdi_Recovery0/production/ver_ppdif_calqinf.xml (112 tokens)
- items/pdi_Recovery0/setup/ver_spdif_mcal.xml (77 tokens)

---

# Sensor Calibration Configuration Analysis for Recovery System

## 1. Overview of Sensor Calibration System

The recovery system employs an extensive sensor calibration framework to ensure accurate readings from various sensors including gyroscopes, accelerometers, magnetometers, and step sensors. This analysis provides a comprehensive breakdown of the calibration parameters, their structure, and how they would be applied to sensor readings.

## 2. Calibration File Organization

The calibration files are organized into three main directories:

1. **installation/** - Contains installation-time calibration data
2. **production/** - Contains production-time calibration data
3. **setup/** - Contains setup-related calibration data

Each file follows a consistent naming convention:
- `ver_ipdif_*` for installation files
- `ver_ppdif_*` for production files
- `ver_spdif_*` for setup files

## 3. Common Calibration Data Structure

### 3.1 Version Information

All calibration files include version information with the same structure:
```xml
<version>
    <major>7</major>
    <minor>3</minor>
    <revision>1</revision>
</version>
```

This indicates all calibration files are at version 7.3.1, suggesting a unified calibration system version.

### 3.2 File Identification

Each calibration file contains:
- A unique `<id>` number
- A `<filename>` that corresponds to the binary file where the actual calibration data is stored

## 4. Gyroscope Calibration

### 4.1 Main Gyroscope Calibration (gyrocal.bin)

File: `items/pdi_Recovery0/installation/ver_ipdif_gyrocal.xml`
ID: 249

The gyroscope calibration contains calibration parameters for 8 different configurations (c0-c7), suggesting either:
- Multiple gyroscopes in the system
- Different operational modes for the same gyroscope
- Calibration for different temperature ranges

For each configuration and each axis (x, y, z), the following parameters are defined:
- **bias**: Offset correction (all set to 0.0)
- **scale-factor**: Multiplicative correction (all set to 0.0)
- **variance**: Expected measurement variance (all set to 0.0)

The zero values suggest these are default/placeholder values that would be updated during actual calibration.

### 4.2 Temperature-Dependent Gyroscope Calibration

Files:
- `items/pdi_Recovery0/production/ver_ppdif_calgyr0.xml` (ID: 111)
- `items/pdi_Recovery0/production/ver_ppdif_calgyr1.xml` (ID: 112)
- `items/pdi_Recovery0/production/ver_ppdif_calgyr2.xml` (ID: 260)
- `items/pdi_Recovery0/production/ver_ppdif_calgyr3.xml` (ID: 362)
- `items/pdi_Recovery0/installation/ver_ipdif_extcalgyr0.xml` (ID: 164)
- `items/pdi_Recovery0/installation/ver_ipdif_extcalgyr1.xml` (ID: 165)

These files contain temperature-dependent calibration data with:
- **temp_hyst**: Temperature hysteresis value (0.5 or 1.0)
- **temp**: Reference temperature (320.0 or 0.0)
- **b0, b1, b2**: Bias vector components (all 0.0)
- **a00-a22**: 3x3 calibration matrix (identity matrix with all diagonal elements 1.0, others 0.0)

The calibration matrix would be applied to raw gyroscope readings as:
```
[calibrated_x]   [a00 a01 a02]   [raw_x - b0]
[calibrated_y] = [a10 a11 a12] * [raw_y - b1]
[calibrated_z]   [a20 a21 a22]   [raw_z - b2]
```

## 5. Magnetometer Calibration

### 5.1 Main Magnetometer Calibration Files

Files:
- `items/pdi_Recovery0/installation/ver_ipdif_calmag0.xml` (ID: 113)
- `items/pdi_Recovery0/installation/ver_ipdif_calmag2.xml` (ID: 272)
- `items/pdi_Recovery0/installation/ver_ipdif_calmag3.xml` (ID: 273)
- `items/pdi_Recovery0/installation/ver_ipdif_calmag4.xml` (ID: 263)
- `items/pdi_Recovery0/installation/ver_ipdif_calmag5.xml` (ID: 269)
- `items/pdi_Recovery0/installation/ver_ipdif_calmag6.xml` (ID: 356)
- `items/pdi_Recovery0/installation/ver_ipdif_calmag7.xml` (ID: 365, named as `entry-calrm3100`)
- `items/pdi_Recovery0/production/ver_ppdif_calmag_res.xml` (ID: 367, named as `entry-calmagRes`)

The presence of multiple magnetometer calibration files indicates either:
1. Multiple magnetometer sensors in the system
2. Backup/redundant calibration data
3. Different operational modes or conditions

Each magnetometer calibration file contains:
- **temp_hyst**: Temperature hysteresis (0.5 or 1.0)
- **temp**: Reference temperature (varies: 320.0, 1.0, or 0.0)
- **b0, b1, b2**: Bias vector components (all 0.0)
- **a00-a22**: 3x3 calibration matrix (identity matrix)

### 5.2 Extended Magnetometer Calibration

Files:
- `items/pdi_Recovery0/installation/ver_ipdif_extcalmag0.xml` (ID: 166)
- `items/pdi_Recovery0/installation/ver_ipdif_extcalmag1.xml` (ID: 167)

These files follow the same structure as the main magnetometer calibration files but are designated as "extended" calibrations, possibly for additional or backup magnetometers.

## 6. Accelerometer Calibration

### 6.1 Main Accelerometer Calibration

Files:
- `items/pdi_Recovery0/production/ver_ppdif_calacc0.xml` (ID: 109)
- `items/pdi_Recovery0/production/ver_ppdif_calacc1.xml` (ID: 110)
- `items/pdi_Recovery0/production/ver_ppdif_calacc2.xml` (ID: 259)
- `items/pdi_Recovery0/production/ver_ppdif_calacc3.xml` (ID: 361)

These files follow the same structure as the magnetometer calibration files:
- **temp_hyst**: Temperature hysteresis (0.5 or 1.0)
- **temp**: Reference temperature (320.0 or 0.0)
- **b0, b1, b2**: Bias vector components (all 0.0)
- **a00-a22**: 3x3 calibration matrix (identity matrix)

### 6.2 Extended Accelerometer Calibration

Files:
- `items/pdi_Recovery0/installation/ver_ipdif_extcalacc0.xml` (ID: 162)
- `items/pdi_Recovery0/installation/ver_ipdif_extcalacc1.xml` (ID: 163)

These follow the same structure as the main accelerometer calibration files but are designated as "extended" calibrations.

### 6.3 Backup Accelerometer Calibration

File: `items/pdi_Recovery0/installation/ver_ipdif_acclbu.xml` (ID: 277)

This file contains only the calibration matrix without temperature dependency:
```xml
<data>
    <a00>1.0</a00>
    <a10>0.0</a10>
    <a20>0.0</a20>
    <a01>0.0</a01>
    <a11>1.0</a11>
    <a21>0.0</a21>
    <a02>0.0</a02>
    <a12>0.0</a12>
    <a22>1.0</a22>
</data>
```

This serves as a backup calibration that can be used if the primary temperature-dependent calibration fails.

## 7. Step Sensor Calibration

Files:
- `items/pdi_Recovery0/production/ver_ppdif_calstp0.xml` (ID: 264)
- `items/pdi_Recovery0/production/ver_ppdif_calstp1.xml` (ID: 265)
- `items/pdi_Recovery0/production/ver_ppdif_calstp2.xml` (ID: 266)

The step sensor calibration has a different structure:
```xml
<data>
    <temp_hyst>0.0</temp_hyst>
    <cal_data>
        <str-tunarray-element>
            <x>0.0</x>
            <y1>0.0</y1>
            <y2>0.0</y2>
        </str-tunarray-element>
    </cal_data>
</data>
```

This suggests a simpler calibration model, possibly using a linear or quadratic function where:
- **x**: Input value
- **y1, y2**: Calibration coefficients

## 8. Additional Calibration Files

### 8.1 Q-Inference Calibration

File: `items/pdi_Recovery0/production/ver_ppdif_calqinf.xml` (ID: 267)

This file follows the same structure as the step sensor calibration files, suggesting it might be related to a similar type of sensor or processing.

### 8.2 Master Calibration Control

File: `items/pdi_Recovery0/setup/ver_spdif_mcal.xml` (ID: 133)

This file appears to control the overall calibration process:
```xml
<data>
    <map>
        <tmeas>0.0</tmeas>
        <save_xcal>0</save_xcal>
    </map>
</data>
```

Where:
- **tmeas**: Possibly the measurement temperature
- **save_xcal**: A flag (0) indicating whether to save extended calibration data

## 9. Calibration Application Process

Based on the structure of the calibration files, the following process would be used to apply calibrations to sensor readings:

1. **Temperature Selection**:
   - Measure the current temperature
   - Select the appropriate calibration based on temperature and hysteresis
   - If current temperature is within ±temp_hyst of a calibration's reference temperature, use that calibration

2. **Bias Correction**:
   - Subtract the bias vector [b0, b1, b2] from raw sensor readings

3. **Scale and Cross-Axis Correction**:
   - Apply the 3x3 calibration matrix to the bias-corrected readings
   - This corrects for scale factors and cross-axis sensitivity

4. **For Step Sensors and Q-Inference**:
   - Apply the simpler x, y1, y2 calibration model

## 10. Redundancy and Backup Mechanisms

The calibration system includes several redundancy mechanisms:

1. **Multiple Sensor Calibrations**: Multiple calibration files for each sensor type (gyroscopes, accelerometers, magnetometers)

2. **Extended Calibrations**: Additional "ext" calibration files that could serve as alternatives

3. **Backup Accelerometer Calibration**: A dedicated backup calibration file (acclbu.bin) that doesn't depend on temperature

4. **Temperature Hysteresis**: The temp_hyst parameter allows for smooth transitions between calibrations at different temperatures, preventing oscillation between calibration sets when temperature fluctuates around a threshold

5. **Default Identity Matrices**: All calibration matrices are initialized as identity matrices with zeros for bias, ensuring that even without proper calibration, the system can still function with uncalibrated raw data

## 11. File-by-File Breakdown

### 11.1 Installation Files

| File | ID | Purpose | Key Parameters |
|------|----|---------|--------------------|
| ver_ipdif_gyrocal.xml | 249 | Main gyroscope calibration | 8 configurations (c0-c7) with bias, scale-factor, variance |
| ver_ipdif_calmag0.xml | 113 | Magnetometer 0 calibration | temp_hyst=0.5, temp=320.0, 3x3 matrix |
| ver_ipdif_calmag2.xml | 272 | Magnetometer 2 calibration | temp_hyst=1.0, temp=1.0, 3x3 matrix |
| ver_ipdif_calmag3.xml | 273 | Magnetometer 3 calibration | temp_hyst=1.0, temp=1.0, 3x3 matrix |
| ver_ipdif_calmag4.xml | 263 | Magnetometer 4 calibration | temp_hyst=1.0, temp=1.0, 3x3 matrix |
| ver_ipdif_calmag5.xml | 269 | Magnetometer 5 calibration | temp_hyst=1.0, temp=1.0, 3x3 matrix |
| ver_ipdif_calmag6.xml | 356 | Magnetometer 6 calibration | temp_hyst=1.0, temp=1.0, 3x3 matrix |
| ver_ipdif_calmag7.xml | 365 | RM3100 magnetometer calibration | temp_hyst=1.0, temp=0.0, 3x3 matrix |
| ver_ipdif_extcalacc0.xml | 162 | Extended accelerometer 0 calibration | temp_hyst=1.0, temp=0.0, 3x3 matrix |
| ver_ipdif_extcalacc1.xml | 163 | Extended accelerometer 1 calibration | temp_hyst=1.0, temp=0.0, 3x3 matrix |
| ver_ipdif_extcalgyr0.xml | 164 | Extended gyroscope 0 calibration | temp_hyst=1.0, temp=0.0, 3x3 matrix |
| ver_ipdif_extcalgyr1.xml | 165 | Extended gyroscope 1 calibration | temp_hyst=1.0, temp=0.0, 3x3 matrix |
| ver_ipdif_extcalmag0.xml | 166 | Extended magnetometer 0 calibration | temp_hyst=1.0, temp=1.0, 3x3 matrix |
| ver_ipdif_extcalmag1.xml | 167 | Extended magnetometer 1 calibration | temp_hyst=1.0, temp=0.0, 3x3 matrix |
| ver_ipdif_acclbu.xml | 277 | Backup accelerometer calibration | 3x3 matrix only (no temperature dependency) |

### 11.2 Production Files

| File | ID | Purpose | Key Parameters |
|------|----|---------|--------------------|
| ver_ppdif_calacc0.xml | 109 | Accelerometer 0 calibration | temp_hyst=0.5, temp=320.0, 3x3 matrix |
| ver_ppdif_calacc1.xml | 110 | Accelerometer 1 calibration | temp_hyst=0.5, temp=320.0, 3x3 matrix |
| ver_ppdif_calacc2.xml | 259 | Accelerometer 2 calibration | temp_hyst=1.0, temp=320.0, 3x3 matrix |
| ver_ppdif_calacc3.xml | 361 | Accelerometer 3 calibration | temp_hyst=1.0, temp=0.0, 3x3 matrix |
| ver_ppdif_calgyr0.xml | 111 | Gyroscope 0 calibration | temp_hyst=0.5, temp=320.0, 3x3 matrix |
| ver_ppdif_calgyr1.xml | 112 | Gyroscope 1 calibration | temp_hyst=0.5, temp=320.0, 3x3 matrix |
| ver_ppdif_calgyr2.xml | 260 | Gyroscope 2 calibration | temp_hyst=1.0, temp=320.0, 3x3 matrix |
| ver_ppdif_calgyr3.xml | 362 | Gyroscope 3 calibration | temp_hyst=1.0, temp=0.0, 3x3 matrix |
| ver_ppdif_calstp0.xml | 264 | Step sensor 0 calibration | temp_hyst=0.0, x/y1/y2 parameters |
| ver_ppdif_calstp1.xml | 265 | Step sensor 1 calibration | temp_hyst=0.0, x/y1/y2 parameters |
| ver_ppdif_calstp2.xml | 266 | Step sensor 2 calibration | temp_hyst=0.0, x/y1/y2 parameters |
| ver_ppdif_calmag_res.xml | 367 | Reserve magnetometer calibration | temp_hyst=1.0, temp=0.0, 3x3 matrix |
| ver_ppdif_calqinf.xml | 267 | Q-inference calibration | temp_hyst=0.0, x/y1/y2 parameters |

### 11.3 Setup Files

| File | ID | Purpose | Key Parameters |
|------|----|---------|--------------------|
| ver_spdif_mcal.xml | 133 | Master calibration control | tmeas=0.0, save_xcal=0 |

## 12. Mathematical Model for Sensor Calibration

### 12.1 For Gyroscopes, Accelerometers, and Magnetometers

The calibration is applied using the following equation:

```
[calibrated_x]   [a00 a01 a02]   [raw_x - b0]
[calibrated_y] = [a10 a11 a12] * [raw_y - b1]
[calibrated_z]   [a20 a21 a22]   [raw_z - b2]
```

Where:
- [raw_x, raw_y, raw_z] are the uncalibrated sensor readings
- [b0, b1, b2] is the bias vector
- [a00...a22] is the 3x3 calibration matrix that corrects for scale factors and cross-axis sensitivity
- [calibrated_x, calibrated_y, calibrated_z] are the resulting calibrated readings

### 12.2 For Step Sensors and Q-Inference

These appear to use a simpler model, possibly:

```
calibrated_value = f(raw_value, x, y1, y2)
```

Where f() could be a linear or polynomial function using the x, y1, and y2 coefficients.

## 13. Temperature Dependency and Hysteresis

The calibration system accounts for temperature variations through:

1. **Reference Temperatures**: Each calibration set has a reference temperature (temp)
2. **Temperature Hysteresis**: The temp_hyst parameter defines a band around the reference temperature
3. **Selection Logic**: The appropriate calibration is selected based on the current temperature:
   - If |current_temp - reference_temp| ≤ temp_hyst, use this calibration
   - This prevents oscillation between calibration sets when temperature fluctuates around a threshold

## 14. Conclusion

The recovery system employs a comprehensive sensor calibration framework with the following key features:

1. **Multiple Sensor Support**: Calibration for gyroscopes, accelerometers, magnetometers, and step sensors
2. **Temperature Compensation**: Temperature-dependent calibration with hysteresis
3. **Full 3D Calibration**: 3x3 matrices for correcting scale factors and cross-axis sensitivity
4. **Redundancy**: Multiple calibration files and backup mechanisms
5. **Unified Version Control**: All calibration files at version 7.3.1
6. **Default Safe Values**: Identity matrices and zero biases as defaults

The calibration system is designed to ensure accurate sensor readings across different operational conditions while providing redundancy in case of calibration failures.