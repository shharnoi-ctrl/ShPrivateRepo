# Generated from:

- items/pdi_Recovery1/setup/ver_spdif_imu0.xml (241 tokens)
- items/pdi_Recovery1/setup/ver_spdif_imu1.xml (241 tokens)
- items/pdi_Recovery1/setup/ver_spdif_imu2.xml (137 tokens)
- items/pdi_Recovery1/setup/ver_spdif_imu3.xml (129 tokens)
- items/pdi_Recovery1/setup/ver_spdif_imugeom.xml (122 tokens)
- items/pdi_Recovery1/setup/ver_spdif_imupos.xml (78 tokens)
- items/pdi_Recovery1/setup/ver_spdif_gyrsuite.xml (325 tokens)
- items/pdi_Recovery1/setup/ver_spdif_accsuite.xml (325 tokens)
- items/pdi_Recovery1/setup/ver_spdif_gyrlps.xml (334 tokens)
- items/pdi_Recovery1/setup/ver_spdif_acclps.xml (334 tokens)
- items/pdi_Recovery1/setup/ver_spdif_maglps.xml (684 tokens)
- items/pdi_Recovery1/setup/ver_spdif_vargyr.xml (237 tokens)
- items/pdi_Recovery1/setup/ver_spdif_varacc.xml (237 tokens)
- items/pdi_Recovery1/setup/ver_spdif_varmag.xml (237 tokens)
- items/pdi_Recovery1/setup/ver_spdif_extgyr0.xml (136 tokens)
- items/pdi_Recovery1/setup/ver_spdif_extgyr1.xml (136 tokens)
- items/pdi_Recovery1/setup/ver_spdif_extmag0.xml (136 tokens)
- items/pdi_Recovery1/setup/ver_spdif_extmag1.xml (136 tokens)
- items/pdi_Recovery1/setup/ver_spdif_extacc0.xml (136 tokens)
- items/pdi_Recovery1/setup/ver_spdif_extacc1.xml (136 tokens)
- items/pdi_Recovery1/setup/ver_spdif_extnavsen.xml (92 tokens)

## With context from:

- Amazon-PrimeAir/items/ASTRO/items/EV2/Recovery 1/03_Sensor_Calibration.md (4976 tokens)
- Amazon-PrimeAir/items/ASTRO/items/EV2/Recovery 1/03_Sensor_Filters.md (4343 tokens)

---

# PDI Recovery1 Sensor Configuration Analysis

## 1. IMU Redundancy Architecture

The PDI Recovery1 system implements a sophisticated sensor redundancy architecture with four distinct IMUs (Inertial Measurement Units), each with unique configurations and capabilities. This multi-IMU approach provides fault tolerance, improved accuracy through sensor fusion, and adaptability to different operational conditions.

### 1.1 IMU0 and IMU1 Configuration (Primary IMUs)

IMU0 and IMU1 share identical configurations, suggesting they are the same hardware model and serve as redundant primary inertial sensors:

```xml
<accelRange>4</accelRange>              <!-- ±4g acceleration range -->
<accelSampleRate>160</accelSampleRate>  <!-- 160 Hz accelerometer sampling -->
<accelbw>0</accelbw>                    <!-- Accelerometer bandwidth setting -->
<enOutDr>1</enOutDr>                    <!-- Data ready output enabled -->
<gyroRange>12</gyroRange>               <!-- ±12 deg/s gyroscope range -->
<gyroSampleRate>128</gyroSampleRate>    <!-- 128 Hz gyroscope sampling -->
<gyroHpfEn>0</gyroHpfEn>                <!-- High-pass filter disabled -->
<temp_enabled>1</temp_enabled>          <!-- Temperature sensing enabled -->
<accel_max_nv_samples>10</accel_max_nv_samples>  <!-- Max non-valid accelerometer samples -->
<gyro_max_nv_samples>10</gyro_max_nv_samples>    <!-- Max non-valid gyroscope samples -->
<acc_max_delta>313.8128</acc_max_delta>          <!-- Max accelerometer delta (m/s²) -->
<gyr_max_delta>69.81317</gyr_max_delta>          <!-- Max gyroscope delta (rad/s) -->
```

These IMUs feature:
- Moderate acceleration range (±4g)
- Relatively high sampling rates (160Hz for accelerometer, 128Hz for gyroscope)
- Temperature compensation capability
- Outlier rejection with max delta thresholds

### 1.2 IMU2 Configuration (Secondary IMU)

IMU2 uses a different hardware model with distinct configuration parameters:

```xml
<accRange>2</accRange>                <!-- ±2g acceleration range -->
<accODR>12</accODR>                   <!-- Output data rate setting -->
<accBWP>160</accBWP>                  <!-- Bandwidth parameter -->
<accMaxNvSamples>30</accMaxNvSamples> <!-- Higher tolerance for non-valid samples -->
<gyrRange>0</gyrRange>                <!-- Different gyroscope range encoding -->
<gyrOdrBw>2</gyrOdrBw>                <!-- Combined ODR/bandwidth setting -->
<gyrMaxNvSamples>30</gyrMaxNvSamples> <!-- Higher tolerance for non-valid samples -->
<acc_max_delta>235.3596</acc_max_delta>  <!-- Different max accelerometer delta -->
<gyr_max_delta>69.81317</gyr_max_delta>  <!-- Same max gyroscope delta as IMU0/1 -->
```

IMU2 features:
- Lower acceleration range (±2g) but potentially higher precision
- Different parameter structure indicating a different hardware model
- Higher tolerance for non-valid samples (30 vs 10)
- Different maximum acceleration delta threshold

### 1.3 IMU3 Configuration (Tertiary IMU)

IMU3 represents yet another hardware model with a minimal configuration set:

```xml
<accMaxNvSamples>10</accMaxNvSamples>   <!-- Same as IMU0/1 -->
<gyrMaxNvSamples>10</gyrMaxNvSamples>   <!-- Same as IMU0/1 -->
<mode_32bit>0</mode_32bit>              <!-- 32-bit mode disabled -->
<filter_stages>4</filter_stages>        <!-- 4-stage filtering -->
<bandwidth_370hz>0</bandwidth_370hz>    <!-- 370Hz bandwidth disabled -->
<acc_max_delta>156.8</acc_max_delta>    <!-- Lower max accelerometer delta -->
<gyr_max_delta>69.81317</gyr_max_delta> <!-- Same max gyroscope delta as others -->
```

IMU3 features:
- Multi-stage filtering capability (4 stages)
- Optional 32-bit mode (currently disabled)
- Optional high bandwidth mode (currently disabled)
- Lower maximum acceleration delta threshold

### 1.4 IMU Geometric Configuration

The system defines the geometric relationship between IMUs through transformation matrices:

```xml
<!-- IMU Geometry Matrix (Lbp) - Identity matrix -->
<Lbp>
    <a00>1.0</a00> <a01>0.0</a01> <a02>0.0</a02>
    <a10>0.0</a10> <a11>1.0</a11> <a12>0.0</a12>
    <a20>0.0</a20> <a21>0.0</a21> <a22>1.0</a22>
</Lbp>

<!-- IMU Position Vector (GIb) - Zero vector -->
<GIb>
    <x>0.0</x>
    <y>0.0</y>
    <z>0.0</z>
</GIb>
```

Currently, the IMU geometry is set to identity matrix and zero position vector, indicating either:
1. All IMUs are considered to be at the same physical location
2. The actual geometric calibration would be performed during system commissioning
3. The transformation is applied elsewhere in the system

## 2. Sensor Suite Management

The PDI Recovery1 system implements comprehensive sensor suite management for gyroscopes, accelerometers, and magnetometers, enabling intelligent sensor fusion and fault tolerance.

### 2.1 Gyroscope Suite Configuration

```xml
<sel>
    <use>1</use>           <!-- Gyroscope suite enabled -->
    <def-sen>0</def-sen>   <!-- Default sensor is IMU0 -->
</sel>
<tau_v>2.0</tau_v>         <!-- Velocity time constant -->
<tau_s2>20.0</tau_s2>      <!-- Variance time constant -->
<variances>
    <!-- Initial and minimum variance settings for 8 possible gyroscope sensors -->
    <s0><ini_s2>1.0</ini_s2><min_s2>1.0E-4</min_s2></s0>
    <s1><ini_s2>1.0</ini_s2><min_s2>1.0E-4</min_s2></s1>
    <!-- ... s2 through s7 with identical settings ... -->
</variances>
```

Key aspects:
- The gyroscope suite is enabled (`use=1`)
- IMU0's gyroscope is designated as the default sensor (`def-sen=0`)
- Time constants for velocity (2.0) and variance (20.0) control the sensor fusion dynamics
- All gyroscopes start with the same initial variance (1.0) and minimum variance (1.0E-4)

### 2.2 Accelerometer Suite Configuration

```xml
<sel>
    <use>1</use>           <!-- Accelerometer suite enabled -->
    <def-sen>0</def-sen>   <!-- Default sensor is IMU0 -->
</sel>
<tau_v>2.0</tau_v>         <!-- Velocity time constant -->
<tau_s2>20.0</tau_s2>      <!-- Variance time constant -->
<variances>
    <!-- Initial and minimum variance settings for 8 possible accelerometer sensors -->
    <s0><ini_s2>1.0</ini_s2><min_s2>1.0E-4</min_s2></s0>
    <s1><ini_s2>1.0</ini_s2><min_s2>1.0E-4</min_s2></s1>
    <!-- ... s2 through s7 with identical settings ... -->
</variances>
```

The accelerometer suite configuration mirrors the gyroscope suite, with identical parameters for time constants and variances.

### 2.3 Sensor Alignment and Calibration

The system defines local platform sensor (LPS) transformation matrices for each sensor type:

```xml
<!-- Gyroscope LPS Matrices -->
<sensor0>
    <a00>1.0</a00> <a01>0.0</a01> <a02>0.0</a02>
    <a10>0.0</a10> <a11>1.0</a11> <a12>0.0</a12>
    <a20>0.0</a20> <a21>0.0</a21> <a22>1.0</a22>
</sensor0>
<!-- Similar identity matrices for sensor1-sensor3 -->

<!-- Accelerometer LPS Matrices -->
<sensor0>
    <a00>1.0</a00> <a01>0.0</a01> <a02>0.0</a02>
    <a10>0.0</a10> <a11>1.0</a11> <a12>0.0</a12>
    <a20>0.0</a20> <a21>0.0</a21> <a22>1.0</a22>
</sensor0>
<!-- Similar identity matrices for sensor1-sensor3 -->

<!-- Magnetometer LPS Matrices -->
<sensor0>
    <a00>1.0</a00> <a01>0.0</a01> <a02>0.0</a02>
    <a10>0.0</a10> <a11>1.0</a11> <a12>0.0</a12>
    <a20>0.0</a20> <a21>0.0</a21> <a22>1.0</a22>
</sensor0>
<!-- Similar identity matrices for sensor1-sensor8 -->
```

Currently, all transformation matrices are set to identity, indicating either:
1. All sensors are perfectly aligned with the body frame
2. The actual alignment calibration would be performed during system commissioning
3. The alignment is handled elsewhere in the system

### 2.4 Variable Sensor Configuration

The system supports runtime variable sensor configurations for gyroscopes, accelerometers, and magnetometers:

```xml
<rvar0>
    <enable>0</enable>                    <!-- Currently disabled -->
    <rvar_id0>4100</rvar_id0>             <!-- Variable identifier -->
    <min_value>-3.4028235E38</min_value>  <!-- Minimum allowed value -->
    <max_value>3.4028235E38</max_value>   <!-- Maximum allowed value -->
    <max_delta>3.4028235E38</max_delta>   <!-- Maximum allowed change -->
    <max_count_nv>0</max_count_nv>        <!-- Maximum non-valid count -->
</rvar0>
<rvar1>
    <!-- Similar configuration -->
</rvar1>
```

These configurations are currently disabled (`enable=0`) but provide a framework for runtime sensor parameter adjustment.

## 3. External Sensor Integration

The PDI Recovery1 system supports integration with external sensors, including external gyroscopes, accelerometers, and magnetometers, as well as navigation sensors.

### 3.1 External Gyroscope Configuration

```xml
<!-- External Gyroscope 0 -->
<desired_freq>0.0</desired_freq>        <!-- Desired frequency (0 = disabled) -->
<flt_cfg>
    <enable>0</enable>                  <!-- Filter disabled -->
    <cutoff_freq>1.0</cutoff_freq>      <!-- 1.0 Hz cutoff frequency -->
</flt_cfg>
<min_value>-3.4028235E38</min_value>    <!-- Minimum allowed value -->
<max_value>3.4028235E38</max_value>     <!-- Maximum allowed value -->
<max_delta>3.4028235E38</max_delta>     <!-- Maximum allowed change -->
<max_count_nv>10</max_count_nv>         <!-- Maximum non-valid count -->
```

External Gyroscope 1 has an identical configuration. Both are currently disabled (`desired_freq=0.0`).

### 3.2 External Accelerometer Configuration

```xml
<!-- External Accelerometer 0 -->
<desired_freq>0.0</desired_freq>        <!-- Desired frequency (0 = disabled) -->
<flt_cfg>
    <enable>0</enable>                  <!-- Filter disabled -->
    <cutoff_freq>1.0</cutoff_freq>      <!-- 1.0 Hz cutoff frequency -->
</flt_cfg>
<min_value>-3.4028235E38</min_value>    <!-- Minimum allowed value -->
<max_value>3.4028235E38</max_value>     <!-- Maximum allowed value -->
<max_delta>3.4028235E38</max_delta>     <!-- Maximum allowed change -->
<max_count_nv>10</max_count_nv>         <!-- Maximum non-valid count -->
```

External Accelerometer 1 has an identical configuration. Both are currently disabled (`desired_freq=0.0`).

### 3.3 External Magnetometer Configuration

```xml
<!-- External Magnetometer 0 -->
<desired_freq>0.0</desired_freq>        <!-- Desired frequency (0 = disabled) -->
<flt_cfg>
    <enable>0</enable>                  <!-- Filter disabled -->
    <cutoff_freq>1.0</cutoff_freq>      <!-- 1.0 Hz cutoff frequency -->
</flt_cfg>
<min_value>-3.4028235E38</min_value>    <!-- Minimum allowed value -->
<max_value>3.4028235E38</max_value>     <!-- Maximum allowed value -->
<max_delta>3.4028235E38</max_delta>     <!-- Maximum allowed change -->
<max_count_nv>10</max_count_nv>         <!-- Maximum non-valid count -->
```

External Magnetometer 1 has an identical configuration. Both are currently disabled (`desired_freq=0.0`).

### 3.4 External Navigation Sensor Configuration

```xml
<desired_freq>100.0</desired_freq>      <!-- 100 Hz desired frequency -->
<req_status0_present>0</req_status0_present>  <!-- Status check disabled -->
<req_status0_value>0</req_status0_value>      <!-- Required status value -->
```

Unlike the other external sensors, the navigation sensor has a non-zero desired frequency (100 Hz), suggesting it may be actively used in the system.

## 4. Sensor Sampling Rates and Ranges

### 4.1 Accelerometer Sampling Rates and Ranges

| IMU | Sampling Rate | Range | Max Delta | Max NV Samples |
|-----|--------------|-------|-----------|----------------|
| IMU0 | 160 Hz | ±4g | 313.8128 m/s² | 10 |
| IMU1 | 160 Hz | ±4g | 313.8128 m/s² | 10 |
| IMU2 | Defined by accODR=12 | ±2g | 235.3596 m/s² | 30 |
| IMU3 | Not explicitly defined | Not defined | 156.8 m/s² | 10 |

### 4.2 Gyroscope Sampling Rates and Ranges

| IMU | Sampling Rate | Range | Max Delta | Max NV Samples |
|-----|--------------|-------|-----------|----------------|
| IMU0 | 128 Hz | ±12 deg/s | 69.81317 rad/s | 10 |
| IMU1 | 128 Hz | ±12 deg/s | 69.81317 rad/s | 10 |
| IMU2 | Defined by gyrOdrBw=2 | Defined by gyrRange=0 | 69.81317 rad/s | 30 |
| IMU3 | Not explicitly defined | Not defined | 69.81317 rad/s | 10 |

### 4.3 External Sensor Configuration

| Sensor Type | Desired Frequency | Filter Cutoff | Max NV Samples |
|-------------|------------------|---------------|----------------|
| External Gyroscope 0-1 | 0.0 Hz (disabled) | 1.0 Hz | 10 |
| External Accelerometer 0-1 | 0.0 Hz (disabled) | 1.0 Hz | 10 |
| External Magnetometer 0-1 | 0.0 Hz (disabled) | 1.0 Hz | 10 |
| External Navigation Sensor | 100.0 Hz | Not applicable | Not defined |

## 5. Sensor Alignment and Calibration

### 5.1 Sensor Alignment Matrices

All sensor alignment matrices (gyroscope, accelerometer, and magnetometer) are currently set to identity matrices:

```
[1.0 0.0 0.0]
[0.0 1.0 0.0]
[0.0 0.0 1.0]
```

This indicates that either:
1. All sensors are perfectly aligned with the body frame
2. The actual alignment calibration would be performed during system commissioning
3. The alignment is handled elsewhere in the system

### 5.2 Sensor Calibration Process

Based on the context files, the PDI Recovery1 system employs a comprehensive calibration process:

1. **Temperature-Based Calibration**: Different sensors have different temperature hysteresis thresholds:
   - Critical sensors: 0.5 degrees hysteresis
   - Secondary sensors: 1.0 degrees hysteresis
   - Some sensors: No temperature compensation (0.0 degrees)

2. **Calibration Transformation**:
   - Bias correction: Raw values adjusted by subtracting bias vector
   - Scale and cross-axis correction: Unbiased values multiplied by calibration matrix
   - Temperature compensation: Additional corrections based on temperature

3. **Sensor Fusion**:
   - Initial variance: All sensors start with the same variance (1.0)
   - Minimum variance: Lower bound on sensor variance (1.0E-4)
   - Time constants: Control how quickly the system responds to changes (tau_v=2.0, tau_s2=20.0)

## 6. Sensor Data Processing Pipeline

Combining information from the sensor configuration and context files, the PDI Recovery1 sensor data processing pipeline can be reconstructed:

1. **Raw Data Acquisition**:
   - IMU0/1: 160 Hz accelerometer, 128 Hz gyroscope
   - IMU2: Custom data rates defined by accODR and gyrOdrBw
   - IMU3: Custom filtering with 4 filter stages
   - External sensors: Configurable rates (currently disabled except for navigation sensor)

2. **Outlier Rejection**:
   - Max delta thresholds: Different for each sensor type and instance
   - Non-valid sample counting: Tolerance for consecutive invalid readings
   - Min/max value checking: Bounds on acceptable sensor values

3. **Filtering**:
   - Low-pass filtering: 1.0 Hz cutoff frequency (currently disabled)
   - IMU3: Multi-stage filtering with 4 stages
   - External sensors: Optional 1.0 Hz filtering (currently disabled)

4. **Calibration Application**:
   - Temperature-based parameter selection
   - Bias correction
   - Scale and cross-axis correction
   - Temperature compensation

5. **Sensor Fusion**:
   - Default sensor selection (IMU0 for both gyroscope and accelerometer)
   - Variance-based weighting
   - Dynamic variance adjustment based on sensor agreement

6. **Coordinate Transformation**:
   - Local platform sensor (LPS) transformations
   - Body frame alignment

## 7. Sensor Suite Redundancy Strategy

The PDI Recovery1 system implements a sophisticated sensor redundancy strategy:

1. **Multiple IMU Instances**:
   - Four distinct IMUs with different capabilities
   - IMU0/1: Identical primary sensors
   - IMU2: Different model with higher non-valid sample tolerance
   - IMU3: Different model with multi-stage filtering

2. **Sensor Suite Management**:
   - Default sensor selection (IMU0)
   - Dynamic variance adjustment
   - Time constants for smooth transitions

3. **External Sensor Integration**:
   - Support for external gyroscopes, accelerometers, and magnetometers
   - External navigation sensor at 100 Hz
   - Filtering and validation for external sensors

4. **Fault Tolerance**:
   - Non-valid sample counting
   - Max delta thresholds
   - Min/max value checking

## 8. Magnetometer Configuration

The system supports multiple magnetometer configurations:

1. **Internal Magnetometers**:
   - Up to 9 magnetometer sensors supported in the LPS configuration
   - Special handling for RM3100 high-precision magnetometer (mag7filt)

2. **External Magnetometers**:
   - Two external magnetometer interfaces
   - Currently disabled (desired_freq=0.0)
   - 1.0 Hz filtering available when enabled

3. **Magnetometer Calibration**:
   - Temperature hysteresis: 0.5-1.0 degrees depending on sensor
   - Reference temperatures: 0.0, 1.0, or 320.0 degrees
   - Identity calibration matrices (currently)

## 9. Summary of Key Findings

1. **Redundant IMU Architecture**:
   - Four distinct IMUs with different capabilities and configurations
   - Different sampling rates, ranges, and filtering options
   - Common max gyroscope delta (69.81317 rad/s) across all IMUs

2. **Sensor Suite Management**:
   - Unified approach to gyroscope and accelerometer fusion
   - Default sensors designated (IMU0)
   - Common time constants and variance parameters

3. **External Sensor Support**:
   - Interfaces for external gyroscopes, accelerometers, and magnetometers (currently disabled)
   - Active external navigation sensor interface (100 Hz)
   - Consistent filtering approach (1.0 Hz cutoff)

4. **Calibration and Alignment**:
   - Identity transformation matrices (currently)
   - Temperature-based calibration with different hysteresis thresholds
   - Comprehensive calibration process with bias correction and matrix transformation

5. **Sensor Data Validation**:
   - Different max delta thresholds for different sensors
   - Different non-valid sample tolerances (10 for most, 30 for IMU2)
   - Min/max value checking for external sensors

## Referenced Context Files

1. **03_Sensor_Calibration.md**: Provided valuable information about the calibration process, including:
   - Temperature compensation strategy
   - Calibration matrix application
   - Bias correction methodology
   - Different temperature hysteresis thresholds for different sensors

2. **03_Sensor_Filters.md**: Contributed insights about the filtering subsystem, including:
   - Filter types (Notch, Butterworth, IIR)
   - Cutoff frequencies (consistently 1.0 Hz)
   - Filter cascade effects
   - Currently disabled state of most filters

These context files were essential for understanding how the sensor configuration parameters interact with the calibration and filtering subsystems to create a complete sensor data processing pipeline.