# Generated from:

- code/PA_SIL_navigation_test/database/Input_gnss_pos_db.h (1844 tokens)
- code/PA_SIL_navigation_test/database/Process_lidar_db.h (879 tokens)
- code/PA_SIL_navigation_test/database/Imu_batch_loop_test_db.h (1388 tokens)
- code/PA_SIL_navigation_test/database/Input_dyn_pressure_db.h (538 tokens)
- code/PA_SIL_navigation_test/database/bus2struct.h (1302 tokens)
- code/PA_SIL_navigation_test/database/mechanize_imu_db.h (548 tokens)
- code/PA_SIL_navigation_test/database/Initializer_db.h (1222 tokens)
- code/PA_SIL_navigation_test/database/Apply_delta_state_db.h (723 tokens)
- code/PA_SIL_navigation_test/database/Compute_estimated_msl_db.h (549 tokens)
- code/PA_SIL_navigation_test/database/Input_static_pressure_db.h (1311 tokens)
- code/PA_SIL_navigation_test/database/Input_uplink_heading_db.h (1157 tokens)
- code/PA_SIL_navigation_test/database/csv_parser.h (1559 tokens)
- code/PA_SIL_navigation_test/database/Airdata_db.h (976 tokens)
- code/PA_SIL_navigation_test/database/Capture_heading_db.h (453 tokens)
- code/PA_SIL_navigation_test/database/Input_heading_db.h (1252 tokens)
- code/PA_SIL_navigation_test/database/Input_gnss_vel_db.h (1556 tokens)
- code/PA_SIL_navigation_test/database/Propagate_covariance_db.h (468 tokens)
- code/PA_SIL_navigation_test/database/On_ground_db.h (855 tokens)
- code/PA_SIL_navigation_test/database/compute_air_speed_db.h (600 tokens)
- code/PA_SIL_navigation_test/database/Gnss_check_accuracies_db.h (491 tokens)
- code/PA_SIL_navigation_test/source/bus2struct.cpp (12023 tokens)

---

# Navigation Testing Database Components Analysis

## 1. Functional Behavior and Logic

### CSV Parser System
The `csv_parser` class provides the foundation for all database operations in the navigation testing framework. It handles:

- Opening CSV files for reading test data or writing test results
- Reading rows of data from CSV files into arrays of `Real64` or `Real` types
- Writing arrays of data back to CSV files
- Tracking the number of rows in a file
- Proper resource management through file closing

The parser is implemented in `csv_parser.h` with these key methods:
- `get_real64_arr(Real64 *data)` - Extracts a row of double-precision values
- `get_real_arr(Real *data)` - Extracts a row of single-precision values
- `set_real64_arr(const Real64 *data, const Uint32 length)` - Writes an array to a CSV file
- `array_to_csv_row(const double* array, Uint32 size)` - Converts an array to a CSV-formatted string

### Data Conversion System
The `bus2struct.h` and `bus2struct.cpp` files implement a comprehensive data conversion system that:

1. Converts between CSV data arrays and navigation data structures
2. Provides bidirectional conversion for all major navigation data types
3. Maintains consistent data representation across test components

Key conversion functions include:
- `state_dec` - Converts array data to `State` objects
- `delta_state_dec` - Converts array data to `Delta_state` objects
- `gnss_dec` - Converts array data to GNSS measurement objects
- `ud_dec` - Converts array data to covariance matrices
- `p_dec` - Converts array data to position/velocity covariance matrices
- `state_to_array` - Converts `State` objects back to arrays for output
- `delta_state_to_array` - Converts `Delta_state` objects back to arrays
- `ud_to_array` - Converts covariance matrices back to arrays
- `p_to_array` - Converts position/velocity covariance matrices back to arrays

### Database Class Pattern
All database classes follow a consistent pattern:
1. Define input, expected output, and actual output data structures
2. Provide methods to read test data from CSV files
3. Provide methods to write test results to CSV files
4. Manage file resources through proper initialization and cleanup

## 2. Control Flow and State Transitions

### Test Database Lifecycle

Each database class follows this operational sequence:

1. **Initialization Phase**
   - Constructor opens all required CSV files
   - Input files are opened in read mode
   - Output files are opened in write mode (with optional clearing)
   - Row counts are established

2. **Data Reading Phase**
   - `read()` method loads test data into input structures
   - Expected outputs are also loaded for later comparison
   - Data conversion happens from CSV arrays to navigation structures

3. **Test Execution Phase**
   - Navigation algorithms operate on the input data (handled outside database classes)
   - Results are captured in output structures

4. **Result Writing Phase**
   - `write()` method converts results back to arrays
   - Arrays are written to output CSV files

5. **Cleanup Phase**
   - `close()` method ensures all files are properly closed

## 3. Inputs and Stimuli

### Navigation Test Data Sources

The database components handle various navigation input types:

1. **IMU Data**
   - Accelerometer readings (f vector)
   - Gyroscope readings (w vector)
   - Saturation flags
   - Timestamps

2. **GNSS Data**
   - Position in latitude/longitude/altitude
   - Velocity in NED frame
   - Accuracy metrics (horizontal, vertical, speed)
   - Fix type and satellite count
   - Timestamps

3. **Lidar Data**
   - Range measurements
   - Return strength percentages
   - Timestamps

4. **Air Data**
   - Static pressure
   - Dynamic pressure
   - Timestamps

5. **Heading Data**
   - Uplink heading measurements
   - Heading cache values
   - Timestamps

## 4. Outputs and Effects

### Test Result Capture

The database components capture various navigation outputs:

1. **State Outputs**
   - Position (t_ned_ned2ekf_m)
   - Velocity (v_ned_ned2ekf_m_per_s)
   - Attitude quaternion (q_ned_from_ekf)
   - Acceleration (f_ekf_ned2ekf_m_per_s2)
   - Angular velocity (w_ekf_ned2ekf_rad_per_s)
   - Sensor biases (bias_a, bias_w)
   - Ground height (z_ned_ned2gnd_m)
   - Air data (air_speed_TAS_m_per_s, air_density_kg_per_m3)

2. **Covariance Outputs**
   - UD factorized covariance matrices
   - Position and velocity covariance submatrices

3. **Delta State Outputs**
   - State corrections from measurement updates

4. **Status Outputs**
   - Sensor health indicators
   - Navigation validity flags
   - Initialization status

## 5. Parameters and Configuration

### Test Database Configuration

Each database class is configured with:

1. **File Paths**
   - Base path defined as `CSV::CSV_PATH = "../../database/csv"`
   - Input file paths for test data
   - Expected output file paths for validation
   - Actual output file paths for results

2. **Buffer Sizes**
   - Most classes use a buffer of size 300 for data transfer
   - Some specialized buffers for specific data types

3. **Array Length Constants**
   - `STATE_EN_LENGTH = 74`
   - `MEAS_EN_LENGTH = 54`
   - `UD_EN_LENGTH = 240`
   - `DELTA_STATE_EN_LENGTH = 16`
   - `IMU_EN_LENGTH = 8`
   - `CONTROLLER_INTROSPECT_EN_LENGTH = 13`
   - `STATE_ESTIMATE_EN_LENGTH = 32`
   - `GNSS_MEAS_EN_LENGTH = 14`
   - `P_EN_LENGTH = 225`
   - `STP_EN_LENGTH = 3`
   - `SV_DATA_EN_LENGTH = 992`
   - `AIRDATA_EN_LENGTH = 7`

## 6. Error Handling and Contingency Logic

### File Operation Error Handling

The `csv_parser` class includes error handling for file operations:
```cpp
if (!file.is_open()) {
    if (file.fail()) {
        // Get the error code
        std::ios_base::iostate state = file.rdstate();

        // Check for specific error bits
        if (state & std::ios_base::eofbit) {
            std::cout << "End of file reached." << std::endl;
        }
        if (state & std::ios_base::failbit) {
            std::cout << "Non-fatal I/O error occurred." << std::endl;
        }
        if (state & std::ios_base::badbit) {
            std::cout << "Fatal I/O error occurred." << std::endl;
        }

        // Print system error message
        std::perror("Error: ");

        return;
    }
    throw std::runtime_error("Failed to open file: " + name);
}
```

### Data Type Conversion Safety

The conversion functions use static casting to ensure proper type conversion:
```cpp
state.q_ned_from_ekf[0] = static_cast<Real>(state_en[n++]);
```

## 7. File-by-File Breakdown

### Input_gnss_pos_db.h
- Handles GNSS position measurement testing
- Provides structures for input data, expected data, and output data
- Manages CSV files for GNSS position and velocity test data
- Implements read_pos(), read_vel(), write(), and close() methods
- Supports testing of GNSS position measurement integration into the navigation filter

### Process_lidar_db.h
- Handles lidar measurement processing tests
- Provides structures for input data, expected data, and output data
- Manages CSV files for lidar test data
- Implements read0(), read1(), write(), and close() methods
- Supports testing of lidar-based altitude estimation

### Imu_batch_loop_test_db.h
- Handles IMU batch processing tests
- Provides structures for input data and expected data
- Manages CSV files for IMU batch test data
- Implements read(), close(), and imu_meas_read() methods
- Supports testing of IMU data integration at different rates (500Hz and 50Hz)

### Input_dyn_pressure_db.h
- Handles dynamic pressure measurement testing
- Provides structures for input data, expected data, and output data
- Manages CSV files for dynamic pressure test data
- Implements read(), write(), and close() methods
- Supports testing of air data integration into the navigation filter

### bus2struct.h
- Defines conversion functions between CSV data arrays and navigation data structures
- Declares constants for array lengths of different data types
- Provides bidirectional conversion for all major navigation data types

### mechanize_imu_db.h
- Handles IMU mechanization testing
- Provides structures for input data, expected data, and output data
- Manages CSV files for IMU mechanization test data
- Implements read(), write(), and close() methods
- Supports testing of IMU-based state propagation

### Initializer_db.h
- Handles navigation initialization testing
- Provides structures for input data, expected data, and output data
- Manages CSV files for initialization test data
- Implements read(), write(), and close() methods
- Supports testing of navigation initialization at different rates (500Hz and 50Hz)

### Apply_delta_state_db.h
- Handles state correction testing
- Provides structures for input data, expected data, and output data
- Manages CSV files for delta state application test data
- Implements read(), write(), and close() methods
- Supports testing of state correction after measurement updates

### Compute_estimated_msl_db.h
- Handles mean sea level estimation testing
- Provides structures for input data, expected data, and output data
- Manages CSV files for MSL estimation test data
- Implements read(), write(), and close() methods
- Supports testing of altitude reference computation

### Input_static_pressure_db.h
- Handles static pressure measurement testing
- Provides structures for input data, expected data, and output data
- Manages CSV files for static pressure test data
- Implements read(), write(), and close() methods
- Supports testing of barometric altitude estimation

### Input_uplink_heading_db.h
- Handles uplink heading measurement testing
- Provides structures for input data, expected data, and output data
- Manages CSV files for uplink heading test data
- Implements read(), write(), and close() methods
- Supports testing of external heading integration

### csv_parser.h
- Implements the CSV file parsing functionality
- Provides methods to read and write data from/to CSV files
- Handles file opening, closing, and error checking
- Supports both single and double precision data types

### Airdata_db.h
- Handles air data processing testing
- Provides structures for input data, expected data, and output data
- Manages CSV files for air data test data
- Implements read(), write(), and close() methods
- Supports testing of air data computation and wind estimation

### Capture_heading_db.h
- Handles heading capture testing
- Provides structures for expected data
- Manages CSV files for heading capture test data
- Implements read(), write(), and close() methods
- Supports testing of heading initialization and validation

### Input_heading_db.h
- Handles heading measurement testing
- Provides structures for input data, expected data, and output data
- Manages CSV files for heading test data
- Implements read(), write(), and close() methods
- Supports testing of heading measurement integration

### Input_gnss_vel_db.h
- Handles GNSS velocity measurement testing
- Provides structures for input data, expected data, and output data
- Manages CSV files for GNSS velocity test data
- Implements read(), write(), and close() methods
- Supports testing of GNSS velocity integration into the navigation filter

### Propagate_covariance_db.h
- Handles covariance propagation testing
- Provides structures for input data and expected data
- Manages CSV files for covariance propagation test data
- Implements read() and close() methods
- Supports testing of uncertainty propagation in the navigation filter

### On_ground_db.h
- Handles on-ground detection testing
- Provides structures for input data and output data
- Manages CSV files for on-ground detection test data
- Implements read(), write(), and close() methods
- Supports testing of aircraft ground state determination

### compute_air_speed_db.h
- Handles air speed computation testing
- Provides structures for input data, expected data, and output data
- Manages CSV files for air speed computation test data
- Implements read(), write(), and close() methods
- Supports testing of indicated and true airspeed calculation

### Gnss_check_accuracies_db.h
- Handles GNSS accuracy checking testing
- Provides structures for input data and expected data
- Manages CSV files for GNSS accuracy test data
- Implements read(), write(), and close() methods
- Supports testing of GNSS measurement quality assessment

### bus2struct.cpp
- Implements the conversion functions declared in bus2struct.h
- Provides detailed conversion between CSV data arrays and navigation data structures
- Handles complex data types like quaternions, vectors, and matrices
- Ensures proper type conversion and data integrity

## 8. Cross-Component Relationships

### Database and Parser Integration
- All database classes use the `csv_parser` class for file I/O
- Database classes construct parser objects with appropriate file paths
- Parser objects handle the low-level file operations

### Data Conversion Flow
1. CSV files → csv_parser → Real64/Real arrays
2. Arrays → bus2struct conversion functions → Navigation data structures
3. Navigation algorithms process the data
4. Navigation data structures → bus2struct conversion functions → Arrays
5. Arrays → csv_parser → CSV output files

### Common Data Structures
- `State` - Core navigation state used by most components
- `Delta_state` - State corrections used by measurement update components
- `Covariance_ud` - Uncertainty representation used by filter components
- `Measurements` - Sensor data container used by input components

### Test Data Flow
1. Input database classes load test data
2. Navigation algorithms process the data
3. Output database classes capture and validate results
4. Results are compared against expected outputs

## 9. Referenced Context Files

The following context files were helpful in understanding the database components:

- `Entypes.h` - Provides basic data types used throughout the system
- `State.h` - Defines the navigation state structure
- `Delta_state.h` - Defines the state correction structure
- `Covariance_ud.h` - Defines the uncertainty representation
- `Measurements.h` and `Measurements_fullsim.h` - Define sensor data structures
- `State_history.h` - Defines the state history structure
- `Math_aux.h` - Provides mathematical utilities
- `Utils.h` - Provides general utilities
- `Nav_type.h` - Defines navigation types (recovery, monitor)
- `State_estimate.h` - Defines the state estimate structure
- `Fifo_imu_SIL.h` - Defines the IMU data buffer for software-in-the-loop testing

These files provide the necessary context for understanding the data structures and algorithms being tested by the database components.

## Common Patterns Across Database Classes

The navigation testing database components exhibit several common patterns:

1. **Three-Part Data Structure Pattern**
   - Input_data: Contains test inputs
   - Expected_data: Contains expected outputs for validation
   - Output_data/Out_data: Contains actual outputs for comparison

2. **File Path Construction Pattern**
   - Base path: `CSV::CSV_PATH`
   - Input files: `{test_name}_in_{data_type}.csv`
   - Expected files: `{test_name}_out_{data_type}.csv` or `{test_name}_exp_{data_type}.csv`
   - Output files: `Output_{test_name}_{data_type}.csv`

3. **Test Method Pattern**
   - Constructor: Opens all files
   - read(): Loads test data
   - write(): Saves test results
   - close(): Cleans up resources

4. **Data Conversion Pattern**
   - CSV arrays → Navigation structures (for input)
   - Navigation structures → CSV arrays (for output)

5. **Multiple Test Case Pattern**
   - Some database classes support multiple test cases (e.g., read0(), read1())
   - Others support different navigation types (recovery vs. monitor)

These patterns ensure consistency across the testing framework and facilitate the addition of new test cases and components.