# Generated from:

- Amazon-PrimeAir/items/ASTRO/items/Wrapper/03_Recovery_GNSS_Processing.md (2400 tokens)
- Amazon-PrimeAir/items/ASTRO/items/Wrapper/03_Recovery_Route_Tracking.md (4308 tokens)
- Amazon-PrimeAir/items/ASTRO/items/Wrapper/03_Recovery_Message_Handling.md (2328 tokens)
- Amazon-PrimeAir/items/ASTRO/items/Wrapper/03_Recovery_Wrapper_Core.md (4298 tokens)

---

# Recovery System: High-Level Architecture and Operation

## 1. System Overview

The Recovery System is a comprehensive backup navigation and control solution designed to take over vehicle operation when the primary flight control system fails. It provides a complete, independent path from sensor inputs to motor commands, ensuring continued safe operation and mission completion or safe landing.

The system consists of four major components working together:
1. **Recovery Wrapper Core** - The central coordination component
2. **GNSS Processing** - Handles satellite navigation data
3. **Route Tracking** - Manages mission routes and landing decisions
4. **Message Handling** - Transforms data between system components

## 2. System Architecture

```
┌─────────────────────────────────────────────────────────────────────────┐
│                         Recovery Wrapper Core                           │
│                                                                         │
│  ┌─────────────┐    ┌─────────────┐    ┌─────────────┐    ┌──────────┐  │
│  │   Sensor    │    │ Navigation  │    │ Controllers │    │ Actuator │  │
│  │   Inputs    │───▶│  (500 Hz)   │───▶│  (100 Hz)  │───▶│ Allocator│  │
│  └─────────────┘    └─────────────┘    └─────────────┘    └──────────┘  │
│         ▲                  ▲                  ▲                 │       │
└─────────┼──────────────────┼──────────────────┼─────────────────┼───────┘
          │                  │                  │                 │
          │                  │                  │                 ▼
┌─────────┼──────────────────┼──────────────────┼─────────────────┼───────┐
│         │                  │                  │                 │       │
│  ┌─────────────┐    ┌─────────────┐    ┌─────────────┐    ┌──────────┐  │
│  │    GNSS     │    │    Route    │    │   Message   │    │  Motor   │  │
│  │  Processor  │───▶│   Tracker   │───▶│  Handling   │───▶│ Commands │  │
│  └─────────────┘    └─────────────┘    └─────────────┘    └──────────┘  │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

## 3. Data Flow and Component Interaction

### 3.1 Sensor Input to State Estimation

1. **Sensor Data Collection**
   - IMU data (accelerometer, gyroscope) at 500Hz
   - GNSS position and velocity data
   - Pressure sensor data (dynamic and static)
   - LIDAR ground distance measurements
   - Time synchronization information

2. **GNSS Processing**
   - Processes two types of GNSS data:
     - Navigation messages from satellites
     - Raw GNSS measurements
   - Generates position/velocity solutions
   - Provides accuracy metrics and fix type information

3. **Navigation Processing**
   - Fuses all sensor data to produce a complete state estimate
   - Runs at 500Hz, triggered by IMU data
   - Outputs position, velocity, attitude, and status information
   - Maintains filter states for sensor fusion

### 3.2 State Estimation to Control Commands

1. **State Estimate Processing**
   - Converts navigation output to controller-compatible format
   - Validates position and velocity estimates
   - Determines flight phase (ground, takeoff, cruise, landing)

2. **Route Tracking**
   - Manages mission routes:
     - Takeoff-to-delivery route
     - Delivery-to-landing route
     - Takeoff-to-landing route
     - Return home routes
   - Selects appropriate route based on mission phase
   - Makes landing decisions based on:
     - Route completion
     - Battery state of charge
     - Position estimate validity
     - Tracking error magnitude

3. **Control Command Generation**
   - Generates trajectory commands based on route
   - Runs at 100Hz, triggered by state estimate updates
   - Produces force and torque commands for vehicle control

### 3.3 Control Commands to Motor Output

1. **Actuator Allocation**
   - Converts force and torque commands to motor RPM commands
   - Handles motor mixing and allocation
   - Provides feedback to controllers via mixer return

2. **Motor Command Generation**
   - Sets motor RPM values for each motor
   - Controls motor arming and enabling states
   - Applies safety checks before commanding motors

## 4. Switchover Detection and Recovery Sequence

### 4.1 Switchover Detection

The system monitors a designated file for a "RECOVERY" signal that triggers switchover:

```
bool RecoveryWrapperObject::HasSwitchoverBeenSignalled() {
    // Read from switchover file
    // Check for "RECOVERY" string
    // Return true if found
}
```

### 4.2 Recovery Sequence

When switchover is detected:

1. **Immediate Control Takeover**
   - System transitions to DepartureRecovery state
   - Navigation system continues providing state estimates
   - Control system begins generating commands

2. **Return Home Route Selection**
   - System identifies the best return home route:
     - Shortest route (by number of maneuvers)
     - Must include current maneuver
   - If no suitable route is found, commands immediate landing

3. **Mission Continuation or Landing**
   - If valid route is found, continues mission execution
   - If tracking error exceeds threshold, commands landing
   - If battery is low or position invalid, commands landing

## 5. Critical Paths and Resilience Features

### 5.1 Critical Paths

1. **Switchover Detection Path**
   - File monitoring → State machine transition → Control activation
   - Must be reliable and quick to respond

2. **Navigation Path**
   - Sensor inputs → State estimation → Position/attitude output
   - Must maintain valid state estimate for safe control

3. **Control Command Path**
   - State estimate → Route tracking → Control commands → Motor outputs
   - Must generate stable, safe commands in all conditions

4. **Landing Decision Path**
   - Route status → Battery monitoring → Position validity → Landing command
   - Must make appropriate landing decisions for safety

### 5.2 Resilience Features

1. **Redundant Sensor Inputs**
   - Dual GNSS receivers (A and B)
   - Multiple pressure sensors
   - IMU and LIDAR for altitude determination

2. **Graceful Degradation**
   - Can operate with partial sensor availability
   - Degrades performance rather than failing completely

3. **Contingency Handling**
   - Low battery detection and response
   - Invalid position handling
   - Excessive tracking error detection

4. **Safety Checks**
   - Arming protection logic
   - Route validation before takeoff
   - Continuous monitoring of system health

## 6. System States and Transitions

The Recovery System implements a state machine with the following states:

| State | Description | Entry Condition | Exit Condition |
|-------|-------------|----------------|----------------|
| Initializing | System startup | System power-on | Navigation initialized |
| Idle | Waiting for commands | Navigation initialized | Pre-flight checks complete |
| ReadyForTakeOff | Ready for mission | Pre-flight checks complete | Takeoff or switchover |
| ReadyForInAirTakeOver | Ready for in-air control | In flight, before switchover | Switchover signal |
| DepartureRecovery | Initial recovery control | Switchover detected | Vehicle stabilized |
| FlyMission | Following mission route | Vehicle stabilized | Route completed or landing commanded |
| Land | Executing landing | Landing commanded | On-ground detection |
| Landed | On ground after landing | On-ground confirmed | Mission complete |
| KillHazOps | Shutdown sequence | Mission complete | System shutdown |

## 7. Message Transformation and Communication

The Message Handling component serves as a critical data transformation layer:

1. **VSDK to Simulink Conversion**
   - Converts VSDK message formats to Simulink data structures
   - Handles unit conversions and data mapping
   - Ensures proper data formatting across system boundaries

2. **Simulink to VSDK Conversion**
   - Extracts data from Simulink outputs
   - Populates VSDK messages for external communication
   - Maintains data integrity across format boundaries

3. **Key Transformations**
   - GNSS data transformation
   - State estimate conversion
   - Navigation introspection data formatting
   - Controller log population

## 8. System Resilience and Contingency Handling

### 8.1 Low Battery Handling

```
if (input.is_recovery_in_control) {
    if (input.battery_soc_received && 
        input.pack_state_of_charge_cp < param_.max_state_of_charge_for_land_cp) {
        // Battery state of charge below threshold, command landing
        SetStraightLandCommand();
    }
}
```

### 8.2 Position Estimate Loss

```
if (input.is_recovery_in_control) {
    if (state_estimate.status_posvel_horiz.value != StateEstimateFieldStatus::VALID) {
        // Horizontal position is not valid, command landing
        SetStraightLandCommand();
    }
}
```

### 8.3 Excessive Tracking Error

```
const float horizontal_tracking_error = controllers_route_tracking_data.tracking_error_horizontal_m;
const float vertical_tracking_error = controllers_route_tracking_data.tracking_error_vertical_m;
const float total_tracking_error = std::sqrt(horizontal_tracking_error*horizontal_tracking_error + 
                                           vertical_tracking_error*vertical_tracking_error);

if (total_tracking_error > param_.straight_land_on_switchover_total_tracking_threshold_m) {
    // Tracking error too large, command landing
    SetStraightLandCommand();
}
```

## 9. Conclusion

The Recovery System provides a comprehensive backup navigation and control capability that can take over vehicle operation when the primary system fails. Its architecture ensures a complete, independent path from sensor inputs to motor commands, with robust contingency handling and safety features.

The system's modular design with specialized components for GNSS processing, route tracking, and message handling enables efficient operation and clear separation of concerns. The dual-rate architecture (500Hz for navigation, 100Hz for control) ensures responsive attitude control while maintaining efficient computational resource usage.

The Recovery System's ability to continue mission execution or safely land the vehicle in various failure scenarios makes it a critical safety component for autonomous vehicle operations.