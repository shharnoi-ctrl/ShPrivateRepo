# Generated from:

- Amazon-PrimeAir/items/ASTRO/items/EV2/Recovery 1/02_Core_Configuration.md (9363 tokens)
- Amazon-PrimeAir/items/ASTRO/items/EV2/Recovery 1/02_Navigation_Positioning.md (3311 tokens)
- Amazon-PrimeAir/items/ASTRO/items/EV2/Recovery 1/02_Sensor_Configuration.md (5062 tokens)
- Amazon-PrimeAir/items/ASTRO/items/EV2/Recovery 1/02_Flight_Control_Systems.md (5206 tokens)
- Amazon-PrimeAir/items/ASTRO/items/EV2/Recovery 1/02_Communication_Interfaces.md (3678 tokens)

---

# PDI Recovery1 System Safety Analysis

## 1. Safety Architecture Overview

The PDI Recovery1 system implements a comprehensive safety architecture with multiple layers of redundancy, fault detection, error handling, and recovery mechanisms. This analysis synthesizes information from the core configuration, navigation, sensor, flight control, and communication subsystems to provide a holistic view of the system's safety features.

### 1.1 Safety Philosophy

The PDI Recovery1 system follows a defense-in-depth approach to safety with:

1. **Redundant Hardware**: Multiple IMUs, dual GNSS receivers, and redundant communication channels
2. **Fault Detection**: Extensive monitoring variables and thresholds for detecting anomalies
3. **Graceful Degradation**: Multiple operational modes with varying levels of capability
4. **Contingency Management**: Structured responses to different types of failures
5. **Recovery Mechanisms**: Dedicated recovery subsystem with switchover capability

## 2. Sensor Redundancy and Fault Tolerance

### 2.1 IMU Redundancy Architecture

The system employs four distinct IMUs with different capabilities:

| IMU | Acceleration Range | Sampling Rate | Max NV Samples | Role |
|-----|-------------------|---------------|----------------|------|
| IMU0 | ±4g | 160 Hz (acc), 128 Hz (gyro) | 10 | Primary |
| IMU1 | ±4g | 160 Hz (acc), 128 Hz (gyro) | 10 | Primary Redundant |
| IMU2 | ±2g | Custom (accODR=12) | 30 | Secondary with higher tolerance |
| IMU3 | Not specified | 4-stage filtering | 10 | Tertiary with enhanced filtering |

**Safety Features:**
- **Non-Valid Sample Counting**: Each IMU tracks consecutive invalid readings (10-30 samples allowed)
- **Maximum Delta Thresholds**: Limits on acceptable changes between readings (e.g., 69.81317 rad/s for gyroscopes)
- **Sensor Suite Management**: Dynamic selection of best-performing sensors
- **Variance-Based Weighting**: Sensors with higher variance contribute less to the final state estimate

### 2.2 GNSS Redundancy

The system employs dual GNSS receivers with multi-constellation support:

| Receiver | Update Rate | Dynamic Model | Min Satellites | Constellations |
|----------|-------------|---------------|----------------|---------------|
| Primary (UBX0) | 4 Hz | Airborne <4g | 4 | GPS, Galileo, GLONASS, BeiDou, QZSS, SBAS |
| Secondary (UBX1) | 2 Hz | Airborne <4g | 4 | GPS, Galileo, GLONASS, BeiDou, QZSS, SBAS |

**Safety Features:**
- **Multi-Constellation Support**: Maintains positioning even if signals from certain constellations are compromised
- **Position Accuracy Limits**: 15m horizontal, 25m vertical maximum acceptable error
- **GPS Validation Time**: 5.0 seconds required to validate GPS signals
- **Dead Reckoning**: Maintains navigation during brief GNSS outages (parameter: 10.0)

## 3. Error Detection and Monitoring

### 3.1 Comprehensive Performance Monitoring

The system implements 113 monitoring variables tracking performance across all subsystems:

#### 3.1.1 Controller Timing Metrics
- ctr_time_max/avg: Controller execution time
- ctr_pre_time_max/avg: Pre-controller processing time
- ctr_input_max/avg: Controller input processing time
- post_ctr_max/avg: Post-controller processing time

#### 3.1.2 Component Performance Metrics
- sep_max/avg: State Estimation Processor metrics
- tcg_max/avg: Trajectory Command Generator metrics
- tsc_max/avg: Trajectory Setpoint Controller metrics
- aacg_max/avg: Attitude and Acceleration Command Generator metrics
- mixer_step_max/avg: Mixer step execution metrics
- rmdp_max/avg: Recovery Module Data Processor metrics
- rmpf_max/avg: Recovery Module Phase Finder metrics
- rrc_max/avg: Recovery Route Calculator metrics

### 3.2 System Status Flags

The system maintains 42 status flags for monitoring critical states:

- is_onground (1300): Ground detection status
- control status (1301): Current control status
- do switchover (1302): Control system switchover command
- mixer is saturated (1305): Actuator saturation detection
- recovery is in control (1306): Recovery system control status
- recovery is armed allowed (1308): Recovery arming permission

### 3.3 Motor Monitoring

- rpm0 through rpm5: Continuous monitoring of all six motor speeds
- motor_spin_dir_test_init_rcv (1328): Motor spin direction test initialization
- motor_spin_dir_test_result_rcv (1329): Motor spin direction test results

## 4. Recovery Subsystem

### 4.1 Core Recovery Configuration

The recovery subsystem serves as a backup flight control system that can take over in case of primary system failure:

- **Switchover Enabled**: 1 (enabled)
- **Motor Arm Delay**: 5.0 seconds after Main Recovery System (MRS) activation
- **Wind Estimate Source**: CX3 wind estimates (enabled)

### 4.2 Recovery Phase Detection

The Recovery Module Phase Finder (RMPF) detects flight phases with specific thresholds:

- **Ground Detection**: 0.48m altitude threshold
- **Takeoff Detection**: 1.0m altitude, 0.5m/s velocity, 2.6m/s² acceleration
- **Landing Detection**: 0.5m/s vertical velocity, 10.0m horizontal position, 0.5m/s groundspeed

### 4.3 Contingency Planning

- **Battery Thresholds**: Minimum SOC for contingency planning: 1000, Maximum SOC for landing: 2300
- **Bounding Box Protection**: Enabled with 5.0m half-length, 5.0m half-width, 10.0m half-height
- **GNSS Requirements**: Maximum horizontal position accuracy: 15.0m, Maximum vertical position accuracy: 25.0m

### 4.4 Ground Detection

Multiple mechanisms for reliable ground detection:

- **Jerk-Based Detection**: 3.5m/s³ threshold with 0.75s window
- **Velocity-Based Detection**: 0.25m/s vertical velocity threshold
- **Motor-Based Takeoff Validation**: Requires 4 motors at minimum 1500 RPM

## 5. Contingency Management

### 5.1 Geofencing System

The system implements a multi-level geofencing approach:

- **Contingency Boundary**: First level of protection triggering warnings
- **Emergency Boundary**: Second level requiring immediate action
- **Emergency Margin**: Buffer zone around emergency boundary
- **Prohibited Areas**: Absolutely restricted areas

### 5.2 Wind Management

- **Wind Gust Threshold**: 12.8m/s
- **Wind Gust Counter**: Triggers after 3 consecutive detections
- **Weathervaning**: Enabled above 2.0m/s airspeed
- **Maximum IAS Threshold**: 25.0m/s

### 5.3 Attitude Contingency Handling

- **Attitude Contingency Mode Blending**: Enabled with 2.0s blending time
- **Maximum Attitude Error**: 3.1415 rad (180°)
- **Maximum Angular Rate**: 3.1415 rad/s (180°/s)
- **Maximum Tracking Errors**: 
  - Horizontal: 9999.0m (effectively unlimited in non-VTOL mode)
  - Vertical: 99.0m (non-VTOL), 5.0m (VTOL)
  - VTOL horizontal: 10.0m

## 6. Communication Redundancy

### 6.1 CAN Bus Redundancy

The system implements three CAN interfaces for redundant communication:

- **CAN A**: 500,000 bps with 4 receive filters
- **CAN B**: 500,000 bps with 4 receive filters (identical to CAN A)
- **CAN FD A**: Higher speed with bit rate switching enabled and 12 receive filters

### 6.2 Telemetry Redundancy

Four telemetry streams provide redundant system monitoring:

- **Primary Stream**: 20 Hz with 70 data fields
- **Secondary Stream**: 20 Hz with 65 data fields
- **Tertiary Stream**: 20 Hz with 65 data fields
- **Quaternary Stream**: 10 Hz with 60 data fields

### 6.3 External Communication Options

Multiple communication pathways (currently configured but disabled):
- **Iridium Satellite**: For global connectivity
- **SARA Cellular**: For connectivity where cellular networks are available
- **ADS-B Integration**: For air traffic awareness

## 7. Control System Safety Features

### 7.1 Mixer Safety Features

- **Actuator Saturation Detection**: Flag when mixer reaches limits
- **Contingency Mode Blending**: 2.0s transition time for smooth handover
- **Motor Configuration**: 6 motors for redundancy (can operate with motor failures)

### 7.2 State Machine Safety Parameters

- **Track Spline Parameters**: Maximum tracking errors defined for different flight phases
- **Takeoff Manager**: Horizontal controllers enabled in on-ground mode
- **Land Manager**: Fast descent rate: -1.0m/s for quick landing when needed

### 7.3 Attitude Control Safety

- **Maximum Vertical Speed**: 10.0m/s limit
- **Maximum VTOL Altitude**: 20.0m limit
- **Vertical Acceleration Command Thresholds**: -1.5g to -0.6g
- **Pitch Augmentation Limits**: -10° to 10°

## 8. Sensor Data Validation

### 8.1 Outlier Rejection

- **Max Delta Thresholds**: Different for each sensor type and instance
  - Accelerometers: 156.8 to 313.8128 m/s² depending on IMU
  - Gyroscopes: Consistent 69.81317 rad/s across all IMUs
  
- **Non-Valid Sample Counting**: Tolerance for consecutive invalid readings
  - Primary IMUs (0,1): 10 samples
  - Secondary IMU (2): 30 samples
  - External sensors: 10 samples

### 8.2 Sensor Fusion

- **Default Sensor Selection**: IMU0 designated as primary for both gyroscope and accelerometer
- **Dynamic Variance Adjustment**: Initial variance 1.0, minimum variance 1.0E-4
- **Time Constants**: tau_v=2.0, tau_s2=20.0 for smooth transitions

## 9. Recovery Procedures

### 9.1 Switchover Mechanism

- **Switchover Command**: Triggered by "do switchover" flag (1302)
- **Recovery Control Indication**: "recovery is in control" flag (1306)
- **Recovery Tracking Status**: "recovery tracking has started" flag (1307)

### 9.2 Arming Sequence

- **Arming Permission**: Controlled by "recovery is armed allowed" flag (1308)
- **Arming Restriction**: Monitored by "recovery arming disallowed" flag (1309)
- **Motor Arm Delay**: 5.0 seconds after MRS activation

### 9.3 Recovery Route Planning

- **Minimum Velocity**: 0.2m/s required for route planning
- **Initial Tracking Point**: Set by "recovery initial tracking point set" flag (1311)
- **Takeoff Execution**: Monitored by "recovery takeoff executed" flag (1310)

## 10. Key Safety Parameters

### 10.1 Critical Thresholds

| Parameter | Value | Safety Impact |
|-----------|-------|--------------|
| Motor Arm Delay | 5.0 seconds | Prevents premature motor activation |
| Ground Altitude | 0.48m | Threshold for ground detection |
| Takeoff Altitude | 1.0m | Minimum height to confirm takeoff |
| Landing Velocity | 0.5m/s | Maximum vertical speed for landing detection |
| Wind Gust Threshold | 12.8m/s | Triggers wind gust contingency handling |
| GNSS Horizontal Accuracy | 15.0m | Maximum acceptable position error |
| GNSS Vertical Accuracy | 25.0m | Maximum acceptable altitude error |
| Minimum Motor Count | 4 motors at 1500 RPM | Required for takeoff validation |
| Jerk Threshold | 3.5m/s³ | For impact/ground detection |
| Maximum VTOL Tracking Error | 10.0m horizontal, 5.0m vertical | Safety limits during VTOL operation |

### 10.2 Time Constants

| Parameter | Value | Safety Impact |
|-----------|-------|--------------|
| Attitude Contingency Blending | 2.0s | Smooth transition during contingency |
| Mixer Contingency Blending | 2.0s | Smooth transition for motor outputs |
| Wind Time Constant | 10.0s | Filtering period for wind estimates |
| GPS Validation Time | 5.0s | Required period to trust GPS signals |
| Dead Reckoning Parameter | 10.0 | Maximum duration for navigation without GPS |
| Jerk Window | 0.75s | Time window for impact detection |

## 11. Integrated Safety Workflow

The PDI Recovery1 system implements a layered safety approach:

1. **Continuous Monitoring**:
   - Performance metrics for all subsystems
   - Status flags for critical states
   - Sensor data validation with outlier rejection

2. **Anomaly Detection**:
   - Threshold-based detection for sensor anomalies
   - Performance monitoring for timing issues
   - Status flag monitoring for system state changes

3. **Contingency Response**:
   - Geofencing with multiple boundary levels
   - Wind gust handling with counter threshold
   - Attitude contingency mode with blending

4. **Recovery Activation**:
   - Switchover to recovery system when needed
   - Arming sequence with safety delays
   - Route planning for safe trajectory

5. **Safe Landing**:
   - Ground detection with multiple mechanisms
   - Landing velocity thresholds
   - Fast descent rate for emergency situations

## 12. Conclusion

The PDI Recovery1 system implements a comprehensive safety architecture with multiple layers of redundancy, fault detection, and recovery mechanisms. The system is designed to handle a wide range of anomalies and failures, from sensor errors to communication issues and environmental challenges.

Key safety features include:
- Multiple redundant sensors (4 IMUs, dual GNSS)
- Extensive performance monitoring (113 variables)
- Comprehensive status tracking (42 flags)
- Dedicated recovery subsystem with switchover capability
- Multi-level geofencing and contingency management
- Robust ground detection and landing logic
- Redundant communication channels

These features work together to ensure the system can detect anomalies, respond appropriately, and maintain safe operation even in degraded conditions. The careful configuration of thresholds, time constants, and blending parameters ensures smooth transitions between normal and contingency operations, while the redundant hardware architecture provides resilience against component failures.