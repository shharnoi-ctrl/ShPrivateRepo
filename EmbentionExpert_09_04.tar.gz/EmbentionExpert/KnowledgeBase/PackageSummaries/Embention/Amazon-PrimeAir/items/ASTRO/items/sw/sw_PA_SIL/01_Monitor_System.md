# Generated from:

- Amazon-PrimeAir/items/ASTRO/items/sw/sw_PA_SIL/02_Monitor_Module.md (3976 tokens)
- Amazon-PrimeAir/items/ASTRO/items/sw/sw_PA_SIL/02_Monitor_Tests_Core.md (2825 tokens)
- Amazon-PrimeAir/items/ASTRO/items/sw/sw_PA_SIL/02_Monitor_Tests_State_Machines.md (1751 tokens)
- Amazon-PrimeAir/items/ASTRO/items/sw/sw_PA_SIL/02_Monitor_Tests_Checks.md (4281 tokens)

---

# Comprehensive Overview of the Prime Air Monitor System

## 1. Introduction and System Architecture

The Prime Air Monitor System is a critical safety component of Amazon's Prime Air drone delivery platform. It serves as an independent safety monitor that continuously evaluates the drone's state, detects anomalies, and triggers appropriate responses to maintain safe operation. The monitor system operates alongside the primary flight control system, providing an additional layer of safety through independent verification of the drone's behavior.

The monitor system architecture consists of several key components:

### Core Components

1. **Monitor Builder (`Monitor_builder`)**:
   - Central component responsible for constructing and initializing the monitoring system
   - Builds and initializes monitor objects in a structured manner
   - Provides access to the Platform Abstraction (PA) Monitor instance

2. **PA Monitor (`Blk_pa_mon`)**:
   - Main monitoring logic implementation
   - Processes inputs from various system components
   - Generates outputs including failover triggers, log data, and alerts
   - Executes safety checks and state machine logic

3. **Monitor Wrapper (`Emb_monitor_wrapper`)**:
   - Interface between the monitor module and the broader simulation framework
   - Implements the `FirmwareSimulation` interface
   - Handles message passing, initialization, and execution scheduling
   - Manages simulation time and component execution

4. **Package Delivery System (PDS) Simulation**:
   - Simulates the package delivery door mechanism
   - Models servo behavior, door states, and position feedback
   - Provides realistic simulation of physical hardware components
   - Implements state machine for door operations (open, closed, opening, closing)

### Hierarchical State Machine System

The monitor implements a sophisticated hierarchical state machine system to track and control the drone's mission phases:

1. **Top-Level State Machine**:
   - **Mission_mode_sm**: Controls high-level mission phases
     - States: `idle`, `pre_flight`, `in_flight`, `post_flight`

2. **Second-Level State Machines**:
   - **Idle_sm**: Manages initialization states
   - **Pre_flight_sm**: Manages pre-flight checks and preparations
   - **In_flight_sm**: Manages in-flight operations
   - **Post_flight_sm**: Manages post-flight operations

3. **Third-Level State Machines**:
   - **In_flight_nominal_sm**: Manages nominal flight operations
   - **Backyard_delivery_sm**: Manages delivery operations
   - **Backyard_exit_sm**: Manages exit from delivery area
   - **Landing_sm**: Manages landing operations

This hierarchical structure allows the monitor to track the drone's state at multiple levels of granularity and enforce appropriate safety checks for each mission phase.

## 2. Monitor System Functionality

### Input Processing and Message Handling

The monitor processes a wide range of input messages through the `PutMessage` method. These messages are categorized by their type and routed to the appropriate components:

1. **State Estimates**:
   - Primary state estimate (`cyp_pa_primary_state_estimate_compact`)
   - Recovery state estimate (`cyp_state_estimate_compact`)
   - Monitor state estimate (`cyp_mon_nav_state_estimate`)

2. **Motor Commands and Performance**:
   - Primary motor RPM command (`cyp_motor_rpm_cmd_a`)
   - Recovery motor RPM command (`cyp_pa_recovery_motor_rpm_command_rear_right`)
   - Motor performance data (`cyp_motor_perf`)

3. **Mission and System Status**:
   - Mission reset command (`cyp_pa_mission_reset_command`)
   - Controllers monitored data (`cyp_pa_controllers_monitored_data`)
   - Mission readiness signal (`cyp_pa_recovery_mission_readiness`)
   - VMS monitored data (`cyp_pa_monitored_data`)

4. **Heartbeats and Health Signals**:
   - Air data estimator heartbeat (`cyp_pa_air_data_estimator_heartbeat`)
   - On ground heartbeat (`cyp_pa_on_ground_heartbeat`)
   - CCP heartbeat (`cyp_pa_ccp_heartbeat`)

5. **Package Delivery System Commands**:
   - PDS door command (`cyp_pa_pds_command`)
   - PDS calibration command (`cyp_pds_calibration_command`)

6. **Mission Planning**:
   - Monitor mission plan data (`cyp_pa_monitor_mission_plan_data`)
   - Upload mission plan wrapper (`cyp_pa_upload_mission_plan_wrapper_mon`)

7. **Sensor Data**:
   - Dynamic pressure calibrated left/right (`cyp_meas_dyn_press_calib_left`, `cyp_meas_dyn_press_calib_right`)
   - Pseudojerk measurements (`cyp_pseudojerk`)

8. **Contingency Commands**:
   - Diverse comms command contingency (`cyp_pa_diverse_comms_command_contingency`)
   - Command contingency wrapper (`cyp_pa_command_contingency_wrapper`)

### Output Generation

The monitor generates several types of outputs through the `GetMessage` method:

1. **Failover Triggers**:
   - Generated when the monitor detects critical anomalies
   - Sent with message type `cyp_fail_over_trigger`
   - Initiates appropriate contingency responses

2. **Log Data**:
   - Compact log data containing monitoring information
   - Sent with message type `cyp_mon_logdatacompact`
   - Provides diagnostic information for post-flight analysis

3. **Monitor Alerts**:
   - Alerts about detected anomalies or issues
   - Sent with message type `cyp_pa_monitor_alerts`
   - Provides real-time notification of potential issues

4. **PDS State Updates**:
   - Package Delivery System state information
   - Sent periodically (every 100ms)
   - Includes door state, position, and health information

5. **Drone State Updates**:
   - Drone state information
   - Sent with message type `cyp_mon_drone_state`
   - Provides current mission phase and status information

### Execution Flow

The main execution flow occurs in the `ExecuteAndScheduleNextExecutionInNs` method:

1. Build monitor objects if not already done
2. Set the current simulation time
3. Step the PA monitor if build was successful
4. Run the Package Delivery System simulation
5. Update simulation time and return

This execution flow ensures that the monitor processes inputs, updates its state, and generates outputs in a consistent and timely manner.

## 3. Safety Checks and Monitoring Algorithms

The monitor system implements a comprehensive set of safety checks to detect anomalies and ensure safe operation. These checks are organized into several categories:

### Vehicle State Checks

1. **Angular Velocity Checks**:
   - Detects unsafe angular velocities (roll, pitch, yaw rates)
   - Compares estimated and expected angular rates
   - Applies phase-specific thresholds (VTOL, transition, WBF)
   - Adjusts thresholds during contingency operations

2. **Position Checks**:
   - Detects position errors relative to expected trajectory
   - Monitors alongtrack, crosstrack, and altitude errors
   - Applies phase-specific thresholds
   - Adjusts thresholds based on DGNSS availability

3. **Attitude Checks**:
   - Monitors roll, pitch, and yaw angles
   - Compares estimated and expected attitudes
   - Applies phase-specific thresholds
   - Ensures the drone maintains proper orientation

4. **Linear Velocity Checks**:
   - Monitors velocity errors in all three axes
   - Compares estimated and expected velocities
   - Applies phase-specific thresholds
   - Ensures the drone maintains proper speed control

### Navigation Checks

1. **Navigation Position Checks**:
   - Detects inconsistencies between navigation solutions
   - Applies tighter thresholds when DGNSS is available
   - Monitors horizontal and vertical position differences
   - Ensures reliable position information

2. **Navigation Velocity Checks**:
   - Detects velocity inconsistencies between navigation solutions
   - Implements fault detection counters
   - Manages state machine transitions between inactive, active, and failure states
   - Ensures reliable velocity information

3. **RAIM (Receiver Autonomous Integrity Monitoring)**:
   - Monitors GNSS integrity
   - Validates position solutions from GNSS measurements
   - Integrates differential GNSS corrections
   - Detects GNSS measurement inconsistencies

### System Health Checks

1. **Motor Arm Check**:
   - Verifies proper motor arming states for different mission phases
   - Ensures motors are armed during flight
   - Validates motor arming state based on mission mode

2. **Inadvertent Takeoff Check**:
   - Detects unintended motor activation
   - Monitors motor RPMs during pre-flight
   - Prevents unexpected takeoff

3. **Enacted Contingency Checks**:
   - Detects mismatches between commanded and enacted contingencies
   - Ensures proper response to contingency commands
   - Handles detection timeouts

4. **Mission Phase Check**:
   - Detects mission phase inconsistencies
   - Ensures monitor and primary systems have synchronized mission phases
   - Maintains consistent system state awareness

5. **Message Rate Check**:
   - Monitors the rate of critical messages
   - Ensures timely communication between components
   - Detects communication failures

### Urgent Land Monitor

The Urgent Land Monitor is a specialized component that detects conditions requiring immediate landing:

1. **Navigation Conditions**:
   - Detects navigation issues requiring urgent land
   - Monitors position and velocity errors
   - Ensures the drone can safely navigate

2. **Energy Conditions**:
   - Detects energy-related issues requiring urgent land
   - Monitors battery state and power consumption
   - Ensures sufficient energy for safe operation

3. **Mission Phase**:
   - Detects landing mission phase
   - Ensures proper landing sequence
   - Monitors landing progress

4. **Command Handling**:
   - Processes urgent land commands
   - Ensures proper response to emergency situations
   - Prioritizes safety-critical commands

## 4. State Machine Logic and Mission Phases

The monitor's state machine system manages the drone's mission phases and ensures proper sequencing of operations:

### Mission Initialization

1. The system starts in the `idle` state
2. Waits for all three navigation systems (primary, monitor, recovery) to be initialized
3. Transitions to `pre_flight` when a valid mission is received
4. Performs heading checks to ensure proper orientation

### Pre-Flight Sequence

1. Validates mission plan against site heading
2. Waits for mission readiness signal
3. Verifies required inputs from all systems
4. Performs takeoff state checks and heading verification
5. Waits for propulsion window and performs motor checks
6. Waits for takeoff window and transitions to flight when ready

### In-Flight Operations

1. Manages takeoff, flight to delivery, delivery operations, and return flight
2. Handles contingencies like urgent land commands
3. Monitors height above target during delivery operations
4. Controls package delivery system (PDS) operations

### Landing and Post-Flight

1. Manages landing descent and touchdown
2. Handles motor disarming
3. Controls PDS door operations
4. Waits for reset signal to return to idle state

### Safety Features

The state machine system implements several critical safety features:

1. **Heading Checks**: Multiple heading checks ensure the drone is properly oriented before takeoff
2. **Attitude Checks**: Verifies roll and pitch are within acceptable limits
3. **Timing Windows**: Enforces proper timing for propulsion enabling and takeoff
4. **Contingency Handling**: Manages urgent land and other contingency responses
5. **Height Monitoring**: Verifies proper altitude management during delivery operations

## 5. Package Delivery System (PDS)

The Package Delivery System is a critical component for the drone's primary mission of delivering packages:

### PDS Components and Parameters

```cpp
// PDS simulation parameters
data->pds_sim_param.max_servo_angle_voltage_V = 3.3F;
data->pds_sim_param.min_servo_angle_voltage_V = 0.0F;
data->pds_sim_param.max_servo_angle_deg = 180.0F;
data->pds_sim_param.min_servo_angle_deg = -180.0F;
data->pds_sim_param.max_servo_angle_pwm_period_us = 2100.0F;
data->pds_sim_param.min_servo_angle_pwm_period_us = 900.0F;
data->pds_sim_param.open_door_servo_angle_deg = 145.0F;
data->pds_sim_param.closed_door_servo_angle_deg = -163.0F;
```

### PDS State Machine

The PDS implements a state machine for the door with the following states:
- `open`: Door is fully open (angle > open_door_servo_angle_deg)
- `closed`: Door is fully closed (angle < closed_door_servo_angle_deg)
- `opening`: Door is transitioning to open (angle increasing)
- `closing`: Door is transitioning to closed (angle decreasing)

### PDS Control Logic

The PDS processes two main inputs:
1. `power_enable_command`: Boolean indicating if power should be enabled
2. `pwm_command`: PWM period in microseconds controlling servo position

The simulation converts the PWM command to an angle and voltage using linear mapping:
```cpp
Real pwm_period_range_us = parameters_.max_servo_angle_pwm_period_us - parameters_.min_servo_angle_pwm_period_us;
Real servo_angle_range_deg = parameters_.max_servo_angle_deg - parameters_.min_servo_angle_deg;
Real servo_angle_voltage_range_V = parameters_.max_servo_angle_voltage_V - parameters_.min_servo_angle_voltage_V;

Real angle_cmd_deg = (pwm_cmd - parameters_.min_servo_angle_pwm_period_us) / pwm_period_range_us * servo_angle_range_deg - (servo_angle_range_deg / 2);
Real angle_meas_deg = angle_cmd_deg;
Real V_meas = (angle_meas_deg + (servo_angle_range_deg / 2)) / servo_angle_range_deg * servo_angle_voltage_range_V;
```

### PDS Command Generator

The PDS Command Generator is responsible for generating appropriate commands for the PDS based on the current mission phase and delivery requirements. It ensures that the door opens and closes at the right times during the delivery sequence.

## 6. Testing Methodology

The Prime Air Monitor System is thoroughly tested using a comprehensive test suite that verifies the correct behavior of all components:

### Test Framework Structure

The test framework includes:
1. **Test Utilities**: Functions for initializing test data structures
2. **Test Result Reporting**: Mechanisms for reporting test results with color coding
3. **Test Runner**: Orchestrates the execution of all test cases

### Common Testing Patterns

Across all monitor tests, several common patterns emerge:

1. **Test Class Structure**:
   - Constructor that initializes test parameters and inputs
   - `reset()` method to restore default test conditions
   - `test_all()` static method as the entry point
   - `run_all_tests()` method that executes individual test cases
   - Individual test methods for specific functionality

2. **Test Execution Pattern**:
   - Set up test inputs and expected outputs
   - Call the component's `step()` method
   - Verify outputs match expectations
   - Reset test conditions for the next test

### Comprehensive Test Coverage

The test suite provides comprehensive coverage of:

1. **Normal Operation Paths**: Testing the expected sequence of states during a successful mission
2. **Contingency Paths**: Testing responses to various failure conditions
3. **Boundary Conditions**: Testing edge cases like timing window boundaries
4. **Safety Checks**: Verifying all safety-critical checks function properly

### Testing Methodology

The monitor tests demonstrate a comprehensive approach to safety verification:

1. **Boundary Testing**: Tests verify behavior at and around threshold values
   ```cpp
   testcases[0].error_lpf_rad_per_s = check_inputs_.roll_rate_trim_ned2trim.max_error_lpf_rad_per_s;
   testcases[1].error_lpf_rad_per_s = check_inputs_.roll_rate_trim_ned2trim.max_error_lpf_rad_per_s + 1.0F;
   ```

2. **State Machine Testing**: Tests verify proper state transitions and behaviors
   ```cpp
   test_result = test_check_statemachine_inactive_to_active();
   test_result = test_check_statemachine_active_to_inactivelatched();
   ```

3. **Parameter Sensitivity**: Tests verify behavior with different parameter values
   ```cpp
   test_parameters_.count_increment = 3;
   test_parameters_.count_decrement = 2;
   test_parameters_.max_fault_detection_count = 25;
   ```

4. **Failure Mode Testing**: Tests verify proper detection of various failure modes
   ```cpp
   test_result = test_angular_velocity_check_est_rpy_rate_fail();
   test_result = test_difference_large_dgnss();
   ```

5. **Mathematical Correctness**: Tests verify correct implementation of mathematical algorithms
   ```cpp
   bool test_compute_expected_roll_trim_ned2trim();
   bool test_compute_expected_pitch_trim_ned2trim();
   bool test_compute_expected_yaw_trim_ned2trim();
   ```

### Specific Test Components

1. **State Machine Tests**:
   - Verify correct state transitions based on events
   - Ensure proper sequencing of mission phases
   - Validate safety constraints during transitions

2. **Safety Check Tests**:
   - Verify detection of unsafe conditions
   - Validate threshold selection and application
   - Ensure proper fault detection and response

3. **Algorithm Tests**:
   - Verify correct implementation of mathematical algorithms
   - Validate filter behavior (e.g., IIR filters)
   - Ensure proper time handling (e.g., TAI time)

4. **Integration Tests**:
   - Verify proper interaction between components
   - Validate end-to-end behavior
   - Ensure system-level safety properties

## 7. Key Algorithms and Data Structures

### Monitor Builder Pattern

The monitor uses a builder pattern for initialization:
1. Create builder with dependencies
2. Call `build()` to construct monitor components
3. Check `is_build_ok()` before using the monitor
4. Access components via getter methods

### IIR Filter Implementation

The monitor uses Infinite Impulse Response filters for signal processing:
1. Configurable numerator and denominator coefficients
2. Proper handling of edge cases (no taps, only numerator, only denominator)
3. Mathematically equivalent to state-space model implementation
4. Used for smoothing sensor data and detecting trends

### Time in TAI Implementation

The monitor implements International Atomic Time (TAI) handling:
1. Proper time constants and conversions
2. Synchronized time serialization
3. Conversion between different time representations
4. Critical for ensuring proper timing of safety-critical operations

### Message Routing Algorithm

The monitor uses a sophisticated message routing system:
1. Messages are categorized by type
2. Each message type is routed to the appropriate component
3. Single-slot buffers are cleared before adding new messages
4. Ensures proper handling of all input messages

### PDS Simulation Algorithm

The PDS simulation implements a simplified physical model of a servo-controlled door:
1. Process power enable command (if power is off, set minimum values)
2. Saturate PWM command within valid range
3. Convert PWM command to angle using linear mapping
4. Determine door state based on angle and previous state
5. Calculate position voltage based on angle
6. Populate output state structure with calculated values

### RAIM Algorithm

The Receiver Autonomous Integrity Monitoring algorithm:
1. Processes GNSS measurements and navigation messages
2. Computes position and velocity solutions
3. Detects and handles measurement inconsistencies
4. Applies DGNSS corrections when available
5. Ensures reliable navigation information

## 8. Error Handling and Contingency Logic

The monitor includes several error handling mechanisms:

1. **Message Validation**:
   - Checks if incoming messages are valid before processing
   - Returns false if message type is unknown or processing fails
   - Ensures robust handling of communication errors

2. **Build Status Checking**:
   - Verifies that the monitor is properly built before stepping
   - Only processes messages if the monitor build is successful
   - Prevents operation with incomplete initialization

3. **PDS Simulation Safeguards**:
   - Handles power-off conditions gracefully
   - Saturates PWM commands within valid ranges
   - Maintains consistent door state transitions
   - Prevents unsafe door operations

4. **Failover Triggering**:
   - Generates failover triggers when critical anomalies are detected
   - Sends these triggers to the broader system for handling
   - Ensures appropriate response to safety-critical conditions

5. **Fault Detection Counters**:
   - Implements counters to track persistent faults
   - Increments counters when errors are detected
   - Decrements counters when errors are resolved
   - Prevents false alarms from transient errors

6. **State Machine Safeguards**:
   - Enforces proper state transitions
   - Prevents invalid state combinations
   - Ensures mission phases proceed in the correct sequence
   - Maintains system safety during all operations

## 9. Integration with SIL Framework

The monitor module integrates with the broader Software-In-the-Loop (SIL) framework through the `FirmwareSimulation` interface:

### Initialization

```cpp
extern "C" FirmwareSimulation* get_firmware_simulation_instance()
{
    static FirmwareSimulation* ret = new Wrapper::Emb_monitor_wrapper();
    return ret;
}
```

This function provides a C-compatible interface for the simulation framework to obtain an instance of the monitor wrapper.

### Configuration Loading

The monitor can load configuration data from PDI (Persistent Data Interface) files:
- `cfg_vmgr` (6.bin): Variable initialization data
- `cfg_amz_site_cfg` (495.bin): Site configuration data
- `cfg_amz_mon_param` (496.bin): Monitor parameters

### Execution Scheduling

The simulation framework calls `ExecuteAndScheduleNextExecutionInNs` to advance the simulation by a specified time interval. The monitor processes inputs, updates its state, and schedules the next execution.

## 10. Conclusion: Safety and Reliability Assurance

The Prime Air Monitor System plays a crucial role in ensuring the safety and reliability of the Prime Air drone delivery platform. It achieves this through:

1. **Independent Verification**: The monitor operates independently from the primary flight control system, providing an additional layer of safety through independent verification of the drone's behavior.

2. **Comprehensive Monitoring**: The monitor implements a wide range of safety checks that cover vehicle state, navigation, system health, and mission phases, ensuring that all aspects of the drone's operation are continuously monitored.

3. **Hierarchical State Machines**: The monitor's hierarchical state machine system ensures proper sequencing of mission phases and enforces appropriate safety constraints at each stage of the mission.

4. **Robust Testing**: The comprehensive test suite verifies the correct behavior of all monitor components, ensuring that the monitor can detect and respond to unsafe conditions before they lead to system failures or safety incidents.

5. **Contingency Handling**: The monitor can detect anomalies and trigger appropriate contingency responses, including failover to backup systems or urgent landing, ensuring safe operation even in the presence of failures.

6. **Package Delivery System Control**: The monitor ensures safe operation of the package delivery system, controlling door operations and verifying proper delivery sequence.

7. **Configuration Management**: The monitor can load configuration data from persistent storage, allowing for site-specific parameters and customization.

The Prime Air Monitor System represents a sophisticated approach to safety assurance in autonomous drone operations, combining state machine logic, safety checks, and contingency handling to ensure reliable and safe package delivery.