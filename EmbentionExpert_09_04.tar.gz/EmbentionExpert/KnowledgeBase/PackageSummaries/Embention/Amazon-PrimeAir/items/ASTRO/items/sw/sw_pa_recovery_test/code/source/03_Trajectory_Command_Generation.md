# Generated from:

- TrajectoryCommandGenerator_Unit_Test.cpp (35390 tokens)
- Trajectory_polynomial_pa_test.cpp (493 tokens)
- Ttcg_pa_test.cpp (43929 tokens)
- Track_spline_state_pa_test.cpp (538 tokens)
- Tcg_test.cpp (7267 tokens)
- Tsc_pa_test.cpp (7603 tokens)

---

# Trajectory Command Generation Components: High-Fidelity Semantic Knowledge Graph

## 1. Trajectory Command Generator (TCG) Overview

The Trajectory Command Generator (TCG) is a critical component responsible for generating position, velocity, and acceleration commands based on route information. It serves as the primary interface between route planning and flight control systems, translating route data into actionable trajectory commands.

### 1.1 Core Components and Architecture

The TCG system consists of three main components working together:

1. **Trajectory Command Generator (TCG)** - The main component that coordinates the generation of trajectory commands
2. **Time-based Trajectory Command Generator (TTCG)** - Handles time-based trajectory generation and route tracking
3. **Translational Stability Controller (TSC)** - Generates acceleration commands based on position and velocity errors

The TCG integrates these components to produce commands for the flight control system based on the current flight phase, route information, and vehicle state.

### 1.2 TCG State and Parameters

```cpp
struct State {
    Real eas_cmd_previous_m_per_s;
    bool is_lla_ned_origin_latched;
    Base::Tllh lla_ned_origin;
    Base::Rv3 p_err_pos_ncg2pos_at_smoothing_start_m;
    bool smoothing_filters_first_run_complete;
    Tsc::Tsc_tracking_mode::Type tsc_tracking_mode;
    Base::Rv3 v_err_pos_ned2pos_at_smoothing_start_m_per_s;
    Waypoint_msg wp_previous_ned_ned2pos;
};

struct Parameters_ {
    Atcg::Param_ atcg;
    Ttcg::Param ttcg;
    Waca::Param waca;
    Real eas_tol_outbound_transition_switch_tsc_tracking_mode_m_per_s;
    Wp_switch_blender wp_switch_blender;
    Real p_err_pos_ncg2pos_x_m;
    Real p_err_pos_ncg2pos_y_m;
    Real p_err_pos_ncg2pos_z_m;
    Real v_ff_cmd_pos_ned2pos_x_m_per_s;
    Real v_ff_cmd_pos_ned2pos_y_m_per_s;
    Real v_ff_cmd_pos_ned2pos_z_m_per_s;
};
```

### 1.3 TCG Input and Output

```cpp
struct Input {
    Current_route_information current_route_information;
    Route_msg route;
    bool clear_route_data;
    Base::Tllh takeoff_initial_tracking_point;
    Base::Tllh lla_est_ncg;
    Real density_sched_kg_per_m3;
    Real dynamic_pressure_sched_pa;
    Base::Rv3 v_filt_ned_ned2wind_m_per_s;
    Real groundspeed_est_m_per_s;
    bool is_active_stop_and_hover;
    Waypoint_msg wp_previous_ned_ned2pos;
    Real eas_cmd_previous_m_per_s;
    State_machines_state::Mode::Controllers_mode controllers_mode;
    Rotor_failure_case::Type rotor_failure_case;
    bool freeze_tracked_point_search;
    bool always_perform_search_for_closest_point;
};

struct Output {
    Base::Rv3 p_err_pos_ncg2pos_m;
    Base::Rv3 v_ff_cmd_pos_ned2pos_m_per_s;
    Base::Rv3 v_est_pos_ned2ncg_m_per_s;
    Base::Rv3 a_ff_cmd_pos_ned2pos_m_per_s2;
    Real a_ff_cmd_x_grtraj_m_per_s2;
    Real a_ff_cmd_z_grtraj_m_per_s2;
    Base::Rv3 a_filt_vel_m_per_s2;
    Base::Rv4 q_vel_from_ned;
    Real eas_cmd_m_per_s;
    Route_tracking_data route_tracking_data;
    Phase_of_flight tracked_phase_of_flight;
    Tsc::Tsc_tracking_mode::Type tsc_tracking_mode_cmd;
    bool is_new_route_tracking_initiated;
    Real displacement_from_start_of_route_m;
    Real displacement_planned_m;
    Real speed_planned_m_per_s;
    Real route_start_time_offset_s;
    Heading_cmd heading_vel_from_ned;
};
```

## 2. Time-based Trajectory Command Generator (TTCG)

The TTCG is responsible for generating time-based trajectory commands by tracking routes and managing transitions between different flight phases.

### 2.1 TTCG State and Parameters

```cpp
struct State {
    Uint32 curr_maneuver_idx;
    Real curr_maneuver_ref_time;
    Real displacement_planned_m;
    Real inbound_hs_maneuver_time;
    Real inbound_latched_density_kg_per_m3;
    Real inbound_latched_route_time_crit_s;
    Base::Rv3 inbound_latched_v_ned_ned2wind_m_per_s;
    Real inbound_ls_maneuver_time;
    Maneuver_coordinate inbound_mc_hs;
    Maneuver_coordinate inbound_mc_ls;
    Real inbound_route_time_s;
    Real outbound_groundspeed;
    Maneuver_coordinate outbound_maneuver_coordinate;
    Real outbound_maneuver_time;
    Real route_start_time_offset_s;
    Real route_time_planned_s;
    Base::Array<Route_msg> routes;
    Phase_of_flight tracked_phase_of_flight;
    Uint32 tracked_route_idx;
    Real tracked_route_time_s;
    bool was_route_cleared_last_run;
};

struct Param {
    Real closest_point_search_tol_time_s;
    Real closest_point_search_tol_zero;
    Real closest_point_search_time_window_max_width_s;
    Real inbound_eas_crit_m_per_s;
    Real inbound_max_accel_alongtrack_highspeed_m_per_s2;
    Real inbound_max_accel_alongtrack_lowspeed_m_per_s2;
    Real inbound_transition_hs_integration_dt_override_s;
    Real inbound_transition_search_tol_speed_m_per_s;
    Real inbound_transition_search_tol_time_s;
    Real outbound_transition_search_tol_speed_m_per_s;
    Real outbound_transition_search_tol_time_s;
};
```

### 2.2 TTCG Core Functionality

#### 2.2.1 Route Tracking

The TTCG tracks routes by maintaining the current route index, maneuver index, and time within the current maneuver. It evaluates the route at the current time to generate trajectory commands.

```cpp
bool Ttcg::step(const Input& input, Output& output) {
    // Update tracked route information based on input
    // Evaluate trajectory tracking data
    // Update phase of flight
    // Evaluate transition logic
    // Update planned displacement
    // Generate output
}
```

#### 2.2.2 Phase of Flight Management

The TTCG manages transitions between different flight phases:
- VTOL (Vertical Take-Off and Landing)
- Outbound Transition
- WBF (Wing-Borne Flight)
- Inbound Transition

```cpp
bool Ttcg::update_phase_of_flight(const Input& input) {
    // Determine current phase of flight
    // Handle transitions between phases
    // Manage outbound and inbound transition maneuvers
}
```

#### 2.2.3 Closest Point Search

The TTCG performs a search to find the closest point on the trajectory to the current vehicle position, which is used to determine the current tracking point.

```cpp
bool Ttcg::search_for_closest_point_on_trajectory(const Base::Tllh& lla_est_ncg,
                                                 Real& tracked_maneuver_time_s) {
    // Find closest point on trajectory to current position
    // Update tracked maneuver time
}
```

### 2.3 Trajectory Polynomials

The TTCG uses polynomial trajectories to generate smooth transitions between waypoints. These polynomials define position, velocity, and acceleration profiles over time.

```cpp
class Polynomial {
public:
    enum Der_coeffs { orig = 0, d1 = 1, d2 = 2, d3 = 3 };
    
    void construct_trajectory_polynomial(const Base::Rv4& si, const Base::Rv4& sf, Real ts);
    Real eval_der(Real t, Der_coeffs der) const;
    bool get_valid() const;
};
```

The trajectory polynomial test demonstrates that these polynomials correctly interpolate between initial and final states:

```cpp
bool Trajectory_polynomial_pa_test::Test_1() {
    Base::Rv4 si = { 1, 2, 3, 4 };  // Initial state [position, velocity, acceleration, jerk]
    Base::Rv4 sf = { 5, 6, 7, 8 };  // Final state
    Real ts = 5;                    // Time span
    
    Polynomial p;
    p.construct_trajectory_polynomial(si, sf, ts);
    
    // Verify initial conditions
    ret &= Rfun::comp_real(1, p.eval_der(0.0F, Polynomial::Der_coeffs::orig), tol);
    ret &= Rfun::comp_real(2, p.eval_der(0.0F, Polynomial::Der_coeffs::d1), tol);
    ret &= Rfun::comp_real(3, p.eval_der(0.0F, Polynomial::Der_coeffs::d2), tol);
    ret &= Rfun::comp_real(4, p.eval_der(0.0F, Polynomial::Der_coeffs::d3), tol);
    
    // Verify final conditions
    ret &= Rfun::comp_real(5, p.eval_der(ts, Polynomial::Der_coeffs::orig), 0.002);
    ret &= Rfun::comp_real(6, p.eval_der(5.0F, Polynomial::Der_coeffs::d1), 0.002);
    ret &= Rfun::comp_real(7, p.eval_der(5.0F, Polynomial::Der_coeffs::d2), 0.002);
    ret &= Rfun::comp_real(8, p.eval_der(5.0F, Polynomial::Der_coeffs::d3), 0.002);
}
```

### 2.4 Maneuver Coordinates

Maneuver coordinates represent the trajectory for a specific maneuver, containing waypoint coordinates and polynomials for interpolation.

```cpp
class Maneuver_coordinate {
public:
    Base::Tnarrayresz<Waypoint_coordinate, Ku16::u8> wp_coord;
    Real inv_time_scale_factor;
    Base::Tnarrayresz<Polynomial, Ku16::u8> polynomial_list;
    Base::Bitset<Ku16::u8> poly_constructed;
    bool is_valid;
    
    void construct_polynomials();
    void evaluate_at_time(Real t, Waypoint_coordinate& wc) const;
    Real get_duration() const;
    Real integrate_to_time(Real t) const;
};
```

## 3. Translational Stability Controller (TSC)

The TSC generates acceleration commands based on position and velocity errors to maintain stability during trajectory tracking.

### 3.1 TSC State and Parameters

```cpp
struct State_ {
    Base::Rv3 previous_a_v2a_fb_cmd_vel_m_per_s2;
};

struct Parameters_ {
    Gssc::Parameters position_to_velocity_horizontal_controller_pristine;
    Gssc::Parameters position_to_velocity_vertical_controller_pristine;
    Gssc::Parameters velocity_to_acceleration_horizontal_controller_pristine;
    Gssc::Parameters velocity_to_acceleration_vertical_controller_pristine;
    Gssc::Parameters acceleration_to_acceleration_controller_pristine;
    Gssc::Parameters acceleration_to_acceleration_low_pass_filter_pristine;
    // Additional parameters for degraded modes
};
```

### 3.2 TSC Tracking Modes

The TSC operates in different tracking modes depending on the flight phase:

1. **GROUNDSPEED** - Used during VTOL, transitions, and during speed changes in WBF
2. **AIRSPEED** - Used during normal WBF operation
3. **UNDEFINED** - Invalid state

```cpp
namespace Tsc_tracking_mode {
    enum Type {
        UNDEFINED = 0,
        GROUNDSPEED = 1,
        AIRSPEED = 2
    };
}
```

The TCG determines the appropriate tracking mode based on the current phase of flight, airspeed, and speed change status:

```cpp
bool Tcg::update_tsc_tracking_mode(Phase_of_flight pof, 
                                  Real eas_sched_m_per_s,
                                  Real eas_cmd_m_per_s,
                                  Speed_change_phase::Type speed_change_phase) {
    // Determine appropriate tracking mode based on inputs
    // Update state.tsc_tracking_mode
}
```

### 3.3 TSC Control Logic

The TSC implements a cascaded control structure:
1. Position error → Velocity command
2. Velocity error → Acceleration command
3. Acceleration filtering → Final acceleration command

```cpp
bool Tsc::step(const Input& input, Output& output) {
    // Transform inputs to velocity frame
    // Apply position-to-velocity control
    // Apply velocity-to-acceleration control
    // Apply acceleration-to-acceleration control
    // Filter acceleration commands
    // Transform outputs back to NED frame
}
```

## 4. Flight Phase Transitions

The TCG manages transitions between different flight phases, which is a critical aspect of its operation.

### 4.1 Outbound Transition (VTOL to WBF)

During outbound transition, the vehicle accelerates from hover to wing-borne flight:

```cpp
bool Ttcg::evaluate_outbound_transition_logic(const Input& input, Waypoint_msg& wp_ned_ned2pos) {
    // Update outbound maneuver time
    // Generate acceleration profile for transition
    // Update waypoint based on transition progress
}
```

The outbound transition uses a maneuver coordinate that defines a speed profile with three phases:
1. Initial acceleration phase
2. Constant acceleration phase
3. Final acceleration phase

### 4.2 Inbound Transition (WBF to VTOL)

During inbound transition, the vehicle decelerates from wing-borne flight to hover:

```cpp
bool Ttcg::evaluate_inbound_transition_logic(const Input& input, Waypoint_msg& wp_ned_ned2pos) {
    // Determine if high-speed or low-speed phase
    // Generate appropriate deceleration profile
    // Update waypoint based on transition progress
}
```

The inbound transition consists of two phases:
1. **High-speed phase** - Deceleration from cruise speed to critical speed
2. **Low-speed phase** - Deceleration from critical speed to hover

```cpp
bool Ttcg::evaluate_inbound_transition_highspeed_logic(Waypoint_msg& wp_ned_ned2pos) {
    // Generate high-speed deceleration profile
    // Update waypoint based on transition progress
}

bool Ttcg::evaluate_inbound_transition_lowspeed_logic(Waypoint_msg& wp_ned_ned2pos) {
    // Generate low-speed deceleration profile
    // Update waypoint based on transition progress
}
```

### 4.3 Transition Displacement Calculation

The TCG calculates the displacement required for transitions to ensure smooth deceleration:

```cpp
bool Ttcg::compute_inbound_transition_route_time_required(const Input& input,
                                                        Real& route_time_at_inbound_complete_s,
                                                        Maneuver_coordinate& mc_hs,
                                                        Maneuver_coordinate& mc_ls) {
    // Calculate displacement required for inbound transition
    // Generate maneuver coordinates for high-speed and low-speed phases
    // Determine route time at completion of transition
}
```

## 5. Testing Methodology

The TCG components are extensively tested using unit tests and integration tests.

### 5.1 Unit Tests

Unit tests verify the functionality of individual components:

```cpp
bool TrajectoryCommandGenerator_Unit_Test::test0_ControllersMode() {
    // Test TCG behavior with different controller modes
}

bool TrajectoryCommandGenerator_Unit_Test::test2_TscTrackingModeUndefined() {
    // Test TSC tracking mode determination with undefined inputs
}

bool TrajectoryCommandGenerator_Unit_Test::test3_TscTrackingModeVtol() {
    // Test TSC tracking mode determination during VTOL
}

bool TrajectoryCommandGenerator_Unit_Test::test4_TscTrackingModeOutbound() {
    // Test TSC tracking mode determination during outbound transition
}

bool TrajectoryCommandGenerator_Unit_Test::test5_TscTrackingModeInbound() {
    // Test TSC tracking mode determination during inbound transition
}

bool TrajectoryCommandGenerator_Unit_Test::test6_TscTrackingModeWbf() {
    // Test TSC tracking mode determination during WBF
}
```

### 5.2 TTCG Tests

Tests for the TTCG component verify route tracking, phase transitions, and trajectory generation:

```cpp
bool Ttcg_pa_test::test_10() // SampleValidVtolStraightManeuverRun
bool Ttcg_pa_test::test_11() // SampleValidVtolHoverManeuverRun
bool Ttcg_pa_test::test_14() // UpdatePhaseOfFlight
bool Ttcg_pa_test::test_19() // ClosestPointLookupRetrogradeMotion
bool Ttcg_pa_test::test_20() // ClosestPointLookupOrthogonalVariation
bool Ttcg_pa_test::test_21() // ClosestPointLookupEndOfManeuver
bool Ttcg_pa_test::test_22() // OutboundManeuverCoordinate
bool Ttcg_pa_test::test_34() // ComputeInboundTransitionRouteTimeRequired
bool Ttcg_pa_test::test_35() // EvaluateInboundTransitionDisplacementRequiredLowSpeed
bool Ttcg_pa_test::test_36() // EvaluateInboundTransitionHighspeedLogic
bool Ttcg_pa_test::test_37() // EvaluateInboundTransitionLowspeedLogic
bool Ttcg_pa_test::test_38() // EvaluateTransitionLogicInbound
```

### 5.3 Matlab Tests

The TCG is also validated against Matlab reference implementations:

```cpp
bool TrajectoryCommandGenerator_Unit_Test::matlab_test0_Example1aVtolConstWinds() {
    // Test TCG against Matlab reference for VTOL with constant winds
}

bool TrajectoryCommandGenerator_Unit_Test::matlab_test1_Example1gOtConstWinds() {
    // Test TCG against Matlab reference for outbound transition with constant winds
}

bool TrajectoryCommandGenerator_Unit_Test::matlab_test2_VtolHoverDiagonalAscentHover() {
    // Test TCG against Matlab reference for VTOL hover and diagonal ascent
}

bool TrajectoryCommandGenerator_Unit_Test::matlab_test3_ExampleStopAndHoverWbf() {
    // Test TCG against Matlab reference for stop and hover during WBF
}

bool TrajectoryCommandGenerator_Unit_Test::matlab_test4_ExampleStopAndHoverVtol() {
    // Test TCG against Matlab reference for stop and hover during VTOL
}
```

## 6. Spline Tracking and Route Handling

### 6.1 Spline Tracking

The TCG tracks splines by evaluating the route at the current time and generating appropriate commands:

```cpp
bool Ttcg::evaluate_trajectory_tracking_data(const Input& input,
                                           Waypoint_msg& wp_ned_ned2pos,
                                           Maverick::Rvector3& p_est_ned_ned2ncg_m,
                                           Heading_cmd& heading_vel_from_ned) {
    // Evaluate route at current time
    // Generate waypoint data
    // Calculate position error
}
```

### 6.2 Route Management

The TCG manages routes by storing them in the state and updating the tracked route based on commands:

```cpp
bool Ttcg::update_tracked_route_information(const Current_route_information& current_route_info,
                                          bool& is_new_route_tracking_initiated) {
    // Find route with matching ID
    // Update tracked route index
    // Reset tracking state for new route
}
```

### 6.3 Displacement Calculation

The TCG calculates displacement from the start of the route to track progress:

```cpp
Real Ttcg::compute_commanded_displacement_from_start_of_route() {
    // Calculate displacement from start of route to current position
}

void Ttcg::update_planned_displacement_from_start_of_route(const Waypoint_msg& wp_ned_ned2pos,
                                                         Real& gs_planned_m_per_s) {
    // Update planned displacement based on current waypoint
    // Calculate groundspeed for planning
}
```

## 7. Referenced Context Files

The following context files provided valuable information for understanding the trajectory command generation components:

1. **TrajectoryCommandGenerator_Unit_Test.cpp** - Contains unit tests for the TCG, including tests for controller modes, TSC tracking modes, and Matlab reference comparisons.

2. **Trajectory_polynomial_pa_test.cpp** - Tests for trajectory polynomials used in generating smooth transitions.

3. **Ttcg_pa_test.cpp** - Tests for the Time-based Trajectory Command Generator, including route tracking, phase transitions, and closest point search.

4. **Track_spline_state_pa_test.cpp** - Tests for the spline tracking state management.

5. **Tcg_test.cpp** - Integration tests for the TCG component.

6. **Tsc_pa_test.cpp** - Tests for the Translational Stability Controller, including control logic and tracking modes.

These files helped establish a comprehensive understanding of how the trajectory command generation components work together to produce smooth, stable flight trajectories across different flight phases.