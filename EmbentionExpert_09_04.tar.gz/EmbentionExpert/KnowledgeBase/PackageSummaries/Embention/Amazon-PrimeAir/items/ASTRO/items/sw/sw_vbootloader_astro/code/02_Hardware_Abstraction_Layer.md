# Generated from:

- sw_vbootloader_astro/code/source_astro/Halsuite_2838x_astro.cpp (3842 tokens)
- sw_vbootloader_astro/code/source_astro/Sysuid_cpu1_amz.cpp (1438 tokens)
- sw_vbootloader_astro/code/source_astro/FormatSD_amz.cpp (304 tokens)

## With context from:

- Amazon-PrimeAir/items/ASTRO/items/sw/sw_vbootloader_astro/code/03_Bootloader_Core.md (4045 tokens)

---

# Hardware Abstraction Layer for Astro Platform: High-Fidelity Semantic Knowledge Graph

## 1. Halsuite Implementation for Astro Platform

The Astro platform's hardware abstraction layer (HAL) is implemented through the `Halsuite` class in the TMS320F2838x microcontroller environment. This class provides a comprehensive interface to the platform's peripherals and hardware resources.

### 1.1 Core HAL Functionality

The `Halsuite` class provides a step function that manages the periodic processing of communication peripherals:

```cpp
void Halsuite::step_hi()
{
    // Process all SCI ports
    scia_port.step();
    scib_port.step();
    scic_port.step();
    scid_port.step();

    // Check for CAN transmission timeouts
    cana.check_tx_tout();
    canb.check_tx_tout();
    can_fd.check_tx_tout();
}
```

This function is responsible for:
- Calling the `step()` method for each SCI (Serial Communication Interface) port (A, B, C, and D)
- Checking for transmission timeouts on all CAN interfaces (CAN A, CAN B, and CAN FD)

### 1.2 GPIO Configuration System

The `Halsuite` class implements a sophisticated GPIO configuration system through the `get_cfg()` method, which returns pin configurations based on functionality and device identity:

```cpp
Halsuite::GPIOcfg Halsuite::get_cfg(GPIOfunc f, Bsp::Uid64 uid)
```

#### 1.2.1 GPIO Configuration Structure

The method returns a `GPIOcfg` structure containing:
- GPIO pin ID
- Pin configuration (direction, pull-up/down, multiplexer setting, qualification)
- Core assignment (which processor core controls the pin)

#### 1.2.2 Standard GPIO Configurations

The method defines several standard GPIO configurations:

```cpp
static const GPIOtun cfg_gpio_out = GPIOtun::build(GPIOtun::dir_output, GPIOtun::pu_dis, GPIOtun::Mux(0), GPIOtun::qsel_sync);
static const GPIOtun cfg_sci_tx   = GPIOtun::build(GPIOtun::dir_output, GPIOtun::pu_dis, GPIOtun::Mux(6), GPIOtun::qsel_sync);
static const GPIOtun cfg_sci_rx   = GPIOtun::build(GPIOtun::dir_input,  GPIOtun::pu_dis, GPIOtun::Mux(6), GPIOtun::qsel_async);
static const GPIOtun cfg_can_tx   = GPIOtun::build(GPIOtun::dir_output, GPIOtun::pu_en,  GPIOtun::Mux(3), GPIOtun::qsel_sync);
static const GPIOtun cfg_can_rx   = GPIOtun::build(GPIOtun::dir_input,  GPIOtun::pu_en,  GPIOtun::Mux(3), GPIOtun::qsel_async);
```

These configurations define:
- Standard GPIO output: Output direction, pull-up disabled, mux 0, synchronous qualification
- SCI TX: Output direction, pull-up disabled, mux 6, synchronous qualification
- SCI RX: Input direction, pull-up disabled, mux 6, asynchronous qualification
- CAN TX: Output direction, pull-up enabled, mux 3, synchronous qualification
- CAN RX: Input direction, pull-up enabled, mux 3, asynchronous qualification

### 1.3 GPIO Pin Assignments by Functionality

The `get_cfg()` method maps specific functionalities to GPIO pins based on the application type and hardware version:

#### 1.3.1 LED Indicators

**Red LED (f_led_red):**
- For `sapp_mc110_v2`: GPIO 71
- For `sapp_par_nav`, `sapp_pam`, `sapp_par_ctrl`, `sapp_uapp` (Veronte/Astro): GPIO 128
- For `sapp_386_ccard`: GPIO 31 on CM core

**Green LED (f_led_green):**
- For `sapp_mc110_v2`: GPIO 70
- For `sapp_pam`, `sapp_par_nav`, `sapp_par_ctrl`: GPIO 130
- For `sapp_uapp` with hardware version < 4.10: GPIO 116
- For `sapp_uapp` with hardware version >= 4.10: GPIO 129
- For `sapp_386_ccard`: GPIO 34

**Blue LED (f_led_blue):**
- For `sapp_pam`, `sapp_par_nav`, `sapp_par_ctrl`: GPIO 129 on CM core

#### 1.3.2 SCI (Serial Communication Interface) Ports

**SCI-A:**
- TX: GPIO 140 for `sapp_mc110_v2`, GPIO 29 for others
- RX: GPIO 139 for `sapp_mc110_v2`, GPIO 28 for others (with mux 1)

**SCI-B:**
- TX: GPIO 142 for `sapp_mc110_v2`, GPIO 54 for others
- RX: GPIO 141 for `sapp_mc110_v2`, GPIO 55 for others

**SCI-C:**
- TX: GPIO 153 for `sapp_mc110_v2`, GPIO 140 for others
- RX: GPIO 152 for `sapp_mc110_v2`, GPIO 13 for others

**SCI-D:**
- TX: GPIO 142 for all applications
- RX: GPIO 141 for `sapp_par_nav`, `sapp_pam`, `sapp_par_ctrl`, `sapp_uapp`; GPIO 94 for others

#### 1.3.3 CAN (Controller Area Network) Interfaces

**CAN-A:**
- TX: GPIO 37 for `sapp_mc110_v2`, GPIO 4 (mux 6) for others
- RX: GPIO 36 (mux 6) for all applications

**CAN-B:**
- TX: GPIO 38 for `sapp_mc110_v2`, GPIO 20 for others
- RX: GPIO 39 for `sapp_mc110_v2`, GPIO 17 (mux 2) for others

**CAN-FD:**
- TX: GPIO 19 (mux 9)
- RX: GPIO 18 (mux 9)

### 1.4 Ethernet Configuration

The `get_eth_cfg()` method provides the Ethernet MII (Media Independent Interface) pin configuration:

```cpp
const Dsp28335_ent::CM_helpers::Pinout_mii& Halsuite::get_eth_cfg()
{
    static const CM_helpers::Pinout_mii cm_gpios = {
        { gpio_043, GPIOmux16::mux_11 },  // UARTCM_RX (RS232 CM)
        { gpio_042, GPIOmux16::mux_11 },  // UARTCM_TX (RS232 CM)
        {
            { gpio_105, GPIOmux16::mux_14 },  // ENET_MDIO_CLK
            { gpio_106, GPIOmux16::mux_14 },  // ENET_MDIO_DATA
            { gpio_109, GPIOmux16::mux_14 },  // ENET_MII_CRS
            { gpio_110, GPIOmux16::mux_14 },  // ENET_MII_COL
            { gpio_121, GPIOmux16::mux_14 },  // ENET_MII_TX_DATA0
            { gpio_060, GPIOmux16::mux_11 },  // ENET_MII_TX_DATA1
            { gpio_061, GPIOmux16::mux_11 },  // ENET_MII_TX_DATA2
            { gpio_062, GPIOmux16::mux_11 },  // ENET_MII_TX_DATA3
            { gpio_118, GPIOmux16::mux_14 },  // ENET_MII_TX_EN
            { gpio_114, GPIOmux16::mux_14 },  // ENET_MII_RX_DATA0
            { gpio_115, GPIOmux16::mux_14 },  // ENET_MII_RX_DATA1
            { gpio_116, GPIOmux16::mux_14 },  // ENET_MII_RX_DATA2
            { gpio_117, GPIOmux16::mux_14 },  // ENET_MII_RX_DATA3
            { gpio_all, GPIOmux16::mux_0  },  // ENET_MII_RX_ERR NOT USED IN PA
            { gpio_112, GPIOmux16::mux_14 },  // ENET_MII_RX_DV
            { gpio_120, GPIOmux16::mux_14 },  // ENET_MII_TX_CLK
            { gpio_111, GPIOmux16::mux_14 },  // ENET_MII_RX_CLK
            { gpio_all, GPIOmux16::mux_0 },   // ENET power down (not used)
            { gpio_all, GPIOmux16::mux_0 }    // ENET reset (not used)
        }
    };
    return cm_gpios;
}
```

This configuration defines:
- UART pins for the CM core (RS232 communication)
- Complete MII interface pins for Ethernet communication
- All necessary data, control, and clock signals for the Ethernet interface

## 2. System Identity Determination (Sysuid)

The Astro platform implements a system for determining device identity based on hardware configuration pins. This is implemented in the `Sysuid_cpu1_amz.cpp` file.

### 2.1 GPIO Configuration Pins

The system defines several GPIO pins used to determine hardware configuration:

```cpp
static const Dsp28335_ent::GPIOid gpio_config_b0      = Dsp28335_ent::gpio_008;
static const Dsp28335_ent::GPIOid gpio_config_b0_ev2  = Dsp28335_ent::gpio_022;
static const Dsp28335_ent::GPIOid gpio_config_b1      = Dsp28335_ent::gpio_126;

// HW revision pins
static const Dsp28335_ent::GPIOid gpio_hw_id0        = Dsp28335_ent::gpio_009;
static const Dsp28335_ent::GPIOid gpio_hw_id1        = Dsp28335_ent::gpio_010;
static const Dsp28335_ent::GPIOid gpio_hw_id2        = Dsp28335_ent::gpio_011;
static const Dsp28335_ent::GPIOid gpio_hw_id3        = Dsp28335_ent::gpio_012;
```

### 2.2 System Identity Determination Process

The `get_uid_aux()` function determines the system identity based on hardware configuration pins:

```cpp
Uid64 get_uid_aux()
{
    // Delay to ensure stable GPIO readings
    Dsp28335_ent::Delay::ms(150);

    // Configure hardware revision pins as inputs with pull-up
    const Dsp28335_ent::GPIOtun cfg = {
        Dsp28335_ent::GPIOtun::dir_input, 
        Dsp28335_ent::GPIOtun::pu_en,
        Dsp28335_ent::GPIOmux16::mux_gpio, 
        Dsp28335_ent::GPIOtun::qsel_async
    };
    
    Dsp28335_ent::GPIOioctl::apply(Ver::GPIOname::gpio_hw_id0, cfg);
    Dsp28335_ent::GPIOioctl::apply(Ver::GPIOname::gpio_hw_id1, cfg);
    Dsp28335_ent::GPIOioctl::apply(Ver::GPIOname::gpio_hw_id2, cfg);
    Dsp28335_ent::GPIOioctl::apply(Ver::GPIOname::gpio_hw_id3, cfg);

    Dsp28335_ent::Delay::ms(10);

    // Read hardware revision ID
    Uint8 rev_id = 0;
    rev_id  = Dsp28335_ent::GPIO(Ver::GPIOname::gpio_hw_id0).get();
    rev_id = (rev_id | (Dsp28335_ent::GPIO(Ver::GPIOname::gpio_hw_id1).get() << Ku32::u1));
    rev_id = (rev_id | (Dsp28335_ent::GPIO(Ver::GPIOname::gpio_hw_id2).get() << Ku32::u2));
    rev_id = (rev_id | (Dsp28335_ent::GPIO(Ver::GPIOname::gpio_hw_id3).get() << Ku32::u3));

    // Define hardware revision values
    enum Revisions {
        ev1 = 0x01,
        ev1_res = 0x02,
        ev2 = 0x05,
        dv1 = 0x11
    };

    // Select configuration pin based on hardware revision
    Dsp28335_ent::GPIOid gpio_config_b0 = (rev_id <= ev2) ? 
        Ver::GPIOname::gpio_config_b0 : Ver::GPIOname::gpio_config_b0_ev2;
    
    // Configure configuration pins as inputs
    Dsp28335_ent::GPIOioctl::apply_input(gpio_config_b0);
    Dsp28335_ent::GPIOioctl::apply_input(Ver::GPIOname::gpio_config_b1);

    Dsp28335_ent::Delay::ms(10);

    // Read configuration bits
    Uint8 compute_config = 0;
    compute_config = Dsp28335_ent::GPIO(gpio_config_b0).get();
    compute_config = (compute_config | (Dsp28335_ent::GPIO(Ver::GPIOname::gpio_config_b1).get() << Ku32::u1));

    // Initialize UID with default values
    Uid64 otp_uid = { 0 };
    otp_uid.app = Bsp::sapp_par_nav;  // Default application type
    otp_uid.phy = 12345;              // Default physical ID
    otp_uid.hwv = 5;                  // Default hardware version
    otp_uid.res = rev_id;             // Store hardware revision in reserved field

    // Define Cyphal node IDs
    static const Uint32 mon_node_id      = 22UL;  // Monitor node ID
    static const Uint32 rec_nav_node_id  = 28UL;  // Recovery with navigation node ID
    static const Uint32 rec_ctrl_node_id = 31UL;  // Recovery with control node ID

    // Determine application type and node ID based on hardware revision and configuration
    if(rev_id <= ev1_res) {
        // For older hardware revisions (EV1 and EV1_RES)
        enum Variants {
            mon  = 1,   // Monitor with Recovery-Control
            recv0 = 2,  // Recovery (sensors and nav)
        };
        
        switch (compute_config) {
            case mon:
                otp_uid.phy = mon_node_id;
                otp_uid.app = Bsp::sapp_pam;
                break;
            case recv0:
                otp_uid.phy = rec_nav_node_id;
                otp_uid.app = Bsp::sapp_par_nav;
                break;
            default:
                Bsp::warning();
        }
    } else {
        // For newer hardware revisions (EV2 and later)
        enum Variants {
            mon  = 1,   // Monitor
            recv1 = 2,  // Recovery (controllers)
            recv0 = 3   // Recovery (sensors and nav)
        };
        
        switch (compute_config) {
            case mon:
                otp_uid.phy = mon_node_id;
                otp_uid.app = Bsp::sapp_pam;
                break;
            case recv0:
                otp_uid.phy = rec_nav_node_id;
                otp_uid.app = Bsp::sapp_par_nav;
                break;
            case recv1:
                otp_uid.phy = rec_ctrl_node_id;
                otp_uid.app = Bsp::sapp_par_ctrl;
                break;
            default:
                Bsp::warning();
                break;
        }
    }
    
    return otp_uid;
}
```

### 2.3 System Identity Caching

The `get_uid()` function provides a cached version of the system identity, with an option to force a fresh read:

```cpp
Uid64 get_uid(bool force_read)
{
    static Uid64 otp_uid = get_uid_aux();
    if(force_read) {
        otp_uid = get_uid_aux();
    }
    return otp_uid;
}
```

### 2.4 Application Types and Node IDs

The system supports several application types, each with a specific node ID:

1. **Monitor (sapp_pam)**: Node ID 22
   - For hardware with configuration bit pattern 1

2. **Recovery with Navigation (sapp_par_nav)**: Node ID 28
   - For older hardware (rev_id <= ev1_res) with configuration bit pattern 2
   - For newer hardware with configuration bit pattern 3

3. **Recovery with Control (sapp_par_ctrl)**: Node ID 31
   - Only for newer hardware (rev_id > ev1_res) with configuration bit pattern 2

### 2.5 Hardware Revision Detection

The system detects hardware revision using four GPIO pins (gpio_hw_id0 through gpio_hw_id3), which form a 4-bit value:

- EV1: 0x01
- EV1_RES: 0x02
- EV2: 0x05
- DV1: 0x11

The hardware revision affects:
- Which GPIO pin is used for configuration bit 0 (gpio_config_b0 or gpio_config_b0_ev2)
- The mapping between configuration bits and application types

## 3. File System Configuration

The Astro platform implements a file system configuration for SD card formatting, defined in `FormatSD_amz.cpp`.

### 3.1 Partition Configuration

The `get_filesystem_description()` method defines the file system partition layout:

```cpp
void DFS2::DFS2_fs::get_filesystem_description(const DFS2_fs& fsd, DFS2_fs::Format_part& parts)
{
    static const Uint32 sectors_for_fd = Ku32::u8;  // 8 sectors for file descriptor

    // Define PDIF partition: 2,000 files of 120 sectors each (~117 MB)
    static const DFS2::Partition pdif_partition(
        static_cast<Uint32>(2000),           // Number of files
        static_cast<Uint32>(120),            // Sectors per file
        Partition::dt_pdif_part,             // Partition type
        true,                                // Circular buffer
        sectors_for_fd                       // Sectors for file descriptor
    );

    static const Uint16 num_partition_flash = 1;  // Number of partitions in flash

    // Create partition configuration
    const DFS2_fs::Format_part ver_parts = {
        num_partition_flash,
        {
            pdif_partition,  // Ver::pdif_part
        }
    };
    
    parts = ver_parts;

    // Set initial sectors value
    parts.set_initial_sectors(sectors_for_fd);
}
```

### 3.2 File System Structure

The file system is configured with:
- A single partition of type `dt_pdif_part`
- 2,000 files with 120 sectors per file (~117 MB total)
- 8 sectors reserved for file descriptors
- Circular buffer behavior enabled

## 4. Integration with Bootloader Core

The HAL components integrate with the bootloader core in several ways:

### 4.1 Hardware Abstraction for Peripherals

The `Halsuite` class provides hardware abstraction for peripherals used by the bootloader:
- SCI ports for serial communication
- CAN interfaces for network communication
- GPIO pins for LEDs and other functions

### 4.2 System Identity for Configuration

The system identity determination (`get_uid()`) provides critical information to the bootloader:
- Application type (`app` field)
- Node ID (`phy` field)
- Hardware version (`hwv` field)

This information is used in the bootloader to:
- Configure network parameters
- Adjust communication ports
- Select appropriate GPIO pins

### 4.3 File System for Storage

The file system configuration provides storage capabilities to the bootloader:
- Defines partition layout for the flash memory
- Configures file storage parameters
- Enables circular buffer behavior for logging

### 4.4 Ethernet Configuration

The Ethernet configuration (`get_eth_cfg()`) provides the pin mapping needed by the bootloader to initialize the Ethernet interface on the CM core.

## 5. GPIO Pin Assignment Tables

### 5.1 LED Indicators

| Function | Application Type | Hardware Version | GPIO Pin | Core | Direction | Pull-up | Mux | Qualification |
|----------|------------------|------------------|----------|------|-----------|---------|-----|--------------|
| Red LED | sapp_mc110_v2 | Any | 71 | C1 | Output | Disabled | 0 | Sync |
| Red LED | sapp_par_nav, sapp_pam, sapp_par_ctrl, sapp_uapp | Any | 128 | C1 | Output | Disabled | 0 | Sync |
| Red LED | sapp_386_ccard | Any | 31 | CM | Output | Disabled | 0 | Sync |
| Green LED | sapp_mc110_v2 | Any | 70 | C1 | Output | Disabled | 0 | Sync |
| Green LED | sapp_pam, sapp_par_nav, sapp_par_ctrl | Any | 130 | C1 | Output | Disabled | 0 | Sync |
| Green LED | sapp_uapp | < 4.10 | 116 | C1 | Output | Disabled | 0 | Sync |
| Green LED | sapp_uapp | >= 4.10 | 129 | C1 | Output | Disabled | 0 | Sync |
| Green LED | sapp_386_ccard | Any | 34 | C1 | Output | Disabled | 0 | Sync |
| Blue LED | sapp_pam, sapp_par_nav, sapp_par_ctrl | Any | 129 | CM | Output | Disabled | 0 | Sync |

### 5.2 SCI (Serial Communication Interface) Ports

| Function | Application Type | GPIO Pin | Direction | Pull-up | Mux | Qualification |
|----------|------------------|----------|-----------|---------|-----|--------------|
| SCI-A TX | sapp_mc110_v2 | 140 | Output | Disabled | 6 | Sync |
| SCI-A TX | Others | 29 | Output | Disabled | 6 | Sync |
| SCI-A RX | sapp_mc110_v2 | 139 | Input | Disabled | 6 | Async |
| SCI-A RX | Others | 28 | Input | Disabled | 1 | Async |
| SCI-B TX | sapp_mc110_v2 | 142 | Output | Disabled | 6 | Sync |
| SCI-B TX | Others | 54 | Output | Disabled | 6 | Sync |
| SCI-B RX | sapp_mc110_v2 | 141 | Input | Disabled | 6 | Async |
| SCI-B RX | Others | 55 | Input | Disabled | 6 | Async |
| SCI-C TX | sapp_mc110_v2 | 153 | Output | Disabled | 6 | Sync |
| SCI-C TX | Others | 140 | Output | Disabled | 6 | Sync |
| SCI-C RX | sapp_mc110_v2 | 152 | Input | Disabled | 6 | Async |
| SCI-C RX | Others | 13 | Input | Disabled | 6 | Async |
| SCI-D TX | All | 142 | Output | Disabled | 6 | Sync |
| SCI-D RX | sapp_par_nav, sapp_pam, sapp_par_ctrl, sapp_uapp | 141 | Input | Disabled | 6 | Async |
| SCI-D RX | Others | 94 | Input | Disabled | 6 | Async |

### 5.3 CAN (Controller Area Network) Interfaces

| Function | Application Type | GPIO Pin | Direction | Pull-up | Mux | Qualification |
|----------|------------------|----------|-----------|---------|-----|--------------|
| CAN-A TX | sapp_mc110_v2 | 37 | Output | Enabled | 3 | Sync |
| CAN-A TX | Others | 4 | Output | Enabled | 6 | Sync |
| CAN-A RX | All | 36 | Input | Enabled | 6 | Async |
| CAN-B TX | sapp_mc110_v2 | 38 | Output | Enabled | 3 | Sync |
| CAN-B TX | Others | 20 | Output | Enabled | 3 | Sync |
| CAN-B RX | sapp_mc110_v2 | 39 | Input | Enabled | 3 | Async |
| CAN-B RX | Others | 17 | Input | Enabled | 2 | Async |
| CAN-FD TX | All | 19 | Output | Enabled | 9 | Sync |
| CAN-FD RX | All | 18 | Input | Enabled | 9 | Async |

### 5.4 System Identity Configuration Pins

| Function | Hardware Revision | GPIO Pin |
|----------|------------------|----------|
| Config Bit 0 | <= EV2 (0x05) | 8 |
| Config Bit 0 | > EV2 (0x05) | 22 |
| Config Bit 1 | All | 126 |
| HW ID Bit 0 | All | 9 |
| HW ID Bit 1 | All | 10 |
| HW ID Bit 2 | All | 11 |
| HW ID Bit 3 | All | 12 |

### 5.5 Application Type Mapping

| Hardware Revision | Config Bits | Application Type | Node ID |
|------------------|-------------|------------------|---------|
| <= EV1_RES (0x02) | 01 | sapp_pam (Monitor) | 22 |
| <= EV1_RES (0x02) | 10 | sapp_par_nav (Recovery with Navigation) | 28 |
| > EV1_RES (0x02) | 01 | sapp_pam (Monitor) | 22 |
| > EV1_RES (0x02) | 10 | sapp_par_ctrl (Recovery with Control) | 31 |
| > EV1_RES (0x02) | 11 | sapp_par_nav (Recovery with Navigation) | 28 |

## Referenced Context Files

- **03_Bootloader_Core.md**: Provided context on how the HAL components integrate with the bootloader core, including how the system identity is used to configure network parameters and how the Ethernet configuration is used to initialize the CM core.