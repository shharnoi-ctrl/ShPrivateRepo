# Generated from:

- Amazon-PrimeAir/items/ASTRO/items/sw/sw_vbootloader_astro/code/03_Bootloader_Core.md (4045 tokens)
- Amazon-PrimeAir/items/ASTRO/items/sw/sw_vbootloader_astro/code/02_Memory_Layout_Configuration.md (3308 tokens)
- Amazon-PrimeAir/items/ASTRO/items/sw/sw_vbootloader_astro/code/02_Hardware_Abstraction_Layer.md (5008 tokens)
- Amazon-PrimeAir/items/ASTRO/items/sw/sw_vbootloader_astro/code/02_Build_System_Configuration.md (2587 tokens)
- Amazon-PrimeAir/items/ASTRO/items/sw/sw_vbootloader_astro/code/02_Testing_Framework.md (3711 tokens)
- Amazon-PrimeAir/items/ASTRO/items/sw/sw_vbootloader_astro/code/01_System_Architecture.md (3659 tokens)

---

# Astro Bootloader System: Knowledge Graph Overview

## System Architecture Overview

The Astro bootloader is a sophisticated dual-core bootloader system designed for the TI TMS320F2838x microcontroller, which features a C28x DSP (CPU1) and an ARM Cortex-M (CM) core. The system provides a secure, reliable mechanism for initializing the hardware, verifying and loading application firmware, and supporting firmware updates across both processor cores.

### Core Architecture Components

1. **Dual-Core Bootloader Implementation**
   - CPU1 (C28x DSP) bootloader: Primary bootloader that initializes the system
   - CM (ARM Cortex-M) bootloader: Secondary bootloader that handles communication tasks

2. **Memory Management System**
   - Separate memory spaces for each core with defined boundaries
   - Shared memory regions for inter-processor communication
   - Flash memory partitioning for bootloader and application code

3. **Hardware Abstraction Layer (HAL)**
   - Peripheral interface abstraction
   - GPIO configuration system
   - System identity determination

4. **Security Framework**
   - Secure boot implementation with ECDSA signature verification
   - Device Control Security Module (DCSM) integration
   - Secure CAN communication

5. **Communication Interfaces**
   - SPI for flash memory access
   - CAN for bootloader commands and firmware updates
   - Ethernet (on CM core) for network communication
   - Inter-processor communication mechanisms

6. **File System Support**
   - DFS2 file system for flash storage
   - Partition management for firmware storage

## Boot Sequence and Initialization

The boot sequence follows these steps:

1. **CPU1 Bootloader Initialization**
   - CPU1 bootloader starts execution from flash address 0x80000 (word addressing)
   - Verifies bootloader header integrity
   - Initializes hardware peripherals (GPIO, SPI, CAN)
   - Configures memory layout and shared memory regions

2. **System Identity Determination**
   - Reads hardware configuration pins to determine:
     - Application type (Monitor, Recovery with Navigation, Recovery with Control)
     - Hardware version
     - Node ID for network communication

3. **CM Core Initialization**
   - CPU1 initializes shared memory with configuration data (UID, IP address, MAC address)
   - CPU1 boots the CM core with a bootloader command
   - CM bootloader starts execution from flash address 0x200000 (byte addressing)
   - CM reads configuration from shared memory
   - CM initializes Ethernet interface

4. **Application Verification and Loading**
   - Both bootloaders check for valid application images in their respective memory regions
   - Verify signatures and integrity of application images
   - If valid, load and execute applications; otherwise, remain in bootloader mode

## Memory Architecture

### Memory Layout

The memory architecture accommodates both cores with their different addressing schemes:

#### CPU1 (C28x) Memory Map (16-bit word addressing)
- **Flash Memory**: 0x080000-0x0C0000
  - Bootloader: 0x080000-0x090000 (0x10000 words)
  - Application: 0x090000-0x0C0000 (0x30000 words)
- **RAM Regions**:
  - RAMM_DAT: 0x000140-0x000800
  - RAML: 0x008000-0x00D000
  - RAMS: 0x00D000-0x01D000
  - RAMFUNCS: 0x01D000-0x01D7C0 (functions running from RAM)
- **IPC Memory**:
  - CMTOCPURAM: 0x038000-0x038800
  - CPUTOCMRAM: 0x039000-0x039800

#### CM (Cortex-M) Memory Map (8-bit byte addressing)
- **Flash Memory**: 0x200000-0x280000
  - Bootloader: 0x200000-0x220000 (0x20000 bytes)
  - Application: 0x220000-0x250000 (0x30000 bytes)
- **RAM Regions**:
  - C1RAM: 0x1FFFC000-0x1FFFE000 (8KB)
  - C0RAM: 0x1FFFE000-0x20000000 (8KB)
  - ESRAM: 0x20000100-0x20014000
- **IPC Memory**:
  - CPU1TOCMMSGRAM: 0x20080000-0x20081000
  - CMTOCPU1MSGRAM: 0x20082000-0x20083000

## Hardware Abstraction Layer

The HAL provides a clean interface to hardware peripherals:

1. **SCI (Serial Communication Interface)**
   - Four SCI ports (A, B, C, D) with configurable pins
   - Periodic processing through the `step_hi()` method

2. **CAN (Controller Area Network)**
   - Three CAN interfaces: CAN-A, CAN-B, and CAN-FD
   - Transmission timeout checking
   - Secure CAN configuration with transceiver control

3. **SPI (Serial Peripheral Interface)**
   - SPI-C interface for flash memory communication
   - Configurable speed, data width, and mode

4. **GPIO (General Purpose Input/Output)**
   - Comprehensive GPIO configuration system
   - Pin multiplexing for various functions
   - Core assignment for GPIO control

## Security Framework

The bootloader implements secure boot mechanisms:

1. **ECDSA Signature Verification**
   - Verification of application signatures before loading
   - Rejection of applications with invalid signatures

2. **Device Control Security Module (DCSM)**
   - Security zone configuration
   - Security key management
   - JTAG access control

3. **Binary Integrity Verification**
   - CRC32 checksum verification
   - Header schema validation
   - Core binary verification

## File System and Storage

The bootloader includes flash memory management:

1. **SPI Flash Interface**
   - SPI-C communication with flash memory
   - Chip select control via GPIO

2. **MX66L Flash Driver**
   - Driver for MX66L flash memory
   - Read, write, and erase operations

3. **DFS2 File System**
   - Single PDIF partition with 2,000 files
   - 120 sectors per file (~117 MB total)
   - 8 sectors for file descriptors
   - Circular buffer enabled for continuous logging

## Communication Interfaces

The bootloader implements multiple communication interfaces:

1. **CAN Communication**
   - Three CAN interfaces with different roles
   - 500 Kbps standard baudrate
   - 2 Mbps data baudrate for CAN-FD
   - ID-based filtering for incoming messages

2. **Ethernet Communication (CM Core)**
   - Lightweight IP stack for network communication
   - UDP protocol support for bootloader commands
   - MAC address derived from device UID

3. **Inter-Processor Communication**
   - Dedicated shared memory regions for bi-directional communication
   - Command interface for core control
   - Configuration data sharing

## Build and Testing System

The bootloader uses a sophisticated build and testing system:

1. **Build System**
   - JSON-based hierarchical configuration
   - Separate builds for C28x and ARM cores
   - Core-specific libraries for each processor

2. **Testing Framework**
   - 21 test cases covering various aspects of bootloader functionality
   - Binary manipulation tools for testing integrity checks
   - Version management with semantic versioning support
   - Interface to the embedded software updater

## Key Design Patterns

The bootloader employs several key design patterns:

1. **Class Hierarchy and Inheritance**
   - `Bootloader` base class with common functionality
   - `Bootloader_dual` for dual-core management
   - `Bootloader_astro` for Astro-specific implementation
   - Factory method pattern for instance creation

2. **Hardware Abstraction and Dependency Injection**
   - Interface-based design for hardware abstraction
   - Constructor-based dependency injection

3. **Memory Management Strategy**
   - Different addressing schemes for different cores
   - RAM function execution for performance-critical operations

4. **Security-First Design**
   - Multiple security layers (DCSM, signatures, CRC)
   - Fail-secure approach with rejection of invalid applications

## Detailed Information Links

For more detailed information on specific aspects of the system, refer to the following documents:

1. [Bootloader Core Implementation](03_Bootloader_Core.md) - Details on the core bootloader classes and functionality
2. [Memory Layout Configuration](02_Memory_Layout_Configuration.md) - In-depth analysis of memory organization
3. [Hardware Abstraction Layer](02_Hardware_Abstraction_Layer.md) - Details on peripheral interfaces and system identity
4. [Build System Configuration](02_Build_System_Configuration.md) - Information on the build system architecture
5. [Testing Framework](02_Testing_Framework.md) - Comprehensive overview of the testing methodology

## System Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│                      Astro Bootloader System                     │
└───────────────────────────────┬─────────────────────────────────┘
                                │
    ┌───────────────────────────┼───────────────────────────┐
    │                           │                           │
┌───▼───────────────┐    ┌─────▼─────────────┐    ┌────────▼────────┐
│  CPU1 Bootloader  │    │  CM Bootloader    │    │  Security       │
│  (C28x DSP Core)  │◄──►│  (ARM Cortex-M)   │    │  Framework      │
└───────┬───────────┘    └─────────┬─────────┘    └────────┬────────┘
        │                          │                       │
┌───────▼───────────┐    ┌─────────▼─────────┐    ┌───────▼────────┐
│ Hardware          │    │ Communication     │    │ File System    │
│ Abstraction Layer │    │ Interfaces        │    │ & Storage      │
└───────────────────┘    └───────────────────┘    └────────────────┘
```

This architecture provides a solid foundation for the Astro platform, ensuring reliable operation and secure updates throughout the system's lifecycle.