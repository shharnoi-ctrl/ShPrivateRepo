# Generated from:

- data/Protobuf/json/63db8373-44d6-4135-9591-fde5d967baca.pb.json (1557 tokens)
- data/Protobuf/json/bc06bf3e-c10a-473a-9b19-96731efdfed7.pb.json (2094 tokens)
- data/Protobuf/json/mon_rec_a_b_a_cage_v4_recovery.pb.json (768 tokens)
- data/Protobuf/json/1e773572-4295-4b6b-8b19-2ced83758b1f.pb.json (4927 tokens)
- data/Protobuf/json/bc06bf3e-c10a-473a-9b19-96731efdfed7_v4_recovery.pb.json (1481 tokens)
- data/Protobuf/json/id_20_2_1_recovery_channel_switchover_cage_flight_v4_recovery.pb.json (1143 tokens)
- data/Protobuf/json/0dbe532e-3783-4b3d-8ced-e687dc2d224a.pb.json (4231 tokens)
- data/Protobuf/json/719be9d4-d77a-4548-be7f-3c9c7db7845e.pb.json (2383 tokens)
- data/Protobuf/json/ef2b83f1-f174-4d9a-b46a-ed4f9d9be2c3.pb.json (1845 tokens)
- data/Protobuf/json/cx3-l2_verification-mission-h.pb.json (3703 tokens)
- data/Protobuf/json/2edf2686-c88e-4505-9fb8-0329573b0d33.pb.json (4541 tokens)
- data/Protobuf/json/21eaa1c4-0183-4bf4-adbe-bcaaa8a7c450.pb.json (5281 tokens)
- data/Protobuf/json/e379a463-ba0d-484a-841e-1ffc9ab1affa.pb.json (53707 tokens)
- data/Protobuf/json/hybrid_a_b_a_delivery_gps_land_with_return_home_no_divert_pad_v4_recovery.pb.json (2067 tokens)
- data/Protobuf/json/9fe93450-eb7d-4297-8495-fa68c2f74546.pb.json (10748 tokens)

---

# Comprehensive Summary of Drone Mission Planning System

This document provides a detailed analysis of the drone flight planning system based on the protobuf flight plan files. The system defines structured flight plans that guide autonomous drone operations through various mission phases including takeoff, transit, delivery, and landing.

## 1. Flight Plan Structure and Version Evolution

### 1.1 Protocol Version Evolution

The system has evolved from protocol version 3.0 to 4.0, with both versions currently in use:

- **Version 3.0**: Includes detailed vehicle parameters within the flight plan itself
- **Version 4.0**: Moves vehicle parameters out of the flight plan, focusing on mission definition

Key differences between versions:
- Version 4.0 introduces the `takeoff_bounding_volume` field at the top level
- Version 3.0 includes extensive vehicle parameters (speeds, accelerations, angles)
- Version 4.0 has a cleaner structure focused on mission definition

### 1.2 Core Flight Plan Components

Each flight plan contains:

```
flight_id: Unique identifier for the flight
version: Protocol version information and diagnostics
reference_time: Base time for mission timing (often 0 or epoch timestamp)
crs: Coordinate reference system definition
initial_plan: Primary sequence of mission steps
alternate_plans: Contingency plans (e.g., return home)
wind_vectors: Wind information for each mission step
timing_windows: Time constraints for mission steps
```

### 1.3 Coordinate Reference System

All flight plans use an equirectangular projection based on WGS84:

```json
"crs": {
  "equirectangular_projection": {
    "geographic_coordinate_system": {
      "name": "WGS84",
      "datum": {
        "name": "WGS 84",
        "spheroid": {
          "semi_major_axis_m": 6378137.0,
          "inverse_flattening": 298.257223563
        }
      },
      "prime_meridian_rad": 0.0
    },
    "projection_latitude_rad": [reference latitude],
    "projection_longitude_rad": [reference longitude],
    "false_easting_m": 0.0,
    "false_northing_m": [offset value]
  }
}
```

The projection is centered on the mission area, with coordinates expressed in radians.

## 2. Vehicle Parameters (Version 3.0)

Version 3.0 flight plans include detailed vehicle performance parameters:

### 2.1 Wing-Borne Flight (WBF) Parameters

```
max_wbf_crosstrack_acceleration_m_per_s2: 2.8125-6.4
max_wbf_roll_rate_deg_per_s: 45.0
max_wbf_alongtrack_acceleration_m_per_s2: 0.0-1.0
max_wbf_alongtrack_deceleration_m_per_s2: 0.0-1.0
max_wbf_eas_airspeed_m_per_s: 33.0
min_wbf_eas_airspeed_m_per_s: 27.0
nominal_wbf_eas_airspeed_m_per_s: 30.0
max_wbf_vertical_acceleration_m_per_s2: 1.9-2.0
max_wbf_vertical_deceleration_m_per_s2: 1.9-2.0
max_wbf_ground_relative_flight_path_angle_deg: 4.0-6.5
min_wbf_ground_relative_flight_path_angle_deg: 4.0-6.5
```

Some plans include phased acceleration parameters:
```
max_wbf_alongtrack_initial_phase_acceleration_m_per_s2: 0.5
max_wbf_alongtrack_final_phase_acceleration_m_per_s2: 2.5
wbf_alongtrack_acceleration_breakpoint_eas_m_per_s: 20.0
max_wbf_alongtrack_initial_phase_deceleration_m_per_s2: 0.5
max_wbf_alongtrack_final_phase_deceleration_m_per_s2: 2.5
```

### 2.2 VTOL (Vertical Takeoff and Landing) Parameters

```
max_vtol_yaw_rate_deg_per_s: 30.0
max_vtol_horizontal_acceleration_m_per_s2: 1.0-2.0
max_vtol_horizontal_groundspeed_m_per_s: 2.5-3.0
max_vtol_vertical_acceleration_m_per_s2: 1.9-2.0
max_vtol_vertical_deceleration_m_per_s2: 1.9-2.0
max_vtol_climb_rate_m_per_s: 3.0
max_vtol_descent_rate_m_per_s: 2.0
```

### 2.3 Environmental Parameters

```
max_wind_speed_m_per_s: 12.3467-12.86
```

## 3. Mission Steps and Maneuvers

Flight plans consist of sequenced mission steps, each with a unique ID and specific action type.

### 3.1 Takeoff Action

Defines the initial launch of the drone:

```json
"takeoff_action": {
  "ground_point": {
    "latitude_rad": [value],
    "longitude_rad": [value],
    "altitude_hae_m": [value]
  },
  "initial_tracking_point": {
    "latitude_rad": [value],
    "longitude_rad": [value],
    "altitude_hae_m": [value]
  },
  "takeoff_heading_rad": [value],
  "bounding_volume": {
    "centroid": {
      "latitude_rad": [value],
      "longitude_rad": [value],
      "altitude_hae_m": [value]
    },
    "half_length_m": 2.6-4.0,
    "half_width_m": 2.6-4.0,
    "half_height_m": 7.0,
    "major_axis_rotation_rad": [value]
  }
}
```

The bounding volume defines the safe takeoff area, typically 5.2-8m wide and 14m tall.

### 3.2 VTOL Maneuvers

#### 3.2.1 Straight VTOL Maneuver

Used for vertical or near-vertical flight segments:

```json
"straight_vtol_maneuver": {
  "final_point": {
    "latitude_rad": [value],
    "longitude_rad": [value],
    "altitude_hae_m": [value]
  },
  "final_velocity": {
    "east_m_per_s": [value],
    "north_m_per_s": [value],
    "up_m_per_s": [value]
  }
}
```

#### 3.2.2 Hover VTOL Maneuver

Maintains position for a specified duration:

```json
"hover_vtol_maneuver": {
  "hover_duration_s": [value],
  "use_specified_heading": false
}
```

Hover durations range from 0.01s (transitional) to 10s (operational).

### 3.3 Wing-Borne Flight (WBF) Maneuvers

#### 3.3.1 Straight WBF Maneuver

Linear flight path:

```json
"straight_wbf_maneuver": {
  "final_point": {
    "latitude_rad": [value],
    "longitude_rad": [value],
    "altitude_hae_m": [value]
  },
  "final_course_rad": [value],
  "final_fpa_ground_relative_rad": [value]
}
```

Some v4 plans include `urgent_land_transition_altitude_hae_m` for emergency scenarios.

#### 3.3.2 Roll WBF Maneuver

Initiates a turn with specified radius:

```json
"roll_wbf_maneuver": {
  "final_point": {
    "latitude_rad": [value],
    "longitude_rad": [value],
    "altitude_hae_m": [value]
  },
  "turn_direction": "LEFT" or "RIGHT",
  "final_course_rad": [value],
  "final_fpa_ground_relative_rad": [value],
  "initial_turn_radius_m": [value],
  "final_turn_radius_m": [value]
}
```

Turn radii typically range from 0m (start/end of turn) to 320-640m (during turn).

#### 3.3.3 Turn WBF Maneuver

Executes a constant-radius turn:

```json
"turn_wbf_maneuver": {
  "final_point": {
    "latitude_rad": [value],
    "longitude_rad": [value],
    "altitude_hae_m": [value]
  },
  "turn_direction": "LEFT" or "RIGHT",
  "final_course_rad": [value],
  "final_fpa_ground_relative_rad": [value],
  "turn_radius_m": [value]
}
```

Turn radii are typically 320-640m, matching the roll maneuver's final_turn_radius.

### 3.4 Delivery Actions

#### 3.4.1 Marker Delivery Action

Delivery to a marked location:

```json
"marker_delivery_action": {
  "minimum_search_altitude_point": {
    "latitude_rad": [value],
    "longitude_rad": [value],
    "altitude_hae_m": [value]
  },
  "target_point": {
    "latitude_rad": [value],
    "longitude_rad": [value],
    "altitude_hae_m": [value]
  },
  "outbound_initial_tracking_point": {
    "latitude_rad": [value],
    "longitude_rad": [value],
    "altitude_hae_m": [value]
  },
  "marker_id": [value],
  "delivery_type": "LOCKER_DELIVERY"
}
```

#### 3.4.2 Markerless Delivery Action

Delivery to a specified location without marker:

```json
"markerless_delivery_action": {
  "minimum_search_altitude_point": {
    "latitude_rad": [value],
    "longitude_rad": [value],
    "altitude_hae_m": [value]
  },
  "target_point": {
    "latitude_rad": [value],
    "longitude_rad": [value],
    "altitude_hae_m": [value]
  },
  "outbound_initial_tracking_point": {
    "latitude_rad": [value],
    "longitude_rad": [value],
    "altitude_hae_m": [value]
  }
}
```

The minimum search altitude is typically 20-30m above the target point.

### 3.5 Landing Actions

#### 3.5.1 GPS Land Action

Landing at a specified GPS coordinate:

```json
"gps_land_action": {
  "target_point": {
    "latitude_rad": [value],
    "longitude_rad": [value],
    "altitude_hae_m": [value]
  }
}
```

#### 3.5.2 Marker Land Action

Landing at a marked location:

```json
"marker_land_action": {
  "target_point": {
    "latitude_rad": [value],
    "longitude_rad": [value],
    "altitude_hae_m": [value]
  },
  "minimum_search_altitude_point": {
    "latitude_rad": [value],
    "longitude_rad": [value],
    "altitude_hae_m": [value]
  },
  "marker_id": [value],
  "use_specified_heading": false
}
```

## 4. Alternate Plans and Contingency Management

### 4.1 Alternate Plan Structure

Alternate plans provide contingency routes for various scenarios:

```json
"alternate_plans": [
  {
    "id": [value],
    "plan_type": "RETURN_HOME",
    "start_mission_step_id": [value],
    "mission_steps": [
      // Sequence of mission steps
    ]
  }
]
```

### 4.2 Return Home Plans

Most common alternate plan type, triggered from various mission points:
- Early mission (after takeoff)
- Mid-mission (during transit)
- Late mission (after delivery)

Return home plans typically include:
1. Transition to hover (if in WBF mode)
2. Return flight to home coordinates
3. Descent to landing altitude
4. Landing action (GPS or marker-based)

### 4.3 Branching Logic

Alternate plans can be triggered from specific mission steps:
- `start_mission_step_id` indicates the step after which the alternate plan can be activated
- Multiple alternate plans may be defined for different mission phases
- Each alternate plan has its own sequence of mission steps with unique IDs

## 5. Environmental Considerations

### 5.1 Wind Vectors

Wind information for each mission step:

```json
"wind_vectors": [
  {
    "mission_step_id": [value],
    "wind_velocity_ne_to": {
      "east_m_per_s": [value],
      "north_m_per_s": [value]
    }
  }
]
```

Many plans include zero wind vectors, suggesting they're placeholders for runtime values.

### 5.2 No-Fly Zones

Polygonal areas to be avoided:

```json
"no_fly_zones": [
  {
    "corners": [
      {
        "latitude_rad": [value],
        "longitude_rad": [value]
      },
      // Additional corner points
    ]
  }
]
```

### 5.3 No-Land Zones

Areas where landing is prohibited:

```json
"no_land_zones": [
  {
    "corners": [
      {
        "latitude_rad": [value],
        "longitude_rad": [value]
      },
      // Additional corner points
    ]
  }
]
```

## 6. Timing and Sequencing

### 6.1 Timing Windows

Time constraints for mission steps:

```json
"timing_windows": [
  {
    "mission_step_id": [value],
    "earliest_relative_time_s": [value],
    "latest_relative_time_s": [value],
    "nominal_relative_time_s": [value]
  }
]
```

### 6.2 Mission Timing Divert Offsets

Spatial offsets for delivery operations:

```json
"mission_timing_divert_offsets": {
  "before_delivery_offset_up_m": 0.0-15.0,
  "before_delivery_offset_right_m": 0.0-20.0,
  "after_delivery_offset_up_m": -25.5-15.0,
  "after_delivery_offset_right_m": 0.0-20.0
}
```

## 7. Flight Test Actions

Special actions for testing scenarios:

```json
"flight_test_action_plan": {
  "flight_test_actions": [
    {
      "mission_step_mode": {
        "maneuver_ids": [value]
      },
      "action_config": {
        "encoding": "CYPHAL_BINARY",
        "data": ""
      },
      "id": [value],
      "action_type": "STOP_PRIMARY_RPM_COMMANDS"
    }
  ]
}
```

Alternative mode using geofence triggers:

```json
"flight_test_actions": [
  {
    "geofence_mode": {
      "cuboid": {
        "centroid": {
          "latitude_rad": [value],
          "longitude_rad": [value],
          "altitude_hae_m": [value]
        },
        "half_length_m": 10.0,
        "half_width_m": 10.0,
        "half_height_m": 10.0,
        "major_axis_rotation_rad": 0.0
      }
    },
    "action_config": {
      "encoding": "CYPHAL_BINARY",
      "data": ""
    },
    "id": [value],
    "action_type": "TRANSIT_PHASE_PERCEPTION_ALERT"
  }
]
```

## 8. Typical Mission Profiles

### 8.1 Delivery Mission Profile

1. **Takeoff Phase**
   - Takeoff action from ground point
   - Straight VTOL ascent to initial altitude
   - Hover for stabilization

2. **Transit Phase**
   - Transition to WBF mode
   - Series of straight/roll/turn WBF maneuvers to destination
   - Altitude adjustments as needed

3. **Delivery Phase**
   - Hover at delivery location
   - Marker or markerless delivery action
   - Post-delivery ascent to safe altitude

4. **Return Phase**
   - WBF transit back to home location
   - Transition to VTOL mode
   - Descent to landing altitude
   - GPS or marker-based landing

### 8.2 Test Flight Profile

1. **Takeoff and Hover**
   - Takeoff to low altitude
   - Series of hover maneuvers
   - Short VTOL movements

2. **Pattern Flight**
   - Simple geometric patterns (square, circle)
   - Altitude changes during pattern
   - Return to starting point

3. **Landing**
   - Descent to landing altitude
   - GPS or marker-based landing

## 9. Coordinate System and Spatial Representation

All flight plans use a consistent coordinate system:
- Geographic coordinates in radians (latitude_rad, longitude_rad)
- Altitudes in meters above ellipsoid (altitude_hae_m)
- Velocities in meters per second with ENU (East-North-Up) components
- Headings and courses in radians
- Flight path angles in radians relative to ground

The equirectangular projection provides a local reference frame for each mission, with the projection centered near the mission area.

## Referenced Context Files

The following files provided valuable information for this summary:

1. `63db8373-44d6-4135-9591-fde5d967baca.pb.json` - Version 4.0 delivery mission with marker delivery and landing
2. `bc06bf3e-c10a-473a-9b19-96731efdfed7.pb.json` - Version 3.0 flight plan with detailed vehicle parameters
3. `bc06bf3e-c10a-473a-9b19-96731efdfed7_v4_recovery.pb.json` - Version 4.0 conversion of the same plan
4. `mon_rec_a_b_a_cage_v4_recovery.pb.json` - Simple hover test flight pattern
5. `1e773572-4295-4b6b-8b19-2ced83758b1f.pb.json` - Complex flight with multiple alternate plans
6. `0dbe532e-3783-4b3d-8ced-e687dc2d224a.pb.json` - Flight with detailed wind vectors
7. `719be9d4-d77a-4548-be7f-3c9c7db7845e.pb.json` - Flight with flight test actions
8. `ef2b83f1-f174-4d9a-b46a-ed4f9d9be2c3.pb.json` - Version 4.0 plan with vehicle parameters
9. `cx3-l2_verification-mission-h.pb.json` - Complex mission with multiple alternate plans and timing windows
10. `hybrid_a_b_a_delivery_gps_land_with_return_home_no_divert_pad_v4_recovery.pb.json` - Version 4.0 delivery mission
11. `9fe93450-eb7d-4297-8495-fa68c2f74546.pb.json` - Flight with no-fly and no-land zones