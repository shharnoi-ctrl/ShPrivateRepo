# Generated from:

- code/PA_SIL_raim/include/Raim_builder.h (252 tokens)
- code/PA_SIL_raim/include/Emb_raim_wrapper.h (930 tokens)
- code/PA_SIL_raim/source/Raim_builder.cpp (168 tokens)
- code/PA_SIL_raim/source/Emb_raim_wrapper.cpp (2437 tokens)

---

# RAIM (Receiver Autonomous Integrity Monitoring) Module Analysis

## Overview

The RAIM module is a critical component designed to monitor and validate the integrity of GNSS (Global Navigation Satellite System) signals. It implements algorithms to detect and mitigate potential errors or inconsistencies in satellite navigation data, ensuring reliable positioning information for the navigation system. The module is structured using a builder pattern for component construction and implements a wrapper for the FirmwareSimulation interface to integrate with the broader system.

## Core Components

### 1. Raim_builder Class

The `Raim_builder` class serves as the primary construction mechanism for the RAIM module, following the builder design pattern.

#### Structure and Properties
- **Location**: `code/PA_SIL_raim/include/Raim_builder.h` and `code/PA_SIL_raim/source/Raim_builder.cpp`
- **Key Members**:
  - `Pa_blocks::Raim_parameters* raim_param`: Holds configuration parameters for the RAIM algorithm
  - `Pa_blocks::Blk_pa_raim* pa_raim`: The core RAIM algorithm implementation
  - `bool build_ok`: Flag indicating successful construction of the RAIM components

#### Key Methods
- **Constructor**: Initializes all pointers to NULL and sets `build_ok` to false
- **build()**: 
  ```cpp
  void Raim_builder::build()
  {
      if (!build_ok)
      {
          Base::Allocator& alloc = Base::Memmgr::get_external_allocator();
          raim_param = alloc.allocate_new<Pa_blocks::Raim_parameters>();
          pa_raim = alloc.allocate_new<Pa_blocks::Blk_pa_raim>(*raim_param);

          build_ok = alloc.get_alloc_ok();
      }
  }
  ```
  This method allocates memory for the RAIM parameters and the RAIM algorithm block using an external memory allocator. It sets `build_ok` based on successful allocation.

- **step()**: Executes a single processing step of the RAIM algorithm if the build was successful
  ```cpp
  void Raim_builder::step()
  {
      if (build_ok && pa_raim)
      {
          pa_raim->step();
      }
  }
  ```

- **Accessor Methods**:
  - `is_build_ok()`: Returns the build status
  - `get_raim()`: Returns a pointer to the RAIM algorithm block
  - `get_raim_outputs()`: Returns the outputs from the RAIM algorithm

### 2. Emb_raim_wrapper Class

The `Emb_raim_wrapper` class implements the `FirmwareSimulation` interface, serving as a bridge between the RAIM module and the broader system.

#### Structure and Properties
- **Location**: `code/PA_SIL_raim/include/Emb_raim_wrapper.h` and `code/PA_SIL_raim/source/Emb_raim_wrapper.cpp`
- **Key Members**:
  - `std::unique_ptr<PdiSetter> pdi_setter`: Configures system variables
  - `std::unique_ptr<Data> data`: Contains the RAIM builder and message handling components
  - `uint64_t simulation_time_ns`: Tracks simulation time in nanoseconds
  - `bool is_meas_gnss_sent`: Tracks message sending state

#### Nested Structures
1. **PdiSetter**:
   - Sets system variables, specifically enabling DGNSS corrections for RAIM
   ```cpp
   PdiSetter()
   {
       Bsp::Hbvar(Pa_blocks::Pa_system_vars::mon_raim_use_dgnss_corrections).set(true);
   }
   ```

2. **Data**:
   - Contains the RAIM builder and message handling components
   - Includes senders and readers for RAIM measurement GNSS messages and RAIM output messages
   ```cpp
   struct Data
   {
       Wrapper::Raim_builder pa_raim;

       Cyphal::Cy_tdsync_can_sender<Pa_blocks::Measurements::Gnss_meas::payload_sz>::Xct raim_meas_gnss_sender;
       Base::Dsync::Reader raim_meas_gnss_cpct_msg_rd;

       Cyphal::Cy_tdsync_can_sender<Pa_blocks::Raim::Outputs::msg_sz>::Xct raim_output_sender;
       Base::Dsync::Reader raim_output_cpct_msg_rd;
   }
   ```

#### Key Methods

1. **Constructor**:
   ```cpp
   Emb_raim_wrapper::Emb_raim_wrapper() :
           pdi_setter(std::make_unique<Emb_raim_wrapper::PdiSetter>()),
           data(std::make_unique<Emb_raim_wrapper::Data>()),
           simulation_time_ns(0),
           is_meas_gnss_sent(false)
   {
       data.get()->pa_raim.build(); // Build RAIM object once.
   }
   ```
   Initializes the wrapper and immediately builds the RAIM object.

2. **Init**:
   ```cpp
   bool Emb_raim_wrapper::Init(const FirmwareInitData& init_data)
   {
       return true;
   }
   ```
   Simple initialization that always returns success.

3. **ExecuteAndScheduleNextExecutionInNs**:
   ```cpp
   bool Emb_raim_wrapper::ExecuteAndScheduleNextExecutionInNs(uint64_t& interval_ns)
   {
       Bsp::Htimehelper::set_time_us(Base::Ttime(static_cast<double>(simulation_time_ns) * 1.0E-9));

       Raim_builder& raim_builder = data.get()->pa_raim;

       if (raim_builder.is_build_ok()) {
           raim_builder.get_raim()->step();
       }
       
       // 20 ms of execution rate
       interval_ns = static_cast<uint64_t>(20U) * static_cast<uint64_t>(1000000U);
       simulation_time_ns += interval_ns;
       return true;
   }
   ```
   - Updates the system time based on simulation time
   - Executes a step of the RAIM algorithm if properly built
   - Sets the next execution interval to 20 milliseconds (20,000,000 nanoseconds)
   - Updates the simulation time and returns success

4. **PutMessage**:
   ```cpp
   bool Emb_raim_wrapper::PutMessage(const MessageData& msg)
   {
       Raim_builder& raim_builder = data.get()->pa_raim;
       bool ret = msg.is_valid;

       static const uint16_t kMonitorDroneStatePseudojerkId 
           = Base::Stanag_msg_type::Msg_type::stg_cyphal_msg + 1080;

       if (ret && raim_builder.is_build_ok())
       {
           Base::Lossy str(reinterpret_cast<uint16_t*>(const_cast<unsigned char*>(msg.serialized_payload.data())),
                          (msg.serialized_payload.size() + 1) / 2);

           Pa_blocks::Raim::Inputs& raim_inputs = raim_builder.get_raim()->inputs_.raim_inputs;

           switch (Base::Stanag_msg_type::Msg_type::stg_cyphal_msg + msg.port_id)
           {
               case Base::Stanag_msg_type::cyp_gnss_nav_msg:
               {
                   raim_inputs.gnss_nav_msg.clear();
                   raim_inputs.gnss_nav_msg.emplace_back();
                   raim_inputs.gnss_nav_msg.back().message.cset(str);
                   ret = true;
                   break;
               }
               case Base::Stanag_msg_type::cyp_raw_meas_gnss_compact_primary:
               {
                   raim_inputs.gnss_raw_meas_compact.clear();
                   raim_inputs.gnss_raw_meas_compact.emplace_back();
                   raim_inputs.gnss_raw_meas_compact.back().message.cset(str);
                   ret = true;
                   break;
               }
               case Base::Stanag_msg_type::cyp_dgnss_correct:
               {
                   raim_inputs.dgnss_corrections_wrapper.clear();
                   raim_inputs.dgnss_corrections_wrapper.emplace_back();
                   raim_inputs.dgnss_corrections_wrapper.back().message.cset(str);
                   ret = true;
                   break;
               }
               case Base::Stanag_msg_type::cyp_mon_drone_state:
               {
                   raim_inputs.mon_drone_state_set.clear();
                   raim_inputs.mon_drone_state_set.emplace_back();
                   raim_inputs.mon_drone_state_set.back().message.cset(str);
                   ret = true;
                   break;
               }
               default:
               {
                   ret = false;
                   break;
               }
           }
       }

       return ret;
   }
   ```
   - Processes incoming messages and routes them to the appropriate RAIM input channels
   - Handles four specific message types:
     1. `cyp_gnss_nav_msg`: GNSS navigation messages
     2. `cyp_raw_meas_gnss_compact_primary`: Raw GNSS measurements in compact form
     3. `cyp_dgnss_correct`: Differential GNSS corrections
     4. `cyp_mon_drone_state`: Drone state monitoring data
   - For each message type, it clears any existing data, adds a new entry, and populates it with the incoming message

5. **GetMessage**:
   ```cpp
   bool Emb_raim_wrapper::GetMessage(MessageData& msg)
   {
       const Pa_blocks::Command_fifo<Pa_blocks::Raim::Outputs*, Ku16::u1>& raim_out
                   = data.get()->pa_raim.get_raim_outputs().raim_output;
       
       const bool& is_ready = data.get()->pa_raim.get_raim()->is_ready_output();

       if (raim_out.size() != 0 && is_ready)
       {
           if (!is_meas_gnss_sent)
           {
               // First call: Send RaimMeasGnssMsg
               GetRaimMeasGnssMsg(msg);
               is_meas_gnss_sent = true;
               return true;
           }
           else
           {
               // Second call: Send RaimOutputMsg and clear outputs
               GetRaimOutputMsg(msg);
               data.get()->pa_raim.get_raim()->clear_outputs();
               is_meas_gnss_sent = false;  // Reset for next sequence
               return true;
           }
       }

       // Reset the state if there's no data or RAIM is not ready
       is_meas_gnss_sent = false;
       return false;
   }
   ```
   - Checks if RAIM outputs are available and ready
   - Implements a two-phase message sending sequence:
     1. First call sends GNSS measurement data
     2. Second call sends RAIM output data and clears the output buffer
   - Returns false if no data is available or RAIM is not ready

6. **GetRaimMeasGnssMsg**:
   ```cpp
   void Emb_raim_wrapper::GetRaimMeasGnssMsg(MessageData& msg) {
       // Message ID setup
       static const Uint16 meas_gnss_subject = Base::Stanag_msg_type::cyp_monitor_raim_meas_gnss -
                   static_cast<Uint16>(Base::Stanag_msg_type::stg_cyphal_msg);
       static Cyphal::CyCAN_id cy_meas_gnss_id = Cyphal::CyCAN_id::build_msg(
           Cyphal::pr_nominal, meas_gnss_subject, Ver::Stab_a::pa_id_monitor);
       
       // Prepare message sender
       Cyphal::Cy_tdsync_can_sender<Pa_blocks::Measurements::Gnss_meas::payload_sz>::
                                       Xct::Wrsafe pkt_wr(data.get()->raim_meas_gnss_sender);
       Cyphal::Cyphal_msg cy_msg(pkt_wr.data.to_mblock8());
       cy_msg.set_id(cy_meas_gnss_id);
       Cyphal::Cyphal_msg::Mutator m(cy_msg);

       // Set up data mutator for serialization
       Base::Data_mutator<Base::Lossy::Mutator_traits8<>, Base::U8ostream::Data_traits8<> > mutator(m.os);
       Base::Lossy& str(mutator.m);

       // Populate GNSS measurements from RAIM
       Pa_blocks::Measurements::Gnss_meas gnss_meas;
       data.get()->pa_raim.get_raim()->populate_gnss_meas_from_raim(gnss_meas);
       gnss_meas.cget(str);

       // Read serialized data into buffer
       Cyphal::Cy_tdsync_can_sender<Pa_blocks::Measurements::Gnss_meas::payload_sz>::T_nic_array buff;
       Cyphal::Cyphal_msg cyphal_msg(buff.to_mblock8());
       data.get()->raim_meas_gnss_cpct_msg_rd = data.get()->raim_meas_gnss_sender.read(buff);

       // Populate output message
       msg.port_id = meas_gnss_subject;
       msg.payload_size_bytes = static_cast<Uint32>(Pa_blocks::Measurements::Gnss_meas::payload_sz);
       msg.serialized_payload.resize(msg.payload_size_bytes);

       for(Uint16 i = 0; i < msg.payload_size_bytes; ++i)
       {
           msg.serialized_payload[i] = buff.get(i + Cyphal::Cyphal_msg::hdr_sz);
       }
       msg.is_valid = true;
   }
   ```
   - Creates and populates a message containing GNSS measurements derived from RAIM
   - Uses the Cyphal messaging system for serialization and transmission
   - Copies the serialized payload into the output message structure

7. **GetRaimOutputMsg**:
   ```cpp
   void Emb_raim_wrapper::GetRaimOutputMsg(MessageData& msg) {
       // Message ID setup
       static const Uint16 raim_out_subject = Base::Stanag_msg_type::cyp_pa_mon_raim_output -
                   static_cast<Uint16>(Base::Stanag_msg_type::stg_cyphal_msg);
       static Cyphal::CyCAN_id cy_raim_out_id = Cyphal::CyCAN_id::build_msg(
           Cyphal::pr_nominal, raim_out_subject, Ver::Stab_a::pa_id_monitor);
       
       // Prepare message sender
       Cyphal::Cy_tdsync_can_sender<Pa_blocks::Raim::Outputs::msg_sz>::
                                       Xct::Wrsafe pkt_wr(data.get()->raim_output_sender);
       Cyphal::Cyphal_msg cy_msg(pkt_wr.data.to_mblock8());
       cy_msg.set_id(cy_raim_out_id);
       Cyphal::Cyphal_msg::Mutator m(cy_msg);

       // Set up data mutator for serialization
       Base::Data_mutator<Base::Lossy::Mutator_traits8<>, Base::U8ostream::Data_traits8<> > mutator(m.os);
       Base::Lossy& str(mutator.m);

       // Get RAIM output and serialize it
       const Pa_blocks::Command_fifo<Pa_blocks::Raim::Outputs*, Ku16::u1>& raim_out
                   = data.get()->pa_raim.get_raim_outputs().raim_output;
       (*raim_out.back().message).cget(str);

       // Read serialized data into buffer
       Cyphal::Cy_tdsync_can_sender<Pa_blocks::Raim::Outputs::msg_sz>::T_nic_array buff;
       Cyphal::Cyphal_msg cyphal_msg(buff.to_mblock8());
       data.get()->raim_output_cpct_msg_rd = data.get()->raim_output_sender.read(buff);

       // Populate output message
       msg.port_id = raim_out_subject;
       msg.payload_size_bytes = static_cast<Uint32>(Pa_blocks::Raim::Outputs::msg_sz);
       msg.serialized_payload.resize(msg.payload_size_bytes);

       for(Uint16 i = 0; i < msg.payload_size_bytes; ++i)
       {
           msg.serialized_payload[i] = buff.get(i + Cyphal::Cyphal_msg::hdr_sz);
       }
       msg.is_valid = true;
   }
   ```
   - Creates and populates a message containing RAIM output data
   - Similar structure to GetRaimMeasGnssMsg but uses RAIM output data instead of GNSS measurements

## RAIM Functionality and Data Flow

### Input Processing
The RAIM module accepts four primary types of input data:

1. **GNSS Navigation Messages** (`cyp_gnss_nav_msg`):
   - Contains navigation data from GNSS satellites
   - Includes ephemeris data, almanac, and other navigation parameters

2. **Raw GNSS Measurements** (`cyp_raw_meas_gnss_compact_primary`):
   - Contains raw measurements from GNSS receivers
   - Includes pseudorange, carrier phase, Doppler, and signal strength measurements

3. **Differential GNSS Corrections** (`cyp_dgnss_correct`):
   - Contains correction data to improve GNSS accuracy
   - Used when `mon_raim_use_dgnss_corrections` is enabled (set to true by default)

4. **Drone State Information** (`cyp_mon_drone_state`):
   - Contains information about the drone's current state
   - May include position, velocity, and attitude information

### Processing Cycle
1. The RAIM module runs at a fixed 20ms interval (50Hz)
2. Each cycle, it:
   - Updates the system time
   - Processes any new input messages
   - Executes the RAIM algorithm step
   - Prepares output messages if results are ready

### Output Generation
The RAIM module produces two types of output messages in sequence:

1. **RAIM GNSS Measurements** (`cyp_monitor_raim_meas_gnss`):
   - Contains processed GNSS measurements after RAIM validation
   - Generated by `populate_gnss_meas_from_raim()` method

2. **RAIM Output** (`cyp_pa_mon_raim_output`):
   - Contains integrity monitoring results
   - Includes information about satellite health, position error estimates, and integrity status

## RAIM Algorithm Implementation

While the specific algorithm details are not fully visible in the provided code, we can infer several aspects of the RAIM implementation:

1. **Component Structure**:
   - The core algorithm is implemented in `Pa_blocks::Blk_pa_raim`
   - It uses parameters from `Pa_blocks::Raim_parameters`
   - The algorithm processes inputs stored in `Pa_blocks::Raim::Inputs`
   - Results are stored in `Pa_blocks::Raim::Outputs`

2. **Processing Flow**:
   - The algorithm is stepped at regular intervals (20ms)
   - It processes GNSS measurements and navigation data
   - It optionally incorporates differential GNSS corrections
   - It considers drone state information for context

3. **Output Generation**:
   - The algorithm produces results when ready (controlled by `is_ready_output()`)
   - Results include both processed GNSS measurements and integrity status
   - Outputs are stored in a command FIFO queue

4. **Memory Management**:
   - The RAIM components are allocated using an external memory allocator
   - The builder pattern ensures proper initialization and cleanup

## Integration with External Systems

The RAIM module integrates with the broader system through:

1. **FirmwareSimulation Interface**:
   - Implements standard methods like `Init`, `ExecuteAndScheduleNextExecutionInNs`, `Reset`, etc.
   - Provides a C-style entry point via `get_firmware_simulation_instance()`

2. **Cyphal Messaging System**:
   - Uses `Cy_tdsync_can_sender` for message transmission
   - Follows the STANAG message type conventions
   - Serializes data using the Lossy/Data_mutator framework

3. **System Variables**:
   - Configures behavior through system variables like `mon_raim_use_dgnss_corrections`

## Conclusion

The RAIM module is a sophisticated component designed to ensure the integrity of GNSS navigation data. It implements a comprehensive algorithm for detecting and mitigating errors in satellite signals, providing reliable positioning information for navigation systems. The module is well-structured, using modern C++ design patterns and efficient memory management techniques. It integrates seamlessly with the broader system through standardized interfaces and messaging protocols.

The implementation follows a clear separation of concerns, with distinct components for building the RAIM system, processing inputs, executing the algorithm, and generating outputs. The use of the builder pattern and wrapper classes enhances modularity and maintainability, while the fixed execution rate ensures consistent performance.