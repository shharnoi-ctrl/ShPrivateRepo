# Generated from:

- Amazon-PrimeAir/items/ASTRO/items/sw/sw_PA_SIL/01_System_Architecture.md (3242 tokens)
- Amazon-PrimeAir/items/ASTRO/items/sw/sw_PA_SIL/02_Core_SIL_Framework.md (4103 tokens)
- Amazon-PrimeAir/items/ASTRO/items/sw/sw_PA_SIL/02_SIL_Base_Components.md (3354 tokens)
- Amazon-PrimeAir/items/ASTRO/items/sw/sw_PA_SIL/02_Application_Interfaces.md (5868 tokens)
- Amazon-PrimeAir/items/ASTRO/items/sw/sw_PA_SIL/01_Navigation_System.md (2833 tokens)
- Amazon-PrimeAir/items/ASTRO/items/sw/sw_PA_SIL/02_Monitor_Navigation_Module.md (4800 tokens)
- Amazon-PrimeAir/items/ASTRO/items/sw/sw_PA_SIL/02_RAIM_Module.md (4526 tokens)
- Amazon-PrimeAir/items/ASTRO/items/sw/sw_PA_SIL/02_Navigation_Test_Core.md (3780 tokens)
- Amazon-PrimeAir/items/ASTRO/items/sw/sw_PA_SIL/02_Navigation_Test_Components.md (2709 tokens)
- Amazon-PrimeAir/items/ASTRO/items/sw/sw_PA_SIL/02_Navigation_Test_Database.md (4354 tokens)
- Amazon-PrimeAir/items/ASTRO/items/sw/sw_PA_SIL/01_Monitor_System.md (6095 tokens)
- Amazon-PrimeAir/items/ASTRO/items/sw/sw_PA_SIL/02_Monitor_Module.md (3976 tokens)
- Amazon-PrimeAir/items/ASTRO/items/sw/sw_PA_SIL/02_Monitor_Tests_Core.md (2825 tokens)
- Amazon-PrimeAir/items/ASTRO/items/sw/sw_PA_SIL/02_Monitor_Tests_State_Machines.md (1751 tokens)
- Amazon-PrimeAir/items/ASTRO/items/sw/sw_PA_SIL/02_Monitor_Tests_Checks.md (4281 tokens)
- Amazon-PrimeAir/items/ASTRO/items/sw/sw_PA_SIL/01_Control_System.md (2873 tokens)
- Amazon-PrimeAir/items/ASTRO/items/sw/sw_PA_SIL/02_Controllers_Module.md (3192 tokens)
- Amazon-PrimeAir/items/ASTRO/items/sw/sw_PA_SIL/02_Controllers_Test.md (2475 tokens)

---

# Prime Air SIL System: Knowledge Graph Overview

This document provides a comprehensive overview of the Amazon Prime Air Software-In-the-Loop (SIL) system, which is designed to test and validate the flight control software for Amazon's Prime Air delivery drones. The system follows a layered architecture with clear separation of concerns, enabling thorough testing of all drone subsystems in a simulated environment.

## System Architecture Overview

The Prime Air SIL system is organized into a layered architecture:

```
┌─────────────────────────────────────────────────────────────┐
│                  Application Interfaces                     │
│  ┌───────────────┐  ┌───────────────┐  ┌───────────────┐    │
│  │  AstroConsole │  │    AstroDLL   │  │    AstroSO    │    │
│  │   (Windows)   │  │   (Windows)   │  │    (Linux)    │    │
│  └───────────────┘  └───────────────┘  └───────────────┘    │
├─────────────────────────────────────────────────────────────┤
│                   Core SIL Framework                        │
│  ┌───────────────┐  ┌───────────────┐  ┌───────────────┐    │
│  │ Message System│  │  Navigation   │  │   Recovery    │    │
│  │               │  │    System     │  │    System     │    │
│  └───────────────┘  └───────────────┘  └───────────────┘    │
├─────────────────────────────────────────────────────────────┤
│                     SIL Base Components                     │
│  ┌───────────────┐  ┌───────────────┐  ┌───────────────┐    │
│  │ Firmware      │  │ Configuration │  │ Serialization │    │
│  │ Simulation    │  │ Management    │  │ Utilities     │    │
│  └───────────────┘  └───────────────┘  └───────────────┘    │
└─────────────────────────────────────────────────────────────┘
```

### Layer Responsibilities

1. **SIL Base Components**: Provides foundational interfaces and utilities:
   - `FirmwareSimulation` interface hierarchy
   - Configuration management
   - Serialization utilities
   - Memory management

2. **Core SIL Framework**: Implements the simulation logic:
   - Message handling system
   - Navigation system
   - Recovery system
   - Controller system
   - Monitor system

3. **Application Interfaces**: Provides platform-specific entry points:
   - Windows console application and DLL interface
   - Linux console application and shared object interface

## Key Subsystems

### 1. Navigation System

The navigation system is a sophisticated, multi-component architecture designed to provide reliable positioning, velocity, and attitude information. It consists of three primary subsystems:

1. **Monitor Navigation Module**: The primary navigation system responsible for state estimation
   - Processes sensor inputs (IMU, GNSS, pressure sensors, LIDAR)
   - Implements an Extended Kalman Filter for state estimation
   - Generates navigation outputs (position, velocity, attitude)

2. **RAIM (Receiver Autonomous Integrity Monitoring) Module**: Validates GNSS measurements
   - Detects and mitigates errors in satellite navigation data
   - Ensures reliable positioning information
   - Provides integrity status information to the navigation system

3. **Navigation Testing Framework**: Comprehensive testing infrastructure
   - Replays recorded flight data through navigation algorithms
   - Validates specific navigation functions
   - Manages test data and results

### 2. Control System

The control system is responsible for flight management and ensuring stable operations:

1. **High-Level Control Interface**: Serves as the primary interface between the SIL framework and embedded controllers
   - Manages initialization, execution scheduling, and message passing
   - Operates on a deterministic 64Hz cycle (15.625ms intervals)

2. **Force and Torque Allocation**: Translates high-level commands into motor outputs
   - Uses constrained quadratic programming for optimization
   - Allocates forces and torques to 6 motors in the hexacopter configuration

3. **Trajectory Planning**: Handles generation and execution of flight paths
   - Supports various maneuver types (straight, turn, roll)
   - Respects vehicle dynamics and constraints

### 3. Monitor System

The monitor system serves as an independent safety component:

1. **Monitor Builder**: Constructs and initializes the monitoring system
   - Builds monitor objects in a structured manner
   - Provides access to the Platform Abstraction Monitor instance

2. **PA Monitor**: Implements main monitoring logic
   - Processes inputs from various system components
   - Generates outputs including failover triggers and alerts
   - Executes safety checks and state machine logic

3. **Hierarchical State Machine System**: Tracks and controls mission phases
   - Top-level state machine for mission modes
   - Second-level state machines for specific phases
   - Third-level state machines for detailed operations

4. **Package Delivery System Simulation**: Models the package delivery mechanism
   - Simulates servo behavior and door states
   - Implements state machine for door operations

### 4. Recovery System

The recovery system handles contingency situations:

1. **Recovery Lane Step 1**: Provides interface to the recovery system
   - Processes state estimates and mission parameters
   - Generates motor state commands and recovery actions

2. **Recovery State Machine**: Manages recovery actions
   - Tracks recovery states and contingency actions
   - Controls motor state during recovery

3. **Switchover Mechanism**: Transitions between primary and recovery systems
   - Triggered through failover messages
   - Sets GPIO signals for hardware switchover

## Cross-Platform Support

The SIL system provides cross-platform support through:

1. **Common Interface**: Both Windows and Linux implementations use the same interface
   - Identical function signatures
   - Consistent error handling and configuration parameters

2. **Platform-Specific Implementations**:
   - Windows: Uses `LoadLibraryA` and `GetProcAddress` for dynamic loading
   - Linux: Uses `dlopen` and `dlsym` for dynamic loading

3. **Wrapper Classes**: Abstract platform differences
   - `Astro_dll_wrapper` for Windows
   - `Astro_so_wrapper` for Linux

## Testing Framework

The SIL system includes comprehensive testing capabilities:

1. **Navigation Testing**: Validates navigation algorithms
   - Replays recorded flight data
   - Tests individual components (IMU processing, GNSS integration)
   - Verifies state estimation accuracy

2. **Controller Testing**: Verifies control algorithms
   - Tests trajectory planning and execution
   - Validates force and torque allocation
   - Ensures proper motor command generation

3. **Monitor Testing**: Validates safety monitoring
   - Tests state machine transitions
   - Verifies safety check functionality
   - Ensures proper contingency handling

## Data Flow Architecture

The SIL system implements a comprehensive data flow architecture:

```
┌───────────────┐    ┌───────────────┐    ┌───────────────┐
│ External      │    │ SIL Framework │    │ Vehicle       │
│ Simulation    │◄───┤ Message       ├───►│ Control       │
│ Environment   │    │ System        │    │ Systems       │
└───────┬───────┘    └───────────────┘    └───────┬───────┘
        │                                         │
        │            ┌───────────────┐            │
        └───────────►│ Navigation    ├────────────┘
                     │ System        │
                     └───────────────┘
```

1. **Message Flow**:
   - External stimuli enter through the `PutMessage` method
   - Messages are deserialized and routed to appropriate components
   - Components generate output messages through the `GetMessage` method

2. **Execution Flow**:
   - The `ExecuteAndScheduleNextExecutionInNs` method runs simulation steps
   - Each step processes inputs, updates internal state, and generates outputs
   - The method returns the time interval until the next execution

## Configuration System

The SIL system implements a comprehensive configuration system:

1. **Configuration Sources**:
   - Command-line arguments provide basic configuration
   - Configuration files (`dll_config.vcfg`) provide additional settings
   - PDI files provide detailed component configuration

2. **Configuration Management**:
   - The `Knobs` class manages configuration parameters
   - Parameters include navigation settings, vehicle parameters, and sensor filtering values

3. **PDI Loading**:
   - The system loads configuration data from PDI files during initialization
   - This allows for detailed configuration of specific components

## Where to Find More Information

For more detailed information about specific components, refer to these files:

1. **Navigation System**: See `/01_Navigation_System.md` for comprehensive details on:
   - Monitor Navigation Module
   - RAIM Module
   - Navigation Testing Framework

2. **Control System**: See `/01_Control_System.md` for information about:
   - Control system architecture
   - Force and torque allocation
   - Trajectory planning and execution

3. **Monitor System**: See `/01_Monitor_System.md` for details on:
   - Monitor architecture
   - Safety checks and monitoring algorithms
   - State machine logic and mission phases
   - Package Delivery System

4. **Core Framework**: See `/02_Core_SIL_Framework.md` for information about:
   - Message handling system
   - Navigation system integration
   - Recovery system integration

5. **Base Components**: See `/02_SIL_Base_Components.md` for details on:
   - FirmwareSimulation interface hierarchy
   - Message data structures
   - Configuration and allocation utilities

6. **Application Interfaces**: See `/02_Application_Interfaces.md` for information about:
   - Console applications
   - DLL interface
   - Shared object implementations

## Summary

The Prime Air SIL system is a comprehensive simulation framework designed to test and validate the flight control software for Amazon's Prime Air delivery drones. It follows a layered architecture with clear separation of concerns, enabling thorough testing of all drone subsystems in a simulated environment.

The system's key strengths include:
- Modularity through interface-based design
- Cross-platform support with consistent interfaces
- Comprehensive testing capabilities
- Detailed configuration options
- Realistic simulation of all drone subsystems

These architectural strengths enable the SIL system to provide a robust simulation environment for testing and validating the Prime Air drone control software across different platforms and configurations.