# Generated from:

- pa_blocks/code/include/Cy_maint_action.h (1116 tokens)
- pa_blocks/code/include/Cy_maint_action_consts.h (796 tokens)
- pa_blocks/code/include/Cy_pds_calibration.h (1180 tokens)
- pa_blocks/code/include/Cy_pds_state.h (200 tokens)
- pa_blocks/code/source/Cy_maint_action.cpp (1109 tokens)
- pa_blocks/code/source/Cy_pds_state.cpp (350 tokens)

## With context from:

- PackageSummaries/Embention/Amazon-PrimeAir/items/ASTRO/items/sw/sw_Astro/code/04_Communication_Systems.md (4759 tokens)
- PackageSummaries/Embention/Amazon-PrimeAir/items/ASTRO/items/sw/sw_Astro/code/03_Command_Processing.md (6508 tokens)

---

# Drone Maintenance Action System: High-Fidelity Semantic Knowledge Graph

## 1. Functional Behavior and Logic

### Maintenance Action System Overview

The drone's maintenance action system is implemented through a set of classes that handle maintenance operations, commands, and responses. The system is designed to process maintenance requests, execute maintenance actions, and provide structured responses back to the requester.

#### Cy_maint_action Class

The `Cy_maint_action` class serves as the central component of the maintenance action system. It implements both `Stanag::IStanag_rx_hdl` and `Cyphal::CyphalStanag_tx_hnd` interfaces, allowing it to receive maintenance action requests and send responses.

```cpp
class Cy_maint_action : public Stanag::IStanag_rx_hdl, public Cyphal::CyphalStanag_tx_hnd
{
    // Implementation details...
};
```

Key responsibilities of this class include:
1. Deserializing incoming maintenance action requests
2. Routing requests to appropriate handlers based on command type
3. Processing maintenance actions asynchronously
4. Serializing and sending maintenance action responses

The class maintains a map of command handlers indexed by command type:

```cpp
Base::Map<Cy_maint_action_consts::Command_types, Cy_maint_action_consts::Imaint_action*> commands;
```

This allows different maintenance actions to be registered and handled by specialized components.

#### Maintenance Action Command Types

The system supports several command types defined in `Cy_maint_action_consts::Command_types`:

```cpp
enum Command_types
{
    cmd_none                = 0,    ///< No command currently set.
    // 1 - 3 reserved for Knobs
    cmd_set_site_config     = 4,    ///< Set site configuration command.
    cmd_get_site_config     = 5,    ///< Get site configuration command.
    cmd_dcomss_install_test = 6,    ///< DiverseComms install test command.
    cmd_rf_install_test     = 7,    ///< RangeFinder install test command.
    cmd_radar_install_test  = 8     ///< Radar install test command.
};
```

These commands allow for various maintenance operations including:
- Setting and retrieving site configuration
- Testing the installation of DiverseComms systems
- Testing the installation of RangeFinder systems
- Testing the installation of Radar systems

#### Maintenance Action Interface

The `Imaint_action` interface defines the contract that all maintenance action handlers must implement:

```cpp
struct Imaint_action : public Base::Iserializable_u8, public Base::Ideserializable_u8
{
    virtual void fill_res_params(Result_codes& result_code,
                                 Payload_types& payload_type,
                                 Cyphal_common_types::String_cy& debug_msg) const = 0;
    virtual bool processed_req() = 0;
};
```

This interface requires two key methods:
1. `fill_res_params`: Fills the response parameters including result code, payload type, and debug message
2. `processed_req`: Executes the maintenance action and returns true when complete

#### PDS Calibration System

The `Cy_pds_calibration` class implements calibration functionality for the Position Determination System (PDS):

```cpp
class Cy_pds_calibration : public Stanag::Stanag_msg_tx, public Stanag::Stanag_msg_rx_async
{
    // Implementation details...
};
```

This class:
1. Receives calibration commands
2. Updates offset values
3. Stores calibration data persistently
4. Sends calibration responses

The calibration data is stored in a configuration structure:

```cpp
struct Pds_calib : public Base::Itunable
{
    Persistent_pdi pdi_data;        ///< Persistent PDI data.
    volatile Real& offset_var;      ///< Real reference variable for offset value.
    
    // Methods...
};
```

#### PDS State Reporting

The `Cy_pds_state` class handles reporting of PDS state information:

```cpp
class Cy_pds_state : private Stanag::Stanag_msg_tx
{
    // Implementation details...
};
```

This class:
1. Receives PDS state information from internal systems
2. Formats the state information according to the Cyphal protocol
3. Transmits the state information to external systems

### Maintenance Action Processing Flow

The maintenance action processing flow follows these steps:

1. **Request Reception**: The `on_rx` method deserializes incoming maintenance action requests
   ```cpp
   Base::Msg_data::Ack_type Cy_maint_action::on_rx(Rx_params& rx_p)
   {
       // Deserialize request and extract command information
       // Find appropriate handler for the command type
       // Start asynchronous processing
   }
   ```

2. **Asynchronous Processing**: The `step_task` method continues processing the request
   ```cpp
   bool Cy_maint_action::step_task()
   {
       // Check if request is complete or timed out
       // Send response when complete
   }
   ```

3. **Response Generation**: The `on_tx_impl` method serializes the response
   ```cpp
   bool Cy_maint_action::on_tx_impl(Tx_params& tx_p)
   {
       // Get response parameters from handler
       // Serialize response
       // Reset state for next request
   }
   ```

This asynchronous approach allows maintenance actions to be processed without blocking other system operations.

## 2. Control Flow and State Transitions

### Maintenance Action Request-Response Flow

| State | Trigger | Actions | Next State | Location |
|-------|---------|---------|------------|----------|
| Idle | Maintenance action request received | Deserialize request, identify command type, find handler | Processing | Cy_maint_action.cpp:on_rx |
| Processing | `step_task` called | Call handler's `processed_req` method | Complete or Continue Processing | Cy_maint_action.cpp:step_task |
| Complete | Handler returns true or timeout expires | Send response message | Idle | Cy_maint_action.cpp:step_task |
| Response Generation | Response message transmission | Call handler's `fill_res_params`, serialize response | Idle | Cy_maint_action.cpp:on_tx_impl |

### PDS Calibration State Machine

| State | Trigger | Actions | Next State | Location |
|-------|---------|---------|------------|----------|
| Idle | Calibration command received | Extract offset value, start timeout | Processing | Cy_pds_calibration.cpp:on_rx |
| Processing | `step_task` called | Save offset to configuration if requested | Complete | Cy_pds_calibration.cpp:step_task |
| Complete | Task finished or timeout expired | Send calibration response | Idle | Cy_pds_calibration.cpp:step_task |

## 3. Inputs and Stimuli

### Maintenance Action Requests

The `Cy_maint_action::on_rx` method processes incoming maintenance action requests:

```cpp
Base::Msg_data::Ack_type Cy_maint_action::on_rx(Rx_params& rx_p)
{
    Base::Msg_data::Ack_type ret = Base::Msg_data::rejected;
    rx_p.is.get_uint8();        // Cyphal::Cyphal_stg_fields.all (not used)
    rx_p.is.get_uint64_le();    // Received transfer ID.
    rx_p.is.get_uint8();        // dummy byte

    const Uint16 target_node_id = rx_p.is.get_uint16_le();

    if(((target_node_id == Ver::Fastbus::get_node_id()) || (target_node_id == Cy_maint_action_consts::anonymous_node_id))
            && (curr_req == 0)) // Just process if it is for me and no more request being processed
    {
        command_type = static_cast<Cy_maint_action_consts::Command_types>(rx_p.is.get_uint8());
        const Uint8 payload_type = rx_p.is.get_uint8();

        const Uint32 opaque_size = Cyphal_common_types::get_array_size(Cyphal_common_types::max_opaque_payload, rx_p.is);
        curr_req = commands.get(command_type, 0U);
        if(curr_req != 0)
        {
            const Uint32 pos = rx_p.is.get_pos();
            curr_req->cset(rx_p.is);
            Base::Assertions::runtime((rx_p.is.get_pos() - pos) == opaque_size);
            dst_addr = rx_p.hdr.get_src();
            tout.start();
            ret = Base::Msg_data::not_completed;    // It starts step_task
        }
        else
        {
            ret = Base::Msg_data::received;
        }
    }
    return ret;
}
```

Key inputs processed:
- **Target Node ID**: Identifies which node should process the request
- **Command Type**: Identifies which maintenance action to perform
- **Payload Type**: Indicates the format of the payload data
- **Opaque Payload**: Command-specific data processed by the appropriate handler

### PDS Calibration Commands

The `Cy_pds_calibration::on_rx` method processes incoming calibration commands:

```cpp
virtual Base::Msg_data::Ack_type on_rx(Rx_params& rx_p);
```

This method:
- Extracts calibration offset values
- Determines whether to save the calibration permanently
- Starts a timeout for the calibration process

### PDS State Updates

The `Cy_pds_state::send` method receives PDS state updates:

```cpp
void Cy_pds_state::send(const Vms_pds_state& pds_state0)
{
    pds_state = pds_state0;

    msg_sender.send(Base::Msg_data(Base::Address(Ver::Stab_a::pa_id_primary0),
                                   Base::Stanag_msg_type::cyp_pds_state,
                                   0));
}
```

This method:
- Receives updated PDS state information
- Triggers transmission of the state information

## 4. Outputs and Effects

### Maintenance Action Responses

The `Cy_maint_action::on_tx_impl` method generates maintenance action responses:

```cpp
bool Cy_maint_action::on_tx_impl(Tx_params& tx_p)
{
    Cy_maint_action_consts::Result_codes result_code = Cy_maint_action_consts::res_failure;
    Cy_maint_action_consts::Payload_types payload_type = Cy_maint_action_consts::pyl_empty;

    const bool is_reg = Base::Assertions::runtime(curr_req != 0);
    if(is_reg)
    {
        debug_message.resize(0U);
        curr_req->fill_res_params(result_code, payload_type, debug_message);
    }

    tx_p.os.put_uint16_le(Ver::Fastbus::get_node_id()); // source_node_id
    tx_p.os.put_uint8(command_type);
    tx_p.os.put_uint32_le(result_code);
    tx_p.os.put_uint8(payload_type);
    const Uint32 size_offset = tx_p.os.get_pos();
    Cyphal_common_types::put_array_size(0U, tx_p.os, Cyphal_common_types::max_opaque_payload);

    if(is_reg)
    {
        const Uint32 opaque_offset = tx_p.os.get_pos();
        curr_req->cget(tx_p.os);
        const Uint32 opaque_size = tx_p.os.get_pos();
        tx_p.os.seek(size_offset);
        Cyphal_common_types::put_array_size(opaque_size - opaque_offset, tx_p.os, Cyphal_common_types::max_opaque_payload);
        tx_p.os.seek(opaque_size);
    }
    Cyphal_common_types::serialize_string(tx_p.os, debug_message);

    // Set available
    curr_req = 0U;

    return true;
}
```

Key outputs generated:
- **Source Node ID**: Identifies which node is responding
- **Command Type**: Echoes the command type being responded to
- **Result Code**: Indicates success or failure with specific error code
- **Payload Type**: Indicates the format of the response payload
- **Opaque Payload**: Command-specific response data
- **Debug Message**: Additional information about the result

### PDS Calibration Responses

The `Cy_pds_calibration::on_tx` method generates calibration responses:

```cpp
virtual bool on_tx(Tx_params& tx_p);
```

This method:
- Serializes the calibration result (success or failure)
- Provides information about the calibration process

### PDS State Messages

The `Cy_pds_state::on_tx` method generates PDS state messages:

```cpp
bool Cy_pds_state::on_tx(Tx_params& tx_p)
{
    Cyphal::Cyphal_stg_fields cyf = {0U};
    cyf.priority = Cyphal::pr_nominal;
    tx_p.os.put_uint8(cyf.all);
    tx_p.os.put_uint64_le(0U);  // Transfer ID, not needed in CAN communications (managed internally)
    tx_p.os.put_uint8(Ku8::u0); // dummy byte
    Base::Data_mutator<Base::Lossy::Mutator_traits8<>, Base::U8ostream::Data_traits8<> > m(tx_p.os);
    pds_state.cget(m.m);
    return true;
}
```

This method:
- Serializes the current PDS state information
- Formats it according to the Cyphal protocol
- Transmits it to external systems

## 5. Parameters and Configuration

### Maintenance Action Constants

The `Cy_maint_action_consts` namespace defines several important constants and enumerations:

```cpp
namespace Cy_maint_action_consts
{
    /// Anonymous Node ID.
    static const Uint16 anonymous_node_id = 65535U;

    enum Command_types
    {
        cmd_none                = 0,    ///< No command currently set.
        // 1 - 3 reserved for Knobs
        cmd_set_site_config     = 4,    ///< Set site configuration command.
        cmd_get_site_config     = 5,    ///< Get site configuration command.
        cmd_dcomss_install_test = 6,    ///< DiverseComms install test command.
        cmd_rf_install_test     = 7,    ///< RangeFinder install test command.
        cmd_radar_install_test  = 8     ///< Radar install test command.
    };

    static const Uint16 ncommands = 9;

    enum Payload_types
    {
        pyl_empty               = 0,    ///< Empty payload.
        pyl_cyphal_msg          = 1,    ///< Cyphal message payload.
        pyl_sha256_hash         = 2,    ///< SHA256 hash payload.
        pyl_ascii_str           = 3,    ///< ASCII string payload.
        pyl_json_str            = 4,    ///< JSON string payload.
        pyl_format_knobs_str    = 5,    ///< Format Knobs string payload.
        pyl_bin_file            = 6     ///< Binary file payload.
    };

    enum Result_codes
    {
        // 0 - 299 Common Result Codes
        res_success         = 0,    ///< Generic success.
        res_failure         = 1,    ///< Generic failure.
        // 300 - 399 Perform Diverse Comms Install Test result codes.
        res_dcomms_not_connected    = 300,
        res_dcomms_not_enabled      = 301,
        res_dcomms_not_powered      = 302,
        // 400 - 499 Set Site Configuration Result Codes
        // 500 - 599 Get Site Configuration Result Codes
    };
}
```

Key parameters include:
- **anonymous_node_id**: Special node ID (65535) that allows commands to be sent to all nodes
- **Command_types**: Enumeration of supported maintenance commands
- **Payload_types**: Enumeration of supported payload formats
- **Result_codes**: Enumeration of possible result codes, organized by command type

### PDS Calibration Parameters

The `Cy_pds_calibration::Pds_calib` structure stores calibration parameters:

```cpp
struct Pds_calib : public Base::Itunable
{
    Persistent_pdi pdi_data;        ///< Persistent PDI data.
    volatile Real& offset_var;      ///< Real reference variable for offset value.
    
    // Methods...
};
```

Key parameters include:
- **pdi_data**: Persistent data interface for storing calibration values
- **offset_var**: Reference to the offset variable that will be updated

### Timeout Parameters

The `Cy_maint_action` class uses a timeout to limit how long it waits for a maintenance action to complete:

```cpp
Base::Timeout tout(Const::TEN);
```

This timeout is set to 10 seconds, after which the maintenance action will be considered failed if not completed.

## 6. Error Handling and Contingency Logic

### Maintenance Action Timeout

The `Cy_maint_action::step_task` method implements timeout handling:

```cpp
bool Cy_maint_action::step_task()
{
    const bool ret = (Base::Assertions::runtime(curr_req != 0) && (curr_req->processed_req())) || (tout.expired());
    if(ret)
    {
        msg_sender.send(Base::Msg_data(dst_addr, Base::Stanag_msg_type::cyp_maintenance_action_res, 0U));
    }
    return ret;
}
```

If the timeout expires before the maintenance action completes, the system will:
1. Consider the action failed
2. Send a response with an appropriate error code
3. Reset the state to handle new requests

### Result Code Handling

The `Cy_maint_action_consts::Result_codes` enumeration defines various result codes:

```cpp
enum Result_codes
{
    // 0 - 299 Common Result Codes
    res_success         = 0,    ///< Generic success.
    res_failure         = 1,    ///< Generic failure.
    // 300 - 399 Perform Diverse Comms Install Test result codes.
    res_dcomms_not_connected    = 300,
    res_dcomms_not_enabled      = 301,
    res_dcomms_not_powered      = 302,
    // 400 - 499 Set Site Configuration Result Codes
    // 500 - 599 Get Site Configuration Result Codes
};
```

These codes allow the system to provide detailed error information:
- **res_success**: The maintenance action completed successfully
- **res_failure**: The maintenance action failed for a generic reason
- **res_dcomms_not_connected**: The DiverseComms system is not connected
- **res_dcomms_not_enabled**: The DiverseComms system is not enabled
- **res_dcomms_not_powered**: The DiverseComms system is not powered

### Target Node Validation

The `Cy_maint_action::on_rx` method validates the target node ID:

```cpp
if(((target_node_id == Ver::Fastbus::get_node_id()) || (target_node_id == Cy_maint_action_consts::anonymous_node_id))
        && (curr_req == 0)) // Just process if it is for me and no more request being processed
{
    // Process the request
}
```

This ensures that:
1. The request is intended for this node (or is a broadcast to all nodes)
2. No other request is currently being processed

If these conditions are not met, the request is rejected.

### Handler Validation

The `Cy_maint_action::on_rx` method validates that a handler exists for the requested command type:

```cpp
curr_req = commands.get(command_type, 0U);
if(curr_req != 0)
{
    // Process the request
}
else
{
    ret = Base::Msg_data::received;
}
```

If no handler is registered for the command type, the request is acknowledged but not processed further.

### PDS Calibration Error Handling

The `Cy_pds_calibration` class defines result codes for calibration operations:

```cpp
enum Result
{
    success = 0,    ///< Success result.
    failure = 1     ///< Failure result.
};
```

If a calibration operation fails, the system will:
1. Set the result code to `failure`
2. Send a response indicating the failure
3. Not update the stored calibration value

## 7. File-by-File Breakdown

### Cy_maint_action.h
- Defines the `Cy_maint_action` class for handling maintenance action requests and responses
- Declares methods for receiving, processing, and responding to maintenance actions
- Implements the `Stanag::IStanag_rx_hdl` and `Cyphal::CyphalStanag_tx_hnd` interfaces
- Provides a registration mechanism for command handlers

### Cy_maint_action.cpp
- Implements the `Cy_maint_action` class methods
- Contains the core logic for processing maintenance action requests
- Handles deserialization of requests and serialization of responses
- Manages the asynchronous processing of maintenance actions

### Cy_maint_action_consts.h
- Defines constants and enumerations used by the maintenance action system
- Contains command types, payload types, and result codes
- Defines the `Imaint_action` interface that all maintenance action handlers must implement
- Provides a structured approach to handling different types of maintenance actions

### Cy_pds_calibration.h
- Defines the `Cy_pds_calibration` class for handling PDS calibration
- Declares methods for receiving calibration commands and sending responses
- Implements the `Stanag::Stanag_msg_tx` and `Stanag::Stanag_msg_rx_async` interfaces
- Defines the `Pds_calib` structure for storing calibration data

### Cy_pds_calibration.cpp (not provided in the input)
- Would implement the `Cy_pds_calibration` class methods
- Would contain logic for processing calibration commands
- Would handle saving calibration data persistently
- Would manage the serialization of calibration responses

### Cy_pds_state.h
- Defines the `Cy_pds_state` class for reporting PDS state information
- Declares methods for sending PDS state updates
- Implements the `Stanag::Stanag_msg_tx` interface
- Provides a mechanism for transmitting PDS state to external systems

### Cy_pds_state.cpp
- Implements the `Cy_pds_state` class methods
- Contains logic for serializing PDS state information
- Handles transmission of PDS state messages
- Conditionally registers the handler based on hardware version

## 8. Cross-Component Relationships

### Maintenance Action System and Command Handlers

The `Cy_maint_action` class maintains a map of command handlers:

```cpp
Base::Map<Cy_maint_action_consts::Command_types, Cy_maint_action_consts::Imaint_action*> commands;
```

This allows different components to register handlers for specific command types:

```cpp
inline void reg(Cy_maint_action_consts::Command_types command, Cy_maint_action_consts::Imaint_action& des)
{
    commands.put(command, &des);
}
```

When a maintenance action request is received, the appropriate handler is looked up and invoked:

```cpp
curr_req = commands.get(command_type, 0U);
if(curr_req != 0)
{
    const Uint32 pos = rx_p.is.get_pos();
    curr_req->cset(rx_p.is);
    // ...
}
```

This relationship allows the maintenance action system to be extended with new command types without modifying the core system.

### Maintenance Action System and Message Sender

The `Cy_maint_action` class uses a message sender interface to transmit responses:

```cpp
Base::Imsg_sender& msg_sender;
```

This interface is provided during construction:

```cpp
explicit Cy_maint_action(Base::Imsg_sender& msg_sender0, Stanag::IStanag_rx_pkt* forwarder0 = 0);
```

When a maintenance action is complete, the system sends a response:

```cpp
if(ret)
{
    msg_sender.send(Base::Msg_data(dst_addr, Base::Stanag_msg_type::cyp_maintenance_action_res, 0U));
}
```

This relationship allows the maintenance action system to communicate with external systems without being tightly coupled to a specific communication mechanism.

### Maintenance Action System and Message Forwarder

The `Cy_maint_action` class optionally uses a message forwarder:

```cpp
Stanag::IStanag_rx_pkt* forwarder;
```

This forwarder is used to forward messages to another core for processing:

```cpp
Base::Msg_data::Ack_type Cy_maint_action::on_rx_pkt(Params& params)
{
    // ...
    Base::Msg_data::Ack_type ret = on_rx(push_p);
    if((ret == Base::Msg_data::received) && (forwarder != 0))
    {
        forwarder->on_rx_pkt(params);
    }
    return ret;
}
```

This relationship allows maintenance actions to be processed on different cores, improving system responsiveness and resource utilization.

### PDS Calibration and Configuration Manager

The `Cy_pds_calibration` class uses a configuration manager:

```cpp
Media::Cfgmgr& cfg_mgr;
```

This manager is used to save calibration data persistently:

```cpp
Cy_pds_calibration(Media::Cfgmgr& cfg_mgr0,
                   volatile Real& offset_var0,
                   Base::Imsg_sender& msg_sender0);
```

This relationship allows calibration data to be preserved across system restarts, ensuring that calibration settings are not lost.

### PDS State and Parser

The `Cy_pds_state` class uses a parser to access the message sender:

```cpp
Cy_pds_state(Midlevel::Irxfw::Parser& irxfw_parser0) :
        pds_state(),
        msg_sender(irxfw_parser0.get_responses_mgr())
{
    // ...
}
```

This relationship allows the PDS state reporting system to send messages through the established communication channels.

## 9. Referenced Context Files

The following context files provided useful information for understanding the maintenance action system:

- **Communication Systems Documentation**: Provided insights into how the maintenance action system interfaces with the broader communication architecture
  - Explained the role of Cyphal in maintenance action communication
  - Detailed the DiverseComms system that can be tested through maintenance actions
  - Showed how messages are forwarded between different cores

- **Command Processing Documentation**: Provided context on how commands are processed in the system
  - Explained the command processing flow that is similar to the maintenance action flow
  - Detailed how commands are validated and acknowledged
  - Showed how responses are generated and transmitted

These context files helped establish how the maintenance action system fits into the broader drone architecture, particularly how it interfaces with the communication systems and command processing systems.