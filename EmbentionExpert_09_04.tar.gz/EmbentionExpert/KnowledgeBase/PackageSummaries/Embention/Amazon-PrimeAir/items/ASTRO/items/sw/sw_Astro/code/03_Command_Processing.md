# Generated from:

- pa_blocks/code/include/Commands_processor.h (833 tokens)
- pa_blocks/code/include/Command_response.h (514 tokens)
- pa_blocks/code/include/Command_acknowledgement_msg.h (107 tokens)
- pa_blocks/code/include/Command_received_types.h (101 tokens)
- pa_blocks/code/include/Command_fifo.h (541 tokens)
- pa_blocks/code/include/Command_routes_and_deviations_params.h (660 tokens)
- pa_blocks/code/include/Command_route_entries.h (101 tokens)
- pa_blocks/code/include/Command_route_entry.h (184 tokens)
- pa_blocks/code/include/Cy_command_response.h (333 tokens)
- pa_blocks/code/source/Commands_processor.cpp (1015 tokens)
- pa_blocks/code/source/Command_response.cpp (441 tokens)
- pa_blocks/code/source/Command_received_types.cpp (46 tokens)
- pa_blocks/code/source/Command_routes_and_deviations_params.cpp (420 tokens)
- pa_blocks/code/source/Command_route_entries.cpp (166 tokens)
- pa_blocks/code/source/Command_route_entry.cpp (107 tokens)
- pa_blocks/code/source/Cy_command_response.cpp (333 tokens)

## With context from:

- PackageSummaries/Embention/Amazon-PrimeAir/items/ASTRO/items/sw/sw_Astro/code/04_Communication_Systems.md (4759 tokens)

---

# Drone Command Processing System: High-Fidelity Semantic Knowledge Graph

## 1. Functional Behavior and Logic

### Command Processing Architecture

The drone's command processing system is built around a structured approach to receiving, validating, and executing commands. The system is primarily implemented through the `Commands_processor` class, which serves as the central hub for processing various types of commands.

#### Command Types and Processing Flow

The command processing system handles several primary command types:
- **Takeoff Commands**: Instructions for the drone to initiate takeoff procedures
- **Land Commands**: Instructions for the drone to land at a specified location
- **Route Commands**: Instructions for the drone to follow a specified route
- **Airspeed Modulation Commands**: Instructions to enable/disable airspeed modulation

The command processing flow follows these steps:
1. Commands are received through command FIFOs (First-In-First-Out queues)
2. Commands are validated by checking sequence IDs to ensure they are newer than previously processed commands
3. Valid commands are stored in the processor's state
4. A `Command_received_types` object is returned indicating which commands were received and processed
5. Other components of the system can then act on these commands

#### Command Sequence ID Validation

The system uses sequence IDs to ensure commands are processed in the correct order and to prevent replay attacks:

```cpp
bool Commands_processor::check_and_update_last_command_sequence_id(const Uint32 new_command_sequence_id)
{
    bool is_valid = new_command_sequence_id > state.last_controllers_command_sequence_id;
    if (is_valid)
    {
        state.last_controllers_command_sequence_id = new_command_sequence_id;
    }
    return is_valid;
}
```

This function in `Commands_processor.cpp` ensures that only commands with sequence IDs greater than the last processed command are accepted, preventing replay attacks and ensuring commands are processed in order.

### Command FIFO Mechanism

The system uses a template-based FIFO queue implementation (`Command_fifo`) to manage incoming commands:

```cpp
template <typename T, Uint16 N>
class Command_fifo
{
    // Implementation details...
};
```

Key features of the Command FIFO:
- Generic implementation that can handle different command types
- Fixed maximum size (N) specified as a template parameter
- Tracks whether commands are new with the `is_new` flag
- Provides methods to add commands (`emplace_back`) and access them
- Supports serialization and deserialization through `cset` and `cget` methods

### Command Response Generation

The system provides structured responses to commands through the `Command_response` class:

```cpp
struct Command_response : public Cyphal::CyphalStanag_rx_hnd, public Cyphal::CyphalStanag_tx_hnd
{
    Cyphal_common_types::String_cy reply_to_request_id;
    Command_response_status_code::Id status_code;
    Cyphal_common_types::String_cy status_message;
    
    // Methods...
};
```

Response status codes include:
- `success` (0): Command was successfully processed
- `rejected_integrity_check_failed` (1): Command failed integrity validation
- `rejected_invalid_command_request` (2): Command was invalid
- `rejected_incompatible_drone_state` (3): Drone state doesn't allow this command
- `rejected_drone_internal_error` (4): Internal error prevented command execution

The `Cy_command_response` class extends this functionality to handle transmission of command responses through cross-core communication:

```cpp
struct Cy_command_response: public Command_response
{
    // Implementation details...
    void step(const Command_response* cmd);
};
```

This class implements a retry mechanism that attempts to send the response multiple times with a timeout between attempts.

## 2. Control Flow and State Transitions

### Command Processing Flow

The main command processing flow is implemented in the `process_commands` method of `Commands_processor`:

| Step | Action | Next Step | Location |
|------|--------|-----------|----------|
| Start | Check for takeoff commands | Process if present | Commands_processor.cpp:process_commands |
| Process Takeoff | Validate sequence ID, store command | Check for route commands | Commands_processor.cpp:process_commands |
| Process Route | Validate sequence ID, store command | Check for airspeed modulation | Commands_processor.cpp:process_commands |
| Process Airspeed | Store command (no sequence validation) | Check for land commands | Commands_processor.cpp:process_commands |
| Process Land | Store command, update sequence ID | Return processed commands | Commands_processor.cpp:process_commands |

### Command Response Flow

The command response system follows this flow:

| State | Trigger | Actions | Next State | Location |
|-------|---------|---------|------------|----------|
| Initial | Command response needed | Fill response with request ID and status | Ready to send | Cy_command_response.cpp:step |
| Ready to send | Timer expired & attempts remaining | Send response through sender interface | Waiting for next attempt | Cy_command_response.cpp:step |
| Waiting for next attempt | Timer expired & attempts remaining | Send response again | Waiting for next attempt or Complete | Cy_command_response.cpp:step |
| Complete | All attempts used or successful send | No further action | Complete | Cy_command_response.cpp:step |

## 3. Inputs and Stimuli

### Command FIFO Inputs

The `Commands_processor::process_commands` method takes several command FIFOs as inputs:

```cpp
Command_received_types Commands_processor::process_commands(
    const Command_fifo<Commands_processor::Takeoff_command, Ku16::u1>& takeoff_command_vector,
    const Command_fifo<Commands_processor::Land_command, Ku16::u1>& land_command_vector,
    const Command_fifo<Commands_processor::Route_command_and_control, Ku16::u1>& route_command_and_control_vector,
    const Command_fifo<Commands_processor::Airspeed_modulation_command, Ku16::u1>& airspeed_modulation_command_vector,
    const State_machines_state::Mode::Controllers_mode& mode);
```

Each FIFO contains commands of a specific type:
- **Takeoff Commands**: Contains parameters like takeoff altitude and initial tracking point
- **Land Commands**: Contains landing coordinates and landing type
- **Route Commands**: Contains route information and waypoints
- **Airspeed Modulation Commands**: Contains flags to enable/disable airspeed modulation

The system also takes the current controller mode as input to determine if commands are valid in the current state.

### Command Response Inputs

The `Command_response::cset` method processes incoming command response data:

```cpp
void Command_response::cset(Base::Lossy& is)
{
    Cyphal_common_types::deserialize_string(is, reply_to_request_id);
    const Uint32 truncated_reply = Cyphal_common_types::get_truncated_id(reply_to_request_id);
    Bsp::Huvar(Pa_system_vars::reply_to_request_id_low).set(Base::Bitutils::get_u32_l(truncated_reply));
    Bsp::Huvar(Pa_system_vars::reply_to_request_id_high).set(Base::Bitutils::get_u32_h(truncated_reply));

    is.get_enum8(status_code);
    Bsp::Huvar(Pa_system_vars::status_code).set(status_code);

    Cyphal_common_types::deserialize_string(is, status_message);
}
```

This method:
- Deserializes the request ID string
- Extracts and stores the truncated request ID in system variables
- Deserializes the status code and stores it in system variables
- Deserializes the status message

### Route Deviation Commands

The system handles route deviation commands through the `Command_routes_and_deviations_params` structure, which defines several types of deviations:

```cpp
struct Route_deviation_maneuver
{
    enum Type
    {
        NO_MANEUVER = 0,
        STOP_AND_HOVER_MANEUVER = 1,
        TRACK_SPLINE_WITH_OFFSET = 2,
        HOLD_CURRENT_OFFSET = 3,
        TRACK_VTOL_ROUTE_FINAL_POINT = 4
    };
};
```

Each deviation type has specific parameters:
- **Stop and Hover**: Optional specified altitude
- **Track Spline with Offset**: Position and speed offsets in multiple dimensions
- **Track VTOL Route Final Point**: Updated final waypoint location

## 4. Outputs and Effects

### Command Processing Outputs

The primary output of the command processing system is the `Command_received_types` object:

```cpp
struct Command_received_types
{
    enum Command_received_type
    {
        NONE,
        TAKEOFF,
        LAND,
        TRACK_SPLINE
    };

    Command_received_type primary_command;
};
```

This object indicates which type of command was successfully processed and should be executed. The system can only process one primary command at a time, with the following priority:
1. Land commands (highest priority)
2. Takeoff commands
3. Route/track spline commands
4. No command (lowest priority)

### Command Response Outputs

The command response system generates structured responses through the `Command_response::cget` method:

```cpp
void Command_response::cget(Base::Lossy& os) const
{
    Cyphal_common_types::serialize_string(os, reply_to_request_id);
    os.put_uint8(status_code);
    Cyphal_common_types::serialize_string(os, status_message);
}
```

This method serializes:
- The request ID to correlate the response with the original command
- The status code indicating success or failure
- A status message providing additional details (empty for successful commands)

The `Cy_command_response::step` method sends these responses through the provided sender interface:

```cpp
if((send_dcnt > 0) && send_tout.expired())
{
    if(sender.send(Base::Msg_data(Base::Address(Ver::Stab_a::pa_id_primary0),
                                  Base::Stanag_msg_type::cyp_pa_command_response,
                                  0)))
    {
        send_dcnt--;
        send_tout.start();
    }
}
```

This ensures reliable delivery by attempting to send the response multiple times with timeouts between attempts.

### State Updates

The command processing system updates its internal state with processed commands:

```cpp
if (takeoff_command_vector.size() > 0)
{
    if (check_and_update_last_command_sequence_id(takeoff_command_vector.back().message.controller_cmd_seq_id))
    {
        commands_received.primary_command = Command_received_types::TAKEOFF;
        state.takeoff_command = takeoff_command_vector.back().message;
    }
}
```

These state updates include:
- Storing the latest valid takeoff command
- Storing the latest valid land command
- Storing the latest valid route command and control information
- Storing the latest airspeed modulation command
- Updating the last processed command sequence ID

## 5. Parameters and Configuration

### Command Processor State Parameters

The `Commands_processor::State` structure maintains the current state of the command processor:

```cpp
struct State
{
    Uint32 last_controllers_command_sequence_id;
    Uint32 last_route_deviation_command_sequence_id;
    Takeoff_command takeoff_command;
    Land_command land_command;
    Route_command_and_control route_command_and_control;
    Controls_command_processor::Route_deviation route_deviation;
    Airspeed_modulation_command airspeed_modulation_command;
};
```

Key parameters include:
- **last_controllers_command_sequence_id**: Tracks the sequence ID of the last processed command
- **last_route_deviation_command_sequence_id**: Tracks the sequence ID of the last processed route deviation
- **takeoff_command**: Stores the latest valid takeoff command
- **land_command**: Stores the latest valid land command
- **route_command_and_control**: Stores the latest valid route command
- **route_deviation**: Stores the latest valid route deviation
- **airspeed_modulation_command**: Stores the latest airspeed modulation command

### Takeoff Command Parameters

The `Takeoff_command` structure contains parameters for takeoff operations:

```cpp
struct Takeoff_command
{
    Message_id message_id;
    Uint32 controller_cmd_seq_id;
    Real takeoff_agl_m;
    Base::Tllh initial_tracking_point;
};
```

Key parameters include:
- **message_id**: Identifies the message type
- **controller_cmd_seq_id**: Sequence ID for command ordering
- **takeoff_agl_m**: Takeoff altitude above ground level in meters
- **initial_tracking_point**: Initial point to track during takeoff (latitude, longitude, height)

### Land Command Parameters

The `Land_command` structure contains parameters for landing operations:

```cpp
struct Land_command
{
    Message_id message_id;
    Uint32 controller_cmd_seq_id;
    Real64 latitude_rad;
    Real64 longitude_rad;
    bool use_backyard_frame;
    Land_command_params::Land_type land_type;
};
```

Key parameters include:
- **message_id**: Identifies the message type
- **controller_cmd_seq_id**: Sequence ID for command ordering
- **latitude_rad**: Landing latitude in radians
- **longitude_rad**: Landing longitude in radians
- **use_backyard_frame**: Flag to use backyard reference frame
- **land_type**: Type of landing (e.g., POSITION_LATCHED)

### Route Command Parameters

The `Route_command_and_control` structure contains parameters for route following:

```cpp
struct Route_command_and_control
{
    Current_route_information current_route_information;
    Route_msg route;
    bool clear_route_data;
    Uint16 controller_cmd_seq_id;
};
```

Key parameters include:
- **current_route_information**: Information about the current route
- **route**: The route message containing waypoints
- **clear_route_data**: Flag to clear existing route data
- **controller_cmd_seq_id**: Sequence ID for command ordering

### Command Response Parameters

The `Command_response` structure contains parameters for command responses:

```cpp
struct Command_response
{
    Cyphal_common_types::String_cy reply_to_request_id;
    Command_response_status_code::Id status_code;
    Cyphal_common_types::String_cy status_message;
};
```

Key parameters include:
- **reply_to_request_id**: Correlates the response with the original command
- **status_code**: Indicates success or failure with reason
- **status_message**: Provides additional details about the status

### Command FIFO Parameters

The `Command_fifo` template class is parameterized by:
- **T**: The type of command to store
- **N**: The maximum number of commands that can be stored

For all command types in the provided code, N is set to `Ku16::u1`, indicating a small FIFO size.

## 6. Error Handling and Contingency Logic

### Command Sequence Validation

The system validates command sequence IDs to prevent replay attacks and ensure commands are processed in order:

```cpp
bool Commands_processor::check_and_update_last_command_sequence_id(const Uint32 new_command_sequence_id)
{
    bool is_valid = new_command_sequence_id > state.last_controllers_command_sequence_id;
    if (is_valid)
    {
        state.last_controllers_command_sequence_id = new_command_sequence_id;
    }
    return is_valid;
}
```

If a command has a sequence ID less than or equal to the last processed command, it is rejected.

### Command Response Error Codes

The `Command_response_status_code` enumeration defines error codes for command responses:

```cpp
struct Command_response_status_code
{
    enum Id
    {
        success                             = 0,
        rejected_integrity_check_failed     = 1,
        rejected_invalid_command_request    = 2,
        rejected_incompatible_drone_state   = 3,
        rejected_drone_internal_error       = 4
    };
};
```

These codes provide detailed information about why a command was rejected:
- **rejected_integrity_check_failed**: The command failed integrity validation
- **rejected_invalid_command_request**: The command was invalid
- **rejected_incompatible_drone_state**: The drone's current state doesn't allow this command
- **rejected_drone_internal_error**: An internal error prevented command execution

### Command Response Retry Mechanism

The `Cy_command_response` class implements a retry mechanism to ensure reliable delivery of command responses:

```cpp
if((send_dcnt > 0) && send_tout.expired())
{
    if(sender.send(Base::Msg_data(Base::Address(Ver::Stab_a::pa_id_primary0),
                                  Base::Stanag_msg_type::cyp_pa_command_response,
                                  0)))
    {
        send_dcnt--;
        send_tout.start();
    }
}
```

This mechanism:
- Attempts to send the response multiple times (controlled by `send_dcnt`)
- Waits for a timeout between attempts (controlled by `send_tout`)
- Stops when either all attempts are used or the send is successful

### Command Acknowledgement Types

The `Command_acknowledgement_msg` structure defines acknowledgement types:

```cpp
struct Command_acknowledgement_msg
{
    enum Type
    {
        NONE     = 0,  ///< No command received
        ACCEPTED = 1,  ///< Command accepted
        REJECTED = 2   ///< Command rejected
    };
};
```

These types provide a simple indication of whether a command was accepted or rejected.

## 7. File-by-File Breakdown

### Commands_processor.h
- Defines the `Commands_processor` class and related structures
- Contains definitions for various command types (Takeoff, Land, Route, etc.)
- Declares the `process_commands` method for command processing
- Defines the state structure to track command processing state

### Commands_processor.cpp
- Implements the `Commands_processor` class methods
- Contains the core command processing logic in `process_commands`
- Implements sequence ID validation in `check_and_update_last_command_sequence_id`
- Initializes command structures with default values

### Command_response.h
- Defines the `Command_response` class for command responses
- Declares methods for serialization and deserialization
- Defines status codes for command responses
- Inherits from Cyphal handler classes for communication

### Command_response.cpp
- Implements the `Command_response` class methods
- Contains serialization and deserialization logic
- Implements the `fill` method to populate response fields
- Updates system variables with response information

### Command_acknowledgement_msg.h
- Defines the `Command_acknowledgement_msg` structure
- Contains simple acknowledgement types (NONE, ACCEPTED, REJECTED)
- Used for basic command acknowledgement

### Command_received_types.h
- Defines the `Command_received_types` structure
- Contains command type enumeration (NONE, TAKEOFF, LAND, TRACK_SPLINE)
- Used to indicate which commands were received and processed

### Command_received_types.cpp
- Implements the `Command_received_types` constructor
- Initializes the primary command to NONE

### Command_fifo.h
- Defines the template-based `Command_fifo` class
- Implements a FIFO queue for command storage
- Provides methods to add, access, and clear commands
- Supports serialization and deserialization

### Command_routes_and_deviations_params.h
- Defines structures for route deviation commands
- Contains deviation types (NO_MANEUVER, STOP_AND_HOVER, etc.)
- Defines parameters for each deviation type

### Command_routes_and_deviations_params.cpp
- Implements constructors for deviation parameter structures
- Contains deserialization logic for deviation parameters
- Initializes parameters with default values

### Command_route_entries.h
- Defines the `Command_route_entries` class
- Inherits from `Shallow_copy_array<Command_route_entry>`
- Used to store multiple route entries

### Command_route_entries.cpp
- Implements the `Command_route_entries` constructor
- Sets up the array for route entries

### Command_route_entry.h
- Defines the `Command_route_entry` structure
- Contains route ID, flight ID, and maneuvers
- Used to represent a single route entry

### Command_route_entry.cpp
- Implements the `Command_route_entry` constructor and reset method
- Initializes route entry fields with default values

### Cy_command_response.h
- Defines the `Cy_command_response` class
- Extends `Command_response` with transmission capabilities
- Implements a retry mechanism for reliable delivery

### Cy_command_response.cpp
- Implements the `Cy_command_response` class methods
- Contains the step method for response transmission
- Implements the retry logic with timeout and counter

## 8. Cross-Component Relationships

### Command Processing and Command FIFOs

The `Commands_processor` class processes commands from multiple `Command_fifo` instances:

```cpp
Command_received_types Commands_processor::process_commands(
    const Command_fifo<Commands_processor::Takeoff_command, Ku16::u1>& takeoff_command_vector,
    const Command_fifo<Commands_processor::Land_command, Ku16::u1>& land_command_vector,
    const Command_fifo<Commands_processor::Route_command_and_control, Ku16::u1>& route_command_and_control_vector,
    const Command_fifo<Commands_processor::Airspeed_modulation_command, Ku16::u1>& airspeed_modulation_command_vector,
    const State_machines_state::Mode::Controllers_mode& mode);
```

This relationship allows the processor to receive commands from multiple sources and process them according to priority.

### Command Processing and Command Responses

The command processing system generates responses through the `Command_response` class:

```cpp
void Command_response::fill(const Cyphal_common_types::String_cy& reply, Command_response_status_code::Id st)
{
    Cyphal_common_types::copy_string(reply, reply_to_request_id);
    status_code = st;
    status_message.resize(0U);
}
```

These responses are then transmitted through the `Cy_command_response` class:

```cpp
void Cy_command_response::step(const Command_response* cmd)
{
    if(cmd)
    {
        if(to_fill)
        {
            fill(cmd->reply_to_request_id, cmd->status_code);
            to_fill = false;
        }
        
        // Transmission logic...
    }
}
```

This relationship ensures that commands are acknowledged and their status is reported back to the sender.

### Route Commands and Route Entries

Route commands are processed through the `Route_command_and_control` structure:

```cpp
struct Route_command_and_control
{
    Current_route_information current_route_information;
    Route_msg route;
    bool clear_route_data;
    Uint16 controller_cmd_seq_id;
};
```

These commands reference route entries stored in `Command_route_entries`:

```cpp
class Command_route_entries : public Shallow_copy_array<Command_route_entry>
{
    // Implementation...
};
```

This relationship allows the system to store and process complex route information with multiple waypoints and maneuvers.

### Command Processing and System State

The command processor maintains state through the `Commands_processor::State` structure:

```cpp
struct State
{
    Uint32 last_controllers_command_sequence_id;
    Uint32 last_route_deviation_command_sequence_id;
    Takeoff_command takeoff_command;
    Land_command land_command;
    Route_command_and_control route_command_and_control;
    Controls_command_processor::Route_deviation route_deviation;
    Airspeed_modulation_command airspeed_modulation_command;
};
```

This state is updated during command processing and referenced by other components to determine what actions to take.

### Command Responses and System Variables

Command responses update system variables through the `Command_response::cset` method:

```cpp
void Command_response::cset(Base::Lossy& is)
{
    Cyphal_common_types::deserialize_string(is, reply_to_request_id);
    const Uint32 truncated_reply = Cyphal_common_types::get_truncated_id(reply_to_request_id);
    Bsp::Huvar(Pa_system_vars::reply_to_request_id_low).set(Base::Bitutils::get_u32_l(truncated_reply));
    Bsp::Huvar(Pa_system_vars::reply_to_request_id_high).set(Base::Bitutils::get_u32_h(truncated_reply));

    is.get_enum8(status_code);
    Bsp::Huvar(Pa_system_vars::status_code).set(status_code);

    Cyphal_common_types::deserialize_string(is, status_message);
}
```

This relationship allows other components to monitor command response status through system variables.

## 9. Referenced Context Files

The following context files provided useful information for understanding the command processing system:

- **Communication Systems Documentation**: Provided insights into how the command processing system interfaces with the communication system
  - Explained the role of Cyphal in command transmission and reception
  - Detailed how commands are received from ground systems
  - Showed how command responses are transmitted back to ground systems

This context helped establish how the command processing system fits into the broader drone architecture, particularly how it interfaces with the communication systems to receive commands from ground control and send responses back.