# Generated from:

- items/pdi_Recovery1/setup/ver_spdif_amz_site_config.xml (165 tokens)
- items/pdi_Recovery1/setup/ver_spdif_amz_radio_dyn.xml (145 tokens)
- items/pdi_Recovery1/setup/ver_spdif_amz_radio_st.xml (64 tokens)
- items/pdi_Recovery1/setup/ver_spdif_amz_radio_sync.xml (80 tokens)
- items/pdi_Recovery1/setup/ver_spdif_amz_lights.xml (81 tokens)
- items/pdi_Recovery1/setup/ver_spdif_amz_activated_prescription_config.xml (95 tokens)
- items/pdi_Recovery1/setup/Cage Flight/ver_spdif_fmset.xml (3053 tokens)
- items/pdi_Recovery1/setup/Cage Flight/ver_spdif_fmsg_p.xml (158 tokens)
- items/pdi_Recovery1/setup/SingleRPM/ver_spdif_fmset.xml (3053 tokens)
- items/pdi_Recovery1/setup/SingleRPM/ver_spdif_fmsg_p.xml (232 tokens)
- items/pdi_Recovery1/setup/Replay Mode/ver_spdif_mbit.xml (1816 tokens)
- items/pdi_Recovery1/setup/Replay Mode/ver_spdif_xpccan.xml (105 tokens)
- items/pdi_Recovery1/setup/Replay Mode/ver_spdif_varini.xml (164 tokens)
- items/pdi_Recovery1/setup/Replay Mode/ver_spdif_can_fd_a.xml (788 tokens)

---

# Amazon PDI Recovery1 System Configuration Analysis

This document provides a comprehensive analysis of the Amazon-specific configuration files for the PDI Recovery1 drone system, focusing on site configuration, radio communication, lighting systems, prescription management, and flight modes.

## 1. System Overview and Version Information

The PDI Recovery1 system uses a consistent versioning scheme across all configuration files:
- Major version: 7
- Minor version: 3
- Revision: 1

This indicates a unified configuration package with all components designed to work together at the same version level.

### 1.1 Core Configuration Files

The system includes several core configuration files that define the fundamental behavior of the drone:

| File | ID | Purpose |
|------|----|----|
| amz_site_config.bin | 495 | Site-specific configuration parameters |
| amz_radio_dyn.bin | 493 | Dynamic radio configuration |
| amz_radio_st.bin | 490 | Static radio configuration |
| amz_radio_sync.bin | 492 | Radio synchronization parameters |
| amz_lights.bin | 486 | Lighting system configuration |
| amz_activated_prescription_config.bin | 494 | Active prescription management |

## 2. Site Configuration

The site configuration (`ver_spdif_amz_site_config.xml`) defines location-specific parameters for the drone operation.

### 2.1 Persistent PDI Data

```xml
<persistent_pdi_data>
    <is_persistent_pdi>1</is_persistent_pdi>
    <is_pdi_config_valid>1</is_pdi_config_valid>
</persistent_pdi_data>
```

- `is_persistent_pdi` set to 1 indicates that PDI (Payload Data Interface) data should be preserved across system restarts
- `is_pdi_config_valid` set to 1 confirms that the PDI configuration is valid and can be used

### 2.2 Site Identification

```xml
<site_config_guid>UNKNOWN</site_config_guid>
<operating_region>UNKNOWN</operating_region>
<operator_registration_number>UNKNOWN</operator_registration_number>
```

These fields are placeholders that would be populated with specific site information:
- Site configuration globally unique identifier
- Geographic operating region
- Operator registration number for regulatory compliance

### 2.3 Navigation Parameters

```xml
<nav_init_heading_degrees>0</nav_init_heading_degrees>
```

This parameter sets the initial heading reference for the navigation system to 0 degrees.

## 3. Radio Communication Configuration

The radio system is configured through multiple files that handle different aspects of radio operation.

### 3.1 Dynamic Radio Configuration (`ver_spdif_amz_radio_dyn.xml`)

```xml
<is_persistent_pdi>1</is_persistent_pdi>
<freq_table/>
<reg_values/>
<call_sign>
    <reg>0</reg>
    <value/>
</call_sign>
```

- Marked as persistent PDI data
- Contains empty placeholders for frequency table and register values
- Includes a call sign structure with register 0 and empty value

### 3.2 Static Radio Configuration (`ver_spdif_amz_radio_st.xml`)

```xml
<reg_values/>
```

Contains an empty placeholder for register values that would define static radio parameters.

### 3.3 Radio Synchronization (`ver_spdif_amz_radio_sync.xml`)

```xml
<ts>100</ts>
<tg>0</tg>
<t_cmd_offset>200</t_cmd_offset>
```

These parameters define the timing for radio synchronization:
- `ts`: Synchronization time parameter set to 100 (likely milliseconds)
- `tg`: Time gap parameter set to 0
- `t_cmd_offset`: Command offset time set to 200 (likely milliseconds)

These timing parameters are critical for ensuring proper communication between the drone and ground control systems, establishing the protocol for message transmission and reception.

## 4. Lighting System Configuration

The lighting system configuration (`ver_spdif_amz_lights.xml`) contains empty placeholders for:

```xml
<config/>
<light-states-left/>
<light-states-right/>
<sequences/>
```

These would normally contain:
- General configuration parameters for the lighting system
- State definitions for left-side lights
- State definitions for right-side lights
- Sequence definitions for light patterns (likely for signaling different drone states)

## 5. Prescription Configuration

The activated prescription configuration (`ver_spdif_amz_activated_prescription_config.xml`) contains:

```xml
<activated-prescription-filename>UNKNOWN</activated-prescription-filename>
```

This is a placeholder for the filename of the currently active prescription. In a deployed system, this would reference a specific prescription file that defines mission parameters or operational constraints.

## 6. Flight Modes

The PDI Recovery1 system includes three distinct flight modes, each with its own configuration files:

1. Cage Flight
2. SingleRPM
3. Replay Mode

### 6.1 Cage Flight Mode

Cage Flight mode is configured through two primary files:

#### 6.1.1 Flight Mode Settings (`Cage Flight/ver_spdif_fmset.xml`)

This file contains detailed binary protocol definitions for flight control communication. Key elements include:

- Matcher configurations with specific bit patterns (e.g., value 193 with mask 255)
- Skip configurations for binary protocol parsing
- Real-ibits configurations for control parameters with ranges from -8192.0 to 8191.0
- Integer parameters with specific ranges (e.g., ID 1000 with range 0.0-3.0)

The configuration includes two main array elements:
1. First element with endianness 2 (likely big-endian), time 1.0, offset 0.0
2. Second element with endianness 1 (likely little-endian), time 0.01, offset 0.0

These different timing parameters suggest different update rates for different types of control data.

#### 6.1.2 Flight Message Parameters (`Cage Flight/ver_spdif_fmsg_p.xml`)

This file contains empty data arrays for four message categories (keys 0-3), suggesting that Cage Flight mode doesn't use flight messages or uses default values.

### 6.2 SingleRPM Mode

SingleRPM mode has a similar structure to Cage Flight mode:

#### 6.2.1 Flight Mode Settings (`SingleRPM/ver_spdif_fmset.xml`)

The configuration is identical to Cage Flight mode, suggesting that the binary protocol and control parameter definitions are the same.

#### 6.2.2 Flight Message Parameters (`SingleRPM/ver_spdif_fmsg_p.xml`)

Unlike Cage Flight mode, SingleRPM mode defines a flight message in the first category (key 0):

```xml
<str-tunarray-element>
    <fmsg-id>1</fmsg-id>
    <time>0.0</time>
    <type>0</type>
    <bitid>0</bitid>
    <triggers_ev>0</triggers_ev>
</str-tunarray-element>
```

This message has:
- Message ID: 1
- Time: 0.0 (likely indicating it should be sent immediately)
- Type: 0
- Bit ID: 0
- Trigger event flag: 0 (does not trigger an event)

### 6.3 Replay Mode

Replay Mode has the most complex configuration with four configuration files:

#### 6.3.1 Message Bit Definitions (`Replay Mode/ver_spdif_mbit.xml`)

This file defines a comprehensive set of message bits (IDs 1200-1327) with descriptions for various system states and commands:

Key message bits include:
- 1300: is_onground
- 1301: control status
- 1302: do switchover
- 1306: recovery is in control
- 1307: recovery tracking has started
- 1310: recovery takeoff executed
- 1327: Enable Replay Mode

These bits represent system states and commands that are particularly relevant to the recovery and replay functionality.

#### 6.3.2 CAN Communication Configuration (`Replay Mode/ver_spdif_xpccan.xml`)

```xml
<str-tunarray-element>
    <producer>9</producer>
    <consumer>18</consumer>
    <group>1</group>
    <enable-bvar>1</enable-bvar>
</str-tunarray-element>
```

This defines a CAN communication channel with:
- Producer ID: 9
- Consumer ID: 18
- Group: 1
- Enable bit variable: 1 (enabled)

#### 6.3.3 Variable Initialization (`Replay Mode/ver_spdif_varini.xml`)

```xml
<str-tunarray-element>
    <vtype>0</vtype>
    <id>3200</id>
    <val0>150.0</val0>
</str-tunarray-element>
<str-tunarray-element>
    <vtype>2</vtype>
    <id>1117</id>
    <val0>3.0</val0>
</str-tunarray-element>
<str-tunarray-element>
    <vtype>3</vtype>
    <id>1327</id>
    <val0>1.0</val0>
</str-tunarray-element>
```

This initializes three variables:
- ID 3200 (type 0): Value 150.0
- ID 1117 (type 2): Value 3.0
- ID 1327 (type 3): Value 1.0 (corresponds to "Enable Replay Mode" from the mbit definitions)

#### 6.3.4 CAN FD Configuration (`Replay Mode/ver_spdif_can_fd_a.xml`)

This file configures the CAN FD (Flexible Data-rate) communication:

```xml
<can_fd_mode>1</can_fd_mode>
<enable_brs>1</enable_brs>
```

- CAN FD mode is enabled (1)
- Bit Rate Switching is enabled (1)

Arbitration phase configuration:
```xml
<arb>
    <use_timings>0</use_timings>
    <baudrate>3</baudrate>
    <tim>
        <prescaler>49</prescaler>
        <tseg1>4</tseg1>
        <tseg2>1</tseg2>
        <sjw>1</sjw>
    </tim>
</arb>
```

Data phase configuration:
```xml
<data>
    <use_timings>0</use_timings>
    <baudrate>6</baudrate>
    <tim>
        <prescaler>9</prescaler>
        <tseg1>5</tseg1>
        <tseg2>2</tseg2>
        <sjw>2</sjw>
    </tim>
</data>
```

The file also defines seven receive filters for specific CAN message IDs, all using extended IDs (29-bit) with specific masks:

| Size | Extended ID | Mask |
|------|------------|------|
| 9 | 274754081 | 1048320 |
| 9 | 274756129 | 1048320 |
| 1 | 274850849 | 1048320 |
| 1 | 274834721 | 1048320 |
| 1 | 274848801 | 1048320 |
| 2 | 274835745 | 1048320 |
| 4 | 274817825 | 1048320 |

## 7. Flight Mode Transitions and Control Flow

Based on the configuration files, we can infer the following about flight mode transitions and control flow:

### 7.1 Mode Selection and Activation

The system appears to support three distinct flight modes that can be selected based on operational requirements:

1. **Cage Flight Mode**: Likely a restricted flight mode with limited movement, possibly for testing or indoor operation.

2. **SingleRPM Mode**: Possibly a mode where all motors run at a single RPM setting, which could be used for testing motor functionality or for specific flight behaviors.

3. **Replay Mode**: A specialized mode that can replay previously recorded flight paths or commands, enabled by setting bit 1327 to 1.

### 7.2 Radio Communication Flow

The radio communication system follows this general flow:

1. System initializes with static radio parameters from `amz_radio_st.bin`
2. Dynamic radio parameters from `amz_radio_dyn.bin` are applied
3. Radio synchronization parameters from `amz_radio_sync.xml` establish timing:
   - `ts` (100) defines the synchronization time
   - `tg` (0) defines the time gap
   - `t_cmd_offset` (200) defines the command offset time

### 7.3 Recovery System Integration

The message bit definitions in Replay Mode suggest a sophisticated recovery system with states for:
- Ground detection (`is_onground`)
- Control status tracking
- System switchover capability
- Recovery tracking
- Takeoff execution

The recovery system appears to have a sequence of operations:
1. Recovery arming (bits 1308, 1309)
2. Initial tracking point setting (bit 1311)
3. Pre-takeoff command (bit 1317)
4. Takeoff execution (bit 1310)
5. Tracking start (bit 1307)

## 8. Key Parameters Affecting System Operation

Several critical parameters across the configuration files directly impact system behavior:

### 8.1 Radio Timing Parameters

- `ts` (100): Affects synchronization timing between drone and ground control
- `t_cmd_offset` (200): Determines command processing delay

### 8.2 Flight Control Parameters

- Real-ibits parameters (IDs 3100-3105): Control parameters with ranges from -8192.0 to 8191.0
- Integer parameters (IDs 1000-1002): Control mode selectors with specific ranges

### 8.3 CAN Communication Parameters

- Baudrate settings (3 for arbitration, 6 for data): Determine communication speed
- Filter IDs: Determine which messages are processed by the system

### 8.4 Replay Mode Parameters

- Variable 3200 (value 150.0): Likely a threshold or timing parameter
- Variable 1117 (value 3.0): Possibly a mode selector or parameter
- Variable 1327 (value 1.0): Enables Replay Mode

## 9. System Architecture Integration

The configuration files reveal how these components integrate into the broader system architecture:

1. **Site Configuration**: Provides the foundation with site-specific parameters and navigation initialization

2. **Radio System**: Forms the communication backbone with:
   - Static parameters for basic operation
   - Dynamic parameters for adaptive communication
   - Synchronization parameters for timing coordination

3. **Flight Modes**: Provide specialized behavior profiles:
   - Cage Flight: Restricted operation
   - SingleRPM: Simplified motor control
   - Replay Mode: Advanced replay capabilities with CAN integration

4. **Recovery System**: Integrated through message bits and state tracking, with specific sequences for recovery operations

5. **CAN Communication**: Provides high-speed data exchange, particularly important for Replay Mode operation

The architecture follows a layered approach with:
- Base configuration (site, radio)
- Operational modes (flight modes)
- Communication infrastructure (radio sync, CAN)
- Specialized functionality (recovery, replay)

This modular design allows for flexible configuration while maintaining system integrity through consistent versioning across all components.