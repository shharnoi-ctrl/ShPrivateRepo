# Generated from:

- include/gtest/gtest.h (22864 tokens)
- include/gtest/gtest-assertion-result.h (2125 tokens)
- include/gtest/gtest-message.h (2300 tokens)
- include/gtest/gtest-test-part.h (1791 tokens)
- include/gtest/gtest_pred_impl.h (3195 tokens)
- include/gtest/gtest_prod.h (625 tokens)

---

# Google Test Framework: Comprehensive Overview

## 1. Core Framework Architecture

Google Test (gtest) is a C++ testing framework that provides a rich set of assertions, test fixtures, and test organization capabilities. The framework is built around several key abstractions that work together to enable effective testing.

### Key Classes and Their Responsibilities

#### `Test` Class
```cpp
class Test {
public:
  virtual ~Test();
  
  // Test fixture setup/teardown - per test case
  static void SetUpTestSuite();
  static void TearDownTestSuite();
  
  // Test setup/teardown - per test
  virtual void SetUp();
  virtual void TearDown();
  
  // Test status checking
  static bool HasFatalFailure();
  static bool HasNonfatalFailure();
  static bool IsSkipped();
  static bool HasFailure();
  
  // Test property recording
  static void RecordProperty(const std::string& key, const std::string& value);
  
protected:
  Test();
  
private:
  virtual void TestBody() = 0; // Implemented by TEST/TEST_F macros
};
```

The `Test` class is the base class for all test fixtures. It provides:
- Virtual `SetUp()` and `TearDown()` methods that are called before and after each test
- Static `SetUpTestSuite()` and `TearDownTestSuite()` methods for suite-wide setup/teardown
- Methods to check test status (`HasFatalFailure()`, `HasNonfatalFailure()`, etc.)
- Property recording for test metadata

#### `TestInfo` Class
```cpp
class TestInfo {
public:
  // Accessors
  const char* test_suite_name() const;
  const char* name() const;
  const char* type_param() const;  // For typed/parameterized tests
  const char* value_param() const; // For value-parameterized tests
  const char* file() const;
  int line() const;
  bool should_run() const;
  bool is_reportable() const;
  const TestResult* result() const;
  
private:
  // Test metadata
  const std::string test_suite_name_;
  const std::string name_;
  internal::CodeLocation location_;
  bool should_run_;
  bool is_disabled_;
  bool matches_filter_;
  bool is_in_another_shard_;
  internal::TestFactoryBase* const factory_;
  TestResult result_;
};
```

`TestInfo` represents metadata about a single test:
- Test name and test suite name
- Source file location
- Test parameters (for parameterized tests)
- Test execution status and results
- Factory for creating test instances

#### `TestSuite` Class
```cpp
class TestSuite {
public:
  // Accessors
  const char* name() const;
  const char* type_param() const;
  bool should_run() const;
  
  // Test counting methods
  int successful_test_count() const;
  int skipped_test_count() const;
  int failed_test_count() const;
  int disabled_test_count() const;
  int reportable_test_count() const;
  int test_to_run_count() const;
  int total_test_count() const;
  
  // Status methods
  bool Passed() const;
  bool Failed() const;
  TimeInMillis elapsed_time() const;
  
  // Access to individual tests
  const TestInfo* GetTestInfo(int i) const;
  
private:
  std::string name_;
  std::vector<TestInfo*> test_info_list_;
  internal::SetUpTestSuiteFunc set_up_tc_;
  internal::TearDownTestSuiteFunc tear_down_tc_;
  bool should_run_;
  TimeInMillis elapsed_time_;
  TestResult ad_hoc_test_result_;
};
```

`TestSuite` groups related tests together:
- Contains a collection of `TestInfo` objects
- Tracks suite-wide statistics (pass/fail counts, execution time)
- Manages suite-wide setup and teardown
- Provides access to individual tests

#### `UnitTest` Class (Singleton)
```cpp
class UnitTest {
public:
  // Singleton access
  static UnitTest* GetInstance();
  
  // Test execution
  int Run();
  
  // Environment access
  Environment* AddEnvironment(Environment* env);
  
  // Test suite access
  const TestSuite* GetTestSuite(int i) const;
  int total_test_suite_count() const;
  
  // Test counting methods
  int successful_test_count() const;
  int failed_test_count() const;
  int disabled_test_count() const;
  int total_test_count() const;
  
  // Status methods
  bool Passed() const;
  bool Failed() const;
  
  // Event listeners
  TestEventListeners& listeners();
  
private:
  // Test registration and reporting
  void AddTestPartResult(TestPartResult::Type result_type,
                         const char* file_name, int line_number,
                         const std::string& message,
                         const std::string& os_stack_trace);
  void RecordProperty(const std::string& key, const std::string& value);
};
```

`UnitTest` is the singleton that manages the entire test program:
- Maintains the collection of all test suites
- Provides global test statistics
- Manages test environments
- Coordinates test execution
- Handles command-line flags and configuration

#### `TestResult` Class
```cpp
class TestResult {
public:
  TestResult();
  ~TestResult();
  
  // Test part counting
  int total_part_count() const;
  int test_property_count() const;
  
  // Status methods
  bool Passed() const;
  bool Skipped() const;
  bool Failed() const;
  bool HasFatalFailure() const;
  bool HasNonfatalFailure() const;
  
  // Timing
  TimeInMillis elapsed_time() const;
  TimeInMillis start_timestamp() const;
  
  // Access to test parts and properties
  const TestPartResult& GetTestPartResult(int i) const;
  const TestProperty& GetTestProperty(int i) const;
  
private:
  std::vector<TestPartResult> test_part_results_;
  std::vector<TestProperty> test_properties_;
  int death_test_count_;
  TimeInMillis start_timestamp_;
  TimeInMillis elapsed_time_;
};
```

`TestResult` tracks the outcome of a test:
- Collects test part results (assertions)
- Stores test properties
- Tracks execution time
- Provides status information (pass/fail/skip)

#### `TestPartResult` Class
```cpp
class TestPartResult {
public:
  enum Type {
    kSuccess,          // Succeeded
    kNonFatalFailure,  // Failed but test continues (EXPECT_*)
    kFatalFailure,     // Failed and test aborts (ASSERT_*)
    kSkip              // Test skipped
  };
  
  TestPartResult(Type a_type, const char* a_file_name, 
                 int a_line_number, const char* a_message);
  
  // Accessors
  Type type() const;
  const char* file_name() const;
  int line_number() const;
  const char* summary() const;
  const char* message() const;
  
  // Status methods
  bool skipped() const;
  bool passed() const;
  bool nonfatally_failed() const;
  bool fatally_failed() const;
  bool failed() const;
};
```

`TestPartResult` represents the result of a single assertion:
- Type of result (success, non-fatal failure, fatal failure, skip)
- Source file location
- Failure message
- Status methods to check the outcome

## 2. Assertion Mechanism

Google Test provides a rich set of assertions that are the building blocks of tests. The assertion system is built around macros that generate appropriate code to check conditions and report failures.

### Assertion Types

1. **Basic Assertions**:
   - `ASSERT_TRUE(condition)` / `EXPECT_TRUE(condition)`
   - `ASSERT_FALSE(condition)` / `EXPECT_FALSE(condition)`

2. **Binary Comparisons**:
   - `ASSERT_EQ(val1, val2)` / `EXPECT_EQ(val1, val2)` - Equal
   - `ASSERT_NE(val1, val2)` / `EXPECT_NE(val1, val2)` - Not equal
   - `ASSERT_LT(val1, val2)` / `EXPECT_LT(val1, val2)` - Less than
   - `ASSERT_LE(val1, val2)` / `EXPECT_LE(val1, val2)` - Less than or equal
   - `ASSERT_GT(val1, val2)` / `EXPECT_GT(val1, val2)` - Greater than
   - `ASSERT_GE(val1, val2)` / `EXPECT_GE(val1, val2)` - Greater than or equal

3. **String Comparisons**:
   - `ASSERT_STREQ(s1, s2)` / `EXPECT_STREQ(s1, s2)` - C strings equal
   - `ASSERT_STRNE(s1, s2)` / `EXPECT_STRNE(s1, s2)` - C strings not equal
   - `ASSERT_STRCASEEQ(s1, s2)` / `EXPECT_STRCASEEQ(s1, s2)` - Case-insensitive equal
   - `ASSERT_STRCASENE(s1, s2)` / `EXPECT_STRCASENE(s1, s2)` - Case-insensitive not equal

4. **Floating Point Comparisons**:
   - `ASSERT_FLOAT_EQ(val1, val2)` / `EXPECT_FLOAT_EQ(val1, val2)`
   - `ASSERT_DOUBLE_EQ(val1, val2)` / `EXPECT_DOUBLE_EQ(val1, val2)`
   - `ASSERT_NEAR(val1, val2, abs_error)` / `EXPECT_NEAR(val1, val2, abs_error)`

5. **Exception Assertions**:
   - `ASSERT_THROW(statement, exception_type)` / `EXPECT_THROW(statement, exception_type)`
   - `ASSERT_ANY_THROW(statement)` / `EXPECT_ANY_THROW(statement)`
   - `ASSERT_NO_THROW(statement)` / `EXPECT_NO_THROW(statement)`

6. **Predicate Assertions**:
   - `ASSERT_PRED1(pred, val1)` / `EXPECT_PRED1(pred, val1)`
   - `ASSERT_PRED2(pred, val1, val2)` / `EXPECT_PRED2(pred, val1, val2)`
   - `ASSERT_PRED_FORMAT1(pred_format, val1)` / `EXPECT_PRED_FORMAT1(pred_format, val1)`

### Assertion Implementation

The assertion mechanism works through a series of macros and helper functions:

1. **Macro Expansion**: When an assertion macro is used, it expands to code that:
   - Evaluates the condition
   - Creates appropriate messages
   - Reports success or failure

2. **Fatal vs. Non-Fatal**: 
   - `ASSERT_*` macros cause fatal failures that abort the current test
   - `EXPECT_*` macros cause non-fatal failures that allow the test to continue

3. **Reporting Chain**:
   - Assertion failures create `TestPartResult` objects
   - These are added to the current test's `TestResult`
   - Failures are reported through the test event listeners

### Example of Assertion Implementation

```cpp
// Simplified version of how EXPECT_EQ works internally
#define EXPECT_EQ(val1, val2) \
  EXPECT_PRED_FORMAT2(::testing::internal::EqHelper::Compare, val1, val2)

// Helper function that creates the appropriate failure message
template <typename T1, typename T2>
AssertionResult CmpHelperEQ(const char* lhs_expression,
                           const char* rhs_expression,
                           const T1& lhs, const T2& rhs) {
  if (lhs == rhs) {
    return AssertionSuccess();
  }
  
  return AssertionFailure()
         << "Expected equality of these values:\n"
         << "  " << lhs_expression << "\n"
         << "    Which is: " << lhs << "\n"
         << "  " << rhs_expression << "\n"
         << "    Which is: " << rhs;
}
```

## 3. Test Registration and Execution Flow

### Test Registration

Tests are registered with the framework through macros that create test classes and register them with the `UnitTest` singleton:

1. **Simple Tests**:
   ```cpp
   TEST(TestSuiteName, TestName) {
     // Test body
   }
   ```

   This expands to:
   - A class definition for a test that inherits from `::testing::Test`
   - An implementation of the `TestBody()` method
   - Registration of the test with the framework

2. **Fixture Tests**:
   ```cpp
   class MyFixture : public ::testing::Test {
   protected:
     void SetUp() override { /* setup code */ }
     void TearDown() override { /* teardown code */ }
     // Fixture members
   };
   
   TEST_F(MyFixture, TestName) {
     // Test body with access to fixture
   }
   ```

   This creates a test that:
   - Inherits from the specified fixture class
   - Gets access to the fixture's members and methods
   - Automatically calls `SetUp()` and `TearDown()`

3. **Registration Mechanism**:
   - Tests are registered during static initialization
   - The `internal::MakeAndRegisterTestInfo()` function creates a `TestInfo` object
   - The `TestInfo` is added to the appropriate `TestSuite`
   - The `TestSuite` is added to the `UnitTest` singleton

### Test Execution Flow

When `RUN_ALL_TESTS()` is called, the following sequence occurs:

1. **Initialization**:
   - Command-line flags are processed
   - Test filters are applied
   - Random seed is set (if shuffling is enabled)

2. **Environment Setup**:
   - Global test environments are set up

3. **Test Suite Iteration**:
   - For each test suite that has tests to run:
     - Call `SetUpTestSuite()`
     - Run each enabled test in the suite
     - Call `TearDownTestSuite()`

4. **Individual Test Execution**:
   - For each test:
     - Create a new instance of the test class
     - Call `SetUp()`
     - Call `TestBody()` (the actual test code)
     - Call `TearDown()`
     - Delete the test instance
     - Record the test result

5. **Environment Teardown**:
   - Global test environments are torn down

6. **Result Reporting**:
   - Test results are reported through listeners
   - XML output is generated (if requested)
   - Return code is determined (0 for success, non-zero for failure)

### Example Test Execution Flow

```cpp
// User code
TEST(MathTest, Addition) {
  EXPECT_EQ(2 + 2, 4);
}

TEST(MathTest, Subtraction) {
  EXPECT_EQ(4 - 2, 2);
}

int main(int argc, char** argv) {
  ::testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}
```

Execution flow:
1. `InitGoogleTest()` processes command-line arguments
2. `RUN_ALL_TESTS()` is called
3. The `MathTest` test suite is identified
4. `MathTest::SetUpTestSuite()` is called (default empty implementation)
5. For the `Addition` test:
   - A new `MathTest_Addition_Test` instance is created
   - `SetUp()` is called
   - `TestBody()` runs the `EXPECT_EQ(2 + 2, 4)` assertion
   - `TearDown()` is called
   - The test instance is deleted
6. For the `Subtraction` test:
   - A new `MathTest_Subtraction_Test` instance is created
   - `SetUp()` is called
   - `TestBody()` runs the `EXPECT_EQ(4 - 2, 2)` assertion
   - `TearDown()` is called
   - The test instance is deleted
7. `MathTest::TearDownTestSuite()` is called
8. Results are reported
9. `RUN_ALL_TESTS()` returns 0 (success)

## 4. Event Listeners and Result Reporting

Google Test provides an event listener mechanism to observe and respond to test events:

```cpp
class TestEventListener {
public:
  virtual ~TestEventListener() = default;
  
  // Program-level events
  virtual void OnTestProgramStart(const UnitTest& unit_test) = 0;
  virtual void OnTestIterationStart(const UnitTest& unit_test, int iteration) = 0;
  virtual void OnTestProgramEnd(const UnitTest& unit_test) = 0;
  virtual void OnTestIterationEnd(const UnitTest& unit_test, int iteration) = 0;
  
  // Environment events
  virtual void OnEnvironmentsSetUpStart(const UnitTest& unit_test) = 0;
  virtual void OnEnvironmentsSetUpEnd(const UnitTest& unit_test) = 0;
  virtual void OnEnvironmentsTearDownStart(const UnitTest& unit_test) = 0;
  virtual void OnEnvironmentsTearDownEnd(const UnitTest& unit_test) = 0;
  
  // Test suite events
  virtual void OnTestSuiteStart(const TestSuite& test_suite) = 0;
  virtual void OnTestSuiteEnd(const TestSuite& test_suite) = 0;
  
  // Test events
  virtual void OnTestStart(const TestInfo& test_info) = 0;
  virtual void OnTestEnd(const TestInfo& test_info) = 0;
  virtual void OnTestDisabled(const TestInfo& test_info) = 0;
  virtual void OnTestPartResult(const TestPartResult& test_part_result) = 0;
};
```

The framework includes built-in listeners:
- `DefaultResultPrinter`: Outputs test results to the console
- `XmlUnitTestResultPrinter`: Generates XML reports

Custom listeners can be added to extend the framework's functionality:

```cpp
class CustomListener : public ::testing::EmptyTestEventListener {
public:
  void OnTestStart(const ::testing::TestInfo& test_info) override {
    std::cout << "Starting test: " << test_info.name() << std::endl;
  }
  
  void OnTestPartResult(const ::testing::TestPartResult& result) override {
    if (result.failed()) {
      std::cout << "Failure in " << result.file_name() << ":" 
                << result.line_number() << std::endl;
      std::cout << result.message() << std::endl;
    }
  }
};

int main(int argc, char** argv) {
  ::testing::InitGoogleTest(&argc, argv);
  ::testing::UnitTest::GetInstance()->listeners().Append(new CustomListener);
  return RUN_ALL_TESTS();
}
```

## 5. Usage Examples

### Basic Test

```cpp
#include "gtest/gtest.h"

// Function to test
int Add(int a, int b) {
  return a + b;
}

// Simple test
TEST(MathTest, AdditionWorks) {
  EXPECT_EQ(Add(2, 3), 5);
  EXPECT_EQ(Add(-1, 1), 0);
  EXPECT_EQ(Add(0, 0), 0);
}

int main(int argc, char** argv) {
  ::testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}
```

### Test Fixture

```cpp
#include "gtest/gtest.h"
#include <vector>

// Test fixture for vector tests
class VectorTest : public ::testing::Test {
protected:
  void SetUp() override {
    // Called before each test
    v1_.push_back(1);
    v1_.push_back(2);
    
    v2_.push_back(10);
    v2_.push_back(20);
  }
  
  void TearDown() override {
    // Called after each test
    // (Usually not needed for simple cases like this)
  }
  
  // Objects accessible to all tests using this fixture
  std::vector<int> v1_;
  std::vector<int> v2_;
};

// Test using the fixture
TEST_F(VectorTest, SizeIsCorrect) {
  EXPECT_EQ(v1_.size(), 2U);
  EXPECT_EQ(v2_.size(), 2U);
}

TEST_F(VectorTest, ElementsAreCorrect) {
  EXPECT_EQ(v1_[0], 1);
  EXPECT_EQ(v1_[1], 2);
  
  EXPECT_EQ(v2_[0], 10);
  EXPECT_EQ(v2_[1], 20);
}
```

### Parameterized Tests

```cpp
#include "gtest/gtest.h"

// Function to test
bool IsPrime(int n) {
  if (n <= 1) return false;
  if (n <= 3) return true;
  if (n % 2 == 0 || n % 3 == 0) return false;
  
  for (int i = 5; i * i <= n; i += 6) {
    if (n % i == 0 || n % (i + 2) == 0) return false;
  }
  return true;
}

// Parameterized test fixture
class PrimeTest : public ::testing::TestWithParam<std::tuple<int, bool>> {
};

// Define test cases
TEST_P(PrimeTest, CheckPrimality) {
  int number = std::get<0>(GetParam());
  bool expected = std::get<1>(GetParam());
  
  EXPECT_EQ(IsPrime(number), expected);
}

// Instantiate the test with parameters
INSTANTIATE_TEST_SUITE_P(
  PrimeValues,
  PrimeTest,
  ::testing::Values(
    std::make_tuple(2, true),
    std::make_tuple(3, true),
    std::make_tuple(4, false),
    std::make_tuple(5, true),
    std::make_tuple(6, false),
    std::make_tuple(7, true),
    std::make_tuple(8, false),
    std::make_tuple(9, false),
    std::make_tuple(10, false),
    std::make_tuple(11, true)
  )
);
```

### Death Tests

```cpp
#include "gtest/gtest.h"
#include <stdexcept>

// Function that might throw or crash
void DangerousFunction(bool should_throw) {
  if (should_throw) {
    throw std::runtime_error("Intentional exception");
  }
}

// Death test
TEST(DeathTest, FunctionThrows) {
  // Test that the function throws an exception with the expected message
  EXPECT_THROW({
    DangerousFunction(true);
  }, std::runtime_error);
  
  // Test that the function doesn't throw when it shouldn't
  EXPECT_NO_THROW({
    DangerousFunction(false);
  });
}
```

## 6. Command-Line Flags

Google Test provides many command-line flags to control test execution:

- `--gtest_list_tests`: List all tests without running them
- `--gtest_filter=PATTERN`: Run only tests matching the pattern
- `--gtest_also_run_disabled_tests`: Run disabled tests too
- `--gtest_repeat=COUNT`: Run tests multiple times
- `--gtest_shuffle`: Randomize test order
- `--gtest_random_seed=NUMBER`: Set random seed for shuffling
- `--gtest_break_on_failure`: Break into debugger on failures
- `--gtest_catch_exceptions`: Catch exceptions and report as failures
- `--gtest_output=xml:PATH`: Generate XML report

## 7. Integration with Test Runners

Google Test can be integrated with various test runners and CI systems:

1. **Command-line execution**:
   ```
   ./my_test --gtest_filter=MathTest.*
   ```

2. **IDE Integration**:
   - Visual Studio has built-in support for Google Test
   - CLion provides Google Test integration
   - Eclipse and other IDEs have plugins

3. **CI Systems**:
   - Jenkins, Travis CI, GitHub Actions, etc. can parse Google Test XML output
   - Example GitHub Actions workflow:
     ```yaml
     jobs:
       test:
         runs-on: ubuntu-latest
         steps:
           - uses: actions/checkout@v2
           - name: Build tests
             run: cmake -B build && cmake --build build
           - name: Run tests
             run: ./build/my_test --gtest_output=xml:test-results.xml
           - name: Publish test results
             uses: EnricoMi/publish-unit-test-result-action@v1
             with:
               files: test-results.xml
     ```

## Referenced Context Files

The following context files were helpful in understanding the Google Test framework:

- `gtest/gtest-assertion-result.h`: Defines the `AssertionResult` class used for predicate assertions
- `gtest/gtest-message.h`: Defines the `Message` class for constructing test failure messages
- `gtest/gtest-test-part.h`: Defines `TestPartResult` for tracking individual assertion results
- `gtest/gtest_pred_impl.h`: Implements predicate assertion macros
- `gtest/gtest_prod.h`: Provides the `FRIEND_TEST` macro for testing private members

These files provided insights into how assertions are implemented and how test results are tracked and reported.