# Generated from:

- ASTRO-PRQChecklists/script/polarion_workitem.py (1027 tokens)
- ASTRO-VS/script/polarion_workitem.py (1027 tokens)
- SDD-VS/script/polarion_workitem.py (1027 tokens)

---

# Polarion Work Item Extraction System

This document provides a comprehensive analysis of the Polarion work item extraction system that retrieves various types of work items from Polarion and generates LaTeX documentation.

## 1. Functional Behavior and Logic

### Core System Purpose

The system is designed to extract work items from Polarion via its web service API and generate LaTeX documentation files for different types of requirements and diagrams. The system follows a consistent pattern across multiple project directories (ASTRO-PRQChecklists, ASTRO-VS, SDD-VS) with identical implementation.

### Main Workflow

1. **Initialization**:
   - Parse command-line arguments (version, root directory, filter flag)
   - Create acronym dictionary from a predefined file
   - Initialize Polarion web service session

2. **Work Item Retrieval**:
   - For each work item type (PR, HLR, LLR, algorithms, PDIR, diagrams):
     - Construct a query criteria based on type and filters
     - Define fields to retrieve
     - Call Polarion web service to get raw work items
     - Process raw work items into structured objects
     - Generate LaTeX content
     - Write to appropriate output file

3. **Diagram Processing**:
   - For diagram work items, additional steps:
     - Extract attachment content
     - Download diagram image
     - Save to figures directory
   - Also handles specific diagram IDs listed explicitly

## 2. Control Flow and State Transitions

The script follows a linear execution flow with the following sequence:

1. Command-line argument parsing
2. Acronym dictionary creation
3. Polarion session initialization
4. Conditional filter setup based on arguments
5. Sequential work item retrieval and processing for each type
6. LaTeX file generation for each work item type
7. Special handling for diagrams (download and save)
8. Processing of explicitly listed diagram figures

## 3. Inputs and Stimuli

### Command Line Arguments

| Argument | Description | Required | Default | Location |
|----------|-------------|----------|---------|----------|
| version | Version to be parsed | Yes | N/A | read_input_arguments() |
| rootDirectory | Root directory of repository | Yes | N/A | read_input_arguments() |
| -all | Flag to include non-verified items | No | False | read_input_arguments() |

### Environment Variables

| Variable | Purpose | Usage |
|----------|---------|-------|
| POLARION_HOST | Hostname for Polarion server | Used to replace 'localhost' in attachment URLs |

### Work Item Query Parameters

For each work item type, the system constructs specific query criteria:

| Work Item Type | Query Criteria | Fields Retrieved | Output File |
|----------------|----------------|------------------|-------------|
| productrequirement | (type:productrequirement) AND linkedWorkItems:(VER-4014) | id, title, description, customFields.derived, customFields.rationale, status | ../PR.tex |
| hlrequirement | (type:hlrequirement) [+ verified_filter] AND linkedWorkItems:(VER-4014) | id, title, description, customFields.derived, customFields.rationale, status | ../HLR.tex |
| llrequirement | (type:llrequirement) [+ verified_filter] AND linkedWorkItems:(VER-4014) | id, title, description, customFields.derived, customFields.rationale, status | ../LLR.tex |
| algorithm | (type:algorithm) [+ verified_filter] AND linkedWorkItems:(VER-4014) | id, title, description, customFields.derived, customFields.rationale, status | ../SW_Algorithms.tex |
| pdireq | (type:pdireq) AND linkedWorkItems:(VER-4014) | id, title, description, customFields.derived, customFields.rationale, status | ../PDIR.tex |
| diagram | (type:diagram) AND linkedWorkItems:(VER-4014) | id, title, description, attachments.content, customFields.rationale | ../SW_Diagrams.tex |

### Specific Diagram IDs

The system also explicitly processes specific diagram IDs:
- VER-4057
- VER-4056

## 4. Outputs and Effects

### LaTeX Files Generated

| File | Content | Parse Description | Is Diagram |
|------|---------|------------------|------------|
| ../PR.tex | Product Requirements | True | False |
| ../HLR.tex | High-Level Requirements | True | False |
| ../LLR.tex | Low-Level Requirements | True | False |
| ../SW_Algorithms.tex | Software Algorithms | False | False |
| ../PDIR.tex | PDI Requirements | True | False |
| ../SW_Diagrams.tex | Software Diagrams | False | True |

### Diagram Images

- For each diagram work item, saves image to `../figures/wi_[ID].png`
- For specific diagrams (VER-4057, VER-4056), saves to the same location

### Log Files

The system creates query log files for debugging/tracking:
- Polarion-QUERY-PR.txt
- Polarion-QUERY-HL.txt
- Polarion-QUERY-LLR.txt
- Polarion-QUERY-Algorithms.txt
- Polarion-QUERY-PDIR.txt
- Polarion-QUERY-Diagrams.txt
- Polarion-QUERY.txt (for specific diagram queries)

## 5. Parameters and Configuration

### Constants

| Constant | Value | Purpose |
|----------|-------|---------|
| HOSTNAME | os.environ['POLARION_HOST'] | Polarion server hostname |

### Verification Filter

```python
verified_filter = ""
if args.all == False:
    verified_filter = ' AND (status:verified)'
```

This filter is applied to certain work item types (hlrequirement, llrequirement, algorithm) to include only verified items unless the `-all` flag is set.

### Common Work Item Link

All queries include `AND linkedWorkItems:(VER-4014)` which restricts results to items linked to a specific work item (VER-4014).

## 6. Error Handling and Contingency Logic

The script does not contain explicit error handling for:
- Missing environment variables
- Failed Polarion connections
- Failed work item retrieval
- Failed file operations

This suggests that errors would propagate as exceptions from the underlying libraries or Python runtime.

## 7. File-by-File Breakdown

### polarion_workitem.py (identical across all three directories)

This file contains the complete workflow for retrieving work items from Polarion and generating LaTeX documentation.

**Key Functions:**

1. **get_diagram(WI_id)**
   - Purpose: Retrieves a specific diagram by ID
   - Input: Work item ID (e.g., "VER-4057")
   - Process:
     - Splits the ID into components
     - Constructs a query to find the specific work item
     - Retrieves the work item with its attachments
     - Downloads the diagram image
     - Saves it to the figures directory
   - Output: Saves diagram as PNG file

2. **make_tex(path, list, parse_description=True, is_diagram=False)**
   - Purpose: Generates LaTeX content from work items and writes to file
   - Inputs:
     - path: Output file path
     - list: List of work item objects
     - parse_description: Whether to parse description field (default: True)
     - is_diagram: Whether items are diagrams (default: False)
   - Process:
     - Opens the output file
     - Calls get_tex() on the work item list
     - Writes the resulting LaTeX to file
     - Closes the file

3. **read_input_arguments()**
   - Purpose: Parses command-line arguments
   - Process:
     - Sets up argument parser
     - Defines required and optional arguments
     - Parses arguments
     - Prints version and filter status
   - Output: Sets global args variable

4. **Main Execution Block**
   - Purpose: Orchestrates the entire workflow
   - Process:
     - Reads input arguments
     - Creates acronym dictionary
     - Initializes Polarion session
     - Sets up verification filter
     - For each work item type:
       - Constructs query criteria
       - Defines fields to retrieve
       - Retrieves and processes work items
       - Generates LaTeX file
     - Special handling for diagrams:
       - Downloads and saves diagram images
       - Processes specific diagram IDs

## 8. Cross-Component Relationships

### External Dependencies

| Module | Purpose | Key Functions Used |
|--------|---------|-------------------|
| Tools.acronyms | Handles acronym processing | make_acronym_dictionary() |
| Tools.polarionWebService | Interfaces with Polarion | init_session(), get_raw_work_items(), get_diagram() |
| Tools.workItemLib | Processes work items | get_work_items(), work_item_list.get_tex() |

### Data Flow

1. **Command Line → Script**
   - Version, root directory, and filter flag

2. **Script → Polarion Web Service**
   - Query criteria
   - Fields to retrieve
   - Version information

3. **Polarion Web Service → Script**
   - Raw work item data
   - Attachment content (for diagrams)

4. **Script → Work Item Library**
   - Raw work items for processing
   - Query log file paths

5. **Work Item Library → Script**
   - Structured work item objects
   - LaTeX content

6. **Script → File System**
   - LaTeX files for each work item type
   - Diagram images in figures directory
   - Query log files

## 9. Common Patterns

### Work Item Retrieval Pattern

For each work item type, the system follows this pattern:

```python
criteria = '(type:TYPE)' + [optional_filter] + ' AND linkedWorkItems:(VER-4014)'
fields = ['id','title','description','customFields.derived','customFields.rationale', 'status']
make_tex("../OUTPUT.tex", workItemLib.get_work_items(polarionWebService.get_raw_work_items(tracker, criteria, fields, args.version), "Polarion-QUERY-TYPE.txt"))
```

This pattern is consistent across all work item types with minor variations:
- Some types don't use the verified_filter
- Diagrams include attachments.content field
- Some outputs have different parse_description settings

### Diagram Processing Pattern

For diagrams, there's an additional pattern:

```python
for i in Wi:
    diagram = polarionWebService.get_diagram((i.list_attachments[-1]).replace('localhost', HOSTNAME))
    diagram.save('../figures/wi_'+i.id+'.png')
```

This pattern downloads each diagram attachment and saves it as a PNG file.

## 10. System Integration Points

### Polarion Integration

- The system connects to Polarion via a web service interface
- It uses environment variables for configuration
- It constructs specific queries to retrieve work items
- It downloads attachments for diagrams

### LaTeX Document Generation

- The system generates LaTeX files for different work item types
- It handles special formatting for diagrams
- It processes descriptions differently based on work item type

### File System Integration

- The system writes LaTeX files to the parent directory
- It saves diagram images to a figures subdirectory
- It creates query log files for debugging/tracking

## 11. Workflow Reconstruction

The complete workflow of the system can be reconstructed as:

1. **Initialization Phase**
   - Parse command-line arguments
   - Set up acronym dictionary
   - Initialize Polarion session
   - Configure verification filter

2. **Work Item Retrieval Phase**
   - For each work item type (PR, HLR, LLR, algorithms, PDIR, diagrams):
     - Construct query criteria
     - Define fields to retrieve
     - Call Polarion web service
     - Process raw work items
     - Generate LaTeX content
     - Write to output file

3. **Diagram Processing Phase**
   - For diagram work items:
     - Download diagram images
     - Save to figures directory
   - For specific diagram IDs:
     - Retrieve by ID
     - Download and save images

This workflow is identical across all three project directories, suggesting a standardized approach to documentation generation.

## Referenced Context Files

No context files were provided in the input.

AI Agent: This summary provides a comprehensive extraction of the Polarion work item system's behavior, focusing on the workflow for retrieving different types of work items and generating LaTeX documentation. The analysis covers query construction patterns, field selection, and the special handling for diagram work items, addressing the special instructions to focus on these aspects of the system.