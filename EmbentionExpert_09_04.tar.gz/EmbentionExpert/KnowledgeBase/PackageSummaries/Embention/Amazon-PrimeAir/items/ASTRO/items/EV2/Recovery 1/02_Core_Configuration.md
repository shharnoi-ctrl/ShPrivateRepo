# Generated from:

- items/pdi_Recovery1/setup/ver_spdif_cfgmgr.xml (11573 tokens)
- items/pdi_Recovery1/setup/ver_spdif_mrvar.xml (14046 tokens)
- items/pdi_Recovery1/setup/ver_spdif_tm.xml (22408 tokens)
- items/pdi_Recovery1/setup/ver_spdif_muvar.xml (1294 tokens)
- items/pdi_Recovery1/setup/ver_spdif_mvars.xml (270 tokens)
- items/pdi_Recovery1/setup/ver_spdif_pk0.xml (3407 tokens)
- items/pdi_Recovery1/setup/ver_spdif_vehicle_ident.xml (858 tokens)
- items/pdi_Recovery1/setup/ver_spdif_amz_rec_param.xml (3199 tokens)
- items/pdi_Recovery1/setup/ver_spdif_mbit.xml (2432 tokens)

---

# PDI Recovery1 System Configuration Analysis

This document provides a comprehensive analysis of the core configuration files for the PDI Recovery1 system, focusing on the configuration manager, monitoring variables, telemetry configuration, user variables, vehicle identification, and recovery parameters.

## 1. Configuration Manager (ver_spdif_cfgmgr.xml)

### 1.1 Basic Structure and Version Information

The configuration manager file defines the fundamental configuration settings for the PDI Recovery1 system.

- **File ID**: 0
- **Filename**: cfgmgr.bin
- **Version**: 7.3.1
- **Structure**: Contains an extensive array of tunable elements (str-tunarray-element)

### 1.2 Mode Configuration

The configuration file contains 500 tunable array elements, each with a mode parameter set to 0. This uniform mode setting suggests that the system is configured with a consistent operational mode across all configuration parameters.

```xml
<str-tunarray-element>
    <mode>0</mode>
</str-tunarray-element>
```

This standardized mode setting (0) likely represents the default operational mode for the Recovery1 system. The extensive number of identical elements suggests a comprehensive configuration system with numerous parameters that can be adjusted but are currently set to their default values.

## 2. Monitoring Variables (ver_spdif_mrvar.xml)

### 2.1 Basic Structure and Version Information

The monitoring variables file defines variables that are tracked and monitored during system operation.

- **File ID**: 136
- **Filename**: mrvar.bin
- **Version**: 7.3.1

### 2.2 Monitored Variables

The file defines 113 monitoring variables, each with a unique ID and name. These variables can be categorized into several groups:

#### 2.2.1 RPM Monitoring (IDs 3100-3105)
- rpm0, rpm1, rpm2, rpm3, rpm4, rpm5 - Monitor rotation speeds of the six motors

#### 2.2.2 Controller Timing and Performance Metrics
- ctr_time_max/avg (3202-3203): Controller execution time (maximum and average)
- ctr_pre_time_max/avg (3204-3205): Pre-controller processing time
- ctr_input_max/avg (3206-3207): Controller input processing time
- post_ctr_max/avg (3222-3223): Post-controller processing time

#### 2.2.3 System Component Performance Metrics
- sep_max/avg (3210-3211): State Estimation Processor metrics
- tcg_max/avg (3214-3215): Trajectory Command Generator metrics
- tsc_max/avg (3216-3217): Trajectory Setpoint Controller metrics
- aacg_max/avg (3218-3219): Attitude and Acceleration Command Generator metrics
- asc_max/avg (3220-3221): Attitude Setpoint Controller metrics
- ttcg_max/avg (3224-3225): Transition Trajectory Command Generator metrics
- atcg_max/avg (3226-3227): Attitude Trajectory Command Generator metrics
- waca_max/avg (3228-3229): Wind-Aware Command Adapter metrics

#### 2.2.4 State Machine and Control Metrics
- sm_step_max/avg (3232-3233): State Machine step execution metrics
- cm_step_max/avg (3236-3237): Control Manager step execution metrics
- pre_recov_max/avg (3246-3247): Pre-recovery processing metrics
- rccp_step_max/avg (3248-3249): Recovery Control Command Processor metrics
- ctrl_obj_step_max/avg (3252-3253): Control Object step execution metrics
- post_recov_max/avg (3256-3257): Post-recovery processing metrics

#### 2.2.5 Recovery Module Performance Metrics
- rmdp_max/avg (3258-3259): Recovery Module Data Processor metrics
- rmpf_max/avg (3260-3261): Recovery Module Phase Finder metrics
- rrc_max/avg (3262-3263): Recovery Route Calculator metrics
- tp_max/avg (3264-3265): Trajectory Planner metrics
- rmdp_io_max/avg (3270-3271): Recovery Module Data Processor I/O metrics
- rrc_io_max/avg (3278-3279): Recovery Route Calculator I/O metrics
- tp_io_max/avg (3282-3283): Trajectory Planner I/O metrics
- gcc_max/avg (3286-3287): Guidance Command Calculator metrics
- rccp_io_max/avg (3288-3289): Recovery Control Command Processor I/O metrics

#### 2.2.6 Mixer and Scheduler Metrics
- mixer_sched_max/avg (3292-3293): Mixer scheduler metrics
- mixer_step_max/avg (3294-3295): Mixer step execution metrics
- mixer_pop_out_max/avg (3296-3297): Mixer output population metrics
- sched_disp_alloc_param_max/avg (3298-3299): Scheduler dispatch allocation parameter metrics

#### 2.2.7 Constrained Quadratic Programming Metrics
- cqp_pre_max/avg (3300-3301): CQP pre-processing metrics
- cqp_step_max/avg (3302-3303): CQP step execution metrics
- cqp_solve_max/avg (3304-3305): CQP solver metrics
- cqp_chol_whl_time_max/avg (3314-3315): CQP Cholesky whole time metrics
- cqp_chol_cst_time_max/avg (3318-3319): CQP Cholesky constraint time metrics

#### 2.2.8 Transition Trajectory Command Generator Detailed Metrics
- ttcg_init_out_log_msg_max/avg (3322-3323): TTCG initialization output logging metrics
- ttcg_pof_max/avg (3324-3325): TTCG Path Optimization Function metrics
- ttcg_pofts_vtol_max/avg (3328-3329): TTCG POFTS VTOL metrics
- ttcg_pofts_it_max/avg (3330-3331): TTCG POFTS iteration metrics
- ttcg_pofts_wbf_ot_max/avg (3332-3333): TTCG POFTS WBF OT metrics
- ttcg_origin_max/avg (3342-3343): TTCG origin calculation metrics
- ttcg_utri_max/avg (3344-3345): TTCG UTRI metrics
- ttcg_ettd_max/avg (3346-3347): TTCG ETTD metrics
- ttcg_pdsr_max/avg (3364-3365): TTCG PDSR metrics
- ttcg_log_max/avg (3370-3371): TTCG logging metrics
- ttcg_prof_itrt_3_max/avg (3376-3377): TTCG profiling iteration 3 metrics
- ttcg_prof_itrt_4_max/avg (3378-3379): TTCG profiling iteration 4 metrics
- ttcg_prof_cp_3_max/avg (3394-3395): TTCG profiling CP 3 metrics

## 3. Telemetry Configuration (ver_spdif_tm.xml)

### 3.1 Basic Structure and Version Information

The telemetry configuration file defines how system data is collected and transmitted.

- **File ID**: 60
- **Filename**: tm.bin
- **Version**: 7.3.1

### 3.2 Telemetry Streams

The file defines four telemetry streams, each with different fields, sampling periods, and destinations:

#### 3.2.1 Primary Telemetry Stream
- **Enable**: 1 (enabled)
- **Period**: 0.05 seconds (20 Hz)
- **Address**: UAV 2
- **Fields**: 70 data fields including:
  - Real float32 values (type 0)
  - Bit values (type 3)
  - Unsigned integer16 values (type 2)
- Includes critical flight parameters, system states, and control values

#### 3.2.2 Secondary Telemetry Stream
- **Enable**: 1 (enabled)
- **Period**: 0.05 seconds (20 Hz)
- **Address**: UAV 2
- **Fields**: 65 data fields primarily consisting of real float32 values and bit values
- Focuses on controller performance metrics and system states

#### 3.2.3 Tertiary Telemetry Stream
- **Enable**: 1 (enabled)
- **Period**: 0.05 seconds (20 Hz)
- **Address**: UAV 2
- **Fields**: 65 data fields including RPM values, control states, and recovery metrics

#### 3.2.4 Quaternary Telemetry Stream
- **Enable**: 1 (enabled)
- **Period**: 0.1 seconds (10 Hz)
- **Address**: UAV 2
- **Fields**: 60 data fields including TTCG metrics, system states, and mission status flags

### 3.3 Data Types and Scaling

The telemetry configuration uses several data types:
- **real-float32**: Floating-point values with scale factors (typically 1.0)
- **bit**: Boolean values for system states and flags
- **uinteger16**: Unsigned 16-bit integers with defined min/max ranges (0-65535)

## 4. User Variables (ver_spdif_muvar.xml)

### 4.1 Basic Structure and Version Information

The user variables file defines named variables that can be accessed and modified by users or other system components.

- **File ID**: 137
- **Filename**: muvar.bin
- **Version**: 7.3.1

### 4.2 User Variable Definitions

The file defines 39 user variables with descriptive names, organized into several functional groups:

#### 4.2.1 Motor Control Variables (IDs 1000-1003)
- control motor enable intent (1000)
- control disabled motor (1001)
- control motor arm intent (1002)
- control motor source (1003)

#### 4.2.2 Controller Mode Variables (IDs 1100-1117)
- controllers mode (1100)
- ttcg tracked phase (1101)
- ttcg route id (1102)
- ttcg route status (1103)
- ttcg maneuver id (1104)
- ttcg maneuver status (1105)
- ttcg transition tracking method (1106)
- ttcg transition speed mode (1107)
- tsc tracking mode (1108)
- sm integrators mode (1109)
- sm land mode (1110)
- sm takeoff mode (1111)
- sm controllers mode (1112)
- sm degradation level (1113)
- sm gain type (1114)
- mixer solver status (1115)
- recovery previous track phase (1116)
- Hardcoded Mission ID (1117)

## 5. System Status Flags (ver_spdif_mbit.xml)

### 5.1 Basic Structure and Version Information

The system status flags file defines boolean indicators for various system states and conditions.

- **File ID**: 138
- **Filename**: mbit.bin
- **Version**: 7.3.1

### 5.2 Status Flag Definitions

The file defines 42 status flags, including:

#### 5.2.1 General Status Flags (IDs 1200-1220)
- 21 unnamed general status flags

#### 5.2.2 System State Flags (IDs 1300-1311)
- is_onground (1300): Indicates if the vehicle is on the ground
- control status (1301): Current control status
- do switchover (1302): Command to switch control systems
- ttcg wp is valid (1303): Indicates if the current waypoint is valid
- self arm enabled (1304): Self-arming capability status
- mixer is saturated (1305): Indicates if the mixer is at saturation limits
- recovery is in control (1306): Indicates if recovery system has control
- recovery tracking has started (1307): Recovery tracking status
- recovery is armed allowed (1308): Recovery arming permission status
- recovery arming disallowed (1309): Recovery arming restriction status
- recovery takeoff executed (1310): Recovery takeoff status
- recovery initial tracking point set (1311): Initial tracking point status

#### 5.2.3 Recovery Command Flags (ID 1317)
- recovery pre takeoff cmd (1317): Pre-takeoff command status

#### 5.2.4 Motor Test Flags (IDs 1328-1329)
- motor_spin_dir_test_init_rcv (1328): Motor spin direction test initialization
- motor_spin_dir_test_result_rcv (1329): Motor spin direction test results

#### 5.2.5 Mission Status Flags (IDs 1330-1339)
- mission_has_flight_id (1330): Flight ID presence
- mission_has_version (1331): Mission version presence
- mission_has_crs (1332): CRS presence
- mission_has_initial_plan (1333): Initial plan presence
- mission_has_takeoff_bounding_volume (1334): Takeoff bounding volume presence
- is_mission_plan_data_valid (1335): Mission plan data validity
- is_upload_mission_plan_wrapper_valid (1336): Mission plan wrapper validity
- is_mission_plan_data_cached (1337): Mission plan data cache status
- is_mission_metadata_received (1338): Mission metadata reception status
- is_mission_deserialized_successfully (1339): Mission deserialization status

## 6. Vehicle Identification (ver_spdif_vehicle_ident.xml)

### 6.1 Basic Structure and Version Information

The vehicle identification file defines unique identifiers and characteristics for the vehicle.

- **File ID**: 380
- **Filename**: vehicle_ident.bin
- **Version**: 7.3.1

### 6.2 Vehicle Identification Parameters

- **UAV Address**: 4278190080 (0xFF000000)
- **Vehicle Type**: 0
- **Vehicle Subtype**: 0
- **Payloads**: Single payload with ID 0
- **Tail Number**: "RP7819080    " (ASCII values: 52 50 55 56 49 57 48 48 56 48 32 32 32 32 32 0)
- **ATC Call Sign**: Empty (all spaces)

## 7. Recovery Parameters (ver_spdif_amz_rec_param.xml)

### 7.1 Basic Structure and Version Information

The recovery parameters file defines detailed configuration for the recovery system.

- **File ID**: 488
- **Filename**: amz_rec_param.bin
- **Version**: 7.3.1

### 7.2 Recovery System Configuration

#### 7.2.1 Core Recovery Settings
- **Switchover Enabled**: 1 (enabled)
- **Preflight Switchover Test**: 0 (disabled)
- **Preflight Health Checks**: 0 (disabled)
- **Motor Arm Delay**: 5.0 seconds after MRS
- **Wind Estimate Source**: CX3 wind estimates (enabled)

#### 7.2.2 Recovery Control Command Processor (RCCP) Parameters
- **Recovery Module Phase Finder (RMPF) Parameters**:
  - Ground altitude: 0.48m
  - Takeoff thresholds: 1.0m (altitude), 0.5m/s (velocity), 2.6m/s² (acceleration)
  - Landing thresholds: 0.5m/s (vertical velocity), 10.0m (horizontal position), 0.5m/s (groundspeed)

- **Recovery Route Calculator (RRC) Parameters**:
  - Minimum velocity for route planning: 0.2m/s

- **Battery Parameters**:
  - Minimum SOC for contingency planning: 1000
  - Maximum SOC for landing: 2300

- **Bounding Box Protection**:
  - Enabled: 1 (enabled)
  - Logging interval: 1.0 second
  - Use mission dimensions: 0 (disabled)
  - Default dimensions: 5.0m (half-length), 5.0m (half-width), 10.0m (half-height)

#### 7.2.3 Logging Configuration
- **Control Log Output**: Suppressed (1)
- **Recovery Telemetry Output**: Enabled (0)
- **Recovery Telemetry Period**: 0.02 seconds (50 Hz)
- **Recovery Controller Telemetry**: Enabled (0)
- **Recovery Controller Telemetry Period**: 0.1 seconds (10 Hz)

#### 7.2.4 GNSS Configuration
- **Use Receiver PVT**: 1 (enabled)
- **Use GNSS A**: 1 (true, use GNSS A)
- **Maximum Vertical Position Accuracy**: 25.0m
- **Maximum Horizontal Position Accuracy**: 15.0m

#### 7.2.5 Navigation Parameters
- **Installation Parameters**: Defines transformation matrices and vectors for IMU, antennas, and laser positioning
- **Wind Parameters**: 10.0s time constant, 25.0m/s IAS threshold
- **Air Data**: 0.6168s dynamic pressure low-pass filter time constant
- **Heading**: Updates enabled with 0.7854 rad (45°) maximum innovation threshold
- **Ground Detection**: 
  - Jerk threshold: 3.5m/s³
  - Jerk window: 0.75s
  - Takeoff requirements: 4 motors at 1500 RPM
  - Landing thresholds: 0.25m/s velocity, 0.75m/s command velocity

#### 7.2.6 Attitude and Acceleration Command Generator (AACG) Parameters
- **Attitude Contingency Mode Blending**: Enabled with 2.0s blending time
- **Blending-Based Takeoff Logic**: Enabled

#### 7.2.7 State Estimation Processor (SEP) Parameters
- **Attitude Contingency Mode Blending**: Enabled with 2.0s blending time
- **Position Low-Pass Filter Parameters**: Detailed gains for lateral, longitudinal, and height filtering

#### 7.2.8 Trajectory Setpoint Controller (TSC) Parameters
- **A2A Bypass Configuration**: Connected to V2A output with 2.5s maximum time limit

#### 7.2.9 Trajectory Command Generator (TCG) Parameters
- **Waypoint Command Blending**: 3.0s blending time
- **Position Error Blending Rate Limits**: 2.0m/s for all axes
- **Transition Trajectory Command Generator (TTCG)**: 
  - Integration time override: 0.5s
  - Nominal pristine airspeed: 30.0m/s
- **Wind-Aware Command Adapter (WACA)**: 5.0s airspeed command mode blending time
- **Attitude Trajectory Command Generator (ATCG)**:
  - Weathervaning: Enabled
  - Minimum engaged airspeed: 2.0m/s
  - Maximum rate: 3.0m/s
  - Maximum yaw rate: 0.7854 rad/s (45°/s)
  - Vertical acceleration command thresholds: -1.5g to -0.6g
  - Pitch augmentation limits: -10° to 10°

#### 7.2.10 Mixer Parameters
- **State Reset**: Disabled
- **Actuator Hysteresis Override**: Disabled
- **Contingency Mode Blending**: Enabled with 2.0s blending time
- **Vehicle Parameters**: 6 motors, 0 control surfaces

#### 7.2.11 State Machine (SM) Parameters
- **Track Spline Parameters**:
  - Maximum attitude error: 3.1415 rad (180°)
  - Maximum angular rate: 3.1415 rad/s (180°/s)
  - Maximum horizontal tracking error: 9999.0m (effectively unlimited)
  - Maximum vertical tracking error: 99.0m
  - Maximum VTOL horizontal tracking error: 10.0m
  - Maximum VTOL vertical tracking error: 5.0m
  - Maximum vertical speed: 10.0m/s
  - Maximum VTOL altitude: 20.0m

#### 7.2.12 Control Manager (CM) Parameters
- **Takeoff Manager**: Horizontal controllers enabled in on-ground mode
- **Track Spline Manager**: 
  - Wind gust threshold: 12.8m/s
  - Wind gust counter threshold: 3
  - Wind threshold monitor enabled for command skip
- **Land Manager**: Fast descent rate: -1.0m/s

## 8. Variable Mapping (ver_spdif_mvars.xml)

### 8.1 Basic Structure and Version Information

The variable mapping file defines mappings for different variable types.

- **File ID**: 278
- **Filename**: mvars.bin
- **Version**: 7.3.1

### 8.2 Variable Type Mappings

The file defines empty mappings for six different variable types (0, 2, 3, 4, 5, 6), suggesting that variable name arrays are defined elsewhere or dynamically.

## 9. Initial Covariance Matrix (ver_spdif_pk0.xml)

### 9.1 Basic Structure and Version Information

The initial covariance matrix file defines the starting covariance for state estimation.

- **File ID**: 89
- **Filename**: pk0.bin
- **Version**: 7.3.1

### 9.2 Covariance Matrix Structure

The file defines a 16x16 covariance matrix with all elements initialized to 0.0, indicating perfect initial state knowledge (which is likely updated during operation).

## 10. Cross-Component Relationships

### 10.1 Configuration and Monitoring Integration

The configuration manager (cfgmgr.xml) provides the base settings that affect the behavior of all other components. The monitoring variables (mrvar.xml) track the performance and state of these components during operation.

### 10.2 Telemetry and Variable Mapping

The telemetry configuration (tm.xml) references variables by ID that are defined in the monitoring variables (mrvar.xml) and user variables (muvar.xml) files. The variable mapping (mvars.xml) provides a framework for organizing these variables by type.

### 10.3 Recovery System Integration

The recovery parameters (amz_rec_param.xml) define the behavior of the recovery system, which interacts with the status flags (mbit.xml) to determine system state and trigger appropriate responses. The vehicle identification (vehicle_ident.xml) provides context for the recovery system's operation.

### 10.4 State Estimation and Control Flow

The initial covariance matrix (pk0.xml) provides the starting point for state estimation, which feeds into the control system defined by the recovery parameters. The monitoring variables track the performance of this control flow, and the telemetry system reports the results.

## 11. Key System Parameters

### 11.1 Critical Recovery Parameters

- **Switchover Control**: Enabled but without preflight testing
- **Motor Configuration**: 6 motors with 5-second arm delay
- **GNSS Configuration**: Primary receiver (A) with 15m horizontal and 25m vertical accuracy limits
- **Bounding Box**: 10m x 10m x 20m protected volume
- **Wind Handling**: 12.8m/s gust threshold with weathervaning enabled above 2.0m/s

### 11.2 Performance Monitoring

- Extensive performance metrics for all system components
- High-frequency telemetry (20Hz for most data, 10Hz for additional data)
- Detailed timing metrics for critical path operations

### 11.3 Safety Parameters

- Takeoff requires 4 motors at minimum 1500 RPM
- Landing detection at 0.25m/s vertical velocity
- Maximum tracking errors defined for different flight phases
- Battery state of charge thresholds for contingency planning

## 12. Summary

The PDI Recovery1 system is a sophisticated flight control and recovery system with extensive configuration options and monitoring capabilities. The system is designed with redundancy (switchover capability), detailed performance tracking, and comprehensive telemetry. The recovery parameters define a cautious approach to flight operations, with conservative thresholds for takeoff, landing, and contingency handling.

The system appears to be designed for a hexacopter (6 motors) with VTOL capabilities and transition to forward flight. The configuration emphasizes safety through multiple layers of monitoring and contingency handling, while providing detailed telemetry for post-flight analysis and system improvement.

The version consistency (7.3.1) across all configuration files indicates a coordinated release of the system configuration, ensuring compatibility between components.

AI: I've analyzed the core configuration files of the PDI Recovery1 system, focusing on how they define the fundamental behavior of the system. This analysis covers the configuration manager, monitoring variables, telemetry configuration, user variables, vehicle identification, and recovery parameters.

# PDI Recovery1 System Configuration Analysis

## 1. Configuration Manager (ver_spdif_cfgmgr.xml)

### 1.1 Basic Structure and Version Information
- **File ID**: 0
- **Filename**: cfgmgr.bin
- **Version**: 7.3.1
- **Structure**: Contains 500 tunable array elements, each with a mode parameter set to 0

### 1.2 Mode Configuration
The configuration file contains a uniform mode setting (0) across all 500 tunable elements, suggesting a standardized default operational mode for the Recovery1 system. This extensive array of identical elements indicates a comprehensive configuration system with numerous parameters that can be adjusted but are currently set to their default values.

## 2. Monitoring Variables (ver_spdif_mrvar.xml)

### 2.1 Basic Structure and Version Information
- **File ID**: 136
- **Filename**: mrvar.bin
- **Version**: 7.3.1

### 2.2 Monitored Variables
The file defines 113 monitoring variables organized into several functional categories:

#### 2.2.1 RPM Monitoring (IDs 3100-3105)
- rpm0 through rpm5: Monitor rotation speeds of the six motors

#### 2.2.2 Controller Timing and Performance Metrics
- ctr_time_max/avg (3202-3203): Controller execution time
- ctr_pre_time_max/avg (3204-3205): Pre-controller processing time
- ctr_input_max/avg (3206-3207): Controller input processing time
- post_ctr_max/avg (3222-3223): Post-controller processing time

#### 2.2.3 System Component Performance Metrics
- sep_max/avg (3210-3211): State Estimation Processor metrics
- tcg_max/avg (3214-3215): Trajectory Command Generator metrics
- tsc_max/avg (3216-3217): Trajectory Setpoint Controller metrics
- aacg_max/avg (3218-3219): Attitude and Acceleration Command Generator metrics
- asc_max/avg (3220-3221): Attitude Setpoint Controller metrics
- ttcg_max/avg (3224-3225): Transition Trajectory Command Generator metrics
- atcg_max/avg (3226-3227): Attitude Trajectory Command Generator metrics
- waca_max/avg (3228-3229): Wind-Aware Command Adapter metrics

#### 2.2.4 State Machine and Control Metrics
- sm_step_max/avg (3232-3233): State Machine step execution metrics
- cm_step_max/avg (3236-3237): Control Manager step execution metrics
- pre_recov_max/avg (3246-3247): Pre-recovery processing metrics
- rccp_step_max/avg (3248-3249): Recovery Control Command Processor metrics
- ctrl_obj_step_max/avg (3252-3253): Control Object step execution metrics
- post_recov_max/avg (3256-3257): Post-recovery processing metrics

#### 2.2.5 Recovery Module Performance Metrics
- rmdp_max/avg (3258-3259): Recovery Module Data Processor metrics
- rmpf_max/avg (3260-3261): Recovery Module Phase Finder metrics
- rrc_max/avg (3262-3263): Recovery Route Calculator metrics
- tp_max/avg (3264-3265): Trajectory Planner metrics
- rmdp_io_max/avg (3270-3271): Recovery Module Data Processor I/O metrics
- rrc_io_max/avg (3278-3279): Recovery Route Calculator I/O metrics
- tp_io_max/avg (3282-3283): Trajectory Planner I/O metrics
- gcc_max/avg (3286-3287): Guidance Command Calculator metrics
- rccp_io_max/avg (3288-3289): Recovery Control Command Processor I/O metrics

#### 2.2.6 Mixer and Scheduler Metrics
- mixer_sched_max/avg (3292-3293): Mixer scheduler metrics
- mixer_step_max/avg (3294-3295): Mixer step execution metrics
- mixer_pop_out_max/avg (3296-3297): Mixer output population metrics
- sched_disp_alloc_param_max/avg (3298-3299): Scheduler dispatch allocation parameter metrics

#### 2.2.7 Constrained Quadratic Programming Metrics
- cqp_pre_max/avg (3300-3301): CQP pre-processing metrics
- cqp_step_max/avg (3302-3303): CQP step execution metrics
- cqp_solve_max/avg (3304-3305): CQP solver metrics
- cqp_chol_whl_time_max/avg (3314-3315): CQP Cholesky whole time metrics
- cqp_chol_cst_time_max/avg (3318-3319): CQP Cholesky constraint time metrics

#### 2.2.8 Transition Trajectory Command Generator Detailed Metrics
Numerous detailed metrics for the TTCG component, including:
- ttcg_init_out_log_msg_max/avg (3322-3323)
- ttcg_pof_max/avg (3324-3325)
- ttcg_pofts_vtol_max/avg (3328-3329)
- ttcg_origin_max/avg (3342-3343)
- ttcg_utri_max/avg (3344-3345)
- ttcg_ettd_max/avg (3346-3347)
- ttcg_pdsr_max/avg (3364-3365)
- ttcg_log_max/avg (3370-3371)
- ttcg_prof_itrt_3_max/avg (3376-3377)
- ttcg_prof_cp_3_max/avg (3394-3395)

## 3. Telemetry Configuration (ver_spdif_tm.xml)

### 3.1 Basic Structure and Version Information
- **File ID**: 60
- **Filename**: tm.bin
- **Version**: 7.3.1

### 3.2 Telemetry Streams
The file defines four telemetry streams, each with different fields, sampling periods, and destinations:

#### 3.2.1 Primary Telemetry Stream
- **Enable**: 1 (enabled)
- **Period**: 0.05 seconds (20 Hz)
- **Address**: UAV 2
- **Fields**: 70 data fields including real float32 values, bit values, and unsigned integer16 values

#### 3.2.2 Secondary Telemetry Stream
- **Enable**: 1 (enabled)
- **Period**: 0.05 seconds (20 Hz)
- **Address**: UAV 2
- **Fields**: 65 data fields primarily consisting of real float32 values and bit values

#### 3.2.3 Tertiary Telemetry Stream
- **Enable**: 1 (enabled)
- **Period**: 0.05 seconds (20 Hz)
- **Address**: UAV 2
- **Fields**: 65 data fields including RPM values, control states, and recovery metrics

#### 3.2.4 Quaternary Telemetry Stream
- **Enable**: 1 (enabled)
- **Period**: 0.1 seconds (10 Hz)
- **Address**: UAV 2
- **Fields**: 60 data fields including TTCG metrics, system states, and mission status flags

### 3.3 Data Types and Scaling
- **real-float32**: Floating-point values with scale factors (typically 1.0)
- **bit**: Boolean values for system states and flags
- **uinteger16**: Unsigned 16-bit integers with defined min/max ranges (0-65535)

## 4. User Variables (ver_spdif_muvar.xml)

### 4.1 Basic Structure and Version Information
- **File ID**: 137
- **Filename**: muvar.bin
- **Version**: 7.3.1

### 4.2 User Variable Definitions
The file defines 39 user variables with descriptive names, organized into several functional groups:

#### 4.2.1 Motor Control Variables (IDs 1000-1003)
- control motor enable intent (1000)
- control disabled motor (1001)
- control motor arm intent (1002)
- control motor source (1003)

#### 4.2.2 Controller Mode Variables (IDs 1100-1117)
- controllers mode (1100)
- ttcg tracked phase (1101)
- ttcg route id (1102)
- ttcg route status (1103)
- ttcg maneuver id (1104)
- ttcg maneuver status (1105)
- ttcg transition tracking method (1106)
- ttcg transition speed mode (1107)
- tsc tracking mode (1108)
- sm integrators mode (1109)
- sm land mode (1110)
- sm takeoff mode (1111)
- sm controllers mode (1112)
- sm degradation level (1113)
- sm gain type (1114)
- mixer solver status (1115)
- recovery previous track phase (1116)
- Hardcoded Mission ID (1117)

## 5. Vehicle Identification (ver_spdif_vehicle_ident.xml)

### 5.1 Basic Structure and Version Information
- **File ID**: 380
- **Filename**: vehicle_ident.bin
- **Version**: 7.3.1

### 5.2 Vehicle Identification Parameters
- **UAV Address**: 4278190080 (0xFF000000)
- **Vehicle Type**: 0
- **Vehicle Subtype**: 0
- **Payloads**: Single payload with ID 0
- **Tail Number**: "RP7819080    " (ASCII values: 52 50 55 56 49 57 48 48 56 48 32 32 32 32 32 0)
- **ATC Call Sign**: Empty (all spaces)

## 6. Recovery Parameters (ver_spdif_amz_rec_param.xml)

### 6.1 Basic Structure and Version Information
- **File ID**: 488
- **Filename**: amz_rec_param.bin
- **Version**: 7.3.1

### 6.2 Recovery System Configuration

#### 6.2.1 Core Recovery Settings
- **Switchover Enabled**: 1 (enabled)
- **Preflight Switchover Test**: 0 (disabled)
- **Preflight Health Checks**: 0 (disabled)
- **Motor Arm Delay**: 5.0 seconds after MRS
- **Wind Estimate Source**: CX3 wind estimates (enabled)

#### 6.2.2 Recovery Control Command Processor (RCCP) Parameters
- **Recovery Module Phase Finder (RMPF) Parameters**:
  - Ground altitude: 0.48m
  - Takeoff thresholds: 1.0m (altitude), 0.5m/s (velocity), 2.6m/s² (acceleration)
  - Landing thresholds: 0.5m/s (vertical velocity), 10.0m (horizontal position), 0.5m/s (groundspeed)

- **Recovery Route Calculator (RRC) Parameters**:
  - Minimum velocity for route planning: 0.2m/s

- **Battery Parameters**:
  - Minimum SOC for contingency planning: 1000
  - Maximum SOC for landing: 2300

- **Bounding Box Protection**:
  - Enabled: 1 (enabled)
  - Logging interval: 1.0 second
  - Use mission dimensions: 0 (disabled)
  - Default dimensions: 5.0m (half-length), 5.0m (half-width), 10.0m (half-height)

#### 6.2.3 Logging Configuration
- **Control Log Output**: Suppressed (1)
- **Recovery Telemetry Output**: Enabled (0)
- **Recovery Telemetry Period**: 0.02 seconds (50 Hz)
- **Recovery Controller Telemetry**: Enabled (0)
- **Recovery Controller Telemetry Period**: 0.1 seconds (10 Hz)

#### 6.2.4 GNSS Configuration
- **Use Receiver PVT**: 1 (enabled)
- **Use GNSS A**: 1 (true, use GNSS A)
- **Maximum Vertical Position Accuracy**: 25.0m
- **Maximum Horizontal Position Accuracy**: 15.0m

#### 6.2.5 Navigation Parameters
- **Installation Parameters**: Defines transformation matrices and vectors for IMU, antennas, and laser positioning
- **Wind Parameters**: 10.0s time constant, 25.0m/s IAS threshold
- **Air Data**: 0.6168s dynamic pressure low-pass filter time constant
- **Heading**: Updates enabled with 0.7854 rad (45°) maximum innovation threshold
- **Ground Detection**: 
  - Jerk threshold: 3.5m/s³
  - Jerk window: 0.75s
  - Takeoff requirements: 4 motors at 1500 RPM
  - Landing thresholds: 0.25m/s velocity, 0.75m/s command velocity

#### 6.2.6 Attitude and Acceleration Command Generator (AACG) Parameters
- **Attitude Contingency Mode Blending**: Enabled with 2.0s blending time
- **Blending-Based Takeoff Logic**: Enabled

#### 6.2.7 State Estimation Processor (SEP) Parameters
- **Attitude Contingency Mode Blending**: Enabled with 2.0s blending time
- **Position Low-Pass Filter Parameters**: Detailed gains for lateral, longitudinal, and height filtering

#### 6.2.8 Trajectory Setpoint Controller (TSC) Parameters
- **A2A Bypass Configuration**: Connected to V2A output with 2.5s maximum time limit

#### 6.2.9 Trajectory Command Generator (TCG) Parameters
- **Waypoint Command Blending**: 3.0s blending time
- **Position Error Blending Rate Limits**: 2.0m/s for all axes
- **Transition Trajectory Command Generator (TTCG)**: 
  - Integration time override: 0.5s
  - Nominal pristine airspeed: 30.0m/s
- **Wind-Aware Command Adapter (WACA)**: 5.0s airspeed command mode blending time
- **Attitude Trajectory Command Generator (ATCG)**:
  - Weathervaning: Enabled
  - Minimum engaged airspeed: 2.0m/s
  - Maximum rate: 3.0m/s
  - Maximum yaw rate: 0.7854 rad/s (45°/s)
  - Vertical acceleration command thresholds: -1.5g to -0.6g
  - Pitch augmentation limits: -10° to 10°

#### 6.2.10 Mixer Parameters
- **State Reset**: Disabled
- **Actuator Hysteresis Override**: Disabled
- **Contingency Mode Blending**: Enabled with 2.0s blending time
- **Vehicle Parameters**: 6 motors, 0 control surfaces

#### 6.2.11 State Machine (SM) Parameters
- **Track Spline Parameters**:
  - Maximum attitude error: 3.1415 rad (180°)
  - Maximum angular rate: 3.1415 rad/s (180°/s)
  - Maximum horizontal tracking error: 9999.0m (effectively unlimited)
  - Maximum vertical tracking error: 99.0m
  - Maximum VTOL horizontal tracking error: 10.0m
  - Maximum VTOL vertical tracking error: 5.0m
  - Maximum vertical speed: 10.0m/s
  - Maximum VTOL altitude: 20.0m

#### 6.2.12 Control Manager (CM) Parameters
- **Takeoff Manager**: Horizontal controllers enabled in on-ground mode
- **Track Spline Manager**: 
  - Wind gust threshold: 12.8m/s
  - Wind gust counter threshold: 3
  - Wind threshold monitor enabled for command skip
- **Land Manager**: Fast descent rate: -1.0m/s

## 7. System Status Flags (ver_spdif_mbit.xml)

### 7.1 Basic Structure and Version Information
- **File ID**: 138
- **Filename**: mbit.bin
- **Version**: 7.3.1

### 7.2 Status Flag Definitions
The file defines 42 status flags, including:

#### 7.2.1 General Status Flags (IDs 1200-1220)
- 21 unnamed general status flags

#### 7.2.2 System State Flags (IDs 1300-1311)
- is_onground (1300): Indicates if the vehicle is on the ground
- control status (1301): Current control status
- do switchover (1302): Command to switch control systems
- ttcg wp is valid (1303): Indicates if the current waypoint is valid
- self arm enabled (1304): Self-arming capability status
- mixer is saturated (1305): Indicates if the mixer is at saturation limits
- recovery is in control (1306): Indicates if recovery system has control
- recovery tracking has started (1307): Recovery tracking status
- recovery is armed allowed (1308): Recovery arming permission status
- recovery arming disallowed (1309): Recovery arming restriction status
- recovery takeoff executed (1310): Recovery takeoff status
- recovery initial tracking point set (1311): Initial tracking point status

#### 7.2.3 Mission Status Flags (IDs 1330-1339)
- mission_has_flight_id (1330): Flight ID presence
- mission_has_version (1331): Mission version presence
- mission_has_crs (1332): CRS presence
- mission_has_initial_plan (1333): Initial plan presence
- mission_has_takeoff_bounding_volume (1334): Takeoff bounding volume presence
- is_mission_plan_data_valid (1335): Mission plan data validity
- is_upload_mission_plan_wrapper_valid (1336): Mission plan wrapper validity
- is_mission_plan_data_cached (1337): Mission plan data cache status
- is_mission_metadata_received (1338): Mission metadata reception status
- is_mission_deserialized_successfully (1339): Mission deserialization status

## 8. Variable Mapping and Initial Covariance Matrix

### 8.1 Variable Mapping (ver_spdif_mvars.xml)
- **File ID**: 278
- **Filename**: mvars.bin
- **Version**: 7.3.1
- Defines empty mappings for six different variable types (0, 2, 3, 4, 5, 6)

### 8.2 Initial Covariance Matrix (ver_spdif_pk0.xml)
- **File ID**: 89
- **Filename**: pk0.bin
- **Version**: 7.3.1
- Defines a 16x16 covariance matrix with all elements initialized to 0.0

## 9. Key System Relationships and Parameters

### 9.1 System Architecture
The PDI Recovery1 system appears to be a sophisticated flight control and recovery system for a hexacopter (6 motors) with VTOL capabilities and transition to forward flight. The system components form a hierarchical structure:

1. **Configuration Manager**: Provides base settings for all components
2. **State Estimation**: Processes sensor data to determine vehicle state
3. **Trajectory Generation**: Plans paths based on mission requirements
4. **Control Command Generation**: Converts trajectories to control commands
5. **Mixer**: Translates commands to motor outputs
6. **Monitoring System**: Tracks performance across all components

### 9.2 Critical Parameters
- **Vehicle Configuration**: Hexacopter (6 motors) with no control surfaces
- **Recovery Capability**: Switchover enabled with 5-second motor arm delay
- **Navigation Accuracy**: 15m horizontal, 25m vertical position accuracy limits
- **Safety Boundaries**: 10m x 10m x 20m protected volume
- **Wind Handling**: 12.8m/s gust threshold with weathervaning above 2.0m/s
- **Takeoff Parameters**: Requires 4 motors at minimum 1500 RPM
- **Landing Detection**: 0.25m/s vertical velocity threshold

### 9.3 Performance Monitoring
The system implements extensive performance monitoring with:
- Maximum and average execution time tracking for all components
- High-frequency telemetry (20Hz for most data, 10Hz for additional data)
- Detailed timing metrics for critical path operations

### 9.4 Contingency Handling
Multiple contingency mechanisms are implemented:
- Attitude contingency mode blending (2.0s transition time)
- Battery state of charge thresholds for contingency planning
- Wind gust detection and command skipping
- Bounding box protection for spatial containment

## 10. Conclusion

The PDI Recovery1 system is a comprehensive flight control and recovery system with sophisticated configuration, monitoring, and telemetry capabilities. The system emphasizes safety through multiple layers of monitoring and contingency handling while providing detailed performance metrics for system optimization.

The consistent version numbering (7.3.1) across all configuration files indicates a coordinated release, ensuring compatibility between components. The system's architecture supports both normal flight operations and recovery scenarios, with particular attention to the transition between flight modes and handling of off-nominal conditions.

The extensive monitoring variables and telemetry streams suggest a system designed for detailed post-flight analysis and continuous improvement, while the comprehensive recovery parameters indicate a focus on operational safety and reliability.