# Generated from:

- code/sw_vbootloader_astro/code/include/Bootloader_astro.h (413 tokens)
- code/sw_vbootloader_astro/code/source_astro/Bootloader_astro.cpp (944 tokens)
- code/sw_vbootloader_astro/code/source_astro/Bootloader_pa.cpp (1245 tokens)
- code/sw_vbootloader_astro/code/source_astro/main_2838x_bldr_astro.cpp (1333 tokens)

---

# Astro Bootloader Architecture Analysis

## 1. Core Architecture Overview

The Astro bootloader is a sophisticated multi-core bootloader system designed for the Astro platform. It follows a hierarchical class structure with specialized components for the Astro hardware configuration.

### Class Hierarchy

```
Bootloader (Base class)
    └── Bootloader_dual (Intermediate class)
        └── Bootloader_astro (Specialized implementation)
```

The architecture employs a factory pattern for bootloader instantiation through the `Bootloader_dual::build()` static method, which creates and returns a singleton instance of `Bootloader_astro`.

### Core Components

1. **Bootloader_astro**: Specialized implementation for the Astro platform
   - Extends `Bootloader_dual` with Astro-specific hardware interfaces
   - Manages SPI flash memory access through MX66L driver
   - Implements file system functionality via DFS2_fs

2. **Multi-Core Management**:
   - Manages three cores: C1 (main core), C2 (secondary core), and CM (communication/management core)
   - Defines memory regions for each core in the bootloader parameters
   - Uses IPC (Inter-Processor Communication) mechanisms for core coordination

3. **Hardware Interfaces**:
   - SPI interface for flash memory access
   - GPIO management for various control signals
   - CAN bus interfaces for communication
   - Security features including DCSM (Device Configuration and Security Module)

## 2. Initialization Sequence

The bootloader initialization follows a precise sequence:

1. **System Security Setup**:
   - Optional ECSL_only() function to secure the device and limit to JTAG access
   - Configures DCSM zones and security keys

2. **Parameter Configuration**:
   - Sets up memory regions for bootloader and application code for all cores
   - Defines core management bitmap (which cores are managed by the bootloader)

3. **Shared Memory Setup**:
   - Initializes CPU1-CM shared memory structure
   - Sets system UID, address, Ethernet MAC, IP configuration
   - Configures communication ports based on application type

4. **CM Core Initialization**:
   - Turns off CM core
   - Starts CM initialization with Ethernet configuration
   - Sets up heartbeat LED
   - Forces CM into bootloader mode
   - Boots CM core
   - Clears command

5. **Address Handler Setup**:
   - Creates Address_handler with system address and core management configuration

6. **Bootloader Instantiation**:
   - Calls `Bootloader_dual::build()` to create the bootloader instance
   - Completes CM initialization

7. **Bootloader Execution**:
   - Calls `bldr.run()` to start the main bootloader execution

## 3. Memory Management

The bootloader implements a sophisticated memory management scheme:

```
Flash Memory Layout:
- Flash Start: 0x80000
- Flash Size: 0x40000 words
- Bootloader Region: 0x80000 to 0x8FFFF (0x10000 words)
- User Code Region: 0x90000 to 0xBFFFF (0x30000 words)
```

Memory regions are defined for each core:
- C1 (Core 1): User code region in main flash
- C2 (Core 2): Flash region
- CM (Communication Module): Separate memory region defined by cm_user_start and cm_user_size

The `Bldr_mgr::Params` structure defines these memory regions and core management configuration:
```cpp
static Bldr_mgr::Params par = {
    { bldr_start, words16_to_bytes_c<bldr_size>::value },    // Bootloader data block (in bytes)
    {
        3,  // Number of cores
        {
            {
                { user_start, words16_to_bytes_c<user_size>::value },    // User data block in C1 (in bytes)
                { flash_start, words16_to_bytes_c<flash_size>::value},   // User data block in C2 (in bytes)
                { cm_user_start, cm_user_size }                          // User data block in CM (in bytes)
            }
        }
    },
    { (1U << Bldr_mgr::c1_core_index) | (1U << Bldr_mgr::c2_core_index) } // Core management bitmap
};
```

## 4. Bootloader_astro Implementation

The `Bootloader_astro` class extends `Bootloader_dual` with Astro-specific hardware interfaces:

### Components
- **SPI Interface**: `spic` - SPI-C device for flash communication
- **GPIO Management**: `flash_cs` - Chip Select for SPI-C flash memory
- **Flash Driver**: `drv` - MX66L driver for flash memory operations
- **File System**: `fs` - DFS2_fs file system implementation
- **Support Components**:
  - `tprov_null` - Null Time Provider instance
  - `rnull` - Null Reset instance
  - `format_hnd` - File system format handler

### Initialization Process
1. Initializes parent class (`Bootloader_dual`)
2. Configures GPIO pins for SPI-C interface
3. Configures SPI-C with specific parameters (12.5MHz speed, 8-bit mode)
4. Configures flash chip select GPIO
5. Registers format handler with STANAG message manager
6. Initializes the file system

## 5. CAN Bus Configuration

The bootloader implements sophisticated CAN bus configuration for communication:

### CAN Configuration Methods
- `set_can_in_cfg()`: Configures CAN input filters
- `set_can_cfg()`: Sets up CAN input/output and SerialCAN configurations
- `config_can()`: Main CAN configuration method

### CAN Bus Setup Process
1. Configures GPIO pins for CAN interfaces
2. Sets up transceiver enable and standby pins
3. Applies default CAN configuration (500kbps)
4. Configures CAN filters based on node ID
5. Enables transceivers with appropriate security settings
6. Configures CAN FD with 500kbps nominal rate and 2Mbps data rate

### Secure CAN Implementation
The bootloader uses `Secure_CAN` class to manage CAN transceivers:
- Controls enable and standby pins for transceivers
- Implements security measures for CAN communication
- Supports different configurations for commands vs. normal operation

## 6. Security Features

The bootloader implements several security mechanisms:

### DCSM (Device Configuration and Security Module)
- Configures security zones (Zone 1 and Zone 2)
- Sets security keys to protect device access
- Can force security settings if device is found unsecured

### Secure Boot
- The bootloader likely implements signature verification (implied by the ECDSA reference in the special instructions)
- Uses SHA-256 hashing (referenced by the inclusion of sha256.h)
- Implements ECC (Elliptic Curve Cryptography) utilities (referenced by ecc_util.h)

### Application Header Verification
- Verifies application bootloader header mark
- Issues warning if header mark is invalid

## 7. Factory Pattern Implementation

The bootloader uses a factory pattern for instantiation:

```cpp
Bootloader_dual& Bootloader_dual::build(Bldr_mgr::Params par, Base::IAddress_handler & addr_handler)
{
    static Bootloader_astro bldr2(par, addr_handler);
    return bldr2;
}
```

This pattern:
- Creates a singleton instance of `Bootloader_astro`
- Returns it as a reference to the base class `Bootloader_dual`
- Allows for polymorphic behavior while hiding implementation details
- Ensures only one bootloader instance exists throughout the system

## 8. Inter-Core Communication

The bootloader manages communication between cores:

### Shared Memory
- Uses `CPU1_CM_shared` structure for data sharing between C1 and CM cores
- Populates shared memory with system configuration:
  - UID (Unique Identifier)
  - System address
  - Ethernet MAC address
  - IP configuration
  - Communication ports
  - Heartbeat LED ID

### IPC Mechanisms
- Uses `Ipc` class for inter-processor communication
- Controls CM core state (turn off, boot)
- Sends commands to CM core (e.g., force bootloader mode)
- Synchronizes initialization between cores

## 9. Hardware Interface Management

The bootloader implements comprehensive hardware interface management:

### GPIO Configuration
- Configures pins for various interfaces (SPI, CAN)
- Sets up control signals (chip select, transceiver enable/standby)
- Manages heartbeat LED

### SPI Configuration
- Sets up SPI-C interface for flash memory communication
- Configures speed (12.5MHz), mode (mode 0), and data width (8 bits)

### Flash Memory Interface
- Uses MX66L driver to communicate with flash memory
- Implements file system operations through DFS2_fs
- Supports file system formatting through HformatSD handler

## 10. Main Execution Flow

The main execution flow of the bootloader:

1. Optional security configuration (ECSL_only)
2. Parameter and memory region setup
3. Shared memory initialization
4. CM core initialization and boot sequence
5. Address handler creation
6. Bootloader instantiation through factory method
7. CM initialization completion
8. Bootloader execution (bldr.run())

The bootloader then likely performs:
- Application image verification
- Core initialization
- Application loading and execution
- Communication with host systems
- Update management

## Referenced Context Files

No context files were provided in the input, so this section is not applicable.