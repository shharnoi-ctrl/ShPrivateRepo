# Generated from:

- items/pdi_Recovery1/setup/ver_spdif_status.xml (72 tokens)
- items/pdi_Recovery1/setup/ver_spdif_modes.xml (50 tokens)
- items/pdi_Recovery1/setup/ver_spdif_mmodes.xml (51 tokens)
- items/pdi_Recovery1/setup/ver_spdif_maction.xml (122 tokens)
- items/pdi_Recovery1/setup/ver_spdif_mcheck.xml (156 tokens)
- items/pdi_Recovery1/setup/ver_spdif_mdev.xml (86 tokens)
- items/pdi_Recovery1/setup/ver_spdif_mevent.xml (311 tokens)
- items/pdi_Recovery1/setup/ver_spdif_mevact.xml (58 tokens)
- items/pdi_Recovery1/setup/ver_spdif_mmission.xml (53 tokens)
- items/pdi_Recovery1/setup/ver_spdif_mname.xml (57 tokens)
- items/pdi_Recovery1/setup/ver_spdif_mnotif.xml (58 tokens)
- items/pdi_Recovery1/setup/ver_spdif_mstep.xml (57 tokens)
- items/pdi_Recovery1/setup/ver_spdif_mexvar.xml (58 tokens)
- items/pdi_Recovery1/setup/ver_spdif_m4xow.xml (62 tokens)
- items/pdi_Recovery1/setup/ver_spdif_mxplane.xml (76 tokens)
- items/pdi_Recovery1/setup/ver_spdif_mvxmap.xml (62 tokens)
- items/pdi_Recovery1/setup/ver_spdif_actions.xml (60 tokens)
- items/pdi_Recovery1/setup/ver_spdif_events.xml (51 tokens)
- items/pdi_Recovery1/setup/ver_spdif_evact.xml (50 tokens)
- items/pdi_Recovery1/setup/ver_spdif_limits.xml (51 tokens)
- items/pdi_Recovery1/setup/ver_spdif_oprrng.xml (51 tokens)
- items/pdi_Recovery1/setup/ver_spdif_pdi_mode.xml (63 tokens)
- items/pdi_Recovery1/setup/ver_spdif_varini.xml (127 tokens)
- items/pdi_Recovery1/setup/ver_spdif_fstr.xml (150 tokens)
- items/pdi_Recovery1/setup/ver_spdif_fstr1.xml (50 tokens)
- items/pdi_Recovery1/setup/ver_spdif_fstr100.xml (127 tokens)
- items/pdi_Recovery1/setup/ver_spdif_fmsg_c.xml (132 tokens)
- items/pdi_Recovery1/setup/ver_spdif_fmsg_p.xml (106 tokens)
- items/pdi_Recovery1/setup/ver_spdif_freqmgr.xml (76 tokens)
- items/pdi_Recovery1/setup/ver_spdif_chnmgr.xml (65 tokens)
- items/pdi_Recovery1/setup/ver_spdif_mchannel.xml (61 tokens)
- items/pdi_Recovery1/setup/ver_spdif_agname.xml (63 tokens)
- items/pdi_Recovery1/setup/ver_spdif_arcx.xml (49 tokens)
- items/pdi_Recovery1/setup/ver_spdif_cbitcfg.xml (68 tokens)
- items/pdi_Recovery1/setup/ver_spdif_chklist.xml (52 tokens)
- items/pdi_Recovery1/setup/ver_spdif_dpqr.xml (81 tokens)
- items/pdi_Recovery1/setup/ver_spdif_extobs.xml (82 tokens)
- items/pdi_Recovery1/setup/ver_spdif_intnest.xml (147 tokens)
- items/pdi_Recovery1/setup/ver_spdif_metaop.xml (58 tokens)
- items/pdi_Recovery1/setup/ver_spdif_metatc.xml (58 tokens)
- items/pdi_Recovery1/setup/ver_spdif_mrtcm.xml (93 tokens)
- items/pdi_Recovery1/setup/ver_spdif_overwrit.xml (92 tokens)
- items/pdi_Recovery1/setup/ver_spdif_pfields.xml (52 tokens)
- items/pdi_Recovery1/setup/ver_spdif_sniffer.xml (52 tokens)
- items/pdi_Recovery1/setup/ver_spdif_us76ex.xml (135 tokens)
- items/pdi_Recovery1/production/ver_ppdif_arbaddr.xml (79 tokens)

---

# PDI Recovery1 System Configuration Analysis

This document provides a comprehensive analysis of the configuration files for the PDI Recovery1 system, organized by functional categories. These XML files define the system's behavior, parameters, and integration points.

## 1. System Status and Version Configuration

### Status Configuration (`ver_spdif_status.xml`)
- **ID**: 51
- **Filename**: status.bin
- **Version**: 7.3.1
- **Key Parameters**:
  - `vcp_tx_enabled`: Set to 1 (enabled)
  - `period`: 1.0 seconds - defines the status transmission period

### PDI Mode Configuration (`ver_spdif_pdi_mode.xml`)
- **ID**: 354
- **Filename**: pdi_mode.bin
- **Version**: 7.3.1
- **Key Parameters**:
  - `pdi_mode`: Set to 0 - indicates the default operating mode

## 2. Frequency and Timing Management

### Frequency Manager Configuration (`ver_spdif_freqmgr.xml`)
- **ID**: 25
- **Filename**: freqmgr.bin
- **Version**: 7.3.1
- **Key Parameters**:
  - `period_acq`: 9.90099E-4 seconds (approximately 1ms) - acquisition period
  - `period_gnc`: 0.015625 seconds (approximately 15.6ms) - guidance, navigation, and control period

### Field Stream Configuration (`ver_spdif_fstr.xml`)
- **ID**: 61
- **Filename**: fstr.bin
- **Version**: 7.3.1
- **Key Parameters**:
  - `periode`: 0.1 seconds - defines the field stream update period
  - `fields`: Contains a real-float32 field with ID 300 and scale 1.0

### Field Stream 100 Configuration (`ver_spdif_fstr100.xml`)
- **ID**: 62
- **Filename**: fstr100.bin
- **Version**: 7.3.1
- **Key Parameters**:
  - Contains a real-float32 field with ID 300 and scale 1.0

### Field Stream 1 Configuration (`ver_spdif_fstr1.xml`)
- **ID**: 59
- **Filename**: fstr1.bin
- **Version**: 7.3.1
- **Data**: Empty configuration

## 3. Mission and Mode Management

### Mission Modes Configuration (`ver_spdif_mmodes.xml`)
- **ID**: 127
- **Filename**: mmodes.bin
- **Version**: 7.3.1
- **Data**: Empty configuration

### Mission Configuration (`ver_spdif_mmission.xml`)
- **ID**: 125
- **Filename**: mmission.bin
- **Version**: 7.3.1
- **Data**: Empty configuration

### Mission Name Configuration (`ver_spdif_mname.xml`)
- **ID**: 126
- **Filename**: mname.bin
- **Version**: 7.3.1
- **Data**: Empty name field

### Modes Configuration (`ver_spdif_modes.xml`)
- **ID**: 27
- **Filename**: modes.bin
- **Version**: 7.3.1
- **Data**: Empty configuration

## 4. Event and Action Management

### Mission Event Configuration (`ver_spdif_mevent.xml`)
- **ID**: 128
- **Filename**: mevent.bin
- **Version**: 7.3.1
- **Key Parameters**:
  - Contains an event named "BIT == 1" that checks variable ID 4101
  - Icon: 10
  - Time control: 0.0
  - Check parameters: 0 (check disabled), checkTime: 0

### Mission Action Configuration (`ver_spdif_maction.xml`)
- **ID**: 130
- **Filename**: maction.bin
- **Version**: 7.3.1
- **Key Parameters**:
  - Contains an action named "GPIO HI"

### Mission Event-Action Configuration (`ver_spdif_mevact.xml`)
- **ID**: 129
- **Filename**: mevact.bin
- **Version**: 7.3.1
- **Data**: Empty map

### Events Configuration (`ver_spdif_events.xml`)
- **ID**: 82
- **Filename**: events.bin
- **Version**: 7.3.1
- **Data**: Empty configuration

### Actions Configuration (`ver_spdif_actions.xml`)
- **ID**: 83
- **Filename**: actions.bin
- **Version**: 7.3.1
- **Key Parameters**:
  - Contains an empty action-array

### Event-Action Configuration (`ver_spdif_evact.xml`)
- **ID**: 84
- **Filename**: evact.bin
- **Version**: 7.3.1
- **Data**: Empty configuration

## 5. Device and Channel Management

### Mission Device Configuration (`ver_spdif_mdev.xml`)
- **ID**: 147
- **Filename**: mdev.bin
- **Version**: 7.3.1
- **Key Parameters**:
  - Empty cameras configuration
  - Empty drop-system-array

### Channel Manager Configuration (`ver_spdif_chnmgr.xml`)
- **ID**: 10
- **Filename**: chnmgr.bin
- **Version**: 7.3.1
- **Key Parameters**:
  - Empty configs and channels sections

### Meta Channel Configuration (`ver_spdif_mchannel.xml`)
- **ID**: 131
- **Filename**: mchannel.bin
- **Version**: 7.3.1
- **Data**: Empty map

## 6. Variable and Parameter Management

### Variable Initialization Configuration (`ver_spdif_varini.xml`)
- **ID**: 6
- **Filename**: varini.bin
- **Version**: 7.3.1
- **Key Parameters**:
  - Variable ID 3200 (type 0): initialized to 150.0
  - Variable ID 1117 (type 2): initialized to 3.0

### Mission External Variable Configuration (`ver_spdif_mexvar.xml`)
- **ID**: 142
- **Filename**: mexvar.bin
- **Version**: 7.3.1
- **Data**: Empty map

### Meta Overwrite Configuration (`ver_spdif_m4xow.xml`)
- **ID**: 214
- **Filename**: m4xow.bin
- **Version**: 7.3.1
- **Data**: Empty map

### Overwrite Configuration (`ver_spdif_overwrit.xml`)
- **ID**: 91
- **Filename**: overwrit.bin
- **Version**: 7.3.1
- **Key Parameters**:
  - `enabled`: 0 (disabled)
  - Empty cfg section
  - `period`: 0.0
  - `arb_addr.uav`: 4278190080 (255.255.255.0 in IP format)

## 7. Check and Verification Systems

### Mission Check Configuration (`ver_spdif_mcheck.xml`)
- **ID**: 141
- **Filename**: mcheck.bin
- **Version**: 7.3.1
- **Key Parameters**:
  - Icon: 46
  - Time control: 0.0
  - Check: 0 (disabled)
  - Check time: 0

### Checklist Configuration (`ver_spdif_chklist.xml`)
- **ID**: 92
- **Filename**: chklist.bin
- **Version**: 7.3.1
- **Data**: Empty configuration

### Continuous Built-In Test Configuration (`ver_spdif_cbitcfg.xml`)
- **ID**: 270
- **Filename**: cbitcfg.bin
- **Version**: 7.3.1
- **Key Parameters**:
  - Empty bits_0, bits_1, and bits_2 sections

### Limits Configuration (`ver_spdif_limits.xml`)
- **ID**: 88
- **Filename**: limits.bin
- **Version**: 7.3.1
- **Data**: Empty configuration

### Operating Range Configuration (`ver_spdif_oprrng.xml`)
- **ID**: 4
- **Filename**: oprrng.bin
- **Version**: 7.3.1
- **Data**: Empty configuration

## 8. External Systems Integration

### X-Plane Integration Configuration (`ver_spdif_mxplane.xml`)
- **ID**: 149
- **Filename**: mxplane.bin
- **Version**: 7.3.1
- **Key Parameters**:
  - Empty data-veronte and data-xplane sections

### Veronte Variable Mapping (`ver_spdif_mvxmap.xml`)
- **ID**: 132
- **Filename**: mvxmap.bin
- **Version**: 7.3.1
- **Key Parameters**:
  - Empty data-to-veronte-vref section

### RTCM Configuration (`ver_spdif_mrtcm.xml`)
- **ID**: 144
- **Filename**: mrtcm.bin
- **Version**: 7.3.1
- **Key Parameters**:
  - `enabled`: 0 (disabled)
  - `timeBetweeMsg`: 300.0 seconds
  - Empty host field
  - `port`: 0
  - Empty user and pass fields
  - Empty stream field

### External Obstacles Configuration (`ver_spdif_extobs.xml`)
- **ID**: 152
- **Filename**: extobs.bin
- **Version**: 7.3.1
- **Key Parameters**:
  - `enable`: 0 (disabled)
  - `time`: 1.0 second

### US Standard Atmosphere 1976 Extended Configuration (`ver_spdif_us76ex.xml`)
- **ID**: 40
- **Filename**: us76ex.bin
- **Version**: 7.3.1
- **Key Parameters**:
  - `enable`: 0 (disabled)
  - `addr.uav`: 4278190080 (255.255.255.0 in IP format)
  - `period`: 60.0 seconds
  - `ext-alt`: 1 (enabled)
  - `alt`: Reference to a constant value of 0.0
  - `T1`: 288.16 (standard temperature at sea level in Kelvin)

## 9. Message and Communication Configuration

### Field Message Configuration (Client) (`ver_spdif_fmsg_c.xml`)
- **ID**: 75
- **Filename**: fmsg_c.bin
- **Version**: 7.3.1
- **Key Parameters**:
  - Three empty data elements with keys 0, 1, and 2

### Field Message Configuration (Provider) (`ver_spdif_fmsg_p.xml`)
- **ID**: 74
- **Filename**: fmsg_p.bin
- **Version**: 7.3.1
- **Key Parameters**:
  - Two empty data elements with keys 0 and 1

### Sniffer Configuration (`ver_spdif_sniffer.xml`)
- **ID**: 63
- **Filename**: sniffer.bin
- **Version**: 7.3.1
- **Data**: Empty configuration

## 10. Mission Step and Notification Management

### Mission Step Configuration (`ver_spdif_mstep.xml`)
- **ID**: 143
- **Filename**: mstep.bin
- **Version**: 7.3.1
- **Data**: Empty map

### Mission Notification Configuration (`ver_spdif_mnotif.xml`)
- **ID**: 145
- **Filename**: mnotif.bin
- **Version**: 7.3.1
- **Data**: Empty map

## 11. Miscellaneous Configurations

### DPQR Configuration (`ver_spdif_dpqr.xml`)
- **ID**: 28
- **Filename**: dpqr.bin
- **Version**: 7.3.1
- **Key Parameters**:
  - Two values: 1.0 and -1.0

### Internal Nest Configuration (`ver_spdif_intnest.xml`)
- **ID**: 93
- **Filename**: intnest.bin
- **Version**: 7.3.1
- **Key Parameters**:
  - `inst_version`: 0
  - `inst_range`: 15.0
  - `inst_baserot`: Identity matrix (3x3 matrix with 1s on diagonal, 0s elsewhere)

### Archive Configuration (`ver_spdif_arcx.xml`)
- **ID**: 23
- **Filename**: arcx.bin
- **Version**: 7.3.1
- **Data**: Empty configuration

### Meta Operation Configuration (`ver_spdif_metaop.xml`)
- **ID**: 140
- **Filename**: metaop.bin
- **Version**: 7.3.1
- **Data**: Empty map

### Meta TC Configuration (`ver_spdif_metatc.xml`)
- **ID**: 139
- **Filename**: metatc.bin
- **Version**: 7.3.1
- **Data**: Empty data section

### Automations Group Name Configuration (`ver_spdif_agname.xml`)
- **ID**: 150
- **Filename**: agname.bin
- **Version**: 7.3.1
- **Data**: Empty map

### Parameter Fields Configuration (`ver_spdif_pfields.xml`)
- **ID**: 119
- **Filename**: pfields.bin
- **Version**: 7.3.1
- **Data**: Empty configuration

## 12. System Addressing Configuration

### Arbiter Address Configuration (`ver_ppdif_arbaddr.xml`)
- **ID**: 80
- **Filename**: arbaddr.bin
- **Version**: 7.3.1
- **Key Parameters**:
  - `arbaddr.uav`: 999 - System's unique address identifier
  - Empty apaddrs section

## System Integration Analysis

The PDI Recovery1 system configuration reveals several key insights:

1. **System Status and Communication**:
   - The system has status transmission enabled with a 1-second period
   - Operating in default PDI mode (0)

2. **Timing and Frequency Management**:
   - Acquisition cycle runs at approximately 1ms (9.90099E-4 seconds)
   - GNC (Guidance, Navigation, Control) cycle runs at approximately 15.6ms (0.015625 seconds)
   - Field stream updates occur every 0.1 seconds

3. **Variable Initialization**:
   - Two variables are explicitly initialized:
     - Variable 3200 (type 0) set to 150.0
     - Variable 1117 (type 2) set to 3.0

4. **Event Handling**:
   - One event defined ("BIT == 1") that checks variable 4101
   - One action defined ("GPIO HI")
   - Event checking is currently disabled (check parameter set to 0)

5. **External System Integration**:
   - Multiple external systems are configured but disabled:
     - RTCM integration (disabled)
     - External obstacles detection (disabled)
     - US Standard Atmosphere model (disabled)
     - X-Plane integration (configured but empty)

6. **Addressing**:
   - System has arbiter address 999
   - Default network address 255.255.255.0 (4278190080) used in multiple configurations

7. **Feature Status**:
   - Most features appear to be disabled or have empty configurations
   - Status transmission is one of the few explicitly enabled features

The configuration suggests a system that is either in early setup stages or intentionally running with minimal features enabled. The core timing parameters (acquisition and GNC cycles) are defined, along with basic status reporting, but most advanced features remain unconfigured or disabled.

## Referenced Context Files

No context files were provided in the input.