# Generated from:

- items/pdi_Recovery0/setup/ver_spdif_imu0.xml (241 tokens)
- items/pdi_Recovery0/setup/ver_spdif_imu1.xml (241 tokens)
- items/pdi_Recovery0/setup/ver_spdif_imu2.xml (137 tokens)
- items/pdi_Recovery0/setup/ver_spdif_imu3.xml (128 tokens)
- items/pdi_Recovery0/setup/ver_spdif_imugeom.xml (122 tokens)
- items/pdi_Recovery0/setup/ver_spdif_imupos.xml (78 tokens)
- items/pdi_Recovery0/setup/ver_spdif_gyrsuite.xml (325 tokens)
- items/pdi_Recovery0/setup/ver_spdif_accsuite.xml (325 tokens)
- items/pdi_Recovery0/setup/ver_spdif_gyr0filt.xml (172 tokens)
- items/pdi_Recovery0/setup/ver_spdif_gyr1filt.xml (172 tokens)
- items/pdi_Recovery0/setup/ver_spdif_gyr2filt.xml (172 tokens)
- items/pdi_Recovery0/setup/ver_spdif_gyr3filt.xml (172 tokens)
- items/pdi_Recovery0/setup/ver_spdif_acc0filt.xml (172 tokens)
- items/pdi_Recovery0/setup/ver_spdif_acc1filt.xml (172 tokens)
- items/pdi_Recovery0/setup/ver_spdif_acc2filt.xml (172 tokens)
- items/pdi_Recovery0/setup/ver_spdif_acc3filt.xml (172 tokens)
- items/pdi_Recovery0/setup/ver_spdif_mag0filt.xml (105 tokens)
- items/pdi_Recovery0/setup/ver_spdif_mag2filt.xml (105 tokens)
- items/pdi_Recovery0/setup/ver_spdif_mag3filt.xml (105 tokens)
- items/pdi_Recovery0/setup/ver_spdif_mag4filt.xml (105 tokens)
- items/pdi_Recovery0/setup/ver_spdif_mag5filt.xml (105 tokens)
- items/pdi_Recovery0/setup/ver_spdif_mag6filt.xml (105 tokens)
- items/pdi_Recovery0/setup/ver_spdif_mag7filt.xml (107 tokens)
- items/pdi_Recovery0/setup/ver_spdif_magResfilt.xml (106 tokens)
- items/pdi_Recovery0/setup/ver_spdif_gyrlps.xml (334 tokens)
- items/pdi_Recovery0/setup/ver_spdif_acclps.xml (334 tokens)
- items/pdi_Recovery0/setup/ver_spdif_maglps.xml (684 tokens)
- items/pdi_Recovery0/setup/ver_spdif_extgyr0.xml (136 tokens)
- items/pdi_Recovery0/setup/ver_spdif_extgyr1.xml (136 tokens)
- items/pdi_Recovery0/setup/ver_spdif_extmag0.xml (136 tokens)
- items/pdi_Recovery0/setup/ver_spdif_extmag1.xml (136 tokens)
- items/pdi_Recovery0/setup/ver_spdif_extacc0.xml (136 tokens)
- items/pdi_Recovery0/setup/ver_spdif_extacc1.xml (136 tokens)
- items/pdi_Recovery0/setup/ver_spdif_extnavsen.xml (92 tokens)
- items/pdi_Recovery0/setup/ver_spdif_extobs.xml (82 tokens)
- items/pdi_Recovery0/setup/ver_spdif_vargyr.xml (237 tokens)
- items/pdi_Recovery0/setup/ver_spdif_varacc.xml (237 tokens)
- items/pdi_Recovery0/setup/ver_spdif_varmag.xml (237 tokens)
- items/pdi_Recovery0/setup/ver_spdif_varstp.xml (198 tokens)
- items/pdi_Recovery0/setup/ver_spdif_stp0filt.xml (103 tokens)
- items/pdi_Recovery0/setup/ver_spdif_stp1filt.xml (103 tokens)
- items/pdi_Recovery0/setup/ver_spdif_stp2filt.xml (104 tokens)
- items/pdi_Recovery0/setup/ver_spdif_qinffilt.xml (103 tokens)
- items/pdi_Recovery0/setup/ver_spdif_varqinf.xml (198 tokens)

## With context from:

- Amazon-PrimeAir/items/ASTRO/items/EV2/Recovery 0/04_Sensor_Calibration_System.md (4221 tokens)

---

# IMU and Sensor Configuration Analysis for Recovery System

## 1. Overview of Sensor Configuration System

The recovery system employs a sophisticated sensor configuration framework that works in conjunction with the previously analyzed calibration system. This configuration system defines the operational parameters, filtering options, data validation mechanisms, and sensor fusion approach for four Inertial Measurement Units (IMUs) and various auxiliary sensors. The configuration files establish how raw sensor data is processed before the calibration parameters (analyzed previously) are applied.

## 2. IMU Configuration Architecture

### 2.1 IMU Hardware Configuration

The recovery system incorporates four distinct IMUs, each with its own configuration file:

| IMU | File | ID | Purpose |
|-----|------|-----|---------|
| IMU0 | ver_spdif_imu0.xml | 102 | Primary IMU with high-precision gyro and accelerometer |
| IMU1 | ver_spdif_imu1.xml | 103 | Secondary IMU with identical configuration to IMU0 (redundancy) |
| IMU2 | ver_spdif_imu2.xml | 256 | Tertiary IMU with different sensor parameters |
| IMU3 | ver_spdif_imu3.xml | 360 | Quaternary IMU with minimal configuration |

Each IMU has specific configuration parameters that define its operational characteristics, sampling rates, and filtering options.

### 2.2 IMU Geometry and Positioning

Two key files define the spatial arrangement of the IMUs:

1. **IMU Geometry** (`ver_spdif_imugeom.xml`, ID: 52):
   - Defines the orientation matrix `Lbp` that maps between body frame and platform frame
   - Currently set as an identity matrix (1.0 on diagonal, 0.0 elsewhere)
   - This indicates the IMU coordinate system is aligned with the platform coordinate system

2. **IMU Position** (`ver_spdif_imupos.xml`, ID: 53):
   - Defines the position vector `GIb` of the IMU relative to the platform's center of gravity
   - Currently set to [0.0, 0.0, 0.0], indicating the IMU is positioned at the center of gravity
   - This positioning eliminates lever arm effects in acceleration measurements

## 3. IMU-Specific Configurations

### 3.1 IMU0 and IMU1 Configuration (Identical)

Files: `ver_spdif_imu0.xml` (ID: 102) and `ver_spdif_imu1.xml` (ID: 103)

These two IMUs have identical configurations, suggesting they serve as redundant primary sensors:

```xml
<data>
    <accelRange>4</accelRange>                <!-- ±4g range -->
    <accelSampleRate>160</accelSampleRate>    <!-- 160 Hz sampling -->
    <accelbw>0</accelbw>                      <!-- Bandwidth setting 0 -->
    <enOutDr>1</enOutDr>                      <!-- Output data ready signal enabled -->
    <linear_lpf2>0</linear_lpf2>              <!-- Linear LPF2 disabled -->
    <accel_dso_lpf2_en>0</accel_dso_lpf2_en>  <!-- DSO LPF2 disabled -->
    <accel_dso_lpf2_fc>0</accel_dso_lpf2_fc>  <!-- DSO LPF2 cutoff frequency 0 -->
    <gyroRange>12</gyroRange>                 <!-- ±12 deg/s range -->
    <gyroSampleRate>128</gyroSampleRate>      <!-- 128 Hz sampling -->
    <gyroHpfEn>0</gyroHpfEn>                  <!-- High-pass filter disabled -->
    <gyroHpf>0</gyroHpf>                      <!-- High-pass filter setting 0 -->
    <gyro_dso_lpf1_en>0</gyro_dso_lpf1_en>    <!-- DSO LPF1 disabled -->
    <gyro_dso_lpf1_fc>0</gyro_dso_lpf1_fc>    <!-- DSO LPF1 cutoff frequency 0 -->
    <temp_enabled>1</temp_enabled>            <!-- Temperature sensor enabled -->
    <accel_max_nv_samples>10</accel_max_nv_samples>  <!-- Max 10 non-valid accelerometer samples -->
    <gyro_max_nv_samples>10</gyro_max_nv_samples>    <!-- Max 10 non-valid gyroscope samples -->
    <acc_max_delta>313.8128</acc_max_delta>   <!-- Max allowed delta between consecutive accel readings -->
    <gyr_max_delta>69.81317</gyr_max_delta>   <!-- Max allowed delta between consecutive gyro readings (≈4 deg/s) -->
</data>
```

Key characteristics:
- Moderate accelerometer range (±4g) with high sampling rate (160 Hz)
- Low gyroscope range (±12 deg/s) with moderate sampling rate (128 Hz)
- Temperature sensing enabled for thermal compensation
- Data validation through maximum delta thresholds
- No internal filtering enabled (filtering handled externally)

### 3.2 IMU2 Configuration

File: `ver_spdif_imu2.xml` (ID: 256)

IMU2 has a different configuration structure and parameters:

```xml
<data>
    <accRange>2</accRange>                <!-- ±2g range -->
    <accODR>12</accODR>                   <!-- Output data rate setting 12 -->
    <accBWP>160</accBWP>                  <!-- Bandwidth parameter 160 Hz -->
    <accMaxNvSamples>30</accMaxNvSamples> <!-- Max 30 non-valid accelerometer samples -->
    <gyrRange>0</gyrRange>                <!-- Range setting 0 -->
    <gyrOdrBw>2</gyrOdrBw>                <!-- Output data rate and bandwidth setting 2 -->
    <gyrMaxNvSamples>30</gyrMaxNvSamples> <!-- Max 30 non-valid gyroscope samples -->
    <acc_max_delta>235.3596</acc_max_delta> <!-- Max allowed delta between consecutive accel readings -->
    <gyr_max_delta>69.81317</gyr_max_delta> <!-- Max allowed delta between consecutive gyro readings -->
</data>
```

Key characteristics:
- Lower accelerometer range (±2g) with different parameter structure
- Different gyroscope configuration with range setting 0
- Higher tolerance for non-valid samples (30 vs 10)
- Different maximum delta threshold for accelerometer

### 3.3 IMU3 Configuration

File: `ver_spdif_imu3.xml` (ID: 360)

IMU3 has a minimal configuration:

```xml
<data>
    <accMaxNvSamples>0</accMaxNvSamples>    <!-- No tolerance for non-valid accelerometer samples -->
    <gyrMaxNvSamples>0</gyrMaxNvSamples>    <!-- No tolerance for non-valid gyroscope samples -->
    <mode_32bit>0</mode_32bit>              <!-- 32-bit mode disabled -->
    <filter_stages>0</filter_stages>        <!-- No filter stages -->
    <bandwidth_370hz>0</bandwidth_370hz>    <!-- 370Hz bandwidth disabled -->
    <acc_max_delta>156.8</acc_max_delta>    <!-- Max allowed delta between consecutive accel readings -->
    <gyr_max_delta>69.81317</gyr_max_delta> <!-- Max allowed delta between consecutive gyro readings -->
</data>
```

Key characteristics:
- No tolerance for non-valid samples (strict data validation)
- No filtering enabled
- Lower maximum delta threshold for accelerometer
- Same maximum delta threshold for gyroscope as other IMUs

## 4. Sensor Suite Configurations

### 4.1 Gyroscope Suite Configuration

File: `ver_spdif_gyrsuite.xml` (ID: 3)

This file configures how multiple gyroscopes work together:

```xml
<data>
    <sel>
        <use>1</use>                <!-- Gyroscope suite enabled -->
        <def-sen>0</def-sen>        <!-- Default sensor is 0 -->
    </sel>
    <tau_v>2.0</tau_v>              <!-- Time constant for variance estimation -->
    <tau_s2>20.0</tau_s2>           <!-- Time constant for squared variance estimation -->
    <variances>
        <!-- Initial and minimum variance settings for 8 gyroscopes (s0-s7) -->
        <s0><ini_s2>1.0</ini_s2><min_s2>1.0E-4</min_s2></s0>
        <s1><ini_s2>1.0</ini_s2><min_s2>1.0E-4</min_s2></s1>
        <!-- ... s2 through s7 with identical settings ... -->
    </variances>
</data>
```

Key characteristics:
- Gyroscope suite is enabled with sensor 0 as the default
- Time constants for variance estimation (2.0 and 20.0)
- Identical initial variance (1.0) and minimum variance (1.0E-4) for all 8 gyroscopes
- This configuration supports sensor fusion across multiple gyroscopes

### 4.2 Accelerometer Suite Configuration

File: `ver_spdif_accsuite.xml` (ID: 2)

This file has an identical structure to the gyroscope suite configuration:

```xml
<data>
    <sel>
        <use>1</use>                <!-- Accelerometer suite enabled -->
        <def-sen>0</def-sen>        <!-- Default sensor is 0 -->
    </sel>
    <tau_v>2.0</tau_v>              <!-- Time constant for variance estimation -->
    <tau_s2>20.0</tau_s2>           <!-- Time constant for squared variance estimation -->
    <variances>
        <!-- Initial and minimum variance settings for 8 accelerometers (s0-s7) -->
        <s0><ini_s2>1.0</ini_s2><min_s2>1.0E-4</min_s2></s0>
        <s1><ini_s2>1.0</ini_s2><min_s2>1.0E-4</min_s2></s1>
        <!-- ... s2 through s7 with identical settings ... -->
    </variances>
</data>
```

Key characteristics:
- Accelerometer suite is enabled with sensor 0 as the default
- Identical time constants and variance settings as the gyroscope suite
- This configuration supports sensor fusion across multiple accelerometers

## 5. Sensor Filtering Configurations

### 5.1 Gyroscope Filtering

Files:
- `ver_spdif_gyr0filt.xml` (ID: 98)
- `ver_spdif_gyr1filt.xml` (ID: 108)
- `ver_spdif_gyr2filt.xml` (ID: 258)
- `ver_spdif_gyr3filt.xml` (ID: 364)

All four gyroscope filter configurations are identical:

```xml
<data>
    <notch>
        <num-harmonics>0</num-harmonics>     <!-- No harmonic notch filtering -->
        <center-freq>
            <vref-kval>
                <type>65534</type>           <!-- Reference type 65534 -->
                <kval>100.0</kval>           <!-- Reference value 100.0 -->
            </vref-kval>
        </center-freq>
        <bandwidth>20.0</bandwidth>          <!-- Notch bandwidth 20.0 Hz -->
        <notch-gain>0.5</notch-gain>         <!-- Notch gain 0.5 -->
    </notch>
    <butterworth>
        <enable>0</enable>                   <!-- Butterworth filter disabled -->
        <cutoff_freq>1.0</cutoff_freq>       <!-- Cutoff frequency 1.0 Hz (if enabled) -->
    </butterworth>
</data>
```

Key characteristics:
- Notch filter configured but not active (num-harmonics = 0)
- Butterworth low-pass filter defined but disabled
- These filters would be used to remove noise at specific frequencies if enabled

### 5.2 Accelerometer Filtering

Files:
- `ver_spdif_acc0filt.xml` (ID: 97)
- `ver_spdif_acc1filt.xml` (ID: 107)
- `ver_spdif_acc2filt.xml` (ID: 257)
- `ver_spdif_acc3filt.xml` (ID: 363)

All four accelerometer filter configurations are identical to the gyroscope filters:

```xml
<data>
    <notch>
        <num-harmonics>0</num-harmonics>     <!-- No harmonic notch filtering -->
        <center-freq>
            <vref-kval>
                <type>65534</type>           <!-- Reference type 65534 -->
                <kval>100.0</kval>           <!-- Reference value 100.0 -->
            </vref-kval>
        </center-freq>
        <bandwidth>20.0</bandwidth>          <!-- Notch bandwidth 20.0 Hz -->
        <notch-gain>0.5</notch-gain>         <!-- Notch gain 0.5 -->
    </notch>
    <butterworth>
        <enable>0</enable>                   <!-- Butterworth filter disabled -->
        <cutoff_freq>1.0</cutoff_freq>       <!-- Cutoff frequency 1.0 Hz (if enabled) -->
    </butterworth>
</data>
```

### 5.3 Magnetometer Filtering

Files:
- `ver_spdif_mag0filt.xml` (ID: 99)
- `ver_spdif_mag2filt.xml` (ID: 124)
- `ver_spdif_mag3filt.xml` (ID: 253)
- `ver_spdif_mag4filt.xml` (ID: 262)
- `ver_spdif_mag5filt.xml` (ID: 268)
- `ver_spdif_mag6filt.xml` (ID: 355)
- `ver_spdif_mag7filt.xml` (ID: 366)
- `ver_spdif_magResfilt.xml` (ID: 368)

All magnetometer filter configurations follow a simpler structure:

```xml
<data>
    <iir_cfg>
        <enable>0</enable>                   <!-- IIR filter disabled -->
        <cutoff_freq>1.0</cutoff_freq>       <!-- Cutoff frequency 1.0 Hz (if enabled) -->
    </iir_cfg>
    <max_nv_samples>0</max_nv_samples>       <!-- No tolerance for non-valid samples -->
    <max_delta>3.4028235E38</max_delta>      <!-- Effectively no limit on delta between readings -->
</data>
```

Key characteristics:
- Simple IIR filter defined but disabled
- No tolerance for non-valid samples
- Very high maximum delta threshold (effectively disabled)

### 5.4 Step Sensor Filtering

Files:
- `ver_spdif_stp0filt.xml` (ID: 105)
- `ver_spdif_stp1filt.xml` (ID: 106)
- `ver_spdif_stp2filt.xml` (ID: 261)

Step sensor filters follow the same structure as magnetometer filters but with different max_delta values:

```xml
<data>
    <iir_cfg>
        <enable>0</enable>                   <!-- IIR filter disabled -->
        <cutoff_freq>1.0</cutoff_freq>       <!-- Cutoff frequency 1.0 Hz (if enabled) -->
    </iir_cfg>
    <max_nv_samples>10</max_nv_samples>      <!-- Max 10 non-valid samples -->
    <max_delta>450.0|113.4|177.1875</max_delta> <!-- Different for each step sensor -->
</data>
```

### 5.5 Q-Inference Filtering

File: `ver_spdif_qinffilt.xml` (ID: 153)

```xml
<data>
    <iir_cfg>
        <enable>0</enable>                   <!-- IIR filter disabled -->
        <cutoff_freq>1.0</cutoff_freq>       <!-- Cutoff frequency 1.0 Hz (if enabled) -->
    </iir_cfg>
    <max_nv_samples>10</max_nv_samples>      <!-- Max 10 non-valid samples -->
    <max_delta>200.0</max_delta>             <!-- Max delta between consecutive readings -->
</data>
```

## 6. Linear Parameter Scaling (LPS) Configurations

### 6.1 Gyroscope Linear Parameter Scaling

File: `ver_spdif_gyrlps.xml` (ID: 275)

```xml
<data>
    <sensor0>
        <a00>1.0</a00><a10>0.0</a10><a20>0.0</a20>
        <a01>0.0</a01><a11>1.0</a11><a21>0.0</a21>
        <a02>0.0</a02><a12>0.0</a12><a22>1.0</a22>
    </sensor0>
    <!-- Identical matrices for sensor1, sensor2, and sensor3 -->
</data>
```

Key characteristics:
- Identity matrices for all four gyroscopes
- These matrices would be applied to sensor readings before calibration
- Currently configured to have no effect (identity transformation)

### 6.2 Accelerometer Linear Parameter Scaling

File: `ver_spdif_acclps.xml` (ID: 274)

```xml
<data>
    <sensor0>
        <a00>1.0</a00><a10>0.0</a10><a20>0.0</a20>
        <a01>0.0</a01><a11>1.0</a11><a21>0.0</a21>
        <a02>0.0</a02><a12>0.0</a12><a22>1.0</a22>
    </sensor0>
    <!-- Identical matrices for sensor1, sensor2, and sensor3 -->
</data>
```

### 6.3 Magnetometer Linear Parameter Scaling

File: `ver_spdif_maglps.xml` (ID: 276)

```xml
<data>
    <sensor0>
        <a00>1.0</a00><a10>0.0</a10><a20>0.0</a20>
        <a01>0.0</a01><a11>1.0</a11><a21>0.0</a21>
        <a02>0.0</a02><a12>0.0</a12><a22>1.0</a22>
    </sensor0>
    <!-- Identical matrices for sensor1 through sensor8 -->
</data>
```

Key characteristics:
- Identity matrices for all nine magnetometers
- Supports up to 9 magnetometer sensors (compared to 4 for gyros/accelerometers)

## 7. External Sensor Configurations

### 7.1 External Gyroscope Configurations

Files:
- `ver_spdif_extgyr0.xml` (ID: 158)
- `ver_spdif_extgyr1.xml` (ID: 159)

```xml
<data>
    <desired_freq>0.0</desired_freq>         <!-- Desired frequency 0.0 Hz (disabled) -->
    <flt_cfg>
        <enable>0</enable>                   <!-- Filter disabled -->
        <cutoff_freq>1.0</cutoff_freq>       <!-- Cutoff frequency 1.0 Hz (if enabled) -->
    </flt_cfg>
    <min_value>-3.4028235E38</min_value>     <!-- Minimum allowed value (effectively no limit) -->
    <max_value>3.4028235E38</max_value>      <!-- Maximum allowed value (effectively no limit) -->
    <max_delta>3.4028235E38</max_delta>      <!-- Maximum allowed delta (effectively no limit) -->
    <max_count_nv>10</max_count_nv>          <!-- Max 10 non-valid samples -->
</data>
```

### 7.2 External Magnetometer Configurations

Files:
- `ver_spdif_extmag0.xml` (ID: 160)
- `ver_spdif_extmag1.xml` (ID: 161)

Identical structure to external gyroscope configurations.

### 7.3 External Accelerometer Configurations

Files:
- `ver_spdif_extacc0.xml` (ID: 156)
- `ver_spdif_extacc1.xml` (ID: 157)

Identical structure to external gyroscope configurations.

### 7.4 External Navigation Sensor Configuration

File: `ver_spdif_extnavsen.xml` (ID: 168)

```xml
<data>
    <desired_freq>100.0</desired_freq>       <!-- Desired frequency 100.0 Hz -->
    <req_status0_present>0</req_status0_present> <!-- Status0 not required -->
    <req_status0_value>0</req_status0_value>     <!-- Status0 value 0 -->
</data>
```

Key characteristics:
- Higher desired frequency (100 Hz) compared to other external sensors (0 Hz)
- Status checking parameters defined but not required

### 7.5 External Obstacles Configuration

File: `ver_spdif_extobs.xml` (ID: 152)

```xml
<data>
    <map>
        <enable>0</enable>                   <!-- External obstacles map disabled -->
        <time>1.0</time>                     <!-- Time parameter 1.0 -->
    </map>
</data>
```

## 8. Variable Sensor Configurations

### 8.1 Variable Gyroscope Configuration

File: `ver_spdif_vargyr.xml` (ID: 122)

```xml
<data>
    <rvar0>
        <enable>0</enable>                   <!-- Variable gyroscope 0 disabled -->
        <rvar_id0>4100</rvar_id0>            <!-- Variable ID 4100 -->
        <rvar_id1>4100</rvar_id1>            <!-- Variable ID 4100 -->
        <rvar_id2>4100</rvar_id2>            <!-- Variable ID 4100 -->
        <min_value>-3.4028235E38</min_value> <!-- Minimum allowed value (effectively no limit) -->
        <max_value>3.4028235E38</max_value>  <!-- Maximum allowed value (effectively no limit) -->
        <max_delta>3.4028235E38</max_delta>  <!-- Maximum allowed delta (effectively no limit) -->
        <max_count_nv>0</max_count_nv>       <!-- No tolerance for non-valid samples -->
    </rvar0>
    <!-- Identical configuration for rvar1 -->
</data>
```

Key characteristics:
- Two variable gyroscope configurations (rvar0, rvar1)
- Both disabled (enable = 0)
- Variable IDs all set to 4100
- No limits on values or deltas
- No tolerance for non-valid samples

### 8.2 Variable Accelerometer Configuration

File: `ver_spdif_varacc.xml` (ID: 121)

Identical structure to variable gyroscope configuration.

### 8.3 Variable Magnetometer Configuration

File: `ver_spdif_varmag.xml` (ID: 123)

Identical structure to variable gyroscope configuration.

### 8.4 Variable Step Sensor Configuration

File: `ver_spdif_varstp.xml` (ID: 65)

```xml
<data>
    <rvar0>
        <enable>0</enable>                   <!-- Variable step sensor 0 disabled -->
        <rvar_id>4100</rvar_id>              <!-- Variable ID 4100 -->
        <min_value>-3.4028235E38</min_value> <!-- Minimum allowed value (effectively no limit) -->
        <max_value>3.4028235E38</max_value>  <!-- Maximum allowed value (effectively no limit) -->
        <max_delta>3.4028235E38</max_delta>  <!-- Maximum allowed delta (effectively no limit) -->
        <max_count_nv>0</max_count_nv>       <!-- No tolerance for non-valid samples -->
    </rvar0>
    <!-- Identical configuration for rvar1 -->
</data>
```

Key characteristics:
- Simpler structure with single rvar_id (compared to three for gyro/accel/mag)
- Otherwise identical parameters to other variable sensor configurations

### 8.5 Variable Q-Inference Configuration

File: `ver_spdif_varqinf.xml` (ID: 66)

Identical structure to variable step sensor configuration.

## 9. Sensor Data Processing Pipeline

Based on the configuration files, the sensor data processing pipeline can be reconstructed as follows:

1. **Raw Data Acquisition**:
   - IMUs collect raw gyroscope and accelerometer data at configured sample rates
   - IMU0/IMU1: Accelerometer at 160Hz, Gyroscope at 128Hz
   - IMU2/IMU3: At their respective configured rates

2. **Initial Data Validation**:
   - Check for non-valid samples (up to configured max_nv_samples)
   - Verify delta between consecutive readings is within max_delta threshold
   - IMU0/IMU1: Max 10 non-valid samples, acc_max_delta=313.8128, gyr_max_delta=69.81317
   - IMU2: Max 30 non-valid samples, acc_max_delta=235.3596, gyr_max_delta=69.81317
   - IMU3: No tolerance for non-valid samples, acc_max_delta=156.8, gyr_max_delta=69.81317

3. **Linear Parameter Scaling**:
   - Apply LPS matrices to sensor readings
   - Currently all set to identity matrices (no transformation)

4. **Filtering**:
   - Apply configured filters to sensor data
   - All filters currently disabled but defined:
     - Gyro/Accel: Notch filter (center=100Hz, bandwidth=20Hz) and Butterworth (cutoff=1Hz)
     - Mag/Step/QInf: IIR filter (cutoff=1Hz)

5. **Sensor Suite Processing**:
   - Combine data from multiple sensors of the same type
   - Use variance estimation (tau_v=2.0, tau_s2=20.0)
   - Default to sensor 0 for both gyro and accel suites

6. **Calibration Application**:
   - Apply calibration parameters from the previously analyzed calibration system
   - Temperature-dependent calibration matrices and bias vectors

7. **External and Variable Sensor Integration**:
   - Incorporate data from external sensors (currently disabled)
   - Process variable sensor inputs (currently disabled)

8. **Navigation System Input**:
   - Provide processed sensor data to the navigation system
   - External navigation sensor configured for 100Hz operation

## 10. Key Insights and Relationships

### 10.1 Redundancy and Fault Tolerance

The sensor configuration demonstrates multiple redundancy mechanisms:

1. **Dual Primary IMUs**: IMU0 and IMU1 have identical configurations, suggesting they serve as redundant primary sensors.

2. **Multiple Backup IMUs**: IMU2 and IMU3 have different configurations, suggesting they serve as backup sensors with different characteristics.

3. **Sensor Suites**: Both gyroscope and accelerometer suites are configured to combine data from multiple sensors, enhancing reliability.

4. **Non-Valid Sample Handling**: Each sensor has a configured tolerance for non-valid samples, allowing the system to continue operation despite occasional bad readings.

5. **External Sensor Support**: Configuration for external sensors provides additional redundancy options.

### 10.2 Data Validation Mechanisms

The system employs several data validation approaches:

1. **Maximum Delta Thresholds**: Each sensor type has a configured maximum allowed change between consecutive readings:
   - Gyroscopes: 69.81317 (consistent across all IMUs)
   - Accelerometers: Varies by IMU (313.8128, 235.3596, 156.8)
   - Step sensors: Varies by sensor (450.0, 113.4, 177.1875)
   - Q-Inference: 200.0

2. **Non-Valid Sample Limits**: Different tolerance for non-valid samples:
   - IMU0/IMU1: 10 samples
   - IMU2: 30 samples
   - IMU3: 0 samples (no tolerance)

3. **Min/Max Value Bounds**: External and variable sensors have configurable minimum and maximum allowed values (currently set to effectively unlimited).

### 10.3 Filtering Strategy

The configuration defines a comprehensive filtering strategy that is currently disabled but ready to be enabled:

1. **Gyroscope and Accelerometer Filtering**:
   - Notch filters to remove specific frequency noise (e.g., vibration at 100Hz)
   - Butterworth low-pass filters to remove high-frequency noise

2. **Magnetometer, Step, and Q-Inference Filtering**:
   - Simple IIR low-pass filters with 1Hz cutoff frequency

3. **Filter Enablement**: All filters are defined but disabled (enable=0), suggesting they can be activated when needed without reconfiguration.

### 10.4 Relationship to Calibration System

The sensor configuration system works in conjunction with the previously analyzed calibration system:

1. **Pre-Calibration Processing**: The configuration system defines how raw sensor data is processed before calibration is applied.

2. **Temperature Compensation**: IMU0/IMU1 have temperature sensing enabled (temp_enabled=1), which would feed into the temperature-dependent calibration system.

3. **Coordinate System Alignment**: The IMU geometry (Lbp matrix) defines the coordinate system transformation that complements the calibration matrices.

4. **Sensor Identification**: The sensor IDs in the configuration files correspond to the sensor IDs in the calibration files, ensuring proper matching.

## 11. Conclusion

The IMU and sensor configuration system for the recovery system provides a comprehensive framework for sensor data acquisition, validation, filtering, and fusion. Key features include:

1. **Multi-IMU Architecture**: Four IMUs with different configurations provide redundancy and diverse sensing capabilities.

2. **Extensive Filtering Options**: Various filter types (notch, Butterworth, IIR) are defined but currently disabled, allowing for flexible noise reduction when needed.

3. **Robust Data Validation**: Maximum delta thresholds and non-valid sample handling ensure data integrity.

4. **Sensor Fusion Support**: Sensor suite configurations enable combining data from multiple sensors of the same type.

5. **Geometric Configuration**: IMU position and orientation matrices define the spatial relationship between sensors and the platform.

6. **External Sensor Integration**: Support for external sensors provides additional data sources and redundancy.

7. **Variable Sensor Support**: Configuration for variable sensors allows for dynamic sensor inputs.

The configuration system is designed to work seamlessly with the calibration system, providing a complete sensor data processing pipeline from raw acquisition to calibrated output for the navigation system.

## Referenced Context Files

- `Amazon-PrimeAir/items/ASTRO/items/EV2/Recovery 0/04_Sensor_Calibration_System.md` - Provided essential information about the calibration system that complements the sensor configuration files, including temperature-dependent calibration matrices, bias vectors, and the overall calibration application process.