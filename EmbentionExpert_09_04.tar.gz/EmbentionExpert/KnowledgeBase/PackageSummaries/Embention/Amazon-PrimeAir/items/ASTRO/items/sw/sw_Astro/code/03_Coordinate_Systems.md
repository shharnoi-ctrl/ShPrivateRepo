# Generated from:

- pa_blocks/code/include/WGS84_point_3d.h (258 tokens)
- pa_blocks/code/include/Tllh_cs_64.h (1390 tokens)
- pa_blocks/code/include/Geographic_coordinate_system.h (137 tokens)
- pa_blocks/code/include/Geospatial_cuboid.h (206 tokens)
- pa_blocks/code/include/Coordinate_reference_system.h (89 tokens)
- pa_blocks/code/include/Gnc_body_transformations.h (332 tokens)
- pa_blocks/code/include/Gnc_transformation.h (775 tokens)
- pa_blocks/code/include/Gnc_rotation.h (253 tokens)
- pa_blocks/code/include/Equirectangular_projection.h (149 tokens)
- pa_blocks/code/include/Rotation.h (177 tokens)
- pa_blocks/code/include/Rpy.h (60 tokens)
- pa_blocks/code/include/Rph_from_q.h (587 tokens)
- pa_blocks/code/include/Spheroid.h (69 tokens)
- pa_blocks/code/include/Datum.h (87 tokens)
- pa_blocks/code/include/Check_bounding_box.h (635 tokens)
- pa_blocks/code/include/Backyard_abort_threshold_monitor.h (562 tokens)
- pa_blocks/code/source/WGS84_point_3d.cpp (387 tokens)
- pa_blocks/code/source/Tllh_cs_64.cpp (3127 tokens)
- pa_blocks/code/source/Geographic_coordinate_system.cpp (502 tokens)
- pa_blocks/code/source/Geospatial_cuboid.cpp (488 tokens)
- pa_blocks/code/source/Coordinate_reference_system.cpp (351 tokens)
- pa_blocks/code/source/Gnc_body_transformations.cpp (318 tokens)
- pa_blocks/code/source/Gnc_transformation.cpp (1963 tokens)
- pa_blocks/code/source/Gnc_rotation.cpp (157 tokens)
- pa_blocks/code/source/Equirectangular_projection.cpp (637 tokens)
- pa_blocks/code/source/Rotation.cpp (1301 tokens)
- pa_blocks/code/source/Rph_from_q.cpp (450 tokens)
- pa_blocks/code/source/Spheroid.cpp (352 tokens)
- pa_blocks/code/source/Datum.cpp (347 tokens)
- pa_blocks/code/source/Check_bounding_box.cpp (751 tokens)
- pa_blocks/code/source/Backyard_abort_threshold_monitor.cpp (1144 tokens)

## With context from:

- PackageSummaries/Embention/Amazon-PrimeAir/items/ASTRO/items/sw/sw_Astro/code/04_Mathematical_Utilities.md (9780 tokens)

---

# Comprehensive Summary of Drone Coordinate Systems and Transformations

This document provides a detailed analysis of the coordinate systems and transformations used in the drone system, focusing on how different reference frames are defined, related, and transformed between each other.

## 1. Core Coordinate Systems

The drone system uses several key coordinate systems that serve different purposes in navigation, control, and mission planning.

### 1.1 Global Reference Frames

#### 1.1.1 WGS84 (World Geodetic System 1984)

```cpp
struct Geographic_coordinate_system {
    enum Geographic_coordinate_system_name {
        unknown = 0,
        wgs84 = 1,
    };
    
    Geographic_coordinate_system_name name;
    Datum datum;
    Base::Optional<Real> prime_meridian_rad;
};
```

WGS84 is the primary global reference frame used by the system, defined by:
- An ellipsoidal model of the Earth (specified in the `Datum` and `Spheroid` classes)
- Latitude, longitude, and height above ellipsoid (HAE) coordinates
- The `WGS84_point_3d` class extends `Base::Tllh` to represent positions in this system

```cpp
struct WGS84_point_3d : public Base::Tllh {
    inline const Real64& latitude_rad() const { return ll.lat; }
    inline const Real64& longitude_rad() const { return ll.lon; }
    inline const Real64& altitude_hae_m() const { return h; }
    
    // Setters and other methods...
};
```

#### 1.1.2 ECEF (Earth-Centered, Earth-Fixed)

The ECEF coordinate system is a Cartesian system with:
- Origin at the Earth's center of mass
- X-axis passing through the intersection of the equator and prime meridian
- Z-axis aligned with the Earth's rotational axis
- Y-axis completing the right-handed system

The `Tllh_cs_64` class provides transformations between WGS84 and ECEF:

```cpp
void Tllh_cs_64::compute_ecef_from_lla() {
    const Real64 n = Environ_params::Earth::R0_m / sqrtr(Kr64::ONE - (e0_2*(slat*slat)));
    const Real64 n_plus_h = n + llh.h;

    ecef[u0] = n_plus_h*clat*clon;  // X
    ecef[u1] = n_plus_h*clat*slon;  // Y
    ecef[u2] = ((n*(Kr64::ONE - e0_2)) + llh.h)*slat;  // Z
}
```

### 1.2 Local Navigation Frames

#### 1.2.1 NED (North-East-Down)

The NED frame is a local tangent plane coordinate system:
- Origin at a reference point on the Earth's surface
- X-axis pointing North
- Y-axis pointing East
- Z-axis pointing Down (toward Earth's center)

The `Tllh_cs_64` class provides transformations between ECEF and NED:

```cpp
void Tllh_cs_64::delta_ecef_to_ned(const Maverick::Irvector3& delta_ecef, Maverick::Irvector3& ned) const {
    ned[u0] = -slat_lr*clon_lr*delta_ecef[u0] - slat_lr*slon_lr*delta_ecef[u1] + clat_lr*delta_ecef[u2];  // North
    ned[u1] = -slon_lr*delta_ecef[u0] + clon_lr*delta_ecef[u1];  // East
    ned[u2] = -clat_lr*clon_lr*delta_ecef[u0] - clat_lr*slon_lr*delta_ecef[u1] - slat_lr*delta_ecef[u2];  // Down
}
```

The rotation matrix from ECEF to NED is constructed as:

```cpp
void Tllh_cs_64::ecef_to_ned_rot_mat(Maverick::Irmatrix3& rne) const {
    rne.set(u0, u0, -slat_lr*clon_lr);
    rne.set(u0, u1, -slat_lr*slon_lr);
    rne.set(u0, u2,  clat_lr);

    rne.set(u1, u0, -slon_lr);
    rne.set(u1, u1,  clon_lr);
    rne.set(u1, u2,  0);

    rne.set(u2, u0, -clat_lr*clon_lr);
    rne.set(u2, u1, -clat_lr*slon_lr);
    rne.set(u2, u2, -slat_lr);
}
```

### 1.3 Vehicle Body Frames

The drone system uses multiple body-fixed coordinate systems:

#### 1.3.1 BUL (Base Unit Link) Frame

The BUL frame is a reference frame fixed to the drone's base unit.

#### 1.3.2 VTOL (Vertical Take-Off and Landing) Frame

The VTOL frame is used for vertical flight control.

#### 1.3.3 VF (Vehicle Frame)

The VF frame is the primary vehicle-fixed reference frame.

These frames are related through the `Gnc_body_transformations` class:

```cpp
class Gnc_body_transformations {
public:
    Gnc_body_transformations(const Gnc_transformation::Build_params& vtol_from_bul,
                             const Gnc_transformation::Build_params& vf_from_bul,
                             const Base::Rv3& t_bul_bul2vf_m);

    Gnc_transformation::Build_params vtol_cg_from_vf(const Maverick::Irvector3& p_bul_bul2cg_m) const;

private:
    Gnc_transformation vtol_from_bul_;
    Gnc_transformation vf_from_bul_;
    Gnc_transformation bul_from_vtol_;
    Gnc_transformation vf_from_vtol_;
    Gnc_transformation bul_from_vf_;
    Gnc_transformation vtol_from_vf_;
    const Base::Rv3& t_bul_bul2vf_m_;
};
```

## 2. Transformation Mechanisms

### 2.1 Quaternion-Based Rotations

The system uses quaternions extensively for representing rotations between coordinate frames:

```cpp
class Gnc_rotation {
public:
    explicit Gnc_rotation(const Base::Rv9& matrix_data);

    inline const Maverick::Irmatrix3& get_dcm() const { return matrix; }
    inline const Maverick::Irquat& get_quaternion() const { return quaternion; }
    
    inline void transform_vector(const Maverick::Irvector3& vector_in,
                                Maverick::Irvector3& vector_out) const {
        vector_out.matvec(matrix, vector_in);
    }

    bool is_valid() const;

private:
    Maverick::Rmatrix3 matrix;
    Maverick::Rquat quaternion;
};
```

The `Pa_irquat` namespace provides utilities for quaternion operations:

```cpp
namespace Pa_irquat {
    void rpy2quat(Real r, Real p, Real y, Maverick::Irquat& quat);
    void quat2rpy(const Maverick::Irquat& quat, Real& r, Real& p, Real& y);
    Real quat2pitch(const Maverick::Irquat& quat);
    Real quat2roll(const Maverick::Irquat& quat);
    Real quat2yaw(const Maverick::Irquat& quat);
    
    void quat_conj_rotate_vector(const Maverick::Irquat& quat,
                                const Maverick::Irvector3& in,
                                Maverick::Irvector3& out);
    
    // Additional quaternion operations...
}
```

### 2.2 Rigid Body Transformations

The `Gnc_transformation` class encapsulates both rotation and translation:

```cpp
class Gnc_transformation {
public:
    struct Build_params {
        static Build_params build(const Base::Rv9& rotation0,
                                  const Base::Rv3& translation0) {
            Build_params ret = {rotation0, translation0};
            return ret;
        }
        Base::Rv9 rotation;
        Base::Rv3 translation;
    };

    explicit Gnc_transformation(const Build_params& bp);

    // Transform velocities between frames
    void transform_velocities(const Maverick::Irvector3& v_a_c2a_m_per_s,
                             const Maverick::Irvector3& w_a_c2a_rad_per_s,
                             Maverick::Irvector3& v_b_c2b_m_per_s,
                             Maverick::Irvector3& w_b_c2b_rad_per_s) const;

    // Transform accelerations between frames
    void transform_accelerations(const Maverick::Irvector3& a_a_c2a_m_per_s2,
                                const Maverick::Irvector3& w_dot_a_c2a_rad_per_s2,
                                const Maverick::Irvector3& w_a_c2a_rad_per_s,
                                Maverick::Irvector3& a_b_c2b_m_per_s2,
                                Maverick::Irvector3& w_dot_b_c2b_rad_per_s2) const;

    // Compute inverse transformation
    Build_params inverse() const;

    // Combine transformations
    static Build_params combine(const Build_params& p_transformation_C_from_B,
                               const Build_params& p_transformation_B_from_A);

    // Transform forces and moments
    void transform_wrench(const Maverick::Irvector3& f_in_N,
                         const Maverick::Irvector3& m_in_N_m,
                         Maverick::Irvector3& f_out_N,
                         Maverick::Irvector3& m_out_N_m) const;

    // Transform inertia tensor
    void transform_inertia(const Maverick::Irmatrix3& J_A_kg_m2,
                          const Real mass_kg,
                          const Maverick::Irvector3& p_B_B2cg_m,
                          Maverick::Irmatrix3& J_B_kg_m2) const;

private:
    Gnc_rotation rotation_;
    Maverick::Rvector3 translation_m_;
    
    // Transform twist (linear and angular velocity)
    void transform_twist(const Maverick::Irvector3& v_in_m_per_s,
                        const Maverick::Irvector3& w_in_rad_per_s,
                        Maverick::Irvector3& v_out_m_per_s,
                        Maverick::Irvector3& w_out_rad_per_s) const;
};
```

This class implements the mathematics for rigid body transformations, including:

1. **Twist Transformation**: Transforms linear and angular velocities between frames
   ```cpp
   void Gnc_transformation::transform_twist(const Maverick::Irvector3& v_in_m_per_s,
                                           const Maverick::Irvector3& w_in_rad_per_s,
                                           Maverick::Irvector3& v_out_m_per_s,
                                           Maverick::Irvector3& w_out_rad_per_s) const {
       rotation_.transform_vector(v_in_m_per_s, v_out_m_per_s);
       Rmatrix3 skew;
       skew.skewp(translation_m_);
       skew.matthis(rotation_.get_dcm());
       v_out_m_per_s.matvec_sub(skew, w_in_rad_per_s);

       rotation_.transform_vector(w_in_rad_per_s, w_out_rad_per_s);
   }
   ```

2. **Acceleration Transformation**: Transforms linear and angular accelerations between frames, accounting for centripetal and tangential effects
   ```cpp
   void Gnc_transformation::transform_accelerations(const Maverick::Irvector3& a_a_c2a_m_per_s2,
                                                  const Maverick::Irvector3& w_dot_a_c2a_rad_per_s2,
                                                  const Maverick::Irvector3& w_a_c2a_rad_per_s,
                                                  Maverick::Irvector3& a_b_c2b_m_per_s2,
                                                  Maverick::Irvector3& w_dot_b_c2b_rad_per_s2) const {
       Rmatrix3 w_A_C2A_skew;
       w_A_C2A_skew.skewp(w_a_c2a_rad_per_s);
       Rmatrix3 w_dot_A_C2A_skew;
       w_dot_A_C2A_skew.skewp(w_dot_a_c2a_rad_per_s2);

       // Compute acceleration of origin of B in A-frame coordinates
       Rvector3 a_A_C2B_m_per_s2;
       a_A_C2B_m_per_s2.copy(a_a_c2a_m_per_s2);
       
       // Add centripetal acceleration
       Rvector3 centripetal_acceleration;
       centripetal_acceleration.matvec(w_A_C2A_skew, translation_m_);
       centripetal_acceleration.matthis(w_A_C2A_skew);
       
       // Add tangential acceleration
       Rvector3 tangential_acceleration;
       tangential_acceleration.matvec(w_dot_A_C2A_skew, translation_m_);
       
       a_A_C2B_m_per_s2.vecadd(centripetal_acceleration);
       a_A_C2B_m_per_s2.vecadd(tangential_acceleration);

       // Transform to output frame
       a_b_c2b_m_per_s2.matvec(rotation_.get_dcm(), a_A_C2B_m_per_s2);
       w_dot_b_c2b_rad_per_s2.matvec(rotation_.get_dcm(), w_dot_a_c2a_rad_per_s2);
   }
   ```

3. **Wrench Transformation**: Transforms forces and moments between frames
   ```cpp
   void Gnc_transformation::transform_wrench(const Maverick::Irvector3& f_in_N,
                                           const Maverick::Irvector3& m_in_N_m,
                                           Maverick::Irvector3& f_out_N,
                                           Maverick::Irvector3& m_out_N_m) const {
       f_out_N.matvec(rotation_.get_dcm(), f_in_N);
       Rmatrix3 trans_skew;
       trans_skew.skewp(translation_m_);
       trans_skew.scale(-1.0F);
       trans_skew.matthis(rotation_.get_dcm());
       m_out_N_m.matvec(trans_skew, f_in_N);
       m_out_N_m.matvec_add(rotation_.get_dcm(), m_in_N_m);
   }
   ```

4. **Inertia Transformation**: Transforms inertia tensors between frames using the parallel axis theorem
   ```cpp
   void Gnc_transformation::transform_inertia(const Maverick::Irmatrix3& J_A_kg_m2,
                                            const Real mass_kg,
                                            const Maverick::Irvector3& p_B_B2cg_m,
                                            Maverick::Irmatrix3& J_B_kg_m2) const {
       // Implementation uses parallel axis theorem to transform inertia tensor
       // between different reference points
   }
   ```

### 2.3 Equirectangular Projection

For local navigation, the system uses an equirectangular projection to convert between WGS84 coordinates and a local Cartesian system:

```cpp
struct Equirectangular_projection {
    Geographic_coordinate_system geographic_coordinate_system;
    Base::Optional<Real> projection_latitude_rad;
    Base::Optional<Real> projection_longitude_rad;
    Base::Optional<Real> false_easting_m;
    Base::Optional<Real> false_northing_m;
};
```

The `Tllh_cs_64` class implements the equirectangular projection:

```cpp
void Tllh_cs_64::ned_from_lla_equirectangular(const Tllh_cs_64& llh, Maverick::Irvector3& inc_ned) const {
    Base::Tnarray<Real64, u3> k_ned_per_lla;
    k_ned_per_lla[u0] = Environ_params::Earth::R0_m;
    k_ned_per_lla[u1] = Environ_params::Earth::R0_m * clat;
    k_ned_per_lla[u2] = -Kr64::ONE;

    Base::Tnarray<Real64, u3> delta_lla;
    delta_lla[u0] = llh.get_llh().ll.lat - this->llh.ll.lat;
    delta_lla[u1] = llh.get_llh().ll.lon - this->llh.ll.lon;
    delta_lla[u2] = llh.get_llh().h - this->llh.h;

    inc_ned[u0] = k_ned_per_lla[u0] * delta_lla[u0];  // North
    inc_ned[u1] = k_ned_per_lla[u1] * delta_lla[u1];  // East
    inc_ned[u2] = k_ned_per_lla[u2] * delta_lla[u2];  // Down
}
```

This projection approximates the Earth as a sphere and scales longitude differences by the cosine of latitude to account for meridian convergence.

## 3. Spatial Bounding and Containment

### 3.1 Geospatial Cuboid

The system uses geospatial cuboids to define regions in 3D space:

```cpp
struct Geospatial_cuboid {
    WGS84_point_3d centroid_;
    Real half_length_m_;
    Real half_width_m_;
    Real half_height_m_;
    Real major_axis_rotation_rad_;
};
```

These cuboids are used for defining operational boundaries and safety zones.

### 3.2 Bounding Box Checking

The `Check_bounding_box` class verifies if the drone is within a defined operational area:

```cpp
class Check_bounding_box {
public:
    struct Output {
        Output();
        bool in_bounding_box;
    };

    Check_bounding_box(const State_estimate& state_estimate0,
                      const Mission_data& mission_data0);

    void step();
    inline const Output& get_out() const { return out; }

private:
    const Mission_data& mission_data;
    const State_estimate& state_estimate;
    Output out;
};
```

The implementation uses the equirectangular projection to efficiently check if the drone is within the bounding box:

```cpp
void Check_bounding_box::step() {
    Maverick::Rvector3 t_ned_se_m(0.0F, 0.0F, 0.0F);
    Maverick::Rvector3 t_ned_centroid_m(0.0F, 0.0F, 0.0F);
    Maverick::Rvector3 t_ned_centroid2se_m(0.0F, 0.0F, 0.0F);
    
    // Convert current position and centroid to NED coordinates
    mission_data.data->projection_point_rad_and_m.ned_from_lla_equirectangular(
        state_estimate.lla_rrm, t_ned_se_m);
    mission_data.data->projection_point_rad_and_m.ned_from_lla_equirectangular(
        mission_data.data->centroid_lla_rad_and_m, t_ned_centroid_m);
    
    // Compute vector from centroid to current position
    t_ned_centroid2se_m.vecres(t_ned_se_m, t_ned_centroid_m);

    // Check if position is within bounding box
    out.in_bounding_box = Knobs::get_instance().nav_params_shutoff_bounding_box_protection ||
        (Rfun::in_range<Real>(t_ned_centroid2se_m[north],
                             -mission_data.data->half_length_m,
                             mission_data.data->half_length_m) &&
         Rfun::in_range<Real>(t_ned_centroid2se_m[east],
                             -mission_data.data->half_width_m,
                             mission_data.data->half_width_m) &&
         Rfun::in_range<Real>(t_ned_centroid2se_m[down],
                             -mission_data.data->half_height_m,
                             mission_data.data->half_height_m));
}
```

## 4. Attitude Representation and Conversion

### 4.1 Roll-Pitch-Heading (RPH) from Quaternion

The `Rph_from_q` class extracts roll, pitch, and heading angles from a quaternion:

```cpp
class Rph_from_q {
public:
    struct Output {
        Output();
        Base::Tnarray<Real, Ku16::u3> RPH_rad;
    };

    explicit Rph_from_q(const Base::Rv4& q_ned_from_frame0);
    void step();
    inline const Output& get_out() const { return out; }

private:
    static const Maverick::Rvector3 t_vf_vf2x;  // Vector pointing to the x direction (1,0,0)
    const Maverick::Irquat::K q_ned_from_frame;
    Output out;
};
```

The implementation:

```cpp
void Rph_from_q::step() {
    // Compute the inverse quaternion (frame from NED)
    Maverick::Rquat q_frame_from_ned;
    q_frame_from_ned.copy(q_ned_from_frame.kquat);
    q_frame_from_ned.invert();

    // Rotate the x-axis unit vector to NED frame
    Maverick::Rvector3 t_ned_vf2x;
    q_ned_from_frame.kquat.b2n(t_vf_vf2x, t_ned_vf2x);

    // Extract roll, pitch, and heading
    out.RPH_rad[Ku16::u0] = Pa_irquat::quat2roll(q_frame_from_ned);
    out.RPH_rad[Ku16::u1] = Pa_irquat::quat2pitch(q_frame_from_ned);
    out.RPH_rad[Ku16::u2] = Rmath::atan2r(t_ned_vf2x[Ku16::u1], t_ned_vf2x[Ku16::u0]);
}
```

This method:
1. Computes the quaternion representing rotation from NED to the frame
2. Rotates the x-axis unit vector from the vehicle frame to NED
3. Extracts roll and pitch directly from the quaternion
4. Computes heading as the arctangent of the y and x components of the rotated x-axis

### 4.2 Rotation Validation

The `Rotation` class provides utilities for working with rotations:

```cpp
struct Rotation {
    static bool compute_shortest_rotation_between_two_vectors(
        const Maverick::Irvector3& v_A_A,
        const Maverick::Irvector3& v_B_A,
        Maverick::Irquat& q_A_from_B);

    static bool is_valid_dcm(const Maverick::Irmatrix3& dcm);
};
```

The `is_valid_dcm` method checks if a matrix is a valid rotation matrix (orthogonal with determinant +1):

```cpp
bool Rotation::is_valid_dcm(const Maverick::Irmatrix3& dcm) {
    // Check orthogonality: DCM * DCM^T = I
    Maverick::Rmatrix3 dcm_times_dcmT_minus_eye3;
    dcm_times_dcmT_minus_eye3.eye(-1.0F);
    dcm_times_dcmT_minus_eye3.matmatT_add(dcm, dcm);
    bool is_good = dcm_times_dcmT_minus_eye3.trace() < Comparison_constants::k_matrix_norm_tol;

    // Check determinant = +1
    is_good &= Rmath::fabsr(dcm.det() - 1.0F) < Comparison_constants::k_matrix_norm_tol;

    return is_good;
}
```

## 5. Coordinate System Applications

### 5.1 Backyard Abort Threshold Monitoring

The `Backyard_abort_threshold_monitor` class uses coordinate systems to monitor vehicle dynamics during critical operations:

```cpp
class Backyard_abort_threshold_monitor {
public:
    struct Param {
        Param();
        Real vtol_roll_rate_max_rad_per_s;
        Real vtol_pitch_rate_max_rad_per_s;
        Real vtol_roll_accel_cmd_max_rad_per_s2;
        Real vtol_pitch_accel_cmd_max_rad_per_s2;
        Real height_above_marker_below_which_to_activate_logic_m;
    };
    
    enum Update_backyard_abort_threshold_status {
        NOMINAL,
        ANGULAR_RATES_OR_ACCELERATIONS_EXCEEDED
    };
    
    Backyard_abort_threshold_monitor(const Param& threshold_monitor_params);
    
    Update_backyard_abort_threshold_status update_backyard_abort_threshold_status(
        const State_estimate& state_estimate,
        const State_machines_state::Mode::Controllers_mode& controllers_mode,
        const Command_trajectory& commanded_trajectory,
        const Control_system_phase_off_flight_notification& control_system_phase_of_flight) const;
};
```

This monitor checks if angular rates and accelerations exceed thresholds in the vehicle's body frame, triggering an abort if necessary.

## 6. Mathematical Foundation of Coordinate Transformations

### 6.1 WGS84 to ECEF Transformation

The transformation from WGS84 (latitude φ, longitude λ, height h) to ECEF (X, Y, Z) is given by:

```
n = R0 / sqrt(1 - e0² * sin²(φ))
X = (n + h) * cos(φ) * cos(λ)
Y = (n + h) * cos(φ) * sin(λ)
Z = (n * (1 - e0²) + h) * sin(φ)
```

Where:
- R0 is the Earth's equatorial radius
- e0 is the first eccentricity of the Earth ellipsoid

### 6.2 ECEF to WGS84 Transformation

The inverse transformation from ECEF to WGS84 is more complex:

```
p = sqrt(X² + Y²)
λ = atan2(Y, X)
θ = atan2(R0 * Z, Rp * p)
φ = atan2(Z + Rp * ep² * sin³(θ), p - R0 * e0² * cos³(θ))
n = R0 / sqrt(1 - e0² * sin²(φ))
h = p / cos(φ) - n
```

Where:
- Rp is the Earth's polar radius
- ep is the second eccentricity of the Earth ellipsoid

### 6.3 ECEF to NED Transformation

The rotation matrix from ECEF to NED at a point with latitude φ and longitude λ is:

```
R_NED_from_ECEF = [
    -sin(φ)*cos(λ)  -sin(φ)*sin(λ)   cos(φ)
    -sin(λ)          cos(λ)           0
    -cos(φ)*cos(λ)  -cos(φ)*sin(λ)  -sin(φ)
]
```

### 6.4 Quaternion-Based Rotations

For a quaternion q = [qs, qx, qy, qz], the rotation of a vector v is:

```
v' = q * v * q⁻¹
```

Where * represents quaternion multiplication and q⁻¹ is the quaternion conjugate.

In the implementation, this is often computed using the equivalent rotation matrix (DCM) derived from the quaternion.

## 7. Coordinate System Hierarchy and Relationships

The coordinate systems in the drone form a hierarchical structure:

1. **Global Reference Frames**
   - WGS84 (latitude, longitude, height)
   - ECEF (Earth-centered Cartesian)

2. **Local Navigation Frames**
   - NED (North-East-Down) - local tangent plane

3. **Vehicle Body Frames**
   - BUL (Base Unit Link)
   - VTOL (Vertical Take-Off and Landing)
   - VF (Vehicle Frame)

The transformations between these frames are:

- WGS84 ⟷ ECEF: Implemented in `Tllh_cs_64::compute_ecef_from_lla()` and `Tllh_cs_64::construct_lla_from_ecef()`
- ECEF ⟷ NED: Implemented in `Tllh_cs_64::ned2ecef_lr()` and `Tllh_cs_64::delta_ecef_to_ned()`
- NED ⟷ Body Frames: Implemented through quaternion rotations in various classes
- Between Body Frames: Implemented in `Gnc_body_transformations`

## 8. Velocity and Acceleration Transformations

When transforming velocities and accelerations between frames, additional terms arise due to the relative motion of the frames:

1. **Velocity Transformation**:
   ```
   v_B = R_B_from_A * v_A - R_B_from_A * (ω_A × r_A_to_B)
   ω_B = R_B_from_A * ω_A
   ```

2. **Acceleration Transformation**:
   ```
   a_B = R_B_from_A * (a_A - ω_A × (ω_A × r_A_to_B) - α_A × r_A_to_B)
   α_B = R_B_from_A * α_A
   ```

Where:
- v_A, v_B are linear velocities in frames A and B
- ω_A, ω_B are angular velocities
- a_A, a_B are linear accelerations
- α_A, α_B are angular accelerations
- r_A_to_B is the position vector from the origin of frame A to frame B
- R_B_from_A is the rotation matrix from frame A to frame B

These transformations are implemented in the `Gnc_transformation` class.

## Referenced Context Files

The following context files provided useful information for understanding the mathematical foundations of the coordinate systems:

- **04_Mathematical_Utilities.md**: Provided information about quaternion operations, vector operations, and mathematical utilities used in coordinate transformations.

## Summary

The drone system employs a comprehensive set of coordinate systems and transformations to enable precise navigation, control, and mission planning. Key aspects include:

1. **Global Reference Frames**: WGS84 and ECEF provide global positioning
2. **Local Navigation Frames**: NED provides a local tangent plane reference
3. **Vehicle Body Frames**: Multiple body-fixed frames for different aspects of control
4. **Transformation Mechanisms**: Quaternions and rigid body transformations enable conversion between frames
5. **Spatial Bounding**: Geospatial cuboids define operational regions
6. **Attitude Representation**: Multiple representations of orientation (quaternions, Euler angles)
7. **Mathematical Foundation**: Rigorous mathematical basis for all transformations

These coordinate systems and transformations form the spatial foundation of the drone's navigation and control systems, enabling it to accurately perceive and interact with its environment.