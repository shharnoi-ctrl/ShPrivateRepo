# Generated from:

- _sw_Veronte/code/vpgnc/code/include/Calibration.h (657 tokens)
- _sw_Veronte/code/vpgnc/code/source/Calibration.cpp (644 tokens)
- _sw_Veronte/code/vpgnc/code/include/Opmgr.h (501 tokens)
- _sw_Veronte/code/vpgnc/code/source/Opmgr.cpp (213 tokens)
- _sw_Veronte/code/vpgnc/code/include/Opmgr_fw.h (25 tokens)
- _sw_Veronte/code/vpgnc/code/include/Opranges.h (639 tokens)
- _sw_Veronte/code/vpgnc/code/source/Opranges.cpp (686 tokens)
- _sw_Veronte/code/vpgnc/code/include/Oprvar.h (932 tokens)
- _sw_Veronte/code/vpgnc/code/source/Oprvar.cpp (1129 tokens)
- _sw_Veronte/code/vpgnc/code/include/Operator_pos.h (1040 tokens)
- _sw_Veronte/code/vpgnc/code/source/Operator_pos.cpp (1167 tokens)
- _sw_Veronte/code/vpgnc/code/include/Rmark.h (698 tokens)
- _sw_Veronte/code/vpgnc/code/source/Rmark.cpp (326 tokens)
- _sw_Veronte/code/vpgnc/code/include/Rmarkmgr.h (647 tokens)
- _sw_Veronte/code/vpgnc/code/source/Rmarkmgr.cpp (838 tokens)
- _sw_Veronte/code/vpgnc/code/include/Imarks.h (220 tokens)
- _sw_Veronte/code/vpgnc/code/include/Meta.h (191 tokens)
- _sw_Veronte/code/vpgnc/code/source/Meta.cpp (719 tokens)
- _sw_Veronte/code/vpgnc/code/include/Mem_log_ctrl.h (618 tokens)
- _sw_Veronte/code/vpgnc/code/source/Mem_log_ctrl.cpp (923 tokens)

## With context from:

- PackageSummaries/Embention/Amazon-PrimeAir/items/ASTRO/items/sw/sw_Astro/items/06_VPGNC_Core.md (7671 tokens)

---

# Utility Components and Helpers in the VPGNC Framework

This document provides a detailed analysis of the utility components and helpers in the VPGNC framework, focusing on gyroscope calibration, operational variable management, operator position management, route marking, PDI management, and memory log control.

## 1. Calibration Class: Gyroscope Calibration

The `Calibration` class provides functionality to calibrate the gyroscope by taking measurements over a specified time period.

### 1.1 Class Structure and Attributes

```cpp
class Calibration : public Base::Itunable, private Base::Itask {
public:
    Calibration(Media::Cfgmgr& cfg0, Ver::Suite& sen0);
    virtual void cset(Base::Lossy_error& str);
    virtual void cget(Base::Lossy& str) const;

private:
    enum State {
        st_wait,        // Initial state, collecting measurements
        st_save_req,    // Requesting to save calibration
        st_msync_req,   // Requesting to sync calibration
        st_calibrated   // Calibration completed
    };
    
    State st;                   // Current state of calibration
    Media::Cfgmgr& cfg;         // Reference to configuration manager
    Ver::Suite& sen;            // Reference to sensor suite
    Base::Chrono chrono;        // Timer for calibration duration
    bool save_xcal;             // Flag to save calibration to PDI
    Real tmeas;                 // Time to calibrate (seconds)
    
    virtual bool step_task();   // Task execution method
};
```

### 1.2 Initialization and Configuration

The constructor initializes the calibration system with default values:

```cpp
Calibration::Calibration(Media::Cfgmgr& cfg0, Ver::Suite& sen0) :
    st(st_calibrated),
    cfg(cfg0),
    sen(sen0),
    save_xcal(false),
    tmeas(Ku16::u3)  // Default calibration time is 3 seconds
{
}
```

The class is configurable through PDI with the following parameters:

| Type   | Name       | Content                                         | Range |
|--------|------------|------------------------------------------------|-------|
| Real   | tmeas      | Time during which to take samples (seconds)     |   -   |
| Bool16 | save_xcal  | Flag to save calibration to PDI                 | [0,1] |

### 1.3 Calibration Process

The calibration process is implemented in the `step_task()` method, which is called periodically by the task manager:

```cpp
bool Calibration::step_task() {
    switch(st) {
        case st_wait:  // Collecting measurements
            sen.add_meas();  // Add current measurement to calibration
            if(chrono.toc() > tmeas) {
                sen.calibrate();  // Compute calibration from collected measurements
                st = save_xcal ? st_save_req : st_msync_req;
            }
            break;
            
        case st_msync_req:  // Sync calibration in memory
            if(cfg.msync_req(Base::Cfg::cfg_gyrocal)) {
                st = st_calibrated;
            }
            break;
            
        case st_save_req:  // Save calibration to PDI
            if(cfg.save_req(Base::Cfg::cfg_gyrocal)) {
                st = st_calibrated;
            }
            break;
            
        default:
            break;
    }
    return st == st_calibrated;  // Return true when calibration is complete
}
```

### 1.4 Calibration Workflow

1. When `cset()` is called with configuration parameters:
   - The task is canceled if already running
   - Configuration parameters are deserialized
   - The task is added to the task manager
   - The chrono timer is started
   - Measurement collection is reset
   - State is set to `st_wait`

2. During the `st_wait` state:
   - Measurements are collected via `sen.add_meas()`
   - When the specified time elapses, `sen.calibrate()` is called
   - State transitions to either `st_save_req` or `st_msync_req` based on `save_xcal`

3. During the `st_save_req` or `st_msync_req` states:
   - The calibration is either saved to PDI or synced in memory
   - When complete, state transitions to `st_calibrated`

4. The task completes when the state is `st_calibrated`

## 2. Operational Variable Management System

The operational variable management system consists of three main classes: `Opmgr`, `Opranges`, and `Oprvar`.

### 2.1 Opmgr: Operational Variables Manager

The `Opmgr` class manages operational variables and provides access to them.

#### 2.1.1 Class Structure and Attributes

```cpp
class Opmgr {
public:
    explicit Opmgr(const Base::Checklist& checklist0);
    const Base::Tuncache<Rvar_op_commit::Roptype>& get_oprvar() const;
    Base::Ideserializable& build_oprvar_tun();

private:
    Rvar_op_commit rvarcommit;                          // Helper for operation rvar commit
    Base::Tuncache<Rvar_op_commit::Roptype> oprvar;     // Manager for operation rvars
};
```

#### 2.1.2 Initialization

The constructor initializes the operational variable manager:

```cpp
Opmgr::Opmgr(const Base::Checklist& checklist0) :
    rvarcommit(oprvar),
    oprvar(checklist0, &rvarcommit)
{
    // Set pointers to operation manager
    Oprvar::set_opmgr(*this);
}
```

#### 2.1.3 Functionality

- `get_oprvar()`: Returns a constant reference to the operational variable manager
- `build_oprvar_tun()`: Builds and returns a tunable for operational variables

### 2.2 Opranges: Operational Variable Range Checker

The `Opranges` class manages ranges for operational variables and checks if variables are within their configured ranges.

#### 2.2.1 Class Structure and Attributes

```cpp
class Opranges : public Base::Icheck {
public:
    explicit Opranges(const Opmgr& opmgr0);
    Base::Ideserializable& build_tun();
    virtual void check(Base::Error& err) const;

    struct Rng {
        Oprvar min;  // Minimum range value
        Oprvar max;  // Maximum range value
        
        Rng();
        void cset(Base::Lossy_error& str);
    };

private:
    const Opmgr& opmgr;  // Reference to operation manager
    Base::Arraymsk<Rng, Rvar_op_commit::nropvars> ranges;  // Operation ranges
};
```

#### 2.2.2 Range Configuration

Each range consists of minimum and maximum values defined using `Oprvar` objects:

```cpp
void Opranges::Rng::cset(Base::Lossy_error& str) {
    min.cset(str);
    max.cset(str);
    str.assrt(min.get() <= max.get(), Base::err_oprng);
}
```

#### 2.2.3 Range Checking

The `check()` method verifies that all operational variables are within their configured ranges:

```cpp
void Opranges::check(Base::Error& err) const {
    const Base::Tnarray<Base::Realtun, Rvar_op_commit::nropvars>& r = 
        opmgr.get_oprvar().get().op_arrmsk.data;
        
    for (Uint16 i = 0; i < ranges.size(); ++i) {
        if (ranges.is_enabled(i)) {
            const Real v = r[i].value;
            err.assrt((v >= ranges.data[i].min.get()) &&
                      (v <= ranges.data[i].max.get()), Base::err_oprng_check);
        }
    }
}
```

### 2.3 Oprvar: Operational Variable Reference

The `Oprvar` class provides access to operational variables by reference.

#### 2.3.1 Class Structure and Attributes

```cpp
class Oprvar {
public:
    static void set_opmgr(const Opmgr& opmgr0);
    Oprvar();
    explicit Oprvar(const Real init);
    Real get() const;
    void cset(Base::Lossy_error& str);
    void cget(Base::Lossy& str) const;
    void check(Base::Error& err) const;

private:
    static const Uint16 no_op = 0xFFFFU;  // Operation index when no operation
    static const Base::Tuncache<Rvar_op_commit::Roptype>* oprvar;  // Reference to operation rvar manager
    Base::Vref val;  // Variable reference
    Uint16 op_idx;   // Precomputed operation index (for speed)
};
```

#### 2.3.2 Initialization

The class maintains a static pointer to the operational variable manager:

```cpp
const Base::Tuncache<Rvar_op_commit::Roptype>* Oprvar::oprvar = 0;

void Oprvar::set_opmgr(const Opmgr& opmgr0) {
    Base::Assertions::runtime(oprvar == 0);
    oprvar = &opmgr0.get_oprvar();
}
```

#### 2.3.3 Variable Access

The `get()` method retrieves the value of the operational variable:

```cpp
Real Oprvar::get() const {
    return (op_idx == no_op) ? 
        val.kget() : 
        oprvar->get().op_arrmsk.data[op_idx].value;
}
```

#### 2.3.4 Configuration

The `cset()` method configures the operational variable reference:

```cpp
void Oprvar::cset(Base::Lossy_error& str) {
    val.cset(str);
    op_idx = is_rvar_range(val, Base::v_operation_00, Base::v_operation_39) ?
            (val.entry.id - Base::v_operation_00) :
            no_op;
    val.compute();
    check(str.get_error());
}
```

## 3. Operator_pos: Operator Position Management

The `Operator_pos` class manages the operator's position and provides licensing functionality.

### 3.1 Class Structure and Attributes

```cpp
class Operator_pos {
public:
    Operator_pos();
    Base::Ideserializable& build_cfgtun();
    Base::Itunable& build_cmdtun();

    class License {
    public:
        explicit License(const volatile Base::Permission& p0);
        bool authorized(const Geo::Apos& pos);
    private:
        static Geo::Fidposcache fidpos;  // Cache position for reads
        const volatile Base::Permission& p;  // Permission
        Base::Chrono ch;  // Timeout for out of area
    };

private:
    struct Cfg {
        Base::Feature cfg_pos;  // Configured operator position
        void cset(Base::Lossy_error& str);
    };
    Cfg cfg_mgr;  // Manager for configuration
    
    struct Cmd {
        void cset(Base::Lossy_error& str);
        void cget(Base::Lossy& str) const;
    };
    Cmd cmd_mgr;  // Manager for command
};
```

### 3.2 Position Configuration and Commands

The `Cfg` structure manages the configuration of the operator position:

```cpp
void Operator_pos::Cfg::cset(Base::Lossy_error& str) {
    cfg_pos.cset(str);
    Bsp::Hfvar(Base::c_operator).set(cfg_pos);
}
```

The `Cmd` structure manages commands to change the operator position:

```cpp
void Operator_pos::Cmd::cset(Base::Lossy_error& str) {
    Base::Feature aux;
    aux.cset(str);
    Bsp::Hfvar(Base::c_operator).set(aux);
}

void Operator_pos::Cmd::cget(Base::Lossy& str) const {
    Base::Feature aux;
    Bsp::Hfvar(Base::c_operator).get(aux);
    aux.cget(str);
}
```

### 3.3 License Management

The `License` class checks if operations are authorized based on the operator's position:

```cpp
bool Operator_pos::License::authorized(const Geo::Apos& pos) {
    bool ret = p.has(Base::Permission::permission_tpfix);
    
    if (ret) {
        ch.cancel();
    } else {
        fidpos.refresh();
        Maverick::Rvector3 rn;
        fidpos.get_pos().relthis_drn(pos, rn);
        
        if (rn.norm22xy() > (p.pfix_dist*p.pfix_dist)) {
            if (!ch.ongoing()) {
                ch.tic();
            }
        } else {
            ch.cancel();
        }
        
        ret = ((!ch.ongoing()) || (ch.toc() < p.pfix_time));
    }
    
    return ret;
}
```

This method:
1. Checks if the system has the `permission_tpfix` permission
2. If not, calculates the distance from the operator position to the given position
3. If the distance exceeds the permitted distance, starts a timeout
4. Returns true if within distance or if the timeout hasn't expired

## 4. Route Marking System

The route marking system consists of two main classes: `Rmark` and `Rmarkmgr`.

### 4.1 Rmark: Route Mark

The `Rmark` class represents a single mark on a route that can trigger events when achieved.

#### 4.1.1 Class Structure and Attributes

```cpp
class Rmark : public Base::Ideserializable {
public:
    Rmark();
    virtual void cset(Base::Lossy_error& str);
    bool is_achieved(const Base::Patchid p, const Base::Curvst& c, const Real last_s);
    bool flush_achieved(Base::Patchid p);

private:
    enum Type {
        mrk_mstart = 0,  // Meters from start of patch
        mrk_sz = 1,      // Number of types
        mrk_off = 0xFFFF // Mark is off
    };
    
    Type t;           // Type of mark
    Base::Patchid id; // Patch id
    Real s;           // Position inside patch
    bool achieved;    // True if mark has been achieved
};
```

#### 4.1.2 Mark Configuration

The `cset()` method configures the mark from a PDI:

```cpp
void Rmark::cset(Base::Lossy_error& str) {
    str.get_enum16(t);
    str.get_uint16(id.patchset_id);
    str.get_int16(id.patch_id);
    str.get_float(s);

    str.assrt(((t == mrk_mstart) || (t == mrk_off)), Base::err_marks);
    achieved = false;
}
```

#### 4.1.3 Mark Achievement Detection

The `is_achieved()` method checks if the mark has been achieved:

```cpp
bool Rmark::is_achieved(const Base::Patchid p, const Base::Curvst& c, const Real last_s) {
    // Mark is achieved if current position is after mark and prior position is before mark
    const bool achieved_now = (t==mrk_mstart) && (id==p) && (c.s>=s) && (last_s<s);
    achieved |= achieved_now;
    return achieved_now;
}
```

### 4.2 Rmarkmgr: Route Mark Manager

The `Rmarkmgr` class manages multiple route marks and detects when they are achieved.

#### 4.2.1 Class Structure and Attributes

```cpp
class Rmarkmgr : public Imarks {
public:
    Rmarkmgr(const Base::Trackst& tst0, const Base::Patchid& achieved0, 
             Uint32 n0, Base::Memmgr::Type memtype);
    void step();
    bool mark_event(const Base::Mblock<Uint16>& marks) const;
    Base::Ideserializable_async& build_tun();

private:
    Base::Bitmblock mst;               // Array of achieved flags
    Base::Patchid last_achieved;       // Last patch achieved
    const Base::Trackst& tst;          // Current track state
    const Base::Patchid& achieved;     // Last achieved waypoint information
    Base::Tunarray_async<Rmark> marks; // Marks over route
    Real last_s;                       // Last position in patch
};
```

#### 4.2.2 Mark Processing

The `step()` method processes all marks to check if any have been achieved:

```cpp
void Rmarkmgr::step() {
    const bool achieved_changed = (last_achieved != achieved);
    last_achieved = achieved;
    
    if (achieved_changed) {
        last_s = invalid_s;  // Reset last_s when waypoint changes
    }

    for (Uint32 i = 0; i < mst.size(); ++i) {
        if(marks.is_enabled(i)) {
            Rmark& m = marks[i];
            const bool flush_last_achieved = achieved_changed ? m.flush_achieved(last_achieved) : false;
            const bool current_achieved = m.is_achieved(tst.current, tst.cst, last_s);
            mst.set(i, flush_last_achieved || current_achieved);
        } else {
            mst.clear(i);
        }
    }
    
    last_s = tst.cst.s;  // Store current position for next step
}
```

#### 4.2.3 Event Detection

The `mark_event()` method checks if any of the specified marks have been achieved:

```cpp
bool Rmarkmgr::mark_event(const Base::Mblock<Uint16>& marks) const {
    bool ret = false;
    const Uint16* const vz = marks.last();
    
    for (const Uint16* vi = &marks[0]; (!ret) && (vi <= vz); ++vi) {
        ret = mst.get(*vi);
    }
    
    return ret;  // True if any mark was achieved
}
```

## 5. Meta: PDI Management

The `Meta` class provides functionality to register meta PDI files that are not loaded by Veronte but are used by tools.

### 5.1 Class Structure

```cpp
class Meta {
public:
    static void register_cfgs(Media::Cfgmgr& cfg);

private:
    Meta();  // = delete
    Meta(const Meta& orig);  // = delete
    Meta& operator=(const Meta& orig);  // = delete
};
```

### 5.2 Meta PDI Registration

The `register_cfgs()` method registers all meta PDI files with the configuration manager:

```cpp
void Meta::register_cfgs(Media::Cfgmgr& cmgr) {
    static const Base::Cfg::Id meta_ids[] = {
        Base::Cfg::cfg_mcal,
        Base::Cfg::cfg_mcheck,
        Base::Cfg::cfg_mname,
        Base::Cfg::cfg_meta_tc,
        Base::Cfg::cfg_mgeoref,
        Base::Cfg::cfg_mrvar,
        Base::Cfg::cfg_muvar,
        Base::Cfg::cfg_mbit,
        Base::Cfg::cfg_mevent,
        Base::Cfg::cfg_maction,
        Base::Cfg::cfg_mevact,
        Base::Cfg::cfg_mmission,
        Base::Cfg::cfg_checklist,
        Base::Cfg::cfg_mstick,
        Base::Cfg::cfg_mmodes,
        Base::Cfg::cfg_mexcludevar,
        Base::Cfg::cfg_mstep,
        Base::Cfg::cfg_mrtcm,
        Base::Cfg::cfg_mnotif,
        Base::Cfg::cfg_mgeocage,
        Base::Cfg::cfg_mdevice,
        Base::Cfg::cfg_mfmgr,
        Base::Cfg::cfg_mblocks,
        Base::Cfg::cfg_meaut_gname,
        Base::Cfg::cfg_ext_obs,
        Base::Cfg::cfg_metaop,
        Base::Cfg::cfg_mchnl4x,
        Base::Cfg::cfg_mchannel,
        Base::Cfg::cfg_mlayer,
        Base::Cfg::cfg_mxplane
    };
    static const Uint16 meta_cnt = sizeof(meta_ids)/sizeof(meta_ids[0]);

    for(Uint16 i=0; i<meta_cnt; ++i) {
        cmgr.add_meta(meta_ids[i]);
    }
}
```

## 6. Mem_log_ctrl: Memory Log Control

The `Mem_log_ctrl` class provides functionality for non-persistent memory logging.

### 6.1 Class Structure and Attributes

```cpp
struct Mem_log_ctrl {
    static const Uint16 mem_file_log_part = 0;  // Memory file doesn't support partitions

    Mem_log_ctrl(const volatile bool& is_wr_allowed0,
                 Base::Mblock<Uint16> fs,
                 Base::Ifile& index_file,
                 Base::Session& session0,
                 Real time_flush0,
                 Base::Ifile::Uid header_uid0,
                 Base::Xfstrt::Type_kpodsync& cfg0,
                 Base::Istep* file_helper);
    void step();

private:
    const volatile bool& is_wr_allowed;  // Is writing allowed flag
    Base::Fsmem mem_data;                // File system in RAM
    Base::Mem_file data_file;            // Memory file for log data
    Base::Mem_file aux_file;             // Auxiliary memory file
    Media::Logctrl log_ctrl;             // Log control
    Base::Fstr log_sampler;              // Log sampler
    Base::Xfstrt::Type_kpodsync& cfg;    // Log configuration
    Bsp::Hbvar log_sampling;             // Log sampling
    bool is_init;                        // Flag to control if index file has been updated
};
```

### 6.2 Initialization

The constructor initializes the memory log control system:

```cpp
Mem_log_ctrl::Mem_log_ctrl(const volatile bool& is_wr_allowed0,
                           Base::Mblock<Uint16> fs,
                           Base::Ifile& index_file0,
                           Base::Session& session0,
                           Real time_flush0,
                           Base::Ifile::Uid header_uid0,
                           Base::Xfstrt::Type_kpodsync& cfg0,
                           Base::Istep* file_helper) :
    is_wr_allowed(is_wr_allowed0),
    mem_data(fs, session0),
    data_file(mem_data),
    aux_file(mem_data),
    log_ctrl(mem_file_log_part,
             Base::Fsmem::max_files,
             data_file,
             index_file0,
             aux_file,
             session0,
             time_flush0,
             header_uid0,
             Bsp::Huvar(Base::vu_memlog_first).get_ref(),
             Bsp::Huvar(Base::vu_memlog_last).get_ref(),
             Bsp::sysaddr(),
             file_helper),
    log_sampler(log_ctrl, session0),
    cfg(cfg0),
    log_sampling(Base::kbit_log_ram_stp),
    is_init(false)
{
    log_sampling.set(true);
}
```

### 6.3 Logging Process

The `step()` method handles the logging process:

```cpp
void Mem_log_ctrl::step() {
    if(!is_init) {
        static const Real max_init_t = 0.1F;
        log_ctrl.init(max_init_t);
        is_init = true;
    }

    if(log_sampling.get() && is_wr_allowed) {
        // Sample data to log
        Base::Xfstrt::Type_rd rd(cfg);
        Base::Async_res res = log_sampler.sample(Base::Xfstr::Type_rd(rd));
    } else {
        // Close session if requested
        const bool session_closed = log_sampler.close_session() == Base::async_done_ok;
        if(session_closed) {
            is_init = false;
            log_sampling.set(true);
        }
    }
}
```

This method:
1. Initializes the log control if not already initialized
2. If logging is enabled and writing is allowed, samples data to log
3. Otherwise, attempts to close the session
4. If the session is closed successfully, resets the initialization flag

## 7. Integration and Relationships

### 7.1 Operational Variable System Integration

The operational variable system components work together as follows:

1. `Opmgr` is the central manager that:
   - Initializes the operational variable system
   - Provides access to operational variables
   - Sets up the `Oprvar` static reference

2. `Opranges` uses `Opmgr` to:
   - Access operational variables
   - Check if variables are within configured ranges

3. `Oprvar` uses the static reference set by `Opmgr` to:
   - Access operational variables by reference
   - Optimize access with precomputed indices

### 7.2 Route Marking System Integration

The route marking system components work together as follows:

1. `Rmarkmgr` manages multiple `Rmark` instances and:
   - Processes all marks during each step
   - Detects when marks are achieved
   - Provides an interface for checking mark events

2. `Rmark` represents a single mark and:
   - Stores mark configuration (patch, position)
   - Detects when the mark is achieved
   - Tracks achievement state

### 7.3 System-Wide Integration

These utility components integrate with the broader VPGNC framework:

1. `Calibration` integrates with:
   - `Ver::Suite` for sensor access
   - `Media::Cfgmgr` for configuration management

2. The operational variable system integrates with:
   - The variable management system
   - The configuration system

3. `Operator_pos` integrates with:
   - The permission system
   - The feature variable system

4. The route marking system integrates with:
   - The track state system
   - The event system

5. `Meta` integrates with:
   - `Media::Cfgmgr` for PDI registration

6. `Mem_log_ctrl` integrates with:
   - The file system
   - The session management system
   - The logging system

## 8. Key Workflows

### 8.1 Gyroscope Calibration Workflow

1. Configuration is loaded from PDI
2. Calibration task is started
3. Measurements are collected for the specified time
4. Calibration is computed from collected measurements
5. Calibration is saved to PDI or synced in memory
6. Task completes when calibration is finished

### 8.2 Operational Variable Management Workflow

1. `Opmgr` is initialized with a checklist
2. `Oprvar::set_opmgr()` is called to set the static reference
3. `Oprvar` instances are created to reference operational variables
4. `Opranges` is configured with min/max ranges for variables
5. `Opranges::check()` is called to verify variables are within ranges

### 8.3 Operator Position Management Workflow

1. Operator position is configured via PDI
2. Commands can be sent to change the operator position
3. `License::authorized()` checks if operations are permitted based on position
4. If the vehicle moves too far from the operator, a timeout starts
5. Operations are restricted if the timeout expires

### 8.4 Route Marking Workflow

1. Route marks are configured via PDI
2. `Rmarkmgr::step()` is called periodically to check marks
3. When a vehicle passes a mark, it is flagged as achieved
4. `Rmarkmgr::mark_event()` is called to check if specific marks were achieved
5. The event system uses this information to trigger automations

### 8.5 Memory Logging Workflow

1. Memory log control is initialized with configuration
2. `Mem_log_ctrl::step()` is called periodically
3. If logging is enabled, data is sampled and stored in memory
4. If logging is disabled, the session is closed
5. When the session is closed, the system is reset for a new session

## 9. Referenced Context Files

The following context file provided valuable information for understanding the VPGNC framework:

- `06_VPGNC_Core.md` - Provided overview of the VPGNC framework core components, including the Vpu class, Vpunav class, and variable management classes.

This file helped establish the broader context in which these utility components operate, particularly regarding the variable management system and the overall architecture of the VPGNC framework.