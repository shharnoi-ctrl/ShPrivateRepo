# Generated from:

- code/PA_monitor_tests/include/Mon_active_interface_check_pa_test.h (205 tokens)
- code/PA_monitor_tests/include/Mon_pds_command_generator_pa_test.h (604 tokens)
- code/PA_monitor_tests/include/Mon_pretakeoff_bounding_volume_check_pa_test.h (277 tokens)
- code/PA_monitor_tests/include/Mon_vms_checks_pa_test.h (345 tokens)
- code/PA_monitor_tests/include/Mon_reset_check_pa_test.h (268 tokens)
- code/PA_monitor_tests/include/Mon_mission_phase_check_pa_test.h (264 tokens)
- code/PA_monitor_tests/include/Mon_land_command_check_pa_test.h (265 tokens)
- code/PA_monitor_tests/include/Mon_vehicle_state_attitude_check_pa_test.h (564 tokens)
- code/PA_monitor_tests/include/Mon_message_rate_check_pa_test.h (240 tokens)
- code/PA_monitor_tests/include/Mon_locker_delivery_check_pa_test.h (268 tokens)
- code/PA_monitor_tests/include/Mon_motor_arm_check_pa_test.h (211 tokens)
- code/PA_monitor_tests/include/Mon_nav_velocity_check_pa_test.h (417 tokens)
- code/PA_monitor_tests/include/Mon_inadvertent_takeoff_check_pa_test.h (234 tokens)
- code/PA_monitor_tests/include/Mon_navigation_position_checks_pa_test.h (269 tokens)
- code/PA_monitor_tests/include/Mon_vehicle_state_position_check_pa_test.h (545 tokens)
- code/PA_monitor_tests/include/Mon_motor_performance_check_pa_test.h (416 tokens)
- code/PA_monitor_tests/include/Mon_reset_pa_test.h (261 tokens)
- code/PA_monitor_tests/include/Mon_nav_attitude_check_pa_test.h (291 tokens)
- code/PA_monitor_tests/include/Mon_vehicle_state_linear_velocity_check_pa_test.h (407 tokens)
- code/PA_monitor_tests/include/Mon_switchover_logic_pa_test.h (1302 tokens)
- code/PA_monitor_tests/include/Mon_vehicle_state_angular_velocity_check_pa_test.h (705 tokens)
- code/PA_monitor_tests/include/Mon_disarm_check_pa_test.h (1161 tokens)
- code/PA_monitor_tests/include/Mon_urgent_land_monitor_pa_test.h (328 tokens)
- code/PA_monitor_tests/include/Mon_enacted_contingency_checks_pa_test.h (303 tokens)
- code/PA_monitor_tests/include/Raim_test.h (1914 tokens)
- code/PA_monitor_tests/source/Mon_vehicle_state_linear_velocity_check_pa_test.cpp (10360 tokens)
- code/PA_monitor_tests/source/Mon_pds_command_generator_pa_test.cpp (13114 tokens)
- code/PA_monitor_tests/source/Mon_inadvertent_takeoff_check_pa_test.cpp (1558 tokens)
- code/PA_monitor_tests/source/Mon_reset_check_pa_test.cpp (1174 tokens)
- code/PA_monitor_tests/source/Mon_land_command_check_pa_test.cpp (2665 tokens)
- code/PA_monitor_tests/source/Mon_disarm_check_pa_test.cpp (20025 tokens)
- code/PA_monitor_tests/source/Mon_enacted_contingency_checks_pa_test.cpp (2279 tokens)
- code/PA_monitor_tests/source/Mon_locker_delivery_check_pa_test.cpp (4095 tokens)
- code/PA_monitor_tests/source/Mon_message_rate_check_pa_test.cpp (2527 tokens)
- code/PA_monitor_tests/source/Mon_reset_pa_test.cpp (2270 tokens)
- code/PA_monitor_tests/source/Mon_active_interface_check_pa_test.cpp (1364 tokens)
- code/PA_monitor_tests/source/Mon_switchover_logic_pa_test.cpp (8017 tokens)
- code/PA_monitor_tests/source/Mon_pretakeoff_bounding_volume_check_pa_test.cpp (2368 tokens)
- code/PA_monitor_tests/source/Mon_nav_attitude_check_pa_test.cpp (5658 tokens)
- code/PA_monitor_tests/source/Mon_vehicle_state_attitude_check_pa_test.cpp (17691 tokens)
- code/PA_monitor_tests/source/Mon_motor_performance_check_pa_test.cpp (2952 tokens)
- code/PA_monitor_tests/source/Mon_mission_phase_check_pa_test.cpp (2714 tokens)
- code/PA_monitor_tests/source/Mon_vehicle_state_angular_velocity_check_pa_test.cpp (23047 tokens)
- code/PA_monitor_tests/source/Mon_navigation_position_checks_pa_test.cpp (4173 tokens)
- code/PA_monitor_tests/source/Raim_test.cpp (18916 tokens)
- code/PA_monitor_tests/source/Mon_nav_velocity_check_pa_test.cpp (6075 tokens)
- code/PA_monitor_tests/source/Mon_vms_checks_pa_test.cpp (2351 tokens)
- code/PA_monitor_tests/source/Mon_urgent_land_monitor_pa_test.cpp (2416 tokens)
- code/PA_monitor_tests/source/Mon_motor_arm_check_pa_test.cpp (1432 tokens)
- code/PA_monitor_tests/source/Mon_vehicle_state_position_check_pa_test.cpp (14735 tokens)

---

# Monitor Check Tests Analysis

This analysis focuses on the monitor check tests in the Prime Air system, examining how they verify the correct behavior of various safety checks performed by the monitor component.

## Common Testing Patterns

Across all monitor check tests, several common patterns emerge:

1. **Test Class Structure**: Each test class inherits from the corresponding monitor check class and adds testing functionality:
   - Constructor that initializes test parameters and inputs
   - `reset()` method to restore default test conditions
   - `test_all()` static method as the entry point
   - `run_all_tests()` method that executes individual test cases
   - Individual test methods for specific functionality

2. **Test Execution Pattern**:
   - Set up test inputs and expected outputs
   - Call the monitor check's `step()` method
   - Verify outputs match expectations
   - Reset test conditions for the next test

3. **Comprehensive Coverage**:
   - Tests for both nominal (passing) and off-nominal (failing) conditions
   - Tests for parameter sensitivity (thresholds, enable flags)
   - Tests for different flight phases and contingency states

## Vehicle State Checks

### Angular Velocity Checks (`Mon_vehicle_state_angular_velocity_check_pa_test`)

Tests verify that the monitor correctly detects unsafe angular velocities:

```cpp
bool test_angular_velocity_check_est_rpy_rate_fail();
bool test_angular_velocity_check_exp_rpy_rate_fail();
bool test_compute_max_roll_rate_error();
bool test_compute_max_pitch_rate_error();
bool test_compute_max_yaw_rate_error();
```

Key aspects tested:
- **Roll, Pitch, and Yaw Rate Errors**: Tests verify detection when estimated and expected angular rates differ beyond thresholds
- **Phase-Specific Thresholds**: Different thresholds are applied for VTOL, transition, and WBF flight phases
- **Contingency Thresholds**: Higher thresholds are applied during contingency operations (Stop & Hover, Evasive Maneuver)
- **Airspeed-Based Thresholds**: Maximum allowable errors scale with equivalent airspeed

The tests verify that:
1. Angular rate errors are correctly computed from monitor and primary state estimates
2. Appropriate thresholds are selected based on flight phase and contingency status
3. Check failures are properly triggered when thresholds are exceeded
4. Check remains inactive under appropriate conditions (initialization, degraded state estimates)

### Position Checks (`Mon_vehicle_state_position_check_pa_test`)

Tests verify detection of position errors relative to expected trajectory:

```cpp
bool test_vtol();
bool test_vtol_stop_and_hover();
bool test_transition();
bool test_wbf();
```

Key aspects tested:
- **Alongtrack, Crosstrack, and Altitude Errors**: Tests verify detection when aircraft deviates from expected position
- **Phase-Specific Thresholds**: Different thresholds for VTOL, transition, and WBF flight phases
- **Contingency Thresholds**: Higher thresholds during contingency operations
- **DGNSS Availability**: Tests confirm behavior changes appropriately when DGNSS is unavailable

The tests verify that:
1. Position errors are correctly computed in alongtrack, crosstrack, and altitude dimensions
2. Appropriate thresholds are selected based on flight phase and contingency status
3. Check failures are properly triggered when thresholds are exceeded
4. Check remains inactive under appropriate conditions (initialization, no ground-to-air transition)

## Navigation Checks

### Navigation Position Checks (`Mon_navigation_position_checks_pa_test`)

Tests verify detection of inconsistencies between navigation solutions:

```cpp
bool test_difference_large();
bool test_difference_large_dgnss();
bool test_difference_small();
bool test_difference_small_dgnss();
```

Key aspects tested:
- **Position Difference Detection**: Tests verify detection when position estimates from different sources differ significantly
- **DGNSS Thresholds**: Tighter thresholds are applied when DGNSS is available
- **Horizontal and Vertical Differences**: Separate thresholds for horizontal and vertical position differences

The tests verify that:
1. Position differences between navigation solutions are correctly computed
2. Appropriate thresholds are selected based on DGNSS availability
3. Check failures are properly triggered when thresholds are exceeded
4. Check remains inactive under appropriate conditions (initialization, no mission readiness signal)

### Navigation Velocity Checks (`Mon_nav_velocity_check_pa_test`)

Tests verify detection of velocity inconsistencies between navigation solutions:

```cpp
bool test_check_erroneous_velocity();
bool test_check_fault_detection_counter_increment_decrement();
bool test_check_statemachine_inactive_to_active();
```

Key aspects tested:
- **Velocity Error Detection**: Tests verify detection when velocity estimates from different sources differ significantly
- **Fault Detection Counter**: Tests verify proper incrementing and decrementing of fault counters
- **State Machine Transitions**: Tests verify proper transitions between inactive, active, and failure states

The tests verify that:
1. Velocity differences between navigation solutions are correctly computed
2. Fault detection counters properly increment when errors are detected and decrement when errors are resolved
3. State machine transitions correctly between states based on error conditions
4. Check failures are properly triggered when fault counters exceed thresholds

## VMS (Vehicle Management System) Checks

### Motor Arm Check (`Mon_motor_arm_check_pa_test`)

Tests verify detection of improper motor arming states:

```cpp
bool test_motor_arm_uninitialized();
bool test_motor_arm_idle();
bool test_motor_arm_pre_flight();
bool test_motor_arm_in_flight();
bool test_motor_arm_post_flight();
```

Key aspects tested:
- **Flight Phase Validation**: Tests verify that motors must be armed during in-flight phase
- **Mission Mode Validation**: Tests verify appropriate motor arming states for different mission modes

The tests verify that:
1. Motor arm check correctly validates motor arming state based on mission phase
2. Check failures are properly triggered when motors are disarmed during flight
3. Check remains inactive in appropriate mission phases (pre-flight, post-flight)

### Inadvertent Takeoff Check (`Mon_inadvertent_takeoff_check_pa_test`)

Tests verify detection of unintended motor activation:

```cpp
bool test_safe_rpm();
bool test_takeoff_rpm();
```

Key aspects tested:
- **RPM Thresholds**: Tests verify detection when motor RPMs exceed safe levels in pre-flight

The tests verify that:
1. Check correctly detects when motor RPMs exceed thresholds during pre-flight
2. Check failures are properly triggered when RPMs exceed thresholds

### Enacted Contingency Checks (`Mon_enacted_contingency_checks_pa_test`)

Tests verify detection of mismatches between commanded and enacted contingencies:

```cpp
bool test_urgent_land_mismatch();
bool test_straight_land_mismatch();
```

Key aspects tested:
- **Contingency Mismatch Detection**: Tests verify detection when commanded contingency doesn't match enacted contingency
- **Timeout Handling**: Tests verify proper handling of detection timeouts

The tests verify that:
1. Check correctly detects mismatches between commanded and enacted contingencies
2. Check failures are properly triggered when mismatches are detected
3. Check remains inactive when appropriate conditions are met (e.g., monitor has detected dual probe fault)

### Mission Phase Check (`Mon_mission_phase_check_pa_test`)

Tests verify detection of mission phase inconsistencies:

```cpp
bool test_pre_flight_phase_out_of_sync();
bool test_phase_of_flight_out_of_sync();
bool test_drone_mission_state_out_of_sync();
```

Key aspects tested:
- **Phase Synchronization**: Tests verify detection when monitor and primary systems have different mission phases

The tests verify that:
1. Check correctly detects when mission phases are out of sync between monitor and primary
2. Check failures are properly triggered when phases are out of sync

## Urgent Land Monitor

Tests verify proper detection of conditions requiring urgent landing:

```cpp
bool test_is_nav_ul_valid();
bool test_is_eps_ul_valid();
bool test_is_in_land_mission_phase();
bool test_comms_ul_commanded();
```

Key aspects tested:
- **Navigation Conditions**: Tests verify detection of navigation issues requiring urgent land
- **Energy Conditions**: Tests verify detection of energy-related issues requiring urgent land
- **Mission Phase**: Tests verify detection of landing mission phase
- **Command Handling**: Tests verify proper handling of urgent land commands

The tests verify that:
1. Urgent land monitor correctly identifies conditions requiring urgent landing
2. Monitor properly responds to navigation issues, energy issues, mission phases, and commands

## RAIM (Receiver Autonomous Integrity Monitoring) Tests

Tests verify proper functioning of GNSS integrity monitoring:

```cpp
bool Test_2_gnss_compact();
bool Test_2_gnss_dgnss_compact();
bool ReplayRawMeasAndNavCsvData();
```

Key aspects tested:
- **Position Solution Validation**: Tests verify correct position solutions from GNSS measurements
- **DGNSS Integration**: Tests verify proper integration of differential GNSS corrections
- **Integrity Monitoring**: Tests verify detection of GNSS measurement inconsistencies

The tests verify that:
1. RAIM correctly processes GNSS measurements and navigation messages
2. Position and velocity solutions match expected values
3. RAIM properly detects and handles measurement inconsistencies
4. DGNSS corrections are properly applied when available

## Testing Methodology

The monitor check tests demonstrate a comprehensive approach to safety verification:

1. **Boundary Testing**: Tests verify behavior at and around threshold values
   ```cpp
   testcases[0].error_lpf_rad_per_s = check_inputs_.roll_rate_trim_ned2trim.max_error_lpf_rad_per_s;
   testcases[1].error_lpf_rad_per_s = check_inputs_.roll_rate_trim_ned2trim.max_error_lpf_rad_per_s + 1.0F;
   ```

2. **State Machine Testing**: Tests verify proper state transitions and behaviors
   ```cpp
   test_result = test_check_statemachine_inactive_to_active();
   test_result = test_check_statemachine_active_to_inactivelatched();
   ```

3. **Parameter Sensitivity**: Tests verify behavior with different parameter values
   ```cpp
   test_parameters_.count_increment = 3;
   test_parameters_.count_decrement = 2;
   test_parameters_.max_fault_detection_count = 25;
   ```

4. **Failure Mode Testing**: Tests verify proper detection of various failure modes
   ```cpp
   test_result = test_angular_velocity_check_est_rpy_rate_fail();
   test_result = test_difference_large_dgnss();
   ```

5. **Mathematical Correctness**: Tests verify correct implementation of mathematical algorithms
   ```cpp
   bool test_compute_expected_roll_trim_ned2trim();
   bool test_compute_expected_pitch_trim_ned2trim();
   bool test_compute_expected_yaw_trim_ned2trim();
   ```

## Conclusion

The monitor check tests demonstrate a robust safety verification framework for the Prime Air system. They verify that the monitor correctly detects unsafe conditions across a wide range of parameters and flight phases, ensuring the system can respond appropriately to maintain safety.

The tests are particularly thorough in verifying:
- Vehicle state monitoring (attitude, position, velocity)
- Navigation solution consistency
- Motor and delivery system safety
- System integrity and communication reliability
- Proper handling of contingency situations

This comprehensive testing approach helps ensure the Prime Air system can detect and respond to unsafe conditions before they lead to system failures or safety incidents.

## Referenced Context Files

The following context files provided valuable information for understanding the monitor check tests:

1. `Mon_vehicle_state_angular_velocity_check_pa_test.cpp`: Provided detailed tests for angular velocity checks, including threshold selection and error computation.

2. `Mon_navigation_position_checks_pa_test.cpp`: Provided tests for navigation position checks, including DGNSS threshold handling.

3. `Raim_test.cpp`: Provided tests for GNSS integrity monitoring, including position solution validation and DGNSS integration.

4. `Mon_nav_velocity_check_pa_test.cpp`: Provided tests for navigation velocity checks, including fault detection counter behavior.

5. `Mon_vms_checks_pa_test.cpp`: Provided tests for vehicle management system checks, including motor arming and contingency handling.

6. `Mon_urgent_land_monitor_pa_test.cpp`: Provided tests for urgent land monitoring, including navigation and energy condition detection.

7. `Mon_motor_arm_check_pa_test.cpp`: Provided detailed tests for motor arming checks in different mission phases.

8. `Mon_vehicle_state_position_check_pa_test.cpp`: Provided tests for position checks, including alongtrack, crosstrack, and altitude error detection.