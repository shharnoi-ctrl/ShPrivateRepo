# Generated from:

- items/pdi_Monitor/setup/ver_spdif_stg_ua_lights.xml (66 tokens)
- items/pdi_Monitor/setup/ver_spdif_amz_lights.xml (24431 tokens)

## With context from:

- Amazon-PrimeAir/items/ASTRO/items/Monitor/07_System_Architecture.md (3174 tokens)
- Amazon-PrimeAir/items/ASTRO/items/Monitor/06_Communication_Interfaces.md (7524 tokens)

---

# PDI Monitor Lighting Systems Analysis

## 1. Overview of Lighting Systems

The PDI Monitor system incorporates two distinct lighting subsystems:
- **UA (Unmanned Aircraft) Lights**: Basic configuration for aircraft lighting
- **AMZ (Amazon) Lights**: Advanced lighting system with complex patterns and sequences

These lighting systems are critical components of the PDI Monitor, providing visual indicators of the aircraft's status, operational mode, and potentially supporting navigation and visibility requirements.

## 2. UA Lights Configuration

### 2.1 Basic Configuration (File: ver_spdif_stg_ua_lights.xml)

```xml
<entry-stg-ua-lights>
    <id>382</id>
    <filename>stg_ua_lights.bin</filename>
    <version>
        <major>7</major>
        <minor>1</minor>
        <revision>1</revision>
    </version>
    <data>
        <var0>1200</var0>
    </data>
</entry-stg-ua-lights>
```

#### 2.1.1 Configuration Parameters

| Parameter | Value | Description |
|-----------|-------|-------------|
| ID | 382 | Unique identifier for UA lights configuration |
| Filename | stg_ua_lights.bin | Binary configuration file |
| Version | 7.1.1 | Configuration version |
| var0 | 1200 | Single parameter value, likely a timing value in milliseconds |

#### 2.1.2 UA Lights Functional Analysis

The UA lights configuration is minimal, containing only a single parameter (`var0` with value 1200). This suggests:

- The UA lights system has a simple configuration with limited customization
- The value 1200 likely represents a timing parameter (possibly flash rate or duty cycle in milliseconds)
- The system may have predefined behavior with this single parameter controlling its timing

## 3. AMZ Lights Configuration

### 3.1 Basic Configuration (File: ver_spdif_amz_lights.xml)

The AMZ lights system has a significantly more complex configuration structure compared to the UA lights, with detailed control over lighting patterns, sequences, and states.

#### 3.1.1 Configuration Parameters

| Parameter | Description |
|-----------|-------------|
| ID | 486 (Unique identifier for AMZ lights configuration) |
| Filename | amz_lights.bin (Binary configuration file) |
| Version | 7.1.1 (Configuration version) |

### 3.2 Register Configuration

The AMZ lights system uses a register-based configuration approach with 42 register entries defining various system parameters:

```xml
<config>
    <str-tunarray-element>
        <reg>128</reg>
        <value>56</value>
    </str-tunarray-element>
    <!-- Additional register configurations -->
</config>
```

#### 3.2.1 Key Register Values

| Register | Value | Potential Purpose |
|----------|-------|-------------------|
| 0 | 96 | Base configuration or mode setting |
| 1 | 0 | Disabled feature or reserved |
| 2 | 192 | High-level control parameter |
| 9, 13, 17 | 25 | Timing parameters (all identical) |
| 112-127 | 94 | Intensity values (all identical) |
| 128 | 56 | Master control register |
| 129 | 7 | Configuration flags or mode bits |
| 130 | 66 | Secondary control parameter |

### 3.3 Light States Configuration

The AMZ lights system defines separate light states for left and right sides, with 13 distinct state definitions for each side. Each state contains:

1. **Phases**: 20 phase values per state
2. **Widths**: 20 width values per state

#### 3.3.1 Light State Structure

```xml
<light-states-left>
    <str-tunarray-element>
        <phases>
            <!-- 20 phase values -->
        </phases>
        <widths>
            <!-- 20 width values -->
        </widths>
    </str-tunarray-element>
    <!-- 12 additional state definitions -->
</light-states-left>
```

#### 3.3.2 Pattern Analysis

The phase and width values define complex lighting patterns. For example, in the first light state:

```xml
<phases>
    <str-tunarray-element>0</str-tunarray-element>
    <!-- values 0-4 are all 0 -->
    <str-tunarray-element>45</str-tunarray-element>
    <str-tunarray-element>0</str-tunarray-element>
    <!-- ... -->
    <str-tunarray-element>71</str-tunarray-element>
    <str-tunarray-element>15</str-tunarray-element>
    <!-- ... -->
</phases>
<widths>
    <str-tunarray-element>0</str-tunarray-element>
    <!-- values 0-4 are all 0 -->
    <str-tunarray-element>25</str-tunarray-element>
    <str-tunarray-element>15</str-tunarray-element>
    <!-- ... -->
    <str-tunarray-element>25</str-tunarray-element>
    <str-tunarray-element>15</str-tunarray-element>
    <!-- ... -->
</widths>
```

This pattern shows:
- Initial inactive period (phases 0-4 are 0)
- Active phase at position 5 with phase=45 and width=25
- Inactive phase at position 6 with phase=0 and width=15
- Another active phase at position 9 with phase=71 and width=25
- Another active phase at position 10 with phase=15 and width=15

The pattern continues with varying phase and width values, creating a complex blinking or pulsing pattern.

#### 3.3.3 State Pattern Characteristics

Each state has a unique pattern signature. Some notable patterns:

| State | Characteristic | Potential Purpose |
|-------|----------------|-------------------|
| 0 | Multiple short pulses with phases 45, 71, 97 | Standard operation indicator |
| 1 | Sparse pattern with phases 64, 128 | Warning or alert pattern |
| 2 | Pattern with phases 84, 169, 32 | Status indicator |
| 5 | Complex pattern with phases 42, 85, 32 | Special operation mode |
| 7 | Dense pattern with phases 51, 102, 64, 128 | Emergency or critical status |
| 8 | Complex pattern with phases 153, 184, 214 | Navigation or orientation indicator |
| 9 | Rapid pattern with phases 38, 64, 89 | Attention-grabbing pattern |

### 3.4 Sequence Configuration

The AMZ lights system defines 11 sequences, each containing 10 steps. Each step specifies which light state to use for the left and right sides:

```xml
<sequences>
    <str-tunarray-element>
        <str-tunarray-element>
            <left>11</left>
            <right>11</right>
        </str-tunarray-element>
        <!-- 9 additional steps -->
    </str-tunarray-element>
    <!-- 10 additional sequences -->
</sequences>
```

#### 3.4.1 Sequence Analysis

| Sequence | Pattern | Potential Purpose |
|----------|---------|-------------------|
| 0 | All steps use state 11 for both sides | Default or idle sequence |
| 1 | Steps alternate between states 8 and 12 | Warning or attention sequence |
| 2 | Mostly state 6, ending with state 7 | Transition sequence |
| 3 | All steps use state 0 | Basic operation sequence |
| 4 | All steps use state 9 | Status indication sequence |
| 5 | Starts with state 10, transitions to state 12 | Alert escalation sequence |
| 6 | Starts with state 3, then all state 5 | Special operation sequence |
| 7 | Starts with state 1, then all state 5 | Alternative special operation |
| 8 | All steps use state 12 | Critical status sequence |
| 9 | Starts with state 4, then all state 5 | Warning transition sequence |
| 10 | Starts with state 2, then all state 5 | Status transition sequence |

#### 3.4.2 Sequence Symmetry

Most sequences maintain symmetry between left and right sides (same state used for both), suggesting:
- Balanced visual appearance
- Consistent visibility from different viewing angles
- Simplified control logic

## 4. Lighting Control Mechanisms

### 4.1 Control Architecture

Based on the configuration files and system architecture context, the lighting systems are likely controlled through:

1. **Register-Based Control**: The AMZ lights use a register-based approach where specific registers control different aspects of the lighting system
2. **State-Based Patterns**: Predefined light states contain specific patterns of phases and widths
3. **Sequence-Based Activation**: Higher-level sequences determine which states are active at any given time
4. **Symmetrical Control**: Left and right sides can be controlled independently but are often synchronized

### 4.2 Control Flow

The likely control flow for the lighting systems is:

1. System selects an appropriate sequence based on aircraft status or mode
2. Sequence defines which light states to use for left and right sides at each step
3. Light states define specific phase and width patterns for the lights
4. Register settings control global parameters like intensity (registers 112-127 all set to 94)

### 4.3 Timing Control

Several timing mechanisms are evident:

1. **Phase Values**: Define when lights activate within a pattern
2. **Width Values**: Define how long lights remain active
3. **Sequence Steps**: Define how patterns change over time
4. **UA Lights Timing**: Simple timing parameter (1200) for basic timing control

## 5. Integration with System Architecture

### 5.1 Relationship to PDI Monitor System

The lighting systems are integrated into the PDI Monitor as configuration components:

1. **Configuration Files**: Stored as XML definitions in the setup directory
2. **Binary Representation**: Referenced as binary files (stg_ua_lights.bin and amz_lights.bin)
3. **Version Control**: Both systems use version 7.1.1, consistent with other system components

### 5.2 Operational Integration

Based on the system architecture context, the lighting systems likely:

1. **Respond to System State**: Light patterns change based on the operational state of the aircraft
2. **Provide Visual Feedback**: Indicate system status, warnings, or operational modes
3. **Support Safety Functions**: Provide visibility and status indication for safety purposes
4. **Integrate with Monitoring**: The PDI Monitor likely controls lights based on monitored parameters

## 6. Lighting System State Model

### 6.1 State Transition Model

The AMZ lights system implements a sophisticated state model:

```
                    ┌─────────────┐
                    │ System Boot │
                    └──────┬──────┘
                           │
                           ▼
                    ┌─────────────┐
                    │ Default     │
                    │ Sequence (0)│
                    └──────┬──────┘
                           │
           ┌───────────────┴───────────────┐
           │                               │
           ▼                               ▼
┌────────────────────┐         ┌────────────────────┐
│ Normal Operation   │         │ Special Operation  │
│ Sequences (3,4)    │◄────────┤ Sequences (6,7,8)  │
└────────┬───────────┘         └────────┬───────────┘
         │                              │
         ▼                              ▼
┌────────────────────┐         ┌────────────────────┐
│ Warning/Alert      │         │ Transition         │
│ Sequences (1,5)    │         │ Sequences (2,9,10) │
└────────────────────┘         └────────────────────┘
```

### 6.2 Light State Usage Patterns

Analyzing the sequence definitions reveals how light states are used:

1. **State 5**: Most commonly used state (appears in sequences 6, 7, 9, 10)
2. **State 11**: Used exclusively in sequence 0 (default sequence)
3. **State 12**: Used in sequences 1 and 8 (likely warning/critical states)
4. **States 0-4**: Used in specific sequences for particular indications

## 7. Technical Implementation Details

### 7.1 Hardware Interface

While not explicitly defined in the provided files, the lighting systems likely interface with:

1. **PWM Outputs**: The system architecture includes PWM device configurations that could control light intensity
2. **GPIO Pins**: Digital outputs could control on/off states of lights
3. **Dedicated Controllers**: The register-based approach suggests a dedicated lighting controller

### 7.2 Performance Characteristics

The lighting system configuration suggests:

1. **Update Rate**: Likely synchronized with system cycles
2. **Pattern Resolution**: High resolution with 20 phase/width values per state
3. **State Transitions**: Quick transitions between states based on sequence steps
4. **Intensity Control**: 16 intensity registers (112-127) all set to the same value (94)

## 8. Cross-Component Relationships

### 8.1 Relationship to Communication Interfaces

Based on the context files, the lighting systems likely interact with:

1. **CAN Bus**: Status and commands may be transmitted over CAN
2. **Cross-Process Communication**: Light states may be controlled via XPCU8 or similar mechanisms
3. **Telemetry**: Light status may be included in telemetry data

### 8.2 Relationship to System Modes

The PDI Monitor operates in two distinct modes (Mission Mode and Maintenance Mode), which likely affect lighting behavior:

1. **Mission Mode**: Full lighting functionality with operational sequences
2. **Maintenance Mode**: Possibly limited lighting functionality or special maintenance patterns

## 9. File-by-File Breakdown

### 9.1 ver_spdif_stg_ua_lights.xml

- **Purpose**: Defines basic configuration for UA (Unmanned Aircraft) lights
- **Key Components**: Single parameter (var0=1200)
- **Integration Point**: Loaded during PDI Monitor initialization
- **Control Mechanism**: Simple timing-based control

### 9.2 ver_spdif_amz_lights.xml

- **Purpose**: Defines complex configuration for AMZ (Amazon) lights
- **Key Components**:
  - Register configuration (42 register entries)
  - Light states (13 states for left and right sides)
  - Sequences (11 sequences with 10 steps each)
- **Integration Point**: Loaded during PDI Monitor initialization
- **Control Mechanism**: Sophisticated state and sequence-based control

## 10. Summary of Lighting System Capabilities

### 10.1 UA Lights System

- **Complexity**: Low (single parameter)
- **Configurability**: Limited
- **Purpose**: Basic aircraft lighting
- **Control Mechanism**: Simple timing control

### 10.2 AMZ Lights System

- **Complexity**: High (registers, states, sequences)
- **Configurability**: Extensive
- **Purpose**: Advanced status indication and signaling
- **Control Mechanism**: Sophisticated pattern and sequence control
- **Features**:
  - Independent left/right control
  - Complex blinking/pulsing patterns
  - Multiple operational sequences
  - Intensity control
  - State-based pattern definition

## 11. Conclusion

The PDI Monitor incorporates two lighting systems with significantly different complexity levels. The UA lights system provides basic lighting functionality with minimal configuration, while the AMZ lights system implements a sophisticated control architecture with registers, states, and sequences.

The AMZ lights system is particularly notable for its complex pattern capabilities, allowing for a wide range of visual indications through different combinations of phases, widths, and sequences. This suggests that visual indication is an important aspect of the system's operation, potentially for status communication, safety signaling, or operational mode indication.

The lighting systems are fully integrated into the PDI Monitor architecture, with configuration loaded during system initialization and likely controlled based on the system's operational state and monitoring functions. The symmetrical but independent control of left and right sides provides flexibility while maintaining visual balance.

The register-based approach of the AMZ lights system suggests a dedicated lighting controller with sophisticated capabilities, while the extensive use of sequences and states indicates a design focused on clear visual communication of system status through distinct lighting patterns.