# Generated from:

- pa_blocks/code/include/Navigation.h (1024 tokens)
- pa_blocks/code/include/Blk_pa_nav.h (725 tokens)
- pa_blocks/code/include/Blk_pa_nav_base.h (1050 tokens)
- pa_blocks/code/include/Blk_pa_nav_fw.h (26 tokens)
- pa_blocks/code/include/Nav_builder.h (845 tokens)
- pa_blocks/code/include/Nav_params.h (4742 tokens)
- pa_blocks/code/include/Nav_sched.h (101 tokens)
- pa_blocks/code/include/Nav_status_enum.h (58 tokens)
- pa_blocks/code/include/Nav_type.h (50 tokens)
- pa_blocks/code/include/Nav_max_value_set.h (130 tokens)
- pa_blocks/code/include/Nav_introspect_compact.h (380 tokens)
- pa_blocks/code/include/Nav_replay_log.h (202 tokens)
- pa_blocks/code/include/State_estimate.h (639 tokens)
- pa_blocks/code/include/State_estimate_compact.h (670 tokens)
- pa_blocks/code/include/State_estimate_field_status.h (104 tokens)
- pa_blocks/code/include/State_estimate_logic.h (1464 tokens)
- pa_blocks/code/include/State_estimate_sim.h (81 tokens)
- pa_blocks/code/include/State_estimate_status_logic.h (836 tokens)
- pa_blocks/code/include/State_fw.h (22 tokens)
- pa_blocks/code/include/State.h (582 tokens)
- pa_blocks/code/include/State_history.h (1168 tokens)
- pa_blocks/code/include/State_history_fw.h (28 tokens)
- pa_blocks/code/include/State_transition_matrix.h (1031 tokens)
- pa_blocks/code/include/Estimator.h (1694 tokens)
- pa_blocks/code/source/Navigation.cpp (1610 tokens)
- pa_blocks/code/source/Blk_pa_nav.cpp (1813 tokens)
- pa_blocks/code/source/Blk_pa_nav_base.cpp (2005 tokens)
- pa_blocks/code/source/Nav_builder.cpp (1198 tokens)
- pa_blocks/code/source/Nav_params.cpp (5974 tokens)
- pa_blocks/code/source/Nav_introspect_compact.cpp (773 tokens)
- pa_blocks/code/source/State_estimate.cpp (2004 tokens)
- pa_blocks/code/source/State_estimate_compact.cpp (1399 tokens)
- pa_blocks/code/source/State_estimate_logic.cpp (6206 tokens)
- pa_blocks/code/source/State_estimate_sim.cpp (638 tokens)
- pa_blocks/code/source/State_estimate_status_logic.cpp (1701 tokens)
- pa_blocks/code/source/State.cpp (1430 tokens)
- pa_blocks/code/source/State_history.cpp (1587 tokens)
- pa_blocks/code/source/State_transition_matrix.cpp (1593 tokens)
- pa_blocks/code/source/Estimator.cpp (5964 tokens)

## With context from:

- PackageSummaries/Embention/Amazon-PrimeAir/items/ASTRO/items/sw/sw_Astro/code/03_Coordinate_Systems.md (6564 tokens)

---

# Comprehensive Summary of the Drone's Navigation System

This document provides a detailed analysis of the drone's navigation system, focusing on state estimation based on sensor inputs, the Extended Kalman Filter (EKF) implementation, and related mechanisms.

## 1. Navigation System Architecture

The navigation system is responsible for estimating the vehicle's state based on various sensor inputs. It consists of several key components:

### 1.1 Core Components

- **Navigation**: The main class that orchestrates the navigation process
- **Initializer**: Handles system initialization
- **Estimator**: Implements the Extended Kalman Filter (EKF) for state estimation
- **State_estimate_logic**: Transforms the internal state to the output state estimate
- **Input_measurements**: Processes sensor measurements and updates the state

```cpp
class Navigation {
public:
    Navigation(const Measurements& meas0, 
               Nav_type::Type nav_type0,
               Nav_max_value_set& max_value_set0,
               const Site_config& site_config,
               const bool& is_dgnss_available0);
    
    void step();
    void vms_reset();
    
    // Output structure containing state estimates
    struct Output {
        const State_estimate* state_estimate;
        const State& state;
        const On_ground::Introspect_onground& introspect_onground_estimator;
        const Introspect_initializer& introspect_initializer;
        const Maverick::Rvector::K d_cov;
        Real max_pseudojerk_m_per_s3;
    };
    
private:
    Nav_max_value_set& max_value_set;
    bool initialization_pulse;
    State state;
    Controller_introspect controller_introspect;
    Initializer initializer;
    Estimator estimator;
    Output out;
    
    Measurements::Imu imu_meas;
    Nav_type::Type nav_type;
    Base::Int_decimator covprop_dec;
    Nav_sched::Sched sched;
    
    const volatile Uint16& imu_error;
    volatile bool& imu_diag_failed;
};
```

### 1.2 Navigation Types

The system supports two navigation types:
- **Recovery**: Primary navigation system with higher update rates
- **Monitor**: Secondary navigation system with lower update rates

```cpp
struct Nav_type {
    enum Type {
        recovery,
        monitor
    };
};
```

### 1.3 Navigation Scheduling

The navigation system uses a scheduler to manage different processing phases:

```cpp
struct Nav_sched {
    enum Sched {
        first_covprop  = 0,  // Run first covprop step
        second_covprop = 1,  // Run second covprop step
        input_meas     = 2,  // Run input meas
        idle           = 3   // Don't run input meas or covprop
    };
};
```

## 2. State Representation

### 2.1 Core State Structure

The `State` structure represents the internal state of the navigation system:

```cpp
struct State {
    Base::Ttime time_s;                  // Current time
    Base::Rv4 q_ned_from_ekf;            // Quaternion rotation from EKF frame to NED
    Base::Rv3 t_ned_ned2ekf_m;           // Position of EKF origin in NED frame
    Base::Rv3 v_ned_ned2ekf_m_per_s;     // Velocity of EKF origin in NED frame
    Base::Rv3 f_ekf_ned2ekf_m_per_s2;    // Acceleration in EKF frame
    Base::Rv3 w_ekf_ned2ekf_rad_per_s;   // Angular velocity in EKF frame
    Base::Rv3 dvel_cov_m_per_s;          // Velocity covariance
    Base::Rv3 dtheta_cov_rad;            // Attitude covariance
    Base::Rv3 bias_a;                    // Accelerometer bias
    Base::Rv3 bias_w;                    // Gyroscope bias
    Real z_ned_ned2gnd_m;                // Height above ground
    Real air_speed_TAS_m_per_s;          // True airspeed
    Real air_density_kg_per_m3;          // Air density
    Real dt_cov_s;                       // Time step for covariance propagation
    Tllh_cs_64 lla0_rrm;                 // Reference position in LLA coordinates
    Aiding_sensors_info sensor_status;   // Status of aiding sensors
    Measurements::Time_sync_offset timesync_info; // Time synchronization info
    Nav_status nav_status;               // Navigation status flags
    Uint32 lidar_consistency_count;      // Counter for lidar consistency checks
    
    // Calibrated dynamic pressure values (only used on Monitor)
    Measurements::Dyn_pressure::Calibrated dyn_pres_calib_left;
    Measurements::Dyn_pressure::Calibrated dyn_pres_calib_right;
    
    void apply_delta_state(Delta_state& delta_state);
};
```

### 2.2 Navigation Status

The navigation status tracks the health and validity of various state components:

```cpp
struct Nav_status {
    bool initialized;           // Navigation system is initialized
    bool agl_valid;             // Above-ground-level estimate is valid
    bool imu_saturated;         // IMU is currently saturated
    bool in_imu_saturation_mode; // System is in IMU saturation mode
    bool need_reset_gnss_posvel; // GNSS position/velocity needs reset
    bool horiz_channel_valid;   // Horizontal channel is valid
    bool vert_channel_valid;    // Vertical channel is valid
    bool timesync_offset_valid; // Time synchronization is valid
    bool need_reset_agl;        // AGL estimate needs reset
};
```

### 2.3 State Estimate

The `State_estimate` structure represents the output state provided to other systems:

```cpp
struct State_estimate : public Base::Iserializable_u8 {
    Base::Ttime time_s;                  // Current time
    Base::Ttime dt_cov_s;                // Time step for covariance
    Maverick::Rquat q_ned_from_vf;       // Quaternion rotation from VF to NED
    Maverick::Rvector3 t_ned_ned2vf_m;   // Position of VF origin in NED
    Maverick::Rvector3 v_ned_ned2vf_m_per_s; // Velocity of VF origin in NED
    Maverick::Rvector3 f_vf_ned2vf_m_per_s2; // Acceleration in VF frame
    Maverick::Rvector3 w_vf_ned2vf_rad_per_s; // Angular velocity in VF frame
    Airdata airdata;                     // Air data estimates
    Maverick::Rvector3 dtheta_cov_rad;   // Attitude covariance
    Maverick::Rvector3 dvel_cov_m_per_s; // Velocity covariance
    Maverick::Rvector3 bias_a;           // Accelerometer bias
    Maverick::Rvector3 bias_w;           // Gyroscope bias
    const Base::Tnarray<Real, Ku16::u3>& rph_rad; // Roll, pitch, heading
    Base::Rv3 v_ned_ned2wind_m_per_s;    // Wind velocity in NED
    Tllh_cs_64 lla_rrm;                  // Position in LLA coordinates
    Real z_ned_ned2gnd_m;                // Height above ground
    Real alt_agl_m;                      // Altitude above ground level
    Aiding_sensors_info sensor_status;   // Status of aiding sensors
    const State_estimate_status_logic::Status& status; // Status flags
    const bool& on_ground;               // On-ground flag
    const bool& is_imu_saturated;        // IMU saturation flag
    const bool& is_dgnss_available;      // DGNSS availability flag
    Time_in_tai time_in_tai;             // Time in TAI format
    Max_value& abs_max_accel_norm_m_per_s2; // Maximum acceleration
};
```

### 2.4 State Estimate Field Status

The system uses a status enumeration to indicate the validity of different state fields:

```cpp
struct State_estimate_field_status {
    enum Type {
        INVALID                             = 0U,
        DEGRADED                            = 1U,
        VALID                               = 2U,
        INVALID_ABSOLUTE_AND_VALID_RELATIVE = 3U
    };
};
```

## 3. Extended Kalman Filter Implementation

### 3.1 Estimator Class

The `Estimator` class implements the Extended Kalman Filter for state estimation:

```cpp
class Estimator {
public:
    Estimator(const bool& do_init0,
              const Measurements& meas0,
              const Controller_introspect& controller_introspect0,
              State& state0,
              Nav_type::Type nav_type0,
              Nav_max_value_set& max_value_set0,
              const bool& is_dgnss_available0);
    
    void step(const Measurements::Imu& imu_meas, Nav_sched::Sched sched);
    void vms_reset();
    
private:
    // Inputs
    const bool& do_init;
    const Measurements& meas;
    const Controller_introspect& controller_introspect;
    State& state;
    
    // Internal state
    Covariance_ud ud;                                // Covariance UD decomposition
    Delta_state delta_state;                         // Delta state
    State_history state_history;                     // State history
    Base::Int_decimator state_estimate_dec;          // Decimator for state estimate
    State_estimate_logic state_estimate;             // State estimate manager
    Input_measurements input_measurements;           // Input measurements manager
    Quiescence_detector quiescence;                  // Quiescence detector
    Maverick::Rvector3 w_ned_inertial2ned_rad_per_s; // Earth rotation rate
    
    // IMU filtering
    Base::Array<Moving_average> imu_average_value_filter_acc;
    Base::Array<Moving_average> imu_average_value_filter_gyro;
    
    // Covariance propagation
    Propagate_covariance propagate_covariance;
    
    // IMU saturation handling
    Time_cache tcache_imu;
    Uint16 count_sat_imu;
    
    // Processing methods
    void pre_process_imu(Measurements::Imu& imu);
    void mechanize_imu(const Measurements::Imu& imu_pre);
    void always_update();
    void get_earth_rotation(const Real lat, Maverick::Irvector3& w_inertial) const;
    void imu_average_value_filter();
    void capture_heading();
};
```

### 3.2 State History for Latent Measurements

The `State_history` class maintains a history of states to handle latent measurements:

```cpp
class State_history {
public:
    explicit State_history(Nav_type::Type nav_type);
    
    Base::Optional<Uint16> history_lookup(const Base::Ttime& latent_time_s);
    void apply_latent_deltas(const Uint16 starting_index, const Maverick::Rvector& latent_delta);
    void write_to_state_history(const State& state, const Delta_state& delta_state);
    void reset();
    
    inline const State& get_historical_state() const { return historical_state; }
    
private:
    const Uint16 length_history;
    Base::Array<State> state_nominal_history;   // State history
    Base::Array<Delta_state> delta_history;     // Delta history
    Uint16 index_cursor;                        // Index for next element
    bool is_filled;                             // Buffer is filled
    
    State historical_state;                     // Last computed historical state
    
    Base::Optional<Uint16> get_nearest_index(const Base::Ttime& latent_time_s) const;
};
```

### 3.3 Covariance Propagation

The system uses UD factorization for covariance propagation, which is numerically stable:

```cpp
class Propagate_covariance {
public:
    Propagate_covariance(State& state0, Covariance_ud& ud0);
    
    void init();
    void step(Nav_sched::Sched sched);
    
private:
    State& state;
    Covariance_ud& ud;
    State_transition_matrix stm;
    
    void propagate_covariance();
};
```

The `State_transition_matrix` class computes the state transition matrix F and the product F·U:

```cpp
class State_transition_matrix {
public:
    State_transition_matrix(const Real& dt_cov_s0,
                           const Base::Rv3& w_ekf_ned2ekf_cov0,
                           const Base::Rv3& f_ekf_ned2ekf_cov0,
                           const Base::Rv4& q_ned_from_ekf0,
                           const Maverick::Rmatrix& u_k_10,
                           Maverick::Rmatrix& yt0);
    
    void step();
    
private:
    // F matrix subblocks
    Maverick::Rmatrix3 f00;  // Attitude update
    Maverick::Rmatrix3 f04;  // Gyro bias effect on attitude
    Maverick::Rmatrix3 f12;  // Position update from velocity
    Maverick::Rmatrix3 f20;  // Attitude effect on velocity
    Maverick::Rmatrix3 f23;  // Accel bias effect on velocity
    Maverick::Rmatrix3 f33;  // Accel bias dynamics
    Maverick::Rmatrix3 f44;  // Gyro bias dynamics
    
    void y_transpose();  // Compute (F·U)ᵀ
};
```

## 4. Sensor Integration

### 4.1 Input Measurements

The `Input_measurements` class processes sensor measurements and updates the state:

```cpp
class Input_measurements {
public:
    Input_measurements(const Measurements& meas0,
                      State& state0,
                      Covariance_ud& ud0,
                      Delta_state& delta_state0,
                      const bool& on_ground0,
                      State_history& state_history0,
                      Nav_type::Type nav_type0);
    
    bool step(Nav_sched::Sched sched);
    
private:
    // Process specific measurements
    void process_gnss_pos();
    void process_gnss_vel();
    void process_static_pressure();
    void process_dyn_pressure();
    void process_lidar();
    void process_heading();
    
    // Chi-square test for measurement validation
    bool chi2_test(const Real& chi2, const Real& threshold, Real& chi2_failure_count);
};
```

### 4.2 Sensor Status Tracking

The `Aiding_sensors_info` structure tracks the status of each sensor:

```cpp
struct Aiding_sensors_info {
    struct Sensor_info {
        bool healthy;
        Base::Ttime time_meas_s;
        Base::Ttime time_received_s;
        Base::Ttime time_healthy_s;
        Real chi2_failure_count;
    };
    
    Sensor_info gnss_pos;
    Sensor_info gnss_vel;
    Sensor_info static_pressure;
    Sensor_info dyn_pressure;
    Sensor_info lidar;
};
```

### 4.3 Measurement Processing

For each sensor type, the system:
1. Checks if new measurements are available
2. Validates measurements using chi-square tests
3. Computes measurement residuals
4. Updates the state using the Kalman filter equations
5. Updates sensor status information

Example for GNSS position processing:

```cpp
void Input_measurements::process_gnss_pos() {
    // Check if new GNSS position is available
    if (meas.gnss_b.gnss_time.time_s > state.sensor_status.gnss_pos.time_received_s) {
        // Update received time
        state.sensor_status.gnss_pos.time_received_s = meas.gnss_b.gnss_time.time_s;
        
        // Check if GNSS fix is valid
        if (meas.gnss_b.fix >= 3) {
            // Update measurement time
            state.sensor_status.gnss_pos.time_meas_s = meas.gnss_b.gnss_time.time_s;
            
            // Find historical state at measurement time
            Base::Optional<Uint16> idx = state_history.history_lookup(meas.gnss_b.gnss_time.time_s);
            
            if (idx.present) {
                // Compute measurement residual
                Maverick::Rvector3 residual;
                compute_gnss_pos_residual(state_history.get_historical_state(), meas.gnss_b, residual);
                
                // Compute measurement covariance
                Maverick::Rmatrix3 R;
                compute_gnss_pos_covariance(meas.gnss_b, R);
                
                // Compute Kalman gain and update state
                Maverick::Rvector delta_x;
                Real chi2 = update_state_with_gnss_pos(residual, R, delta_x);
                
                // Validate measurement with chi-square test
                bool valid = chi2_test(chi2, Nav_params::chi2_3dof_p001, 
                                      state.sensor_status.gnss_pos.chi2_failure_count);
                
                if (valid) {
                    // Apply latent delta to state history
                    state_history.apply_latent_deltas(idx.value, delta_x);
                    state.sensor_status.gnss_pos.healthy = true;
                    state.sensor_status.gnss_pos.time_healthy_s = meas.gnss_b.gnss_time.time_s;
                }
            }
        }
    }
}
```

## 5. State Estimation Logic

### 5.1 State Estimate Logic

The `State_estimate_logic` class transforms the internal EKF state to the output state estimate:

```cpp
class State_estimate_logic {
public:
    State_estimate_logic(const State& state0,
                        const Controller_introspect& controller_introspect0,
                        const Measurements& meas0,
                        Nav_type::Type nav_type0,
                        Nav_max_value_set& max_value_set0,
                        const bool& is_dgnss_available0);
    
    void step();
    void vms_reset();
    void init_state_estimate();
    
private:
    const State& state;
    State_estimate_status_logic state_estimate_status_logic;
    Rph_from_q rph_from_q;
    On_ground_inputs on_ground_inputs;
    On_ground on_ground;
    Base::Ttime prev_time_s;
    Maverick::Rvector3 prev_v_ned_ned2wind_m_per_s;
    Real prev_tas_blended_m_per_s;
    const Controller_introspect& controller_introspect;
    Output out;
    
    void blend_air_speed();
    void estimate_wind();
    Real ias_from_tas(Real density_kg_per_m2, Real tas_m_per_s);
};
```

### 5.2 Status Logic

The `State_estimate_status_logic` class determines the validity status of different state components:

```cpp
class State_estimate_status_logic {
public:
    struct Status {
        State_estimate_field_status::Type agl;
        State_estimate_field_status::Type airdata;
        State_estimate_field_status::Type posvel_horiz;
        State_estimate_field_status::Type posvel_vert;
        const bool& initialized;
    };
    
    State_estimate_status_logic(const Base::Ttime& time_s0,
                               const Aiding_sensors_info& sensor_status0,
                               const State::Nav_status& nav_status0);
    
    void step();
    
private:
    const Base::Ttime& time_s;
    const Aiding_sensors_info& sensor_status;
    const State::Nav_status& nav_status;
    Output out;
};
```

### 5.3 On-Ground Detection

The system includes logic to detect when the vehicle is on the ground:

```cpp
class On_ground {
public:
    struct Introspect_onground {
        struct A2g {
            Real pseudojerk_m_per_s3;
        };
        
        A2g a2g;
        bool on_ground;
        bool cmd_vel;
        bool pseudojerk;
        bool roll_pitch;
        bool vel_high;
        bool vel_medium;
        bool low_agl;
        bool imu_saturated;
    };
    
    On_ground(const On_ground_inputs& on_ground_inputs0,
             Nav_type::Type nav_type0,
             Nav_max_value_set& max_value_set0);
    
    void step();
    
    inline const Output& get_out() const { return out; }
    
private:
    const On_ground_inputs& on_ground_inputs;
    Output out;
    
    void compute_pseudojerk();
    void compute_on_ground();
};
```

## 6. Initialization Process

### 6.1 Initializer Class

The `Initializer` class handles the initialization of the navigation system:

```cpp
class Initializer {
public:
    enum Init_flags {
        bias,
        gnss,
        heading,
        lidar,
        init_done_sz
    };
    
    Initializer(const Measurements& meas0,
               State& state0,
               const Controller_introspect& controller_introspect0,
               Nav_type::Type nav_type0,
               Nav_max_value_set& max_value_set0,
               const Site_config& site_config0,
               const bool& is_dgnss_available0);
    
    void step(const Measurements::Imu& imu_meas);
    void vms_reset();
    
private:
    const Measurements& meas;
    State& state;
    const Controller_introspect& controller_introspect;
    Base::Bitmask<Uint16> init_flags;
    
    void init_bias();
    void init_gnss();
    void init_heading();
    void init_lidar();
    void check_init_done();
};
```

### 6.2 Initialization Sequence

The initialization process follows these steps:

1. **Bias Initialization**: Calibrates IMU biases during a quiescent period
2. **GNSS Initialization**: Sets initial position and velocity from GNSS
3. **Heading Initialization**: Sets initial heading from uplink or site configuration
4. **Lidar Initialization**: Initializes height above ground from lidar measurements
5. **Completion Check**: Verifies all initialization steps are complete

Once initialization is complete, the system transitions to normal operation.

## 7. Navigation System Operation

### 7.1 Main Navigation Loop

The main navigation loop in `Navigation::step()` processes IMU measurements and updates the state:

```cpp
void Navigation::step() {
    bool just_one = false;   // Flag to exit after one measurement for recovery nav
    out.max_pseudojerk_m_per_s3 = -Const::MAX;

    if(covprop_dec.step()) {
        sched = Nav_sched::first_covprop;
    }

    // Check for IMU diagnostic errors
    imu_diag_failed |= Base::Imu_output_data::sensor_failure(imu_error);

    // Process IMU measurements
    while(!just_one && Measurements::get_imu_meas(imu_meas)) {
        if (state.nav_status.initialized) {
            // Run estimator
            estimator.step(imu_meas, sched);
            initialization_pulse = false;
            out.state_estimate = &estimator.get_out().state_estimate;
            
            // Update scheduler state
            switch (sched) {
                case Nav_sched::first_covprop:
                    sched = Nav_sched::second_covprop;
                    break;
                case Nav_sched::second_covprop:
                    sched = (nav_type == Nav_type::recovery) ? 
                            Nav_sched::input_meas : Nav_sched::idle;
                    break;
                default:
                    break;
            }
        } else {
            // Run initializer
            initializer.step(imu_meas);
        }
        
        just_one = (nav_type == Nav_type::recovery);
        
        // Track maximum pseudojerk
        Real pseudojerk_abs = Rmath::fabsr(out.introspect_onground_estimator.a2g.pseudojerk_m_per_s3);
        out.max_pseudojerk_m_per_s3 = (out.max_pseudojerk_m_per_s3 < pseudojerk_abs) ? 
                                      pseudojerk_abs : out.max_pseudojerk_m_per_s3;
    }

    if(nav_type == Nav_type::monitor) {
        sched = Nav_sched::input_meas;
    }
}
```

### 7.2 IMU Processing

The IMU processing in `Estimator::mechanize_imu()` integrates IMU measurements to update position, velocity, and attitude:

```cpp
void Estimator::mechanize_imu(const Measurements::Imu& imu_pre) {
    // Compute time step
    const Base::Ttime dt_hr = imu_pre.time_s - state.time_s;
    const Real dt = dt_hr.get_seconds();

    // Update state with IMU measurements
    state.time_s = imu_pre.time_s;
    state.f_ekf_ned2ekf_m_per_s2 = imu_pre.f;
    state.w_ekf_ned2ekf_rad_per_s = imu_pre.w;
    
    // Update covariance time and velocity
    state.dt_cov_s += dt;
    Maverick::Irvector3(state.dvel_cov_m_per_s).lincmb_add(dt, imu_pre.f);

    // Compute velocity update
    Maverick::Irquat q_ned_from_ekf(state.q_ned_from_ekf);
    Maverick::Rvector3 dv;
    dv.copy(imu_pre.f);
    q_ned_from_ekf.b2n(dv, dv);  // Rotate to NED frame
    
    // Add gravity
    Maverick::Rvector3 grav;
    grav.copy(Environ_params::Earth::gravity_ned_ecef2ned_m_per_s2.to_mblock());
    dv.vecadd(grav);
    dv.scale(dt);  // dv = (a + g) * dt

    // Update position
    Maverick::Irvector3 t_ned_ned2ekf_m(state.t_ned_ned2ekf_m);
    Maverick::Irvector3 v_ned_ned2ekf_m_per_s(state.v_ned_ned2ekf_m_per_s);
    t_ned_ned2ekf_m.lincmb_add(dt, v_ned_ned2ekf_m_per_s);
    t_ned_ned2ekf_m.lincmb_add(Const::ONEHALF * dt, dv);

    // Update velocity
    v_ned_ned2ekf_m_per_s.vecadd(dv);

    // Update attitude
    Maverick::Rvector3 rho_ekf_prev2cur;
    rho_ekf_prev2cur.copy(imu_pre.w);
    rho_ekf_prev2cur.scale(dt);
    Maverick::Irvector3(state.dtheta_cov_rad).vecadd(rho_ekf_prev2cur);
    q_ned_from_ekf.b2n(rho_ekf_prev2cur, rho_ekf_prev2cur);

    Maverick::Rquat q_curr_from_prev;
    q_curr_from_prev.qrotfromaxis(rho_ekf_prev2cur);
    
    q_ned_from_ekf.quatthis(q_curr_from_prev);
    q_ned_from_ekf.norm2alize();
    q_ned_from_ekf.rectify();
}
```

### 7.3 Covariance Propagation

The covariance propagation is split into two steps to reduce computational load:

```cpp
void Propagate_covariance::step(Nav_sched::Sched sched) {
    switch (sched) {
        case Nav_sched::first_covprop:
        case Nav_sched::second_covprop:
            propagate_covariance();
            break;
        default:
            break;
    }
}

void Propagate_covariance::propagate_covariance() {
    // Compute state transition matrix
    stm.step();
    
    // Compute process noise
    Maverick::Rvector q;
    compute_process_noise(q);
    
    // Update UD factorization
    ud.time_update(q);
    
    // Reset accumulated covariance terms
    state.dt_cov_s = 0.0F;
    state.dvel_cov_m_per_s.zeros();
    state.dtheta_cov_rad.zeros();
}
```

## 8. Status Fields and System Interaction

### 8.1 Status Field Determination

The `State_estimate_status_logic` class determines the validity of different state fields:

```cpp
void State_estimate_status_logic::step() {
    // Compute sensor data age
    const Base::Ttime gnss_pos_age = time_s - sensor_status.gnss_pos.time_healthy_s;
    const Base::Ttime gnss_vel_age = time_s - sensor_status.gnss_vel.time_healthy_s;
    const Base::Ttime baro_age = time_s - sensor_status.static_pressure.time_healthy_s;

    // Check if GNSS is degraded
    const Base::Ttime gnss_outage_duration_before_degraded_s(
            Knobs::get_instance().nav_params_gnss_outage_duration_before_degraded_s);
    const bool gnss_not_degraded = !(gnss_pos_age > gnss_outage_duration_before_degraded_s)
                       && !(gnss_vel_age > gnss_outage_duration_before_degraded_s);
    
    // Check if barometer is out
    const bool baro_out = baro_age > Knobs::get_instance().nav_params_baro_outage_duration_before_out_s;

    // Determine horizontal channel status
    if (nav_status.horiz_channel_valid) {
        if (gnss_not_degraded) {
            out.status.posvel_horiz = State_estimate_field_status::VALID;
        } else {
            out.status.posvel_horiz = State_estimate_field_status::DEGRADED;
        }
    } else {
        out.status.posvel_horiz = State_estimate_field_status::INVALID;
    }

    // Determine vertical channel status
    if(nav_status.vert_channel_valid) {
        if(gnss_not_degraded || sensor_status.static_pressure.healthy) {
            out.status.posvel_vert = State_estimate_field_status::VALID;
        } else {
            out.status.posvel_vert = State_estimate_field_status::DEGRADED;
        }

        if (baro_out) {
            if (out.status.posvel_horiz == State_estimate_field_status::DEGRADED) {
                out.status.posvel_vert = State_estimate_field_status::DEGRADED;
            } else if (out.status.posvel_horiz == State_estimate_field_status::INVALID) {
                out.status.posvel_vert = State_estimate_field_status::INVALID;
            }
        }
    } else {
        out.status.posvel_vert = State_estimate_field_status::INVALID;
    }

    // Determine AGL status
    if (nav_status.agl_valid && !nav_status.need_reset_agl) {
        if (sensor_status.lidar.healthy) {
            out.status.agl = State_estimate_field_status::VALID;
        } else {
            out.status.agl = State_estimate_field_status::DEGRADED;
        }
    } else {
        out.status.agl = State_estimate_field_status::INVALID;
    }

    // Airdata is always valid
    out.status.airdata = State_estimate_field_status::VALID;
}
```

### 8.2 IMU Saturation Handling

The system detects and handles IMU saturation:

```cpp
void Estimator::pre_process_imu(Measurements::Imu& imu) {
    // Check for IMU saturation
    const Base::Ttime saturation_enter_window_s(
            Knobs::get_instance().nav_params_imu_saturation_enter_window_s);
    const bool reset = !(tcache_imu.is_recent(imu.time_s, imu.railed, saturation_enter_window_s));
    
    if(reset) {
        count_sat_imu = 0U;
    } else if(imu.railed) {
        count_sat_imu++;
    }
    
    const bool exceeds_entry_count = 
            (count_sat_imu >= Knobs::get_instance().nav_params_imu_saturation_enter_count);

    const Base::Ttime saturation_exit_window_s(
            Knobs::get_instance().nav_params_imu_saturation_exit_window_s);
    const bool clear_during_exit_w = 
            !(tcache_imu.is_recent(imu.time_s, imu.railed, saturation_exit_window_s));

    // Update saturation flags
    state.nav_status.imu_saturated = imu.railed;
    state.nav_status.in_imu_saturation_mode = 
            (!state.nav_status.in_imu_saturation_mode && exceeds_entry_count) ||
            (state.nav_status.in_imu_saturation_mode && !clear_during_exit_w);
    
    // Set reset flags when in saturation mode
    state.nav_status.need_reset_gnss_posvel |= state.nav_status.in_imu_saturation_mode;
    state.nav_status.need_reset_agl |= state.nav_status.in_imu_saturation_mode;
    
    // Pre-process IMU measurements
    // ...
}
```

### 8.3 Navigation Channel Validity

The system determines the validity of navigation channels based on sensor health:

```cpp
void Estimator::always_update() {
    // Estimate air density
    // ...
    
    // Filter IMU values
    imu_average_value_filter();
    
    // Update navigation status fields
    const Base::Ttime gnss_duration_out(
            Knobs::get_instance().nav_params_gnss_outage_duration_before_invalid_s);
    
    bool gnss_out = ((state.time_s - state.sensor_status.gnss_pos.time_healthy_s) > gnss_duration_out) ||
                    ((state.time_s - state.sensor_status.gnss_vel.time_healthy_s) > gnss_duration_out);
    
    // Latch GNSS outage if it persists
    const Base::Ttime gnss_duration_latch_out(
            Knobs::get_instance().nav_params_gnss_outage_duration_before_latch_invalid_s);
    gnss_out |= latch_gnss_out.step(
            ((state.time_s - state.sensor_status.gnss_pos.time_healthy_s) > gnss_duration_latch_out) ||
            ((state.time_s - state.sensor_status.gnss_vel.time_healthy_s) > gnss_duration_latch_out));
    
    const bool lidar_stale = ((state.time_s - state.sensor_status.lidar.time_healthy_s) >
                             Knobs::get_instance().nav_params_lidar_duration_stale_s);
    const bool baro_out = ((state.time_s - state.sensor_status.static_pressure.time_healthy_s) >
                          Knobs::get_instance().nav_params_baro_duration_stale_s);
    
    const bool imu_not_saturated = !state.nav_status.in_imu_saturation_mode;
    
    // Set channel validity flags
    state.nav_status.horiz_channel_valid = (imu_not_saturated && !gnss_out);
    state.nav_status.vert_channel_valid = (imu_not_saturated && (!gnss_out || !baro_out));
    
    bool prev_agl_valid = state.nav_status.agl_valid;
    state.nav_status.agl_valid = (!lidar_stale && state.nav_status.vert_channel_valid && imu_not_saturated);
    
    // Set reset flag if AGL becomes valid after being invalid
    state.nav_status.need_reset_agl |= (!prev_agl_valid && state.nav_status.agl_valid);
}
```

## 9. System Integration

### 9.1 Navigation Builder

The `Nav_builder` class constructs and manages the navigation system:

```cpp
class Nav_builder : public Base::Ideserializable {
public:
    Nav_builder(Base::Ipkt_sender& ixpw0,
               Midlevel::Irxfw::Parser& irxfw_parser0,
               Cyphal::Cy_tdsync_can_sender<Pa_blocks::State_estimate_compact::payload_sz>::Xct& state_estimate_compact0,
               Cyphal::Cy_tdsync_can_sender<Pa_blocks::Nav_introspect_compact::payload_sz>::Xct& nav_introspect_compact0,
               Cyphal::Cy_tdsync_can_sender<Pa_blocks::Covariance_ud::D_serializer::payload_sz>::Xct& d_vector0,
               Cyphal::Cy_tdsync_can_sender<Pa_blocks::State_estimate::payload_sz>::Xct& state_estimate0,
               Out_nav_pa_base::Params nav_params0,
               const Site_config& site_config0);
    
    virtual void cset(Base::Lossy_error& str);
    void step();
    void build();
    
private:
    Base::Ipkt_sender& ixpw;
    Midlevel::Irxfw::Parser& irxfw_parser;
    Cyphal::Cy_tdsync_can_sender<Pa_blocks::State_estimate_compact::payload_sz>::Xct& state_estimate_compact;
    Cyphal::Cy_tdsync_can_sender<Pa_blocks::Nav_introspect_compact::payload_sz>::Xct& nav_introspect_compact;
    Cyphal::Cy_tdsync_can_sender<Pa_blocks::State_estimate::payload_sz>::Xct& state_estimate;
    Cyphal::Cy_tdsync_can_sender<Pa_blocks::Covariance_ud::D_serializer::payload_sz>::Xct& d_vector;
    const volatile bool& nav_enabled;
    Blk_pa_nav* pa_nav;
    Out_pa_nav_rec* out_mgr_nav;
    bool build_ok;
    Pa_profiling full_nav_prof;
    Dsp28335_ent::GPIO hgpio_switch_fb;
    Bsp::Hbvar hctr_switchover_signaled_to_recovery;
    Out_nav_pa_base::Params nav_params;
    const Site_config& site_config;
};
```

### 9.2 Navigation Block

The `Blk_pa_nav` class wraps the navigation system and handles sensor inputs:

```cpp
class Blk_pa_nav : public Blk_pa_nav_base {
public:
    explicit Blk_pa_nav(Base::Allocator& alloc, const Site_config& site_config);
    void run();
    
    inline const Measurements& get_meas() { return meas; }
    inline Cyphal::CyphalStanag_rx_hnd& get_msg_mon_data() { return in_msg_mon_data; }
    
private:
    Measurements meas;
    const volatile Base::Meas& sens_meas;
    Measurements::Imu imu_meas;
    
    // Sensor data readers
    Base::Dsync::Reader stp_rd;
    Base::Dsync::Reader qinf_rd;
    Base::Dsync::Reader gnss_pos_rd;
    Base::Dsync::Reader gnss_vel_rd;
    Base::Dsync::Reader gnss_time_rd;
    Base::Dsync::Reader lidar_dis_rd;
    Base::Dsync::Reader lidar_con_rd;
    Base::Tnarray<Base::Dsync::Reader, Pa_blocks::Motor_performance::motor_size> motor_performance_rd;
    
    const volatile Uint16& svid;
    const volatile bool& static_valid;
    bool is_dgnss_available;
    
    Knob_initializer knob_initializer;
    Cyphal_cset_wrapper<Vms_monitored_data> in_msg_mon_data;
    Vms_monitored_data mon_data;
    
    Base::Dsync::Reader state_estimate_rd;
    Command_fifo<Controllers_state_estimate, Ku16::u1> state_estimate;
};
```

### 9.3 State Estimate Compact

The `State_estimate_compact` class provides a compact representation of the state estimate for communication:

```cpp
struct State_estimate_compact {
    Real64 latitude_rad;
    Real64 longitude_rad;
    Real altitude_hae_wgs84_m;
    Real altitude_agl_m;
    Base::Rv3 v_ned_ned2vf_m_per_s;
    Base::Rv4 q_ned_from_vf;
    Real dynamic_pressure_Pa;
    Real air_density_kg_per_m3;
    Real abs_max_accel_norm_m_per_s2;
    State_estimate_field_status::Type status_posvel_horiz;
    State_estimate_field_status::Type status_posvel_vert;
    State_estimate_field_status::Type status_agl;
    bool is_left_and_right_probe_healthy;
    bool is_initialized_roll_pitch_heading;
    bool is_onground;
    bool is_imu_saturated;
    bool is_dgnss_available;
    
    void compact_state_estimate(const State_estimate& state_estimate);
    void convert_to_full_state_estimate(Controllers_state_estimate& state_estimate) const;
};
```

## 10. Key Parameters and Constants

The navigation system uses various parameters defined in `Nav_params`:

```cpp
struct Nav_params {
    struct Baro {
        static const Real rate_hz;                  // 10.0F
        static const Real min_valid_pressure_Pa;    // 53000.0F
        static const Real max_valid_pressure_Pa;    // 111000.0F
        static const Real timeout_check_s;          // 1.0F
    };
    
    static const Real chi2_1dof_p001;               // 10.83F
    static const Real chi2_1dof_p01;                // 6.64F
    static const Real chi2_3dof_p001;               // 16.27F
    
    struct Gnss {
        static const Real duration_out_s;           // 1.0F
        static const Real duration_stale_s;         // 1.0F
        static const Real rate_hz;                  // 4.0F
        static const Real timeout_check_s;          // 1.0F
    };
    
    struct Imu {
        struct Accel {
            static const Real max_G;                // 8.0F
            static const Real sigma_bias_m_per_s2;  // 0.1F
            static const Real sigma_noise_m_per_s2; // 0.2F
            static const Real tau_bias_s;           // 5000.0F
            static const bool use_bias;             // false
        };
        
        struct Gyro {
            static const Real max_rad_per_s;        // 8.73F
            static const Real sigma_bias_rad_per_s; // 0.001F
            static const Real sigma_noise_rad_per_s;// 0.012F
            static const Real tau_bias_s;           // 600.0F
            static const bool use_bias;             // true
        };
        
        static const Real rate_hz;                  // 500.0F
        static const Real saturation_s;             // 0.5F
    };
    
    struct Lidar {
        static const Real alpha;                    // 0.9048F
        static const Real cutoff_hz;                // 1.0F
        static const Real duration_stale_s;         // 1.0F
        static const Real rate_hz;                  // 10.0F
        static const Real threshold_dist_max_m;     // 50.0F
        static const Real threshold_strength_percent;// 70.0F
        static const Real valid_angle_rad;          // 0.6458F
        static const Real agl_consistency_max_dt_s; // 0.5F
        static const Real agl_consistency_max_disagreement_m; // 1.0F
        static const Uint16 consistency_checks_count_threshold; // 10U
    };
    
    static const Uint16 trigger_cov_prop_rec0;      // 50U
    static const Uint16 trigger_cov_prop_mon;       // 5U
    static const Uint16 trigger_cov_prop_split;     // 2U
    static const Uint16 trigger_state_estimate_rec0;// 5U
    static const Uint16 trigger_state_estimate_mon; // 5U
};
```

## 11. Summary of Navigation System Features

### 11.1 State Estimation

- Uses Extended Kalman Filter (EKF) for state estimation
- Maintains 15-state vector: position, velocity, attitude, accelerometer bias, gyroscope bias
- Employs UD factorization for numerically stable covariance propagation
- Processes measurements from multiple sensors: IMU, GNSS, barometer, dynamic pressure, lidar
- Handles latent measurements through state history mechanism

### 11.2 Sensor Integration

- IMU: Primary sensor for state propagation (500 Hz)
- GNSS: Position and velocity updates (4 Hz)
- Barometer: Altitude updates (10 Hz)
- Dynamic Pressure: Airspeed updates
- Lidar: Height above ground updates (10 Hz)
- Validates measurements using chi-square tests

### 11.3 Robustness Features

- Detects and handles IMU saturation
- Tracks sensor health and validity
- Provides status flags for different state components
- Supports graceful degradation when sensors fail
- Implements wind estimation for improved airspeed calculation

### 11.4 Dual Navigation Systems

- Recovery navigation: Primary system with higher update rates
- Monitor navigation: Secondary system with lower update rates
- Both systems share the same architecture but use different parameters

### 11.5 On-Ground Detection

- Uses multiple criteria to detect on-ground state:
  - Pseudojerk (third derivative of position)
  - Roll and pitch angles
  - Velocity magnitude
  - Height above ground
  - Command velocity

### 11.6 System Integration

- Provides state estimates to other systems via compact messages
- Supports VMS (Vehicle Management System) reset
- Interfaces with mission data and site configuration
- Monitors system health and reports diagnostics

## Referenced Context Files

The coordinate systems document provided valuable context for understanding the reference frames used in the navigation system, including:

- WGS84 (latitude, longitude, height) global reference frame
- ECEF (Earth-Centered, Earth-Fixed) Cartesian system
- NED (North-East-Down) local tangent plane
- Vehicle body frames (BUL, VTOL, VF)
- Transformations between these frames

This information helped clarify how the navigation system represents and transforms positions, velocities, and attitudes between different coordinate systems.