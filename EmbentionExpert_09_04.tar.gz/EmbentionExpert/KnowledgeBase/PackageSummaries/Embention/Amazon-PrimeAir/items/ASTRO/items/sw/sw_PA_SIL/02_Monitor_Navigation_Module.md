# Generated from:

- code/PA_SIL_monitor_nav/include/Fullsim_mon_nav_builder.h (831 tokens)
- code/PA_SIL_monitor_nav/include/Emb_monitor_nav_wrapper.h (877 tokens)
- code/PA_SIL_monitor_nav/source/Emb_monitor_nav_wrapper.cpp (6165 tokens)
- code/PA_SIL_monitor_nav/source/Fullsim_mon_nav_builder.cpp (1017 tokens)

---

# Monitor Navigation Module Analysis

## 1. System Architecture Overview

The monitor navigation module is a critical component of the SIL (Software-In-the-Loop) framework, responsible for processing sensor inputs and generating navigation outputs. The system follows a builder pattern architecture with a wrapper implementation for the FirmwareSimulation interface.

### Core Components

1. **Emb_monitor_nav_wrapper**: Implements the FirmwareSimulation interface to integrate with the broader simulation framework
2. **Fullsim_mon_nav_builder**: Builder class that constructs and manages the navigation components
3. **Mon_nav_input_manager**: Manages sensor inputs for the navigation system
4. **Blk_pa_mon_nav**: Core navigation computation module
5. **Out_nav_pa_base**: Handles output management for navigation data

### Integration Points

The monitor navigation module integrates with the broader SIL framework through:
- The FirmwareSimulation interface implementation
- Cyphal message passing for communication
- Shared memory for data exchange between components
- Configuration data loaded from PDI (Parameter Data Items) files

## 2. Fullsim_mon_nav_builder Implementation

The `Fullsim_mon_nav_builder` class is responsible for constructing and managing the navigation components.

### Constructor and Initialization

```cpp
Fullsim_mon_nav_builder::Fullsim_mon_nav_builder(
    Cyphal::Cy_tdsync_can_sender<State_estimate_compact::payload_sz>::Xct& state_estimate_compact0,
    Cyphal::Cy_tdsync_can_sender<Nav_introspect_compact::payload_sz>::Xct& nav_introspect_compact0,
    Cyphal::Cy_tdsync_can_sender<State_estimate::payload_sz>::Xct& state_estimate0,
    Base::Ipkt_sender& sender0,
    Out_nav_pa_base::Params& params0,
    const Site_config& site_config0)
```

The constructor initializes the builder with references to:
- Message senders for different types of navigation data
- Packet sender for cross-core communication
- Output parameters
- Site configuration

### Build Process

The `build()` method creates the navigation components:

1. Configures navigation parameters (either from PDI or default values)
2. Allocates memory for `Blk_pa_mon_nav` using the external allocator
3. Creates an output manager (`Out_nav_pa_base`) for handling navigation outputs
4. Sets the `build_ok` flag based on allocation success

### Configuration

The `cset()` method loads configuration parameters from a serialized data stream:

```cpp
void Fullsim_mon_nav_builder::cset(Base::Lossy_error& str)
{
    Vsdk_recovery_params::get_instance().cset(str);
    cset_called = true;
    build();
}
```

### Execution

The `step()` method executes the navigation processing:

```cpp
bool Fullsim_mon_nav_builder::step()
{
    if(build_ok)
    {
        pa_mon_nav->run();
        out_mgr_nav->step();
    }
    return build_ok;
}
```

## 3. Emb_monitor_nav_wrapper Implementation

The `Emb_monitor_nav_wrapper` class implements the FirmwareSimulation interface to integrate the monitor navigation module with the simulation framework.

### Interface Implementation

The wrapper implements the following FirmwareSimulation interface methods:
- `Init`: Initializes the firmware with configuration data
- `ExecuteAndScheduleNextExecutionInNs`: Executes the navigation processing and schedules the next execution
- `GetErrorString`: Returns error information
- `Reset`: Resets the firmware state
- `PutMessage`: Processes incoming messages
- `GetMessage`: Retrieves outgoing messages

### Data Structure

The wrapper uses a private `Data` structure to encapsulate its state:

```cpp
struct Emb_monitor_nav_wrapper::Data
{
    Cyphal::Cy_msg_id_gen gen;
    Pkt_sender_null sender;
    Cyphal::Cy_tdsync_can_sender<...>::Xct navigation_msg_sync;
    Cyphal::Cy_tdsync_can_sender<...>::Xct nav_state_estimate_cpct_sync;
    Cyphal::Cy_tdsync_can_sender<...>::Xct nav_intro_cpct_sync;
    Base::Dsync::Reader state_estimate_cpct_msg_rd;
    Base::Dsync::Reader nav_intro_cpct_rd;
    Base::Dsync::Reader navigation_msg_rd;
    Pa_blocks::Site_config site_cfg;
    Fullsim_builder_helper<Pa_blocks::Fullsim_mon_nav_builder> monnav_builder;
    Base::Int_decimator nav_dec;
    bool has_max_pseudojerk_been_sent;
};
```

### Initialization

The `Init` method loads configuration data from PDI files:

```cpp
bool Emb_monitor_nav_wrapper::Init(const FirmwareInitData& init_data)
{
    // Load variable initialization data (6.bin)
    const std::vector<uint8_t>& pdi_varini = init_data.configuration_data[std::to_string(static_cast<Uint16>(Base::Cfg::cfg_vmgr))];
    if(pdi_varini.size() > 0U) {
        // Process variable initialization data
    }

    // Load site configuration data (495.bin)
    const std::vector<uint8_t>& pdi_site_cfg = init_data.configuration_data[std::to_string(static_cast<Uint16>(Base::Cfg::cfg_amz_site_cfg))];
    if(pdi_site_cfg.size() > 0U) {
        // Process site configuration data
    }

    // Load recovery parameters (488.bin)
    const std::vector<uint8_t>& pdi_rec = init_data.configuration_data[std::to_string(static_cast<Uint16>(Base::Cfg::cfg_amz_rec_param))];
    if(pdi_rec.size() > 0U) {
        // Process recovery parameters
    }

    return true;
}
```

### Execution

The `ExecuteAndScheduleNextExecutionInNs` method executes the navigation processing:

```cpp
bool Emb_monitor_nav_wrapper::ExecuteAndScheduleNextExecutionInNs(uint64_t& interval_ns)
{
    data.get()->monnav_builder.build_if_needed();
    Bsp::Htimehelper::set_time_us(Base::Ttime(static_cast<double>(simulation_time_ns) * 1.0E-9));
    
    if(data.get()->nav_dec.step())
    {
        data.get()->monnav_builder.step();
        data.get()->has_max_pseudojerk_been_sent = false;
    }
    
    // 2 ms of execution rate
    interval_ns = static_cast<uint64_t>(2.0F * Const::E1000 * Const::FROM_NANO);
    simulation_time_ns += interval_ns;

    return true;
}
```

### Message Processing

The `PutMessage` method processes incoming messages based on their type:

```cpp
bool Emb_monitor_nav_wrapper::PutMessage(const MessageData& msg)
{
    bool ret = msg.is_valid;
    if (ret)
    {
        Base::Lossy str(reinterpret_cast<uint16_t*>(const_cast<unsigned char*>(msg.serialized_payload.data())),
                        (msg.serialized_payload.size() + 1) / 2);

        switch (Base::Stanag_msg_type::Msg_type::stg_cyphal_msg + msg.port_id)
        {
            case Base::Stanag_msg_type::Msg_type::cyp_meas_accel_gyro_mon:
                // Process accelerometer/gyroscope measurements
                break;
            case Base::Stanag_msg_type::Msg_type::cyp_meas_gnss_primary:
                // Process primary GNSS measurements
                break;
            // Other message types...
        }
    }
    return ret;
}
```

The `GetMessage` method retrieves outgoing messages:

```cpp
bool Emb_monitor_nav_wrapper::GetMessage(MessageData& msg)
{
    bool ret = false;

    if(data.get()->monnav_builder.is_build_ok())
    {
        Pa_blocks::Navigation& monnav = data.get()->monnav_builder.unsafe_get_nav()->get_nav();
        
        // Check for different types of messages to send
        if (data.get()->sender.buffer.size() > 0) {
            // Send buffered message
        }
        else if (!data.get()->navigation_msg_rd.is_valid()) {
            // Send navigation message
        }
        else if(!data.get()->state_estimate_cpct_msg_rd.is_valid()) {
            // Send compact state estimate
        }
        // Other message types...
    }

    msg.is_valid = ret;
    return ret;
}
```

## 4. Sensor Input Processing

The monitor navigation module processes various sensor inputs:

### IMU (Inertial Measurement Unit)

```cpp
case Base::Stanag_msg_type::Msg_type::cyp_meas_accel_gyro_mon:
{
    Pa_blocks::Measurements::Meas_acc_gyr meas;
    meas.cset(str);
    ret = true;
    Base::Imu_output_data imu_data;
    imu_data.acc_m_per_s2 = meas.data.f;
    imu_data.gyr_rad_per_s = meas.data.w;
    imu_data.temperature_kelvin = 298.15F;
    imu_data.errors.value = meas.data.railed ? Base::Imu_output_data::rail_error_mask : 0;
    imu_data.timestamp_tics = Base::Ttime(static_cast<double>(simulation_time_ns) * 1.0E-9);
    Ver::Hmeas::get_meas().imu_adis165053.write(imu_data);
    Bsp::Hbvar(Base::Bvar::kbit_imu3_has_rail).set(meas.data.railed);
    Pa_blocks::Fifo_imu_SIL::write(meas.data);
    break;
}
```

### GNSS (Global Navigation Satellite System)

```cpp
case Base::Stanag_msg_type::Msg_type::cyp_meas_gnss_primary:
{
    if (Pa_blocks::Knobs::get_instance().nav_params_use_receiver_pvt)
    {
        Pa_blocks::Measurements::Gnss_meas gnss_meas;
        gnss_meas.cset(str);

        Pa_blocks::Mon_nav_input_manager& meas = data.get()->monnav_builder.get_meas();

        meas.gnss_b.gnss_time.time_s = Bsp::Htime::get_time();
        meas.gnss_b.gnss_time.tow_s = Base::Ttime(gnss_meas.time_of_week_s);
        meas.gnss_b.gnss_time.week = gnss_meas.week;
        meas.gnss_b.lla_rrm = Pa_blocks::Tllh_cs_64(Base::Tllh::build(
                                                    gnss_meas.longitude_rad,
                                                    gnss_meas.latitude_rad,
                                                    gnss_meas.altitude_hae_m));
        meas.gnss_b.fix = gnss_meas.fix;
        meas.gnss_b.v_ned_ned2ant_m_per_s.copy(gnss_meas.v_ned_ned2antenna_m_per_s);
        meas.gnss_b.s_acc_m_per_s = gnss_meas.speed_accuracy_m_per_s;
        meas.gnss_b.h_acc_m = gnss_meas.horizontal_accuracy_m;
        meas.gnss_b.v_acc_m = gnss_meas.vertical_accuracy_m;
        meas.gnss_b.n_sv = gnss_meas.n_SV;
    }
    ret = true;
    break;
}
```

### Other Sensors

The module also processes:
- RAIM (Receiver Autonomous Integrity Monitoring) GNSS measurements
- Time synchronization offsets
- Ground LIDAR measurements
- Dynamic pressure (left and right)
- Static pressure

## 5. Navigation Output Generation

The monitor navigation module generates several types of outputs:

### State Estimate

Full state estimate containing detailed navigation information:

```cpp
else if (!data.get()->navigation_msg_rd.is_valid())
{
    Cyphal::Cy_tdsync_can_sender<Pa_blocks::State_estimate::payload_sz>::T_nic_array buff;
    Cyphal::Cyphal_msg cyphal_msg(buff.to_mblock8());
    data.get()->navigation_msg_rd = data.get()->navigation_msg_sync.read(buff);
    msg.payload_size_bytes = static_cast<Uint32>(Pa_blocks::State_estimate::payload_sz);
    msg.serialized_payload.resize(msg.payload_size_bytes);
    for(Uint16 i = 0; i < msg.payload_size_bytes; ++i)
    {
        msg.serialized_payload[i] = buff.get(i + Cyphal::Cyphal_msg::hdr_sz);
    }
    msg.port_id = Base::Stanag_msg_type::cyp_mon_nav_state_estimate - Base::Stanag_msg_type::stg_cyphal_msg;
    ret = true;
}
```

### Compact State Estimate

Reduced-size state estimate for bandwidth-constrained communication:

```cpp
else if(!data.get()->state_estimate_cpct_msg_rd.is_valid())
{
    Cyphal::Cy_tdsync_can_sender<Pa_blocks::State_estimate_compact::payload_sz>::T_nic_array buff;
    Cyphal::Cyphal_msg cyphal_msg(buff.to_mblock8());
    data.get()->state_estimate_cpct_msg_rd = data.get()->nav_state_estimate_cpct_sync.read(buff);
    msg.payload_size_bytes = static_cast<Uint32>(Pa_blocks::State_estimate_compact::payload_sz);
    msg.serialized_payload.resize(msg.payload_size_bytes);
    for(Uint16 i = 0; i < msg.payload_size_bytes; ++i)
    {
        msg.serialized_payload[i] = buff.get(i + Cyphal::Cyphal_msg::hdr_sz);
    }
    msg.port_id = Base::Stanag_msg_type::cyp_mon_state_estimate_compact - Base::Stanag_msg_type::stg_cyphal_msg;
    ret = true;
}
```

### Navigation Introspection

Diagnostic information about the navigation system:

```cpp
else if(!data.get()->nav_intro_cpct_rd.is_valid())
{
    Cyphal::Cy_tdsync_can_sender<Pa_blocks::Nav_introspect_compact::payload_sz>::T_nic_array buff;
    Cyphal::Cyphal_msg cyphal_msg(buff.to_mblock8());
    data.get()->nav_intro_cpct_rd = data.get()->nav_intro_cpct_sync.read(buff);
    msg.payload_size_bytes = static_cast<Uint32>(Pa_blocks::Nav_introspect_compact::payload_sz);
    msg.serialized_payload.resize(msg.payload_size_bytes);
    for(Uint16 i = 0; i < msg.payload_size_bytes; ++i)
    {
        msg.serialized_payload[i] = buff.get(i + Cyphal::Cyphal_msg::hdr_sz);
    }
    msg.port_id = Base::Stanag_msg_type::cyp_mon_nav_instrospect_compact - Base::Stanag_msg_type::stg_cyphal_msg;
    ret = true;
}
```

### Calibrated Dynamic Pressure

Processed and calibrated dynamic pressure measurements:

```cpp
else if(monnav.get_left_dyn_pres_calib().is_new)
{
    msg.payload_size_bytes = Pa_blocks::Measurements::Dyn_pressure::Calibrated::payload_sz;
    msg.serialized_payload.resize(msg.payload_size_bytes);
    Base::Lossy str(reinterpret_cast<uint16_t*>(const_cast<unsigned char*>(msg.serialized_payload.data())),
                    (msg.serialized_payload.size() + 1) / 2);
    monnav.get_left_dyn_pres_calib().cget(str);
    msg.port_id = Base::Stanag_msg_type::cyp_meas_dyn_press_calib_left - Base::Stanag_msg_type::stg_cyphal_msg;
    monnav.get_left_dyn_pres_calib().is_new = false;
    ret = true;
}
```

### Maximum Pseudojerk

Motion characteristic used for control and analysis:

```cpp
else if(!data.get()->has_max_pseudojerk_been_sent)
{
    msg.payload_size_bytes = Ku16::u4; // Just one float
    msg.serialized_payload.resize(msg.payload_size_bytes);
    Base::Lossy str(reinterpret_cast<uint16_t*>(const_cast<unsigned char*>(msg.serialized_payload.data())),
                    (msg.serialized_payload.size() + 1) / 2);
    str.put_float(monnav.get_out().max_pseudojerk_m_per_s3);
    msg.port_id = Base::Stanag_msg_type::cyp_pseudojerk - Base::Stanag_msg_type::stg_cyphal_msg;
    data.get()->has_max_pseudojerk_been_sent = true;
    ret = true;
}
```

## 6. Builder Pattern Implementation

The monitor navigation module uses the builder pattern to construct and manage its components:

### Builder Interface

The `Fullsim_mon_nav_builder` class provides methods for:
- Configuration (`cset`)
- Construction (`build`)
- Execution (`step`)
- Status checking (`is_build_ok`)
- Component access (`get_meas`, `unsafe_get_nav`)

### Component Construction

The `build` method constructs the navigation components:

```cpp
void Fullsim_mon_nav_builder::build()
{
    if(!build_ok)
    {
        // Configure navigation parameters
        if(!cset_called)
        {
            overwrite_knobs_monitor_nav();
        }

        Base::Allocator& alloc = Base::Memmgr::get_external_allocator();

        // Create navigation computation module
        pa_mon_nav = alloc.allocate_new<Blk_pa_mon_nav>(mon_nav_input, 
                                                        site_config, 
                                                        raim_dgnss_status.get_is_dgnss_available());

        if(alloc.get_alloc_ok())
        {
            // Create output manager
            out_mgr_nav = alloc.allocate_new<Out_nav_pa_base>(
                    pa_mon_nav->get_nav(),
                    state_estimate_compact,
                    nav_introspect_compact,
                    state_estimate,
                    ixpw,
                    mon_nav_input,
                    pa_mon_nav->get_max_value_set(),
                    params);
        }

        build_ok = alloc.get_alloc_ok();
    }
}
```

### Builder Helper

The `Fullsim_builder_helper` template class is used to manage the builder:

```cpp
Fullsim_builder_helper<Pa_blocks::Fullsim_mon_nav_builder> monnav_builder;
```

## 7. FirmwareSimulation Interface Wrapper

The `Emb_monitor_nav_wrapper` class implements the FirmwareSimulation interface to integrate with the simulation framework:

### Interface Methods

- `Init`: Loads configuration data and initializes the system
- `ExecuteAndScheduleNextExecutionInNs`: Executes the navigation processing and schedules the next execution
- `GetErrorString`: Returns error information
- `Reset`: Resets the system state
- `PutMessage`: Processes incoming messages
- `GetMessage`: Retrieves outgoing messages

### C Interface

The module provides a C interface for dynamic loading:

```cpp
extern "C"
{
    FirmwareSimulation* get_firmware_simulation_instance()
    {
        static FirmwareSimulation* ret = new Wrapper::Emb_monitor_nav_wrapper();
        return ret;
    }
}
```

## 8. Timing and Execution

The monitor navigation module operates at specific frequencies:

- IMU data processing: 500 Hz
- Navigation processing: 50 Hz
- Output generation:
  - State estimate: 100 Hz
  - Compact state estimate: 50 Hz
  - Navigation introspection: 10 Hz
  - Time synchronization: 1 Hz

The execution is controlled by a decimator:

```cpp
if(data.get()->nav_dec.step())
{
    data.get()->monnav_builder.step();
    data.get()->has_max_pseudojerk_been_sent = false;
}
```

The system schedules its next execution with a 2 ms interval:

```cpp
interval_ns = static_cast<uint64_t>(2.0F * Const::E1000 * Const::FROM_NANO);
```

## 9. Configuration Management

The monitor navigation module uses several configuration sources:

### PDI Files

- Variable initialization (6.bin)
- Site configuration (495.bin)
- Recovery parameters (488.bin)

### Default Configuration

If PDI files are not available, default values are used:

```cpp
static void overwrite_knobs_monitor_nav()
{
    // Temporary method to overwrite MonNav values while the FWSIM version of the Monitor wrapper is fixed
    Vsdk_recovery_params& param = Vsdk_recovery_params::get_instance();
    param.nav.installation.t_vf_vf2imu_m[0] = 0.3867F;
    param.nav.installation.t_vf_vf2imu_m[1] = -0.0595F;
    param.nav.installation.t_vf_vf2imu_m[2] = -0.0993F;
    // Additional configuration...
}
```

## 10. Memory Management

The monitor navigation module uses an external allocator for memory management:

```cpp
Base::Allocator& alloc = Base::Memmgr::get_external_allocator();

pa_mon_nav = alloc.allocate_new<Blk_pa_mon_nav>(mon_nav_input, 
                                                site_config, 
                                                raim_dgnss_status.get_is_dgnss_available());

if(alloc.get_alloc_ok())
{
    out_mgr_nav = alloc.allocate_new<Out_nav_pa_base>(/* parameters */);
}

build_ok = alloc.get_alloc_ok();
```

The system checks allocation success before proceeding with execution.

## Summary

The monitor navigation module is a sophisticated component of the SIL framework that processes sensor inputs to generate navigation outputs. It uses a builder pattern for component construction and a wrapper implementation for the FirmwareSimulation interface. The system processes various sensor inputs (IMU, GNSS, LIDAR, pressure) and generates multiple types of navigation outputs (state estimates, introspection data, calibrated measurements). The module operates at specific frequencies and uses configuration data from PDI files or default values.