# Generated from:

- test/version.py (466 tokens)
- test/bin_generator.py (1109 tokens)
- test/env_setup.py (2572 tokens)
- test/logger.py (388 tokens)
- test/bldr_test_plan.py (19961 tokens)
- test/emb_software_updater.py (6005 tokens)

## With context from:

- Amazon-PrimeAir/items/ASTRO/items/sw/sw_vbootloader_astro/code/03_Bootloader_Core.md (4045 tokens)

---

# Astro Bootloader Testing Framework: High-Fidelity Semantic Knowledge Graph

## 1. Version Management System

The testing framework includes a robust version management system implemented in `version.py` that handles semantic versioning for the bootloader and applications.

### Version Class

```python
class Version:
    def __init__(self, major: int, minor: int, revision: int):
        self.major = major
        self.minor = minor
        self.revision = revision
        self._original = f"{major}.{minor}.{revision}"
```

The `Version` class provides:

- **Direct Constructor**: Create versions by specifying major, minor, and revision components
- **String Parser**: Alternative constructor `from_string()` to parse version strings in "X.Y.Z" format
- **String Representation**: Both `__str__` and `__repr__` methods for different formatting needs
- **Comparison Operators**: Full set of comparison methods (`__eq__`, `__lt__`, `__le__`, `__gt__`, `__ge__`) for version comparison

Version objects are used throughout the testing framework to verify bootloader and application versions, ensuring compatibility and proper upgrade/downgrade paths.

## 2. Binary File Generation and Management

The `bin_generator.py` module handles the preparation of binary files needed for testing, including bootloader and application binaries.

### Configuration Structure

```python
CONFIG = {
    "bdlr_astro": [
        ("items/ASTRO/items/sw/sw_vbootloader_astro/code/sw_vbootloader_astro/code/project/vpgen_ccs/2838x/smart.bin", "smart0.bin"),
        ("items/ASTRO/items/sw/sw_vbootloader_astro/code/sw_vbootloader_astro_cm/code/project/vpgen_ccs_arm/2838x_arm/smart.bin", "smart2.bin"),
    ],
    "bdlr_ipc": [...],
    "signing": {...},
    "ev2_pdi": {...},
}
```

### Key Functions

- **`find_project_root()`**: Locates the project root directory
- **`ensure_dir()`**: Creates directories if they don't exist
- **`copy_file()`** and **`copy_directory()`**: Handle file and directory copying operations
- **`run_batch()`**: Executes batch files for signing operations
- **`main()`**: Orchestrates the binary generation process:
  1. Copies smart.bin files for different cores
  2. Runs signing batch processes
  3. Copies and renames signing outputs
  4. Copies EV2 PDI folders

The module ensures all necessary binary files are properly prepared, signed, and organized for testing.

## 3. Environment Setup

The `env_setup.py` module prepares the testing environment by processing firmware zip files and organizing them for testing.

### File Naming Convention

```
product-vX.Y.Z_YYYY-MM-DD_HH-MM-SS.zip
```

Where product can be:
- `fw_recovery1`, `fw_recovery0`, `fw_monitor`, `fw_ipc` (firmware products)
- `bl_astro`, `bl_ipc` (bootloader products)
- `pdi_recovery1`, `pdi_recovery0`, `pdi_monitor` (PDI products)

### Key Functions

- **`parse_filename()`**: Extracts product, version, and date from filenames
- **`process_zip_file()`**: Processes zip files based on product type:
  - For firmware products: Extracts inner zip files
  - For PDI products: Extracts content directly
- **`process_directory()`**: Processes the 'raw_files' directory structure
- **`validate_products()`**: Performs validation checks:
  1. Ensures products exist in both 'new' and 'old' directories
  2. Verifies firmware products have corresponding PDI products
  3. Checks that 'new' versions are newer than 'old' versions
- **`copy_tools()`**: Copies required JAR files to appropriate directories

The module ensures a consistent testing environment with proper version relationships between components.

## 4. Logging System

The `logger.py` module implements a custom logging system with color-coded output levels.

### Features

- **Custom TRACE Level**: Adds a TRACE level (5) below DEBUG for very detailed logging
- **Color-Coded Output**: Different colors for different log levels:
  - TRACE: White
  - DEBUG: Blue
  - INFO: Green
  - WARNING: Yellow
  - ERROR: Red
  - CRITICAL: Bold Red
- **Formatter**: Custom formatter that applies colors to log messages

This logging system provides clear visibility into test execution and helps identify issues quickly.

## 5. Embedded Software Updater Interface

The `emb_software_updater.py` module provides an interface to the embedded software updater tool used to communicate with the bootloader.

### Key Components

- **Status Enum**: Defines possible status codes returned by the updater
- **Command Classes**: Structured representation of commands and their responses:
  - `get_info`: Retrieve bootloader information
  - `restart`: Restart the target
  - `software_install`: Install software binary
  - `system_reset`: Change system modes
  - `system_status`: Get system status
  - `format_external_fs`: Format external filesystem
  - `query_external_fs_format`: Query filesystem format
  - `get_app_check_status`: Check application status
- **Options Classes**: Configuration options for commands:
  - `Compute`: Target compute (MONITOR, RECOVERY0, RECOVERY1, ESC0-5)
  - `Interface`: Network interface
  - `Transport`: Communication transport (CAN, UDP)
  - `Core`: Target core (C1, C2, CM)
  - `Mode`: System mode (BOOTLOADER, MAINT, MISSION)
- **EmbUpdater Class**: Main interface to the updater:
  - SSH connection management
  - Command execution
  - File transfer
  - Status tracking

This module abstracts the complexity of communicating with the bootloader, providing a clean interface for test cases.

## 6. Bootloader Test Plan

The `bldr_test_plan.py` module implements a comprehensive test plan for the bootloader, with 21 test cases covering various aspects of bootloader functionality.

### TestPlan Class

The `TestPlan` class manages test execution and provides utility methods for interacting with the bootloader:

```python
class TestPlan:
    def __init__(
        self,
        compute: emb_su.Options.Compute,
        expected_bldr_version: Version,
        expected_app_version: Version,
        expected_downgrade_app_version: Version,
    ):
        self.updater = emb_su.EmbUpdater()
        self.compute = compute
        self.expected_bldr_version = expected_bldr_version
        self.expected_app_version = expected_app_version
        self.expected_downgrade_app_version = expected_downgrade_app_version
```

### Test Case Decorator

```python
def test_case(num):
    """
    Decorator to set up and print a test number,
    then run the method and show success message.
    """
    def decorator(method):
        @wraps(method)
        def wrapper(self, *args, **kwargs):
            self.test_num = num
            self.print_test_number()
            result = method(self, *args, **kwargs)
            self.print_test_success()
            return result
        return wrapper
    return decorator
```

### Utility Methods

- **Binary Manipulation**:
  - `truncate_and_corrupt_file()`: Creates corrupted binaries for testing
  - `update_file_crc32()`: Updates CRC32 checksums in binary files
  - `modify_signature()`: Modifies signature bytes for testing
  - `modify_header()`: Modifies header bytes for testing
- **PDI Installation**: `install_pdi()` encodes and uploads PDI files
- **Version Reading**: `read_version_from_file()` extracts version from binary files
- **CAN Communication**: `capture_can_stab_a()` captures CAN frames
- **Mode Management**: `wait_for_mode_change()` waits for mode transitions
- **Command Wrappers**: Methods like `cmd_system_status()`, `cmd_get_info()`, etc.

### Test Cases

The test plan includes 21 test cases covering:

1. **Nominal Factory Load Bootloader**: Initial bootloader loading
2. **Nominal Factory Load Applications**: Application loading
3. **Nominal Upgrade**: Application upgrade process
4. **Nominal Downgrade**: Application downgrade process
5-7. **Error Core Stopped During Load**: Testing interrupted loads for each core
8-10. **Install Core Detect**: Testing core binary mismatch detection
11-13. **Boot Time Authentication**: Testing signature verification
14. **C2 Application Space Erased**: Recovery from erased application space
15. **Secure CAN Configuration, Power Cycle**: CAN security after power cycle
16. **Secure CAN Configuration, Jump to Bootloader**: CAN security after mode change
17. **ADS Serial Port Silence**: Verifying serial port behavior
18-20. **Bootloader Header Schema**: Testing header validation for each core
21. **App/Bootloader Transition Endurance**: Stress testing mode transitions

Each test case follows a structured approach with clear steps, verification points, and error handling.

## 7. Test Execution Flow

The main execution flow in `bldr_test_plan.py` creates a `TestPlan` instance and runs the test cases in sequence:

```python
def main():
    test_plan = TestPlan(
        emb_su.Options.Compute.RECOVERY0,
        expected_bldr_version=Version(7, 3, 129),
        expected_app_version=Version(7, 3, 139),
        expected_downgrade_app_version=Version(7, 3, 131),
    )
    try:
        test_plan.test1()
        test_plan.test2()
        test_plan.test4()  # Done before test 3 to first perform a downgrade
        test_plan.test3()
        # ... additional tests ...
    finally:
        test_plan.updater.close()
```

## 8. Binary File Manipulation for Testing

The framework includes several methods to create test cases with corrupted or modified binaries:

### Truncation and Corruption

```python
def truncate_and_corrupt_file(
    file_path: Union[str, Path],
    truncate_ratio: float,
    random_data_length_bytes: int,
) -> Path:
```

This function:
1. Truncates a file by removing a specified percentage from the end
2. Appends random bytes that are guaranteed to differ from the original
3. Returns the path to the corrupted file

### CRC32 Manipulation

```python
def update_file_crc32(file_path: str, crc_offset: int = 12) -> int:
```

This function:
1. Computes CRC32 of the file excluding the four bytes at crc_offset
2. Writes the CRC32 (little-endian) back at that offset
3. Returns the computed CRC32 value

### Signature and Header Modification

```python
def modify_signature(file_path: str) -> Path:
def modify_header(file_path: str) -> Path:
```

These functions:
1. Copy the original file to a new file with a descriptive name
2. Modify specific bytes at signature or header offsets
3. Update the CRC32 checksum
4. Return the path to the modified file

## 9. Cross-Component Relationships

The testing framework components interact in the following ways:

1. **Version Management** (`version.py`):
   - Used by `env_setup.py` to parse and compare versions from filenames
   - Used by `bldr_test_plan.py` to verify bootloader and application versions

2. **Binary Generation** (`bin_generator.py`):
   - Prepares binary files used by `bldr_test_plan.py` for testing
   - Organizes files in a structure expected by the test plan

3. **Environment Setup** (`env_setup.py`):
   - Processes firmware files used by `bldr_test_plan.py`
   - Validates version relationships between components

4. **Logging System** (`logger.py`):
   - Used by all other components for consistent logging
   - Provides visibility into test execution

5. **Embedded Software Updater** (`emb_software_updater.py`):
   - Used by `bldr_test_plan.py` to communicate with the bootloader
   - Abstracts the complexity of the communication protocol

6. **Test Plan** (`bldr_test_plan.py`):
   - Uses all other components to implement and execute test cases
   - Provides a structured approach to bootloader testing

## 10. Verification Methods

The testing framework employs several verification methods:

1. **Version Verification**: Checking that reported versions match expected versions
2. **Mode Verification**: Ensuring the system transitions to expected modes
3. **Application Status Verification**: Checking application status for each core
4. **CAN Communication Verification**: Capturing and analyzing CAN frames
5. **Binary Integrity Verification**: Testing bootloader response to corrupted binaries
6. **Security Verification**: Testing signature verification and secure boot
7. **Endurance Testing**: Stress testing mode transitions

These verification methods ensure the bootloader functions correctly under various conditions and can handle error cases appropriately.

## 11. Security Testing Features

The framework includes several features for testing bootloader security:

1. **Signature Verification**: Tests that the bootloader rejects binaries with invalid signatures
2. **Header Validation**: Tests that the bootloader validates header schema versions
3. **Core Binary Verification**: Tests that the bootloader rejects binaries for the wrong core
4. **Secure CAN Configuration**: Tests that CAN security features work correctly
5. **Binary Corruption Detection**: Tests that the bootloader detects corrupted binaries

These features ensure the bootloader maintains security even under adverse conditions.

## 12. Error Handling and Recovery

The test plan includes comprehensive error handling and recovery mechanisms:

1. **Test Failure Handling**: The `fail()` method logs errors and can continue or abort testing
2. **SSH Connection Management**: The `SSHConnection` class handles SSH connection errors
3. **Command Result Validation**: Each command result is validated for success
4. **Mode Transition Monitoring**: The `wait_for_mode_change()` method ensures successful transitions
5. **Recovery Procedures**: Tests include steps to recover from error conditions

These mechanisms ensure tests can run reliably and provide clear information about failures.

## Conclusion

The Astro bootloader testing framework is a comprehensive system for verifying bootloader functionality, security, and reliability. It provides:

1. **Structured Test Cases**: 21 test cases covering various aspects of bootloader functionality
2. **Binary Manipulation Tools**: Tools for creating test cases with corrupted or modified binaries
3. **Version Management**: Robust version comparison and verification
4. **Environment Setup**: Automated preparation of test environment
5. **Communication Interface**: Clean interface to the embedded software updater
6. **Logging System**: Clear visibility into test execution
7. **Error Handling**: Comprehensive error handling and recovery mechanisms

This framework ensures the bootloader meets its requirements for functionality, security, and reliability.