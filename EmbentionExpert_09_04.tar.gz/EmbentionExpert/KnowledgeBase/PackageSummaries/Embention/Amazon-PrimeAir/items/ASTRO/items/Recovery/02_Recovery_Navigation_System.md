# Generated from:

- items/sw_Recovery/code/main2/code/source/Blockfactory_par.cpp (2181 tokens)

---

# Recovery Navigation System Implementation Analysis

## 1. Blockfactory Overview and Architecture

The `Blockfactory` class serves as the central component factory for the recovery navigation system. It orchestrates the initialization, configuration, and execution of various navigation-related components. The class is implemented in the `Vblocks` namespace and is responsible for:

1. Creating and managing navigation components
2. Handling communication interfaces
3. Processing commands and telemetry
4. Managing site configuration
5. Coordinating maintenance actions

The implementation follows a composition pattern where the `Blockfactory` contains a private `Data` structure that holds all the component instances and their relationships.

## 2. Initialization Sequence and Component Setup

### 2.1 Blockfactory Construction

The `Blockfactory` constructor initializes the system with the following steps:

1. Allocates memory for the `Data` structure using the external memory manager
2. Establishes references to key components like `nav_pos`
3. Registers configuration handlers for recovery parameters
4. Sets up communication handlers for various message types
5. Configures default GNSS selection to use the real signal (HI source)
6. Registers maintenance action handlers

```cpp
Blockfactory::Blockfactory(Vpgnc::Vpu& uav0,
                          Media::Cfgmgr& cfg,
                          Base::Stepmgr& smgr,
                          Midlevel::Irxfw::Parser& irxfw_parser,
                          const Uint32 block_allocator_size_words16,
                          Base::Checklist& opchlist,
                          Vpgnc::Polymgr_impl& poly,
                          Vpgnc::Airframe_action_wp_publish& aac_publish0)
```

The constructor takes multiple system components as parameters, including:
- Vehicle Processing Unit (`uav0`)
- Configuration manager (`cfg`)
- Step manager (`smgr`)
- Parser for communication (`irxfw_parser`)
- Memory allocation size (`block_allocator_size_words16`)
- Operation checklist (`opchlist`)
- Polynomial manager (`poly`)
- Waypoint publisher (`aac_publish0`)

### 2.2 Data Structure Initialization

The `Data` structure constructor performs detailed initialization of all navigation components:

```cpp
Data(Vpgnc::Vpu& uav0, Midlevel::Irxfw::Parser& irxfw_parser0) :
    dummy(*Base::Memmgr::get_internal_allocator().allocate_new<Uint16>()), 
    dcomms_site_cfg(Ver::Hxcfg::get_xcfg().xctp.amz_radio_dyn_cfg),
    site_cfg(Ver::Hxcfg::get_xcfg().xctp.amz_rep_dev_pdi, uav0.cfg, &dcomms_site_cfg),
    nav(uav0.ixpw,
        irxfw_parser0,
        Ver::Hstate_estimate_compact::get_state_estimate_compact(),
        Ver::Hnav_introspect_compact::get_nav_introspect_compact(),
        Ver::Hd_vector::get_d_vector(),
        Ver::Hx_nav_msg::get_nav_msg(),
        get_out_mgr_params(),
        site_cfg),
    // ... other initializations
```

Key components initialized include:
- Site configuration (`site_cfg`)
- Navigation builder (`nav`)
- Position and rotation matrices (`nav_pos`, `lnb`)
- Command handlers for contingency and in-flight speed changes
- Maintenance action handlers

## 3. Navigation Builder Configuration

The `Nav_builder` is the core component responsible for navigation functionality. It's initialized with several parameters:

```cpp
nav(uav0.ixpw,
    irxfw_parser0,
    Ver::Hstate_estimate_compact::get_state_estimate_compact(),
    Ver::Hnav_introspect_compact::get_nav_introspect_compact(),
    Ver::Hd_vector::get_d_vector(),
    Ver::Hx_nav_msg::get_nav_msg(),
    get_out_mgr_params(),
    site_cfg)
```

The navigation builder receives:
1. Vehicle processing interface (`uav0.ixpw`)
2. Communication parser (`irxfw_parser0`)
3. State estimation components
4. Navigation introspection components
5. Vector data
6. Navigation message handlers
7. Output manager parameters
8. Site configuration

### 3.1 Output Manager Parameters

The output manager parameters are configured through the `get_out_mgr_params()` function:

```cpp
static Out_nav_pa_base::Params get_out_mgr_params()
{
    static const Uint16 se_freq  = Ku16::u100;
    static const Uint16 sec_freq = Ku16::u25;
    static const Uint16 nic_freq = Ku16::u10;
    static const Uint16 tsc_freq = Ku16::u1;

    Out_nav_pa_base::Params ret =
    {
        rec_gnc_freq,
        Ver::Stab_a::pa_id_recovery_nav,
        Base::Stanag_msg_type::cyp_recovery_state_estimate, (rec_gnc_freq / se_freq),
        Base::Stanag_msg_type::cyp_state_estimate_compact,  (rec_gnc_freq / sec_freq),
        Base::Stanag_msg_type::cyp_nav_instrospect_compact, (rec_gnc_freq / nic_freq),

        Base::kbit_pps_ok,
        Base::Stanag_msg_type::cyp_time_sync_off_rec,       (rec_gnc_freq / tsc_freq)
    };
    return ret;
}
```

This configures:
- Base frequency for recovery GNC operations (`rec_gnc_freq`)
- Recovery navigation identifier
- Message types and their respective frequencies:
  - Recovery state estimate: 1/100th of GNC frequency
  - Compact state estimate: 1/25th of GNC frequency
  - Navigation introspect: 1/10th of GNC frequency
  - Time synchronization: 1/1 of GNC frequency (same as GNC)
- PPS (Pulse Per Second) status bit

## 4. Message Handling and Communication

The Blockfactory sets up extensive message handling capabilities for diverse communications:

```cpp
irxfw_parser.add_rx_hdl(Base::Stanag_msg_type::cyp_pa_dcomms_tm, data.dcomms_tm);
irxfw_parser.add_rx_hdl(Base::Stanag_msg_type::cyp_pa_diverse_comms_command_response, data.cmd_response);
irxfw_parser.add_tx_hdl(Base::Stanag_msg_type::cyp_pa_diverse_comms_command_contingency, data.cmd_contingency);
irxfw_parser.add_tx_hdl(Base::Stanag_msg_type::cyp_pa_dcomms_isc, data.isc_cmd_wrapper_stg);
```

### 4.1 Received Messages (RX)

The system handles incoming messages of types:
- `cyp_pa_dcomms_tm`: Diverse communications telemetry
- `cyp_pa_diverse_comms_command_response`: Command responses
- `cyp_maintenance_action_req`: Maintenance action requests

### 4.2 Transmitted Messages (TX)

The system sends outgoing messages of types:
- `cyp_pa_diverse_comms_command_contingency`: Contingency commands
- `cyp_pa_dcomms_isc`: In-flight speed change commands
- `cyp_maintenance_action_res`: Maintenance action responses

## 5. In-Flight Speed Change Command Handling

The system includes specialized handling for in-flight speed change commands:

```cpp
static In_flight_speed_change_cmd::Params get_isc_params(const Cyphal_common_types::String_cy& flight_id)
{
    In_flight_speed_change_cmd::Params ret =
    {
         Bsp::Huvar(Pa_system_vars::request_id_rcv_low).get_kref(),
         Bsp::Huvar(Pa_system_vars::request_id_rcv_high).get_kref(),
         flight_id,
         Bsp::Huvar(Pa_system_vars::window_shift_earliest_relative_time_s).get_kref(),
         Bsp::Huvar(Pa_system_vars::window_shift_nominal_relative_time_s).get_kref(),
         Bsp::Huvar(Pa_system_vars::window_shift_latest_relative_time_s).get_kref(),
         Bsp::Huvar(Pa_system_vars::comply_by_mission_relative_time_s).get_kref(),
         Bsp::Huvar(Pa_system_vars::speed_change_mode).get_kref()
    };
    return ret;
}
```

This configures parameters for speed change commands including:
- Request ID ranges (low and high)
- Flight identifier
- Time windows for speed changes (earliest, nominal, latest)
- Compliance deadline
- Speed change mode

## 6. Maintenance Action Handling

The system registers handlers for maintenance actions:

```cpp
maint_action.reg(Cy_maint_action_consts::cmd_set_site_config, site_cfg.get_setter());
maint_action.reg(Cy_maint_action_consts::cmd_get_site_config, site_cfg.get_getter());
```

These registrations enable:
- Setting site configuration via maintenance commands
- Retrieving site configuration via maintenance queries

## 7. Execution Flow

The Blockfactory implements three key execution methods:

### 7.1 Post-PDI Load

```cpp
void Blockfactory::post_pdi_load()
{
    data.nav.build();
}
```

This method is called after the PDI (Platform Description Interface) is loaded and triggers the navigation builder to construct its internal components.

### 7.2 Pre-GNC Step

```cpp
void Blockfactory::step_pre_gnc()
{
    data.nav.step();
}
```

This method is called before the main GNC (Guidance, Navigation, and Control) step and executes the navigation step.

### 7.3 GNC Step

```cpp
void Blockfactory::step_gnc()
{
    // Intentionally empty
}
```

According to work item #28666, the GNC step is intentionally empty as the Veronte Block Builder doesn't perform any actions during this phase.

## 8. Key Parameters Affecting Navigation Behavior

Several parameters significantly influence the navigation system's behavior:

1. **Frequency Parameters**:
   - `rec_gnc_freq`: Base frequency for recovery GNC operations
   - Message output frequencies (`se_freq`, `sec_freq`, `nic_freq`, `tsc_freq`)

2. **Speed Change Parameters**:
   - Window shift times (earliest, nominal, latest)
   - Compliance deadline
   - Speed change mode

3. **GNSS Selection**:
   - `gnss_sel_src`: Set to true to force the use of real GNSS signal

4. **Site Configuration**:
   - Dynamic radio configuration
   - Device PDI configuration

## 9. Contingency Handling

The system includes dedicated contingency handling through:

```cpp
Command_contingency_wrapper_ser cmd_contingency;
```

This component is initialized with:
- Request ID ranges (low and high)
- Command type for contingency
- Flight identifier

The contingency wrapper is registered as a transmit handler for the `cyp_pa_diverse_comms_command_contingency` message type, allowing the system to send contingency commands when needed.

## 10. Component Relationships

The Blockfactory establishes relationships between multiple components:

1. **Navigation Builder** (`Nav_builder`) is the central component that:
   - Receives configuration from the configuration manager
   - Uses the site configuration
   - Processes state estimates and navigation introspection
   - Outputs navigation messages

2. **Site Configuration** (`Site_config`) manages:
   - Device PDI configuration
   - Dynamic radio configuration
   - Can be modified through maintenance actions

3. **Command Handlers** process:
   - Contingency commands
   - In-flight speed change commands
   - Maintenance action requests

4. **Communication System** handles:
   - Diverse communications telemetry
   - Command responses
   - Maintenance actions

## 11. Switchover Handling

The system tracks recovery switchover status:

```cpp
Bsp::Hbvar has_switchover_been_signalled_to_recovery;
```

This variable is initialized with `Pa_system_vars::ctr_switchover_signaled_to_recovery` and is used to publish the switchover status to the recovery system.

## Referenced Context Files

The implementation references numerous header files that provide context for the recovery navigation system:

1. `Blockfactory.h` - Main header defining the Blockfactory class interface
2. `Nav_builder.h` - Navigation builder component that constructs the navigation system
3. `Pa_system_vars.h` - System variables used for configuration and status tracking
4. `Hstate_estimate_compact.h` - Compact state estimation interface
5. `Hnav_introspect_compact.h` - Navigation introspection interface
6. `Site_config.h` - Site configuration management
7. `Command_contingency_wrapper.h` - Wrapper for contingency commands
8. `In_flight_speed_change_cmd.h` - In-flight speed change command handling
9. `Cy_maint_action.h` - Maintenance action handling

These files provide the interfaces and data structures that enable the recovery navigation system's functionality.