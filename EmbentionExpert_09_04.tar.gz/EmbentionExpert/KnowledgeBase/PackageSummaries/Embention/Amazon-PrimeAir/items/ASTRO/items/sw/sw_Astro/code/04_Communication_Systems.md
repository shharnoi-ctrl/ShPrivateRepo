# Generated from:

- pa_blocks/code/include/DComms_cfg.h (2071 tokens)
- pa_blocks/code/include/DComms_dev.h (577 tokens)
- pa_blocks/code/include/Diverse_comms_health.h (733 tokens)
- pa_blocks/code/include/Diverse_comms_telemetry.h (1241 tokens)
- pa_blocks/code/include/Cy_dcomms_site_config.h (455 tokens)
- pa_blocks/code/include/Cy_maint_dcomms.h (1321 tokens)
- pa_blocks/code/include/Cy_forwarder.h (396 tokens)
- pa_blocks/code/include/Cy_file_transfer.h (546 tokens)
- pa_blocks/code/include/Cy_tx_msg_wrap.h (tokens unknown)
- pa_blocks/code/include/Cy_msg_wrapper.h (191 tokens)
- pa_blocks/code/include/Cyphal_cset_command_fifo.h (319 tokens)
- pa_blocks/code/include/Cyphal_cset_wrapper.h (206 tokens)
- pa_blocks/code/include/Cyphal_types_amz.h (608 tokens)
- pa_blocks/code/source/DComms_cfg.cpp (3557 tokens)
- pa_blocks/code/source/DComms_dev.cpp (384 tokens)
- pa_blocks/code/source/Diverse_comms_health.cpp (668 tokens)
- pa_blocks/code/source/Diverse_comms_telemetry.cpp (1710 tokens)
- pa_blocks/code/source/Cy_dcomms_site_config.cpp (684 tokens)
- pa_blocks/code/source/Cy_maint_dcomms.cpp (1692 tokens)
- pa_blocks/code/source/Cy_forwarder.cpp (630 tokens)
- pa_blocks/code/source/Cy_file_transfer.cpp (780 tokens)
- pa_blocks/code/source/Cy_msg_wrapper.cpp (104 tokens)
- pa_blocks/code/source/Cyphal_types_amz.cpp (192 tokens)

---

# High-Fidelity Semantic Knowledge Graph: Drone Communication Systems

## 1. Functional Behavior and Logic

### Diverse Communications (DComms) System

The drone's communication system is built around a "Diverse Communications" (DComms) architecture that provides multiple communication channels and protocols for data exchange. The system includes:

#### DComms Configuration Management
- The system uses a structured configuration approach with `DComms_cfg` class that separates configuration into:
  - **Dynamic Configuration**: Frequency tables, register values, and call signs that can be updated during operation
  - **Static Configuration**: Fixed register values that remain constant
- Configuration is built and sent to the radio device in a specific sequence:
  1. Enter command mode with `+++` sequence
  2. Reset configuration with `AT&F65`
  3. Configure frequency table with password protection
  4. Configure registers with AT commands
  5. Exit command mode with `AT&WA`

#### DComms Device Handler
- `DComms_dev` class manages the radio device configuration through a port interface
- Uses asynchronous task management to configure the radio without blocking execution
- Implements a state machine that:
  1. Builds Rawpcfg using dynamic configuration
  2. Sends configuration to the device
  3. Waits for completion
  4. Builds and sends static configuration
  5. Returns to transparent serial mode for normal operation

#### Communication Health Monitoring
- `Diverse_comms_health` class monitors and reports the health of the communication system
- Tracks metrics including:
  - RSSI (signal strength) in dBm
  - Modem temperature in Celsius
  - Time since last message received (heartbeat)
  - Command received request IDs and timestamps
  - Connection status to Flight Monitor
  - FTDMA allocation status
  - Control status (BMOS in control)

#### Telemetry Data Exchange
- `Diverse_comms_telemetry` class handles telemetry data exchange including:
  - Flight identification
  - Recovery control status
  - Position data (latitude, longitude, altitude)
  - Wind velocity estimates
  - Air data (pressure, density)
  - Vehicle velocity
  - State estimation status
  - Mission status and progress
  - Battery state of charge

### Cyphal Communication Protocol

The system uses Cyphal as a primary communication protocol for structured data exchange:

#### Message Forwarding
- `Cy_forwarder` class forwards messages between Cyphal networks
- Handles message buffering and transmission
- Tracks dropped messages when transmission fails

#### File Transfer Protocol
- `Cy_file_transfer` class implements a file transfer protocol over Cyphal
- Supports writing file chunks with offset positioning
- Validates file paths and handles errors including:
  - File not found
  - I/O errors
  - Access denied
  - File too large
  - Out of space

#### Message Wrapping and Serialization
- `Cy_msg_wrapper` adds message IDs and checksums to outgoing messages
- Ensures message integrity and proper routing

#### Command FIFO Management
- `Cyphal_cset_command_fifo` template class manages command queues
- Deserializes incoming commands and places them in a FIFO queue for processing

## 2. Control Flow and State Transitions

### DComms Device Configuration State Machine

| State | Trigger | Actions | Next State | Location |
|-------|---------|---------|------------|----------|
| Initial | `start()` called | Build dynamic config, start async task | Waiting for dynamic config completion | DComms_dev.cpp |
| Waiting for dynamic config | `dtsk.is_task_finished()` returns true | Build static config, restart async task | Waiting for static config completion | DComms_dev.cpp |
| Waiting for static config | `dtsk.is_task_finished()` returns true | Set finished flag | Complete | DComms_dev.cpp |

### Maintenance Test State Machine

| State | Trigger | Actions | Next State | Location |
|-------|---------|---------|------------|----------|
| st_idle | Test initiated | Send `+++` command | st_wait | Cy_maint_dcomms.cpp |
| st_wait | Timeout expired | Flush buffer | st_req | Cy_maint_dcomms.cpp |
| st_req | Current command < command count | Send command (ATI7, ATI3, or ATI1) | st_read | Cy_maint_dcomms.cpp |
| st_read | "OK" response received | Process response, increment command | st_req or st_exit_cmd | Cy_maint_dcomms.cpp |
| st_exit_cmd | Exit command sent | Enable transmission, set success | st_success | Cy_maint_dcomms.cpp |

### File Transfer Protocol Flow

1. Receive file write request with path, offset, and data chunk
2. Validate file path against expected path
3. Check if write operation would exceed file size limit
4. Write data at specified offset
5. Send response with success or error code

## 3. Inputs and Stimuli

### DComms Configuration Inputs
- **Frequency Table Entries**: Channel number, frequency, bandwidth, and direction
  - Processed in `DComms_cfg::Freq_entry::build_rawpcfg`
  - Affects radio frequency configuration
  - Located in DComms_cfg.cpp

- **Register Values**: Register ID and value pairs for radio configuration
  - Processed in `DComms_cfg::Reg_cfg::build_rawpcfg`
  - Affects radio parameters like modulation, power, bandwidth
  - Located in DComms_cfg.cpp

- **Call Sign**: String identifier for the radio
  - Processed in `DComms_cfg::Reg_str_cfg::build_rawpcfg`
  - Sets the radio's call sign identifier
  - Located in DComms_cfg.cpp

### Site Configuration Inputs
- **Cyphal Site Configuration Messages**: Modulation link, output power, bandwidth
  - Received and processed in `Cy_dcomms_site_config::cset`
  - Updates dynamic configuration of the radio
  - Located in Cy_dcomms_site_config.cpp

### Maintenance Commands
- **AT Commands**: Serial commands for radio diagnostics
  - Processed in `Cy_maint_dcomms::processed_req`
  - Retrieves serial number, firmware version, part number
  - Located in Cy_maint_dcomms.cpp

### File Transfer Inputs
- **File Write Requests**: Path, offset, and data chunk
  - Processed in `Cy_file_transfer::on_rx_cy`
  - Writes data to specified file location
  - Located in Cy_file_transfer.cpp

### Telemetry Data Inputs
- **Cyphal Telemetry Messages**: Flight data, position, status
  - Processed in `Diverse_comms_telemetry::cset`
  - Updates system variables with received telemetry
  - Located in Diverse_comms_telemetry.cpp

## 4. Outputs and Effects

### DComms Configuration Outputs
- **AT Command Sequences**: Generated in `DComms_cfg::build_rawpcfg`
  - Sent to radio to configure parameters
  - Affects radio operation mode, frequency, power
  - Located in DComms_cfg.cpp

### Health Monitoring Outputs
- **Health Status Messages**: Generated in `Diverse_comms_health::cget`
  - Reports RSSI, temperature, connection status
  - Used by ground systems to monitor link quality
  - Located in Diverse_comms_health.cpp

### Maintenance Test Outputs
- **Radio Information**: Collected in `Cy_maint_dcomms::processed_req`
  - Provides serial number, firmware version, part number
  - Used for diagnostics and verification
  - Located in Cy_maint_dcomms.cpp

### File Transfer Outputs
- **Transfer Status Responses**: Generated in `Cy_file_transfer::on_tx_impl`
  - Reports success or error codes for file operations
  - Confirms successful data transfer
  - Located in Cy_file_transfer.cpp

### Telemetry System Variable Updates
- **System Variable Updates**: Performed in `Diverse_comms_telemetry::cset`
  - Updates system variables with received telemetry
  - Affects drone behavior based on received data
  - Located in Diverse_comms_telemetry.cpp

## 5. Parameters and Configuration

### Radio Configuration Parameters

#### Frequency Table Parameters
- **nchannel**: Channel number (0-63)
  - Defined in `DComms_cfg::Freq_entry`
  - Must be less than `freq_table_max_entries` (64)
  - Located in DComms_cfg.h

- **freq**: Frequency in Hz
  - Defined in `DComms_cfg::Freq_entry`
  - Valid range: 410,000,000 to 480,000,000 Hz
  - Located in DComms_cfg.h

- **bandwidth**: Bandwidth setting (0-2)
  - Defined in `DComms_cfg::Freq_entry`
  - Affects channel bandwidth
  - Located in DComms_cfg.h

- **ch_dir**: Channel direction (0-2)
  - Defined in `DComms_cfg::Freq_entry`
  - Controls transmission direction
  - Located in DComms_cfg.h

#### Register Configuration Parameters
- **reg_modulation_link** (103): Modulation link rate
  - Valid range: 0-8
  - Located in DComms_cfg.h

- **reg_local_address** (105): Local address
  - Valid range: 1-255
  - Located in DComms_cfg.h

- **reg_output_power** (108): Output power
  - Valid values: 20-30 or 33
  - Located in DComms_cfg.h

- **reg_occupied_bwidth** (125): Occupied bandwidth
  - Valid range: 0-2
  - Located in DComms_cfg.h

- **reg_call_sign** (228): Call sign
  - String up to 16 characters
  - Located in DComms_cfg.h

### File Transfer Parameters
- **max_chuck_sz**: Maximum chunk size (1000 bytes)
  - Defined in `Cy_file_transfer::File_write`
  - Limits size of individual file transfers
  - Located in Cy_file_transfer.h

- **max_file_path**: Maximum file path length (255 bytes)
  - Defined in `Cy_file_transfer::File_write`
  - Limits length of file paths
  - Located in Cy_file_transfer.h

### Message Forwarding Parameters
- **buffer size**: Size of message buffer
  - Passed to `Cy_forwarder` constructor
  - Limits maximum message size that can be forwarded
  - Located in Cy_forwarder.cpp

## 6. Error Handling and Contingency Logic

### DComms Configuration Validation
- **Frequency Validation**: In `DComms_cfg::Freq_entry::cset`
  - Validates frequency is within 410-480 MHz range
  - Validates bandwidth and direction are within range
  - Triggers `err_dcomms_freq_table` error if invalid
  - Located in DComms_cfg.cpp

- **Register Value Validation**: In `DComms_cfg::Reg_cfg::cset`
  - Validates register values are within allowed ranges
  - Triggers `err_dcomms_regs_range` error if invalid
  - Located in DComms_cfg.cpp

- **String Register Validation**: In `DComms_cfg::Reg_str_cfg::cset`
  - Validates string length is within limits
  - Triggers `err_dcomms_str_sz` error if too long
  - Located in DComms_cfg.cpp

- **Duplicate Register Check**: In `check_regs_cfgs`
  - Ensures no duplicate register configurations
  - Triggers `err_duplicated_regs` error if duplicates found
  - Located in DComms_cfg.cpp

### File Transfer Error Handling
- **Path Validation**: In `Cy_file_transfer::File_write::check_path`
  - Verifies file path matches expected path
  - Returns `Error::not_found` if path doesn't match
  - Located in Cy_file_transfer.cpp

- **Size Validation**: In `Cy_file_transfer::write`
  - Checks if write would exceed file size limit
  - Returns `Error::file_too_large` if too large
  - Located in Cy_file_transfer.cpp

- **Error Response**: In `Cy_file_transfer::Error::cget`
  - Sends appropriate error code in response
  - Error types include: not_found, io_error, access_denied, file_too_large
  - Located in Cy_file_transfer.cpp

### Maintenance Test Error Handling
- **Connection Status**: In `Cy_maint_dcomms::fill_res_params`
  - Checks if DComms is enabled and powered
  - Returns appropriate error code and message
  - Located in Cy_maint_dcomms.cpp

- **Command Response Timeout**: In `Cy_maint_dcomms::processed_req`
  - Uses timeout to wait for command mode entry
  - Flushes buffer if timeout expires
  - Located in Cy_maint_dcomms.cpp

### Message Forwarding Error Tracking
- **Drop Counter**: In `Cy_forwarder::on_rx`
  - Increments drop counter when message can't be sent
  - Tracks communication reliability
  - Located in Cy_forwarder.cpp

## 7. File-by-File Breakdown

### DComms_cfg.h
- Defines configuration structures for Diverse Communications
- Contains classes for frequency table entries, register configurations
- Provides methods to build and validate radio configurations
- Separates configuration into dynamic and static components

### DComms_cfg.cpp
- Implements configuration building methods
- Contains validation logic for configuration parameters
- Handles AT command generation for radio configuration
- Implements serialization and deserialization of configuration data

### DComms_dev.h
- Defines device handler class for Diverse Communications
- Declares asynchronous task interface for configuration
- Provides port access for communication with the radio

### DComms_dev.cpp
- Implements device configuration state machine
- Handles sequential configuration of dynamic and static parameters
- Manages asynchronous task completion

### Diverse_comms_health.h
- Defines health monitoring class for Diverse Communications
- Declares parameters for health status reporting
- Implements Cyphal serialization interface

### Diverse_comms_health.cpp
- Implements health status serialization
- Calculates time since last message received
- Formats health data for transmission

### Diverse_comms_telemetry.h
- Defines telemetry handling class
- Declares fields for various telemetry data types
- Implements Cyphal reception interface

### Diverse_comms_telemetry.cpp
- Implements telemetry data processing
- Updates system variables with received telemetry
- Handles various data types including position, velocity, mission status

### Cy_dcomms_site_config.h
- Defines site configuration class for Diverse Communications
- Declares Cyphal serialization and deserialization interfaces
- Links to dynamic configuration

### Cy_dcomms_site_config.cpp
- Implements site configuration processing
- Updates radio parameters based on received configuration
- Handles serialization for configuration reporting

### Cy_maint_dcomms.h
- Defines maintenance test class for Diverse Communications
- Declares state machine for radio testing
- Implements maintenance action interface

### Cy_maint_dcomms.cpp
- Implements radio test state machine
- Handles AT command sending and response processing
- Reports radio information for maintenance

### Cy_forwarder.h
- Defines message forwarding class
- Declares Cyphal reception interface
- Provides buffer management for message forwarding

### Cy_forwarder.cpp
- Implements message forwarding logic
- Handles message buffering and transmission
- Tracks dropped messages

### Cy_file_transfer.h
- Defines file transfer protocol class
- Declares file write request handling
- Implements Cyphal service interfaces

### Cy_file_transfer.cpp
- Implements file transfer protocol
- Validates file paths and sizes
- Handles data writing and error reporting

### Cy_msg_wrapper.h
- Defines message wrapping class
- Declares serialization interface
- Adds message IDs and checksums

### Cy_msg_wrapper.cpp
- Implements message wrapping
- Adds message ID and checksum to outgoing messages
- Ensures message integrity

### Cyphal_cset_command_fifo.h
- Defines template class for command FIFO management
- Implements Cyphal reception interface
- Handles command deserialization and queueing

### Cyphal_cset_wrapper.h
- Defines wrapper class for Cyphal deserialization
- Implements Cyphal reception interface
- Simplifies object deserialization

### Cyphal_types_amz.h
- Defines Amazon-specific Cyphal type handling
- Declares serialization and deserialization functions
- Handles array and float conversions

### Cyphal_types_amz.cpp
- Implements Amazon-specific Cyphal type handling
- Handles waypoint message serialization
- Converts between different data formats

## 8. Cross-Component Relationships

### Configuration and Device Management
- `DComms_cfg` provides configuration structures
- `DComms_dev` uses these configurations to configure the radio
- Configuration flows: Dynamic config → Static config → Normal operation

### Health Monitoring and Telemetry
- `Diverse_comms_health` monitors communication system health
- `Diverse_comms_telemetry` processes incoming telemetry data
- Both components use Cyphal for data exchange

### Site Configuration and Radio Parameters
- `Cy_dcomms_site_config` receives site-specific configuration
- Updates `DComms_cfg::Dynamic` with new parameters
- Affects radio operation through subsequent reconfiguration

### Maintenance Testing and Radio Control
- `Cy_maint_dcomms` performs radio diagnostics
- Interacts directly with radio port for command/response
- Temporarily disables normal communication during testing

### File Transfer and Memory Management
- `Cy_file_transfer` handles file data reception
- Writes to specified memory blocks
- Validates paths and sizes before writing

### Message Forwarding and Communication
- `Cy_forwarder` forwards messages between networks
- `Cy_msg_wrapper` adds message IDs and checksums
- Together they ensure proper message routing and integrity

## 9. Referenced Context Files

- **Rawpcfg.h**: Provided essential structures for radio configuration commands
  - Defined command types and response formats for radio communication
  - Used by DComms_cfg to build configuration sequences

- **Tnarrayresz.h**: Provided resizable array implementation
  - Used for frequency tables and register value collections
  - Enabled dynamic sizing of configuration data

- **Cyphal_common_types.h**: Provided Cyphal data type definitions
  - Used for serialization and deserialization of messages
  - Enabled structured data exchange over Cyphal

- **Itask.h**: Provided asynchronous task interface
  - Used by DComms_dev for non-blocking configuration
  - Enabled parallel operation during radio configuration

- **Timeout.h**: Provided timeout management
  - Used for tracking message reception times
  - Enabled heartbeat monitoring in health reporting

- **Stanag_msg_type.h**: Provided message type definitions
  - Used for message identification in Cyphal communication
  - Enabled proper routing of different message types