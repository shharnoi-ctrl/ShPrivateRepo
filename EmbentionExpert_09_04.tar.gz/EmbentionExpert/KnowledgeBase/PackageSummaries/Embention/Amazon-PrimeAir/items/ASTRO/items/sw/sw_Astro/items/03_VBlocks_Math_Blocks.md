# Generated from:

- _sw_Veronte/code/vblocks/code/include/Blk_fun_r1xr1.h (1327 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_fun_r1xr1.cpp (975 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_fun_r2xr1.h (1085 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_fun_r2xr1.cpp (854 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_fun_rnxr1.h (710 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_fun_rnxr1.cpp (992 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_fun_bnxb1.h (727 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_fun_bnxb1.cpp (411 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_vec_ops.h (993 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_vec_ops.cpp (4422 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_matvec.h (677 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_matvec.cpp (358 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_kmult_vec.h (742 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_kmult_vec.cpp (361 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_dot.h (616 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_dot.cpp (266 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_poly.h (490 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_poly.cpp (389 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_rtable3d.h (890 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_rtable3d.cpp (267 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_vec_interp.h (1130 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_vec_interp.cpp (2080 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_fft.h (557 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_fft.cpp (845 tokens)

## With context from:

- PackageSummaries/Embention/Amazon-PrimeAir/items/ASTRO/items/sw/sw_Astro/items/04_VBlocks_Core.md (5729 tokens)

---

# Mathematical Operation Blocks in VBlocks Library

This document provides a comprehensive analysis of the mathematical operation blocks in the VBlocks library, focusing on how they implement various mathematical functions, vector operations, matrix operations, and interpolation.

## 1. Function Blocks with Single Real Input and Output (Blk_fun_r1xr1)

### 1.1 Overview

`Blk_fun_r1xr1` implements unary mathematical operations that take one real input and produce one real output. The class supports 21 different mathematical functions.

### 1.2 Supported Operations

The block supports the following operations through the `Er1x1type` enumeration:
- `t1x1_abs` (0): Absolute value
- `t1x1_floor` (1): Round to nearest integer towards negative infinity
- `t1x1_ceil` (2): Round to nearest integer towards positive infinity
- `t1x1_sqrt` (3): Square root
- `t1x1_sin` (4): Sine
- `t1x1_cos` (5): Cosine
- `t1x1_tan` (6): Tangent
- `t1x1_asin` (7): Arc sine
- `t1x1_acos` (8): Arc cosine
- `t1x1_atan` (9): Arc tangent
- `t1x1_exp` (10): Exponential
- `t1x1_log` (11): Natural logarithm
- `t1x1_wrap2pi` (12): Wrap to interval [-pi,pi]
- `t1x1_wrap22pi` (13): Wrap to interval [0,2pi]
- `t1x1_wrap201` (14): Wrap to interval [0,1]
- `t1x1_wrap205` (15): Wrap to interval [-0.5,0.5]
- `t1x1_sqr` (16): Square power
- `t1x1_inv` (17): Inverse (1/x)
- `t1x1_minus` (18): Change sign (-x)
- `t1x1_round` (19): Round to nearest integer
- `t1x1_sign` (20): Returns sign of input (1 for positive, -1 for negative)

### 1.3 Implementation Details

The block uses a function pointer array to map the operation type to the corresponding function:

```cpp
typedef Real (*Fstep_p)(Real in);  // General definition of function
static const Fstep_p fstep[] = {
    &Rmath::fabsr,
    &Rmath::floorr,
    &Rmath::ceilr,
    &Rfun::safe_sqrt,
    &Rmath::sinr,
    &Rmath::cosr,
    &Rmath::tanr,
    &Rfun::asinw,
    &Rfun::acosw,
    &Rmath::atanr,
    &Rmath::expr,
    &Rfun::safe_log,
    &Rfun::wrap2pi,
    &Rfun::wrap22pi,
    &Rfun::wrap21,
    &Rfun::wrap205,
    &sqr,
    &inverse,
    &minus,
    &Rmath::roundr,
    &Rfun::sign
};
```

The `step()` method executes the selected function on the input value:

```cpp
void Blk_fun_r1xr1::step() {
    out.val = fstep[subtype](in.read());
}
```

### 1.4 Error Handling

The block includes safety mechanisms for operations with restricted domains:
- Square root returns 0 for negative values
- Arc sine/cosine clamp inputs to [-1, 1]
- Natural logarithm uses a minimum allowed value for inputs outside its domain
- Inverse uses a minimum allowed value (epsilon) to avoid divide by zero errors

### 1.5 Configuration

The block is configured through its PDI (Parameter Definition Interface) with:
- `in`: Input address
- `type`: Type of R1xR1 function (0-20)

## 2. Function Blocks with Two Real Inputs and One Real Output (Blk_fun_r2xr1)

### 2.1 Overview

`Blk_fun_r2xr1` implements binary mathematical operations that take two real inputs and produce one real output. The class supports 9 different mathematical functions.

### 2.2 Supported Operations

The block supports the following operations through the `Er2xr1type` enumeration:
- `tr2xr1_add` (0): Addition of two values
- `tr2xr1_sub` (1): Subtraction of first value minus second value
- `tr2xr1_mul` (2): Multiplication of two values
- `tr2xr1_div` (3): Divide first value with second value
- `tr2xr1_mod` (4): Remainder (modulo) of division of first value with second value
- `tr2xr1_pow` (5): First value to the power of the second value
- `tr2xr1_atan2` (6): Signed arc tangent
- `tr2xr1_min` (7): Returns the lowest input
- `tr2xr1_max` (8): Returns the highest input

### 2.3 Implementation Details

Similar to `Blk_fun_r1xr1`, this block uses a function pointer array:

```cpp
typedef Real (*Fstep_p)(Real in0, Real in1);  // General definition of function
static const Fstep_p fstep[] = {
    &add,
    &sub,
    &mul,
    &div,
    &Rfun::safe_modulo,
    &Rfun::safe_pow,
    &Rfun::safe_atan2,
    &Rfun::min<Real>,
    &Rfun::max<Real>
};
```

The `step()` method applies the selected function to the two input values:

```cpp
void Blk_fun_r2xr1::step() {
    out.val = fstep[subtype](in0.read(), in1.read());
}
```

### 2.4 Error Handling

The block includes safety mechanisms for operations with potential errors:
- Division uses a minimum allowed denominator (epsilon) to avoid divide by zero
- Modulo returns the numerator if the denominator is considered to be zero
- Exponent returns 0 if both base and exponent are considered to be zero
- Arc tangent returns ±pi/2 if the denominator is considered to be zero

### 2.5 Configuration

The block is configured through its PDI with:
- `in0`: Input address of the first input
- `in1`: Input address of the second input
- `type`: Type of R2xR1 function (0-8)

## 3. Vector Reduction Function Blocks (Blk_fun_rnxr1)

### 3.1 Overview

`Blk_fun_rnxr1` implements operations that reduce a vector of real values to a single real value. The class supports 3 different reduction operations.

### 3.2 Supported Operations

The block supports the following operations through the `Ernx1type` enumeration:
- `tnx1_mult` (0): Multiplication of all elements
- `tnx1_add` (1): Addition of all elements
- `tnx1_norm` (2): Euclidean norm of vector

### 3.3 Implementation Details

The block uses a function pointer array to map the operation type:

```cpp
typedef Real (*Fstep_p)(const Maverick::Rvector& v0);  // General definition of function
static const Fstep_p fstep[] = {
    &mult,
    &add,
    &norm,
};
```

The `step()` method applies the selected function to the input vector:

```cpp
void Blk_fun_rnxr1::step() {
    const Maverick::Rvector::K v0(in.get_mblock());
    out.val = fstep[subtype](v0.kvec);
}
```

The implementation of each operation:
- `mult`: Calls `Maverick::Rvector::mult()` to multiply all elements
- `add`: Calls `Maverick::Rvector::accumulate()` to add all elements
- `norm`: Calls `Maverick::Rvector::norm2()` to compute the Euclidean norm

### 3.4 Configuration

The block is configured through its PDI with:
- `in`: Input address (vector with 1-32 elements)
- `subtype`: Type of nx1 function (0-2)

## 4. Boolean Logic Function Blocks (Blk_fun_bnxb1)

### 4.1 Overview

`Blk_fun_bnxb1` implements logical operations that combine multiple boolean inputs into a single boolean output. The class supports AND and OR operations.

### 4.2 Supported Operations

The block supports the following operations through the `mode` boolean:
- `true`: AND operation (all inputs must be true for output to be true)
- `false`: OR operation (any input being true makes output true)

### 4.3 Implementation Details

The `step()` method implements the logical operations directly:

```cpp
void Blk_fun_bnxb1::step() {
    out.val = ins[0U].read();
    if (mode) {
        // AND
        for (Uint32 i = 1U; i < ins.size(); ++i) {
            out.val &= ins[i].read();
        }
    } else {
        // OR
        for (Uint32 i = 1U; i < ins.size(); ++i) {
            out.val |= ins[i].read();
        }
    }
}
```

### 4.4 Configuration

The block is configured through its PDI with:
- `inputs`: Array of boolean inputs (1-32 inputs)
- `mode`: Mode of the block (true = AND, false = OR)

## 5. Vector Operations Blocks (Blk_vec_ops)

### 5.1 Overview

`Blk_vec_ops` implements operations between two vectors or matrices. The class supports 9 different vector and matrix operations.

### 5.2 Supported Operations

The block supports the following operations through the `Mathmode` enumeration:
- `vec_add` (0): Addition of 2 vectors
- `vec_subtract` (1): Subtraction of 2 vectors
- `vec_cross` (2): Cross product of 2 vectors
- `mat_rotate` (3): Multiply by a rotation matrix
- `mat_mat` (4): Product of two 3x3 matrices
- `mat_matT` (5): Product of a 3x3 matrix and the transpose of another 3x3 matrix
- `matT_mat` (6): Product of the transpose of a 3x3 matrix and another 3x3 matrix
- `matT_matT` (7): Product of the transpose of two 3x3 matrices
- `mat_vec` (8): Product of a 3x3 matrix and a 3-element vector

### 5.3 Implementation Details

The block uses a function pointer array to map the operation type:

```cpp
typedef void (*Fstep_p)(const Base::Mblock<const Real>& in0,
                        const Base::Mblock<const Real>& in1,
                        Base::Mblock<Real> out);
static const Fstep_p fstep[] = {
    &add,
    &subtract,
    &cross,
    &matrotate,
    &matmat_prod,
    &matmatT_prod,
    &matTmat_prod,
    &matTmatT_prod,
    &matvec_prod
};
```

The `step()` method applies the selected function to the input vectors/matrices:

```cpp
void Blk_vec_ops::step() {
    fstep[subtype](in0.get_mblock(), in1.get_mblock(), out.val.to_mblock());
}
```

### 5.4 Vector Operation Implementations

- **Vector Addition**: Uses `Rvector::sum()` to add two vectors element-wise
- **Vector Subtraction**: Uses `Rvector::subtract()` to subtract two vectors element-wise
- **Cross Product**: Uses `Irvector3::cross()` to compute the cross product of two 3D vectors
- **Matrix Rotation**: Creates a rotation matrix from Euler angles and applies it to a vector
- **Matrix-Matrix Product**: Uses various matrix multiplication methods from `Irmatrix3` class
- **Matrix-Vector Product**: Uses `Irvector3::matvec()` to multiply a matrix by a vector

### 5.5 Configuration

The block is configured through its PDI with:
- `in0`: Address of first input
- `in1`: Address of second input
- `subtype`: Type of operation (0-8)

The block validates that the input sizes match the requirements of the selected operation:
- Vector addition/subtraction: Both inputs must have the same size
- Cross product/rotation: Both inputs must be 3-element vectors
- Matrix operations: Inputs must be 9-element arrays (3x3 matrices)
- Matrix-vector product: First input must be a 9-element array, second input must be a 3-element vector

## 6. Matrix-Vector Multiplication Block (Blk_matvec)

### 6.1 Overview

`Blk_matvec` implements multiplication of a vector by a static matrix. The output is a vector with size equal to the number of rows in the matrix.

### 6.2 Implementation Details

The `step()` method uses the `Dynrvector::matvec()` method to perform the matrix-vector multiplication:

```cpp
void Blk_matvec::step() {
    out.val.matvec(m0, Maverick::Rvector::K(in0.get_mblock()).kvec);
}
```

### 6.3 Configuration

The block is configured through its PDI with:
- `in0`: Input vector address
- `m0`: Matrix configuration

The block validates that:
- The number of elements in the input vector equals the number of columns in the matrix
- The output vector can be allocated with size equal to the number of rows in the matrix

## 7. Vector Scaling Block (Blk_kmult_vec)

### 7.1 Overview

`Blk_kmult_vec` implements multiplication of a vector by a scalar constant. The output is a vector with the same size as the input.

### 7.2 Implementation Details

The `step()` method copies the input vector and scales it by the constant:

```cpp
void Blk_kmult_vec::step() {
    out.val.copy(in0.get_mblock());
    out.val.scale(in1.read());
}
```

### 7.3 Configuration

The block is configured through its PDI with:
- `in0`: Input vector address (up to 32 elements)
- `in1`: Input scalar address (1 element)

## 8. Dot Product Block (Blk_dot)

### 8.1 Overview

`Blk_dot` implements the dot product of two vectors of equal size. The output is a single real value.

### 8.2 Implementation Details

The `step()` method uses the `Rvector::dot()` method to compute the dot product:

```cpp
void Blk_dot::step() {
    const Maverick::Rvector::K v0(in0.get_mblock());
    const Maverick::Rvector::K v1(in1.get_mblock());
    out.val = v0.kvec.dot(v1.kvec);
}
```

### 8.3 Configuration

The block is configured through its PDI with:
- `in0`: Address of first input vector
- `in1`: Address of second input vector

The block validates that both input vectors have the same size.

## 9. Polynomial Evaluation Block (Blk_poly)

### 9.1 Overview

`Blk_poly` evaluates a polynomial equation of the form:
```
v[0] + v[1]*x + v[2]*x^2 + ... + v[n-1]*x^(n-1)
```
where `x` is the block's real input and `v` is the block's vector input containing the polynomial coefficients.

### 9.2 Implementation Details

The `step()` method uses the `Rvector::polynomial()` method to evaluate the polynomial:

```cpp
void Blk_poly::step() {
    const Maverick::Rvector::K c0(coeff.get_mblock());
    out.val = c0.kvec.polynomial(in.read());
}
```

### 9.3 Configuration

The block is configured through its PDI with:
- `coeff`: Polynomial coefficients (vector)
- `in`: Input evaluation value (scalar)

## 10. 3D Table Interpolation Block (Blk_rtable3d)

### 10.1 Overview

`Blk_rtable3d` performs 2D interpolation over an x-y table of values. Given two input values (x and y), it returns the interpolated value from the table.

### 10.2 Implementation Details

The `step()` method uses the `Rtable3d::interp2()` method to perform the interpolation:

```cpp
void Blk_rtable3d::step() {
    out.val = fxy.get().interp2(inx.read(), iny.read());
}
```

### 10.3 Configuration

The block is configured through its PDI with:
- `in_x`: Address of x input for interpolation
- `in_y`: Address of y input for interpolation
- `table`: Configuration of the table to interpolate

## 11. Vector Interpolation Block (Blk_vec_interp)

### 11.1 Overview

`Blk_vec_interp` interpolates each component of a vector over several X-Y tables, one table for each component. It can interpolate X over Y or Y over X, depending on configuration.

### 11.2 Implementation Details

The `step()` method performs interpolation for each component of the input vector:

```cpp
void Blk_vec_interp::step() {
    const Base::Mblock<const Real> v0(in.get_mblock());
    if (inv_interp) {
        // Inverse interpolation (Y to X)
        for (Uint32 i = 0; i < tablearray.size(); ++i) {
            tablearray[i].rt.get().interp1_linear_1(0, v0[i], out.val[i], true);
        }
    } else {
        // Direct interpolation (X to Y)
        for (Uint32 i = 0; i < tablearray.size(); ++i) {
            tablearray[i].rt.get().interp1_linear(v0[i], out.val[i]);
        }
    }
}
```

### 11.3 Configuration

The block is configured through its PDI with:
- `in`: Block input (vector)
- `inv_interp`: Interpolation inversion flag
- `tablearray`: Array of interpolation tables (one per vector component)

Each table in `tablearray` contains:
- `x_table`: X values for the table
- `y_table`: Y values for the table

The block validates that:
- The number of tables equals the number of elements in the input vector
- For each table, the X values are non-descending (sorted)
- For inverse interpolation, Y values must be either all ascending or all descending (bijective function)

## 12. Fast Fourier Transform Block (Blk_fft)

### 12.1 Overview

`Blk_fft` computes the Fast Fourier Transform of an input signal and provides two vectors containing the three frequencies with the highest amplitudes (peaks) and their corresponding magnitude values.

### 12.2 Implementation Details

The `step()` method uses a `Cyclest` object to compute the FFT:

```cpp
void Blk_fft::step() {
    if (fft.is_free()) {
        fft.init(tmax, fft_stages, this);
    }
    if (fft.is_owned_by(this)) {
        if (fft.step(in.read())) {
            // init
            const Gnc::Cyclest::Peakdata& peaks = fft.get_peaks();
            amax.val.copy(peaks.mag);
            fmax.val.copy(peaks.f);
            fft.free();
        }
    }
}
```

The block collects samples over time, then computes the FFT when enough samples have been collected.

### 12.3 Configuration

The block is configured through its PDI with:
- `in`: Address of input to be filtered
- `stages`: Stage number for the FFT algorithm (determines vector size as 2^stages)
- `tmax`: Time for FFT calculation (determines sampling time as tmax/size)

The block validates that:
- The stages value is valid (typically between 5 and 10)
- The maximum time is positive

## 13. Cross-Component Relationships

### 13.1 Mathematical Function Hierarchy

The mathematical operation blocks form a hierarchy based on their input/output characteristics:

1. **Scalar Operations**
   - `Blk_fun_r1xr1`: One scalar input, one scalar output
   - `Blk_fun_r2xr1`: Two scalar inputs, one scalar output

2. **Vector Reduction Operations**
   - `Blk_fun_rnxr1`: Vector input, scalar output
   - `Blk_dot`: Two vector inputs, scalar output

3. **Vector Operations**
   - `Blk_vec_ops`: Two vector/matrix inputs, vector/matrix output
   - `Blk_matvec`: Matrix and vector inputs, vector output
   - `Blk_kmult_vec`: Vector and scalar inputs, vector output

4. **Interpolation Operations**
   - `Blk_poly`: Scalar input and vector of coefficients, scalar output
   - `Blk_rtable3d`: Two scalar inputs, scalar output from 2D table
   - `Blk_vec_interp`: Vector input, vector output from multiple 1D tables

5. **Signal Processing Operations**
   - `Blk_fft`: Scalar input over time, two vector outputs (frequencies and magnitudes)

### 13.2 Common Implementation Patterns

Several common patterns appear across the mathematical operation blocks:

1. **Function Pointer Arrays**: Many blocks use arrays of function pointers to map operation types to implementation functions.

2. **Safe Operations**: Blocks implement safety checks for operations with restricted domains or potential errors.

3. **Vector/Matrix Operations**: Blocks leverage the `Maverick` library's vector and matrix classes for efficient operations.

4. **Configuration Validation**: Blocks validate their configuration during deserialization to ensure inputs have compatible sizes.

5. **Memory Management**: Blocks use custom memory allocation for dynamic data structures.

## 14. Referenced Context Files

The following context files provided useful information for understanding the mathematical operation blocks:

- `04_VBlocks_Core.md`: Provided context about the overall VBlocks architecture, block factory system, and block type definitions, which helped understand how mathematical operation blocks fit into the larger system.

## 15. Summary

The VBlocks library provides a comprehensive set of mathematical operation blocks that cover:

1. **Basic Mathematical Functions**: Trigonometric, exponential, logarithmic, and other common functions
2. **Vector Operations**: Addition, subtraction, cross product, dot product, and scaling
3. **Matrix Operations**: Matrix-matrix and matrix-vector multiplication with various transpose options
4. **Interpolation**: Polynomial evaluation, table lookup, and vector interpolation
5. **Signal Processing**: Fast Fourier Transform for frequency analysis

These blocks form the mathematical foundation of the VBlocks library, enabling complex calculations and algorithms to be implemented through block connections. The library's design emphasizes safety, efficiency, and flexibility, with careful handling of edge cases and error conditions.