# Generated from:

- src/AdnVehicleRecoveryWrapperAlgorithms/algorithm/RecoveryWrapper/src/PopulateMessages.cpp (11980 tokens)

---

# Message Handling Functionality in PopulateMessages.cpp

This file implements a comprehensive set of message population functions that serve as the data transformation layer in the Recovery Wrapper system. It handles the conversion between VSDK message formats and Simulink data structures, enabling communication between different components of the system.

## 1. Functional Behavior and Logic

### Namespace and Type Definitions
- Uses namespace aliases for clarity:
  - `RecoveryMsg` = `vsdk::message::adn::vehicle::recovery`
  - `PrimaryMsg` = `vsdk::message::adn::vehicle::navigationandsensingsystem`
- Operates within `vsdk::algorithm::recoverywrapper` namespace
- Utilizes environment constants from `gnc_utilities::environment_constants`

### Utility Functions
- Defines a template utility function `copy_to_std_array<T1, T2, N>` that copies arrays between different formats
  - Used extensively throughout the file to transfer data between array types
  - Simplifies the repetitive task of copying array elements

## 2. GNSS Data Transformation Functions

### `PopulateGnssFromVsdkMessage` (Recovery Message Version)
- **Purpose**: Converts Recovery message GNSS data to Simulink GNSS structure
- **Inputs**: 
  - `current_time_s`: Current system time in seconds
  - `input_pvt`: GNSS data in Recovery message format
  - `simulink_gnss`: Output Simulink GNSS structure (modified in-place)
- **Logic**:
  - Copies time information (current time, week, time of week)
  - Transfers position data (latitude, longitude, altitude)
  - Copies velocity data in NED frame
  - Transfers accuracy metrics (horizontal, vertical, speed)
  - Copies fix type and number of satellites

### `PopulateGnssFromVsdkMessage` (Primary Message Version)
- **Purpose**: Converts Primary message GNSS data to Simulink GNSS structure
- **Inputs**: 
  - `current_time_s`: Current system time in seconds
  - `input_pvt`: GNSS data in Primary message format
  - `simulink_gnss`: Output Simulink GNSS structure (modified in-place)
- **Logic**:
  - Similar to the Recovery message version but maps from different field names
  - Handles the field name differences between message types (e.g., `tow_s` vs `time_of_week_s`)

## 3. Measurement Data Population Functions

### `PopulateMeasurementsFromSimulink`
- **Purpose**: Extracts measurement data from Simulink output and populates a VSDK message
- **Input**: `measurements`: Recovery message measurements structure (modified in-place)
- **Logic**:
  - Copies IMU measurements (time, force, angular velocity)
  - Transfers GNSS A and B data (time, week, position, velocity, accuracy metrics)
  - Copies LIDAR measurements (time, distance to target, return strength)
  - Transfers pressure measurements (dynamic and static)
  - Copies uplink heading data
  - Transfers time synchronization information with unit conversion (seconds to nanoseconds)

## 4. Navigation Introspect Data Functions

### `PopulateNavIntrospectFromSimulink`
- **Purpose**: Populates navigation introspection data from Simulink to VSDK message format
- **Inputs**:
  - `nav_introspect`: Output Recovery message navigation introspect structure
  - `emb_out`: Embention navigation wrapper outputs
- **Logic**:
  - Calls `PopulateMeasurementsFromSimulink` to handle measurement data
  - Copies extensive state information:
    - Quaternion orientation
    - Position and velocity vectors
    - Acceleration and angular velocity
    - Bias values for accelerometer and gyroscope
    - Ground distance and air data
    - Covariance information
    - Reference LLA coordinates
  - Transfers sensor status information for multiple sensors:
    - GNSS position and velocity
    - LIDAR
    - Static and dynamic pressure
  - Copies navigation status flags
  - Transfers time synchronization data with unit conversion
  - Copies ground detection information
  - Transfers initializer flags

### `PopulateNavIntrospectCompact`
- **Purpose**: Creates a compact version of navigation introspection data
- **Input**: `nav_introspect_compact`: Output compact navigation introspect message
- **Logic**:
  - Extracts only the most essential information from the full navigation introspect data
  - Focuses on sensor status information and navigation flags
  - Copies ground detection data
  - Transfers initializer flags

## 5. State Estimate Functions

### `PopulateStateEstimateCompactOutput`
- **Purpose**: Creates a compact state estimate from full state data
- **Inputs**:
  - `state_estimate_log_msg`: Source state estimate message
  - `simulink_state_estimate`: Simulink state estimate data
  - `state_estimate_compact`: Output compact state estimate message
- **Logic**:
  - Copies only essential state information (time, position, orientation)
  - Transfers key status flags

### `PopulateStateEstimateLogOutput`
- **Purpose**: Converts Simulink state estimate to VSDK message format
- **Inputs**:
  - `simulink_state_estimate`: Source Simulink state estimate
  - `state_estimate_log_msg`: Output state estimate message
- **Logic**:
  - Transfers position data (latitude, longitude, altitude)
  - Copies velocity vectors
  - Transfers attitude information (roll, pitch, heading, quaternion)
  - Copies angular rates and acceleration
  - Calculates and transfers environmental data (dynamic pressure, air density)
  - Sets wind velocity information
  - Transfers status flags using `SetStatusValue` helper function

### `SetStatusValue`
- **Purpose**: Converts Simulink status enum to VSDK status enum
- **Inputs**:
  - `simulink_status_field`: Source Simulink status enum
  - `state_estimate_status`: Output VSDK status field
- **Logic**:
  - Maps between different status enumerations:
    - `NavStatusEnum::VALID` → `StateEstimateFieldStatus_0_1::VALID`
    - `NavStatusEnum::DEGRADED` → `StateEstimateFieldStatus_0_1::DEGRADED`
    - `NavStatusEnum::INVALID` → `StateEstimateFieldStatus_0_1::INVALID`
  - Logs warning for invalid status values

### `PopulateSimulinkEstimateFromStateEstimate`
- **Purpose**: Converts VSDK state estimate to Simulink format
- **Inputs**:
  - `dst`: Output Simulink state estimate structure
  - `se_msg`: Source VSDK state estimate message
- **Logic**:
  - Initializes NED converter if this is the first LLA received
  - Converts LLA to NED coordinates
  - Transfers time information
  - Copies quaternion orientation
  - Transfers position, velocity, acceleration, and angular velocity vectors
  - Calculates and copies air data
  - Transfers attitude angles (roll, pitch, heading)
  - Copies LLA coordinates and altitude above ground
  - Sets ground detection flag
  - Transfers navigation status information

## 6. Controller Logs Population

### `PopulateRecoveryControllerLogs`
- **Purpose**: Extracts controller log data from Simulink and populates VSDK message
- **Input**: `recovery_controller_logs`: Output controller logs message
- **Logic**:
  - Copies extensive controller data across multiple subsystems:
    - AACG logs (desired bank angle)
    - Actuator logs (RPM commands)
    - ASC logs (quaternions, angular velocities, accelerations)
    - Flight condition information
    - Mixer logs (wrench data)
    - State machine logs (land mode, recovery state)
    - Scheduler logs (pressure, airspeed, acceleration)
    - TCG logs (waypoint commands, velocities)
    - TSC logs (tracking errors)

## 7. Error Handling and Data Validation

- Performs unit conversions where necessary (seconds to nanoseconds)
- Handles special cases for air speed calculation:
  ```cpp
  if (se_msg.dynamic_pressure_Pa > 0) {
      dst.air_speed_IAS_m_per_s = sqrt(2*se_msg.dynamic_pressure_Pa/kAirDensityMeanSeaLevelKgPerM3);
  } else {
      dst.air_speed_IAS_m_per_s = 0;
  }
  ```
- Validates status values and logs warnings for invalid status enums
- Handles initialization of coordinate conversion systems:
  ```cpp
  if (!state_.first_lla_received) {
      ned_converter_ = adn::geotrans::NedLlaConverter{lla_rrm};
      state_.first_lla_received = true;
  }
  ```
- Contains TODO comments indicating incomplete functionality:
  ```cpp
  recovery_controller_logs.recovery_state_machine_logs.contingency_action = 99; // TODO
  ```

## 8. Cross-Component Relationships

The file serves as a critical data transformation layer between:
1. VSDK message formats (both Recovery and Primary message types)
2. Simulink data structures used by the Recovery algorithms
3. Embention navigation wrapper outputs

It enables bidirectional data flow between these components, ensuring proper communication between different parts of the system.

## 9. Key Message Transformation Patterns

The file consistently uses several patterns for data transformation:
1. Direct field-by-field copying for scalar values
2. Using `copy_to_std_array` utility for array data
3. Explicit loops for array copying when needed
4. Unit conversions where required (e.g., seconds to nanoseconds)
5. Status enum mapping between different representation systems

This comprehensive message handling functionality ensures that data can flow correctly between the different components of the Recovery Wrapper system, maintaining data integrity and proper formatting across system boundaries.