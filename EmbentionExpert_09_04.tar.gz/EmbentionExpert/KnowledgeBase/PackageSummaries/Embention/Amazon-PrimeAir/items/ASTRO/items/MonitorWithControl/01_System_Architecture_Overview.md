# Generated from:

- Amazon-PrimeAir/items/ASTRO/items/MonitorWithControl/02_Monitor_Control_Core.md (3494 tokens)

---

# Monitor with Control System: Comprehensive Architectural Overview

## 1. System Architecture and Key Components

The Monitor with Control (MwC) system is a safety-critical architecture designed with redundancy and fault tolerance as core principles. It consists of primary and recovery control systems with sophisticated switchover mechanisms to ensure continuous operation even in the presence of failures.

### Core Components

1. **Blockfactory**
   - Central orchestration mechanism for the control systems
   - Manages initialization, execution flow, and switchover between primary and recovery systems
   - Contains internal data structures for state management and performance monitoring

2. **Recovery Wrapper Control System Object (RWCSO)**
   - Manages inputs and outputs for the recovery system
   - Provides isolation between the recovery system and external interfaces
   - Ensures clean transitions during switchover events

3. **Control Builder**
   - Responsible for constructing the control system implementation
   - Configures the control system based on system type and requirements
   - Initializes control parameters after PDI (Parameter Data Item) loading

4. **Switchover Mechanism**
   - Hardware and software components that manage transitions between primary and recovery systems
   - Uses GPIO signals for reliable hardware-level communication
   - Implements timeout-based triggering for controlled transitions

5. **Performance Monitoring System**
   - Profiles execution times for control operations
   - Tracks both maximum and average execution times
   - Separately monitors input processing and overall control execution

6. **Communication Interfaces**
   - Message handlers for various communication types
   - File transfer mechanisms for mission data
   - GPIO interfaces for hardware-level signaling

### System Types

The architecture supports different system types with specialized behaviors:

1. **EV1 Systems**
   - Execute both switchover and control steps
   - Manage switchover timing internally
   - Identified by UID resource value (uid.res <= Ku32::u2)

2. **Monitor Systems**
   - Execute only the switchover step
   - Responsible for signaling switchover to other systems
   - Identified by application type (uid.app == Bsp::sapp_pam)

3. **Other Systems**
   - Read switchover signals from GPIO feedback
   - Execute control steps based on external switchover signals
   - Do not manage switchover timing internally

## 2. Redundancy Model and Switchover Mechanisms

The MwC system implements a sophisticated redundancy model with well-defined switchover mechanisms to ensure continuous operation in the presence of failures.

### Redundancy Architecture

The system employs a primary-recovery redundancy model where:

1. **Primary System**
   - Handles normal operation under nominal conditions
   - Continuously monitored for failures or anomalies
   - Can be signaled to transfer control to the recovery system

2. **Recovery System**
   - Runs in parallel with the primary system
   - Ready to take over control when signaled
   - Isolated through the Recovery Wrapper Control System Object (RWCSO)

### Switchover Mechanism Implementation

```cpp
void step_switch_over()
{
    static const volatile Real& user_clk = Bsp::Hrvar(Pa_system_vars::ctr_user_clk).get_kref();
    if(user_clk > 0.0F)
    {
        static Base::Timeout out(user_clk);
        if (out.expired())
        {
            // Update switchover output GPIOs
            static Dsp28335_ent::GPIO g_alert(Ver::get_gpio_switch_alert());
            static Dsp28335_ent::GPIO g_nalert(Ver::get_gpio_switch_nalert());
            g_alert.set_hi();
            g_nalert.set_lo();
            has_switchover_been_signalled_to_primary.set(true);
            has_switchover_been_signalled_to_recovery.set(true);
        }
    }
}
```

### Switchover Signaling

The switchover mechanism uses multiple signaling paths to ensure reliability:

1. **GPIO Signaling**
   - `g_alert`: GPIO signal for switchover alert (active high)
   - `g_nalert`: Inverted GPIO signal for switchover alert (active low)
   - `feedback`: GPIO input for reading switchover status from other systems

2. **State Variables**
   - `has_switchover_been_signalled_to_primary`: Tracks if primary system has been notified
   - `has_switchover_been_signalled_to_recovery`: Tracks if recovery system has been notified

3. **Timeout-Based Triggering**
   - Uses a timeout mechanism based on `user_clk` to control switchover timing
   - Ensures switchover occurs at a controlled time rather than immediately upon failure detection

### System-Specific Switchover Behavior

The switchover behavior varies based on system type:

1. **EV1 Systems**
   - Both switchover and control steps are executed
   - Manage switchover timing internally

2. **Monitor Systems**
   - Only execute the switchover step
   - Responsible for signaling switchover to other systems
   - Act as the authority for switchover decisions

3. **Other Systems**
   - Read switchover signals from GPIO feedback
   - Update internal state variables based on GPIO input
   - Execute control steps based on the current active system

### Switchover Safety Features

1. **Dual Signaling**: Uses both normal and inverted GPIO signals to ensure reliable detection
2. **State Tracking**: Maintains explicit state variables for switchover status
3. **System Type Awareness**: Adapts behavior based on system type for proper coordination
4. **Clean Input/Output Separation**: Ensures clean interfaces during transitions

## 3. Control Flow and Execution Model

The MwC system implements a structured control flow with performance monitoring to ensure reliable and timely execution.

### Control Execution Sequence

```cpp
void step_control()
{
    ctrl_profiling.tic();

    // Read inputs
    ctrl_in_profiling.tic();
    rwcso_input.step();
    ctrl_in_profiling.toc();

    // Execute Recovery Wrapper Control System object
    control.step(rwcso_input, rwcso_output);

    // Publish outputs
    rwcso_output.step();

    ctrl_profiling.toc();
}
```

The control execution follows a clear sequence:

1. **Start Performance Profiling**
   - Begin overall control execution timing
   - Initialize performance metrics

2. **Input Processing**
   - Start input profiling timer
   - Read all inputs via `rwcso_input.step()`
   - Stop input profiling timer
   - Update input performance metrics

3. **Control Execution**
   - Execute the control algorithm via `control.step(rwcso_input, rwcso_output)`
   - Process inputs and generate appropriate outputs
   - Apply control logic based on current system state

4. **Output Publishing**
   - Publish all outputs via `rwcso_output.step()`
   - Ensure outputs are properly transmitted to actuators and other systems

5. **End Performance Profiling**
   - Stop overall control execution timing
   - Update performance metrics

### Main Execution Flow

The system's main execution flow is managed through the Blockfactory class:

```
Blockfactory::step_pre_gnc()
  ├── [System Type Detection]
  │     ├── EV1 Systems: Execute both switchover and control
  │     ├── Monitor Systems: Execute only switchover
  │     └── Other Systems: Read switchover signals and execute control
  │
  ├── Data::step_switch_over() [for EV1 and Monitor systems]
  │     └── GPIO signaling for switchover
  │
  └── Data::step_control() [for EV1 and non-Monitor systems]
        ├── rwcso_input.step() [Read inputs]
        ├── control.step(rwcso_input, rwcso_output) [Execute control]
        └── rwcso_output.step() [Publish outputs]
```

### Performance Monitoring

The system implements comprehensive performance monitoring:

1. **Input Processing Profiling**
   - `ctrl_in_profiling`: Measures input reading performance
   - Tracks maximum time: `Pa_system_vars::ctr_input_max`
   - Tracks average time: `Pa_system_vars::ctr_input_avg`

2. **Overall Control Profiling**
   - `ctrl_profiling`: Measures overall control execution performance
   - Tracks maximum time: `Pa_system_vars::ctr_time_max`
   - Tracks average time: `Pa_system_vars::ctr_time_avg`

3. **Performance Metrics**
   - Maximum execution times provide worst-case timing information
   - Average execution times provide typical performance characteristics
   - Both metrics are essential for ensuring real-time constraints are met

### Memory Management in Execution

The system employs sophisticated memory management strategies:

1. **Internal Volatile Memory**
   - `Base::Mblock<Uint16> mem_volatile` (14000 units)
   - Used for temporary calculations and working memory
   - Allocated at initialization time

2. **External Memory Allocation**
   - Used for persistent data structures
   - Allocated through the memory manager's external allocator

3. **Internal Memory Allocation**
   - Used for small, frequently accessed data
   - Allocated through the memory manager's internal allocator

4. **Scheduler Memory Configuration**
   - Configures scheduler tables with appropriate memory allocation
   - Ensures efficient scheduling of control tasks

## 4. Communication Interfaces and Protocols

The MwC system implements extensive communication interfaces to interact with other system components.

### Message Handling Framework

The system registers multiple message handlers for different message types:

```cpp
irxfw_parser.add_rx_hdl(Base::Stanag_msg_type::cyp_pa_mission_readiness, data.rwcso_input.get_msg_mission_readiness());
irxfw_parser.add_rx_hdl(Base::Stanag_msg_type::cyp_pa_diverse_comms_command_contingency, data.rwcso_input.get_msg_command_contingency());
irxfw_parser.add_rx_hdl(Base::Stanag_msg_type::cyp_pa_command_contingency_wrapper, data.rwcso_input.get_msg_command_contingency());
irxfw_parser.add_rx_hdl(Base::Stanag_msg_type::cyp_file_transfer, data.cyphal_file_mgr);
irxfw_parser.add_tx_hdl(Base::Stanag_msg_type::cyp_file_transfer, data.cyphal_file_mgr);
irxfw_parser.add_rx_hdl(Base::Stanag_msg_type::cyp_pa_upload_mission_plan_wrapper_rec, data.rwcso_input.get_msg_mission_plan_upload_metadata());
irxfw_parser.add_rx_hdl(Base::Stanag_msg_type::cyp_motor_rpm_cmd_a, data.rpm_tunnel);
irxfw_parser.add_rx_hdl(Base::Stanag_msg_type::cyp_motor_spin_dir_test_init, data.mon_motor_spin_test_init);
irxfw_parser.add_rx_hdl(Base::Stanag_msg_type::cyp_motor_spin_dir_test_result, data.mon_motor_spin_test_rcv);
irxfw_parser.add_rx_hdl(Base::Stanag_msg_type::cyp_maintenance_action_req, data.maint_action);
irxfw_parser.add_tx_hdl(Base::Stanag_msg_type::cyp_maintenance_action_res, data.maint_action);
```

### Message Categories and Protocols

1. **Mission Control Messages**
   - `cyp_pa_mission_readiness`: Mission readiness status
   - `cyp_pa_diverse_comms_command_contingency`: Contingency commands from diverse communication channels
   - `cyp_pa_command_contingency_wrapper`: Wrapped contingency commands
   - `cyp_pa_upload_mission_plan_wrapper_rec`: Mission plan upload metadata

2. **File Transfer Protocol**
   - `cyp_file_transfer`: Bidirectional file transfer messages
   - Used for mission plan data transfer
   - Implemented through the cyphal file manager

3. **Motor Control Protocol**
   - `cyp_motor_rpm_cmd_a`: Motor RPM commands
   - `cyp_motor_spin_dir_test_init`: Motor spin direction test initialization
   - `cyp_motor_spin_dir_test_result`: Motor spin direction test results
   - Includes tunneling mechanism for RPM commands between stabilizers

4. **Maintenance Protocol**
   - `cyp_maintenance_action_req`: Maintenance action requests
   - `cyp_maintenance_action_res`: Maintenance action responses
   - Supports system maintenance operations

### Hardware Communication Interfaces

1. **GPIO Interfaces**
   - `Ver::get_gpio_switch_alert()`: Alert signal for switchover (active high)
   - `Ver::get_gpio_switch_nalert()`: Inverted alert signal for switchover (active low)
   - `Ver::get_gpio_switch_fb()`: Feedback signal for switchover status
   - Used for reliable hardware-level communication between systems

2. **Mission Plan Data Interface**
   - Dedicated structure for mission plan data storage
   - File transfer mechanism for mission data:
     ```cpp
     cyphal_file_mgr(mission_plan_data.data.to_mblock(), file_path.to_mblock(), mission_plan_data.mission_sz)
     ```

### Communication Flow

```
External Systems
  │
  ├── Message Handlers (irxfw_parser)
  │     ├── RX Handlers (Incoming Messages)
  │     │     ├── Mission Control Messages → rwcso_input
  │     │     ├── File Transfer Messages → cyphal_file_mgr
  │     │     ├── Motor Control Messages → rpm_tunnel, motor test handlers
  │     │     └── Maintenance Messages → maint_action
  │     │
  │     └── TX Handlers (Outgoing Messages)
  │           ├── File Transfer Messages ← cyphal_file_mgr
  │           └── Maintenance Response Messages ← maint_action
  │
  └── GPIO Communication
        ├── Switch Alert Signal (g_alert)
        ├── Switch Inverted Alert Signal (g_nalert)
        └── Switch Feedback Signal (feedback)
```

## 5. Safety and Reliability Features

The MwC system incorporates numerous safety and reliability features to ensure robust operation in all conditions.

### Redundancy and Fault Tolerance

1. **Primary-Recovery Architecture**
   - Dual control systems (primary and recovery)
   - Recovery system ready to take over upon primary failure
   - Clean isolation through Recovery Wrapper Control System Object

2. **Switchover Mechanism Safety**
   - Dual signaling with normal and inverted GPIO signals
   - State tracking for switchover status
   - Timeout-based triggering for controlled transitions
   - System type awareness for proper coordination

3. **Diverse Implementation**
   - Different system types with specialized roles
   - Distributed responsibility for switchover decisions
   - Redundant signaling paths

### Performance Monitoring and Timing Guarantees

1. **Execution Time Profiling**
   - Monitors both maximum and average execution times
   - Separate profiling for input processing
   - Overall control execution profiling
   - Performance metrics stored in system variables

2. **Real-Time Constraints**
   - Structured control flow ensures predictable timing
   - Memory pre-allocation minimizes runtime allocation overhead
   - Efficient scheduler configuration

### Motor Control Safety

1. **Motor Testing**
   - Dedicated handlers for motor spin direction testing
   - Test initialization and result processing
   - Ensures motors operate in the correct direction

2. **RPM Command Tunneling**
   - Secure mechanism for RPM commands between stabilizers
   - Ensures proper motor control during all operational phases

### Maintenance and Diagnostics

1. **Maintenance Protocol**
   - Support for maintenance action requests and responses
   - Enables system diagnostics and maintenance operations
   - Helps identify and address potential issues

2. **Mission Readiness Monitoring**
   - Tracks mission readiness status
   - Ensures system is properly prepared for mission execution

### Safety-Critical Behavior During Switchover

1. **Controlled Timing**
   - Switchover triggered based on timeout mechanism
   - Ensures switchover occurs at appropriate times

2. **Clean Transitions**
   - Separate input/output managers ensure clean interfaces
   - Recovery wrapper provides isolation during transitions

3. **State Preservation**
   - Mission plan data preserved during switchover
   - System state maintained across transitions

4. **Reliable Signaling**
   - Dual GPIO signals (normal and inverted)
   - State variables track signaling status
   - Different behavior based on system type

### Memory Safety

1. **Structured Allocation**
   - Clear separation between volatile and persistent memory
   - Pre-allocation of working memory
   - Different allocators for different memory types

2. **Resource Management**
   - External memory for large data structures
   - Internal memory for frequently accessed data
   - Volatile memory for temporary calculations

## System Integration and Operational Flow

The Monitor with Control system integrates all components into a cohesive operational flow:

1. **Initialization Phase**
   - System type detection based on UID
   - Memory allocation for all components
   - Registration of message handlers
   - Configuration of GPIO interfaces

2. **Post-PDI Loading Phase**
   - Control system construction
   - Parameter initialization
   - Scheduler configuration

3. **Operational Phase**
   - Pre-GNC step execution
     - System type-specific behavior
     - Switchover management
     - Control execution
   - Performance monitoring
   - Communication handling

4. **Switchover Events**
   - Detection of switchover conditions
   - GPIO signaling
   - State variable updates
   - Transition between primary and recovery systems

5. **Maintenance Operations**
   - Processing of maintenance requests
   - Execution of maintenance actions
   - Reporting of maintenance results

## Conclusion

The Monitor with Control system represents a sophisticated safety-critical architecture with comprehensive redundancy, fault tolerance, and performance monitoring capabilities. Its design principles focus on ensuring continuous operation even in the presence of failures, with clean transitions between primary and recovery systems. The system's communication interfaces, memory management strategies, and safety features work together to provide a robust platform for mission-critical applications.

The architecture demonstrates a clear understanding of safety-critical system design, with multiple layers of protection, diverse implementation, and careful attention to timing guarantees and resource management. These characteristics make it suitable for applications where reliability and fault tolerance are paramount concerns.