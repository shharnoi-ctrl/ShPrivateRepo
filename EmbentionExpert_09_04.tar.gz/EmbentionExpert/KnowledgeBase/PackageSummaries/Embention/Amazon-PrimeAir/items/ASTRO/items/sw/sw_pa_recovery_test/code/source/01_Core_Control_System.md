# Generated from:

- Amazon-PrimeAir/items/ASTRO/items/sw/sw_pa_recovery_test/code/source/02_Flight_Control_Components.md (5008 tokens)
- Amazon-PrimeAir/items/ASTRO/items/sw/sw_pa_recovery_test/code/source/02_State_Machines.md (3260 tokens)
- Amazon-PrimeAir/items/ASTRO/items/sw/sw_pa_recovery_test/code/source/02_Mission_Planning.md (3566 tokens)
- Amazon-PrimeAir/items/ASTRO/items/sw/sw_pa_recovery_test/code/source/02_Trajectory_Generation.md (3857 tokens)

---

# Drone Control System Architecture: Comprehensive Overview

## 1. System Architecture Overview

The drone control system is a sophisticated multi-layered architecture designed to manage autonomous flight across multiple flight regimes (VTOL, transition, and fixed-wing). The system integrates several key components in a hierarchical structure:

```
Mission Planning
    ↓
State Machines
    ↓
Trajectory Generation
    ↓
Flight Control Components
    ↓
Actuator Commands
```

This architecture enables the drone to execute complex missions while maintaining stability and adapting to changing conditions. The system is designed with redundancy and degraded operation capabilities to handle component failures.

## 2. Mission Planning Layer

The mission planning layer defines the high-level flight plan and objectives:

### 2.1 Mission Plan Structure

A mission plan consists of:
- **Initial Plan**: Primary mission path with sequence of mission steps
- **Alternate Plans**: Contingency routes (e.g., return home)
- **Coordinate Reference System**: Defines projection for coordinate transformations
- **Environment Data**: Atmospheric conditions (pressure, temperature)
- **Flight ID**: Unique mission identifier

### 2.2 Mission Actions

The system supports several mission action types:
- **Takeoff Action**: Defines initial flight parameters
- **Markerless Delivery Action**: Package delivery parameters
- **Marker Land Action**: Landing using visual markers
- **GPS Land Action**: Landing using GPS coordinates

### 2.3 Recovery Mission Data Processor

The Recovery Mission Data Processor translates mission plans into executable routes:

```cpp
bool run(const Input& input, Output& output, Log_data& log_data)
```

Key responsibilities:
1. Deserializing mission plan data
2. Extracting mission parameters (NED origin, environment values)
3. Generating command route entries for each route type
4. Populating return home contingency plan (RHCP) data

### 2.4 Route Types

The system defines several route types:
- `route_type_takeoff_to_delivery`: From takeoff to delivery point
- `route_type_delivery_to_landing`: From delivery point to landing
- `route_type_takeoff_to_landing`: Direct from takeoff to landing
- `route_type_return_home`: Return to home location

## 3. State Machine Layer

The state machine layer manages flight modes and transitions between them:

### 3.1 Main Controller Modes

- `INIT`: System initialization
- `GROUND_IDLE`: Motors armed but not producing significant thrust
- `TAKEOFF`: Vertical ascent from ground
- `LAND`: Vertical descent to ground
- `TRACK_SPLINE`: Following a predefined trajectory
- `IN_FLIGHT_TEST`: Special mode for testing
- `DEGRADED_*`: Various degraded operation modes

### 3.2 Takeoff State Machine

Manages the takeoff sequence through states:
- `UNINITIALIZED`: Initial state
- `ON_GROUND`: Ready for takeoff
- `ATTITUDE_IN_AIR`: Initial climb
- `POSITION_HOLD_CLIMBING`: Climbing with position hold
- `TAKEOFF_COMPLETE`: Takeoff process complete

### 3.3 Land State Machine

Controls the landing sequence through states:
- `UNINITIALIZED`: Initial state
- `SLOW_DOWN_TO_HOVER`: Deceleration before descent
- `FAST_DESCENT`: Rapid descent from higher altitudes
- `SLOW_DESCENT`: Careful descent at lower altitudes

### 3.4 Gain Type Management

The state machine manages controller gain types:
- `PRECISE`: For low-speed maneuvers, landing, and precise control
- `ROBUST`: For high-speed maneuvers and more aggressive control

### 3.5 Degradation Level Management

Tracks vehicle health and adjusts behavior based on degradation levels:
- Normal operation: All rotors operational
- Level 1: One rotor inoperative
- Level 2+: More than one rotor inoperative

## 4. Trajectory Generation Layer

The trajectory generation layer creates smooth flight paths based on mission plans:

### 4.1 Trajectory Command Generator (TCG)

The TCG serves as the primary interface between route planning and flight control:
- Coordinates trajectory generation across flight phases
- Manages transitions between flight phases
- Determines appropriate tracking modes
- Generates position, velocity, and acceleration commands

### 4.2 Time-based Trajectory Command Generator (TTCG)

Generates time-based trajectory commands:
- Maintains current route index, maneuver index, and time
- Evaluates route at current time to generate trajectory commands
- Performs closest point search to determine tracking point

### 4.3 Translational Stability Controller (TSC)

Generates acceleration commands based on position and velocity errors:
- Implements tracking modes (GROUNDSPEED, AIRSPEED)
- Uses cascaded control structure for position and velocity control

### 4.4 Attitude Trajectory Command Generator (ATCG)

Generates attitude commands based on trajectory information:
- Handles different flight modes (VTOL, WBF, transitions)
- Implements weathervaning logic to align with wind
- Generates quaternion attitude commands

### 4.5 Attitude Acceleration Command Generator (AACG)

Transforms acceleration commands to attitude commands:
- Converts from velocity frame to trim frame
- Generates feedforward angular velocity commands
- Handles special cases for takeoff and landing

## 5. Flight Control Components

The flight control components execute the trajectory commands and maintain vehicle stability:

### 5.1 State Estimation

#### 5.1.1 State Estimator Processor (SEP)

The SEP provides critical state information by:
- Processing raw sensor data from IMUs, GPS, and air data sensors
- Performing coordinate transformations between reference frames
- Filtering acceleration, velocity, and angular rate data
- Computing air data parameters (dynamic pressure, density, airspeed)

Key outputs include:
- Filtered acceleration in VTOL NCG frame
- Quaternion orientation estimates
- Filtered angular rates
- Velocity estimates in NED frame
- Air data parameters (density, dynamic pressure)
- Position estimates (latitude, longitude, altitude)
- Airspeed estimates (true and equivalent)

### 5.2 Controller Objects

#### 5.2.1 Controller Hierarchy

The controller system is organized as a hierarchical structure:
1. **Controllers_object**: Base class providing controller interface
2. **Controller_object_wrapper**: Wrapper for controller execution
3. **Recovery_wrapper_control_system_object**: Extension for recovery scenarios

#### 5.2.2 Controller Manager (CM)

The Controller Manager coordinates controller modes and commands:
- Determines controller modes based on rotor health status
- Manages takeoff and landing operations
- Controls integrator modes
- Handles position and velocity commands

#### 5.2.3 Attitude Stability Controller (ASC)

The ASC stabilizes vehicle attitude:
- Computes attitude error between commanded and estimated orientation
- Generates angular acceleration commands to correct attitude errors
- Provides feedforward control for improved tracking
- Applies integrators for steady-state error elimination

### 5.3 Mixer System

#### 5.3.1 Mixer Allocator

The `Mixer_allocator` converts force and moment commands to actuator commands:
- Takes wrench requests (forces and moments) in the vehicle frame
- Converts these requests to actuator commands (rotor speeds in krpm²)
- Handles actuator constraints and failures
- Implements prioritization schemes for wrench components

#### 5.3.2 Allocation Process

The allocation process follows these steps:
1. Receive wrench requests in the vehicle frame
2. Transform requests to the allocation frame
3. Apply prioritization scheme (hard or soft)
4. Solve the constrained optimization problem
5. Apply hysteresis to prevent oscillations
6. Output actuator commands and predicted achievable wrench

#### 5.3.3 Prioritization Schemes

Two main prioritization schemes:
1. **Hard Prioritization**: Enforces strict hierarchy of wrench components
2. **Soft Prioritization**: Uses weighted optimization to balance all components

## 6. Flight Phases and Control Strategies

The system manages four distinct flight phases with specific control strategies:

### 6.1 VTOL (Vertical Take-Off and Landing)

During VTOL phase:
- TCG uses GROUNDSPEED tracking mode
- TTCG generates vertical or hover trajectories
- ATCG uses VTOL-specific attitude generation with weathervaning
- Position control prioritizes vertical stability
- Mixer uses VTOL-specific allocation priorities

### 6.2 Outbound Transition (VTOL to WBF)

During outbound transition:
- Vehicle accelerates from hover to wing-borne flight
- TTCG generates three-phase acceleration profile
- ATCG blends between VTOL and WBF attitudes based on airspeed
- TSC uses GROUNDSPEED tracking mode
- Mixer gradually shifts from VTOL to WBF allocation priorities

### 6.3 Wing-Borne Flight (WBF)

During WBF phase:
- TCG typically uses AIRSPEED tracking mode
- TTCG follows route waypoints with spline interpolation
- ATCG uses WBF-specific attitude generation aligned with air-relative velocity
- TSC optimizes for efficient forward flight
- Mixer uses WBF-specific allocation priorities

### 6.4 Inbound Transition (WBF to VTOL)

During inbound transition:
- Vehicle decelerates from wing-borne flight to hover
- TTCG manages high-speed and low-speed deceleration phases
- ATCG gradually transitions from WBF to VTOL attitude control
- TSC uses GROUNDSPEED tracking mode
- Mixer gradually shifts from WBF to VTOL allocation priorities

## 7. Reference Frame Transformations

The system uses multiple reference frames with transformations between them:

### 7.1 Key Reference Frames
- **NED (North-East-Down)**: Global reference frame
- **VF (Vehicle Frame)**: Aligned with vehicle body
- **VTOLNCG**: VTOL navigation control frame
- **BUL (Body frame)**: Body-up-left frame
- **NCG (Nominal Center of Gravity)**: Frame at nominal CG
- **TRIM0NCG**: Trim navigation control frame (zero trim)
- **VEL**: Velocity-aligned frame
- **POS**: Position-aligned frame
- **GRTRAJ**: Gravity-compensated trajectory frame

### 7.2 Frame Transformation Flow
```
Sensors → NED → VEL → POS → GRTRAJ → TRIM0NCG → Actuator Commands
```

## 8. Control Flow and Data Paths

The control flow through the system follows this sequence:

### 8.1 Mission Planning to State Machines
1. Mission plan is processed by Recovery Mission Data Processor
2. Routes and maneuvers are extracted from mission plan
3. State machines determine appropriate controller mode based on mission phase
4. Controller mode and route information are passed to trajectory generation

### 8.2 State Machines to Trajectory Generation
1. State machines determine controller mode and gain type
2. Trajectory Command Generator receives route and controller mode
3. TCG selects appropriate trajectory generation strategy based on flight phase
4. TTCG generates position, velocity, and acceleration references
5. TSC generates corrective acceleration commands based on tracking errors

### 8.3 Trajectory Generation to Flight Control
1. ATCG generates attitude references based on trajectory information
2. AACG transforms acceleration commands to attitude commands
3. ASC generates angular acceleration commands based on attitude errors
4. Controller Manager coordinates controller outputs based on mode

### 8.4 Flight Control to Mixer
1. Controller generates force and moment requests (wrench)
2. Mixer allocator converts wrench to actuator commands
3. Actuator commands are sent to motors
4. Mixer provides feedback on achievable wrench

### 8.5 Sensor Data to State Estimation
1. IMU data (accelerations, angular rates) is processed
2. GPS data (position, velocity) is incorporated
3. Air data (pressure, temperature) is processed
4. SEP generates comprehensive state estimate
5. State estimate is provided to controllers and trajectory generators

## 9. Fault Tolerance and Degraded Operation

The system implements several mechanisms for fault tolerance:

### 9.1 Rotor Health Monitoring
- Detects and responds to rotor failures
- Adjusts control strategy based on number of inoperative rotors
- Transitions to appropriate degraded controller mode

### 9.2 Return Home Contingency Plan (RHCP)
- Maintains RHCP data to handle contingencies
- Maps nominal maneuver IDs to RHCP route IDs
- Enables smooth transition to return home route if needed

### 9.3 Mixer Adaptation
- Redistributes commands to remaining actuators when failures occur
- Provides feedback on achievable wrench to controllers
- Implements hysteresis to prevent oscillations near constraints

### 9.4 State Machine Contingencies
- Automatically transitions to ground modes when on-ground state is detected
- Prevents unsafe mode transitions at low altitudes
- Manages timeouts in critical phases

## 10. Key Algorithms

### 10.1 Constrained Quadratic Programming (CQP)
Used by the mixer for optimal control allocation:
```cpp
class Cqp {
public:
    struct Results {
        enum Status {
            success,
            infeasible,
            max_iterations_reached
        };
        
        Status status;
        R64vector solution;
        Base::Array<Constraint> active_set;
    };
    
    void step();
    const Results& get_out() const;
};
```

### 10.2 Quaternion-Based Attitude Control
Used by the ASC for attitude stabilization:
```cpp
// Quaternion error computation
Base::Rv4 q_error = quaternion_multiply(q_cmd_trim0ncg_from_ned, 
                                       quaternion_inverse(q_est_trim0ncg_from_ned));

// Angular acceleration command generation
w_dot_cmd = Kp * q_error.vector() + Kd * (w_cmd - w_est) + Ki * integral_term;
```

### 10.3 Trajectory Polynomials
Used by the TTCG for smooth transitions:
```cpp
void Polynomial::construct_trajectory_polynomial(const Base::Rv4& si, 
                                               const Base::Rv4& sf, 
                                               Real ts) {
    // si: Initial state [position, velocity, acceleration, jerk]
    // sf: Final state
    // ts: Time span
    // Constructs polynomial coefficients for smooth interpolation
}
```

### 10.4 Switch Blending
Used for smooth transitions between control signals:
```cpp
class Switch_blender {
public:
    // Blending modes
    struct Blending_mode { enum Type { ONE_SIDED, TWO_SIDED }; };
    struct Interpolation_mode { enum Type { LINEAR, SMOOTH }; };
    struct Limiting_mode { enum Type { TIME_LIMITED, RATE_LIMITED }; };
    struct Angle_wrapping_mode { enum Type { DISABLED, ENABLED }; };
    
    // Methods
    Real run(const Maverick::Rvector& input_signals, const Uint16 selected_signal_index);
};
```

## 11. System Diagram

```
┌─────────────────────────────────────────────────────────────────────────┐
│                           Mission Planning                              │
│                                                                         │
│  ┌───────────────────┐  ┌───────────────────┐  ┌───────────────────┐    │
│  │   Initial Plan    │  │  Alternate Plans  │  │ Environment Data  │    │
│  └─────────┬─────────┘  └─────────┬─────────┘  └─────────┬─────────┘    │
└───────────────────────────────────┼───────────────────────────────────┘
                                    │
                                    ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                           State Machines                                │
│                                                                         │
│  ┌───────────────────┐  ┌───────────────────┐  ┌───────────────────┐    │
│  │ Controller Mode   │  │  Takeoff/Land SM  │  │ Degradation Level │    │
│  └─────────┬─────────┘  └─────────┬─────────┘  └─────────┬─────────┘    │
└───────────────────────────────────┼───────────────────────────────────┘
                                    │
                                    ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                        Trajectory Generation                            │
│                                                                         │
│  ┌───────────────┐     ┌───────────────┐     ┌───────────────┐          │
│  │      TCG      │────▶│     TTCG      │────▶│      TSC      │          │
│  └───────────────┘     └───────────────┘     └───────┬───────┘          │
│                                                      │                   │
│  ┌───────────────┐     ┌───────────────┐            │                   │
│  │     AACG      │◀────│     ATCG      │◀───────────┘                   │
│  └───────┬───────┘     └───────────────┘                                │
└──────────┼──────────────────────────────────────────────────────────────┘
           │
           ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                        Flight Control Components                        │
│                                                                         │
│  ┌───────────────┐     ┌───────────────┐     ┌───────────────┐          │
│  │      SEP      │────▶│ Controller Mgr│────▶│      ASC      │          │
│  └───────┬───────┘     └───────────────┘     └───────┬───────┘          │
│          │                                           │                   │
│          │             ┌───────────────┐             │                   │
│          └────────────▶│ Mixer System  │◀────────────┘                   │
│                        └───────┬───────┘                                │
└────────────────────────────────┼──────────────────────────────────────────┘
                                 │
                                 ▼
                         Actuator Commands
```

## 12. Conclusion

The drone control system architecture represents a sophisticated multi-layered approach to autonomous flight control. The system's strength lies in its modular design with well-defined interfaces between components, enabling complex behaviors while maintaining stability across different flight regimes.

Key architectural features include:
1. Hierarchical structure from high-level mission planning to low-level actuator commands
2. State machine-based mode management for different flight phases
3. Advanced trajectory generation with specialized handling for each flight regime
4. Comprehensive flight control with attitude stabilization and force allocation
5. Robust fault tolerance with degraded operation capabilities

This architecture enables the drone to execute complex missions autonomously while adapting to changing conditions and handling component failures. The integration between mission planning, state machines, trajectory generation, and flight control creates a cohesive system capable of stable flight across the entire flight envelope from vertical takeoff to wing-borne flight and back to vertical landing.