# Generated from:

- _sw_Veronte/code/vpgnc/code/include/Event.h (2190 tokens)
- _sw_Veronte/code/vpgnc/code/source/Event.cpp (3529 tokens)
- _sw_Veronte/code/vpgnc/code/include/Event_fw.h (23 tokens)
- _sw_Veronte/code/vpgnc/code/include/Evtmgr.h (1864 tokens)
- _sw_Veronte/code/vpgnc/code/source/Evtmgr.cpp (6810 tokens)
- _sw_Veronte/code/vpgnc/code/include/Event_inside_checker.h (347 tokens)
- _sw_Veronte/code/vpgnc/code/source/Event_inside_checker_amz.cpp (290 tokens)
- _sw_Veronte/code/vpgnc/code/source/Event_inside_checker_ver.cpp (2111 tokens)
- _sw_Veronte/code/vpgnc/code/include/Event_inside_checker_fw.h (32 tokens)
- _sw_Veronte/code/vpgnc/code/include/Evt_wp_groups.h (471 tokens)
- _sw_Veronte/code/vpgnc/code/source/Evt_wp_groups.cpp (353 tokens)
- _sw_Veronte/code/vpgnc/code/include/Evt_wp_groups_fw.h (27 tokens)
- _sw_Veronte/code/vpgnc/code/include/Def_contingency.h (447 tokens)
- _sw_Veronte/code/vpgnc/code/source/Def_contingency.cpp (1008 tokens)
- _sw_Veronte/code/vpgnc/code/include/Def_contingency_data.h (379 tokens)
- _sw_Veronte/code/vpgnc/code/source/Def_contingency_data.cpp (65 tokens)
- _sw_Veronte/code/vpgnc/code/include/Stanag_msg_event_fw.h (30 tokens)
- _sw_Veronte/code/vpgnc/code/include/Envelope.h (1866 tokens)
- _sw_Veronte/code/vpgnc/code/source/Envelope.cpp (505 tokens)
- _sw_Veronte/code/vpgnc/code/include/Envelope_fw.h (24 tokens)

## With context from:

- PackageSummaries/Embention/Amazon-PrimeAir/items/ASTRO/items/sw/sw_Astro/items/06_VPGNC_Core.md (7671 tokens)
- PackageSummaries/Embention/Amazon-PrimeAir/items/ASTRO/items/sw/sw_Astro/items/03_VPGNC_Waypoints.md (13880 tokens)

---

# Comprehensive Analysis of the Event System in VPGNC Framework

This document provides a detailed analysis of the event detection, triggering, and management system in the VPGNC framework, focusing on how events are defined, detected, processed, and used for contingency management.

## 1. Event Class: Individual Event Detection

The `Event` class is the fundamental building block of the event system, responsible for detecting and triggering individual events based on configured conditions.

### 1.1 Core Components and Structure

```cpp
class Event {
public:
    // Input structure for step function
    struct Input {
        const Vlimits& lim;                     // Reference to configured limits
        const Base::Uclkmgr& uclk;              // Reference to user configured timers
        Imarks& rmarks;                         // Reference to route marks event manager
        Evt_wp_groups& wp_groups;               // Reference to waypoint flying event manager
        Base::Message_received_hnd& msg_event;  // Reference to message receiver manager
        
        // Constructor
        Input(const Vlimits& lim0, const Base::Uclkmgr& uclk0, Imarks& rmarks0,
              Evt_wp_groups& wp_groups0, Base::Message_received_hnd& msg_event0);
    };

private:
    Base::Eventout0 eout;                   // Next event status to publish
    Base::Event_type::Type type;            // Type of event
    Real duration;                          // Minimum time to consider to be true
    Base::Fid idx;                          // Fid (used by polygon events)
    Base::Event_type::Idx_type indexes;     // Indexes of Vlimits, events, codes, etc.
    Base::Chrono detected;                  // Time at which the event occurred
    Uint16 wphm_last;                       // Last waypoint, phase or mode
};
```

### 1.2 Event Types

The `Event` class supports multiple event types, each with specific detection logic:

1. **User Events (`user`)**: Manually triggered events via telecommands
2. **Waypoint Events**:
   - `patch_achieved`: Triggered when specific waypoints are reached
   - `patch_selected`: Triggered when specific waypoints are selected for navigation
3. **System State Events**:
   - `phase`: Triggered when the system enters specific phases
   - `mode`: Triggered when the system enters specific modes
4. **Variable Limit Events**:
   - `wrapper_inside`: Triggered when variables are inside configured limits
   - `wrapper_outside`: Triggered when variables are outside configured limits
5. **System Bit Events**:
   - `bit_codes_all_ok`: Triggered when all configured system bits are true
   - `bit_codes_fail_1`: Triggered when at least one configured system bit is false
6. **Polygon Events**:
   - `poly_inside`: Triggered when the vehicle is inside configured polygons
   - `poly_outside`: Triggered when the vehicle is outside configured polygons
7. **Timer Events (`timer`)**: Triggered when configured timers expire
8. **Message Events**:
   - `stanag_msg_rvd`: Triggered when specific STANAG messages are received
   - `fu8_msg_rvd`: Triggered when specific FU8 messages are received
   - `cyphal_msg_rvd`: Triggered when specific Cyphal messages are received

### 1.3 Event Detection Process

The `Event::step()` method implements the core event detection logic:

```cpp
void Event::step(Input& in) {
    switch (type) {
        case Event_type::user:
            // User events are handled separately via trigger_usr()
            eout.set(false);
            break;
        case Event_type::patch_achieved:
            step_achieved(in.rmarks);
            break;
        case Event_type::patch_selected:
            step_wp(in.wp_groups);
            break;
        case Event_type::phase:
            step_uvar(vu_phase);
            break;
        case Event_type::mode:
            step_uvar(vu_mode);
            break;
        case Event_type::wrapper_inside:
            step_wrapper(in.lim, true); // true => inside
            break;
        case Event_type::wrapper_outside:
            step_wrapper(in.lim, false); // false => outside
            break;
        case Event_type::bit_codes_all_ok:
            step_kbit_allok(false); // false => do not invert
            break;
        case Event_type::bit_codes_fail_1:
            step_kbit_allok(true); // true => invert
            break;
        case Event_type::poly_outside: // Fall-through
        case Event_type::poly_inside:
            // Managed from outside by Event_inside_checker
            break;
        case Event_type::timer:
            step_timer(in.uclk);
            break;
        case Event_type::stanag_msg_rvd:
        case Event_type::fu8_msg_rvd:
        case Event_type::cyphal_msg_rvd:
            step_rcv_msg(in.msg_event);
            break;
        default:
            Bsp::warning();
            break;
    }
}
```

### 1.4 Event Duration Management

The `Event` class implements a duration mechanism to prevent false triggers from transient conditions:

```cpp
void Event::compute_duration(const bool result_t0) {
    bool cond_next = false;
    if(result_t0) {
        // If the condition is true, start or continue the timer
        if(!detected.ongoing()) {
            detected.tic();
        }
        // Check if the condition has been true for the required duration
        cond_next = (detected.toc() >= duration);
    } else {
        // If the condition is false, cancel the timer
        detected.cancel();
    }
    // Set the event output state
    eout.set(cond_next);
}
```

This ensures that an event is only triggered if its condition remains true for at least the configured duration.

### 1.5 Event Type-Specific Detection Methods

#### 1.5.1 Waypoint Achievement Events

```cpp
void Event::step_achieved(Imarks& rmarks) {
    compute_duration(rmarks.mark_event(indexes.to_mblock()));
}
```

Checks if any of the configured waypoints have been reached.

#### 1.5.2 Waypoint Selection Events

```cpp
void Event::step_wp(const Evt_wp_groups& wp_groups) {
    static Bsp::Huvar hwp(vu_tpselected);
    const Uint16 wphm = hwp.get();
    bool result_t0 = false;
    
    // Check if the current waypoint matches any in the configured groups
    const Uint16* const wphm_list_end = indexes.last();
    for(const Uint16* wphm_list = indexes.first(); 
        (wphm_list <= wphm_list_end) && (!result_t0); ++wphm_list) {
        if(wp_groups.matches(*wphm_list, wphm)) {
            result_t0 = true;
            if(wphm != wphm_last) {
                // Reset when waypoint changes
                reset();
            }
        }
    }
    
    wphm_last = wphm;
    compute_duration(result_t0);
}
```

Checks if the currently selected waypoint is in any of the configured waypoint groups.

#### 1.5.3 System Variable Events

```cpp
void Event::step_uvar(const Uvar id) {
    bool result_t0 = false;
    const Uint16 wphm = Bsp::Huvar(id).get();
    
    // Check if the current value matches any configured value
    const Uint16* const wphm_list_end = indexes.last();
    for(const Uint16* wphm_list = indexes.first(); 
        (wphm_list <= wphm_list_end) && (!result_t0); ++wphm_list) {
        if(wphm == *wphm_list) {
            result_t0 = true;
            if(wphm != wphm_last) {
                // Reset when phase or mode changes
                reset();
            }
        }
    }
    
    wphm_last = wphm;
    compute_duration(result_t0);
}
```

Checks if a system variable (phase or mode) matches any of the configured values.

#### 1.5.4 Variable Limit Events

```cpp
void Event::step_wrapper(const Vlimits& limits, const bool inside) {
    if(indexes.size() > 0) {
        // Check if variables are inside or outside limits
        const bool in = limits.is_inside(indexes);
        compute_duration(inside == in);
    } else {
        compute_duration(false);
    }
}
```

Checks if variables are inside or outside their configured limits.

#### 1.5.5 System Bit Events

```cpp
void Event::step_kbit_allok(const bool invert) {
    bool all_ok = true;
    const Uint16* const bcode_end = indexes.last();
    
    // Check if all system bits are true
    for(const Uint16* bcode = indexes.first(); (bcode <= bcode_end) && all_ok; ++bcode) {
        if(!Bsp::Hbvar(static_cast<Bvar>(*bcode)).get()) {
            all_ok = false;
        }
    }
    
    // Invert logic for bit_codes_fail_1
    compute_duration(invert != all_ok);
}
```

Checks if all configured system bits are true or if at least one is false.

#### 1.5.6 Timer Events

```cpp
void Event::step_timer(const Uclkmgr& uclk) {
    bool result_t0 = false;
    const Uint16* const clk_id_end = indexes.last();
    
    // Check if any timer has expired
    for(const Uint16* clk_id = indexes.first(); 
        (clk_id <= clk_id_end) && (!result_t0); ++clk_id) {
        if(uclk.timer_event(*clk_id)) {
            result_t0 = true;
        }
    }
    
    compute_duration(result_t0);
}
```

Checks if any of the configured timers have expired.

#### 1.5.7 Message Events

```cpp
void Event::step_rcv_msg(Base::Message_received_hnd& msg) {
    if(msg.step(indexes, wphm_last, type)) {
        eout.set_and_clear();
    }
}
```

Checks if specific messages have been received.

### 1.6 Event Configuration

Events are configured through a PDI (Persistent Data Interface) with the following structure:

```
|Type                |Name    |Comment                                                |Range           |
|--------------------|--------|-------------------------------------------------------|----------------|
|Uint16              |type    |Type of event                                          |See below       |
|Real                |duration|Time that this event has to be true to trigger [s]     |>= 0            |
|Uint16              |idx     |Feature index used for polygon events                  |Valid Fid       |
|Array<Uint16,Uint16>|indexes |List of indexes with meaning depending on event type   |Up to 32 indexes|
```

The `Event::cset()` method deserializes this configuration:

```cpp
void Event::cset(Lossy_error& str) {
    str.get_enum16(type);
    str.get_float(duration);
    str.get_enum16(idx);
    Tuntraits::Tundefault<Event_type::Idx_type>::str2elem(indexes, str);
    reset();
    
    // Validate configuration
    str.assrt((type > 0) &&
              (type < Event_type::max_type) &&
              (type != Event_type::invalid_type8) &&
              (((type != Event_type::poly_inside) && 
                (type != Event_type::poly_outside)) || Jfid::validate0(idx)) &&
              (duration >= 0), err_events);
}
```

## 2. Evtmgr Class: Event Management System

The `Evtmgr` class manages the collection of events, their execution, and their interaction with other system components.

### 2.1 Core Components and Structure

```cpp
class Evtmgr : public Base::Ideserializable, public Stanag::Stanag_msg {
private:
    Base::Xcpktwr& xpw;            // Cross core packet writer
    Event_inside_checker& poly;    // Inside/outside polygon event checker
    State st;                      // Current execution state
    Base::Uclkmgr uclk;            // User timers
    Vlimits limits;                // Variable limits for events
    Base::Tunarray<Event> events;  // Set of events
    Evhilo& evhl;                  // High and low priority events
    Uint16 evlo_idx;               // Next low priority event index to process
    Uint16 evlo_grp_sz;            // Number of low priority events per step
    volatile Base::Eventout& eout; // Published events status
    Uevtcmd ucmd;                  // User event command data
    bool& events_ready;            // Events have been evaluated at least once
    Evt_wp_groups wp_groups;       // Event waypoint groups
    Event::Input evt_input;        // Input for events step
    
    // Polygon event management
    static const Uint16 max_poly_evts = 60U;
    Base::Tnarrayresz<Uint16, max_poly_evts> poly_evts;
    Uint16 curr_poly_evt;
    
    Base::Message_received_hnd msg_received;  // Message event handler
};
```

### 2.2 Event Execution States

The `Evtmgr` class implements a state machine to distribute event processing across multiple execution cycles:

```cpp
enum State {
    st_marks,    // Process route marks
    st_uclk,     // Process user timers
    st_evstep,   // Process events
    st_evcommit, // Commit event states
};
```

### 2.3 Event Priority Management

The `Evtmgr` class divides events into high and low priority categories:

```cpp
static bool is_evhi(const Event& e) {
    bool result = false;
    switch(e.get_type()) {
        case Event_type::wrapper_inside:
        case Event_type::wrapper_outside:
        case Event_type::bit_codes_all_ok:
        case Event_type::bit_codes_fail_1:
            static const Real duration_hi = 0.15F;
            result = e.get_duration() <= duration_hi;
            break;
        default:
            break;
    }
    return result;
}
```

High priority events are:
1. Variable limit events (`wrapper_inside`, `wrapper_outside`)
2. System bit events (`bit_codes_all_ok`, `bit_codes_fail_1`)
3. Events with a duration less than or equal to 0.15 seconds

The `Evhilo` class manages the separation of events into high and low priority queues:

```cpp
class Evtmgr::Evhilo {
private:
    static const Uint16 sz = events_sz;
    static const Uint16 lo_imax = sz-1;
    Tnarray<Uint16,sz> hl_array;
    Uint16 hsz;  // High priority events count
    Uint16 lsz;  // Low priority events count
    
public:
    void hadd(Uint16 value);  // Add high priority event
    void ladd(Uint16 value);  // Add low priority event
    Uint16 hget(Uint16 i) const;  // Get high priority event
    Uint16 lget(Uint16 i) const;  // Get low priority event
    Uint16 hsize() const;  // Get high priority events count
    Uint16 lsize() const;  // Get low priority events count
};
```

### 2.4 Event Processing Workflow

The `Evtmgr::step()` method implements the main event processing workflow:

```cpp
void Evtmgr::step() {
    switch (st) {
        case st_marks:
            // Process route marks
            evt_input.rmarks.step();
            evhi_step();
            evhi_commit();
            st = st_uclk;
            break;
            
        case st_uclk:
            // Process user timers
            uclk.step();
            evhi_step();
            evhi_commit();
            st = st_evstep;
            break;
            
        case st_evstep:
            // Process low priority events
            const Uint16 evlo_idx_nxt = evlo_idx + evlo_grp_sz;
            const Uint16 evlo_sz = evhl.lsize();
            
            if(evlo_idx_nxt < evlo_sz) {
                evlo_step(evlo_idx_nxt);
            } else {
                evlo_step(evlo_sz);
                evlo_idx = 0;
                st = st_evcommit;
            }
            
            evhi_step();
            evhi_commit();
            break;
            
        case st_evcommit:
            // Commit all event states
            evhi_step();
            
            for(Uint16 i = 0; i < events_sz; ++i) {
                eout[i].copy(events[i].get_eout());
            }
            
            st = st_marks;
            events_ready = true;
            break;
    }
}
```

This state machine ensures that:
1. High priority events are checked in every state
2. Low priority events are distributed across multiple execution cycles
3. Event states are committed to the system after all events have been processed

### 2.5 High and Low Priority Event Processing

The `Evtmgr` class implements separate methods for processing high and low priority events:

```cpp
void Evtmgr::evhi_step() {
    const Uint16 sz = evhl.hsize();
    for(Uint16 i = 0; i < sz; ++i) {
        events[evhl.hget(i)].step(evt_input);
    }
    step_inside();
}

void Evtmgr::evlo_step(const Uint16 to_excluded) {
    while(evlo_idx < to_excluded) {
        events[evhl.lget(evlo_idx)].step(evt_input);
        ++evlo_idx;
    }
}

void Evtmgr::evhi_commit() {
    const Uint16 sz = evhl.hsize();
    for(Uint16 i = 0; i < sz; ++i) {
        Uint16 j = evhl.hget(i);
        eout[j].copy(events[j].get_eout());
    }
}
```

### 2.6 Polygon Event Processing

The `Evtmgr` class implements special handling for polygon events:

```cpp
void Evtmgr::step_inside() {
    if (poly_evts.size() > 0) {
        if (poly.step_task()) {
            curr_poly_evt = (curr_poly_evt + 1U) % static_cast<Uint16>(poly_evts.size());
            poly.init(events[poly_evts[curr_poly_evt]]);
        }
    }
}
```

This method:
1. Checks if there are any polygon events
2. Processes one polygon event per step
3. Rotates through all polygon events over time

### 2.7 Event Configuration and Initialization

The `Evtmgr::cset()` method deserializes the event configuration and initializes the event system:

```cpp
void Evtmgr::cset(Lossy_error& str) {
    events.cset(str);
    evhl.clear();
    poly_evts.resize(0U);
    curr_poly_evt = 0;
    
    for (Uint16 i = 0U; i < events_sz; ++i) {
        if (events.is_enabled(i)) {
            // Add to high or low priority queue
            is_evhi(events[i]) ? evhl.hadd(i) : evhl.ladd(i);
            
            // Handle polygon events
            if (((events[i].get_type() == Event_type::poly_inside) ||
                 (events[i].get_type() == Event_type::poly_outside)) &&
                str.assrt(poly_evts.size() < poly_evts.size_max(), err_max_poly_evt)) {
                
                if (poly_evts.size() == 0) {
                    str.assrt(poly.init(events[i]), err_inside_evt_impl);
                }
                
                poly_evts[poly_evts.size()] = i;
                poly_evts.resize(poly_evts.size() + 1U);
            }
        } else {
            // Reset disabled events
            events[i].reset();
        }
    }
    
    // Calculate low priority events group size
    evlo_grp_sz = (evhl.lsize() + (evlo_ngroups - 1U))/evlo_ngroups;
}
```

This method:
1. Deserializes the event configuration
2. Clears existing event queues
3. Categorizes events as high or low priority
4. Identifies and initializes polygon events
5. Calculates the number of low priority events to process per step

### 2.8 User Event Command Processing

The `Evtmgr` class implements methods to handle user event commands:

```cpp
Msg_data::Ack_type Evtmgr::on_rx(Stanag::IStanag_msg_rx::Rx_params& push_p) {
    Data_mutator<Lossy::Mutator_traits8<>, U8istream::Data_traits8> mutator(push_p.is);
    Lossy& str(mutator.m);
    
    Uint16 arg = 0;
    str.get_enum16(arg);
    
    static const Uint16 amx_command_arg = 0x0U;  // User event command
    if (arg == amx_command_arg) {
        Uint16 evt = 0;
        str.get_uint16(evt);
        Uint32 usr_rx_id = 0;
        str.get_uint32(usr_rx_id);
        
        const bool enabled = events.is_enabled(evt);
        const bool is_user = (events[evt].get_type() == Event_type::user);
        const bool has_license = Ver::Hlicense::get_kpermissions().has(Permission::permission_rtc);
        
        if (usr_rx_id != ucmd.message_id) { // avoid processing duplicate messages
            ucmd.message_id = usr_rx_id;
            if(enabled && is_user && has_license) {
                events[evt].trigger_usr();
            }
        }
        
        // Send acknowledgment
        ucmd.response.reuse();
        ucmd.response.put_uint16(evt);
        ucmd.response.put_uint32(ucmd.message_id);
        ucmd.response.put_bool16(enabled);
        ucmd.response.put_bool16(is_user);
        ucmd.response.put_bool16(has_license);
        
        static const Uint16 amx_ack_arg = 0x1U;
        push_p.msg_sender.send(Msg_data(push_p.hdr.get_src(),
                                        Stanag_msg_type::stg_event,
                                        amx_ack_arg));
    }
    
    return Msg_data::received;
}
```

This method:
1. Parses the user event command
2. Validates the event (enabled, user type, has license)
3. Triggers the event if valid
4. Sends an acknowledgment with the event status

## 3. Event_inside_checker Class: Polygon-Based Event Detection

The `Event_inside_checker` class implements polygon-based event detection, checking if the vehicle is inside or outside configured polygons.

### 3.1 Core Components and Structure

```cpp
class Event_inside_checker {
public:
    bool init(Event& event0);
    bool step_task();
    
private:
    struct Data {
        Geo::Polymgr::Inside_checker poly_check;  // Helper to check position inside polygon
        Uint16 idx;                               // Current index being checked
        Geo::Fidposcache pos;                     // Position of the given Fid
        Event* evt;                               // Event being checked
    };
    
    Data& data;
};
```

### 3.2 Initialization Process

The `Event_inside_checker::init()` method initializes the polygon checker for a specific event:

```cpp
bool Event_inside_checker::init(Event& event0) {
    data.idx = 0U;
    data.pos.set(event0.idx);
    data.pos.refresh();
    
    if (event0.indexes.size() > 0) {
        data.poly_check.init(data.pos.get_pos(), event0.indexes[data.idx]);
    }
    
    data.evt = &event0;
    return true;
}
```

This method:
1. Sets the position to check (from the event's `idx` field)
2. Initializes the polygon checker with the first polygon group
3. Stores a reference to the event

### 3.3 Polygon Checking Process

The `Event_inside_checker::step_task()` method implements the polygon checking process:

```cpp
bool Event_inside_checker::step_task() {
    bool ret = false;
    const Uint16 indexes_sz = static_cast<Uint16>(data.evt->indexes.size());
    
    if (indexes_sz > 0U) {
        if (data.poly_check.step_task()) {
            ++data.idx;
            ret = (data.poly_check.is_inside() || (data.idx >= indexes_sz));
            
            if (ret) {
                data.evt->compute_duration(
                    (data.evt->type == Base::Event_type::poly_inside) == data.poly_check.is_inside());
            } else {
                data.poly_check.init(data.pos.get_pos(), data.evt->indexes[data.idx]);
            }
        }
    } else {
        ret = true;
        data.evt->compute_duration(false);
    }
    
    return ret;
}
```

This method:
1. Checks if the position is inside or outside the current polygon group
2. Moves to the next polygon group if needed
3. Triggers the event if the position is inside/outside all polygon groups
4. Returns `true` when the check is complete

## 4. Evt_wp_groups Class: Waypoint Group Management

The `Evt_wp_groups` class manages groups of waypoints used for waypoint selection events.

### 4.1 Core Components and Structure

```cpp
class Evt_wp_groups : public Base::Ideserializable_async {
private:
    static const Uint16 max_patches_per_group = 8U;
    Base::Tunarray_async<Base::Tdes<Base::Tnarrayresz<Uint16, max_patches_per_group> > > groups;
    
public:
    bool matches(const Uint16 key, const Uint16 expected_val) const;
    Base::Async_sres cset(Base::Lossy_error& str);
};
```

### 4.2 Waypoint Matching

The `Evt_wp_groups::matches()` method checks if a waypoint is in a specific group:

```cpp
bool Evt_wp_groups::matches(const Uint16 key, const Uint16 expected_val) const {
    bool ret = false;
    if (groups.is_enabled(key)) {
        const Uint16* const ez = groups[key].value.last();
        for (const Uint16* ei = groups[key].value.first(); (ei <= ez) && (!ret); ++ei) {
            ret = ((*ei) == expected_val);
        }
    }
    return ret;
}
```

This method:
1. Checks if the specified group is enabled
2. Iterates through all waypoints in the group
3. Returns `true` if the expected waypoint is found in the group

## 5. Contingency System: Event-Based Response

The VPGNC framework includes a contingency system that uses events to trigger responses to specific conditions.

### 5.1 Def_contingency Class: Contingency Definition

The `Def_contingency` class parses STANAG message #13007 to define contingency waypoints:

```cpp
class Def_contingency : public Stanag::Stanag_msg_rx {
private:
    Tpatchset& route;             // Route data
    Base::U8pkmblock route_id;    // Route ID
    Base::U8pkmblock mission_id;  // Mission ID
    
public:
    explicit Def_contingency(Tpatchset& route0);
    virtual Base::Msg_data::Ack_type on_rx(Rx_params& push_p);
};
```

### 5.2 Contingency Data Structure

The `Def_contingency_data` struct defines the data for a contingency:

```cpp
struct Def_contingency_data {
    enum Cond_mod {
        cm_or  = 0,   // Disjunctive Logic (OR)
        cm_and = 1    // Conjunctive Logic (AND)
    };
    
    Uint16 cont_wp;                                               // Contingency Waypoint Number
    Cond_mod cond_mod;                                            // Condition Modifier
    Uint8 n_cond;                                                 // Number of conditions
    Base::U8pkarray<Stanag::Mission_constants::max_contingency_cond> cc;  // Contingency Conditions
    Uint32 activity_id;                                           // Activity ID
    
    bool validate() const;
};
```

### 5.3 Contingency Message Parsing

The `Def_contingency::on_rx()` method parses STANAG message #13007:

```cpp
Base::Msg_data::Ack_type Def_contingency::on_rx(Rx_params& push_p) {
    Base::Msg_data::Ack_type ack = Base::Msg_data::rejected;
    
    Base::Presence_vec pvec(push_p.auth_c.pres_vec_s, Base::Presence_vec::size1);
    pvec.cset(push_p.is);
    
    if (pvec.get(f_timestamp)) {
        push_p.t.cset(push_p.is);
    }
    
    if (pvec.get(f_cont_scope)) {
        const Cont_scope cs = static_cast<Cont_scope>(push_p.is.get_uint8());
        const Uint16 wp_area_id = ((cs == cs_wp) || (cs == cs_area)) ? 
                                  push_p.is.get_uint16_be() : 0U;
        
        bool ok = true;
        if (pvec.get(f_route_mission_id)) {
            if (cs == cs_route) {
                push_p.is.get_u8pkmblock(route_id);
            } else if (cs == cs_mission) {
                push_p.is.get_u8pkmblock(mission_id);
            } else {
                ok = false;
            }
        }
        
        Def_contingency_data dcd;
        dcd.cont_wp = pvec.get(f_cont_wp_number) ? (push_p.is.get_uint16_be() - 1U) : 0U;
        dcd.cond_mod = pvec.get(f_cond_mod) ?
                static_cast<Def_contingency_data::Cond_mod>(push_p.is.get_uint8()) :
                Def_contingency_data::cm_or;
        dcd.n_cond = pvec.get(f_num_cond) ? push_p.is.get_uint8() : 0U;
        
        for (Uint32 i = 0U; i < dcd.n_cond; ++i) {
            const Uint8 u8 = push_p.is.get_uint8();
            if (i < dcd.cc.size()) {
                dcd.cc.set(i, u8);
            }
        }
        
        dcd.activity_id = pvec.get(f_activity_id) ? push_p.is.get_uint24_be() : 0U;
        
        if (ok) {
            switch (cs) {
                case cs_wp:
                    if (route.set_wp_contingency(wp_area_id - 1U, dcd)) {
                        ack = Base::Msg_data::completed;
                    }
                    break;
                case cs_route:
                    // TODO
                    break;
                case cs_mission:
                    // TODO
                    break;
                case cs_area:
                    // TODO
                    break;
                default:
                    break;
            }
        }
    }
    
    return ack;
}
```

This method:
1. Parses the contingency scope (waypoint, route, mission, or area)
2. Parses the contingency data (waypoint, conditions, activity)
3. Sets the contingency in the route

### 5.4 Contingency Validation

The `Def_contingency_data::validate()` method validates the contingency data:

```cpp
bool Def_contingency_data::validate() const {
    return (cont_wp < Stanag::Mission_constants::max_waypoints) &&
           (cond_mod < cm_all) &&
           (n_cond < cc.size());
}
```

This method checks that:
1. The contingency waypoint number is valid
2. The condition modifier is valid
3. The number of conditions is below the limit

## 6. Integration with Flight Envelope Management

The event system integrates with the flight envelope management system through the `Envelope` class, which defines the allowed physical flight limits.

### 6.1 Envelope Class Structure

```cpp
class Envelope {
private:
    bool hovtol;                               // Whether hover on point is enabled
    Base::Wrapper_ref wstall;                  // Wrapper for stall speed limits
    Base::Wrapper_ref wgs;                     // Wrapper for ground speed limits
    Base::Wrapper_ref wvdown;                  // Wrapper for down speed limits
    Base::Wrapper_ref wfpa;                    // Wrapper for flight path angle limits
    Accelimit accenv;                          // Acceleration envelope
    Base::Vref acc_obstacles;                  // Maximum acceleration to avoid obstacles
    
public:
    bool bound_stall(Real& value) const;
    bool bound_ground(Real& value) const;
    bool hover_on_point() const;
    bool bound_vdown(Real& value) const;
    bool bound_fpa(Real& value) const;
    bool bound_accel(const Maverick::Irvector3& vn_prev,
                     const Maverick::Irvector3& an_prev,
                     const Real dt,
                     const Dynamics::Rigidbody& uav,
                     const Real dvwx,
                     Maverick::Irvector3& vn) const;
    Real get_acc_obstacles() const;
    void cset(Base::Lossy_error& str);
    void cget(Base::Lossy& str) const;
};
```

### 6.2 Integration with Event System

The `Envelope` class provides methods that can be used in conjunction with the event system:

1. **Hover Control**: The `hover_on_point()` method determines if hovering is enabled, which can be used by events to trigger hover-related actions.

2. **Limit Checking**: The various `bound_*()` methods check if values are within limits, which can be used by events to detect when the vehicle is approaching or exceeding flight envelope limits.

3. **Obstacle Avoidance**: The `get_acc_obstacles()` method provides the maximum acceleration for obstacle avoidance, which can be used by events to trigger obstacle avoidance maneuvers.

## 7. Event System Data Flow

The event system data flow can be summarized as follows:

```
+----------------+         +----------------+         +----------------+
|    Evtmgr      |-------->|     Event      |-------->| Event Detection|
| (Event Manager)|         | (Individual    |         | (Type-specific |
|                |         |  Event)        |         |  methods)      |
+----------------+         +----------------+         +----------------+
       |                          |                          |
       v                          v                          v
+----------------+         +----------------+         +----------------+
| Event_inside_  |-------->|  Evt_wp_groups |-------->| Contingency    |
| checker        |         | (Waypoint      |         | System         |
| (Polygon Events)|        |  Groups)       |         |                |
+----------------+         +----------------+         +----------------+
```

1. **Event Configuration**:
   - Events are configured through PDIs
   - The `Evtmgr::cset()` method deserializes the configuration
   - Events are categorized as high or low priority

2. **Event Processing**:
   - The `Evtmgr::step()` method implements the main event processing workflow
   - High priority events are processed in every state
   - Low priority events are distributed across multiple execution cycles
   - Polygon events are processed separately

3. **Event Detection**:
   - Each event type has a specific detection method
   - The `Event::step()` method calls the appropriate detection method
   - The `Event::compute_duration()` method ensures events are only triggered after their duration

4. **Event Triggering**:
   - When an event is triggered, its state is set in the `eout` field
   - The `Evtmgr::evhi_commit()` method commits high priority event states
   - The `Evtmgr::step()` method commits all event states in the `st_evcommit` state

5. **Contingency Response**:
   - The `Def_contingency` class defines contingency responses
   - Contingency responses are triggered by events
   - The `Def_contingency_data` struct defines the contingency data

## 8. Key Workflows

### 8.1 Event Detection and Triggering

1. **Event Configuration**:
   - Events are configured through PDIs
   - Each event has a type, duration, and type-specific parameters

2. **Event Detection**:
   - The `Evtmgr::step()` method processes events according to their priority
   - Each event type has a specific detection method
   - The `Event::compute_duration()` method ensures events are only triggered after their duration

3. **Event Triggering**:
   - When an event is triggered, its state is set in the `eout` field
   - The `Evtmgr::evhi_commit()` method commits high priority event states
   - The `Evtmgr::step()` method commits all event states in the `st_evcommit` state

### 8.2 Polygon Event Processing

1. **Polygon Event Configuration**:
   - Polygon events are configured with a feature ID and polygon group indexes
   - The `Evtmgr::cset()` method identifies and initializes polygon events

2. **Polygon Event Detection**:
   - The `Evtmgr::step_inside()` method processes one polygon event per step
   - The `Event_inside_checker::step_task()` method checks if the position is inside or outside polygons
   - The `Event_inside_checker::init()` method initializes the polygon checker for a specific event

3. **Polygon Event Triggering**:
   - When a polygon event is triggered, its state is set in the `eout` field
   - The `Evtmgr::step()` method commits all event states in the `st_evcommit` state

### 8.3 User Event Command Processing

1. **User Event Command Reception**:
   - The `Evtmgr::on_rx()` method receives user event commands
   - Commands include the event index and a message ID

2. **User Event Validation**:
   - The `Evtmgr::on_rx()` method validates the event (enabled, user type, has license)
   - Duplicate messages are detected and ignored

3. **User Event Triggering**:
   - The `Event::trigger_usr()` method triggers the user event
   - The `Evtmgr::on_rx()` method sends an acknowledgment with the event status

### 8.4 Contingency Response

1. **Contingency Definition**:
   - The `Def_contingency::on_rx()` method parses STANAG message #13007
   - The `Def_contingency_data` struct defines the contingency data

2. **Contingency Validation**:
   - The `Def_contingency_data::validate()` method validates the contingency data
   - The `Def_contingency::on_rx()` method checks if the contingency can be set

3. **Contingency Setting**:
   - The `Def_contingency::on_rx()` method sets the contingency in the route
   - The route's `set_wp_contingency()` method associates the contingency with a waypoint

## 9. Summary

The event system in the VPGNC framework provides a comprehensive solution for detecting, triggering, and managing events based on various conditions. The system is built around several key components:

1. **Event Class**: Implements individual event detection based on various conditions, including waypoint achievement, system state, variable limits, system bits, polygons, timers, and messages.

2. **Evtmgr Class**: Manages the collection of events, their execution, and their interaction with other system components. It implements a state machine to distribute event processing across multiple execution cycles and categorizes events as high or low priority.

3. **Event_inside_checker Class**: Implements polygon-based event detection, checking if the vehicle is inside or outside configured polygons.

4. **Evt_wp_groups Class**: Manages groups of waypoints used for waypoint selection events.

5. **Contingency System**: Uses events to trigger responses to specific conditions, such as navigating to a contingency waypoint.

The event system integrates with the flight envelope management system through the `Envelope` class, which defines the allowed physical flight limits. This integration allows the event system to trigger responses based on the vehicle's flight envelope status.

The event system's design allows for efficient processing of events with different priorities, ensuring that critical events are detected and triggered promptly while distributing the processing load across multiple execution cycles.