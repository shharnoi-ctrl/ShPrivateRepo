# Generated from:

- include/gtest/gtest-matchers.h (8266 tokens)
- include/gtest/gtest-death-test.h (3727 tokens)
- include/gtest/gtest-spi.h (3210 tokens)
- include/gtest/gtest-param-test.h (6002 tokens)
- include/gtest/gtest-typed-test.h (3972 tokens)
- include/gtest/gtest-printers.h (10127 tokens)

## With context from:

- Amazon-PrimeAir/items/ASTRO/items/sw/sw_pa_recovery_test/code/googletest/04_GoogleTest_Core_Framework.md (5240 tokens)

---

# Google Test Advanced Features: Comprehensive Analysis

## 1. Matcher Framework

The matcher framework in Google Test provides a powerful and expressive way to validate values in tests. It's implemented in `gtest-matchers.h` and offers a more readable and composable alternative to traditional assertions.

### Core Matcher Architecture

#### `MatcherInterface<T>` Class
```cpp
template <typename T>
class MatcherInterface : public MatcherDescriberInterface {
public:
  // Evaluates the matcher against x, explaining the match result to 'listener'
  virtual bool MatchAndExplain(T x, MatchResultListener* listener) const = 0;

  // Inherited from MatcherDescriberInterface:
  // virtual void DescribeTo(::std::ostream* os) const = 0;
  // virtual void DescribeNegationTo(::std::ostream* os) const;
};
```

This interface defines the core functionality that all matchers must implement:
- `MatchAndExplain()`: Evaluates if a value matches and explains the result
- `DescribeTo()`: Describes what the matcher is looking for
- `DescribeNegationTo()`: Describes what the matcher is not looking for

#### `Matcher<T>` Class
```cpp
template <typename T>
class Matcher : public internal::MatcherBase<T> {
public:
  // Constructs a null matcher (uninitialized)
  explicit Matcher();
  
  // Constructs a matcher from its implementation
  explicit Matcher(const MatcherInterface<const T&>* impl);
  
  // Constructs from any type with is_gtest_matcher trait
  template <typename M>
  Matcher(M&& m);
  
  // Implicit constructor for convenience (e.g., Eq(5))
  Matcher(T value);
};
```

`Matcher<T>` is a copyable, immutable object that wraps a `MatcherInterface<T>` implementation. It provides:
- Various constructors for different matcher sources
- Implicit conversion from values (allowing `EXPECT_THAT(x, 5)` instead of `EXPECT_THAT(x, Eq(5))`)
- Integration with the internal matcher base implementation

#### `MatcherBase<T>` Class
```cpp
template <typename T>
class MatcherBase : private MatcherDescriberInterface {
public:
  // Evaluates the matcher against x and explains the result
  bool MatchAndExplain(const T& x, MatchResultListener* listener) const;
  
  // Returns true if the matcher matches x
  bool Matches(const T& x) const;
  
  // Describes this matcher to an ostream
  void DescribeTo(::std::ostream* os) const override;
  
  // Describes the negation of this matcher
  void DescribeNegationTo(::std::ostream* os) const override;
  
  // Explains why x matches or doesn't match
  void ExplainMatchResultTo(const T& x, ::std::ostream* os) const;
};
```

`MatcherBase<T>` provides the common implementation for all matchers, including:
- Match evaluation and explanation
- Description generation
- Result explanation
- Value storage and polymorphic dispatch

#### `PolymorphicMatcher<Impl>` Class
```cpp
template <class Impl>
class PolymorphicMatcher {
public:
  explicit PolymorphicMatcher(const Impl& an_impl);
  
  // Returns a mutable reference to the implementation
  Impl& mutable_impl();
  
  // Returns an immutable reference to the implementation
  const Impl& impl() const;
  
  // Converts to a Matcher<T> for any type T
  template <typename T>
  operator Matcher<T>() const;
};
```

`PolymorphicMatcher<Impl>` enables the creation of matchers that work with multiple types. It:
- Wraps an implementation object
- Provides conversion to `Matcher<T>` for any type T
- Allows creating generic matchers like `Eq()` that work with many types

### Built-in Matchers

The framework includes several built-in matchers:

#### Comparison Matchers
```cpp
// Equality matchers
template <typename T>
PolymorphicMatcher<internal::EqMatcher<T>> Eq(T x);

// Inequality matchers
template <typename T>
PolymorphicMatcher<internal::NeMatcher<T>> Ne(T x);

// Relational matchers
template <typename T>
PolymorphicMatcher<internal::LtMatcher<T>> Lt(T x);

template <typename T>
PolymorphicMatcher<internal::GtMatcher<T>> Gt(T x);

template <typename T>
PolymorphicMatcher<internal::LeMatcher<T>> Le(T x);

template <typename T>
PolymorphicMatcher<internal::GeMatcher<T>> Ge(T x);
```

These matchers check for equality and ordering relationships between values.

#### String Matchers
```cpp
// Matches a string that fully matches the regex
PolymorphicMatcher<internal::MatchesRegexMatcher> MatchesRegex(const internal::RE* regex);
PolymorphicMatcher<internal::MatchesRegexMatcher> MatchesRegex(const std::string& regex);

// Matches a string that contains the regex
PolymorphicMatcher<internal::MatchesRegexMatcher> ContainsRegex(const internal::RE* regex);
PolymorphicMatcher<internal::MatchesRegexMatcher> ContainsRegex(const std::string& regex);
```

These matchers check if strings match or contain regular expressions.

### Matcher Implementation Details

The matcher framework uses several sophisticated C++ techniques:

1. **Type Erasure**: The `Matcher<T>` class uses type erasure to store and dispatch to different matcher implementations.

2. **Value Storage**: The `MatcherBase<T>` class uses a union and template specialization to efficiently store matcher values either inline (for small types) or on the heap (for larger types).

3. **Polymorphic Dispatch**: The framework uses virtual function tables (`VTable`) to dispatch matcher operations to the appropriate implementation.

4. **SFINAE and Type Traits**: The framework uses SFINAE (Substitution Failure Is Not An Error) and type traits to select the appropriate implementation based on the properties of the types involved.

### Usage Examples

```cpp
// Basic equality matching
EXPECT_THAT(value, Eq(5));

// String matching with regex
EXPECT_THAT(str, MatchesRegex("\\d+"));
EXPECT_THAT(str, ContainsRegex("\\d+"));

// Comparison matchers
EXPECT_THAT(value, Gt(5));
EXPECT_THAT(value, Le(10));

// Combining matchers (requires gmock)
EXPECT_THAT(value, AllOf(Gt(5), Lt(10)));
```

## 2. Death Tests

Death tests allow testing code that is expected to terminate abnormally (e.g., by crashing, exiting, or throwing an uncaught exception). They are implemented in `gtest-death-test.h` and the internal implementation files.

### Core Death Test Architecture

#### Death Test Macros
```cpp
// Tests that statement causes the program to exit with a non-zero exit code
#define ASSERT_DEATH(statement, matcher) \
  ASSERT_EXIT(statement, ::testing::internal::ExitedUnsuccessfully, matcher)

// Tests that statement causes the program to exit with a given exit code
#define ASSERT_EXIT(statement, predicate, matcher) \
  GTEST_DEATH_TEST_(statement, predicate, matcher, GTEST_FATAL_FAILURE_)

// Non-fatal versions
#define EXPECT_DEATH(statement, matcher) \
  EXPECT_EXIT(statement, ::testing::internal::ExitedUnsuccessfully, matcher)

#define EXPECT_EXIT(statement, predicate, matcher) \
  GTEST_DEATH_TEST_(statement, predicate, matcher, GTEST_NONFATAL_FAILURE_)
```

These macros provide the interface for death tests, allowing you to:
- Test that code crashes or exits with a specific exit code
- Verify that error output matches a pattern
- Choose between fatal (`ASSERT_*`) and non-fatal (`EXPECT_*`) failures

#### Death Test Predicates
```cpp
// Tests that an exit code describes a normal exit with a given exit code
class ExitedWithCode {
public:
  explicit ExitedWithCode(int exit_code);
  bool operator()(int exit_status) const;
private:
  const int exit_code_;
};

// Tests that an exit code describes an exit due to a signal
class KilledBySignal {
public:
  explicit KilledBySignal(int signum);
  bool operator()(int exit_status) const;
private:
  const int signum_;
};
```

These predicate classes check the exit status of the child process:
- `ExitedWithCode` checks for a normal exit with a specific code
- `KilledBySignal` checks for termination by a specific signal (not available on Windows)

### Death Test Implementation

Death tests work by:

1. **Fork/Clone**: The test creates a child process to run the potentially crashing code.

2. **Execution Styles**:
   - **"threadsafe"** style: The child process re-executes the test binary from the start, running only the specific death test.
   - **"fast"** style: The child process executes the test logic immediately after forking.

3. **Monitoring**: The parent process waits for the child to terminate and checks:
   - The exit code or signal
   - The error output against the specified matcher

4. **Safety Checks**: Death tests include safety checks:
   - Warning if there's more than one active thread (forking with multiple threads is unsafe)
   - Path validation for the test binary

### Usage Examples

```cpp
// Test that a function crashes
void CrashingFunction() {
  int* null_ptr = nullptr;
  *null_ptr = 42;  // Crash!
}

TEST(DeathTest, CrashingFunctionCrashes) {
  EXPECT_DEATH(CrashingFunction(), "");
}

// Test that a function exits with a specific code
void ExitingFunction() {
  exit(1);
}

TEST(DeathTest, ExitingFunctionExits) {
  EXPECT_EXIT(ExitingFunction(), ::testing::ExitedWithCode(1), "");
}

// Test that a function outputs a specific error message before crashing
void CrashWithMessage() {
  std::cerr << "Fatal error: invalid input" << std::endl;
  abort();
}

TEST(DeathTest, CrashWithMessageOutputsError) {
  EXPECT_DEATH(CrashWithMessage(), "Fatal error: invalid input");
}
```

## 3. Parameterized Tests

Parameterized tests allow running the same test logic with different parameters. They are implemented in `gtest-param-test.h` and related internal files.

### Core Parameterized Test Architecture

#### `TestWithParam<T>` Class
```cpp
template <typename T>
class TestWithParam : public Test, public WithParamInterface<T> {
public:
  // Gets the test parameter
  static const T& GetParam();
};
```

`TestWithParam<T>` is the base class for parameterized tests. It:
- Inherits from `Test` to get the standard test functionality
- Implements `WithParamInterface<T>` to access the current parameter
- Provides `GetParam()` to access the current parameter value

#### Test Registration Macros
```cpp
// Defines a parameterized test
#define TEST_P(test_suite_name, test_name) /* ... */

// Instantiates a test suite with parameters
#define INSTANTIATE_TEST_SUITE_P(prefix, test_suite_name, generator, ...) /* ... */
```

These macros:
- `TEST_P`: Defines a test that will be run with each parameter
- `INSTANTIATE_TEST_SUITE_P`: Creates instances of the test with specific parameters

#### Parameter Generators
```cpp
// Generates values in a range
template <typename T, typename IncrementT>
internal::ParamGenerator<T> Range(T start, T end, IncrementT step);

// Generates values from a container
template <typename Container>
internal::ParamGenerator<typename Container::value_type> ValuesIn(const Container& container);

// Generates values from an explicit list
template <typename... T>
internal::ValueArray<T...> Values(T... v);

// Generates boolean values
inline internal::ParamGenerator<bool> Bool();

// Generates combinations of values from other generators
template <typename... Generator>
internal::CartesianProductHolder<Generator...> Combine(const Generator&... g);
```

These functions create parameter generators that produce values for parameterized tests:
- `Range()`: Generates values in a numeric range
- `ValuesIn()`: Generates values from a container or array
- `Values()`: Generates values from an explicit list
- `Bool()`: Generates `true` and `false`
- `Combine()`: Generates combinations of values from other generators

### Parameterized Test Implementation

Parameterized tests work through:

1. **Test Definition**: `TEST_P` defines a test template that can access the current parameter via `GetParam()`.

2. **Test Instantiation**: `INSTANTIATE_TEST_SUITE_P` creates actual test instances by:
   - Specifying a prefix for the test names
   - Providing a parameter generator
   - Optionally providing a name generator function

3. **Parameter Generation**: The specified generator produces parameter values.

4. **Test Execution**: For each parameter value:
   - A new test instance is created
   - The parameter is set
   - The test is executed with that parameter

### Usage Examples

```cpp
// Simple value parameterization
class ValueParamTest : public ::testing::TestWithParam<int> {};

TEST_P(ValueParamTest, IsPositive) {
  EXPECT_GT(GetParam(), 0);
}

INSTANTIATE_TEST_SUITE_P(
  PositiveValues,
  ValueParamTest,
  ::testing::Values(1, 2, 3, 5, 8, 13)
);

// Parameterization with custom structs
struct TestParams {
  std::string input;
  bool expected_result;
};

class StringParamTest : public ::testing::TestWithParam<TestParams> {};

TEST_P(StringParamTest, IsEmpty) {
  const TestParams& params = GetParam();
  EXPECT_EQ(params.input.empty(), params.expected_result);
}

INSTANTIATE_TEST_SUITE_P(
  StringTests,
  StringParamTest,
  ::testing::Values(
    TestParams{"", true},
    TestParams{"hello", false},
    TestParams{"world", false}
  )
);

// Using Combine for multiple parameters
class PairParamTest : public ::testing::TestWithParam<std::tuple<int, std::string>> {};

TEST_P(PairParamTest, Combine) {
  int num = std::get<0>(GetParam());
  std::string str = std::get<1>(GetParam());
  
  EXPECT_GT(num, 0);
  EXPECT_FALSE(str.empty());
}

INSTANTIATE_TEST_SUITE_P(
  CombinedTests,
  PairParamTest,
  ::testing::Combine(
    ::testing::Values(1, 2, 3),
    ::testing::Values("apple", "banana", "cherry")
  )
);
```

## 4. Typed Tests

Typed tests allow testing with multiple types without duplicating test code. They are implemented in `gtest-typed-test.h`.

### Core Typed Test Architecture

#### Basic Typed Tests
```cpp
// Defines a list of types to test with
typedef ::testing::Types<char, int, unsigned int> MyTypes;

// Associates the type list with a test suite
#define TYPED_TEST_SUITE(CaseName, Types, ...) /* ... */

// Defines a typed test
#define TYPED_TEST(CaseName, TestName) /* ... */
```

These macros:
- `TYPED_TEST_SUITE`: Associates a list of types with a test fixture
- `TYPED_TEST`: Defines a test that will be instantiated for each type

#### Type-Parameterized Tests
```cpp
// Declares a type-parameterized test suite
#define TYPED_TEST_SUITE_P(SuiteName) /* ... */

// Defines a type-parameterized test
#define TYPED_TEST_P(SuiteName, TestName) /* ... */

// Registers all tests in a type-parameterized test suite
#define REGISTER_TYPED_TEST_SUITE_P(SuiteName, ...) /* ... */

// Instantiates a type-parameterized test suite with specific types
#define INSTANTIATE_TYPED_TEST_SUITE_P(Prefix, SuiteName, Types, ...) /* ... */
```

These macros enable more flexible typed testing:
- `TYPED_TEST_SUITE_P`: Declares a type-parameterized test suite
- `TYPED_TEST_P`: Defines a test pattern
- `REGISTER_TYPED_TEST_SUITE_P`: Registers all tests in the suite
- `INSTANTIATE_TYPED_TEST_SUITE_P`: Creates instances with specific types

### Typed Test Implementation

Typed tests work through:

1. **Template Fixture**: You define a template fixture class parameterized by type.

2. **Test Definition**: `TYPED_TEST` defines a test template that can access:
   - The current type as `TypeParam`
   - The fixture type as `TestFixture`

3. **Type Registration**: `TYPED_TEST_SUITE` associates types with the fixture.

4. **Test Instantiation**: The framework instantiates the test for each type.

### Usage Examples

```cpp
// Basic typed tests
template <typename T>
class NumericTest : public ::testing::Test {
protected:
  static const T zero;
  static const T one;
};

template <typename T>
const T NumericTest<T>::zero = 0;

template <typename T>
const T NumericTest<T>::one = 1;

typedef ::testing::Types<int, float, double> NumericTypes;
TYPED_TEST_SUITE(NumericTest, NumericTypes);

TYPED_TEST(NumericTest, IsZeroAdditive) {
  EXPECT_EQ(TypeParam(0) + this->one, this->one);
}

TYPED_TEST(NumericTest, IsOneMultiplicative) {
  EXPECT_EQ(TypeParam(1) * this->zero, this->zero);
}

// Type-parameterized tests
template <typename T>
class ContainerTest : public ::testing::Test {
protected:
  typedef T Container;
  void AddElements(const Container& c) {
    for (const auto& e : c) {
      sum_ += e;
    }
  }
  int sum_ = 0;
};

TYPED_TEST_SUITE_P(ContainerTest);

TYPED_TEST_P(ContainerTest, SumsElements) {
  Container c = {1, 2, 3, 4, 5};
  this->AddElements(c);
  EXPECT_EQ(this->sum_, 15);
}

REGISTER_TYPED_TEST_SUITE_P(ContainerTest, SumsElements);

typedef ::testing::Types<std::vector<int>, std::list<int>, std::deque<int>> ContainerTypes;
INSTANTIATE_TYPED_TEST_SUITE_P(StandardContainers, ContainerTest, ContainerTypes);
```

## 5. Universal Printing Framework

The universal printing framework in `gtest-printers.h` provides a way to print any value for test output and failure messages.

### Core Printing Architecture

#### `UniversalPrinter<T>` Class
```cpp
template <typename T>
class UniversalPrinter {
public:
  static void Print(const T& value, ::std::ostream* os) {
    PrintTo(value, os);
  }
};
```

`UniversalPrinter<T>` is the main entry point for printing values. It:
- Delegates to the appropriate `PrintTo()` function
- Handles special cases through template specialization

#### `PrintTo()` Functions
```cpp
// Default implementation for types without custom printers
template <typename T>
void PrintTo(const T& value, ::std::ostream* os) {
  internal::PrintWithFallback(value, os);
}

// Specializations for built-in types
void PrintTo(bool b, ::std::ostream* os);
void PrintTo(char c, ::std::ostream* os);
void PrintTo(float f, ::std::ostream* os);
void PrintTo(double d, ::std::ostream* os);
void PrintTo(const char* s, ::std::ostream* os);
void PrintTo(const std::string& s, ::std::ostream* os);
// ... and many more
```

`PrintTo()` functions provide type-specific printing logic:
- Default implementation uses operator<< or prints raw bytes
- Specializations for built-in types provide better formatting
- Users can define their own for custom types

#### Printer Selection Logic
```cpp
template <typename T>
void PrintWithFallback(const T& value, ::std::ostream* os) {
  using Printer = typename FindFirstPrinter<
      T, void, ContainerPrinter, FunctionPointerPrinter, PointerPrinter,
      ProtobufPrinter, StreamPrinter, ConvertibleToIntegerPrinter,
      ConvertibleToStringViewPrinter, RawBytesPrinter, FallbackPrinter>::type;
  Printer::PrintValue(value, os);
}
```

The framework selects the best printer in this order:
1. Container printers (for types with begin/end)
2. Function pointer printers
3. Object pointer printers
4. Protocol buffer printers
5. Stream operator printers (using operator<<)
6. Integer conversion printers
7. String view conversion printers
8. Raw bytes printers (last resort)

### Special Printing Features

#### Container Printing
```cpp
struct ContainerPrinter {
  template <typename T>
  static void PrintValue(const T& container, std::ostream* os) {
    *os << '{';
    size_t count = 0;
    for (auto&& elem : container) {
      if (count > 0) *os << ',';
      if (count == kMaxCount) {  // Limit output for large containers
        *os << " ...";
        break;
      }
      *os << ' ';
      internal::UniversalPrint(elem, os);
      ++count;
    }
    if (count > 0) *os << ' ';
    *os << '}';
  }
};
```

Container printing:
- Prints elements within braces
- Limits output for large containers
- Recursively prints elements using `UniversalPrint`

#### Pointer Printing
```cpp
struct PointerPrinter {
  template <typename T>
  static void PrintValue(T* p, ::std::ostream* os) {
    if (p == nullptr) {
      *os << "NULL";
    } else {
      *os << p;
    }
  }
};
```

Pointer printing:
- Handles null pointers specially
- Uses operator<< for non-null pointers
- Special handling for char pointers (prints the string)

#### Smart Pointer Printing
```cpp
template <typename T, typename D>
void PrintTo(const std::unique_ptr<T, D>& ptr, std::ostream* os) {
  (PrintSmartPointer<T>)(ptr, os, 0);
}

template <typename T>
void PrintTo(const std::shared_ptr<T>& ptr, std::ostream* os) {
  (PrintSmartPointer<T>)(ptr, os, 0);
}
```

Smart pointer printing:
- Prints both the pointer address and the pointed-to value
- Handles null pointers specially
- Works with `std::unique_ptr` and `std::shared_ptr`

### Usage Examples

```cpp
// Default printing for built-in types
int x = 42;
std::cout << ::testing::PrintToString(x) << std::endl;  // "42"

// Container printing
std::vector<int> v = {1, 2, 3};
std::cout << ::testing::PrintToString(v) << std::endl;  // "{ 1, 2, 3 }"

// Custom printing for user-defined types
struct Point {
  int x, y;
};

void PrintTo(const Point& p, std::ostream* os) {
  *os << "Point(" << p.x << ", " << p.y << ")";
}

Point p = {10, 20};
std::cout << ::testing::PrintToString(p) << std::endl;  // "Point(10, 20)"

// Smart pointer printing
std::unique_ptr<int> ptr = std::make_unique<int>(42);
std::cout << ::testing::PrintToString(ptr) << std::endl;  // "(ptr = 0x..., value = 42)"
```

## 6. Integration Between Components

The advanced features of Google Test are designed to work together seamlessly:

### Matchers with Death Tests
```cpp
// Using matchers with death tests
TEST(DeathTest, ExitsWithSpecificMessage) {
  EXPECT_EXIT(
    ExitWithMessage("Fatal error"),
    ::testing::ExitedWithCode(1),
    ::testing::ContainsRegex("Fatal.*error")
  );
}
```

### Matchers with Parameterized Tests
```cpp
class StringMatchTest : public ::testing::TestWithParam<std::tuple<std::string, std::string>> {};

TEST_P(StringMatchTest, MatchesRegex) {
  std::string text = std::get<0>(GetParam());
  std::string pattern = std::get<1>(GetParam());
  
  EXPECT_THAT(text, ::testing::MatchesRegex(pattern));
}

INSTANTIATE_TEST_SUITE_P(
  RegexTests,
  StringMatchTest,
  ::testing::Values(
    std::make_tuple("abc123", "abc\\d+"),
    std::make_tuple("def456", "def\\d+"),
    std::make_tuple("ghi789", "ghi\\d+")
  )
);
```

### Universal Printing with All Features
```cpp
// Universal printing enhances all test output
TEST(PrintingTest, EnhancesFailureMessages) {
  std::vector<int> actual = {1, 2, 3};
  std::vector<int> expected = {1, 2, 4};
  
  // Failure message will show the vectors in readable format
  EXPECT_EQ(actual, expected);
}

// With parameterized tests
TEST_P(ValueParamTest, PrintsParameters) {
  // Test failure messages include nicely formatted parameter values
  EXPECT_TRUE(GetParam() < 0);  // Will fail for positive parameters
}

// With death tests
TEST(DeathTest, PrintsArgumentsInFailures) {
  std::vector<int> v = {1, 2, 3};
  
  // If this fails, v will be printed nicely in the error message
  EXPECT_DEATH(ProcessVector(v), "Invalid vector");
}
```

## 7. Practical Examples

### Advanced Matcher Usage
```cpp
// Custom matcher for checking if a number is prime
class IsPrimeMatcher {
public:
  using is_gtest_matcher = void;
  
  bool MatchAndExplain(int n, std::ostream*) const {
    if (n <= 1) return false;
    if (n <= 3) return true;
    if (n % 2 == 0 || n % 3 == 0) return false;
    
    for (int i = 5; i * i <= n; i += 6) {
      if (n % i == 0 || n % (i + 2) == 0) return false;
    }
    return true;
  }
  
  void DescribeTo(std::ostream* os) const {
    *os << "is a prime number";
  }
  
  void DescribeNegationTo(std::ostream* os) const {
    *os << "is not a prime number";
  }
};

inline ::testing::PolymorphicMatcher<IsPrimeMatcher> IsPrime() {
  return ::testing::MakePolymorphicMatcher(IsPrimeMatcher());
}

// Using the custom matcher
TEST(NumberTest, CheckPrime) {
  EXPECT_THAT(2, IsPrime());
  EXPECT_THAT(3, IsPrime());
  EXPECT_THAT(4, Not(IsPrime()));
  EXPECT_THAT(17, IsPrime());
}
```

### Complex Death Test
```cpp
// Testing signal handling with death tests
void SignalHandler(int signal_number) {
  std::cerr << "Received signal " << signal_number << std::endl;
  exit(signal_number);
}

TEST(SignalTest, HandlesSignals) {
  // Set up signal handler
  signal(SIGTERM, SignalHandler);
  
  // Test that the handler works correctly
  EXPECT_EXIT(
    raise(SIGTERM),
    ::testing::ExitedWithCode(SIGTERM),
    "Received signal " + std::to_string(SIGTERM)
  );
}
```

### Advanced Parameterized Test
```cpp
// Parameterized test with complex parameter type and generator
struct SortTestParam {
  std::vector<int> input;
  std::vector<int> expected;
  std::string name;
};

class SortTest : public ::testing::TestWithParam<SortTestParam> {};

TEST_P(SortTest, SortsCorrectly) {
  const SortTestParam& param = GetParam();
  std::vector<int> actual = param.input;
  
  std::sort(actual.begin(), actual.end());
  
  EXPECT_EQ(actual, param.expected);
}

std::vector<SortTestParam> GenerateSortTestParams() {
  return {
    {
      {3, 1, 4, 1, 5, 9},
      {1, 1, 3, 4, 5, 9},
      "Simple"
    },
    {
      {5, 5, 5, 5, 5},
      {5, 5, 5, 5, 5},
      "AllSame"
    },
    {
      {9, 8, 7, 6, 5, 4, 3, 2, 1},
      {1, 2, 3, 4, 5, 6, 7, 8, 9},
      "Reversed"
    },
    {
      {},
      {},
      "Empty"
    }
  };
}

// Custom name generator
struct SortTestNameGenerator {
  template <typename ParamType>
  std::string operator()(const ::testing::TestParamInfo<ParamType>& info) const {
    return info.param.name;
  }
};

INSTANTIATE_TEST_SUITE_P(
  SortTests,
  SortTest,
  ::testing::ValuesIn(GenerateSortTestParams()),
  SortTestNameGenerator()
);
```

### Combined Typed and Parameterized Test
```cpp
// A test that is both typed and parameterized
template <typename T>
class SortAlgorithmTest : public ::testing::TestWithParam<int> {
protected:
  void FillRandom(std::vector<T>& v, int size) {
    v.resize(size);
    for (int i = 0; i < size; ++i) {
      v[i] = static_cast<T>(rand() % 100);
    }
  }
  
  bool IsSorted(const std::vector<T>& v) {
    for (size_t i = 1; i < v.size(); ++i) {
      if (v[i] < v[i-1]) return false;
    }
    return true;
  }
};

TYPED_TEST_SUITE_P(SortAlgorithmTest);

TYPED_TEST_P(SortAlgorithmTest, SortsRandomData) {
  std::vector<TypeParam> data;
  this->FillRandom(data, GetParam());
  
  std::sort(data.begin(), data.end());
  
  EXPECT_TRUE(this->IsSorted(data));
}

REGISTER_TYPED_TEST_SUITE_P(SortAlgorithmTest, SortsRandomData);

typedef ::testing::Types<int, float, double> NumericTypes;
INSTANTIATE_TYPED_TEST_SUITE_P(Numeric, SortAlgorithmTest, NumericTypes);

INSTANTIATE_TEST_SUITE_P(
  DifferentSizes,
  SortAlgorithmTest<int>,
  ::testing::Values(0, 1, 10, 100, 1000)
);
```

## Referenced Context Files

The following context files were helpful in understanding Google Test's advanced features:

- `gtest/gtest-matchers.h`: Defines the matcher framework, including the core interfaces and built-in matchers
- `gtest/gtest-death-test.h`: Implements death tests for testing code that terminates abnormally
- `gtest/gtest-param-test.h`: Provides parameterized test functionality
- `gtest/gtest-typed-test.h`: Implements typed tests for testing with multiple types
- `gtest/gtest-printers.h`: Implements the universal printing framework for test output
- `gtest/gtest-spi.h`: Provides testing utilities for testing Google Test itself

These files provided insights into how the advanced features are implemented and how they integrate with the core framework.