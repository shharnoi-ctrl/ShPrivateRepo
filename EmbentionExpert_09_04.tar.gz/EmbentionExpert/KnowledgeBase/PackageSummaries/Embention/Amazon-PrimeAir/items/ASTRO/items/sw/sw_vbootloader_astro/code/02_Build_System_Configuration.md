# Generated from:

- vpgen/projects.json (52 tokens)
- vpgen/projects0.json (855 tokens)
- vpgen/vpgen.bat (25 tokens)

---

# Astro Bootloader Build System Configuration Analysis

This document provides a comprehensive analysis of the build system configuration for the Astro bootloader project, focusing on project structure, dependencies, build process, and multi-core support.

## Project Structure Overview

The Astro bootloader project is organized as a dual-core system targeting both the C28x DSP and ARM Cortex-M cores of the TI F2838x microcontroller. The build configuration is managed through a hierarchical JSON-based system with the following key files:

1. `vpgen/projects.json` - Top-level configuration file that includes:
   - References to other configuration files (`projects0.json`)
   - References to library configurations (`../../items/_Vlibs/vpgen/projects.json`)

2. `vpgen/projects0.json` - Primary project configuration containing:
   - Code definitions
   - Executable targets
   - Library dependencies
   - Build configurations for different platforms

3. `vpgen/vpgen.bat` - Build script that invokes the Python-based build system

## Build System Architecture

The build system uses a Python-based generator tool called `vpgen` located in the `_Vlibs` directory. The system processes JSON configuration files to generate appropriate build files for the different target platforms.

### Key Components:

1. **JSON Include Mechanism**: The system supports including other JSON files to create a hierarchical configuration:
   ```json
   "json_include": [ "projects0.json", "../../items/_Vlibs/vpgen/projects.json" ]
   ```

2. **Code Generation**: The system can generate header files with constants:
   ```json
   "code_defs": {
     "../base/code/include/generated/base_consts.h": {
       "spkt_max_data_size" : "1030U" 
     }
   }
   ```

3. **Build Process Flow**:
   - `vpgen.bat` changes to the `_Vlibs/vpgen` directory
   - Invokes `vpgen.py` with the project configuration file
   - The Python script processes the configuration and generates build files

## Executable Targets

The project defines two main executable targets:

### 1. Vbootloader_2838x_astro (C28x DSP Core)

```json
"Vbootloader_2838x_astro": {
  "path": "sw_vbootloader_astro/code",
  "headers": [
    "include", 
    "../../sw_vbootloader_astro_cm/code/include_astro",
    "../../../items/_Vlibs/sw_vbootloader_cm/code/include" 
  ],
  "sources": [ "source_astro",
               "../../../items/_Vlibs/DSP28x/code/source/DSP28x_CodeStartBranch.asm",
               "../../../items/_Vlibs/DSP2837x_ent/code/source/common/Kclk.cpp",
               "../../../items/_Vlibs/vbootloader/code/source/src_c2000/Sysaddr_bldr_c2000.cpp",
               "../../../items/_Vlibs/vbootloader/code/source/src_specific/Bldr_mgr_with_cm.cpp", 
               "../../../items/_Vlibs/vbootloader/code/source/src_dual" ],
  "hcmd": "../../../source_astro",
  "lnFlags": "lnFlags4kstack",
  "smart": "smart.bin",
  "config": {
    "2838x": { 
      "dependencies": ["bsp", "first", "base", "FPU", "maverick", "media", "midlevel", "vbootloader/2838x_ecdsa", "DSP28x", "DSP2838x_ent/cpu1_2838x", "DSP2837x_ent/cpu1_2838x", "FlashAPI_F2838xD", "stanag", "DFS2", "devices", "crypto_c28" ],
      "excludeSources": [
        "source_astro/cmd",
        "../../../items/_Vlibs/vbootloader/code/source/src_dual/Bootloader_emb.cpp"
      ],
      "libSearchPaths": [ 
        "source_astro/cmd",
        "../../../items/_Vlibs/DSP28x/code/source/cmd",
        "../../../items/_Vlibs/ti/code/FlashAPI_F2838xD/lib"
      ],
      "libs": [ "F2838x_C28x_FlashAPI.lib" ]
    }
  }
}
```

### 2. Vbootloader_2838x_astro_cm (ARM Cortex-M Core)

```json
"Vbootloader_2838x_astro_cm": {
  "path": "sw_vbootloader_astro_cm/code",
  "headers": [
    "include_astro",
    "../../../items/_Vlibs/sw_vbootloader_cm/code/include" 
  ],
  "sources": [ 
    "source",
    "../../../items/_Vlibs/sw_vbootloader_cm/code/source/Bld_mgr_2838xCM.cpp",
    "../../../items/_Vlibs/sw_vbootloader_cm/code/source/CM_CPU1_shared.cpp",
    "../../../items/_Vlibs/sw_vbootloader_cm/code/source/main_2838x_cm.cpp",
    "../../../items/_Vlibs/sw_vbootloader_cm/code/source/startup_ccs.c",
    "../../sw_vbootloader_astro_cm/code/source/2838x_flash_astro_cm_lwip.cmd"
  ],
  "hcmd": "../../..",
  "lnFlags": "lnFlags4kstack",
  "smart": "smart.bin",
  "config": {
    "2838x_arm" : {
      "type": "2838x_arm",
      "dependencies": [
        "bsp/2838x_arm", "first/2838x_arm", "base/2838x_arm", "FPU/2838x_arm", "maverick/2838x_arm", "FlashAPI_F2838xD_CM/2838x_arm", "stanag/2838x_arm",
        "vbootloader/2838x_ecdsa_arm", "DSP2838x_cm/2838x_arm", "lwip/2838x_arm", "DSP2838x_eth_cm/2838x_arm",
        "crypto/2838x_arm"
      ],
      "excludeSources": [
        "source/cmd"
      ],
      "libSearchPaths": [ 
        "source/cmd",
        "../../../items/_Vlibs/DSP28x/code/source/cmd",
        "../../../items/_Vlibs/ti/code/FlashAPI_F2838xD_CM/lib" 
      ],
      "libs": [ "F2838x_CM_FlashAPI.lib" ]
    }
  }
}
```

## Multi-Core Support Analysis

The build system is specifically designed to support the dual-core architecture of the TI F2838x microcontroller:

### C28x DSP Core Configuration

1. **Target Identification**: The configuration uses `"2838x"` to identify the C28x DSP core target.

2. **Core-Specific Sources**:
   - Uses `DSP28x_CodeStartBranch.asm` for processor initialization
   - Includes `Sysaddr_bldr_c2000.cpp` for C2000-specific bootloader functionality
   - Includes `Bldr_mgr_with_cm.cpp` for managing communication with the CM core

3. **DSP-Specific Libraries**:
   - Uses `F2838x_C28x_FlashAPI.lib` for flash programming on the C28x core
   - Includes dependencies like `crypto_c28` for cryptographic functions specific to the C28x

4. **Memory Configuration**:
   - Uses a 4K stack configuration (`"lnFlags": "lnFlags4kstack"`)

### ARM Cortex-M Core Configuration

1. **Target Identification**: The configuration uses `"2838x_arm"` to identify the ARM Cortex-M core target.

2. **Core-Specific Sources**:
   - Includes `main_2838x_cm.cpp` as the entry point for the CM core
   - Uses `startup_ccs.c` for ARM core initialization
   - Includes `2838x_flash_astro_cm_lwip.cmd` as the linker command file

3. **ARM-Specific Libraries**:
   - Uses `F2838x_CM_FlashAPI.lib` for flash programming on the CM core
   - Includes ARM-specific versions of dependencies (indicated by `/2838x_arm` suffix)
   - Includes `lwip/2838x_arm` for networking capabilities on the CM core

4. **Inter-Core Communication**:
   - Includes `CM_CPU1_shared.cpp` for shared memory communication between cores
   - Uses `Bld_mgr_2838xCM.cpp` for bootloader management on the CM side

## Key Libraries and Their Purposes

### Common Libraries

1. **Base Libraries**:
   - `bsp`: Board Support Package - hardware abstraction layer
   - `first`: Likely initialization and startup code
   - `base`: Core functionality and common utilities
   - `FPU`: Floating Point Unit support
   - `maverick`: Unknown, possibly a custom framework
   - `stanag`: Likely related to NATO STANAG standards implementation

2. **Cryptographic Libraries**:
   - `crypto_c28`: Cryptographic functions for C28x DSP
   - `crypto/2838x_arm`: Cryptographic functions for ARM Cortex-M
   - `vbootloader/2838x_ecdsa` and `vbootloader/2838x_ecdsa_arm`: ECDSA (Elliptic Curve Digital Signature Algorithm) implementation for secure boot

### C28x DSP Specific Libraries

1. **DSP Support**:
   - `DSP28x`: Core DSP support library
   - `DSP2838x_ent/cpu1_2838x`: F2838x-specific DSP support for CPU1
   - `DSP2837x_ent/cpu1_2838x`: Compatibility layer for F2837x code
   - `FlashAPI_F2838xD`: TI Flash API for the F2838x DSP core
   - `DFS2`: Unknown, possibly Digital Filter System
   - `devices`: Device drivers and peripheral support

### ARM Cortex-M Specific Libraries

1. **ARM Support**:
   - `DSP2838x_cm/2838x_arm`: CM core support for F2838x
   - `FlashAPI_F2838xD_CM/2838x_arm`: TI Flash API for the F2838x CM core
   - `lwip/2838x_arm`: Lightweight IP stack for networking
   - `DSP2838x_eth_cm/2838x_arm`: Ethernet support for the CM core

## Build Process Details

1. **Configuration Generation**:
   - The `vpgen.py` script processes the JSON configuration files
   - Generates appropriate build files for each target platform

2. **Compilation Flow**:
   - Header files are included from multiple locations, including shared headers between cores
   - Source files are compiled according to the target architecture
   - Excluded sources are skipped during compilation

3. **Linking Process**:
   - Libraries are linked from specified search paths
   - Platform-specific libraries are included based on the target configuration
   - Linker flags (e.g., `lnFlags4kstack`) control memory allocation

4. **Output Generation**:
   - Produces executable binaries for both cores
   - Generates `smart.bin` files, likely containing metadata or binary information

## Code Generation

The build system can generate header files with constants:

```json
"code_defs": {
  "../base/code/include/generated/base_consts.h": {
    "spkt_max_data_size" : "1030U" 
  }
}
```

This generates a header file `base_consts.h` with the constant `spkt_max_data_size` defined as `1030U`, which appears to be related to packet size limitations in the system.

## Conclusion

The Astro bootloader build system is a sophisticated configuration that supports building for the dual-core TI F2838x microcontroller. It manages separate builds for the C28x DSP and ARM Cortex-M cores while sharing common code and libraries where appropriate. The system uses a hierarchical JSON-based configuration approach that allows for flexible and extensible build definitions.

Key features of the build system include:
- Support for both C28x DSP and ARM Cortex-M cores
- Extensive library dependencies for each core
- Secure boot capabilities through ECDSA
- Flash programming support for both cores
- Networking capabilities on the ARM core through lwIP
- Inter-core communication mechanisms

The build process is automated through a Python-based generator that processes the JSON configuration files and produces appropriate build files for each target platform.

## Referenced Context Files

No context files were provided in the input.