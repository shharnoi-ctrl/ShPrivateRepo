# Generated from:

- items/pdi_Recovery1/setup/ver_spdif_ppm0.xml (1137 tokens)
- items/pdi_Recovery1/setup/ver_spdif_ppm1.xml (1138 tokens)
- items/pdi_Recovery1/setup/ver_spdif_ppm2.xml (1138 tokens)
- items/pdi_Recovery1/setup/ver_spdif_ppm3.xml (1138 tokens)
- items/pdi_Recovery1/setup/ver_spdif_pwmdev.xml (1240 tokens)
- items/pdi_Recovery1/setup/ver_spdif_pulse.xml (908 tokens)
- items/pdi_Recovery1/setup/ver_spdif_ecap.xml (451 tokens)
- items/pdi_Recovery1/setup/ver_spdif_xpecap.xml (257 tokens)
- items/pdi_Recovery1/setup/ver_spdif_xpcu8.xml (53 tokens)
- items/pdi_Recovery1/setup/ver_spdif_stick.xml (58 tokens)
- items/pdi_Recovery1/setup/ver_spdif_stickvar.xml (90 tokens)
- items/pdi_Recovery1/setup/ver_spdif_mstick.xml (51 tokens)
- items/pdi_Recovery1/setup/ver_spdif_stg_ua_stick.xml (64 tokens)
- items/pdi_Recovery1/setup/ver_spdif_rpm.xml (309 tokens)

---

# PDI Recovery1 System I/O Device Configuration Analysis

This document provides a comprehensive analysis of the input/output device configurations in the PDI Recovery1 system, focusing on PPM interfaces, PWM devices, pulse capture elements, and GPIO configurations.

## 1. PPM (Pulse Position Modulation) Interface Configuration

The system includes four PPM interfaces (PPM0-PPM3) with identical configurations, designed to receive and process PPM signals from external devices such as remote controllers.

### 1.1 Common PPM Configuration Parameters

Each PPM interface (ppm0.bin, ppm1.bin, ppm2.bin, ppm3.bin) shares the following configuration:

| Parameter | Value | Description |
|-----------|-------|-------------|
| `puls_pol` | 0 | Pulse polarity (0 = normal) |
| `vguard` | 0.004 | Guard time in seconds (4ms) |
| `puls_min` | 2.5E-4 | Minimum pulse width (250μs) |
| `puls_max` | 5.0E-4 | Maximum pulse width (500μs) |
| `valid_min` | 8.0E-4 | Minimum valid frame time (800μs) |
| `valid_max` | 0.0022 | Maximum valid frame time (2.2ms) |
| `pos_min` | 9.0E-4 | Minimum position value (900μs) |
| `pos_max` | 0.0021 | Maximum position value (2.1ms) |
| `ch_num` | 16 | Number of channels |
| `chmsk` | 4095 | Channel mask (0xFFF - first 12 channels enabled) |
| `fmsk` | 4294967295 | Frame mask (0xFFFFFFFF - all frames enabled) |

### 1.2 Frame Glitch Logic (FGL) Parameters

Each PPM interface includes frame glitch logic with identical settings:

| Parameter | Value | Description |
|-----------|-------|-------------|
| `delta_min` | 0.0 | Minimum delta for glitch detection |
| `delta_max` | 1000.0 | Maximum delta for glitch detection |
| `delta_min_alpha` | 1.0 | Alpha filter coefficient for minimum delta |
| `delta_max_alpha` | 0.02 | Alpha filter coefficient for maximum delta |

### 1.3 Channel Configuration

Each PPM interface supports 16 channels (ch01-ch16), all configured with:
- `trim`: 0 (no trim adjustment)
- `type`: 0 (direct type)

### 1.4 Signal Processing Flow

1. The PPM signal is received and checked against pulse width parameters (`puls_min`, `puls_max`)
2. Valid pulses are processed to extract channel positions within the frame
3. Channel positions are validated against `pos_min` and `pos_max`
4. Frame timing is validated against `valid_min` and `valid_max`
5. Glitch detection is applied using the FGL parameters
6. Each channel value is processed according to its configuration (direct type with no trim)

## 2. PWM (Pulse Width Modulation) Device Configuration

The system includes 8 PWM devices (indexed 0-7) for generating output signals to control actuators such as servos or motors.

### 2.1 Common PWM Configuration

All PWM devices share identical configuration:

| Parameter | Value | Description |
|-----------|-------|-------------|
| `frequency` | 50 | PWM frequency in Hz (standard servo frequency) |
| `activeHigh` | 1 | Signal is active high (1 = high pulse) |
| `rangeMode` | 0 | Range mode (0 = standard) |
| `min` | 900.0 | Minimum pulse width in microseconds |
| `max` | 2100.0 | Maximum pulse width in microseconds |

### 2.2 PWM Channel Structure

Each PWM device has two channels (A and B) with identical configuration parameters, allowing for 16 total PWM outputs (8 devices × 2 channels).

### 2.3 Signal Output Characteristics

- The PWM signals operate at 50Hz (20ms period)
- Pulse width ranges from 900μs to 2100μs (standard servo control range)
- Signals are active high (positive pulse)
- The configuration supports standard RC servo control

## 3. Pulse Capture Configuration

The system includes multiple pulse capture mechanisms for measuring input signals.

### 3.1 Enhanced Capture (ECAP) Configuration

Six enhanced capture modules (ecap1-ecap6) are configured for pulse timing measurement:

| Parameter | Value | Description |
|-----------|-------|-------------|
| `enable` | 1 | All modules are enabled |
| `gpio-id` | 100-103 | GPIO pin IDs for input capture |
| `wrap` | 3 | Wrap mode (3 = continuous capture) |
| `trigger1` | 0 | Falling edge trigger for first event |
| `trigger2` | 1 | Rising edge trigger for second event |
| `trigger3` | 0 | Falling edge trigger for third event |
| `trigger4` | 1 | Rising edge trigger for fourth event |

The trigger pattern (0-1-0-1) indicates the modules are configured to capture both rising and falling edges, allowing for precise pulse width and period measurement.

### 3.2 Cross-Processor ECAP Configuration (XPECAP)

The XPECAP configuration defines relationships between producers and consumers:

| Producer | Consumer | Group | Enabled |
|----------|----------|-------|---------|
| 0 | 0 | 0 | 1 |
| 1 | 4 | 0 | 1 |
| 2 | 5 | 0 | 1 |
| 3 | 6 | 0 | 1 |

This configuration establishes signal routing between capture modules, allowing for synchronized timing across the system.

### 3.3 Pulse Capture (CAP-PULSE) Configuration

Four pulse capture modules (cap-pulse-1 through cap-pulse-4) are configured with:

| Parameter | Value | Description |
|-----------|-------|-------------|
| `type` | 0 | Standard capture type |
| `tout` | 1.0 | Timeout value in seconds |

Each module includes a time-to-value (t2v) conversion table with 5 entries, all currently set to zero values, indicating default or unused conversion.

### 3.4 RPM Capture Configuration

Six RPM capture modules (cap-pps1 through cap-pps6) are configured for rotational speed measurement:

| Parameter | Value | Description |
|-----------|-------|-------------|
| `p2x_s` | 6.2831855 | Conversion factor (2π) |
| `mean` | 5 | Averaging filter depth |
| `pmin_s` | 2.0E-4 | Minimum pulse width (200μs) |
| `toff_s` | 0.5 | Timeout in seconds |

This configuration allows for measuring rotational speed from pulse inputs, with filtering to smooth readings.

## 4. Additional I/O Configurations

### 4.1 Stick Configuration

The system includes several stick-related configurations:
- `stick.bin`: Empty tunSource configuration
- `stickvar.bin`: Disabled stick variables (`enabled`: 0)
- `mstick.bin`: Empty configuration
- `stg_ua_stick.bin`: Port set to 0

### 4.2 Cross-Processor Unit 8 (XPCU8)

The XPCU8 configuration (`xpcu8.bin`) is present but contains no specific parameters, suggesting it may be using default values or is reserved for future use.

## 5. Signal Flow Architecture

The overall signal flow in the PDI Recovery1 system can be described as:

1. **Input Signal Processing**:
   - PPM signals are received on up to 4 interfaces (PPM0-PPM3)
   - Each PPM interface decodes up to 16 channels
   - Enhanced capture modules (ECAP1-ECAP6) measure pulse timing on GPIO pins
   - RPM capture modules process pulse trains for rotational speed measurement

2. **Signal Routing**:
   - XPECAP configuration routes capture data between processors
   - Cross-processor communication enables synchronized timing

3. **Output Signal Generation**:
   - 8 PWM devices (16 total channels) generate control signals
   - Each PWM channel produces standard 50Hz servo control signals
   - Output range is 900-2100μs, suitable for standard RC servos

## 6. Hardware Interface Characteristics

### 6.1 Input Interfaces

| Interface | Type | Pins | Signal Characteristics |
|-----------|------|------|------------------------|
| PPM | Digital | Not specified | 250-500μs pulses, frame 0.8-2.2ms |
| ECAP | Digital | GPIO 100-103 | Edge-triggered capture |
| RPM | Digital | Not specified | Pulse trains, min 200μs width |

### 6.2 Output Interfaces

| Interface | Type | Channels | Signal Characteristics |
|-----------|------|----------|------------------------|
| PWM | Digital | 16 (8×2) | 50Hz, 900-2100μs pulse width, active high |

## 7. Timing and Control Parameters

### 7.1 Critical Timing Parameters

| Parameter | Value | Location | Effect |
|-----------|-------|----------|--------|
| PPM pulse width | 250-500μs | ppm*.xml | Defines valid input pulse detection |
| PPM frame time | 0.8-2.2ms | ppm*.xml | Defines valid frame timing |
| PWM frequency | 50Hz | pwmdev.xml | Sets output signal frequency |
| PWM pulse range | 900-2100μs | pwmdev.xml | Sets output control range |
| RPM timeout | 0.5s | rpm.xml | Sets detection timeout for rotation |

### 7.2 Signal Processing Parameters

| Parameter | Value | Location | Effect |
|-----------|-------|----------|--------|
| FGL delta_max_alpha | 0.02 | ppm*.xml | Controls glitch filter response |
| RPM mean | 5 | rpm.xml | Sets averaging depth for RPM calculation |
| ECAP wrap | 3 | ecap.xml | Sets continuous capture mode |

## 8. System Integration Points

The PDI Recovery1 I/O configuration establishes several key integration points:

1. **Remote Control Input**: Through PPM interfaces that can decode standard RC transmitter signals
2. **Servo/Actuator Control**: Via PWM outputs compatible with standard RC servos and ESCs
3. **Rotational Sensing**: Through RPM capture for engine speed or other rotating components
4. **Pulse Timing Measurement**: Via ECAP modules for precise timing of external events
5. **Cross-Processor Communication**: Through XPECAP for synchronized timing across processors

## 9. File-by-File Breakdown

### 9.1 PPM Configuration Files

- **ver_spdif_ppm0.xml (ID: 9)**:
  - Configures PPM interface 0 with 16 channels
  - Sets timing parameters for pulse detection and validation
  - Establishes glitch filtering parameters

- **ver_spdif_ppm1.xml (ID: 18)**:
  - Identical configuration to PPM0
  - Provides a second independent PPM input interface

- **ver_spdif_ppm2.xml (ID: 19)**:
  - Identical configuration to PPM0/PPM1
  - Provides a third independent PPM input interface

- **ver_spdif_ppm3.xml (ID: 30)**:
  - Identical configuration to other PPM interfaces
  - Provides a fourth independent PPM input interface

### 9.2 PWM Configuration Files

- **ver_spdif_pwmdev.xml (ID: 54)**:
  - Configures 8 PWM devices (0-7)
  - Each device has two channels (A and B)
  - All channels set to 50Hz, 900-2100μs range, active high

### 9.3 Capture Configuration Files

- **ver_spdif_pulse.xml (ID: 116)**:
  - Configures 4 pulse capture modules
  - Each with time-to-value conversion tables (currently zeroed)
  - 1-second timeout for each module

- **ver_spdif_ecap.xml (ID: 101)**:
  - Configures 6 enhanced capture modules
  - Sets GPIO pins and edge triggering patterns
  - All modules enabled with continuous capture

- **ver_spdif_xpecap.xml (ID: 100)**:
  - Maps relationships between producer and consumer modules
  - Enables cross-processor capture synchronization

- **ver_spdif_rpm.xml (ID: 20)**:
  - Configures 6 RPM capture modules
  - Sets parameters for rotational speed measurement
  - Includes filtering and timeout settings

### 9.4 Additional Configuration Files

- **ver_spdif_xpcu8.xml (ID: 12)**:
  - Cross-processor unit 8 configuration (empty)

- **ver_spdif_stick.xml (ID: 56)**:
  - Empty stick configuration

- **ver_spdif_stickvar.xml (ID: 55)**:
  - Disabled stick variables

- **ver_spdif_mstick.xml (ID: 134)**:
  - Empty mstick configuration

- **ver_spdif_stg_ua_stick.xml (ID: 393)**:
  - Stick configuration with port 0

## 10. Cross-Component Relationships

### 10.1 Input to Processing Flow

```
PPM Interfaces (0-3) → Channel Decoding → System Control Logic
ECAP Modules (1-6) → Pulse Timing → XPECAP Routing → Processing Logic
RPM Capture → Rotational Speed Calculation → System Monitoring
```

### 10.2 Processing to Output Flow

```
System Control Logic → PWM Value Calculation → PWM Devices (0-7) → Servo/Actuator Control
```

### 10.3 Hardware Connection Map

| Input Component | Connected To | Output Component |
|-----------------|--------------|------------------|
| PPM Receivers | Not specified | PPM Interfaces (0-3) |
| GPIO Pins (100-103) | Not specified | ECAP Modules (1-6) |
| PWM Outputs (16 channels) | Not specified | Servos/Actuators |

## 11. Summary of Key Findings

1. The PDI Recovery1 system provides comprehensive I/O capabilities including:
   - 4 PPM interfaces with 16 channels each
   - 16 PWM output channels (8 devices × 2 channels)
   - 6 enhanced capture modules for precise timing measurement
   - 6 RPM capture modules for rotational speed measurement

2. The system uses standard RC servo timing:
   - 50Hz PWM frequency
   - 900-2100μs pulse width range
   - Compatible with standard RC servos and ESCs

3. The PPM interfaces are configured for standard RC receiver signals:
   - 250-500μs pulse width
   - 0.8-2.2ms frame timing
   - Support for up to 16 channels per interface

4. The system includes sophisticated signal processing:
   - Glitch filtering for PPM inputs
   - Averaging for RPM measurements
   - Edge detection for precise timing

5. Cross-processor communication is enabled through XPECAP configuration, allowing for synchronized timing across the system.

This comprehensive configuration enables the PDI Recovery1 system to interface with a wide range of sensors, actuators, and control inputs, providing a flexible platform for control applications.