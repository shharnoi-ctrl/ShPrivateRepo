# Generated from:

- _sw_Veronte/code/vblocks/code/include/Blk_senimu.h (900 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_senimu.cpp (768 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_senalt.h (617 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_senalt.cpp (1002 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_sengnss.h (1721 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_sengnss.cpp (2887 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_senmag.h (633 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_senmag.cpp (2163 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_senstp.h (743 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_senstp.cpp (1672 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_sensrtm.h (522 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_sensrtm.cpp (569 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_senrel.h (747 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_senrel.cpp (1339 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_senqinf.h (967 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_senqinf.cpp (1419 tokens)
- _sw_Veronte/code/vblocks/code/include/Sen_health_publisher.h (561 tokens)
- _sw_Veronte/code/vblocks/code/source/Sen_health_publisher.cpp (223 tokens)

## With context from:

- PackageSummaries/Embention/Amazon-PrimeAir/items/ASTRO/items/sw/sw_Astro/items/04_VBlocks_Core.md (5729 tokens)

---

# Comprehensive Summary of Sensor Interface Blocks in VBlocks Library

This document provides a detailed analysis of the sensor interface blocks in the VBlocks library, focusing on how they interface with physical sensors, process sensor data, and provide it to other blocks in the system.

## 1. Common Sensor Block Architecture

All sensor interface blocks in the VBlocks library follow a similar architectural pattern:

### 1.1 Common Components

Each sensor block typically includes:

- **Measurement References**: References to volatile measurement arrays provided by the CIO (Control Input/Output) system
- **Synchronization Readers**: `Base::Dsync::Reader` objects to detect when new measurements are available
- **Sensor Selection**: A `sel` parameter to choose which specific sensor to use
- **Output Pins**: Typed output pins that provide processed sensor data to other blocks
- **Configuration Parameters**: Sensor-specific parameters like variance settings

### 1.2 Common Methods

Each sensor block implements these standard methods:

- **Constructor**: Initializes references to sensor measurements and other required components
- **on_focus()**: Flushes old measurements when the block becomes active to prevent using stale data
- **step()**: Checks for new measurements and updates outputs accordingly
- **get_out()**: Returns pointers to the block's outputs
- **cset()**: Deserializes block configuration from PDI (Parameter Definition Interface)
- **read()**: Internal method to read new measurements from sensors

### 1.3 Sensor Health Monitoring

Many sensor blocks use the `Sen_health_publisher` class to monitor and publish sensor health:

```cpp
class Sen_health_publisher : public Base::Istep {
public:
    Sen_health_publisher(const Base::Bvar health_bit_id0,
                         const volatile Base::Bitmask<Uint16>& enabled_mask0,
                         const Base::Mblock<const Base::Bvar> bit_ids0,
                         const Base::Stepmgr::Id step_id0);
    virtual void step();
private:
    Bsp::Hbvar health_bit;
    const volatile Base::Bitmask<Uint16>& enabled_mask;
    const Base::Array<Bsp::Hbvar> hdl_bits;
};
```

This class:
1. Monitors the health of enabled sensors
2. Sets a global health bit to false if any enabled sensor is unhealthy
3. Registers itself with the step manager to be called periodically

## 2. IMU Sensor Block (Blk_senimu)

The IMU sensor block reads accelerometer and gyroscope measurements from the IMU sensors.

### 2.1 Structure and Initialization

```cpp
class Blk_senimu : public Blocks::Iblock {
private:
    const volatile Base::Meas::Type_array_acc& accmeas;  // Accelerometer measurements
    const volatile Base::Meas::Type_array_gyr& gyrmeas;  // Gyroscope measurements
    const Base::Bitmask<Uint16> hw_mask;                 // Hardware version mask
    Base::Dsync::Reader accrd;                           // Sync for accelerometer updates
    Base::Dsync::Reader gyrrd;                           // Sync for gyroscope updates
    Uint16 sel;                                          // Selected sensor
    Blocks::Pin<Signals::Imu::Mea> out;                  // Output pin
};
```

The constructor initializes these components:
```cpp
Blk_senimu::Blk_senimu(const volatile Base::Meas::Type_array_acc& accmeas0,
                       const volatile Base::Meas::Type_array_gyr& gyrmeas0,
                       const Base::Bitmask<Uint16> hw_mask0) :
    accmeas(accmeas0),
    gyrmeas(gyrmeas0),
    hw_mask(hw_mask0),
    accrd(),
    gyrrd(),
    sel(Ku16::u0),
    out()
{
    out.val.zeros();
}
```

### 2.2 Measurement Processing

The `step()` method checks for new measurements and updates the output:

```cpp
void Blk_senimu::step() {
    Signals::Rarrayst::set_updated(read(), out.val[Signals::Imu::is_new]);
}

bool Blk_senimu::read() {
    const bool ret = (!accrd.is_valid()) && (!gyrrd.is_valid());
    if (ret) {
        Base::Rv3 aux_acc;
        Base::Rv3 aux_gyr;
        accrd = accmeas[sel].read(aux_acc);
        gyrrd = gyrmeas[sel].read(aux_gyr);
        Maverick::Irvector3(&(out.val[Signals::Imu::acc_x])).set(aux_acc);
        Maverick::Irvector3(&(out.val[Signals::Imu::w_x])).set(aux_gyr);
    }
    return ret;
}
```

The block considers a measurement new only when both accelerometer and gyroscope have new data.

### 2.3 Configuration

The block is configured through PDI with the following parameters:
- `sel`: Selected sensor index (must be available in the hardware version)

```cpp
void Blk_senimu::cset(Base::Lossy_error& str, Csetpm& params) {
    str.get_uint16(sel);
    str.assrt((sel < accmeas.size()) && (hw_mask.get(sel)), Base::err_vblk_senimu);
}
```

### 2.4 Output Format

The IMU block outputs a `Signals::Imu::Mea` structure containing:
- `is_new`: Flag indicating if the measurement is new
- `acc_x`, `acc_y`, `acc_z`: Linear acceleration components
- `w_x`, `w_y`, `w_z`: Angular velocity components

## 3. Altimeter Sensor Block (Blk_senalt)

The altimeter sensor block reads measurements from altimeter sensors and produces altitude measurements.

### 3.1 Structure and Initialization

```cpp
class Blk_senalt : public Blocks::Iblock {
private:
    const volatile Base::Meas::Type_array_range& meas;  // Altimeter measurements
    Base::Dsync::Reader rd;                             // Sync for measurement updates
    Uint16 sel;                                         // Selected sensor
    Base::Rvar var;                                     // Selected range sensor variable
    Blocks::Pin_ptr<Real> e2;                           // Input sensor variance
    Blocks::Pin<Signals::Alt::Mea> out;                 // Output pin
};
```

The constructor initializes these components:
```cpp
Blk_senalt::Blk_senalt(const volatile Base::Meas::Type_array_range& meas0) :
    meas(meas0),
    rd(),
    sel(0U),
    var(Base::v_lidar01),
    e2(),
    out()
{
    out.val.zeros();
}
```

### 3.2 Measurement Processing

The `step()` method checks for new measurements and updates the output:

```cpp
void Blk_senalt::step() {
    Real aux = 0.0F;
    if (Signals::Rarrayst::set_updated(read(aux), out.val[alt_new])) {
        out.val[alt_rng] = aux;
        out.val[alt_e2] = e2.read();
    }
}

bool Blk_senalt::read(Real& val) {
    const bool ret = !rd.is_valid();
    if (ret) {
        rd = meas[sel].read(val);
    }
    return ret;
}
```

### 3.3 Configuration

The block is configured through PDI with the following parameters:
- `e2`: Input sensor variance
- `var`: Selected altimeter sensor variable

```cpp
void Blk_senalt::cset(Base::Lossy_error& str, Csetpm& params) {
    bool ret = e2.cset(str, params.accpins, 1U, 1U);
    str.get_enum16(var);
    
    // Obtain selected sensor index from variable id
    static const Uint16 sel_invalid = 0xFFFF;
    sel = sel_invalid;
    if ((Base::v_lidar01 <= var) && (var <= Base::v_exrange05)) {
        sel = static_cast<Base::Meas::Meas_range>(var - Base::v_lidar01);
    }
    else if (var == Base::v_radaralt) {
        sel = Base::Meas::radaralt;
    }
    
    str.assrt(ret && (sel != sel_invalid), Base::err_vblk_senalt);
}
```

### 3.4 Output Format

The altimeter block outputs a `Signals::Alt::Mea` structure containing:
- `alt_new`: Flag indicating if the measurement is new
- `alt_rng`: Altitude measurement
- `alt_e2`: Measurement variance

## 4. GNSS Sensor Block (Blk_sengnss)

The GNSS sensor block reads absolute position, velocity, and relative position from GNSS sources.

### 4.1 Structure and Initialization

```cpp
class Blk_sengnss : public Blocks::Iblock {
private:
    const volatile Base::Meas::Type_array_time_fix& timemeas;  // Time measurements
    const volatile Base::Meas::Type_array_pos& posmeas;        // Position measurements
    const volatile Base::Meas::Type_array_vel& velmeas;        // Velocity measurements
    const volatile Base::Meas::Type_array_drn& drnmeas;        // Relative position measurements
    const Base::Suiteref<const volatile bool, Base::Meas::mgps_all> is_gnss_rover;  // Rover flags
    
    Base::Dsync::Reader timerd;  // Sync for time updates
    Base::Dsync::Reader posrd;   // Sync for position updates
    Base::Dsync::Reader velrd;   // Sync for velocity updates
    Base::Dsync::Reader drnrd;   // Sync for relative position updates
    
    Uint16 sel;                  // Selected sensor
    
    Usre2 hpe2;                  // Horizontal position variance manager
    Usre2 vpe2;                  // Vertical position variance manager
    Usre2 hve2;                  // Horizontal velocity variance manager
    Usre2 vve2;                  // Vertical velocity variance manager
    Usre2 drne2;                 // Relative position variance manager
    Real cfg_delay;              // Configured receiver delay
    
    Blocks::Pin<Signals::Pos::Mea> posout;    // Position output
    Blocks::Pin<Signals::Vel::Mea> velout;    // Velocity output
    Blocks::Pin<Signals::Drn::Mea> drnout;    // Relative position output
    
    Base::Mabs_time_fix atime;   // Last updated time measurement
};
```

The constructor initializes these components with minimum variance values:
```cpp
Blk_sengnss::Blk_sengnss(const volatile Base::Meas::Type_array_time_fix& timemeas0,
                         const volatile Base::Meas::Type_array_pos& posmeas0,
                         const volatile Base::Meas::Type_array_vel& velmeas0,
                         const volatile Base::Meas::Type_array_drn& drnmeas0,
                         const volatile bool& is_gnss0_rover0,
                         const volatile bool& is_gnss1_rover0) :
    timemeas(timemeas0),
    posmeas(posmeas0),
    velmeas(velmeas0),
    drnmeas(drnmeas0),
    is_gnss_rover(is_gnss0_rover0, is_gnss1_rover0, is_gnss2_rover0),
    timerd(),
    posrd(),
    velrd(),
    drnrd(),
    sel(0U),
    hpe2(min_pose2h),  // 2e-2F (0.02 m²)
    vpe2(min_pose2v),  // 9e-2F (0.09 m²)
    hve2(min_vele2),   // 1e-2F (0.01 (m/s)²)
    vve2(min_vele2),   // 1e-2F (0.01 (m/s)²)
    drne2(min_drne2),  // 2.5e-3F (0.0025 m²)
    posout(),
    velout(),
    drnout(),
    cfg_delay(0.0F)
{
    velout.val.zeros();
    drnout.val.zeros();
}
```

### 4.2 Measurement Processing

The `step()` method processes time, position, velocity, and relative position measurements:

```cpp
void Blk_sengnss::step() {
    // Update time measurements
    if (!timerd.is_valid()) {
        timerd = timemeas[sel].read(atime);
    }
    
    // Process position measurements
    posout.val.is_new = false;
    if (!posrd.is_valid()) {
        Base::Mposition aux;
        posrd = posmeas[sel].read(aux);
        posout.val.is_new = true;
        posout.val.fix = aux.fix;
        posout.val.pos.set_llh(aux.pos_llh);
        
        // Apply variance limits
        posout.val.e2[0] = hpe2.get(aux.e2ned[0]);
        posout.val.e2[1] = hpe2.get(aux.e2ned[1]);
        posout.val.e2[2] = vpe2.get(aux.e2ned[2]);
        
        posout.val.delay = mea_delay(aux.tow_ms);
    }
    
    // Process velocity measurements
    velout.val[vel_new] = 0.0F;
    if (!velrd.is_valid()) {
        Base::Mvel aux;
        velrd = velmeas[sel].read(aux);
        velout.val[vel_new] = 1.0F;
        velout.val[vel_fix] = aux.fix;
        
        // Copy velocity components
        Maverick::Irvector3(&(velout.val[vel_vn])).set(aux.vn);
        
        // Apply variance limits
        velout.val[vel_e2n] = hve2.get(aux.e2ned[0]);
        velout.val[vel_e2e] = hve2.get(aux.e2ned[1]);
        velout.val[vel_e2d] = vve2.get(aux.e2ned[2]);
        
        velout.val[vel_del] = mea_delay(aux.tow_ms);
    }
    
    // Process relative position measurements
    drnout.val[drn_new] = 0.0F;
    if (!drnrd.is_valid()) {
        Base::Mdrn aux;
        drnrd = drnmeas[sel].read(aux);
        drnout.val[drn_new] = 1.0F;
        
        // Set rover/base flag
        drnout.val[drn_rvr] = static_cast<Real>(is_gnss_rover.get(sel));
        
        // Copy TOW and relative position
        set_tow(aux.tow_ms, drnout.val[drn_tow]);
        Maverick::Irvector3(&(drnout.val[drn_drn])).set(aux.drn);
        
        // Apply variance limit
        drnout.val[drn_e2] = drne2.get(aux.e2);
        
        drnout.val[drn_del] = mea_delay(aux.tow_ms);
    }
}
```

The block also implements a `mea_delay()` method to calculate measurement delay:

```cpp
Real Blk_sengnss::mea_delay(const Uint32 tow_ms) const {
    static const Real week_seconds = 604800.0F;
    
    // Compute time since last absolute time mark
    Real delay = (Bsp::Htime::get_time() - Base::Ttime(atime.tics)).get_seconds();
    
    if (delay < week_seconds) {
        // Compute time difference between current measurement TOW and last time mark
        static const int32 week_ms = 604800000;
        static const int32 half_week_ms = week_ms / 2;
        int32 diff_tow_ms = static_cast<int32>(tow_ms) - static_cast<int32>(atime.gnss_time.tow_ms);
        
        // Handle week rollover
        if (diff_tow_ms > half_week_ms) {
            diff_tow_ms -= week_ms;
        }
        else if (diff_tow_ms < -half_week_ms) {
            diff_tow_ms += week_ms;
        }
        
        // Calculate delay
        static const Real millisec_to_sec = 0.001F;
        delay -= (static_cast<Real>(diff_tow_ms) * millisec_to_sec);
    }
    else {
        // No time mark information, use configured delay
        delay = cfg_delay;
    }
    
    return delay;
}
```

### 4.3 Configuration

The block is configured through PDI with the following parameters:
- `sel`: Selected sensor index
- `rb`: Position of antenna in body frame
- `hpe2`, `vpe2`, `hve2`, `vve2`, `drne2`: Variance configurations
- `delay`: GNSS measurement delay

```cpp
void Blk_sengnss::cset(Base::Lossy_error& str, Csetpm& params) {
    str.get_uint16(sel);
    
    Tunrv3::str2elem(posout.val.rb, str);
    Maverick::Irvector3(&(velout.val[vel_rbx])).set(posout.val.rb);
    Maverick::Irvector3(&(drnout.val[drn_rbx])).set(posout.val.rb);
    
    hpe2.cset(str);
    vpe2.cset(str);
    hve2.cset(str);
    vve2.cset(str);
    drne2.cset(str);
    
    str.get_float(cfg_delay);
    
    str.assrt((sel < Base::Meas::mgps_all) && (cfg_delay >= 0.0F), Base::err_vblk_sengnss);
}
```

### 4.4 Output Format

The GNSS block provides three outputs:
1. Position output (`Signals::Pos::Mea`):
   - `is_new`: Flag indicating if the measurement is new
   - `fix`: GNSS position fix flag
   - `pos`: Absolute position
   - `e2`: Position variance in NED frame
   - `rb`: Position of antenna relative to center of mass
   - `delay`: Measurement delay

2. Velocity output (`Signals::Vel::Mea`):
   - `vel_new`: Flag indicating if the measurement is new
   - `vel_fix`: GNSS velocity fix flag
   - `vel_vn`, `vel_ve`, `vel_vd`: Velocity components
   - `vel_e2n`, `vel_e2e`, `vel_e2d`: Velocity variances
   - `vel_del`: Measurement delay
   - `vel_rbx`, `vel_rby`, `vel_rbz`: Position of antenna relative to center of mass

3. Relative position output (`Signals::Drn::Mea`):
   - `drn_new`: Flag indicating if the measurement is new
   - `drn_rvr`: Flag indicating if the receiver is a rover
   - `drn_tow`: Time of week of the measurement
   - `drn_drn`, `drn_drne`, `drn_drnd`: Relative position components
   - `drn_e2`: Relative position variance
   - `drn_del`: Measurement delay
   - `drn_rbx`, `drn_rby`, `drn_rbz`: Position of antenna relative to center of mass

## 5. Magnetometer Sensor Block (Blk_senmag)

The magnetometer sensor block reads measurements from internal magnetometers.

### 5.1 Structure and Initialization

```cpp
class Blk_senmag : public Blocks::Iblock {
private:
    const volatile Base::Meas::Type_array_mag& meas;  // Magnetometer measurements
    const Ver::HWversion_ver::Id hw;                  // Hardware version ID
    Base::Mblock<const Midlevel::Sensor3D> cal;       // Sensor calibrations
    Base::Dsync::Reader rd;                           // Sync for measurement updates
    Uint16 sel;                                       // Selected sensor
    Blocks::Pin<Signals::Mis::Mea> out;               // Output pin
    Maverick::Irvector3 out_mea;                      // Output measurement vector
};
```

The constructor initializes these components:
```cpp
Blk_senmag::Blk_senmag(const volatile Base::Meas::Type_array_mag& meas0,
                       const Array<Midlevel::Sensor3D>& cal0,
                       const Ver::HWversion_ver::Id& hw0) :
    meas(meas0),
    cal(cal0.to_mblock()),
    hw(hw0),
    rd(),
    sel(0U),
    out(),
    out_mea(&(out.val[mis_vx]))
{
    Assertions::runtime(cal0.size() == meas.size());
    out.val.zeros();
}
```

### 5.2 Measurement Processing

The `step()` method checks for new measurements, applies calibration, and updates the output:

```cpp
void Blk_senmag::step() {
    Rv3 aux;
    if (Signals::Rarrayst::set_updated(read(aux), out.val[mis_new])) {
        cal[sel].compute(aux);  // Apply calibration
        out_mea.set(aux);       // Set output vector
    }
}

bool Blk_senmag::read(Rv3& val) {
    const bool ret = !rd.is_valid();
    if (ret) {
        rd = meas[sel].read(val);
    }
    return ret;
}
```

### 5.3 Configuration and Sensor Health

The block is configured through PDI with the following parameters:
- `sel`: Selected magnetometer
- `variance`: Configured sensor variance

```cpp
void Blk_senmag::cset(Base::Lossy_error& str, Csetpm& params) {
    // Define hardware-specific sensor masks
    static const Uint16 com_mask = /* common sensors mask */;
    static const Bitmask<Uint16> hw_mask[] = {
        // Masks for different hardware versions
    };
    
    str.get_uint16(sel);
    str.get_float(out.val[mis_e2]);
    
    if (str.assrt((sel < meas.size()) && 
                 (hw_mask[hw].get(sel)) && 
                 (out.val[mis_e2] > 0.0F), err_vblk_senmag)) {
        Ver::Hsensel::get_sensel().mag.set(sel);
    }
    
    // Create sensor health publisher
    static const Base::Tnarray<Base::Bvar, Base::Meas::mmag_all> bits_mag = {
        // Bit IDs for each magnetometer
    };
    
    static Sen_health_publisher sen_health_publisher(
        Base::kbit_mags_ok,
        Ver::Hsensel::get_ksensel().mag,
        bits_mag.to_mblock(),
        Base::Stepmgr::step_mag_health
    );
}
```

The block creates a `Sen_health_publisher` to monitor and publish the health of the magnetometers.

### 5.4 Output Format

The magnetometer block outputs a `Signals::Mis::Mea` structure containing:
- `mis_new`: Flag indicating if the measurement is new
- `mis_vx`, `mis_vy`, `mis_vz`: Magnetic field vector components
- `mis_e2`: Measurement variance

## 6. Static Pressure Sensor Block (Blk_senstp)

The static pressure sensor block reads from internal static pressure sensors.

### 6.1 Structure and Initialization

```cpp
class Blk_senstp : public Blocks::Iblock {
private:
    const volatile Base::Meas::Type_array_stp& meas;  // Static pressure measurements
    const Ver::HWversion_ver::Id hw_id;               // Hardware version ID
    Base::Dsync::Reader rd;                           // Sync for measurement updates
    Uint16 sel;                                       // Selected sensor
    Blocks::Pin<Signals::Stp::Mea> out;               // Output pin
};
```

The constructor initializes these components:
```cpp
Blk_senstp::Blk_senstp(const volatile Base::Meas::Type_array_stp& meas0,
                       const Ver::HWversion_ver::Id& hw0) :
    meas(meas0),
    hw_id(hw0),
    rd(),
    sel(0U),
    out()
{
    out.val.zeros();
}
```

### 6.2 Measurement Processing

The `step()` method checks for new measurements and updates the output:

```cpp
void Blk_senstp::step() {
    Real aux = 0.0F;
    if (Signals::Rarrayst::set_updated(read(aux), out.val[stp_new])) {
        out.val[stp_p] = aux;
    }
}

bool Blk_senstp::read(Real& val) {
    const bool ret = !rd.is_valid();
    if (ret) {
        rd = meas[sel].read(val);
    }
    return ret;
}
```

### 6.3 Configuration and Sensor Health

The block is configured through PDI with the following parameters:
- `sel`: Selected static pressure sensor
- `e2`: Configured sensor variance

```cpp
void Blk_senstp::cset(Base::Lossy_error& str, Csetpm& params) {
    // Define hardware-specific sensor masks
    static const Uint16 com_mask = /* common sensors mask */;
    static const Uint16 msk_get_40 = com_mask | /* HSC sensor mask */;
    static const Uint16 msk_get_47 = com_mask | /* DPS310 sensor mask */;
    
    static const Bitmask<Uint16> hw_mask[] = {
        // Masks for different hardware versions
    };
    
    str.get_uint16(sel);
    str.get_float(out.val[stp_e2]);
    
    if (str.assrt((sel < meas.size()) && 
                 (hw_mask[hw_id].get(sel)) && 
                 (out.val[stp_e2] > 0.0F), err_vblk_senstp)) {
        Ver::Hsensel::get_sensel().stp.set(sel);
    }
    
    // Create sensor health publisher
    static const Base::Tnarray<Bvar, Meas::mstp_all> bits_stp = {
        // Bit IDs for each static pressure sensor
    };
    
    static Sen_health_publisher sen_health_publisher(
        Base::kbit_stps_ok,
        Ver::Hsensel::get_ksensel().stp,
        bits_stp.to_mblock(),
        Base::Stepmgr::step_stp_health
    );
}
```

The block creates a `Sen_health_publisher` to monitor and publish the health of the static pressure sensors.

### 6.4 Output Format

The static pressure block outputs a `Signals::Stp::Mea` structure containing:
- `stp_new`: Flag indicating if the measurement is new
- `stp_p`: Pressure measurement
- `stp_e2`: Measurement variance

## 7. SRTM Terrain Height Block (Blk_sensrtm)

The SRTM block reads terrain altitude for the current navigation position.

### 7.1 Structure and Initialization

```cpp
class Blk_sensrtm : public Blocks::Iblock {
private:
    const Base::Lonlat& pos;            // Reference to current position
    const Geo::Igeomesh& gref;          // Terrain altitude provider
    const Real& delta;                  // Height offset
    Real fine_e2;                       // Variance for fine mesh
    Real coarse_e2;                     // Variance for coarse mesh
    Blocks::Pin<Signals::Dem::Mea> out; // Output pin
};
```

The constructor initializes these components:
```cpp
Blk_sensrtm::Blk_sensrtm(const Base::Lonlat& pos0,
                         const Geo::Igeomesh& gref0,
                         const Real& delta0) :
    pos(pos0),
    gref(gref0),
    delta(delta0),
    fine_e2(0.0F),
    coarse_e2(0.0F),
    out()
{
}
```

### 7.2 Measurement Processing

The `step()` method queries the terrain height for the current position:

```cpp
void Blk_sensrtm::step() {
    static const Bsp::Hbvar posfix(Base::kbit_gpsnav);  // True when there is position fix
    const Geo::Terrain_height th = gref.srtm_height(pos);
    
    out.val[dem_new] = (th.is_ready() && posfix.get()) ? 1.0F : 0.0F;
    out.val[dem_valid] = out.val[dem_new];
    out.val[dem_h] = th.h - delta;
    out.val[dem_e2] = (th.s == Geo::Terrain_height::acs1) ? fine_e2 : coarse_e2;
}
```

### 7.3 Configuration

The block is configured through PDI with the following parameters:
- `fine_e2`: Altitude variance for the fine terrain mesh
- `coarse_e2`: Altitude variance for the coarse terrain mesh

```cpp
void Blk_sensrtm::cset(Base::Lossy_error& str, Csetpm& params) {
    str.get_float(fine_e2);
    str.get_float(coarse_e2);
    str.assrt((fine_e2 > 0.0F) && (coarse_e2 > 0.0F), Base::err_vblk_sensrtm);
}
```

### 7.4 Output Format

The SRTM block outputs a `Signals::Dem::Mea` structure containing:
- `dem_new`: Flag indicating if the measurement is new
- `dem_valid`: Flag indicating if the measurement is valid
- `dem_h`: Terrain height
- `dem_e2`: Measurement variance

## 8. Relative Position Sensor Block (Blk_senrel)

The relative position sensor block reads relative position measurements from the Internest device.

### 8.1 Structure and Initialization

```cpp
class Blk_senrel : public Blocks::Iblock {
private:
    const volatile Base::Hmeasinest& meas;  // Internest measurements
    Base::Dsync::Reader rd;                 // Sync for measurement updates
    
    bool invert;                            // Invert measurement flag
    Usre2 hpe2;                             // Horizontal position variance manager
    Usre2 vpe2;                             // Vertical position variance manager
    Real hpe2dist;                          // Horizontal variance increment by distance
    Real vpe2dist;                          // Vertical variance increment by distance
    
    Blocks::Pin_ptr<Geo::Apos> basepos;     // Base position input
    Blocks::Pin_ptr_opt<Real> meayaw;       // Yaw rotation input
    Blocks::Pin_ptr_opt<Real> meapitch;     // Pitch rotation input
    Blocks::Pin_ptr_opt<Real> mearoll;      // Roll rotation input
    Blocks::Pin<Signals::Pos::Mea> out;     // Output pin
};
```

The constructor initializes these components:
```cpp
Blk_senrel::Blk_senrel(const volatile Base::Hmeasinest& meas0) :
    meas(meas0),
    rd(),
    invert(false),
    hpe2(min_e2),  // 0.0001F (0.0001 m²)
    vpe2(min_e2),  // 0.0001F (0.0001 m²)
    hpe2dist(0.0F),
    vpe2dist(0.0F),
    basepos(),
    meayaw(),
    meapitch(),
    mearoll(),
    out()
{
}
```

### 8.2 Measurement Processing

The `step()` method processes relative position measurements:

```cpp
void Blk_senrel::step() {
    out.val.is_new = !rd.is_valid();
    if (out.val.is_new) {
        Base::Minest aux;
        rd = meas.read(aux);
        
        // Build rotation matrix for measurements
        Maverick::Rmatrix3 rot;
        rot.euler321abc2L01(meayaw.read(0.0F), meapitch.read(0.0F), mearoll.read(0.0F));
        
        // Move base position according to measurement
        Maverick::Rvector3 vec;
        vec.matvec(rot, Maverick::Irvector3::K(aux.r).kvec);
        if (invert) {
            vec.signinv();
        }
        out.val.pos.copynr(basepos.read());
        out.val.pos.move_rn(vec);
        
        // Rotate sensor variances
        Maverick::Irvector3(out.val.e2).matvec(rot, Maverick::Irvector3::K(aux.e2).kvec);
        
        // Bound sensor variances and add distance-dependent component
        const Real dist = Maverick::Irvector3::K(aux.r).kvec.norm2();
        const Real hp2distinc = hpe2dist * dist;
        out.val.e2[0] = hpe2.get(out.val.e2[0]) + hp2distinc;
        out.val.e2[1] = hpe2.get(out.val.e2[1]) + hp2distinc;
        out.val.e2[2] = vpe2.get(out.val.e2[2]) + vpe2dist * dist;
    }
}
```

### 8.3 Configuration

The block is configured through PDI with the following parameters:
- `basepos`: Absolute position of base
- `yaw`, `pitch`, `roll`: Base orientation
- `invert`: Flag to invert measurements
- `hpe2`, `vpe2`: Position variance configurations
- `hpe2dist`, `vpe2dist`: Variance increment with distance
- `rb`: Position of sensor in body frame

```cpp
void Blk_senrel::cset(Base::Lossy_error& str, Csetpm& params) {
    bool ret = basepos.cset(str, params.accpins, 1U, 1U);
    ret &= meayaw.cset(str, params.accpins, 1U, 1U);
    ret &= meapitch.cset(str, params.accpins, 1U, 1U);
    ret &= mearoll.cset(str, params.accpins, 1U, 1U);
    
    str.get_bool16(invert);
    hpe2.cset(str);
    vpe2.cset(str);
    str.get_float(hpe2dist);
    str.get_float(vpe2dist);
    Tunrv3::str2elem(out.val.rb, str);
    
    str.assrt(ret && (hpe2dist >= 0.0F) && (vpe2dist >= 0.0F), Base::err_vblk_senrel);
}
```

### 8.4 Output Format

The relative position block outputs a `Signals::Pos::Mea` structure containing:
- `is_new`: Flag indicating if the measurement is new
- `pos`: Absolute position
- `e2`: Position variance
- `rb`: Position of sensor in body frame

## 9. Dynamic Pressure Sensor Block (Blk_senqinf)

The dynamic pressure sensor block reads from internal dynamic pressure sensors.

### 9.1 Structure and Initialization

```cpp
class Blk_senqinf : public Blocks::Iblock {
private:
    const Dynamics::Aircraft& body;                   // Physical variables
    const volatile Base::Meas::Type_array_qinf& meas; // Dynamic pressure measurements
    Base::Dsync::Reader rd;                           // Sync for measurement updates
    Uint16 sel;                                       // Selected sensor
    Real qmin;                                        // Minimum pressure
    const Bsp::Huvar navsrc;                          // Navigation source
    const volatile Real& sim_ias;                     // Simulated IAS
    Real e2_qinf;                                     // Sensor variance
    
    Blocks::Pin<Real> out_qinf;                       // Dynamic pressure output
    Blocks::Pin<Real> out_ias;                        // IAS output
    Blocks::Pin<Signals::Wind::Mea> out_wind;         // Wind computation output
};
```

The constructor initializes these components:
```cpp
Blk_senqinf::Blk_senqinf(const volatile Base::Meas::Type_array_qinf& meas0,
                         const Dynamics::Aircraft& body0,
                         const volatile Real& sim_ias0) :
    body(body0),
    meas(meas0),
    rd(),
    sel(Ku16::u0),
    qmin(Const::ZERO),
    navsrc(vu_nav_source),
    sim_ias(sim_ias0),
    e2_qinf(Const::ZERO),
    out_qinf(),
    out_ias(),
    out_wind()
{
    out_ias.val = 0.0F;
    out_qinf.val = 0.0F;
    out_wind.val.zeros();
}
```

### 9.2 Measurement Processing

The `step()` method processes dynamic pressure measurements based on the navigation source:

```cpp
void Blk_senqinf::step() {
    // Process based on navigation source
    switch (navsrc.get()) {
        case nav_sim_state:
            // Use simulated IAS
            out_qinf.val = Const::ONEHALF * Geo::Ussa76::rho0 * sim_ias * sim_ias;
            out_wind.val[is_new] = 1.0F;
            break;
            
        case nav_external:
            // Use body velocity
            out_qinf.val = Const::ONEHALF * Geo::Ussa76::rho0 * body.get_vn().norm22();
            out_wind.val[is_new] = 1.0F;
            break;
            
        default:
            // Use sensor measurement
            Real qinf = 0.0F;
            if (Signals::Rarrayst::set_updated(read(qinf), out_wind.val[is_new])) {
                out_qinf.val = qinf;
            }
            break;
    }
    
    // Apply minimum pressure
    if (out_qinf.val <= qmin) {
        out_qinf.val = qmin;
    }
    
    // Compute dependent values
    Real rho = body.get_rho();
    out_wind.val[e2] = e2_qinf / (Const::TWO * rho * out_qinf.val);
    out_ias.val = Rmath::sqrtr(Const::TWO * out_qinf.val / Geo::Ussa76::rho0);
    out_wind.val[tas] = out_ias.val * Rmath::sqrtr(Geo::Ussa76::rho0 / rho);
}

bool Blk_senqinf::read(Real& val) {
    const bool ret = !rd.is_valid();
    if (ret) {
        rd = meas[sel].read(val);
    }
    return ret;
}
```

### 9.3 Configuration

The block is configured through PDI with the following parameters:
- `sel`: Selected sensor
- `e2_qinf`: Pressure variance
- `qmin`: Minimum dynamic pressure

```cpp
void Blk_senqinf::cset(Base::Lossy_error& str, Csetpm& params) {
    static const Bitmask<Uint16> valid_mask = Bitmask<Uint16>::build(
        (1 << Base::Meas::mqinf_hsc) |
        (1 << Base::Meas::mqinf_rvar0) |
        (1 << Base::Meas::mqinf_rvar1)
    );
    
    str.get_uint16(sel);
    str.get_float(e2_qinf);
    str.get_float(qmin);
    
    str.assrt((sel < meas.size()) &&
             (valid_mask.get(sel)) &&
             (e2_qinf > 0.0F) &&
             (qmin >= Const::ONE), err_vblk_senqinf);
}
```

### 9.4 Output Format

The dynamic pressure block provides three outputs:
1. Dynamic pressure output (`Real`): Dynamic pressure in Pa
2. IAS output (`Real`): Indicated airspeed in m/s
3. Wind computation output (`Signals::Wind::Mea`):
   - `is_new`: Flag indicating if the measurement is new
   - `tas`: True airspeed
   - `e2`: Measurement variance

## 10. Cross-Component Relationships

### 10.1 Sensor Block to Sensor Hardware

Each sensor block interfaces with hardware sensors through the CIO (Control Input/Output) system:

```
Hardware Sensor → CIO → Measurement Arrays → Sensor Block → Processed Output
```

The CIO system provides volatile measurement arrays that are accessed by the sensor blocks.

### 10.2 Sensor Block to Block Manager

Sensor blocks are created by the block factory and managed by the block manager:

```
Block Factory → Creates → Sensor Block → Managed by → Block Manager
```

The block manager executes the sensor blocks as part of the GNC (Guidance, Navigation, and Control) loop.

### 10.3 Sensor Block to Other Blocks

Sensor blocks provide processed sensor data to other blocks through output pins:

```
Sensor Block → Output Pin → Input Pin → Other Block
```

Other blocks can connect to sensor block outputs through the PDI configuration system.

### 10.4 Sensor Health Monitoring

Many sensor blocks use the `Sen_health_publisher` to monitor and publish sensor health:

```
Sensor Block → Configures → Sen_health_publisher → Publishes → Health Bit
```

The health bits are used by the system to detect sensor failures and take appropriate action.

## 11. Referenced Context Files

The following context files provided useful information for understanding the sensor interface blocks:

- **09_System_Architecture.md**: Provided context on the overall VBlocks architecture, including the block factory system, block type definitions, and signal types. This helped understand how sensor blocks fit into the larger system.

## 12. Summary

The VBlocks library provides a comprehensive set of sensor interface blocks that read data from various physical sensors, process the data, and provide it to other blocks in the system. Key features include:

1. **Common Architecture**: All sensor blocks follow a similar pattern with measurement references, synchronization readers, sensor selection, and output pins.

2. **Measurement Processing**: Sensor blocks check for new measurements, process them (applying calibration, variance limits, etc.), and update their outputs.

3. **Configuration**: Sensor blocks are configured through the PDI system with parameters like sensor selection, variance settings, and other sensor-specific options.

4. **Health Monitoring**: Many sensor blocks use the `Sen_health_publisher` to monitor and publish sensor health.

5. **Output Formats**: Each sensor block provides structured outputs with measurement values, variance information, and update flags.

6. **Supported Sensor Types**:
   - IMU (accelerometer and gyroscope)
   - Altimeter
   - GNSS (position, velocity, and relative position)
   - Magnetometer
   - Static pressure
   - SRTM terrain height
   - Relative position
   - Dynamic pressure

These sensor interface blocks form a critical part of the VBlocks library, providing the system with the sensor data needed for navigation, guidance, and control.