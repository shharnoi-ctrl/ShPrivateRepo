# Generated from:

- code/PA_SIL_navigation_test/include/Utils.h (435 tokens)
- code/PA_SIL_navigation_test/include/Nav_replay.h (611 tokens)
- code/PA_SIL_navigation_test/include/Measurements_fullsim.h (97 tokens)
- code/PA_SIL_navigation_test/include/Estimator_test.h (605 tokens)
- code/PA_SIL_navigation_test/include/Math_aux.h (2671 tokens)
- code/PA_SIL_navigation_test/include/Nav_replay_mapper.h (345 tokens)
- code/PA_SIL_navigation_test/source/Utils.cpp (3415 tokens)
- code/PA_SIL_navigation_test/source/Nav_replay.cpp (5067 tokens)
- code/PA_SIL_navigation_test/source/Measurements_fullsim.cpp (101 tokens)
- code/PA_SIL_navigation_test/source/PA_SIL_navigation_test.cpp (1159 tokens)
- code/PA_SIL_navigation_test/scripts/nav_replay/batch_nav_replay.py (719 tokens)
- code/PA_SIL_navigation_test/scripts/nav_replay/emb_struct.py (4830 tokens)
- code/PA_SIL_navigation_test/scripts/nav_replay/csv_flight_generator.py (478 tokens)
- code/PA_SIL_navigation_test/scripts/nav_replay/nav_replay.py (2272 tokens)
- code/PA_SIL_navigation_test/scripts/nav_replay/deserialize_outputs.py (624 tokens)

---

# Navigation Testing System: High-Fidelity Semantic Knowledge Graph

This document provides a comprehensive analysis of the navigation testing system, focusing on the replay system, utilities, and mathematical functions used for testing navigation algorithms.

## 1. Functional Behavior and Logic

### Nav_replay System

The `Nav_replay` class is the core component for replaying flight data to test navigation algorithms. It loads recorded sensor data from binary files and feeds them into the navigation system in a controlled manner.

**Key Responsibilities:**
- Loads flight data from binary files into memory maps
- Orchestrates the replay of sensor measurements with proper timing
- Feeds measurements to the navigation system
- Records and saves the navigation system's outputs

**Workflow:**
1. Constructor initializes data structures and loads binary files
   ```cpp
   Nav_replay(std::string flight_path0, std::string general_path0, const Nav_type::Type nav_type0, const bool is_nav_rig)
   ```
2. `loop()` method orchestrates the replay process:
   - Uses IMU measurements as the timing reference
   - Feeds all measurements between consecutive IMU timestamps
   - Calls `nav.step()` to process the measurements
   - Records outputs to binary files

**Data Sources:**
- IMU measurements (accelerometer and gyroscope)
- GNSS measurements (position and velocity)
- Time synchronization data
- Dynamic pressure measurements (left and right)
- Static pressure measurements
- Lidar measurements
- Recovery telemetry
- Motor performance data
- Mission readiness signals

**Output Files:**
- `ni_compact.bin`: Navigation introspection data
- `state_estimate.bin`: Navigation state estimates

### Utility Functions

The `Utils` namespace provides comparison functions to validate navigation system outputs against expected values:

**Key Functions:**
- `compare_ud()`: Compares covariance matrices in UD decomposition form
- `compare_state()`: Compares complete navigation state objects
- `compare_state_estimate()`: Compares state estimate objects
- `compare_airdata()`: Compares air data measurements
- `compare_sv_data()`: Compares space vehicle (satellite) data

### Mathematical Utilities

The `Math_aux` namespace provides mathematical helper functions for testing:

**Key Functions:**
- Vector and matrix operations
- Comparison functions with configurable tolerances
- Random number generation
- Debug printing functions

## 2. Control Flow and State Transitions

### Nav_replay Main Loop

The main control flow in `Nav_replay::loop()` follows this sequence:

1. **Initialization**:
   - Set up iterators for all measurement maps
   - Open output files for writing

2. **Main Loop**:
   - For each step:
     - Determine time window between current and next IMU measurement(s)
     - Update all measurements that fall within this time window
     - Call `nav.step()` to process measurements
     - Record navigation outputs
   - Continue until all IMU measurements are processed

3. **Termination**:
   - Close output files
   - Print completion message

### Navigation System States

The navigation system being tested transitions through several states:

| State | Trigger | Actions | Next State | Location |
|-------|---------|---------|------------|----------|
| Uninitialized | First measurements | Initialize filters | Initializing | Nav_replay::loop() |
| Initializing | Sufficient measurements | Complete initialization | Running | nav.step() |
| Running | Continuous measurements | Update navigation solution | Running | nav.step() |
| Error | Measurement inconsistency | Set error flags | Running or Reset | nav.step() |

## 3. Inputs and Stimuli

### IMU Measurements

**Source:** `meas_acc_gyr.bin`
**Structure:** `Measurements::Meas_acc_gyr`
**Processing:** Fed directly to navigation system via `Fifo_imu_SIL`
**Effect:** Primary input for inertial navigation

### GNSS Measurements

**Source:** `meas_gnss_secondary.bin` or `raim_output.bin`
**Structure:** `Measurements::Gnss_meas`
**Processing:** Position and velocity updates
**Effect:** Corrects drift in inertial solution

### Time Synchronization

**Source:** `time_sync_offset_primary.bin` or `time_sync_offset_secondary.bin`
**Structure:** `Time_sync_off_des`
**Processing:** Updates time synchronization between GPS and system time
**Effect:** Ensures proper time alignment of measurements

### Pressure Measurements

**Source:** `dynamic_pressure_left.bin`, `dynamic_pressure_right.bin`, `static_pressure.bin`
**Structure:** `Measurements::Dyn_pressure`, `Measurements::Static_pressure`
**Processing:** Air data calculations
**Effect:** Updates airspeed and altitude estimates

### Lidar Measurements

**Source:** `ground_lidar.bin`
**Structure:** `Measurements::Lidar`
**Processing:** Height above ground calculations
**Effect:** Updates altitude above ground level

### Recovery Telemetry

**Source:** `recovery_telemetry.bin`
**Structure:** `Recovery_telemetry`
**Processing:** Recovery system state information
**Effect:** Influences navigation mode decisions

### Motor Performance

**Source:** `motor_performance.bin`
**Structure:** `Motor_performance_reduced`
**Processing:** Motor RPM information
**Effect:** Used for propulsion system modeling

### Mission Readiness Signal

**Source:** `mission_readiness_signal.bin`
**Structure:** `Recovery_mission_readiness_signal`
**Processing:** Mission readiness flag
**Effect:** Influences navigation system readiness state

## 4. Outputs and Effects

### State Estimate

**File:** `state_estimate.bin`
**Structure:** Contains position, velocity, attitude, and status information
**Generation:** Created by `nav.get_nav().get_out().state_estimate->cget()`
**Usage:** Primary output for analysis and comparison

Key fields:
- Position (latitude, longitude, altitude)
- Velocity (NED frame)
- Attitude (quaternion and Euler angles)
- Sensor status flags
- Navigation validity flags

### Navigation Introspection

**File:** `ni_compact.bin`
**Structure:** Contains internal navigation system state information
**Generation:** Created by `ni_compact.cget()`
**Usage:** Debugging and detailed analysis of navigation system behavior

## 5. Parameters and Configuration

### Navigation Type

**Parameter:** `nav_type`
**Values:** `Nav_type::recovery` or `Nav_type::monitor`
**Effect:** Determines which navigation system is being tested
**Location:** `Nav_replay` constructor

### IMU Processing Rate

**Parameter:** `n_imu_per_step`
**Values:** 1 for recovery navigation, 10 for monitor navigation
**Effect:** Controls how many IMU measurements are processed per step
**Location:** `Nav_replay` constructor

### Navigation Parameters

**Parameter:** `Knobs::get_instance0().nav_params_*`
**Effect:** Controls navigation filter behavior
**Location:** `Nav_replay` constructor

```cpp
Knobs::get_instance0().nav_params_gnss_outage_duration_before_latch_invalid_s = Base::Ttime(100000.0F);
Knobs::get_instance0().nav_params_gnss_max_horiz_pos_accuracy_m = 80.0F;
Knobs::get_instance0().nav_params_gnss_max_vert_pos_accuracy_m = 80.0F;
Knobs::get_instance0().nav_params_gnss_max_speed_accuracy_m_per_s = 80.0F;
```

### Sensor Installation Parameters

**Parameter:** `param.nav.installation.*`
**Effect:** Defines sensor mounting locations and orientations
**Location:** `Nav_replay::Knob_overwritter` constructor

### Comparison Tolerances

**Parameter:** `Utils::eps`
**Value:** 0.001F
**Effect:** Default tolerance for comparison functions
**Location:** `Utils.h`

## 6. Error Handling and Contingency Logic

### File Opening Errors

**Detection:** Check if file streams are valid after opening
**Response:** Print error message and continue with available data
**Location:** `Nav_replay` constructor and `loop()` method

```cpp
if(!file)
{
    std::cerr << "Failed to open file in " << path_bin;
}
```

### Missing Measurements

**Detection:** Check if measurement maps are empty
**Response:** Skip processing for that measurement type
**Location:** `Nav_replay::loop()`

```cpp
if(it_imu == imu_data_map.end())
{
    std::cerr << "Error: No imu measurements on map. Ending program...";
    return;
}
```

### Comparison Failures

**Detection:** Comparison functions return false when values differ beyond tolerance
**Response:** Print detailed information about the mismatch
**Location:** Various `compare_*` functions in `Utils.cpp`

```cpp
bool ret2 = Rfun::comp_real<Real64>(v1[i], v2[i], eps);
if (!ret2)
{
    std::printf(" - Failed in element %d: out = (%.50f); exp = (%.50f)\n", i, v1[i], v2[i]);
}
```

## 7. File-by-File Breakdown

### Utils.h / Utils.cpp

**Purpose:** Provides comparison functions for navigation data structures
**Key Components:**
- Comparison functions for various navigation data types
- Default comparison tolerance (0.001F)

### Nav_replay.h / Nav_replay.cpp

**Purpose:** Core replay system for navigation testing
**Key Components:**
- Data structures for storing flight measurements
- Methods for loading and replaying measurements
- Navigation system integration
- Output recording

### Measurements_fullsim.h / Measurements_fullsim.cpp

**Purpose:** Extends the Measurements class for simulation use
**Key Components:**
- Methods to write and read IMU measurements
- Integration with `Fifo_imu_SIL`

### Estimator_test.h

**Purpose:** Testing framework for the navigation estimator
**Key Components:**
- Input and expected data structures
- Methods for reading test data
- Test execution and validation

### Math_aux.h

**Purpose:** Mathematical utilities for testing
**Key Components:**
- Vector and matrix operations
- Comparison functions
- Debug printing functions
- Random number generation

### Nav_replay_mapper.h

**Purpose:** Helper class for loading binary measurement files
**Key Components:**
- Template class for deserializing binary data
- Methods for populating measurement maps

### PA_SIL_navigation_test.cpp

**Purpose:** Main entry point for the navigation test application
**Key Components:**
- Command-line argument processing
- Test case selection
- Nav_replay instantiation and execution

### Python Scripts

**batch_nav_replay.py:**
- Processes multiple flight data files in batch mode
- Finds and processes RAIM output files
- Calls nav_replay.py for each flight

**emb_struct.py:**
- Defines data structures for binary file parsing
- Provides serialization and deserialization methods
- Maps binary structures to CSV fields

**csv_flight_generator.py:**
- Downloads flight data from a repository
- Processes CSV files into binary format
- Prepares data for replay

**nav_replay.py:**
- Main script for running navigation replay
- Processes command-line arguments
- Orchestrates the replay process
- Creates output ZIP files

**deserialize_outputs.py:**
- Converts binary output files to Parquet and CSV formats
- Flattens nested data structures
- Prepares data for analysis

## 8. Cross-Component Relationships

### Data Flow

1. **Binary Files → Nav_replay_mapper → Measurement Maps**
   - Binary files are loaded and parsed into in-memory maps

2. **Measurement Maps → Nav_replay → Navigation System**
   - Measurements are fed to the navigation system in time order

3. **Navigation System → Output Files**
   - Navigation outputs are serialized and saved to binary files

4. **Output Files → Python Scripts → Analysis Files**
   - Binary outputs are converted to Parquet and CSV for analysis

### Component Dependencies

- `Nav_replay` depends on `Nav_replay_mapper` for loading data
- `Nav_replay` depends on `Blk_pa_nav_base` for navigation processing
- `Utils` functions are used for validation and comparison
- Python scripts depend on the C++ executable for replay processing

## 9. Referenced Context Files

The following context files provided valuable insights:

- **State.h**: Defines the navigation state structure used throughout the system
- **Sv_data.h**: Defines space vehicle (satellite) data structures
- **Covariance_ud.h**: Defines covariance matrix structures using UD decomposition
- **Delta_state.h**: Defines state update structures
- **Estimator.h**: Defines the navigation estimator interface
- **State_estimate_logic.h**: Defines state estimation logic and status flags
- **Comparison_constants.h**: Defines constants used in comparison operations
- **Waypoint_coordinate.h**: Defines waypoint structures for navigation
- **Maneuver_coordinate.h**: Defines maneuver structures for navigation

## Key Insights About the Navigation Testing System

1. **Comprehensive Replay System**: The system can replay recorded flight data through the navigation algorithms, allowing for consistent and repeatable testing.

2. **Dual Navigation Support**: The system supports testing both recovery navigation (`Nav_type::recovery`) and monitor navigation (`Nav_type::monitor`) systems, with appropriate configuration differences.

3. **Rich Measurement Set**: The system processes a comprehensive set of sensor measurements, including IMU, GNSS, pressure sensors, lidar, and system status information.

4. **Detailed Validation**: The `Utils` namespace provides extensive comparison functions to validate navigation outputs against expected values with configurable tolerances.

5. **Python Integration**: The system includes Python scripts for batch processing, data conversion, and result analysis, creating a complete testing pipeline.

6. **Configurable Parameters**: The system allows for testing with different navigation parameters, sensor configurations, and comparison tolerances.

7. **Time Synchronization**: The system handles time synchronization between different measurement sources, ensuring proper temporal alignment.

8. **Output Analysis**: The system generates both binary outputs for efficiency and converted CSV/Parquet files for analysis.

The navigation testing system provides a robust framework for validating navigation algorithms using recorded flight data, ensuring that the navigation system performs correctly under various conditions and with different parameter settings.