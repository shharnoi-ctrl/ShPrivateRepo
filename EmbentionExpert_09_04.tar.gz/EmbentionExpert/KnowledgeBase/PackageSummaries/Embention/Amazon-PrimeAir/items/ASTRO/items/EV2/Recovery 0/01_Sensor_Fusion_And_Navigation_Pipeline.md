# Generated from:

- Amazon-PrimeAir/items/ASTRO/items/EV2/Recovery 0/04_Sensor_Calibration_System.md (4221 tokens)
- Amazon-PrimeAir/items/ASTRO/items/EV2/Recovery 0/03_IMU_And_Sensor_Configuration.md (7086 tokens)
- Amazon-PrimeAir/items/ASTRO/items/EV2/Recovery 0/02_Navigation_And_Positioning.md (5574 tokens)
- Amazon-PrimeAir/items/ASTRO/items/EV2/Recovery 0/03_Communication_Interfaces.md (7580 tokens)

---

# Sensor Fusion and Navigation Pipeline Analysis for Recovery System

## 1. Overview of the Navigation and Sensor Fusion Architecture

The recovery system implements a sophisticated sensor fusion and navigation pipeline that integrates data from multiple sensors to provide robust position, velocity, and attitude determination. This analysis synthesizes information from the sensor calibration, IMU configuration, navigation and positioning, and communication interfaces to provide a comprehensive understanding of the sensor fusion approach.

## 2. Sensor Hardware Architecture

### 2.1 Multi-IMU Configuration

The system employs four distinct Inertial Measurement Units (IMUs) with different configurations:

| IMU | Purpose | Accelerometer Configuration | Gyroscope Configuration | Data Validation |
|-----|---------|----------------------------|-------------------------|----------------|
| IMU0 | Primary | ±4g range, 160Hz sampling | ±12 deg/s range, 128Hz | Max 10 non-valid samples, acc_max_delta=313.8128, gyr_max_delta=69.81317 |
| IMU1 | Redundant Primary | ±4g range, 160Hz sampling | ±12 deg/s range, 128Hz | Max 10 non-valid samples, acc_max_delta=313.8128, gyr_max_delta=69.81317 |
| IMU2 | Backup/Secondary | ±2g range, different parameter structure | Range setting 0, different parameter structure | Max 30 non-valid samples, acc_max_delta=235.3596, gyr_max_delta=69.81317 |
| IMU3 | Tertiary/Specialized | Minimal configuration | Minimal configuration | No tolerance for non-valid samples, acc_max_delta=156.8, gyr_max_delta=69.81317 |

The identical configuration of IMU0 and IMU1 indicates a hot redundancy approach, where both sensors operate simultaneously to provide fault tolerance.

### 2.2 GNSS Receivers

The system incorporates dual u-blox GNSS receivers with different configurations:

| Receiver | Update Rate | Port Configuration | Constellations | Primary Messages |
|----------|-------------|-------------------|----------------|------------------|
| UBX0 | 4Hz (250ms) | SPI Port ID 1, SCI Port ID 1, 115200 baud | GPS, GLONASS, Galileo, BeiDou, QZSS, SBAS | NAV-STATUS, NAV-PVT, TIME-GPS |
| UBX1 | 2Hz (500ms) | SPI Port ID 4, SCI Port ID 2, 38400 baud | GPS, GLONASS, Galileo, BeiDou, QZSS, SBAS | Different message configuration |

Both receivers are configured for the "Airborne <4g" dynamic model and "3D only" fix mode, optimizing them for aerial vehicle operation.

### 2.3 Magnetometers

The system supports up to 9 magnetometers with different configurations:

- 7 standard magnetometers (calmag0, calmag2-calmag7)
- 1 reserve magnetometer (calmag_res)
- 2 extended magnetometers (extcalmag0, extcalmag1)

Each magnetometer has specific temperature-dependent calibration parameters.

### 2.4 Additional Sensors

- **Step Sensors**: 3 step sensors with different maximum delta thresholds (450.0, 113.4, 177.1875)
- **Q-Inference Sensor**: Specialized sensor with max_delta=200.0
- **External AHRS**: External attitude and heading reference system

## 3. Sensor Data Flow and Processing Pipeline

The sensor fusion pipeline follows a sophisticated multi-stage process:

### 3.1 Raw Data Acquisition

1. **IMU Data Collection**:
   - IMU0/IMU1: Accelerometer data at 160Hz, Gyroscope data at 128Hz
   - IMU2/IMU3: At their respective configured rates
   - Temperature data from IMUs with temperature sensing enabled

2. **GNSS Data Collection**:
   - UBX0: Position, velocity, and time data at 4Hz
   - UBX1: Position, velocity, and time data at 2Hz
   - NMEA messages processed with 0.5-second timeout

3. **Magnetometer Data Collection**:
   - Multiple magnetometers providing magnetic field measurements
   - Very high maximum delta threshold (effectively no limit)

4. **Step Sensor and Q-Inference Data Collection**:
   - Step sensors with specific maximum delta thresholds
   - Q-inference sensor with 200.0 maximum delta threshold

### 3.2 Initial Data Validation

1. **Non-Valid Sample Checking**:
   - Each sensor has a configured tolerance for non-valid samples
   - IMU0/IMU1: Max 10 non-valid samples
   - IMU2: Max 30 non-valid samples
   - IMU3: No tolerance for non-valid samples
   - Magnetometers: No tolerance for non-valid samples
   - Step sensors: Max 10 non-valid samples

2. **Delta Threshold Validation**:
   - Verify that the change between consecutive readings is within limits
   - Gyroscopes: Consistent 69.81317 max delta across all IMUs
   - Accelerometers: Varying thresholds (313.8128, 235.3596, 156.8)
   - Magnetometers: Effectively unlimited delta threshold
   - Step sensors: Varying thresholds (450.0, 113.4, 177.1875)
   - Q-Inference: 200.0 max delta

### 3.3 Linear Parameter Scaling

1. **Apply LPS Matrices**:
   - Apply 3x3 transformation matrices to raw sensor readings
   - Currently all set to identity matrices (no transformation)
   - Separate matrices for gyroscopes, accelerometers, and magnetometers
   - Supports up to 4 gyroscopes, 4 accelerometers, and 9 magnetometers

### 3.4 Filtering

1. **Gyroscope and Accelerometer Filtering**:
   - Notch filters configured but disabled (num-harmonics=0)
   - Center frequency: 100Hz, bandwidth: 20Hz, gain: 0.5
   - Butterworth low-pass filters configured but disabled (cutoff=1Hz)

2. **Magnetometer, Step Sensor, and Q-Inference Filtering**:
   - Simple IIR filters configured but disabled (cutoff=1Hz)

### 3.5 Sensor Suite Processing

1. **Gyroscope Suite**:
   - Enabled with sensor 0 as default
   - Time constants for variance estimation: tau_v=2.0, tau_s2=20.0
   - Initial variance=1.0, minimum variance=1.0E-4 for all gyroscopes

2. **Accelerometer Suite**:
   - Enabled with sensor 0 as default
   - Identical time constants and variance settings as gyroscope suite

### 3.6 Calibration Application

1. **Temperature-Dependent Calibration Selection**:
   - Measure current temperature
   - Select appropriate calibration based on temperature and hysteresis
   - Use calibration if current temperature is within ±temp_hyst of reference temperature

2. **Bias Correction**:
   - Subtract bias vector [b0, b1, b2] from sensor readings
   - Bias vectors currently set to [0.0, 0.0, 0.0] in calibration files

3. **Scale and Cross-Axis Correction**:
   - Apply 3x3 calibration matrix to bias-corrected readings
   - Currently set to identity matrices in calibration files

4. **Step Sensor and Q-Inference Calibration**:
   - Apply simpler x, y1, y2 calibration model

### 3.7 Attitude Determination

1. **Complementary Filter**:
   - Beta=0.025 (proportional gain)
   - Zeta=0.003 (integral gain)
   - Beta0=10.0 (initial proportional gain)
   - Zeta0=0.0 (initial integral gain)
   - Filter steps=50
   - KFG=2.0 (Kalman filter gain)
   - Norm filter=0.1

2. **External AHRS Integration**:
   - External attitude reference system enabled (disabled mode=0)

3. **Delta PQR Processing**:
   - Angular rate processing with tuning array [1.0, -1.0]

### 3.8 Position and Velocity Determination

1. **GNSS Data Processing**:
   - Position and velocity from GNSS receivers
   - Position error thresholds: 2.0m horizontal, 5.0m vertical
   - Velocity error thresholds: 1.0m/s for both horizontal and vertical

2. **Kalman Filter Integration**:
   - GPS OK time: 5.0 seconds
   - Process noise parameters all set to 0.0 except Qdem=1.0
   - Combines GNSS and inertial data for optimal state estimation

3. **Dead Reckoning**:
   - DRN parameter=10.0
   - Used when GNSS data is unavailable

4. **Georeferencing**:
   - Auto georeferencing enabled (1)
   - Margin georeferencing=0.2
   - Auto magnetic field enabled (1)

## 4. Sensor Fusion Algorithm

The core of the navigation system is a sophisticated sensor fusion algorithm that integrates data from multiple sensors:

### 4.1 Kalman Filter Implementation

The Kalman filter is the primary sensor fusion algorithm, with the following characteristics:

1. **State Vector**:
   - Position (3D)
   - Velocity (3D)
   - Attitude (quaternion)
   - Force bias (3D)
   - Angular rate bias (3D)
   - Force bias derivative (3D)
   - Angular rate bias derivative (3D)
   - Earth magnetic field

2. **Process Noise Parameters**:
   - Qnfb (Force Bias): [0.0, 0.0, 0.0]
   - Qnwb (Angular Rate Bias): [0.0, 0.0, 0.0]
   - Qdwb (Angular Rate Bias Derivative): [0.0, 0.0, 0.0]
   - Qdfb (Force Bias Derivative): [0.0, 0.0, 0.0]
   - Qdem (Earth Magnetic Field): 1.0

3. **Measurement Updates**:
   - GNSS position and velocity (when available and valid)
   - Magnetometer readings for heading
   - External AHRS data when available

4. **Time Propagation**:
   - IMU acceleration and angular rate measurements
   - Dead reckoning when GNSS is unavailable

### 4.2 Complementary Filter for Attitude

The attitude determination uses a complementary filter approach:

1. **Gyroscope Integration**:
   - Short-term attitude changes from gyroscope measurements
   - Corrected by accelerometer and magnetometer data

2. **Accelerometer and Magnetometer Fusion**:
   - Long-term attitude reference
   - Weighted by Beta (0.025) and Zeta (0.003) parameters

3. **Initial Convergence**:
   - Higher initial gain (Beta0=10.0) for rapid convergence
   - 50 filter steps for convergence

### 4.3 Sensor Weighting and Variance Estimation

1. **Dynamic Variance Estimation**:
   - Time constants tau_v=2.0 and tau_s2=20.0
   - Initial variance=1.0, minimum variance=1.0E-4

2. **Sensor Selection Logic**:
   - Default sensors (0) for both gyroscope and accelerometer suites
   - Automatic selection based on estimated variance

3. **GNSS Validation**:
   - 5.0 seconds of consistent GPS data required
   - Position and velocity error thresholds

## 5. Redundancy and Error Handling Mechanisms

The navigation system implements multiple redundancy and error handling mechanisms:

### 5.1 Sensor Redundancy

1. **Dual Primary IMUs**:
   - IMU0 and IMU1 have identical configurations
   - Operate simultaneously for hot redundancy

2. **Backup IMUs**:
   - IMU2 and IMU3 with different configurations
   - Provide alternative measurements if primary IMUs fail

3. **Dual GNSS Receivers**:
   - UBX0 and UBX1 with different update rates and port configurations
   - Provide redundant position and velocity information

4. **Multiple Magnetometers**:
   - Up to 9 magnetometers supported
   - Reserve magnetometer (calmag_res) for backup

### 5.2 Data Validation

1. **Non-Valid Sample Handling**:
   - Configurable tolerance for non-valid samples
   - Different thresholds for different sensors

2. **Maximum Delta Thresholds**:
   - Prevent use of erroneous readings with large jumps
   - Sensor-specific thresholds

3. **GNSS Validation**:
   - 5.0 seconds of consistent data required
   - Position and velocity error thresholds

### 5.3 Fallback Mechanisms

1. **Dead Reckoning**:
   - Used when GNSS is unavailable
   - DRN parameter=10.0

2. **Backup Calibration**:
   - Backup accelerometer calibration (acclbu.bin)
   - No temperature dependency for reliability

3. **Default Identity Matrices**:
   - All calibration matrices initialized as identity matrices
   - Ensures system can function with uncalibrated data if necessary

### 5.4 Temperature Compensation

1. **Temperature-Dependent Calibration**:
   - Different calibrations for different temperature ranges
   - Temperature hysteresis to prevent oscillation between calibration sets

2. **Temperature Sensing**:
   - Enabled in IMU0/IMU1 (temp_enabled=1)
   - Used to select appropriate calibration parameters

## 6. Communication and Data Flow

### 6.1 Internal Communication

1. **CAN Bus Network**:
   - Three CAN interfaces (CAN A, CAN B, CAN FD A) at 500 kbps
   - Extensive message filtering for proper routing
   - Producer-consumer model for telemetry data

2. **Port Routing**:
   - 10 routing rules for inter-component communication
   - Address-based routing with specific port mappings

3. **Tunneling**:
   - Mechanism for raw data transfer between components
   - 0.01-second DTS (data transfer speed)

### 6.2 External Communication

1. **GNSS Communication**:
   - UBX proprietary protocol for u-blox receivers
   - NMEA 0183 standard messages
   - RTCM differential corrections (currently disabled)

2. **Radio Communication**:
   - Amazon Radio with 8 channels (451.8-469.55 MHz)
   - SARA cellular module (currently disabled)
   - Iridium satellite communication (currently disabled)

## 7. Navigation Pipeline Integration

The complete navigation pipeline integrates all components as follows:

### 7.1 Sensor Data Acquisition and Preprocessing

```
Raw Sensor Data → Initial Validation → Linear Parameter Scaling → Filtering
```

### 7.2 Sensor Fusion and State Estimation

```
Preprocessed Data → Calibration Application → Sensor Suite Processing → Kalman Filter → State Vector
```

### 7.3 Navigation Output and Communication

```
State Vector → Position/Velocity/Attitude → CAN Bus Messages → External Communication
```

## 8. Key Parameters and Their Significance

### 8.1 Critical Sensor Fusion Parameters

1. **Kalman Filter Parameters**:
   - GPS OK Time (5.0s): Ensures consistent GNSS data before use
   - Process Noise (0.0): High confidence in sensor bias stability
   - Earth Magnetic Field Noise (1.0): Accounts for magnetic environment variations

2. **Attitude Determination Parameters**:
   - Beta (0.025): Low value prioritizes gyroscope for short-term changes
   - Zeta (0.003): Minimal integral correction to prevent drift
   - Beta0 (10.0): High initial value for rapid convergence

3. **Sensor Suite Parameters**:
   - tau_v (2.0): Time constant for variance estimation
   - tau_s2 (20.0): Time constant for squared variance estimation
   - Initial variance (1.0): Starting point for variance estimation
   - Minimum variance (1.0E-4): Lower bound for variance

### 8.2 Data Validation Thresholds

1. **Gyroscope Delta Threshold**:
   - 69.81317 (approximately 4 deg/s): Maximum allowed change between readings

2. **Accelerometer Delta Thresholds**:
   - IMU0/IMU1: 313.8128
   - IMU2: 235.3596
   - IMU3: 156.8

3. **GNSS Error Thresholds**:
   - Horizontal Position Error: 2.0m
   - Vertical Position Error: 5.0m
   - Velocity Errors: 1.0m/s

## 9. System Performance Characteristics

Based on the configuration analysis, the navigation system exhibits the following performance characteristics:

### 9.1 Accuracy

1. **Position Accuracy**:
   - Horizontal: Better than 2.0m (GNSS error threshold)
   - Vertical: Better than 5.0m (GNSS error threshold)

2. **Velocity Accuracy**:
   - Better than 1.0m/s (GNSS error threshold)

3. **Attitude Accuracy**:
   - Determined by complementary filter performance
   - Enhanced by multiple magnetometers and external AHRS

### 9.2 Update Rates

1. **IMU Data**:
   - Accelerometer: 160Hz (IMU0/IMU1)
   - Gyroscope: 128Hz (IMU0/IMU1)

2. **GNSS Data**:
   - UBX0: 4Hz (250ms)
   - UBX1: 2Hz (500ms)

3. **Navigation Solution**:
   - Likely determined by Kalman filter update rate
   - Probably in the range of 50-100Hz based on IMU rates

### 9.3 Robustness

1. **Sensor Redundancy**:
   - Multiple IMUs, GNSS receivers, and magnetometers
   - Hot redundancy for critical sensors

2. **Fallback Mechanisms**:
   - Dead reckoning when GNSS is unavailable
   - Backup calibrations and default parameters

3. **Environmental Adaptation**:
   - Temperature-dependent calibration
   - Automatic georeferencing and magnetic field determination

## 10. Relationships Between Components

### 10.1 Sensor Calibration and IMU Configuration

The sensor calibration system works in conjunction with the IMU configuration:

1. **Temperature Sensing**:
   - IMU configuration enables temperature sensing (temp_enabled=1)
   - Calibration system uses temperature for selecting appropriate parameters

2. **Coordinate System Alignment**:
   - IMU geometry (Lbp matrix) defines coordinate system transformation
   - Calibration matrices apply corrections in this coordinate system

3. **Sensor Identification**:
   - Sensor IDs in configuration files match IDs in calibration files

### 10.2 Navigation System and Sensor Fusion

The navigation system integrates with the sensor fusion approach:

1. **Kalman Filter**:
   - Processes calibrated sensor data
   - Applies process noise parameters to different state components

2. **Attitude Determination**:
   - Uses complementary filter with configurable gains
   - Integrates with external AHRS when available

3. **Position and Velocity**:
   - Combines GNSS and inertial data
   - Applies error thresholds and validation

### 10.3 Communication and Navigation

The communication system supports the navigation pipeline:

1. **GNSS Communication**:
   - UBX and NMEA protocols for position and time data
   - RTCM support for differential corrections

2. **Internal Data Flow**:
   - CAN bus for sensor data and navigation solutions
   - Port routing for inter-component communication

3. **External Interfaces**:
   - Radio systems for external communication
   - ADS-B for air traffic management

## 11. Conclusion: Integrated Sensor Fusion Approach

The recovery system implements a sophisticated sensor fusion approach that combines data from multiple sensors to provide robust navigation performance. Key aspects of this approach include:

1. **Multi-Sensor Integration**:
   - Four IMUs with different configurations
   - Dual GNSS receivers
   - Multiple magnetometers
   - Step sensors and Q-inference sensor
   - External AHRS

2. **Advanced Filtering and Fusion**:
   - Kalman filter for optimal state estimation
   - Complementary filter for attitude determination
   - Sensor suite processing for combining similar sensors
   - Temperature-dependent calibration

3. **Robust Error Handling**:
   - Extensive data validation mechanisms
   - Multiple redundancy approaches
   - Fallback mechanisms for sensor failures
   - Environmental adaptation

4. **Comprehensive Communication**:
   - CAN bus network for internal communication
   - Multiple external communication interfaces
   - Standardized protocols for interoperability

The navigation pipeline demonstrates a well-designed approach to sensor fusion that prioritizes accuracy, reliability, and fault tolerance. The system's architecture allows it to maintain accurate positioning and attitude information even in challenging environments or when individual sensors fail.

## Referenced Context Files

1. `Amazon-PrimeAir/items/ASTRO/items/EV2/Recovery 0/04_Sensor_Calibration_System.md` - Provided detailed information about the calibration parameters, temperature-dependent calibration, and calibration application process.

2. `Amazon-PrimeAir/items/ASTRO/items/EV2/Recovery 0/03_IMU_And_Sensor_Configuration.md` - Provided essential information about the IMU configurations, sensor suite processing, and filtering options.

3. `Amazon-PrimeAir/items/ASTRO/items/EV2/Recovery 0/02_Navigation_And_Positioning.md` - Provided details about the navigation system architecture, Kalman filter parameters, and attitude determination.

4. `Amazon-PrimeAir/items/ASTRO/items/EV2/Recovery 0/03_Communication_Interfaces.md` - Provided information about the communication interfaces, particularly the GNSS receiver configurations and internal communication architecture.