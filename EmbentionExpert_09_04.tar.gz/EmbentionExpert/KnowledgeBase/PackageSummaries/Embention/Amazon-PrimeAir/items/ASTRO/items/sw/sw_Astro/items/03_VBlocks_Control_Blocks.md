# Generated from:

- _sw_Veronte/code/vblocks/code/include/Blk_pid.h (1871 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_pid.cpp (1565 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_pid_static.h (1386 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_pid_static.cpp (914 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_pid_tsched.h (1418 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_pid_tsched.cpp (848 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_quatctrl.h (1797 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_quatctrl.cpp (5192 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_enctrl.h (945 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_enctrl.cpp (1402 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_guid.h (493 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_guid.cpp (672 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_acclim.h (720 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_acclim.cpp (1052 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_ratelimiter.h (771 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_ratelimiter.cpp (759 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_yawing.h (746 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_yawing.cpp (1375 tokens)
- _sw_Veronte/code/vblocks/code/include/Yawing_fw.h (tokens unknown)
- _sw_Veronte/code/vblocks/code/include/Autotune.h (1135 tokens)
- _sw_Veronte/code/vblocks/code/source/Autotune.cpp (1667 tokens)
- _sw_Veronte/code/vblocks/code/include/Autotune_fw.h (24 tokens)
- _sw_Veronte/code/vblocks/code/include/Iautotune.h (332 tokens)
- _sw_Veronte/code/vblocks/code/include/Pid_autotune.h (618 tokens)
- _sw_Veronte/code/vblocks/code/source/Pid_autotune.cpp (254 tokens)
- _sw_Veronte/code/vblocks/code/include/Null_autotune.h (495 tokens)
- _sw_Veronte/code/vblocks/code/include/Autotune_null.h (412 tokens)

## With context from:

- PackageSummaries/Embention/Amazon-PrimeAir/items/ASTRO/items/sw/sw_Astro/items/04_VBlocks_Core.md (5729 tokens)

---

# Control System Blocks in VBlocks Library

This comprehensive summary details the implementation of control system blocks in the VBlocks library, focusing on different types of controllers and signal processing blocks used for control systems.

## 1. PID Controller Base Class (`Blk_pid`)

`Blk_pid` is an abstract base class that encapsulates a PID controller with common functionality shared by all PID controller implementations.

### 1.1 Core Structure and Attributes

```cpp
class Blk_pid : public Blocks::Iblock, public Blocks::Icmdblock {
    // Core controller
    Gnc::Pid pid;                               // Base PID controller
    Blocks::Cmdsubs cmds;                       // Command subscription
    Gnc::Opinctrl opin;                         // Input controller error computing
    Base::Wrapper_ref limits;                   // Output limits
    bool respect_on_enabled;                    // True if respect has to be done after on_focus
    
    // Input pins
    Blocks::Pin_ptr<Real> yc;                   // Desired value (guidance)
    Blocks::Pin_ptr<Real> y;                    // Current state of controlled value (navigation)
    Blocks::Pin_ptr_opt<Real> dy;               // Optional derivative of current state
    Blocks::Pin_ptr_opt<Real> usat;             // Optional previous applied output (after saturation)
    Blocks::Pin_ptr_opt<Real> ff;               // Optional feed forward input
    Blocks::Pin_ptr_opt<bool> respect_now;      // Do respect now
    Blocks::Pin_ptr_opt<bool> integral_enable;  // Enable integral in this step
    Blocks::Pin_ptr_opt<Real> i0;               // Initialization value for integral
    
    // Output pins
    Base::Tnarray<Blocks::Pin<Real>,nouts> out; // Array of real outputs
    
    // Working variables
    bool do_onfocus;                            // True if first step after on_focus
    Base::Chrono clk;                           // Chronometer
    Real u_before_sat;                          // Computed PID output before any saturation is done
};
```

### 1.2 PID Controller Outputs

The PID controller provides four outputs:
- `ou` (ID0): Total control action (after saturation)
- `opu` (ID1): Proportional term (before saturation)
- `oiu` (ID2): Integral term (before saturation)
- `odu` (ID3): Derivative term (before saturation)

### 1.3 Key Methods

#### 1.3.1 Initialization and Reset

```cpp
Blk_pid::Blk_pid() :
    respect_on_enabled(true),
    do_onfocus(false),
    u_before_sat(0.0F)
{
}

void Blk_pid::on_focus() {
    do_onfocus = true;
    clk.tic();
    pid.reset();
    u_before_sat = 0.0F;
    out[ou].val = 0.0F;
}
```

The `on_focus()` method resets the PID controller state, including the integral term, derivative filter, and output values.

#### 1.3.2 Control Computation

```cpp
void Blk_pid::step() {
    // Calculate time step
    const Real dt = clk.step();
    const Real dt_1 = (dt > min_dt) ? (1.0F/dt) : 0.0F;
    const Real u_prev = usat.read(out[ou].val);
    
    // Prepare PID input structure
    const Gnc::Pidst::Input in = {
        dt,                                                // Time step
        dt_1,                                              // Inverse of time step
        opin,                                              // Error computation options
        yc.read(),                                         // Setpoint
        y.read(),                                          // Current value
        Base::Optional<Real>::build(dy.is_connected(), dy.read(0.0F)), // Derivative
        ((do_onfocus && respect_on_enabled) || respect_now.read(false)), // Reset flag
        u_prev,                                            // Previous output
        integral_enable.read(true),                        // Enable integral
        do_onfocus ? 0.0F : (u_prev - u_before_sat),       // Anti-windup
        ff.read(0.0F),                                     // Feed forward
        Base::Optional<Real>::build(i0.is_connected(), i0.read(0.0F)) // Initial integral
    };
    
    // Compute control action and apply limits
    u_before_sat = control_compute(in);
    out[ou].val = u_before_sat;
    limits.wrap(out[ou].val);
    
    // Update output terms
    out[opu].val = pid.get_pu();
    out[oiu].val = pid.get_iu();
    out[odu].val = pid.get_du();
    
    do_onfocus = false;
}
```

The `step()` method:
1. Calculates the time step since the last execution
2. Prepares the PID input structure with all necessary parameters
3. Calls the derived class's `control_compute()` method to calculate the control action
4. Applies output limits to the control action
5. Updates the output pins with the control terms

### 1.4 Abstract Methods for Derived Classes

```cpp
// Must be implemented by derived classes
virtual Real control_compute(const Gnc::Pidst::Input& in) = 0;
virtual void cset_pid(Base::Lossy_error& str) = 0;
virtual void cget_pid(Base::Lossy& str) const = 0;
virtual bool cmd_subscribe(Base::Lossy& str, Blocks::Cmdblockmgr& cmdmgr) = 0;
virtual void cmd_cget_subscribe(Base::Lossy& str) const = 0;
```

These abstract methods must be implemented by derived classes to provide specific PID controller behavior.

## 2. Static PID Controller (`Blk_pid_static`)

`Blk_pid_static` is a concrete implementation of `Blk_pid` that provides a standard PID controller with fixed gains.

### 2.1 Additional Features

```cpp
class Blk_pid_static : public Blk_pid {
private:
    Pid_autotune pid_autotune;                // Autotuning commands
    Blocks::Cmdsubs autotune_sub;             // Autotune command subscription
};
```

The static PID controller adds autotuning capabilities to automatically determine optimal PID gains.

### 2.2 Control Computation

```cpp
Real Blk_pid_static::control_compute(const Gnc::Pidst::Input& in) {
    return pid_autotune.step(in.opin, in.yck, in.yk, pid.pos_pid(in));
}
```

The `control_compute()` method:
1. Calls the base PID controller's `pos_pid()` method to calculate the control action
2. Passes the result through the autotuner, which may modify it during autotuning

### 2.3 Autotuning

```cpp
void Blk_pid_static::on_focus() {
    Blk_pid::on_focus();
    pid_autotune.reset();
}
```

The autotuner is reset when the controller is initialized, ensuring that autotuning starts from a clean state.

## 3. Table-Scheduled PID Controller (`Blk_pid_tsched`)

`Blk_pid_tsched` extends the base PID controller with gain scheduling capabilities, allowing the controller gains to vary based on an input parameter.

### 3.1 Additional Features

```cpp
class Blk_pid_tsched : public Blk_pid {
private:
    Blocks::Pin_ptr<Real> var;   // Variable used for table
    Gnc::Tsched tsched;          // Table scheduled PID
    
    Uint16 col_cmd;              // Column Index to which the read/write cmd is directed
    bool rw_col;                 // True is writing command/False is reading command
};
```

The table-scheduled PID controller adds:
- An input variable for gain scheduling
- A table scheduler that interpolates PID gains based on the input variable
- Command support for reading/writing specific columns of the gain table

### 3.2 Control Computation

```cpp
Real Blk_pid_tsched::control_compute(const Gnc::Pidst::Input& in) {
    tsched.update_gains(var.read());
    return pid.pos_pid(in);
}
```

The `control_compute()` method:
1. Updates the PID gains by interpolating the gain table based on the input variable
2. Calls the base PID controller's `pos_pid()` method with the updated gains

### 3.3 Command Interface

```cpp
void Blk_pid_tsched::cset_cmd(Base::Lossy_error& str) {
    str.get_uint16(col_cmd);
    str.get_bool16(rw_col);
    if (rw_col) {
        opin.cset(str);
        tsched.cset_col(str, col_cmd);
        limits.cset(str);
        str.get_bool16(respect_on_enabled);
    }
}
```

The command interface allows:
- Reading or writing specific columns of the gain table
- Updating the input controller error computing options
- Updating the output limits
- Enabling/disabling respect on initialization

## 4. Quaternion Controller (`Blk_quatctrl`)

`Blk_quatctrl` is a specialized controller for multicopter attitude control using quaternion-based representation.

### 4.1 Core Structure and Attributes

```cpp
class Blk_quatctrl : public Blocks::Iblock {
private:
    // Aircraft navigation
    const Dynamics::Rigidbody& uav;                    // Reference to navigation data
    
    // Block inputs/outputs
    Blocks::Pin_ptr_opt<bool> att;                    // Attitude control
    Blocks::Pin_ptr_opt<Real> vn;                     // Desired north velocity (NED)
    Blocks::Pin_ptr_opt<Real> ve;                     // Desired east velocity (NED)
    Blocks::Pin_ptr<Real> vd;                         // Desired down velocity (NED)
    Blocks::Pin_ptr<Real> yaw_c;                      // Desired yaw
    Blocks::Pin_ptr_opt<Real> pitch_c;                // Desired pitch angle
    Blocks::Pin_ptr_opt<Real> roll_c;                 // Desired roll angle
    Blocks::Pin_ptr_opt<Real> thrc_sat;               // Thrust saturation (for anti wind-up)
    Blocks::Pin_ptr_opt<Real> thr_ff;                 // Thrust feed-forward vector (NED)
    
    Blocks::Pin<Real> rrc;                            // Computed desired roll rate
    Blocks::Pin<Real> prc;                            // Computed desired pitch rate
    Blocks::Pin<Real> yrc;                            // Computed desired yaw rate
    Blocks::Pin<Real> thrc;                           // Computed desired collective thrust
    
    // Configuration variables
    bool respect;                                     // True if respect enabled
    Real kph;                                         // Horizontal proportional gain
    Real kih;                                         // Horizontal integral gain
    Real kdh;                                         // Horizontal derivative gain
    Real kpv;                                         // Vertical proportional gain
    Real kiv;                                         // Vertical integral gain
    Real kdv;                                         // Vertical derivative gain
    Real max_inclination;                             // Maximum roll/pitch inclination
    Real tau;                                         // Overall controller time constant
    Real p;                                           // Yaw controller ratio
    
    // Work variables
    Base::Chrono clk;                                 // Clock for computing period
    Maverick::Rvector3 thrust;                        // Computed thrust by PI controllers
    Maverick::Rvector3 thrust_sat;                    // Computed thrust after saturation
    Base::Tnarray<Gnc::Pid,Ku16::u3> pid;             // PID Controllers for thrust
    Real tan_max_inclination;                         // Tangent of maximum inclination
    bool do_respect;                                  // True if respect in this step
};
```

### 4.2 Control Algorithm

The quaternion controller implements a cascaded control approach:

1. **Thrust Vector Computation**:
   ```cpp
   void Blk_quatctrl::compute_thrust(const bool is_att, const Maverick::Irvector3& zn) {
       // Set thrust_sat with previous thrust direction and magnitude
       thrust_sat.lincmb(thrc_sat.read(thrc.val), zn);
       
       // Compute time step
       const Real dt = clk.step();
       const Real dt_1 = (dt > min_dt) ? (1.0F/dt) : 0.0F;
       
       // Get desired velocity
       Maverick::Rvector3 vc(vn.read(0.0F), ve.read(0.0F), vd.read());
       
       // In attitude mode, only control vertical thrust
       Uint16 idx = u0;
       if (is_att) {
           idx = u2;
           pid[u0].reset();
           pid[u1].reset();
           thrust[u0] = 0.0F;
           thrust[u1] = 0.0F;
       }
       
       // Execute PIDs for thrust components
       for (Uint16 i=idx; i<u3; i++) {
           const Gnc::Pidst::Input in = {
               dt, dt_1, opin,
               vc[i],                // Setpoint: desired velocity
               uav.get_vn()[i],      // Feedback: current velocity
               { true, uav.get_an()[i] }, // Derivative: acceleration
               do_respect,           // Reset flag
               thrust_sat[i],        // Previous output
               true,                 // Enable integral
               thrust_sat[i]-thrust[i], // Anti-windup
               ff[i]                 // Feed forward
           };
           thrust[i] = pid[i].pos_pid(in);
       }
       
       do_respect = false;
       
       // Apply thrust saturation
       thrust_sat.copy(thrust);
       thrust_sat[u2] = Rfun::wrap<Real>(thrust_sat[u2], -1.0F, min_thrust);
       
       // Limit lateral thrust based on maximum inclination
       const Real thrust_xy2 = thrust_sat.norm22xy();
       if (thrust_xy2 > min_thrust_xy2) {
           const Real lambda0 = Rmath::sqrtr((1.0F - (thrust_sat[u2]*thrust_sat[u2])) / thrust_xy2);
           const Real lambda1 = -(thrust_sat[u2]*tan_max_inclination) / Rmath::sqrtr(thrust_xy2);
           const Real lambda = Rfun::min<Real>(1.0F, Rfun::min<Real>(lambda0, lambda1));
           thrust_sat[u0] *= lambda;
           thrust_sat[u1] *= lambda;
       }
       
       // Compute thrust magnitude
       thrc.val = thrust_sat.norm2();
       
       // Correct thrust for attitude mode
       if (is_att) {
           thrc.val /= (Rmath::cosr(uav.get_ypr()[Ku16::u1])*Rmath::cosr(uav.get_ypr()[Ku16::u2]));
       }
   }
   ```

2. **Quaternion Computation**:
   ```cpp
   void Blk_quatctrl::compute_quat_red_full(const bool is_att,
                                          const Maverick::Irvector3& zn,
                                          Maverick::Irquat& qcmd_r,
                                          Maverick::Irquat& qcmd_f) {
       if (is_att) {
           // Clip desired pitch and roll angles
           const Real pc = Rfun::wrap<Real>(pitch_c.read(0.0F),-max_inclination,max_inclination);
           const Real rc = Rfun::wrap<Real>(roll_c.read(0.0F),-max_inclination,max_inclination);
           
           // Compute quaternions with current and desired yaw
           qcmd_r.ypr2quat(uav.get_ypr()[0], pc, rc);
           qcmd_f.ypr2quat(yaw_c.read(), pc, rc);
       } else {
           // Compute error angle between current and desired thrust
           const Real alpha = Rfun::acosw(zn.dot(thrust_sat)/thrc.val);
           
           // Compute thrust vector in body frame
           Rvector3 thrust_satb;
           uav.n2b(thrust_sat, thrust_satb);
           
           // Compute rotation axis
           Rvector3 k;
           k.cross(zb, thrust_satb);
           k.norm2alize();
           
           // Compute quaternion for thrust direction
           Rquat qe_r;
           qe_r.qrot(k, alpha);
           qcmd_r.quatmult(uav.get_qbn(), qe_r);
           
           // Compute desired attitude with yaw
           Rmatrix3 rot;
           const Real yc = yaw_c.read();
           rot.rotz(yc);
           
           // Compute desired pitch and roll
           Rvector3 thrust_sat_k;
           thrust_sat_k.matvec(rot, thrust_sat);
           const Real pc = Rmath::atanr(thrust_sat_k[u0]/thrust_sat_k[u2]);
           
           rot.roty(pc);
           Rvector3 thrust_sat_l;
           thrust_sat_l.matvec(rot, thrust_sat_k);
           const Real rc = Rmath::atan2r(thrust_sat_l[u1],-thrust_sat_l[u2]);
           
           // Compute full quaternion
           qcmd_f.ypr2quat(yc, pc, rc);
       }
   }
   ```

3. **Angle Rate Computation**:
   ```cpp
   void Blk_quatctrl::compute_angle_rates(const Maverick::Irquat& qcmd_r,
                                        const Maverick::Irquat& qcmd_f) {
       // Compute quaternion difference for yaw
       Rquat qcmd_r1;
       qcmd_r1.copy(qcmd_r);
       qcmd_r1.conjugate();
       
       Rquat qmix;
       qmix.quatmult(qcmd_r1, qcmd_f);
       Real alpha_mix = Rmath::atan2r(qmix[Irquat::qk], qmix[Irquat::qs])*Const::TWO;
       alpha_mix = Rfun::wrap2pi(alpha_mix);
       
       // Compute scaled yaw quaternion
       Rquat qmixp;
       qmixp[Irquat::qs] = Rmath::cosr(p*alpha_mix*Const::ONEHALF);
       qmixp[Irquat::qi] = 0.0F;
       qmixp[Irquat::qj] = 0.0F;
       qmixp[Irquat::qk] = Rmath::sinr(p*alpha_mix*Const::ONEHALF);
       
       // Compute commanded quaternion
       Rquat qcmd;
       qcmd.quatmult(qcmd_r, qmixp);
       
       // Compute quaternion error
       Rquat q_1;
       q_1.copy(uav.get_qbn());
       q_1.conjugate();
       Rquat qe;
       qe.quatmult(q_1, qcmd);
       
       // Compute desired rates
       const Real scaler = Const::TWO*Rfun::sign(qe[Irquat::qs]) / tau;
       rrc.val = scaler*qe[Irquat::qi];
       prc.val = scaler*qe[Irquat::qj];
       yrc.val = scaler*qe[Irquat::qk];
   }
   ```

4. **Main Step Function**:
   ```cpp
   void Blk_quatctrl::step() {
       // Get execution mode
       const bool is_att = att.read(false);
       
       // Get current thrust direction
       Rvector3 zn;
       uav.b2n(zb, zn);
       
       // Compute thrust
       compute_thrust(is_att, zn);
       
       // Compute quaternions
       Rquat qcmd_r;
       Rquat qcmd_f;
       compute_quat_red_full(is_att, zn, qcmd_r, qcmd_f);
       
       // Compute angle rates
       compute_angle_rates(qcmd_r, qcmd_f);
   }
   ```

## 5. Energy Controller (`Blk_enctrl`)

`Blk_enctrl` implements a total energy control system (TECS) for fixed-wing aircraft.

### 5.1 Core Structure and Attributes

```cpp
class Blk_enctrl : public Blocks::Iblock {
private:
    const Dynamics::Aircraft& uav;             // Reference to navigation data
    
    // Gain scheduling
    static const Uint16 kgae_max_points = 5U;  // Max points for kgae interpolation
    Maverick::Rtablen<1,kgae_max_points> kgae_table; // kgae interpolation table
    
    // Block inputs
    Blocks::Pin_ptr<Real> fpac;       // Desired FPA
    Blocks::Pin_ptr<Real> vc;         // Desired velocity (m/s)
    Blocks::Pin_ptr_opt<Real> fpa;    // Navigational FPA
    Blocks::Pin_ptr_opt<Real> v;      // Navigational velocity
    Blocks::Pin_ptr_opt<Real> v_ias;  // Navigational IAS
    Blocks::Pin_ptr_opt<Real> a_l;    // Navigational Longitudinal Acceleration
    
    // Block configuration
    Real kv;                     // Conversion factor from speed difference to desired acceleration
    Base::Vref stall;            // Stall speed
    
    // Block outputs
    Blocks::Pin<Real> endist;    // Energy distribution error
    Blocks::Pin<Real> enrate;    // Energy rate error
    Blocks::Pin<Real> desenra;   // Desired energy rate
    Blocks::Pin<Real> desdisenra;// Desired distributed energy rate
};
```

### 5.2 Control Algorithm

```cpp
void Blk_enctrl::step() {
    // Interpolate KGAE based on normalized airspeed
    Real kgae = 1.0F;
    Real ias_speed = ias.get();
    if (kgae_table.t.get_nentries() > 0) {
        const Real x = v_ias.read(ias_speed) / Rfun::max<Real>(stall.kget(), min_v_stall);
        kgae_table.t.interp1_linear(x, kgae);
    }
    
    // Compute desired normalized longitudinal acceleration
    const Real v_val = v.read(ias_speed);
    const Real alc = kv * (vc.read() - v_val) * Const::g0_1;
    
    // Compute sine of desired flight path angle
    const Real sin_des_gamma = Rmath::sinr(fpac.read());
    
    // Compute desired energy rates
    desenra.val = sin_des_gamma + alc;
    desdisenra.val = -kgae * sin_des_gamma + alc;
    
    // Compute current normalized acceleration and flight path angle
    const Real al = a_l.read(uav.get_ab()[Maverick::Irvector3::vx]) * Const::g0_1;
    const Real sin_gamma = Rmath::sinr(fpa.read(uav.get_vhfb()[1]));
    
    // Compute energy control errors
    enrate.val = desenra.val - (sin_gamma + al);
    endist.val = desdisenra.val - (-kgae*sin_gamma + al);
}
```

The energy controller:
1. Interpolates the energy distribution gain (KGAE) based on normalized airspeed
2. Computes the desired normalized longitudinal acceleration from speed error
3. Computes the desired energy rate and desired distributed energy rate
4. Computes the current normalized acceleration and flight path angle
5. Computes the energy rate error and energy distribution error

## 6. Guidance Controller (`Blk_guid`)

`Blk_guid` interfaces with the UAV's guidance system to compute cruise guidance based on configuration inputs.

### 6.1 Core Structure and Attributes

```cpp
class Blk_guid : public Blocks::Iblock {
private:
    static bool first;                             // Block already exists
    Vpgnc::Guidance& uavc;                         // Reference to UAV's guidance
    const Vpgnc::Gtrackcfg* prev_in;               // Pointer to previous input
    
    Blocks::Pin_ptr<Vpgnc::Gtrackcfg> in_guid_cfg; // Input guidance configuration
    Blocks::Pin_ptr<Vpgnc::Envelope> in_envelope;  // Input flight envelope
};
```

### 6.2 Guidance Algorithm

```cpp
void Blk_guid::on_focus() {
    prev_in = &(in_guid_cfg.read());
    uavc.on_focus_gtrack(*prev_in, true, false);
}

void Blk_guid::step() {
    uavc.step();
    const Vpgnc::Gtrackcfg* curr_in = &(in_guid_cfg.read());
    if (prev_in != curr_in) {
        const bool route_change = (prev_in->idx != curr_in->idx);
        prev_in = curr_in;
        uavc.on_focus_gtrack(*prev_in, route_change, true);
    }
    uavc.step_gtrack(*prev_in, in_envelope.read());
}

void Blk_guid::on_blur() {
    uavc.on_blur_gtrack();
}
```

The guidance controller:
1. Initializes the guidance track on focus
2. Detects changes in guidance configuration
3. Executes the guidance step with the current configuration and flight envelope
4. Cleans up the guidance track on blur

## 7. Signal Processing Blocks

### 7.1 Acceleration Limiter (`Blk_acclim`)

`Blk_acclim` smoothens an input signal by limiting its first and second derivatives.

#### 7.1.1 Core Structure and Attributes

```cpp
class Blk_acclim : public Blocks::Iblock {
private:
    Blocks::Pin_ptr<Real> init;   // Initial value
    Blocks::Pin_ptr<Real> in;     // Input signal
    Blocks::Pin<Real> out;        // Output signal
    Base::Chrono clk;             // Chrono
    
    Blocks::Pin_ptr_opt<Real> up_limit;   // Maximum increment rate (units/second)
    Blocks::Pin_ptr_opt<Real> down_limit; // Maximum decrement rate (units/second)
    bool anglewrap;                       // Flag to wrap angle inputs
    Blocks::Pin_ptr<Real> acclim;         // Acceleration limit
    Real inc_1;                           // Previous increment
    Real64 hr_out;                        // High resolution output
};
```

#### 7.1.2 Signal Processing Algorithm

```cpp
void Blk_acclim::step() {
    if (clk.ongoing()) {
        const Real dt = clk.step();
        const Real vacclim = Rmath::fabsr(acclim.read());
        
        // Compute increment
        Real inc = static_cast<Real>(in.read() - hr_out);
        if (anglewrap) {
            inc = Rfun::wrap2pi(inc);
        }
        
        // Compute velocity limits
        const Real vbrake = Rmath::sqrtr(Rmath::fabsr(Const::TWO*vacclim*inc));
        const Real dmin = Rfun::min<Real>(Rmath::fabsr(down_limit.read(Const::MAX)), vbrake)*dt;
        const Real dmax = Rfun::min<Real>(Rmath::fabsr(up_limit.read(Const::MAX)), vbrake)*dt;
        
        // Apply acceleration limit
        Real vacclim_dt2 = vacclim*dt*dt;
        if (Rfun::wrap(-vacclim_dt2, vacclim_dt2, inc - inc_1, vacclim_dt2)) {
            inc = vacclim_dt2 + inc_1;
        }
        
        // Apply rate limits
        inc_1 = Rfun::wrap<Real>(inc, -dmin, dmax);
        hr_out += inc_1;
        
        // Handle angle wrapping
        if (anglewrap) {
            if (hr_out < -Kr64::PI) {
                hr_out += Kr64::PI2;
            } else if (hr_out >= Kr64::PI) {
                hr_out -= Kr64::PI2;
            }
        }
    } else {
        // Initialize on first step
        clk.tic();
        hr_out = init.read();
        inc_1 = 0.0F;
    }
    
    // Update output
    out.val = static_cast<Real>(hr_out);
}
```

The acceleration limiter:
1. Computes the increment between the input and current output
2. Computes velocity limits based on the acceleration limit and current error
3. Applies the acceleration limit to the increment
4. Applies rate limits to the increment
5. Updates the output with the limited increment
6. Handles angle wrapping if enabled

### 7.2 Rate Limiter (`Blk_ratelimiter`)

`Blk_ratelimiter` limits the rate of change of an input signal.

#### 7.2.1 Core Structure and Attributes

```cpp
class Blk_ratelimiter : public Blocks::Iblock {
private:
    Blocks::Pin_ptr<Real> init;   // Initial value
    Blocks::Pin_ptr<Real> in;     // Input signal
    Blocks::Pin<Real> out;        // Output signal
    Base::Chrono clk;             // Chrono
    
    Blocks::Pin_ptr_opt<Real> up_limit;   // Maximum increment rate (units/second)
    Blocks::Pin_ptr_opt<Real> down_limit; // Maximum decrement rate (units/second)
    bool anglewrap;                       // Flag to wrap angle inputs
};
```

#### 7.2.2 Signal Processing Algorithm

```cpp
void Blk_ratelimiter::step() {
    if (clk.ongoing()) {
        const Real dt = clk.step();
        const Real inc = in.read() - out.val;
        const Real dmin = -Rmath::fabsr(down_limit.read(Const::MAX)*dt);
        const Real dmax = Rmath::fabsr(up_limit.read(Const::MAX)*dt);
        
        if (anglewrap) {
            out.val += Rfun::wrap<Real>(Rfun::wrap2pi(inc), dmin, dmax);
            out.val = Rfun::wrap2pi(out.val);
        } else {
            out.val += Rfun::wrap<Real>(inc, dmin, dmax);
        }
    } else {
        // Initialize on first step
        clk.tic();
        out.val = init.read();
    }
}
```

The rate limiter:
1. Computes the increment between the input and current output
2. Computes the maximum allowed increment based on the rate limits and time step
3. Limits the increment to the allowed range
4. Updates the output with the limited increment
5. Handles angle wrapping if enabled

### 7.3 Yawing Controller (`Blk_yawing`)

`Blk_yawing` calculates the desired yaw based on configurable reference modes.

#### 7.3.1 Core Structure and Attributes

```cpp
class Blk_yawing : public Blocks::Iblock {
private:
    static Uint16 stepcount;           // Number of guidance steps without yawing
    
    const Dynamics::Rigidbody& vpu;    // Navigation estimation
    Bsp::Hrvar hyawc;                  // Handler to get/set the desired yaw
    Real ref_angle;                    // Current reference angle
    Base::Chrono clk;                  // Clock for rate limiter
    bool do_reset;                     // Resets the desired yaw to target yaw
    Base::Logicfsm hdgstate;           // Heading state
    Real prev_yawc;                    // Previous value of desired yaw
    
    Blocks::Pin_ptr_opt<Real> cmdoff;  // Commanded yaw offset with respect to reference
    enum Reference {
        current_yaw = 0,               // Current yaw (read in on_focus or when yawc is changed externally)
        heading     = 1,               // Heading if ground speed is above 0.5 meters
        north       = 2                // North direction
    };
    Reference ref;                     // Reference to which yaw offsets are referred
    bool is_ratelim;                   // True if the rate limit is enabled
    Real ratelim;                      // Rate limit
};
```

#### 7.3.2 Yaw Control Algorithm

```cpp
void Blk_yawing::step() {
    if (stepcount == 0U) {
        on_focus();
    } else {
        stepcount = 0U;
        static const Real eps = 1.0E-5;
        const Real yawc = hyawc.get();
        
        if (Rfun::comp_real(yawc, prev_yawc, eps)) {
            // Update reference angle based on reference mode
            if (ref == heading) {
                static const Real mingroundspeed = 0.5F;
                static const Bsp::Hbvar ghvr(Base::kbit_hovering);
                switch (hdgstate.step((vpu.get_GS() >= mingroundspeed) && (!ghvr.get()))) {
                    case Base::Logicfsm::neg_edge:
                        ref_angle = vpu.get_ypr()[0];
                        break;
                    case Base::Logicfsm::neg_level:
                        break;
                    default:
                        ref_angle = vpu.get_vhfb()[0];
                        break;
                }
            }
            
            // Compute target yaw angle
            const Real target_angle = ref_angle + cmdoff.read(0.0F);
            
            // Apply rate limit or reset
            if (do_reset || (!is_ratelim)) {
                hyawc.set(Rfun::wrap2pi(target_angle));
                do_reset = false;
            } else {
                const Real maxinc = clk.step()*ratelim;
                hyawc.set(Rfun::wrap2pi(
                        Rfun::wrap<Real>(Rfun::wrap2pi(target_angle - yawc), -maxinc, maxinc) + yawc));
            }
        } else {
            on_focus();
        }
        prev_yawc = hyawc.get();
    }
}
```

The yawing controller:
1. Detects when no other yawing controller has been executed
2. Updates the reference angle based on the selected reference mode
3. Computes the target yaw angle as the reference angle plus the commanded offset
4. Applies rate limiting to the yaw change if enabled
5. Updates the desired yaw system variable

## 8. PID Autotuning System

### 8.1 Autotuning Interface (`Iautotune`)

```cpp
class Iautotune {
public:
    virtual void reset() = 0;
    virtual bool is_computing() const = 0;
    virtual bool step(const Gnc::Opinctrl opin, Real yc, Real y, Real& u) = 0;
    virtual void cset_cmd(Base::Lossy_error& str) = 0;
    virtual void cget_cmd(Base::Lossy& str) const = 0;
protected:
    ~Iautotune();
};
```

### 8.2 Autotuning Implementation (`Autotune`)

```cpp
class Autotune : public Iautotune {
private:
    Real at_tmax;                  // Maximum duration of autotuning process
    Uint16 at_stages;              // Number of stages for FFT (size=1<<stages)
    
    Gnc::Relay relay;              // Control output modification (relay method)
    Gnc::Cyclest& stats;           // Amplitude, period and FFT computation
    bool computing;                // Boolean to computing autotuning
    bool initialized;              // Boolean indicating if autotune has been initialized
    Gnc::Zn zn;                    // Gain computation
};
```

#### 8.2.1 Autotuning Algorithm

```cpp
bool Autotune::step(const Gnc::Opinctrl opin, const Real yc, const Real y, Real& u) {
    if (!initialized) {
        // Initialize autotuning
        stats.init(at_tmax, at_stages, this);
        relay.reset(u);
        initialized = true;
    }
    
    // Apply relay control
    relay.rcontrol(opin.compute(yc, y), u);
    
    // Check if autotuning is complete
    if (stats.step(y)) {
        // Compute ultimate gain and period
        Real Ku = Const::ZERO;
        relay.ultimate(stats.get_a(), Ku);
        
        // Compute PID gains using Ziegler-Nichols method
        zn.compute(Ku, stats.get_t());
        
        // Reset autotuning
        reset();
    }
    
    return computing;
}
```

The autotuning algorithm:
1. Initializes the autotuning process with the specified parameters
2. Applies relay control to the system to induce oscillations
3. Analyzes the system response to determine the ultimate gain and period
4. Computes optimal PID gains using the Ziegler-Nichols method
5. Resets the autotuning process when complete

### 8.3 PID Autotuning Manager (`Pid_autotune`)

```cpp
class Pid_autotune : public Blocks::Icmdblock {
private:
    Iautotune& autotune;           // Autotune helper
    bool autotuning;               // Autotune in use
};
```

#### 8.3.1 Autotuning Management

```cpp
Real Pid_autotune::step(const Gnc::Opinctrl opin,
                        const Real yc,
                        const Real y,
                        const Real u0) {
    Real u = u0;
    if (autotuning) {
        autotuning = autotune.step(opin, yc, y, u);
    }
    return u;
}
```

The autotuning manager:
1. Passes control inputs to the autotuner when autotuning is active
2. Updates the autotuning state based on the autotuner's response
3. Returns the modified control output during autotuning or the original output otherwise

## 9. Cross-Component Relationships

### 9.1 Controller Hierarchy

```
Blk_pid (Abstract Base Class)
  ├── Blk_pid_static
  │     └── Uses Pid_autotune for autotuning
  └── Blk_pid_tsched
        └── Uses Gnc::Tsched for gain scheduling

Blk_quatctrl
  └── Uses Gnc::Pid internally for thrust control

Blk_enctrl
  └── Implements TECS algorithm for energy control

Blk_guid
  └── Interfaces with Vpgnc::Guidance for path following

Signal Processing Blocks
  ├── Blk_acclim (Acceleration Limiter)
  ├── Blk_ratelimiter (Rate Limiter)
  └── Blk_yawing (Yaw Controller)

Autotuning System
  ├── Iautotune (Interface)
  ├── Autotune (Implementation)
  └── Pid_autotune (Manager)
```

### 9.2 Data Flow

1. **PID Controllers**:
   - Inputs: Setpoint, current value, optional derivative, previous output
   - Processing: Compute proportional, integral, and derivative terms
   - Outputs: Control action, P/I/D terms

2. **Quaternion Controller**:
   - Inputs: Desired velocities or attitudes, current state
   - Processing: Compute thrust vector, quaternions, and angle rates
   - Outputs: Desired roll/pitch/yaw rates, thrust magnitude

3. **Energy Controller**:
   - Inputs: Desired flight path angle, desired velocity, current state
   - Processing: Compute energy rates and errors
   - Outputs: Energy distribution error, energy rate error

4. **Signal Processing Blocks**:
   - Inputs: Raw signal, rate/acceleration limits
   - Processing: Apply limits to signal changes
   - Outputs: Smoothed signal

5. **Autotuning System**:
   - Inputs: Setpoint, current value, control output
   - Processing: Apply relay control, analyze response
   - Outputs: Modified control output, optimal PID gains

## 10. Referenced Context Files

The following context files provided useful information for understanding the control system blocks:

- **09_System_Architecture.md**: Provided overall system architecture context, explaining how the VBlocks library fits into the larger system and how blocks are created, configured, and connected.

## 11. Summary

The VBlocks library provides a comprehensive set of control system blocks for various applications:

1. **PID Controllers**:
   - `Blk_pid`: Abstract base class for PID controllers
   - `Blk_pid_static`: Standard PID controller with fixed gains
   - `Blk_pid_tsched`: PID controller with gain scheduling

2. **Specialized Controllers**:
   - `Blk_quatctrl`: Quaternion-based attitude controller for multicopters
   - `Blk_enctrl`: Total energy control system for fixed-wing aircraft
   - `Blk_guid`: Guidance controller for path following

3. **Signal Processing Blocks**:
   - `Blk_acclim`: Acceleration limiter for signal smoothing
   - `Blk_ratelimiter`: Rate limiter for signal smoothing
   - `Blk_yawing`: Yaw controller with multiple reference modes

4. **Autotuning System**:
   - `Iautotune`: Interface for PID autotuning
   - `Autotune`: Implementation of relay-based autotuning
   - `Pid_autotune`: Manager for PID autotuning

These blocks provide a flexible and powerful framework for implementing control systems in the VBlocks library, with support for various control algorithms, signal processing techniques, and autotuning capabilities.