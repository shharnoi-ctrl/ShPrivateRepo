# Generated from:

- _sw_Veronte/code/vblocks/code/include/Blk_arcade0.h (766 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_arcade0.cpp (907 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_arcade_bounce.h (754 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_arcade_bounce.cpp (714 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_arcade_extend.h (438 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_arcade_extend.cpp (353 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_arcade_pure.h (348 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_arcade_pure.cpp (307 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_arctrim.h (749 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_arctrim.cpp (860 tokens)
- _sw_Veronte/code/vpgnc/code/include/Arctrim_fw.h (66 tokens)
- _sw_Veronte/code/vblocks/code/include/Iarcxset.h (206 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_gimbal.h (772 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_gimbal.cpp (1899 tokens)
- _sw_Veronte/code/vblocks/code/include/Gimbal.h (1752 tokens)
- _sw_Veronte/code/vblocks/code/source/Gimbal.cpp (3197 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_envelope.h (533 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_envelope.cpp (39 tokens)

## With context from:

- PackageSummaries/Embention/Amazon-PrimeAir/items/ASTRO/items/sw/sw_Astro/items/04_VBlocks_Core.md (5729 tokens)
- PackageSummaries/Embention/Amazon-PrimeAir/items/ASTRO/items/sw/sw_Astro/items/03_VBlocks_Control_Blocks.md (9401 tokens)

---

# Arcade Control and Gimbal Management System in VBlocks Library

This comprehensive analysis details the arcade control system and gimbal management components in the VBlocks library, focusing on how arcade-style inputs are processed and used to control vehicle movement.

## 1. Arcade Control System Overview

The arcade control system provides a way to control vehicle movement using stick inputs in an "arcade" style, where a single stick can control multiple aspects of vehicle movement. The system includes several variants of arcade blocks, a trim system, and integration with gimbal control.

### 1.1 Core Arcade Block Architecture

The arcade control system is built around a base abstract class `Blk_arcade0` that provides common functionality, with several specialized implementations:

```
Blk_arcade0 (Abstract Base Class)
  ├── Blk_arcade_pure
  ├── Blk_arcade_bounce
  └── Blk_arcade_extend
```

## 2. Base Arcade Block (`Blk_arcade0`)

`Blk_arcade0` is an abstract base class that implements the core functionality for all arcade blocks.

### 2.1 Structure and Attributes

```cpp
class Blk_arcade0 : public Blocks::Iblock {
private:
    const Modetable& vmodetable;         // Table of modes
    Blocks::Pin_ptr<Real> in_stick;      // Stick control variable input
    Blocks::Pin_ptr_opt<Real> in_auto;   // Auto variable input
    Uint16 channel;                      // Stick control channel
    Blocks::Switchmap map;               // Phase to arcade entry map
    Base::Dynarray<Base::Arcadecfg> arc; // Set of arcade managers for each phase group
    Blocks::Pin<bool> out_enabled;       // Output indicating if arcade is enabled
    Blocks::Pin<Real> out;               // Output with arcade value
    
    // Abstract method to be implemented by derived classes
    virtual bool compute(const Real in_arc_val, Real& out_arc_val) = 0;
};
```

### 2.2 Key Methods

#### 2.2.1 Step Method

```cpp
void Blk_arcade0::step() {
    // Set default values for cases when arcade is not enabled
    out_enabled.val = false;
    out.val = in_auto.read(0.0F);

    if (vmodetable.get_current_mode(channel) == Mode::arcade_g) {
        static const Bsp::Huvar phase(Base::vu_phase);              // Arcade getter handler
        static const Uint16 not_found = 0xFFFFU;                    // Used to identify cases not configured in map
        const Uint16 arc_id = map.get_value(phase.get(),not_found); // zero is default case -> arcade disabled
        if (arc_id != not_found) {
            out_enabled.val = compute(arc[arc_id].compute(in_stick.read()), out.val);
        }
    }
}
```

The step method:
1. Sets default output values (arcade disabled, using auto input)
2. Checks if the current mode for the specified channel is arcade mode
3. Gets the current phase and looks up the corresponding arcade configuration
4. If a configuration is found, computes the arcade value and updates outputs

#### 2.2.2 Configuration Deserialization

```cpp
void Blk_arcade0::cset0(Base::Lossy_error& str, Csetpm& params) {
    bool ret = in_stick.cset(str, params.accpins, Ku16::u1, Ku16::u1);
    ret &= in_auto.cset(str, params.accpins, Ku16::u1, Ku16::u1);
    str.get_uint16(channel);
    ret &= (channel < Modetable::max_channels);
    map.cset(str, params.alloc);
    Uint16 len = 0;
    str.get_uint16(len);
    ret &= (len > map.get_max_value()); // Make sure that there is a configuration for all cases
    ret &= arc.allocate_new(params.alloc, len);
    if (ret) {
        for (Uint32 i = 0; i < arc.size(); ++i) {
            arc[i].cset(str);
        }
    }
    str.assrt(ret, Base::err_block_arcade0);
}
```

The configuration deserialization:
1. Configures input pins for stick and auto values
2. Gets the channel number and validates it
3. Configures the phase-to-arcade mapping
4. Allocates and configures the array of arcade configurations

## 3. Arcade Block Variants

### 3.1 Pure Arcade Block (`Blk_arcade_pure`)

The pure arcade block provides the simplest implementation of arcade control, where the arcade value is passed through directly.

#### 3.1.1 Structure and Attributes

```cpp
class Blk_arcade_pure : public Blk_arcade0 {
private:
    bool zero_enabled;  // True if arcade is also enabled when stick is on zero position
    
    virtual bool compute(const Real in_arc_val, Real& out_arc_val);
};
```

#### 3.1.2 Compute Method

```cpp
bool Blk_arcade_pure::compute(const Real in_arc_val, Real& out_arc_val) {
    static const Real eps = 1e-6F;
    const bool ret = (zero_enabled || !Rfun::comp_real(in_arc_val, 0.0F, eps));
    if (ret) {
        out_arc_val = in_arc_val;
    }
    return ret;
}
```

The compute method:
1. Determines if arcade should be enabled based on the input value and the `zero_enabled` flag
2. If enabled, sets the output value to the input value
3. Returns whether arcade is enabled

### 3.2 Bounce Arcade Block (`Blk_arcade_bounce`)

The bounce arcade block smooths transitions from arcade enabled to disabled by resetting the final value on the bounce.

#### 3.2.1 Structure and Attributes

```cpp
class Blk_arcade_bounce : public Blk_arcade0 {
private:
    class Bounce_smoothing {
    private:
        bool stopping;        // Flag that indicates that is is in stopping stage
        bool prev_commanding; // Flag to detect changes from arcade to auto
        bool sign;            // Sign on stop start (true -> positive)
        
    public:
        Bounce_smoothing();
        bool step(const bool commanding, const Real in);
        void clear();
        bool get_sign(const Real in);
    };
    
    Bounce_smoothing bounce;    // Helper to apply bounce smoothing
    Blocks::Pin_ptr<Real> vc;   // Navigation controlled variable
    
    virtual bool compute(const Real in_arc_val, Real& out_arc_val);
};
```

#### 3.2.2 Bounce Smoothing Algorithm

```cpp
bool Blk_arcade_bounce::Bounce_smoothing::step(const bool commanding, const Real in) {
    bool ret = commanding;
    if (commanding) {
        stopping = false;
    } else {
        if (prev_commanding) {
            // First step after arcade
            stopping = true;
            sign = get_sign(in);
        } else {
            if (stopping && (sign != get_sign(in))) {
                ret = true;
                stopping = false;
            }
        }
    }
    prev_commanding = commanding;
    return ret;
}
```

The bounce smoothing algorithm:
1. If commanding, disables stopping mode
2. If transitioning from commanding to not commanding, enters stopping mode and records the sign
3. If in stopping mode and the sign changes, re-enables commanding and exits stopping mode
4. Returns whether commanding is active

#### 3.2.3 Compute Method

```cpp
bool Blk_arcade_bounce::compute(const Real in_arc_val, Real& out_arc_val) {
    static const Real eps = 1e-6F;
    const bool ret = bounce.step(!Rfun::comp_real(in_arc_val, 0.0F, eps), vc.read());
    if (ret) {
        out_arc_val = in_arc_val;
    }
    return ret;
}
```

The compute method:
1. Determines if the input value is non-zero (commanding)
2. Passes this and the controlled variable to the bounce smoothing algorithm
3. If commanding is active, sets the output value to the input value
4. Returns whether commanding is active

### 3.3 Extended Arcade Block (`Blk_arcade_extend`)

The extended arcade block extends arcade control until the derivative of the controlled variable is small.

#### 3.3.1 Structure and Attributes

```cpp
class Blk_arcade_extend : public Blk_arcade0 {
private:
    Gnc::Arcadest extend;       // Helper to apply extended smoothing
    Blocks::Pin_ptr<Real> vc;   // Navigation controlled variable
    
    virtual bool compute(const Real in_arc_val, Real& out_arc_val);
};
```

#### 3.3.2 Compute Method

```cpp
bool Blk_arcade_extend::compute(const Real in_arc_val, Real& out_arc_val) {
    static const Real eps = 1e-6F;
    extend.step(!Rfun::comp_real(in_arc_val, 0.0F, eps), vc.read());
    const bool ret = extend.is_arcade();
    if (ret) {
        out_arc_val = in_arc_val;
    }
    return ret;
}
```

The compute method:
1. Determines if the input value is non-zero (commanding)
2. Updates the arcade extension state with this information and the controlled variable
3. Checks if arcade mode is active according to the extension algorithm
4. If active, sets the output value to the input value
5. Returns whether arcade is active

## 4. Arcade Trim System (`Blk_arctrim`)

The arcade trim system allows for storing and applying trim values to control inputs, which helps maintain a desired state without constant stick input.

### 4.1 Structure and Attributes

```cpp
class Blk_arctrim : public Blocks::Iblock, public Blocks::Icmdblock {
private:
    Base::Array<Vpgnc::Arctrim>& trimarray;     // Array of Arctrim to manage trim
    Blocks::Pin_ptr<Real> in_u;                 // Control vector
    Blocks::Pin<Base::Dynarray<Real>> out_du;   // Control trim vector
    Uint16 id;                                  // Block id
    Uint16 szu;                                 // Size of control vector
    Blocks::Cmdsubs cmds;                       // Command subscription
};
```

### 4.2 Key Methods

#### 4.2.1 Step Method

```cpp
void Blk_arctrim::step() {
    const Maverick::Rvector::K u(in_u.get_mblock());
    Maverick::Rvector du(&out_du.val[0], out_du.get_num_elements());
    du.copy(u.kvec);
    trimarray[id].step(du);
}
```

The step method:
1. Gets the input control vector
2. Creates a vector for the output trim values
3. Copies the input vector to the output vector
4. Applies the trim values to the output vector

#### 4.2.2 Command Interface

```cpp
void Blk_arctrim::cset_cmd(Base::Lossy_error& str) {
    bool cmd_update = false;
    bool cmd_save = false;
    str.get_bool16(cmd_update);
    str.get_bool16(cmd_save);
    trimarray[id].cmd_set(cmd_update, cmd_save);
}

void Blk_arctrim::cget_cmd(Base::Lossy& str) const {
    bool cmd_update = false;
    bool cmd_save = false;
    trimarray[id].cmd_get(cmd_update, cmd_save);
    str.put_bool16(cmd_update);
    str.put_bool16(cmd_save);
}
```

The command interface:
1. Allows updating the current trim values based on the current control inputs
2. Allows saving the trim values for persistent storage
3. Provides a way to query the current trim command state

## 5. Gimbal Control System (`Blk_gimbal`)

The gimbal control system manages a 3-degree-of-freedom gimbal device, allowing for stabilization and pointing control.

### 5.1 Structure and Attributes

```cpp
class Blk_gimbal : public Blocks::Iblock, public Blocks::Icmdblock {
private:
    Base::Chrono clk;                    // Chronometer
    Gimbal g;                            // Gimbal manager
    Blocks::Cmdsubs cmds;                // Command subscription

    // Input pins
    Blocks::Pin_ptr_opt<bool> pos_ctrl;  // True if in position control
    Blocks::Pin_ptr_opt<Real> azc;       // Commanded azimuth value (NED)
    Blocks::Pin_ptr_opt<Real> elc;       // Commanded elevation value (NED)
    Blocks::Pin_ptr_opt<Real> roc;       // Commanded roll value (NED)
    Blocks::Pin_ptr_opt<Real> razc;      // Commanded azimuth rate (NED)
    Blocks::Pin_ptr_opt<Real> relc;      // Commanded elevation rate (NED)
    Blocks::Pin_ptr_opt<Real> rroc;      // Commanded roll rate (NED)

    // Output pins
    Blocks::Pin<bool> tc;                // True if block is being remotely telecommanded
    Blocks::Pin<Real> j0;                // Output joint 0
    Blocks::Pin<Real> j1;                // Output joint 1
    Blocks::Pin<Real> j2;                // Output joint 2
    Blocks::Pin<Geo::Apos> point;        // Pointed position
};
```

### 5.2 Key Methods

#### 5.2.1 Step Method

```cpp
void Blk_gimbal::step() {
    if (pos_ctrl.read(false)) {
        g.set_cmd(Maverick::Rvector3(azc.read(0.0F), elc.read(0.0F), roc.read(0.0F)));
    } else {
        g.set_cmd_rate(clk.step(), Maverick::Rvector3(razc.read(0.0F), relc.read(0.0F), rroc.read(0.0F)));
    }
    tc.val = g.step();
    j0.val = g.get_joints()[Ku16::u0];
    j1.val = g.get_joints()[Ku16::u1];
    j2.val = g.get_joints()[Ku16::u2];
    point.val.copynr(g.get_target());
}
```

The step method:
1. Determines whether to use position control or rate control based on the `pos_ctrl` input
2. Sets the gimbal command accordingly (position or rate)
3. Executes the gimbal step to update joint positions
4. Updates output pins with joint values and target position

### 5.3 Gimbal Manager (`Gimbal`)

The `Gimbal` class handles the core gimbal control logic, including different mount types and control modes.

#### 5.3.1 Structure and Attributes

```cpp
class Gimbal {
public:
    enum Mode {
        g_no_command = 0,   // Pointing according to external input
        g_body       = 1,   // Pointing with constant joint parameters
        g_ned        = 2,   // Pointing towards some NED direction
        g_target     = 3,   // Pointing towards some target
        g_cmddelta   = 4    // Increment in last cmd (body or NED)
    };

private:
    class Gmount {
    public:
        enum Logic {
            l_servo   = 0,         // conventional gimbal
            l_board   = 1,         // self-stabilized gimbal (apparent servo)
            logic_all = 2          // limit logic
        };
        enum Type {
            t_32     = 0,          // pan-tilt as 3-2 rotation from b to g
            t_312    = 1,          // pan-roll-tilt as 3-1-2 rotation from b to g
            t_12     = 2,          // roll-tilt as 3-1-2 rotation from b to g
            type_all = 3
        };
        
        Logic logic;               // Logic to control the gimbal
        Type type;                 // Type of gimbal mount
        Maverick::Rvector3 GPb;    // vector from base's G to gimbal (P)
        Maverick::Rmatrix3 Lsb;    // Transformation matrix from gimbal frame to body frame
        Maverick::Rvector3 joint;  // Joint parameters (e.g. pan, tilt)
        Real K_roll_rate;          // Roll rate compensation for roll-pitch gimbal
        Real K_pitch_rate;         // Pitch rate compensation for roll-pitch gimbal
        Base::Radrng limits_j0;    // Limits for joint 0
        Base::Radrng limits_j1;    // Limits for joint 1
        Base::Radrng limits_j2;    // Limits for joint 2
    };
    
    class Gcmd {
    private:
        Base::Rv3 cmddata;         // Command data
        Maverick::Irvector3 cmd;   // Command parameters
    };
    
    const Dynamics::Rigidbody& base;  // Reference to base body
    const Vblocks::Iarcxset& arcx;    // Arcade axes
    bool commanding;                  // True if the gimbal is being commanded
    Gmount mount;                     // Gimbal mount
    Mode m;                           // Pointing mode
    Uint16 arcx_sel;                  // Selected axis configuration
    Gcmd cmd;                         // Command parameters
    Geo::Frefcache target_cmd;        // Commanded target
    Geo::Apos target_proj;            // Projected target
    Maverick::Rmatrix3 Lng;           // rotation matrix Ned frame-gimbal desired orientation
    Maverick::Rmatrix3 Lng_f;         // rotation matrix Ned frame-gimbal commanded orientation
    Maverick::Irvector3 ined;         // vertical image axis unit vector (ned)
    Maverick::Rmatrix3 Lbg;           // rotation matrix body-gimbal desired orientation
    Maverick::Rmatrix3 Lsg;           // rotation matrix sensor-gimbal desired orientation
    Maverick::Rvector3 rn;            // work vector
};
```

#### 5.3.2 Gimbal Control Algorithm

```cpp
bool Gimbal::step() {
    // Compute gimbal position based on mode
    switch (m) {
        case g_no_command:
            set_ned(cmd.get());
            break;
        case g_body:
            set_body();
            set_joints();
            break;
        case g_ned:
            Maverick::Rvector3 azeld;
            azeld.copy(cmd.get());
            azeld[0] += Rfun::wrap2pi(arcx.get_angle_axis0(arcx_sel)); // insert offset pan
            set_ned(azeld);
            break;
        case g_target:
            // Calculate direction to target
            target_cmd.refresh();
            Maverick::Rvector3 r;
            base.get_pos().relthis(target_cmd.get_pos(), r);
            Maverick::Rvector3 aux;
            base.b2n(mount.GPb, aux);
            r.vecsub(aux);
            r.azeld(aux[u0], aux[u1], aux[u2]);
            aux[u2] = 0;
            set_ned(aux);
            break;
    }
    
    // Apply limits to joints
    mount.apply_limits();
    
    // Compute target pointing
    compute_Lng();
    
    // Calculate target projection if not in target mode
    if (m != g_target) {
        // Complex algorithm to compute where the gimbal is pointing on the ground
        // [Implementation details omitted for brevity]
    } else {
        target_cmd.refresh();
    }
    
    return (m != g_no_command);
}
```

The gimbal step method:
1. Updates the gimbal position based on the current mode:
   - `g_no_command`: Uses the current command values directly
   - `g_body`: Sets the gimbal orientation in body frame
   - `g_ned`: Sets the gimbal orientation in NED frame, with arcade offset
   - `g_target`: Points the gimbal at a specific target position
2. Applies joint limits to ensure the gimbal stays within its physical constraints
3. Computes the actual gimbal orientation based on the joint positions
4. Calculates where the gimbal is pointing on the ground
5. Returns whether the gimbal is being commanded

#### 5.3.3 Gimbal Mount Types

The gimbal system supports three different mount types:
1. **Pan-Tilt (t_32)**: A 3-2 rotation sequence (yaw-pitch)
2. **Pan-Roll-Tilt (t_312)**: A 3-1-2 rotation sequence (yaw-roll-pitch)
3. **Roll-Tilt (t_12)**: A 1-2 rotation sequence (roll-pitch)

Each mount type has different joint-to-orientation conversion methods:

```cpp
void Gimbal::Gmount::Lbg2joint(const Maverick::Rmatrix3& Lbg) {
    switch(type) {
        case t_32:
            joint[Base::Coord::az] = Rmath::atan2r(Lbg[u1], Lbg[u0]);
            joint[Base::Coord::el] = -Rfun::asinw(Lbg[u2]);
            joint[Base::Coord::rll] = Const::ZERO;
            break;
        case t_312:
            joint[Base::Coord::rll] = Rfun::asinw(Lbg[u5]);
            joint[Base::Coord::az] = Rmath::atan2r(-Lbg[u3], Lbg[u4]);
            joint[Base::Coord::el] = Rfun::asinw(-Lbg[u2]/Rmath::cosr(joint[Base::Coord::rll]));
            break;
        case t_12:
            joint[Base::Coord::rll] = Rfun::asinw(Lbg[u5]);
            joint[Base::Coord::az] = 0;
            joint[Base::Coord::el] = Rfun::asinw(-Lbg[u2]/Rmath::cosr(joint[Base::Coord::rll]));
            break;
    }
}
```

#### 5.3.4 Gimbal Control Modes

The gimbal system supports two control logics:
1. **Conventional Gimbal (l_servo)**: The gimbal joints are directly controlled
2. **Self-Stabilized Gimbal (l_board)**: The gimbal maintains its orientation in NED frame

```cpp
void Gimbal::set_ned(const Maverick::Irvector3& azeld) {
    switch (mount.type) {
        case Gmount::t_32:
        case Gmount::t_312:
            mount.joint2Lbg(azeld, Lng);     // Calculate rotation matrix Lng based on commanded angles
            Lbg.matmat(base.get_Lbn(), Lng); // Compute Lbg
            Lsg.matmat(mount.Lsb, Lbg);
            set_joints();
            break;
        case Gmount::t_12:
            const Maverick::Irvector3& ypr = base.get_ypr();
            if (mount.logic == Gmount::l_servo) {
                mount.joint[Base::Coord::rll] = azeld[Base::Coord::rll] - ypr[Base::Coord::roll];
                mount.joint[Base::Coord::el] = azeld[Base::Coord::pitch] - ypr[Base::Coord::pitch];
                mount.joint[Base::Coord::az] = 0;
            } else if (mount.logic == Gmount::l_board) {
                mount.joint[Base::Coord::rll] = azeld[Base::Coord::rll];
                mount.joint[Base::Coord::el] = azeld[Base::Coord::el];
                mount.joint[Base::Coord::az] = 0;
            }
            rates_compensation();
            break;
    }
}
```

## 6. Flight Envelope Configuration (`Blk_envelope`)

The flight envelope configuration block provides a way to configure the current guidance flight envelope.

### 6.1 Structure and Attributes

```cpp
class Blk_envelope : public Blocks::Iblock {
private:
    Blocks::Pin<Vpgnc::Envelope> out;  // Envelope configuration
};
```

### 6.2 Key Methods

```cpp
void Blk_envelope::cset(Base::Lossy_error& str, Csetpm& params) {
    out.val.cset(str);
}

const Blocks::Ipin* Blk_envelope::get_out(Uint16 i) const {
    return Base::Paramsel::select<Blocks::Ipin>(i, out);
}
```

The envelope block:
1. Deserializes the envelope configuration from PDI
2. Provides the envelope configuration as an output

## 7. Cross-Component Relationships

### 7.1 Arcade Control Flow

```
User Input (Stick) → Blk_arcade0 Variants → Control Outputs
                                   ↓
                        Blk_arctrim (Trim System)
                                   ↓
                          Vehicle Control System
```

1. User provides stick inputs
2. Arcade blocks process these inputs based on mode and phase
3. Trim system applies stored trim values
4. Resulting control values are sent to the vehicle control system

### 7.2 Gimbal Control Flow

```
User/System Commands → Blk_gimbal → Gimbal Class → Joint Outputs
                          ↑             ↑
                          |             |
                     Arcade System   Vehicle State
```

1. Commands come from user inputs or system automation
2. The gimbal block processes these commands
3. The gimbal class computes joint positions based on the commands and vehicle state
4. Joint outputs control the physical gimbal hardware

### 7.3 Integration with Arcade System

The gimbal system integrates with the arcade system through the `Iarcxset` interface:

```cpp
class Iarcxset {
public:
    virtual Real get_angle_axis0(Uint16 idx) const = 0;
};
```

This interface allows the gimbal to get the current arcade axis angle, which is used as an offset for the gimbal pan angle in NED mode:

```cpp
case g_ned:
    Maverick::Rvector3 azeld;
    azeld.copy(cmd.get());
    azeld[0] += Rfun::wrap2pi(arcx.get_angle_axis0(arcx_sel)); // insert offset pan
    set_ned(azeld);
    break;
```

## 8. Arcade Control System Behavior

### 8.1 Mode Selection

The arcade system operates based on the current mode for a specific channel:

```cpp
if (vmodetable.get_current_mode(channel) == Mode::arcade_g) {
    // Arcade processing
}
```

This allows different channels to be in different modes (arcade, manual, etc.).

### 8.2 Phase-Based Configuration

The arcade system uses the current phase to select the appropriate arcade configuration:

```cpp
static const Bsp::Huvar phase(Base::vu_phase);              // Arcade getter handler
static const Uint16 not_found = 0xFFFFU;                    // Used to identify cases not configured in map
const Uint16 arc_id = map.get_value(phase.get(), not_found); // zero is default case -> arcade disabled
```

This allows different arcade behaviors for different flight phases.

### 8.3 Arcade Value Computation

Each arcade configuration applies transformations to the raw stick input:

```cpp
out_enabled.val = compute(arc[arc_id].compute(in_stick.read()), out.val);
```

The `Arcadecfg::compute` method applies:
1. Dead-band filtering (ignoring small stick movements)
2. Gain scaling (adjusting sensitivity)
3. Zero offset correction (accounting for stick center position)

### 8.4 Variant-Specific Behaviors

#### 8.4.1 Pure Arcade

- Simplest behavior
- Can be configured to enable arcade even when stick is at zero position
- Otherwise, only enables arcade when stick is not at zero

#### 8.4.2 Bounce Arcade

- Smooths transitions from arcade to auto mode
- Detects when the controlled variable changes sign after arcade is disabled
- Re-enables arcade briefly to prevent "bounce" effects

#### 8.4.3 Extended Arcade

- Extends arcade control beyond when the stick is released
- Continues arcade control until the derivative of the controlled variable is small
- Provides smoother transitions from arcade to auto mode

## 9. Gimbal System Behavior

### 9.1 Control Modes

The gimbal system supports several control modes:

1. **No Command Mode**: Gimbal is controlled by external inputs
2. **Body Mode**: Gimbal maintains a constant orientation relative to the vehicle body
3. **NED Mode**: Gimbal points in a specific direction in the NED frame
4. **Target Mode**: Gimbal points at a specific geographic target
5. **Command Delta Mode**: Incremental adjustment to the current command

### 9.2 Mount Types and Logic

The gimbal system supports different mount types and control logics:

#### 9.2.1 Mount Types

1. **Pan-Tilt (t_32)**: A 3-2 rotation sequence (yaw-pitch)
2. **Pan-Roll-Tilt (t_312)**: A 3-1-2 rotation sequence (yaw-roll-pitch)
3. **Roll-Tilt (t_12)**: A 1-2 rotation sequence (roll-pitch)

#### 9.2.2 Control Logics

1. **Conventional Gimbal (l_servo)**: The gimbal joints are directly controlled
2. **Self-Stabilized Gimbal (l_board)**: The gimbal maintains its orientation in NED frame

### 9.3 Joint Limits and Rate Compensation

The gimbal system applies limits to joint angles to prevent exceeding physical constraints:

```cpp
void Gimbal::Gmount::apply_limits() {
    joint[Ku16::u0] = Rfun::wrap2pi(limits_j0.wrap(joint[Ku16::u0]));
    joint[Ku16::u1] = Rfun::wrap2pi(limits_j1.wrap(joint[Ku16::u1]));
    joint[Ku16::u2] = Rfun::wrap2pi(limits_j2.wrap(joint[Ku16::u2]));
}
```

It also applies rate compensation to counteract vehicle motion:

```cpp
void Gimbal::rates_compensation() {
    const Maverick::Irvector3& pqr = base.get_pqr();
    const Maverick::Irvector3& ypr = base.get_ypr();
    
    Real roll_rate = pqr[Ku16::u0] + (Rmath::tanr(ypr[Base::Coord::pitch]) *
                    (pqr[Ku16::u1] * Rmath::sinr(ypr[Base::Coord::roll]) +
                     pqr[Ku16::u2] * Rmath::cosr(ypr[Base::Coord::roll])));
    Real pitch_rate = Rmath::cosr(ypr[Base::Coord::pitch])*pqr[Ku16::u1] -
                      Rmath::sinr(ypr[Base::Coord::roll])*pqr[Ku16::u2];
    
    mount.joint[Base::Coord::roll] -= roll_rate*mount.K_roll_rate;
    mount.joint[Base::Coord::pitch]-= pitch_rate*mount.K_pitch_rate;
}
```

## 10. Summary

The VBlocks library provides a comprehensive arcade control and gimbal management system with the following key components:

1. **Base Arcade Block (`Blk_arcade0`)**: Abstract base class for arcade control blocks
   - Processes stick inputs based on mode and phase
   - Applies arcade transformations (dead-band, gain, zero offset)
   - Provides outputs for arcade value and enabled state

2. **Arcade Block Variants**:
   - **Pure Arcade (`Blk_arcade_pure`)**: Simple pass-through of arcade values
   - **Bounce Arcade (`Blk_arcade_bounce`)**: Smooths transitions from arcade to auto mode
   - **Extended Arcade (`Blk_arcade_extend`)**: Extends arcade control until vehicle stabilizes

3. **Arcade Trim System (`Blk_arctrim`)**: 
   - Stores and applies trim values to control inputs
   - Allows updating and saving trim values via commands
   - Supports multiple trim configurations

4. **Gimbal Control System (`Blk_gimbal`)**:
   - Manages a 3-degree-of-freedom gimbal device
   - Supports position and rate control modes
   - Provides outputs for joint positions and target position

5. **Gimbal Manager (`Gimbal`)**:
   - Implements different control modes (no command, body, NED, target)
   - Supports different mount types (pan-tilt, pan-roll-tilt, roll-tilt)
   - Applies joint limits and rate compensation
   - Calculates target projection on the ground

6. **Flight Envelope Configuration (`Blk_envelope`)**:
   - Configures the guidance flight envelope
   - Provides envelope configuration as an output

The arcade control system and gimbal management system work together to provide intuitive control of vehicle movement and camera pointing, with various options for smoothing transitions and extending control beyond direct stick inputs.