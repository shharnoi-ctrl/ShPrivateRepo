# Generated from:

- code/sw_vbootloader_astro/code/source_astro/Halsuite_2838x_astro.cpp (3842 tokens)
- code/sw_vbootloader_astro/code/source_astro/Sysuid_cpu1_amz.cpp (1438 tokens)
- code/sw_vbootloader_astro_cm/code/include_astro/Bldr_defs.h (108 tokens)

## With context from:

- PackageSummaries/Amazon-PrimeAir/items/ASTRO/items/sw/sw_vbootloader_astro/04_Bootloader_Core_Architecture.md (2297 tokens)

---

# Hardware Abstraction Layer for Astro Platform

## 1. Hardware Identification and Configuration System

The Astro platform implements a sophisticated hardware abstraction layer that identifies hardware variants through GPIO pins and maps functional requirements to hardware-specific configurations. This system enables the same codebase to support multiple hardware variants with different peripheral layouts.

### 1.1 UID Determination Process

The platform uses a combination of GPIO pins to determine the hardware variant and application type, which together form a Unique Identifier (UID) for the device:

```cpp
Uid64 get_uid_aux()
{
    // Wait 150ms after power-up to ensure stable GPIO readings
    Dsp28335_ent::Delay::ms(150);
    
    // Configure hardware revision GPIO pins as inputs with pull-up
    Dsp28335_ent::GPIOioctl::apply(Ver::GPIOname::gpio_hw_id0, cfg);
    Dsp28335_ent::GPIOioctl::apply(Ver::GPIOname::gpio_hw_id1, cfg);
    Dsp28335_ent::GPIOioctl::apply(Ver::GPIOname::gpio_hw_id2, cfg);
    Dsp28335_ent::GPIOioctl::apply(Ver::GPIOname::gpio_hw_id3, cfg);
    
    // Read hardware revision ID from GPIO pins
    Uint8 rev_id = 0;
    rev_id  = Dsp28335_ent::GPIO(Ver::GPIOname::gpio_hw_id0).get();
    rev_id = (rev_id | (Dsp28335_ent::GPIO(Ver::GPIOname::gpio_hw_id1).get() << Ku32::u1));
    rev_id = (rev_id | (Dsp28335_ent::GPIO(Ver::GPIOname::gpio_hw_id2).get() << Ku32::u2));
    rev_id = (rev_id | (Dsp28335_ent::GPIO(Ver::GPIOname::gpio_hw_id3).get() << Ku32::u3));
    
    // Select appropriate configuration pins based on hardware revision
    Dsp28335_ent::GPIOid gpio_config_b0 = (rev_id <= ev2) ? 
        Ver::GPIOname::gpio_config_b0 : Ver::GPIOname::gpio_config_b0_ev2;
    
    // Configure and read application configuration pins
    Dsp28335_ent::GPIOioctl::apply_input(gpio_config_b0);
    Dsp28335_ent::GPIOioctl::apply_input(Ver::GPIOname::gpio_config_b1);
    
    Uint8 compute_config = 0;
    compute_config = Dsp28335_ent::GPIO(gpio_config_b0).get();
    compute_config = (compute_config | (Dsp28335_ent::GPIO(Ver::GPIOname::gpio_config_b1).get() << Ku32::u1));
    
    // Initialize UID with default values
    Uid64 otp_uid = { 0 };
    otp_uid.app = Bsp::sapp_par_nav; // Default application type
    otp_uid.phy = 12345;             // Default physical ID
    otp_uid.hwv = 5;                 // Hardware version
    otp_uid.res = rev_id;            // Store revision ID in reserved field
    
    // Determine application type and node ID based on hardware revision and configuration
    // [Configuration logic follows...]
}
```

#### Hardware Revision Identification

The system uses four GPIO pins to identify the hardware revision:
- `gpio_hw_id0` (GPIO 9)
- `gpio_hw_id1` (GPIO 10)
- `gpio_hw_id2` (GPIO 11)
- `gpio_hw_id3` (GPIO 12)

These pins are read to form a 4-bit revision ID that identifies hardware variants:
- `ev1` = 0x01
- `ev1_res` = 0x02
- `ev2` = 0x05
- `dv1` = 0x11

#### Application Type Determination

Based on the hardware revision, the system reads additional configuration pins:
- For older revisions (≤ ev2): `gpio_config_b0` = GPIO 8
- For newer revisions: `gpio_config_b0` = GPIO 22
- For all revisions: `gpio_config_b1` = GPIO 126

These pins form a 2-bit configuration value that determines the application type:

| Hardware Revision | Config Value | Application Type | Node ID | App Enum |
|------------------|--------------|------------------|---------|----------|
| ≤ ev1_res        | 1            | Monitor          | 22      | sapp_pam |
| ≤ ev1_res        | 2            | Recovery (Nav)   | 28      | sapp_par_nav |
| > ev1_res        | 1            | Monitor          | 22      | sapp_pam |
| > ev1_res        | 2            | Recovery (Ctrl)  | 31      | sapp_par_ctrl |
| > ev1_res        | 3            | Recovery (Nav)   | 28      | sapp_par_nav |

### 1.2 UID Caching Mechanism

The system implements a caching mechanism for the UID to avoid repeated GPIO reads:

```cpp
Uid64 get_uid(bool force_read)
{
    static Uid64 otp_uid = get_uid_aux();
    if(force_read)
    {
        otp_uid = get_uid_aux();
    }
    return otp_uid;
}
```

This function returns a cached UID unless `force_read` is true, in which case it re-reads the GPIO pins to determine the UID.

## 2. Hardware Abstraction for Peripherals

The `Halsuite` class provides a comprehensive hardware abstraction layer that maps functional requirements to hardware-specific configurations based on the device's UID.

### 2.1 GPIO Configuration Mapping

The `get_cfg` method maps functional requirements to GPIO configurations based on the device's application type and hardware version:

```cpp
Halsuite::GPIOcfg Halsuite::get_cfg(GPIOfunc f, Bsp::Uid64 uid)
{
    // Default configuration
    GPIOcfg res = { gpio_000, cfg_gpio_out, GPIOioctl::c1 };
    
    // Hardware version threshold for certain configurations
    static const Uint16 hwv_4_10 = 5U;
    
    switch(f)
    {
        case f_led_red:
            // LED configuration based on application type
            switch(uid.app)
            {
                case sapp_mc110_v2:
                    res.b.id = Dsp28335_ent::gpio_071;
                    break;
                case sapp_par_nav:
                case sapp_pam:
                case sapp_par_ctrl:
                case sapp_uapp:  // Veronte/Astro
                    res.b.id = Dsp28335_ent::gpio_128;
                    break;
                case sapp_386_ccard:
                    res.b.id = Dsp28335_ent::gpio_031;
                    res.core = Dsp28335_ent::GPIOioctl::cm;
                    break;
                default:
                    Bsp::warning(); // App not supported
            }
            break;
            
        // [Additional function cases follow...]
    }
    
    return res;
}
```

### 2.2 GPIO Configuration Tables

The system defines standard GPIO configurations for different peripheral types:

#### LED GPIO Configurations

| Function | Application | GPIO ID | Direction | Pullup | Mux | Qualification | Core |
|----------|------------|---------|-----------|--------|-----|--------------|------|
| f_led_red | sapp_mc110_v2 | 71 | Output | Disabled | 0 | Sync | C1 |
| f_led_red | sapp_par_nav/pam/par_ctrl/uapp | 128 | Output | Disabled | 0 | Sync | C1 |
| f_led_red | sapp_386_ccard | 31 | Output | Disabled | 0 | Sync | CM |
| f_led_green | sapp_mc110_v2 | 70 | Output | Disabled | 0 | Sync | C1 |
| f_led_green | sapp_par_nav/pam/par_ctrl | 130 | Output | Disabled | 0 | Sync | C1 |
| f_led_green | sapp_uapp (<4.10) | 116 | Output | Disabled | 0 | Sync | C1 |
| f_led_green | sapp_uapp (≥4.10) | 129 | Output | Disabled | 0 | Sync | C1 |
| f_led_green | sapp_386_ccard | 34 | Output | Disabled | 0 | Sync | C1 |
| f_led_blue | sapp_pam/par_nav/par_ctrl | 129 | Output | Disabled | 0 | Sync | CM |

#### Serial Communication GPIO Configurations

| Function | Application | GPIO ID | Direction | Pullup | Mux | Qualification |
|----------|------------|---------|-----------|--------|-----|--------------|
| f_sci_a_tx | sapp_mc110_v2 | 140 | Output | Disabled | 6 | Sync |
| f_sci_a_tx | Others | 29 | Output | Disabled | 6 | Sync |
| f_sci_a_rx | sapp_mc110_v2 | 139 | Input | Disabled | 6 | Async |
| f_sci_a_rx | Others | 28 | Input | Disabled | 1 | Async |
| f_sci_b_tx | sapp_mc110_v2 | 142 | Output | Disabled | 6 | Sync |
| f_sci_b_tx | Others | 54 | Output | Disabled | 6 | Sync |
| f_sci_b_rx | sapp_mc110_v2 | 141 | Input | Disabled | 6 | Async |
| f_sci_b_rx | Others | 55 | Input | Disabled | 6 | Async |
| f_sci_c_tx | sapp_mc110_v2 | 153 | Output | Disabled | 6 | Sync |
| f_sci_c_tx | Others | 140 | Output | Disabled | 6 | Sync |
| f_sci_c_rx | sapp_mc110_v2 | 152 | Input | Disabled | 6 | Async |
| f_sci_c_rx | Others | 13 | Input | Disabled | 6 | Async |
| f_sci_d_tx | All | 142 | Output | Disabled | 6 | Sync |
| f_sci_d_rx | sapp_par_nav/pam/par_ctrl/uapp | 141 | Input | Disabled | 6 | Async |
| f_sci_d_rx | Others | 94 | Input | Disabled | 6 | Async |

#### CAN Bus GPIO Configurations

| Function | Application | GPIO ID | Direction | Pullup | Mux | Qualification |
|----------|------------|---------|-----------|--------|-----|--------------|
| f_can_a_tx | sapp_mc110_v2 | 37 | Output | Enabled | 3 | Sync |
| f_can_a_tx | Others | 4 | Output | Enabled | 6 | Sync |
| f_can_a_rx | All | 36 | Input | Enabled | 6 | Async |
| f_can_b_tx | sapp_mc110_v2 | 38 | Output | Enabled | 3 | Sync |
| f_can_b_tx | Others | 20 | Output | Enabled | 3 | Sync |
| f_can_b_rx | sapp_mc110_v2 | 39 | Input | Enabled | 3 | Async |
| f_can_b_rx | Others | 17 | Input | Enabled | 2 | Async |
| f_canfd_tx | All | 19 | Output | Enabled | 9 | Sync |
| f_canfd_rx | All | 18 | Input | Enabled | 9 | Async |

### 2.3 Ethernet MII Configuration

The system provides a fixed Ethernet MII configuration for the Communication Manager (CM) core:

```cpp
const Dsp28335_ent::CM_helpers::Pinout_mii& Halsuite::get_eth_cfg()
{
    static const CM_helpers::Pinout_mii cm_gpios =
    {
        { gpio_043, GPIOmux16::mux_11 },///< UARTCM_RX (RS232 CM)
        { gpio_042, GPIOmux16::mux_11 },///< UARTCM_TX (RS232 CM)
        {
            { gpio_105, GPIOmux16::mux_14 },///< ENET_MDIO_CLK
            { gpio_106, GPIOmux16::mux_14 },///< ENET_MDIO_DATA
            { gpio_109, GPIOmux16::mux_14 },///< ENET_MII_CRS
            { gpio_110, GPIOmux16::mux_14 },///< ENET_MII_COL
            { gpio_121, GPIOmux16::mux_14 },///< ENET_MII_TX_DATA0
            { gpio_060, GPIOmux16::mux_11 },///< ENET_MII_TX_DATA1
            { gpio_061, GPIOmux16::mux_11 },///< ENET_MII_TX_DATA2
            { gpio_062, GPIOmux16::mux_11 },///< ENET_MII_TX_DATA3
            { gpio_118, GPIOmux16::mux_14 },///< ENET_MII_TX_EN
            { gpio_114, GPIOmux16::mux_14 },///< ENET_MII_RX_DATA0
            { gpio_115, GPIOmux16::mux_14 },///< ENET_MII_RX_DATA1
            { gpio_116, GPIOmux16::mux_14 },///< ENET_MII_RX_DATA2
            { gpio_117, GPIOmux16::mux_14 },///< ENET_MII_RX_DATA3
            { gpio_all, GPIOmux16::mux_0  },///< ENET_MII_RX_ERR NOT USED IN PA
            { gpio_112, GPIOmux16::mux_14 },///< ENET_MII_RX_DV
            { gpio_120, GPIOmux16::mux_14 },///< ENET_MII_TX_CLK
            { gpio_111, GPIOmux16::mux_14 },///< ENET_MII_RX_CLK
            { gpio_all, GPIOmux16::mux_0 }, ///< ENET power down (not used)
            { gpio_all, GPIOmux16::mux_0 }  ///< ENET reset (not used)
        }
    };
    return cm_gpios;
}
```

This configuration defines the GPIO pins and multiplexer settings for the Ethernet MII interface, including:
- UART pins for CM core communication
- MDIO interface pins for PHY management
- MII data and control signals for Ethernet communication

## 3. Memory Layout for Communication Manager Core

The system defines specific memory regions for the Communication Manager (CM) core:

```cpp
static const Uint32 cm_bldr_start  = 0x200000UL;                   // Address where CM bootloader starts
static const Uint32 cm_bldr_size   =  0x20000UL;                   // CM bootloader max size (in bytes)
static const Uint32 cm_user_start  = cm_bldr_start + cm_bldr_size; // Address where CM user code starts
static const Uint32 cm_user_size   = 0x30000;                      // CM user code size (in bytes)
```

This memory layout defines:
- CM bootloader region: 0x200000 - 0x21FFFF (128KB)
- CM user code region: 0x220000 - 0x24FFFF (192KB)

These memory regions are used by the bootloader to manage code loading and execution on the CM core.

## 4. Periodic Processing in Hardware Abstraction Layer

The `Halsuite::step_hi()` method provides periodic processing for hardware interfaces:

```cpp
void Halsuite::step_hi()
{
    /// \alg
    scia_port.step();   /// - Call step for SCI-A
    scib_port.step();   /// - Call step for SCI-B
    scic_port.step();   /// - Call step for SCI-C
    scid_port.step();   /// - Call step for SCI-D

    cana.check_tx_tout();   /// Call CAN::check_tx_tout for ::cana.
    canb.check_tx_tout();   /// Call CAN::check_tx_tout for ::canb.
    can_fd.check_tx_tout(); /// Call CAN_FD::check_tx_tout for ::can_fd.
}
```

This method:
1. Processes all serial communication ports (SCI-A through SCI-D)
2. Checks for transmission timeouts on all CAN interfaces (CAN-A, CAN-B, and CAN-FD)

## Referenced Context Files

- **04_Bootloader_Core_Architecture.md**: Provided context about the overall bootloader architecture, including memory management, core initialization sequence, and inter-core communication mechanisms. This helped understand how the hardware abstraction layer integrates with the bootloader system, particularly regarding the CM core memory layout and initialization.