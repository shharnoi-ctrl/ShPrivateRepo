# Generated from:

- src/AdnVehicleRecoveryWrapperAlgorithms/tst/PACS_test.h (17437 tokens)
- src/AdnVehicleRecoveryWrapperAlgorithms/tst/RecoveryWrapper_test.cc (5106 tokens)

## With context from:

- Amazon-PrimeAir/items/ASTRO/items/Wrapper/02_Recovery_System_Integration.md (2771 tokens)

---

# Testing Approach for the Recovery System

## 1. Overall Testing Strategy

The recovery system testing approach focuses on validating the functionality of the recovery wrapper and its components through unit tests and integration tests. The tests verify the system's ability to detect switchover conditions, process navigation data, track routes, and generate appropriate control commands.

## 2. Test Fixtures and Environment

### 2.1 RecoveryWrapperFixture

The primary test fixture `RecoveryWrapperFixture` provides a controlled environment for testing the recovery wrapper functionality:

```cpp
class RecoveryWrapperFixture : public ::testing::Test {
public:
    RecoveryWrapperFixture() :
        filename_("tmp_switchover"),
        seq_num_(0) {
        switchover_.open(filename_.c_str());
        
        // Enable switchover
        param_.is_switchover_enabled = true;
        
        // Set PACS parameters
        PACSTestFixture pacs_test_fixture;
        // Configure control parameters from PACS test fixture
        // ...
    }
    
    // Test setup/teardown methods
    virtual void SetUp() override { /* ... */ }
    virtual void TearDown() override { /* ... */ }
    
    // Helper methods for test cases
    void SetSwitchover(bool should_switch) { /* ... */ }
    void EmplaceControllerCommand(vsdk::algorithm::recoverywrapper::Input& input, int seq_num) { /* ... */ }
    void EmplaceRouteCommandAndControl(vsdk::algorithm::recoverywrapper::Input& input, int seq_num) { /* ... */ }
    void EmplaceSensorData(vsdk::algorithm::recoverywrapper::Input& input) { /* ... */ }
    void PrepareRecoveryToRun(vsdk::algorithm::recoverywrapper::RecoveryWrapperObject& recovery_wrapper_object) { /* ... */ }
    
    // Test fixture members
    vsdk::algorithm::recoverywrapper::Param param_;
    vsdk::message::adn::vehicle::vms::ControllerCommand_0_1 controller_command_;
    vsdk::message::adn::vehicle::controlsystem::controlscommandprocessor::tp::RouteCommandAndControl_0_1 route_command_and_control_;
    vsdk::message::adn::vehicle::navigationandsensingsystem::MeasAccelGyro_0_1 meas_accel_gyro_;
    
    std::string filename_;
    std::ofstream switchover_;
    int seq_num_;
};
```

### 2.2 PACSTestFixture

A supporting test fixture `PACSTestFixture` provides control system parameters for testing:

```cpp
class PACSTestFixture {
public:
    PACSTestFixture() {
        // Define common parameters
        common_parameters.R_fw_from_bul[0] = {1,0,0};
        // ...
        
        // Define SEP params
        // ...
        
        // Define ASC
        // ...
        
        // Define AACG
        // ...
        
        // Define DCG
        // ...
        
        // Define TSC
        // ...
        
        // Define Force & Moment gains
        // ...
    }
    
    // Member variables for different control system components
    ::controllers::pacs::common::PacsCommonParam common_parameters;
    pacs::common::Param_0_1 vsdk_common_parameters;
    // ...and many other control system parameters
};
```

### 2.3 TranslationalStateControllerParameters

A specialized class for configuring the translational state controller parameters:

```cpp
class TranslationalStateControllerParameters {
public:
    TranslationalStateControllerParameters() {
        // Configure horizontal controller parameters
        // ...
        
        // Configure vertical controller parameters
        // ...
        
        // Configure TEE parameters
        // ...
        
        // Configure TSC parameters
        // ...
    }
    
    // Member variables for controller parameters
    ::controllers::pacs::common::PacsCommonParam common_param;
    ::controllers::pacs::common::genericstatespace::modeldynamic::PacsModelDynamicParamNoReset ss_pv_param;
    // ...and many other controller parameters
};
```

## 3. Key Test Cases

### 3.1 Basic Construction and Operation

```cpp
TEST_F(RecoveryWrapperFixture, ConstructsAndRuns) {
    vsdk::test::TestAlgorithmPlatformAbstractionLayer algo_pal;
    param_.bypass_nav = true;
    vsdk::algorithm::recoverywrapper::RecoveryWrapperObject recovery{param_, algo_pal};
    vsdk::algorithm::recoverywrapper::Input input;
    vsdk::algorithm::recoverywrapper::Output output;
    
    // Set up basic sensor data
    vsdk::message::adn::vehicle::navigationandsensingsystem::MeasAccelGyro_0_1 meas_accel_gyro;
    meas_accel_gyro.data_valid = 1;
    meas_accel_gyro.average_accel_m_per_s2[0] = 0;
    vsdk::algorithm::recoverywrapper::Input::_vsdk_meas_accelgyroMessageEnvelope imu_envelope;
    imu_envelope.message = meas_accel_gyro;
    input.meas_accelgyro.emplace_back(imu_envelope);
    
    // Add state estimate
    vsdk::message::adn::vehicle::navigationandsensingsystem::StateEstimate_0_1 state_estimate;
    vsdk::algorithm::recoverywrapper::Input::_vsdk_state_estimateMessageEnvelope envelope;
    state_estimate.latitude_rad = 0;
    envelope.message = state_estimate;
    input.state_estimate.emplace_back(envelope);
    
    // Verify the recovery system runs without throwing exceptions
    EXPECT_NO_THROW(recovery.run(input, output));
}
```

### 3.2 Route Input Processing

```cpp
TEST_F(RecoveryWrapperFixture, RouteInput) {
    vsdk::test::TestAlgorithmPlatformAbstractionLayer algo_pal;
    vsdk::algorithm::recoverywrapper::Input input;
    vsdk::algorithm::recoverywrapper::Output output;
    vsdk::algorithm::recoverywrapper::State state;
    vsdk::algorithm::recoverywrapper::RecoveryWrapperObject recovery{param_, algo_pal};
    EmplaceSensorData(input);
    
    // Run recovery system with basic input
    EXPECT_EQ(vsdk::Status::Success, recovery.run(input, output));
    
    // Verify initial route status
    recovery.getState(state);
    const auto& route_tracker_state = state.route_tracker;
    EXPECT_EQ(RecoveryRouteStatus::UNAVAILABLE, route_tracker_state.takeoff_to_delivery_route_info.status.value);
    EXPECT_EQ(RecoveryRouteStatus::UNAVAILABLE, route_tracker_state.delivery_to_land_route_info.status.value);
    EXPECT_EQ(RecoveryRouteStatus::UNAVAILABLE, route_tracker_state.takeoff_to_land_route_info.status.value);
    EXPECT_EQ(0, route_tracker_state.return_home_route_info.size());
    
    // Prepare recovery system and add a return home route
    PrepareRecoveryToRun(recovery);
    vsdk::algorithm::recoverywrapper::Input input2;
    vsdk::algorithm::recoverywrapper::Output output2;
    route_command_and_control_.route.id = 1005; // RH route
    route_command_and_control_.route.status.value = RouteStatusMsg::GENERATED;
    route_command_and_control_.route.maneuvers.resize(1);
    EmplaceRouteCommandAndControl(input2);
    EmplaceSensorData(input2);
    
    // Run recovery system with return home route
    EXPECT_EQ(vsdk::Status::Success, recovery.run(input2, output2));
    
    // Verify return home route was processed
    recovery.getState(state);
    const auto& updated_route_tracker_state = state.route_tracker;
    EXPECT_EQ(1, updated_route_tracker_state.return_home_route_info.size());
}
```

### 3.3 Route Input Increments

```cpp
TEST_F(RecoveryWrapperFixture, RouteInputIncrements) {
    vsdk::test::TestAlgorithmPlatformAbstractionLayer algo_pal;
    vsdk::algorithm::recoverywrapper::State state;
    vsdk::algorithm::recoverywrapper::RecoveryWrapperObject recovery{param_, algo_pal};
    
    // Test adding delivery to landing route
    {
        PrepareRecoveryToRun(recovery);
        vsdk::algorithm::recoverywrapper::Input input;
        vsdk::algorithm::recoverywrapper::Output output;
        EmplaceSensorData(input);
        route_command_and_control_.route.id = 2; // Delivery to landing route
        route_command_and_control_.route.status.value = RouteStatusMsg::GENERATED;
        route_command_and_control_.route.maneuvers.resize(1);
        EmplaceRouteCommandAndControl(input);
        EXPECT_EQ(vsdk::Status::Success, recovery.run(input, output));
        
        // Verify delivery to landing route was processed
        recovery.getState(state);
        const auto& route_tracker_state = state.route_tracker;
        EXPECT_EQ(RecoveryRouteStatus::READY, route_tracker_state.delivery_to_land_route_info.status.value);
    }
    
    // Test adding return home route
    {
        PrepareRecoveryToRun(recovery);
        vsdk::algorithm::recoverywrapper::Input input;
        vsdk::algorithm::recoverywrapper::Output output;
        EmplaceSensorData(input);
        route_command_and_control_.route.id = 1005; // RH route
        route_command_and_control_.route.status.value = RouteStatusMsg::GENERATED;
        route_command_and_control_.route.maneuvers.resize(1);
        EmplaceRouteCommandAndControl(input);
        EXPECT_EQ(vsdk::Status::Success, recovery.run(input, output));
        
        // Verify return home route was added
        recovery.getState(state);
        const auto& route_tracker_state = state.route_tracker;
        EXPECT_EQ(1, route_tracker_state.return_home_route_info.size());
    }
    
    // Test adding another return home route
    {
        PrepareRecoveryToRun(recovery);
        vsdk::algorithm::recoverywrapper::Input input;
        vsdk::algorithm::recoverywrapper::Output output;
        EmplaceSensorData(input);
        route_command_and_control_.route.id = 1006; // Another RH route
        EmplaceRouteCommandAndControl(input);
        RecoveryLane_Y.RecoveryControllerLogs_mjme.recovery_state_machine_logs.recovery_state = ControlSystemFlightPhase::ReadyForInAirTakeOver;
        EXPECT_EQ(vsdk::Status::Success, recovery.run(input, output));
        
        // Verify second return home route was added
        recovery.getState(state);
        const auto& route_tracker_state = state.route_tracker;
        EXPECT_EQ(2, route_tracker_state.return_home_route_info.size());
    }
    
    // Test adding takeoff to delivery route
    {
        PrepareRecoveryToRun(recovery);
        vsdk::algorithm::recoverywrapper::Input input;
        vsdk::algorithm::recoverywrapper::Output output;
        EmplaceSensorData(input);
        route_command_and_control_.route.id = 1; // Take Off To Delivery
        EmplaceRouteCommandAndControl(input);
        RecoveryLane_Y.RecoveryControllerLogs_mjme.recovery_state_machine_logs.recovery_state = ControlSystemFlightPhase::ReadyForInAirTakeOver;
        EXPECT_EQ(vsdk::Status::Success, recovery.run(input, output));
        
        // Verify takeoff to delivery route was added
        recovery.getState(state);
        const auto& route_tracker_state = state.route_tracker;
        EXPECT_EQ(RecoveryRouteStatus::READY, route_tracker_state.takeoff_to_delivery_route_info.status.value);
    }
    
    // Test adding takeoff to landing route
    {
        PrepareRecoveryToRun(recovery);
        vsdk::algorithm::recoverywrapper::Input input;
        vsdk::algorithm::recoverywrapper::Output output;
        EmplaceSensorData(input);
        route_command_and_control_.route.id = 3; // Take Off To Landing
        EmplaceRouteCommandAndControl(input);
        RecoveryLane_Y.RecoveryControllerLogs_mjme.recovery_state_machine_logs.recovery_state = ControlSystemFlightPhase::ReadyForInAirTakeOver;
        EXPECT_EQ(vsdk::Status::Success, recovery.run(input, output));
        
        // Verify takeoff to landing route was added
        recovery.getState(state);
        const auto& route_tracker_state = state.route_tracker;
        EXPECT_EQ(RecoveryRouteStatus::READY, route_tracker_state.takeoff_to_land_route_info.status.value);
    }
}
```

### 3.4 Pretakeoff Command Ends Route Acceptance

```cpp
TEST_F(RecoveryWrapperFixture, PretakeoffCommandEndsRouteAcceptance) {
    vsdk::test::TestAlgorithmPlatformAbstractionLayer algo_pal;
    vsdk::algorithm::recoverywrapper::State state;
    vsdk::algorithm::recoverywrapper::RecoveryWrapperObject recovery{param_, algo_pal};
    
    // Add a return home route
    {
        PrepareRecoveryToRun(recovery);
        vsdk::algorithm::recoverywrapper::Input input;
        vsdk::algorithm::recoverywrapper::Output output;
        route_command_and_control_.route.id = 1005; // RH route
        route_command_and_control_.route.status.value = RouteStatusMsg::GENERATED;
        route_command_and_control_.route.maneuvers.resize(1);
        EmplaceRouteCommandAndControl(input);
        EmplaceSensorData(input);
        EXPECT_EQ(vsdk::Status::Success, recovery.run(input, output));
        
        // Verify return home route was added
        recovery.getState(state);
        const auto& route_tracker_state = state.route_tracker;
        EXPECT_EQ(1, route_tracker_state.return_home_route_info.size());
    }
    
    // Send pretakeoff check command
    {
        PrepareRecoveryToRun(recovery);
        vsdk::algorithm::recoverywrapper::Input input;
        vsdk::algorithm::recoverywrapper::Output output;
        EmplaceSensorData(input);
        controller_command_.command_type.value = controller_command_.command_type.PRETAKEOFF_CHECK_COMMAND;
        EmplaceControllerCommand(input);
        RecoveryLane_Y.RecoveryControllerLogs_mjme.recovery_state_machine_logs.recovery_state = ControlSystemFlightPhase::ReadyForInAirTakeOver;
        EXPECT_EQ(vsdk::Status::Success, recovery.run(input, output));
        
        // Verify max controller command sequence ID was set
        recovery.getState(state);
        const auto& route_tracker_state = state.route_tracker;
        EXPECT_EQ(seq_num_, route_tracker_state.max_controller_cmd_seq_id_to_accept_routes);
    }
}
```

### 3.5 Invalid Sequence Number Rejection

```cpp
TEST_F(RecoveryWrapperFixture, InvalidSequenceNumberRejected) {
    vsdk::test::TestAlgorithmPlatformAbstractionLayer algo_pal;
    vsdk::algorithm::recoverywrapper::State state;
    vsdk::algorithm::recoverywrapper::RecoveryWrapperObject recovery{param_, algo_pal};
    
    // Send route with sequence number 0
    {
        vsdk::algorithm::recoverywrapper::Input input;
        vsdk::algorithm::recoverywrapper::Output output;
        EmplaceSensorData(input);
        route_command_and_control_.route.id = 1005;
        EmplaceRouteCommandAndControl(input, 0);
        EXPECT_EQ(vsdk::Status::Success, recovery.run(input, output));
        recovery.getState(state);
    }
}
```

## 4. Test Helper Methods

### 4.1 Switchover Simulation

The `SetSwitchover` method simulates the switchover signal by writing to a temporary file:

```cpp
void RecoveryWrapperFixture::SetSwitchover(bool should_switch) {
    if (!switchover_.is_open()) {
        switchover_.open(filename_.c_str());
    }

    if (should_switch) {
        switchover_ << "RECOVERY";
    } else {
        switchover_ << "PRIMARY";
    }
}
```

### 4.2 Message Injection

Several helper methods inject messages into the recovery system:

```cpp
void RecoveryWrapperFixture::EmplaceControllerCommand(vsdk::algorithm::recoverywrapper::Input& input, int seq_num) {
    controller_command_.controller_cmd_seq_id = seq_num;
    seq_num_ = seq_num;
    vsdk::algorithm::recoverywrapper::Input::_vsdk_controller_commandMessageEnvelope route_envelope;
    route_envelope.message = controller_command_;
    input.controller_command.emplace_back(route_envelope);
}

void RecoveryWrapperFixture::EmplaceRouteCommandAndControl(vsdk::algorithm::recoverywrapper::Input& input, int seq_num) {
    route_command_and_control_.controller_cmd_seq_id = seq_num;
    seq_num_ = seq_num;
    vsdk::algorithm::recoverywrapper::Input::_vsdk_route_command_and_controlMessageEnvelope route_command_and_control_envelope;
    route_command_and_control_envelope.message = route_command_and_control_;
    input.route_command_and_control.emplace_back(route_command_and_control_envelope);
}

void RecoveryWrapperFixture::EmplaceSensorData(vsdk::algorithm::recoverywrapper::Input& input) {
    meas_accel_gyro_.sequence_number++;
    int64_t time_increase_ns = static_cast<int64_t>(1.0/500.0 * 1e9);
    meas_accel_gyro_.mono_ns += time_increase_ns;
    meas_accel_gyro_.timestamp.monotonic_ns +=  time_increase_ns;
    meas_accel_gyro_.data_valid = 1;
    meas_accel_gyro_.average_accel_m_per_s2[0] = 0;

    vsdk::algorithm::recoverywrapper::Input::_vsdk_meas_accelgyroMessageEnvelope meas_accel_gyro_envelope;
    meas_accel_gyro_envelope.message = meas_accel_gyro_;
    input.meas_accelgyro.emplace_back(meas_accel_gyro_envelope);

    vsdk::algorithm::recoverywrapper::Input::_vsdk_state_estimateMessageEnvelope envelope;
    vsdk::message::adn::vehicle::navigationandsensingsystem::StateEstimate_0_1 state_estimate;
    state_estimate.latitude_rad = 0;
    input.state_estimate.emplace_back(envelope);
}
```

### 4.3 Recovery System Preparation

The `PrepareRecoveryToRun` method ensures the recovery system is ready for testing:

```cpp
void RecoveryWrapperFixture::PrepareRecoveryToRun(vsdk::algorithm::recoverywrapper::RecoveryWrapperObject& recovery_wrapper_object) {
    auto current_time_s = RecoveryLane_DW.RateTransition_Buffer.time_s;

    // Run and stop immediately after the first time change
    bool time_has_changed = false;
    for(size_t run_count = 0; run_count < 5; ++run_count){
        vsdk::algorithm::recoverywrapper::Input input;
        vsdk::algorithm::recoverywrapper::Output output;
        EmplaceSensorData(input);
        EXPECT_EQ(vsdk::Status::Success, recovery_wrapper_object.run(input, output));
        time_has_changed = (RecoveryLane_DW.RateTransition_Buffer.time_s-current_time_s) > std::numeric_limits<float>::epsilon();
        if (time_has_changed) {
            break;
        }
    }

    EXPECT_TRUE(time_has_changed);

    // Now run it 4 more times, to make sure that at the next run call the time will change again
    for(size_t count = 0; count < 4; ++count) {
        vsdk::algorithm::recoverywrapper::Input input;
        vsdk::algorithm::recoverywrapper::Output output;
        EmplaceSensorData(input);
        EXPECT_EQ(vsdk::Status::Success, recovery_wrapper_object.run(input, output));
    }
}
```

## 5. Testing Focus Areas

The recovery system tests focus on several critical aspects:

1. **Switchover Detection**: Testing the system's ability to detect and respond to switchover signals through file monitoring.

2. **Route Management**: Verifying the system can properly receive, store, and manage different types of routes (takeoff-to-delivery, delivery-to-land, takeoff-to-land, and return home).

3. **Command Sequence Validation**: Ensuring the system properly handles command sequencing and rejects invalid sequence numbers.

4. **State Transitions**: Testing the system's ability to transition between different operational states based on commands and conditions.

5. **Sensor Data Processing**: Verifying the system can process sensor inputs and generate appropriate state estimates.

## 6. Mock Objects and Simulation

The tests use several mock objects and simulation techniques:

1. **TestAlgorithmPlatformAbstractionLayer**: A mock implementation of the algorithm platform abstraction layer for testing.

2. **Simulated Sensor Data**: The tests generate simulated IMU and state estimate data to feed into the recovery system.

3. **File-Based Switchover Simulation**: The switchover mechanism is tested by writing to a temporary file that the recovery system monitors.

4. **Global State Access**: The tests directly access global state variables (like `RecoveryLane_DW` and `RecoveryLane_Y`) to verify internal state changes.

## Referenced Context Files

- `02_Recovery_System_Integration.md`: Provided context about the overall recovery system architecture, data flow, and component interactions, which helped understand the testing approach for the recovery wrapper.