# Generated from:

- sw_vbootloader_astro/code/source_astro/bootloader_2838x_astro.cmd (1282 tokens)
- sw_vbootloader_astro/code/source_astro/cmd/app_hdr_c1.cmd (90 tokens)
- sw_vbootloader_astro/code/source_astro/source/smart.hcmd (150 tokens)
- sw_vbootloader_astro_cm/code/include_astro/Bldr_defs.h (108 tokens)
- sw_vbootloader_astro_cm/code/source/2838x_flash_astro_cm_lwip.cmd (778 tokens)
- sw_vbootloader_astro_cm/code/source/cmd/app_hdr_cm.cmd (90 tokens)
- sw_vbootloader_astro_cm/code/source/smart.hcmd (128 tokens)

## With context from:

- Amazon-PrimeAir/items/ASTRO/items/sw/sw_vbootloader_astro/code/03_Bootloader_Core.md (4045 tokens)

---

# Memory Layout and Linker Configuration Analysis for Astro Platform Bootloader

## Overview of Dual-Core Memory Architecture

The Astro platform bootloader implements a dual-core architecture with a C28x CPU (CPU1) and an ARM Cortex-M (CM) core. Each core has its own dedicated memory regions, bootloader sections, and application spaces, with specific mechanisms for inter-processor communication.

## CPU1 (C28x) Memory Layout

### Memory Map Overview

The C28x processor uses a 16-bit word-addressable architecture with the following memory organization:

```
Memory Address Space:
- 0x000000 - 0x000140: Boot reserved area (BOOT_RSVD)
- 0x000140 - 0x000800: M0-M1 RAM (RAMM_DAT)
- 0x008000 - 0x00D000: Local RAM (RAML)
- 0x00D000 - 0x01D000: Shared RAM (RAMS)
  - 0x01D000 - 0x01D7C0: RAMFUNCS (reserved for functions running from RAM)
- 0x038000 - 0x038800: CM to CPU RAM (CMTOCPURAM)
- 0x039000 - 0x039800: CPU to CM RAM (CPUTOCMRAM)
- 0x080000 - 0x0C0000: Flash memory
  - 0x080000 - 0x090000: Bootloader section (BLDR_START to BLDR_START+BLDR_SZ)
  - 0x090000 - 0x0C0000: User application section
```

### Flash Memory Organization for CPU1

```
Flash memory (16-bit addressing):
- Start address: 0x080000
- Total size: 0x040000 words (0x080000 bytes)
- Bootloader section: 0x010000 words (0x020000 bytes)
- User application section: 0x030000 words (0x060000 bytes)
```

### RAM Allocation for CPU1

The C28x core has several RAM regions:
1. **RAMM_DAT**: Small RAM block (M0-M1) starting at 0x000140, size 0x0006C0
2. **RAML**: Local RAM starting at 0x008000, size 0x005000
3. **RAMS**: Shared RAM starting at 0x00D000, size 0x010000 (minus RAMFUNCS)
4. **RAMFUNCS**: Special RAM section for functions that run from RAM, located at the end of RAMS

### Inter-Processor Communication Memory

Two dedicated memory regions facilitate communication between CPU1 and CM cores:
- **CPUTOCMRAM**: 0x039000-0x039800 (2KB) - For CPU1 to CM communication
- **CMTOCPURAM**: 0x038000-0x038800 (2KB) - For CM to CPU1 communication

## CM (Cortex-M) Core Memory Layout

### Memory Map Overview

The CM core uses byte-addressable memory with the following organization:

```
Memory Address Space:
- 0x200000 - 0x280000: Flash memory
  - 0x200000 - 0x220000: Bootloader section (cm_bldr_start to cm_bldr_start+cm_bldr_size)
  - 0x220000 - 0x250000: User application section (cm_user_start to cm_user_start+cm_user_size)
- 0x1FFFC000 - 0x1FFFE000: C1RAM (8KB)
- 0x1FFFE000 - 0x20000000: C0RAM (8KB)
- 0x20000000 - 0x20000100: Boot reserved area (BOOT_RSVD)
- 0x20000100 - 0x20014000: ESRAM
- 0x20080000 - 0x20081000: CPU1 to CM message RAM (CPU1TOCMMSGRAM)
- 0x20082000 - 0x20083000: CM to CPU1 message RAM (CMTOCPU1MSGRAM)
- 0x20084000 - 0x20085000: CPU2 to CM message RAM (CPU2TOCMMSGRAM0/1)
- 0x20086000 - 0x20087000: CM to CPU2 message RAM (CMTOCPU2MSGRAM0/1)
```

### Flash Memory Organization for CM

```
Flash memory (byte addressing):
- Start address: 0x200000
- Total size: 0x080000 bytes
- Bootloader section: 0x020000 bytes
- User application section: 0x030000 bytes
```

### RAM Allocation for CM

The CM core has several RAM regions:
1. **C1RAM**: 8KB RAM at 0x1FFFC000
2. **C0RAM**: 8KB RAM at 0x1FFFE000
3. **ESRAM**: Main RAM starting at 0x20000100, size 0x013F00

### Inter-Processor Communication Memory for CM

Multiple message RAM regions for communication with CPU1 and CPU2:
- **CPU1TOCMMSGRAM**: 4KB at 0x20080000
- **CMTOCPU1MSGRAM**: 4KB at 0x20082000
- **CPU2TOCMMSGRAM0/1**: 2KB each at 0x20084000 and 0x20084800
- **CMTOCPU2MSGRAM0/1**: 2KB each at 0x20086000 and 0x20086800

## Memory Section Allocation and Usage

### CPU1 Section Allocation

The CPU1 linker command file (`bootloader_2838x_astro.cmd`) defines the following section allocations:

1. **Code Sections**:
   - `.text`: Placed in FLASH_PRG
   - `.cinit`, `.pinit`, `.switch`, `.const`, `.init_array`: All placed in FLASH_PRG

2. **Data Sections**:
   - `.stack`: Placed in RAML
   - `.sysmem`: Placed in RAML
   - `.data`: Placed in RAML
   - `.bss`: Placed in RAMS

3. **Special Sections**:
   - `.TI.ramfunc`: Functions that run from RAM, loaded from FLASH_PRG but executed from RAMFUNCS
   - `SHARED_RAM`: Special section for shared data between CPU1 and CM, placed in CPUTOCMRAM
   - `MEMMGR_INT` and `MEMMGR_EXT`: Memory manager sections placed in RAMS

4. **Reset Vector**:
   - `.reset`: Standard section containing the address of the entry point, marked as DSECT (not loaded)

### CM Section Allocation

The CM linker command file (`2838x_flash_astro_cm_lwip.cmd`) defines the following section allocations:

1. **Code Sections**:
   - `.resetisr`: Reset vector placed at APP_BEGIN
   - `.vftable`: Vector table placed in FLASH_PRG
   - `.vtable`: RAM copy of vector table placed in ESRAM
   - `.text`, `.cinit`, `.pinit`, `.switch`, `.init_array`: All placed in FLASH_PRG

2. **Data Sections**:
   - `.stack`: Placed in C0RAM
   - `.ebss`: Placed in C1RAM
   - `.data`: Placed in ESRAM
   - `.bss`: Placed in ESRAM
   - `.sysmem`: Placed in ESRAM

3. **Special Sections**:
   - `.const`: Loaded from FLASH_PRG but copied to ESRAM at runtime
   - `.TI.ramfunc`: Functions that run from RAM, loaded from FLASH_PRG but executed from ESRAM
   - `SHARED_RAM`: Special section for shared data between CM and CPU1, placed in CMTOCPU1MSGRAM
   - `MEMMGR_INT` and `MEMMGR_EXT`: Memory manager sections placed in ESRAM

## Addressing Differences Between Cores

### Word vs. Byte Addressing

A critical difference between the two cores is their addressing scheme:

1. **CPU1 (C28x)**: Uses 16-bit word addressing
   - Each address increment represents 2 bytes
   - Defined with `SIZE_FACTOR = 2` in app_hdr_c1.cmd
   - Memory sizes in linker files are specified in words

2. **CM (Cortex-M)**: Uses 8-bit byte addressing
   - Each address increment represents 1 byte
   - Defined with `SIZE_FACTOR = 1` in app_hdr_cm.cmd
   - Memory sizes in linker files are specified in bytes

This difference is handled in several ways:
- The `words16_to_bytes_c<size>::value` template is used to convert word counts to byte counts
- The `smart.hcmd` files for both cores specify the appropriate ROM width (16 for CPU1, 8 for CM)
- Memory region definitions account for the addressing differences

### Memory Constants and Conversion

The bootloader code uses constants that account for these addressing differences:

```cpp
// CPU1 (C28x) constants - in words
static const Uint32 flash_start = 0x80000UL;
static const Uint32 flash_size  = 0x40000UL;
static const Uint32 bldr_start  = flash_start;
static const Uint32 bldr_size   = 0x10000UL;
static const Uint32 user_start  = bldr_start + bldr_size;
static const Uint32 user_size   = 0x40000UL - bldr_size;

// CM constants - in bytes
static const Uint32 cm_bldr_start  = 0x200000UL;
static const Uint32 cm_bldr_size   = 0x20000UL;
static const Uint32 cm_user_start  = cm_bldr_start + cm_bldr_size;
static const Uint32 cm_user_size   = 0x30000;
```

When passing these values between cores, the code converts between addressing schemes using the `words16_to_bytes_c` template:

```cpp
{ user_start, words16_to_bytes_c<user_size>::value }  // User data block in C1 (in bytes)
```

## Binary Image Generation

### CPU1 Binary Generation

The `smart.hcmd` file for CPU1 defines how the binary image is generated:

```
APPLICATION_BINARY:
org = 0x100000,  /* In bytes */
len =  0x20000,  /* In bytes */
romwidth = 16,   /* 16-bit ROM width */
fill = 0xFFFF
```

Key points:
- The binary starts at 0x100000 (byte address equivalent to 0x80000 word address)
- Length is 0x20000 bytes (equivalent to 0x10000 words)
- ROM width is 16 bits
- Unused space is filled with 0xFFFF

### CM Binary Generation

The `smart.hcmd` file for CM defines:

```
APPLICATION_BINARY:
org = 0x200000,  /* In bytes */
len =  0x20000,  /* In bytes */
romwidth = 8,    /* 8-bit ROM width */
fill = 0xFFFFFFFF
```

Key points:
- The binary starts at 0x200000 (byte address)
- Length is 0x20000 bytes
- ROM width is 8 bits
- Unused space is filled with 0xFFFFFFFF

## Header Definitions and Boot Process

### Bootloader Headers

Both cores use header definitions to identify and validate the bootloader:

1. **CPU1 Header**: Included from `app_hdr_c1.cmd` and `bldr_hdr_ecdsa.cmd`
   - Defines bootloader start address (0x80000) and size (0x10000 words)
   - The header is checked during boot with:
   ```cpp
   if(App_blr_hdr_inst<0, bldr_size, Bsp::sapp_uapp, 0U>::instance.bld_hdr_mark != Base::App_blr_hdr::hdr_bldr_mark_v)
   {
       Bsp::warning();
   }
   ```

2. **CM Header**: Included from `app_hdr_cm.cmd` and `bldr_hdr_ecdsa.cmd`
   - Defines bootloader start address (0x200000) and size (0x20000 bytes)

### RAM Functions

Both cores use RAM functions for critical operations:

1. **CPU1 RAM Functions**:
   - Flash operations (Flash_wr_2837x.obj)
   - Cryptographic functions (sha256*.obj)
   - IPC functions for inter-processor communication
   - CRC32 calculation
   - Bootloader management functions

2. **CM RAM Functions**:
   - Flash operations (Flash_wr_2838x_cm.obj)

These functions are loaded from flash but copied to RAM for execution, providing faster performance for critical operations.

## Inter-Processor Communication

### Shared Memory Regions

The bootloader uses dedicated shared memory regions for communication between cores:

1. **CPU1 to CM**:
   - Region: CPUTOCMRAM (0x039000-0x039800)
   - Section: `SHARED_RAM` containing `CPU1_CM_shared.obj (.bss:shared_cpu1_cm*)`

2. **CM to CPU1**:
   - Region: CMTOCPU1MSGRAM (0x20082000-0x20083000)
   - Section: `SHARED_RAM` containing `CM_CPU1_shared.obj (.bss:shared_cm_cpu1*)`

### Shared Data Structure

The shared memory contains a data structure (`CPU1_CM_shared`) that includes:
- Device UID
- System address
- Ethernet MAC address
- IP address and network mask
- Communication ports
- Heartbeat LED ID

This structure is initialized by CPU1 and read by the CM core:

```cpp
CPU1_CM_shared& shared_c1 = get_c1_writer();
shared_c1.uid      = Bsp::get_uid();
shared_c1.sys_addr = shared_c1.uid.phy;
shared_c1.eth_mac  = 0xA863F2000000 | (shared_c1.uid.phy & mask24);
```

## Dual-Bootloader Architecture

The Astro platform implements a dual-bootloader architecture where both CPU1 and CM cores have their own bootloaders:

1. **CPU1 Bootloader**:
   - Located at 0x80000-0x90000 (word addressing)
   - Responsible for initializing CPU1 and booting the CM core
   - Manages the overall boot process

2. **CM Bootloader**:
   - Located at 0x200000-0x220000 (byte addressing)
   - Responsible for initializing CM peripherals
   - Handles network communication (Ethernet/LWIP)

The boot sequence is:
1. CPU1 bootloader starts execution
2. CPU1 initializes shared memory with configuration data
3. CPU1 boots the CM core with a bootloader command:
   ```cpp
   Ipc::turn_off_cm();
   CM_helpers::cm_init_start(Halsuite::get_eth_cfg());
   Ipc::set_cm_command(Bsp::bldr_force_bldr_cmd);
   CM_helpers::cm_boot();
   ```
4. CM bootloader starts execution
5. CM reads configuration from shared memory
6. Both bootloaders check for valid application images
7. If valid images exist, they are loaded and executed

## Conclusion

The Astro platform bootloader implements a sophisticated dual-core architecture with:

1. **Separate Memory Spaces**: Each core has dedicated flash and RAM regions
2. **Different Addressing Schemes**: CPU1 uses 16-bit word addressing, CM uses 8-bit byte addressing
3. **Shared Memory Communication**: Dedicated regions for inter-processor communication
4. **Dual-Bootloader Design**: Each core has its own bootloader with specific responsibilities
5. **RAM Functions**: Critical functions run from RAM for better performance
6. **Binary Image Generation**: Separate binary images for each core with appropriate addressing

This architecture enables efficient dual-core operation while maintaining clear separation between the cores, with well-defined communication channels and memory boundaries.

## Referenced Context Files

- `Amazon-PrimeAir/items/ASTRO/items/sw/sw_vbootloader_astro/code/03_Bootloader_Core.md`: Provided essential information about the bootloader architecture, boot sequence, and inter-processor communication mechanisms. This file helped clarify how the memory layout supports the dual-bootloader architecture and how the cores interact during the boot process.