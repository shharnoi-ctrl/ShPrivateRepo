# Generated from:

- items/pdi_Monitor/setup/ver_spdif_metatc.xml (58 tokens)
- items/pdi_Monitor/setup/ver_spdif_metagnss.xml (79 tokens)
- items/pdi_Monitor/setup/ver_spdif_varini.xml (91 tokens)
- items/pdi_Monitor/setup/ver_spdif_mvars.xml (270 tokens)
- items/pdi_Monitor/setup/ver_spdif_muvar.xml (1240 tokens)
- items/pdi_Monitor/setup/ver_spdif_mrvar.xml (7227 tokens)
- items/pdi_Monitor/setup/ver_spdif_mnotif.xml (58 tokens)
- items/pdi_Monitor/setup/ver_spdif_overwrit.xml (92 tokens)

## With context from:

- Amazon-PrimeAir/items/ASTRO/items/Monitor/07_System_Architecture.md (3174 tokens)

---

# PDI Monitor Variable Management System Analysis

## 1. Variable System Overview

The PDI Monitor implements a comprehensive variable management system that organizes system data into distinct categories with specific ID ranges, types, and purposes. This system serves as the backbone for monitoring, control, and configuration of the entire platform.

## 2. Variable Types and Classification

The variable management system uses multiple XML configuration files to define different types of variables, their properties, and organization. Based on the analyzed files, the system supports at least two primary variable types:

### 2.1 Unsigned Integer Variables (MUVAR)

Defined in `ver_spdif_muvar.xml`, these variables:
- Store discrete state information and enumerated values
- Use ID range starting at 1000
- Represent system states, modes, and status indicators
- Are primarily used for control flow decisions and state tracking

### 2.2 Real (Floating Point) Variables (MRVAR)

Defined in `ver_spdif_mrvar.xml`, these variables:
- Store continuous numerical values
- Use ID ranges starting at 3100 and 1100
- Represent physical measurements, timing values, and performance metrics
- May have associated units (though many have no explicit unit defined)

## 3. Variable Organization and Structure

### 3.1 ID-Based Organization

Variables are organized using a structured ID system:
- IDs in the 1000-1999 range: Control and state variables (unsigned integers)
- IDs in the 3100-3147 range: RPM and performance measurements (real values)
- IDs in the 3200-3213 range: Timing and performance metrics (real values)

### 3.2 Variable Definition Structure

Each variable definition includes:
- Unique numeric ID
- Variable type identifier
- Descriptive name (optional)
- Unit information (optional)
- Initial value (in some cases)

Example structure from `ver_spdif_mrvar.xml`:
```xml
<str-tunarray-element>
    <id>3100</id>
    <value>
        <description>
            <name>rpm0</name>
        </description>
        <unit>
            <no-exist-unit>
                <exist>0</exist>
            </no-exist-unit>
        </unit>
    </value>
</str-tunarray-element>
```

## 4. Variable Groups and Functional Categories

The variables can be grouped into several functional categories based on their IDs and descriptions:

### 4.1 Motor Control Variables (ID: 1000-1003)

These unsigned integer variables manage motor control states:
- `control motor enable intent` (ID: 1000)
- `control disabled motor` (ID: 1001)
- `control motor arm intent` (ID: 1002)
- `control motor source` (ID: 1003)

These variables likely form a cohesive subsystem for motor control decision-making.

### 4.2 Controller Mode Variables (ID: 1100-1116)

These variables track various controller modes and states:
- `controllers mode` (ID: 1100)
- `ttcg tracked phase` (ID: 1101)
- `ttcg route id` (ID: 1102)
- `ttcg route status` (ID: 1103)
- `ttcg maneuver id` (ID: 1104)
- `ttcg maneuver status` (ID: 1105)
- `ttcg transition tracking method` (ID: 1106)
- `ttcg transition speed mode` (ID: 1107)
- `tsc tracking mode` (ID: 1108)
- `sm integrators mode` (ID: 1109)
- `sm land mode` (ID: 1110)
- `sm takeoff mode` (ID: 1111)
- `sm controllers mode` (ID: 1112)
- `sm degradation level` (ID: 1113)
- `sm gain type` (ID: 1114)
- `mixer solver status` (ID: 1115)
- `recovery previous track phase` (ID: 1116)

These variables appear to manage the flight control system's operational modes and tracking states.

### 4.3 RPM Monitoring Variables (ID: 3100-3105)

These real-valued variables monitor motor RPMs:
- `rpm0` through `rpm5` (IDs: 3100-3105)

These variables likely represent the rotational speeds of multiple motors or propellers.

### 4.4 Performance Timing Variables (ID: 3200-3213)

These real-valued variables track system performance metrics:
- `switchover time` (ID: 3200)
- `ttcg tracked route time` (ID: 3201)
- Various task timing measurements (IDs: 3202-3213)

These variables monitor execution times of different system components, likely for performance analysis and debugging.

## 5. Variable Initialization

The `ver_spdif_varini.xml` file defines initial values for specific variables:

```xml
<entry-varini>
    <id>6</id>
    <filename>varini.bin</filename>
    <version>
        <major>7</major>
        <minor>1</minor>
        <revision>1</revision>
    </version>
    <data>
        <str-tunarray-element>
            <vtype>0</vtype>
            <id>3200</id>
            <val0>150.0</val0>
        </str-tunarray-element>
    </data>
</entry-varini>
```

This initializes variable ID 3200 (`switchover time`) with a value of 150.0.

## 6. Variable Type Mapping

The `ver_spdif_mvars.xml` file defines a mapping structure for variable types:

```xml
<map>
    <str-tunarray-element>
        <idType>0</idType>
        <var-name-array/>
    </str-tunarray-element>
    <str-tunarray-element>
        <idType>2</idType>
        <var-name-array/>
    </str-tunarray-element>
    <!-- Additional type mappings -->
</map>
```

This structure appears to define different variable type categories (0, 2, 3, 4, 5, 6), though the specific var-name-arrays are empty in this configuration.

## 7. Variable Usage Patterns

### 7.1 State Tracking Pattern

The unsigned integer variables (MUVAR) follow a pattern of tracking discrete system states:
- Controller modes (controllers mode, tracking modes)
- Motor states (enable intent, arm intent)
- Route and maneuver tracking (route id, maneuver id, status)

These variables likely serve as inputs to state machines that control system behavior.

### 7.2 Performance Monitoring Pattern

The real variables (MRVAR) in the 3200-3213 range follow a pattern of tracking performance metrics:
- Maximum execution times
- Average execution times
- Current execution times

For each major system component (Controllers Task, Mixer Task, Controller Object Task, Route Tracker Task).

### 7.3 Sensor Reading Pattern

The rpm0-rpm5 variables (IDs 3100-3105) follow a pattern of storing sensor readings, likely from motor RPM sensors.

## 8. Variable Relationships

Several relationships between variable groups can be identified:

### 8.1 Controller Mode Hierarchy

The controller mode variables appear to form a hierarchical relationship:
- `controllers mode` (ID: 1100) likely represents the top-level mode
- Specific submodes like `sm land mode`, `sm takeoff mode`, and `sm controllers mode` represent specialized states

### 8.2 TTCG Variable Group

The "ttcg" (possibly "trajectory tracking control guidance") variables form a related group:
- `ttcg tracked phase` (ID: 1101)
- `ttcg route id` (ID: 1102)
- `ttcg route status` (ID: 1103)
- `ttcg maneuver id` (ID: 1104)
- `ttcg maneuver status` (ID: 1105)
- `ttcg transition tracking method` (ID: 1106)
- `ttcg transition speed mode` (ID: 1107)
- `ttcg tracked route time` (ID: 3201)

These variables work together to manage trajectory tracking and route following.

### 8.3 Motor Control Group

The motor control variables form a cohesive group:
- `control motor enable intent` (ID: 1000)
- `control disabled motor` (ID: 1001)
- `control motor arm intent` (ID: 1002)
- `control motor source` (ID: 1003)
- `rpm0` through `rpm5` (IDs: 3100-3105)

The control variables determine motor states, while the RPM variables monitor the resulting performance.

## 9. GNSS Configuration

The `ver_spdif_metagnss.xml` file defines GNSS preset selections:

```xml
<data>
    <sel_preset_gnss0>0</sel_preset_gnss0>
    <sel_preset_gnss1>0</sel_preset_gnss1>
</data>
```

This suggests the system supports dual GNSS receivers with configurable presets.

## 10. Variable Access and Overwrite Configuration

The `ver_spdif_overwrit.xml` file defines a mechanism for overwriting variables:

```xml
<data>
    <enabled>0</enabled>
    <cfg/>
    <period>0.0</period>
    <arb_addr>
        <uav>4278190080</uav>
    </arb_addr>
</data>
```

This mechanism is currently disabled (`enabled>0</enabled>`), but provides a framework for external systems to modify variables at runtime.

## 11. Notification System

The `ver_spdif_mnotif.xml` file defines a notification map structure, though it appears to be empty in the current configuration:

```xml
<data>
    <map/>
</data>
```

This suggests the system supports notifications related to variable changes or threshold crossings.

## 12. Variable Management in System Architecture

The variable management system integrates with the overall PDI Monitor architecture in several ways:

### 12.1 State Management

The unsigned integer variables provide a state tracking mechanism that likely drives the system's state machines and mode transitions.

### 12.2 Performance Monitoring

The timing variables (3202-3213) provide a comprehensive performance monitoring framework for tracking execution times of critical system components.

### 12.3 Sensor Integration

The RPM variables (3100-3105) demonstrate how sensor data is integrated into the variable system for monitoring and control purposes.

### 12.4 Configuration Management

The initialization file (`ver_spdif_varini.xml`) shows how the system can be configured with specific initial values.

## 13. Variable Naming Conventions

The variable naming follows several patterns:

### 13.1 Subsystem Prefixes

Many variables use prefixes to indicate the subsystem they belong to:
- `sm_`: State Machine related variables
- `ttcg_`: Trajectory Tracking Control Guidance variables
- `tsc_`: Possibly Trajectory Speed Control variables
- `PA_`: Possibly Prime Air specific variables

### 13.2 Functional Suffixes

Variables often use suffixes to indicate their function:
- `_mode`: Mode selection variables
- `_status`: Status indicator variables
- `_id`: Identifier variables
- `_time`: Timing measurement variables

## 14. File-by-File Breakdown

### 14.1 ver_spdif_muvar.xml

This file defines unsigned integer variables used for system state tracking:
- Contains 17 defined variables with IDs from 1000-1116
- Variables primarily track controller modes, motor states, and tracking phases
- Each variable has a descriptive name but no additional metadata

### 14.2 ver_spdif_mrvar.xml

This file defines real (floating point) variables:
- Contains RPM monitoring variables (IDs 3100-3105)
- Contains many placeholder variables with empty names (IDs 3106-3147)
- Contains performance timing variables (IDs 3200-3213)
- Each variable has a name and unit information (though most have no explicit unit)

### 14.3 ver_spdif_varini.xml

This file defines initial values for specific variables:
- Currently initializes variable ID 3200 (`switchover time`) to 150.0
- Uses a type identifier (`vtype>0</vtype>`) to specify the variable type

### 14.4 ver_spdif_mvars.xml

This file defines a mapping structure for variable types:
- Contains empty mappings for variable types 0, 2, 3, 4, 5, and 6
- Likely used to organize variables into type-specific collections

### 14.5 ver_spdif_metagnss.xml

This file configures GNSS presets:
- Defines selection values for two GNSS receivers (both set to 0)

### 14.6 ver_spdif_metatc.xml

This file appears to be a metadata container for TC (possibly Telemetry and Command) configuration:
- Contains no specific configuration data in the current version

### 14.7 ver_spdif_mnotif.xml

This file defines a notification map structure:
- Currently empty, suggesting no notifications are configured

### 14.8 ver_spdif_overwrit.xml

This file configures variable overwrite capabilities:
- Currently disabled (`enabled>0</enabled>`)
- Includes an arbitrary address field for UAV communication (4278190080)

## 15. Variable Usage in System Operation

The variable system likely supports several key operational aspects:

### 15.1 Mode Management

The controller mode variables (1100-1116) enable the system to track and transition between different operational modes:
- Normal flight control
- Takeoff and landing modes
- Degraded operation modes
- Recovery modes

### 15.2 Performance Monitoring

The timing variables (3202-3213) allow the system to:
- Track execution times of critical components
- Detect performance anomalies
- Optimize resource usage

### 15.3 Motor Control

The motor control variables (1000-1003) and RPM monitoring variables (3100-3105) work together to:
- Control motor states (enabled, armed)
- Monitor motor performance
- Detect motor anomalies

### 15.4 Route Tracking

The TTCG variables track the system's progress along routes and maneuvers:
- Route and maneuver IDs identify the current path
- Status variables track execution progress
- Timing variables measure performance

## 16. Conclusion

The PDI Monitor variable management system provides a comprehensive framework for system state tracking, performance monitoring, and configuration. The system uses a structured ID-based approach to organize variables by type and function, with clear patterns for different variable categories.

The variable system integrates closely with the overall system architecture, providing the data backbone for state machines, control algorithms, and monitoring functions. The naming conventions and organization suggest a well-designed system with clear separation of concerns and functional grouping.

The variable system appears to be extensible, with many placeholder variables defined but not yet named, suggesting room for future expansion. The configuration files provide mechanisms for initialization, type mapping, and external access, creating a flexible framework for system operation and maintenance.