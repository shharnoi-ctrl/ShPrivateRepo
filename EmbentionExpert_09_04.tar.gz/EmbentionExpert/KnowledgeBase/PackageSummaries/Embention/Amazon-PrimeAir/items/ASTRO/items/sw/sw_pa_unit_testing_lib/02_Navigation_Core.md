# Generated from:

- include/Navigation/State_history_unit_test.h (313 tokens)
- include/Navigation/Moving_avg_imu_unit_test.h (205 tokens)
- include/Navigation/Detect_pseudo_jerk_unit_test.h (329 tokens)
- include/Navigation/Persistence_test.h (325 tokens)
- include/Navigation/Input_uplink_heading_test.h (260 tokens)
- include/Navigation/ImuMovingAverage_unit_test.h (411 tokens)
- include/Navigation/Quiescence_unit_test.h (178 tokens)
- include/Navigation/On_ground_unit_test.h (361 tokens)
- include/Navigation/State_estimate_status_logic_unit_test.h (337 tokens)
- include/Navigation/Lidar_update_ned2gnd_unit_test.h (186 tokens)
- include/Navigation/Quaternion_normalization_unit_test.h (283 tokens)
- include/Navigation/Update_ud_unit_test.h (407 tokens)
- include/Navigation/On_ground_g2a_unit_test.h (529 tokens)
- include/Navigation/Vms_reset_test.h (138 tokens)
- include/Navigation/Initializer_test.h (185 tokens)
- include/Navigation/Heading_unit_test.h (478 tokens)
- include/Navigation/A2g_unit_test.h (725 tokens)
- source/Navigation/Input_uplink_heading_test.cpp (2247 tokens)
- source/Navigation/ImuMovingAverage_unit_test.cpp (1724 tokens)
- source/Navigation/On_ground_g2a_unit_test.cpp (1560 tokens)
- source/Navigation/Quiescence_unit_test.cpp (1359 tokens)
- source/Navigation/Vms_reset_test.cpp (1437 tokens)
- source/Navigation/Lidar_update_ned2gnd_unit_test.cpp (1037 tokens)
- source/Navigation/Detect_pseudo_jerk_unit_test.cpp (1428 tokens)
- source/Navigation/Quaternion_normalization_unit_test.cpp (1442 tokens)
- source/Navigation/Moving_avg_imu_unit_test.cpp (2537 tokens)
- source/Navigation/A2g_unit_test.cpp (6001 tokens)
- source/Navigation/State_estimate_status_logic_unit_test.cpp (1542 tokens)
- source/Navigation/On_ground_unit_test.cpp (4096 tokens)
- source/Navigation/Initializer_test.cpp (3346 tokens)
- source/Navigation/State_history_unit_test.cpp (1927 tokens)
- source/Navigation/Heading_unit_test.cpp (4539 tokens)
- source/Navigation/Update_ud_unit_test.cpp (2413 tokens)
- source/Navigation/Persistence_test.cpp (3234 tokens)

---

# High-Fidelity Semantic Knowledge Graph: Drone Navigation System Core Components

## 1. State History Management

The `State_history` class maintains a historical record of drone states, enabling lookups of past states based on timestamps.

### Key Behaviors and Implementation Details

- **Buffer Management**: Maintains a circular buffer of state history with a fixed capacity (likely 550 entries based on tests)
- **History Lookup**: Provides timestamp-based lookup functionality to retrieve historical states
  - Returns an optional index when a matching timestamp is found
  - Returns empty optional when timestamp is not in history
- **Reset Capability**: Can clear/reset the history buffer while maintaining structure
- **Time-Based Access**: Supports querying states within specific time ranges
- **Overflow Handling**: When buffer is full, oldest entries are overwritten

### Test Cases Reveal Implementation Details

- **Partial History**: Lookups work when buffer is partially filled (test00_history_lookup_partial)
- **Empty History**: Lookups return empty when buffer is empty (test01_history_lookup_empty)
- **Full History**: Lookups work when buffer is exactly full (test02_history_lookup_full)
- **Overflow Behavior**: When buffer overflows, oldest entries are no longer accessible (test03_history_lookup_overfull_remains, test04_history_lookup_overfull_gone)
- **Future Timestamps**: Lookups for future timestamps return empty (test05_history_lookup_future)
- **Reset Behavior**: After reset, only entries written after reset are accessible (test06_history_reset550_remains, test07_history_reset550_gone, test08_history_reset1000_remains, test09_history_reset1000_gone)

## 2. IMU Data Processing and Moving Average Filtering

The system implements sophisticated IMU data processing with moving average filtering to reduce noise.

### Moving Average Implementation

- **Filter Window**: Configurable window size for moving average (default: 5 samples)
- **Separate Filtering**: Independent filtering for accelerometer and gyroscope data
- **Step Response**: Tests verify correct step response behavior with expected ramp-up
- **Normalization**: Quaternion normalization ensures numerical stability

### IMU Data Flow

1. Raw IMU data is received with accelerometer (`f`) and gyroscope (`w`) measurements
2. Moving average filter is applied based on configuration parameters
3. Filtered data is stored in the state as `f_ekf_ned2ekf_m_per_s2` and `w_ekf_ned2ekf_rad_per_s`
4. State estimate is updated with filtered values as `f_vf_ned2vf_m_per_s2` and `w_vf_ned2vf_rad_per_s`

### Configuration Parameters

- `onground.accel_filtering_is_enabled`: Enables/disables accelerometer filtering
- `onground.gyro_filtering_is_enabled`: Enables/disables gyroscope filtering
- `onground.imu_filter_window_n`: Sets the window size for the moving average filter

### Test Cases Reveal Implementation Details

- **Step Response**: Tests verify correct behavior when input signals change abruptly (test00_moving_avg_step_response)
- **Quaternion Normalization**: Ensures quaternions maintain unit length despite numerical errors (test00_quaternion_nomalization_test)

## 3. Ground Detection System

The system implements a sophisticated ground detection mechanism that combines multiple signals to determine if the drone is on the ground.

### Ground-to-Air (G2A) Detection

- **RPM-Based Detection**: Monitors motor RPMs to detect takeoff
  - Requires a configurable number of motors exceeding takeoff RPM threshold
  - Implements persistence check to avoid false positives
  - Parameters: `onground.num_motors_to_takeoff`, `onground.takeoff_rpm`, `onground.persistency_timeout_s`

### Air-to-Ground (A2G) Detection

- **Multiple Detection Methods**: Combines several signals to detect landing
  - **Control Mode**: Detects when recovery controller is in LAND mode
  - **Flight Phase**: Monitors transition to VTOL phase
  - **Velocity Commands**: Detects when velocity commands are below threshold
  - **Pseudo-Jerk Detection**: Detects impact with ground through acceleration changes
  - **IMU Saturation**: Uses IMU saturation as landing indicator

- **Persistence Logic**: Implements time-based persistence checks to avoid false detections
  - Parameters: `onground.land_threshold_vel_cmd_timeout_s`, `onground.land_threshold_vel_cmd_m_per_s`, `onground.land_threshold_vel_m_per_s`

- **Latching Behavior**: Once on ground is detected, it remains latched until explicit takeoff is detected

### Pseudo-Jerk Detection

- **Jerk Calculation**: Computes rate of change of acceleration to detect ground impact
- **Filtering**: Implements fast and slow filters to detect rapid changes
- **Velocity Threshold**: Only triggers when vertical velocity is below threshold
- **Parameters**: `onground.jerk_threshold_m_per_s3`, `onground.jerk_window_s`, `onground.jerk_fast_tau_s`, `onground.jerk_slow_tau_s`, `onground.jerk_vel_down_threshold_m_per_s`

### Test Cases Reveal Implementation Details

- **G2A Detection**: Tests verify takeoff detection based on motor RPMs (test00_on_ground_no_g2a, test01_on_ground_takeoff_g2a)
- **A2G Detection**: Tests verify landing detection through various signals (Test_00_a2g_transition_in_control through Test_05_a2g_transition_pseudojerk_imusat_true)
- **Latching Behavior**: Tests verify that on_ground state remains latched after landing (test03_on_ground_latch)
- **Pseudo-Jerk Detection**: Tests verify impact detection at different velocities (test00_detect_pseudo_jerk_high_vel, test01_detect_pseudo_jerk_low_vel)

## 4. State Estimation and Sensor Fusion

The system implements a sophisticated state estimation system that fuses data from multiple sensors.

### Sensor Status Logic

- **Sensor Health Monitoring**: Tracks health status of various sensors
  - GNSS position and velocity
  - Barometric pressure
  - Lidar
  - IMU

- **Channel Validity**: Maintains validity status for horizontal and vertical channels
  - Horizontal channel depends primarily on GNSS
  - Vertical channel depends on barometric pressure and GNSS

- **Status Classification**: Classifies state estimate fields as VALID, DEGRADED, or INVALID
  - Position and velocity (horizontal and vertical)
  - Altitude above ground level (AGL)
  - Air data

### Covariance Update (UD Factorization)

- **UD Factorization**: Implements UD factorization for covariance updates in Kalman filtering
  - Maintains numerical stability
  - Efficient computation

- **Observation Model**: Supports custom observation models through the `Iekf_updater` interface
  - Computes innovation, observation matrix, and measurement noise

### Lidar Processing

- **Height Estimation**: Uses lidar measurements to update ground height estimate
  - Applies exponential filter to smooth updates
  - Parameters control filter time constant

- **Frame Transformations**: Accounts for sensor mounting positions and orientations
  - Transforms measurements between vehicle frame, lidar frame, and NED frame

### Test Cases Reveal Implementation Details

- **State Estimate Status**: Tests verify correct status logic based on sensor availability (test00_nav_status_healthy through test03_nav_status_baro_out_horiz_invalid)
- **UD Update**: Tests verify correct covariance updates using UD factorization (test00_update_ud_1pass, test01_update_ud_2pass)
- **Lidar Update**: Tests verify correct ground height updates from lidar measurements (test00_lidar_update_zng)

## 5. Initialization System

The system implements a comprehensive initialization procedure to establish the initial state estimate.

### Initialization Requirements

- **IMU Bias Estimation**: Requires periods of quiescence to estimate gyro biases
  - Monitors acceleration magnitude to ensure it's close to gravity
  - Monitors gyro readings to ensure minimal rotation
  - Parameters: `nav_params_init_bias_quiescence_threshold_gravity_deviation_percent`, `nav_params_init_bias_quiescence_threshold_gyro_rad_per_s`

- **GNSS Requirements**: Requires valid GNSS fix and time synchronization
  - Waits for fix quality of 3 (RTK fixed solution)
  - Ensures time synchronization between GNSS and system time

- **Heading Initialization**: Multiple methods for heading initialization
  - Site-specific heading from configuration
  - Uplink heading from ground control
  - Capture heading from state estimate when conditions are met

### Initialization Flags

- **Bias Initialization**: Set when gyro bias estimation is complete
- **GNSS Initialization**: Set when valid GNSS measurements are received
- **Heading Initialization**: Set when heading is initialized
- **Time Sync**: Set when time synchronization is established

### Test Cases Reveal Implementation Details

- **Nominal Initialization**: Tests verify successful initialization under nominal conditions (test00_nominal_with_bias_window)
- **Failure Cases**: Tests verify initialization fails under various error conditions:
  - Acceleration magnitude too large or small (test01_big_accel, test02_small_accel)
  - No GNSS fix (test03_no_fix)
  - No GNSS availability (test05_no_gnss)
- **Heading Initialization**: Tests verify heading initialization from various sources (test00_heading_reset through test05_site_specific_heading_test)

## 6. Time Management and Persistence Checking

The system implements sophisticated time management and persistence checking mechanisms.

### Time Cache

- **Recent Event Tracking**: Tracks when events occurred to determine recency
- **Persistence Checking**: Verifies conditions persist for specified durations
  - Requires continuous true condition for threshold duration
  - Resets on any false condition

### Persistence Logic Implementation

- **Rising Edge Delay**: Output becomes true only after input has been true for threshold duration
- **Falling Edge Immediate**: Output becomes false immediately when input becomes false
- **Threshold Configuration**: Configurable threshold duration for different checks

### Test Cases Reveal Implementation Details

- **Persistence Behavior**: Tests verify correct persistence logic under various conditions (test00_always_T through test05_t5_F_T_F)
- **Recency Checking**: Tests verify correct recency checking behavior (test06_recency_always_F through test08_recency_T_then_F)

## 7. Heading Management

The system implements sophisticated heading management with multiple sources and validity checks.

### Heading Sources

- **Site-Specific Heading**: Can use pre-configured heading for specific sites
  - Stored in site configuration
  - Validated for range (-180 to 180 degrees)

- **Uplink Heading**: Can receive heading updates from ground control
  - Only consumed when on ground and after mission readiness signal

- **Captured Heading**: Can capture heading from state estimate
  - Requires quiescent conditions (minimal acceleration and rotation)
  - Only valid when on ground

### Heading Validity

- **Validity Checks**: Maintains validity flag for heading
  - Invalidated when in air
  - Invalidated when motion exceeds thresholds

- **Mission Readiness**: Heading can be reset when mission readiness signal is received
  - Allows alignment with mission requirements

### Test Cases Reveal Implementation Details

- **Heading Reset**: Tests verify heading reset on mission readiness signal (test00_heading_reset)
- **Heading Capture**: Tests verify heading capture under various conditions (test01_capture_heading_always_valid through test04_capture_heading_in_air_MRS_false)
- **Site-Specific Heading**: Tests verify site-specific heading initialization (test05_site_specific_heading_test)

## 8. Quiescence Detection

The system implements quiescence detection to identify periods of minimal motion.

### Quiescence Criteria

- **Acceleration Magnitude**: Checks if acceleration magnitude is close to gravity
  - Parameter: `nav_params_init_bias_quiescence_threshold_gravity_deviation_percent`

- **Angular Velocity**: Checks if angular velocity is below threshold
  - Parameter: `nav_params_init_bias_quiescence_threshold_gyro_rad_per_s`

- **Linear Velocity**: Checks if linear velocity is below threshold
  - Parameter: `onground.motionless_threshold_speed_m_per_s`

### Test Cases Reveal Implementation Details

- **Quiescence Detection**: Tests verify correct detection of quiescent periods under various conditions (test00_quiescence_unit_test)

## 9. VMS Reset Handling

The system implements Vehicle Management System (VMS) reset handling to manage state resets.

### Reset Conditions

- **Mission Reset Command**: Resets can be triggered by mission reset commands
  - Checks for new command sequence ID

- **On Ground Requirement**: Resets only allowed when on ground
  - Prevents disruptive resets during flight

- **Switchover Handling**: Special handling for switchover between controllers
  - Prevents resets during switchover

### Test Cases Reveal Implementation Details

- **Base Reset**: Tests verify correct reset behavior under various conditions (test00_base_reset)

## Referenced Context Files

The following context files provided useful information for understanding the navigation system:

1. **include/Navigation/State_history_unit_test.h**: Revealed the structure and behavior of the state history system, including buffer management and lookup functionality.

2. **include/Navigation/Moving_avg_imu_unit_test.h** and **include/Navigation/ImuMovingAverage_unit_test.h**: Provided insights into the IMU data processing and moving average filtering implementation.

3. **include/Navigation/On_ground_unit_test.h** and **include/Navigation/On_ground_g2a_unit_test.h**: Revealed the ground detection system's implementation, including G2A and A2G detection mechanisms.

4. **include/Navigation/Detect_pseudo_jerk_unit_test.h**: Provided details on the pseudo-jerk detection mechanism for ground impact detection.

5. **include/Navigation/State_estimate_status_logic_unit_test.h**: Revealed the state estimation status logic implementation.

6. **include/Navigation/Update_ud_unit_test.h**: Provided insights into the covariance update mechanism using UD factorization.

7. **include/Navigation/Lidar_update_ned2gnd_unit_test.h**: Revealed the lidar processing implementation for ground height estimation.

8. **include/Navigation/Initializer_test.h**: Provided details on the initialization system requirements and procedure.

9. **include/Navigation/Persistence_test.h**: Revealed the time management and persistence checking mechanisms.

10. **include/Navigation/Heading_unit_test.h** and **include/Navigation/Input_uplink_heading_test.h**: Provided insights into the heading management system.

11. **include/Navigation/Quiescence_unit_test.h**: Revealed the quiescence detection implementation.

12. **include/Navigation/Vms_reset_test.h**: Provided details on the VMS reset handling mechanism.