# Generated from:

- PackageSummaries/Embention/Amazon-PrimeAir/items/ASTRO/items/sw/sw_Astro/items/09_System_Architecture.md (5081 tokens)
- PackageSummaries/Embention/Amazon-PrimeAir/items/ASTRO/items/sw/sw_Astro/items/08_Multi_Core_Execution.md (6182 tokens)
- PackageSummaries/Embention/Amazon-PrimeAir/items/ASTRO/items/sw/sw_Astro/items/02_Cross_Core_Communication.md (5351 tokens)
- PackageSummaries/Embention/Amazon-PrimeAir/items/ASTRO/items/sw/sw_Astro/items/02_Hardware_Abstraction_Layer.md (8636 tokens)
- PackageSummaries/Embention/Amazon-PrimeAir/items/ASTRO/items/sw/sw_Astro/items/07_Variable_Management.md (7265 tokens)
- PackageSummaries/Embention/Amazon-PrimeAir/items/ASTRO/items/sw/sw_Astro/items/01_Communication_Protocols.md (8692 tokens)
- PackageSummaries/Embention/Amazon-PrimeAir/items/ASTRO/items/sw/sw_Astro/items/01_CAN_Interface.md (6854 tokens)
- PackageSummaries/Embention/Amazon-PrimeAir/items/ASTRO/items/sw/sw_Astro/items/01_Serial_Interface.md (9613 tokens)
- PackageSummaries/Embention/Amazon-PrimeAir/items/ASTRO/items/sw/sw_Astro/items/01_Navigation_System.md (6416 tokens)
- PackageSummaries/Embention/Amazon-PrimeAir/items/ASTRO/items/sw/sw_Astro/items/04_VBlocks_Core.md (5729 tokens)
- PackageSummaries/Embention/Amazon-PrimeAir/items/ASTRO/items/sw/sw_Astro/items/03_VBlocks_Sensor_Blocks.md (9064 tokens)
- PackageSummaries/Embention/Amazon-PrimeAir/items/ASTRO/items/sw/sw_Astro/items/02_VBlocks_Navigation_Blocks.md (10779 tokens)
- PackageSummaries/Embention/Amazon-PrimeAir/items/ASTRO/items/sw/sw_Astro/items/03_VBlocks_Control_Blocks.md (9401 tokens)
- PackageSummaries/Embention/Amazon-PrimeAir/items/ASTRO/items/sw/sw_Astro/items/02_VBlocks_IO_Blocks.md (8033 tokens)
- PackageSummaries/Embention/Amazon-PrimeAir/items/ASTRO/items/sw/sw_Astro/items/03_VBlocks_Math_Blocks.md (5216 tokens)
- PackageSummaries/Embention/Amazon-PrimeAir/items/ASTRO/items/sw/sw_Astro/items/02_VBlocks_Signal_Processing.md (8426 tokens)
- PackageSummaries/Embention/Amazon-PrimeAir/items/ASTRO/items/sw/sw_Astro/items/02_VBlocks_Coordinate_Blocks.md (5188 tokens)
- PackageSummaries/Embention/Amazon-PrimeAir/items/ASTRO/items/sw/sw_Astro/items/02_VBlocks_Utility_Blocks.md (5515 tokens)
- PackageSummaries/Embention/Amazon-PrimeAir/items/ASTRO/items/sw/sw_Astro/items/02_VBlocks_Arcade_Blocks.md (7430 tokens)
- PackageSummaries/Embention/Amazon-PrimeAir/items/ASTRO/items/sw/sw_Astro/items/06_VPGNC_Core.md (7671 tokens)
- PackageSummaries/Embention/Amazon-PrimeAir/items/ASTRO/items/sw/sw_Astro/items/05_VPGNC_Navigation.md (8463 tokens)
- PackageSummaries/Embention/Amazon-PrimeAir/items/ASTRO/items/sw/sw_Astro/items/04_VPGNC_Guidance.md (12551 tokens)
- PackageSummaries/Embention/Amazon-PrimeAir/items/ASTRO/items/sw/sw_Astro/items/03_VPGNC_Environment.md (6808 tokens)
- PackageSummaries/Embention/Amazon-PrimeAir/items/ASTRO/items/sw/sw_Astro/items/03_VPGNC_Waypoints.md (13880 tokens)
- PackageSummaries/Embention/Amazon-PrimeAir/items/ASTRO/items/sw/sw_Astro/items/02_VPGNC_Events.md (9592 tokens)
- PackageSummaries/Embention/Amazon-PrimeAir/items/ASTRO/items/sw/sw_Astro/items/03_VPGNC_Patch_Management.md (6443 tokens)
- PackageSummaries/Embention/Amazon-PrimeAir/items/ASTRO/items/sw/sw_Astro/items/02_VPGNC_Flight_Modes.md (14666 tokens)
- PackageSummaries/Embention/Amazon-PrimeAir/items/ASTRO/items/sw/sw_Astro/items/02_VPGNC_Geometry.md (8039 tokens)
- PackageSummaries/Embention/Amazon-PrimeAir/items/ASTRO/items/sw/sw_Astro/items/02_VPGNC_Utilities.md (6396 tokens)
- PackageSummaries/Embention/Amazon-PrimeAir/items/ASTRO/items/sw/sw_Astro/items/01_System_Integration.md (2692 tokens)
- PackageSummaries/Embention/Amazon-PrimeAir/items/ASTRO/items/sw/sw_Astro/items/01_VBlocks_Framework.md (3960 tokens)
- PackageSummaries/Embention/Amazon-PrimeAir/items/ASTRO/items/sw/sw_Astro/items/01_VPGNC_Framework.md (2949 tokens)

---

# Embention Veronte Software System Overview

This document provides a comprehensive overview of the Embention Veronte software system, serving as the primary entry point for understanding the system architecture, components, and functionality.

## System Architecture Overview

The Veronte system is a sophisticated flight control system built on a multi-core architecture with three distinct processing cores:

1. **CPU1** - Primary control core responsible for system initialization, hardware management, and low-priority tasks
2. **CPU2** - Real-time processing core handling time-critical operations and navigation functions
3. **CM** - Communications Manager core dedicated to network communications and protocol handling

These cores operate in parallel with synchronized initialization sequences and communicate through shared memory structures.

### Core Components

The system is organized into several major components:

- **Hardware Abstraction Layer (HAL)**: Provides a unified interface to hardware peripherals
- **Cross-Core Communication**: Enables data exchange between the three processing cores
- **Variable Management System**: Manages system variables and their distribution across cores
- **Navigation System**: Processes sensor data to estimate the vehicle's state
- **VBlocks Library**: Implements control algorithms and signal processing
- **Communication Protocols**: Handles external communication through various protocols

### Boot Sequence

The system follows a carefully orchestrated boot sequence:

1. **CPU1 Initialization**:
   - Configure hardware peripherals
   - Initialize shared memory structures
   - Start CM initialization

2. **CPU1-CPU2 Synchronization**:
   - CPU1 sets load state for CPU2
   - CPU1 waits for CPU2 to reach its load configuration point
   - CPU1 processes cross-core file service while waiting for CPU2
   - CPU1 and CPU2 synchronize through multiple handshake points

3. **Boot Mode State Machine**:
   - Check PDI (Parameter Definition Interface) correctness
   - Start real-time tasks based on boot mode
   - Initialize file system resources
   - Configure communication components

## Cross-Core Communication

The system implements sophisticated cross-core communication mechanisms:

### Shared Memory Structures

- **CPU1-CM Shared Data**: Contains network configuration, MAC address, IP settings
- **CPU1-CPU2 Shared Data**: Contains cross-core variables and state information

### Communication Mechanisms

- **FIFO Ports**: Used for message passing between cores
- **Cross-Core File Service**: Allows one core to access files managed by another core
- **IPC Primitives**: Ensure proper sequencing during boot and operation
- **Cross-Core Packet Reader**: Reads packets from other cores

## Hardware Abstraction Layer

The HAL provides a consistent interface to hardware peripherals:

### Key Components

- **GPIO Interface**: Controls general-purpose input/output pins
- **Serial Communication**: Manages UART, SPI, I2C, and other serial interfaces
- **ADC Suite**: Handles analog-to-digital conversion
- **PWM Suite**: Controls pulse-width modulation outputs
- **CAN Interface**: Manages CAN bus communication

### Hardware Version Adaptation

The HAL adapts to different hardware versions:
- **v4.0**: Basic configuration
- **v4.5**: Added IMU1 CS, FTS feedback
- **v4.7**: Added SCI expander
- **v4.8**: Added CAN terminators
- **v4.10**: Changed GPIO mappings, added CAN FD

## Variable Management System

The system implements a comprehensive variable management system:

### Variable Types

- **Real Variables**: Floating-point values
- **Unsigned Variables**: Integer values
- **Boolean Variables**: True/false values
- **Feature Variables**: Complex data structures

### Cross-Core Variable Distribution

- **CPU1 Ownership**: CPU1 owns and writes to most system variables
- **CPU2 Access**: CPU2 can read variables through cross-core mechanisms
- **Variable Updates**: When CPU1 updates a variable, it sends a message to CPU2 to update its copy

## Navigation System

The navigation system processes sensor data to estimate the vehicle's state:

### Sensor Integration

- **IMU Sensors**: Process accelerometer and gyroscope data
- **GNSS Receivers**: Process position and velocity data
- **Barometric Sensors**: Process pressure data for altitude estimation
- **Magnetometers**: Process magnetic field data for heading estimation

### Extended Kalman Filter

The system implements an Extended Kalman Filter (EKF) for state estimation:
- Processes sensor measurements to estimate position, velocity, and attitude
- Handles sensor fusion and filtering
- Provides robust state estimation in the presence of noise and uncertainty

### Atmospheric Modeling

The system includes a comprehensive atmospheric modeling system:
- Based on the U.S. Standard Atmosphere 1976 (USSA76) model
- Supports calibration for local conditions
- Provides accurate density, pressure, and temperature estimates

### Geospatial Reference Systems

The system includes geospatial reference systems for terrain and geoid information:
- **Geoid Grid**: Provides geoid height data for converting between ellipsoidal and orthometric heights
- **SRTM Grid**: Provides terrain elevation data at different resolutions

## Guidance System

The guidance system computes desired velocity and position commands:

### Path Following

- **Navigation Curves**: Implements point, line, arc, and other path primitives
- **Projection Types**: Supports 2D, 3D, and 2.5D projections
- **Closest Path Finding**: Finds and navigates to the closest path segment

### Flight Modes

The system supports various flight modes for different operations:
- **Approach**: Landing approach guidance
- **Climb**: Takeoff and initial climb guidance
- **Detour**: Temporary route deviation
- **Taxi**: Ground movement guidance
- **VTOL**: Vertical takeoff and landing
- **Rendezvous**: Operations with moving targets

### Waypoint Management

- **Patchset System**: Manages navigation routes composed of connected path segments
- **Route Management**: Handles route configuration and waypoint transitions
- **Airframe Actions**: Executes actions at waypoints

## Event System

The system includes a comprehensive event detection and management system:

### Event Types

- **User Events**: Manually triggered events
- **Waypoint Events**: Triggered by waypoint achievement or selection
- **System State Events**: Triggered by phase or mode changes
- **Variable Limit Events**: Triggered by variable values
- **System Bit Events**: Triggered by system bit states
- **Polygon Events**: Triggered by position relative to polygons
- **Timer Events**: Triggered by timer expiration
- **Message Events**: Triggered by message reception

### Event Processing

- **Event Detection**: Detects events based on configured conditions
- **Event Duration**: Ensures events are only triggered after conditions persist
- **Event Priority**: Processes high-priority events more frequently
- **Contingency Response**: Triggers responses to specific conditions

## VBlocks Library

The VBlocks library implements control algorithms and signal processing:

### Block Types

- **Mathematical Blocks**: Implement mathematical operations and functions
- **Signal Processing Blocks**: Implement filtering, differentiation, and integration
- **Coordinate Transformation Blocks**: Convert between different coordinate systems
- **Utility Blocks**: Provide common functionality for system development
- **Arcade Control Blocks**: Implement arcade-style control inputs
- **Sensor Interface Blocks**: Interface with physical sensors
- **Control Blocks**: Implement control algorithms
- **I/O Blocks**: Interface with actuators and user inputs

### Block Factory System

The library uses a factory pattern to create blocks:
- Blocks are created based on their type identifiers
- Blocks are configured through the PDI system
- Blocks are connected through pins for data flow

## Communication Protocols

The system supports various communication protocols:

### UBX Protocol

- Communicates with u-blox GNSS receivers
- Processes positioning data
- Handles device configuration

### CAN Bus

- Implements a producer-consumer architecture
- Supports flexible connections between producers and consumers
- Handles priority-based message processing

### Serial Communication

- Manages UART interfaces
- Implements a producer-consumer architecture
- Supports data routing between different interfaces

### Cyphal Protocol

- Provides a standardized communication interface
- Handles message routing and processing
- Supports time synchronization

## System Architecture Diagram

```
+------------------+         +------------------+         +------------------+
|      CPU1        |<------->|      CPU2        |<------->|       CM         |
|                  |         |                  |         |                  |
| - System init    |         | - Navigation     |         | - Communication  |
| - Hardware mgmt  |         | - Control        |         | - Protocol       |
| - File system    |         | - Real-time      |         | - Network        |
+------------------+         +------------------+         +------------------+
        ^                           ^                           ^
        |                           |                           |
        v                           v                           v
+-----------------------------------------------------------------------+
|                        Hardware Abstraction Layer                      |
| - GPIO | - Serial | - ADC | - PWM | - CAN | - Sensors | - Actuators   |
+-----------------------------------------------------------------------+
        ^                           ^                           ^
        |                           |                           |
        v                           v                           v
+-----------------------------------------------------------------------+
|                         Variable Management                           |
| - Real vars | - Unsigned vars | - Boolean vars | - Feature vars       |
+-----------------------------------------------------------------------+
        ^                           ^                           ^
        |                           |                           |
        v                           v                           v
+-----------------------------------------------------------------------+
|                           VBlocks Library                             |
| - Sensor blocks | - Navigation blocks | - Control blocks | - I/O blocks|
+-----------------------------------------------------------------------+
        ^                           ^                           ^
        |                           |                           |
        v                           v                           v
+-----------------------------------------------------------------------+
|                        Guidance and Control                           |
| - Path following | - Flight modes | - Event system | - Waypoint mgmt  |
+-----------------------------------------------------------------------+
```

## Where to Find More Information

For more detailed information about specific components, refer to the following documents:

- **System Architecture**: [09_System_Architecture.md](09_System_Architecture.md)
- **Multi-Core Execution**: [08_Multi_Core_Execution.md](08_Multi_Core_Execution.md)
- **Cross-Core Communication**: [02_Cross_Core_Communication.md](02_Cross_Core_Communication.md)
- **Hardware Abstraction Layer**: [02_Hardware_Abstraction_Layer.md](02_Hardware_Abstraction_Layer.md)
- **Variable Management**: [07_Variable_Management.md](07_Variable_Management.md)
- **Communication Protocols**: [01_Communication_Protocols.md](01_Communication_Protocols.md)
- **CAN Interface**: [01_CAN_Interface.md](01_CAN_Interface.md)
- **Serial Interface**: [01_Serial_Interface.md](01_Serial_Interface.md)
- **Navigation System**: [01_Navigation_System.md](01_Navigation_System.md)
- **VPGNC Core**: [06_VPGNC_Core.md](06_VPGNC_Core.md)
- **VPGNC Navigation**: [05_VPGNC_Navigation.md](05_VPGNC_Navigation.md)
- **VPGNC Guidance**: [04_VPGNC_Guidance.md](04_VPGNC_Guidance.md)
- **VPGNC Environment**: [03_VPGNC_Environment.md](03_VPGNC_Environment.md)
- **VPGNC Events**: [02_VPGNC_Events.md](02_VPGNC_Events.md)
- **VPGNC Patch Management**: [03_VPGNC_Patch_Management.md](03_VPGNC_Patch_Management.md)
- **VPGNC Flight Modes**: [02_VPGNC_Flight_Modes.md](02_VPGNC_Flight_Modes.md)
- **VPGNC Waypoints**: [03_VPGNC_Waypoints.md](03_VPGNC_Waypoints.md)
- **VBlocks Core**: [04_VBlocks_Core.md](04_VBlocks_Core.md)
- **VBlocks Math Blocks**: [03_VBlocks_Math_Blocks.md](03_VBlocks_Math_Blocks.md)
- **VBlocks Signal Processing**: [02_VBlocks_Signal_Processing.md](02_VBlocks_Signal_Processing.md)
- **VBlocks Coordinate Blocks**: [02_VBlocks_Coordinate_Blocks.md](02_VBlocks_Coordinate_Blocks.md)
- **VBlocks Utility Blocks**: [02_VBlocks_Utility_Blocks.md](02_VBlocks_Utility_Blocks.md)
- **VBlocks Arcade Blocks**: [02_VBlocks_Arcade_Blocks.md](02_VBlocks_Arcade_Blocks.md)
- **VBlocks Sensor Blocks**: [03_VBlocks_Sensor_Blocks.md](03_VBlocks_Sensor_Blocks.md)
- **VBlocks Navigation Blocks**: [02_VBlocks_Navigation_Blocks.md](02_VBlocks_Navigation_Blocks.md)
- **VBlocks Control Blocks**: [03_VBlocks_Control_Blocks.md](03_VBlocks_Control_Blocks.md)
- **VBlocks I/O Blocks**: [02_VBlocks_IO_Blocks.md](02_VBlocks_IO_Blocks.md)
- **VPGNC Geometry**: [02_VPGNC_Geometry.md](02_VPGNC_Geometry.md)
- **VPGNC Utilities**: [02_VPGNC_Utilities.md](02_VPGNC_Utilities.md)
- **System Integration**: [01_System_Integration.md](01_System_Integration.md)
- **VBlocks Framework**: [01_VBlocks_Framework.md](01_VBlocks_Framework.md)
- **VPGNC Framework**: [01_VPGNC_Framework.md](01_VPGNC_Framework.md)

This overview provides a high-level understanding of the Embention Veronte software system. For more detailed information about specific components, refer to the referenced documents.