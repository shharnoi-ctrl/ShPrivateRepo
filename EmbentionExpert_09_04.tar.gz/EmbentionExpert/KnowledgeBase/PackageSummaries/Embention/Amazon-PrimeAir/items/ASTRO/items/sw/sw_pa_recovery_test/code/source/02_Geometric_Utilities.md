# Generated from:

- Utilities_geometric_pa_test.cpp (16225 tokens)
- Body_transformation_pa_test.cpp (4501 tokens)
- Transformation_pa_test.cpp (16071 tokens)
- utilities_linear_algebra_test.cpp (3232 tokens)
- utilities_rotation_pa_test.cpp (9225 tokens)

---

# High-Fidelity Semantic Knowledge Graph: Geometric Utilities

This document provides a comprehensive analysis of the geometric utilities in the codebase, focusing on transformations, rotations, and linear algebra operations that support coordinate transformations between different reference frames.

## 1. Geometric Utilities Overview

The codebase contains a rich set of geometric utilities that handle various aspects of 3D transformations, rotations, and coordinate frame conversions. These utilities are primarily tested in the following files:

- `Utilities_geometric_pa_test.cpp`
- `Body_transformation_pa_test.cpp`
- `Transformation_pa_test.cpp`
- `utilities_linear_algebra_test.cpp`
- `utilities_rotation_pa_test.cpp`

## 2. Circle Geometry Functions

### 2.1 Circle From Two Points and Two Tangents

The `circle_from_two_points_and_two_tangents` function calculates a circle that passes through two points with specified tangent directions at those points.

```cpp
bool Pa_geometric::circle_from_two_points_and_two_tangents(
    const Maverick::Rvector2& p1, 
    const Maverick::Rvector2& p2, 
    const Maverick::Rvector2& v1, 
    const Maverick::Rvector2& v2, 
    Maverick::Rvector2& c, 
    Real& r)
```

**Parameters:**
- `p1`, `p2`: Two points on the circle (2D vectors)
- `v1`, `v2`: Tangent directions at those points (2D vectors)
- `c`: Output parameter for the circle center
- `r`: Output parameter for the circle radius

**Behavior:**
- Returns a circle that passes through the two points with the specified tangent directions
- Handles special cases:
  - When points are equal (returns radius 0)
  - When headings are equal (returns radius 0)
  - When vectors have zero magnitude (returns false)
  - When points are zero (calculates radius as half the distance to the non-zero point)

**Edge Cases:**
- The function handles inconsistent distances between points by returning false
- For anti-parallel headings, it correctly calculates the circle

## 3. Transformation Classes

### 3.1 Gnc_transformation Class

This class represents a rigid body transformation (rotation and translation) between coordinate frames.

#### 3.1.1 Core Functionality

```cpp
class Gnc_transformation {
public:
    struct Build_params {
        static Build_params build(const Base::Rv9& rotation, const Base::Rv3& translation);
    };
    
    Gnc_transformation(const Build_params& params);
    Gnc_transformation inverse() const;
    
    // Transformation methods
    void transform_vector(const Maverick::Rvector3& v_in, Maverick::Rvector3& v_out) const;
    void transform_velocities(const Maverick::Rvector3& v_m_per_s_in, 
                             const Maverick::Rvector3& w_rad_per_s_in,
                             Maverick::Rvector3& v_m_per_s_out, 
                             Maverick::Rvector3& w_rad_per_s_out) const;
    void transform_wrench(const Maverick::Rvector3& f_N_in, 
                         const Maverick::Rvector3& m_N_m_in,
                         Maverick::Rvector3& f_N_out, 
                         Maverick::Rvector3& m_N_m_out) const;
    void transform_accelerations(const Maverick::Rvector3& a_m_per_s2_in,
                                const Maverick::Rvector3& alpha_rad_per_s2_in,
                                const Maverick::Rvector3& w_rad_per_s_in,
                                Maverick::Rvector3& a_m_per_s2_out,
                                Maverick::Rvector3& alpha_rad_per_s2_out) const;
    
    // Accessors
    const Gnc_rotation& get_rotation() const;
    const Maverick::Rvector3& get_translation() const;
};
```

#### 3.1.2 Transformation Operations

The class provides methods to transform:
- Vectors (positions)
- Velocities (linear and angular)
- Wrenches (forces and moments)
- Accelerations (linear and angular)

Each transformation properly accounts for the rotation and translation components according to rigid body dynamics principles.

### 3.2 Gnc_body_transformations Class

This class manages transformations between multiple coordinate frames in a vehicle system.

```cpp
class Gnc_body_transformations {
protected:
    Gnc_body_transformations(const Gnc_transformation::Build_params& vtol_from_bul,
                           const Gnc_transformation::Build_params& vf_from_bul,
                           const Base::Rv3& t_bul_bul2vf_m);
    
    // Frame transformations
    const Gnc_transformation vtol_from_bul_;  // VTOL frame from BUL frame
    const Gnc_transformation vf_from_bul_;    // VF frame from BUL frame
    const Gnc_transformation bul_from_vtol_;  // BUL frame from VTOL frame
    const Gnc_transformation vf_from_vtol_;   // VF frame from VTOL frame
    const Gnc_transformation bul_from_vf_;    // BUL frame from VF frame
    const Gnc_transformation vtol_from_vf_;   // VTOL frame from VF frame
    
    // Translation vector
    const Base::Rv3 t_bul_bul2vf_m_;
    
    // CG transformations
    Gnc_transformation::Build_params vtol_cg_from_vf(const Maverick::Rvector3& p_bul_bul2cg_m) const;
};
```

**Key Frames:**
- BUL: Body Up Left frame
- VTOL: Vertical Take-Off and Landing frame
- VF: Vehicle Frame
- CG: Center of Gravity frame

The class maintains transformations between all these frames and provides methods to compute transformations involving the center of gravity.

## 4. Rotation Utilities

### 4.1 Gnc_rotation Class

This class represents a 3D rotation using both quaternion and DCM (Direction Cosine Matrix) representations.

```cpp
class Gnc_rotation {
public:
    Gnc_rotation(const Base::Rv9& rotation_matrix);
    
    // Transform vectors
    void transform_vector(const Maverick::Rvector3& v_in, Maverick::Rvector3& v_out) const;
    
    // Accessors
    const Maverick::Rmatrix3& get_dcm() const;
    const Maverick::Rquat& get_quaternion() const;
};
```

### 4.2 Rotation Namespace Functions

The `Rotation` namespace provides utilities for computing rotations between vectors:

```cpp
namespace Rotation {
    bool compute_shortest_rotation_between_two_vectors(
        const Maverick::Rvector3& v_A_A, 
        const Maverick::Rvector3& v_B_A, 
        Maverick::Rquat& q_A_from_B);
}
```

This function computes the quaternion representing the shortest rotation that transforms one vector to another.

### 4.3 Quaternion Operations

The codebase includes extensive quaternion operations through the `Pa_irquat` namespace:

```cpp
namespace Pa_blocks::Pa_irquat {
    void quaternion_slerp(const Maverick::Rquat& q0, 
                         const Maverick::Rquat& q1, 
                         Real t, 
                         Maverick::Rquat& q2);
    
    void rpy2quat(Real roll, Real pitch, Real yaw, Maverick::Rquat& q);
    
    void limit_rotation_angle(const Maverick::Rquat& q_from, 
                             const Maverick::Rquat& q_to, 
                             Real max_angle_rad, 
                             Maverick::Rquat& q_limited);
}
```

These functions provide:
- Spherical linear interpolation between quaternions
- Conversion from roll-pitch-yaw angles to quaternion
- Limiting the rotation angle between two quaternions

## 5. Linear Algebra Utilities

### 5.1 Matrix Operations

The codebase includes various matrix operations:

```cpp
// Skew-symmetric matrix operations
void Maverick::Irmatrix3::skewp(const Maverick::Rvector3& v);

// Matrix decompositions
void Maverick::Tmatrix<Real>::cholesky_decomp();
void Maverick::Tmatrix<Real>::cholesky_solve(const Maverick::Tarray<Real>& v, Maverick::Tarray<Real>& x);

// Matrix solving
void Maverick::Tmatrix<Real>::upper_triangular_backsolve(const Maverick::Tarray<Real>& b, Maverick::Tarray<Real>& x);

// Matrix manipulations
void Maverick::Tmatrix<Real>::remove_row(Uint16 row);
void Maverick::Tmatrix<Real>::remove_column(Uint16 col);
void Maverick::Tmatrix<Real>::resize_mat(Uint16 rows, Uint16 cols);
```

### 5.2 Givens Rotations

The codebase implements Givens rotations for numerical stability in matrix operations:

```cpp
struct Maverick::Tmatrix<Real>::Givens_rotation {
    static Givens_rotation make_givens(Real a, Real b, Real tol);
    static Givens_rotation make_transposed(const Givens_rotation& g);
};

void Maverick::Tmatrix<Real>::apply_left_givens_rotation(const Givens_rotation& g, Uint16 i, Uint16 j);
```

Givens rotations are used for:
- QR decomposition
- Zeroing specific elements in matrices
- Maintaining numerical stability in matrix operations

## 6. Testing Methodology

The test files demonstrate a comprehensive approach to validating the geometric utilities:

### 6.1 Unit Testing

- Individual functions are tested with known inputs and expected outputs
- Edge cases are explicitly tested (zero vectors, parallel vectors, etc.)
- Numerical precision is verified using appropriate tolerances

### 6.2 Monte Carlo Testing

Several functions are tested using Monte Carlo methods:
- Random inputs are generated within specified ranges
- Thousands of test cases are run to ensure robustness
- Statistical analysis of errors is performed

### 6.3 Validation Approaches

- Analytical validation: Results are compared with known mathematical solutions
- Cross-validation: Different methods for computing the same result are compared
- Inverse validation: Operations are applied and then their inverse to verify return to original state

## 7. Numerical Considerations

The code demonstrates careful attention to numerical stability:

- Normalization of vectors before critical operations
- Handling of near-zero values with appropriate tolerances
- Use of stable algorithms like Givens rotations
- Explicit handling of degenerate cases

Key tolerance constants include:
- `k_near_eq_tol`: General equality tolerance
- `k_vector_norm_tol`: Tolerance for vector norms
- `k_near_eq_angle_tol_rad`: Tolerance for angle comparisons
- `k_near_eq_position_tol_m`: Tolerance for position comparisons
- `k_near_eq_velocity_tol_m_per_s`: Tolerance for velocity comparisons
- `k_near_eq_accel_tol_m_per_s2`: Tolerance for acceleration comparisons

## 8. Coordinate Frame Conventions

The codebase uses several coordinate frames:

- **BUL (Body Up Left)**: A body-fixed frame
- **VTOL (Vertical Take-Off and Landing)**: A frame specific to VTOL operations
- **VF (Vehicle Frame)**: Another body-fixed frame with different orientation
- **CG (Center of Gravity)**: Frames centered at the vehicle's center of gravity

Transformations between these frames are rigorously defined and tested.

## 9. Referenced Context Files

The following context files provided helpful information:

- `Vehicle_params.h`: Contains definitions of standard frame transformations and vehicle parameters
- `Comparison_constants.h`: Defines tolerance constants used in comparisons
- `Rmath.h` and `Rfun.h`: Provide mathematical functions and utilities

## 10. Quaternion Operations

The quaternion operations in the codebase include:

- Quaternion multiplication (`thisquat`)
- Quaternion normalization (`norm2alize`)
- Quaternion rectification (`rectify`) - ensures the scalar part is positive
- Conversion between quaternions and rotation matrices
- Spherical linear interpolation between quaternions (`quaternion_slerp`)
- Conversion between Euler angles and quaternions (`rpy2quat`, `ypr2quat`)
- Quaternion-based vector rotation (`b2n`, `n2b`)

These operations form the foundation for the rotation utilities in the control system.

## 11. Matrix Manipulations

The matrix classes provide comprehensive functionality:

- Basic operations: addition, subtraction, multiplication
- Specialized operations: transpose, inverse, determinant
- Decompositions: Cholesky
- Solvers: upper/lower triangular systems
- Manipulations: row/column removal, resizing
- Numerical techniques: Givens rotations

These capabilities support the geometric transformations and control algorithms in the system.

## 12. Application in Control Systems

The geometric utilities support the control system by:

1. Providing accurate transformations between different reference frames
2. Enabling proper handling of forces, moments, velocities, and accelerations in different frames
3. Supporting trajectory planning through circle geometry functions
4. Ensuring numerical stability in control computations
5. Facilitating attitude control through quaternion operations

The comprehensive testing ensures these utilities are reliable for critical control applications.