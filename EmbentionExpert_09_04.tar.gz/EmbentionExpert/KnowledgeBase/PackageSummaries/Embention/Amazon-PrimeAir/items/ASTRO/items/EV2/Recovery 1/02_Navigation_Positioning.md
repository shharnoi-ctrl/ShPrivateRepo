# Generated from:

- items/pdi_Recovery1/setup/ver_spdif_nav.xml (57 tokens)
- items/pdi_Recovery1/setup/ver_spdif_vgeoref.xml (60 tokens)
- items/pdi_Recovery1/setup/ver_spdif_mgeoref.xml (91 tokens)
- items/pdi_Recovery1/setup/ver_spdif_ubx0.xml (2696 tokens)
- items/pdi_Recovery1/setup/ver_spdif_ubx1.xml (2691 tokens)
- items/pdi_Recovery1/setup/ver_spdif_vargps.xml (300 tokens)
- items/pdi_Recovery1/setup/ver_spdif_metagnss.xml (79 tokens)
- items/pdi_Recovery1/setup/ver_spdif_grav_ext_ahrs.xml (76 tokens)
- items/pdi_Recovery1/setup/ver_spdif_att.xml (105 tokens)
- items/pdi_Recovery1/setup/ver_spdif_kf.xml (166 tokens)
- items/pdi_Recovery1/operation/ver_opdif_init_pos.xml (125 tokens)
- items/pdi_Recovery1/operation/ver_opdif_oppos.xml (142 tokens)
- items/pdi_Recovery1/setup/ver_spdif_amz_pds_offset.xml (110 tokens)

---

# PDI Recovery1 Navigation and Positioning Subsystem Analysis

## 1. Navigation System Overview

The PDI Recovery1 drone employs a sophisticated navigation and positioning subsystem that integrates multiple GNSS receivers, georeference systems, attitude estimation, and Kalman filtering components. This comprehensive analysis details how these components work together to provide reliable navigation data.

### 1.1 Core Navigation Components

The navigation system is built around version 7.3.1 of the navigation software (`nav.bin`), which integrates the following key components:

- Dual GNSS receivers (primary and secondary)
- Multi-constellation GNSS configuration
- Attitude estimation system
- Kalman filtering for sensor fusion
- Georeference systems (vertical and magnetic)
- Dead reckoning capabilities

## 2. GNSS Configuration and Capabilities

### 2.1 Multi-Constellation GNSS Setup

The PDI Recovery1 drone is configured to use multiple GNSS constellations simultaneously, providing redundancy and improved positioning accuracy. The system supports:

| Constellation | Reserved Channels | Maximum Channels | Flags      | Status    |
|--------------|------------------|-----------------|------------|-----------|
| GPS          | 8                | 16              | 17891329   | Enabled   |
| Galileo      | 10               | 18              | 18939905   | Enabled   |
| GLONASS      | 8                | 14              | 17891329   | Enabled   |
| BeiDou       | 2                | 5               | 17891329   | Enabled   |
| QZSS         | 0                | 3               | 17891329   | Enabled   |
| SBAS         | 3                | 3               | 16842753   | Enabled   |

This multi-constellation approach allows the drone to maintain positioning even when signals from certain constellations are compromised or unavailable.

### 2.2 Dual GNSS Receiver Configuration

The system employs two independent GNSS receivers (UBX0 and UBX1) with different configurations:

#### Primary GNSS (UBX0):
- Port configuration: SPI (port_id: 1) and SCI (port_id: 1)
- Measurement rate: 250ms (4Hz)
- Dynamic model: 8 (Airborne <4g)
- Minimum elevation angle: 5 degrees
- Minimum CNO (Carrier-to-Noise ratio): 6 dB-Hz
- Minimum satellites: 4
- Maximum satellites: 20
- PDOP limit: 25.00
- Position accuracy limit: 100m
- Interference mitigation: Enabled (config: 761441280, config2: 52297728)

#### Secondary GNSS (UBX1):
- Port configuration: SPI (port_id: 4) and SCI (port_id: 2)
- Measurement rate: 500ms (2Hz)
- Same dynamic model and satellite parameters as UBX0
- Interference mitigation: Disabled

This dual-receiver setup provides redundancy and allows for cross-validation of position solutions.

### 2.3 GNSS Message Configuration

The primary and secondary receivers are configured to output different message types:

#### Primary GNSS (UBX0) Messages:
- NAV-STATUS (class: 1, id: 3): Enabled on UART1
- NAV-PVT (class: 1, id: 7): Enabled on UART1
- NAV-TIMEGPS (class: 1, id: 32): Enabled on UART1 with rate 4
- RXM-SFRBX (class: 2, id: 19): Enabled on UART1

#### Secondary GNSS (UBX1) Messages:
- NAV-STATUS (class: 1, id: 3): Rate 1
- NAV-PVT (class: 1, id: 7): Rate 1
- NAV-TIMEGPS (class: 1, id: 32): Rate 8
- RXM-RAWX (class: 2, id: 21): Enabled on UART1

This configuration allows the primary receiver to focus on navigation solutions while the secondary receiver provides additional raw measurement data.

## 3. Georeference Systems

### 3.1 Vertical Georeference System

The vertical georeference system (`vgeoref.bin`) is configured with:
- Dead reckoning parameter (drn): 10.0

This parameter likely controls the maximum duration or distance for which the system will rely on dead reckoning when GNSS signals are compromised.

### 3.2 Magnetic Georeference System

The magnetic georeference system (`mgeoref.bin`) has the following configuration:
- Auto-georeference: Enabled (isAutoGeoref: 1)
- Georeference margin: 0.2 (marginGeoref: 0.2)
- Auto-magnetic field: Enabled (isAutoMagfield: 1)

These settings allow the system to automatically calibrate and adjust its georeference and magnetic field models based on sensor data.

## 4. Attitude Estimation

The attitude estimation system (`att.bin`) uses a complementary filter approach with the following parameters:

- Beta: 0.025 (proportional gain)
- Zeta: 0.003 (integral gain)
- Beta0: 10.0 (initial proportional gain)
- Zeta0: 0.0 (initial integral gain)
- Filter steps: 50
- Gyroscope feedback gain (kfg): 2.0
- Normalization filter coefficient: 0.1

These parameters control how the system fuses accelerometer and gyroscope data to estimate the drone's orientation. The relatively low beta and zeta values suggest a configuration that prioritizes stability over rapid response to changes.

## 5. Kalman Filtering for Sensor Fusion

The Kalman filter (`kf.bin`) is configured with:

- GPS validation time: 5.0 seconds (gpsok-time)
- Process noise covariance matrices:
  - Accelerometer bias (Qnfb): [0.0, 0.0, 0.0]
  - Gyroscope bias (Qnwb): [0.0, 0.0, 0.0]
  - Gyroscope drift (Qdwb): [0.0, 0.0, 0.0]
  - Accelerometer drift (Qdfb): [0.0, 0.0, 0.0]
  - Magnetic field disturbance (Qdem): 1.0

The zero values in the process noise matrices suggest that the system may be using pre-calibrated sensor models or that these parameters are set dynamically during operation.

## 6. GPS Variance Parameters

The GPS variance parameters (`vargps.bin`) define how the system weights GPS measurements:

- Horizontal position error weight (vgps_hpe): 2.0
- Vertical position error weight (vgps_vpe): 5.0
- Horizontal velocity error weight (vgps_hve): 1.0
- Vertical velocity error weight (vgps_vve): 1.0

These weights indicate that the system considers vertical position measurements to be less reliable than horizontal ones (higher weight value = lower confidence).

## 7. Position Initialization and Operation

### 7.1 Initial Position

The initial position configuration (`init_pos.bin`) is set to:
- Longitude: 0
- Latitude: 0
- Altitude: 0

This suggests that the system requires manual initialization or automatically determines its position upon startup.

### 7.2 Operational Position

Similarly, the operational position (`oppos.bin`) is set to default values:
- Longitude: 0
- Latitude: 0
- Altitude: 0

## 8. External AHRS Integration

The external AHRS (Attitude and Heading Reference System) integration (`grav_ext_ahrs.bin`) is configured with:
- Mode: 0 (disabled)

This indicates that the drone relies on its internal attitude estimation rather than an external AHRS.

## 9. Navigation Data Flow and Integration

The navigation subsystem integrates data from multiple sources in the following sequence:

1. **GNSS Signal Reception**: Both GNSS receivers collect signals from multiple constellations.
2. **Position and Velocity Determination**: The receivers calculate position and velocity solutions.
3. **Attitude Estimation**: The attitude estimation system fuses accelerometer and gyroscope data.
4. **Kalman Filtering**: The Kalman filter integrates GNSS and inertial data to produce a unified navigation solution.
5. **Georeference Application**: The georeference systems apply corrections to the navigation solution.

## 10. Dead Reckoning Capabilities

The system includes dead reckoning capabilities with a parameter of 10.0 (from `vgeoref.bin`). This allows the drone to maintain navigation when GNSS signals are temporarily unavailable by:

1. Using inertial measurements to estimate position changes
2. Applying the Kalman filter to predict position and velocity
3. Limiting the duration of dead reckoning to prevent excessive drift

## 11. Key Performance Parameters

Several parameters directly impact the navigation performance:

| Parameter | Value | Impact on Navigation |
|-----------|-------|---------------------|
| GNSS Measurement Rate (Primary) | 4Hz | Determines position update frequency |
| GNSS Measurement Rate (Secondary) | 2Hz | Provides backup position updates |
| Minimum Satellites | 4 | Minimum threshold for position solution |
| PDOP Limit | 25.00 | Maximum acceptable position dilution of precision |
| GPS Validation Time | 5.0s | Time required to validate GPS signals |
| Attitude Filter Beta | 0.025 | Controls attitude estimation responsiveness |
| Dead Reckoning Parameter | 10.0 | Maximum dead reckoning duration/distance |

## 12. System Integration and Redundancy

The navigation system employs several redundancy mechanisms:

1. **Dual GNSS Receivers**: Provides backup if one receiver fails
2. **Multi-Constellation Support**: Ensures positioning even if one constellation is unavailable
3. **Sensor Fusion**: Combines GNSS and inertial data for robust navigation
4. **Dead Reckoning**: Maintains navigation during brief GNSS outages

## 13. Persistent Data Storage

The system includes a persistent data storage mechanism (`amz_pds_offset.bin`):
- Persistent PDI enabled: 1 (enabled)
- PDI configuration valid: 0 (not valid)
- Offset: 0.0

This allows certain navigation parameters to persist across system restarts.

## 14. File-by-File Breakdown

### 14.1 Navigation Core (`nav.bin`)
- ID: 104
- Version: 7.3.1
- Purpose: Core navigation system
- Data: nav=1 (enabled)

### 14.2 Vertical Georeference (`vgeoref.bin`)
- ID: 57
- Version: 7.3.1
- Purpose: Vertical reference system
- Key parameter: drn=10.0 (dead reckoning)

### 14.3 Magnetic Georeference (`mgeoref.bin`)
- ID: 135
- Version: 7.3.1
- Purpose: Magnetic reference system
- Key parameters: Auto-georeference enabled, margin=0.2

### 14.4 Primary GNSS Configuration (`ubx0.bin`)
- ID: 13
- Version: 7.3.1
- Purpose: Configure primary GNSS receiver
- Key parameters: 4Hz update rate, multi-constellation support

### 14.5 Secondary GNSS Configuration (`ubx1.bin`)
- ID: 14
- Version: 7.3.1
- Purpose: Configure secondary GNSS receiver
- Key parameters: 2Hz update rate, same constellation configuration

### 14.6 GPS Variance Parameters (`vargps.bin`)
- ID: 94
- Version: 7.3.1
- Purpose: Define GPS measurement weights
- Key parameters: Horizontal position error=2.0, Vertical position error=5.0

### 14.7 Meta GNSS Configuration (`metagnss.bin`)
- ID: 173
- Version: 7.3.1
- Purpose: Meta configuration for GNSS
- Key parameters: sel_preset_gnss0=0, sel_preset_gnss1=0

### 14.8 External AHRS Configuration (`grav_ext_ahrs.bin`)
- ID: 26
- Version: 7.3.1
- Purpose: External AHRS integration
- Key parameter: mode=0 (disabled)

### 14.9 Attitude Estimation (`att.bin`)
- ID: 45
- Version: 7.3.1
- Purpose: Attitude estimation parameters
- Key parameters: beta=0.025, zeta=0.003, filter steps=50

### 14.10 Kalman Filter (`kf.bin`)
- ID: 46
- Version: 7.3.1
- Purpose: Sensor fusion parameters
- Key parameter: gpsok-time=5.0

### 14.11 Initial Position (`init_pos.bin`)
- ID: 11
- Version: 7.3.1
- Purpose: Initial position configuration
- Key parameters: Default position (0,0,0)

### 14.12 Operational Position (`oppos.bin`)
- ID: 118
- Version: 7.3.1
- Purpose: Operational position configuration
- Key parameters: Default position (0,0,0)

### 14.13 Persistent Data Storage (`amz_pds_offset.bin`)
- ID: 489
- Version: 7.3.1
- Purpose: Persistent data storage
- Key parameters: Persistent PDI enabled, offset=0.0

## 15. Cross-Component Relationships

The navigation subsystem components interact in the following ways:

1. **GNSS Receivers → Kalman Filter**: Position and velocity data flow from both GNSS receivers to the Kalman filter
2. **Attitude Estimation → Kalman Filter**: Orientation data flows from the attitude estimation system to the Kalman filter
3. **Kalman Filter → Navigation Core**: Filtered navigation solution flows to the navigation core
4. **Georeference Systems → Navigation Core**: Georeference corrections are applied to the navigation solution
5. **Navigation Core → Flight Control**: The final navigation solution is used for flight control

## 16. Conclusion

The PDI Recovery1 drone employs a sophisticated navigation and positioning subsystem that integrates dual GNSS receivers with multi-constellation support, attitude estimation, and Kalman filtering. The system is designed for robustness through redundancy and sensor fusion, with capabilities for dead reckoning during GNSS outages. Key performance parameters are tuned for reliable navigation in aerial operations, with particular attention to attitude estimation stability and GNSS signal validation.