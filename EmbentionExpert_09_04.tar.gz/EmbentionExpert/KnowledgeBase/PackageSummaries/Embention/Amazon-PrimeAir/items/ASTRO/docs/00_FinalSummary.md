# Generated from:

- Amazon-PrimeAir/items/ASTRO/docs/03_Polarion_Workitem_Core.md (3002 tokens)
- Amazon-PrimeAir/items/ASTRO/docs/02_Polarion_Workitem_Type_Handlers.md (3128 tokens)
- Amazon-PrimeAir/items/ASTRO/docs/02_Data_Conversion_Utilities.md (3417 tokens)
- Amazon-PrimeAir/items/ASTRO/docs/02_Build_Tools.md (2166 tokens)
- Amazon-PrimeAir/items/ASTRO/docs/01_Documentation_System_Overview.md (2240 tokens)

---

# ASTRO Documentation System Knowledge Graph

## System Overview

The ASTRO Documentation System is a comprehensive toolchain designed to automatically generate structured documentation from Polarion work items. This system transforms requirements, test cases, diagrams, and other work items into LaTeX-formatted documentation, ensuring consistency and traceability across project artifacts.

## System Architecture

The architecture follows a modular design with these key components:

1. **Core Polarion Work Item Extraction System**
   - Connects to Polarion via web service API
   - Retrieves and processes work items
   - Generates LaTeX documentation for requirements and diagrams

2. **Specialized Work Item Handlers**
   - Test Case Handler (tc)
   - Traceability Document Handler (td)
   - Test Steps Handler (ts)
   - Test Results Handler (tr)

3. **Data Conversion Utilities**
   - HTML to LaTeX Converter
   - CSV to LaTeX Converter

4. **Code Visualization Tools**
   - Doxygen Call Graph Generator

## Documentation Workflow

The system follows this general workflow:

1. **Work Item Extraction**: Query Polarion for specific work items
2. **Data Processing**: Transform raw work items into structured objects
3. **Format Conversion**: Convert HTML/CSV content to LaTeX
4. **LaTeX Document Generation**: Create formatted documentation files
5. **Code Visualization**: Generate call graphs and diagrams (parallel process)

## Types of Documentation Generated

The system produces several documentation types:

- **Requirements Documentation**: PR, HLR, LLR, PDIR
- **Design Documentation**: Software Algorithms, Diagrams
- **Test Documentation**: Test Cases, Steps, Results
- **Traceability Documentation**: Requirements matrices, Test coverage
- **Code Structure Visualization**: Function call graphs, Class diagrams

## Key Integration Points

- **Polarion Web Service API**: For work item retrieval
- **LaTeX Document System**: For final documentation format
- **External Tools**: Doxygen, web browser
- **Common Libraries**: polarionWebService, workItemLib, acronyms, parseTexLib

## Detailed Component Information

For more detailed information about specific components:

- [Polarion Work Item Core](03_Polarion_Workitem_Core.md): Core system for extracting work items
- [Specialized Work Item Handlers](02_Polarion_Workitem_Type_Handlers.md): Handlers for specific work item types
- [Data Conversion Utilities](02_Data_Conversion_Utilities.md): Tools for format conversion
- [Build Tools](02_Build_Tools.md): Tools for code visualization and documentation building

## Project Structure

The system is organized into multiple project directories (ASTRO-PRQChecklists, ASTRO-VS, SDD-VS) with identical scripts, indicating:

1. Independent component operation
2. Standardized documentation processes
3. Common work item backbone (linked to VER-4014)
4. Comprehensive documentation coverage

## System Value

The documentation system provides:

1. Automation of documentation tasks
2. Consistency across documents
3. Traceability between artifacts
4. Verification support
5. Process compliance
6. Knowledge transfer

By automatically generating documentation from Polarion work items, the system ensures that documentation accurately reflects the current project state while reducing manual maintenance effort.