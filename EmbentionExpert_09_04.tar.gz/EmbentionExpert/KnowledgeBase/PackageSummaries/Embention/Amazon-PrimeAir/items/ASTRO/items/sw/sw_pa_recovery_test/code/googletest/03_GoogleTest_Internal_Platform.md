# Generated from:

- include/gtest/internal/gtest-port.h (22508 tokens)
- include/gtest/internal/gtest-port-arch.h (1076 tokens)
- include/gtest/internal/gtest-string.h (1830 tokens)
- include/gtest/internal/gtest-filepath.h (2584 tokens)

---

# Google Test Platform Abstraction Layer Analysis

This document provides a comprehensive analysis of Google Test's platform abstraction layer, focusing on how it achieves cross-platform compatibility through platform detection, feature detection, and platform-specific implementations.

## 1. Platform Detection Architecture

### 1.1 Platform Detection Macros

Google Test uses a comprehensive set of platform detection macros defined in `gtest-port-arch.h` to identify the operating system and environment. These macros follow a consistent naming pattern:

```cpp
#define GTEST_OS_WINDOWS 1
#define GTEST_OS_LINUX 1
#define GTEST_OS_MAC 1
// etc.
```

The platform detection is hierarchical and detailed:

- **Major OS families**: `GTEST_OS_WINDOWS`, `GTEST_OS_LINUX`, `GTEST_OS_MAC`
- **OS variants**: `GTEST_OS_WINDOWS_MOBILE`, `GTEST_OS_WINDOWS_PHONE`, `GTEST_OS_LINUX_ANDROID`
- **Unix-like systems**: `GTEST_OS_FREEBSD`, `GTEST_OS_SOLARIS`, `GTEST_OS_AIX`, etc.
- **Embedded platforms**: `GTEST_OS_ESP8266`, `GTEST_OS_ESP32`, `GTEST_OS_XTENSA`, etc.

The detection logic uses compiler predefined macros like `__CYGWIN__`, `__APPLE__`, `__linux__`, etc. to determine the platform.

### 1.2 Platform Detection Implementation

The platform detection is implemented through a cascade of `#ifdef` and `#elif defined()` checks in `gtest-port-arch.h`:

```cpp
#ifdef __CYGWIN__
#define GTEST_OS_CYGWIN 1
#elif defined(__MINGW__) || defined(__MINGW32__) || defined(__MINGW64__)
#define GTEST_OS_WINDOWS_MINGW 1
#define GTEST_OS_WINDOWS 1
#elif defined _WIN32
#define GTEST_OS_WINDOWS 1
// Further Windows platform detection...
#elif defined __APPLE__
#define GTEST_OS_MAC 1
// Further Apple platform detection...
// ...and so on for other platforms
#endif
```

This approach ensures that exactly one primary platform is identified, with additional sub-platform flags as needed.

## 2. Feature Detection and Configuration

### 2.1 Feature Detection Macros

Google Test uses feature detection macros to determine the availability of specific language or platform features:

```cpp
#define GTEST_HAS_EXCEPTIONS 1     // C++ exception support
#define GTEST_HAS_RTTI 1           // Runtime type information
#define GTEST_HAS_STD_WSTRING 1    // std::wstring support
#define GTEST_HAS_PTHREAD 1        // POSIX threads support
#define GTEST_HAS_STREAM_REDIRECTION 1  // Stream redirection capability
#define GTEST_HAS_DEATH_TEST 1     // Death test capability
#define GTEST_HAS_TYPED_TEST 1     // Typed test support
```

These macros are defined to either 1 or left undefined (which is treated as 0 in preprocessor conditions).

### 2.2 Feature Detection Implementation

The feature detection is sophisticated and uses multiple approaches:

1. **Compiler-specific detection**:
   ```cpp
   #if defined(_MSC_VER) && defined(_CPPUNWIND)
   #define GTEST_HAS_EXCEPTIONS 1
   #elif defined(__GNUC__) && defined(__EXCEPTIONS) && __EXCEPTIONS
   #define GTEST_HAS_EXCEPTIONS 1
   // ...other compiler-specific checks
   #endif
   ```

2. **Platform-based inference**:
   ```cpp
   #if (defined(GTEST_OS_LINUX) || defined(GTEST_OS_MAC) || /* other Unix-like OSes */)
   #define GTEST_HAS_PTHREAD 1
   #else
   #define GTEST_HAS_PTHREAD 0
   #endif
   ```

3. **Capability-based detection**:
   ```cpp
   #if defined(GTEST_OS_LINUX) && !defined(__ia64__)
   #define GTEST_HAS_CLONE 1
   #else
   #define GTEST_HAS_CLONE 0
   #endif
   ```

4. **User override support**:
   ```cpp
   #ifndef GTEST_HAS_EXCEPTIONS
   // Auto-detection logic
   #endif
   ```
   This allows users to override the auto-detection by defining these macros before including Google Test headers.

## 3. String Handling Abstraction

### 3.1 String Utility Class

The `String` class in `gtest-string.h` provides platform-independent string manipulation utilities:

```cpp
class GTEST_API_ String {
 public:
  // C string handling
  static const char* CloneCString(const char* c_str);
  static bool CStringEquals(const char* lhs, const char* rhs);
  static bool CaseInsensitiveCStringEquals(const char* lhs, const char* rhs);
  
  // Wide string handling
  static std::string ShowWideCString(const wchar_t* wide_c_str);
  static bool WideCStringEquals(const wchar_t* lhs, const wchar_t* rhs);
  static bool CaseInsensitiveWideCStringEquals(const wchar_t* lhs, const wchar_t* rhs);
  
  // String formatting
  static std::string FormatIntWidth2(int value);
  static std::string FormatHexInt(int value);
  static std::string FormatByte(unsigned char value);
  // ...other utility methods
};
```

### 3.2 Windows-Specific String Handling

For Windows Mobile, special UTF-16 conversion functions are provided:

```cpp
#ifdef GTEST_OS_WINDOWS_MOBILE
  static LPCWSTR AnsiToUtf16(const char* c_str);
  static const char* Utf16ToAnsi(LPCWSTR utf16_str);
#endif
```

These functions handle the conversion between ANSI and UTF-16 encodings required for Windows API calls.

### 3.3 Case-Insensitive String Comparison

The implementation of case-insensitive string comparison is platform-aware:

```cpp
// On Windows, uses _wcsicmp which compares according to LC_CTYPE environment variable
// On GNU platform uses wcscasecmp which compares according to LC_CTYPE category of the current locale
// On MacOS X, uses towlower, which also uses LC_CTYPE category of the current locale
static bool CaseInsensitiveWideCStringEquals(const wchar_t* lhs, const wchar_t* rhs);
```

## 4. File System Abstraction

### 4.1 FilePath Class

The `FilePath` class in `gtest-filepath.h` provides a platform-independent way to manipulate file paths:

```cpp
class GTEST_API_ FilePath {
 public:
  FilePath();
  explicit FilePath(const std::string& pathname);
  
  // Path manipulation
  FilePath RemoveTrailingPathSeparator() const;
  FilePath RemoveDirectoryName() const;
  FilePath RemoveFileName() const;
  FilePath RemoveExtension(const char* extension) const;
  
  // Path operations
  bool CreateDirectoriesRecursively() const;
  bool CreateFolder() const;
  bool FileOrDirectoryExists() const;
  bool DirectoryExists() const;
  bool IsDirectory() const;
  bool IsRootDirectory() const;
  bool IsAbsolutePath() const;
  
  // Static utilities
  static FilePath GetCurrentDir();
  static FilePath MakeFileName(const FilePath& directory, const FilePath& base_name, 
                              int number, const char* extension);
  static FilePath ConcatPaths(const FilePath& directory, const FilePath& relative_path);
  static FilePath GenerateUniqueFileName(const FilePath& directory, const FilePath& base_name,
                                        const char* extension);
  
  // ...other methods
};
```

### 4.2 Path Separator Handling

The framework handles different path separators across platforms:

```cpp
#ifdef GTEST_OS_WINDOWS
#define GTEST_PATH_SEP_ "\\"
#define GTEST_HAS_ALT_PATH_SEP_ 1  // Windows accepts "/" as an alternate separator
#else
#define GTEST_PATH_SEP_ "/"
#define GTEST_HAS_ALT_PATH_SEP_ 0
#endif
```

The `FilePath::Normalize()` method handles platform-specific path normalization:
- Replaces multiple consecutive separators with a single separator
- On Windows, replaces the alternate path separator '/' with the primary path separator '\\'

### 4.3 File System Operations

The framework provides platform-independent file system operations through the `posix` namespace:

```cpp
namespace posix {
#if GTEST_HAS_FILE_SYSTEM
#ifdef GTEST_OS_WINDOWS
  typedef struct _stat StatStruct;
  inline int FileNo(FILE* file) { return _fileno(file); }
  inline int Stat(const char* path, StatStruct* buf) { return _stat(path, buf); }
  inline int RmDir(const char* dir) { return _rmdir(dir); }
  inline bool IsDir(const StatStruct& st) { return (_S_IFDIR & st.st_mode) != 0; }
#else
  typedef struct stat StatStruct;
  inline int FileNo(FILE* file) { return fileno(file); }
  inline int Stat(const char* path, StatStruct* buf) { return stat(path, buf); }
  inline int RmDir(const char* dir) { return rmdir(dir); }
  inline bool IsDir(const StatStruct& st) { return S_ISDIR(st.st_mode); }
#endif
#endif  // GTEST_HAS_FILE_SYSTEM

  // Other platform-specific function wrappers
  inline int DoIsATTY(int fd);
  inline int StrCaseCmp(const char* s1, const char* s2);
  inline int ChDir(const char* dir);
  inline FILE* FOpen(const char* path, const char* mode);
  // ...other POSIX function wrappers
}
```

## 5. Thread and Synchronization Primitives

### 5.1 Threading Support Detection

Google Test detects threading support and enables thread-safe features accordingly:

```cpp
#ifndef GTEST_IS_THREADSAFE
#if (GTEST_HAS_MUTEX_AND_THREAD_LOCAL_ ||
     (defined(GTEST_OS_WINDOWS) && !defined(GTEST_OS_WINDOWS_PHONE) && 
      !defined(GTEST_OS_WINDOWS_RT)) ||
     GTEST_HAS_PTHREAD)
#define GTEST_IS_THREADSAFE 1
#endif
#endif  // GTEST_IS_THREADSAFE
```

### 5.2 Mutex Implementation

The framework provides platform-specific mutex implementations:

1. **Windows Implementation**:
   ```cpp
   #if defined(GTEST_OS_WINDOWS) && !defined(GTEST_OS_WINDOWS_PHONE) && !defined(GTEST_OS_WINDOWS_RT)
   class GTEST_API_ Mutex {
     // Windows-specific implementation using CRITICAL_SECTION
     unsigned int owner_thread_id_;
     MutexType type_;
     long critical_section_init_phase_;
     GTEST_CRITICAL_SECTION* critical_section_;
     // ...methods
   };
   #endif
   ```

2. **POSIX Implementation**:
   ```cpp
   #elif GTEST_HAS_PTHREAD
   class MutexBase {
     // POSIX-specific implementation using pthread_mutex_t
     pthread_mutex_t mutex_;
     bool has_owner_;
     pthread_t owner_;
     // ...methods
   };
   
   class Mutex : public MutexBase {
     // ...methods
   };
   #endif
   ```

3. **No-op Implementation** (when threading is not supported):
   ```cpp
   #else  // GTEST_IS_THREADSAFE
   class Mutex {
    public:
     Mutex() {}
     void Lock() {}
     void Unlock() {}
     void AssertHeld() const {}
   };
   #endif
   ```

### 5.3 Thread-Local Storage

The framework provides platform-specific thread-local storage implementations:

1. **Windows Implementation**:
   ```cpp
   #if defined(GTEST_OS_WINDOWS) && !defined(GTEST_OS_WINDOWS_PHONE) && !defined(GTEST_OS_WINDOWS_RT)
   template <typename T>
   class ThreadLocal {
     // Windows-specific implementation using ThreadLocalRegistry
     // ...implementation
   };
   #endif
   ```

2. **POSIX Implementation**:
   ```cpp
   #elif GTEST_HAS_PTHREAD
   template <typename T>
   class GTEST_API_ ThreadLocal {
     // POSIX-specific implementation using pthread_key_t
     pthread_key_t key_;
     std::unique_ptr<ValueHolderFactory> default_factory_;
     // ...methods
   };
   #endif
   ```

3. **No-op Implementation** (when threading is not supported):
   ```cpp
   #else  // GTEST_IS_THREADSAFE
   template <typename T>
   class GTEST_API_ ThreadLocal {
    public:
     ThreadLocal() : value_() {}
     explicit ThreadLocal(const T& value) : value_(value) {}
     T* pointer() { return &value_; }
     const T* pointer() const { return &value_; }
     const T& get() const { return value_; }
     void set(const T& value) { value_ = value; }
    private:
     T value_;
   };
   #endif
   ```

## 6. Regular Expression Support

### 6.1 Regular Expression Implementation Selection

Google Test provides three different regular expression implementations based on platform capabilities:

```cpp
#ifdef GTEST_HAS_ABSL
// When using Abseil, RE2 is required
#include "absl/strings/string_view.h"
#include "re2/re2.h"
#define GTEST_USES_RE2 1
#elif GTEST_HAS_POSIX_RE
// Use POSIX regular expressions
#include <regex.h>
#define GTEST_USES_POSIX_RE 1
#else
// Use Google Test's own simple regex implementation
#define GTEST_USES_SIMPLE_RE 1
#endif
```

### 6.2 Regular Expression Class

The `RE` class provides a unified interface regardless of the underlying implementation:

```cpp
#ifdef GTEST_USES_RE2
class GTEST_API_ RE {
  // RE2-based implementation
  RE2 regex_;
  // ...methods
};
#elif defined(GTEST_USES_POSIX_RE) || defined(GTEST_USES_SIMPLE_RE)
class GTEST_API_ RE {
  // POSIX or simple regex implementation
  std::string pattern_;
  bool is_valid_;
  
  #ifdef GTEST_USES_POSIX_RE
  regex_t full_regex_;     // For FullMatch()
  regex_t partial_regex_;  // For PartialMatch()
  #else  // GTEST_USES_SIMPLE_RE
  std::string full_pattern_;  // For FullMatch();
  #endif
  
  // ...methods
};
#endif
```

## 7. Compiler-Specific Adaptations

### 7.1 Compiler Detection

Google Test detects the compiler being used:

```cpp
#ifdef __GNUC__
// 40302 means version 4.3.2
#define GTEST_GCC_VER_ \
  (__GNUC__ * 10000 + __GNUC_MINOR__ * 100 + __GNUC_PATCHLEVEL__)
#endif  // __GNUC__
```

### 7.2 Compiler-Specific Macros

The framework provides macros to handle compiler-specific behaviors:

```cpp
// Disabling Microsoft Visual C++ warnings
#if defined(_MSC_VER)
#define GTEST_DISABLE_MSC_WARNINGS_PUSH_(warnings) \
  __pragma(warning(push)) __pragma(warning(disable : warnings))
#define GTEST_DISABLE_MSC_WARNINGS_POP_() __pragma(warning(pop))
#else
#define GTEST_DISABLE_MSC_WARNINGS_PUSH_(warnings)
#define GTEST_DISABLE_MSC_WARNINGS_POP_()
#endif

// Special handling for Clang on Windows
#ifdef __clang__
#define GTEST_DISABLE_MSC_DEPRECATED_PUSH_() \
  _Pragma("clang diagnostic push") \
  _Pragma("clang diagnostic ignored \"-Wdeprecated-declarations\"") \
  _Pragma("clang diagnostic ignored \"-Wdeprecated-implementations\"")
#define GTEST_DISABLE_MSC_DEPRECATED_POP_() _Pragma("clang diagnostic pop")
#else
#define GTEST_DISABLE_MSC_DEPRECATED_PUSH_() GTEST_DISABLE_MSC_WARNINGS_PUSH_(4996)
#define GTEST_DISABLE_MSC_DEPRECATED_POP_() GTEST_DISABLE_MSC_WARNINGS_POP_()
#endif
```

### 7.3 Attribute Handling

The framework provides macros for compiler attributes with fallbacks:

```cpp
#ifdef __has_attribute
#define GTEST_HAVE_ATTRIBUTE_(x) __has_attribute(x)
#else
#define GTEST_HAVE_ATTRIBUTE_(x) 0
#endif

#if GTEST_HAVE_ATTRIBUTE_(unused)
#define GTEST_ATTRIBUTE_UNUSED_ __attribute__((unused))
#else
#define GTEST_ATTRIBUTE_UNUSED_
#endif

#if GTEST_HAVE_ATTRIBUTE_(format) && defined(__MINGW_PRINTF_FORMAT)
#define GTEST_ATTRIBUTE_PRINTF_(string_index, first_to_check) \
  __attribute__((format(__MINGW_PRINTF_FORMAT, string_index, first_to_check)))
#elif GTEST_HAVE_ATTRIBUTE_(format)
#define GTEST_ATTRIBUTE_PRINTF_(string_index, first_to_check) \
  __attribute__((format(printf, string_index, first_to_check)))
#else
#define GTEST_ATTRIBUTE_PRINTF_(string_index, first_to_check)
#endif
```

## 8. C++ Standard Library Feature Detection

### 8.1 C++17 Feature Detection

Google Test detects and adapts to C++17 features when available:

```cpp
#ifdef GTEST_HAS_ABSL
// Use Abseil implementations
#define GTEST_INTERNAL_HAS_ANY 1
#include "absl/types/any.h"
namespace testing {
namespace internal {
using Any = ::absl::any;
}
}
#else
#ifdef __has_include
#if __has_include(<any>) && GTEST_INTERNAL_CPLUSPLUS_LANG >= 201703L
// Use std::any for C++17 and higher
#define GTEST_INTERNAL_HAS_ANY 1
#include <any>
namespace testing {
namespace internal {
using Any = ::std::any;
}
}
#endif
#endif
#endif

// Similar detection for std::optional, std::string_view, and std::variant
```

### 8.2 Standard Library Compatibility

The framework provides compatibility layers for standard library features:

```cpp
// Legacy imports for backwards compatibility
namespace testing {
using std::get;
using std::make_tuple;
using std::tuple;
using std::tuple_element;
using std::tuple_size;
}
```

## 9. Integration with External Libraries

### 9.1 Abseil Integration

Google Test can integrate with Abseil for enhanced functionality:

```cpp
#ifdef GTEST_HAS_ABSL
#include "absl/flags/declare.h"
#include "absl/flags/flag.h"
#include "absl/flags/reflection.h"

// Macros for defining flags with Abseil
#define GTEST_DEFINE_bool_(name, default_val, doc) \
  ABSL_FLAG(bool, GTEST_FLAG_NAME_(name), default_val, doc)
#define GTEST_DEFINE_int32_(name, default_val, doc) \
  ABSL_FLAG(int32_t, GTEST_FLAG_NAME_(name), default_val, doc)
#define GTEST_DEFINE_string_(name, default_val, doc) \
  ABSL_FLAG(std::string, GTEST_FLAG_NAME_(name), default_val, doc)

// Flag access with Abseil
#define GTEST_FLAG_GET(name) ::absl::GetFlag(GTEST_FLAG(name))
#define GTEST_FLAG_SET(name, value) (void)(::absl::SetFlag(&GTEST_FLAG(name), value))
#else
// Native Google Test flag implementation
// ...
#endif
```

## 10. Environment Variable Handling

The framework provides platform-independent environment variable access:

```cpp
namespace posix {
inline const char* GetEnv(const char* name) {
#if defined(GTEST_OS_WINDOWS_MOBILE) || defined(GTEST_OS_WINDOWS_PHONE) || \
    defined(GTEST_OS_ESP8266) || defined(GTEST_OS_XTENSA) || defined(GTEST_OS_QURT)
  // Embedded platforms have no environment variables
  static_cast<void>(name);
  return nullptr;
#elif defined(__BORLANDC__) || defined(__SunOS_5_8) || defined(__SunOS_5_9)
  // Handle empty environment variables as NULL
  const char* const env = getenv(name);
  return (env != nullptr && env[0] != '\0') ? env : nullptr;
#else
  return getenv(name);
#endif
}
}
```

## 11. Stream Redirection

The framework provides platform-specific stream redirection capabilities:

```cpp
#if GTEST_HAS_STREAM_REDIRECTION
// Defines the stderr capturer:
GTEST_API_ void CaptureStdout();
GTEST_API_ std::string GetCapturedStdout();
GTEST_API_ void CaptureStderr();
GTEST_API_ std::string GetCapturedStderr();
#endif  // GTEST_HAS_STREAM_REDIRECTION
```

## 12. Character and String Utilities

The framework provides platform-independent character handling utilities:

```cpp
// Utilities for char
inline bool IsAlpha(char ch) {
  return isalpha(static_cast<unsigned char>(ch)) != 0;
}
inline bool IsAlNum(char ch) {
  return isalnum(static_cast<unsigned char>(ch)) != 0;
}
// ...other character utilities

// Handle different character types
inline bool IsXDigit(char ch) {
  return isxdigit(static_cast<unsigned char>(ch)) != 0;
}
#ifdef __cpp_lib_char8_t
inline bool IsXDigit(char8_t ch) {
  return isxdigit(static_cast<unsigned char>(ch)) != 0;
}
#endif
inline bool IsXDigit(char16_t ch) {
  const unsigned char low_byte = static_cast<unsigned char>(ch);
  return ch == low_byte && isxdigit(low_byte) != 0;
}
// ...other character type utilities
```

## Conclusion

Google Test's platform abstraction layer is a sophisticated system that enables the framework to work consistently across a wide range of platforms, compilers, and environments. Key aspects of this abstraction layer include:

1. **Hierarchical platform detection** that identifies both major operating systems and specific variants
2. **Feature detection mechanisms** that adapt to available language and platform capabilities
3. **String handling utilities** that work consistently across different character encodings and platforms
4. **File system abstractions** that handle path differences and file operations
5. **Threading primitives** with implementations for Windows, POSIX, and non-threaded environments
6. **Regular expression support** with multiple backend implementations
7. **Compiler-specific adaptations** for different warning systems and language extensions
8. **C++ standard library feature detection** to leverage modern C++ features when available

This abstraction layer allows the rest of the Google Test framework to be written in a platform-agnostic manner, focusing on testing functionality rather than platform differences. It enables Google Test to maintain a consistent API and behavior across diverse environments, from embedded systems to desktop applications, and from legacy compilers to the latest C++ standards.

## Referenced Context Files

- `include/gtest/internal/gtest-port.h`: Provided the core platform abstraction layer with platform detection, feature detection, and platform-specific implementations.
- `include/gtest/internal/gtest-port-arch.h`: Contained the platform detection macros and logic.
- `include/gtest/internal/gtest-string.h`: Provided string handling utilities for cross-platform string operations.
- `include/gtest/internal/gtest-filepath.h`: Implemented file path handling for cross-platform file operations.