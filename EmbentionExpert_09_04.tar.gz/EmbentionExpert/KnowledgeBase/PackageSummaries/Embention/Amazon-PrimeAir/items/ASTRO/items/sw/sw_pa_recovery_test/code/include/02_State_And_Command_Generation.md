# Generated from:

- State_machines_pa_test.h (1893 tokens)
- Tcg_test.h (481 tokens)
- Ttcg_pa_test.h (2793 tokens)
- Tsc_pa_test.h (1352 tokens)
- Aacg_pa_test.h (515 tokens)
- Aacg_pa_test_vec.h (614 tokens)
- Asc_pa_test_vec.h (543 tokens)
- Sep_pa_test.h (695 tokens)
- Sep_validity_test.h (939 tokens)
- Recovery_controller_telemetry_msg_test.h (613 tokens)

## With context from:

- Amazon-PrimeAir/items/ASTRO/items/sw/sw_pa_recovery_test/code/include/03_Trajectory_And_Navigation.md (4707 tokens)

---

# State Machines and Command Generation Components Analysis

This document provides a comprehensive analysis of the state machines and command generation components in the drone control system, focusing on state transitions, trajectory command generation, and attitude control.

## 1. State Machines Framework

### 1.1 State Machines Core Architecture

The `State_machines` class serves as the central component for managing the drone's operational states. It handles transitions between different flight modes and coordinates the behavior of various subsystems. The class is tested through `State_machines_pa_test`, which exposes protected methods and variables for testing purposes:

```cpp
class State_machines_pa_test : public State_machines {
public:
    State_machines_pa_test();
    
    // Test methods
    bool Test_1() through Test_37();
    bool step();
    
    // Inputs
    Params state_machines_parameters;
    Vsdk_common_params vsdk_common_param;
    Pa_blocks::Processed_inputs processed_inputs;
    Pa_blocks::Command_received_types command_received_types;
    Pa_blocks::Controllers_state* controllers_state;
    Pa_blocks::Controllers_state_estimate state_estimate;
    Base::Ttime timestamp_ns;
    
    // State machine reset and initialization methods
    void ResetTakeoffStateMachine(Pa_blocks::State_machines_state::Takeoff_mode::Mode& takeoff_mode);
    void ResetLandStateMachine(Pa_blocks::State_machines_state::Land& land_state);
    void InitializeLandStateMachine(...);
    void InitializeTakeoffStateMachine(...);
    
    // State Machine condition evaluations
    bool EvalIntegratorsOnGround();
    bool EvalIntegratorsModeForceOn();
    bool EvalModePBITDonePassed();
    bool EvalModeTakeoff();
    bool EvalModeTrackSpline();
    bool EvalModeTakeoffComplete();
    bool EvalModeLand();
    bool EvalModeOnGround();
    bool EvalModeInFlightTest();
    bool EvalTakeoffOnGround();
    bool EvalTakeoffAbovePositionHoldAltitude();
    bool EvalTakeoffAboveCompleteAltitude();
    bool EvalGainTypeLandMode();
    bool EvalGainTypeTrackSplineMode();
    bool EvalGainTypeLowSpeedManeuver();
    bool EvalGainTypeLandStateSlowDownToHover();
};
```

### 1.2 State Machine Components

The state machine framework consists of several interconnected state machines:

1. **Mode State Machine**: Controls the high-level operational mode of the drone
   - Modes include: PBIT, Takeoff, Track Spline, Land, On Ground, Flight Test
   - Transitions based on commands and flight conditions

2. **Takeoff State Machine**: Manages the takeoff sequence
   - States: On Ground, Position Hold, Complete
   - Transitions based on altitude thresholds and stability conditions

3. **Land State Machine**: Manages the landing sequence
   - Initialized based on the previous controller mode
   - Tracks the phase of flight during landing

4. **Integrators State Machine**: Controls when integrators are active
   - Conditions include: on ground status and force-on mode

5. **Gain Type State Machine**: Selects appropriate controller gains
   - Conditions include: land mode, track spline mode, low-speed maneuver, slow-down to hover

### 1.3 State Machine Parameters

The state machines use various parameters to control their behavior:

```cpp
// Example parameters from the test code
state_machines_parameters.mode.land_to_track_spline_agl_threshold_m = 3.0f;
```

These parameters define thresholds for state transitions, such as the altitude at which to transition from land mode to track spline mode.

### 1.4 State Machine Testing Approach

The `State_machines_pa_test` class contains 37 test methods that verify:

1. Correct initialization of state machines
2. Proper state transitions based on conditions
3. Accurate evaluation of transition conditions
4. Appropriate reset behavior
5. Handling of edge cases and invalid inputs

The tests use a combination of:
- Direct method calls to evaluate conditions
- Step-by-step execution to verify state transitions
- Parameter manipulation to test different scenarios

## 2. Trajectory Command Generator (TCG)

### 2.1 TCG Architecture

The Trajectory Command Generator (TCG) is responsible for generating trajectory commands for the flight controller. It consists of several interconnected components:

```
Tcg (Trajectory Command Generator)
├── Ttcg (Translational Trajectory Command Generator)
├── Atcg (Attitude Trajectory Command Generator)
├── Switch_blender (For smooth transitions)
└── Waca (Wind-Aware Command Adapter)
```

The `Tcg_test` class tests the overall TCG functionality:

```cpp
class Tcg_test {
public:
    Tcg_test();
    bool step();

private:
    void fill_data();
    void update_input(Uint32 i);
    void fill_maneuver_data();
    bool check_outputs();

    Route_msg route;
    Tcg::Input in;
    Tcg::Output out;
    Tcg::Output exp_out;
    Common_controller_params common_param;
    Tcg::Parameters_ param;
    Base::Mblock<Uint16> mem_volatile;
    Tcg tcg;
    // Additional data handling members
};
```

### 2.2 Translational Trajectory Command Generator (TTCG)

The TTCG component generates translational trajectory commands (position, velocity, acceleration). The `Ttcg_pa_test` class provides extensive testing for this component:

```cpp
class Ttcg_pa_test {
public:
    // Test methods
    bool test_1() through test_39();
    bool step();
    
    // Matlab-based tests
    bool matlab_test0_VtolHoverDiagonalAscentHover_LIPSO();
    bool matlab_test1_Example1aVtolConstWinds_LIPSO();
    bool matlab_test2_Example1cWbfConstWinds_Matlab_LIPSO();
    bool matlab_test3_ExampleWbfSTurn_Matlab_LIPSO();
    
    // Route and maneuver construction methods
    void construct_vtol_straight_maneuver_msg(Uint32 id, Maneuver_msg& maneuver_msg);
    void construct_wbf_straight_maneuver_msg(Uint32 id, Maneuver_msg& maneuver_msg);
    void construct_turn_maneuver_msg(Uint32 id, Turn_direction::Direction turn_direction, Real turn_radius_m, Maneuver_msg& maneuver_msg);
    void construct_vtol_hover_maneuver_msg(Uint32 id, Maneuver_msg& maneuver_msg);
    void construct_roll_maneuver_msg(Uint32 id, Turn_direction::Direction turn_direction, Real turn_radius_m, Real target_turn_radius, Maneuver_msg& maneuver_msg);
    
    // Utility methods
    bool GetRoutePhaseOfFlightTransitionIndices(const Route_msg& route, const Phase_of_flight& phase_of_flight_from, const Phase_of_flight& phase_of_flight_to, Base::Tnarrayresz<Uint32, Ku16::u4>& transition_indices);
    void create_turning_flight_waypoint(Real internal_angle_rad, Real V_m_per_s, Maverick::Rvector3& p_ned_ned2center_m, Real turn_radius_m, Turn_direction::Direction turn_direction, Waypoint_msg& wp_msg);
    Route_msg get_route_msg(Uint32 route_id, bool& ret);
    bool verify_2d_turning_waypoint(const Maverick::Rvector3& v_m_per_s, const Maverick::Rvector3& a_m_per_s2, Real turn_radius_m, Turn_direction::Direction turn_direction);
};
```

The TTCG tests verify:

1. **Route Processing**:
   - Correct handling of different route types
   - Proper extraction of waypoints and maneuvers
   - Accurate calculation of trajectory parameters

2. **Maneuver Handling**:
   - Support for different maneuver types (VTOL straight, WBF straight, turn, hover, roll)
   - Correct calculation of maneuver parameters
   - Proper transitions between maneuvers

3. **Trajectory Generation**:
   - Accurate position, velocity, and acceleration commands
   - Proper handling of different flight phases
   - Correct behavior during transitions

4. **Special Cases**:
   - Stop-and-hover maneuvers
   - Evasive maneuvers
   - Wind-aware command adaptation

### 2.3 Attitude Trajectory Command Generator (ATCG)

The ATCG component generates attitude commands based on the translational trajectory. While there's no direct ATCG test class in the provided files, it's referenced in the TCG architecture and is likely tested through the integrated TCG tests.

### 2.4 Switch Blender

The Switch Blender component provides smooth transitions between different command sources. It's referenced in the TCG architecture and is initialized in the `State_machines_pa_test` constructor:

```cpp
Switch_blender::State_ switch_blender(Tcg::n_switch_blender, Base::Memmgr::get_instance().get_allocator(Base::Memmgr::external));
```

### 2.5 TCG Testing Methodology

The TCG testing employs several approaches:

1. **Unit Testing**:
   - Tests individual components in isolation
   - Verifies specific behaviors and edge cases
   - Ensures components meet their requirements

2. **Integration Testing**:
   - Tests interactions between components
   - Verifies end-to-end functionality
   - Ensures components work together correctly

3. **Matlab-Based Testing**:
   - Uses Matlab-generated test cases
   - Compares C++ implementation with Matlab reference
   - Verifies numerical accuracy and algorithm correctness

4. **Binary File Testing**:
   - Uses binary files for input/output comparison
   - Handles large datasets efficiently
   - Supports regression testing

## 3. Trajectory Spline Controller (TSC)

### 3.1 TSC Architecture

The Trajectory Spline Controller (TSC) is responsible for tracking spline-based trajectories. The `Tsc_pa_test` class tests this component:

```cpp
class Tsc_pa_test {
public:
    Tsc_pa_test(std::string filename0, std::string out, Base::Allocator& alloc_ext);
    void SetInputsFromJson();
    bool step();
    void parse_csv(uint64_t index);
    void write_to_csv(uint32_t index);
    void ResetInputs();
    void ResetStates();
    bool compare_states();
    bool compare_output();
    
    // State setting methods
    void SetGsscStateFromFile();
    void SetVectorSaturationStateFromJson(uint64_t i);
    void SetGsscInputFromJson(uint64_t i);
    void SetSwitchBlenderStateFromJson(uint64_t i);
    void SetGsscInterpolationPointStateFromJson(uint64_t i, Real interpolation_point);
};
```

The TSC tests verify:

1. **State Management**:
   - Correct initialization of controller states
   - Proper state transitions
   - Accurate state tracking

2. **Input Processing**:
   - Correct handling of different input types
   - Proper parameter interpretation
   - Accurate calculation of control signals

3. **Output Generation**:
   - Accurate control commands
   - Proper handling of different flight phases
   - Correct behavior during transitions

4. **CSV-Based Testing**:
   - Uses CSV files for input/output comparison
   - Supports large datasets
   - Enables detailed analysis of controller behavior

### 3.2 TSC Testing Methodology

The TSC testing uses a data-driven approach:

1. **CSV File Parsing**:
   - Reads test vectors from CSV files
   - Extracts input values and expected outputs
   - Supports large datasets

2. **State Comparison**:
   - Compares internal states with expected values
   - Verifies correct state evolution
   - Identifies state discrepancies

3. **Output Comparison**:
   - Compares generated outputs with expected values
   - Uses tolerance-based comparison for floating-point values
   - Logs discrepancies for analysis

4. **Result Logging**:
   - Writes test results to CSV files
   - Includes actual and expected values
   - Supports detailed analysis of test results

## 4. Attitude and Acceleration Command Generator (AACG)

### 4.1 AACG Architecture

The Attitude and Acceleration Command Generator (AACG) is responsible for generating attitude and acceleration commands. The `Aacg_pa_test` class tests this component:

```cpp
class Aacg_pa_test {
public:
    Aacg_pa_test();
    bool step();
    bool check_outputs(const Json::Value& json_inputs);

private:
    Input_data in;
    Expected_data out;
    Aacg uut;
};
```

The `Aacg_pa_test_vec` class provides additional testing using test vectors:

```cpp
class Aacg_pa_test_vec {
public:
    Aacg_pa_test_vec();
    bool step();
    bool check_outputs(Uint16 i);
    bool read();

private:
    Input_data in;
    Expected_data exp;
    Expected_data out;
    Aacg uut;
};
```

### 4.2 AACG Testing

The AACG tests verify:

1. **Command Generation**:
   - Correct attitude commands
   - Accurate acceleration commands
   - Proper handling of different flight phases

2. **Parameter Handling**:
   - Correct interpretation of parameters
   - Proper application of constraints
   - Accurate calculation of command values

3. **State Management**:
   - Correct initialization of controller states
   - Proper state transitions
   - Accurate state tracking

4. **Test Vector Processing**:
   - Uses large test vectors (31,118 entries)
   - Compares outputs with expected values
   - Identifies discrepancies for analysis

## 5. Attitude Stability Controller (ASC)

### 5.1 ASC Architecture

The Attitude Stability Controller (ASC) is responsible for maintaining attitude stability. The `Asc_pa_test_vec` class tests this component:

```cpp
class Asc_pa_test_vec {
public:
    Asc_pa_test_vec();
    bool step();
    bool check_outputs(Uint16 i);
    bool read();

    std::ofstream TestVectors_asc_out;
    std::ofstream TestVectors_asc_exp;

private:
    Input_data in;
    Expected_data exp;
    Expected_data out;
    Asc uut;
    void saveToCSV(std::ofstream& outputFile, Real64 data_arr[], size_t size);
};
```

### 5.2 ASC Testing

The ASC tests verify:

1. **Stability Control**:
   - Correct attitude stabilization
   - Accurate control commands
   - Proper handling of disturbances

2. **Parameter Handling**:
   - Correct interpretation of parameters
   - Proper application of constraints
   - Accurate calculation of control values

3. **Test Vector Processing**:
   - Uses large test vectors (18,872 entries)
   - Compares outputs with expected values
   - Saves results to CSV files for analysis

## 6. State Estimate Processor (SEP)

### 6.1 SEP Architecture

The State Estimate Processor (SEP) is responsible for processing and validating state estimates. The `Sep_pa_test` class tests this component:

```cpp
class Sep_pa_test {
public:
    Sep_pa_test();
    bool step();
    bool check_outputs(Uint16 step);
    bool read_inputs_outputs();
    void save_data(std::ofstream& exp_csv, std::ofstream& out_csv);

private:
    Input_data in;
    Expected_data exp;
    Expected_data out;
    Sep uut;
    bool save_test_data;
};
```

The `Sep_validity_test` class provides additional testing focused on validity checks:

```cpp
class Sep_validity_test {
public:
    enum Tests {
        test_ValidClassConstruction,
        test_InvalidClassConstruction,
        test_VtolncgFromVfTransformation
    };
    
    Sep_validity_test();
    bool step(Tests idx);
    bool check_outputs(Tests idx);
    void new_uut();
    void get_uut_state();
    void uut_calling(Tests idx);
    
    // Tests
    bool test0_ValidClassConstruction();
    bool test1_InvalidClassConstruction();
    bool test2_VtolncgFromVfTransformation();
    bool step_test();
};
```

### 6.2 SEP Testing

The SEP tests verify:

1. **State Processing**:
   - Correct processing of state estimates
   - Accurate validation of state data
   - Proper handling of invalid states

2. **Transformation Validation**:
   - Correct transformation between coordinate frames
   - Accurate calculation of transformed states
   - Proper handling of edge cases

3. **Construction Validation**:
   - Correct initialization with valid parameters
   - Proper rejection of invalid parameters
   - Accurate state initialization

4. **Test Vector Processing**:
   - Uses test vectors from CSV files
   - Compares outputs with expected values
   - Saves results for analysis

## 7. Recovery Controller Telemetry

### 7.1 Telemetry Architecture

The Recovery Controller Telemetry system is responsible for collecting and transmitting telemetry data from various components. The `Recovery_controller_telemetry_msg_test` class tests this system:

```cpp
class Recovery_controller_telemetry_msg_test {
public:
    // Tests
    static bool test0_serialization_deserialization();
    
    // Auxiliar
    static bool check_Recovery_controller_telemetry_deserialization(Recovery_controller_telemetry& obj);
    static bool check_Controllers_telemetry(Controllers_telemetry& obj);
    static bool check_Sep_telemetry(Sep::Telemetry& obj);
    static bool check_Tcg_telemetry(Tcg::Telemetry& obj);
    static bool check_Aacg_telemetry(Aacg::Telemetry& obj);
    static bool check_Asc_telemetry(Asc::Telemetry& obj);
    static bool check_Tsc_telemetry(Tsc::Telemetry& obj);
    static bool check_Forces_and_torques_request_telemetry(Forces_and_torques_request::Telemetry& obj);
    static bool check_Waca_telemetry(Waca::Telemetry& obj);
    static bool check_Ttcg_telemetry(Ttcg::Telemetry& obj);
    static bool check_Atcg_telemetry(Atcg::Telemetry& obj);
    static bool check_Aee_telemetry(Aee::Telemetry& obj);
    static bool check_Afc_telemetry(Afc::Telemetry& obj);
    static bool check_Gnc_model_set_telemetry(Gnc_model_set::Telemetry& obj, Uint16 active_id, Base::Tnarrayresz<Uint16, 6U> x);
    static bool check_Mixer_telemetry(Mixer_telemetry& obj);
    static bool check_Mixer_return_telemetry(Controllers_object::Mixer_return::Telemetry& obj);
    static bool check_RCCP_logdata(Recovery_controls_command_processor::Log_data& obj);
    static bool check_Rmpf_logdata(Recovery_mission_phase_of_flight::Log_data& obj);
    static bool check_Rmdp_logdata(Recovery_mission_data_processor::Log_data& obj);
    static bool check_Rrc_logdata(Recovery_route_constructor::Log_data& obj);
    static bool check_Tp_logdata(Tp_log_data& obj);
    static bool check_Recovery_state_machine_logs(Recovery_lane_step1::Recovery_state_machine::Logs& obj);
    static bool check_State_machines_telemetry(State_machines::Telemetry& obj);
};
```

### 7.2 Telemetry Testing

The telemetry tests verify:

1. **Serialization/Deserialization**:
   - Correct serialization of telemetry data
   - Accurate deserialization of serialized data
   - Proper handling of different data types

2. **Component Telemetry**:
   - Correct telemetry data from each component
   - Accurate representation of component states
   - Proper formatting of telemetry data

3. **Log Data**:
   - Correct log data from various components
   - Accurate representation of system events
   - Proper formatting of log entries

## 8. State Transitions and Command Flow

### 8.1 State Transition Flow

The state transition flow follows these general patterns:

1. **Startup Sequence**:
   - System initializes in PBIT (Power-On Built-In Test) mode
   - Upon successful PBIT, transitions to On Ground mode
   - Awaits takeoff command

2. **Takeoff Sequence**:
   - Receives takeoff command
   - Transitions to Takeoff mode
   - Progresses through takeoff states (On Ground → Position Hold → Complete)
   - Upon reaching Complete state, transitions to Track Spline mode

3. **Normal Flight**:
   - Operates in Track Spline mode
   - Follows route and maneuver commands
   - Adjusts controller gains based on flight phase and conditions

4. **Landing Sequence**:
   - Receives land command
   - Transitions to Land mode
   - Initializes land state machine based on previous controller mode
   - Upon landing, transitions to On Ground mode

### 8.2 Command Generation Flow

The command generation flow follows these steps:

1. **Route and Maneuver Processing**:
   - Route commands are received and processed
   - Maneuvers are extracted from the route
   - Current maneuver is selected based on position and time

2. **Trajectory Command Generation**:
   - TTCG generates translational trajectory commands
   - Commands include position, velocity, and acceleration
   - Commands are adapted for wind conditions

3. **Attitude Command Generation**:
   - ATCG generates attitude commands based on translational trajectory
   - Commands include roll, pitch, and yaw
   - Commands are adjusted based on flight phase

4. **Stability Control**:
   - ASC provides stability control
   - Ensures attitude commands are followed
   - Compensates for disturbances

5. **Force and Torque Generation**:
   - Commands are converted to forces and torques
   - Mixer allocates forces and torques to actuators
   - Actuator commands are generated

### 8.3 State Estimate Processing

The state estimate processing flow follows these steps:

1. **Sensor Data Collection**:
   - Sensor data is collected from various sources
   - Data includes accelerometers, gyroscopes, pressure sensors, etc.

2. **State Estimation**:
   - Sensor data is processed to estimate vehicle state
   - State includes position, velocity, attitude, etc.

3. **State Validation**:
   - SEP validates the estimated state
   - Checks for consistency and plausibility
   - Handles invalid or missing data

4. **State Distribution**:
   - Validated state is distributed to other components
   - Components use the state for control and decision-making

## 9. Key Relationships Between Components

### 9.1 State Machines and Command Generation

The state machines determine the operational mode of the drone, which affects how commands are generated:

- In Takeoff mode, commands focus on vertical ascent and position holding
- In Track Spline mode, commands follow the planned route and maneuvers
- In Land mode, commands focus on controlled descent and touchdown

### 9.2 Trajectory and Attitude Command Generation

The trajectory commands (position, velocity, acceleration) drive the attitude commands:

- Position and velocity errors determine desired acceleration
- Desired acceleration determines required attitude
- Attitude commands are generated to achieve the desired acceleration

### 9.3 Command Generation and State Estimation

The command generation relies on accurate state estimation:

- Position and velocity estimates are used to track the trajectory
- Attitude estimates are used for attitude control
- State validity affects the confidence in generated commands

### 9.4 Telemetry and System Monitoring

The telemetry system collects data from all components:

- State machine status and transitions
- Command generation outputs
- State estimation results
- Control system performance

This data is used for system monitoring, debugging, and performance analysis.

## 10. Testing Methodology

The testing methodology employs several approaches:

### 10.1 Unit Testing

- Tests individual components in isolation
- Verifies specific behaviors and edge cases
- Ensures components meet their requirements

### 10.2 Integration Testing

- Tests interactions between components
- Verifies end-to-end functionality
- Ensures components work together correctly

### 10.3 Data-Driven Testing

- Uses test vectors from CSV files or binary files
- Compares outputs with expected values
- Supports large datasets and detailed analysis

### 10.4 Matlab-Based Testing

- Uses Matlab-generated test cases
- Compares C++ implementation with Matlab reference
- Verifies numerical accuracy and algorithm correctness

### 10.5 Telemetry Testing

- Verifies correct serialization and deserialization
- Ensures accurate representation of system state
- Validates proper formatting of telemetry data

## 11. Conclusion

The state machines and command generation components form a comprehensive system for controlling the drone's behavior. The state machines manage the operational modes and transitions, while the command generation components produce the trajectory and attitude commands needed for flight control.

The testing framework verifies that each component functions correctly in isolation and that the integrated system produces the expected behavior. The combination of unit tests, integration tests, and data-driven validation ensures the system's reliability and accuracy.

The system's ability to handle different flight phases and maneuver types provides the flexibility needed for complex missions, while the state machine architecture ensures proper sequencing of operations and smooth transitions between modes.

## Referenced Context Files

The analysis incorporates information from the following context files:
- **03_Trajectory_And_Navigation.md**: Provides information about the trajectory planning components that feed into the command generation system.