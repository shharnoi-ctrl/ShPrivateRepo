# Generated from:

- Amazon-PrimeAir/items/ASTRO/items/sw/sw_pa_recovery_test/code/source/03_Controller_Objects.md (6657 tokens)
- Amazon-PrimeAir/items/ASTRO/items/sw/sw_pa_recovery_test/code/source/03_Mixer_System.md (4014 tokens)
- Amazon-PrimeAir/items/ASTRO/items/sw/sw_pa_recovery_test/code/source/03_State_Estimation.md (2992 tokens)

---

# Flight Control System: Comprehensive Analysis

## 1. System Architecture Overview

The flight control system is a sophisticated multi-component architecture responsible for maintaining stable flight across various operating conditions. It consists of three primary subsystems:

1. **Controller Objects** - Responsible for high-level control logic, mode management, and trajectory generation
2. **Mixer System** - Allocates control forces and moments to individual actuators
3. **State Estimation** - Processes sensor data to determine vehicle position, velocity, attitude, and rates

These components form a closed-loop system where state estimates inform controller decisions, controllers generate force/moment commands, and the mixer allocates these commands to actuators.

## 2. State Estimation Components

### 2.1 State Estimator Processor (SEP)

The SEP is the foundation of the flight control system, providing critical state information by:

- Processing raw sensor data from IMUs, GPS, and air data sensors
- Performing coordinate transformations between multiple reference frames:
  - NED (North-East-Down)
  - VF (Vehicle Frame)
  - VTOL (Vertical Take-Off and Landing frame)
  - BUL (Body frame)
  - NCG (Nominal Center of Gravity frame)
  - TRIM0NCG (Trim reference frame at nominal CG)
- Filtering acceleration, velocity, and angular rate data to reduce noise
- Computing air data parameters including dynamic pressure, density, and airspeed

The SEP outputs a comprehensive state estimate including:

```
- a_filt_vtolncg_m_per_s2: Filtered acceleration in VTOL NCG frame
- q_est_vtolncg_from_ned: Quaternion from NED to VTOL NCG
- q_est_trim0ncg_from_ned: Quaternion from NED to TRIM0 NCG
- w_filt_trim0ncg_ned2trim0ncg_rad_per_s: Filtered angular rate
- v_est_ned_ned2ncg_m_per_s: Velocity estimate in NED frame
- density_sched_kg_per_m3: Scheduled air density
- dynamic_pressure_sched_Pa: Scheduled dynamic pressure
- lla_est_ncg: Latitude, longitude, altitude estimate
- tas_est_m_per_s: True airspeed estimate
- eas_est_m_per_s: Equivalent airspeed estimate
```

The SEP implements validation mechanisms including status flags for position/velocity quality and rotor health monitoring to account for potential failures.

### 2.2 Attitude Stability Controller (ASC)

The ASC uses state estimates from the SEP to stabilize vehicle attitude by:

- Computing attitude error between commanded and estimated orientation
- Generating angular acceleration commands to correct attitude errors
- Providing feedforward control for improved tracking
- Applying integrators for steady-state error elimination

The ASC processes inputs including:
- Current controller mode
- Dynamic pressure
- Commanded quaternion orientation
- Feedforward angular rate commands
- Estimated quaternion orientation
- Filtered angular rates

Its primary output is `w_dot_cmd_trim0ncg_ned2trim0ncg_rad_per_s2`, a 3-element vector representing commanded angular acceleration around each axis.

## 3. Controller Objects Architecture

### 3.1 Controller Object Hierarchy

The controller system is organized as a hierarchical structure:

1. **Controllers_object** - Base class providing the interface for controller operations
2. **Controller_object_wrapper** - Wrapper for stepping through controller execution
3. **Recovery_wrapper_control_system_object** - Extension for recovery scenarios

The controller system implements several key components:

#### 3.1.1 Controller Manager (CM)

The Controller Manager coordinates controller modes and commands by:
- Determining controller modes based on rotor health status
- Managing takeoff and landing operations
- Controlling integrator modes
- Handling position and velocity commands

#### 3.1.2 Trajectory Command Generator (TCG)

Generates trajectory commands based on mission plans and current state.

#### 3.1.3 Trajectory Stabilization Controller (TSC)

Stabilizes the vehicle along commanded trajectories.

### 3.2 Control Modes and State Machines

The controller operates in various modes including:
- INIT
- GROUND_IDLE
- TAKEOFF
- LAND
- TRACK_SPLINE
- DEGRADED modes (for rotor failures)

State transitions are managed through a state machine that tracks:
- Current controller mode
- Degradation level (NOMINAL or degraded states)
- Command sequence IDs
- Route tracking data

### 3.3 Constrained Quadratic Programming (CQP)

The system uses Constrained Quadratic Programming for optimal control allocation:

```cpp
class Cqp {
public:
    struct Results {
        enum Status {
            success,
            infeasible,
            max_iterations_reached
        };
        
        Status status;
        R64vector solution;
        Base::Array<Constraint> active_set;
    };
    
    // Methods for solving optimization problems
    void step();
    const Results& get_out() const;
};
```

The CQP solver handles:
- Unconstrained optimization
- Bound constraints (upper and lower)
- Equality constraints
- Inequality constraints
- Feasibility checking

### 3.4 Switch Blending for Smooth Transitions

The `Switch_blender` class provides smooth transitions between different control signals:

```cpp
class Switch_blender {
public:
    // Blending modes
    struct Blending_mode { enum Type { ONE_SIDED, TWO_SIDED }; };
    struct Interpolation_mode { enum Type { LINEAR, SMOOTH }; };
    struct Limiting_mode { enum Type { TIME_LIMITED, RATE_LIMITED }; };
    struct Angle_wrapping_mode { enum Type { DISABLED, ENABLED }; };
    
    // Methods
    Real run(const Maverick::Rvector& input_signals, const Uint16 selected_signal_index);
};
```

This component supports:
- One-sided and two-sided blending modes
- Linear and smooth interpolation
- Time-limited and rate-limited transitions
- Optional angle wrapping for angular signals

### 3.5 Controller Telemetry

The system implements comprehensive telemetry through the `Recovery_controller_telemetry_msg` class, capturing detailed information about:

1. **Controllers Telemetry**:
   - Sep (State Estimation and Prediction)
   - Tcg (Trajectory Command Generator)
   - Aacg (Attitude and Acceleration Command Generator)
   - Asc (Attitude Stabilization Controller)
   - Tsc (Trajectory Stabilization Controller)
   - Forces and torques requests

2. **Mixer Telemetry**:
   - Mixer return values
   - Saturation status

3. **Recovery Control Command Processor (RCCP) Log Data**:
   - Recovery mission phase of flight
   - Mission data processing
   - Route construction
   - Tracking processor data

4. **State Machine Logs**:
   - Recovery state machine logs
   - State machines telemetry

## 4. Mixer System

### 4.1 Mixer Allocator Core Functionality

The `Mixer_allocator` class is the central component that:
- Takes wrench requests (forces and moments) in the vehicle frame
- Converts these requests to actuator commands (rotor speeds in krpm²)
- Handles actuator constraints and failures
- Implements prioritization schemes for wrench components
- Applies hysteresis to prevent rapid actuator oscillations

### 4.2 Allocation Process

The allocation process follows these steps:
1. Receive wrench requests in the vehicle frame
2. Transform requests to the allocation frame using quaternion rotation
3. Apply prioritization scheme (hard or soft)
4. Solve the constrained optimization problem
5. Apply hysteresis to prevent oscillations near constraints
6. Output actuator commands and predicted achievable wrench

### 4.3 Prioritization Schemes

The system operates with two main prioritization schemes:

1. **Hard Prioritization**: Enforces strict hierarchy of wrench components
   - Solves for highest priority components first
   - Fixes those solutions and solves for next priority level
   - Continues until all components are addressed or constraints prevent further optimization

2. **Soft Prioritization**: Uses weighted optimization to balance all components
   - All components are optimized simultaneously
   - Weights determine relative importance
   - Solution minimizes weighted sum of errors

### 4.4 Mixer Outputs

The `Mixer_allocator` produces an `Allocation_results` structure containing:

1. **Actuator Commands (`actuators`)**:
   - Vector of actuator commands in krpm² (kilo-RPM squared)
   - Used to control motor speeds

2. **Predicted Wrench (`fm_vtol_predict_N_and_N_m`)**:
   - 6-component vector of achievable forces and moments
   - May differ from requested wrench if constraints prevent exact achievement

3. **Wrench Component Exactness (`wrench_component_exact`)**:
   - Boolean array indicating which wrench components were achieved exactly
   - Used to determine if prioritization was successful

4. **Solve Status (`solve_status`)**:
   - Indicates success or failure of the optimization
   - Value from `Maverick::Cqp::Results` enum

### 4.5 Actuator Failure Handling

The mixer can handle actuator failures through the `actuator_failed` parameter:
- Failed actuators are constrained to their target values
- The optimization redistributes commands to remaining actuators
- Wrench components may not be achievable if too many actuators fail

### 4.6 Hysteresis Implementation

The mixer implements hysteresis to prevent actuator oscillations:
- When an actuator would be commanded to a value below a minimum threshold (but above zero), it is instead commanded to the hysteresis value
- This prevents rapid on/off cycling of actuators
- The hysteresis threshold is configurable via `scheduled_data.allocation_parameters.hysteresis_krpm`

## 5. Data Flow Between Components

The flight control system operates as a closed-loop system with the following data flow:

1. **Sensor Data → State Estimation**:
   - IMU data (accelerations, angular rates)
   - GPS data (position, velocity)
   - Air data (pressure, temperature)

2. **State Estimation → Controllers**:
   - Position, velocity, attitude estimates
   - Angular rates
   - Air data parameters (dynamic pressure, density)

3. **Controllers → Mixer**:
   - Force and moment requests (wrench)
   - Controller mode information
   - Prioritization schemes

4. **Mixer → Actuators**:
   - Motor speed commands (in krpm²)
   - Actuator status information

5. **Mixer → Controllers**:
   - Achievable wrench feedback
   - Saturation status

This closed-loop architecture ensures that the system can adapt to changing conditions and maintain stable flight.

## 6. Flight Control Algorithms

### 6.1 Attitude Control

The Attitude Stability Controller (ASC) implements a quaternion-based attitude control algorithm:
- Computes quaternion error between commanded and estimated attitude
- Applies proportional-derivative control to generate angular acceleration commands
- Uses feedforward angular rate commands for improved tracking
- Implements integrators for steady-state error elimination

### 6.2 Position Control

The position control system likely uses a cascaded control approach:
- Outer loop generates velocity commands based on position error
- Inner loop generates acceleration commands based on velocity error
- Acceleration commands are converted to force requests

### 6.3 Trajectory Tracking

The system implements trajectory tracking through:
- Trajectory Command Generator (TCG) for generating reference trajectories
- Trajectory Stabilization Controller (TSC) for following these trajectories
- Route tracking with waypoint navigation

### 6.4 Recovery Control

The recovery control system handles off-nominal conditions:
- Detects and responds to rotor failures
- Implements degraded control modes
- Manages motor states during recovery operations

## 7. Interfaces Between Components

### 7.1 Controller and Mixer Interface

The controller provides the mixer with:
```cpp
// Forces and torques request
Pa_blocks::Forces_and_torques_request forces_and_torques_request;
forces_and_torques_request.fx_N = fx_N;
forces_and_torques_request.fy_N = fy_N;
forces_and_torques_request.fz_N = fz_N;
forces_and_torques_request.l_N_m = l_N_m;
forces_and_torques_request.m_N_m = m_N_m;
forces_and_torques_request.n_N_m = n_N_m;
```

The mixer provides feedback to the controller:
```cpp
// Mixer return data
Pa_blocks::Mixer_return mixer_return;
controllers_input.mixer_return.emplace_back();
controllers_input.mixer_return.back().message = mixer_return;
```

### 7.2 State Estimation and Controller Interface

The state estimator provides the controller with:
```cpp
// State estimate
Pa_blocks::Controllers_state_estimate state_estimate;
state_estimate.is_initialized_roll_pitch = true;
state_estimate.is_initialized_roll_pitch_heading = true;
state_estimate.latitude_rad = latitude_rad;
state_estimate.longitude_rad = longitude_rad;
state_estimate.altitude_hae_wgs84_m = altitude_hae_wgs84_m;
state_estimate.altitude_agl_m = altitude_agl_m;
state_estimate.v_ned_ned2vf_m_per_s[0] = v_north;
state_estimate.v_ned_ned2vf_m_per_s[1] = v_east;
state_estimate.v_ned_ned2vf_m_per_s[2] = v_down;
```

### 7.3 Command Processing Interface

The controller processes various commands:
```cpp
// Take off command
Pa_blocks::Commands_processor::Takeoff_command take_off_command;
take_off_command.controller_cmd_seq_id = 1;
take_off_command.initial_tracking_point.ll.lat = latitude_rad;
take_off_command.initial_tracking_point.ll.lon = longitude_rad;
take_off_command.initial_tracking_point.h = altitude_hae_wgs84_m + take_off_agl;
take_off_command.takeoff_agl_m = take_off_agl;

// Land command
Pa_blocks::Commands_processor::Land_command land_command;
land_command.controller_cmd_seq_id = 30;
land_command.latitude_rad = land_latitude_rad;
land_command.longitude_rad = land_longitude_rad;
land_command.use_backyard_frame = false;
land_command.land_type = Pa_blocks::Land_command_params::Land_type::POSITION_COMMANDED;

// Route command
Pa_blocks::Commands_processor::Route_command_and_control route_command_and_control;
route_command_and_control.controller_cmd_seq_id = 10;
route_command_and_control.route.lla_ned_origin.ll.lat = state_estimate.latitude_rad;
route_command_and_control.route.lla_ned_origin.ll.lon = state_estimate.longitude_rad;
```

## 8. Flight Regimes and Mode Transitions

The flight control system handles different flight regimes through mode transitions:

### 8.1 Ground Operations
- INIT: System initialization
- GROUND_IDLE: Motors armed but not producing significant thrust

### 8.2 Vertical Flight
- TAKEOFF: Vertical ascent from ground
- LAND: Vertical descent to ground
- HOVER: Maintaining position with zero ground speed

### 8.3 Forward Flight
- TRACK_SPLINE: Following a predefined trajectory
- Various transition modes between vertical and forward flight

### 8.4 Degraded Operations
- DEGRADED_R1R6: Operation with specific rotor failures
- Other degraded modes based on failure patterns

Mode transitions are managed by the Controller Manager (CM) based on commands and vehicle state.

## 9. Key Algorithms

### 9.1 Quaternion-Based Attitude Control

The system uses quaternions for attitude representation and control:
```cpp
// Quaternion error computation
Base::Rv4 q_error = quaternion_multiply(q_cmd_trim0ncg_from_ned, quaternion_inverse(q_est_trim0ncg_from_ned));

// Angular acceleration command generation
w_dot_cmd = Kp * q_error.vector() + Kd * (w_cmd - w_est) + Ki * integral_term;
```

### 9.2 Constrained Quadratic Programming

The mixer uses quadratic programming to solve the allocation problem:
```cpp
// Objective function: Minimize ||Gx - a||² subject to constraints
// G: Actuator effectiveness matrix
// a: Desired wrench
// x: Actuator commands

// Constraints:
// lb ≤ x ≤ ub (Actuator bounds)
// Ax = b (Equality constraints)
// Cx ≤ d (Inequality constraints)
```

### 9.3 Switch Blending

The system implements smooth transitions between control signals:
```cpp
// Linear blending
output = (1-alpha) * signal_from + alpha * signal_to;

// Smooth blending (using sigmoid or similar function)
alpha = smooth_function(linear_blending_remaining);
output = (1-alpha) * signal_from + alpha * signal_to;
```

## 10. Error Handling and Robustness

### 10.1 Parameter Validation

The system validates parameters before operation:
```cpp
bool Controllers_object::is_specification_valid() {
    // Check controller frequency
    if (param_.common.controller_frequency_hz <= 0.0F) {
        return false;
    }
    // Additional parameter checks...
    return true;
}
```

### 10.2 Power-On Built-In Test (PBIT)

The system performs built-in tests to verify configuration:
```cpp
bool ControllersObjectTester_emb::IsPbitParameterConfigurationSelfConsistent() {
    return power_on_built_in_test_.is_parameter_configuration_self_consistent();
}
```

### 10.3 Rotor Health Monitoring

The system monitors rotor health and adapts control accordingly:
```cpp
// MEP out R1
in.rotors_health_status.rotor_rear_right_inoperative = true;
in.rotors_health_status.rotor_center_right_inoperative = false;
// Additional rotor status settings...
ret &= cm.step(in.input, out.output);
ret &= (out.output.modes_and_commands.controller_mode == Controller_mode::DEGRADED_R1R6);
```

### 10.4 Navigation Initialization Checking

The system checks navigation initialization before using state estimates:
```cpp
// NAV not initialized
Controllers_state_estimate state_estimate;
state_estimate.is_initialized_roll_pitch = false;
state_estimate.is_initialized_roll_pitch_heading = false;
```

## 11. Performance Considerations

### 11.1 Computational Efficiency

The mixer must solve a constrained optimization problem in real-time:
- Uses efficient quadratic programming algorithms
- Leverages matrix operations for performance
- Implements sensitivity analysis for predictable behavior

### 11.2 Memory Management

The system uses custom memory allocation:
```cpp
Base::Allocator& alloc_volatile(Base::Memmgr::get_instance().get_allocator(Base::Memmgr::external));
```

This allows for efficient memory usage in a real-time embedded system.

### 11.3 Numerical Stability

The system includes several techniques for numerical stability:
- Regularization coefficient for over-actuated systems
- Tolerance parameters for comparisons
- Air density scaling for consistent behavior at different altitudes

## 12. Testing and Validation

The flight control components are extensively tested through:

### 12.1 Unit Tests
- Parameter validation
- Algorithm correctness
- Error handling

### 12.2 Vector Tests
- Predefined input/output pairs
- Regression testing
- Edge case validation

### 12.3 Integration Tests
- Component interaction
- Data flow verification
- Mode transition testing

### 12.4 Sensitivity Analysis
- Response to parameter variations
- Robustness to disturbances
- Performance across flight envelope

## Conclusion

The flight control system is a sophisticated, multi-component architecture designed to maintain stable flight across various operating conditions. The tight integration between state estimation, control algorithms, and actuator allocation enables precise control of the vehicle's attitude and position. The system's robustness features, including parameter validation, health monitoring, and degraded operation modes, ensure safe operation even in the presence of failures or unexpected conditions.

The modular design with well-defined interfaces between components facilitates testing, maintenance, and future enhancements. The extensive testing framework ensures that the system meets its performance requirements across the entire flight envelope.