# Generated from:

- include/GeneralizedStateSpaceModels/Model_dynamic_unit_test.h (2951 tokens)
- include/GeneralizedStateSpaceModels/Model_unit_test.h (1319 tokens)
- include/GeneralizedStateSpaceModels/Gnc_model_gain_unit_test.h (229 tokens)
- include/GeneralizedStateSpaceModels/Model_dynamic_matlab_test.h (136 tokens)
- source/GeneralizedStateSpaceModels/Gnc_model_gain_unit_test.cpp (2229 tokens)
- source/GeneralizedStateSpaceModels/Model_unit_test.cpp (15071 tokens)
- source/GeneralizedStateSpaceModels/Model_dynamic_unit_test.cpp (42520 tokens)
- source/GeneralizedStateSpaceModels/Model_dynamic_matlab_test.cpp (3970 tokens)
- data/GeneralizedStateSpaceModels/generic_ss_unit_test.json (45945 tokens)

---

# Comprehensive Summary of Drone State Space Model Implementation

## 1. Model Base Class Architecture

The `Model` class serves as the abstract base class for all state space models in the system. It provides core functionality for handling state updates, input limiting, and model execution.

### Key Components

- **State Vectors**: Maintains internal state vectors for:
  - `x_state`: System state vector
  - `u_state`: Input state vector (current input after limiting)
  - `y_state`: Output state vector
  - `u_current_limit`: Temporary vector for limited input values

- **Input Limiting Parameters**:
  - `u_min`/`u_max`: Value bounds for inputs
  - `u_rate_min`/`u_rate_max`: Rate bounds for inputs
  - `tau_s`: Time step for rate limiting calculations

- **Model Parameters**:
  - `model_frequency_hz`: Execution frequency of the model
  - State space matrices (A, B, C, D) stored in the derived classes

- **State Management Flags**:
  - `is_state_update_enabled`: Controls whether state updates are performed
  - `is_output_initialized`: Tracks if output has been initialized
  - `is_output_state_reset_enabled`: Controls if state reset to match output is enabled

### Input Limiting Logic

The `limit_input()` method implements sophisticated input limiting with the following features:

1. **Value Limiting**: Constrains inputs between `u_min` and `u_max`
2. **Rate Limiting**: Restricts rate of change between `u_rate_min` and `u_rate_max`
3. **Limit Disabling**: 
   - Value limits are disabled when `u_min[i] == u_max[i] == 0`
   - Rate limits are disabled when `u_rate_min[i] == u_rate_max[i] == 0`
4. **Validity Checking**: Ensures `u_min[i] <= u_max[i]` and `u_rate_min[i] <= u_rate_max[i]`
5. **Tiny Bounds Handling**: Special handling for very small limit values (< 1e-4)

```cpp
// Pseudocode for input limiting
void limit_input(const Rvector& u, const Rvector& u_min, const Rvector& u_max, 
                 const Rvector& u_rate_min, const Rvector& u_rate_max, Rvector& u_limited) {
    // Apply value limits if valid
    if (u_min[i] <= u_max[i] && !(u_min[i] == 0 && u_max[i] == 0)) {
        u_limited[i] = min(max(u[i], u_min[i]), u_max[i]);
    } else {
        u_limited[i] = u[i];
    }
    
    // Apply rate limits if valid
    if (u_rate_min[i] <= u_rate_max[i] && !(u_rate_min[i] == 0 && u_rate_max[i] == 0)) {
        Real rate = (u_limited[i] - u_state[i]) / tau_s;
        rate = min(max(rate, u_rate_min[i]), u_rate_max[i]);
        u_limited[i] = u_state[i] + rate * tau_s;
    }
}
```

### Core Methods

- **`step_model()`**: Main method for advancing the model state
- **`reset_state()`**: Resets the model to initial conditions
- **`zero_x_state()`**: Sets state vector to zero (pure virtual)
- **`perform_state_reset_to_specified_output()`**: Resets state to produce specified output (pure virtual)

## 2. Model_dynamic Class Implementation

The `Model_dynamic` class extends `Model` to implement dynamic state space models with interpolation between multiple operating points.

### Key Features

#### Interpolation Mechanism

The class implements piecewise linear interpolation between state space models defined at different operating points:

```cpp
// Pseudocode for interpolation
void interpolate_matrices(Real interpolation_point) {
    // Find appropriate breakpoint indices
    int idx_low = find_lower_breakpoint_index(interpolation_point);
    int idx_high = idx_low + 1;
    
    // Calculate interpolation fraction
    Real alpha = (interpolation_point - breakpoints[idx_low]) / 
                 (breakpoints[idx_high] - breakpoints[idx_low]);
    
    // Interpolate matrices
    for (i = 0; i < nx; i++) {
        for (j = 0; j < nx; j++) {
            A_interp[i][j] = (1-alpha) * A[idx_low][i][j] + alpha * A[idx_high][i][j];
        }
        // Similar interpolation for B, C, D matrices
    }
}
```

This allows the model to handle non-linear systems by approximating them as piecewise linear systems across different operating regions.

#### Anti-Windup Logic

The `Model_dynamic` class implements sophisticated anti-windup logic to handle output saturation:

1. **RESET_STATE**: Resets the state when output saturation occurs
2. **FREEZE_STATE_SINGLE_AXIS**: Selectively freezes state updates along axes that would increase saturation

```cpp
// Pseudocode for anti-windup logic
bool run_anti_windup_logic(const Rvector& u, Real interpolation_point, 
                          const Rvector& previous_y_saturated) {
    if (antiwindup_logic_type == RESET_STATE) {
        // Reset state to match saturated output
        return perform_state_reset_to_specified_output(previous_y_saturated);
    } 
    else if (antiwindup_logic_type == FREEZE_STATE_SINGLE_AXIS) {
        // For each output axis that's saturated
        for (int i = 0; i < ny; i++) {
            if (is_saturated(y_state[i], previous_y_saturated[i])) {
                // Determine if state update would increase or decrease saturation
                // Freeze state updates along axes that would increase saturation
                for (int j = 0; j < nx; j++) {
                    if (would_increase_saturation(j, i)) {
                        is_state_update_enabled_along_axes[j] = false;
                    }
                }
            }
        }
        return true;
    }
}
```

#### State Update Control

The class provides fine-grained control over state updates:

1. **Global Enable/Disable**: Through `is_state_update_enabled` flag
2. **Per-Axis Enable/Disable**: Through `is_state_update_enabled_along_axes` vector
3. **Selective Freezing**: Through anti-windup logic

```cpp
// Pseudocode for state update
void update_state(const Rvector& u_limited) {
    if (!is_state_update_enabled) return;
    
    // Calculate next state: x = Ax + Bu
    for (int i = 0; i < nx; i++) {
        if (is_state_update_enabled_along_axes[i]) {
            Real new_state = 0;
            for (int j = 0; j < nx; j++) {
                new_state += A_interp[i][j] * x_state[j];
            }
            for (int j = 0; j < nu; j++) {
                new_state += B_interp[i][j] * u_limited[j];
            }
            x_state[i] = new_state;
        }
    }
}
```

### Step Execution Flow

The `step()` method implements the main execution flow:

1. Apply anti-windup logic if previous saturated output is provided
2. Limit input values based on min/max and rate constraints
3. Interpolate state space matrices based on operating point
4. Update state vector if state updates are enabled
5. Calculate output: y = Cx + Du
6. Store current input and output for next iteration

## 3. Gnc_model_gain Implementation

The `Gnc_model_gain` class is a specialized implementation for gain-only models (no state dynamics, only direct input-to-output mapping).

### Key Features

- Implements a simplified state space model where output is directly calculated from input
- Uses interpolation to handle gain scheduling based on operating point
- Supports the same input limiting functionality as the base Model class

```cpp
// Pseudocode for Gnc_model_gain step method
bool step(const Rvector& u, Real interpolation_point, Rvector& y) {
    // Limit input
    limit_input(u, u_min, u_max, u_rate_min, u_rate_max, u_limited);
    
    // Interpolate D matrix (gain matrix)
    interpolate_D_matrix(interpolation_point);
    
    // Calculate output: y = Du
    for (int i = 0; i < ny; i++) {
        y[i] = 0;
        for (int j = 0; j < nu; j++) {
            y[i] += D_interp[i][j] * u_limited[j];
        }
    }
    
    return true;
}
```

## 4. State Space Model Parameters

The system uses a `State_space_model_params` structure to store and pass model parameters:

```cpp
template <Uint16 NX_MAX, Uint16 NU, Uint16 NY, Uint16 NI_MAX>
struct Tstate_space_model_params {
    Real model_frequency_hz;
    Maverick::Rvector input_lower_bounds;
    Maverick::Rvector input_upper_bounds;
    Maverick::Rvector input_rate_lower_bounds;
    Maverick::Rvector input_rate_upper_bounds;
    Antiwindup_logic_type::Type antiwindup_logic_type;
    Maverick::Rvector initial_output;
    Base::Xrtable<Ku32::u1, Ku32::u1> abcd_data;
    
    // Methods to set A, B, C, D matrices and breakpoints
    void set_a(const Real (&A)[NI_MAX][NX_MAX][NX_MAX]);
    void set_b(const Real (&B)[NI_MAX][NX_MAX][NU]);
    void set_c(const Real (&C)[NI_MAX][NY][NX_MAX]);
    void set_d(const Real (&D)[NI_MAX][NY][NU]);
    void set_breakpoints(const Real (&breakpoints)[NI_MAX]);
};
```

## 5. Error Handling and Validation

The implementation includes comprehensive error handling and validation:

1. **Input Parameter Validation**:
   - Checks for valid min/max bounds (min ≤ max)
   - Validates rate limits
   - Ensures matrix dimensions are consistent

2. **Runtime Validation**:
   - Checks for NaN/Inf values in calculations
   - Validates interpolation points against breakpoint range
   - Ensures state dimensions match model dimensions

3. **Reset Solution Validity**:
   - Validates that output matrices have full row rank for state reset operations
   - Checks that interpolated matrices maintain required properties

## 6. Testing Framework

The implementation includes extensive unit tests to validate functionality:

### Model Unit Tests

- Tests for input limiting behavior with various boundary conditions
- Tests for state reset functionality
- Tests for input state initialization

### Model_dynamic Unit Tests

- Tests for basic state space model functionality
- Tests for interpolation between operating points
- Tests for anti-windup logic with different saturation scenarios
- Tests for selective state update freezing
- Tests for handling non-injective state-to-output mappings

### MATLAB Test Vectors

The implementation includes validation against MATLAB reference implementations:

- Uses JSON test vectors generated from MATLAB
- Validates state evolution, output calculation, and input limiting
- Ensures numerical accuracy within specified tolerances

```cpp
// Example of MATLAB test vector validation
bool test00_MatlabTestVectors() {
    // Load test vectors from JSON file
    Json::Value obj = load_json_file("generic_ss_unit_test.json");
    
    // Extract system matrices, inputs, and expected outputs
    extract_matrices_from_json(obj);
    
    // Create model instance
    ModelDynamicTest ssm(x_state, u_state, y_state, ...);
    
    // Run test vector inputs through system
    for (Uint32 i = 1; i < num_points; i++) {
        // Get input and expected output
        u_in = get_input_from_json(obj, i);
        y_expected = get_expected_output_from_json(obj, i);
        
        // Run model
        ssm.Run(u_in, interpolation_point, y_test);
        
        // Verify output matches expected within tolerance
        EXPECT_NEAR(y_expected, y_test, TOL);
    }
}
```

## 7. Memory Management

The implementation uses a custom memory management system:

- Uses `Base::Memmgr` for memory allocation
- Supports different memory allocation strategies (external, internal)
- Properly handles vector and matrix memory allocation/deallocation

## 8. Key Algorithms

### Piecewise Linear Interpolation

The system uses piecewise linear interpolation to approximate non-linear systems:

1. Find the two breakpoints surrounding the current operating point
2. Calculate interpolation fraction based on position between breakpoints
3. Linearly interpolate all state space matrices (A, B, C, D)
4. Use interpolated matrices for state update and output calculation

### Anti-Windup Logic

Two anti-windup strategies are implemented:

1. **RESET_STATE**: 
   - Resets the entire state vector to match saturated output
   - Simple but can cause discontinuities

2. **FREEZE_STATE_SINGLE_AXIS**:
   - More sophisticated approach
   - Analyzes which state components contribute to saturation
   - Selectively freezes state updates that would increase saturation
   - Allows updates that would reduce saturation
   - Handles non-injective state-to-output mappings

## 9. JSON Test Vector Format

The implementation uses JSON test vectors for validation against MATLAB reference implementations. The JSON file `generic_ss_unit_test.json` contains:

1. **State Space Matrices**:
   - A1, B1, C1, D1: Matrices for first operating point
   - A2, B2, C2, D2: Matrices for second operating point
   - A3, B3, C3, D3: Matrices for third operating point

2. **System Parameters**:
   - tau: Time step (0.01)
   - breakpoints: Operating points [1, 5, 9]
   - y_bounds: Output bounds {lb: [-6, -11], ub: [5, 10]}
   - u_bounds: Input bounds {lb: [-4, -9], ub: [4, 11]}
   - u_rate_bounds: Input rate bounds {lb: [-60, -35], ub: [60, 35]}

3. **Test Vectors**:
   - time: Time points from 0 to 10 seconds
   - x0: Initial state [0, 0, 0]
   - interpolation_param: Interpolation parameter values
   - u: Input values for each time step
   - ulim: Limited input values
   - y_out: Expected output values
   - x_out: Expected state values

The test vectors provide a comprehensive validation suite for the state space model implementation, ensuring that the C++ implementation matches the MATLAB reference implementation across a wide range of operating conditions.

## Referenced Context Files

The following context files provided valuable information for understanding the system:

1. `data/GeneralizedStateSpaceModels/generic_ss_unit_test.json`: Contains comprehensive test vectors for validating the state space model implementation against MATLAB reference implementations. Includes state space matrices for three operating points, system parameters, and expected state/output trajectories.

This JSON file is particularly valuable as it demonstrates:
- The structure of the state space matrices used in the model
- The format of the breakpoints for interpolation (1, 5, 9)
- The input and output bounds used for limiting and saturation
- The expected behavior of the system under various input conditions
- The expected state evolution and output response

The test vectors in this file provide a complete reference implementation that can be used to validate the correctness of the C++ implementation, ensuring that it matches the MATLAB reference implementation in terms of state evolution, output calculation, and input limiting behavior.