# Generated from:

- pa_blocks/code/include/Irmatrix3_sub.h (1226 tokens)
- pa_blocks/code/include/Col_piv_householder_qr.h (4668 tokens)
- pa_blocks/code/include/Least_square_solver_basic.h (539 tokens)
- pa_blocks/code/include/Least_squares_solver_vel.h (1233 tokens)
- pa_blocks/code/include/Least_squares_single_shot_solution.h (143 tokens)
- pa_blocks/code/include/Least_squares_single_shot_position.h (260 tokens)
- pa_blocks/code/include/Least_squares_single_shot_velocity.h (162 tokens)
- pa_blocks/code/include/Iterative_least_squares_solver.h (1618 tokens)
- pa_blocks/code/include/Ls_pos_state.h (245 tokens)
- pa_blocks/code/include/Real16_amz.h (160 tokens)
- pa_blocks/code/include/Shallow_copy_array.h (925 tokens)
- pa_blocks/code/include/Slew_rate_filter.h (480 tokens)
- pa_blocks/code/include/Switch_blender.h (1086 tokens)
- pa_blocks/code/include/Vector_saturation.h (5304 tokens)
- pa_blocks/code/include/Magnitude_saturation_type.h (698 tokens)
- pa_blocks/code/include/Direction_saturation_type.h (289 tokens)
- pa_blocks/code/include/Norm_type.h (62 tokens)
- pa_blocks/code/include/Antiwindup_logic_type.h (147 tokens)
- pa_blocks/code/include/Max_value.h (184 tokens)
- pa_blocks/code/include/Crc32_checksum.h (127 tokens)
- pa_blocks/code/include/Checksum_info.h (327 tokens)
- pa_blocks/code/include/Latch_on_first_true.h (69 tokens)
- pa_blocks/code/include/Pa_irquat.h (920 tokens)
- pa_blocks/code/include/Pa_geometric.h (386 tokens)
- pa_blocks/code/include/Gnc_vector_saturation.h (11142 tokens)
- pa_blocks/code/include/Gnc_vector_saturation_set.h (1261 tokens)
- pa_blocks/code/include/Gnc_model_dynamic.h (447 tokens)
- pa_blocks/code/include/Gnc_model_gain.h (410 tokens)
- pa_blocks/code/include/Gnc_model_set.h (604 tokens)
- pa_blocks/code/include/Covariance_ud.h (1026 tokens)
- pa_blocks/code/include/Covariance_ud_fw.h (28 tokens)
- pa_blocks/code/include/Cqp.h (2889 tokens)
- pa_blocks/code/include/Delta_state.h (145 tokens)
- pa_blocks/code/include/Delta_state_fw.h (27 tokens)
- pa_blocks/code/include/Dyn_pa_interpolator_cat_2.h (693 tokens)
- pa_blocks/code/include/Dyn_pa_interpolator_cat_2_fw.h (41 tokens)
- pa_blocks/code/include/Iekf_updater.h (256 tokens)
- pa_blocks/code/include/Saturation_parameters.h (2064 tokens)
- pa_blocks/code/include/Saturation_parameters_fw.h (34 tokens)
- pa_blocks/code/include/Velocity_2d.h (195 tokens)
- pa_blocks/code/include/Velocity_3d.h (400 tokens)
- pa_blocks/code/source/Irmatrix3_sub.cpp (1767 tokens)
- pa_blocks/code/source/Least_square_solver_basic.cpp (540 tokens)
- pa_blocks/code/source/Least_squares_solver_vel.cpp (3026 tokens)
- pa_blocks/code/source/Least_squares_single_shot_solution.cpp (108 tokens)
- pa_blocks/code/source/Least_squares_single_shot_position.cpp (168 tokens)
- pa_blocks/code/source/Least_squares_single_shot_velocity.cpp (144 tokens)
- pa_blocks/code/source/Iterative_least_squares_solver.cpp (2733 tokens)
- pa_blocks/code/source/Ls_pos_state.cpp (289 tokens)
- pa_blocks/code/source/Real16_amz.cpp (2216 tokens)
- pa_blocks/code/source/Slew_rate_filter.cpp (353 tokens)
- pa_blocks/code/source/Switch_blender.cpp (3747 tokens)
- pa_blocks/code/source/Vector_saturation.cpp (6818 tokens)
- pa_blocks/code/source/Max_value.cpp (tokens unknown)
- pa_blocks/code/source/Crc32_checksum.cpp (42 tokens)
- pa_blocks/code/source/Latch_on_first_true.cpp (85 tokens)
- pa_blocks/code/source/Pa_irquat.cpp (2754 tokens)
- pa_blocks/code/source/Pa_geometric.cpp (4167 tokens)
- pa_blocks/code/source/Gnc_vector_saturation.cpp (6691 tokens)
- pa_blocks/code/source/Gnc_vector_saturation_set.cpp (752 tokens)
- pa_blocks/code/source/Gnc_model_dynamic.cpp (630 tokens)
- pa_blocks/code/source/Gnc_model_gain.cpp (326 tokens)
- pa_blocks/code/source/Gnc_model_set.cpp (531 tokens)
- pa_blocks/code/source/Covariance_ud.cpp (1386 tokens)
- pa_blocks/code/source/Cqp.cpp (12664 tokens)
- pa_blocks/code/source/Delta_state.cpp (82 tokens)
- pa_blocks/code/source/Dyn_pa_interpolator_cat_2.cpp (1433 tokens)
- pa_blocks/code/source/Saturation_parameters.cpp (355 tokens)
- pa_blocks/code/source/Velocity_2d.cpp (526 tokens)
- pa_blocks/code/source/Velocity_3d.cpp (669 tokens)

---

# Mathematical Utilities in the Drone System

This document provides a comprehensive analysis of the mathematical utilities used throughout the drone system. These utilities form the foundation for various operations including navigation, control, state estimation, and optimization.

## 1. Matrix and Vector Operations

### 1.1 Irmatrix3_sub Class

The `Irmatrix3_sub` class represents a 3x3 matrix with contiguous memory rows but non-contiguous memory columns. It's designed to work with submatrices of larger matrices.

```cpp
class Irmatrix3_sub {
public:
    // Creates a submatrix from a larger matrix
    Irmatrix3_sub(Maverick::Rmatrix& m0, const Uint16 i, const Uint16 j);
    
    // Matrix operations
    void submatTmatT(const Irmatrix3_sub& y, const Maverick::Irmatrix3& x0);
    void submatTmatT_add(const Irmatrix3_sub& y, const Maverick::Irmatrix3& x0);
    void thisdiagthisT_add(const Maverick::Irvector3& d, Maverick::Irmatrix3& out0) const;
    void setsubmatT(const Irmatrix3_sub& m);
    
    static const Uint16 nr = 3U;  // Number of columns
    static const Uint16 nc = 3U;  // Number of rows
    
private:
    Base::Tnarray<Real*, nc> cols;  // Array of pointers to first element of every column
};
```

Key operations include:
- `submatTmatT`: Computes the product of the transpose of a sub-matrix by the transpose of a matrix
- `submatTmatT_add`: Computes the product and adds it to the current value
- `thisdiagthisT_add`: Increments a matrix by `Irmatrix3_sub * diag(d) * Irmatrix3_sub^T`
- `setsubmatT`: Transposes a given matrix and stores it in the current instance

### 1.2 Vector Operations

The system includes specialized vector operations through classes like `Vector_saturation` which provides various vector saturation methods:

```cpp
struct Vector_saturation {
    // Direction saturation methods
    static void apply_vec_dir_saturation_euler(const Maverick::Irvector3& vec_in,
                                              const Real min_pitch_rad,
                                              const Real max_pitch_rad,
                                              const Real min_yaw_rad,
                                              const Real max_yaw_rad,
                                              Vec_sat_output& out);
                                              
    static void apply_vec_dir_saturation_quaternion(const Norm_type::Type norm_type,
                                                   const Maverick::Irvector3& vec_in,
                                                   const Real theta_y_max_rad,
                                                   const Real theta_z_max_rad,
                                                   Vec_sat_output& out);
    
    // Magnitude saturation methods
    static void apply_vec_mag_saturation_max_direction_preserving(const Maverick::Rvector& vec_in,
                                                                 const Maverick::Rvector& saturation_limits,
                                                                 Vec_sat_output& out,
                                                                 const Norm_type::Type n_type = Norm_type::two);
    
    static void apply_vec_mag_saturation_min_independent(const Maverick::Rvector& vec_in,
                                                        const Maverick::Rvector& saturation_limits,
                                                        Vec_sat_output& out);
    
    // Many more saturation methods...
};
```

These methods provide various ways to saturate vectors while preserving certain properties:
- Direction saturation using Euler angles or quaternions
- Magnitude saturation with direction preservation
- Independent axis saturation
- Cylindrical saturation

## 2. Quaternion Operations

The `Pa_irquat` namespace provides quaternion operations specifically tailored for the drone's orientation representation:

```cpp
namespace Pa_irquat {
    // Convert between quaternions and roll-pitch-yaw angles
    void rpy2quat(Real r, Real p, Real y, Maverick::Irquat& quat);
    void quat2rpy(const Maverick::Irquat& quat, Real& r, Real& p, Real& y);
    
    // Extract individual angles
    Real quat2pitch(const Maverick::Irquat& quat);
    Real quat2roll(const Maverick::Irquat& quat);
    Real quat2yaw(const Maverick::Irquat& quat);
    
    // Quaternion operations
    void quat_conj_rotate_vector(const Maverick::Irquat& quat,
                                const Maverick::Irvector3& in,
                                Maverick::Irvector3& out);
    
    void quaternion_slerp(const Maverick::Irquat& q_0,
                         const Maverick::Irquat& q_1,
                         const Real t,
                         Maverick::Irquat& q);
    
    void limit_rotation_angle(const Maverick::Irquat& q_b0_from_n,
                             const Maverick::Irquat& q_b1_from_n,
                             const Real max_abs_rotation_angle_rad,
                             Maverick::Irquat& q_rotation_limited_b1_from_n);
    
    Real angular_distance(const Maverick::Irquat& q_b0_from_n,
                         const Maverick::Irquat& q_b1_from_n);
    
    void quat_mult_rect(const Maverick::Irquat& q_0,
                       const Maverick::Irquat& q_1,
                       Maverick::Irquat& q);
    
    void quat_from_angle_axis_rad(const Maverick::Irvector3& axis,
                                 const Real angle,
                                 Maverick::Irquat& quat);
}
```

These functions provide essential operations for working with quaternions in the context of drone orientation:
- Converting between quaternions and Euler angles
- Extracting individual rotation components
- Performing quaternion interpolation (SLERP)
- Limiting rotation angles
- Computing angular distances between orientations
- Creating quaternions from rotation axes and angles

## 3. Least Squares Solvers

The system includes several least squares solvers for different applications:

### 3.1 Basic Least Squares Solver

```cpp
class Least_square_solver_basic {
public:
    Least_square_solver_basic(const R64matrix& h0,
                             const R64vector& epsilons0,
                             const R64vector& weights0,
                             R64vector& delta0,
                             Base::Memmgr::Type memtype);
    
    bool solve();
    
private:
    const R64matrix& h;              // Observation matrix
    const R64vector& epsilons;       // Residual vector
    const R64vector& weights;        // Position weights array
    R64vector& delta;                // Solution
    R64matrix weights_h;             // Work matrix to store weights*h
    R64matrix ht_weights_h;          // Work matrix to store ht*weights*h
    R64vector epsilons_weigths;      // Work vector to store epsilons*weights
    R64vector ht_weights_epsilons;   // Work vector to store ht*weights*epsilons
};
```

This solver computes the least squares solution of the equation `h'*weights*h*delta = weights*epsilons` where delta is the unknown.

### 3.2 Velocity Least Squares Solver

```cpp
class Least_squares_solver_vel {
public:
    struct Output {
        Base::R64v3 v_n_e2receiver_mps;      // Velocity in NED frame [mps]
        Base::R64v3 v_e_e2receiver;          // Velocity in ECEF frame [mps]
        Real64 clock_drift_m_per_s;          // Clock drift [mps]
        Maverick::R64vector x_prev;          // Previous estimated state vector
        bool is_success;                     // Flag indicating successful estimation
        Real64 speed_accuracy_m_per_s;       // Speed accuracy [mps]
    };
    
    Least_squares_solver_vel(const Raim_parameters& parameters0,
                            const Base::R64v3& p_e_e2receiver_m0,
                            const Sv_data& sv_data0,
                            const Gnss_raw_meas& exp_raw_meas0,
                            const Maverick::R64matrix& r_ne0);
    
    void step(const Gnss_nav_parser_state::Health_arr& useful_svids);
    
    const Output& get_out() const;
    
    void reset_success_flag();
};
```

This solver performs iterative least squares for velocity estimation using GNSS measurements.

### 3.3 Iterative Least Squares Solver for Position

```cpp
class Iterative_least_squares_solver {
public:
    struct DilutionOfPrecision {
        Real pdop;  // Position Dilution of Precision
        Real tdop;  // Time Dilution of Precision
        Real gdop;  // Geometric Dilution of Precision
        Real hdop;  // Horizontal Dilution of Precision
        Real vdop;  // Vertical Dilution of Precision
    };
    
    struct Output {
        Maverick::R64vector delta_x;
        bool is_success;
        bool position_is_success;
        const Maverick::R64vector& position_weighting_array;
        const Maverick::R64matrix& pos_H;
        const Maverick::R64vector& pos_epsilons;
        const Uint16& num_gps_svs_used;
        const Uint16& num_gal_svs_used;
        Base::R64v3 p_e_e2receiver_m;
        Real64 receiver_clock_bias_m;
        Real64 galileo_bias_m;
    };
    
    Iterative_least_squares_solver(const Raim_parameters& raim_parameters0,
                                  const Gnss_raw_meas& gnss_raw_meas0,
                                  Sv_data& sv_data0,
                                  const Gnss_nav_parser_state& gps_nav_msgs,
                                  const Ls_pos_state& initial_ls_state,
                                  const Raim_states& raim_state);
    
    void step(Gnss_nav_parser_state::Health_arr& useful_svids);
    
    const Output& get_out() const;
};
```

This solver performs iterative least squares for position estimation using GNSS measurements.

### 3.4 QR-based Least Squares Solver

The system includes a column-pivoted Householder QR factorization for solving least squares problems:

```cpp
template <typename T>
class Col_piv_householder_qr {
public:
    Col_piv_householder_qr(const Maverick::Tmatrix<T>& A0, Base::Allocator& allocator0);
    
    void compute_in_place();
    void make_householder(Maverick::Tvector<T>& essential, Real& tau, Real& beta, Real& c0);
    void make_householder_in_place(Maverick::Tvector<T>& u, Real& tau, Real& beta);
    void apply_householder_on_the_left(Maverick::Tmatrix<T>& matrix,
                                      Maverick::Tvector<T>& essential,
                                      Real& tau,
                                      Real* workspace);
    void householder_q(Uint32 length);
    void householder_r(Uint32 sz);
    void solve(const Maverick::Tvector<T>& rhs, Maverick::Tvector<T>& x);
    
protected:
    // Various internal matrices and vectors for the QR factorization
    const Maverick::Tmatrix<T>& A;
    Uint32 diagonal_size;
    Maverick::Tmatrix<T> m_qr;
    Maverick::Tvector<T> m_h_coeffs;
    Maverick::Tvector<Uint16> m_cols_transpositions;
    Maverick::Tvector<Real> m_col_norms_updated;
    Maverick::Tvector<Real> m_col_norms_direct;
    // More internal state...
};
```

This implementation provides a numerically stable method for solving least squares problems through QR factorization with column pivoting.

## 4. Constrained Quadratic Programming

The `Cqp` class implements a solver for constrained quadratic programming problems:

```cpp
class Cqp {
public:
    struct Active_constraints {
        Active_constraints(const Uint16 num_variables, Base::Allocator& alloc);
        Maverick::Rmatrix a_active;  // Jacobian matrix defining active constraints
        Maverick::Rvector b_active;  // Right-hand side defining active constraints
    };
    
    struct Constraint {
        enum Constraint_type {
            equality    = 0U,  // Equality constraint
            inequality  = 1U,  // Inequality constraint
            lower_bound = 2U,  // Lower bound
            upper_bound = 3U   // Upper bound
        };
        
        Constraint(Constraint_type type0, Uint16 index0);
        Constraint_type type;
        Uint16 index;
    };
    
    struct Results {
        enum Solve_status {
            success        = 0U,  // Solution found
            max_iterations = 1U,  // Error: maximum iterations reached
            infeasible     = 2U,  // Error: problem is infeasible
            incomplete     = 3U   // Solution not found yet
        };
        
        Results(const Uint16 num_variables, Base::Allocator& alloc_volatile);
        Solve_status status;
        Maverick::R64vector solution;
        Base::Array<Constraint> active_set;
        Maverick::R64matrix j;
        Maverick::R64matrix r;
    };
    
    Cqp(const Maverick::R64matrix& g0,
        const Maverick::R64vector& a0,
        const Maverick::R64matrix& a_eq0,
        const Maverick::R64vector& b_eq0,
        const Maverick::R64matrix& a_ineq0,
        const Maverick::R64vector& b_ineq0,
        const Maverick::R64vector& lb0,
        const Maverick::R64vector& ub0,
        Base::Allocator& alloc_volatile);
    
    void step();
    const Results& get_out() const;
    void construct_active_constraints(Cqp::Active_constraints& active_constraints);
    void publish_timing();
    
private:
    // Internal methods and state for the solver
    void apply_constraints(const Constraint violated_constraint,
                          const Uint16 a_eq_rows,
                          const Uint16 maximum_iterations,
                          Uint16& number_of_active_set_updates);
    
    void compute_step_directions();
    void update_to_add_constraint();
    void update_to_remove_constraint(const Uint16 index);
    
    // Problem definition
    const Uint16 num_variables;
    const Maverick::R64matrix& g;       // Hessian matrix
    const Maverick::R64vector& a;       // Gradient vector
    const Maverick::R64matrix& a_eq;    // Equality constraint matrix
    const Maverick::R64matrix& a_ineq;  // Inequality constraint matrix
    const Maverick::R64vector& b_eq;    // Equality constraint RHS
    const Maverick::R64vector& b_ineq;  // Inequality constraint RHS
    const Maverick::R64vector& lb;      // Lower bounds
    const Maverick::R64vector& ub;      // Upper bounds
    
    // Solution and working variables
    Results results;
    Maverick::R64matrix llt_lower;
    Maverick::R64vector u;
    Maverick::R64vector n_p;
    Maverick::R64vector d;
    Maverick::R64vector primal_z;
    Maverick::R64vector dual_r;
    // More internal state...
};
```

This solver implements the Goldfarb-Idnani dual method for solving quadratic programming problems with equality and inequality constraints, as well as bound constraints.

## 5. Covariance and State Estimation

### 5.1 Covariance UD Factorization

The `Covariance_ud` class manages the estimated state covariance using UD factorization:

```cpp
struct Covariance_ud {
    enum Delta_state_enum {
        ds_rho_x  =  0U,  // Position states
        ds_rho_y  =  1U,
        ds_rho_z  =  2U,
        ds_t_x    =  3U,  // Translation states
        ds_t_y    =  4U,
        ds_t_z    =  5U,
        ds_v_x    =  6U,  // Velocity states
        ds_v_y    =  7U,
        ds_v_z    =  8U,
        ds_bacc_x =  9U,  // Accelerometer bias states
        ds_bacc_y = 10U,
        ds_bacc_z = 11U,
        ds_bgyr_x = 12U,  // Gyroscope bias states
        ds_bgyr_y = 13U,
        ds_bgyr_z = 14U,
        ds_z      = 15U   // Other state
    };
    
    static const Uint16 num_states = 15U;
    static const Uint16 max_sen_dimension = 3U;
    
    Covariance_ud();
    
    void update_ud(const Iekf_updater& obs, Uint16 i);
    void rank1_updates(const State& state0, Iekf_updater& obs, Maverick::Rvector& delta);
    void update_p_pos();
    void update_p_vel();
    const Maverick::Rmatrix& get_k() const;
    
    Maverick::Rmatrix u;  // Upper triangular matrix for covariance P = UDU'
    Maverick::Rvector d;  // Diagonal matrix for covariance
    Maverick::Rvector f;  // Work vector for update f = U'*H(i,:)'
    Maverick::Rvector v;  // Work vector for update v = D.*f
    Maverick::Rmatrix k;  // Kalman filter gain
    Maverick::Rmatrix3 p_pos;  // Position covariance
    Maverick::Rmatrix3 p_vel;  // Velocity covariance
    
    // More internal state...
};
```

This class implements the UD factorization for covariance updates in Kalman filtering, which is numerically more stable than directly updating the covariance matrix.

### 5.2 Delta State

The `Delta_state` struct holds the state corrections:

```cpp
struct Delta_state {
    Delta_state();
    
    Base::Ttime time_s;  // Time when the delta state was computed
    Base::Tnarray<Real, Covariance_ud::num_states> x;  // Delta states
};
```

## 6. Signal Processing Utilities

### 6.1 Slew Rate Filter

```cpp
class Slew_rate_filter {
public:
    struct State {
        State();
        void reset(Real x0);
        
        Real x;          // The filter state
        bool initialized; // True if filter has been initialized
    };
    
    struct Param {
        Real slew_rate_limit_min;  // Minimum slew rate limit
        Real slew_rate_limit_max;  // Maximum slew rate limit
        Real dt_s;                 // Filter time step [s]
    };
    
    Slew_rate_filter(const Param& slew_rate_filter_parameters,
                    State& slew_rate_filter_state);
    
    Real step(const Real u_cmd);
    void reset_filter(const Real x0);
    bool reset_state();
    bool is_state_reset_allowed() const;
    const State& get_state() const;
    
private:
    State& state_;
    const Param& param_;
    static const Real dt_min_s;  // Minimum time step
};
```

This filter limits the rate of change of a signal, ensuring smooth transitions.

### 6.2 Switch Blender

```cpp
class Switch_blender {
public:
    struct Blending_mode { enum Type { ONE_SIDED, TWO_SIDED }; };
    struct Angle_wrapping_mode { enum Type { DISABLED, ENABLED }; };
    struct Interpolation_mode { enum Type { LINEAR, SMOOTH }; };
    struct Limiting_mode { enum Type { TIME_LIMITED, RATE_LIMITED }; };
    
    struct Param_ {
        Param_();
        
        Blending_mode::Type blending_mode;
        Angle_wrapping_mode::Type angle_wrapping_mode;
        Interpolation_mode::Type interpolation_mode;
        Real blending_rate_limit;
        Real time_step_s;
        Limiting_mode::Type limiting_mode;
        Real max_time_limit_s;
        Uint16 initial_signal_index;
    };
    
    struct State_ {
        State_(Uint16 n, Base::Allocator& alloc, Uint16 initial_signal_index_0);
        void reset();
        void copy(const State_& other);
        
        bool ran_once;
        Maverick::Rvector previous_input_signals;
        Uint16 blending_to_signal_index;
        Uint16 blending_from_signal_index;
        Real linear_blending_remaining;
        Real signal_difference_to_minus_from;
        Uint16 initial_signal_index_for_state_reset;
    };
    
    Switch_blender(const Param_& param_0, Uint16 n, Base::Allocator& alloc);
    
    Real run(const Maverick::Rvector& input_signals, Uint16 requested_signal_index);
    
    Uint16 get_blending_to_signal_index() const;
    Uint16 get_blending_from_signal_index() const;
    bool is_blending_in_progress() const;
    bool reset_state();
    State_& get_state();
    bool is_valid() const;
    
    void set_blending_to_signal_index(Uint16 blending_to_signal_index);
    void set_blending_from_signal_index(Uint16 blending_from_signal_index);
    void set_initial_signal_index_for_state_reset(Uint16 initial_signal_index_for_state_reset);
    
private:
    static const Real EPS;
    const Param_& param_;
    State_ state_;
    const Uint16 sz;
    const bool is_valid_;
    
    bool check_validity() const;
};
```

This class provides smooth blending between different signals, with support for different blending modes, angle wrapping, and interpolation methods.

## 7. Geometric Utilities

The `Pa_geometric` namespace provides geometric operations:

```cpp
namespace Pa_geometric {
    bool circle_from_two_points_and_two_tangents(const Maverick::Rvector2& point1, 
                                                const Maverick::Rvector2& point2, 
                                                const Maverick::Rvector2& tangent1, 
                                                const Maverick::Rvector2& tangent2, 
                                                Maverick::Rvector2& circle_center, 
                                                Real& circle_radius);
    
    bool circle_from_two_points_and_one_tangent(const Maverick::Rvector2& point1, 
                                               const Maverick::Rvector2& point2, 
                                               const Maverick::Rvector2& tangent1, 
                                               Maverick::Rvector2& circle_center, 
                                               Real& circle_radius);
    
    bool get_unsigned_angle_between_two_vectors(const Maverick::Rvector3& vec1,
                                               const Maverick::Rvector3& vec2,
                                               Real& angle);
    
    Real wrap2pi(const Real& angle_rad);
    Real wrap22pi(const Real& angle_rad);
}
```

These functions provide geometric operations like finding circles from points and tangents, computing angles between vectors, and wrapping angles.

## 8. Model-Based Control Utilities

### 8.1 Dynamic Models

```cpp
class Gnc_model_dynamic : public Model_dynamic {
public:
    Gnc_model_dynamic(Base::Allocator& alloc,
                     Base::Mblock<Uint16> mem_volatile,
                     const State_space_model_params& table0);
    
    bool reset_state();
    bool reset_state(const bool is_output_initialized);
    bool get_is_state_reset_allowed() const;
    bool get_is_output_initialized() const;
    void set_is_output_initialized(const bool is_output_initialized0);
    
    struct State {
        State(Maverick::Rvector& x_state0,
              Maverick::Rvector& u_state0,
              Maverick::Rvector& y_state0,
              Real& interpolation_parameter0,
              bool& is_state_update_enabled0,
              Maverick::Rvector& is_state_update_enabled_along_axes0);
        
        Maverick::Rvector& x;  // State vector
        Maverick::Rvector& u;  // Input vector
        Maverick::Rvector& y;  // Output vector
        Real& interpolation_parameter;
        bool& is_state_update_enabled;
        Maverick::Rvector& is_state_update_enabled_along_axes;
        
        void copy(const State& other);
    };
    
    State& get_state();
    const State& get_state() const;
    
private:
    State state;
};
```

### 8.2 Gain Models

```cpp
class Gnc_model_gain : public Model {
public:
    Gnc_model_gain(Base::Allocator& alloc,
                  Base::Mblock<Uint16> mem_volatile,
                  const State_space_model_params& gain_model_params0);
    
    virtual bool step(const Maverick::Rvector& u,
                     const Real interpolation_point,
                     Maverick::Rvector& y);
    
    virtual bool get_is_state_update_enabled() const;
    virtual void set_is_state_update_enabled(const bool is_state_update_enabled);
    virtual void zero_x_state();
    virtual bool get_is_output_state_reset_enabled() const;
    virtual bool perform_state_reset_to_specified_output(const Maverick::Rvector& y);
    
protected:
    const State_space_model_params& gain_model_params;
    Maverick::Rvector interp_data;
    Maverick::Rmatrix d;
};
```

### 8.3 Model Sets

```cpp
class Gnc_model_set {
public:
    struct Telemetry {
        Telemetry();
        
        Uint16 active_model_id;  // The active GSSC model within a model set
        Base::Tnarrayresz<Real16_amz, 6U> x;  // State of state space system
        
        void cget(Base::Lossy& str) const;
        void reset(const Uint16 x_size);
    };
    
    Gnc_model_set(const Uint16 default_model0, Model_set_state& state0);
    
    void set_is_state_update_enabled(const bool is_state_update_enabled);
    bool set_active_model_id(const Uint16 active_model_id_new);
    
protected:
    Uint16 get_active_model_id() const;
    Model& get_active_model();
    
    Base::Mixarray<Model> model_set;
    Maverick::Rvector& y_model_set_prior;
    
private:
    const Uint16 default_model;
    Uint16& active_model_id;
};
```

## 9. Vector Saturation Utilities

### 9.1 GNC Vector Saturation

```cpp
class Gnc_vector_saturation {
public:
    struct Output {
        Maverick::Rvector3 vec_out_io;
        bool activated_dir_saturation;
        bool activated_min_mag_saturation;
        bool activated_max_mag_saturation;
        bool activated_saturation;
        bool status;
        
        void set(const Maverick::Irvector3& vec_out_io0,
                const bool activated_dir_saturation0,
                const bool activated_min_mag_saturation0,
                const bool activated_max_mag_saturation0,
                const bool activated_saturation0,
                const bool status0);
    };
    
    struct State_ {
        State_();
        Maverick::Rvector3 previous_output;
    };
    
    bool reset_state();
    
    explicit Gnc_vector_saturation(const Saturation_parameters& parameters_0);
    
    void saturate(const Maverick::Irvector3& vec_in_io,
                 const Maverick::Irquat& q_dirsat_from_io,
                 const Maverick::Irquat& q_magsat_from_io,
                 const Real interpolation_point,
                 Output& out);
    
    void saturate(const Maverick::Irvector3& vec_in_io,
                 const Maverick::Irquat& q_sat_from_io,
                 const Real interpolation_point,
                 Output& out);
    
    bool IsValid() const;
    
    State_& get_state();
    
protected:
    // Internal enums and methods for saturation
    // ...
    
    const Saturation_parameters& parameters_;
    State_ state_;
    const bool is_valid_;
    
    // Internal saturation methods
    void apply_direction_saturation(const Local_dir_sat_type_enum::Type sat_type,
                                   const Norm_type::Type norm_type,
                                   const Maverick::Irvector3& vec_in_io,
                                   const Maverick::Irquat& q_dirsat_from_io,
                                   const Real interpolation_point,
                                   Vec_sat_output& out) const;
    
    void apply_magnitude_saturation(const Local_mag_sat_min_max_enum::Type sat_min_max,
                                   const Local_mag_sat_type_enum::Type sat_type,
                                   const Norm_type::Type norm_type,
                                   const Maverick::Irvector3& vec_in_io,
                                   const Maverick::Irquat& q_magsat_from_io,
                                   const Real interpolation_point,
                                   Vec_sat_output& output_magsat) const;
    
private:
    bool IsSpecificationValid() const;
};
```

### 9.2 GNC Vector Saturation Set

```cpp
class Gnc_vector_saturation_set {
public:
    Gnc_vector_saturation_set(const Saturation_parameters& def_saturation_parameters,
                             const Base::Mblock<Saturation_parameters>& saturation_parameters);
    
    void saturate(const Uint16 model_id,
                 const Maverick::Irvector3& vec_in_io,
                 const Maverick::Irquat& q_dirsat_from_io,
                 const Maverick::Irquat& q_magsat_from_io,
                 const Real interpolation_point,
                 Gnc_vector_saturation::Output& out);
    
    void saturate(const Uint16 model_id,
                 const Maverick::Irvector3& vec_in_io,
                 const Maverick::Irquat& q_sat_from_io,
                 const Real interpolation_point,
                 Gnc_vector_saturation::Output& out);
    
private:
    Gnc_vector_saturation default_vector_saturation_element_;
    Base::Array<Gnc_vector_saturation> vector_saturation_map_;
};
```

## 10. Numerical Precision Utilities

### 10.1 Half-Precision Float Conversion

```cpp
struct Real16_amz {
    Real value;
    
    Uint16 convert_to_half_precision() const;
    static Uint16 convert_to_half_precision(const Real& single_precision_value);
    static Real convert_to_single_precision(Uint16 half_precision_value);
    
    void cget(Base::Lossy& str) const;
    void cset(Base::Lossy& str);
};
```

This utility provides conversion between single-precision (32-bit) and half-precision (16-bit) floating-point numbers, which can be useful for storage and communication efficiency.

## 11. Interpolation Utilities

```cpp
class Dyn_pa_interpolator_cat_2 {
public:
    class Pa_interpolator_cat_2 {
    public:
        struct Build_params {
            const Base::Mblock<Real> cat2_num_jacobians;
            const Base::Mblock<Blocks::Dynrvector> cat2_ax_az_indices;
            Base::Mblock<Real> data;
            
            Build_params(Base::Mblock<Real> cat2_num_jacobians0,
                        Base::Mblock<Blocks::Dynrvector> cat2_ax_az_indices0,
                        Base::Mblock<Real> data0);
        };
        
        Pa_interpolator_cat_2(Pa_interpolator_cat_2::Build_params& bp);
        
        void interpolate(const Vblocks::Multi_interpolator& interp_cat_1,
                        Base::Array<Real>& out_interp0,
                        Base::Array<Real>& out_fm0) const;
        
    private:
        static const Uint16 n_working_points = 8U;
        const Base::Mblock<Real> cat2_num_jacobians;
        const Base::Mblock<Blocks::Dynrvector> cat2_ax_az_indices;
        Base::Mblock<Real> data;
        
        Uint16 cat_1_to_flat_cat_2(const Base::Tnarray<Uint16, Ku16::u3>& indices) const;
    };
    
    Dyn_pa_interpolator_cat_2();
    const Pa_interpolator_cat_2& get() const;
    void cset(Base::Lossy_error& str, Vblocks::Multi_interpolator_tun& mit, Base::Allocator& alloc);
    
private:
    Pa_interpolator_cat_2* interpolator;
};
```

This class provides specialized interpolation for the drone's control system, particularly for the power allocation scheduler.

## 12. Utility Classes

### 12.1 Max Value Tracker

```cpp
class Max_value {
public:
    Max_value();
    
    // Compares absolute value of value and candidate
    void update_abs(const Real candidate);
    Real get();
    void reset();
    
private:
    Real value;
};
```

This utility tracks the maximum absolute value of a signal over time.

### 12.2 Latch on First True

```cpp
struct Latch_on_first_true {
    Latch_on_first_true();
    bool prev_value;
    
    bool step(const bool in);
    void reset();
};
```

This utility implements a latch that stays true once it has been set to true.

### 12.3 Shallow Copy Array

```cpp
template <typename T>
class Shallow_copy_array {
public:
    explicit Shallow_copy_array(Base::Mblock<T> mem);
    
    T& operator[](Uint32 i);
    const T& operator[](Uint32 i) const;
    
    T* first();
    const T* first() const;
    
    T* last();
    const T* last() const;
    
    Uint32 size() const;
    Uint32 size_max() const;
    
    void clear();
    void zeros();
    bool resize(Uint32 sz0);
    bool append(const T& elem);
    void deep_copy(const Shallow_copy_array& other);
    
private:
    T* v;           // Pointer to first element in array
    Uint32 sz;      // Number of used elements in the array
    Uint32 sz_max;  // Max capacity of the array
};
```

This utility provides an array wrapper that performs shallow copies by default (copying only the pointer, not the data), with an option to perform deep copies when needed.

## 13. Checksum and Validation Utilities

```cpp
struct Crc32_checksum {
    struct Checksum_validation_result {
        Checksum_validation_result();
        bool is_valid;
    };
    
    template <typename T>
    static Checksum_validation_result perform_crc32_checksum_validation(const T& elem);
};

struct Checksum_info {
    enum Checksum_type {
        type_none = 0U,
        type_crc32 = 1U
    };
    
    Checksum_info();
    explicit Checksum_info(const Base::U8pkmblock_k& mb);
    
    void cset(Base::Lossy& is);
    void cget(Base::Lossy& os) const;
    void cget(Base::U8ostream& os) const;
    
    Uint32 value;
    Checksum_type checksum_type;
};
```

These utilities provide CRC32 checksum calculation and validation for data integrity.

## 14. Velocity Data Structures

```cpp
struct Velocity_2d {
    Velocity_2d();
    
    Real velocity_east_m_per_s;
    Real velocity_north_m_per_s;
    
    void zeros();
    static Velocity_2d velocity_2d_from_velocity_ned(const Base::Rv2& v_ned);
    static Velocity_2d velocity_2d_from_velocity_ned(const Maverick::Irvector2& v_ned);
    bool decode(Protobuf_decoder& decoder);
};

struct Velocity_3d {
    Real velocity_east_m_per_s;
    Real velocity_north_m_per_s;
    Real velocity_up_m_per_s;
    
    void zeros();
    static Velocity_3d velocity_3d_from_velocity_ned(const Base::Rv3& v_ned);
    static Velocity_3d velocity_3d_from_velocity_ned(const Maverick::Irvector3& v_ned);
    void cset(Base::Lossy& str);
    
    const Real& north_m_per_s() const;
    const Real& east_m_per_s() const;
    const Real& up_m_per_s() const;
    
    void set_north_m_per_s(const Real v0);
    void set_east_m_per_s(const Real v0);
    void set_up_m_per_s(const Real v0);
    
    bool decode(Protobuf_decoder& decoder);
};
```

These structures represent 2D and 3D velocity vectors in the East-North-Up (ENU) coordinate system, with conversion methods from North-East-Down (NED) coordinates.

## Summary

The mathematical utilities in the drone system provide a comprehensive set of tools for:

1. **Matrix and Vector Operations**: Specialized matrix and vector classes for efficient numerical operations
2. **Quaternion Operations**: Functions for working with quaternions for orientation representation
3. **Least Squares Solvers**: Multiple implementations for different applications including position and velocity estimation
4. **Constrained Quadratic Programming**: A solver for optimization problems with constraints
5. **Covariance and State Estimation**: Tools for Kalman filtering and state estimation
6. **Signal Processing**: Filters and blenders for smooth signal processing
7. **Geometric Utilities**: Functions for geometric calculations
8. **Model-Based Control**: Classes for dynamic models and control
9. **Vector Saturation**: Utilities for limiting vector magnitudes and directions
10. **Numerical Precision**: Tools for working with different floating-point precisions
11. **Interpolation**: Specialized interpolation for control systems
12. **Utility Classes**: Various helper classes for common operations
13. **Checksum and Validation**: Tools for data integrity
14. **Velocity Data Structures**: Representations of velocity in different coordinate systems

These utilities form the mathematical foundation of the drone's navigation, control, and state estimation systems, enabling precise and reliable operation.