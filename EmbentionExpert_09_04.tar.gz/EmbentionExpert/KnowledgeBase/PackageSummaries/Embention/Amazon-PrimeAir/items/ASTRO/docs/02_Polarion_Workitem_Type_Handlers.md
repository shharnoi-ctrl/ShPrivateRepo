# Generated from:

- ASTRO-PRQChecklists/script/polarion_workitem_tc.py (643 tokens)
- ASTRO-PRQChecklists/script/polarion_workitem_td.py (4006 tokens)
- ASTRO-PRQChecklists/script/polarion_workitem_ts.py (352 tokens)
- ASTRO-PRQChecklists/script/polarion_workitem_tr.py (1590 tokens)
- ASTRO-VS/script/polarion_workitem_tc.py (643 tokens)
- ASTRO-VS/script/polarion_workitem_td.py (4006 tokens)
- ASTRO-VS/script/polarion_workitem_ts.py (352 tokens)
- ASTRO-VS/script/polarion_workitem_tr.py (1590 tokens)
- SDD-VS/script/polarion_workitem_tc.py (643 tokens)
- SDD-VS/script/polarion_workitem_td.py (4006 tokens)
- SDD-VS/script/polarion_workitem_ts.py (352 tokens)
- SDD-VS/script/polarion_workitem_tr.py (1590 tokens)

## With context from:

- Amazon-PrimeAir/items/ASTRO/docs/03_Polarion_Workitem_Core.md (3002 tokens)

---

# Specialized Polarion Work Item Handlers Analysis

This document provides a comprehensive analysis of the specialized Polarion work item handlers that process specific types of work items: test cases (tc), traceability documents (td), test steps (ts), and test results (tr). The analysis focuses on the unique aspects of each handler while identifying common patterns and shared functionality.

## 1. Common Architecture and Patterns

All four specialized handlers share a common architectural foundation:

1. **Import Structure**:
   - All handlers import `sys`, `polarionWebService` from `Tools`
   - All use the `argparse` module for command-line argument parsing
   - All require a version parameter as a mandatory command-line argument

2. **Basic Workflow Pattern**:
   - Initialize Polarion session using `polarionWebService.init_session()`
   - Construct a query to retrieve specific work items
   - Process the retrieved work items
   - Generate output in a specific format (LaTeX, text files)

3. **Query Construction Pattern**:
   - All queries filter by `linkedWorkItems:(VER-4014)`
   - All queries filter by specific work item types
   - Most include additional filters (e.g., status:verified)

4. **Command-Line Interface**:
   - All handlers implement an `argparse`-based CLI
   - All require a version parameter
   - Some accept additional optional parameters

## 2. Test Case Handler (`polarion_workitem_tc.py`)

### Purpose and Functionality
Extracts test case descriptions from Polarion and formats them as LaTeX documents.

### Unique Aspects
- **Parsing Logic**: 
  ```python
  def build_item(id, title, data):
      item = "\\begin{itemize}\n"
      item += "    \\item [\\textbf{" + id + "}] " + parseTexLib.parse_special_chars(title) + "\n"
      item += "    \\begin{itemize}\n"
      # Iterates through key-value pairs in data dictionary
      for key,value in data.items():
          item += "        \\item [\\textit{ " + key + " }] " + acronyms.parse_acronyms(parseTexLib.parse_html_chars(parseTexLib.parse_chars(value)))+ "\n"
      item += "    \\end{itemize}\n"
      item += "\\end{itemize}\n\n"
      return item
  ```

- **Description Parsing**:
  - Parses test case descriptions using a specific format where sections are marked with `##`
  - Extracts structured data from HTML-formatted descriptions
  - Creates a dictionary of section headers and content

- **Output Format**:
  - Generates LaTeX itemized lists with nested structure
  - Uses special character parsing for LaTeX compatibility
  - Processes acronyms using an acronym dictionary

- **Test Type Categories**:
  - Processes five distinct test types: "unit", "system", "integration", "robustness", "analysis"
  - Creates separate output files for each test type

### Fields Retrieved
```python
fields = ['id', 'title', 'description', 'customFields.testid', 'customFields.testType', 'customFields.testSteps']
```

### Query Pattern
```python
'linkedWorkItems:(VER-4014) AND (type:testcase) AND (status:verified) AND (testType.KEY:' + key + ')'
```

## 3. Traceability Document Handler (`polarion_workitem_td.py`)

### Purpose and Functionality
Generates traceability matrices between different types of work items (requirements, test cases, etc.) in LaTeX format.

### Unique Aspects
- **Complex Data Model**:
  - Defines an `Enum` class for relationship types
  - Implements a `work_item` class with relationship handling
  - Implements a `work_item_list` class for collections

- **Relationship Types**:
  - Defines 18 different relationship types (e.g., HLR_LLR, LLR_TC)
  - Maps relationship types to role names ("refined by", "verified_by", "traces", etc.)

- **Bidirectional Relationship Handling**:
  - Creates both direct and inverse relationship lists
  - Handles special cases where Polarion's relationship direction is inverted

- **Comprehensive Traceability**:
  - Generates multiple traceability matrices:
    - System requirements to product requirements
    - System requirements to high-level requirements
    - Product requirements to high-level requirements
    - High-level requirements to low-level requirements
    - High-level requirements to design models
    - Design models to low-level requirements
    - High-level requirements to test cases
    - Low-level requirements to test cases
    - Test cases to test results
    - Low-level requirements to algorithms

- **Error Checking**:
  - Validates that requirements have necessary relationships
  - Can exit with error if relationships are missing

### Fields Retrieved
Varies by work item type, but typically includes:
```python
fields = ['id', 'title', 'linkedWorkItems', 'customFields.External_ID']  # For system requirements
fields = ['id', 'title', 'linkedWorkItems']  # For test cases
fields = ['id', 'title', 'linkedWorkItems', 'customFields.code']  # For low-level requirements
```

### Query Pattern
```python
criteria = "linkedWorkItems:(VER-4014) AND type:sreq AND project.id:"+args.sys_project
criteria = "linkedWorkItems:(VER-4014) AND type:testcase AND HAS_VALUE:linkedWorkItems" + verified_filter
```

## 4. Test Steps Handler (`polarion_workitem_ts.py`)

### Purpose and Functionality
Extracts test steps from test cases and outputs them to text files.

### Unique Aspects
- **Simplest Implementation**:
  - Shortest and most straightforward of all handlers
  - Minimal processing of retrieved data

- **Output Format**:
  - Outputs raw text files rather than LaTeX
  - Preserves HTML content from test steps

- **Post-Processing**:
  - Calls an external script (`htmltocsv.py`) to convert HTML to CSV format
  - Captures and propagates error codes from the external script

- **Test Type Categories**:
  - Like the test case handler, processes five test types

### Fields Retrieved
```python
fields = ['id', 'title', 'customFields.testStep']
```

### Query Pattern
```python
'linkedWorkItems:(VER-4014) AND (type:testcase) AND (status:verified) AND (testType.KEY:' + key + ')'
```

## 5. Test Results Handler (`polarion_workitem_tr.py`)

### Purpose and Functionality
Extracts test results and formats them as LaTeX documents, including handling of attachments.

### Unique Aspects
- **Environment Variables**:
  - Uses environment variables for Polarion authentication:
    ```python
    HOSTNAME = os.environ['POLARION_HOST']
    USERNAME = os.environ['POLARION_TOKEN'].split(":")[0]
    PASSWORD = os.environ['POLARION_TOKEN'].split(":")[1]
    ```

- **Test Case Filtering**:
  - Retrieves all test cases first
  - Filters test results to match only those with corresponding test cases

- **Complex Output Processing**:
  - Handles special LaTeX formatting markers in content
  - Processes HTML content differently based on markers
  - Removes empty lines from content

- **Attachment Handling**:
  - Downloads PDF attachments from test results
  - Includes them in the LaTeX output using `\includepdf`

- **Status Reporting**:
  - Reports non-passing test results to standard output
  - Can exit with error if any test results are not "pass"

### Fields Retrieved
```python
fields = ['id', 'title', 'attachments', 'customFields.state', 'customFields.log_test']
```

### Query Pattern
```python
'linkedWorkItems:(VER-4014) AND (type:testresults)'
```

## 6. Comparative Analysis

### Data Flow Comparison

| Handler | Input | Processing | Output |
|---------|-------|------------|--------|
| TC | Test cases with descriptions | Parses descriptions with `##` markers | LaTeX itemized lists |
| TD | Multiple work item types with relationships | Builds relationship matrices | LaTeX tables |
| TS | Test cases with test steps | Minimal processing | Text files + CSV conversion |
| TR | Test results with logs and attachments | Complex HTML/LaTeX processing | LaTeX with embedded PDFs |

### Error Handling Comparison

| Handler | Error Checking | Error Reporting | Error Propagation |
|---------|---------------|-----------------|-------------------|
| TC | Minimal | Prints count of items | None |
| TD | Validates relationships | Reports missing relationships | Exits with error message |
| TS | Captures external script errors | None | Propagates error code |
| TR | Validates test result status | Reports non-passing tests | Optional exit on error |

### Query Construction Comparison

| Handler | Base Filter | Type Filter | Additional Filters |
|---------|-------------|-------------|-------------------|
| TC | linkedWorkItems:(VER-4014) | type:testcase | status:verified, testType.KEY |
| TD | linkedWorkItems:(VER-4014) | Multiple types | status:verified (optional) |
| TS | linkedWorkItems:(VER-4014) | type:testcase | status:verified, testType.KEY |
| TR | linkedWorkItems:(VER-4014) | type:testresults | version_result |

### Output Format Comparison

| Handler | Primary Output | Format | Special Processing |
|---------|---------------|--------|-------------------|
| TC | Multiple .tex files | LaTeX itemized lists | Acronym expansion, HTML parsing |
| TD | Multiple .tex files | LaTeX tables | Relationship mapping |
| TS | Multiple .txt files | Plain text | External CSV conversion |
| TR | Single tr.tex file | LaTeX with attachments | HTML parsing, PDF inclusion |

## 7. Integration Points

### How Handlers Work Together

1. **TD → TC/TR Relationship**:
   - TD handler creates traceability matrices linking requirements to test cases
   - TD handler also creates matrices linking test cases to test results
   - These matrices reference the same test cases processed by TC handler
   - These matrices reference the same test results processed by TR handler

2. **TC → TS Relationship**:
   - TC handler processes test case descriptions
   - TS handler processes test steps from the same test cases
   - Both use the same filtering by test type

3. **Common Work Item Backbone**:
   - All handlers operate on work items linked to VER-4014
   - This creates a unified documentation set across all handlers

4. **Documentation Workflow**:
   - TD handler creates the structural relationships
   - TC handler provides detailed test descriptions
   - TS handler provides step-by-step test procedures
   - TR handler provides test execution evidence
   - Together they form a complete test documentation package

## 8. Extension Mechanisms

The handlers demonstrate several patterns for extending the core Polarion work item system:

1. **Custom Work Item Classes**:
   - TD handler defines custom classes for work items and relationships
   - These extend the basic work item concept with specialized behavior

2. **Custom Formatting Logic**:
   - Each handler implements custom formatting for its specific output needs
   - This allows specialized presentation of different work item types

3. **Custom Query Construction**:
   - Each handler builds queries tailored to its specific needs
   - This allows focused retrieval of relevant work items

4. **Custom Field Selection**:
   - Each handler retrieves different fields based on its needs
   - This optimizes data transfer and processing

5. **Custom Processing Pipelines**:
   - Each handler implements a specific processing pipeline
   - This allows specialized handling of different work item types

## 9. Referenced Context Files

The following context files provided useful information for understanding the specialized Polarion work item handlers:

- `Amazon-PrimeAir/items/ASTRO/docs/03_Polarion_Workitem_Core.md` - Provided context about the core Polarion work item system that these specialized handlers extend.