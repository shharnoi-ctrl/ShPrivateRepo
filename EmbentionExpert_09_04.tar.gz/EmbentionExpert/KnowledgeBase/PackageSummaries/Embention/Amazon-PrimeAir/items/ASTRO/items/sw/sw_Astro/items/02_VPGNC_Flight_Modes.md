# Generated from:

- _sw_Veronte/code/vpgnc/code/include/Approach.h (1066 tokens)
- _sw_Veronte/code/vpgnc/code/source/Approach.cpp (2637 tokens)
- _sw_Veronte/code/vpgnc/code/include/Climb.h (616 tokens)
- _sw_Veronte/code/vpgnc/code/source/Climb.cpp (1729 tokens)
- _sw_Veronte/code/vpgnc/code/include/Detour.h (4781 tokens)
- _sw_Veronte/code/vpgnc/code/source/Detour.cpp (6635 tokens)
- _sw_Veronte/code/vpgnc/code/include/Taxi.h (906 tokens)
- _sw_Veronte/code/vpgnc/code/source/Taxi.cpp (2038 tokens)
- _sw_Veronte/code/vpgnc/code/include/Vtol.h (780 tokens)
- _sw_Veronte/code/vpgnc/code/source/Vtol.cpp (2266 tokens)
- _sw_Veronte/code/vpgnc/code/include/Start.h (251 tokens)
- _sw_Veronte/code/vpgnc/code/source/Start.cpp (435 tokens)
- _sw_Veronte/code/vpgnc/code/include/Hover_data.h (192 tokens)
- _sw_Veronte/code/vpgnc/code/source/Hover_data.cpp (152 tokens)
- _sw_Veronte/code/vpgnc/code/include/Loiter_data.h (191 tokens)
- _sw_Veronte/code/vpgnc/code/source/Loiter_data.cpp (406 tokens)
- _sw_Veronte/code/vpgnc/code/include/Loiter_stg_cfg.h (526 tokens)
- _sw_Veronte/code/vpgnc/code/source/ver/Loiter_stg_cfg.cpp (1865 tokens)
- _sw_Veronte/code/vpgnc/code/include/Stg_slave_location.h (535 tokens)
- _sw_Veronte/code/vpgnc/code/source/ver/Stg_slave_location.cpp (2551 tokens)
- _sw_Veronte/code/vpgnc/code/include/Modeconf.h (348 tokens)
- _sw_Veronte/code/vpgnc/code/source/Modeconf.cpp (142 tokens)
- _sw_Veronte/code/vpgnc/code/include/Accelimit.h (1374 tokens)
- _sw_Veronte/code/vpgnc/code/source/Accelimit.cpp (3944 tokens)
- _sw_Veronte/code/vpgnc/code/include/Speed_cfg.h (1296 tokens)
- _sw_Veronte/code/vpgnc/code/source/Speed_cfg.cpp (593 tokens)
- _sw_Veronte/code/vpgnc/code/include_FPA/Speed_cfg.h (1296 tokens)
- _sw_Veronte/code/vpgnc/code/include/Vlimits.h (402 tokens)
- _sw_Veronte/code/vpgnc/code/source/Vlimits.cpp (142 tokens)
- _sw_Veronte/code/vpgnc/code/include/Vlimits_fw.h (23 tokens)
- _sw_Veronte/code/veronte/code/source/ver/Rendezvous.cpp (tokens unknown)
- _sw_Veronte/code/veronte/code/source/ver/Initial.cpp (tokens unknown)

## With context from:

- PackageSummaries/Embention/Amazon-PrimeAir/items/ASTRO/items/sw/sw_Astro/items/06_VPGNC_Core.md (7671 tokens)
- PackageSummaries/Embention/Amazon-PrimeAir/items/ASTRO/items/sw/sw_Astro/items/03_VPGNC_Patch_Management.md (6443 tokens)

---

# Comprehensive Analysis of VPGNC Guidance Modules

This document provides a detailed analysis of the specialized guidance modules in the VPGNC framework, focusing on different flight phases and maneuver types.

## 1. Approach Class: Landing Approach Guidance

The `Approach` class implements guidance for landing approach maneuvers, creating a structured path for aircraft to follow when approaching a landing site.

### 1.1 Core Components and Structure

```cpp
class Approach : public Patchset {
public:
    struct Cfg : public Patchsetcfg {
        Leg::Cfg legcfg;                               // Leg configuration
        Base::Fref f4br;                               // Touch point reference
        struct Patch_conf {                            // Per-patch configuration
            Oprvar fpa;                                // Flight Path Angle
            Oprvar speed;                              // Speed
        };
        Base::Tnarray<Patch_conf, Ku16::u4> patchcfg;  // FPAs and speeds for each patch
        
        // Configuration methods
        Cfg();
        void step();
        void cset(Base::Lossy_error& str);
        void cget(Base::Lossy& str) const;
        void operation_check(Base::Error& err) const;
    };
    
    // Constructor and methods
    Approach(const Vpunav& uav0, Base::Patchid& last_achieved0, 
             Airframe_action_wp_publish& aac_publish0);
    virtual void calculate(const Gtrackcfg& gcfg);
    Base::Itunable& get_cmd_lndget();
    
private:
    const Vpunav& uav;                // UAV navigation data
    Tpatchset& calc;                  // Patchset calculation
    Leg leg;                          // Leg geometry handler
    Base::Twraptun<Base::Tuntraits::Cget_only<Tunpatchset>> tun;  // Tunable
    Geo::Frefcache f4br;              // Touch point cache
    Bsp::Hrvar hur0;                  // Handler for rvar
};
```

### 1.2 Approach Route Geometry

The Approach class creates a structured landing approach route with the following components:

```
                    r1a/r1c (Loiter)
                        *
                       / \
                      /   \
                     /     \
                    *       *
                   r2a      
                    |
                    |
                    *
                   r3a/r3c (Turn)
                    \
                     \
                      \
                       *
                      r4a
                       |
                       |
                       *
                      r4b
                       |
                       |
                       *
                      r5b (Touch point)
```

The approach route consists of:
1. A loiter pattern (r1a to r2a) for altitude adjustment
2. A straight segment (r2a to r3a) for alignment
3. A turn segment (r3a to r4a) for final approach alignment
4. A straight final approach segment (r4a to r4b)
5. A touchdown point (r5b)

### 1.3 Configuration Parameters

The `Approach::Cfg` structure contains:

1. **Leg Configuration**: Base parameters for approach geometry
2. **Touch Point**: Reference to the landing touchdown point
3. **Per-Patch Configuration**: For each patch segment:
   - Flight Path Angle (FPA): Vertical angle for descent
   - Speed: Target speed for the segment

The configuration is validated to ensure:
- All FPAs are within valid ranges (-π/2 < FPA ≤ 0.0)
- All speeds are positive (> 0)

### 1.4 Route Calculation Algorithm

The `calculate` method implements the approach route computation:

```cpp
void Approach::calculate(const Gtrackcfg& gcfg) {
    // Check if configuration is valid
    const Approach::Cfg* c = gcfg.pcfg.get<Approach::Cfg>();
    if (c) {
        // Increment change counter for external tracking
        uchanged.set(uchanged.get() + 1U);
        
        // Check if runway/spot parameters are correct
        if (Geo::Rwymgr::get_instance().calculate(c->legcfg.osid, uav.get_pos(), wind_uh.kvec)) {
            // Publish azimuth of UAV's velocity
            hur0.set(Rmath::atan2r(uav.get_vn()[1], uav.get_vn()[0]));
            
            // Compute patch from 4b to 5b (final approach)
            Maverick::Rvector3 urxy;
            const Real ang = c->legcfg.td.kget();
            urxy[Ku16::u0] = Rmath::cosr(ang);
            urxy[Ku16::u1] = Rmath::sinr(ang);
            urxy[Ku16::u2] = Const::ZERO;
            leg.compute_xscend(c->legcfg, urxy);
            
            // Set up touch point and related positions
            f4br.set(c->f4br);
            f4br.refresh();
            const Geo::Apos& f4br_pos = f4br.get_pos();
            f4br_pos.relthis(uav.get_pos(), leg.r0a);
            leg.refresh_loipos(c->legcfg);
            
            // Compute arc parameters for turn segment
            Maverick::Rvector3 rk_3;
            leg.compute_head(c->legcfg, urxy, rk_3);
            
            // Compute loiter parameters
            Maverick::Rvector3 rk_1;
            leg.compute_loix(c->legcfg, false, rk_1);
            
            // Compute heights and number of loops
            Uint16 nloops = 0;
            const Real tfpa0 = Rmath::tanr(c->patchcfg[0].fpa.get());
            const Real tfpa1 = Rmath::tanr(c->patchcfg[1].fpa.get());
            const Real tfpa2_3 = Rmath::tanr(c->patchcfg[Ku16::u2].fpa.get());
            const Real tfpa4 = Rmath::tanr(c->patchcfg[Ku16::u3].fpa.get());
            leg.compute_heights_landing(c->legcfg, tfpa0, tfpa1, tfpa2_3, tfpa4, nloops);
            
            // Set up patches with appropriate speeds
            Speed_cfg speed_cpy = gcfg.spdcmd.get_speed_cfg();
            calc.clear_masks();
            
            // Initial approach segment
            speed_cpy.data.speed.vlink = c->patchcfg[Ku16::u0].speed.get();
            calc.set_line(pch_0a, f4br_pos.frelthis(leg.r0a), pch_1a, speed_cpy);
            
            // Loiter segment for altitude adjustment
            speed_cpy.data.speed.vlink = c->patchcfg[Ku16::u1].speed.get();
            calc.set_arc(pch_1a, f4br_pos.frelthis(leg.r1a), rk_1[0], rk_1[1], nloops, pch_2a, speed_cpy);
            
            // Straight segment before final turn
            speed_cpy.data.speed.vlink = c->patchcfg[Ku16::u2].speed.get();
            calc.set_line(pch_2a, f4br_pos.frelthis(leg.r2a), pch_3a, speed_cpy);
            
            // Turn to final approach
            calc.set_arc(pch_3a, f4br_pos.frelthis(leg.r3a), rk_3[0], rk_3[1], 0, pch_4a, speed_cpy);
            
            // Final approach segments
            speed_cpy.data.speed.vlink = c->patchcfg[Ku16::u3].speed.get();
            calc.set_line(pch_4a, f4br_pos.frelthis(leg.r4a), pch_4b, speed_cpy);
            calc.set_line(pch_4b, Base::Feature::build_abs(f4br_pos.get_llh()), pch_5b, speed_cpy);
            calc.set_point(pch_5b, f4br_pos.frelthis(leg.r5b), Tpatchset::no_next, speed_cpy);
            
            // Additional points for plotting/compatibility
            calc.set_point(pch_1c, f4br_pos.frelthis(leg.r1c), Tpatchset::no_next, speed_cpy);
            calc.set_point(pch_3c, f4br_pos.frelthis(leg.r3c), Tpatchset::no_next, speed_cpy);
            
            // Set first patch and current patch
            calc.set_first(pch_0a);
            set_current_patch(calc.get_first());
        }
    }
}
```

## 2. Climb Class: Takeoff and Initial Climb Guidance

The `Climb` class implements guidance for takeoff and initial climb maneuvers, creating a structured path for aircraft to follow when departing.

### 2.1 Core Components and Structure

```cpp
class Climb : public Patchset {
public:
    struct Cfg : public Patchsetcfg {
        Leg::Cfg legcfg;     // Leg configuration
        Oprvar fpar;         // Flight Path Angle for climb
        
        // Configuration methods
        Cfg();
        void step();
        void cset(Base::Lossy_error& str);
        void cget(Base::Lossy& str) const;
        void operation_check(Base::Error& err) const;
    };
    
    // Constructor and methods
    Climb(const Vpunav& uav0, Base::Patchid& last_achieved0, 
          Airframe_action_wp_publish& aac_publish0);
    virtual void calculate(const Gtrackcfg& gcfg);
    Base::Itunable& get_cmd_cmbget();
    
private:
    const Vpunav& uav;                // UAV navigation data
    Leg leg;                          // Leg geometry handler
    Tpatchset& calc;                  // Patchset calculation
    Base::Twraptun<Base::Tuntraits::Cget_only<Tunpatchset>> tun;  // Tunable
    Bsp::Hrvar hur0;                  // Handler for rvar
    Maverick::Rvector3 urm;           // Opposite to ur
};
```

### 2.2 Climb Route Geometry

The Climb class creates a structured takeoff and climb route with the following components:

```
                    r1a/r1c (Loiter)
                        *
                       / \
                      /   \
                     /     \
                    *       *
                   r2a      
                    |
                    |
                    *
                   r3a/r3c (Turn)
                    /
                   /
                  /
                 *
                r4a
                 |
                 |
                 *
                r4b (Current position)
                 |
                 |
                 *
                r5b (End point)
```

The climb route is essentially the reverse of the approach route:
1. Starting at the current position (r4b)
2. A straight initial climb segment (r4b to r4a)
3. A turn segment (r4a to r3a) for alignment
4. A straight segment (r3a to r2a) for continued climb
5. A loiter pattern (r2a to r1a) for altitude adjustment

### 2.3 Configuration Parameters

The `Climb::Cfg` structure contains:
1. **Leg Configuration**: Base parameters for climb geometry
2. **Flight Path Angle (FPA)**: Vertical angle for climb

The configuration is validated to ensure:
- FPA is within valid range (0 < FPA < π/2)

### 2.4 Route Calculation Algorithm

The `calculate` method implements the climb route computation:

```cpp
void Climb::calculate(const Gtrackcfg& gcfg) {
    // Check if configuration is valid
    const Climb::Cfg* c = gcfg.pcfg.get<Climb::Cfg>();
    if (c) {
        // Increment change counter for external tracking
        uchanged.set(uchanged.get() + 1U);
        
        // Check if runway/spot parameters are correct
        if (Geo::Rwymgr::get_instance().calculate(c->legcfg.osid, uav.get_pos(), wind_uh.kvec)) {
            // Publish azimuth of UAV's velocity
            hur0.set(Rmath::atan2r(uav.get_vn()[1], uav.get_vn()[0]));
            
            // Compute direction vector (opposite of touchdown direction)
            const Real ang = c->legcfg.td.kget();
            urm[Ku16::u0] = Rmath::cosr(ang);
            urm[Ku16::u1] = Rmath::sinr(ang);
            urm[Ku16::u2] = Const::ZERO;
            urm.signinv();
            leg.compute_xscend(c->legcfg, urm);
            
            // Set up positions relative to current position
            const Geo::Apos& p4b = uav.get_pos();
            leg.refresh_loipos(c->legcfg);
            p4b.relthis(leg.get_loipos(), leg.r0a);
            
            // Compute arc parameters for turn segment
            Maverick::Rvector3 rk_3;
            leg.compute_head(c->legcfg, urm, rk_3);
            
            // Compute loiter parameters
            Maverick::Rvector3 rk_1;
            leg.compute_loix(c->legcfg, true, rk_1);
            
            // Compute heights and number of loops
            Uint16 nloops = 0;
            const Real tfpa = -Rmath::tanr(c->fpar.get());
            leg.compute_heights_climbing(c->legcfg, tfpa, nloops);
            
            const Real R1v = c->legcfg.R1.get();
            
            // Set up patches
            const Speed_cfg speed = gcfg.spdcmd.get_speed_cfg();
            calc.clear_masks();
            
            // Final climb segment
            calc.set_line(pch_5b, p4b.frelthis(leg.r5b), pch_4b, speed);
            
            // Initial climb segment
            calc.set_line(pch_4b, Base::Feature::build_abs(p4b.get_llh()), pch_4a, speed);
            
            // Turn segment
            calc.set_arc(pch_4a, p4b.frelthis(leg.r4a), rk_3[0], rk_3[1], 0, pch_3a, speed);
            
            // Straight segment after turn
            calc.set_line(pch_3a, p4b.frelthis(leg.r3a), pch_2a, speed);
            
            // Loiter segment for altitude adjustment
            calc.set_arc(pch_2a, p4b.frelthis(leg.r2a), rk_1[0], rk_1[1], nloops, pch_1a, speed);
            calc.set_point(pch_1a, p4b.frelthis(leg.r1a), pch_1c, speed);
            calc.set_ellipse(pch_1c, p4b.frelthis(leg.r1c), Base::Polarparams::autoclkws, 
                            Const::ZERO, R1v, R1v, speed);
            
            // Additional points for plotting/compatibility
            calc.set_point(pch_0a, p4b.frelthis(leg.r0a), Tpatchset::no_next, speed);
            calc.set_point(pch_3c, p4b.frelthis(leg.r3c), Tpatchset::no_next, speed);
            
            // Set first patch and current patch
            calc.set_first(pch_4b);
            set_current_patch(calc.get_first());
        }
    }
}
```

## 3. Detour Class: Temporary Route Deviation

The `Detour` class implements guidance for temporary deviations from the main route, supporting various maneuvers like loitering, hovering, and following.

### 3.1 Core Components and Structure

```cpp
class Detour : public Patchset {
public:
    // Constructor and methods
    Detour(const Dynamics::Rigidbody& uav0, const Guidance& uavc0,
           Base::Patchid& last_achieved0, Base::Checklist& opchlist,
           Airframe_action_wp_publish& aac_publish0);
    
    virtual void on_focus(const Geo::Apos& pos, const Maverick::Irvector3& v0);
    virtual void path_compute(const Patchsetcfg& pcfg, const Geo::Apos& pos,
                             Maverick::Irvector3& d, Maverick::Irvector3& t);
    
    // Command methods
    void set_arc(const Real fv, const Real lv);
    virtual void gcmd_cset(Base::Lossy_error& str);
    virtual void gcmd_cget(Base::Lossy& str) const;
    void set_no_patch(const bool hvr_permitted);
    void set_flyroute_start(Patchset& route, const bool flyto_closest);
    void reset();
    bool is_active() const;
    bool is_compute_pending() const;
    void set_arclim(const Real arclim);
    bool apply_h_arcade(Maverick::Irvector3& vn) const;
    
    // Speed command methods
    void set_speed_cmd(const Speedcmd& speed_cmd);
    const Speedcmd& get_speed_cmd() const;
    Base::Itunable& build_speedcmdtun();
    
    // Specialized maneuver methods
    void set_cane(const Loiter_data& data);
    void set_hover(const Hover_data& data);
    
    // Tunable access
    Base::Itunable& get_cmd_gtrkget();
    Base::Itunable& get_cmd_arcxsel();
    
private:
    // Command types
    enum Cmdtype {
        cmd_loiter      = 0,
        cmd_cane        = 1,
        cmd_hover       = 3,
        cmd_hovhere     = 5,
        cmd_followroute = 6,
        cmd_flyroute    = 7,
        cmd_sz          = 8,
        cmd_none        = 0xFFFF
    };
    
    // Command interface
    class Icmd {
    public:
        virtual void calculate(Detour& ps) = 0;
        virtual void step(Detour& ps);
        virtual bool cset(Base::Lossy_error& str);
        virtual void cget(Base::Lossy& str) const;
        virtual Patchset::Prjtype get_prj() const;
        virtual bool is_active() const;
        
    protected:
        explicit Icmd(const Patchset::Prjtype prjtype0);
        ~Icmd();
        Patchset::Prjtype prjtype;
    };
    
    // Command implementations (Loiter, Cane, Hover, etc.)
    class Cmdloi : public Icmd { /* ... */ };
    class Loiter : public Cmdloi { /* ... */ };
    class Cane : public Cmdloi { /* ... */ };
    class Cmdhov : public Icmd { /* ... */ };
    class Hovhere : public Cmdhov { /* ... */ };
    class Hover : public Cmdhov { /* ... */ };
    class Followroute : public Cmdhov { /* ... */ };
    class Flyroute : public Icmd { /* ... */ };
    
    // Member variables
    const Dynamics::Rigidbody& uav;
    const Guidance& uavc;
    Tpatchset& calc;
    Base::Twraptun<Base::Tuntraits::Cget_only<Tunpatchset>> tun;
    Base::U16tun arcx_sel;
    Cmdtype type;
    Loiter loi;
    Cane cane;
    Hover hover;
    Hovhere hovhere;
    Followroute followroute;
    Flyroute flyroute;
    Base::Tnarray<Icmd*, cmd_sz> commands;
    bool compute_pending;
    bool is_arc_h;
    Maverick::Rvector3 vn_arc;
    Bsp::Huvar uchanged;
    Cmdcache<Speedcmd> spdcmd;
    
    void refresh_uchanged();
};
```

### 3.2 Command Types and Maneuvers

The Detour class supports several types of maneuvers:

1. **Loiter**: Circular holding pattern
2. **Cane**: Maneuver to a loiter point with a smooth entry
3. **Hover**: Stationary hold at a specific position
4. **Hovhere**: Stationary hold at current position
5. **Followroute**: Follow a moving target
6. **Flyroute**: Transition to another route

Each command type is implemented as a derived class from the `Icmd` interface, providing specialized behavior for that maneuver type.

### 3.3 Loiter and Cane Maneuvers

The `Cmdloi` class implements common functionality for loiter-based maneuvers:

```cpp
void Detour::Cmdloi::compute_tangent(const Geo::Apos& x0,
                                    const Maverick::Irvector3& t0,
                                    Real rll,
                                    Detour& ps) const {
    // Determine turn direction based on roll angle if auto mode
    Base::Polarparams::Turn_direction t = (turn == Base::Polarparams::autoclkws) ?
                                         ((rll >= 0) ? Base::Polarparams::clkws : 
                                                      Base::Polarparams::anticlkws) : turn;
    
    // Calculate position vector to loiter center
    Rvector3 pc;
    if (t == Base::Polarparams::anticlkws) {
        pc[0] =  t0[1];
        pc[1] = -t0[0];
    } else {
        pc[0] = -t0[1];
        pc[1] =  t0[0];
    }
    pc[Rvector3::vz] = 0;
    
    // Scale to desired radius
    Real radio_value = radio.kget();
    pc.scale(radio_value / pc.norm2());
    
    // Set up loiter ellipse
    ps.calc.clear_masks();
    ps.calc.set_ellipse(pch_loi_center, x0.frelthis(pc), t, 0, radio_value, radio_value,
                       ps.spdcmd.get().get_speed_cfg());
    
    // Set as first and current patch
    ps.calc.set_first(pch_loi_center);
    ps.set_current_patch(ps.calc.get_first());
}
```

The `Cane` maneuver adds a smooth entry to a loiter point:

```cpp
void Detour::Cmdloi::compute_cane(const Geo::Apos& from,
                                 const Geo::Apos& to0,
                                 Detour& ps) const {
    // Determine turn direction
    Base::Polarparams::Turn_direction t = (turn == Base::Polarparams::autoclkws) ?
                                         Base::Polarparams::clkws : turn;
    
    // Handle projection type for height
    const Geo::Apos to(Base::Tllh::build(to0.get_llh().ll,
                                        (this->prjtype == Patchset::prj_2d) ? 
                                        from.get_llh().h : to0.get_llh().h));
    
    // Set up loiter at destination
    ps.calc.clear_masks();
    const Real radio_value = radio.kget();
    const Speed_cfg speed = ps.spdcmd.get().get_speed_cfg();
    ps.calc.set_ellipse(pch_loi_center, Base::Feature::build_abs(to.get_llh()), 
                       t, 0, radio_value, radio_value, speed);
    
    // Calculate vector from current position to loiter center
    Rvector3 r;
    from.relthis(to, r);
    
    // Calculate minimum distance for arc entry
    Real d = r.norm2xy();
    Real dmin = radio_value * Const::SQRT3;
    
    // If far enough away, create a cane entry path
    if (d > dmin) {
        // Calculate arc start point
        r.scale((d - dmin) / d);
        Rvector3 r_arc_start;
        r_arc_start.copy(r);
        Real az0 = r.azimuth();
        Real azc2 = az0;
        Real azk = az0;
        
        // Adjust angles based on turn direction
        if (t == Base::Polarparams::clkws) {
            azc2 -= Const::PI0833;
            azk += PI033;
        } else {
            azc2 += Const::PI0833;
            azk -= PI033;
        }
        
        // Calculate arc end point
        r.azeld_1(azc2, 0, radio_value);
        ps.calc.set_point(pch_arc_end, to.frelthis(r), pch_loi_center, speed);
        
        // Calculate arc control point
        r.azeld_1(azk, 0, radio_value * ONE_COS30);
        ps.calc.set_arc(pch_arc_start, from.frelthis(r_arc_start), r[0], r[1], 0, pch_arc_end, speed);
        
        // Set initial line segment
        ps.calc.set_line(pch_line_start, Base::Feature::build_abs(from.get_llh()), pch_arc_start, speed);
        
        // Set first patch to line start
        ps.calc.set_first(pch_line_start);
    } else {
        // If close enough, just set loiter as first patch
        ps.calc.set_first(pch_loi_center);
    }
    
    ps.set_current_patch(ps.calc.get_first());
}
```

### 3.4 Hover Maneuvers

The `Cmdhov` class implements common functionality for hover-based maneuvers:

```cpp
void Detour::Cmdhov::compute_hover(bool direct,
                                  const Geo::Apos& from,
                                  const Geo::Apos& to,
                                  Detour& ps) {
    compute_hover(direct,
                 Base::Feature::build_abs(from.get_llh()),
                 Base::Feature::build_abs(to.get_llh()),
                 ps);
}

void Detour::Cmdhov::compute_hover(bool direct,
                                  const Base::Feature& from,
                                  const Base::Feature& to0,
                                  Detour& ps) {
    // Handle 2D projection by keeping same height
    Base::Feature to = to0;
    if (to.is_abs() && from.is_abs() && (this->prjtype == Patchset::prj_2d)) {
        to.data.llh.height = from.data.llh.height;
    }
    
    // Set up hover point
    ps.calc.clear_masks();
    const Speed_cfg speed = ps.spdcmd.get().get_speed_cfg();
    ps.calc.set_point(pch_hover, to, Tpatchset::no_next, speed);
    
    // If direct, go straight to hover point
    if (direct) {
        ps.calc.set_first(pch_hover);
    } else {
        // Otherwise, create a line from current position to hover point
        ps.calc.set_line(pch_line_start, from, pch_hover, speed);
        ps.calc.set_first(pch_line_start);
    }
    
    ps.set_current_patch(ps.calc.get_first());
}
```

The `Hover` class adds distance-based activation:

```cpp
void Detour::Hover::step(Detour& ps) {
    static const Real min_dist = 0.5F;
    const Real d = data.distance.kget();
    if (d > min_dist) {
        Rvector3 r;
        data.target.refresh();
        ps.uav.get_pos().relthis(data.target.get_pos(), r);
        
        // Check if within hover distance
        if (r.norm22xy() < (d * d)) {
            if (!in_range) {
                // Switch to hovering at current position
                compute_hover(true, uavf, uavf, ps);
                in_range = true;
                ps.refresh_uchanged();
            }
        } else {
            if (in_range) {
                // Return to flying toward target
                compute_hover(data.direct, Base::Feature::build_abs(ps.uavc.get_pos().get_llh()),
                             data.target.get_fref().get_feature(), ps);
                in_range = false;
                ps.refresh_uchanged();
            }
        }
    }
}
```

The `Hovhere` class adds arcade control for precise positioning:

```cpp
void Detour::Hovhere::step(Detour& ps) {
    // Update horizontal arcade state
    arc_st_h.step((!Rfun::comp_real(arc_cmd[Ku8::u0], Const::ZERO, Const::EPS)) ||
                 (!Rfun::comp_real(arc_cmd[Ku8::u1], Const::ZERO, Const::EPS)),
                 ps.uav.get_GS());
    
    ps.is_arc_h = arc_st_h.is_arcade();
    
    // Update hover position if in arcade mode
    if (ps.is_arc_h) {
        ps.calc.set_point(pch_hover, Base::Feature::build_abs(ps.uav.get_pos().get_llh()), 
                         Tpatchset::no_next, ps.spdcmd.get().get_speed_cfg());
    }
    
    // Copy desired arcade velocity and clear for next step
    ps.vn_arc.copy(arc_cmd);
    arc_cmd.zeros();
}
```

### 3.5 Follow and Flyroute Maneuvers

The `Followroute` class implements following a moving target:

```cpp
void Detour::Followroute::step(Detour& ps) {
    // Update feature position
    feature.refresh();
    pos.copynr(feature.get_pos());
    
    // Apply offset based on coordinate system
    if (var_axis == ned) {
        pos.move_drn(rel_vec);
    } else {
        // Compute position for current angle
        Maverick::Rvector3 rna;
        rna[0] = Rmath::cosr(angle) * rel_vec[0] - Rmath::sinr(angle) * rel_vec[1];
        rna[1] = Rmath::sinr(angle) * rel_vec[0] + Rmath::cosr(angle) * rel_vec[1];
        rna[Rvector3::vz] = rel_vec[Rvector3::vz];
        pos.move_drn(rna);
    }
    
    // Store current position in buffer
    pos_buff.push_back(pos);
    
    // Handle state machine
    if (state == in_course) {
        on_in_course(ps);
    } else {
        on_waiting_pos(ps);
    }
}
```

The `Flyroute` class implements transitioning to another route:

```cpp
bool Detour::Flyroute::set_flyroute_start(Patchset& route, const bool flyto_closest) {
    // Check if the route is correct
    bool ret = route.current_check();
    if (ret) {
        // Inherit projection type from route
        prjtype = route.get_prj();
        
        // Select first point and store distance to it
        Real dist2 = Const::ZERO;
        if (flyto_closest) {
            // Set the next way point after the closest patch
            dist2 = route.flyto_closest();
        }
        
        // Get the position and tangent vector of the way point
        route.on_focus(uav.get_pos(), uav.get_vn());
        pos = route.get_on_focus_data().f0;
        
        // If the way point was selected beforehand set the distance to it
        if (!flyto_closest) {
            Maverick::Rvector3 dr;
            uav.get_pos().relthis(route.get_on_focus_data().p0, dr);
            dist2 = dr.norm22xy();
        }
        
        // Only smoothed if distance is greater than 3 meters
        ret = (dist2 > Const::NINE);
    }
    return ret;
}

void Detour::Flyroute::calculate(Detour& ps) {
    const Speed_cfg speed = ps.spdcmd.get().get_speed_cfg();
    ps.calc.clear_masks();
    ps.calc.set_line(pch_line_start, Base::Feature::build_abs(ps.uav.get_pos().get_llh()), 
                    pch_hover, speed);
    ps.calc.set_point(pch_hover, pos, Tpatchset::no_next, speed);
    ps.calc.set_first(pch_line_start);
    ps.set_current_patch(ps.calc.get_first());
}
```

### 3.6 Command Processing

The `Detour` class processes commands through its `on_focus` and `path_compute` methods:

```cpp
void Detour::on_focus(const Geo::Apos& pos, const Maverick::Irvector3& v0) {
    if (is_active()) {
        Patchset::request_prj(commands[type]->get_prj());
        if (compute_pending) {
            compute_pending = false;
            commands[type]->calculate(*this);
            refresh_uchanged();
        }
        Patchset::on_focus(pos, v0);
    }
}

void Detour::path_compute(const Patchsetcfg& pcfg,
                         const Geo::Apos& pos,
                         Maverick::Irvector3& d,
                         Maverick::Irvector3& t) {
    if (is_active()) {
        commands[type]->step(*this);
        Patchset::refresh_current();
        Patchset::path_compute(pcfg, pos, d, t);
    }
}
```

## 4. Taxi Class: Ground Movement Guidance

The `Taxi` class implements guidance for ground taxi operations, creating paths for aircraft to follow during ground movement.

### 4.1 Core Components and Structure

```cpp
class Taxi : public Patchset {
public:
    struct Cfg : public Patchsetcfg {
        Geo::Rwymgr::Id osid;    // Runway identifier
        Base::Vref urr;          // Runway direction angle
        Base::Fref fer;          // Runway end position
        
        // Configuration methods
        Cfg();
        void step();
        void cset(Base::Lossy_error& str);
        void cget(Base::Lossy& str) const;
        void operation_check(Base::Error& err) const;
    };
    
    // Constructor and methods
    Taxi(const Vpunav& uav0, Base::Patchid& last_achieved0,
         Airframe_action_wp_publish& aac_publish0);
    virtual void calculate(const Gtrackcfg& gcfg);
    Base::Itunable& get_cmd_taxiget();
    
private:
    static const Real max_rad;    // Max radius (10000m)
    static const Real len_extra;  // Extra distance (4000m)
    
    Tpatchset& calc;              // Patchset calculation
    Base::Twraptun<Base::Tuntraits::Cget_only<Tunpatchset>> tun;  // Tunable
    Geo::Frefcache fer;           // Runway end position
    const Vpunav& uav;            // UAV navigation data
    
    // Work variables
    Maverick::Rvector3 r0e;       // End of runway
    Maverick::Rvector3 re2;       // End of last line
    Maverick::Rvector3 rk;        // Arc control point
    Real dr;                      // Runway direction
    Maverick::Rvector3 un_vec;    // Normal vector
};
```

### 4.2 Taxi Route Geometry

The Taxi class creates a route with the following components:

```
    Current Position
         *
          \
           \
            \
             * Arc
             |
             |
             * Runway Start
             |
             |
             * Runway End + Extra
```

The taxi route consists of:
1. An arc from the current position to align with the runway
2. A straight line along the runway
3. An extension beyond the runway end

### 4.3 Configuration Parameters

The `Taxi::Cfg` structure contains:
1. **Runway ID**: Identifier for the runway in the runway manager
2. **Runway Direction**: Azimuth angle of the runway
3. **Runway End Position**: Position of the runway end

### 4.4 Route Calculation Algorithm

The `calculate` method implements the taxi route computation:

```cpp
void Taxi::calculate(const Gtrackcfg& gcfg) {
    // Check if configuration is valid
    const Taxi::Cfg* c = gcfg.pcfg.get<Taxi::Cfg>();
    if (c) {
        const Speed_cfg speed = gcfg.spdcmd.get_speed_cfg();
        
        // Increment change counter for external tracking
        uchanged.set(uchanged.get() + 1U);
        
        // Check if runway/spot parameters are correct
        if (Geo::Rwymgr::get_instance().calculate(c->osid, uav.get_pos(), wind_uh.kvec)) {
            calc.clear_masks();
            
            // Set up runway end position
            fer.set(c->fer);
            fer.refresh();
            const Geo::Apos& fer_pos = fer.get_pos();
            
            // Calculate runway direction vector
            dr = c->urr.kget();
            Rvector3 ur;
            ur[Ku16::u0] = Rmath::cosr(dr);
            ur[Ku16::u1] = Rmath::sinr(dr);
            ur[Ku16::u2] = Const::ZERO;
            
            // Calculate end point beyond runway
            re2.lincmb(len_extra, ur);
            calc.set_point(pch_2, fer_pos.frelthis(re2), Tpatchset::no_next, speed);
            
            // Calculate vector from current position to runway end
            Rvector3 ur0e;
            uav.get_pos().relthis(fer_pos, r0e);
            
            ur0e.copy(r0e);
            ur0e[Ku16::u2] = Const::ZERO;
            const Real d0e = ur0e.norm2();
            ur0e.scale(Const::ONE / d0e);
            
            // Calculate normal vectors for arc
            un_vec.cross_axkn(ur);
            if (un_vec.dot(ur0e) > Const::ZERO) {
                un_vec.signinv();
            }
            
            Rvector3 un0e;
            un0e.cross_axkn(ur0e);
            if (un0e.dot(ur) < Const::ZERO) {
                un0e.signinv();
            }
            
            // Calculate arc radius
            Real p = un0e.dot(un_vec);
            Real R = Const::MAX;
            Real p2 = p * p;
            if (p2 < Const::ONE) {
                R = Const::ONEHALF * d0e / Rmath::sqrtr(Const::ONE - p2);
            }
            
            // If radius is reasonable, create standard arc
            if (R < max_rad) {
                // Calculate arc control point
                rk.lincmb(Const::ONEHALF, r0e, R, un_vec);
                rk.lincmb_add(-R, un0e);
                
                // Set up line from runway start to end
                calc.set_line(pch_1, Base::Feature::build_abs(fer_pos.get_llh()), pch_2, speed);
            } else {
                // If radius too large, use maximum radius and adjust
                R = max_rad;
                Real d1 = -r0e.dot(un_vec);
                Real d3 = Rmath::sqrtr(d1 * (2 * R - d1));
                Real d4 = r0e.dot(ur);
                Rvector3 re1;
                re1.lincmb(d3 - d4, ur);
                calc.set_line(pch_1, fer_pos.frelthis(re1), pch_2, speed);
                
                // Calculate arc control point for large radius
                Rvector3 r01;
                r01.vecsum(r0e, re1);
                rk.cross_axkn(r01);
                rk.norm2alize();
                if (rk.dot(un_vec) > Const::ZERO) {
                    rk.signinv();
                }
                
                Rvector3 r1c;
                r1c.lincmb(R, un_vec);
                rk.scale(R + r1c.dot(rk));
            }
            
            // Set up arc from current position to runway start
            calc.set_arc(pch_0, Base::Feature::build_abs(uav.get_pos().get_llh()), 
                        rk[0], rk[1], 0, pch_1, speed);
            
            // Set first patch and current patch
            calc.set_first(pch_0);
            set_current_patch(calc.get_first());
        }
    }
}
```

## 5. Vtol Class: Vertical Takeoff and Landing

The `Vtol` class implements guidance for vertical takeoff and landing operations, creating paths for VTOL aircraft.

### 5.1 Core Components and Structure

```cpp
class Vtol : public Patchset {
public:
    struct Cfg : public Patchsetcfg {
        enum Ptype {
            p_straight = 0,    // Straight mode
            p_hangman  = 1     // Hangman mode
        };
        
        enum Extend {
            ext_up   = 0,      // Go up forever
            ext_down = 1,      // Go down forever
            ext_none = 2,      // Use touchr data for final height
            ext_all  = 3       // Max type
        };
        
        Ptype ptype;           // Type of landing
        Geo::Height hdst;      // Destination height for straight or safe height for hangman
        Base::Fref touchr;     // Touch point for landing
        Extend ext;            // Final point behavior
        
        // Configuration methods
        Cfg();
        void step();
        void cset(Base::Lossy_error& str);
        void operation_check(Base::Error& err) const;
    };
    
    // Constructor and methods
    Vtol(const Vpunav& uav0, Base::Patchid& last_achieved0,
         Airframe_action_wp_publish& aac_publish0);
    virtual void calculate(const Gtrackcfg& gcfg);
    Base::Itunable& get_cmd_vtolget();
    
private:
    Tpatchset& calc;                  // Patchset calculation
    Base::Twraptun<Base::Tuntraits::Cget_only<Tunpatchset>> tun;  // Tunable
    Geo::Frefcache touchr;            // Touch point for landing
    const Vpunav& uav;                // UAV navigation data
    Maverick::Rvector3 dr;            // Relative position
};
```

### 5.2 VTOL Route Geometry

The Vtol class supports two different route types:

1. **Straight Mode**:
   ```
   Current Position
        *
        |
        |
        * Target Height
   ```

2. **Hangman Mode**:
   ```
   Current Position
        *
        |
        |
        * Safe Height
        |
        |
        * Above Touch Point
        |
        |
        * Touch Point
   ```

### 5.3 Configuration Parameters

The `Vtol::Cfg` structure contains:
1. **Pattern Type**: Straight or hangman
2. **Height**: Destination height or safe height
3. **Touch Point**: Landing position reference
4. **Extension**: Behavior for final point (up, down, or exact)

### 5.4 Route Calculation Algorithm

The `calculate` method implements the VTOL route computation:

```cpp
void Vtol::calculate(const Gtrackcfg& gcfg) {
    // Check if configuration is valid
    const Vtol::Cfg* c = gcfg.pcfg.get<Vtol::Cfg>();
    if (c) {
        const Speed_cfg speed = gcfg.spdcmd.get_speed_cfg();
        
        // Increment change counter for external tracking
        uchanged.set(uchanged.get() + 1U);
        
        const Geo::Apos& upos = uav.get_pos();
        calc.clear_masks();
        
        // Handle hangman mode
        if (c->ptype == Cfg::p_hangman) {
            // Set initial waypoint at current position
            calc.set_line(pch_xscend_start, Base::Feature::build_abs(upos.get_llh()), 
                         pch_translate_start, speed);
            
            // Set up touch point
            touchr.set(c->touchr);
            touchr.refresh();
            const Geo::Apos& touchr_pos = touchr.get_pos();
            
            // Calculate height for second waypoint
            touchr_pos.relthis(upos, dr);
            dr[2] += (c->hdst.type == Geo::Height::relative) ? c->hdst.hdown.kget() :
                    (upos.get_h(c->hdst.habs.get_type()) - c->hdst.habs.get_h());
            
            // Set second waypoint (vertical climb/descent)
            calc.set_line(pch_translate_start, touchr_pos.frelthis(dr), 
                         pch_translate_end, speed);
            
            // Set third waypoint (horizontal movement)
            dr[Base::Coord::pos_x] = 0;
            dr[Base::Coord::pos_y] = 0;
            calc.set_line(pch_translate_end, touchr_pos.frelthis(dr), 
                         pch_xscend_end, speed);
            
            // Set final waypoint based on extension mode
            switch (c->ext) {
                case Cfg::ext_up:
                    // Go up 1000m from touch point
                    dr[Base::Coord::pos_z] += -Const::ONE_THOUSAND;
                    calc.set_point(pch_xscend_end, touchr_pos.frelthis(dr), 
                                  Tpatchset::no_next, speed);
                    break;
                    
                case Cfg::ext_down:
                    // Go down 1000m from touch point
                    dr[Base::Coord::pos_z] += Const::ONE_THOUSAND;
                    calc.set_point(pch_xscend_end, touchr_pos.frelthis(dr), 
                                  Tpatchset::no_next, speed);
                    break;
                    
                case Cfg::ext_none:
                    // Stay at touch point height
                    calc.set_point(pch_xscend_end, Base::Feature::build_abs(touchr_pos.get_llh()),
                                  Tpatchset::no_next, speed);
                    break;
                    
                default:
                    Bsp::warning();
                    break;
            }
            
            // Set first patch
            calc.set_first(pch_xscend_start);
        }
        // Handle straight mode
        else {
            // Calculate final height based on extension mode
            dr[Base::Coord::pos_x] = 0;
            dr[Base::Coord::pos_y] = 0;
            
            switch (c->ext) {
                case Cfg::ext_up:
                    // Go up 1000m
                    dr[Base::Coord::pos_z] = -Const::ONE_THOUSAND;
                    break;
                    
                case Cfg::ext_down:
                    // Go down 1000m
                    dr[Base::Coord::pos_z] = Const::ONE_THOUSAND;
                    break;
                    
                case Cfg::ext_none:
                    // Go to configured height
                    dr[Base::Coord::pos_z] = (c->hdst.type == Geo::Height::relative) ? 
                                            c->hdst.hdown.kget() :
                                            (upos.get_h(c->hdst.habs.get_type()) - c->hdst.habs.get_h());
                    break;
                    
                default:
                    Bsp::warning();
                    break;
            }
            
            // Set up straight vertical path
            calc.set_line(pch_xscend_start, Base::Feature::build_abs(upos.get_llh()), 
                         pch_xscend_end, speed);
            calc.set_point(pch_xscend_end, upos.frelthis(dr), Tpatchset::no_next, speed);
            calc.set_first(pch_xscend_start);
        }
        
        // Set current patch
        set_current_patch(calc.get_first());
    }
}
```

## 6. Rendezvous Class: Operations with Moving Targets

The `Rendezvous` class implements guidance for operations with moving targets, such as aerial refueling or formation flying. While the source file for this class was not available in the provided files, we can infer its functionality from the context and other guidance modules.

### 6.1 Likely Core Components and Structure

```cpp
class Rendezvous : public Patchset {
public:
    struct Cfg : public Patchsetcfg {
        // Configuration parameters for rendezvous
        Base::Fref target;           // Target reference
        Base::Vref offset_distance;  // Offset distance from target
        Base::Vref approach_speed;   // Approach speed
        
        // Configuration methods
        Cfg();
        void step();
        void cset(Base::Lossy_error& str);
        void cget(Base::Lossy& str) const;
        void operation_check(Base::Error& err) const;
    };
    
    // Constructor and methods
    Rendezvous(const Vpunav& uav0, Base::Patchid& last_achieved0,
              Airframe_action_wp_publish& aac_publish0);
    virtual void calculate(const Gtrackcfg& gcfg);
    Base::Itunable& get_cmd_rdvzget();
    
private:
    Tpatchset& calc;                  // Patchset calculation
    Base::Twraptun<Base::Tuntraits::Cget_only<Tunpatchset>> tun;  // Tunable
    Geo::Frefcache target;            // Target position cache
    const Vpunav& uav;                // UAV navigation data
};
```

### 6.2 Likely Rendezvous Route Geometry

The Rendezvous class likely creates a route with the following components:

```
Current Position
      *
       \
        \
         \
          * Intercept Point
           \
            \
             * Target Position + Offset
```

The rendezvous route would consist of:
1. A path from the current position to an intercept point
2. A path from the intercept point to the target position plus offset
3. Continuous updates as the target moves

### 6.3 Integration with STANAG Protocol

The VPGNC framework includes integration with the STANAG protocol for loiter and slave-to-location commands:

1. **Loiter_stg_cfg**: Processes STANAG loiter commands
   ```cpp
   Base::Msg_data::Ack_type Loiter_stg_cfg::on_rx(Rx_params& push_p) {
       // Parse STANAG message
       Base::Msg_data::Ack_type ack = Base::Msg_data::rejected;
       Base::Presence_vec pvec(push_p.auth_c.pres_vec_s, Base::Presence_vec::size2);
       Base::U8istream& is = push_p.is;
       pvec.cset(is);
       
       // Extract loiter parameters
       UA_loiter_data loi;
       // ... (parameter extraction)
       
       // Check if in loiter mode and parameters are valid
       if ((Bsp::Huvar(static_cast<Base::Uvar>(vom.entry0.first_var + cu_select_fpcm)).get() ==
            static_cast<Uint16>(Base::Fly_mode::m_loiter)) && loi.validate()) {
           
           // Get position from configuration
           const Base::Tllh pos_cmd = {get_rvar(cr_loiter_lon), get_rvar(cr_loiter_lat), 
                                      get_rvar(cr_alt_cmd)};
           
           // Execute appropriate command based on loiter type
           switch (loi.type) {
               case UA_loiter_data::lt_circular:
                   guidance.fly_to_loiter(Loiter_data::build_from_ua_stg_loiter(loi, pos_cmd));
                   ack = Base::Msg_data::completed;
                   break;
                   
               case UA_loiter_data::lt_hover:
                   guidance.fly_to_hover(Hover_data(Base::Fref::build_abs(pos_cmd),
                                                  Base::Vref::build(0.0F),
                                                  false,
                                                  Patchset::prj_3d));
                   ack = Base::Msg_data::completed;
                   break;
                   
               default:
                   Bsp::warning();
                   break;
           }
       }
       
       return ack;
   }
   ```

2. **Stg_slave_location**: Processes STANAG slave-to-location commands
   ```cpp
   Base::Msg_data::Ack_type Stg_slave_location::on_rx(IStanag_msg_rx::Rx_params& push_p) {
       // Parse STANAG message
       Base::Msg_data::Ack_type ack = Base::Msg_data::rejected;
       U8istream_pvec is(push_p.is, push_p.auth_c.pres_vec_s, Base::Presence_vec::size3);
       
       // Extract position and parameters
       Base::Tllh_low_res loc_pos = {0.0F, 0.0F, 0.0F};
       const bool loc_lat_pres = is.get_int32_be_ref(Const::BAM32_to_rad, loc_pos.lat);
       const bool loc_lon_pres = is.get_int32_be_ref(Const::BAM32_to_rad, loc_pos.lon);
       // ... (parameter extraction)
       
       // Check if in slave-to-location mode
       bool is_valid = Bsp::Huvar(static_cast<Base::Uvar>(vom.entry0.first_var + cu_select_fpcm)).get() ==
                      static_cast<Uint16>(Base::Fly_mode::m_slave_to_location);
       
       if (is_valid && ((static_cast<Route_slave_mode>(slave_loc_mode) == slave_alt) ||
                       ((static_cast<Route_slave_mode>(slave_loc_mode) == slave_angle)))) {
           
           // Check if position and loiter parameters are valid
           is_valid = loc_lon_pres && loc_lat_pres && loc_alt_pres && offset_pres && loi.validate();
           if (is_valid) {
               // Convert altitude to WGS84
               Geo::Apos pos_to_loiter(loc_pos);
               pos_to_loiter.set_h(Htype::get_ver_htype(static_cast<Defs::Altitude::Type>(loc_alt_type)), 
                                  loc_pos.h);
               
               // Calculate loiter position based on mode
               if (static_cast<Route_slave_mode>(slave_loc_mode) == slave_alt) {
                   is_valid = ua_rel_alt_pres;
                   const Real angle = (offset > 0.0F) ? Rfun::asinw(ua_rel_alt / offset) : Const::PI05;
                   pos_to_loiter.move_drn(Maverick::Rvector3(offset * Rmath::cosr(angle), 
                                                            0.0F, -ua_rel_alt));
               } else {
                   is_valid = look_angle_pres;
                   pos_to_loiter.move_drn(Maverick::Rvector3(Rmath::cosr(look_angle) * offset,
                                                            0.0F,
                                                            -Rmath::sinr(look_angle) * offset));
               }
               
               if (is_valid) {
                   // Execute appropriate command based on loiter type
                   if (loi.type == UA_loiter_data::lt_circular) {
                       guidance.fly_to_loiter(Loiter_data::build_from_ua_stg_loiter(loi, 
                                                                                  pos_to_loiter.get_llh()));
                   } else {
                       guidance.fly_to_hover(Hover_data(Base::Fref::build_abs(pos_to_loiter.get_llh()),
                                                      Base::Vref::build(0.0F),
                                                      false,
                                                      Patchset::prj_3d));
                   }
                   ack = Base::Msg_data::completed;
               }
           }
       }
       
       return ack;
   }
   ```

## 7. Supporting Classes and Data Structures

### 7.1 Hover_data: Hover Maneuver Configuration

```cpp
struct Hover_data {
    Geo::Frefcache target;      // Target position
    Base::Vref distance;        // Hover at that distance
    bool direct;                // True if no linear patch is included
    Patchset::Prjtype prj_type; // Projection type (2D, 3D)
    
    // Constructors
    Hover_data();
    Hover_data(const Base::Fref& target0, const Base::Vref& distance0,
              const bool direct0, const Patchset::Prjtype prj_type0);
};
```

### 7.2 Loiter_data: Loiter Maneuver Configuration

```cpp
struct Loiter_data {
    Base::Polarparams::Turn_direction turn;  // Turn direction
    Base::Vref radio;                        // Turn radius
    Base::Fref flyto;                        // Location to do loiter
    Patchset::Prjtype prj_type;              // Projection type (2D, 3D)
    
    // Build from STANAG data
    static Loiter_data build_from_ua_stg_loiter(const Stanag::UA_loiter_data& ua_stg_loiter_data,
                                               const Base::Tllh& pos_cmd);
};
```

### 7.3 Speed_cfg: Speed Configuration

```cpp
struct Speed_cfg {
    // Speed types
    enum Speed_type {
        st_ias     = 0,  // Indicated Airspeed
        st_tas     = 1,  // True Airspeed
        st_ground  = 2,  // Groundspeed
        st_arrival = 3   // Arrival Time
    };
    
    // Speed data structure
    struct Patch_speed {
        Real vlink;      // Speed between waypoints [m/s]
        Real vpoint;     // Speed on waypoint reach [m/s]
    };
    
    // Data union
    union Speed_data {
        Patch_speed speed;              // Data for speed configuration
        Base::Stimestamp arrival_time;  // Data for arrival time configuration
    };
    
    // Reach modes
    enum Reach_mode {
        rm_fixed = 0,  // Fixed speed
        rm_reach = 1   // Waypoint reach velocity
    };
    
    Speed_data data;    // Speed configuration
    
    // Methods
    Speed_cfg();
    bool validate() const;
    Speed_type get_speed_type() const;
    void set_speed_type(const Speed_type type);
    Reach_mode get_reach_mode() const;
    void set_reach_mode(const Reach_mode mode);
    void cset(Base::Lossy_error& str);
    void cget(Base::Lossy& str) const;
    
private:
    Base::U8pkarray<2> cfg;  // Configuration bytes
};
```

### 7.4 Accelimit: Acceleration Envelope

```cpp
class Accelimit {
public:
    // Constructor and serialization
    Accelimit();
    void cset(Base::Lossy_error& str);
    void cget(Base::Lossy& str) const;
    
    // Acceleration limiting
    bool bound_acc(const Maverick::Irvector3& prev_vn,
                  const Maverick::Irvector3& prev_an,
                  const Real dt,
                  const Dynamics::Rigidbody& uav,
                  const Real dvwx,
                  Maverick::Irvector3& vn) const;
    
private:
    // Axis enumeration
    enum Axis {
        axis_x = 0,  // X component
        axis_y = 1,  // Y component
        axis_z = 2   // Z component
    };
    
    // Range reference structure
    struct Range_ref {
        Base::Vref falling;  // Falling limit
        Base::Vref rising;   // Rising limit
        
        void cset(Base::Lossy_error& str, const Real min, const Real max);
        void cget(Base::Lossy& str) const;
    };
    
    // Acceleration limiting methods
    bool bound_acc_carts(const Maverick::Irvector3& prev_vn,
                        const Maverick::Irvector3& prev_an,
                        const Real dt,
                        const Dynamics::Rigidbody& uav,
                        Maverick::Irvector3& vn) const;
    
    bool bound_acc_azeld(const Maverick::Irvector3& prev_vn,
                        const Real dt,
                        Maverick::Irvector3& vn,
                        const Real dvwx = Const::ZERO) const;
    
    // Configuration parameters
    bool spherical;                              // Type of desired velocity smoothing
    bool limit_acc;                              // True if acceleration is limited
    Base::Tnarray<Range_ref, Ku16::u3> alim;     // Acceleration limits
    bool limit_jerk;                             // Is jerk limited
    Base::Tnarray<Range_ref, Ku16::u3> jlim;     // Jerk limits
    bool limangrate;                             // Spherical limit type
};
```

## 8. Integration with Mode Management

The guidance modules integrate with the mode management system through the `Modeconf` class:

```cpp
class Modeconf {
public:
    Modeconf(Guidance& g0);
    void step();
    const Vblocks::Modetable& get_modetable() const;
    Base::Ideserializable& build_mode_tun();
    Base::Itunable& build_modecmd_tun();
    
private:
    Guidance& guide;                  // Reference to guidance manager
    Vblocks::Modetable vmodetable;    // Table of modes
    Vblocks::Apsel vapsel;            // Autopilot selection manager
};
```

The `step` method monitors mode changes and resets guidance when needed:

```cpp
void Modeconf::step() {
    // Reset guidance if changed to auto or changed to active ap
    const bool entered_auto = vmodetable.step();
    const bool ap_onfocus = vapsel.step();
    if (entered_auto || ap_onfocus) {
        guide.reset_guidance(false);
        guide.on_auto();
    }
}
```

## 9. Summary and Key Insights

### 9.1 Common Design Patterns

1. **Inheritance from Patchset**: All guidance modules inherit from the `Patchset` class, providing a consistent interface for route management.

2. **Configuration Structure**: Each module defines a `Cfg` structure that inherits from `Patchsetcfg`, allowing specialized configuration while maintaining a common interface.

3. **Calculation Method**: Each module implements a `calculate` method that constructs a route based on the current configuration and vehicle state.

4. **Tunable Access**: Each module provides a method to access its tunable parameters, allowing for runtime configuration.

5. **Change Tracking**: Each module maintains a counter that increments when the route changes, allowing external systems to detect changes.

### 9.2 Key Differences Between Modules

1. **Approach**: Creates a structured landing approach with loiter, alignment, and final approach segments. Focuses on precise touchdown point targeting.

2. **Climb**: Creates a structured takeoff and climb route, essentially the reverse of the approach route. Focuses on safe altitude gain.

3. **Detour**: Provides a flexible system for temporary deviations, supporting various maneuvers like loitering, hovering, and following. Focuses on adaptability.

4. **Taxi**: Creates ground movement paths with smooth transitions between current position and runway. Focuses on ground operations.

5. **Vtol**: Creates vertical takeoff and landing paths, supporting both straight and hangman modes. Focuses on vertical movement.

6. **Rendezvous**: Creates paths for intercepting and following moving targets. Focuses on relative positioning.

### 9.3 Integration Points

1. **STANAG Protocol**: The guidance modules integrate with the STANAG protocol through the `Loiter_stg_cfg` and `Stg_slave_location` classes.

2. **Mode Management**: The guidance modules integrate with the mode management system through the `Modeconf` class.

3. **Airframe Actions**: The guidance modules integrate with airframe actions through the `Airframe_action_wp_publish` class.

4. **Speed Control**: The guidance modules use the `Speed_cfg` structure to control vehicle speed during maneuvers.

5. **Acceleration Limiting**: The guidance modules use the `Accelimit` class to ensure smooth transitions between waypoints.

### 9.4 Overall Architecture

The VPGNC guidance modules form a comprehensive system for managing aircraft movement in various flight phases:

1. **Ground Operations**: Taxi module
2. **Takeoff**: Climb and VTOL modules
3. **En-route**: Detour module
4. **Special Operations**: Rendezvous module
5. **Landing**: Approach and VTOL modules

Each module is specialized for its specific flight phase but shares a common interface and design patterns, allowing for consistent behavior and integration with the broader VPGNC framework.