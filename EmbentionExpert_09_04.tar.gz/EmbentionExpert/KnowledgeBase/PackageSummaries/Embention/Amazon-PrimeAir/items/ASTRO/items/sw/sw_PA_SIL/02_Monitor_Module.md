# Generated from:

- code/PA_SIL_monitor/include/Emb_monitor_wrapper.h (1036 tokens)
- code/PA_SIL_monitor/include/Package_delivery_system_sim.h (465 tokens)
- code/PA_SIL_monitor/source/Emb_monitor_wrapper.cpp (6029 tokens)
- code/PA_SIL_monitor/source/Package_delivery_system_sim.cpp (962 tokens)

---

# SIL Monitor Module Analysis

## 1. System Architecture Overview

The SIL (Software-In-the-Loop) Monitor module is a critical component of a larger autonomous system framework, designed to monitor system behavior, detect anomalies, and trigger failover mechanisms when necessary. The module consists of several key components that work together to provide comprehensive monitoring capabilities.

### Core Components

1. **Monitor Builder (`Monitor_builder`)**: 
   - Central component that constructs and manages the monitoring system
   - Responsible for building and initializing the monitor objects
   - Provides access to the PA (Platform Abstraction) Monitor instance

2. **PA Monitor (`Blk_pa_mon`)**: 
   - Main monitoring logic implementation
   - Processes inputs from various system components
   - Generates outputs including failover triggers, log data, and alerts

3. **Package Delivery System Simulation (`Package_delivery_system_sim`)**: 
   - Simulates a package delivery door mechanism
   - Models servo behavior, door states, and position feedback
   - Provides realistic simulation of physical hardware components

4. **Monitor Wrapper (`Emb_monitor_wrapper`)**: 
   - Interface between the monitor module and the broader simulation framework
   - Implements the `FirmwareSimulation` interface
   - Handles message passing, initialization, and execution scheduling

## 2. Functional Behavior and Logic

### Monitor Initialization and Building

The monitor system follows a builder pattern for initialization:

```cpp
// In Emb_monitor_wrapper constructor
monitor(sender, mmdp_input, mission_plan, site_cfg, irxfw_parser)

// In Init method
Pa_blocks::Monitor_builder& monitor_builder = data.get()->monitor;
monitor_builder.build();

// In ExecuteAndScheduleNextExecutionInNs
Pa_blocks::Monitor_builder& monitor_builder = data.get()->monitor;
monitor_builder.build();  // Build monitor objects if not already done
```

The monitor is initialized with several dependencies:
- Message sender
- Mission plan data processor input manager
- Mission plan
- Site configuration
- IRXFW parser

### Execution Flow

The main execution flow occurs in the `ExecuteAndScheduleNextExecutionInNs` method:

1. Build monitor objects if not already done
2. Set the current simulation time
3. Step the PA monitor if build was successful
4. Run the Package Delivery System simulation
5. Update simulation time and return

```cpp
bool Emb_monitor_wrapper::ExecuteAndScheduleNextExecutionInNs(uint64_t& interval_ns)
{
    Pa_blocks::Monitor_builder& monitor_builder = data.get()->monitor;
    monitor_builder.build();  // Build monitor objects if not already done

    Bsp::Htimehelper::set_time_us(Base::Ttime(static_cast<double>(simulation_time_ns) * 1.0E-9));

    if (monitor_builder.is_build_ok())
    {
        monitor_builder.get_pa_monitor()->step();
        data.get()->send_vms_state_set = true;
    }

    // Run the PDS sim
    // [PDS simulation code...]

    simulation_time_ns += interval_ns;
    return true;
}
```

## 3. Input Processing and Message Handling

The monitor processes a wide range of input messages through the `PutMessage` method. These messages are categorized by their type and routed to the appropriate components:

### Key Input Message Types

1. **State Estimates**:
   - Primary state estimate (`cyp_pa_primary_state_estimate_compact`)
   - Recovery state estimate (`cyp_state_estimate_compact`)
   - Monitor state estimate (`cyp_mon_nav_state_estimate`)

2. **Motor Commands and Performance**:
   - Primary motor RPM command (`cyp_motor_rpm_cmd_a`)
   - Recovery motor RPM command (`cyp_pa_recovery_motor_rpm_command_rear_right`)
   - Motor performance data (`cyp_motor_perf`)

3. **Mission and System Status**:
   - Mission reset command (`cyp_pa_mission_reset_command`)
   - Controllers monitored data (`cyp_pa_controllers_monitored_data`)
   - Mission readiness signal (`cyp_pa_recovery_mission_readiness`)
   - VMS monitored data (`cyp_pa_monitored_data`)

4. **Heartbeats and Health Signals**:
   - Air data estimator heartbeat (`cyp_pa_air_data_estimator_heartbeat`)
   - On ground heartbeat (`cyp_pa_on_ground_heartbeat`)
   - CCP heartbeat (`cyp_pa_ccp_heartbeat`)

5. **Package Delivery System Commands**:
   - PDS door command (`cyp_pa_pds_command`)
   - PDS calibration command (`cyp_pds_calibration_command`)

6. **Mission Planning**:
   - Monitor mission plan data (`cyp_pa_monitor_mission_plan_data`)
   - Upload mission plan wrapper (`cyp_pa_upload_mission_plan_wrapper_mon`)

7. **Sensor Data**:
   - Dynamic pressure calibrated left/right (`cyp_meas_dyn_press_calib_left`, `cyp_meas_dyn_press_calib_right`)
   - Pseudojerk measurements (`cyp_pseudojerk`)

8. **Contingency Commands**:
   - Diverse comms command contingency (`cyp_pa_diverse_comms_command_contingency`)
   - Command contingency wrapper (`cyp_pa_command_contingency_wrapper`)

## 4. Output Generation

The monitor generates several types of outputs through the `GetMessage` method:

1. **Failover Triggers**:
   - Generated when the monitor detects critical anomalies
   - Sent with message type `cyp_fail_over_trigger`

2. **Log Data**:
   - Compact log data containing monitoring information
   - Sent with message type `cyp_mon_logdatacompact`

3. **Monitor Alerts**:
   - Alerts about detected anomalies or issues
   - Sent with message type `cyp_pa_monitor_alerts`

4. **PDS State Updates**:
   - Package Delivery System state information
   - Sent periodically (every 100ms)
   - Includes door state, position, and health information

5. **Drone State Updates**:
   - Drone state information
   - Sent with message type `cyp_mon_drone_state`

## 5. Package Delivery System Simulation

The Package Delivery System (PDS) simulation is a detailed model of a servo-controlled door mechanism:

### Parameters and Configuration

```cpp
// PDS simulation parameters
data->pds_sim_param.max_servo_angle_voltage_V = 3.3F;
data->pds_sim_param.min_servo_angle_voltage_V = 0.0F;
data->pds_sim_param.max_servo_angle_deg = 180.0F;
data->pds_sim_param.min_servo_angle_deg = -180.0F;
data->pds_sim_param.max_servo_angle_pwm_period_us = 2100.0F;
data->pds_sim_param.min_servo_angle_pwm_period_us = 900.0F;
data->pds_sim_param.open_door_servo_angle_deg = 145.0F;
data->pds_sim_param.closed_door_servo_angle_deg = -163.0F;
```

### PDS State Machine

The PDS simulation implements a state machine for the door with the following states:
- `open`: Door is fully open (angle > open_door_servo_angle_deg)
- `closed`: Door is fully closed (angle < closed_door_servo_angle_deg)
- `opening`: Door is transitioning to open (angle increasing)
- `closing`: Door is transitioning to closed (angle decreasing)

### PDS Control Logic

The PDS simulation processes two main inputs:
1. `power_enable_command`: Boolean indicating if power should be enabled
2. `pwm_command`: PWM period in microseconds controlling servo position

The simulation converts the PWM command to an angle and voltage:
```cpp
Real pwm_period_range_us = parameters_.max_servo_angle_pwm_period_us - parameters_.min_servo_angle_pwm_period_us;
Real servo_angle_range_deg = parameters_.max_servo_angle_deg - parameters_.min_servo_angle_deg;
Real servo_angle_voltage_range_V = parameters_.max_servo_angle_voltage_V - parameters_.min_servo_angle_voltage_V;

Real angle_cmd_deg = (pwm_cmd - parameters_.min_servo_angle_pwm_period_us) / pwm_period_range_us * servo_angle_range_deg - (servo_angle_range_deg / 2);
Real angle_meas_deg = angle_cmd_deg;
Real V_meas = (angle_meas_deg + (servo_angle_range_deg / 2)) / servo_angle_range_deg * servo_angle_voltage_range_V;
```

## 6. Monitor Integration with SIL Framework

The monitor module integrates with the broader SIL framework through the `FirmwareSimulation` interface:

### Initialization

```cpp
extern "C" FirmwareSimulation* get_firmware_simulation_instance()
{
    static FirmwareSimulation* ret = new Wrapper::Emb_monitor_wrapper();
    return ret;
}
```

This function provides a C-compatible interface for the simulation framework to obtain an instance of the monitor wrapper.

### Configuration Loading

The monitor can load configuration data from PDI (Persistent Data Interface) files:
- `cfg_vmgr` (6.bin): Variable initialization data
- `cfg_amz_site_cfg` (495.bin): Site configuration data
- `cfg_amz_mon_param` (496.bin): Monitor parameters

### Execution Scheduling

The simulation framework calls `ExecuteAndScheduleNextExecutionInNs` to advance the simulation by a specified time interval. The monitor processes inputs, updates its state, and schedules the next execution.

## 7. Data Structures and Key Algorithms

### Monitor Inputs Structure

The monitor processes a wide range of inputs organized in the `Monitor::Inputs` structure:
- State estimates (primary, recovery, monitor)
- Motor commands and performance data
- System status and health signals
- Sensor measurements
- Mission planning data
- PDS commands and state

### PDS Simulation Algorithm

The PDS simulation implements a simplified physical model of a servo-controlled door:
1. Process power enable command (if power is off, set minimum values)
2. Saturate PWM command within valid range
3. Convert PWM command to angle using linear mapping
4. Determine door state based on angle and previous state
5. Calculate position voltage based on angle
6. Populate output state structure with calculated values

### Message Processing Algorithm

The message processing in `PutMessage` follows this pattern:
1. Check if the message is valid and the monitor is built
2. Extract the message type from the port ID
3. Deserialize the message payload based on its type
4. Route the message to the appropriate input buffer in the monitor
5. Clear previous messages of the same type (single-slot buffers)
6. Return success/failure status

## 8. Error Handling and Contingency Logic

The monitor includes several error handling mechanisms:

1. **Message Validation**:
   - Checks if incoming messages are valid before processing
   - Returns false if message type is unknown or processing fails

2. **Build Status Checking**:
   - Verifies that the monitor is properly built before stepping
   - Only processes messages if the monitor build is successful

3. **PDS Simulation Safeguards**:
   - Handles power-off conditions gracefully
   - Saturates PWM commands within valid ranges
   - Maintains consistent door state transitions

4. **Failover Triggering**:
   - Generates failover triggers when critical anomalies are detected
   - Sends these triggers to the broader system for handling

## 9. File-by-File Breakdown

### Emb_monitor_wrapper.h

This header file defines the `Emb_monitor_wrapper` class, which implements the `FirmwareSimulation` interface:

- **Key Components**:
  - `Data` struct (forward declaration)
  - Simulation time tracking
  - PDS state publishing logic
  - Log data storage

- **Public Methods**:
  - `Init`: Initialize the monitor with configuration data
  - `ExecuteAndScheduleNextExecutionInNs`: Step the simulation
  - `GetErrorString`: Retrieve error information
  - `Reset`: Reset the monitor to initial state
  - `PutMessage`: Process incoming messages
  - `GetMessage`: Retrieve outgoing messages
  - `GetLogData`: Access log data

### Package_delivery_system_sim.h

This header defines the Package Delivery System simulation:

- **Key Structures**:
  - `Inputs`: Power enable command and PWM command
  - `Outputs`: PDS state information
  - `Parameters`: Servo and door configuration parameters
  - `States`: Internal simulation state

- **Public Methods**:
  - Constructor taking parameters and state references
  - `step`: Process inputs and update outputs

### Emb_monitor_wrapper.cpp

This implementation file contains the core monitor wrapper logic:

- **Key Functions**:
  - `get_firmware_simulation_instance`: Factory function for the wrapper
  - `Init`: Configuration loading and monitor building
  - `ExecuteAndScheduleNextExecutionInNs`: Simulation stepping
  - `PutMessage`: Extensive message handling logic
  - `GetMessage`: Output message generation

- **Notable Sections**:
  - PDS parameter initialization
  - Configuration data loading
  - Message type handling switch statement
  - Output priority handling

### Package_delivery_system_sim.cpp

This file implements the PDS simulation logic:

- **Key Functions**:
  - `reset`: Reset simulation state
  - `step`: Process inputs and update outputs

- **Notable Algorithms**:
  - PWM to angle conversion
  - Door state determination
  - Position voltage calculation

## 10. Cross-Component Relationships

### Monitor and PDS Simulation

The monitor wrapper integrates with the PDS simulation:
- Passes door commands from the monitor to the PDS simulation
- Receives PDS state from the simulation
- Publishes PDS state at regular intervals

### Monitor and External Components

The monitor interfaces with several external components:
- Receives state estimates from navigation systems
- Processes motor commands and performance data
- Handles mission planning data
- Generates failover triggers and alerts

### Message Flow

The overall message flow follows this pattern:
1. External components send messages to the monitor via `PutMessage`
2. The monitor processes these messages in its step function
3. The monitor generates output messages
4. External components retrieve these messages via `GetMessage`

## 11. Key Algorithms and Data Structures

### Monitor Builder Pattern

The monitor uses a builder pattern for initialization:
1. Create builder with dependencies
2. Call `build()` to construct monitor components
3. Check `is_build_ok()` before using the monitor
4. Access components via getter methods

### PDS State Machine

The PDS implements a state machine for the door:
- State transitions based on angle and previous state
- Four states: open, closed, opening, closing
- Angle thresholds define state boundaries

### Message Routing

The monitor uses a switch statement to route messages based on type:
- Each case handles a specific message type
- Messages are deserialized and stored in appropriate buffers
- Single-slot buffers are cleared before adding new messages

## 12. Referenced Context Files

The implementation references several context files that provide important interfaces and data structures:

1. **FirmwareSimulation.h**: Defines the interface implemented by `Emb_monitor_wrapper`
2. **Mon_log_data_compact.h**: Defines the log data structure used by the monitor
3. **Vms_pds_state.h**: Defines the PDS state structure
4. **Mon_monitor.h**: Defines the core monitor interface
5. **Blk_pa_mon.h**: Implements the PA monitor block
6. **Monitor_builder.h**: Implements the monitor builder pattern
7. **Pa_system_vars.h**: Defines system variables used by the monitor
8. **Stanag_msg_type.h**: Defines message types for communication

These files provide the interfaces and data structures that enable the monitor to integrate with the broader system.

## Summary

The SIL Monitor module is a comprehensive monitoring system that processes inputs from various system components, detects anomalies, and generates appropriate outputs including failover triggers and alerts. It includes a detailed simulation of a Package Delivery System that models servo behavior and door states. The module integrates with the broader SIL framework through a well-defined interface and supports configuration loading from persistent storage. The monitor's architecture follows good software engineering practices including the builder pattern, clear separation of concerns, and comprehensive error handling.