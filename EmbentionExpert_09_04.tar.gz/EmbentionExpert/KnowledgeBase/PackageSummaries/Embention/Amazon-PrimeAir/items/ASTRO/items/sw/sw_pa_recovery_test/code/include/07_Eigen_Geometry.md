# Generated from:

- Eigen/src/Geometry/Rotation2D.h (1715 tokens)
- Eigen/src/Geometry/Quaternion.h (8591 tokens)
- Eigen/src/Geometry/AngleAxis.h (2100 tokens)
- Eigen/src/Geometry/Transform.h (15482 tokens)
- Eigen/src/Geometry/Translation.h (1916 tokens)
- Eigen/src/Geometry/Scaling.h (1681 tokens)
- Eigen/src/Geometry/Hyperplane.h (2990 tokens)
- Eigen/src/Geometry/ParametrizedLine.h (2453 tokens)
- Eigen/src/Geometry/AlignedBox.h (4734 tokens)
- Eigen/src/Geometry/Umeyama.h (1547 tokens)
- Eigen/src/Geometry/EulerAngles.h (906 tokens)
- Eigen/src/Geometry/Homogeneous.h (5181 tokens)
- Eigen/src/Geometry/RotationBase.h (2015 tokens)
- Eigen/src/Geometry/OrthoMethods.h (2238 tokens)

## With context from:

- Amazon-PrimeAir/items/ASTRO/items/sw/sw_pa_recovery_test/code/include/08_Eigen_Matrix_Operations.md (6944 tokens)

---

# Eigen Geometry Module: Comprehensive Analysis

This analysis provides a detailed examination of Eigen's geometry module, focusing on rotation representations, transformations, and geometric primitives. The module builds on Eigen's matrix operations to provide a comprehensive framework for 2D and 3D geometry.

## 1. Rotation Representations

### 1.1 Rotation2D

`Rotation2D` represents a 2D rotation as a single angle in radians:

```cpp
template<typename _Scalar>
class Rotation2D : public RotationBase<Rotation2D<_Scalar>, 2>
{
protected:
  Scalar m_angle;
  
public:
  // Constructs a rotation from an angle in radians
  EIGEN_DEVICE_FUNC explicit inline Rotation2D(const Scalar& a) : m_angle(a) {}
  
  // Default constructor without initialization
  EIGEN_DEVICE_FUNC Rotation2D() {}
  
  // Construct from a 2x2 rotation matrix
  template<typename Derived>
  EIGEN_DEVICE_FUNC explicit Rotation2D(const MatrixBase<Derived>& m)
  {
    fromRotationMatrix(m.derived());
  }
  
  // Access and manipulation of the angle
  EIGEN_DEVICE_FUNC inline Scalar angle() const { return m_angle; }
  EIGEN_DEVICE_FUNC inline Scalar& angle() { return m_angle; }
  
  // Returns the angle in [0,2pi]
  EIGEN_DEVICE_FUNC inline Scalar smallestPositiveAngle() const {
    Scalar tmp = numext::fmod(m_angle, Scalar(2*EIGEN_PI));
    return tmp < Scalar(0) ? tmp + Scalar(2*EIGEN_PI) : tmp;
  }
  
  // Returns the angle in [-pi,pi]
  EIGEN_DEVICE_FUNC inline Scalar smallestAngle() const {
    Scalar tmp = numext::fmod(m_angle, Scalar(2*EIGEN_PI));
    if(tmp > Scalar(EIGEN_PI))       tmp -= Scalar(2*EIGEN_PI);
    else if(tmp < -Scalar(EIGEN_PI)) tmp += Scalar(2*EIGEN_PI);
    return tmp;
  }
  
  // Returns the inverse rotation
  EIGEN_DEVICE_FUNC inline Rotation2D inverse() const { return Rotation2D(-m_angle); }
  
  // Concatenates two rotations
  EIGEN_DEVICE_FUNC inline Rotation2D operator*(const Rotation2D& other) const
  { return Rotation2D(m_angle + other.m_angle); }
  
  // Applies the rotation to a 2D vector
  EIGEN_DEVICE_FUNC Vector2 operator* (const Vector2& vec) const
  { return toRotationMatrix() * vec; }
  
  // Conversion to/from rotation matrix
  template<typename Derived>
  EIGEN_DEVICE_FUNC Rotation2D& fromRotationMatrix(const MatrixBase<Derived>& m);
  EIGEN_DEVICE_FUNC Matrix2 toRotationMatrix() const;
  
  // Spherical interpolation (slerp)
  EIGEN_DEVICE_FUNC inline Rotation2D slerp(const Scalar& t, const Rotation2D& other) const
  {
    Scalar dist = Rotation2D(other.m_angle-m_angle).smallestAngle();
    return Rotation2D(m_angle + dist*t);
  }
  
  // Static identity rotation
  EIGEN_DEVICE_FUNC static inline Rotation2D Identity() { return Rotation2D(0); }
};
```

Key implementation details:
- Stores a single scalar representing the rotation angle
- Provides methods to normalize the angle to different ranges
- Implements rotation composition by adding angles
- Converts to/from 2x2 rotation matrices using sine and cosine:
  ```cpp
  template<typename Scalar>
  Matrix<Scalar,2,2> Rotation2D<Scalar>::toRotationMatrix(void) const
  {
    Scalar sinA = sin(m_angle);
    Scalar cosA = cos(m_angle);
    return (Matrix2() << cosA, -sinA, sinA, cosA).finished();
  }
  
  template<typename Scalar>
  template<typename Derived>
  Rotation2D<Scalar>& Rotation2D<Scalar>::fromRotationMatrix(const MatrixBase<Derived>& mat)
  {
    m_angle = atan2(mat.coeff(1,0), mat.coeff(0,0));
    return *this;
  }
  ```

### 1.2 AngleAxis

`AngleAxis` represents a 3D rotation as a rotation angle around an arbitrary 3D axis:

```cpp
template<typename _Scalar>
class AngleAxis : public RotationBase<AngleAxis<_Scalar>, 3>
{
protected:
  Vector3 m_axis;
  Scalar m_angle;
  
public:
  // Default constructor without initialization
  EIGEN_DEVICE_FUNC AngleAxis() {}
  
  // Constructs from an angle and axis
  EIGEN_DEVICE_FUNC inline AngleAxis(const Scalar& angle, const MatrixBase<Derived>& axis) 
    : m_axis(axis), m_angle(angle) {}
  
  // Constructs from a quaternion
  template<typename QuatDerived> 
  EIGEN_DEVICE_FUNC inline explicit AngleAxis(const QuaternionBase<QuatDerived>& q) { *this = q; }
  
  // Constructs from a rotation matrix
  template<typename Derived>
  EIGEN_DEVICE_FUNC inline explicit AngleAxis(const MatrixBase<Derived>& m) { *this = m; }
  
  // Access to angle and axis
  EIGEN_DEVICE_FUNC Scalar angle() const { return m_angle; }
  EIGEN_DEVICE_FUNC Scalar& angle() { return m_angle; }
  EIGEN_DEVICE_FUNC const Vector3& axis() const { return m_axis; }
  EIGEN_DEVICE_FUNC Vector3& axis() { return m_axis; }
  
  // Concatenation with other rotations
  EIGEN_DEVICE_FUNC inline QuaternionType operator* (const AngleAxis& other) const
  { return QuaternionType(*this) * QuaternionType(other); }
  
  EIGEN_DEVICE_FUNC inline QuaternionType operator* (const QuaternionType& other) const
  { return QuaternionType(*this) * other; }
  
  // Returns the inverse rotation
  EIGEN_DEVICE_FUNC AngleAxis inverse() const
  { return AngleAxis(-m_angle, m_axis); }
  
  // Conversion from quaternion
  template<class QuatDerived>
  EIGEN_DEVICE_FUNC AngleAxis& operator=(const QuaternionBase<QuatDerived>& q);
  
  // Conversion from rotation matrix
  template<typename Derived>
  EIGEN_DEVICE_FUNC AngleAxis& operator=(const MatrixBase<Derived>& m);
  
  // Conversion to rotation matrix
  EIGEN_DEVICE_FUNC Matrix3 toRotationMatrix(void) const;
  
  // Static identity rotation
  EIGEN_DEVICE_FUNC static inline const AngleAxis Identity() 
  { return AngleAxis(Scalar(0), Vector3::UnitX()); }
};
```

Key implementation details:
- Stores a unit vector axis and a rotation angle
- Converts from quaternion by extracting the rotation angle and axis:
  ```cpp
  template<typename Scalar>
  template<typename QuatDerived>
  AngleAxis<Scalar>& AngleAxis<Scalar>::operator=(const QuaternionBase<QuatDerived>& q)
  {
    Scalar n = q.vec().norm();
    if(n < NumTraits<Scalar>::epsilon())
    {
      m_angle = Scalar(0);
      m_axis << Scalar(1), Scalar(0), Scalar(0);
    }
    else
    {
      m_angle = Scalar(2)*atan2(n, abs(q.w()));
      if(q.w() < Scalar(0))
        n = -n;
      m_axis = q.vec() / n;
    }
    return *this;
  }
  ```
- Converts to rotation matrix using the Rodrigues formula:
  ```cpp
  template<typename Scalar>
  Matrix<Scalar,3,3> AngleAxis<Scalar>::toRotationMatrix(void) const
  {
    Matrix3 res;
    Vector3 sin_axis = sin(m_angle) * m_axis;
    Scalar c = cos(m_angle);
    Vector3 cos1_axis = (Scalar(1)-c) * m_axis;
    
    // Build rotation matrix using the Rodrigues formula
    Scalar tmp;
    tmp = cos1_axis.x() * m_axis.y();
    res.coeffRef(0,1) = tmp - sin_axis.z();
    res.coeffRef(1,0) = tmp + sin_axis.z();
    
    tmp = cos1_axis.x() * m_axis.z();
    res.coeffRef(0,2) = tmp + sin_axis.y();
    res.coeffRef(2,0) = tmp - sin_axis.y();
    
    tmp = cos1_axis.y() * m_axis.z();
    res.coeffRef(1,2) = tmp - sin_axis.x();
    res.coeffRef(2,1) = tmp + sin_axis.x();
    
    res.diagonal() = (cos1_axis.cwiseProduct(m_axis)).array() + c;
    
    return res;
  }
  ```

### 1.3 Quaternion

`Quaternion` represents a 3D orientation or rotation using a 4D complex number:

```cpp
template<typename _Scalar, int _Options>
class Quaternion : public QuaternionBase<Quaternion<_Scalar, _Options> >
{
public:
  typedef QuaternionBase<Quaternion<_Scalar, _Options> > Base;
  typedef _Scalar Scalar;
  typedef Matrix<Scalar,4,1> Coefficients;
  
protected:
  Coefficients m_coeffs;
  
public:
  // Default constructor without initialization
  EIGEN_DEVICE_FUNC inline Quaternion() {}
  
  // Constructs a quaternion from its four coefficients
  EIGEN_DEVICE_FUNC inline Quaternion(const Scalar& w, const Scalar& x, const Scalar& y, const Scalar& z) 
    : m_coeffs(x, y, z, w) {}
  
  // Constructs from a rotation matrix, angle-axis, or 4D vector
  template<typename Derived> 
  EIGEN_DEVICE_FUNC explicit inline Quaternion(const MatrixBase<Derived>& other) { *this = other; }
  
  EIGEN_DEVICE_FUNC explicit inline Quaternion(const AngleAxisType& aa) { *this = aa; }
  
  // Static methods to create special quaternions
  EIGEN_DEVICE_FUNC static Quaternion UnitRandom();
  
  template<typename Derived1, typename Derived2>
  EIGEN_DEVICE_FUNC static Quaternion FromTwoVectors(const MatrixBase<Derived1>& a, 
                                                   const MatrixBase<Derived2>& b);
  
  // Access to coefficients
  EIGEN_DEVICE_FUNC inline Coefficients& coeffs() { return m_coeffs; }
  EIGEN_DEVICE_FUNC inline const Coefficients& coeffs() const { return m_coeffs; }
};
```

The `QuaternionBase` class provides most of the functionality:

```cpp
template<class Derived>
class QuaternionBase : public RotationBase<Derived, 3>
{
public:
  // Component access
  EIGEN_DEVICE_FUNC inline CoeffReturnType x() const { return this->derived().coeffs().coeff(0); }
  EIGEN_DEVICE_FUNC inline CoeffReturnType y() const { return this->derived().coeffs().coeff(1); }
  EIGEN_DEVICE_FUNC inline CoeffReturnType z() const { return this->derived().coeffs().coeff(2); }
  EIGEN_DEVICE_FUNC inline CoeffReturnType w() const { return this->derived().coeffs().coeff(3); }
  
  // Vector part access
  EIGEN_DEVICE_FUNC inline const VectorBlock<const Coefficients,3> vec() const 
  { return coeffs().template head<3>(); }
  
  // Normalization
  EIGEN_DEVICE_FUNC inline void normalize() { coeffs().normalize(); }
  EIGEN_DEVICE_FUNC inline Quaternion<Scalar> normalized() const 
  { return Quaternion<Scalar>(coeffs().normalized()); }
  
  // Conversion to rotation matrix
  EIGEN_DEVICE_FUNC inline Matrix3 toRotationMatrix() const;
  
  // Set from two vectors
  template<typename Derived1, typename Derived2>
  EIGEN_DEVICE_FUNC Derived& setFromTwoVectors(const MatrixBase<Derived1>& a, 
                                             const MatrixBase<Derived2>& b);
  
  // Quaternion multiplication
  template<class OtherDerived>
  EIGEN_DEVICE_FUNC EIGEN_STRONG_INLINE Quaternion<Scalar> 
  operator* (const QuaternionBase<OtherDerived>& q) const;
  
  // Inverse and conjugate
  EIGEN_DEVICE_FUNC Quaternion<Scalar> inverse() const;
  EIGEN_DEVICE_FUNC Quaternion<Scalar> conjugate() const;
  
  // Angular distance and interpolation
  template<class OtherDerived>
  EIGEN_DEVICE_FUNC Scalar angularDistance(const QuaternionBase<OtherDerived>& other) const;
  
  template<class OtherDerived>
  EIGEN_DEVICE_FUNC Quaternion<Scalar> slerp(const Scalar& t, 
                                           const QuaternionBase<OtherDerived>& other) const;
  
  // Vector transformation
  EIGEN_DEVICE_FUNC EIGEN_STRONG_INLINE Vector3 _transformVector(const Vector3& v) const;
};
```

Key implementation details:
- Stores quaternion as a 4D vector (x,y,z,w) where (x,y,z) is the vector part and w is the scalar part
- Implements quaternion multiplication using the Hamilton product:
  ```cpp
  template<typename Scalar, int Arch, class Derived1, class Derived2>
  struct quat_product
  {
    EIGEN_DEVICE_FUNC static EIGEN_STRONG_INLINE Quaternion<Scalar> run(
      const QuaternionBase<Derived1>& a, const QuaternionBase<Derived2>& b)
    {
      return Quaternion<Scalar>
      (
        a.w() * b.w() - a.x() * b.x() - a.y() * b.y() - a.z() * b.z(),
        a.w() * b.x() + a.x() * b.w() + a.y() * b.z() - a.z() * b.y(),
        a.w() * b.y() + a.y() * b.w() + a.z() * b.x() - a.x() * b.z(),
        a.w() * b.z() + a.z() * b.w() + a.x() * b.y() - a.y() * b.x()
      );
    }
  };
  ```
- Converts to rotation matrix efficiently:
  ```cpp
  template<class Derived>
  Matrix<typename QuaternionBase<Derived>::Scalar, 3, 3>
  QuaternionBase<Derived>::toRotationMatrix() const
  {
    Matrix3 res;
    
    const Scalar tx  = Scalar(2)*x();
    const Scalar ty  = Scalar(2)*y();
    const Scalar tz  = Scalar(2)*z();
    const Scalar twx = tx*w();
    const Scalar twy = ty*w();
    const Scalar twz = tz*w();
    const Scalar txx = tx*x();
    const Scalar txy = ty*x();
    const Scalar txz = tz*x();
    const Scalar tyy = ty*y();
    const Scalar tyz = tz*y();
    const Scalar tzz = tz*z();
    
    res.coeffRef(0,0) = Scalar(1)-(tyy+tzz);
    res.coeffRef(0,1) = txy-twz;
    res.coeffRef(0,2) = txz+twy;
    res.coeffRef(1,0) = txy+twz;
    res.coeffRef(1,1) = Scalar(1)-(txx+tzz);
    res.coeffRef(1,2) = tyz-twx;
    res.coeffRef(2,0) = txz-twy;
    res.coeffRef(2,1) = tyz+twx;
    res.coeffRef(2,2) = Scalar(1)-(txx+tyy);
    
    return res;
  }
  ```
- Implements spherical linear interpolation (slerp):
  ```cpp
  template <class Derived>
  template <class OtherDerived>
  Quaternion<typename internal::traits<Derived>::Scalar>
  QuaternionBase<Derived>::slerp(const Scalar& t, const QuaternionBase<OtherDerived>& other) const
  {
    const Scalar one = Scalar(1) - NumTraits<Scalar>::epsilon();
    Scalar d = this->dot(other);
    Scalar absD = numext::abs(d);
    
    Scalar scale0;
    Scalar scale1;
    
    if(absD >= one) {
      scale0 = Scalar(1) - t;
      scale1 = t;
    } else {
      // theta is the angle between the 2 quaternions
      Scalar theta = acos(absD);
      Scalar sinTheta = sin(theta);
      
      scale0 = sin((Scalar(1) - t) * theta) / sinTheta;
      scale1 = sin((t * theta)) / sinTheta;
    }
    if(d < Scalar(0)) scale1 = -scale1;
    
    return Quaternion<Scalar>(scale0 * coeffs() + scale1 * other.coeffs());
  }
  ```
- Optimizes vector transformation:
  ```cpp
  template <class Derived>
  typename QuaternionBase<Derived>::Vector3
  QuaternionBase<Derived>::_transformVector(const Vector3& v) const
  {
    // This algorithm comes from optimizing the standard formula:
    // v' = q * v * q^-1
    Vector3 uv = this->vec().cross(v);
    uv += uv;
    return v + this->w() * uv + this->vec().cross(uv);
  }
  ```

## 2. Transformation Classes

### 2.1 Translation

`Translation` represents a pure translation in 2D or 3D space:

```cpp
template<typename _Scalar, int _Dim>
class Translation
{
public:
  enum { Dim = _Dim };
  typedef _Scalar Scalar;
  typedef Matrix<Scalar,Dim,1> VectorType;
  
protected:
  VectorType m_coeffs;
  
public:
  // Default constructor without initialization
  EIGEN_DEVICE_FUNC Translation() {}
  
  // Constructs from a vector of translation coefficients
  EIGEN_DEVICE_FUNC explicit inline Translation(const VectorType& vector) : m_coeffs(vector) {}
  
  // Constructs from individual coordinates
  EIGEN_DEVICE_FUNC inline Translation(const Scalar& sx, const Scalar& sy) {
    m_coeffs.x() = sx;
    m_coeffs.y() = sy;
  }
  
  EIGEN_DEVICE_FUNC inline Translation(const Scalar& sx, const Scalar& sy, const Scalar& sz) {
    m_coeffs.x() = sx;
    m_coeffs.y() = sy;
    m_coeffs.z() = sz;
  }
  
  // Access to components
  EIGEN_DEVICE_FUNC inline Scalar x() const { return m_coeffs.x(); }
  EIGEN_DEVICE_FUNC inline Scalar y() const { return m_coeffs.y(); }
  EIGEN_DEVICE_FUNC inline Scalar z() const { return m_coeffs.z(); }
  
  EIGEN_DEVICE_FUNC inline Scalar& x() { return m_coeffs.x(); }
  EIGEN_DEVICE_FUNC inline Scalar& y() { return m_coeffs.y(); }
  EIGEN_DEVICE_FUNC inline Scalar& z() { return m_coeffs.z(); }
  
  // Access to the vector of coefficients
  EIGEN_DEVICE_FUNC const VectorType& vector() const { return m_coeffs; }
  EIGEN_DEVICE_FUNC VectorType& vector() { return m_coeffs; }
  
  // Concatenation and transformation operations
  EIGEN_DEVICE_FUNC inline Translation operator* (const Translation& other) const
  { return Translation(m_coeffs + other.m_coeffs); }
  
  EIGEN_DEVICE_FUNC inline AffineTransformType operator* (const UniformScaling<Scalar>& other) const;
  
  template<typename OtherDerived>
  EIGEN_DEVICE_FUNC inline AffineTransformType operator* (const EigenBase<OtherDerived>& linear) const;
  
  template<typename Derived>
  EIGEN_DEVICE_FUNC inline IsometryTransformType operator*(const RotationBase<Derived,Dim>& r) const
  { return *this * IsometryTransformType(r); }
  
  template<int Mode, int Options>
  EIGEN_DEVICE_FUNC inline Transform<Scalar,Dim,Mode> operator* (
    const Transform<Scalar,Dim,Mode,Options>& t) const
  {
    Transform<Scalar,Dim,Mode> res = t;
    res.pretranslate(m_coeffs);
    return res;
  }
  
  // Applies translation to vector
  template<typename Derived>
  inline typename internal::enable_if<Derived::IsVectorAtCompileTime,VectorType>::type
  operator* (const MatrixBase<Derived>& vec) const
  { return m_coeffs + vec.derived(); }
  
  // Returns the inverse translation
  Translation inverse() const { return Translation(-m_coeffs); }
  
  static const Translation Identity() { return Translation(VectorType::Zero()); }
};
```

Key implementation details:
- Stores the translation as a vector of coefficients
- Implements translation composition by vector addition
- Provides methods to combine with other transformations
- Applies translation to vectors by simple addition

### 2.2 Transform

`Transform` represents a general transformation in 2D or 3D space:

```cpp
template<typename _Scalar, int _Dim, int _Mode, int _Options>
class Transform
{
public:
  enum {
    Mode = _Mode,
    Options = _Options,
    Dim = _Dim,
    HDim = _Dim+1
  };
  typedef _Scalar Scalar;
  typedef Matrix<Scalar,Dim,Dim> LinearMatrixType;
  typedef Matrix<Scalar,Dim,1> VectorType;
  typedef Matrix<Scalar,Dim,HDim> AffinePart;
  typedef Matrix<Scalar,HDim,HDim> MatrixType;
  typedef Matrix<Scalar,Dim,1> TranslationPart;
  
protected:
  MatrixType m_matrix;
  
public:
  // Default constructor
  EIGEN_DEVICE_FUNC inline Transform()
  {
    internal::transform_make_affine<(Mode==Affine || Mode==Isometry) ? Affine : AffineCompact>::run(m_matrix);
  }
  
  // Constructs from different transformation types
  EIGEN_DEVICE_FUNC inline explicit Transform(const TranslationType& t)
  {
    *this = t;
  }
  
  EIGEN_DEVICE_FUNC inline explicit Transform(const UniformScaling<Scalar>& s)
  {
    *this = s;
  }
  
  template<typename Derived>
  EIGEN_DEVICE_FUNC inline explicit Transform(const RotationBase<Derived, Dim>& r)
  {
    *this = r;
  }
  
  // Constructs from a matrix
  template<typename OtherDerived>
  EIGEN_DEVICE_FUNC inline explicit Transform(const EigenBase<OtherDerived>& other)
  {
    internal::transform_construct_from_matrix<OtherDerived,Mode,Options,Dim,HDim>::run(
      this, other.derived());
  }
  
  // Access to components
  EIGEN_DEVICE_FUNC inline const MatrixType& matrix() const { return m_matrix; }
  EIGEN_DEVICE_FUNC inline MatrixType& matrix() { return m_matrix; }
  
  EIGEN_DEVICE_FUNC inline ConstLinearPart linear() const { return ConstLinearPart(m_matrix,0,0); }
  EIGEN_DEVICE_FUNC inline LinearPart linear() { return LinearPart(m_matrix,0,0); }
  
  EIGEN_DEVICE_FUNC inline ConstAffinePart affine() const { return take_affine_part::run(m_matrix); }
  EIGEN_DEVICE_FUNC inline AffinePart affine() { return take_affine_part::run(m_matrix); }
  
  EIGEN_DEVICE_FUNC inline ConstTranslationPart translation() const 
  { return ConstTranslationPart(m_matrix,0,Dim); }
  EIGEN_DEVICE_FUNC inline TranslationPart translation() 
  { return TranslationPart(m_matrix,0,Dim); }
  
  // Transformation operations
  template<typename OtherDerived>
  EIGEN_DEVICE_FUNC EIGEN_STRONG_INLINE const typename internal::transform_right_product_impl<
    Transform, OtherDerived>::ResultType
  operator * (const EigenBase<OtherDerived> &other) const
  { return internal::transform_right_product_impl<Transform, OtherDerived>::run(*this,other.derived()); }
  
  template<typename OtherDerived>
  EIGEN_DEVICE_FUNC friend inline const typename internal::transform_left_product_impl<
    OtherDerived,Mode,Options,_Dim,_Dim+1>::ResultType
  operator * (const EigenBase<OtherDerived> &a, const Transform &b)
  { return internal::transform_left_product_impl<OtherDerived,Mode,Options,Dim,HDim>::run(a.derived(),b); }
  
  // Concatenation with other transformations
  EIGEN_DEVICE_FUNC inline const Transform operator * (const Transform& other) const
  {
    return internal::transform_transform_product_impl<Transform,Transform>::run(*this,other);
  }
  
  // Identity transformation
  EIGEN_DEVICE_FUNC void setIdentity() { m_matrix.setIdentity(); }
  EIGEN_DEVICE_FUNC static const Transform Identity()
  {
    return Transform(MatrixType::Identity());
  }
  
  // Scaling, translation, and rotation operations
  template<typename OtherDerived>
  EIGEN_DEVICE_FUNC inline Transform& scale(const MatrixBase<OtherDerived> &other);
  
  EIGEN_DEVICE_FUNC inline Transform& scale(const Scalar& s);
  
  template<typename OtherDerived>
  EIGEN_DEVICE_FUNC inline Transform& translate(const MatrixBase<OtherDerived> &other);
  
  template<typename RotationType>
  EIGEN_DEVICE_FUNC inline Transform& rotate(const RotationType& rotation);
  
  // Inverse transformation
  EIGEN_DEVICE_FUNC inline Transform inverse(TransformTraits traits = (TransformTraits)Mode) const;
  
  // Decomposition methods
  template<typename RotationMatrixType, typename ScalingMatrixType>
  EIGEN_DEVICE_FUNC void computeRotationScaling(RotationMatrixType *rotation, 
                                              ScalingMatrixType *scaling) const;
  
  template<typename ScalingMatrixType, typename RotationMatrixType>
  EIGEN_DEVICE_FUNC void computeScalingRotation(ScalingMatrixType *scaling, 
                                              RotationMatrixType *rotation) const;
  
  // Returns the rotation part
  typedef typename internal::conditional<int(Mode)==Isometry,ConstLinearPart,
                                       const LinearMatrixType>::type RotationReturnType;
  EIGEN_DEVICE_FUNC RotationReturnType rotation() const;
};
```

Key implementation details:
- Supports different transformation modes:
  - `Isometry`: Preserves distances (rotation + translation)
  - `Affine`: Linear transformation + translation
  - `AffineCompact`: Affine with compact storage
  - `Projective`: General projective transformation
- Stores the transformation as a matrix
- Provides methods to access and modify components
- Implements transformation composition through matrix multiplication
- Provides methods for scaling, translation, and rotation
- Implements inverse computation based on transformation type:
  ```cpp
  template<typename Scalar, int Dim, int Mode, int Options>
  Transform<Scalar,Dim,Mode,Options>
  Transform<Scalar,Dim,Mode,Options>::inverse(TransformTraits hint) const
  {
    Transform res;
    if (hint == Projective)
    {
      // Full matrix inverse for projective transformations
      res.matrix() = m_matrix.inverse();
    }
    else
    {
      if (hint == Isometry)
      {
        // For isometries, the inverse rotation is the transpose
        res.matrix().template topLeftCorner<Dim,Dim>() = linear().transpose();
      }
      else if(hint&Affine)
      {
        // For affine transformations, invert the linear part
        res.matrix().template topLeftCorner<Dim,Dim>() = linear().inverse();
      }
      // Compute the translation part of the inverse
      res.matrix().template topRightCorner<Dim,1>()
        = - res.matrix().template topLeftCorner<Dim,Dim>() * translation();
      res.makeAffine(); // Set the last row to [0 ... 0 1]
    }
    return res;
  }
  ```
- Provides decomposition methods to extract rotation and scaling components

## 3. Geometric Primitives

### 3.1 Hyperplane

`Hyperplane` represents a hyperplane in n-dimensional space:

```cpp
template <typename _Scalar, int _AmbientDim, int _Options>
class Hyperplane
{
public:
  enum {
    AmbientDimAtCompileTime = _AmbientDim
  };
  typedef _Scalar Scalar;
  typedef Matrix<Scalar,AmbientDimAtCompileTime,1> VectorType;
  typedef Matrix<Scalar,AmbientDimAtCompileTime+1,1,Options> Coefficients;
  
protected:
  Coefficients m_coeffs;
  
public:
  // Default constructor without initialization
  EIGEN_DEVICE_FUNC inline Hyperplane() {}
  
  // Constructs a dynamic-size hyperplane
  EIGEN_DEVICE_FUNC inline explicit Hyperplane(Index _dim) : m_coeffs(_dim+1) {}
  
  // Constructs from normal and point
  EIGEN_DEVICE_FUNC inline Hyperplane(const VectorType& n, const VectorType& e)
    : m_coeffs(n.size()+1)
  {
    normal() = n;
    offset() = -n.dot(e);
  }
  
  // Constructs from normal and distance to origin
  EIGEN_DEVICE_FUNC inline Hyperplane(const VectorType& n, const Scalar& d)
    : m_coeffs(n.size()+1)
  {
    normal() = n;
    offset() = d;
  }
  
  // Static methods to construct from points
  EIGEN_DEVICE_FUNC static inline Hyperplane Through(const VectorType& p0, const VectorType& p1);
  EIGEN_DEVICE_FUNC static inline Hyperplane Through(const VectorType& p0, 
                                                   const VectorType& p1, 
                                                   const VectorType& p2);
  
  // Dimension of the ambient space
  EIGEN_DEVICE_FUNC inline Index dim() const { return AmbientDimAtCompileTime==Dynamic ? 
                                             m_coeffs.size()-1 : Index(AmbientDimAtCompileTime); }
  
  // Normalization
  EIGEN_DEVICE_FUNC void normalize(void)
  {
    m_coeffs /= normal().norm();
  }
  
  // Distance calculations
  EIGEN_DEVICE_FUNC inline Scalar signedDistance(const VectorType& p) const 
  { return normal().dot(p) + offset(); }
  
  EIGEN_DEVICE_FUNC inline Scalar absDistance(const VectorType& p) const 
  { return numext::abs(signedDistance(p)); }
  
  // Projection onto the hyperplane
  EIGEN_DEVICE_FUNC inline VectorType projection(const VectorType& p) const 
  { return p - signedDistance(p) * normal(); }
  
  // Access to components
  EIGEN_DEVICE_FUNC inline ConstNormalReturnType normal() const 
  { return ConstNormalReturnType(m_coeffs,0,0,dim(),1); }
  
  EIGEN_DEVICE_FUNC inline NormalReturnType normal() 
  { return NormalReturnType(m_coeffs,0,0,dim(),1); }
  
  EIGEN_DEVICE_FUNC inline const Scalar& offset() const { return m_coeffs.coeff(dim()); }
  EIGEN_DEVICE_FUNC inline Scalar& offset() { return m_coeffs(dim()); }
  
  // Access to coefficients
  EIGEN_DEVICE_FUNC inline const Coefficients& coeffs() const { return m_coeffs; }
  EIGEN_DEVICE_FUNC inline Coefficients& coeffs() { return m_coeffs; }
  
  // Intersection with another hyperplane (for 2D only)
  EIGEN_DEVICE_FUNC VectorType intersection(const Hyperplane& other) const;
  
  // Transformation
  template<typename XprType>
  EIGEN_DEVICE_FUNC inline Hyperplane& transform(const MatrixBase<XprType>& mat, 
                                               TransformTraits traits = Affine);
  
  template<int TrOptions>
  EIGEN_DEVICE_FUNC inline Hyperplane& transform(
    const Transform<Scalar,AmbientDimAtCompileTime,Affine,TrOptions>& t,
    TransformTraits traits = Affine);
};
```

Key implementation details:
- Represents a hyperplane as a normal vector and offset from origin
- Provides methods to construct from points
- Implements distance calculations and projections
- Supports transformation by matrices and Transform objects
- Implements intersection for 2D hyperplanes (lines)

### 3.2 ParametrizedLine

`ParametrizedLine` represents a parametrized line in n-dimensional space:

```cpp
template <typename _Scalar, int _AmbientDim, int _Options>
class ParametrizedLine
{
public:
  enum {
    AmbientDimAtCompileTime = _AmbientDim
  };
  typedef _Scalar Scalar;
  typedef Matrix<Scalar,AmbientDimAtCompileTime,1,Options> VectorType;
  
protected:
  VectorType m_origin, m_direction;
  
public:
  // Default constructor without initialization
  EIGEN_DEVICE_FUNC inline ParametrizedLine() {}
  
  // Constructs a dynamic-size line
  EIGEN_DEVICE_FUNC inline explicit ParametrizedLine(Index _dim) : m_origin(_dim), m_direction(_dim) {}
  
  // Initializes from origin and direction
  EIGEN_DEVICE_FUNC ParametrizedLine(const VectorType& origin, const VectorType& direction)
    : m_origin(origin), m_direction(direction) {}
  
  // Constructs from a 2D hyperplane
  template <int OtherOptions>
  EIGEN_DEVICE_FUNC explicit ParametrizedLine(
    const Hyperplane<_Scalar, _AmbientDim, OtherOptions>& hyperplane);
  
  // Constructs a line through two points
  EIGEN_DEVICE_FUNC static inline ParametrizedLine Through(const VectorType& p0, const VectorType& p1)
  { return ParametrizedLine(p0, (p1-p0).normalized()); }
  
  // Dimension of the ambient space
  EIGEN_DEVICE_FUNC inline Index dim() const { return m_direction.size(); }
  
  // Access to components
  EIGEN_DEVICE_FUNC const VectorType& origin() const { return m_origin; }
  EIGEN_DEVICE_FUNC VectorType& origin() { return m_origin; }
  
  EIGEN_DEVICE_FUNC const VectorType& direction() const { return m_direction; }
  EIGEN_DEVICE_FUNC VectorType& direction() { return m_direction; }
  
  // Distance calculations
  EIGEN_DEVICE_FUNC RealScalar squaredDistance(const VectorType& p) const
  {
    VectorType diff = p - origin();
    return (diff - direction().dot(diff) * direction()).squaredNorm();
  }
  
  EIGEN_DEVICE_FUNC RealScalar distance(const VectorType& p) const 
  { return sqrt(squaredDistance(p)); }
  
  // Projection onto the line
  EIGEN_DEVICE_FUNC VectorType projection(const VectorType& p) const
  { return origin() + direction().dot(p-origin()) * direction(); }
  
  // Point at a given parameter value
  EIGEN_DEVICE_FUNC VectorType pointAt(const Scalar& t) const;
  
  // Intersection with hyperplane
  template <int OtherOptions>
  EIGEN_DEVICE_FUNC Scalar intersectionParameter(
    const Hyperplane<_Scalar, _AmbientDim, OtherOptions>& hyperplane) const;
  
  template <int OtherOptions>
  EIGEN_DEVICE_FUNC VectorType intersectionPoint(
    const Hyperplane<_Scalar, _AmbientDim, OtherOptions>& hyperplane) const;
  
  // Transformation
  template<typename XprType>
  EIGEN_DEVICE_FUNC inline ParametrizedLine& transform(const MatrixBase<XprType>& mat, 
                                                     TransformTraits traits = Affine);
  
  template<int TrOptions>
  EIGEN_DEVICE_FUNC inline ParametrizedLine& transform(
    const Transform<Scalar,AmbientDimAtCompileTime,Affine,TrOptions>& t,
    TransformTraits traits = Affine);
};
```

Key implementation details:
- Represents a line as an origin point and a unit direction vector
- Provides methods to construct from points or hyperplanes
- Implements distance calculations and projections
- Computes points along the line using the parameter
- Calculates intersections with hyperplanes
- Supports transformation by matrices and Transform objects

### 3.3 AlignedBox

`AlignedBox` represents an axis-aligned box in n-dimensional space:

```cpp
template <typename _Scalar, int _AmbientDim>
class AlignedBox
{
public:
  enum { AmbientDimAtCompileTime = _AmbientDim };
  typedef _Scalar Scalar;
  typedef Matrix<Scalar,AmbientDimAtCompileTime,1> VectorType;
  
  // Corner identifiers for 1D, 2D, and 3D boxes
  enum CornerType {
    // 1D names
    Min=0, Max=1,
    
    // 2D corners
    BottomLeft=0, BottomRight=1,
    TopLeft=2, TopRight=3,
    
    // 3D corners
    BottomLeftFloor=0, BottomRightFloor=1,
    TopLeftFloor=2, TopRightFloor=3,
    BottomLeftCeil=4, BottomRightCeil=5,
    TopLeftCeil=6, TopRightCeil=7
  };
  
protected:
  VectorType m_min, m_max;
  
public:
  // Default constructor initializing a null box
  EIGEN_DEVICE_FUNC inline AlignedBox()
  { if (EIGEN_CONST_CONDITIONAL(AmbientDimAtCompileTime!=Dynamic)) setEmpty(); }
  
  // Constructs a null box with given dimension
  EIGEN_DEVICE_FUNC inline explicit AlignedBox(Index _dim) : m_min(_dim), m_max(_dim)
  { setEmpty(); }
  
  // Constructs a box with extremities min and max
  template<typename OtherVectorType1, typename OtherVectorType2>
  EIGEN_DEVICE_FUNC inline AlignedBox(const OtherVectorType1& min, const OtherVectorType2& max) 
    : m_min(min), m_max(max) {}
  
  // Constructs a box containing a single point
  template<typename Derived>
  EIGEN_DEVICE_FUNC inline explicit AlignedBox(const MatrixBase<Derived>& p) 
    : m_min(p), m_max(m_min) {}
  
  // Dimension of the ambient space
  EIGEN_DEVICE_FUNC inline Index dim() const 
  { return AmbientDimAtCompileTime==Dynamic ? m_min.size() : Index(AmbientDimAtCompileTime); }
  
  // Empty box checks and operations
  EIGEN_DEVICE_FUNC inline bool isEmpty() const { return (m_min.array() > m_max.array()).any(); }
  EIGEN_DEVICE_FUNC inline void setEmpty()
  {
    m_min.setConstant( ScalarTraits::highest() );
    m_max.setConstant( ScalarTraits::lowest() );
  }
  
  // Access to corners
  EIGEN_DEVICE_FUNC inline const VectorType& (min)() const { return m_min; }
  EIGEN_DEVICE_FUNC inline VectorType& (min)() { return m_min; }
  EIGEN_DEVICE_FUNC inline const VectorType& (max)() const { return m_max; }
  EIGEN_DEVICE_FUNC inline VectorType& (max)() { return m_max; }
  
  // Box properties
  EIGEN_DEVICE_FUNC inline const EIGEN_EXPR_BINARYOP_SCALAR_RETURN_TYPE(VectorTypeSum, RealScalar, quotient)
  center() const { return (m_min+m_max)/RealScalar(2); }
  
  EIGEN_DEVICE_FUNC inline const CwiseBinaryOp<internal::scalar_difference_op<Scalar,Scalar>, 
                                             const VectorType, const VectorType> 
  sizes() const { return m_max - m_min; }
  
  EIGEN_DEVICE_FUNC inline Scalar volume() const { return sizes().prod(); }
  
  EIGEN_DEVICE_FUNC inline CwiseBinaryOp<internal::scalar_difference_op<Scalar,Scalar>, 
                                       const VectorType, const VectorType> 
  diagonal() const { return sizes(); }
  
  // Access to corners by index
  EIGEN_DEVICE_FUNC inline VectorType corner(CornerType corner) const;
  
  // Random point inside the box
  EIGEN_DEVICE_FUNC inline VectorType sample() const;
  
  // Containment tests
  template<typename Derived>
  EIGEN_DEVICE_FUNC inline bool contains(const MatrixBase<Derived>& p) const
  {
    return (m_min.array()<=p.array()).all() && (p.array()<=m_max.array()).all();
  }
  
  EIGEN_DEVICE_FUNC inline bool contains(const AlignedBox& b) const
  { return (m_min.array()<=(b.min)().array()).all() && ((b.max)().array()<=m_max.array()).all(); }
  
  // Intersection test
  EIGEN_DEVICE_FUNC inline bool intersects(const AlignedBox& b) const
  { return (m_min.array()<=(b.max)().array()).all() && ((b.min)().array()<=m_max.array()).all(); }
  
  // Box operations
  template<typename Derived>
  EIGEN_DEVICE_FUNC inline AlignedBox& extend(const MatrixBase<Derived>& p)
  {
    m_min = m_min.cwiseMin(p);
    m_max = m_max.cwiseMax(p);
    return *this;
  }
  
  EIGEN_DEVICE_FUNC inline AlignedBox& extend(const AlignedBox& b)
  {
    m_min = m_min.cwiseMin(b.m_min);
    m_max = m_max.cwiseMax(b.m_max);
    return *this;
  }
  
  EIGEN_DEVICE_FUNC inline AlignedBox& clamp(const AlignedBox& b)
  {
    m_min = m_min.cwiseMax(b.m_min);
    m_max = m_max.cwiseMin(b.m_max);
    return *this;
  }
  
  EIGEN_DEVICE_FUNC inline AlignedBox intersection(const AlignedBox& b) const
  {return AlignedBox(m_min.cwiseMax(b.m_min), m_max.cwiseMin(b.m_max)); }
  
  EIGEN_DEVICE_FUNC inline AlignedBox merged(const AlignedBox& b) const
  { return AlignedBox(m_min.cwiseMin(b.m_min), m_max.cwiseMax(b.m_max)); }
  
  // Translation
  template<typename Derived>
  EIGEN_DEVICE_FUNC inline AlignedBox& translate(const MatrixBase<Derived>& a_t)
  {
    const typename internal::nested_eval<Derived,2>::type t(a_t.derived());
    m_min += t;
    m_max += t;
    return *this;
  }
  
  template<typename Derived>
  EIGEN_DEVICE_FUNC inline AlignedBox translated(const MatrixBase<Derived>& a_t) const
  {
    AlignedBox result(m_min, m_max);
    result.translate(a_t);
    return result;
  }
  
  // Distance calculations
  template<typename Derived>
  EIGEN_DEVICE_FUNC inline Scalar squaredExteriorDistance(const MatrixBase<Derived>& p) const;
  
  EIGEN_DEVICE_FUNC inline Scalar squaredExteriorDistance(const AlignedBox& b) const;
  
  template<typename Derived>
  EIGEN_DEVICE_FUNC inline NonInteger exteriorDistance(const MatrixBase<Derived>& p) const
  { return sqrt(NonInteger(squaredExteriorDistance(p))); }
  
  EIGEN_DEVICE_FUNC inline NonInteger exteriorDistance(const AlignedBox& b) const
  { return sqrt(NonInteger(squaredExteriorDistance(b))); }
  
  // Transformation
  template<int Mode, int Options>
  EIGEN_DEVICE_FUNC inline void transform(
    const Transform<Scalar, AmbientDimAtCompileTime, Mode, Options>& transform);
  
  template<int Mode, int Options>
  EIGEN_DEVICE_FUNC AlignedBox transformed(
    const Transform<Scalar, AmbientDimAtCompileTime, Mode, Options>& transform) const
  {
    AlignedBox result(m_min, m_max);
    result.transform(transform);
    return result;
  }
};
```

Key implementation details:
- Represents a box as minimum and maximum corner points
- Provides methods to check if the box is empty
- Implements containment and intersection tests
- Supports operations like extend, clamp, intersection, and merge
- Calculates distances to points and other boxes
- Handles transformation by Transform objects:
  ```cpp
  template<typename Scalar, int Dim, int Mode, int Options>
  EIGEN_DEVICE_FUNC inline void AlignedBox<Scalar,Dim>::transform(
      const Transform<Scalar, AmbientDimAtCompileTime, Mode, Options>& transform)
  {
    // Only Affine and Isometry transforms are currently supported
    EIGEN_STATIC_ASSERT(Mode == Affine || Mode == AffineCompact || Mode == Isometry, 
                       THIS_METHOD_IS_ONLY_FOR_SPECIFIC_TRANSFORMATIONS);
    
    // Method adapted from FCL
    // Two times rotated extent
    const VectorType rotated_extent_2 = transform.linear().cwiseAbs() * sizes();
    // Two times new center
    const VectorType rotated_center_2 = transform.linear() * (this->m_max + this->m_min) +
        Scalar(2) * transform.translation();
    
    this->m_max = (rotated_center_2 + rotated_extent_2) / Scalar(2);
    this->m_min = (rotated_center_2 - rotated_extent_2) / Scalar(2);
  }
  ```

## 4. Utility Functions

### 4.1 Umeyama Algorithm

The Umeyama algorithm finds the transformation between two point sets:

```cpp
template<typename Derived, typename OtherDerived>
typename internal::umeyama_transform_matrix_type<Derived, OtherDerived>::type
umeyama(const MatrixBase<Derived>& src, const MatrixBase<OtherDerived>& dst, bool with_scaling = true)
{
  typedef typename internal::umeyama_transform_matrix_type<Derived, OtherDerived>::type TransformationMatrixType;
  typedef typename internal::traits<TransformationMatrixType>::Scalar Scalar;
  typedef typename NumTraits<Scalar>::Real RealScalar;
  
  enum { Dimension = EIGEN_SIZE_MIN_PREFER_DYNAMIC(Derived::RowsAtCompileTime, 
                                                 OtherDerived::RowsAtCompileTime) };
  
  typedef Matrix<Scalar, Dimension, 1> VectorType;
  typedef Matrix<Scalar, Dimension, Dimension> MatrixType;
  
  const Index m = src.rows(); // dimension
  const Index n = src.cols(); // number of measurements
  
  // Compute mean
  const RealScalar one_over_n = RealScalar(1) / static_cast<RealScalar>(n);
  const VectorType src_mean = src.rowwise().sum() * one_over_n;
  const VectorType dst_mean = dst.rowwise().sum() * one_over_n;
  
  // Compute demeaned matrices
  const RowMajorMatrixType src_demean = src.colwise() - src_mean;
  const RowMajorMatrixType dst_demean = dst.colwise() - dst_mean;
  
  // Compute variance of source points
  const Scalar src_var = src_demean.rowwise().squaredNorm().sum() * one_over_n;
  
  // Compute covariance matrix
  const MatrixType sigma = one_over_n * dst_demean * src_demean.transpose();
  
  // SVD of covariance matrix
  JacobiSVD<MatrixType> svd(sigma, ComputeFullU | ComputeFullV);
  
  // Initialize transformation matrix
  TransformationMatrixType Rt = TransformationMatrixType::Identity(m+1,m+1);
  
  // Compute rotation matrix
  VectorType S = VectorType::Ones(m);
  if (svd.matrixU().determinant() * svd.matrixV().determinant() < 0)
    S(m-1) = -1;
  
  Rt.block(0,0,m,m) = svd.matrixU() * S.asDiagonal() * svd.matrixV().transpose();
  
  if (with_scaling)
  {
    // Compute scaling factor
    const Scalar c = Scalar(1)/src_var * svd.singularValues().dot(S);
    
    // Compute translation
    Rt.col(m).head(m) = dst_mean;
    Rt.col(m).head(m).noalias() -= c*Rt.topLeftCorner(m,m)*src_mean;
    Rt.block(0,0,m,m) *= c;
  }
  else
  {
    // Compute translation without scaling
    Rt.col(m).head(m) = dst_mean;
    Rt.col(m).head(m).noalias() -= Rt.topLeftCorner(m,m)*src_mean;
  }
  
  return Rt;
}
```

Key implementation details:
- Finds the transformation between two point sets using SVD
- Computes the optimal rotation, translation, and optionally scaling
- Returns a homogeneous transformation matrix
- Handles the case where the determinant of the rotation matrix is negative

### 4.2 Euler Angles

Eigen provides methods to extract Euler angles from rotation matrices:

```cpp
template<typename Derived>
EIGEN_DEVICE_FUNC inline Matrix<typename MatrixBase<Derived>::Scalar,3,1>
MatrixBase<Derived>::eulerAngles(Index a0, Index a1, Index a2) const
{
  Matrix<Scalar,3,1> res;
  
  const Index odd = ((a0+1)%3 == a1) ? 0 : 1;
  const Index i = a0;
  const Index j = (a0 + 1 + odd)%3;
  const Index k = (a0 + 2 - odd)%3;
  
  if (a0==a2)
  {
    // Handle gimbal lock case
    res[0] = atan2(coeff(j,i), coeff(k,i));
    if((odd && res[0]<Scalar(0)) || ((!odd) && res[0]>Scalar(0)))
    {
      if(res[0] > Scalar(0)) {
        res[0] -= Scalar(EIGEN_PI);
      }
      else {
        res[0] += Scalar(EIGEN_PI);
      }
      Scalar s2 = Vector2(coeff(j,i), coeff(k,i)).norm();
      res[1] = -atan2(s2, coeff(i,i));
    }
    else
    {
      Scalar s2 = Vector2(coeff(j,i), coeff(k,i)).norm();
      res[1] = atan2(s2, coeff(i,i));
    }
    
    // Compute third angle
    Scalar s1 = sin(res[0]);
    Scalar c1 = cos(res[0]);
    res[2] = atan2(c1*coeff(j,k)-s1*coeff(k,k), c1*coeff(j,j) - s1 * coeff(k,j));
  } 
  else
  {
    // General case
    res[0] = atan2(coeff(j,k), coeff(k,k));
    Scalar c2 = Vector2(coeff(i,i), coeff(i,j)).norm();
    if((odd && res[0]<Scalar(0)) || ((!odd) && res[0]>Scalar(0))) {
      if(res[0] > Scalar(0)) {
        res[0] -= Scalar(EIGEN_PI);
      }
      else {
        res[0] += Scalar(EIGEN_PI);
      }
      res[1] = atan2(-coeff(i,k), -c2);
    }
    else
      res[1] = atan2(-coeff(i,k), c2);
    Scalar s1 = sin(res[0]);
    Scalar c1 = cos(res[0]);
    res[2] = atan2(s1*coeff(k,i)-c1*coeff(j,i), c1*coeff(j,j) - s1 * coeff(k,j));
  }
  if (!odd)
    res = -res;
  
  return res;
}
```

Key implementation details:
- Extracts Euler angles from a rotation matrix
- Supports different rotation sequences (e.g., XYZ, ZYX, ZYZ)
- Handles gimbal lock cases
- Returns angles in the ranges [0:pi]×[-pi:pi]×[-pi:pi]

### 4.3 Orthogonal Methods

Eigen provides methods for cross products and finding orthogonal vectors:

```cpp
// Cross product of two 3D vectors
template<typename Derived>
template<typename OtherDerived>
EIGEN_DEVICE_FUNC EIGEN_STRONG_INLINE
typename MatrixBase<Derived>::template cross_product_return_type<OtherDerived>::type
MatrixBase<Derived>::cross(const MatrixBase<OtherDerived>& other) const
{
  EIGEN_STATIC_ASSERT_VECTOR_SPECIFIC_SIZE(Derived,3)
  EIGEN_STATIC_ASSERT_VECTOR_SPECIFIC_SIZE(OtherDerived,3)
  
  typename internal::nested_eval<Derived,2>::type lhs(derived());
  typename internal::nested_eval<OtherDerived,2>::type rhs(other.derived());
  return typename cross_product_return_type<OtherDerived>::type(
    numext::conj(lhs.coeff(1) * rhs.coeff(2) - lhs.coeff(2) * rhs.coeff(1)),
    numext::conj(lhs.coeff(2) * rhs.coeff(0) - lhs.coeff(0) * rhs.coeff(2)),
    numext::conj(lhs.coeff(0) * rhs.coeff(1) - lhs.coeff(1) * rhs.coeff(0))
  );
}

// Find a unit vector orthogonal to the given vector
template<typename Derived>
EIGEN_DEVICE_FUNC typename MatrixBase<Derived>::PlainObject
MatrixBase<Derived>::unitOrthogonal() const
{
  EIGEN_STATIC_ASSERT_VECTOR_ONLY(Derived)
  return internal::unitOrthogonal_selector<Derived>::run(derived());
}
```

Key implementation details:
- Implements cross product for 3D vectors
- Provides optimized cross product for 4D vectors (using only x,y,z components)
- Implements methods to find unit vectors orthogonal to a given vector
- Handles special cases for 2D and 3D vectors

### 4.4 Homogeneous Coordinates

Eigen provides classes for working with homogeneous coordinates:

```cpp
template<typename MatrixType,int Direction>
class Homogeneous
{
public:
  typedef MatrixType NestedExpression;
  
  EIGEN_DEVICE_FUNC explicit inline Homogeneous(const MatrixType& matrix)
    : m_matrix(matrix)
  {}
  
  EIGEN_DEVICE_FUNC EIGEN_CONSTEXPR
  inline Index rows() const EIGEN_NOEXCEPT 
  { return m_matrix.rows() + (int(Direction)==Vertical ? 1 : 0); }
  
  EIGEN_DEVICE_FUNC EIGEN_CONSTEXPR
  inline Index cols() const EIGEN_NOEXCEPT 
  { return m_matrix.cols() + (int(Direction)==Horizontal ? 1 : 0); }
  
  EIGEN_DEVICE_FUNC const NestedExpression& nestedExpression() const { return m_matrix; }
  
protected:
  typename MatrixType::Nested m_matrix;
};
```

Key implementation details:
- Provides a way to convert between affine and homogeneous coordinates
- Supports both horizontal and vertical homogeneous extensions
- Implements matrix multiplication with homogeneous coordinates
- Provides methods to normalize homogeneous coordinates

## 5. Integration with Core Matrix Operations

The geometry module integrates seamlessly with Eigen's core matrix operations:

1. **Rotation representations** can be converted to/from matrices:
   ```cpp
   Matrix3f R = q.toRotationMatrix(); // Convert quaternion to matrix
   Quaternionf q(R);                  // Convert matrix to quaternion
   ```

2. **Transformations** can be applied to vectors and points:
   ```cpp
   Vector3f v_transformed = transform * v;  // Apply transform to vector
   ```

3. **Geometric primitives** can be transformed:
   ```cpp
   Hyperplane<float,3> plane;
   plane.transform(transform);  // Transform the hyperplane
   ```

4. **Specialized algorithms** exploit the structure of geometric objects:
   ```cpp
   // Efficient quaternion-vector multiplication
   Vector3f v_rotated = q._transformVector(v);
   
   // Optimized transformation composition
   Transform3f t3 = t1 * t2;  // Combines transformations efficiently
   ```

5. **Expression templates** are used throughout for lazy evaluation:
   ```cpp
   // No computation happens until the result is needed
   Transform3f t_combined = t1 * t2 * t3;
   ```

## 6. Key Optimizations

### 6.1 Quaternion Operations

Quaternion operations are highly optimized:

1. **Quaternion multiplication** uses a specialized implementation:
   ```cpp
   template<typename Scalar, int Arch, class Derived1, class Derived2>
   struct quat_product
   {
     static EIGEN_STRONG_INLINE Quaternion<Scalar> run(
       const QuaternionBase<Derived1>& a, const QuaternionBase<Derived2>& b)
     {
       // Optimized Hamilton product implementation
       return Quaternion<Scalar>
       (
         a.w() * b.w() - a.x() * b.x() - a.y() * b.y() - a.z() * b.z(),
         a.w() * b.x() + a.x() * b.w() + a.y() * b.z() - a.z() * b.y(),
         a.w() * b.y() + a.y() * b.w() + a.z() * b.x() - a.x() * b.z(),
         a.w() * b.z() + a.z() * b.w() + a.x() * b.y() - a.y() * b.x()
       );
     }
   };
   ```

2. **Vector rotation** by quaternions uses an optimized algorithm:
   ```cpp
   template <class Derived>
   typename QuaternionBase<Derived>::Vector3
   QuaternionBase<Derived>::_transformVector(const Vector3& v) const
   {
     // Optimized implementation of q * v * q^-1
     Vector3 uv = this->vec().cross(v);
     uv += uv;
     return v + this->w() * uv + this->vec().cross(uv);
   }
   ```

3. **Quaternion interpolation** uses spherical linear interpolation (slerp):
   ```cpp
   template <class Derived>
   template <class OtherDerived>
   Quaternion<typename internal::traits<Derived>::Scalar>
   QuaternionBase<Derived>::slerp(const Scalar& t, const QuaternionBase<OtherDerived>& other) const
   {
     // Optimized slerp implementation
     Scalar d = this->dot(other);
     Scalar absD = numext::abs(d);
     
     if(absD >= Scalar(1) - NumTraits<Scalar>::epsilon()) {
       // Quaternions are nearly parallel, use linear interpolation
       return Quaternion<Scalar>((Scalar(1) - t) * coeffs() + t * other.coeffs());
     } else {
       // Use spherical interpolation
       Scalar theta = acos(absD);
       Scalar sinTheta = sin(theta);
       
       Scalar scale0 = sin((Scalar(1) - t) * theta) / sinTheta;
       Scalar scale1 = sin(t * theta) / sinTheta;
       if(d < Scalar(0)) scale1 = -scale1;
       
       return Quaternion<Scalar>(scale0 * coeffs() + scale1 * other.coeffs());
     }
   }
   ```

### 6.2 Transform Optimizations

Transformations are optimized for different modes:

1. **Isometry** mode exploits the fact that the linear part is a rotation:
   ```cpp
   // For isometries, the inverse rotation is the transpose
   res.matrix().template topLeftCorner<Dim,Dim>() = linear().transpose();
   ```

2. **Affine** mode uses specialized matrix operations:
   ```cpp
   // For affine transformations, invert the linear part
   res.matrix().template topLeftCorner<Dim,Dim>() = linear().inverse();
   ```

3. **Transformation composition** is optimized based on transformation types:
   ```cpp
   template<typename Scalar, int Dim, int LhsMode, int LhsOptions, int RhsMode, int RhsOptions>
   struct transform_transform_product_impl<Transform<Scalar,Dim,LhsMode,LhsOptions>,
                                         Transform<Scalar,Dim,RhsMode,RhsOptions>,false>
   {
     enum { ResultMode = transform_product_result<LhsMode,RhsMode>::Mode };
     typedef Transform<Scalar,Dim,LhsMode,LhsOptions> Lhs;
     typedef Transform<Scalar,Dim,RhsMode,RhsOptions> Rhs;
     typedef Transform<Scalar,Dim,ResultMode,LhsOptions> ResultType;
     
     static ResultType run(const Lhs& lhs, const Rhs& rhs)
     {
       ResultType res;
       res.linear() = lhs.linear() * rhs.linear();
       res.translation() = lhs.linear() * rhs.translation() + lhs.translation();
       res.makeAffine();
       return res;
     }
   };
   ```

### 6.3 Memory Layout Optimizations

The geometry module uses efficient memory layouts:

1. **Quaternions** store components in a 4D vector for efficient SIMD operations
2. **Transformations** use different matrix sizes based on the transformation mode:
   - `Isometry` and `Affine`: (Dim+1) × (Dim+1) matrix with last row [0...0 1]
   - `AffineCompact`: Dim × (Dim+1) matrix (saves memory)
   - `Projective`: (Dim+1) × (Dim+1) matrix without constraints
3. **Geometric primitives** use compact representations:
   - `Hyperplane`: normal vector + offset
   - `ParametrizedLine`: origin point + direction vector
   - `AlignedBox`: min and max corner points

## 7. Common Use Cases and Examples

### 7.1 3D Rotations

```cpp
// Create rotations in different representations
AngleAxisf rotation_x(0.5, Vector3f::UnitX());
Quaternionf q(rotation_x);
Matrix3f R = q.toRotationMatrix();

// Convert between representations
AngleAxisf aa(R);
Quaternionf q2(aa);

// Rotate a vector
Vector3f v(1, 0, 0);
Vector3f v_rotated = q * v;  // Using quaternion
Vector3f v_rotated2 = R * v; // Using rotation matrix
Vector3f v_rotated3 = aa * v; // Using angle-axis

// Compose rotations
Quaternionf q_composed = q * q2;
AngleAxisf aa_composed = aa * aa;
```

### 7.2 3D Transformations

```cpp
// Create a transformation
Transform3f transform = Transform3f::Identity();
transform.translate(Vector3f(1, 2, 3));
transform.rotate(AngleAxisf(0.5, Vector3f::UnitX()));
transform.scale(2.0);

// Apply to a point
Vector3f p(1, 0, 0);
Vector3f p_transformed = transform * p;

// Compose transformations
Transform3f t1, t2;
Transform3f t_combined = t1 * t2;

// Inverse transformation
Transform3f t_inv = transform.inverse();
```

### 7.3 Geometric Primitives

```cpp
// Create a hyperplane (3D plane)
Hyperplane<float, 3> plane = Hyperplane<float, 3>::Through(
  Vector3f(0, 0, 0), Vector3f(1, 0, 0), Vector3f(0, 1, 0));

// Distance from a point to the plane
float dist = plane.signedDistance(Vector3f(1, 1, 1));

// Project a point onto the plane
Vector3f projected = plane.projection(Vector3f(1, 1, 1));

// Create a parametrized line
ParametrizedLine<float, 3> line = ParametrizedLine<float, 3>::Through(
  Vector3f(0, 0, 0), Vector3f(1, 1, 1));

// Point at a parameter value
Vector3f point = line.pointAt(2.0);

// Intersection of line and plane
Vector3f intersection = line.intersectionPoint(plane);

// Create an axis-aligned box
AlignedBox3f box(Vector3f(-1, -1, -1), Vector3f(1, 1, 1));

// Check if a point is inside
bool inside = box.contains(Vector3f(0, 0, 0));

// Extend the box to include a point
box.extend(Vector3f(2, 2, 2));
```

### 7.4 Homogeneous Coordinates

```cpp
// Convert a point to homogeneous coordinates
Vector3f p(1, 2, 3);
Vector4f p_h = p.homogeneous(); // [1, 2, 3, 1]

// Convert a vector to homogeneous coordinates
Vector3f v(1, 2, 3);
Vector4f v_h = v.homogeneous(); // [1, 2, 3, 0]

// Convert back from homogeneous coordinates
Vector3f p2 = p_h.hnormalized(); // [1, 2, 3]
```

## 8. Conclusion

Eigen's geometry module provides a comprehensive framework for 2D and 3D geometry operations. The key components include:

1. **Rotation representations**:
   - `Rotation2D`: Simple 2D rotation using a single angle
   - `AngleAxis`: 3D rotation around an arbitrary axis
   - `Quaternion`: Efficient representation for 3D rotations

2. **Transformation classes**:
   - `Translation`: Pure translation in n-dimensional space
   - `Transform`: General transformation with different modes (Isometry, Affine, Projective)

3. **Geometric primitives**:
   - `Hyperplane`: Hyperplane in n-dimensional space
   - `ParametrizedLine`: Line in n-dimensional space
   - `AlignedBox`: Axis-aligned box in n-dimensional space

4. **Utility functions**:
   - `umeyama`: Find transformation between point sets
   - Euler angles extraction
   - Cross products and orthogonal vectors
   - Homogeneous coordinate operations

The module is built on top of Eigen's matrix operations and leverages the library's expression templates, vectorization, and other optimizations. It provides a clean, intuitive interface for geometric operations while maintaining high performance.

Key strengths of the implementation include:
- Seamless integration with the rest of Eigen
- Efficient memory layouts and specialized algorithms
- Comprehensive set of geometric operations
- Support for different transformation types
- Robust handling of edge cases

The geometry module is particularly useful for applications in computer graphics, robotics, computer vision, and physics simulations where geometric transformations and operations are common.