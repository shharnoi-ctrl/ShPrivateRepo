# Generated from:

- Amazon-PrimeAir/items/ASTRO/items/sw/sw_pa_unit_testing/02_Unit_Testing_Framework.md (2574 tokens)
- Amazon-PrimeAir/items/ASTRO/items/sw/sw_pa_unit_testing/02_Project_Configuration.md (2565 tokens)
- Amazon-PrimeAir/items/ASTRO/items/sw/sw_pa_unit_testing/01_System_Level_Overview.md (3507 tokens)

---

# Prime Air Software System Overview

This document provides a high-level overview of the Amazon Prime Air software system, focusing on the unit testing framework and architecture. It serves as an entry point for understanding the system's structure and components.

## System Architecture

The Prime Air software system appears to be a sophisticated Guidance, Navigation, and Control (GNC) system designed for autonomous aerial delivery drones. The architecture follows a modular design with clear separation of concerns across multiple subsystems:

### Core Subsystems

1. **Controllers (Control Systems)**
   - Attitude Control Guidance
   - Trajectory Tracking Control
   - Wind-Aware Control Adaptation
   - Autonomous Flight Control
   - Control Mixing

2. **Navigation Systems**
   - System Initialization
   - Heading Determination
   - Sensor Data Processing
   - Ground Detection
   - State Estimation

3. **Trajectory Planning**
   - Waypoint Management
   - Maneuver Coordination (Roll, Straight, Hover, Turn)
   - Trajectory Generation

4. **Recovery Systems**
   - Recovery Controls
   - Route Construction
   - Mission Phase Management

5. **State Machines**
   - Flight Mode Management
   - Controller Status Management

6. **GNC Utilities**
   - Geographic Calculations
   - Flight Dynamics
   - Coordinate Transformations
   - Signal Processing

7. **State Space Models**
   - Dynamic Models
   - Gain-Scheduled Models

8. **Data Handling**
   - Serialization
   - Protocol Buffer Handling

### Technical Architecture

The system employs a layered architecture:

1. **Hardware Abstraction Layer**
   - Board Support Package (bsp)
   - Digital Signal Processor support (DSP28x, DSP2837x_ent)
   - Device interfaces

2. **Core System Components**
   - Base functionality
   - Foundation components (first)
   - System components (maverick, veronte)

3. **Functional Components**
   - System blocks
   - GNC components
   - System dynamics
   - Geographical modeling

4. **Testing Infrastructure**
   - Software-In-Loop (SIL) testing
   - Unit testing framework
   - Monitoring tests

## Unit Testing Framework

The Prime Air system includes a comprehensive unit testing framework (`sw_pa_unit_testing`) designed to validate all aspects of the GNC system.

### Key Features

- **Modular Test Organization**: Tests are organized by functional subsystem
- **Flexible Execution**: Tests can run individually or as a complete suite
- **Custom Memory Management**: Allocates dedicated memory pools (5MB internal, 100MB external)
- **Dual-Targeting**: Supports both hardware and Software-In-Loop (SIL) environments
- **Comprehensive Reporting**: Systematic collection and reporting of test results

### Test Registry System

The framework uses a registry system that:
- Maintains a collection of test functions mapped to their names
- Provides a consistent interface for test registration and execution
- Enables selective test execution based on command-line arguments

### Build Environment

- **Primary Configuration**: Headless_Debug (optimized for automated testing)
- **Build Type**: Debug (with maximum debug information)
- **Parallel Build**: Enabled for faster compilation

## Detailed Documentation

For more detailed information about specific components, refer to the following documents:

- [Unit Testing Framework](02_Unit_Testing_Framework.md) - Details on the test harness implementation
- [Project Configuration](02_Project_Configuration.md) - Eclipse project configuration details

## System Purpose

Based on the components and architecture, this system appears to be designed for the Amazon Prime Air delivery drone platform, with a focus on autonomous flight capabilities including:

1. Precise flight control for various maneuvers
2. Accurate navigation and positioning
3. Complex trajectory planning for delivery routes
4. Safety-critical recovery systems
5. State management for different flight modes

The comprehensive testing framework reflects the safety-critical nature of an autonomous aerial delivery system, where thorough validation of all components is essential for operational safety.