# Generated from:

- items/pdi_Monitor/setup/ver_spdif_vgeoref.xml (60 tokens)
- items/pdi_Monitor/setup/ver_spdif_agname.xml (63 tokens)
- items/pdi_Monitor/setup/ver_spdif_rpm.xml (309 tokens)
- items/pdi_Monitor/setup/ver_spdif_us76ex.xml (135 tokens)
- items/pdi_Monitor/setup/ver_spdif_nav.xml (57 tokens)
- items/pdi_Monitor/setup/ver_spdif_mvxmap.xml (62 tokens)
- items/pdi_Monitor/setup/ver_spdif_mstep.xml (57 tokens)
- items/pdi_Monitor/setup/ver_spdif_status.xml (72 tokens)
- items/pdi_Monitor/setup/ver_spdif_mstick.xml (51 tokens)
- items/pdi_Monitor/setup/ver_spdif_ubx0.xml (2696 tokens)
- items/pdi_Monitor/setup/ver_spdif_ubx1.xml (2691 tokens)
- items/pdi_Monitor/setup/ver_spdif_kf.xml (166 tokens)
- items/pdi_Monitor/setup/ver_spdif_mgeoref.xml (91 tokens)
- items/pdi_Monitor/setup/ver_spdif_amz_route.xml (1119 tokens)
- items/pdi_Monitor/setup/ver_spdif_vargps.xml (300 tokens)
- items/pdi_Monitor/setup/ver_spdif_pfields.xml (52 tokens)

## With context from:

- Amazon-PrimeAir/items/ASTRO/items/Monitor/07_System_Architecture.md (3174 tokens)
- Amazon-PrimeAir/items/ASTRO/items/Monitor/05_Sensor_Processing.md (6777 tokens)

---

# PDI Monitor Navigation Systems Analysis

## 1. GNSS Receiver Configuration and Operation

### 1.1 UBX0 Receiver Configuration (Primary GNSS)

The UBX0 receiver is configured as the primary GNSS receiver in the PDI Monitor system with the following key characteristics:

#### 1.1.1 Communication Interface Configuration
```xml
<port_spi>
    <port_id>1</port_id>
    <reserved0>0</reserved0>
    <tx_ready>0</tx_ready>
    <mode>2240</mode>
    <baudRate>115200</baudRate>
    <in_proto_mask>1</in_proto_mask>
    <out_proto_mask>1</out_proto_mask>
    <flags>0</flags>
</port_spi>
<port_sci>
    <port_id>1</port_id>
    <reserved0>0</reserved0>
    <tx_ready>0</tx_ready>
    <mode>2240</mode>
    <baudRate>115200</baudRate>
    <in_proto_mask>1</in_proto_mask>
    <out_proto_mask>1</out_proto_mask>
    <flags>0</flags>
</port_sci>
```
- Uses both SPI and SCI (Serial Communication Interface) ports
- Both interfaces operate at 115200 baud rate
- Protocol mask set to 1 (UBX protocol) for both input and output
- Port mode 2240 indicates specific configuration parameters for the communication interface

#### 1.1.2 Navigation Engine Configuration
```xml
<nav5>
    <mask>1463</mask>
    <dynmodel>8</dynmodel>
    <fixmode>2</fixmode>
    <fixedAlt>0</fixedAlt>
    <fixedAltVar>1</fixedAltVar>
    <minElev>5</minElev>
    <pDop>2500</pDop>
    <tDop>10000</tDop>
    <pAcc>100</pAcc>
    <tAcc>100</tAcc>
    <staticHoldThresh>0</staticHoldThresh>
    <dgnssTimeout>60</dgnssTimeout>
    <cnoThreshNumSVs>4</cnoThreshNumSVs>
    <cnoThresh>0</cnoThresh>
    <staticHoldMaxDist>0</staticHoldMaxDist>
    <utcStandard>0</utcStandard>
</nav5>
```
- Dynamic model 8 (airborne with <4g acceleration) - optimized for aerial vehicle operation
- Fix mode 2 (3D only) - requires altitude calculation from satellite data
- Minimum elevation angle of 5 degrees for satellite visibility
- Position DOP (Dilution of Precision) limit of 25.00 (pDop: 2500)
- Time DOP limit of 100.00 (tDop: 10000)
- Position accuracy limit of 100 meters
- Time accuracy limit of 100 nanoseconds
- DGNSS timeout of 60 seconds
- Requires at least 4 satellites with sufficient signal strength

#### 1.1.3 Extended Navigation Configuration
```xml
<navx5>
    <version>2</version>
    <mask1>26188</mask1>
    <mask2>0</mask2>
    <minSVs>4</minSVs>
    <maxSVs>20</maxSVs>
    <minCNO>6</minCNO>
    <iniFix3D>1</iniFix3D>
    <ackAiding>1</ackAiding>
    <wknRollover>0</wknRollover>
    <sigAttenCompMode>0</sigAttenCompMode>
    <ppp>0</ppp>
    <aopCfg>0</aopCfg>
    <aopOrbMaxErr>0</aopOrbMaxErr>
    <useAdr>0</useAdr>
</navx5>
```
- Minimum of 4 satellites required for a fix
- Maximum of 20 satellites used for navigation solution
- Minimum carrier-to-noise ratio (CNO) of 6 dB-Hz
- Initial 3D fix enabled
- Acknowledge aiding messages enabled
- Precise Point Positioning (PPP) disabled
- AssistNow Autonomous (AOP) disabled
- Automatic Dead Reckoning (ADR) disabled

#### 1.1.4 GNSS System Configuration
```xml
<gnss>
    <msgver>0</msgver>
    <numtrkchhw>0</numtrkchhw>
    <numtrkchuse>255</numtrkchuse>
    <numcfgblks>6</numcfgblks>
    <cfgblocks>
        <GPS>
            <gnssid>0</gnssid>
            <restrkch>8</restrkch>
            <maxtrkch>16</maxtrkch>
            <reserved>0</reserved>
            <flags>17891329</flags>
        </GPS>
        <QZSS>
            <gnssid>5</gnssid>
            <restrkch>0</restrkch>
            <maxtrkch>3</maxtrkch>
            <reserved>0</reserved>
            <flags>17891329</flags>
        </QZSS>
        <GLONASS>
            <gnssid>6</gnssid>
            <restrkch>8</restrkch>
            <maxtrkch>14</maxtrkch>
            <reserved>0</reserved>
            <flags>17891329</flags>
        </GLONASS>
        <BeiDou>
            <gnssid>3</gnssid>
            <restrkch>2</restrkch>
            <maxtrkch>5</maxtrkch>
            <reserved>0</reserved>
            <flags>17891329</flags>
        </BeiDou>
        <SBAS>
            <gnssid>1</gnssid>
            <restrkch>3</restrkch>
            <maxtrkch>3</maxtrkch>
            <reserved>0</reserved>
            <flags>16842753</flags>
        </SBAS>
        <Galileo>
            <gnssid>2</gnssid>
            <restrkch>10</restrkch>
            <maxtrkch>18</maxtrkch>
            <reserved>0</reserved>
            <flags>18939905</flags>
        </Galileo>
    </cfgblocks>
</gnss>
```
- Multi-constellation GNSS configuration with:
  - GPS: 8 reserved channels, maximum 16 tracking channels
  - GLONASS: 8 reserved channels, maximum 14 tracking channels
  - Galileo: 10 reserved channels, maximum 18 tracking channels
  - BeiDou: 2 reserved channels, maximum 5 tracking channels
  - QZSS: 0 reserved channels, maximum 3 tracking channels
  - SBAS: 3 reserved channels, maximum 3 tracking channels
- All systems enabled with similar flag configurations (17891329), except:
  - SBAS with flags 16842753
  - Galileo with flags 18939905
- These flag differences likely indicate different signal processing parameters for each constellation

#### 1.1.5 Timing Mode Configuration
```xml
<tmode3>
    <version>0</version>
    <reserved0>0</reserved0>
    <mode_flags>0</mode_flags>
    <ecef_x_or_lat>0</ecef_x_or_lat>
    <ecef_y_or_lon>0</ecef_y_or_lon>
    <ecef_z_or_alt>0</ecef_z_or_alt>
    <ecef_x_or_lat_hp>0</ecef_x_or_lat_hp>
    <ecef_y_or_lon_hp>0</ecef_y_or_lon_hp>
    <ecef_z_or_alt_hp>0</ecef_z_or_alt_hp>
    <reserved1>0</reserved1>
    <fixed_pos_acc>0</fixed_pos_acc>
    <svin_min_dur>0</svin_min_dur>
    <svin_acc_limit>0</svin_acc_limit>
</tmode3>
```
- Timing mode disabled (mode_flags: 0)
- No fixed position coordinates specified
- Survey-in parameters not configured

#### 1.1.6 SBAS Configuration
```xml
<sbas>
    <mode>3</mode>
    <usage>7</usage>
    <maxSbas>3</maxSbas>
    <scanMode2>0</scanMode2>
    <scanMode1>0</scanMode1>
</sbas>
```
- SBAS mode 3 (enabled)
- Usage 7 (range, differential corrections, and integrity information)
- Maximum of 3 SBAS satellites tracked simultaneously
- No specific scan mode configured

#### 1.1.7 Interference Mitigation
```xml
<itfm>
    <config>761441280</config>
    <config2>52297728</config2>
</itfm>
```
- Interference detection and mitigation enabled with specific configuration parameters

#### 1.1.8 Measurement Rate Configuration
```xml
<cfg_rate>
    <measRate>250</measRate>
    <navRate>1</navRate>
    <timeRef>1</timeRef>
</cfg_rate>
```
- Measurement rate of 250ms (4Hz)
- Navigation rate of 1 (one navigation solution per measurement)
- Time reference set to 1 (GPS time)

#### 1.1.9 Message Output Configuration
UBX0 is configured to output several specific message types:
- NAV-STATUS messages enabled on UART1
- NAV-PVT (Position, Velocity, Time) messages enabled on UART1
- NAV-TIMEGPS messages enabled on UART1 with rate 4
- RXM-SFRBX (Subframe Buffer) messages enabled on UART1
- RXM-RAWX (Raw Measurement) messages enabled on UART1

### 1.2 UBX1 Receiver Configuration (Secondary GNSS)

The UBX1 receiver is configured as a secondary GNSS receiver with some differences from UBX0:

#### 1.2.1 Communication Interface Configuration
```xml
<port_spi>
    <port_id>4</port_id>
    <reserved0>0</reserved0>
    <tx_ready>0</tx_ready>
    <mode>0</mode>
    <baudRate>0</baudRate>
    <in_proto_mask>1</in_proto_mask>
    <out_proto_mask>1</out_proto_mask>
    <flags>0</flags>
</port_spi>
<port_sci>
    <port_id>2</port_id>
    <reserved0>0</reserved0>
    <tx_ready>0</tx_ready>
    <mode>2256</mode>
    <baudRate>38400</baudRate>
    <in_proto_mask>0</in_proto_mask>
    <out_proto_mask>0</out_proto_mask>
    <flags>0</flags>
</port_sci>
```
- SPI port configured differently (port_id: 4) with mode 0
- SCI port uses port_id 2 with 38400 baud rate
- SCI port has protocol masks set to 0 (disabled)
- Different port mode (2256) for SCI

#### 1.2.2 Measurement Rate Configuration
```xml
<cfg_rate>
    <measRate>500</measRate>
    <navRate>1</navRate>
    <timeRef>1</timeRef>
</cfg_rate>
```
- Slower measurement rate of 500ms (2Hz) compared to UBX0's 4Hz

#### 1.2.3 Message Output Configuration
UBX1 has different message output configuration:
- NAV-STATUS messages enabled with rate 1
- NAV-PVT messages enabled with rate 1
- NAV-TIMEGPS messages enabled with rate 8
- RXM-RAWX messages enabled on UART1

#### 1.2.4 Interference Mitigation
```xml
<itfm>
    <config>0</config>
    <config2>0</config2>
</itfm>
```
- Interference detection and mitigation disabled (unlike UBX0)

### 1.3 Dual-GNSS Receiver Architecture

The configuration of UBX0 and UBX1 reveals a dual-GNSS receiver architecture with the following characteristics:

1. **Primary-Secondary Configuration**:
   - UBX0 is configured as the primary receiver with more active message outputs
   - UBX1 is configured as a secondary/backup receiver with fewer active messages

2. **Complementary Sampling Rates**:
   - UBX0: 4Hz measurement rate
   - UBX1: 2Hz measurement rate
   - This provides both high-frequency updates and redundancy

3. **Different Communication Interfaces**:
   - UBX0: Active on both SPI and SCI with 115200 baud
   - UBX1: SPI configured differently, SCI at 38400 baud with protocols disabled

4. **Identical Navigation Parameters**:
   - Both use the same dynamic model (airborne <4g)
   - Both use the same satellite constellation configuration
   - Both require 3D fixes with similar accuracy parameters

5. **Different Interference Handling**:
   - UBX0: Active interference mitigation
   - UBX1: Interference mitigation disabled

This dual-receiver setup provides redundancy, increased satellite visibility, and the potential for advanced positioning techniques like differential GNSS.

## 2. Georeferencing System

### 2.1 Virtual Georeferencing Configuration

```xml
<entry-vgeoref>
    <id>57</id>
    <filename>vgeoref.bin</filename>
    <version>
        <major>7</major>
        <minor>1</minor>
        <revision>1</revision>
    </version>
    <data>
        <drn>10.0</drn>
    </data>
</entry-vgeoref>
```

The virtual georeferencing system has a simple configuration with a single parameter:
- `drn`: 10.0 - Likely represents a distance reference number or deadreckoning parameter

### 2.2 Manual Georeferencing Configuration

```xml
<entry-mgeoref>
    <id>135</id>
    <filename>mgeoref.bin</filename>
    <version>
        <major>7</major>
        <minor>1</minor>
        <revision>1</revision>
    </version>
    <data>
        <size>4</size>
        <isAutoGeoref>1</isAutoGeoref>
        <marginGeoref>0.2</marginGeoref>
        <isAutoMagfield>1</isAutoMagfield>
    </data>
</entry-mgeoref>
```

The manual georeferencing configuration includes:
- `size`: 4 - Likely indicates the number of georeferencing points or parameters
- `isAutoGeoref`: 1 - Automatic georeferencing is enabled
- `marginGeoref`: 0.2 - Margin parameter for georeferencing, possibly in meters
- `isAutoMagfield`: 1 - Automatic magnetic field calibration is enabled

This configuration suggests that the system can automatically determine its georeference and magnetic field parameters, with a margin of 0.2 units (likely meters) for georeferencing accuracy.

### 2.3 Navigation System Enablement

```xml
<entry-nav>
    <id>104</id>
    <filename>nav.bin</filename>
    <version>
        <major>7</major>
        <minor>1</minor>
        <revision>1</revision>
    </version>
    <data>
        <nav>1</nav>
    </data>
</entry-nav>
```

The navigation system is explicitly enabled with the `nav` parameter set to 1.

## 3. Kalman Filter Configuration

```xml
<entry-kf>
    <id>46</id>
    <filename>kf.bin</filename>
    <version>
        <major>7</major>
        <minor>1</minor>
        <revision>1</revision>
    </version>
    <data>
        <gpsok-time>5.0</gpsok-time>
        <Qnfb>
            <x>0.0</x>
            <y>0.0</y>
            <z>0.0</z>
        </Qnfb>
        <Qnwb>
            <x>0.0</x>
            <y>0.0</y>
            <z>0.0</z>
        </Qnwb>
        <Qdwb>
            <x>0.0</x>
            <y>0.0</y>
            <z>0.0</z>
        </Qdwb>
        <Qdfb>
            <x>0.0</x>
            <y>0.0</y>
            <z>0.0</z>
        </Qdfb>
        <Qdem>1.0</Qdem>
    </data>
</entry-kf>
```

The Kalman filter configuration includes:

1. **GPS Validation Time**:
   - `gpsok-time`: 5.0 seconds - Time required for GPS data to be considered valid

2. **Process Noise Covariance Parameters**:
   - `Qnfb`: Force bias process noise (currently set to zeros)
   - `Qnwb`: Angular velocity bias process noise (currently set to zeros)
   - `Qdwb`: Angular velocity derivative bias process noise (currently set to zeros)
   - `Qdfb`: Force derivative bias process noise (currently set to zeros)
   - `Qdem`: 1.0 - Likely a general process noise parameter for the filter

The zero values for most process noise parameters suggest that either:
1. These parameters are dynamically set during operation
2. The system relies on other mechanisms for state estimation
3. These features of the Kalman filter are not currently in use

The non-zero `Qdem` value indicates that at least some aspect of the Kalman filter is active.

## 4. Variable GPS Configuration

```xml
<entry-vargps>
    <id>94</id>
    <filename>vargps.bin</filename>
    <version>
        <major>7</major>
        <minor>1</minor>
        <revision>1</revision>
    </version>
    <data>
        <vgps_wts>-1.0</vgps_wts>
        <vgps_fix>2200</vgps_fix>
        <vgps_tow>4101</vgps_tow>
        <vgps_week>4101</vgps_week>
        <vgps_fid>8195</vgps_fid>
        <vgps_hpe>
            <vref-kval>
                <type>65534</type>
                <kval>2.0</kval>
            </vref-kval>
        </vgps_hpe>
        <vgps_vpe>
            <vref-kval>
                <type>65534</type>
                <kval>5.0</kval>
            </vref-kval>
        </vgps_vpe>
        <vgps_vn>4101</vgps_vn>
        <vgps_ve>4101</vgps_ve>
        <vgps_vd>4101</vgps_vd>
        <vgps_hve>
            <vref-kval>
                <type>65534</type>
                <kval>1.0</kval>
            </vref-kval>
        </vgps_hve>
        <vgps_vve>
            <vref-kval>
                <type>65534</type>
                <kval>1.0</kval>
            </vref-kval>
        </vgps_vve>
        <vgps_pos_enabled>0</vgps_pos_enabled>
        <vgps_vel_enabled>0</vgps_vel_enabled>
    </data>
</entry-vargps>
```

The variable GPS configuration defines parameters for a virtual or simulated GPS system:

1. **General Parameters**:
   - `vgps_wts`: -1.0 - Weighting factor for the virtual GPS
   - `vgps_fix`: 2200 - Fix type code
   - `vgps_tow`: 4101 - Time of Week reference
   - `vgps_week`: 4101 - GPS week number reference
   - `vgps_fid`: 8195 - Frame ID reference

2. **Position Error Parameters**:
   - `vgps_hpe`: Horizontal position error with value 2.0
   - `vgps_vpe`: Vertical position error with value 5.0

3. **Velocity Parameters**:
   - `vgps_vn`: 4101 - North velocity reference
   - `vgps_ve`: 4101 - East velocity reference
   - `vgps_vd`: 4101 - Down velocity reference

4. **Velocity Error Parameters**:
   - `vgps_hve`: Horizontal velocity error with value 1.0
   - `vgps_vve`: Vertical velocity error with value 1.0

5. **Enablement Flags**:
   - `vgps_pos_enabled`: 0 - Position simulation disabled
   - `vgps_vel_enabled`: 0 - Velocity simulation disabled

This configuration defines a virtual GPS system that is currently disabled (both position and velocity simulation are set to 0). The error parameters and reference values are defined but not currently in use.

## 5. Route Tracking and Mission Planning

### 5.1 Amazon Route Configuration

The system includes a detailed route configuration in the `amz_route.bin` file. This binary data appears to contain waypoints, paths, and navigation parameters for mission execution. The binary data is extensive and contains structured information for route planning and execution.

Key observations from the route data structure:
- Contains multiple coordinate points (likely waypoints)
- Includes parameters that appear to be altitude, heading, and velocity information
- Contains what appear to be transition parameters between waypoints
- Includes several sections that likely represent different route segments or mission phases

### 5.2 Navigation Data Flow

Based on the configuration files and system architecture context, the navigation data flow in the PDI Monitor system follows this pattern:

1. **Raw GNSS Data Acquisition**:
   - UBX0 (primary) and UBX1 (secondary) receivers collect satellite signals
   - UBX0 operates at 4Hz, UBX1 at 2Hz
   - Both receivers process signals from multiple constellations (GPS, GLONASS, Galileo, BeiDou, SBAS)

2. **GNSS Data Processing**:
   - Position, Velocity, Time (PVT) data is calculated by the receivers
   - Raw measurement data (RXM-RAWX) is collected for potential post-processing
   - Time synchronization via NAV-TIMEGPS messages

3. **Sensor Fusion**:
   - GNSS data is combined with inertial sensor data (from IMUs)
   - Kalman filtering with the parameters defined in kf.bin
   - 5-second validation period for GPS data (gpsok-time)

4. **Georeferencing**:
   - Automatic georeferencing enabled (isAutoGeoref: 1)
   - Margin of 0.2 units for georeferencing accuracy
   - Automatic magnetic field calibration enabled (isAutoMagfield: 1)

5. **Route Following**:
   - Predefined routes from amz_route.bin
   - Navigation system enabled (nav: 1)
   - Position and heading tracking relative to route waypoints

6. **Status Monitoring**:
   - Regular status updates (configured in status.bin)
   - Period of 1.0 seconds for status reporting
   - VCP (Virtual Com Port) transmission enabled

## 6. Navigation Error Handling and Redundancy

The PDI Monitor navigation system implements several error handling and redundancy mechanisms:

### 6.1 Dual GNSS Receiver Redundancy

- Two independent GNSS receivers (UBX0 and UBX1)
- Different communication interfaces and rates
- Primary-secondary configuration for fallback capability

### 6.2 Multi-Constellation Support

- GPS, GLONASS, Galileo, BeiDou, QZSS, and SBAS supported
- Provides redundancy if one constellation has reduced visibility or performance
- SBAS enabled for differential corrections and integrity information

### 6.3 Interference Mitigation

- Active interference detection and mitigation on UBX0
- Helps maintain navigation performance in challenging RF environments

### 6.4 Virtual GPS Capability

- Virtual GPS system defined but currently disabled
- Could provide simulated position and velocity data if needed
- Defined error parameters for position and velocity

### 6.5 Validation Parameters

- GPS validation time of 5 seconds before data is considered reliable
- Minimum of 4 satellites required for a fix
- Minimum elevation angle of 5 degrees for satellite visibility
- Position and time accuracy thresholds defined

## 7. Integration with Sensor Processing

From the context files, we can see how the navigation system integrates with the sensor processing system:

### 7.1 IMU Integration

- Multiple IMUs provide inertial data for navigation
- IMU geometry and position defined for proper alignment with navigation frame
- Accelerometer and gyroscope data filtered and processed before fusion with GNSS

### 7.2 Attitude Estimation

- Magnetometers provide heading information
- Attitude estimation parameters defined in att.bin
- Complementary or similar filter with adaptive gains for attitude determination

### 7.3 Sensor Fusion Architecture

- Accelerometer and gyroscope suites combine data from multiple sensors
- Kalman filter parameters defined for optimal sensor fusion
- Adaptive variance estimation for changing sensor characteristics

## 8. Navigation System Relationships

The navigation system has relationships with several other components of the PDI Monitor:

### 8.1 Relationship to System Architecture

- Navigation is a core component of the PDI Monitor system
- `Mon_nav_input_manager` processes navigation inputs
- `Blk_pa_mon_nav` performs navigation monitoring
- Navigation system is enabled in mission mode

### 8.2 Relationship to Communication Interfaces

- GNSS receivers communicate via SPI and SCI interfaces
- Status updates transmitted via VCP
- Navigation data likely shared with other system components

### 8.3 Relationship to Mission Planning

- Route data defined in amz_route.bin
- Navigation system provides position and velocity for route following
- Georeferencing system establishes the coordinate frame for navigation

## 9. Navigation Data Processing Flow

Based on the configuration files and context information, the complete navigation data processing flow can be summarized as:

1. **Data Acquisition**:
   - UBX0 and UBX1 GNSS receivers collect satellite signals
   - IMUs provide inertial measurements
   - Magnetometers provide heading information

2. **Data Validation**:
   - GNSS data validated against minimum satellite count and elevation
   - IMU data validated against maximum delta thresholds
   - GPS data requires 5-second validation period

3. **Data Filtering**:
   - GNSS receivers apply internal filtering
   - IMU data filtered through configured filter stages
   - Magnetometer data filtered through IIR filters (when enabled)

4. **Sensor Fusion**:
   - Kalman filter combines GNSS and inertial data
   - Attitude estimation filter processes gyroscope and magnetometer data
   - Adaptive variance estimation weights sensors based on performance

5. **Navigation Solution**:
   - Position, velocity, and attitude determined
   - Georeferencing establishes coordinate frame
   - Route following based on amz_route.bin waypoints

6. **Status Reporting**:
   - Regular status updates at 1-second intervals
   - Navigation performance monitoring
   - Error detection and handling

## 10. Navigation Configuration Summary Table

| Component | Primary Configuration | Key Parameters | Integration Points |
|-----------|----------------------|----------------|-------------------|
| UBX0 GNSS | Primary receiver, 4Hz | Dynamic model 8 (airborne <4g), 3D fix only | SPI/SCI interfaces, PVT and raw data output |
| UBX1 GNSS | Secondary receiver, 2Hz | Same navigation parameters as UBX0 | Different interface settings, complementary to UBX0 |
| Georeferencing | Automatic mode | Margin: 0.2, Auto magnetic field: enabled | Establishes coordinate frame for navigation |
| Kalman Filter | Basic configuration | GPS validation time: 5.0s, Qdem: 1.0 | Fuses GNSS and inertial data |
| Virtual GPS | Defined but disabled | HPE: 2.0, VPE: 5.0, HVE/VVE: 1.0 | Potential backup for GNSS outages |
| Route Planning | Binary route data | Multiple waypoints and parameters | Guides vehicle along planned path |
| Status Reporting | Enabled | 1.0s period, VCP transmission enabled | Provides navigation status to system |

## 11. Conclusion

The PDI Monitor navigation system implements a sophisticated approach to position, velocity, and time determination with multiple layers of redundancy and error handling. The system uses dual GNSS receivers with multi-constellation support, integrated with inertial sensors through Kalman filtering.

The navigation configuration shows a clear focus on reliability and accuracy, with validation parameters, interference mitigation, and sensor fusion. The system is designed for aerial vehicle operation, as evidenced by the airborne dynamic model and 3D-only fix mode.

The integration with the sensor processing system and overall system architecture ensures that navigation data flows properly through the system, providing the foundation for autonomous operation and mission execution. The route planning capability, combined with the georeferencing system, enables the vehicle to follow predefined paths with appropriate accuracy.

## Referenced Context Files

- `Amazon-PrimeAir/items/ASTRO/items/Monitor/07_System_Architecture.md` - Provided context on the overall PDI Monitor system architecture, including the navigation monitoring subsystem and operational modes.

- `Amazon-PrimeAir/items/ASTRO/items/Monitor/05_Sensor_Processing.md` - Provided context on the sensor processing system, including IMUs, gyroscopes, accelerometers, and magnetometers that integrate with the navigation system.