# Generated from:

- items/pdi_Recovery1/setup/ver_spdif_stg_subsystem.xml (2237 tokens)
- items/pdi_Recovery1/setup/ver_spdif_stg_vom_cfg.xml (71 tokens)
- items/pdi_Recovery1/setup/ver_spdif_stg_msg_cfgs.xml (56 tokens)
- items/pdi_Recovery1/setup/ver_spdif_stg_ports_cfg.xml (141 tokens)
- items/pdi_Recovery1/setup/ver_spdif_stg_mcfg.xml (53 tokens)
- items/pdi_Recovery1/setup/ver_spdif_stg_mset.xml (53 tokens)
- items/pdi_Recovery1/setup/ver_spdif_stg_inertial_sts.xml (67 tokens)
- items/pdi_Recovery1/setup/ver_spdif_stg_ua_lights.xml (66 tokens)
- items/pdi_Recovery1/setup/ver_spdif_adsbst.xml (167 tokens)

---

# STG Subsystem Configuration Analysis for PDI Recovery1 System

## 1. System Overview and Architecture

The PDI Recovery1 system utilizes a structured STG (System Technology Group) subsystem configuration framework that defines various components, communication channels, and operational parameters. The configuration is organized into multiple XML files, each responsible for a specific aspect of the system's functionality. These files collectively define the system's architecture, communication infrastructure, and operational behavior.

### 1.1 Configuration File Structure

The STG subsystem configuration consists of the following key files:

| File | ID | Version | Purpose |
|------|----|---------| ------- |
| stg_subsystem.bin | 377 | 7.3.1 | Defines subsystem parameters and memory allocation |
| stg_vom_cfg.bin | 383 | 7.3.1 | Vehicle Object Model configuration |
| stg_msg_cfgs.bin | 381 | 7.3.1 | Message configuration definitions |
| stg_ports_cfg.bin | 17 | 7.3.1 | Port configuration for communication interfaces |
| stg_mcfg.bin | 376 | 7.3.1 | Master configuration parameters |
| stg_mset.bin | 375 | 7.3.1 | Message set definitions |
| stg_inertial_sts.bin | 384 | 7.3.1 | Inertial sensor system configuration |
| stg_ua_lights.bin | 382 | 7.3.1 | User interface lighting configuration |
| adsbst.bin | 295 | 7.3.1 | ADS-B static configuration parameters |

All configuration files maintain a consistent versioning scheme (7.3.1), indicating they are part of a unified release or configuration set.

## 2. Subsystem Configuration (stg_subsystem.bin)

### 2.1 Structure and Organization

The subsystem configuration file (`stg_subsystem.bin`, ID: 377) defines 32 distinct subsystems (subsys0 through subsys31), each with identical configuration structures. This suggests a modular system architecture with multiple parallel or functionally similar components.

### 2.2 Memory Allocation Parameters

Each subsystem contains a tunable array element with the following structure:
- Component number (`comp_n`): 0
- Subcomponent number (`subcomp_n`): 0
- Memory allocation (`uvar`): 2000

This consistent pattern across all 32 subsystems indicates:
1. A uniform memory allocation strategy (2000 units per subsystem)
2. A hierarchical component/subcomponent organization
3. Potential for future differentiation between subsystems (currently all identical)

### 2.3 Subsystem Hierarchy

The configuration suggests a flat initial allocation where all subsystems have identical parameters, but the structure supports future differentiation through the component/subcomponent numbering scheme. This allows for:
- Dynamic resource allocation
- Subsystem specialization
- Hierarchical organization of system components

## 3. Vehicle Object Model Configuration (stg_vom_cfg.bin)

### 3.1 VOM Parameters

The Vehicle Object Model configuration (`stg_vom_cfg.bin`, ID: 383) contains two key variables:
- `var0`: 1000
- `var1`: 3100

These parameters likely define fundamental characteristics of the vehicle model used by the system, potentially including:
- Physical dimensions or constraints
- Operational parameters
- Model identification or version information

### 3.2 VOM Integration

The VOM configuration serves as a bridge between the physical vehicle characteristics and the software system, providing a consistent model for other subsystems to reference. This centralized approach ensures consistency across all components that need to understand vehicle characteristics.

## 4. Message Configuration (stg_msg_cfgs.bin)

### 4.1 Message Configuration Structure

The message configuration file (`stg_msg_cfgs.bin`, ID: 381) contains an empty data section, indicating one of the following possibilities:
1. Default message configurations are used
2. Message configurations are defined elsewhere or dynamically
3. This particular deployment does not require custom message configurations

### 4.2 Communication Framework

Despite the empty configuration, the presence of this file indicates that the system utilizes a structured message-passing architecture. This suggests:
- Component communication via standardized messages
- Potential for message routing, filtering, or transformation
- A publish-subscribe or similar communication pattern

## 5. Ports Configuration (stg_ports_cfg.bin)

### 5.1 Port Parameters

The ports configuration (`stg_ports_cfg.bin`, ID: 17) defines six port elements, all initialized to 0:
```xml
<str-tunarray-element>0</str-tunarray-element> (repeated 6 times)
```

This indicates:
1. Six communication ports or channels available in the system
2. All ports are initially disabled or set to default configuration
3. Ports can be individually configured through these parameters

### 5.2 Communication Infrastructure

The ports configuration suggests a hardware abstraction layer that manages physical or logical communication interfaces. The zero values likely represent:
- Disabled ports
- Default configuration
- Ports awaiting dynamic configuration during system initialization

## 6. Master Configuration (stg_mcfg.bin)

The master configuration file (`stg_mcfg.bin`, ID: 376) contains an empty data section. This suggests:
1. Default master configuration is used
2. Configuration may be populated dynamically at runtime
3. This particular deployment uses standard settings

The presence of this file indicates a centralized configuration management approach where system-wide parameters can be defined.

## 7. Message Set Configuration (stg_mset.bin)

The message set configuration (`stg_mset.bin`, ID: 375) contains an empty data section. This suggests:
1. Default message sets are used
2. Message sets may be defined dynamically
3. This deployment may not require custom message sets

The file's presence indicates support for grouped message definitions or templates that can be referenced by the messaging subsystem.

## 8. Inertial Sensor System Configuration (stg_inertial_sts.bin)

### 8.1 Inertial Sensor Parameters

The inertial sensor system configuration (`stg_inertial_sts.bin`, ID: 384) contains a single parameter:
- `freq`: 0

This parameter likely defines the sampling frequency or operational mode of the inertial sensor system. The zero value suggests:
1. Default frequency is used
2. Sensor is initially disabled
3. Frequency is set dynamically during system initialization

### 8.2 Sensor Integration

The presence of a dedicated configuration file for inertial sensors indicates:
1. The system incorporates motion or orientation sensing capabilities
2. Inertial data is important for system operation
3. Sensor parameters can be tuned independently of other subsystems

## 9. User Interface Lighting Configuration (stg_ua_lights.bin)

### 9.1 Lighting Parameters

The UI lighting configuration (`stg_ua_lights.bin`, ID: 382) contains a single parameter:
- `var0`: 1200

This parameter likely controls aspects of the user interface lighting system, such as:
- Brightness level
- Color temperature
- Operating mode
- Timing characteristics

### 9.2 User Interface Integration

The dedicated configuration for UI lighting suggests:
1. The system includes user-facing display or indicator components
2. Lighting characteristics are configurable
3. UI elements are considered important enough to warrant separate configuration

## 10. ADS-B Static Configuration (adsbst.bin)

### 10.1 ADS-B Parameters

The ADS-B static configuration (`adsbst.bin`, ID: 295) contains several parameters related to Automatic Dependent Surveillance-Broadcast functionality:

- `model`: 0 (ADS-B hardware model or version)
- `init_mode`: 0 (Initialization mode)
- `cm_id`: -1 (Communication manager ID, unassigned)
- `icao`: 0 (ICAO aircraft address, unassigned)
- `emitter`: 0 (Emitter category)
- ASCII array: 8 characters, all set to 0 (likely aircraft identification)
- `custom`: 65535 (Custom parameter, all bits set)

### 10.2 ADS-B Integration

The presence of ADS-B configuration indicates:
1. The system has aviation-related functionality
2. It can transmit position and identification information
3. It complies with aviation standards for surveillance
4. The configuration is currently in a default or uninitialized state

## 11. System Architecture Implications

### 11.1 Modular Design

The configuration files reveal a highly modular system architecture with:
- 32 identical subsystems with uniform memory allocation
- Separate configuration files for different functional areas
- Clear separation between communication, sensing, and user interface components

### 11.2 Communication Infrastructure

The system employs a sophisticated communication framework with:
- Configurable message definitions
- Multiple communication ports
- Potential for message routing and transformation
- Standardized message sets

### 11.3 Sensor Integration

The configuration indicates integration with at least two sensor systems:
1. Inertial sensors (motion/orientation)
2. ADS-B (position/surveillance)

This suggests the system has spatial awareness capabilities and can track its position and movement.

### 11.4 User Interface Components

The presence of UI lighting configuration indicates user-facing components, suggesting:
- Displays or indicators
- User interaction capabilities
- Visual feedback mechanisms

### 11.5 Aviation Context

The ADS-B configuration strongly suggests an aviation context for this system, with capabilities for:
- Position reporting
- Aircraft identification
- Compliance with aviation surveillance standards

## 12. Key Tunable Parameters

The configuration files expose several key tunable parameters:

| Parameter | File | Value | Purpose |
|-----------|------|-------|---------|
| Subsystem Memory | stg_subsystem.bin | 2000 | Memory allocation per subsystem |
| VOM var0 | stg_vom_cfg.bin | 1000 | Vehicle model parameter |
| VOM var1 | stg_vom_cfg.bin | 3100 | Vehicle model parameter |
| Inertial Sensor Frequency | stg_inertial_sts.bin | 0 | Sensor sampling frequency |
| UI Light Setting | stg_ua_lights.bin | 1200 | User interface lighting parameter |
| ADS-B Custom | adsbst.bin | 65535 | Custom ADS-B parameter |

## 13. Operational Behavior

### 13.1 Initialization Sequence

The configuration suggests the following initialization sequence:
1. Load subsystem configurations with memory allocations
2. Initialize vehicle object model with parameters
3. Configure communication ports (currently disabled)
4. Set up inertial sensors (currently disabled)
5. Configure UI lighting
6. Initialize ADS-B with default parameters

### 13.2 Runtime Behavior

During operation, the system likely:
1. Manages 32 subsystems with allocated memory
2. Processes messages between subsystems
3. Collects and processes inertial sensor data
4. Manages UI lighting based on configuration
5. Transmits position information via ADS-B

### 13.3 Configuration Updates

The system appears designed to support dynamic configuration updates, as evidenced by:
- Tunable array elements in subsystem configuration
- Empty configuration sections that may be populated at runtime
- Default values that can be overridden

## 14. Integration with Broader System

The STG subsystem configuration integrates with the broader PDI Recovery1 system by:
1. Providing a structured communication framework
2. Defining interfaces between subsystems
3. Establishing memory allocation for components
4. Configuring sensors and external interfaces
5. Setting up user interface components

The configuration suggests a system designed for aviation applications, with capabilities for position tracking, motion sensing, and standardized communication.

## 15. File-by-File Breakdown

### 15.1 stg_subsystem.bin (ID: 377)
- Defines 32 identical subsystems (subsys0-subsys31)
- Each subsystem has component 0, subcomponent 0
- Each allocates 2000 units of memory
- Establishes the basic structure of the system

### 15.2 stg_vom_cfg.bin (ID: 383)
- Defines two vehicle object model parameters
- var0: 1000
- var1: 3100
- Provides fundamental vehicle characteristics

### 15.3 stg_msg_cfgs.bin (ID: 381)
- Empty data section
- Placeholder for message configuration
- Indicates message-based communication architecture

### 15.4 stg_ports_cfg.bin (ID: 17)
- Defines six communication ports
- All ports initialized to 0 (disabled/default)
- Provides hardware abstraction for communication interfaces

### 15.5 stg_mcfg.bin (ID: 376)
- Empty data section
- Placeholder for master configuration
- Indicates centralized configuration management

### 15.6 stg_mset.bin (ID: 375)
- Empty data section
- Placeholder for message set definitions
- Supports grouped message templates

### 15.7 stg_inertial_sts.bin (ID: 384)
- Defines inertial sensor frequency (0)
- Configures motion/orientation sensing
- Currently disabled or using default frequency

### 15.8 stg_ua_lights.bin (ID: 382)
- Defines UI lighting parameter (1200)
- Configures user interface visual elements
- Indicates presence of user-facing components

### 15.9 adsbst.bin (ID: 295)
- Defines ADS-B parameters in default/uninitialized state
- Includes aircraft identification, ICAO address, emitter type
- Indicates aviation surveillance capabilities

## 16. Cross-Component Relationships

### 16.1 Subsystem Interactions

The 32 subsystems defined in stg_subsystem.bin likely interact through:
- Message passing (configured in stg_msg_cfgs.bin)
- Communication ports (configured in stg_ports_cfg.bin)
- Shared vehicle model (defined in stg_vom_cfg.bin)

### 16.2 Sensor Data Flow

Inertial sensor data (configured in stg_inertial_sts.bin) likely:
- Feeds into multiple subsystems
- Influences vehicle model state
- Contributes to ADS-B position reporting

### 16.3 User Interface Integration

UI lighting (configured in stg_ua_lights.bin) likely:
- Responds to system state changes
- Provides visual feedback to users
- Integrates with other UI components

### 16.4 Communication Pathways

The six communication ports (stg_ports_cfg.bin) likely connect:
- Between internal subsystems
- To external systems
- To physical sensors and actuators
- To user interface components

## 17. Configuration Hierarchy

The configuration files reveal a hierarchical structure:
1. Master configuration (stg_mcfg.bin) - System-wide parameters
2. Subsystem configuration (stg_subsystem.bin) - Component organization
3. Communication configuration (stg_ports_cfg.bin, stg_msg_cfgs.bin) - Data exchange
4. Functional configurations (stg_inertial_sts.bin, stg_ua_lights.bin) - Specific capabilities
5. External interface configuration (adsbst.bin) - Integration with external systems

This hierarchy allows for modular configuration management and targeted updates to specific system aspects.

## 18. Summary

The STG subsystem configuration for the PDI Recovery1 system defines a modular, message-based architecture with 32 identical subsystems, configurable communication ports, sensor integration, and user interface components. The system appears designed for aviation applications, with ADS-B capabilities and inertial sensing. While many configuration elements are currently in default states, the structure supports dynamic configuration and specialized behavior. The consistent versioning (7.3.1) across all files indicates a coordinated configuration set designed to work together as a cohesive system.