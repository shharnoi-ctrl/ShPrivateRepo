# Generated from:

- items/pdi_Recovery1/setup/ver_spdif_gyr0filt.xml (172 tokens)
- items/pdi_Recovery1/setup/ver_spdif_gyr1filt.xml (172 tokens)
- items/pdi_Recovery1/setup/ver_spdif_gyr2filt.xml (172 tokens)
- items/pdi_Recovery1/setup/ver_spdif_gyr3filt.xml (172 tokens)
- items/pdi_Recovery1/setup/ver_spdif_acc0filt.xml (172 tokens)
- items/pdi_Recovery1/setup/ver_spdif_acc1filt.xml (172 tokens)
- items/pdi_Recovery1/setup/ver_spdif_acc2filt.xml (172 tokens)
- items/pdi_Recovery1/setup/ver_spdif_acc3filt.xml (172 tokens)
- items/pdi_Recovery1/setup/ver_spdif_mag0filt.xml (105 tokens)
- items/pdi_Recovery1/setup/ver_spdif_mag2filt.xml (105 tokens)
- items/pdi_Recovery1/setup/ver_spdif_mag3filt.xml (105 tokens)
- items/pdi_Recovery1/setup/ver_spdif_mag4filt.xml (105 tokens)
- items/pdi_Recovery1/setup/ver_spdif_mag5filt.xml (105 tokens)
- items/pdi_Recovery1/setup/ver_spdif_mag6filt.xml (105 tokens)
- items/pdi_Recovery1/setup/ver_spdif_mag7filt.xml (107 tokens)
- items/pdi_Recovery1/setup/ver_spdif_magResfilt.xml (106 tokens)
- items/pdi_Recovery1/setup/ver_spdif_stp0filt.xml (103 tokens)
- items/pdi_Recovery1/setup/ver_spdif_stp1filt.xml (103 tokens)
- items/pdi_Recovery1/setup/ver_spdif_stp2filt.xml (104 tokens)
- items/pdi_Recovery1/setup/ver_spdif_qinffilt.xml (103 tokens)

---

# PDI Recovery1 Sensor Filter Configuration Analysis

This document provides a comprehensive analysis of the sensor filter configurations used in the PDI Recovery1 system. The system employs various filter types across different sensor categories to process and improve sensor data quality.

## 1. Overview of Filter Types

The PDI Recovery1 system utilizes three primary filter types across its sensor array:

1. **Notch Filters**: Used for gyroscopes and accelerometers
2. **Butterworth Filters**: Used for gyroscopes and accelerometers
3. **IIR (Infinite Impulse Response) Filters**: Used for magnetometers and other sensors

Each filter type serves specific purposes in signal processing and noise reduction, with configurations tailored to the characteristics of each sensor type.

## 2. Gyroscope Filter Configurations

### Common Configuration Pattern

All gyroscope filters (gyr0filt through gyr3filt) share identical filter configurations:

#### Notch Filter Parameters
- **ID**: Varies (98, 108, 258, 364)
- **Filename**: gyr[0-3]filt.bin
- **Version**: 7.3.1
- **Number of Harmonics**: 0 (disabled)
- **Center Frequency**:
  - Type: 65534
  - kval: 100.0 Hz
- **Bandwidth**: 20.0 Hz
- **Notch Gain**: 0.5

#### Butterworth Filter Parameters
- **Enable**: 0 (disabled)
- **Cutoff Frequency**: 1.0 Hz

### File-by-File Breakdown

#### gyr0filt.xml (ID: 98)
```xml
<notch>
    <num-harmonics>0</num-harmonics>
    <center-freq>
        <vref-kval>
            <type>65534</type>
            <kval>100.0</kval>
        </vref-kval>
    </center-freq>
    <bandwidth>20.0</bandwidth>
    <notch-gain>0.5</notch-gain>
</notch>
<butterworth>
    <enable>0</enable>
    <cutoff_freq>1.0</cutoff_freq>
</butterworth>
```

#### gyr1filt.xml (ID: 108)
Identical configuration to gyr0filt.xml

#### gyr2filt.xml (ID: 258)
Identical configuration to gyr0filt.xml

#### gyr3filt.xml (ID: 364)
Identical configuration to gyr0filt.xml

### Gyroscope Filter Behavior Analysis

1. **Notch Filter**: Configured to target and attenuate noise at 100 Hz with a bandwidth of 20 Hz. The notch gain of 0.5 indicates a moderate attenuation level. However, with num-harmonics set to 0, the notch filter is effectively disabled.

2. **Butterworth Filter**: A low-pass filter with a cutoff frequency of 1.0 Hz, which would allow signals below 1 Hz to pass while attenuating higher frequencies. However, it is currently disabled (enable=0).

3. **Overall Configuration**: Both filters are currently disabled in the configuration, suggesting that raw gyroscope data is being used without filtering. This could indicate either:
   - The system relies on hardware-level filtering within the gyroscope sensors
   - The filters are enabled programmatically during runtime based on operational conditions
   - The system is configured for a test mode where raw sensor data is preferred

## 3. Accelerometer Filter Configurations

### Common Configuration Pattern

All accelerometer filters (acc0filt through acc3filt) share identical filter configurations:

#### Notch Filter Parameters
- **ID**: Varies (97, 107, 257, 363)
- **Filename**: acc[0-3]filt.bin
- **Version**: 7.3.1
- **Number of Harmonics**: 0 (disabled)
- **Center Frequency**:
  - Type: 65534
  - kval: 100.0 Hz
- **Bandwidth**: 20.0 Hz
- **Notch Gain**: 0.5

#### Butterworth Filter Parameters
- **Enable**: 0 (disabled)
- **Cutoff Frequency**: 1.0 Hz

### File-by-File Breakdown

#### acc0filt.xml (ID: 97)
```xml
<notch>
    <num-harmonics>0</num-harmonics>
    <center-freq>
        <vref-kval>
            <type>65534</type>
            <kval>100.0</kval>
        </vref-kval>
    </center-freq>
    <bandwidth>20.0</bandwidth>
    <notch-gain>0.5</notch-gain>
</notch>
<butterworth>
    <enable>0</enable>
    <cutoff_freq>1.0</cutoff_freq>
</butterworth>
```

#### acc1filt.xml (ID: 107)
Identical configuration to acc0filt.xml

#### acc2filt.xml (ID: 257)
Identical configuration to acc0filt.xml

#### acc3filt.xml (ID: 363)
Identical configuration to acc0filt.xml

### Accelerometer Filter Behavior Analysis

1. **Notch Filter**: Configured identically to the gyroscope notch filters, targeting 100 Hz with a 20 Hz bandwidth and 0.5 gain. As with the gyroscopes, the notch filter is effectively disabled with num-harmonics set to 0.

2. **Butterworth Filter**: A low-pass filter with a cutoff frequency of 1.0 Hz, currently disabled.

3. **Comparison to Gyroscope Filters**: The accelerometer filters use exactly the same configuration as the gyroscope filters, suggesting a unified approach to inertial measurement unit (IMU) filtering. This consistency simplifies system design and maintenance.

## 4. Magnetometer Filter Configurations

### Common Configuration Pattern

All magnetometer filters (mag0filt through mag7filt and magResfilt) share identical filter configurations:

#### IIR Filter Parameters
- **ID**: Varies (99, 124, 253, 262, 268, 355, 366, 368)
- **Filename**: mag[0-7]filt.bin, magResfilt.bin
- **Version**: 7.3.1
- **Enable**: 0 (disabled)
- **Cutoff Frequency**: 1.0 Hz
- **Max NV Samples**: 0 (except for mag7filt which is labeled as magrm3100filt)
- **Max Delta**: 3.4028235E38 (essentially infinite)

### File-by-File Breakdown

#### mag0filt.xml (ID: 99)
```xml
<iir_cfg>
    <enable>0</enable>
    <cutoff_freq>1.0</cutoff_freq>
</iir_cfg>
<max_nv_samples>0</max_nv_samples>
<max_delta>3.4028235E38</max_delta>
```

#### mag2filt.xml (ID: 124)
Identical configuration to mag0filt.xml

#### mag3filt.xml (ID: 253)
Identical configuration to mag0filt.xml

#### mag4filt.xml (ID: 262)
Identical configuration to mag0filt.xml

#### mag5filt.xml (ID: 268)
Identical configuration to mag0filt.xml

#### mag6filt.xml (ID: 355)
Identical configuration to mag0filt.xml

#### mag7filt.xml (ID: 366)
```xml
<entry-magrm3100filt>
    <!-- Same configuration as other mag filters -->
</entry-magrm3100filt>
```
Note: This file uses a different entry tag (magrm3100filt) suggesting it may be for a specific magnetometer model (RM3100).

#### magResfilt.xml (ID: 368)
Identical configuration to mag0filt.xml

### Magnetometer Filter Behavior Analysis

1. **IIR Filter**: A low-pass filter with a cutoff frequency of 1.0 Hz, currently disabled. IIR filters are chosen for magnetometers instead of the notch+Butterworth combination used for inertial sensors.

2. **Max NV Samples**: Set to 0, indicating no non-valid sample threshold is being applied.

3. **Max Delta**: Set to an extremely large value (approximately the maximum value for a 32-bit float), effectively disabling any delta-based outlier rejection.

4. **Filter Purpose**: When enabled, the IIR filter would smooth magnetometer readings by attenuating high-frequency noise while preserving the low-frequency components that represent actual magnetic field changes.

5. **Special Case - mag7filt**: The different entry tag (magrm3100filt) suggests this configuration is for an RM3100 magnetometer, which is a high-precision magnetometer model, though the filter settings remain identical to other magnetometers.

## 5. Other Sensor Filter Configurations

### Static Pressure Sensor Filters (stp0filt, stp1filt, stp2filt)

#### Common Configuration Pattern
- **IIR Filter**:
  - Enable: 0 (disabled)
  - Cutoff Frequency: 1.0 Hz
- **Max NV Samples**: 10 (consistent across all pressure sensors)
- **Max Delta**: Varies by sensor

#### File-by-File Breakdown

##### stp0filt.xml (ID: 105)
```xml
<iir_cfg>
    <enable>0</enable>
    <cutoff_freq>1.0</cutoff_freq>
</iir_cfg>
<max_nv_samples>10</max_nv_samples>
<max_delta>450.0</max_delta>
```

##### stp1filt.xml (ID: 106)
```xml
<iir_cfg>
    <enable>0</enable>
    <cutoff_freq>1.0</cutoff_freq>
</iir_cfg>
<max_nv_samples>10</max_nv_samples>
<max_delta>113.4</max_delta>
```

##### stp2filt.xml (ID: 261)
```xml
<iir_cfg>
    <enable>0</enable>
    <cutoff_freq>1.0</cutoff_freq>
</iir_cfg>
<max_nv_samples>10</max_nv_samples>
<max_delta>177.1875</max_delta>
```

### QINF Sensor Filter (qinffilt)

#### Configuration
- **ID**: 153
- **Filename**: qinffilt.bin
- **Version**: 7.3.1
- **IIR Filter**:
  - Enable: 0 (disabled)
  - Cutoff Frequency: 1.0 Hz
- **Max NV Samples**: 10
- **Max Delta**: 200.0

```xml
<iir_cfg>
    <enable>0</enable>
    <cutoff_freq>1.0</cutoff_freq>
</iir_cfg>
<max_nv_samples>10</max_nv_samples>
<max_delta>200.0</max_delta>
```

### Other Sensor Filter Behavior Analysis

1. **Static Pressure Sensors**:
   - Use IIR filters with the same cutoff frequency (1.0 Hz) as other sensors
   - Unlike magnetometers, they have max_nv_samples set to 10, allowing for rejection of up to 10 consecutive invalid samples
   - Each has a different max_delta value, suggesting different expected ranges of measurement:
     - stp0filt: 450.0
     - stp1filt: 113.4
     - stp2filt: 177.1875

2. **QINF Sensor**:
   - Similar configuration to pressure sensors
   - Max delta of 200.0 suggests a different expected measurement range
   - The purpose of this sensor is not explicitly stated in the configuration, but "QINF" typically refers to dynamic pressure measurement

3. **Outlier Rejection**: Both pressure sensors and the QINF sensor implement outlier rejection through the max_delta parameter, unlike the magnetometers which have this effectively disabled.

## 6. Cross-Sensor Filter Pattern Analysis

### Filter Type Distribution

| Sensor Type | Filter Types | Enabled | Cutoff/Center Freq | Additional Parameters |
|-------------|--------------|---------|-------------------|------------------------|
| Gyroscopes | Notch + Butterworth | No | 100 Hz (notch), 1.0 Hz (Butterworth) | Bandwidth: 20 Hz, Gain: 0.5 |
| Accelerometers | Notch + Butterworth | No | 100 Hz (notch), 1.0 Hz (Butterworth) | Bandwidth: 20 Hz, Gain: 0.5 |
| Magnetometers | IIR | No | 1.0 Hz | max_nv_samples: 0, max_delta: 3.4028235E38 |
| Pressure Sensors | IIR | No | 1.0 Hz | max_nv_samples: 10, max_delta: varies |
| QINF Sensor | IIR | No | 1.0 Hz | max_nv_samples: 10, max_delta: 200.0 |

### Key Observations

1. **Filter Selection Logic**:
   - Inertial sensors (gyroscopes and accelerometers) use a combination of notch and Butterworth filters
   - Environmental sensors (magnetometers, pressure sensors) use IIR filters
   - This suggests different noise characteristics are expected for different sensor types

2. **Consistent Cutoff Frequency**:
   - All low-pass filters (Butterworth and IIR) use the same 1.0 Hz cutoff frequency
   - This indicates a system-wide decision about the frequency content of interest
   - Signals above 1 Hz would be attenuated when filters are enabled

3. **Notch Filter Targeting**:
   - The 100 Hz center frequency with 20 Hz bandwidth suggests targeting a specific noise source
   - Common sources at this frequency include mechanical vibrations or electrical interference

4. **Disabled State**:
   - All filters are currently disabled (enable=0 or num-harmonics=0)
   - This could indicate:
     - A baseline configuration that gets modified at runtime
     - A testing or calibration mode
     - Reliance on hardware-level filtering instead

5. **Outlier Rejection Strategy**:
   - Pressure sensors and QINF have finite max_delta values for outlier rejection
   - Magnetometers have effectively infinite max_delta values
   - This suggests pressure measurements are more prone to outliers than magnetic field measurements

6. **Version Consistency**:
   - All filter configurations share the same version (7.3.1)
   - This indicates they were likely updated or reviewed together as part of a unified filtering strategy

## 7. Signal Processing Implications

### Frequency Domain Characteristics

1. **Low-Pass Filtering**:
   - The consistent 1.0 Hz cutoff across all sensors would create a system that focuses on low-frequency signals
   - This is appropriate for navigation systems where high-frequency components are often noise
   - When enabled, these filters would smooth sensor readings by removing rapid fluctuations

2. **Notch Filtering**:
   - The 100 Hz notch filters for inertial sensors would specifically target noise at that frequency
   - Common 100 Hz noise sources include:
     - Motor or propeller vibrations
     - Power supply interference
     - Structural resonance

3. **Filter Cascade Effects**:
   - For inertial sensors, the combination of notch and Butterworth filters would:
     - First remove specific frequency noise (notch)
     - Then apply general low-pass filtering (Butterworth)
   - This cascade approach provides more targeted noise reduction than either filter alone

### Time Domain Characteristics

1. **Response Time**:
   - The 1.0 Hz cutoff frequency implies a time constant of approximately 0.16 seconds
   - This means the system would respond relatively quickly to actual changes while still filtering noise
   - Higher cutoff frequencies would provide faster response but less filtering

2. **Transient Behavior**:
   - IIR filters can introduce phase shifts that affect timing relationships between signals
   - This could impact sensor fusion algorithms that combine data from multiple sensors

3. **Outlier Handling**:
   - The max_delta parameters for pressure sensors provide a hard limit on how much a reading can change
   - This prevents single erroneous readings from affecting system behavior

## 8. System-Level Filter Strategy

The PDI Recovery1 system employs a comprehensive but currently disabled filtering strategy:

1. **Unified Approach**: The consistent 1.0 Hz cutoff frequency across all filter types suggests a system-wide decision about the frequency content of interest.

2. **Sensor-Specific Techniques**: Different filter types are applied to different sensor categories based on their noise characteristics:
   - Inertial sensors: Notch + Butterworth for targeted and general noise reduction
   - Environmental sensors: IIR filters for smooth response to changing conditions

3. **Configurable Runtime Behavior**: The disabled state of all filters suggests the system may enable them selectively during operation based on:
   - Flight phase or operating mode
   - Detected noise conditions
   - Sensor health or quality metrics

4. **Outlier Rejection**: The system implements different outlier rejection strategies:
   - Pressure sensors: Strict limits on measurement changes (max_delta)
   - Magnetometers: No effective limits, suggesting either:
     - High confidence in magnetometer readings
     - Separate validation logic elsewhere in the system
     - Different handling of magnetometer outliers

5. **Sensor Redundancy**: Multiple instances of each sensor type (4 gyroscopes, 4 accelerometers, 8 magnetometers, 3 pressure sensors) suggest a redundant system design where:
   - Filtering may be less critical due to sensor fusion algorithms
   - Individual sensor failures can be detected and compensated for
   - Different filter settings could be applied dynamically based on sensor agreement

## 9. Conclusion

The PDI Recovery1 sensor filter configurations reveal a sophisticated but currently disabled filtering strategy. The system employs different filter types tailored to each sensor category, with consistent cutoff frequencies suggesting a unified approach to signal processing.

The disabled state of all filters indicates that either:
1. The system relies on hardware-level filtering within the sensors themselves
2. The filters are enabled programmatically during runtime based on operational conditions
3. The system is configured for a test or calibration mode where raw sensor data is preferred

The consistent version numbers (7.3.1) across all filter configurations suggest they were developed or updated as part of a unified filtering strategy. The different approaches to outlier rejection between sensor types indicate a nuanced understanding of each sensor's characteristics and failure modes.

When enabled, these filters would work together to reduce noise, smooth sensor readings, and reject outliers, ultimately improving the quality of sensor data used by the PDI Recovery1 system for navigation, control, or monitoring purposes.