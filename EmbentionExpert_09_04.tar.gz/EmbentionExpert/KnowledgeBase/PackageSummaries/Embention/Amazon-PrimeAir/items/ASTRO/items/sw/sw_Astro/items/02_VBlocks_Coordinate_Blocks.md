# Generated from:

- _sw_Veronte/code/vblocks/code/include/Blk_n2b.h (726 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_n2b.cpp (380 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_btor.h (643 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_btor.cpp (149 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_rtob.h (774 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_rtob.cpp (149 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_rtou.h (804 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_rtou.cpp (184 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_utor.h (759 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_utor.cpp (146 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_u2s.h (1354 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_u2s.cpp (2427 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_azeld.h (622 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_azeld.cpp (519 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_azeld_1.h (735 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_azeld_1.cpp (342 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_relthis.h (701 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_relthis.cpp (259 tokens)

## With context from:

- PackageSummaries/Embention/Amazon-PrimeAir/items/ASTRO/items/sw/sw_Astro/items/04_VBlocks_Core.md (5729 tokens)
- PackageSummaries/Embention/Amazon-PrimeAir/items/ASTRO/items/sw/sw_Astro/items/03_VBlocks_Math_Blocks.md (5216 tokens)

---

# Coordinate Transformation and Type Conversion Blocks in VBlocks Library

This document provides a comprehensive analysis of the coordinate transformation and type conversion blocks in the VBlocks library, focusing on how they convert between different coordinate systems and data types.

## 1. NED to Body Transformation Block (Blk_n2b)

### 1.1 Overview

`Blk_n2b` implements coordinate transformations between the North-East-Down (NED) reference frame and the body reference frame of an aircraft. This block can perform transformations in both directions: from NED to body frame and from body frame to NED.

### 1.2 Class Structure

```cpp
class Blk_n2b : public Blocks::Iblock {
public:
    explicit Blk_n2b(const Maverick::Irmatrix3& Lnb0);
    virtual void step();
    virtual const Blocks::Ipin* get_out(Uint16 i) const;
    virtual void cset(Base::Lossy_error& str, Csetpm& params);

private:
    Blocks::Pin_ptr<Real> in;                // Input vector
    Blocks::Pin<Maverick::Rvector3> out;     // Output vector
    const Maverick::Irmatrix3& Lnb;          // Body to NED rotation matrix
    bool mode;                               // Mode selector: true for n2b and false for b2n
};
```

### 1.3 Transformation Logic

The block uses a rotation matrix `Lnb` (Body to NED rotation matrix) to perform the coordinate transformations:

```cpp
void Blk_n2b::step() {
    const Maverick::Irvector3::K vin(in.get_mblock());
    if (mode) {
        // NED to body transformation
        out.val.matTvec(Lnb, vin.kvec);
    } else {
        // Body to NED transformation
        out.val.matvec(Lnb, vin.kvec);
    }
}
```

For NED to body transformation (`mode = true`):
- Uses `matTvec()` which multiplies the transpose of the rotation matrix by the input vector
- This effectively applies the inverse rotation to convert from NED to body frame

For body to NED transformation (`mode = false`):
- Uses `matvec()` which multiplies the rotation matrix by the input vector
- This applies the direct rotation to convert from body to NED frame

### 1.4 Configuration

The block is configured through its PDI with:
- `in`: Input vector address (3 elements representing a vector in either NED or body frame)
- `mode`: Operation mode (true for NED to body, false for body to NED)

The block constructor requires:
- `Lnb0`: A reference to the body to NED rotation matrix that will be used for transformations

### 1.5 Output Retrieval

The block provides a single output which is the transformed vector:

```cpp
inline const Blocks::Ipin* Blk_n2b::get_out(Uint16 i) const {
    return Base::Paramsel::select<Blocks::Ipin>(i, out);
}
```

## 2. Spherical Coordinates Conversion Blocks

### 2.1 Vector to Spherical Coordinates Block (Blk_azeld)

#### 2.1.1 Overview

`Blk_azeld` converts a 3D vector into spherical coordinates, providing azimuth, elevation, and distance as outputs.

#### 2.1.2 Class Structure

```cpp
class Blk_azeld : public Blocks::Iblock {
public:
    Blk_azeld();
    virtual void step();
    virtual const Blocks::Ipin* get_out(Uint16 i) const;
    virtual void cset(Base::Lossy_error& str, Csetpm& params);

private:
    Blocks::Pin_ptr<Real> in;     // Input vector
    Blocks::Pin<Real> out_az;     // Output Azimuth
    Blocks::Pin<Real> out_e;      // Output Elevation
    Blocks::Pin<Real> out_d;      // Output Distance
};
```

#### 2.1.3 Conversion Logic

The block uses the `azeld()` method from the `Irvector3` class to convert the input vector to spherical coordinates:

```cpp
void Blk_azeld::step() {
    Maverick::Irvector3::K irvect(in.get_mblock());
    irvect.kvec.azeld(out_az.val, out_e.val, out_d.val);
}
```

The `azeld()` method calculates:
- Azimuth: The angle in the horizontal plane from the north direction to the vector's projection
- Elevation: The angle from the horizontal plane to the vector
- Distance: The magnitude (length) of the vector

#### 2.1.4 Configuration

The block is configured through its PDI with:
- `in`: Input vector address (3 elements representing a 3D vector)

#### 2.1.5 Output Retrieval

The block provides three separate outputs for azimuth, elevation, and distance:

```cpp
const Blocks::Ipin* Blk_azeld::get_out(Uint16 i) const {
    static const Uint16 az_flag = 0;   // Output azimuth flag
    static const Uint16 el_flag = 1;   // Output elevation flag
    static const Uint16 d_flag = 2;    // Output distance flag

    const Blocks::Ipin* ret = 0;
    switch (i) {
        case az_flag: ret = &out_az; break;
        case el_flag: ret = &out_e; break;
        case d_flag: ret = &out_d; break;
        default: Bsp::warning(); break;
    }
    return ret;
}
```

### 2.2 Spherical Coordinates to Vector Block (Blk_azeld_1)

#### 2.2.1 Overview

`Blk_azeld_1` performs the inverse operation of `Blk_azeld`, converting spherical coordinates (azimuth, elevation, and distance) into a 3D vector.

#### 2.2.2 Class Structure

```cpp
class Blk_azeld_1 : public Blocks::Iblock {
public:
    Blk_azeld_1();
    virtual void step();
    virtual const Blocks::Ipin* get_out(Uint16 i) const;
    virtual void cset(Base::Lossy_error& str, Csetpm& params);

private:
    Blocks::Pin_ptr<Real> in_az;          // Input Azimuth
    Blocks::Pin_ptr<Real> in_el;          // Input Elevation
    Blocks::Pin_ptr<Real> in_d;           // Input Distance
    Blocks::Pin<Maverick::Rvector3> out;  // Output Vector
};
```

#### 2.2.3 Conversion Logic

The block uses the `azeld_1()` method from the `Rvector3` class to convert the spherical coordinates to a 3D vector:

```cpp
void Blk_azeld_1::step() {
    out.val.azeld_1(in_az.read(), in_el.read(), in_d.read());
}
```

The `azeld_1()` method calculates the 3D vector components based on:
- Azimuth: The angle in the horizontal plane
- Elevation: The angle from the horizontal plane
- Distance: The magnitude of the resulting vector

#### 2.2.4 Configuration

The block is configured through its PDI with:
- `in_az`: Input azimuth address (scalar)
- `in_el`: Input elevation address (scalar)
- `in_d`: Input distance address (scalar)

#### 2.2.5 Output Retrieval

The block provides a single output which is the 3D vector:

```cpp
inline const Blocks::Ipin* Blk_azeld_1::get_out(Uint16 i) const {
    return Base::Assertions::runtime(i == 0) ? &out : 0;
}
```

## 3. Relative Position Block (Blk_relthis)

### 3.1 Overview

`Blk_relthis` calculates the relative position vector between two absolute positions in the NED frame.

### 3.2 Class Structure

```cpp
class Blk_relthis : public Blocks::Iblock {
public:
    Blk_relthis();
    virtual void step();
    virtual const Blocks::Ipin* get_out(Uint16 i) const;
    virtual void cset(Base::Lossy_error& str, Blocks::Iblock::Csetpm& params);

private:
    Blocks::Pin_ptr<Geo::Apos> in0;       // First input position
    Blocks::Pin_ptr<Geo::Apos> in1;       // Second input position
    Blocks::Pin<Maverick::Rvector3> out;  // Output relative vector
};
```

### 3.3 Calculation Logic

The block uses the `relthis()` method from the `Apos` class to calculate the relative position vector:

```cpp
void Blk_relthis::step() {
    in0.read().relthis(in1.read(), out.val);
}
```

The `relthis()` method calculates the vector from the first position to the second position in the NED frame, providing:
- North component: Distance in the north direction
- East component: Distance in the east direction
- Down component: Distance in the down direction

### 3.4 Configuration

The block is configured through its PDI with:
- `in0`: First input position address
- `in1`: Second input position address

### 3.5 Output Retrieval

The block provides a single output which is the relative position vector:

```cpp
inline const Blocks::Ipin* Blk_relthis::get_out(Uint16 i) const {
    return Base::Paramsel::select<Blocks::Ipin>(i, out);
}
```

## 4. Control to Servo Block (Blk_u2s)

### 4.1 Overview

`Blk_u2s` converts control actions to servo actions through a linear transformation, handling saturation and anti-windup strategies.

### 4.2 Class Structure

```cpp
class Blk_u2s : public Blocks::Iblock, public Blocks::Icmdblock {
public:
    Blk_u2s();
    virtual void step();
    virtual void on_focus();
    virtual const Blocks::Ipin* get_out(Uint16 i) const;
    virtual void cset(Base::Lossy_error& str, Csetpm& params);
    virtual void cset_cmd(Base::Lossy_error& str);
    virtual void cget_cmd(Base::Lossy& str) const;

private:
    // Many member variables for inputs, outputs, and internal state
    
    // Anti-windup strategy types
    enum Type {
        none       = 0,    // Saturation not corrected in any preferred direction
        linear     = 1,    // Saturation is applied to all components proportionally
        dir_lambda = 2,    // Saturation corrected in the direction of lambda
        type_all   = 3     // max type
    };
    
    Type sat_type;         // Type of saturation control
    
    // Helper methods
    void sat_u();
    bool is_sat(const Base::Mblock<const Real>& smin, const Base::Mblock<const Real>& smax);
    const Base::Mblock<const Real> get_smin() const;
    const Base::Mblock<const Real> get_smax() const;
};
```

### 4.3 Conversion Logic

The block performs the following operations:

1. **Linear Transformation**: Converts control actions to servo actions using a transformation matrix:
   ```cpp
   s.val.matvec(su, u.kvec);  // s = SU * u
   ```

2. **Saturation Check**: Checks if any servo action exceeds its limits:
   ```cpp
   if (is_sat(smin, smax)) {
       // Correct "u" to prevent saturation (if possible)
       sat_u();
       
       // Recompute "s"
       s.val.matvec(su, usat.val);
   }
   ```

3. **Rate Limiting**: Applies rate limiting to servo actions:
   ```cpp
   for (Uint32 i = 0; i < servos.size(); ++i) {
       is_ok.val[i] = !servos[i].step(dt, s.val[i], p.val[i], smin[i], smax[i]);
   }
   ```

4. **Reverse Transformation**: Calculates the actual control actions after saturation:
   ```cpp
   usat.val.matvec(us, s.val);  // usat = US * s
   ```

### 4.4 Anti-Windup Strategies

The block implements three anti-windup strategies to handle servo saturation:

1. **None** (`sat_type = none`): No correction is applied to control actions.

2. **Linear** (`sat_type = linear`): Saturation is applied proportionally to all control components:
   ```cpp
   // Direction of saturation correction is the control vector itself
   const Maverick::Tvector<Real>& dir = usat.val;
   ```

3. **Direction Lambda** (`sat_type = dir_lambda`): Saturation is corrected in a specific direction:
   ```cpp
   // Direction of saturation correction is the lambda vector
   const Maverick::Tvector<Real>& dir = lambda;
   ```

The saturation correction is calculated as:
```cpp
Real delta = Const::ZERO;  // Scalar in "dir" direction for correction
// Calculate delta based on saturation amount and projection
// ...
usat.val.add(delta, dir);  // Apply correction
```

### 4.5 Configuration

The block is configured through its PDI with:
- `in_u`: Address of control input
- `in_smin`: Optional minimum values for servos
- `in_smax`: Optional maximum values for servos
- `SU`: Matrix for transforming control actions to servo actions
- `US`: Matrix for transforming servo actions to control actions
- `sat_type`: Type of anti-windup strategy
- `lambda`: Direction vector for saturation correction
- `servos`: Array of servo configurations

### 4.6 Output Retrieval

The block provides four outputs:
- `is_ok`: Boolean array indicating if each servo is within limits
- `p`: Pulse actions for PWM output
- `s`: Servo actions after saturation
- `usat`: Control actions after saturation

```cpp
inline const Blocks::Ipin* Blk_u2s::get_out(Uint16 i) const {
    return Base::Paramsel::select<Blocks::Ipin>(i, is_ok, p, s, usat);
}
```

## 5. Type Conversion Blocks

### 5.1 Boolean to Real Conversion Block (Blk_btor)

#### 5.1.1 Overview

`Blk_btor` converts a boolean value to a real value, mapping `false` to `0.0F` and `true` to `1.0F`.

#### 5.1.2 Class Structure

```cpp
class Blk_btor : public Blocks::Iblock {
public:
    Blk_btor();
    virtual void step();
    virtual const Blocks::Ipin* get_out(Uint16 i) const;
    virtual void cset(Base::Lossy_error& str, Csetpm& params);

private:
    Blocks::Pin_ptr<bool> in;   // Boolean input
    Blocks::Pin<Real> out;      // Real output
};
```

#### 5.1.3 Conversion Logic

The conversion is straightforward:

```cpp
inline void Blk_btor::step() {
    out.val = in.read() ? 1.0F : 0.0F;
}
```

#### 5.1.4 Configuration

The block is configured through its PDI with:
- `in`: Boolean input address

#### 5.1.5 Output Retrieval

The block provides a single real output:

```cpp
inline const Blocks::Ipin* Blk_btor::get_out(Uint16 i) const {
    return Base::Assertions::runtime(i == 0) ? &out : 0;
}
```

### 5.2 Real to Boolean Conversion Block (Blk_rtob)

#### 5.2.1 Overview

`Blk_rtob` converts a real value to a boolean value, mapping any non-zero value to `true` and zero to `false`.

#### 5.2.2 Class Structure

```cpp
class Blk_rtob : public Blocks::Iblock {
public:
    Blk_rtob();
    virtual void step();
    virtual const Blocks::Ipin* get_out(Uint16 i) const;
    virtual void cset(Base::Lossy_error& str, Csetpm& params);

private:
    Blocks::Pin_ptr<Real> in;   // Real input
    Blocks::Pin<bool> out;      // Boolean output
};
```

#### 5.2.3 Conversion Logic

The conversion checks if the input is different from zero:

```cpp
inline void Blk_rtob::step() {
    out.val = (in.read() != 0.0F);
}
```

#### 5.2.4 Configuration

The block is configured through its PDI with:
- `in`: Real input address

#### 5.2.5 Output Retrieval

The block provides a single boolean output:

```cpp
inline const Blocks::Ipin* Blk_rtob::get_out(Uint16 i) const {
    return Base::Paramsel::select<Blocks::Ipin>(i, out);
}
```

### 5.3 Real to Uint16 Conversion Block (Blk_rtou)

#### 5.3.1 Overview

`Blk_rtou` converts a real value to an unsigned 16-bit integer by truncation.

#### 5.3.2 Class Structure

```cpp
class Blk_rtou : public Blocks::Iblock {
public:
    Blk_rtou();
    virtual void step();
    virtual const Blocks::Ipin* get_out(Uint16 i) const;
    virtual void cset(Base::Lossy_error& str, Csetpm& params);

private:
    Blocks::Pin_ptr<Real> in;     // Real input
    Blocks::Pin<Uint16> out;      // Uint16 output
};
```

#### 5.3.3 Conversion Logic

The conversion uses a static cast to truncate the real value:

```cpp
inline void Blk_rtou::step() {
    out.val = static_cast<Uint16>(in.read());
}
```

#### 5.3.4 Configuration

The block is configured through its PDI with:
- `in`: Real input address

#### 5.3.5 Output Retrieval

The block provides a single Uint16 output:

```cpp
inline const Blocks::Ipin* Blk_rtou::get_out(Uint16 i) const {
    return Base::Paramsel::select<Blocks::Ipin>(i, out);
}
```

### 5.4 Uint16 to Real Conversion Block (Blk_utor)

#### 5.4.1 Overview

`Blk_utor` converts an unsigned 16-bit integer to a real value.

#### 5.4.2 Class Structure

```cpp
class Blk_utor : public Blocks::Iblock {
public:
    Blk_utor();
    virtual void step();
    virtual const Blocks::Ipin* get_out(Uint16 i) const;
    virtual void cset(Base::Lossy_error& str, Csetpm& params);

private:
    Blocks::Pin_ptr<Uint16> in;   // Uint16 input
    Blocks::Pin<Real> out;        // Real output
};
```

#### 5.4.3 Conversion Logic

The conversion uses a static cast to convert the integer to a real value:

```cpp
inline void Blk_utor::step() {
    out.val = static_cast<Real>(in.read());
}
```

#### 5.4.4 Configuration

The block is configured through its PDI with:
- `in`: Uint16 input address

#### 5.4.5 Output Retrieval

The block provides a single real output:

```cpp
inline const Blocks::Ipin* Blk_utor::get_out(Uint16 i) const {
    return Base::Paramsel::select<Blocks::Ipin>(i, out);
}
```

## 6. Cross-Component Relationships

### 6.1 Coordinate Transformation Hierarchy

The coordinate transformation blocks form a hierarchy based on their transformation types:

1. **Reference Frame Transformations**
   - `Blk_n2b`: Transforms between NED and body reference frames using rotation matrices

2. **Coordinate System Transformations**
   - `Blk_azeld`: Transforms from Cartesian to spherical coordinates
   - `Blk_azeld_1`: Transforms from spherical to Cartesian coordinates

3. **Position Transformations**
   - `Blk_relthis`: Calculates relative position vectors between absolute positions

4. **Control System Transformations**
   - `Blk_u2s`: Transforms control actions to servo actions with saturation handling

### 6.2 Type Conversion Hierarchy

The type conversion blocks form a hierarchy based on their conversion types:

1. **Boolean-Real Conversions**
   - `Blk_btor`: Converts boolean to real
   - `Blk_rtob`: Converts real to boolean

2. **Integer-Real Conversions**
   - `Blk_rtou`: Converts real to unsigned 16-bit integer
   - `Blk_utor`: Converts unsigned 16-bit integer to real

### 6.3 Common Implementation Patterns

Several common patterns appear across the coordinate transformation and type conversion blocks:

1. **Pin Interface**: All blocks use the `Pin_ptr` template for inputs and the `Pin` template for outputs, providing a consistent interface for block connections.

2. **Configuration Validation**: Blocks validate their configuration during deserialization to ensure inputs have compatible types and sizes.

3. **Error Handling**: Blocks include error handling to report configuration issues through the PDI error flag.

4. **Output Selection**: Blocks implement the `get_out` method to provide access to their outputs, often using the `Paramsel::select` helper for consistent behavior.

5. **Transformation Logic**: Coordinate transformation blocks leverage methods from the `Maverick` library's vector and matrix classes for efficient transformations.

## 7. Summary

The VBlocks library provides a comprehensive set of coordinate transformation and type conversion blocks that enable:

1. **Reference Frame Transformations**: Converting vectors between NED and body reference frames
2. **Coordinate System Transformations**: Converting between Cartesian and spherical coordinates
3. **Position Transformations**: Calculating relative positions between absolute positions
4. **Control System Transformations**: Converting between control actions and servo actions with saturation handling
5. **Type Conversions**: Converting between boolean, real, and integer types

These blocks form an essential part of the VBlocks library, enabling the construction of complex control systems that operate across different coordinate systems and data types. The library's design emphasizes safety, efficiency, and flexibility, with careful handling of edge cases and error conditions.

The coordinate transformation blocks are particularly important for navigation and control applications, as they allow the system to work with different reference frames and coordinate systems as needed. The type conversion blocks provide the glue that allows blocks with different data types to be connected together, enhancing the flexibility and composability of the block system.