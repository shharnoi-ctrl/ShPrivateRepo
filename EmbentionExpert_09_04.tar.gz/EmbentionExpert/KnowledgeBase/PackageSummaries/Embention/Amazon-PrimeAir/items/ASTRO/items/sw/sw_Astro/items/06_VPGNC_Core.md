# Generated from:

- _sw_Veronte/code/vpgnc/code/include/Vpu.h (2700 tokens)
- _sw_Veronte/code/vpgnc/code/source/Vpu.cpp (12198 tokens)
- _sw_Veronte/code/vpgnc/code/include/Vpu_fw.h (19 tokens)
- _sw_Veronte/code/vpgnc/code/source/Vpu_dsp.cpp (1035 tokens)
- _sw_Veronte/code/vpgnc/code/source_SIL/Vpu_SIL.cpp (1276 tokens)
- _sw_Veronte/code/vpgnc/code/include/Vpunav.h (3983 tokens)
- _sw_Veronte/code/vpgnc/code/source/Vpunav.cpp (6473 tokens)
- _sw_Veronte/code/vpgnc/code/include/Vpunav_fw.h (22 tokens)
- _sw_Veronte/code/vpgnc/code/include/Varvpu.h (854 tokens)
- _sw_Veronte/code/vpgnc/code/source/Varvpu.cpp (1137 tokens)
- _sw_Veronte/code/vpgnc/code/include/Varguide.h (486 tokens)
- _sw_Veronte/code/vpgnc/code/source/Varguide.cpp (587 tokens)
- _sw_Veronte/code/vpgnc/code/include/Varinit.h (489 tokens)
- _sw_Veronte/code/vpgnc/code/source/Varinit.cpp (949 tokens)
- _sw_Veronte/code/vpgnc/code/include/Navextvar.h (138 tokens)
- _sw_Veronte/code/vpgnc/code/source/Navextvar.cpp (161 tokens)

## With context from:

- PackageSummaries/Embention/Amazon-PrimeAir/items/ASTRO/items/sw/sw_Astro/items/09_System_Architecture.md (5081 tokens)
- PackageSummaries/Embention/Amazon-PrimeAir/items/ASTRO/items/sw/sw_Astro/items/07_Variable_Management.md (7265 tokens)

---

# VPGNC Framework Core Components Analysis

This document provides a detailed analysis of the core components of the VPGNC (Veronte Processing Unit Guidance, Navigation, and Control) framework, focusing on the Vpu class, Vpunav class, and variable management classes.

## 1. Vpu Class: Central GNC Coordinator

The `Vpu` class serves as the central coordinator for GNC (Guidance, Navigation, and Control) tasks in the Veronte system. It manages configuration, block execution, error handling, and cross-core communication.

### 1.1 Core Components and Responsibilities

```
+----------------+         +----------------+         +----------------+
|      Vpu       |-------->| Blockfactory   |-------->| Block Programs |
+----------------+         +----------------+         +----------------+
       |                          |                          |
       v                          v                          v
+----------------+         +----------------+         +----------------+
| Configuration  |         | Navigation     |         | Event Manager  |
| Management     |         | System         |         | (Automations)  |
+----------------+         +----------------+         +----------------+
```

The `Vpu` class contains the following key components:

- **Session Management**: Tracks system time and session information
- **Cross-Core Communication**: Manages packet writing and sending between cores
- **Configuration Management**: Handles PDI configuration loading and synchronization
- **Block Management**: Coordinates execution of GNC blocks
- **Event Management**: Processes events and automations
- **Error Handling**: Manages error detection and reporting
- **System Status**: Reports system status information

### 1.2 Key Member Variables

```cpp
Base::Session ss;                       // Session info
Base::Xcpktwr xpw;                      // Cross core packet writer
Base::Vpktsend_xc ixpw;                 // Cross core packet sender
const Ver::Vfspermission fsperm;        // Veronte file system permissions
Base::Xcfile xcfile_cfg;                // Xcfile user for cfgmgr
Base::Cfgsync cfgsync;                  // Configuration synchronization
Airframe_action_wp_publish aac_publish; // Aircraft action waypoint publication manager
Ver::Xcrdsuite& xrs;                    // Cross core queue reader suite
Cyphal::Cy_msg_id_gen gen;              // Cyphal message ID Generator
Media::Cfgmgr cfg;                      // Configuration manager
Base::Errors_dual err_rd;               // Errors reader (from C1 FIFO and C2 FIFO)
Midlevel::Errors_irx err_irx;           // Errors IRX manager
Ver::Pwm_suite pwm_suite0;              // PWM suite for Veronte
Base::Checklist opchlist;               // Operation PDI check list
Opmgr omgr;                             // Operation variables manager
Base::Checklist ini_chlist;             // Checklist to get out of INI phase
Vblocks::Multi_interpolators_tuns mit;  // Multi interpolators table data tunable
Vblocks::Blockfactory blkfactory;       // Block factory
Polymgr_impl poly;                      // Polygons manager
Evtmgr evm;                             // Event manager
```

### 1.3 Initialization Process

The `Vpu` constructor performs extensive initialization of all subsystems:

1. **Basic Components Initialization**:
   - Session info with system time
   - Cross-core packet writer and sender
   - File system permissions
   - Configuration synchronization

2. **Cross-Core Components Setup**:
   - Cross-core queue reader suite
   - Cross-core file handler

3. **Configuration Manager Setup**:
   - Buffer allocation
   - File system permissions
   - Synchronization
   - Tunable and deserializable counts

4. **Error Handling Setup**:
   - Error readers for both CPU cores
   - Error IRX manager

5. **Hardware Interface Setup**:
   - PWM suite initialization

6. **Block System Setup**:
   - Block factory initialization
   - Block manager initialization
   - Polygon manager initialization

7. **Event System Setup**:
   - Event manager initialization

8. **Configuration Registration**:
   - Register components with configuration manager
   - Register commands with configuration manager
   - Register PDIs with configuration manager

9. **IRX Parser Registration**:
   - Register message handlers with IRX parser

10. **System Status Setup**:
    - Build status bit list
    - Initialize sensor bits

### 1.4 Main Execution Flow

The `Vpu::step()` method implements the main execution flow:

```cpp
void Vpu::step() {
    // Update arbiter capability on older hardware versions
    if(hwv < HWversion_ver::v4_7) {
        static Bsp::Huvar cap_47(vu_arb_cap);
        static const volatile Uint16& cap_45(Bsp::Huvar(vu_arb_apsel).get_kref());
        cap_47.set(cap_45);
    }
    
    // Execute GNC if sensors are initialized
    if(Hsys::get_ksen_init()) {
        blkfactory.step_pre_gnc();  // Prepare for GNC execution
        step_gc();                  // Execute guidance and control
        evm.step();                 // Process events (automations)
    }
    
    // Process configuration and system status
    crcpub.step();          // Process configuration CRCs publisher
    static_cfg.step();      // Process PDI CRCs
    opcheckflush.step();    // Process error operation flush
}
```

The `step_gc()` method executes the guidance and control blocks if the system has the appropriate permissions:

```cpp
void Vpu::step_gc() {
    if (Hlicense::get_kpermissions().has(Base::Permission::permission_gc)) {
        blkfactory.step_gnc();  // Execute guidance and control blocks
    }
}
```

### 1.5 Boot Mode Initialization

The `boot_mode_init()` method implements a state machine that coordinates the boot process with CPU1:

```cpp
void Vpu::boot_mode_init() {
    Base::Loadst last_lst = Base::lst_secure;
    Base::Evar<Base::Loadst> c2_loadst(Base::vu_cfg_loadst);
    
    // Wait for CPU1 to set load state (Sync 1)
    while(!lst_is_done(Hsys::get_loadst_requested())) {
        step_xqrd(-Const::ONE);
    }
    last_lst = Hsys::get_loadst_requested();
    
    // Inform CPU1 we're ready for PDI loading (Sync 2)
    Dsp28335_ent::Ipc::cpu1_unlock();
    
    // Load configuration from persistent memory
    last_lst = Media::PDI_loader::load(cfg, last_lst, false);
    
    // Post-load processing
    if(last_lst == Base::lst_normal) {
        blkfactory.post_pdi_load();
        
        // Check PDI consistency
        Base::Error err;
        xpc8_consistency_check(err);
        can_consistency_check(err);
        if (!err.is_ok()) {
            PDIcheck::commit(err);
            last_lst = Base::lst_failed;
        }
    }
    
    // Enter maintenance mode if needed
    if(last_lst != Base::lst_normal) {
        enter_maint_mode(last_lst == lst_failed);
    }
    
    // Inform CPU1 of our load state (Sync 3)
    c2_loadst.set(last_lst);
    const bool is_normal = (last_lst == lst_normal);
    
    // Wait for CPU1 to finish PDI load (Sync 4)
    Dsp28335_ent::Ipc::cpu2_wait_for_unlock();
    
    // Update system vars (Sync 4.1)
    step_xqrd(5.0F);
    Dsp28335_ent::Ipc::cpu1_unlock();
    
    // Wait for CPU1 to process (Sync 5)
    while(Hsys::get_loadst_requested() == lst_ongoing) {
        step_xqrd(-Const::ONE);
    }
    last_lst = Hsys::get_loadst_requested();
    
    // Handle CPU1 failure with CPU2 success
    if(is_normal && (last_lst == lst_failed)) {
        enter_maint_mode(true);
        sync_xctun();
        c2_loadst.set(lst_failed);  // Sync 6
    }
}
```

### 1.6 Cross-Core Communication

The `Vpu` class manages cross-core communication through several mechanisms:

1. **Cross-Core Packet Writer/Sender**:
   ```cpp
   Base::Xcpktwr xpw;        // Cross core packet writer
   Base::Vpktsend_xc ixpw;   // Cross core packet sender
   ```

2. **Cross-Core Queue Reader**:
   ```cpp
   Ver::Xcrdsuite& xrs;      // Cross core queue reader suite
   ```

3. **Cross-Core File Support**:
   ```cpp
   Base::Xcfile xcfile_cfg;  // Xcfile user for cfgmgr
   ```

4. **Cross-Core Synchronization**:
   ```cpp
   void sync_xctun();        // Synchronize cross-core tunables
   ```

5. **Cross-Core Message Processing**:
   ```cpp
   void step_xqrd(Real max_parse_time_s);  // Process cross-core messages
   ```

### 1.7 Error Handling and Consistency Checking

The `Vpu` class implements several consistency checks:

1. **Serial Connection Consistency**:
   ```cpp
   static void xpc8_consistency_check(Base::Error& err);
   ```
   Ensures that all serial custom message consumers configured to run in the high-importance task are of type external sensor.

2. **CAN Connection Consistency**:
   ```cpp
   static void can_consistency_check(Base::Error& err);
   ```
   Ensures that all CAN custom message consumers configured to run in the high-importance task are of type external sensor.

3. **Error Reporting**:
   ```cpp
   Base::Errors_dual err_rd;       // Errors reader
   Midlevel::Errors_irx err_irx;   // Errors IRX manager
   ```
   Manages error detection, reporting, and forwarding.

### 1.8 System Status Reporting

The `Vpu` class implements the `Istatus_getter` interface to provide system status information:

```cpp
virtual Uint8 get_status_version() const;
virtual void get_status_data(Base::U8ostream& os) const;
virtual void get_status_data_ex(Base::U8ostream& os) const;
virtual Base::Mblock<const Base::Bvar> get_status_bits();
```

The status data includes:
- Time since startup
- Current phase and mode
- Current patchset ID
- Position and velocity information
- Attitude information
- Configuration counters
- System status bits

## 2. Vpunav Class: Navigation System Implementation

The `Vpunav` class implements the navigation system, responsible for estimating the vehicle's position, velocity, and attitude.

### 2.1 Core Components and Responsibilities

```
+----------------+         +----------------+         +----------------+
|    Vpunav      |-------->|     Rains      |-------->|  Sensor Data   |
| (Navigation)   |         |     (EKF)      |         |  Processing    |
+----------------+         +----------------+         +----------------+
       |                          |                          |
       v                          v                          v
+----------------+         +----------------+         +----------------+
| Position &     |         | Attitude       |         | Terrain &      |
| Velocity       |         | Estimation     |         | Height         |
| Estimation     |         |                |         | Management     |
+----------------+         +----------------+         +----------------+
```

The `Vpunav` class inherits from `Dynamics::Aircraft` and contains the following key components:

- **Sensor Data Management**: Processes and filters sensor data
- **Extended Kalman Filter**: Implements state estimation
- **Attitude Estimation**: Computes vehicle orientation
- **Position and Velocity Estimation**: Computes vehicle position and velocity
- **Terrain Height Management**: Manages terrain height information
- **Variable Publishing**: Updates system variables with navigation state

### 2.2 Key Member Variables

```cpp
Ver::Suite sen;                      // Sensors data
Rains& relekf;                       // Reference to EKF
const volatile Base::Permission& permission; // License reference
const Geo::Georef& gref;             // Georef
Maverick::Fir3 dpqre;                // Numerical derivative for pqr
Gravity_extractor gb_extractor;       // Gravity from accelerometer measurements extractor
Gnc::Madgwick mwk;                   // Madgwick for reduced navigation
Ver::Inavsim navsim;                 // Simulated navigation
Geo::Vgeoref vgref;                  // Veronte's georef
Bsp::Hbvar ext_ahrs;                 // Bit for external AHRS
Maverick::Irvector3::K ext_ypr;      // External attitude
Maverick::Irvector3::K ext_pqr;      // External rotation speed
Maverick::Irvector3::K ext_vn;       // External velocity
Maverick::Irvector3::K ext_ab;       // External acceleration
Geo::Fidposcache h_ext_pos;          // External position reading from variables
Ver::Cum_fifo acc_int;               // 3 component FIFO vector to hold acc int
Varvpu vars;                         // Navigation variables
bool init_alignment_done;            // True if the initial alignment has been done
```

### 2.3 Initialization and Alignment

The `Vpunav` constructor initializes all navigation components:

```cpp
Vpunav::Vpunav(const volatile Base::Meas& kmeas0,
               const volatile Base::Permission& permission0,
               const Geo::Georef& gref0) :
    sen(*this, kmeas0, Base::kbit_ngncsim_mode),
    relekf(*Base::Memmgr::get_instance().get_allocator(
            Base::Memmgr::internal).allocate_new<Rains, Vpunav&, const Base::Memmgr::Type>(
            *this,
            Base::Memmgr::internal)),
    permission(permission0),
    gref(gref0),
    dpqre(Ku16::u101, Base::Memmgr::external, 1),
    gb_extractor(sen.get_fb(), pqr),
    mwk(gb_extractor.get_estimated_gb()),
    vgref(),
    ext_ahrs(Base::kbit_ext_attitude),
    ext_ypr(Bsp::Hrvar::get_kblock(Base::v_extypr0, Base::v_extypr2).to_non_volatile()),
    ext_pqr(Bsp::Hrvar::get_kblock(Base::v_extpqr0, Base::v_extpqr2).to_non_volatile()),
    ext_vn(Bsp::Hrvar::get_kblock(Base::v_extvn0, Base::v_extvn2).to_non_volatile()),
    ext_ab(Bsp::Hrvar::get_kblock(Base::v_extab0, Base::v_extab2).to_non_volatile()),
    h_ext_pos(Base::moving_00),
    vars(*this),
    init_alignment_done(false)
{
    aIb1b.zeros();
    aGb1b.zeros();
    wn1xv.zeros();
    an_1.zeros();
    ext_ahrs.set(false);
    dpqre.init_clk();
}
```

The class provides several methods for aligning the navigation system:

1. **Alignment with Body and NED Vectors**:
   ```cpp
   void alignment(const Maverick::Irvector3& Bb, const Maverick::Irvector3& Bn);
   ```
   Initializes attitude using accelerometer measurements and reference vectors in body and NED frames.

2. **Alignment with External Yaw**:
   ```cpp
   bool alignment(const Real yaw);
   ```
   Initializes attitude using accelerometer measurements and an external yaw reference.

3. **Pitch and Roll Alignment**:
   ```cpp
   void align_pitch_roll(Real& cp, Real& sp, Real& cr, Real& sr);
   ```
   Computes pitch and roll based on gravity vector measured by accelerometer.

### 2.4 Navigation Processing

The `Vpunav` class implements several methods for navigation processing:

1. **INS Computation**:
   ```cpp
   void step_attins(const Real dt, const bool is_xfull, 
                   const Base::Mblock<const Gnc::Irainsld::Alig_data*> alig);
   ```
   Executes one INS step, updating the current navigation state.

2. **EKF Integration**:
   ```cpp
   void on_ekf_load(const Rains& ekf);
   void post_ekf(Real dt);
   ```
   Processes EKF updates and applies corrections to the navigation state.

3. **External Navigation Integration**:
   ```cpp
   void step_nav_sim_state(Base::Mreadernavsim& measure, const Real dt);
   void step_nav_ext_state(Base::Mreadernav& measure, const Real dt);
   void step_nav_extvar_state(const Real dt);
   void step_nav_ext_sensor(Base::Mreadernav& measure, const Real dt);
   ```
   Updates navigation state from external sources (simulation, external navigation, system variables, or external sensors).

### 2.5 Position and Velocity Management

The `Vpunav` class provides methods for managing position and velocity:

1. **Position Setting**:
   ```cpp
   void set_nav_pos(const Base::Tllh& pos0);
   ```
   Sets the navigation position and updates dependent variables.

2. **Position and Velocity Initialization**:
   ```cpp
   void init_rv_3d(const Geo::Apos& initpos, const Maverick::Irvector3& initvel);
   void init_rv_2d(const Geo::Apos& initpos, const Maverick::Irvector3& initvel);
   ```
   Initializes 3D or 2D position and velocity.

3. **Position Obfuscation**:
   ```cpp
   void obfuscate_pos2d();
   ```
   Moves the estimated horizontal position 10 meters in a pseudo-random direction.

### 2.6 Terrain Height Management

The `Vpunav` class manages terrain height information:

```cpp
void dem_set(const Base::Lonlat& pos0, const Real dem0);
const Geo::Igeosrc& get_vgeoref() const;
```

These methods allow setting and retrieving terrain height information at specific positions.

### 2.7 Variable Publishing

The `vcommit()` method updates system variables with the current navigation state:

```cpp
void Vpunav::vcommit() {
    // Update position variables
    const Base::Tllh& llh0 = pos.get_llh();
    vars.fpos.set(llh0);
    vars.longitude.set(static_cast<Real>(llh0.ll.lon));
    vars.latitude.set(static_cast<Real>(llh0.ll.lat));
    vars.wgs84.set(static_cast<Real>(llh0.h));
    
    // Update height variables
    vars.height.set(height);
    vars.altitude.set(altitude);
    
    // Update velocity variables
    vars.V.set(V);
    vars.gsb0.set(gsb0);
    vars.gsb1.set(gsb1);
    vars.GS.set(GS);
    vars.acc_tan.set(acc_tan);
    
    // Update other variables
    vars.rpm.set(get_rpm());
    vars.rho.set(get_rho());
    vars.gnz.set(gn[Ku16::u2]);
    
    // Update vector variables
    vars.uvw.commit();
    vars.pqr.commit();
    vars.dpqr.commit();
    vars.an.commit();
    vars.vn.commit();
    vars.ypr.commit();
    vars.dypr.commit();
    vars.coypr.commit();
    vars.vhfb.commit();
    vars.ab.commit();
    vars.nb.commit();
    vars.qbn.commit();
    vars.gyr_bias.commit();
    vars.acc_bias.commit();
    
    // Update SRTM variables
    const Geo::Terrain_height srtm_h = gref.srtm_height(pos.get_llh().ll);
    vars.srtm_ok.set(srtm_h.is_ready());
    vars.srtm_type.set(srtm_h.s);
    vars.geoid_ok.set(gref.inside_geoid(pos.get_llh().ll));
}
```

## 3. Variable Management Classes

The VPGNC framework includes several classes for managing system variables and their relationships.

### 3.1 Varvpu: Navigation Variable Container

The `Varvpu` class serves as a container for navigation-related system variables:

```cpp
struct Varvpu {
    Base::Fvar::Abs fpos;      // Feature equal to pos
    Bsp::Hrvar longitude;      // Longitude
    Bsp::Hrvar latitude;       // Latitude
    Bsp::Hrvar wgs84;          // WGS84 height
    Bsp::Hrvar height;         // Height above ground level
    Bsp::Hrvar altitude;       // Altitude above mean sea level
    Bsp::Hrvar V;              // Speed
    Bsp::Hrvar gsb0;           // Ground speed x body frame
    Bsp::Hrvar gsb1;           // Ground speed y body frame
    Bsp::Hrvar GS;             // Ground speed
    Bsp::Hrvar acc_tan;        // Tangential acceleration
    Bsp::Hrvar rpm;            // RPM
    Bsp::Hrvar rho;            // Air density
    Bsp::Hrvar gnz;            // Gravity down
    
    Bsp::Hrvar::Range uvw;     // Body velocity
    Bsp::Hrvar::Range pqr;     // Angular velocity
    Bsp::Hrvar::Range dpqr;    // Angular acceleration
    Bsp::Hrvar::Range an;      // NED acceleration
    Bsp::Hrvar::Range vn;      // NED velocity
    Bsp::Hrvar::Range ypr;     // Yaw, pitch, roll
    Bsp::Hrvar::Range dypr;    // Yaw, pitch, roll rates
    Bsp::Hrvar::Range coypr;   // Cosines of yaw, pitch, roll
    Bsp::Hrvar::Range vhfb;    // Heading, flight path, bank
    Bsp::Hrvar::Range ab;      // Body acceleration
    Bsp::Hrvar::Range nb;      // Load factors
    Bsp::Hrvar::Range qbn;     // Quaternion
    
    Bsp::Hrvar::Range gyr_bias; // Gyroscope bias
    Bsp::Hrvar::Range acc_bias; // Accelerometer bias
    
    Bsp::Hbvar srtm_ok;        // SRTM data validity
    Bsp::Huvar srtm_type;      // SRTM data type
    Bsp::Hbvar geoid_ok;       // Geoid data validity
    
    explicit Varvpu(const Vpunav& b);
};
```

The constructor initializes all variables with references to the corresponding system variables:

```cpp
Varvpu::Varvpu(const Vpunav& b) :
    fpos(Base::c_vpu),
    longitude(Base::v_llh0),
    latitude(Base::v_llh1),
    wgs84(Base::v_llh2),
    height(Base::v_agl),
    altitude(Base::v_msl),
    V(Base::v_speed),
    gsb0(Base::v_gslon),
    gsb1(Base::v_gslat),
    GS(Base::v_gs),
    acc_tan(Base::v_at),
    rpm(Base::v_rpm),
    rho(Base::v_rho),
    gnz(Base::v_g_at_uav_pos),
    uvw(Mblock<const volatile Real>(b.get_uvw()), Base::v_uvw0, Base::v_uvw2),
    pqr(Mblock<const volatile Real>(b.get_pqr()), Base::v_p, Base::v_r),
    dpqr(Mblock<const volatile Real>(b.get_dpqr()), Base::v_dp, Base::v_dr),
    an(Mblock<const volatile Real>(b.get_an()), Base::v_anorth, Base::v_adown),
    vn(Mblock<const volatile Real>(b.get_vn()), Base::v_vnorth, Base::v_vdown),
    ypr(Mblock<const volatile Real>(b.get_ypr()), Base::v_yaw, Base::v_rll),
    dypr(Mblock<const volatile Real>(b.get_dypr()), Base::v_yawrt, Base::v_rllrt),
    coypr(Mblock<const volatile Real>(b.get_coypr()), Base::v_coyaw, Base::v_corll),
    vhfb(Mblock<const volatile Real>(b.get_vhfb()), Base::v_hdg, Base::v_bnk),
    ab(Mblock<const volatile Real>(b.get_ab()), Base::v_ax, Base::v_az),
    nb(Mblock<const volatile Real>(b.get_nb()), Base::v_nx, Base::v_nz),
    qbn(Mblock<const volatile Real>(b.get_qbn()), Base::v_qbns, Base::v_qbnk),
    gyr_bias(Mblock<const volatile Real>(b.sen.get_wb_estimated_bias()), 
             Base::v_gyr_bias_x, Base::v_gyr_bias_z),
    acc_bias(Mblock<const volatile Real>(b.sen.get_fb_estimated_bias()), 
             Base::v_acc_bias_x, Base::v_acc_bias_z),
    srtm_ok(Base::kbit_srtm),
    srtm_type(Base::vu_srtm_type),
    geoid_ok(Base::kbit_geoid)
{
}
```

### 3.2 Varguide: Guidance Variable Container

The `Varguide` class serves as a container for guidance-related system variables:

```cpp
class Varguide {
public:
    Base::Fvar::Abs fpos;          // Feature position
    Bsp::Hrvar longitude;          // Longitude
    Bsp::Hrvar latitude;           // Latitude
    Bsp::Hrvar wgs84;              // WGS84 height
    Bsp::Hrvar height;             // Height above ground level
    Bsp::Hrvar altitude;           // Altitude above mean sea level
    Bsp::Hrvar V;                  // Speed
    Bsp::Hrvar gsb0;               // Ground speed x body frame
    Bsp::Hrvar gsb1;               // Ground speed y body frame
    Bsp::Hrvar GS;                 // Ground speed
    Bsp::Hrvar acc_tan;            // Tangential acceleration
    Bsp::Hrvar yaw;                // Yaw
    Bsp::Hrvar rpm;                // RPM
    Bsp::Hrvar IAS;                // Indicated airspeed
    Bsp::Huvar route_current;      // Current waypoint
    Bsp::Huvar route_achieved;     // Achieved waypoint
    Bsp::Huvar laps_count;         // Number of times waypoint 0 achieved
    Bsp::Hrvar ne;                 // Guidance north error
    Bsp::Hrvar ee;                 // Guidance east error
    Bsp::Hrvar de;                 // Guidance down error
    Bsp::Hrvar obst_effect_dist;   // Distance at which obstacles affect guidance
    
    Bsp::Hrvar::Range modaz;       // Azimuth modifiers
    Bsp::Hrvar::Range model;       // Elevation modifiers
    Bsp::Hrvar::Range uvw;         // Body velocity
    Bsp::Hrvar::Range pqr;         // Angular velocity
    Bsp::Hrvar::Range vn;          // NED velocity
    Bsp::Hrvar::Range ypr;         // Yaw, pitch, roll
    Bsp::Hrvar::Range coypr;       // Cosines of yaw, pitch, roll
    Bsp::Hrvar::Range vhfb;        // Heading, flight path, bank
    Bsp::Hrvar::Range ab;          // Body acceleration
    Bsp::Hrvar::Range nb;          // Load factors
    Bsp::Hrvar::Range shv;         // Guidance variables
    Bsp::Hrvar::Range pid_vc;      // Guidance PID desired velocity (NED)
    
    explicit Varguide(const Guidance& b);
};
```

### 3.3 Varinit: Variable Initialization

The `Varinit` class manages the initialization of user-writable system variables on system startup:

```cpp
class Varinit {
public:
    Varinit();
    void cset(Base::Lossy_error& str);
    
private:
    struct Value0 {
        Base::Vtype vartype;  // Variable type
        Uint16 index;         // Variable index
        Real val0;            // Initial value
        
        Value0();
        void cset(Base::Lossy_error& str);
        void apply() const;
    };
    
    static const Uint16 max_vars = 96U;  // Maximum number of variables
    Base::Tnarrayresz<Value0,max_vars> v_init;  // User variables - Initial values
};
```

The `cset` method deserializes the configuration from a PDI:

```cpp
void Varinit::cset(Base::Lossy_error& str) {
    Uint16 sz = 0;
    str.get_uint16(sz);
    str.assrt(v_init.resize(sz), Base::err_varinit0);
    
    for (Uint32 i = 0; i < v_init.size(); ++i) {
        v_init[i].cset(str);
    }
    
    if (str.is_ok()) {
        for (Uint32 i = 0; i < v_init.size(); ++i) {
            v_init[i].apply();
        }
    }
}
```

The `Value0::apply` method sets the initial value in the appropriate system variable:

```cpp
void Varinit::Value0::apply() const {
    static Base::Varmgr& vmgr = Base::Varmgr::get_instance();
    switch(vartype) {
        case Base::real_float32:
        case Base::real_fixed:
            vmgr.set(static_cast<Base::Rvar>(index), val0);
            break;
        case Base::uinteger16:
            vmgr.set(static_cast<Base::Uvar>(index), static_cast<Uint16>(val0));
            break;
        case Base::bit:
            vmgr.set(static_cast<Base::Bvar>(index), static_cast<bool>(val0));
            break;
        default:
            break;
    }
}
```

### 3.4 Navextvar: External Navigation Variables

The `Navextvar` class monitors external navigation variables:

```cpp
class Navextvar {
public:
    Navextvar();
    void step();
    
private:
    const Bsp::Hrvar extgpstow;  // External GPS time of week
    Base::Wchronovar wdog;       // Watchdog timer
    Real last_gpstow;            // Last GPS time of week
};
```

The `step` method monitors the external GPS time of week variable and updates a watchdog timer:

```cpp
void Navextvar::step() {
    const Real gpstow = extgpstow.get();
    if (!Rfun::comp_real(gpstow, last_gpstow, Const::E1000)) {
        last_gpstow = gpstow;
        wdog.tic();
    }
    wdog.watch();
}
```

## 4. Cross-Core Variable Communication Flow

The VPGNC framework uses a sophisticated system for managing variables across CPU cores:

1. **Variable Definition**:
   - Variables are defined in the system with specific IDs (e.g., `Base::v_yaw`, `Base::kbit_gpsnav`)
   - These IDs are used to access the variables through handler classes

2. **Variable Access Handlers**:
   - `Hrvar`: Handler for real variables
   - `Huvar`: Handler for unsigned integer variables
   - `Hbvar`: Handler for boolean variables

3. **Variable Containers**:
   - `Varvpu`: Container for navigation variables
   - `Varguide`: Container for guidance variables

4. **Variable Initialization**:
   - `Varinit`: Initializes user-writable variables on startup

5. **Variable Publishing**:
   - `Vpunav::vcommit()`: Updates system variables with navigation state

6. **Cross-Core Communication**:
   - CPU1 owns the primary copy of variables
   - CPU2 maintains a local copy
   - When CPU1 updates a variable, it sends a message to CPU2
   - When CPU2 updates a variable, it updates its local copy
   - Both CPUs can read variables from CPU2's memory

## 5. Key Workflows

### 5.1 Navigation State Update

1. **Sensor Data Processing**:
   - `Vpunav::step_attins()` processes IMU data
   - Updates attitude, position, and velocity

2. **EKF Integration**:
   - `Vpunav::on_ekf_load()` applies EKF corrections
   - `Vpunav::post_ekf()` computes dependent variables

3. **Variable Publishing**:
   - `Vpunav::vcommit()` updates system variables
   - Variables are accessible to other components

### 5.2 Boot Mode Initialization

1. **Wait for CPU1**:
   - Wait for CPU1 to set load state
   - Process cross-core messages

2. **Load Configuration**:
   - Load PDIs from persistent memory
   - Check PDI consistency

3. **Enter Appropriate Mode**:
   - Normal mode if PDIs loaded successfully
   - Maintenance mode if errors occurred

4. **Synchronize with CPU1**:
   - Inform CPU1 of load state
   - Wait for CPU1 to finish PDI load

5. **Handle Cross-Core Synchronization**:
   - Handle case where CPU1 failed but CPU2 succeeded
   - Enter maintenance mode if needed

### 5.3 GNC Execution

1. **Pre-GNC Preparation**:
   - `blkfactory.step_pre_gnc()` prepares for GNC execution

2. **Guidance and Control Execution**:
   - `step_gc()` executes guidance and control blocks
   - Only if system has appropriate permissions

3. **Event Processing**:
   - `evm.step()` processes events and automations

4. **System Status Update**:
   - Update configuration CRCs
   - Process PDI CRCs
   - Process error operation flush

## 6. Referenced Context Files

The following context files provided valuable information for understanding the VPGNC framework:

1. `09_System_Architecture.md` - Provided overview of the Veronte system architecture, including cross-core communication mechanisms
2. `07_Variable_Management.md` - Provided details on the variable management system and how variables are shared between cores

These files helped establish the broader context in which the VPGNC framework operates, particularly regarding the multi-core architecture and variable management system.