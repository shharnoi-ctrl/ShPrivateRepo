# Generated from:

- Amazon-PrimeAir/items/ASTRO/items/sw/sw_PA_SIL/02_Controllers_Module.md (3192 tokens)
- Amazon-PrimeAir/items/ASTRO/items/sw/sw_PA_SIL/02_Controllers_Test.md (2475 tokens)

---

# Comprehensive Control System Architecture and Functionality

## 1. Control System Overview

The Prime Air drone control system is a sophisticated flight management architecture designed to ensure stable and precise flight operations. The system follows a hierarchical design with distinct components handling different aspects of flight control:

1. **High-Level Control Interface** (`Emb_controllers_wrapper`): Serves as the primary interface between the Software-In-the-Loop (SIL) framework and the embedded controllers, managing initialization, execution scheduling, and message passing.

2. **Force and Torque Allocation** (`Mixer_wrapper`): Responsible for translating high-level force and torque commands into specific motor outputs for the hexacopter configuration.

3. **Trajectory Planning and Execution**: Handles the generation and execution of flight paths through various maneuver types (straight, turn, roll) while respecting vehicle dynamics and constraints.

4. **Recovery System**: Provides contingency handling and failsafe mechanisms to ensure safe operation under anomalous conditions.

## 2. Control System Architecture

### 2.1 Core Components and Data Flow

```
SIL Framework
    |
    v
Emb_controllers_wrapper (64Hz execution cycle)
    |
    |-- Control_builder
    |       |
    |       v
    |   Recovery_wrapper_control_system_object
    |       |
    |       v
    |-- Mixer_wrapper
    |       |
    |       |-- Pa_scheduler (Flight regime-based gain scheduling)
    |       |       |
    |       |       v
    |       |-- Mixer_allocator (Constrained optimization)
    |               |
    |               v
    |           Actuator_allocator_object (Motor command generation)
    |
    |-- Message Handling (PutMessage/GetMessage)
            |
            v
        Vehicle Systems
```

### 2.2 Execution Flow

The control system operates on a deterministic 64Hz cycle (15.625ms intervals), following this sequence:

1. **Input Processing**: Receives and processes state estimates, commands, and environmental data
2. **Control Computation**: Processes inputs through the control system to generate force and torque requests
3. **Force/Torque Allocation**: Allocates high-level commands to individual motor outputs
4. **Output Generation**: Produces motor commands and telemetry data
5. **Scheduling**: Schedules the next execution cycle

```cpp
bool Emb_controllers_wrapper::ExecuteAndScheduleNextExecutionInNs(uint64_t& interval_ns) {
    data.get()->control.build_if_needed();
    Bsp::Htimehelper::set_time_us(Base::Ttime(static_cast<double>(simulation_time_ns) * 1.0E-9));
    Pa_blocks::Recovery_wrapper_control_system_object::Input& input = data.get()->rwcso_input;
    input.timestamp_monontonic_ns = simulation_time_ns;
    data.get()->control.step(data.get()->rwcso_input, data.get()->rwcso_output);
    data.get()->rwcso_input.state_estimate.clear();
    interval_ns = static_cast<uint64_t>(15.625F * Const::E1000 * Const::FROM_NANO);
    simulation_time_ns += interval_ns;
    data.get()->update_reset_allowed();
    return true;
}
```

## 3. Control Algorithms and Methods

### 3.1 Force and Torque Allocation

The control system uses a constrained quadratic programming (CQP) approach to allocate forces and torques to individual motors:

1. **Input Processing**: Takes force and torque requests in 6 dimensions (Fx, Fy, Fz, L, M, N)
2. **Scheduling Data Integration**: Incorporates acceleration commands, feedforward acceleration, air density, and dynamic pressure
3. **Optimization-Based Allocation**: Uses the `mixer_allocator.step()` method to perform constrained optimization
4. **Output Generation**: Produces motor commands in RPM for each of the 6 motors

```cpp
// Force and torque request processing
fm_vtol_request_N_and_N_m[0] = in.forces_and_torques_request.fx_N;
fm_vtol_request_N_and_N_m[1] = in.forces_and_torques_request.fy_N;
fm_vtol_request_N_and_N_m[2] = in.forces_and_torques_request.fz_N;
fm_vtol_request_N_and_N_m[3] = in.forces_and_torques_request.l_N_m;
fm_vtol_request_N_and_N_m[4] = in.forces_and_torques_request.m_N_m;
fm_vtol_request_N_and_N_m[5] = in.forces_and_torques_request.n_N_m;

// Allocation algorithm execution
Singleton::get_instance().mixer_allocator.step(previous_actuator_cmd, fm_vtol_request_N_and_N_m, scheduled_data);

// Output processing
for (Uint16 i = 0; i < 6; i++) {
    out.actuator_setpoints.motor_commanded_rpm[i] = krpm2_2_rpm(out_mixer.actuators[i]);
}
```

### 3.2 Flight Regime-Based Gain Scheduling

The `Pa_scheduler` component selects and evaluates the appropriate control parameters based on the current flight regime:

```cpp
Pa_blocks::Pa_scheduler::get_instance().pick_scheduler_and_evaluate(rotor, in_sheduler);
const Pa_blocks::Pa_scheduler::Outputs& scheduled_data = Pa_blocks::Pa_scheduler::get_instance().get_outputs();
```

This allows the control system to adapt to different flight phases (VTOL, transition, wing-borne flight) with appropriate control gains and parameters.

### 3.3 Trajectory Planning and Execution

The control system supports sophisticated trajectory planning through several maneuver types:

1. **Straight Maneuvers**: Linear paths between waypoints
2. **Turn Maneuvers**: Curved paths with specified turn radius
3. **Roll Maneuvers**: Transitions between different bank angles
4. **Vertical Maneuvers**: Changes in altitude

Each maneuver type is constructed to respect vehicle dynamics constraints and ensure smooth transitions between waypoints.

## 4. Vehicle Configuration and Control Allocation

The control system is designed for a hexacopter configuration with 6 motors arranged in the following pattern:

1. Rear right
2. Center right
3. Front right
4. Front left
5. Center left
6. Rear left

This configuration provides full control authority in all 6 degrees of freedom (3 forces and 3 torques), allowing precise control of the vehicle's position and orientation.

## 5. Testing and Verification Framework

The control system is rigorously tested through a comprehensive test suite that verifies its behavior across various scenarios:

### 5.1 Trajectory Planning Tests

- **Maneuver Coordinate Tests**: Verify the construction, evaluation, and integration of polynomial trajectories
- **Waypoint Tests**: Verify waypoint representation and operations
- **Maneuver Type Tests**: Verify the construction and execution of different maneuver types (straight, turn, roll)

### 5.2 Testing Methodologies

The test suite employs several methodologies to ensure comprehensive verification:

1. **Validity Testing**: Verifies proper initialization and validation of control components
2. **Edge Case Testing**: Targets boundary conditions like zero duration, zero speed, or zero turn radius
3. **Random Input Testing**: Uses randomized inputs to ensure robustness across diverse scenarios
4. **Comparison with Expected Values**: Compares computed values with expected results, often derived from MATLAB implementations
5. **Invariance Testing**: Verifies that certain operations preserve important properties

### 5.3 Key Algorithms Tested

- **Trajectory Generation**: Verifies that trajectories meet kinematic constraints and boundary conditions
- **Maneuver Construction**: Verifies correct construction of different maneuver types
- **Coordinate Transformations**: Verifies accurate transformation between coordinate systems
- **Route Planning**: Verifies proper construction and evaluation of multi-maneuver routes
- **Stopping Behavior**: Verifies correct computation of stopping locations

## 6. Communication and Integration

### 6.1 Message Handling

The control system uses a comprehensive message-passing architecture for communication with other components:

#### Input Messages (`PutMessage`):
- State estimates (position, velocity, attitude)
- Controller commands
- Battery status
- Contingency commands
- Mission reset commands
- Motor performance data
- Mission readiness messages
- Mission plan data
- Switch-over signals

#### Output Messages (`GetMessage`):
- Motor RPM commands for each motor
- Mode transition allowance
- Controller telemetry
- Recovery telemetry
- Alerts
- Mission readiness signals
- On-ground controller information
- Pre-flight check telemetry

### 6.2 SIL Framework Integration

The control system integrates with the SIL framework through the `FirmwareSimulation` interface:

```cpp
extern "C" {
    FirmwareSimulation* get_firmware_simulation_instance() {
        static FirmwareSimulation* ret = new Wrapper::Emb_controllers_wrapper();
        return ret;
    }
}
```

This allows the control system to be tested in a simulated environment before deployment on the actual hardware.

## 7. Recovery System Integration

The control system includes robust recovery functionality to handle anomalous conditions:

- **Recovery Mode Transitions**: Manages transitions to recovery modes
- **Recovery Motor Commands**: Generates appropriate motor commands during recovery
- **Recovery Telemetry**: Provides detailed telemetry during recovery operations
- **Recovery Alerts**: Generates alerts for recovery-related events
- **Recovery Mission Readiness**: Assesses readiness for recovery operations

This integration ensures that the vehicle can respond appropriately to unexpected situations and maintain safe operation.

## 8. Geographic Coordinate Handling

The control system includes utilities for geographic coordinate conversions:

- **NED Conversions**: Converts between LLA (Latitude, Longitude, Altitude) and NED (North, East, Down) coordinates
- **Coordinate Transformations**: Supports various coordinate transformations for trajectory planning and execution

These utilities ensure accurate navigation and control in real-world geographic coordinates.

## 9. Control System Performance and Stability

The control system is designed to maintain stable flight under various conditions:

- **Constrained Optimization**: Uses constrained quadratic programming to allocate forces and torques within actuator limits
- **Gain Scheduling**: Adapts control parameters based on flight regime
- **Trajectory Constraints**: Generates trajectories that respect vehicle dynamics constraints
- **Recovery Handling**: Provides robust recovery mechanisms for anomalous conditions

The comprehensive test suite verifies that the control system maintains stability and performance across a wide range of scenarios, including edge cases and random inputs.

## 10. Summary

The Prime Air drone control system is a sophisticated flight management architecture that combines advanced control algorithms, trajectory planning, and recovery mechanisms to ensure stable and precise flight operations. The system's modular design, comprehensive testing framework, and integration with the SIL environment enable robust verification before deployment on actual hardware.

The control system's ability to handle different flight regimes, allocate forces and torques optimally, and execute complex trajectories while respecting vehicle dynamics constraints makes it well-suited for autonomous drone operations in diverse environments.