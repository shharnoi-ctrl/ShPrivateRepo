# Generated from:

- Amazon-PrimeAir/items/ASTRO/items/sw/sw_PA_SIL/02_Core_SIL_Framework.md (4103 tokens)
- Amazon-PrimeAir/items/ASTRO/items/sw/sw_PA_SIL/02_SIL_Base_Components.md (3354 tokens)
- Amazon-PrimeAir/items/ASTRO/items/sw/sw_PA_SIL/02_Application_Interfaces.md (5868 tokens)

---

# Prime Air SIL System Architecture Overview

## 1. System Architecture and Component Organization

The Prime Air Software-In-the-Loop (SIL) system is a comprehensive simulation framework designed to test and validate the flight control software for Amazon's Prime Air delivery drones. The system follows a layered architecture with clear separation of concerns:

```
┌─────────────────────────────────────────────────────────────┐
│                  Application Interfaces                     │
│  ┌───────────────┐  ┌───────────────┐  ┌───────────────┐    │
│  │  AstroConsole │  │    AstroDLL   │  │    AstroSO    │    │
│  │   (Windows)   │  │   (Windows)   │  │    (Linux)    │    │
│  └───────────────┘  └───────────────┘  └───────────────┘    │
├─────────────────────────────────────────────────────────────┤
│                   Core SIL Framework                        │
│  ┌───────────────┐  ┌───────────────┐  ┌───────────────┐    │
│  │ Message System│  │  Navigation   │  │   Recovery    │    │
│  │               │  │    System     │  │    System     │    │
│  └───────────────┘  └───────────────┘  └───────────────┘    │
├─────────────────────────────────────────────────────────────┤
│                     SIL Base Components                     │
│  ┌───────────────┐  ┌───────────────┐  ┌───────────────┐    │
│  │ Firmware      │  │ Configuration │  │ Serialization │    │
│  │ Simulation    │  │ Management    │  │ Utilities     │    │
│  └───────────────┘  └───────────────┘  └───────────────┘    │
└─────────────────────────────────────────────────────────────┘
```

### 1.1 Layer Responsibilities

1. **SIL Base Components**: Provides the foundational interfaces and utilities:
   - `FirmwareSimulation` interface hierarchy
   - Configuration management
   - Serialization utilities
   - Memory management

2. **Core SIL Framework**: Implements the simulation logic:
   - Message handling system
   - Navigation system
   - Recovery system
   - Controller system

3. **Application Interfaces**: Provides platform-specific entry points:
   - Windows console application and DLL interface
   - Linux console application and shared object interface

## 2. Data Flow Architecture

The SIL system implements a comprehensive data flow architecture that simulates the entire drone operation:

```
┌───────────────┐    ┌───────────────┐    ┌───────────────┐
│ External      │    │ SIL Framework │    │ Vehicle       │
│ Simulation    │◄───┤ Message       ├───►│ Control       │
│ Environment   │    │ System        │    │ Systems       │
└───────┬───────┘    └───────────────┘    └───────┬───────┘
        │                                         │
        │            ┌───────────────┐            │
        └───────────►│ Navigation    ├────────────┘
                     │ System        │
                     └───────────────┘
```

### 2.1 Message Flow

1. **Input Processing**:
   - External stimuli (sensor data, commands) enter through the `PutMessage` method
   - Messages are deserialized and routed to appropriate components

2. **Internal Processing**:
   - Navigation system processes sensor data to produce state estimates
   - Controller system uses state estimates to generate control commands
   - Recovery system monitors for contingency situations

3. **Output Generation**:
   - Components generate output messages (actuator commands, telemetry)
   - Messages are serialized and made available through the `GetMessage` method

### 2.2 Execution Flow

The execution flow is managed through a scheduled execution model:

1. The `ExecuteAndScheduleNextExecutionInNs` method runs a simulation step
2. Each step processes inputs, updates internal state, and generates outputs
3. The method returns the time interval until the next execution
4. The application layer manages timing to ensure real-time or faster-than-real-time simulation

## 3. Core Abstractions and Design Patterns

The SIL system employs several key abstractions and design patterns:

### 3.1 Interface-Based Design

The system uses interface-based design to achieve modularity and extensibility:

- `FirmwareSimulation`: Main interface for firmware simulation
- `FirmwareSimulationLifeCycle`: Interface for lifecycle management
- `FirmwareSimulationDataExchange`: Interface for data exchange

This approach allows for multiple implementations and easy extension.

### 3.2 Wrapper Pattern

Wrapper classes provide a clean interface to platform-specific implementations:

- `Astro_dll_wrapper`: Wraps the Windows DLL interface
- `Astro_so_wrapper`: Wraps the Linux shared object interface
- `Emb_navigation_wrapper`: Wraps the navigation system
- `Recovery_lane_step1_wrapper`: Wraps the recovery system

These wrappers abstract platform differences and provide a consistent interface.

### 3.3 Factory Pattern

The system uses factory methods to create instances:

```cpp
extern "C" {
    FirmwareSimulation * get_firmware_simulation_instance();
}
```

This allows for dynamic loading and configuration of the system.

### 3.4 Singleton Pattern

Configuration managers and shared resources are implemented as singletons:

```cpp
Media::Cfgmgr& get_cfgmgr()
{
    static Media::Cfgmgr cfg(...);
    return cfg;
}
```

This ensures a single instance is shared across the application.

### 3.5 Message-Passing Architecture

The system uses a message-passing architecture for communication between components:

- Messages are defined in `Recovery_messages.h`
- Components communicate through the `PutMessage` and `GetMessage` methods
- Message types include navigation messages, control messages, and sensor data

## 4. Component Integration and Relationships

### 4.1 Navigation System Integration

The navigation system integrates with other components through:

1. **Input Integration**:
   - Receives sensor data through message handlers
   - Processes IMU, GNSS, lidar, and pressure sensor data

2. **Output Integration**:
   - Produces state estimates consumed by the controller system
   - Provides status information to the recovery system

3. **Configuration Integration**:
   - Loads parameters from PDI files during initialization
   - Uses the `Knobs` class for configuration

### 4.2 Recovery System Integration

The recovery system integrates with other components through:

1. **Input Integration**:
   - Receives state estimates from the navigation system
   - Monitors for contingency situations

2. **Output Integration**:
   - Controls motor state through the `motor_state_request` structure
   - Triggers contingency actions when necessary

3. **Switchover Integration**:
   - Handles switchover between primary and recovery systems
   - Sets GPIO signals for hardware switchover

### 4.3 Controller System Integration

The controller system integrates with other components through:

1. **Input Integration**:
   - Receives state estimates from the navigation system
   - Receives mission commands from the route tracking system

2. **Output Integration**:
   - Generates motor commands through the `MotorRpmCommand` structure
   - Provides status information to the monitoring system

3. **State Machine Integration**:
   - Manages multiple state machines for different aspects of control
   - Coordinates with the recovery system for contingency handling

## 5. Execution Model

The SIL system implements a hybrid execution model combining event-driven and time-triggered approaches:

### 5.1 Time-Triggered Execution

The primary execution model is time-triggered:

```cpp
bool ExecuteAndScheduleNextExecutionInNs(uint64_t & interval_ns)
{
    // Execute simulation step
    // ...
    
    // Schedule next execution
    interval_ns = static_cast<uint64_t>(2.0F * Const::E1000 * Const::FROM_NANO);
    return true;
}
```

This ensures deterministic execution with a fixed rate (typically 500Hz).

### 5.2 Event-Driven Processing

Within the time-triggered framework, the system processes events:

1. Message arrival triggers processing in the appropriate component
2. State changes trigger transitions in state machines
3. Contingency situations trigger recovery actions

### 5.3 Real-Time Synchronization

The application layer manages real-time synchronization:

```cpp
while (t < next_time)
{
    const auto pc_time_now = std::chrono::high_resolution_clock::now();
    t = std::chrono::duration<double>(pc_time_now - pc_time_start).count();
}
```

This ensures that simulation time matches real-world time or runs at a controlled rate.

## 6. Configuration System

The SIL system implements a comprehensive configuration system:

### 6.1 Configuration Sources

Configuration data comes from multiple sources:

1. **Command-Line Arguments**: Provide basic configuration like paths and versions
2. **Configuration Files**: `dll_config.vcfg` provides additional configuration
3. **PDI Files**: Provide detailed configuration for specific components

### 6.2 Configuration Management

The `Knobs` class manages configuration parameters:

```cpp
struct Knobs
{
    // Navigation parameters
    Real nav_params_gnss_outage_duration_before_degraded_s;
    Real nav_params_gnss_outage_duration_before_invalid_s;
    
    // Vehicle parameters
    Real vehicle_params_mass_kg;
    Real vehicle_params_inertia_xx_kg_m2;
    
    // On-ground detection parameters
    Real on_ground_detection_params_min_time_in_air_s;
    Real on_ground_detection_params_max_time_for_detection_s;
    
    // Sensor filtering parameters
    Real sensor_filtering_params_accel_lpf_cutoff_hz;
    Real sensor_filtering_params_gyro_lpf_cutoff_hz;
};
```

These parameters are loaded during initialization and used throughout the system.

### 6.3 PDI Loading

The system loads configuration data from PDI files:

```cpp
const std::vector<uint8_t>& pdi_varini = init_data.configuration_data[std::to_string(static_cast<Uint16>(Base::Cfg::cfg_vmgr))];
if(pdi_varini.size() > 0U)
{
    Base::Lossy_error str(reinterpret_cast<uint16_t*>(const_cast<unsigned char*>(pdi_varini.data())), (pdi_varini.size() + 1) / 2);
    str.skip_bytes(6U); // Skip bytes of major, minor and revision
    Vpgnc::Varinit varinit;
    varinit.cset(str);
}
```

This allows for detailed configuration of specific components.

## 7. Cross-Platform Support

The SIL system provides cross-platform support through platform-specific implementations with a common interface:

### 7.1 Common Interface

Both Windows and Linux implementations use the same interface:

```cpp
Ver_lib_version get_dll_interface_version();
uint16_t init(char* image_path, char* hw_ver, uint16_t id_ver, FILE* log, Ver_init_out* v);
double step(double t, Ver_input_dll* in, Ver_output_dll* out);
double get_gnc_period();
double get_cio_hi_period();
bool reset_requested();
```

### 7.2 Platform-Specific Implementations

Platform-specific code is isolated in the application interfaces:

1. **Windows Implementation**:
   - Uses `LoadLibraryA` and `GetProcAddress` for dynamic loading
   - Implements Windows-specific path handling

2. **Linux Implementation**:
   - Uses `dlopen` and `dlsym` for dynamic loading
   - Implements Linux-specific path handling

### 7.3 Wrapper Classes

Wrapper classes abstract platform differences:

```cpp
// Windows
const std::unique_ptr<Vdll::Astro_dll_wrapper> verdll = 
    std::make_unique<Vdll::Astro_dll_wrapper>(dll_path, image_path, hw_version, id_version, stderr);

// Linux
const std::unique_ptr<Vdll::Astro_so_wrapper> verdll = 
    std::make_unique<Vdll::Astro_so_wrapper>(dll_path, image_path, hw_version, id_version, stderr);
```

The rest of the code remains identical across platforms.

## 8. Conclusion: Key Architectural Strengths

The Prime Air SIL system architecture demonstrates several key strengths:

1. **Modularity**: Clear separation of concerns between components
2. **Extensibility**: Interface-based design allows for easy extension
3. **Cross-Platform Support**: Common interface with platform-specific implementations
4. **Configurability**: Comprehensive configuration system with multiple sources
5. **Real-Time Capability**: Hybrid execution model with real-time synchronization
6. **Comprehensive Simulation**: Full simulation of navigation, control, and recovery systems

These architectural strengths enable the SIL system to provide a robust simulation environment for testing and validating the Prime Air drone control software across different platforms and configurations.