# Generated from:

- items/pdi_Recovery0/setup/ver_spdif_gpio.xml (733 tokens)
- items/pdi_Recovery0/setup/ver_spdif_pwmdev.xml (1240 tokens)
- items/pdi_Recovery0/setup/ver_spdif_pulse.xml (908 tokens)
- items/pdi_Recovery0/setup/ver_spdif_ecap.xml (451 tokens)
- items/pdi_Recovery0/setup/ver_spdif_xpecap.xml (257 tokens)
- items/pdi_Recovery0/setup/ver_spdif_xpcu8.xml (463 tokens)
- items/pdi_Recovery0/setup/ver_spdif_ppm0.xml (1137 tokens)
- items/pdi_Recovery0/setup/ver_spdif_ppm1.xml (1138 tokens)
- items/pdi_Recovery0/setup/ver_spdif_ppm2.xml (1138 tokens)
- items/pdi_Recovery0/setup/ver_spdif_ppm3.xml (1138 tokens)
- items/pdi_Recovery0/setup/ver_spdif_rpm.xml (309 tokens)
- items/pdi_Recovery0/setup/ver_spdif_stick.xml (58 tokens)
- items/pdi_Recovery0/setup/ver_spdif_stickvar.xml (90 tokens)
- items/pdi_Recovery0/setup/ver_spdif_stg_ua_stick.xml (64 tokens)
- items/pdi_Recovery0/setup/ver_spdif_stg_ua_lights.xml (66 tokens)
- items/pdi_Recovery0/setup/ver_spdif_stg_ports_cfg.xml (141 tokens)

---

# Hardware I/O Configuration Analysis for Recovery System

This document provides a comprehensive analysis of the hardware I/O configuration files for the recovery system, focusing on GPIO, PWM, pulse capture, and other hardware interface configurations.

## 1. GPIO Configuration (ver_spdif_gpio.xml)

The GPIO configuration file defines the setup for various GPIO pins used in the recovery system, including PWM pins and general I/O pins.

### GPIO-PWM Configuration (PWM000-PWM015)

All 16 PWM GPIO pins (PWM000-PWM015) share identical configuration:

| Parameter | Value | Description |
|-----------|-------|-------------|
| io        | 1     | Pin direction (1 = output) |
| pu        | 0     | Pull-up resistor disabled |
| mux       | 0     | Multiplexer setting (default) |
| q         | 0     | Initial output state (low) |

### General I/O Configuration (IO01-IO04)

Four general-purpose I/O pins (IO01-IO04) are configured with identical settings:

| Parameter | Value | Description |
|-----------|-------|-------------|
| io        | 1     | Pin direction (1 = output) |
| pu        | 0     | Pull-up resistor disabled |
| mux       | 0     | Multiplexer setting (default) |
| q         | 0     | Initial output state (low) |

This GPIO configuration establishes all pins as outputs with no pull-up resistors and initial low states, providing a clean baseline for the recovery system's hardware interface.

## 2. PWM Device Configuration (ver_spdif_pwmdev.xml)

The PWM device configuration defines 8 PWM channels (0-7), each with identical settings:

### Common PWM Channel Settings

| Parameter | Value | Description |
|-----------|-------|-------------|
| frequency | 50 Hz | PWM signal frequency (standard servo frequency) |

### PWM A/B Configuration (for each channel)

Each channel has two PWM outputs (A and B) with identical settings:

| Parameter  | Value | Description |
|------------|-------|-------------|
| activeHigh | 1     | Signal is active high (standard for servos) |
| rangeMode  | 0     | Standard range mode |
| min        | 900.0 | Minimum pulse width in microseconds |
| max        | 2100.0| Maximum pulse width in microseconds |

The PWM configuration uses standard servo control parameters (50Hz frequency, 900-2100μs pulse width) which is typical for RC servos and ESCs (Electronic Speed Controllers). This range provides approximately 120° of servo rotation or full throttle range for motors.

## 3. Pulse Capture Configuration (ver_spdif_pulse.xml)

The pulse capture module is configured with 4 capture channels (cap-pulse-1 through cap-pulse-4), each with identical settings:

### Common Pulse Capture Settings

| Parameter | Value | Description |
|-----------|-------|-------------|
| type      | 0     | Standard capture type |
| tout      | 1.0   | Timeout value in seconds |

### Time-to-Value Mapping (t2v)

Each channel has 5 time-to-value mapping points, all initialized to zero:

```
<t2v>
    <str-tunarray-element>
        <x>0.0</x>
        <y1>0.0</y1>
    </str-tunarray-element>
    ...
</t2v>
```

This configuration suggests the pulse capture is set up but not actively mapping input pulse widths to specific values, likely requiring runtime calibration or configuration.

## 4. Enhanced Capture Module Configuration (ver_spdif_ecap.xml)

The enhanced capture (ECAP) module defines 6 capture channels with specific trigger configurations:

### Common ECAP Settings

| Parameter | Value | Description |
|-----------|-------|-------------|
| enable    | 1     | Module enabled |
| wrap      | 3     | Wrap mode (3 = continuous capture) |

### ECAP Channel-Specific Settings

| Channel | GPIO ID | Trigger1 | Trigger2 | Trigger3 | Trigger4 |
|---------|---------|----------|----------|----------|----------|
| ecap1   | 100     | 0 (falling) | 1 (rising) | 0 (falling) | 1 (rising) |
| ecap2   | 101     | 0 (falling) | 1 (rising) | 0 (falling) | 1 (rising) |
| ecap3   | 102     | 0 (falling) | 1 (rising) | 0 (falling) | 1 (rising) |
| ecap4   | 103     | 0 (falling) | 1 (rising) | 0 (falling) | 1 (rising) |
| ecap5   | 100     | 0 (falling) | 1 (rising) | 0 (falling) | 1 (rising) |
| ecap6   | 100     | 0 (falling) | 1 (rising) | 0 (falling) | 1 (rising) |

The ECAP configuration shows that channels 5 and 6 share GPIO ID 100 with channel 1, which may indicate multiplexed functionality or a configuration error. All channels are configured to trigger on both rising and falling edges, enabling precise timing measurement of input signals.

## 5. Cross-Processor ECAP Configuration (ver_spdif_xpecap.xml)

This configuration defines how ECAP data is routed between processors:

| Producer | Consumer | Group | Enable |
|----------|----------|-------|--------|
| 0        | 0        | 0     | 1      |
| 1        | 4        | 0     | 1      |
| 2        | 5        | 0     | 1      |
| 3        | 6        | 0     | 1      |

This routing table shows that ECAP producers 1, 2, and 3 send their capture data to consumers 4, 5, and 6 respectively, all within group 0. This enables cross-processor sharing of timing capture data.

## 6. Cross-Processor U8 Configuration (ver_spdif_xpcu8.xml)

This configuration defines 8-bit data routing between processors:

| Producer | Consumer | Group | Enable BVar |
|----------|----------|-------|-------------|
| 1        | 38       | 0     | 1           |
| 4        | 17       | 1     | 1           |
| 17       | 4        | 1     | 1           |
| 38       | 18       | 1     | 1           |
| 18       | 36       | 1     | 1           |
| 44       | 39       | 0     | 1           |
| 40       | 2        | 0     | 570         |
| 2        | 40       | 0     | 570         |

This routing table establishes bidirectional communication paths between various system components. The last two entries use a specific boolean variable (570) as an enable condition, suggesting conditional data routing based on system state.

## 7. PPM Receiver Configuration (ver_spdif_ppm0.xml, ppm1.xml, ppm2.xml, ppm3.xml)

Four identical PPM (Pulse Position Modulation) receiver configurations are defined, each supporting 16 channels:

### Common PPM Settings

| Parameter        | Value     | Description |
|------------------|-----------|-------------|
| puls_pol         | 0         | Pulse polarity (0 = active low) |
| vguard           | 0.004     | Guard time in seconds (4ms) |
| puls_min         | 0.00025   | Minimum pulse width (250μs) |
| puls_max         | 0.0005    | Maximum pulse width (500μs) |
| valid_min        | 0.0008    | Minimum valid signal (800μs) |
| valid_max        | 0.0022    | Maximum valid signal (2.2ms) |
| pos_min          | 0.0009    | Minimum position value (900μs) |
| pos_max          | 0.0021    | Maximum position value (2.1ms) |
| ch_num           | 16        | Number of channels |
| chmsk            | 4095      | Channel mask (first 12 channels enabled) |
| fmsk             | 4294967295| Frame mask (all bits set) |

### Frame Glitch Logic (FGL)

| Parameter        | Value     | Description |
|------------------|-----------|-------------|
| delta_min        | 0.0       | Minimum delta for glitch detection |
| delta_max        | 1000.0    | Maximum delta for glitch detection |
| delta_min_alpha  | 1.0       | Alpha filter for min delta |
| delta_max_alpha  | 0.02      | Alpha filter for max delta |

### Channel Configuration

All 16 channels in each PPM receiver are configured identically:
- trim: 0 (no trim)
- type: 0 (direct mapping)

The PPM configuration is designed to decode standard RC receiver signals with pulse widths between 900μs and 2.1ms, with appropriate glitch filtering and timing parameters.

## 8. RPM Measurement Configuration (ver_spdif_rpm.xml)

Six identical RPM measurement channels are configured:

### Common RPM Settings

| Parameter | Value     | Description |
|-----------|-----------|-------------|
| p2x_s     | 6.2831855 | 2π (radians per revolution) |
| mean      | 5         | Moving average filter length |
| pmin_s    | 0.0002    | Minimum pulse width (200μs) |
| toff_s    | 0.5       | Timeout in seconds |

This configuration enables RPM measurement from pulse inputs, with appropriate filtering and timeout handling for reliable speed sensing.

## 9. Stick Configuration (ver_spdif_stick.xml, ver_spdif_stickvar.xml, ver_spdif_stg_ua_stick.xml)

The stick configuration appears to be minimal:
- stick.xml contains an empty `<tunSource/>` element
- stickvar.xml has `<enabled>0</enabled>`, indicating the stick functionality is disabled
- stg_ua_stick.xml sets `<port>0</port>`, specifying port 0 for stick interface

## 10. Light Configuration (ver_spdif_stg_ua_lights.xml)

The light configuration contains a single parameter:
```xml
<var0>1200</var0>
```
This likely represents a timing or intensity parameter for the lighting system.

## 11. Port Configuration (ver_spdif_stg_ports_cfg.xml)

The port configuration contains 6 elements, all set to 0:
```xml
<str-tunarray-element>0</str-tunarray-element>
...
```
This indicates that all 6 ports are configured with default settings or disabled.

## Cross-Component Relationships

### Signal Flow Architecture

1. **Input Signal Processing Path**:
   - External signals → GPIO inputs → ECAP modules → Cross-processor routing (XPECAP)
   - PPM receivers decode RC control signals into channel values
   - RPM sensors measure rotation speeds from pulse inputs

2. **Output Signal Generation Path**:
   - Control logic → Cross-processor routing (XPCU8) → PWM modules → GPIO outputs
   - PWM signals drive servos, motors, and other actuators

3. **Cross-Processor Communication**:
   - XPECAP routes timing capture data between processors
   - XPCU8 routes 8-bit control data between processors
   - Bidirectional communication enables coordinated control

### Hardware Interface Integration

The configuration establishes a comprehensive hardware I/O system with:

1. **Input Processing**:
   - 4 PPM receivers for RC signal decoding (64 potential channels)
   - 6 ECAP modules for precise timing measurement
   - 6 RPM measurement channels for speed sensing

2. **Output Generation**:
   - 16 PWM GPIO pins configured as outputs
   - 8 PWM channels with dual outputs (A/B)
   - Standard servo control parameters (50Hz, 900-2100μs)

3. **Cross-System Coordination**:
   - Cross-processor routing enables distributed processing
   - Conditional routing based on system state variables

## Timing Parameters and Signal Characteristics

### PWM Output Signals
- **Frequency**: 50Hz (20ms period)
- **Pulse Width Range**: 900-2100μs
- **Signal Type**: Active high
- **Resolution**: Not explicitly specified, but implied to be high precision

### PPM Input Signals
- **Pulse Polarity**: Active low
- **Pulse Width**: 250-500μs
- **Valid Signal Range**: 800-2200μs
- **Position Value Range**: 900-2100μs
- **Guard Time**: 4ms
- **Channels**: 16 channels per receiver, 12 actively masked

### RPM Measurement
- **Minimum Pulse**: 200μs
- **Timeout**: 0.5s
- **Filter Length**: 5-sample moving average
- **Scaling**: 2π radians per revolution

## Conclusion

The recovery system's hardware I/O configuration establishes a comprehensive interface for sensor input processing and actuator control. The system uses standard RC control signal parameters (900-2100μs pulse widths at 50Hz) for compatibility with common servos and ESCs.

The cross-processor routing configuration enables distributed processing across multiple processors, with conditional routing based on system state. The enhanced capture modules provide precise timing measurement for input signals, while the PWM modules generate accurate control signals for motors and servos.

The PPM receivers are configured to decode standard RC receiver signals, with appropriate glitch filtering and timing parameters. The RPM measurement channels enable reliable speed sensing from pulse inputs, with appropriate filtering and timeout handling.

Overall, the hardware I/O configuration provides a robust foundation for the recovery system's interaction with physical peripherals, supporting motor control, sensor input processing, and cross-processor coordination.