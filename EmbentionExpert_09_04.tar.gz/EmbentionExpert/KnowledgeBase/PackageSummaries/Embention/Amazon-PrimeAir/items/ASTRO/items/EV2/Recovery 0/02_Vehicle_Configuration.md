# Generated from:

- items/pdi_Recovery0/setup/ver_spdif_vehicle_ident.xml (858 tokens)
- items/pdi_Recovery0/setup/ver_spdif_amz_site_config.xml (165 tokens)
- items/pdi_Recovery0/setup/ver_spdif_amz_activated_prescription_config.xml (95 tokens)
- items/pdi_Recovery0/setup/ver_spdif_stg_subsystem.xml (2237 tokens)
- items/pdi_Recovery0/setup/ver_spdif_stg_vom_cfg.xml (71 tokens)
- items/pdi_Recovery0/setup/ver_spdif_stg_mcfg.xml (53 tokens)
- items/pdi_Recovery0/setup/ver_spdif_stg_mset.xml (53 tokens)
- items/pdi_Recovery0/setup/ver_spdif_stg_msg_cfgs.xml (56 tokens)
- items/pdi_Recovery0/setup/ver_spdif_stg_inertial_sts.xml (67 tokens)
- items/pdi_Recovery0/setup/ver_spdif_status.xml (72 tokens)
- items/pdi_Recovery0/setup/ver_spdif_pdi_mode.xml (63 tokens)
- items/pdi_Recovery0/setup/ver_spdif_modes.xml (50 tokens)
- items/pdi_Recovery0/setup/ver_spdif_limits.xml (51 tokens)
- items/pdi_Recovery0/setup/ver_spdif_oprrng.xml (51 tokens)
- items/pdi_Recovery0/setup/ver_spdif_agname.xml (63 tokens)
- items/pdi_Recovery0/setup/ver_spdif_arcx.xml (49 tokens)
- items/pdi_Recovery0/setup/ver_spdif_chklist.xml (52 tokens)
- items/pdi_Recovery0/setup/ver_spdif_cbitcfg.xml (68 tokens)
- items/pdi_Recovery0/setup/ver_spdif_mbit.xml (1485 tokens)
- items/pdi_Recovery0/setup/ver_spdif_pfields.xml (52 tokens)
- items/pdi_Recovery0/setup/ver_spdif_sniffer.xml (52 tokens)
- items/pdi_Recovery0/setup/ver_spdif_varini.xml (384 tokens)
- items/pdi_Recovery0/setup/ver_spdif_overwrit.xml (92 tokens)
- items/pdi_Recovery0/production/ver_ppdif_arbaddr.xml (79 tokens)
- items/pdi_Recovery0/operation/ver_opdif_arctrim0.xml (367 tokens)
- items/pdi_Recovery0/operation/ver_opdif_arctrim1.xml (367 tokens)
- items/pdi_Recovery0/operation/ver_opdif_arctrim2.xml (367 tokens)
- items/pdi_Recovery0/operation/ver_opdif_arctrim3.xml (367 tokens)

---

# Vehicle Configuration Analysis for Recovery System

This document provides a comprehensive analysis of the vehicle configuration files for the recovery system, focusing on vehicle identification, site configuration, subsystem settings, status reporting, built-in test configurations, variable initialization, and ARC trim settings.

## 1. Vehicle Identification Configuration

### File: `items/pdi_Recovery0/setup/ver_spdif_vehicle_ident.xml`

This file defines the core identity parameters for the vehicle within the recovery system.

#### Key Components:
- **ID**: 380
- **Filename**: vehicle_ident.bin
- **Version**: 7.3.1

#### Vehicle Addressing:
- **UAV Address**: 4278190080 (0xFF000000 in hexadecimal)
  - This appears to be a network address used for communication with the vehicle

#### Vehicle Classification:
- **Vehicle Type**: 0
- **Vehicle Subtype**: 0
- **Payloads**: Single element array with value 0

#### Identification Strings:
- **Tail Number**: ASCII representation of "RP78190080" followed by spaces
  - Encoded as individual ASCII values: 52, 50, 55, 56, 49, 57, 48, 48, 56, 48, 32, 32, 32, 32, 32, 0
  - This is likely a unique identifier for the specific vehicle instance
- **ATC Call Sign**: Empty (filled with space characters - ASCII 32)
  - 32 space characters, suggesting this field is reserved but not used in this configuration

## 2. Site Configuration

### File: `items/pdi_Recovery0/setup/ver_spdif_amz_site_config.xml`

This file contains site-specific configuration parameters for the recovery system.

#### Key Components:
- **ID**: 495
- **Filename**: amz_site_config.bin
- **Version**: 7.3.1

#### Persistent Data Configuration:
- **is_persistent_pdi**: 1 (Enabled)
- **is_pdi_config_valid**: 1 (Valid)
  - These flags indicate that PDI (Presumably Program Data Interface) configuration should persist across system restarts

#### Site Identification:
- **site_config_guid**: "UNKNOWN"
- **operating_region**: "UNKNOWN"
- **operator_registration_number**: "UNKNOWN"
  - These placeholder values suggest the configuration is generic or not yet site-specific

#### Navigation Parameters:
- **nav_init_heading_degrees**: 0
  - Initial heading reference for navigation systems, set to 0 degrees

### File: `items/pdi_Recovery0/setup/ver_spdif_amz_activated_prescription_config.xml`

This file specifies the active prescription configuration for the system.

#### Key Components:
- **ID**: 494
- **Filename**: amz_activated_prescription_config.bin
- **Version**: 7.3.1

#### Prescription Configuration:
- **activated-prescription-filename**: "UNKNOWN"
  - Indicates no specific prescription file is currently activated

## 3. Subsystem Configuration

### File: `items/pdi_Recovery0/setup/ver_spdif_stg_subsystem.xml`

This file defines configuration parameters for up to 32 subsystems (subsys0 through subsys31).

#### Key Components:
- **ID**: 377
- **Filename**: stg_subsystem.bin
- **Version**: 7.3.1

#### Subsystem Structure:
- Each subsystem (subsys0-subsys31) contains:
  - **comp_n**: 0 (Component number)
  - **subcomp_n**: 0 (Subcomponent number)
  - **uvar**: 2000 (Likely a default value or timeout)

This uniform configuration across all 32 subsystems suggests either:
1. A template configuration awaiting customization
2. A system where all subsystems use identical parameters
3. A system where only specific subsystems are actually used, but all are defined for consistency

### File: `items/pdi_Recovery0/setup/ver_spdif_stg_vom_cfg.xml`

This file contains configuration for the VOM (Vehicle Operation Management) component.

#### Key Components:
- **ID**: 383
- **Filename**: stg_vom_cfg.bin
- **Version**: 7.3.1

#### VOM Configuration:
- **var0**: 1000
- **var1**: 3100
  - These appear to be system-specific parameters, possibly timeouts, thresholds, or mode identifiers

### File: `items/pdi_Recovery0/setup/ver_spdif_stg_mcfg.xml`

This file is a placeholder for mission configuration data.

#### Key Components:
- **ID**: 376
- **Filename**: stg_mcfg.bin
- **Version**: 7.3.1
- **Data**: Empty (no configuration defined)

### File: `items/pdi_Recovery0/setup/ver_spdif_stg_mset.xml`

This file is a placeholder for mission settings.

#### Key Components:
- **ID**: 375
- **Filename**: stg_mset.bin
- **Version**: 7.3.1
- **Data**: Empty (no settings defined)

### File: `items/pdi_Recovery0/setup/ver_spdif_stg_msg_cfgs.xml`

This file is a placeholder for message configurations.

#### Key Components:
- **ID**: 381
- **Filename**: stg_msg_cfgs.bin
- **Version**: 7.3.1
- **Data**: Empty (no message configurations defined)

### File: `items/pdi_Recovery0/setup/ver_spdif_stg_inertial_sts.xml`

This file configures the inertial status reporting system.

#### Key Components:
- **ID**: 384
- **Filename**: stg_inertial_sts.bin
- **Version**: 7.3.1

#### Inertial Status Configuration:
- **freq**: 0
  - Likely represents the frequency of inertial status updates, with 0 possibly indicating "disabled" or "use default"

## 4. Status Reporting Configuration

### File: `items/pdi_Recovery0/setup/ver_spdif_status.xml`

This file configures the status reporting behavior of the system.

#### Key Components:
- **ID**: 51
- **Filename**: status.bin
- **Version**: 7.3.1

#### Status Configuration:
- **vcp_tx_enabled**: 1 (Enabled)
  - Enables transmission of status data via VCP (Virtual COM Port)
- **period**: 1.0
  - Status reporting frequency of 1 Hz (once per second)

### File: `items/pdi_Recovery0/setup/ver_spdif_pdi_mode.xml`

This file configures the PDI (Program Data Interface) mode.

#### Key Components:
- **ID**: 354
- **Filename**: pdi_mode.bin
- **Version**: 7.3.1

#### PDI Mode Configuration:
- **pdi_mode**: 0
  - Likely represents the operational mode of the PDI system (0 may indicate "normal" or "default")

### File: `items/pdi_Recovery0/setup/ver_spdif_modes.xml`

This file is a placeholder for system modes configuration.

#### Key Components:
- **ID**: 27
- **Filename**: modes.bin
- **Version**: 7.3.1
- **Data**: Empty (no modes defined)

### File: `items/pdi_Recovery0/setup/ver_spdif_limits.xml`

This file is a placeholder for system limits configuration.

#### Key Components:
- **ID**: 88
- **Filename**: limits.bin
- **Version**: 7.3.1
- **Data**: Empty (no limits defined)

### File: `items/pdi_Recovery0/setup/ver_spdif_oprrng.xml`

This file is a placeholder for operational range configuration.

#### Key Components:
- **ID**: 4
- **Filename**: oprrng.bin
- **Version**: 7.3.1
- **Data**: Empty (no operational ranges defined)

### File: `items/pdi_Recovery0/setup/ver_spdif_agname.xml`

This file defines automation group names.

#### Key Components:
- **ID**: 150
- **Filename**: agname.bin
- **Version**: 7.3.1
- **Data**: Empty map (no automation groups defined)

### File: `items/pdi_Recovery0/setup/ver_spdif_arcx.xml`

This file is a placeholder for ARC (possibly Autonomous Recovery Control) configuration.

#### Key Components:
- **ID**: 23
- **Filename**: arcx.bin
- **Version**: 7.3.1
- **Data**: Empty (no ARC configuration defined)

## 5. Built-In Test Configuration

### File: `items/pdi_Recovery0/setup/ver_spdif_chklist.xml`

This file is a placeholder for system checklists.

#### Key Components:
- **ID**: 92
- **Filename**: chklist.bin
- **Version**: 7.3.1
- **Data**: Empty (no checklists defined)

### File: `items/pdi_Recovery0/setup/ver_spdif_cbitcfg.xml`

This file configures the Continuous Built-In Test (CBIT) system.

#### Key Components:
- **ID**: 270
- **Filename**: cbitcfg.bin
- **Version**: 7.3.1

#### CBIT Configuration:
- **bits_0**: Empty (no configuration)
- **bits_1**: Empty (no configuration)
- **bits_2**: Empty (no configuration)
  - These likely represent different categories or priorities of built-in tests

### File: `items/pdi_Recovery0/setup/ver_spdif_mbit.xml`

This file configures the Maintenance Built-In Test (MBIT) system.

#### Key Components:
- **ID**: 138
- **Filename**: mbit.bin
- **Version**: 7.3.1

#### MBIT Configuration:
The file defines a map of test IDs (1200-1220, 1225, 1318, 1320, 1301, 1304, 1110, 1306, 1340) with associated descriptions:

| ID   | Name                              |
|------|-----------------------------------|
| 1200-1220 | (No name provided)               |
| 1225 | Switchover                        |
| 1318 | GPS Outdoor                       |
| 1320 | Enable State Estimate             |
| 1301 | IMU self test failed              |
| 1304 | Full state estimate CAN           |
| 1110 | LIDAR Ok                          |
| 1306 | rec_in_control                    |
| 1340 | Send IMU measurements over Ethernet |

This configuration defines the available built-in tests and their human-readable names for maintenance purposes.

### File: `items/pdi_Recovery0/setup/ver_spdif_pfields.xml`

This file is a placeholder for parameter fields configuration.

#### Key Components:
- **ID**: 119
- **Filename**: pfields.bin
- **Version**: 7.3.1
- **Data**: Empty (no parameter fields defined)

### File: `items/pdi_Recovery0/setup/ver_spdif_sniffer.xml`

This file is a placeholder for network sniffer configuration.

#### Key Components:
- **ID**: 63
- **Filename**: sniffer.bin
- **Version**: 7.3.1
- **Data**: Empty (no sniffer configuration defined)

## 6. Variable Initialization

### File: `items/pdi_Recovery0/setup/ver_spdif_varini.xml`

This file defines the initial values for system variables.

#### Key Components:
- **ID**: 6
- **Filename**: varini.bin
- **Version**: 7.3.1

#### Variable Initialization:
The file contains initialization values for several system variables:

| ID   | Type | Value | Likely Purpose                      |
|------|------|-------|-------------------------------------|
| 1320 | 3    | 1.0   | Enable State Estimate (enabled)     |
| 1318 | 3    | 1.0   | GPS Outdoor (enabled)               |
| 1301 | 3    | 0.0   | IMU self test failed (not failed)   |
| 1304 | 3    | 0.0   | Full state estimate CAN (disabled)  |
| 1340 | 3    | 0.0   | Send IMU over Ethernet (disabled)   |
| 3244 | 0    | 1.0   | Unknown parameter (enabled)         |
| 3245 | 0    | 1.0   | Unknown parameter (enabled)         |
| 3246 | 0    | 1.0   | Unknown parameter (enabled)         |
| 3247 | 0    | 10.0  | Unknown parameter (value 10)        |

These variables control system behavior at startup, with several matching the MBIT test IDs defined earlier.

### File: `items/pdi_Recovery0/setup/ver_spdif_overwrit.xml`

This file configures the variable overwrite functionality.

#### Key Components:
- **ID**: 91
- **Filename**: overwrit.bin
- **Version**: 7.3.1

#### Overwrite Configuration:
- **enabled**: 0 (Disabled)
- **cfg**: Empty (no configuration)
- **period**: 0.0 (No periodic overwrite)
- **arb_addr.uav**: 4278190080 (0xFF000000 in hexadecimal)
  - This matches the UAV address from the vehicle identification file

## 7. Arbiter Address Configuration

### File: `items/pdi_Recovery0/production/ver_ppdif_arbaddr.xml`

This file configures the arbiter addressing scheme.

#### Key Components:
- **ID**: 80
- **Filename**: arbaddr.bin
- **Version**: 7.3.1

#### Arbiter Configuration:
- **arbaddr.uav**: 999
  - This is different from the UAV address in the vehicle identification file (4278190080)
- **apaddrs**: Empty (no access point addresses defined)

## 8. ARC Trim Settings

### Files:
- `items/pdi_Recovery0/operation/ver_opdif_arctrim0.xml`
- `items/pdi_Recovery0/operation/ver_opdif_arctrim1.xml`
- `items/pdi_Recovery0/operation/ver_opdif_arctrim2.xml`
- `items/pdi_Recovery0/operation/ver_opdif_arctrim3.xml`

These four files define trim settings for the ARC (Autonomous Recovery Control) system, with each file representing a different trim configuration set.

#### Key Components (common across all files):
- **IDs**: 350, 351, 352, 353 respectively
- **Filenames**: arctrim0.bin, arctrim1.bin, arctrim2.bin, arctrim3.bin
- **Version**: 7.3.1 (all files)

#### Trim Configuration:
Each file contains an array of 20 floating-point values, all initialized to 0.0. These likely represent trim offsets or calibration values for various control parameters in the recovery system.

The presence of four separate trim files suggests the system may support:
1. Multiple trim configurations for different operational modes
2. Backup/redundant trim sets
3. Trim configurations for different subsystems or control axes

## System Integration and Relationships

The configuration files collectively define a comprehensive setup for the recovery system:

1. **Identity and Addressing**:
   - The vehicle is identified by its tail number "RP78190080"
   - It uses UAV address 4278190080 (0xFF000000) for normal operation
   - The arbiter uses address 999, suggesting a separate control channel

2. **Operational Configuration**:
   - Status reporting is enabled at 1Hz via VCP
   - PDI mode is set to 0 (likely normal operation)
   - Site configuration is marked as valid and persistent
   - Navigation initialization heading is set to 0 degrees

3. **Subsystem Configuration**:
   - 32 subsystems are defined with identical default configurations
   - VOM configuration specifies parameters 1000 and 3100

4. **Testing and Monitoring**:
   - MBIT tests are defined for critical systems (GPS, IMU, LIDAR, state estimation)
   - CBIT configuration structure exists but is not populated

5. **Variable Initialization**:
   - Key system variables are initialized at startup:
     - State estimation is enabled
     - GPS outdoor mode is enabled
     - IMU self-test failure flag is cleared
     - CAN state estimation is disabled
     - Ethernet IMU transmission is disabled

6. **Control Parameters**:
   - Four sets of ARC trim parameters are defined (all zeroed)
   - Variable overwrite functionality is disabled

The system appears to be a template or baseline configuration for a recovery system, with many placeholder elements that would be customized for specific deployments. The configuration emphasizes status reporting, built-in testing, and variable initialization, suggesting a focus on system health monitoring and operational safety.