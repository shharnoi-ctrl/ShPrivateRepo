# Generated from:

- include/controllers/Recovery_controls_command_processor_test.h (296 tokens)
- include/controllers/Recovery_route_constructor_unit_test.h (309 tokens)
- include/controllers/Recovery_mission_data_processor_test.h (1249 tokens)
- include/controllers/Recovery_mission_phase_of_flight_test.h (250 tokens)
- include/RecoveryWrapperAlgorithms/Recovery_wrapper_controls_test.h (1390 tokens)
- source/controllers/Recovery_mission_data_processor_test.cpp (11821 tokens)
- source/controllers/Recovery_mission_phase_of_flight_test.cpp (27742 tokens)
- source/controllers/Recovery_controls_command_processor_test.cpp (31870 tokens)
- source/controllers/Recovery_route_constructor_unit_test.cpp (36358 tokens)
- source/RecoveryWrapperAlgorithms/Recovery_wrapper_controls_test.cpp (15869 tokens)

## With context from:

- Amazon-PrimeAir/items/ASTRO/items/sw/sw_pa_unit_testing_lib/03_Flight_Control_Core.md (3537 tokens)
- Amazon-PrimeAir/items/ASTRO/items/sw/sw_pa_unit_testing_lib/03_Trajectory_Planning.md (2908 tokens)

---

# Drone Recovery Systems: Comprehensive Summary

This document provides a detailed analysis of the drone recovery systems, focusing on how the Recovery Route Constructor (RRC) builds routes during contingency operations and how the Recovery Wrapper Controls component manages motor control during recovery scenarios.

## 1. Recovery System Architecture Overview

The recovery system is designed to provide a redundant control path that can take over when the primary flight control system fails. It consists of several key components:

### 1.1 Core Recovery Components

1. **Recovery Mission Data Processor (RMDP)** - Processes mission plan data for recovery operations
2. **Recovery Mission Phase of Flight (RMPF)** - Determines the current mission phase for recovery
3. **Recovery Route Constructor (RRC)** - Builds appropriate routes during contingency operations
4. **Recovery Controls Command Processor (RCCP)** - Processes commands for recovery controls
5. **Recovery Wrapper Controls (RWC)** - Manages motor control during recovery operations

### 1.2 System Modes and States

The recovery system operates in several modes:

- **Passive Mode** - Monitors primary system without taking control
- **Active Mode** - Takes control after switchover
  - **Active Above PADDC** - Special mode for recovery directly above the launch/landing area
  - **Active Backyard** - Mode for recovery in the "backyard" area near the launch/landing area
- **Done Mode** - Recovery operation completed

## 2. Recovery Mission Phase of Flight (RMPF)

The RMPF component determines the current mission phase, which affects route construction and control strategies.

### 2.1 Mission Phases

```
enum Mission_phase_of_flight {
    pre_takeoff,
    takeoff,
    flight,
    landing,
    post_landing
}
```

### 2.2 Phase Transition Logic

The RMPF implements a state machine that governs transitions between mission phases:

#### Pre-takeoff to Takeoff Transitions
- Triggered when the drone is no longer on ground
- Triggered by vertical velocity exceeding threshold
- Triggered by vertical acceleration exceeding threshold
- Requires preflight checks to be complete

#### Takeoff to Flight Transitions
- Triggered when primary system issues a route command
- Triggered when altitude exceeds takeoff target

#### Flight to Landing Transitions
- Triggered when tracking a landing route that completes
- Triggered when near the final landing point
- Triggered when recovery takes control (immediate landing)
- Triggered when primary system issues a land command

#### Landing to Post-landing Transitions
- Triggered when the drone is detected as on ground

### 2.3 Preflight Checks

The system performs several preflight checks:
- Verifies mission plan is successfully processed
- Validates route commands
- Checks that the drone is within the mission bounding box

## 3. Recovery Route Constructor (RRC)

The RRC is responsible for building appropriate routes during contingency operations.

### 3.1 RRC Mode State Machine

The RRC operates in several modes, with transitions governed by a state machine:

```
enum Mode {
    mode_passive,         // Monitoring primary system
    mode_active,          // Active control (non-VTOL)
    mode_active_backyard, // Active control in backyard area (VTOL)
    mode_active_above_paddc, // Active control above launch/landing area
    mode_done             // Recovery operation completed
}
```

#### Passive Mode Transitions
- Transitions to `mode_active` when recovery takes control and non-VTOL phase is detected
- Transitions to `mode_active_backyard` when recovery takes control and VTOL phase is detected
- Transitions to `mode_active_above_paddc` when recovery takes control and drone is above launch/landing area
- Transitions to `mode_done` when an RHCP (Return Home Contingency Plan) route is sent

#### Active Mode Transitions
- Transitions to `mode_active_backyard` when VTOL backyard route construction is requested
- Transitions to `mode_done` when RHCP route is sent

#### Active Backyard Mode Transitions
- Transitions to `mode_active` when VTOL switchover route is sent

#### Active Above PADDC Mode Transitions
- Transitions to `mode_done` when VTOL switchover route is sent

### 3.2 Route Construction Methods

The RRC implements several specialized route construction methods:

#### 3.2.1 Route Constructor for Active Above PADDC
```cpp
bool route_constructor_for_active_above_paddc(
    const Recovery_route_constructor::Input& input,
    Command_route_entry& command_route)
```

This method constructs a route that brings the drone to a stop directly above the launch/landing area:
- Creates a single maneuver (straight VTOL or hover)
- Calculates stopping trajectory based on current velocity
- Ensures zero final velocity

#### 3.2.2 Route Constructor for Active VTOL Backyard
```cpp
bool route_constructor_for_active_vtol_backyard(
    const Recovery_route_constructor::Input& input,
    const Maverick::Irvector3& p_target_ned_ned2pos_m,
    Command_route_entry& command_route)
```

This method constructs a route that navigates the drone to a specific target position in the backyard area:
- Creates up to two maneuvers (climb/descend and horizontal movement)
- Handles various initial velocity conditions
- Ensures smooth trajectory to target position

### 3.3 Route Selection Logic

The RRC implements logic to select appropriate routes based on the current situation:

#### 3.3.1 Get Route Command from Route ID
```cpp
bool get_route_command_from_route_id(
    const Uint32 route_id,
    Command_route_entry& command_route) const
```

Retrieves a route command with a specific ID from stored routes.

#### 3.3.2 Get Takeoff Route Command
```cpp
bool get_takeoff_route_command(
    Command_route_entry& command_route) const
```

Retrieves the takeoff route command from stored routes.

#### 3.3.3 Get Return Home Route Command from Maneuver ID
```cpp
bool get_return_home_route_command_from_maneuver_id(
    const Uint32 current_maneuver_id,
    const Uint32 current_route_id,
    Command_route_entry& command_route) const
```

Selects an appropriate return home route based on the current maneuver ID and route ID.

## 4. Recovery Controls Command Processor (RCCP)

The RCCP processes commands for recovery controls, determining what commands to issue based on the current mission phase and system state.

### 4.1 Command Generation Logic

The RCCP implements logic to generate appropriate controller commands:

#### 4.1.1 Generate Controller Command
```cpp
bool generate_controller_command(
    const Recovery_controls_command_processor::Input& input,
    const Mission_phase_of_flight::Type& mission_phase_of_flight,
    const Takeoff_command_params& mission_takeoff_parameters,
    const Tp_output& tp_output,
    Recovery_controls_command_processor::Output& output)
```

Generates controller commands based on the current mission phase:
- **Pre-takeoff**: No commands issued
- **Takeoff**: Issues takeoff command
- **Flight**: Issues route commands or land command if required
- **Landing**: Issues land command
- **Post-landing**: No commands issued

#### 4.1.2 Straight Land Required Logic
```cpp
bool is_straight_land_required(
    const Recovery_controls_command_processor::Input& input)
```

Determines if an immediate landing is required based on:
- State estimate status (degraded or invalid)
- Battery state of charge (below threshold)
- Land contingency received from operator
- Primary system in urgent land mode

### 4.2 Bounding Box Protection

The RCCP implements bounding box protection to ensure the drone stays within a safe area:

```cpp
bool check_bounding_box(
    const Real64 current_time_s,
    const Controllers_state_estimate& state_estimate,
    const Mission_phase_of_flight::Type& mission_phase_of_flight,
    const Mission_bounding_box_data& mission_bounding_box,
    Recovery_controls_command_processor::Pre_flight_check_telemetry& preflight_check_telemetry)
```

This function:
- Checks if the drone is within the mission bounding box
- Logs violations for telemetry
- Can be configured to use mission-specific or parameter-defined dimensions

## 5. Recovery Wrapper Controls (RWC)

The RWC component manages motor control during recovery operations, implementing a state machine for motor control.

### 5.1 Motor Control State Machine

The RWC implements a state machine for motor control with the following states:

```
enum Motor_state {
    DISABLED,
    ENABLED,
    ARMED,
    RUNNING
}
```

### 5.2 Preflight Motor Checks

The RWC performs several preflight motor checks:

#### 5.2.1 Switchover Test
```cpp
bool perform_switchover_test()
```

Tests the switchover mechanism between primary and recovery systems:
- Signals switchover to primary system
- Verifies that recovery system receives switchover signal
- Ensures switchover mechanism is functioning correctly

#### 5.2.2 Health Check
```cpp
bool perform_health_check()
```

Performs health checks on the recovery system:
- Verifies state estimate is healthy
- Confirms vehicle is on ground
- Checks other system health indicators

### 5.3 Motor State Request Logic

```cpp
void set_motor_state_request(
    const Recovery_controls_command_processor::Output& rccp_output,
    const Real64 current_time_s,
    Motor_rpm_cmd::Motor_state_request& motor_state_request)
```

This function determines the appropriate motor state request based on:
- Current time
- RCCP output
- Switchover status
- Preflight check status

### 5.4 Motor Command Output

```cpp
void output_motor_commands(
    const Real current_time_s,
    const Actuator_setpoints& actuator_setpoints,
    const Recovery_controls_command_processor::Output& rccp_output,
    Recovery_wrapper_control_system_object::Output& output)
```

This function:
- Processes actuator setpoints
- Applies appropriate motor commands
- Handles motor state transitions
- Ensures smooth motor control during recovery operations

## 6. Recovery Mission Data Processor (RMDP)

The RMDP processes mission plan data for recovery operations, extracting relevant information for route construction.

### 6.1 Mission Plan Processing

```cpp
bool process_mission_plan(
    const Mission_plan_data& mission_plan_data,
    const Upload_mission_plan_wrapper& mission_plan_upload_metadata,
    Mission_plan& mission_plan)
```

This function:
- Deserializes the mission plan
- Validates mission plan data
- Extracts mission parameters

### 6.2 Route Command Packaging

```cpp
bool package_command_route_entry(
    const Mission_plan& mission_plan,
    const Mission_utilities::Route_type route_type,
    const Uint32 return_home_route_idx,
    Command_route_entries& command_route_entries) const
```

This function:
- Packages route commands based on mission plan
- Handles different route types (takeoff to delivery, delivery to landing, etc.)
- Sets appropriate initial conditions

### 6.3 RHCP Maneuver Range Data Population

```cpp
void populate_rhcp_maneuver_range_data(
    const Mission_plan& mission_plan,
    Rhcp_maneuver_range_data_array& rhcp_maneuver_range_data)
```

This function:
- Populates data about Return Home Contingency Plan (RHCP) routes
- Maps nominal maneuver IDs to RHCP route IDs
- Defines maneuver ID ranges for each RHCP

## 7. State Machines and Transitions

### 7.1 Recovery System State Machine

The overall recovery system implements a state machine with the following states:

1. **Monitoring** - Recovery system is passive, monitoring primary system
2. **Switchover** - Recovery system is taking control from primary system
3. **Active Control** - Recovery system is actively controlling the drone
4. **Landing** - Recovery system is executing landing procedure
5. **Completed** - Recovery operation is complete

### 7.2 Preflight Checks State Machine

The preflight checks implement a state machine with the following states:

1. **Not Started** - Preflight checks have not begun
2. **In Progress** - Preflight checks are being performed
3. **Failed** - Preflight checks have failed
4. **Completed** - Preflight checks have completed successfully

### 7.3 Motor Control State Machine

The motor control implements a state machine with the following states:

1. **Disabled** - Motors are disabled
2. **Enabled** - Motors are enabled but not armed
3. **Armed** - Motors are armed but not running
4. **Running** - Motors are running

## 8. Switchover Handling

The recovery system implements detailed logic for handling switchover from primary to recovery control:

### 8.1 Switchover During Pre-takeoff

When switchover occurs during pre-takeoff:
- System transitions to post-landing phase
- No motor commands are issued
- System waits for operator intervention

### 8.2 Switchover During Takeoff

When switchover occurs during takeoff:
- System transitions to landing phase
- Land command is issued immediately
- Motors are controlled to execute landing

### 8.3 Switchover During Flight

When switchover occurs during flight:
- System evaluates current position and velocity
- Constructs appropriate recovery route
- Issues commands to execute recovery route

### 8.4 Switchover During Landing

When switchover occurs during landing:
- System continues landing procedure
- Land command is maintained
- Motors are controlled to complete landing

## 9. Error Handling and Contingencies

The recovery system implements several error handling mechanisms:

### 9.1 RMPF Failure Land Command

If the RMPF component fails:
- System issues immediate land command
- Transitions to landing phase
- Logs failure for telemetry

### 9.2 RRC Failure Land Command

If the RRC component fails:
- System issues immediate land command
- Transitions to landing phase
- Logs failure for telemetry

### 9.3 TP Failure Land Command

If the Trajectory Planner component fails:
- System issues immediate land command
- Transitions to landing phase
- Logs failure for telemetry

### 9.4 Straight Land from Operator Command

If the operator issues a land contingency command:
- System issues immediate land command
- Transitions to landing phase
- Logs operator command for telemetry

## 10. Performance-Critical Components

The recovery system includes several performance-critical components:

1. **Route Construction** - Must quickly generate valid routes during contingency
2. **Motor Control** - Must maintain stable control during switchover
3. **State Machine Transitions** - Must correctly handle mode transitions
4. **Bounding Box Checks** - Must efficiently verify drone position

## 11. Recovery Wrapper Controls Test Implementation

The `Recovery_wrapper_controls_test.cpp` file implements comprehensive tests for the Recovery Wrapper Controls component, focusing on:

### 11.1 Test Structure

The test suite is organized into multiple test blocks:
- Block 0: Basic functionality tests
- Block 1: Preflight check tests
- Block 2: Motor state request tests

### 11.2 Preflight Switchover Tests

The tests verify that the switchover mechanism works correctly:

- `Test01_PretakeoffSwitchoverDisabled`: Verifies behavior when switchover testing is disabled
- `Test02_PretakeoffSwitchoverEnabled`: Verifies the complete switchover test sequence:
  1. Signal switchover to primary
  2. Verify recovery receives switchover signal
  3. Complete switchover test
  4. Verify state transitions

### 11.3 Preflight Health Check Tests

The tests verify that health checks function correctly:

- `Test03_PretakeoffHealthCheckDisabled`: Verifies behavior when health checks are disabled
- `Test04_PretakeoffHealthCheckEnabled`: Verifies health check logic:
  1. Checks navigation initialization
  2. Verifies on-ground status
  3. Validates position/velocity status
  4. Confirms AGL (Above Ground Level) status

### 11.4 Motor State Request Tests

The tests verify motor state request logic:

- `Test07_SetMotorStateRequest_SwitchoverDisabled`: Tests motor state when switchover is disabled
- `Test08_SetMotorStateRequest_SwitchoverEnabled_EnableIntent`: Tests motor enable logic
- `Test09_SetMotorStateRequest_SwitchoverEnabled_ArmIntent`: Tests motor arm logic
- `Test10_SetMotorStateRequest_TimeToMotorChecks`: Tests motor check timing

### 11.5 Motor Command Output Tests

The `Test11_OutputMotorCommands` test verifies that motor commands are correctly output:
- Verifies motor state requests are properly set
- Confirms RPM commands are correctly passed
- Validates motor state transitions

### 11.6 Test Helper Functions

The test implementation includes several helper functions:

- `emplace_state_estimate_data`: Sets up state estimate data for testing
- `set_valid_recovery_parameters`: Configures valid recovery parameters
- `do_switchover`: Simulates switchover between primary and recovery systems

## 12. Conclusion

The drone recovery systems provide a comprehensive framework for handling contingency operations when the primary flight control system fails. The hierarchical structure, from mission data processing to motor control, enables robust recovery operations while maintaining safety constraints.

The state machine-based approach, coupled with specialized route construction methods for different scenarios, allows for precise control of the drone during recovery operations, ensuring safe handling of various failure modes and contingency situations.

The Recovery Wrapper Controls component plays a critical role in managing motor control during recovery operations, implementing a sophisticated state machine that handles preflight checks, switchover testing, and motor state transitions to ensure safe and reliable recovery operations.

## Referenced Context Files

The following context files were particularly helpful in understanding the system:
- `Recovery_controls_command_processor_test.h/cpp`: Command processing logic
- `Recovery_route_constructor_unit_test.h/cpp`: Route construction methods
- `Recovery_mission_data_processor_test.h/cpp`: Mission data processing
- `Recovery_mission_phase_of_flight_test.h/cpp`: Mission phase transitions
- `Recovery_wrapper_controls_test.h`: Motor control during recovery
- Flight Control Core documentation: Provided context on the primary flight control system
- Trajectory Planning documentation: Provided context on route construction methods