# Generated from:

- _sw_Veronte/code/vblocks/code/include/Blk_stick.h (805 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_stick.cpp (1939 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_manual.h (534 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_manual.cpp (707 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_driver.h (666 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_driver.cpp (931 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_pwm.h (389 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_pwm.cpp (712 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_ecu.h (1846 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_ecu.cpp (3448 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_mix.h (547 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_mix.cpp (517 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_apsel.h (677 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_apsel.cpp (671 tokens)
- _sw_Veronte/code/vblocks/code/include/Apsel.h (335 tokens)
- _sw_Veronte/code/vblocks/code/source/Apsel.cpp (357 tokens)
- _sw_Veronte/code/vblocks/code/include/Apsel_fw.h (50 tokens)

## With context from:

- PackageSummaries/Embention/Amazon-PrimeAir/items/ASTRO/items/sw/sw_Astro/items/04_VBlocks_Core.md (5729 tokens)

---

# Input/Output and Actuator Interface Blocks in VBlocks Library

This document provides a comprehensive analysis of the input/output and actuator interface blocks in the VBlocks library, focusing on how they interface with hardware components and user inputs.

## 1. Blk_stick: Stick Input Processing Block

The `Blk_stick` class processes stick inputs from various sources according to configured priorities and transformations.

### 1.1 Purpose and Functionality

`Blk_stick` receives channel values from stick sources (like remote controls), processes them according to a configured priority and channel selection, and applies linear transformations to the values.

### 1.2 Class Structure and Components

```cpp
class Blk_stick : public Blocks::Iblock {
public:
    Blk_stick(const Vblocks::Stickrd& stickrd0, const volatile Base::Stickarray& stickarray0);
    virtual void step();
    virtual const Blocks::Ipin* get_out(Uint16 i) const;
    virtual void cset(Base::Lossy_error& str, Blocks::Iblock::Csetpm& params);

private:
    typedef Base::Dynarray<Uint16> Tsticksrcdyn;
    typedef Base::Tnarray<Tsticksrcdyn,Base::Stickcfg::n_priority_lists> Tsticktable;

    const Vblocks::Stickrd& stickrd;    // Stick data reader
    Blocks::Pin<Blocks::Dynrvector> r;  // Output signal for control vector
    Blocks::Pin<Blocks::Dynrvector> y;  // Output signal for servo vector
    Blocks::Pin<bool> out_ok;           // Output stick status
    Blocks::Pin<Real> out_rx;           // Output RX rate for this block

    Blocks::Dynrmatrix yr;              // YR matrix
    Blocks::Dynrvector y0;              // Y offset
    Base::Dynarray<Uint16> ch_ids;      // Ids of channels to output
    Base::Freqmetric rxrate;            // Counter of sources RX rate

    Tsticktable srcdata;                // Source read data
    Base::Sticksync::Rdsafe hreader0;   // Reader for source 1
    Base::Sticksync::Rdsafe hreader1;   // Reader for source 2
    Base::Sticksync::Rdsafe hreader2;   // Reader for source 3
    Base::Sticksync::Rdsafe hreader3;   // Reader for source 4

    Base::Suiteref<Base::Sticksync::Rdsafe,
                   Base::Stickcfg::n_source_max> hreader;  // Reference of readers for each source

    bool refresh(const Uint16 id);  // Check if new data is available for given source and update raw data if true
};
```

### 1.3 Configuration Parameters

The `Blk_stick` block is configured through its PDI (Parameter Definition Interface) with the following parameters:

| Type | Name | Content | Range |
|------|------|---------|-------|
| Array\<Uint16\> | ch_ids | Selected channel IDs | - |
| Rmatrix | M | Transformation matrix | - |
| Array\<Real\> | y0 | Bias | - |
| Sarray\<Sticktable,2\> | ptables | Priority tables | - |
| Bool16 | msources | Bit to allow multiple source reception | - |

The `Sticktable` structure contains:
- `srcdata`: Array of stick source indices (up to 2 elements)

The `Sticksource` structure contains:
- `idx`: Array of source indices (up to 4 elements with range [0,3])

### 1.4 Initialization and Setup

During initialization, the `Blk_stick` constructor sets up:
1. References to the stick data reader and stick array
2. Frequency metric parameters for RX rate calculation
3. Safe readers for each stick source

```cpp
Blk_stick::Blk_stick(const Vblocks::Stickrd& stickrd0, const volatile Base::Stickarray& stickarray0):
    stickrd(stickrd0),             
    rxrate(rxrate_afilter, rxrate_time_max, rxrate_minfreq),
    hreader0(stickarray0[Ku16::u0]),
    hreader1(stickarray0[Ku16::u1]),
    hreader2(stickarray0[Ku16::u2]),
    hreader3(stickarray0[Ku16::u3]),
    hreader(hreader0,hreader1,hreader2,hreader3)
{
}
```

### 1.5 Processing Logic

The `step()` method implements the core processing logic:

1. Selects the stick priority table based on the system configuration
2. Loops through sources in priority order
3. If a valid source is found, refreshes data from that source
4. Updates RX rate metrics
5. Applies linear transformation to convert raw values to output values

```cpp
void Blk_stick::step() {
    // Stick priority table selection
    static const Bsp::Huvar stkprtsel(Base::vu_stkprt_sel);
    const Tsticksrcdyn& srcs = srcdata[stkprtsel.get()];

    // Loop sources by priority order. If new data is received from that source, data is refreshed
    out_ok.val = false;

    for (Uint32 i = 0; (i < srcs.size()) && (!out_ok.val); ++i) {
        const Uint16 id = srcs[i];
        if (stickrd.source_ok(id)) {
            out_ok.val = true;
            if (refresh(id)) {
                // Update RX rate
                rxrate.count();

                // Conversion from raw to y
                y.val.matvec(yr,r.val);
                y.val.add(y0);
            }
        }
    }

    out_rx.val = rxrate.step();
}
```

The `refresh()` method checks if new data is available from a given source and updates the raw values:

```cpp
bool Blk_stick::refresh(const Uint16 id) {
    Base::Sticksync::Rdsafe& stk = hreader.get(id);
    const bool is_refreshed = stk.refresh();
    if (is_refreshed) {
        for (Uint32 i = 0; i < r.val.size_max(); ++i) {
            r.val[i] = Base::Stick_consts::stk_normalize(stk.get_last_value().r[ch_ids[i]]);
        }
    }
    return is_refreshed;
}
```

### 1.6 Outputs

The block provides four outputs:

| Index | Type | Description |
|-------|------|-------------|
| 0 | Dynrvector | Raw channel values (r) |
| 1 | Dynrvector | Transformed channel values (y = M*r + y0) |
| 2 | bool | Stick status (true if valid) |
| 3 | Real | Reception frequency |

```cpp
const Blocks::Ipin* Blk_stick::get_out(Uint16 i) const {
    enum Outtypes {
        case_r   = 0,   // Output raw data
        case_y   = 1,   // Output y converted data
        case_ok  = 2,   // Output stick status
        case_rx  = 3    // Output sources RX rate
    };
    const Blocks::Ipin* ret = 0;
    switch (static_cast<Outtypes>(i)) {
        case case_r:   ret = &r; break;
        case case_y:   ret = &y; break;
        case case_ok:  ret = &out_ok; break;
        case case_rx:  ret = &out_rx; break;
        default:       Bsp::warning(); break;
    }
    return ret;
}
```

## 2. Blk_manual: Manual Control Mode Block

The `Blk_manual` class handles manual control mode for specific channels.

### 2.1 Purpose and Functionality

`Blk_manual` checks if a specific channel is in manual mode and returns the value of the stick for that channel when it is.

### 2.2 Class Structure and Components

```cpp
class Blk_manual : public Blocks::Iblock {
public:
    Blk_manual(const Modetable& vmodetable0);
    virtual void step();
    virtual const Blocks::Ipin* get_out(Uint16 i) const;
    virtual void cset(Base::Lossy_error& str, Csetpm& params);

private:
    const Modetable& vmodetable;       // Table of modes
    Uint16 channel;                    // Stick control channel
    Blocks::Pin_ptr<Real> in_stick;    // Stick control variable input
    Blocks::Pin_ptr_opt<Real> in_auto; // Auto variable input
    Blocks::Pin<bool> out_enabled;     // Output indicating if manual is enabled
    Blocks::Pin<Real> out;             // Output with manual value
};
```

### 2.3 Configuration Parameters

The `Blk_manual` block is configured with:

| Type | Name | Content | Range |
|------|------|---------|-------|
| Pin_address | stick | Stick value to be used | - |
| Pin_address_optional | auto | Value to be used when not in manual mode | - |
| Uint16 | channel | Channel id | [0,19] |

### 2.4 Processing Logic

The `step()` method checks if the specified channel is in manual mode:

```cpp
void Blk_manual::step() {
    out_enabled.val = (vmodetable.get_current_mode(channel) == Mode::rc);
    out.val = out_enabled.val ? in_stick.read() : in_auto.read(0.0F);
}
```

If the channel is in manual mode (`Mode::rc`), the output is set to the stick value. Otherwise, it's set to the auto value (or 0.0 if no auto value is provided).

### 2.5 Outputs

The block provides two outputs:

| Index | Type | Description |
|-------|------|-------------|
| 0 | bool | Manual mode enabled flag |
| 1 | Real | Output value (stick or auto) |

```cpp
const Blocks::Ipin* Blk_manual::get_out(Uint16 i) const {
    enum Out {
        enabled_flag = 0,  // Output number of arcade enabled flag
        manual_val   = 1   // Output number of arcade value
    };
    const Blocks::Ipin* ret = 0;
    switch (static_cast<Out>(i)) {
        case enabled_flag: ret = &out_enabled; break;
        case manual_val:   ret = &out; break;
        default:           Bsp::warning(); break;
    }
    return ret;
}
```

## 3. Blk_mix: Mixed Control Mode Block

The `Blk_mix` class handles mixed control mode for specific channels.

### 3.1 Purpose and Functionality

`Blk_mix` detects when a specific channel is in mix mode and adds the stick value to its input, giving the result as output.

### 3.2 Class Structure and Components

```cpp
class Blk_mix : public Blocks::Iblock {
public:
    Blk_mix(const Modetable& vmodetable0);
    virtual void step();
    virtual const Blocks::Ipin* get_out(Uint16 i) const;
    virtual void cset(Base::Lossy_error& str, Csetpm& params);

private:
    const Modetable& vmodetable;    // Table of modes
    Blocks::Pin_ptr<Real> in_stick; // Stick control variable input
    Blocks::Pin_ptr<Real> in_auto;  // Control variable input
    Uint16 channel;                 // Control channel
    Real gain;                      // Mix gain
    Blocks::Pin<Real> out;          // Output signal
};
```

### 3.3 Configuration Parameters

The `Blk_mix` block is configured with:

| Type | Name | Content | Range |
|------|------|---------|-------|
| Pin_address | stick | Stick value used for mix/assist mode | - |
| Pin_address | auto | Input address of the value to assist | - |
| Uint16 | channel | Channel id | [0,19] |
| Real | gain | Gain for stick | - |

### 3.4 Processing Logic

The `step()` method checks if the specified channel is in mix mode:

```cpp
void Blk_mix::step() {
    out.val = in_auto.read();
    if (vmodetable.get_current_mode(channel) == Mode::mix) {
        out.val += (gain*in_stick.read());
    }
}
```

If the channel is in mix mode (`Mode::mix`), the output is the auto value plus the stick value multiplied by the gain. Otherwise, it's just the auto value.

### 3.5 Outputs

The block provides one output:

| Index | Type | Description |
|-------|------|-------------|
| 0 | Real | Output value (auto or auto+stick*gain) |

```cpp
inline const Blocks::Ipin* Blk_mix::get_out(Uint16 i) const {
    return Base::Paramsel::select<Blocks::Ipin>(i,out);
}
```

## 4. Blk_pwm: PWM Output Control Block

The `Blk_pwm` class controls PWM outputs for actuators.

### 4.1 Purpose and Functionality

`Blk_pwm` receives a signals vector and sends it to a particular set of PWM ports, allowing the user to enable or disable PWMs.

### 4.2 Class Structure and Components

```cpp
class Blk_pwm : public Blocks::Iblock {
public:
    Blk_pwm(Ver::Pwm_suite& pwms0);
    virtual void step();
    virtual void cset(Base::Lossy_error& str, Csetpm& params);

private:
    Ver::Pwm_suite& pwms;       // PWM suite
    Blocks::Pin_ptr<Real>  in;  // Input array
    Base::Dynarray<Uint16> ids; // Array of pwm IDs
};
```

### 4.3 Configuration Parameters

The `Blk_pwm` block is configured with:

| Type | Name | Content | Range |
|------|------|---------|-------|
| Pin_address | input | Address of input | - |
| Pwm information | pwm-info | List of PWM IDs and enable flags | - |

Each PWM entry contains:
- `id`: ID of PWM [0,15]
- `enable`: State (enable/disable) of PWM

### 4.4 Processing Logic

The `step()` method sends the input values to the corresponding PWM ports:

```cpp
void Blk_pwm::step() {
    const Base::Mblock<const Real> in_mblock = in.get_mblock();
    for (Uint16 i = 0; i < ids.size(); i++) {
        pwms.set_value(ids[i], in_mblock[i]);
    }
}
```

### 4.5 Initialization

During initialization, the block:
1. Connects to the input pin
2. Allocates memory for the PWM IDs
3. Configures each PWM port (ID and enable state)

```cpp
void Blk_pwm::cset(Base::Lossy_error& str, Csetpm& params) {
    bool ret = in.cset(str, params.accpins, Ku16::u1, Ku16::u32);
    Uint16 npwms = 0U;
    str.get_uint16(npwms);
    ret &= (in.get_num_elements() == npwms);
    if (ret) {
        ret &= ids.allocate_new(params.alloc, npwms);
        bool enabled = false;
        for (Uint16 i = 0; ret && (i < ids.size()); i++) {
            str.get_uint16(ids[i]);
            const Dsp28335_ent::Pwmdev::PWMid idx = static_cast<Dsp28335_ent::Pwmdev::PWMid>(ids[i]);
            ret &= ((ids[i] < Ver::num_pwms_ver) && (!pwms.get_enabled(idx)));
            if (ret) {
                str.get_bool16(enabled);
                pwms.enable(idx, enabled);
            }
        }
    }
    str.assrt(ret, Base::err_vblk_pwm);
}
```

## 5. Blk_driver: Trajectory Projection Block

The `Blk_driver` class calculates projected desired trajectory vectors for model predictive control.

### 5.1 Purpose and Functionality

`Blk_driver` calculates the projected desired trajectory vector, which serves as an input for model predictive control. It receives the set point and current system output, along with parameters like prediction interval, damping ratio, and natural frequency.

### 5.2 Class Structure and Components

```cpp
class Blk_driver: public Blocks::Iblock {
public:
    Blk_driver();
    virtual void on_focus();
    virtual void step();
    virtual const Blocks::Ipin* get_out(Uint16 i) const;
    virtual void cset(Base::Lossy_error& str, Csetpm& params);

private:
    Blocks::Pin_ptr<Real> yc;   // Set Point
    Blocks::Pin_ptr<Real> y;    // Value that acts as filtered output

    Real out;                         // output at time t-dt
    Base::Tnarray<Real,Ku16::u2> a;   // output coefficients
    Real b;                           // input coefficients
    Real chi;                         // Damping ratio
    Real w0;                          // Natural frequency

    Base::Chrono clk;           // Chronometer
    Blocks::Pin<Blocks::Dynrvector> yr;   // Output PDT
};
```

### 5.3 Configuration Parameters

The `Blk_driver` block is configured with:

| Type | Name | Content | Range |
|------|------|---------|-------|
| Pin_address | yc | Desired system output (Set Point) | - |
| Pin_address | y | Measured system output | - |
| Uint16 | lambda | Prediction interval | 1-8 |
| Ap-driver | drv | Driver Filter | - |

The `Ap-driver` structure contains:
- `chi`: Damping ratio (>0)
- `w0`: Natural frequency (>0)

### 5.4 Processing Logic

The `step()` method implements a second-order filter to compute the projected desired trajectory:

```cpp
void Blk_driver::step() {
    const Real y0 = y.read();
    if (clk.ongoing()) {
        // Update filter coefficients
        const Real om0 = w0*clk.step();
        const Real b0 = 1.0F / (1.0F + ((Const::TWO*chi*om0) + (om0*om0)));
        a[0] = Const::TWO*(1.0F + (chi*om0))*b0;
        a[1] = -b0;
        b = (1.0F - a[0] - a[1]);

        // Compute output
        const Real byc0 = b*yc.read();
        const Uint16 lambda = static_cast<Uint16>(yr.val.size());

        yr.val[0] = (a[0]*y0) + (a[1]*out) + byc0;
        if (lambda > 1) {
            yr.val[1] = (a[0]*yr.val[0]) + (a[1]*y0) + byc0;
            static const Uint16 min_n = 2U;
            if (lambda > min_n) {
                for (Uint16 i = min_n; i < lambda; ++i) {
                    yr.val[i] = (a[0]*yr.val[i-1]) + (a[1]*yr.val[i-Ku16::u2]) + byc0;
                }
            }
        }
    }
    else {
        clk.tic();
        yr.val.set_all(y0);
    }
    out = y0;
}
```

The filter is based on the equation:
H(s) = w²/(s² + 2wψs + w²)

### 5.5 Outputs

The block provides one output:

| Index | Type | Description |
|-------|------|-------------|
| 0 | Dynrvector | Projected desired trajectory |

```cpp
inline const Blocks::Ipin* Blk_driver::get_out(Uint16 i) const {
    return Base::Paramsel::select<Blocks::Ipin>(i,yr);
}
```

## 6. Blk_ecu: Engine Control Unit Block

The `Blk_ecu` class controls the shaft speed of microjets with PID control and automatic start sequence.

### 6.1 Purpose and Functionality

`Blk_ecu` implements a comprehensive engine control unit for microjets, including:
- PID control for shaft speed
- Automatic start sequence with multiple stages
- Temperature protection
- Voltage monitoring
- Fuel pump control

### 6.2 Class Structure and Components

```cpp
class Blk_ecu : public Blocks::Iblock {
public:
    Blk_ecu(const Dynamics::Rigidbody& uav0);
    virtual void on_focus();
    virtual void step();
    virtual const Blocks::Ipin* get_out(Uint16 i) const;
    virtual void cset(Base::Lossy_error& str, Csetpm& params);

private:
    enum Mode {
        off = 0,        // Engine off
        checking = 1,   // Starter engine check
        running = 2,    // Starting and running sequence
    };

    enum Stage_checking {
        stage_c0,       // Check if voltage is min
        stage_c1,       // Wait until speed is min
        stage_c2        // Starter is ok
    };

    enum Stage_running {
        stage_r0,       // Check if voltage is min
        stage_r1,       // Wait until preheat time
        stage_r2,       // Wait until ignition is done
        stage_r3,       // Wait until speed is min1
        stage_r4,       // Wait until speed is min2
        stage_r5,       // Wait until calibration is done
        stage_r6        // Wait until starter is stopped and normal operation
    };

    // Work variables
    Gnc::Pid pid;                                       // Base PID controller
    Gnc::Tsched tsched;                                 // Base PID tscheduler controller
    Base::Chrono clk;                                   // Chronometer to compute period
    Base::Chrono timer1;                                // Timer for stages
    Real n_ltd;                                         // Limited speed
    bool do_respect;                                    // Boolean to do PID respect
    const Dynamics::Rigidbody& uav;                     // Navigation data
    Stage_checking stg_c;                               // Checking states
    Stage_running stg_r;                                // Running states
    Mode pr_mode;                                       // Previous mode

    // Block inputs
    Blocks::Pin_ptr<Real> n_msd;                        // Measured engine speed (RPM)
    Blocks::Pin_ptr<Real> egt_msd;                      // Measured Exit Gas Temperature (K)
    Blocks::Pin_ptr<Real> pla;                          // Commanded Power Level Angle (%)
    Blocks::Pin_ptr<Real> fpv_resp;                     // Fuel Pump Voltage to respect (V)
    Blocks::Pin_ptr<Uint16> mode;                       // Selection mode
    Blocks::Pin_ptr<Real> v;                            // Voltage supply to engine

    // Block configuration
    static const Uint16 kplan_max_points = 10U;         // Max points for interpolation
    Maverick::Rtablen<1,kplan_max_points> kplan_table;  // kplan interpolation table
    Real n_max;                                         // Maximum engine speed (RPM)
    Real ndot_max;                                      // Maximum increment rate (RPM/s)
    Real ndot_min;                                      // Maximum decrement rate (RPM/s)
    Real egt_max;                                       // Maximum Exit Gas Temperature (K)
    Maverick::Rtablen<1,kplan_max_points> ff_table;     // Interpolation table for pid feedforward
    Real vmax_valves;                                   // Maximum voltage to valves
    Real vmax_ign;                                      // Maximum voltage to igniter
    Real vmax_starter;                                  // Maximum voltage to starter engine
    Real min_v1;                                        // Minimum voltage to checking sequence
    Real min_v2;                                        // Minimum voltage to runnning
    Real fpv_start;                                     // Voltage to fuel pump to start sequence
    Real egt_ignition;                                  // Temperature for ignition
    Real vmin_starter;                                  // Initial voltage to starter
    Real rpm_off_ign;                                   // Igniter stops at this speed
    Real rpm_off_starter;                               // Starter stops at this speed
    Real rpm_min_ok;                                    // Minimum speed to test starter
    Real preheat_t;                                     // Igniter pre heat time
    Real rampup_t;                                      // Time to reach 100% of starter unit
    Real cal_t;                                         // Calibration time

    // Block outputs
    Blocks::Pin<Real> fpv;                              // Fuel Pump Voltage (V)
    Blocks::Pin<bool> tmp_prot;                         // Temperature protection
    Blocks::Pin<Real> prop;                             // Proportional term
    Blocks::Pin<Real> itg;                              // Integral term
    Blocks::Pin<Real> der;                              // Derivative term
    Blocks::Pin<Real> main_v;                           // Voltage to main valve for PWM
    Blocks::Pin<Real> ign_v;                            // Voltage to igniter valve for PWM
    Blocks::Pin<Real> ign;                              // Voltage to igniter for PWM
    Blocks::Pin<Real> starter;                          // Voltage to electric starter engine for PWM

    void reset_output();  // Set outputs to zero
};
```

### 6.3 Processing Logic

The `step()` method implements a complex state machine for engine control:

1. First, it checks if the engine temperature is below the maximum allowed value
2. Then, it processes the current mode (off, checking, or running)
3. For each mode, it handles the appropriate stage of operation
4. In running mode with normal operation (stage_r6), it implements PID control for the engine speed

```cpp
void Blk_ecu::step() {
    if ((egt_msd.read() < egt_max) && tmp_prot.val) {
        const Mode m = static_cast<Mode>(mode.read());   // Actual commanded mode
        if (m != pr_mode) {
            on_focus();
        }
        switch (m) {
            default:    // If mode is not correct
            case off:
                break;
            case checking:
                // Handle checking stages
                break;
            case running:
                // Handle running stages
                break;
        }
        pr_mode = m;
    }
    else {
        reset_output();
        tmp_prot.val = false;
    }
}
```

The checking mode has three stages:
1. Check if voltage is above minimum
2. Ramp up starter and wait for minimum speed
3. Starter is confirmed working

The running mode has seven stages:
1. Check if voltage is above minimum
2. Preheat igniter
3. Start fuel pump and igniter valve
4. Ramp up starter and wait for ignition speed
5. Turn off igniter and wait for self-sustaining speed
6. Calibration period
7. Normal operation with PID control

### 6.4 Outputs

The block provides nine outputs:

| Index | Type | Description |
|-------|------|-------------|
| 0 | Real | Fuel Pump Voltage |
| 1 | bool | Temperature protection status |
| 2 | Real | PID proportional term |
| 3 | Real | PID integral term |
| 4 | Real | PID derivative term |
| 5 | Real | Main valve voltage |
| 6 | Real | Igniter valve voltage |
| 7 | Real | Igniter voltage |
| 8 | Real | Starter engine voltage |

```cpp
const Blocks::Ipin* Blk_ecu::get_out(Uint16 i) const {
    enum Outs {
        out_fpv          = 0,  // Fuel Pump Voltage
        out_tmp_prot     = 1,  // Boolean to know on/off temperature protection
        out_prop         = 2,  // Proportional term of PID
        out_itg          = 3,  // Integral term of PID
        out_der          = 4,  // Derivative term of PID
        out_main_v       = 5,  // Voltage to main valve
        out_ign_v        = 6,  // Voltage to second valve
        out_ign          = 7,  // Voltage to igniter
        out_starter      = 8,  // Voltage to starter engine
    };
    const Blocks::Ipin* ret = 0;
    switch (static_cast<Outs>(i)) {
        case out_fpv:      ret = &fpv; break;
        case out_tmp_prot: ret = &tmp_prot; break;
        case out_prop:     ret = &prop; break;
        case out_itg:      ret = &itg; break;
        case out_der:      ret = &der; break;
        case out_main_v:   ret = &main_v; break;
        case out_ign_v:    ret = &ign_v; break;
        case out_ign:      ret = &ign; break;
        case out_starter:  ret = &starter; break;
        default:           Bsp::warning(); break;
    }
    return ret;
}
```

## 7. Blk_apsel: Autopilot Selection Block

The `Blk_apsel` class handles autopilot selection in redundant configurations.

### 7.1 Purpose and Functionality

`Blk_apsel` produces outputs that indicate when the output of the autopilot should be overwritten with the output from another autopilot (from a redundant 4xVeronte configuration) and provides the actual overwriting value.

### 7.2 Class Structure and Components

```cpp
class Blk_apsel : public Blocks::Iblock {
public:
    Blk_apsel(const volatile Ver::Xapsel_cpu1& apsel10, volatile Ver::Xapsel_cpu2& apsel20);
    virtual void step();
    virtual const Blocks::Ipin* get_out(Uint16 i) const;
    virtual void cset(Base::Lossy_error& str, Csetpm& params);

private:
    const volatile Ver::Xapsel_cpu1& apsel1;    // AP selection data from CPU1
    volatile Ver::Xapsel_cpu2& apsel2;          // AP selection data from CPU2
    Bsp::Hbvar is_selected;                     // True if this AP is the one selected
    Uint16 start_channel;                       // First channel
    Blocks::Pin_ptr<Real> in;                   // Input computed in current AP
    Blocks::Pin<Maverick::Rvector> out;         // Output with overwriting U value
};
```

### 7.3 Configuration Parameters

The `Blk_apsel` block is configured with:

| Type | Name | Content | Range |
|------|------|---------|-------|
| Uint16 | channel | Channel id | <20 |

### 7.4 Processing Logic

The `step()` method determines whether to use the local input or the value from the selected autopilot:

```cpp
void Blk_apsel::step() {
    out.val.copy(is_selected.get() ? &in.read() : const_cast<const Real*>(&apsel1.consens_reals[start_channel]));
}
```

If this autopilot is selected (`is_selected.get()` is true), it uses the local input. Otherwise, it uses the value from the selected autopilot received via CAN.

### 7.5 Outputs

The block provides one output:

| Index | Type | Description |
|-------|------|-------------|
| 0 | Rvector | Output value (local or from selected AP) |

```cpp
inline const Blocks::Ipin* Blk_apsel::get_out(Uint16 i) const {
    return Base::Paramsel::select<Blocks::Ipin>(i, out);
}
```

## 8. Apsel: Autopilot Selection Manager

The `Apsel` class manages the selection of autopilots in a redundant 4xVeronte configuration.

### 8.1 Purpose and Functionality

`Apsel` determines whether the current autopilot should be the active one (CAP - Control Autopilot) based on configuration and communication status.

### 8.2 Class Structure and Components

```cpp
class Apsel {
public:
    Apsel();
    bool step();

private:
    const volatile bool& enabled_4x;     // Reference to 4x enable configuration
    bool prev_active;                    // True if this AP was previously active
    const Bsp::Huvar this_ap;            // This AP's index within the 4x
    const Bsp::Huvar selected;           // Access to index of selected AP
    Bsp::Hbvar is_selected;              // True when this AP is the one selected
    const Bsp::Hbvar error_bit;          // CAN 4x error bit
};
```

### 8.3 Processing Logic

The `step()` method determines if this autopilot should be the active one:

```cpp
bool Apsel::step() {
    const bool active = (!enabled_4x) || (!error_bit.get()) || (this_ap.get() == selected.get());
    const bool ret = (!prev_active) && active;
    prev_active = active;
    is_selected.set(active);
    return ret;
}
```

The autopilot is active if:
1. The 4x functionality is disabled, OR
2. The CAN 4x functionality has failed, OR
3. This autopilot is the selected one

The method returns true if the autopilot has just become active (transition from inactive to active).

## 9. Cross-Component Relationships

### 9.1 Control Flow Relationships

The input/output and actuator interface blocks form a control flow chain:

```
Blk_stick (Input) → Blk_manual/Blk_mix (Mode Selection) → Control Logic → Blk_pwm (Output)
```

1. `Blk_stick` processes raw inputs from remote controls
2. `Blk_manual` and `Blk_mix` handle different control modes
3. Control logic blocks process the inputs
4. `Blk_pwm` sends the processed signals to actuators

### 9.2 Mode Selection Relationships

The mode selection blocks work together with a mode table:

```
Modetable → Blk_manual/Blk_mix
```

The `Modetable` class stores the current mode for each channel, and `Blk_manual` and `Blk_mix` use this information to determine how to process inputs.

### 9.3 Redundancy Relationships

The autopilot selection blocks form a redundancy chain:

```
Apsel → Blk_apsel → Control Outputs
```

1. `Apsel` determines if this autopilot should be active
2. `Blk_apsel` selects between local and remote control values
3. Control outputs are sent to actuators

## 10. Summary

The VBlocks library provides a comprehensive set of input/output and actuator interface blocks:

1. **Blk_stick**: Processes stick inputs from various sources with priority-based selection and linear transformation.
2. **Blk_manual**: Handles manual control mode, selecting between stick and automatic inputs.
3. **Blk_mix**: Implements mixed control mode, adding stick inputs to automatic inputs.
4. **Blk_pwm**: Controls PWM outputs for actuators.
5. **Blk_driver**: Calculates projected desired trajectory vectors for model predictive control.
6. **Blk_ecu**: Implements a comprehensive engine control unit with PID control and automatic start sequence.
7. **Blk_apsel**: Handles autopilot selection in redundant configurations.
8. **Apsel**: Manages the selection of autopilots in a redundant 4xVeronte configuration.

These blocks provide a flexible and powerful interface between the control system and the physical hardware, supporting various control modes, redundancy configurations, and specialized actuator control.

## Referenced Context Files

- **04_VBlocks_Core.md**: Provided context about the overall VBlocks library architecture, including the block factory system, block type definitions, and signal types. This helped understand how the input/output and actuator interface blocks fit into the larger system.