# Generated from:

- include/utils/Serialization_test_utils.h (1663 tokens)
- include/utils/Maneuver_test_utils.h (2057 tokens)
- include/utils/Unit_test_mission_v3.h (348 tokens)
- include/utils/Test_macros.h (1149 tokens)
- include/utils/attribute_comparison.h (846 tokens)
- include/utils/bus2struct.h (170 tokens)
- include/utils/Controller_Status_test_utils.h (165 tokens)
- include/utils/Flight_dynamics_test_utils.h (476 tokens)
- include/utils/csv_parser.h (1417 tokens)
- include/utils/Nav_utils.h (55 tokens)
- include/utils/Rotation_utilities_test_utils.h (98 tokens)
- include/utils/Binary_io.h (473 tokens)
- include/utils/State_machines_test_utils.h (801 tokens)
- include/utils/Ttcg_test_utils.h (1166 tokens)
- include/utils/Print_test_status.h (137 tokens)
- include/utils/protobuf_test_utils.h (417 tokens)
- include/utils/Test_list.h (154 tokens)
- include/utils/Body_transformation_test_utils.h (401 tokens)
- include/utils/json/json-forwards.h (3710 tokens)
- include/utils/json/json_test_utils.h (619 tokens)
- include/utils/json/json.h (19737 tokens)
- source/utils/bus2struct.cpp (4383 tokens)
- source/utils/Controller_Status_test_utils.cpp (328 tokens)
- source/utils/Test_list.cpp (285 tokens)
- source/utils/attribute_comparison.cpp (2968 tokens)
- source/utils/Print_test_status.cpp (447 tokens)
- source/utils/Maneuver_test_utils.cpp (2501 tokens)
- source/utils/Flight_dynamics_test_utils.cpp (1759 tokens)
- source/utils/Rotation_utilities_test_utils.cpp (1500 tokens)
- source/utils/Test_macros.cpp (119 tokens)
- source/utils/Ttcg_test_utils.cpp (6789 tokens)
- source/utils/Body_transformation_test_utils.cpp (881 tokens)
- source/utils/Unit_test_mission_v3.cpp (7973 tokens)
- source/utils/Nav_utils.cpp (633 tokens)
- source/utils/State_machines_test_utils.cpp (1448 tokens)
- source/utils/protobuf_test_utils.cpp (12256 tokens)
- source/utils/json/json_test_utils.cpp (536 tokens)
- source/utils/json/jsoncpp.cpp (39626 tokens)
- source/externs.cpp (9 tokens)

---

# Comprehensive Summary of Drone Testing Framework

## 1. JSON Library Implementation

The testing framework includes a complete implementation of the JsonCpp library, which provides JSON parsing and serialization capabilities. This is a key component used for test data handling and configuration.

### JsonCpp Core Components

The library provides comprehensive JSON handling with the following key features:

- **Value Class**: The central class representing any JSON value (null, boolean, number, string, array, object)
- **Reader Class**: Parses JSON from strings or streams into Value objects
- **Writer Classes**: Multiple writer implementations for different formatting needs:
  - `FastWriter`: Compact output with no whitespace
  - `StyledWriter`: Human-readable output with indentation
  - `StyledStreamWriter`: Stream-based version of StyledWriter
  - `StreamWriter`: Abstract base class for stream-based writers

### JSON Value Types and Operations

The library supports all JSON value types:
- Null values
- Booleans (true/false)
- Numbers (integers, unsigned integers, 64-bit integers, floating-point)
- Strings (with proper Unicode handling)
- Arrays (indexed collections)
- Objects (key-value maps)

Value operations include:
- Type checking (`isNull()`, `isBool()`, `isInt()`, etc.)
- Type conversion (`asInt()`, `asDouble()`, `asString()`, etc.)
- Array and object manipulation (indexing, member access)
- Deep copying and comparison
- Comment handling (before value, after value, same line)

### JSON Parsing Features

The Reader class provides configurable parsing with:
- Comment handling (C and C++ style comments)
- Strict mode for standards compliance
- Error reporting with line and column information
- Support for special values (NaN, Infinity)
- Unicode escape sequence handling

### JSON Writing Features

The writer classes offer:
- Configurable indentation
- YAML compatibility mode
- Null placeholder handling
- Special float value handling (NaN, Infinity)
- UTF-8 output
- Precision control for floating-point values

## 2. Functional Behavior and Logic

The testing framework provides extensive utilities for testing various components of a drone control system. It includes specialized tools for testing serialization, maneuvers, controllers, navigation, and state machines. The framework is designed to support both unit testing and integration testing of the drone's software components.

### Core Testing Infrastructure

The framework provides a robust set of testing macros and utilities that enable:
- Assertion-based testing with detailed failure reporting
- Comparison of floating-point values with appropriate tolerances
- Structured test organization and execution
- Test result reporting and status tracking

### Test Organization and Execution

Tests are organized using the `Test_list` class which maintains a registry of test functions:
```cpp
class Test_list {
public:
    typedef bool (*Ftest)();  // General definition of test function
    bool add_test(const std::string& test_name, Ftest test_function);
    bool run(const std::string& test_name);
    bool test_exists(const std::string& test_name) const;
    std::map<std::string, Ftest> tests;
};
```

Test execution is managed through the `Print_test_status` namespace which provides functions for:
- Printing test titles and headers
- Reporting individual test results (pass/fail/x-fail)
- Formatting overall test status with color coding

## 3. Serialization Testing Utilities

The `Serialization_test_utils` class provides methods for testing serialization and deserialization of various data types:

```cpp
struct Serialization_test_utils {
    template<typename T>
    static bool execute_deserialization(std::string filename, T& obj);
    
    template<typename T>
    static bool execute_deserialization_u8stream(std::string filename, T& obj);
    
    template<typename T>
    static bool execute_serialization(std::string filename, std::string filename_out, T& obj);
    
    template<typename T>
    static bool execute_serialization_u8stream(std::string filename, std::string filename_out, T& obj);
    
    template<typename T>
    static bool execute_deserialization_cyphal(std::string filename, T& obj);
    
    template<typename T>
    static bool execute_serialization_cyphal(std::string filename, std::string filename_out, T& obj);
};
```

These methods support:
- Reading binary data from files
- Serializing objects to binary data
- Deserializing binary data to objects
- Testing Cyphal protocol serialization/deserialization
- Handling different endianness and stream types

The implementation uses `Binary_io` for file operations and various stream classes (`Base::Lossy`, `Base::U8istream`, `Base::U8ostream`) for data manipulation.

## 4. Maneuver Testing Utilities

The framework provides extensive utilities for testing different types of drone maneuvers:

### Straight Maneuver Testing

`Straight_maneuver_test` extends `Straight_maneuver` to expose internal methods for testing:
```cpp
class Straight_maneuver_test : public Straight_maneuver {
public:
    bool ConstructVtolStraightManeuver(const Waypoint_msg& wp_initial_ned_ned2pos, const Waypoint_msg& wp_target_ned_ned2pos);
    bool ConstructWbfStraightManeuver(const Waypoint_msg& wp_initial_ned_ned2pos, const Waypoint_msg& wp_target_ned_ned2pos);
    bool SetValidateWaypointsTest(const Waypoint_msg& wp_initial_ned_ned2pos, const Waypoint_msg& wp_target_ned_ned2pos);
    inline bool IsValid();
};
```

### Hover Maneuver Testing

`Hover_maneuver_test` extends `Hover_maneuver` for testing:
```cpp
class Hover_maneuver_test : public Hover_maneuver {
public:
    bool ConstructVtolHoverManeuver(const Waypoint_msg& wp_ned_ned2pos, const double duration_s);
    inline const bool IsValid();
};
```

### Maneuver Message Creation Utilities

The framework provides functions to create valid maneuver messages for testing:
```cpp
static Maneuver_msg ValidRollManeuverMessage(Turn_direction::Direction& turn_direction, 
                                            Real initial_turn_radius_m,
                                            Real target_turn_radius_m);

static Maneuver_msg ValidStraightManeuverMessage(Phase_of_flight phase_of_flight);

static Maneuver_msg ValidHoverManeuverMessage();

static Maneuver_msg ValidTurnManeuverMessage(Turn_direction::Direction turn_direction, 
                                            Phase_of_flight phase_of_flight, 
                                            Real turn_radius_m);
```

### Waypoint Generation

The framework includes utilities for generating test waypoints:
```cpp
static Waypoint_msg SampleTurning2dFlightWaypoint(
    Real turn_radius_m,
    Turn_direction::Direction& turn_direction,
    Maverick::Rvector2& p_center_of_turn_m,
    Real min_angle_rad,
    Real max_angle_rad,
    Real min_speed_m_per_s,
    Real max_speed_m_per_s);
```

## 5. Controller Testing Utilities

The `Controller_Status_tester` class provides a testing interface for the drone's controller system:

```cpp
class Controller_Status_tester : public Pa_blocks::Controllers_object {
public:
    Controller_Status_tester(const Pa_blocks::Vsdk_controllers_params& param, 
                            const Controllers_param& controllers_param0);
    bool run(const Pa_blocks::Controllers_object::Input& input, 
             Pa_blocks::Controllers_object::Output& output);
    const Pa_blocks::Controllers_state& GetState() const;
    void SetState(Pa_blocks::Controllers_state& state);
    bool IsSpecificationValid();
};
```

This allows testing of:
- Controller state transitions
- Input/output behavior
- Parameter validation
- Controller specification compliance

## 6. State Machine Testing

The `State_machines_tester` class provides comprehensive testing capabilities for the drone's state machines:

```cpp
class State_machines_tester {
public:
    State_machines_tester();
    
    // Reset methods
    void ResetTakeoffStateMachine(Pa_blocks::State_machines_state::Takeoff_mode::Mode& takeoff_mode);
    void ResetLandStateMachine(Pa_blocks::State_machines_state::Land& land_state);
    
    // Initialize methods
    void InitializeLandStateMachine(const Pa_blocks::State_machines_state::Mode::Controllers_mode& last_controllers_mode,
                                   Pa_blocks::Phase_of_flight& tracked_phase_of_flight,
                                   Pa_blocks::State_machines_state::Land &land_state);
    void InitializeTakeoffStateMachine(Pa_blocks::State_machines_state::Takeoff_mode::Mode& takeoff_mode);
    void InitializeIntegratorsStateMachine(Pa_blocks::State_machines_state::Integrators_mode::Mode& integrators_mode);
    void InitializeModeStateMachine(Pa_blocks::State_machines_state::Mode::Controllers_mode& controllers_mode);
    
    // Condition evaluation methods for various state machines
    bool EvalIntegratorsOnGround();
    bool EvalIntegratorsModeForceOn();
    bool EvalModePBITDonePassed();
    bool EvalModeTakeoff();
    bool EvalModeTrackSpline();
    bool EvalModeTakeoffComplete();
    bool EvalModeLand();
    bool EvalModeOnGround();
    bool EvalModeInFlightTest();
    bool EvalTakeoffOnGround();
    bool EvalTakeoffAbovePositionHoldAltitude();
    bool EvalTakeoffAboveCompleteAltitude();
    bool EvalDegradationLevelOneRotorInoperative();
    bool EvalDegradationLevelMoreThanOneRotorInoperative();
    bool EvalGainTypeLandMode();
    bool EvalGainTypeTrackSplineMode();
    bool EvalGainTypeLowSpeedManeuver();
    bool EvalGainTypeLandStateSlowDownToHover();
};
```

This allows testing of:
- State transitions in takeoff, landing, and flight modes
- Condition evaluation for state changes
- Initialization of state machines
- Degradation level detection and handling
- Gain type selection based on flight mode

## 7. Navigation Testing Utilities

The framework provides utilities for testing navigation components:

### Navigation State Comparison

```cpp
struct Nav_utils {
    static bool compare_state(const Pa_blocks::State& s0, const Pa_blocks::State& s1);
};
```

### Bus to Structure Conversion

The `Bus2struct` class provides utilities for converting between bus data formats and structured data:

```cpp
struct Bus2struct {
    static const Uint32 STATE_EN_LENGTH = 74;
    static void state_dec(const Real64* state_en, Pa_blocks::State& state_dec);
    static void state_to_array(const Pa_blocks::State& state, Real64 *state_arr);
    static void introspect_initializer_dec(const Real64* intr_en, Base::Bitmask<Uint16>& ini_done);
    static void meas_dec(const Real64* data_en, Pa_blocks::Measurements& meas_dec, Pa_blocks::Nav_type::Type nav_type);
};
```

This enables testing of:
- Navigation state conversion
- Measurement data processing
- Initialization status tracking

## 8. Trajectory Tracking Testing

The `Ttcg_test_utils` struct provides utilities for testing trajectory generation and tracking:

```cpp
struct Ttcg_test_utils {
    template <Uint32 N>
    static void route_msg_from_maneuver_msg(const Base::Tnarrayresz<Maneuver_msg, N>& maneuver_msg,
                                           const Uint32 id,
                                           Route_msg& route_msg);
    
    static void construct_vtol_straight_maneuver_msg(Uint32 id, Maneuver_msg& maneuver_msg);
    static void construct_wbf_straight_maneuver_msg(Uint32 id, Maneuver_msg& maneuver_msg);
    static void construct_turn_maneuver_msg(Uint32 id, Turn_direction::Direction turn_direction,
                                           Real turn_radius_m, Maneuver_msg& maneuver_msg);
    static void construct_vtol_hover_maneuver_msg(Uint32 id, Maneuver_msg& maneuver_msg);
    static void construct_roll_maneuver_msg(Uint32 id, Turn_direction::Direction turn_direction,
                                          Real turn_radius_m, Real target_turn_radius,
                                          Maneuver_msg& maneuver_msg);
    
    static bool get_route_phase_of_flight_transition_indices(const Route_msg& route,
                                                           const Phase_of_flight& phase_of_flight_from,
                                                           const Phase_of_flight& phase_of_flight_to,
                                                           Base::Tnarrayresz<Uint32, Ku16::u4>& transition_indices);
    
    static void create_turning_flight_waypoint(Real internal_angle_rad, Real V_m_per_s,
                                             Maverick::Rvector3& p_ned_ned2center_m,
                                             Real turn_radius_m, Turn_direction::Direction turn_direction,
                                             Waypoint_msg& wp_msg);
    
    static Route_msg get_route_msg(Uint32 route_id, bool& ret);
    
    static Route_msg update_phase_of_flight_minimal_route_for_test_scenario(...);
    
    static void construct_maneuver(Maneuver_msg& maneuver_);
    
    static Base::Tllh default_wgs84_location();
    
    static Real compute_commanded_displacement_from_start_of_route(Ttcg& ttcg);
};
```

This enables testing of:
- Route construction from maneuvers
- Different maneuver types (straight, turn, hover, roll)
- Phase of flight transitions
- Waypoint generation for turning flight
- Route displacement calculation

## 9. Body Transformation Testing

The `Body_transformations_pa_tester` class provides testing capabilities for body frame transformations:

```cpp
class Body_transformations_pa_tester : public Gnc_body_transformations {
public:
    Body_transformations_pa_tester(const Gnc_transformation::Build_params& vtol_from_bul,
                                 const Gnc_transformation::Build_params& vf_from_bul,
                                 const Base::Rv3& t_bul_bul2vf_m);
    
    // Accessor methods for transformations
    const Gnc_transformation& get_vtol_from_bul() const;
    const Gnc_transformation& get_vf_from_bul() const;
    const Gnc_transformation& get_bul_from_vtol() const;
    const Gnc_transformation& get_vf_from_vtol() const;
    const Gnc_transformation& get_bul_from_vf() const;
    const Gnc_transformation& get_vtol_from_vf() const;
    
    // Methods for center of gravity transformations
    Gnc_transformation::Build_params get_vf_cg_from_vf(const Maverick::Rvector3& p_bul_bul2cg_m) const;
    Gnc_transformation::Build_params get_vf_from_vf_cg(const Maverick::Rvector3& p_bul_bul2cg_m) const;
    Gnc_transformation::Build_params get_vtol_cg_from_vf(const Maverick::Rvector3& p_bul_bul2cg_m) const;
    Gnc_transformation::Build_params get_vtol_cg_from_vtol(const Maverick::Rvector3& p_bul_bul2cg_m) const;
    Gnc_transformation::Build_params get_vtol_from_vtol_cg(const Maverick::Rvector3& p_bul_bul2cg_m) const;
};
```

This allows testing of:
- Frame transformations between different coordinate systems
- Center of gravity transformations
- Rotation and translation operations

## 10. Flight Dynamics Testing

The `Flight_dynamics_test_utils` struct provides utilities for testing flight dynamics calculations:

```cpp
struct Flight_dynamics_test_utils {
    static Real compute_reynolds_number(const Real& true_airspeed_m_per_s, 
                                       const Real& density_kg_per_m3, 
                                       const Real& dynamic_viscosity_kg_per_m_s, 
                                       const Real& length_scale_m);
    
    static Real dynamic_viscocity_from_temperatureC(const Real& temperature_c);
    
    static Tas_alpha_beta tas_alpha_beta_from_air_relative_velocity(const Maverick::Rvector3& v_frame_wind2frame_m_per_s);
    
    static Base::Rv3 air_relative_velocity_from_tas_alpha_beta(const Tas_alpha_beta& tas_alpha_beta);
    
    static Real temperature_celsius_from_kelvin(const Real& temperature_k);
    
    static Base::Tnarray<Real, Ku16::u6> inertia_vector_from_matrix(const Maverick::Rmatrix3& inertia_matrix);
    
    static void mass_matrix_from_inertia_and_mass(const Real& mass, 
                                                const Maverick::Rmatrix3& inertia_matrix,
                                                Maverick::Rmatrix& mass_matrix);
    
    static Real compute_bank_angle(const Maverick::Rvector3& v_ned_ned2frame_m_per_s, 
                                  const Maverick::Rvector3& a_ned_ned2frame_m_per_s2);
};
```

This enables testing of:
- Aerodynamic calculations (Reynolds number)
- Air data conversions (TAS, alpha, beta)
- Temperature conversions
- Inertia and mass matrix calculations
- Bank angle computation

## 11. Attribute Comparison Utilities

The `Utils` struct provides comprehensive comparison functions for various data types:

```cpp
struct Utils {
    static bool are_equal(const Base::Rv3& rv_1, const Base::Rv3& rv_2, Real tol);
    static bool are_equal(const Base::Rv4& rv_1, const Base::Rv4& rv_2, Real tol);
    static bool are_equal(const Waypoint_msg& wp_msg_1, const Waypoint_msg& wp_msg_2);
    static bool are_equal(const Base::Tllh& lla_location_1, const Base::Tllh& lla_location_2, const Real64 tol_lat_lon);
    static bool are_equal(const Commands_processor::Land_command& land_command_1, const Commands_processor::Land_command& land_command_2);
    static bool are_equal(const Current_route_information& current_route_information_1, const Current_route_information& current_route_information_2);
    static bool are_equal(const Commands_processor::Route_command_and_control& route_command_1, const Commands_processor::Route_command_and_control& route_command_2);
    static bool are_equal(const Commands_processor::Takeoff_command& takeoff_command_1, const Commands_processor::Takeoff_command& takeoff_command_2);
    static bool are_equal(const Route_msg& route_msg_1, const Route_msg& route_msg_2);
    static bool are_equal(const Maneuver_msg& maneuver_msg_1, const Maneuver_msg& maneuver_msg_2);
    static bool are_equal(const Maneuver_coordinate& mc_msg_1, const Maneuver_coordinate& mc_msg_2);
    static bool are_equal(const Waypoint_coordinate& wc_msg_1, const Waypoint_coordinate& wc_msg_2);
    static bool comp_vec(const Maverick::Irvector3& v1, const Maverick::Irvector3& v2, Real tol);
    static bool comp_mat(const Maverick::Irmatrix3& v1, const Maverick::Irmatrix3& v2, Real tol);
    static void make_state_estimate_valid(Controllers_state_estimate& state_estimate);
    static bool are_equal(const Base::Ttime& t1, const Base::Ttime& t2);
    static bool are_equal(const State::Nav_status& nav1, const State::Nav_status& nav2);
    static bool are_equal(const Aiding_sensors_info::Sensor_status& s1, const Aiding_sensors_info::Sensor_status& s2);
    static bool are_equal(const Measurements::Time_sync_offset& ts1, const Measurements::Time_sync_offset& ts2);
    
    template <typename P0, typename P1, typename EPS>
    static bool is_approx(const P0& param0, const P1& param1, const EPS eps);
};
```

These functions enable precise comparison of:
- Vectors and matrices
- Waypoints and coordinates
- Route and maneuver messages
- Command messages
- Navigation state components
- Sensor status information
- Time values

## 12. Mission Testing Utilities

The framework provides utilities for testing mission planning and execution:

```cpp
void generate_icd3_viable_mission(Mission_plan_data& mission_plan_data,
                                 Upload_mission_plan_wrapper& mission_plan_upload_metadata);

Mission_plan generate_valid_mission_plan_object();

Mission_step get_gps_land_action_step(const WGS84_point_3d& target_point, const Uint32 step_id);
Mission_step get_marker_land_action_step(const WGS84_point_3d& target_point, const Uint32 step_id);
Mission_step get_takeoff_action_step(const Uint32 step_id);
Mission_step get_markerless_delivery_action_step(const WGS84_point_3d& target_point, const Uint32 step_id);
Mission_step get_straight_vtol_maneuver_step(const Uint32 step_id);
Mission_step get_straight_wbf_maneuver_step(const Uint32 step_id);
Mission_step get_hover_vtol_maneuver_step(const Uint32 step_id, const Real64 hover_duration_s = 1.0F);
Mission_step get_roll_wbf_maneuver_step(const Uint32 step_id);
Mission_step get_turn_wbf_maneuver_step(const Uint32 step_id);
```

These functions enable testing of:
- Mission plan generation
- Mission step creation for various actions (takeoff, land, delivery)
- Maneuver step creation (straight, hover, roll, turn)
- Mission plan validation

## 13. JSON and Protobuf Testing Utilities

The framework includes utilities for testing JSON and Protocol Buffer serialization:

### JSON Utilities

```cpp
namespace JsonTestUtils {
    void CreateDoubleVectorFromJson(const Json::Value& root, std::string name, Maverick::R64vector& vector);
    void CreateFloatVectorFromJson(const Json::Value& root, std::string name, Maverick::Rvector& vector);
    void CreateDoubleMatrixFromJson(const Json::Value& root, std::string name, Maverick::R64matrix& matrix);
    void CreateFloatMatrixFromJson(const Json::Value& root, std::string name, Maverick::Rmatrix& matrix);
}
```

### Protobuf Testing Utilities

```cpp
struct Protobuf_test_utils {
    static bool check_version(const Mission_plan_msg::Mission::Version& actual, const Json::Value& expected);
    static bool check_environment(const Mission_plan_msg::Mission::Environment& actual, const Json::Value& expected);
    static bool check_vehicle_parameters(const Mission_plan_msg::Mission::Vehicle_parameters& actual, const Json::Value& expected);
    static bool check_crs(const Mission_plan_msg::Mission::Crs& actual, const Json::Value& expected);
    static bool check_bounding_volume(const Geospatial_cuboid& actual, const Json::Value& expected);
    static bool check_mission_step(const Mission_step& actual, const Json::Value& expected);
    static bool check_initial_plan(const Initial_plan& actual, const Json::Value& expected);
    static bool check_alternate_plans_buffer(const Mission_plan_msg::Mission& parsed_mission, const Json::Value& expected);
    static bool check_alternate_plan(const Alternate_plan& actual, const Json::Value& expected);
};
```

These utilities enable testing of:
- JSON parsing and serialization
- Protocol Buffer message validation
- Comparison between JSON and Protocol Buffer representations

## 14. Test Assertion Macros

The framework provides a comprehensive set of assertion macros for test validation:

```cpp
#define EXPECT_FALSE(b) Test_macros::return_and_print_failure(((b) == false), __func__, __TEST_FILENAME__, __LINE__);
#define EXPECT_TRUE(b) Test_macros::return_and_print_failure(((b) == true), __func__, __TEST_FILENAME__, __LINE__);
#define EXPECT_EQ(a, b) Test_macros::return_and_print_failure(((a) == (b)), __func__, __TEST_FILENAME__, __LINE__);
#define EXPECT_FLOAT_EQ(a, b) Test_macros::return_and_print_failure(Test_macros::check_floating_point_equality<float>(a, b), __func__, __TEST_FILENAME__, __LINE__);
#define EXPECT_NE(a, b) Test_macros::return_and_print_failure(((a) != (b)), __func__, __TEST_FILENAME__, __LINE__);
#define ASSERT_TRUE(b) Test_macros::return_and_print_failure(((b) == true), __func__, __TEST_FILENAME__, __LINE__);
#define ASSERT_FALSE(b) Test_macros::return_and_print_failure(((b) == false), __func__, __TEST_FILENAME__, __LINE__);
#define ASSERT_EQ(a, b) Test_macros::return_and_print_failure(((a) == (b)), __func__, __TEST_FILENAME__, __LINE__);
#define ASSERT_NE(a, b) Test_macros::return_and_print_failure(((a) != (b)), __func__, __TEST_FILENAME__, __LINE__);
#define EXPECT_FLOAT_NE(a, b) Test_macros::return_and_print_failure(!Rfun::comp_real(a, b, std::numeric_limits<float>::epsilon()), __func__, __TEST_FILENAME__, __LINE__);
#define ASSERT_GE(a, b) Test_macros::return_and_print_failure(((a) >= (b)), __func__, __TEST_FILENAME__, __LINE__);
#define ASSERT_LE(a, b) Test_macros::return_and_print_failure(((a) <= (b)), __func__, __TEST_FILENAME__, __LINE__);
#define EXPECT_GT(a, b) Test_macros::return_and_print_failure(((a) > (b)), __func__, __TEST_FILENAME__, __LINE__);
#define EXPECT_GE(a, b) Test_macros::return_and_print_failure(((a) >= (b)), __func__, __TEST_FILENAME__, __LINE__);
#define EXPECT_LE(a, b) Test_macros::return_and_print_failure(((a) <= (b)), __func__, __TEST_FILENAME__, __LINE__);
#define EXPECT_LT(a, b) Test_macros::return_and_print_failure(((a) < (b)), __func__, __TEST_FILENAME__, __LINE__);
#define EXPECT_DOUBLE_EQ(a, b) Test_macros::return_and_print_failure(Rfun::comp_real(a, b, std::numeric_limits<double>::epsilon()), __func__, __TEST_FILENAME__, __LINE__);
#define EXPECT_NEAR(a, b, c) Test_macros::return_and_print_failure(Rfun::comp_real(a, b, c), __func__, __TEST_FILENAME__, __LINE__);
#define ASSERT_NEAR(a, b, c) Test_macros::return_and_print_failure(Rfun::comp_real(a, b, c), __func__, __TEST_FILENAME__, __LINE__);
#define ASSERT_DOUBLE_EQ(a, b) Test_macros::return_and_print_failure(((a) == (b)), __func__, __TEST_FILENAME__, __LINE__);
```

These macros provide:
- Boolean assertions (TRUE/FALSE)
- Equality assertions (EQ/NE)
- Comparison assertions (GT/GE/LT/LE)
- Floating-point assertions with appropriate tolerances (FLOAT_EQ, DOUBLE_EQ, NEAR)
- Detailed failure reporting with function name, file name, and line number

## 15. CSV Parsing Utilities

The `csv_parser` class provides utilities for reading and writing CSV files:

```cpp
class csv_parser {
public:
    csv_parser(const std::string& name, const bool clean = false);
    uint64_t get_n_row() const;
    void get_real64_arr(Real64 *data);
    std::string array_to_csv_row(const double* array, Uint32 size);
    void set_real64_arr(const Real64 *data, const Uint32 length);
    void get_real_arr(Real *data);
    void close();
};
```

This enables:
- Reading test data from CSV files
- Writing test results to CSV files
- Converting between arrays and CSV rows

## 16. Rotation Utilities Testing

The `Rotation_utilities_utils` class provides utilities for testing rotation operations:

```cpp
class Rotation_utilities_utils {
public:
    static bool compute_shortest_rotation_between_two_vectorsCases(
        const std::string& test_case_name,
        const Maverick::Rvector3 &v_A_A_range,
        const Maverick::Rvector3 &v_B_A_perturbation_range,
        const uint32_t n_cases);
};
```

This enables testing of:
- Rotation calculations between vectors
- Edge cases in rotation operations
- Numerical stability of rotation algorithms

## 17. System Reset Testing

The framework includes a global flag for testing system reset functionality:

```cpp
bool veronte_reset_request = false;
```

This flag can be used in tests to simulate system reset requests and verify proper handling of reset conditions.

## Referenced Context Files

The following context files were helpful in understanding the testing framework:

1. `include/utils/Serialization_test_utils.h` - Defines utilities for testing serialization and deserialization
2. `include/utils/Maneuver_test_utils.h` - Provides utilities for testing different maneuver types
3. `include/utils/Test_macros.h` - Defines assertion macros for test validation
4. `include/utils/attribute_comparison.h` - Contains comparison functions for various data types
5. `include/utils/Binary_io.h` - Provides binary I/O operations for testing
6. `include/utils/State_machines_test_utils.h` - Defines utilities for testing state machines
7. `include/utils/json/json.h` - JSON library implementation for test data
8. `include/utils/Ttcg_test_utils.h` - Utilities for testing trajectory tracking
9. `include/utils/Body_transformation_test_utils.h` - Utilities for testing body frame transformations
10. `include/utils/Flight_dynamics_test_utils.h` - Utilities for testing flight dynamics calculations

These files collectively provide a comprehensive framework for testing all aspects of the drone control system, from low-level serialization to high-level mission planning and execution.