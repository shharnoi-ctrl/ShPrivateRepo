# Generated from:

- _sw_Veronte/code/veronte/code/include/Regvars.h (1768 tokens)
- _sw_Veronte/code/veronte/code/include/Hregvars.h (310 tokens)
- _sw_Veronte/code/veronte/code/source/Hregvars.cpp (74 tokens)
- _sw_Veronte/code/veronte/code/source/cpu1/Hregvars_cpu1.cpp (68 tokens)
- _sw_Veronte/code/veronte/code/include/Varsuite1D.h (485 tokens)
- _sw_Veronte/code/veronte/code/source/Varsuite1D.cpp (118 tokens)
- _sw_Veronte/code/veronte/code/include/Varsuite3D.h (489 tokens)
- _sw_Veronte/code/veronte/code/source/Varsuite3D.cpp (132 tokens)
- _sw_Veronte/code/veronte/code/include/Varsensor1D.h (515 tokens)
- _sw_Veronte/code/veronte/code/source/Varsensor1D.cpp (421 tokens)
- _sw_Veronte/code/veronte/code/include/Varsensor3D.h (555 tokens)
- _sw_Veronte/code/veronte/code/source/Varsensor3D.cpp (552 tokens)
- _sw_Veronte/code/veronte/code/include/Varmeas.h (690 tokens)
- _sw_Veronte/code/veronte/code/source/Varmeas.cpp (323 tokens)
- _sw_Veronte/code/veronte/code/include/VarGps.h (472 tokens)
- _sw_Veronte/code/veronte/code/source/VarGps.cpp (1049 tokens)
- _sw_Veronte/code/veronte/code/include/Hmeas.h (241 tokens)
- _sw_Veronte/code/veronte/code/source/Hmeas.cpp (82 tokens)
- _sw_Veronte/code/veronte/code/source/cpu1/Hmeas_cpu1.cpp (72 tokens)
- _sw_Veronte/code/veronte/code/source/Hvar.cpp (904 tokens)
- _sw_Veronte/code/veronte/code/source/cpu1/Hvar_cpu1.cpp (898 tokens)
- _sw_Veronte/code/veronte/code/source/cpu2/Hvar_cpu2.cpp (1867 tokens)
- _sw_Veronte/code/veronte/code/include/Xvarcal1D.h (116 tokens)
- _sw_Veronte/code/veronte/code/include/Xvarcal1D_fw.h (70 tokens)
- _sw_Veronte/code/veronte/code/include/Xvarcal3D.h (130 tokens)
- _sw_Veronte/code/veronte/code/include/Xvarcal3D_fw.h (75 tokens)
- _sw_Veronte/code/veronte/code/include/Hsensel.h (257 tokens)
- _sw_Veronte/code/veronte/code/source/Hsensel.cpp (85 tokens)
- _sw_Veronte/code/veronte/code/source/cpu2/Hsensel_cpu2.cpp (69 tokens)

## With context from:

- PackageSummaries/Embention/Amazon-PrimeAir/items/ASTRO/items/sw/sw_Astro/items/09_System_Architecture.md (5081 tokens)
- PackageSummaries/Embention/Amazon-PrimeAir/items/ASTRO/items/sw/sw_Astro/items/08_Multi_Core_Execution.md (6182 tokens)

---

# Variable Management System in the Veronte Architecture

This document provides a detailed analysis of the variable management system in the Veronte architecture, focusing on how system variables are defined, accessed, and shared between CPU cores.

## 1. Regvars Structure: Core Variable Storage

The `Regvars` structure serves as the primary container for system variables that are owned by CPU1 and copied to CPU2's variable manager. It provides a structured way to organize different types of system variables.

### 1.1 Variable Type Definitions

The `Regvars` structure defines various variable types using template specializations:

```cpp
struct Regvars {
    typedef Var<Uvar>::Regarray<vu_adc00, vu_adc16> Type_adc;
    typedef Var<Rvar>::Reg<v_tboard> Type_cpu_tboard;
    typedef Var<Rvar>::Regarray<v_rpm0, v_rpm5> Type_rpm;
    typedef Var<Bvar>::Regarray<kbit_pulse0, kbit_pulse3> Type_kbit_pulse;
    // Many more type definitions...
}
```

These type definitions use template specializations to create arrays or single registers of specific variable types:
- `Var<Uvar>`: Unsigned integer variables
- `Var<Rvar>`: Real (floating-point) variables
- `Var<Bvar>`: Boolean variables
- `Var<Fid>`: Feature ID variables

### 1.2 Variable Grouping

Variables are grouped by functionality within the `Regvars` structure:

```cpp
struct Regvars {
    // Type definitions...
    
    Type_adc                adc;                // ADC readings
    Type_cpu_tboard         cpu_tboard;         // CPU temperature
    Type_rpm                rpm;                // RPM measurements
    Type_pulse              pulse;              // Pulse measurements
    Type_kbit_pulse         kbit_pulse;         // Pulse status bits
    Type_regvar_rsec1       rsec1;              // Real variables section 1
    Type_inest_ok           inest_ok;           // Inertial estimation status
    Type_regvar_imu         imu_status;         // IMU status bits
    Type_press_valid        press_valid;        // Pressure sensor validity
    // Many more variable groups...
}
```

This organization provides a structured way to access related variables and helps maintain code clarity.

### 1.3 Complex Variable Groups

The `Regvars` structure also includes more complex variable groupings, such as the `Type_ubx` template for GPS data:

```cpp
template <Rvar rfrom, Rvar rto, Uvar ufrom, Uvar uto, Bvar bfrom, Bvar bto>
struct Type_ubx {
    typedef Var<Rvar>::Regarray<rfrom, rto> Type_rvars;
    typedef Var<Uvar>::Regarray<ufrom, uto> Type_uvars;
    typedef Var<Bvar>::Regarray<bfrom, bto> Type_bvars;
    Type_rvars rvars;
    Type_uvars uvars;
    Type_bvars bvars;
};

typedef Type_ubx<v_gps0_tow, v_gps0_hdop,
                 vu_gps0_nsat, vu_gps0_spoofing,
                 kbit_gps0nav, kbit_gps0movbase> Type_ubx0;
```

This allows for grouping related variables of different types (real, unsigned, boolean) that pertain to a single subsystem like GPS.

## 2. Hregvars: Variable Access Handler

The `Hregvars` class provides a static interface to access the `Regvars` structure, ensuring proper access to the variables across CPU cores.

### 2.1 Access Methods

```cpp
class Hregvars {
public:
    // Get a mutable reference to the registration variables
    static volatile Regvars& get_regvars();
    
    // Get a constant reference to the registration variables
    static const volatile Regvars& get_kregvars();
    
private:
    // Prevent instantiation
    Hregvars();
    Hregvars(const Hregvars& orig);
    ~Hregvars();
    Hregvars& operator=(const Hregvars& orig);
};
```

### 2.2 Implementation Details

The implementation of `Hregvars` differs between CPU cores:

#### Common Implementation (Both CPUs)
```cpp
// Used by both CPU1 and CPU2 for read-only access
const volatile Regvars& Hregvars::get_kregvars() {
    // Return the variables from CPU1's cross-core data
    return Xc::get_xcd_cpu1().vars;
}
```

#### CPU1-Specific Implementation
```cpp
// Only used by CPU1 for read-write access
volatile Regvars& Hregvars::get_regvars() {
    // Return the variables from CPU1's cross-core data
    return Xc::get_xcd_cpu1().vars;
}
```

This design ensures that:
1. CPU1 has full read-write access to the variables through `get_regvars()`
2. Both CPUs can read the variables through `get_kregvars()`
3. CPU2 cannot directly modify the variables (no `get_regvars()` implementation for CPU2)

## 3. Variable Access Handlers (Hrvar, Huvar, Hbvar)

The Veronte architecture provides specialized handlers for accessing different types of system variables.

### 3.1 Handler Classes

Three main handler classes exist for different variable types:

```cpp
// Real variable handler
class Hrvar {
public:
    Hrvar(Base::Rvar id0);
    Real get() const;                      // Get value (CPU2)
    void set(Real value);                  // Set value (CPU1/CPU2)
    const volatile Real& get_kref() const; // Get constant reference
    // Additional methods...
private:
    Base::Rvar id;                         // Variable ID
};

// Unsigned integer variable handler
class Huvar {
public:
    Huvar(Base::Uvar id0);
    Uint16 get() const;                    // Get value (CPU2)
    void set(Uint16 value);                // Set value (CPU1/CPU2)
    const volatile Uint16& get_kref() const; // Get constant reference
    // Additional methods...
private:
    Base::Uvar id;                         // Variable ID
};

// Boolean variable handler
class Hbvar {
public:
    Hbvar(Base::Bvar id0);
    bool get() const;                      // Get value (CPU2)
    void set(bool value);                  // Set value (CPU1/CPU2)
    const volatile bool& get_kref() const; // Get constant reference
    // Additional methods...
private:
    Base::Bvar id;                         // Variable ID
};
```

### 3.2 Implementation Differences Between CPU1 and CPU2

The implementation of these handlers differs significantly between CPU1 and CPU2:

#### CPU1 Implementation
```cpp
// CPU1 implementation for Hrvar::set
void Hrvar::set(Real value) {
    // Write to cross-core message queue for CPU2 to process
    wr.write(Base::xcmid_rvar_update, Base::Xcmrvar::Builder(id, value));
}

// CPU1 implementation for Hbvar::set
void Hbvar::set(bool value) {
    // Write to cross-core message queue for CPU2 to process
    wr.write(Base::xcmid_bvar_update, Base::Xcmbvar::Builder(id, value));
}
```

#### CPU2 Implementation
```cpp
// CPU2 implementation for Hrvar::set
void Hrvar::set(Real value) {
    // Directly update the variable in CPU2's memory
    Ver::Xc::get_xcd_cpu2().vmgr.rvars[id] = value;
}

// CPU2 implementation for Hbvar::set
void Hbvar::set(bool value) {
    // Directly update the variable in CPU2's memory
    Ver::Xc::get_xcd_cpu2().vmgr.bvars[id] = value;
}
```

This design ensures that:
1. When CPU1 sets a variable, it sends a message to CPU2 to update its copy
2. When CPU2 sets a variable, it directly updates its local copy
3. Both CPUs can read variables from CPU2's memory

### 3.3 Block Access Methods

The variable handlers also provide methods to access blocks of variables:

```cpp
// Get a block of real variables (CPU2)
Base::Mblock<volatile Real> Hrvar::get_block(Base::Rvar from_inclusive, Base::Rvar to_inclusive) {
    validate(from_inclusive, to_inclusive);
    return Base::Mblock<volatile Real>(&Ver::Xc::get_xcd_cpu2().vmgr.rvars[from_inclusive],
                              rngsz(from_inclusive, to_inclusive));
}

// Get a constant block of boolean variables (CPU2)
Base::Mblock<const volatile bool> Hbvar::get_kblock(Base::Bvar from, Base::Bvar to_inclusive) {
    return get_block(from, to_inclusive).to_const();
}
```

These methods allow efficient access to ranges of variables, which is useful for operations that need to process multiple related variables.

## 4. Variable Sensor System

The Veronte architecture includes a variable sensor system that allows system variables to be published as measurements.

### 4.1 Varsensor1D and Varsensor3D Classes

These classes convert system variables into 1D and 3D measurements:

```cpp
// 1D variable sensor
class Varsensor1D {
public:
    explicit Varsensor1D(Base::Hmeas1& meas0);
    void step();
    void config(const Base::Varsens1D_cfg::Rsens1d& vs0);
    
private:
    Base::Hmeas1& value;                // Reference to 1D measurement
    Base::Rangedeltacheck_nv dcheck;    // Delta and range checker
    const volatile Real* rvalue;        // Reference to 1D value
};

// 3D variable sensor
class Varsensor3D {
public:
    explicit Varsensor3D(Base::Hmeas3& meas0);
    void step();
    void config(const Base::Varsens3D_cfg::Rsens3d& vs0);
    
private:
    Base::Hmeas3& value;                // Reference to 3D measurement
    Base::Rangedeltacheck3_nv dcheck;   // Delta and range checker
    const volatile Real* rvalue0;       // Reference to X value
    const volatile Real* rvalue1;       // Reference to Y value
    const volatile Real* rvalue2;       // Reference to Z value
};
```

### 4.2 Variable Sensor Implementation

The variable sensors read values from system variables and publish them as measurements:

```cpp
// 1D variable sensor step implementation
void Varsensor1D::step() {
    // Check if variable is valid and within range/delta limits
    const bool is_valid = (rvalue && dcheck.check_var(*rvalue, false) && dcheck.get_nv());
    
    // If valid, write to measurement
    if(is_valid) {
        value.write(*rvalue);
    }
}

// 3D variable sensor step implementation
void Varsensor3D::step() {
    // Check if all three variables are valid
    bool is_valid = rvalue0 && rvalue1 && rvalue2;
    if (is_valid) {
        Base::Rv3 v = { *rvalue0, *rvalue1, *rvalue2 };
        Maverick::Irvector3 rv(v);
        
        // Check if within range/delta limits
        is_valid = (dcheck.check_var(rv, false) && dcheck.get_nv());
        
        // If valid, write to measurement
        if (is_valid) {
            value.write(v);
        }
    }
}
```

### 4.3 Variable Sensor Configuration

The variable sensors are configured with range and delta limits:

```cpp
// 1D variable sensor configuration
void Varsensor1D::config(const Base::Varsens1D_cfg::Rsens1d& vs0) {
    // Set range, delta, and count limits
    dcheck.set_max_count(vs0.value.max_count_nv);
    dcheck.set_range(vs0.value.min_value, vs0.value.max_value);
    dcheck.set_max_delta(vs0.value.max_delta);
    
    // Set reference to system variable if present
    rvalue = vs0.present ? &Bsp::Hrvar(vs0.value.rvar_id).get_kref() : 0;
}

// 3D variable sensor configuration
void Varsensor3D::config(const Base::Varsens3D_cfg::Rsens3d& vs0) {
    // Set range, delta, and count limits
    dcheck.set_max_count(vs0.value.max_count_nv);
    dcheck.set_range(vs0.value.min_value, vs0.value.max_value);
    dcheck.set_max_delta(vs0.value.max_delta);
    
    // Set references to system variables if present
    rvalue0 = vs0.present ? &Bsp::Hrvar(vs0.value.rvar_id0).get_kref() : 0;
    rvalue1 = vs0.present ? &Bsp::Hrvar(vs0.value.rvar_id1).get_kref() : 0;
    rvalue2 = vs0.present ? &Bsp::Hrvar(vs0.value.rvar_id2).get_kref() : 0;
}
```

## 5. Variable Suites

The Veronte architecture includes variable suites that manage collections of variable sensors.

### 5.1 Varsuite1D and Varsuite3D Classes

These classes manage collections of 1D and 3D variable sensors:

```cpp
// 1D variable sensor suite
class Varsuite1D {
public:
    static const Uint16 size = 4;  // Number of 1D sensors
    Varsuite1D(Base::Mblock<Base::Hmeas1> meas0);
    void step();
    void config(const Base::Varsens1D_cfg& cfg0);
    
private:
    Varsensor1D r0;  // First sensor
    Varsensor1D r1;  // Second sensor
};

// 3D variable sensor suite
class Varsuite3D {
public:
    static const Uint16 size = 2;  // Number of 3D sensors
    explicit Varsuite3D(Base::Mblock<Base::Hmeas3> meas0);
    void step();
    void config(const Base::Varsens3D_cfg& cfg0);
    
private:
    Varsensor3D r0;  // First sensor
    Varsensor3D r1;  // Second sensor
};
```

### 5.2 Variable Suite Implementation

The variable suites initialize their sensors and forward step and configuration calls:

```cpp
// 1D variable suite constructor
Varsuite1D::Varsuite1D(Base::Mblock<Base::Hmeas1> meas0) :
    r0(meas0[Base::Meas::rvar0]),
    r1(meas0[Base::Meas::rvar1])
{
    Base::Assertions::runtime(meas0.size()==Ku32::u4);
}

// 1D variable suite step
void Varsuite1D::step() {
    r0.step();
    r1.step();
}

// 1D variable suite configuration
void Varsuite1D::config(const Base::Varsens1D_cfg& cfg0) {
    r0.config(cfg0.r0);
    r1.config(cfg0.r1);
}
```

## 6. Variable Measurement System

The Veronte architecture includes a system for publishing system variables as measurements.

### 6.1 Hmeas Class

The `Hmeas` class provides access to the measurement object:

```cpp
struct Hmeas {
public:
    // Get a constant reference to the measurement object
    static const volatile Meas_obj& get_kmeas();
    
    // Get a mutable reference to the measurement object (CPU1 only)
    static Meas_obj& get_meas();
    
private:
    // Prevent instantiation
    Hmeas();
    Hmeas(const Hmeas& orig);
    ~Hmeas();
    Hmeas& operator=(const Hmeas& orig);
};
```

### 6.2 Implementation Details

The implementation of `Hmeas` differs between CPU cores:

#### Common Implementation (Both CPUs)
```cpp
// Used by both CPU1 and CPU2 for read-only access
const volatile Meas_obj& Hmeas::get_kmeas() {
    // Return the measurement object from CPU1's cross-core data
    return Xc::get_xcd_cpu1().measure;
}
```

#### CPU1-Specific Implementation
```cpp
// Only used by CPU1 for read-write access
Meas_obj& Hmeas::get_meas() {
    // Return the measurement object from CPU1's cross-core data
    return Xc::get_xcd_cpu1().measure;
}
```

### 6.3 Varmeas Class

The `Varmeas` class allows setting system variables and publishing them as measurements:

```cpp
class Varmeas : public Base::Vrefdst {
public:
    Varmeas(Base::Meas& meas0, Base::Iset& fw0);
    
    // Set a variable and potentially publish as measurement
    virtual void vset(const Base::Vref_wr& ref);
    
    // Set a feature
    virtual void vset(const Base::Fref& ref);
    
    // Set a real64 value (not supported)
    virtual void vset(const Iset::Data_r64& data);
    
    // Set a bitmap variable
    virtual void vset(const Base::Hbmapvar::Ref& ref);
    
    virtual bool vset(const Base::U8pkmblock_k& mb);
    
private:
    Base::Meas& meas;  // Measurement reference
    Base::Iset& fw;    // Forward reference for unsupported variables
};
```

The `vset` method for `Vref_wr` attempts to set a measurement value and falls back to forwarding:

```cpp
void Varmeas::vset(const Base::Vref_wr& ref) {
    // If this is a real variable
    if (ref.get().entry.type == Base::Vref::rvar) {
        // Try to set as measurement value
        if (!meas.set_meas_value(static_cast<Base::Rvar>(ref.get().entry.id), ref.get().value)) {
            // If not successful, forward to the next handler
            ref.vset(fw);
        }
    } else {
        // For non-real variables, forward to the next handler
        ref.vset(fw);
    }
}
```

## 7. GPS Variable Integration

The `VarGps` class demonstrates how system variables can be integrated with GPS functionality:

```cpp
class VarGps {
public:
    VarGps(Base::Hmeaspos& hpos, Base::Hmeasvel& hvel);
    void config(const Base::Vargpscfg& cfg0);
    void step();
    
private:
    Base::Hmeaspos& hpos;      // Position measurement
    Base::Hmeasvel& hvel;      // Velocity measurement
    
    // Configuration variables
    Real wts;                  // Period
    Base::Bvar vfix;           // Fix status variable
    Base::Rvar vtow;           // Time of week variable
    Base::Rvar vweek;          // Week number variable
    Geo::Fidposcache fpos;     // Position cache
    Base::Vref hpe;            // Horizontal position error
    Base::Vref vpe;            // Vertical position error
    Base::Rvar vn;             // North velocity variable
    Base::Rvar ve;             // East velocity variable
    Base::Rvar vd;             // Down velocity variable
    Base::Vref hve;            // Horizontal velocity error
    Base::Vref vve;            // Vertical velocity error
    bool pos_enabled;          // Position enabled flag
    bool vel_enabled;          // Velocity enabled flag
    
    // Work variables
    Base::Mposition pos;       // Position data
    Base::Mvel vel;            // Velocity data
    Real tow;                  // Time of week
    Real week;                 // Week number
    bool fix;                  // Fix status
    Base::Chrono clk;          // Clock for timing
    Real last_tow;             // Last time of week
};
```

The `VarGps::step()` method reads system variables and publishes them as position and velocity measurements:

```cpp
void VarGps::step() {
    if ((wts > 0.0F) && (pos_enabled || vel_enabled)) {
        Real elapsed = clk.toc();
        if (elapsed >= wts) {
            // Read time of week from system variable
            const Bsp::Hrvar htow(vtow);
            tow = htow.get();
            
            if (!Rfun::comp_real(last_tow, tow, Const::E1000000)) {
                last_tow = tow;
                clk.tic();
                
                // Read fix status from system variable
                const Bsp::Hbvar hfix(vfix);
                fix = hfix.get();
                
                // Fill position data if enabled
                if (pos_enabled) {
                    fpos.refresh();
                    pos.fix = fix;
                    pos.pos_llh = fpos.get_pos().get_llh();
                    
                    // Set position error from system variables
                    Real e2xy = hpe.kget();
                    e2xy *= e2xy;
                    Real e2z = vpe.kget();
                    e2z *= e2z;
                    pos.e2ned[Base::Coord::north] = e2xy;
                    pos.e2ned[Base::Coord::east] = e2xy;
                    pos.e2ned[Base::Coord::down] = e2z;
                    
                    // Publish position measurement
                    hpos.write(pos);
                }
                
                // Fill velocity data if enabled
                if (vel_enabled) {
                    // Read velocity components from system variables
                    const Bsp::Hrvar hrvn(vn);
                    const Bsp::Hrvar hrve(ve);
                    const Bsp::Hrvar hrvd(vd);
                    
                    vel.fix = fix;
                    vel.vn[Base::Coord::north] = hrvn.get();
                    vel.vn[Base::Coord::east] = hrve.get();
                    vel.vn[Base::Coord::down] = hrvd.get();
                    
                    // Set velocity error from system variables
                    Real ve2xy = hve.kget();
                    ve2xy *= ve2xy;
                    Real ve2z = vve.kget();
                    ve2z *= ve2z;
                    vel.e2ned[Base::Coord::north] = ve2xy;
                    vel.e2ned[Base::Coord::east] = ve2xy;
                    vel.e2ned[Base::Coord::down] = ve2z;
                    
                    // Publish velocity measurement
                    hvel.write(vel);
                }
                
                // Read week number from system variable
                const Bsp::Hrvar hweek(vweek);
                week = hweek.get();
                
                // Update system time
                Hsys::get_gnsstime().init(Base::Ubxtime::build(
                    static_cast<Uint16>(week),
                    static_cast<Uint32>(tow * Const::ONE_THOUSAND), 0));
            }
            else if (elapsed > (Const::FIVEHALVES * wts)) {
                fix = false;
            }
        }
    }
}
```

## 8. Sensor Selection System

The Veronte architecture includes a sensor selection system that determines which sensors are active.

### 8.1 Hsensel Class

The `Hsensel` class provides access to the active sensor selection data:

```cpp
struct Hsensel {
public:
    // Get a constant reference to the sensor selection data
    static const volatile Base::Sensel& get_ksensel();
    
    // Get a mutable reference to the sensor selection data (CPU2 only)
    static volatile Base::Sensel& get_sensel();
    
private:
    // Prevent instantiation
    Hsensel();
    Hsensel(const Hsensel& orig);
    Hsensel& operator=(const Hsensel& orig);
};
```

### 8.2 Implementation Details

The implementation of `Hsensel` differs between CPU cores:

#### Common Implementation (Both CPUs)
```cpp
// Used by both CPU1 and CPU2 for read-only access
const volatile Base::Sensel& Hsensel::get_ksensel() {
    // Return the sensor selection data from CPU2's cross-core data
    return Xc::get_xcd_cpu2().sensel;
}
```

#### CPU2-Specific Implementation
```cpp
// Only used by CPU2 for read-write access
volatile Base::Sensel& Hsensel::get_sensel() {
    // Return the sensor selection data from CPU2's cross-core data
    return Xc::get_xcd_cpu2().sensel;
}
```

## 9. Variable Calibration System

The Veronte architecture includes a calibration system for variables.

### 9.1 Xvarcal1D and Xvarcal3D Structures

These structures store calibration data for 1D and 3D variables:

```cpp
// 1D variable calibration
struct Xvarcal1D {
    Base::Xcal1D::Type_podsync u0;  // Calibration for unsigned variable 0
    Base::Xcal1D::Type_podsync u1;  // Calibration for unsigned variable 1
    Base::Xcal1D::Type_podsync r0;  // Calibration for real variable 0
    Base::Xcal1D::Type_podsync r1;  // Calibration for real variable 1
};

// 3D variable calibration
struct Xvarcal3D {
    Base::Xcal3D::Type_podsync u0;  // Calibration for unsigned variable 0
    Base::Xcal3D::Type_podsync u1;  // Calibration for unsigned variable 1
    Base::Xcal3D::Type_podsync r0;  // Calibration for real variable 0
    Base::Xcal3D::Type_podsync r1;  // Calibration for real variable 1
};
```

## 10. Cross-Core Variable Communication Flow

The variable management system in the Veronte architecture follows a specific flow for cross-core communication:

1. **Variable Definition**: Variables are defined in the `Regvars` structure, which is owned by CPU1.

2. **CPU1 Variable Updates**:
   - When CPU1 updates a variable using `Hrvar::set()`, `Huvar::set()`, or `Hbvar::set()`:
     - A message is sent to the cross-core message queue with the variable ID and new value
     - The message has a type like `xcmid_rvar_update` or `xcmid_bvar_update`

3. **CPU2 Message Processing**:
   - CPU2 processes messages from the cross-core message queue
   - When it receives a variable update message, it updates its local copy of the variable

4. **CPU2 Variable Access**:
   - CPU2 can directly read variables from its local memory using `Hrvar::get()`, `Huvar::get()`, or `Hbvar::get()`
   - CPU2 can also update its local copy of variables using `Hrvar::set()`, `Huvar::set()`, or `Hbvar::set()`

5. **Variable Copying**:
   - The `Ver::Copystep::step()` function is called periodically to copy variables from CPU1 to CPU2
   - This ensures that CPU2's local copy of variables stays in sync with CPU1

6. **Measurement Publication**:
   - Variables can be published as measurements using the `Varsensor1D` and `Varsensor3D` classes
   - These classes read variables from CPU2's local memory and publish them as measurements
   - Measurements are stored in the `Meas_obj` structure, which is owned by CPU1

## 11. Variable Validation and Error Handling

The variable management system includes validation and error handling mechanisms:

1. **ID Validation**:
   ```cpp
   Hrvar::Hrvar(Base::Rvar id0) : id(Base::validate(id0)) {
   }
   ```
   The constructor validates the variable ID to ensure it's within the valid range.

2. **Range and Delta Checking**:
   ```cpp
   bool is_valid = (rvalue && dcheck.check_var(*rvalue, false) && dcheck.get_nv());
   ```
   The `Varsensor1D` and `Varsensor3D` classes check that variables are within specified ranges and don't change too rapidly.

3. **Null Pointer Checking**:
   ```cpp
   bool is_valid = rvalue0 && rvalue1 && rvalue2;
   ```
   The variable sensor classes check that variable references are not null before accessing them.

4. **Block Range Validation**:
   ```cpp
   validate(from_inclusive, to_inclusive);
   ```
   The block access methods validate that the requested range is valid.

5. **Runtime Assertions**:
   ```cpp
   Base::Assertions::runtime(mb.size()==(1+to_inclusive-from));
   ```
   Runtime assertions are used to check that memory blocks have the expected size.

## 12. Cross-Component Relationships

```
+----------------+         +----------------+
|     CPU1       |         |     CPU2       |
+----------------+         +----------------+
| Regvars        |-------->| Local Copy     |
| - Real vars    |         | - Real vars    |
| - Unsigned vars|         | - Unsigned vars|
| - Boolean vars |         | - Boolean vars |
+----------------+         +----------------+
       |                           |
       v                           v
+----------------+         +----------------+
| Hregvars       |         | Variable       |
| - get_regvars()|         | Handlers       |
| - get_kregvars()|        | - Hrvar        |
+----------------+         | - Huvar        |
       |                   | - Hbvar        |
       |                   +----------------+
       v                           |
+----------------+                 |
| Cross-Core     |                 |
| Message Queue  |<----------------+
+----------------+
       |
       v
+----------------+         +----------------+
| Measurement    |<--------| Variable       |
| System         |         | Sensors        |
| - Hmeas        |         | - Varsensor1D  |
| - Meas_obj     |         | - Varsensor3D  |
+----------------+         +----------------+
                                   |
                                   v
                           +----------------+
                           | Variable       |
                           | Suites         |
                           | - Varsuite1D   |
                           | - Varsuite3D   |
                           +----------------+
```

## 13. Referenced Context Files

The following context files provided valuable information for understanding the variable management system:

1. `09_System_Architecture.md` - Provided overview of the Veronte system architecture, including cross-core communication mechanisms
2. `08_Multi_Core_Execution.md` - Provided details on the multi-core execution architecture and how variables are shared between cores