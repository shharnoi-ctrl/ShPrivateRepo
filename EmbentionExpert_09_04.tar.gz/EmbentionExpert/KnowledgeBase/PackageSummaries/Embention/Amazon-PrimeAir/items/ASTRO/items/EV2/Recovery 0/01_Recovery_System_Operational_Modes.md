# Generated from:

- Amazon-PrimeAir/items/ASTRO/items/EV2/Recovery 0/02_Core_Configuration_Files.md (4519 tokens)
- Amazon-PrimeAir/items/ASTRO/items/EV2/Recovery 0/02_Mission_And_Event_Management.md (2568 tokens)
- Amazon-PrimeAir/items/ASTRO/items/EV2/Recovery 0/02_Navigation_And_Positioning.md (5574 tokens)
- Amazon-PrimeAir/items/ASTRO/items/EV2/Recovery 0/02_Vehicle_Configuration.md (3982 tokens)

---

# Recovery System Operational Modes and Contingency Handling Analysis

This comprehensive analysis examines the recovery system's operational modes, state transitions, and contingency handling mechanisms, synthesizing information from core configuration files, mission management, navigation, and vehicle configuration.

## 1. Recovery System Operational Modes

### 1.1 Recovery Mode Phase Function (RMPF)

The Recovery Mode Phase Function defines the core operational phases of the recovery system:

#### Ground Phase
- **Detection Parameters**:
  - `altitude_agl_on_ground_vf_origin_m`: 0.48m (threshold for ground detection)
  - System considers itself on ground when altitude above ground level is below this threshold

#### Takeoff Phase
- **Transition Parameters**:
  - `pretakeoff_to_takeoff_agl_threshold_m`: 1.0m (altitude threshold)
  - `pretakeoff_to_takeoff_velocity_threshold_m_per_s`: 0.5m/s (vertical velocity threshold)
  - `pretakeoff_to_takeoff_acceleration_threshold_m_per_s2`: 2.6m/s² (acceleration threshold)
- **Transition Logic**: 
  - System transitions from pre-takeoff to takeoff when altitude exceeds 1.0m AND
  - Vertical velocity exceeds 0.5m/s AND
  - Vertical acceleration exceeds 2.6m/s²

#### Landing Phase
- **Transition Parameters**:
  - `land_threshold_vel_m_per_s`: 0.25m/s (velocity threshold)
  - `land_threshold_vel_cmd_m_per_s`: 0.75m/s (commanded velocity threshold)
  - `land_threshold_vel_cmd_timeout_s`: 2.0s (timeout period)
- **Transition Logic**:
  - System transitions to landing phase when vertical velocity falls below 0.25m/s OR
  - Commanded velocity remains below 0.75m/s for more than 2.0 seconds

### 1.2 Flight Phases

The system tracks flight phase through variable ID 1102 ("phase_of_flight"), which can have the following states:

1. **Ground/Pre-Takeoff**: Initial state before flight
2. **Takeoff**: Active vertical ascent
3. **Cruise**: Normal flight operations
4. **Approach**: Preparing for landing
5. **Landing**: Active descent to ground
6. **Post-Landing**: After touchdown, before systems shutdown

### 1.3 Mission States

The system tracks mission state through variable ID 1101 ("mission_state"), which can include:

1. **Idle**: System awaiting commands
2. **Preflight**: System performing pre-flight checks
3. **Active**: Mission in progress
4. **Recovery**: System in recovery mode
5. **Contingency**: System handling contingency situation

## 2. State Transition Mechanisms

### 2.1 Event-Driven Transitions

The recovery system implements an event-driven architecture for state transitions with four key event types:

| Event ID | Event Name | Trigger Mechanism |
|----------|------------|-------------------|
| 0 | ISC DComms cmd received | External command via DComms |
| 1 | Contingency command | Internal or external contingency detection |
| 2 | OK to deliver command | System readiness check |
| 3 | Contingency response | Response to contingency situation |

### 2.2 Command Processing Flow

State transitions follow this command processing flow:

1. **Command Reception**:
   - System receives command via DComms (event 0) or detects contingency (event 1)

2. **Command Validation**:
   - System checks if it's OK to deliver command (event 2)
   - Validates against current system state and safety parameters

3. **Command Execution**:
   - If valid, system executes appropriate action:
     - Sends ISC Cyphal messages (action 2) for normal commands
     - Sends contingency Cyphal messages (action 1) for contingency handling

4. **Response Generation**:
   - System generates appropriate response (event 3)
   - Sends response via configured channel (action 0)

### 2.3 Mode Blending Mechanisms

The system implements smooth transitions between operational modes using blending mechanisms:

1. **Attitude Contingency Mode Blending**:
   - `use_attitude_contingency_mode_blending`: 1 (enabled)
   - `attitude_contingency_mode_blending_total_time_s`: 2.0s
   - Provides smooth transition in attitude control during contingency activation

2. **Scheduler Contingency Mode Blending**:
   - `use_scheduler_contingency_mode_blending`: 1 (enabled)
   - `scheduler_contingency_mode_blending_total_time_s`: 2.0s
   - Ensures gradual transition in control scheduling during contingency activation

## 3. Contingency Detection and Handling

### 3.1 Contingency Detection Mechanisms

The system detects contingencies through multiple mechanisms:

#### Navigation-Based Detection
- **Position Accuracy Monitoring**:
  - `max_vert_pos_accuracy_m`: 25.0m (threshold)
  - `max_horiz_pos_accuracy_m`: 15.0m (threshold)
  - Triggers contingency when position accuracy exceeds thresholds

- **Tracking Error Monitoring**:
  - `max_attitude_tracking_error_rad`: 3.1415 rad
  - `max_horizontal_tracking_error_m`: 9999.0m
  - `max_vertical_tracking_error_m`: 99.0m
  - `max_vtol_horizontal_tracking_error_m`: 10.0m
  - `max_vtol_vertical_tracking_error_m`: 5.0m
  - Triggers contingency when tracking errors exceed thresholds

#### Environmental Detection
- **Wind Monitoring**:
  - `wind_gust_threshold_m_per_s`: 12.8m/s
  - `wind_gust_counter_threshold`: 3
  - `enable_wind_threshold_monitor_to_command_skip_delivery`: 1 (enabled)
  - Triggers contingency when wind gusts exceed 12.8m/s for 3 consecutive measurements

#### System Health Monitoring
- **Built-In Tests**:
  - MBIT tests for critical systems (GPS, IMU, LIDAR, state estimation)
  - Tests include:
    - ID 1225: Switchover
    - ID 1318: GPS Outdoor
    - ID 1320: Enable State Estimate
    - ID 1301: IMU self test
    - ID 1110: LIDAR Ok
  - Failures trigger appropriate contingency responses

### 3.2 Contingency Response Mechanisms

The system implements several contingency response mechanisms:

#### Switchover Control
- `is_switchover_enabled`: 1 (enabled)
- Allows system to switch to backup components or systems when primary systems fail

#### Bounding Box Protection
- `enable_bounding_box_protection`: 1 (enabled)
- `bounding_box_half_length_m`: 5.0m
- `bounding_box_half_width_m`: 5.0m
- `bounding_box_half_height_m`: 10.0m
- Prevents vehicle from exceeding defined spatial boundaries

#### Weathervaning
- `is_weathervaning_enabled`: 1 (enabled)
- `tas_awv_min_engaged_m_per_s`: 2.0m/s
- `tas_awv_max_rate_m_per_s`: 3.0m/s
- `yaw_rate_max_awv_rad_per_s`: 0.7854rad/s (~45°/s)
- Automatically orients vehicle into the wind during contingencies

### 3.3 Contingency Command Handling

The system processes contingency commands through a dedicated event-action mapping:

1. **Contingency Detection**:
   - System detects contingency condition (event 1)

2. **Command Validation**:
   - System checks if it's OK to deliver contingency command (event 2, param 1)

3. **Command Execution**:
   - System sends contingency Cyphal message (action 1)
   - Message type: 57485, address: 24

4. **Response Generation**:
   - System generates contingency response (event 3)
   - System sends appropriate response (action 0)

### 3.4 Enacted Contingency Tracking

The system tracks enacted contingencies through variable ID 1100 ("enacted_contingency"), which can include:

1. **No Contingency**: Normal operation
2. **GPS Loss**: Loss of GPS signal
3. **IMU Failure**: Inertial measurement unit failure
4. **Control Loss**: Loss of control authority
5. **Battery Critical**: Critical battery level
6. **Geofence Breach**: Vehicle exceeds geofence boundaries
7. **Wind Limit**: Wind exceeds operational limits

## 4. Recovery System Status Monitoring

### 4.1 System Status Variables

The system monitors status through multiple variables:

- **ID 1108**: "status_code" - Overall system status code
- **ID 1109**: "flags_status_idle" - Status flags during idle state
- **ID 1113**: "flags_status_isc" - Inter-System Communication status flags
- **ID 1101**: "mission_state" - Current mission state
- **ID 1102**: "phase_of_flight" - Current flight phase
- **ID 1103**: "battery_pack_state" - Battery status

### 4.2 Telemetry Reporting

The system reports status through telemetry packets:

1. **System Status Packet**:
   - Contains 32 fields including lights status and navigation metrics
   - Transmission period: 0.1 seconds
   - Addressed to UAV ID 2

2. **Navigation Packet**:
   - Contains 33 fields including navigation data and system status flags
   - Transmission period: 0.05 seconds (higher frequency)
   - Addressed to UAV ID 2

3. **Telemetry Completion Packet**:
   - Contains 50 fields with additional system parameters
   - Transmission period: 0.1 seconds
   - Addressed to UAV ID 2

### 4.3 Status Reporting Configuration

- **vcp_tx_enabled**: 1 (Enabled) - Enables transmission of status data via VCP
- **period**: 1.0 - Status reporting frequency of 1 Hz (once per second)

## 5. Motor and Propulsion Control

### 5.1 Motor Configuration

- **num_motors**: 6 - The vehicle uses a six-motor configuration
- Motor RPMs are monitored through variables:
  - ID 3100: "RPM 1"
  - ID 3101: "RPM 2"
  - ID 3102: "RPM 3"
  - ID 3103: "RPM 4"
  - ID 3104: "RPM 5"
  - ID 3105: "RPM 6"

### 5.2 Motor Control Parameters

- **dt_to_arm_motors_after_mrs_s**: 5.0 seconds - Delay before arming motors
- **dt_to_disarm_after_in_air_motors_disabled_low_rpm_s**: 0.0 seconds - Immediate disarm when motors disabled in air

### 5.3 Motor Control Variables

- **ID 1000**: "Enable (Propeller)" - Motor enable command
- **ID 1001**: "Disable mode (Propeller)" - Motor disable command
- **ID 1002**: "Arm (Propeller)" - Motor arm command
- **ID 1003**: "Source (Propeller)" - Motor control source selection

## 6. Lighting System for Visual Indication

### 6.1 Light States

The lighting system defines 13 different light states for both left and right sides, each with 20 phase values and 20 width values. These states include:

1. **Standard Pattern** (states 0, 1): Regular operation
2. **Alert Pattern** (states 2, 3): Warning or caution
3. **Emergency Pattern** (states 5, 6): Critical situations
4. **Landing Pattern** (states 8, 9): Approach and landing
5. **Special Patterns** (states 10, 11): Specific operations

### 6.2 Light Sequences

The system defines 10 different light sequences, each containing 10 steps. Each step references a light state for left and right sides, creating visual patterns that indicate the vehicle's operational mode or status.

### 6.3 Light Status Monitoring

- **ID 1019**: "Lights Status" - Tracks the current state of the lighting system

## 7. Navigation and Positioning in Recovery Operations

### 7.1 Navigation System Architecture

The recovery system's navigation architecture integrates:

1. **Core Navigation Engine**: Central processing unit for navigation data
2. **GNSS Integration**: Multiple GNSS receivers with configurable presets
3. **Kalman Filter**: Optimal sensor fusion with configurable parameters
4. **Attitude Determination**: Complementary filtering for orientation estimation
5. **Georeferencing**: Automatic georeferencing and magnetic field determination

### 7.2 Navigation Modes and Fallbacks

The system supports different navigation modes with fallback mechanisms:

1. **GNSS-Based Navigation**: Primary mode when GNSS signals are available
   - Requires 5.0 seconds of consistent GPS data before considering it valid
   - Position error thresholds: 2.0m horizontal, 5.0m vertical
   - Velocity error thresholds: 1.0m/s for both horizontal and vertical

2. **Dead Reckoning**: Used when GNSS signals are unavailable
   - Time constant: 10.0
   - Relies on IMU data integrated over time

3. **External Reference**: Can use external attitude reference when available
   - External AHRS is enabled (disabled_mode = 0)

### 7.3 Navigation Data Flow

The navigation data flow follows this sequence:

1. **Sensor Data Acquisition**:
   - GNSS receivers provide position, velocity, and time
   - IMUs provide acceleration and angular rates
   - Magnetometers provide magnetic field measurements

2. **Data Validation and Preprocessing**:
   - GNSS data validated against error thresholds
   - IMU data processed using configured filter parameters
   - Magnetometer data processed with automatic field determination

3. **Attitude Determination**:
   - Angular rates processed using Delta PQR configuration
   - Complementary filter combines gyroscope and accelerometer/magnetometer data
   - Filter parameters control balance between different measurements

4. **Position and Velocity Estimation**:
   - Kalman filter combines GNSS and IMU data
   - Dead reckoning used when GNSS unavailable
   - Position and velocity estimates validated against thresholds

## 8. Integrated Recovery System Operation

### 8.1 Normal Operation Sequence

1. **Initialization**:
   - System initializes with variables set according to `ver_spdif_varini.xml`
   - State estimation enabled (ID 1320 = 1.0)
   - GPS outdoor mode enabled (ID 1318 = 1.0)
   - IMU self-test performed (ID 1301 = 0.0 indicates pass)

2. **Pre-Takeoff**:
   - System in ground phase (altitude < 0.48m)
   - Motors armed after 5.0 seconds (dt_to_arm_motors_after_mrs_s)
   - Standard light pattern activated

3. **Takeoff**:
   - Transition occurs when:
     - Altitude > 1.0m
     - Vertical velocity > 0.5m/s
     - Vertical acceleration > 2.6m/s²
   - Takeoff light pattern activated

4. **Cruise**:
   - Normal flight operations
   - Weathervaning active when airspeed > 2.0m/s
   - Bounding box protection active

5. **Landing**:
   - Transition occurs when:
     - Vertical velocity < 0.25m/s OR
     - Commanded velocity < 0.75m/s for > 2.0 seconds
   - Landing light pattern activated

6. **Post-Landing**:
   - System returns to ground phase when altitude < 0.48m
   - Motors disarmed immediately (dt_to_disarm_after_in_air_motors_disabled_low_rpm_s = 0.0)

### 8.2 Contingency Operation Sequence

1. **Contingency Detection**:
   - System detects contingency through:
     - Navigation errors exceeding thresholds
     - Wind gusts exceeding 12.8m/s for 3 consecutive measurements
     - Built-in test failures
     - Geofence breaches

2. **Contingency Activation**:
   - System generates contingency event (event ID 1)
   - System validates command delivery (event ID 2, param 1)
   - System sends contingency Cyphal message (action ID 1)
   - Emergency light pattern activated

3. **Mode Transition**:
   - Attitude contingency mode blending activates (2.0s transition)
   - Scheduler contingency mode blending activates (2.0s transition)
   - System transitions to appropriate recovery behavior

4. **Recovery Behavior**:
   - Weathervaning orients vehicle into wind
   - Bounding box protection prevents further excursions
   - System attempts to stabilize or return to safe state

5. **Response Generation**:
   - System generates contingency response (event ID 3)
   - System sends response via configured channel (action ID 0)

### 8.3 Key State Transition Parameters

| Transition | Parameter | Value | Description |
|------------|-----------|-------|-------------|
| Ground → Takeoff | altitude_threshold | 1.0m | Minimum altitude to consider takeoff |
| Ground → Takeoff | velocity_threshold | 0.5m/s | Minimum vertical velocity for takeoff |
| Ground → Takeoff | acceleration_threshold | 2.6m/s² | Minimum vertical acceleration for takeoff |
| Flight → Landing | velocity_threshold | 0.25m/s | Maximum vertical velocity to consider landing |
| Flight → Landing | command_velocity_threshold | 0.75m/s | Maximum commanded velocity for landing |
| Flight → Landing | command_timeout | 2.0s | Time threshold for landing detection |
| Landing → Ground | ground_threshold | 0.48m | Maximum altitude to consider on ground |
| Normal → Contingency | mode_blending_time | 2.0s | Transition time between normal and contingency modes |

## 9. System Integration and Relationships

The recovery system integrates multiple subsystems that work together to ensure safe operation:

### 9.1 Event-Action Framework and Navigation

- Navigation system provides position, velocity, and attitude data
- Event system monitors navigation parameters against thresholds
- When thresholds are exceeded, contingency events are triggered
- Actions respond to events by adjusting control parameters

### 9.2 Lighting System and Operational Modes

- Each operational mode has associated light patterns
- Light patterns provide visual indication of system status
- Emergency patterns activate during contingency operations
- Landing patterns activate during approach and landing phases

### 9.3 Motor Control and Flight Phases

- Motors arm 5.0 seconds after system initialization
- Motor RPMs are continuously monitored (IDs 3100-3105)
- Motor control adapts based on flight phase
- Motors disarm immediately upon landing

### 9.4 Built-In Testing and Contingency Handling

- MBIT tests verify critical system functionality
- Test failures trigger appropriate contingency responses
- Contingency responses include mode transitions and visual indicators
- System status is continuously reported via telemetry

## 10. Key Parameters Governing System Behavior

### 10.1 Critical Thresholds

- **Ground Detection**: 0.48m altitude AGL
- **Takeoff Detection**: 1.0m altitude, 0.5m/s velocity, 2.6m/s² acceleration
- **Landing Detection**: 0.25m/s velocity or 0.75m/s commanded velocity for 2.0s
- **Wind Limits**: 12.8m/s gust threshold, 3 consecutive measurements
- **Position Accuracy**: 15.0m horizontal, 25.0m vertical
- **Tracking Errors**: 10.0m horizontal, 5.0m vertical in VTOL mode

### 10.2 Timing Parameters

- **Motor Arming**: 5.0 seconds after initialization
- **Motor Disarming**: 0.0 seconds (immediate) after landing
- **GPS Validation**: 5.0 seconds of consistent data
- **Mode Blending**: 2.0 seconds transition time
- **Landing Detection**: 2.0 seconds timeout for commanded velocity

### 10.3 Control Parameters

- **Attitude Filter**: Beta=0.025, Zeta=0.003 (normal operation)
- **Initial Attitude Filter**: Beta0=10.0, Zeta0=0.0 (initialization)
- **Weathervaning**: Minimum speed 2.0m/s, maximum rate 3.0m/s
- **Yaw Rate Limit**: 0.7854rad/s (~45°/s) during weathervaning

## 11. Conclusion: Recovery System Operational Architecture

The recovery system implements a sophisticated operational architecture with multiple modes, state transitions, and contingency handling mechanisms. The system is designed to:

1. **Detect Operational Phase**: Using altitude, velocity, and acceleration thresholds
2. **Monitor System Health**: Through built-in tests and sensor validation
3. **Respond to Contingencies**: With appropriate mode transitions and actions
4. **Provide Visual Indication**: Through configurable light patterns
5. **Maintain Safe Operation**: With bounding box protection and weathervaning
6. **Report System Status**: Through comprehensive telemetry

This architecture ensures that the recovery system can operate safely in various conditions, detect and respond to contingencies, and provide clear indication of its operational state to operators and observers.

The integration of navigation, motor control, lighting, and event-action frameworks creates a robust system capable of autonomous operation with appropriate fallback mechanisms when primary systems fail or environmental conditions exceed operational limits.