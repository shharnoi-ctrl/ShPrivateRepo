# Generated from:

- items/pdi_Monitor/setup/ver_spdif_gyr1filt.xml (172 tokens)
- items/pdi_Monitor/setup/ver_spdif_mag2filt.xml (105 tokens)
- items/pdi_Monitor/setup/ver_spdif_gyr0filt.xml (172 tokens)
- items/pdi_Monitor/setup/ver_spdif_maglps.xml (684 tokens)
- items/pdi_Monitor/setup/ver_spdif_mag3filt.xml (105 tokens)
- items/pdi_Monitor/setup/ver_spdif_varqinf.xml (198 tokens)
- items/pdi_Monitor/setup/ver_spdif_imupos.xml (78 tokens)
- items/pdi_Monitor/setup/ver_spdif_imu1.xml (241 tokens)
- items/pdi_Monitor/setup/ver_spdif_gyr2filt.xml (172 tokens)
- items/pdi_Monitor/setup/ver_spdif_mchannel.xml (61 tokens)
- items/pdi_Monitor/setup/ver_spdif_gyrlps.xml (334 tokens)
- items/pdi_Monitor/setup/ver_spdif_imu0.xml (241 tokens)
- items/pdi_Monitor/setup/ver_spdif_gyrsuite.xml (325 tokens)
- items/pdi_Monitor/setup/ver_spdif_imu2.xml (137 tokens)
- items/pdi_Monitor/setup/ver_spdif_grav_ext_ahrs.xml (76 tokens)
- items/pdi_Monitor/setup/ver_spdif_imu3.xml (129 tokens)
- items/pdi_Monitor/setup/ver_spdif_vargyr.xml (237 tokens)
- items/pdi_Monitor/setup/ver_spdif_acclps.xml (334 tokens)
- items/pdi_Monitor/setup/ver_spdif_extacc1.xml (136 tokens)
- items/pdi_Monitor/setup/ver_spdif_gyr3filt.xml (172 tokens)
- items/pdi_Monitor/setup/ver_spdif_magResfilt.xml (106 tokens)
- items/pdi_Monitor/setup/ver_spdif_extacc0.xml (136 tokens)
- items/pdi_Monitor/setup/ver_spdif_mag0filt.xml (105 tokens)
- items/pdi_Monitor/setup/ver_spdif_dpqr.xml (81 tokens)
- items/pdi_Monitor/setup/ver_spdif_imugeom.xml (122 tokens)
- items/pdi_Monitor/setup/ver_spdif_stp2filt.xml (104 tokens)
- items/pdi_Monitor/setup/ver_spdif_mag5filt.xml (105 tokens)
- items/pdi_Monitor/setup/ver_spdif_acc0filt.xml (172 tokens)
- items/pdi_Monitor/setup/ver_spdif_extnavsen.xml (92 tokens)
- items/pdi_Monitor/setup/ver_spdif_stp0filt.xml (103 tokens)
- items/pdi_Monitor/setup/ver_spdif_extgyr0.xml (136 tokens)
- items/pdi_Monitor/setup/ver_spdif_extgyr1.xml (136 tokens)
- items/pdi_Monitor/setup/ver_spdif_extmag1.xml (136 tokens)
- items/pdi_Monitor/setup/ver_spdif_acc2filt.xml (172 tokens)
- items/pdi_Monitor/setup/ver_spdif_mag6filt.xml (105 tokens)
- items/pdi_Monitor/setup/ver_spdif_mag7filt.xml (107 tokens)
- items/pdi_Monitor/setup/ver_spdif_stp1filt.xml (103 tokens)
- items/pdi_Monitor/setup/ver_spdif_varstp.xml (198 tokens)
- items/pdi_Monitor/setup/ver_spdif_acc1filt.xml (172 tokens)
- items/pdi_Monitor/setup/ver_spdif_att.xml (105 tokens)
- items/pdi_Monitor/setup/ver_spdif_accsuite.xml (325 tokens)
- items/pdi_Monitor/setup/ver_spdif_extmag0.xml (136 tokens)
- items/pdi_Monitor/setup/ver_spdif_mag4filt.xml (105 tokens)
- items/pdi_Monitor/setup/ver_spdif_extobs.xml (82 tokens)
- items/pdi_Monitor/setup/ver_spdif_varmag.xml (237 tokens)
- items/pdi_Monitor/setup/ver_spdif_varacc.xml (237 tokens)
- items/pdi_Monitor/setup/ver_spdif_qinffilt.xml (103 tokens)

## With context from:

- Amazon-PrimeAir/items/ASTRO/items/Monitor/07_System_Architecture.md (3174 tokens)
- Amazon-PrimeAir/items/ASTRO/items/Monitor/06_Communication_Interfaces.md (7524 tokens)

---

# PDI Monitor Sensor Processing System Analysis

## 1. Sensor Configuration Overview

The PDI Monitor system incorporates a comprehensive sensor processing architecture with multiple IMUs, gyroscopes, accelerometers, and magnetometers. This analysis details the configuration, filtering, and data flow of these sensors within the system.

### 1.1 Sensor Types and Hierarchy

The system utilizes multiple sensor types organized in a hierarchical structure:

1. **IMUs (Inertial Measurement Units)**
   - 4 distinct IMU configurations (IMU0, IMU1, IMU2, IMU3)
   - Each IMU contains both accelerometer and gyroscope components
   - IMUs appear to be the primary motion sensing devices

2. **Gyroscopes**
   - Multiple gyroscope channels (at least 4 distinct configurations)
   - Organized into a "gyroscope suite" for sensor fusion

3. **Accelerometers**
   - Multiple accelerometer channels (at least 3 distinct configurations)
   - Organized into an "accelerometer suite" for sensor fusion

4. **Magnetometers**
   - At least 8 magnetometer configurations (MAG0-MAG7)
   - Includes a specialized RM3100 magnetometer (MAG7)
   - Additional "magRes" magnetometer (likely a high-resolution or specialized unit)

5. **External Sensors**
   - External accelerometers (EXTACC0, EXTACC1)
   - External gyroscopes (EXTGYR0, EXTGYR1)
   - External magnetometers (EXTMAG0, EXTMAG1)
   - External navigation sensors (EXTNAVSEN)

## 2. IMU Configuration Details

### 2.1 IMU0 Configuration (ID: 102)

```xml
<entry-imu0>
    <id>102</id>
    <filename>imu0.bin</filename>
    <data>
        <accelRange>4</accelRange>
        <accelSampleRate>160</accelSampleRate>
        <accelbw>0</accelbw>
        <enOutDr>1</enOutDr>
        <linear_lpf2>0</linear_lpf2>
        <accel_dso_lpf2_en>0</accel_dso_lpf2_en>
        <accel_dso_lpf2_fc>0</accel_dso_lpf2_fc>
        <gyroRange>12</gyroRange>
        <gyroSampleRate>128</gyroSampleRate>
        <gyroHpfEn>0</gyroHpfEn>
        <gyroHpf>0</gyroHpf>
        <gyro_dso_lpf1_en>0</gyro_dso_lpf1_en>
        <gyro_dso_lpf1_fc>0</gyro_dso_lpf1_fc>
        <temp_enabled>1</temp_enabled>
        <accel_max_nv_samples>10</accel_max_nv_samples>
        <gyro_max_nv_samples>10</gyro_max_nv_samples>
        <acc_max_delta>313.8128</acc_max_delta>
        <gyr_max_delta>69.81317</gyr_max_delta>
    </data>
</entry-imu0>
```

Key parameters:
- **Accelerometer**: 
  - Range: ±4g
  - Sample rate: 160 Hz
  - Maximum delta: 313.8128 (likely m/s²)
  - Non-valid sample threshold: 10 samples
  
- **Gyroscope**:
  - Range: ±12 degrees/second
  - Sample rate: 128 Hz
  - Maximum delta: 69.81317 (likely degrees/second)
  - Non-valid sample threshold: 10 samples
  
- **Additional features**:
  - Temperature sensing enabled
  - Data ready output enabled
  - High-pass filtering disabled
  - Digital signal output low-pass filtering disabled

### 2.2 IMU1 Configuration (ID: 103)

IMU1 has identical configuration to IMU0, suggesting redundancy or a dual-IMU setup for reliability.

### 2.3 IMU2 Configuration (ID: 256)

```xml
<entry-imu2>
    <id>256</id>
    <filename>imu2.bin</filename>
    <data>
        <accRange>2</accRange>
        <accODR>12</accODR>
        <accBWP>160</accBWP>
        <accMaxNvSamples>30</accMaxNvSamples>
        <gyrRange>0</gyrRange>
        <gyrOdrBw>2</gyrOdrBw>
        <gyrMaxNvSamples>30</gyrMaxNvSamples>
        <acc_max_delta>235.3596</acc_max_delta>
        <gyr_max_delta>69.81317</gyr_max_delta>
    </data>
</entry-imu2>
```

Key parameters:
- **Accelerometer**: 
  - Range: ±2g (more sensitive than IMU0/1)
  - Output data rate: 12 (likely a code for a specific frequency)
  - Bandwidth: 160 Hz
  - Maximum delta: 235.3596 (likely m/s²)
  - Non-valid sample threshold: 30 samples (higher than IMU0/1)
  
- **Gyroscope**:
  - Range: 0 (likely a code for a default range)
  - Output data rate/bandwidth: 2 (likely a code for a specific setting)
  - Maximum delta: 69.81317 (same as IMU0/1)
  - Non-valid sample threshold: 30 samples (higher than IMU0/1)

### 2.4 IMU3 Configuration (ID: 360)

```xml
<entry-imu3>
    <id>360</id>
    <filename>imu3.bin</filename>
    <data>
        <accMaxNvSamples>10</accMaxNvSamples>
        <gyrMaxNvSamples>10</gyrMaxNvSamples>
        <mode_32bit>0</mode_32bit>
        <filter_stages>4</filter_stages>
        <bandwidth_370hz>0</bandwidth_370hz>
        <acc_max_delta>156.8</acc_max_delta>
        <gyr_max_delta>69.81317</gyr_max_delta>
    </data>
</entry-imu3>
```

Key parameters:
- **Accelerometer**: 
  - Maximum delta: 156.8 (likely m/s²) - more restrictive than other IMUs
  - Non-valid sample threshold: 10 samples
  
- **Gyroscope**:
  - Maximum delta: 69.81317 (same as other IMUs)
  - Non-valid sample threshold: 10 samples
  
- **Additional features**:
  - 32-bit mode disabled
  - 4 filter stages
  - 370Hz bandwidth disabled

### 2.5 IMU Geometry and Position

```xml
<entry-imugeom>
    <id>52</id>
    <filename>imugeom.bin</filename>
    <data>
        <Lbp>
            <a00>1.0</a00>
            <a10>0.0</a10>
            <a20>0.0</a20>
            <a01>0.0</a01>
            <a11>1.0</a11>
            <a21>0.0</a21>
            <a02>0.0</a02>
            <a12>0.0</a12>
            <a22>1.0</a22>
        </Lbp>
    </data>
</entry-imugeom>
```

```xml
<entry-imupos>
    <id>53</id>
    <filename>imupos.bin</filename>
    <data>
        <GIb>
            <x>0.0</x>
            <y>0.0</y>
            <z>0.0</z>
        </GIb>
    </data>
</entry-imupos>
```

These files define:
- **IMU Geometry**: A 3x3 rotation matrix (`Lbp`) that defines the orientation of the IMU relative to the body frame. Currently set to identity matrix (no rotation).
- **IMU Position**: The position vector (`GIb`) of the IMU relative to the body frame. Currently set to origin (0,0,0).

## 3. Sensor Filtering Architecture

### 3.1 Gyroscope Filtering

Each gyroscope has a dedicated filter configuration:

#### 3.1.1 GYR0FILT (ID: 98)

```xml
<entry-gyr0filt>
    <id>98</id>
    <filename>gyr0filt.bin</filename>
    <data>
        <notch>
            <num-harmonics>0</num-harmonics>
            <center-freq>
                <vref-kval>
                    <type>65534</type>
                    <kval>100.0</kval>
                </vref-kval>
            </center-freq>
            <bandwidth>20.0</bandwidth>
            <notch-gain>0.5</notch-gain>
        </notch>
        <butterworth>
            <enable>0</enable>
            <cutoff_freq>1.0</cutoff_freq>
        </butterworth>
    </data>
</entry-gyr0filt>
```

Key filter parameters:
- **Notch Filter**:
  - Harmonics: 0 (no harmonics)
  - Center frequency: 100.0 Hz
  - Bandwidth: 20.0 Hz
  - Gain: 0.5
  
- **Butterworth Filter**:
  - Disabled (enable = 0)
  - Cutoff frequency: 1.0 Hz (would be used if enabled)

GYR1FILT, GYR2FILT, and GYR3FILT have identical configurations, suggesting a consistent filtering approach across all gyroscopes.

### 3.2 Accelerometer Filtering

Each accelerometer has a dedicated filter configuration:

#### 3.2.1 ACC0FILT (ID: 97)

```xml
<entry-acc0filt>
    <id>97</id>
    <filename>acc0filt.bin</filename>
    <data>
        <notch>
            <num-harmonics>0</num-harmonics>
            <center-freq>
                <vref-kval>
                    <type>65534</type>
                    <kval>100.0</kval>
                </vref-kval>
            </center-freq>
            <bandwidth>20.0</bandwidth>
            <notch-gain>0.5</notch-gain>
        </notch>
        <butterworth>
            <enable>0</enable>
            <cutoff_freq>1.0</cutoff_freq>
        </butterworth>
    </data>
</entry-acc0filt>
```

The accelerometer filters have identical configuration to the gyroscope filters, with:
- Notch filter centered at 100 Hz with 20 Hz bandwidth
- Disabled Butterworth filter with 1.0 Hz cutoff frequency

ACC1FILT and ACC2FILT have identical configurations.

### 3.3 Magnetometer Filtering

Each magnetometer has a dedicated IIR filter configuration:

#### 3.3.1 MAG0FILT (ID: 99)

```xml
<entry-mag0filt>
    <id>99</id>
    <filename>mag0filt.bin</filename>
    <data>
        <iir_cfg>
            <enable>0</enable>
            <cutoff_freq>1.0</cutoff_freq>
        </iir_cfg>
        <max_nv_samples>0</max_nv_samples>
        <max_delta>3.4028235E38</max_delta>
    </data>
</entry-mag0filt>
```

Key filter parameters:
- **IIR Filter**:
  - Disabled (enable = 0)
  - Cutoff frequency: 1.0 Hz (would be used if enabled)
  
- **Validation Parameters**:
  - Non-valid sample threshold: 0 (disabled)
  - Maximum delta: 3.4028235E38 (effectively unlimited)

MAG1FILT through MAG7FILT have identical configurations, as does MAGRESFILT.

### 3.4 External Sensor Filtering

External sensors also have dedicated filter configurations:

#### 3.4.1 EXTACC0 (ID: 156)

```xml
<entry-extacc0>
    <id>156</id>
    <filename>extacc0.bin</filename>
    <data>
        <desired_freq>0.0</desired_freq>
        <flt_cfg>
            <enable>0</enable>
            <cutoff_freq>1.0</cutoff_freq>
        </flt_cfg>
        <min_value>-3.4028235E38</min_value>
        <max_value>3.4028235E38</max_value>
        <max_delta>3.4028235E38</max_delta>
        <max_count_nv>10</max_count_nv>
    </data>
</entry-extacc0>
```

Key parameters:
- **Desired Frequency**: 0.0 Hz (likely disabled)
- **Filter Configuration**:
  - Disabled (enable = 0)
  - Cutoff frequency: 1.0 Hz
  
- **Validation Parameters**:
  - Min/Max values: Effectively unlimited
  - Maximum delta: Effectively unlimited
  - Non-valid sample threshold: 10 samples

EXTACC1, EXTGYR0, EXTGYR1, EXTMAG0, and EXTMAG1 have identical configurations.

## 4. Sensor Fusion and Attitude Estimation

### 4.1 Sensor Suites for Fusion

The system organizes sensors into "suites" for sensor fusion:

#### 4.1.1 Accelerometer Suite (ID: 2)

```xml
<entry-accsuite>
    <id>2</id>
    <filename>accsuite.bin</filename>
    <data>
        <sel>
            <use>1</use>
            <def-sen>0</def-sen>
        </sel>
        <tau_v>2.0</tau_v>
        <tau_s2>20.0</tau_s2>
        <variances>
            <s0>
                <ini_s2>1.0</ini_s2>
                <min_s2>1.0E-4</min_s2>
            </s0>
            <!-- s1 through s7 with identical values -->
        </variances>
    </data>
</entry-accsuite>
```

Key parameters:
- **Selection**:
  - Use: 1 (enabled)
  - Default sensor: 0 (first accelerometer)
  
- **Time Constants**:
  - tau_v: 2.0 seconds (likely velocity time constant)
  - tau_s2: 20.0 seconds (likely variance time constant)
  
- **Sensor Variances**:
  - Initial variance (ini_s2): 1.0 for all sensors
  - Minimum variance (min_s2): 0.0001 for all sensors

#### 4.1.2 Gyroscope Suite (ID: 3)

```xml
<entry-gyrsuite>
    <id>3</id>
    <filename>gyrsuite.bin</filename>
    <data>
        <sel>
            <use>1</use>
            <def-sen>0</def-sen>
        </sel>
        <tau_v>2.0</tau_v>
        <tau_s2>20.0</tau_s2>
        <variances>
            <s0>
                <ini_s2>1.0</ini_s2>
                <min_s2>1.0E-4</min_s2>
            </s0>
            <!-- s1 through s7 with identical values -->
        </variances>
    </data>
</entry-gyrsuite>
```

The gyroscope suite has identical configuration to the accelerometer suite.

### 4.2 Linear Parameter Scaling (LPS) for Sensors

The system applies linear parameter scaling to sensor outputs:

#### 4.2.1 Accelerometer LPS (ID: 274)

```xml
<entry-acclps>
    <id>274</id>
    <filename>acclps.bin</filename>
    <data>
        <sensor0>
            <a00>1.0</a00>
            <a10>0.0</a10>
            <a20>0.0</a20>
            <a01>0.0</a01>
            <a11>1.0</a11>
            <a21>0.0</a21>
            <a02>0.0</a02>
            <a12>0.0</a12>
            <a22>1.0</a22>
        </sensor0>
        <!-- sensor1 through sensor3 with identical values -->
    </data>
</entry-acclps>
```

Each sensor has a 3x3 matrix that can be used for:
- Scale factor correction
- Cross-axis sensitivity correction
- Axis alignment

Currently, all matrices are identity matrices (no correction applied).

#### 4.2.2 Gyroscope LPS (ID: 275)

```xml
<entry-gyrlps>
    <id>275</id>
    <filename>gyrlps.bin</filename>
    <data>
        <sensor0>
            <a00>1.0</a00>
            <!-- Identity matrix elements -->
        </sensor0>
        <!-- sensor1 through sensor3 with identical values -->
    </data>
</entry-gyrlps>
```

#### 4.2.3 Magnetometer LPS (ID: 276)

```xml
<entry-maglps>
    <id>276</id>
    <filename>maglps.bin</filename>
    <data>
        <sensor0>
            <a00>1.0</a00>
            <!-- Identity matrix elements -->
        </sensor0>
        <!-- sensor1 through sensor8 with identical values -->
    </data>
</entry-maglps>
```

The magnetometer LPS includes 9 sensors (sensor0 through sensor8), all with identity matrices.

### 4.3 Attitude Estimation Configuration

```xml
<entry-attitude>
    <id>45</id>
    <filename>att.bin</filename>
    <data>
        <beta>0.025</beta>
        <zeta>0.003</zeta>
        <beta0>10.0</beta0>
        <zeta0>0.0</zeta0>
        <filt-steps>50</filt-steps>
        <kfg>2.0</kfg>
        <norm-filt>0.1</norm-filt>
    </data>
</entry-attitude>
```

Key parameters:
- **Beta**: 0.025 (proportional gain)
- **Zeta**: 0.003 (integral gain)
- **Beta0**: 10.0 (initial proportional gain)
- **Zeta0**: 0.0 (initial integral gain)
- **Filter Steps**: 50
- **KFG**: 2.0 (likely a Kalman filter gain)
- **Norm Filter**: 0.1 (normalization filter coefficient)

These parameters suggest the use of a complementary filter or Mahony/Madgwick-style filter for attitude estimation, with adaptive gains.

### 4.4 External Attitude Reference

```xml
<entry-grav-ext-ahrs>
    <id>26</id>
    <filename>grav_ext_ahrs.bin</filename>
    <data>
        <m_disabled>
            <mode>0</mode>
        </m_disabled>
    </data>
</entry-grav-ext-ahrs>
```

This configuration indicates that external AHRS (Attitude and Heading Reference System) input is disabled (mode = 0).

## 5. Variable Sensor Data Processing

### 5.1 Variable Accelerometer Data (ID: 121)

```xml
<entry-varacc>
    <id>121</id>
    <filename>varacc.bin</filename>
    <data>
        <rvar0>
            <enable>0</enable>
            <rvar_id0>4100</rvar_id0>
            <rvar_id1>4100</rvar_id1>
            <rvar_id2>4100</rvar_id2>
            <min_value>-3.4028235E38</min_value>
            <max_value>3.4028235E38</max_value>
            <max_delta>3.4028235E38</max_delta>
            <max_count_nv>0</max_count_nv>
        </rvar0>
        <rvar1>
            <!-- Identical configuration -->
        </rvar1>
    </data>
</entry-varacc>
```

This configuration allows system variables to be used as accelerometer inputs, but is currently disabled (enable = 0).

### 5.2 Variable Gyroscope Data (ID: 122)

```xml
<entry-vargyr>
    <id>122</id>
    <filename>vargyr.bin</filename>
    <data>
        <!-- Configuration identical to varacc -->
    </data>
</entry-vargyr>
```

### 5.3 Variable Magnetometer Data (ID: 123)

```xml
<entry-varmag>
    <id>123</id>
    <filename>varmag.bin</filename>
    <data>
        <!-- Configuration identical to varacc -->
    </data>
</entry-varmag>
```

### 5.4 Variable Quaternion Input (ID: 66)

```xml
<entry-varqinf>
    <id>66</id>
    <filename>varqinf.bin</filename>
    <data>
        <rvar0>
            <enable>0</enable>
            <rvar_id>4100</rvar_id>
            <min_value>-3.4028235E38</min_value>
            <max_value>3.4028235E38</max_value>
            <max_delta>3.4028235E38</max_delta>
            <max_count_nv>0</max_count_nv>
        </rvar0>
        <rvar1>
            <!-- Identical configuration -->
        </rvar1>
    </data>
</entry-varqinf>
```

This configuration allows system variables to be used as quaternion inputs, but is currently disabled.

## 6. Sensor Data Flow Architecture

Based on the configuration files, the sensor data flow in the PDI Monitor system follows this pattern:

1. **Raw Sensor Data Acquisition**
   - IMUs provide raw accelerometer and gyroscope data
   - Magnetometers provide raw magnetic field data
   - External sensors provide additional inputs when configured

2. **Sensor Data Validation**
   - Each sensor type has configurable validation parameters:
     - Maximum delta between consecutive samples
     - Non-valid sample thresholds
     - Min/max value limits

3. **Sensor Data Filtering**
   - First-stage filtering with sensor-specific filters:
     - Notch filters for gyroscopes and accelerometers
     - IIR filters for magnetometers
     - All currently disabled but configured

4. **Linear Parameter Scaling**
   - 3x3 transformation matrices for each sensor
   - Currently identity matrices (no transformation)
   - Can be used for calibration and alignment

5. **Sensor Fusion**
   - Accelerometer suite combines multiple accelerometer inputs
   - Gyroscope suite combines multiple gyroscope inputs
   - Default sensors selected (sensor 0 for each type)
   - Adaptive variance estimation (tau_v, tau_s2 parameters)

6. **Attitude Estimation**
   - Complementary or Mahony/Madgwick-style filter
   - Adaptive gains (beta, zeta parameters)
   - Normalization filtering
   - 50 filter steps per update

7. **External Integration**
   - External AHRS input (currently disabled)
   - Variable sensor inputs (currently disabled)
   - Quaternion input (currently disabled)

## 7. Sensor Configuration Patterns

### 7.1 Redundancy and Sensor Fusion

The system employs multiple redundant sensors:
- 4 IMUs with different configurations
- Multiple dedicated gyroscopes and accelerometers
- 8+ magnetometers
- External sensor inputs

This redundancy is managed through sensor suites that:
- Enable selection of default sensors
- Combine data from multiple sensors
- Adapt to changing sensor variances
- Provide fault tolerance through redundancy

### 7.2 Filtering Strategy

The system uses a multi-stage filtering approach:
1. **Pre-filtering**: Sensor-specific filters
   - Notch filters to remove specific frequencies (e.g., motor vibration)
   - Butterworth filters for general noise reduction
   - IIR filters for magnetometers

2. **Fusion-level filtering**: 
   - Time constants for variance adaptation
   - Minimum variance thresholds

3. **Attitude-level filtering**:
   - Complementary or similar filter with adaptive gains
   - Normalization filtering
   - Multiple filter steps per update

### 7.3 Calibration and Alignment

The system provides multiple mechanisms for sensor calibration:
1. **Linear Parameter Scaling**: 3x3 matrices for each sensor
2. **IMU Geometry**: Rotation matrix for IMU alignment
3. **IMU Position**: Position vector for lever arm compensation

These are currently set to identity/zero values, suggesting either:
- Calibration is performed at runtime
- Calibration values are loaded dynamically
- Physical alignment is precise enough to not require calibration

## 8. Sensor Error Handling

### 8.1 Non-Valid Sample Management

Each sensor type has configurable thresholds for non-valid samples:
- IMU0/1: 10 samples for both accelerometer and gyroscope
- IMU2: 30 samples for both accelerometer and gyroscope
- IMU3: 10 samples for both accelerometer and gyroscope
- External sensors: 10 samples
- Magnetometers: 0 samples (disabled)

This suggests a strategy where:
- Short glitches (< threshold) are ignored
- Persistent errors (≥ threshold) trigger sensor rejection

### 8.2 Maximum Delta Thresholds

Each sensor has a maximum allowed change between consecutive samples:
- Accelerometers: Varies by IMU (156.8 to 313.8128 m/s²)
- Gyroscopes: Consistent at 69.81317 deg/s across all IMUs
- Magnetometers: Effectively unlimited (3.4028235E38)
- External sensors: Effectively unlimited

These thresholds help identify:
- Sensor spikes
- Communication errors
- Sensor failures

### 8.3 Adaptive Variance Estimation

The sensor suites use adaptive variance estimation:
- Initial variance: 1.0 for all sensors
- Minimum variance: 0.0001 for all sensors
- Velocity time constant: 2.0 seconds
- Variance time constant: 20.0 seconds

This allows the system to:
- Adapt to changing sensor noise characteristics
- Reduce the influence of noisier sensors
- Increase the weight of more stable sensors

## 9. Integration with System Architecture

Based on the context files, the sensor processing system integrates with the overall PDI Monitor architecture in the following ways:

### 9.1 Relationship to Navigation System

The sensor data flows into the navigation monitoring subsystem:
- `Mon_nav_input_manager` processes navigation inputs
- `Blk_pa_mon_nav` performs navigation monitoring
- Navigation position and rotation tracking uses sensor data

### 9.2 Communication Interface Integration

Sensor data is communicated through:
- Cross-process communication (XPCU8, XPECAP)
- Telemetry data formatting
- CAN bus interfaces for external sensor data

### 9.3 Operational Mode Impact

The sensor processing behavior likely changes based on system mode:
- **Mission Mode**: Full sensor fusion and attitude estimation active
- **Maintenance Mode**: Possibly reduced sensor processing or different filtering parameters

## 10. Sensor Processing Summary Table

| Sensor Type | Instances | Sample Rate | Range | Filtering | Fusion Method |
|-------------|-----------|-------------|-------|-----------|---------------|
| IMU0/1 Accelerometer | 2 | 160 Hz | ±4g | Notch (100Hz), Butterworth (disabled) | Accelerometer Suite |
| IMU0/1 Gyroscope | 2 | 128 Hz | ±12°/s | Notch (100Hz), Butterworth (disabled) | Gyroscope Suite |
| IMU2 Accelerometer | 1 | Code 12 | ±2g | Notch (100Hz), Butterworth (disabled) | Accelerometer Suite |
| IMU2 Gyroscope | 1 | Code 2 | Code 0 | Notch (100Hz), Butterworth (disabled) | Gyroscope Suite |
| IMU3 Accelerometer | 1 | N/A | N/A | 4 filter stages | Accelerometer Suite |
| IMU3 Gyroscope | 1 | N/A | N/A | 4 filter stages | Gyroscope Suite |
| Magnetometers | 8+ | N/A | N/A | IIR (disabled) | N/A |
| External Sensors | 6 | 0 Hz (disabled) | Unlimited | IIR (disabled) | N/A |

## 11. Conclusion

The PDI Monitor sensor processing system implements a sophisticated approach to inertial sensing, with multiple layers of redundancy, filtering, and fusion. The system is designed to be robust against sensor failures and noise, with configurable validation parameters and adaptive variance estimation.

The sensor configuration shows a clear focus on reliability through redundancy, with four IMUs and multiple dedicated sensors. The filtering architecture provides multiple stages of noise reduction, while the sensor fusion approach allows for adaptive weighting of sensors based on their performance.

The system appears to be designed for a UAV or similar autonomous platform, with a focus on accurate attitude estimation for navigation and control. While many advanced filtering features are currently disabled in the configuration files, the framework is in place to enable them as needed.

The integration with the overall system architecture ensures that sensor data flows into the navigation and monitoring subsystems, providing the foundation for autonomous operation and safety monitoring.

## Referenced Context Files

- `Amazon-PrimeAir/items/ASTRO/items/Monitor/07_System_Architecture.md` - Provided context on the overall PDI Monitor system architecture, including the navigation monitoring subsystem and operational modes.

- `Amazon-PrimeAir/items/ASTRO/items/Monitor/06_Communication_Interfaces.md` - Provided context on the communication interfaces used for sensor data transmission and integration with other system components.