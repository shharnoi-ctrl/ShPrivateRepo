# Generated from:

- Eigen/src/Core/Assign.h (684 tokens)
- Eigen/src/Core/Matrix.h (6085 tokens)
- Eigen/src/Core/Array.h (4195 tokens)
- Eigen/src/Core/Transpose.h (4401 tokens)
- Eigen/src/Core/DiagonalMatrix.h (3667 tokens)
- Eigen/src/Core/Diagonal.h (2467 tokens)
- Eigen/src/Core/Redux.h (4798 tokens)
- Eigen/src/Core/Ref.h (4455 tokens)
- Eigen/src/Core/Reshaped.h (4258 tokens)
- Eigen/src/Core/Dot.h (2913 tokens)
- Eigen/src/Core/SolveTriangular.h (2342 tokens)
- Eigen/src/Core/SelfAdjointView.h (3749 tokens)
- Eigen/src/Core/products/GeneralMatrixMatrix.h (5026 tokens)
- Eigen/src/Core/products/GeneralMatrixVector.h (5431 tokens)

## With context from:

- Amazon-PrimeAir/items/ASTRO/items/sw/sw_pa_recovery_test/code/include/09_Eigen_Core.md (2608 tokens)

---

# Eigen Core Matrix and Array Operations Analysis

This analysis examines Eigen's core matrix and array operations, focusing on the Matrix and Array classes, assignment mechanisms, and common operations like transpose, diagonal extraction, and matrix products.

## 1. Matrix and Array Classes

### 1.1 Matrix Class (`Matrix.h`)

The `Matrix` class is the primary container for dense matrices and vectors in Eigen. It inherits from `PlainObjectBase` and provides a comprehensive interface for matrix operations.

```cpp
template<typename _Scalar, int _Rows, int _Cols, int _Options, int _MaxRows, int _MaxCols>
class Matrix : public PlainObjectBase<Matrix<_Scalar, _Rows, _Cols, _Options, _MaxRows, _MaxCols>>
{
public:
  typedef PlainObjectBase<Matrix> Base;
  EIGEN_DENSE_PUBLIC_INTERFACE(Matrix)
  
  // Constructors for various scenarios
  EIGEN_DEVICE_FUNC inline Matrix() : Base() { ... }
  EIGEN_DEVICE_FUNC explicit Matrix(Index rows, Index cols) { ... }
  EIGEN_DEVICE_FUNC Matrix(const Scalar& x, const Scalar& y) { ... }
  EIGEN_DEVICE_FUNC Matrix(const Scalar& x, const Scalar& y, const Scalar& z) { ... }
  EIGEN_DEVICE_FUNC Matrix(const Scalar& x, const Scalar& y, const Scalar& z, const Scalar& w) { ... }
  
  // Copy constructors
  EIGEN_DEVICE_FUNC Matrix(const Matrix& other) : Base(other) { }
  template<typename OtherDerived>
  EIGEN_DEVICE_FUNC Matrix(const EigenBase<OtherDerived>& other) : Base(other.derived()) { }
  
  // Assignment operators
  EIGEN_DEVICE_FUNC Matrix& operator=(const Matrix& other) { return Base::_set(other); }
  template<typename OtherDerived>
  EIGEN_DEVICE_FUNC Matrix& operator=(const DenseBase<OtherDerived>& other) { return Base::_set(other); }
  template<typename OtherDerived>
  EIGEN_DEVICE_FUNC Matrix& operator=(const EigenBase<OtherDerived>& other) { return Base::operator=(other); }
  
  // Stride information
  EIGEN_DEVICE_FUNC EIGEN_CONSTEXPR inline Index innerStride() const EIGEN_NOEXCEPT { return 1; }
  EIGEN_DEVICE_FUNC EIGEN_CONSTEXPR inline Index outerStride() const EIGEN_NOEXCEPT { return this->innerSize(); }
};
```

Key features:
- Template parameters control size, scalar type, and storage options
- Fixed-size matrices have sizes known at compile time
- Dynamic-size matrices have sizes determined at runtime
- Storage order can be row-major or column-major (default)
- Comprehensive set of constructors for different initialization scenarios
- Stride information for efficient memory traversal

The class also defines numerous typedefs for common matrix types:
```cpp
// Fixed-size typedefs
typedef Matrix<int, 2, 2> Matrix2i;
typedef Matrix<float, 3, 3> Matrix3f;
typedef Matrix<double, 4, 4> Matrix4d;

// Dynamic-size typedefs
typedef Matrix<double, Dynamic, Dynamic> MatrixXd;
typedef Matrix<float, Dynamic, 1> VectorXf;
typedef Matrix<int, 1, Dynamic> RowVectorXi;

// C++11 template aliases
template <typename Type, int Size>
using Vector = Matrix<Type, Size, 1>;

template <typename Type>
using Matrix3 = Matrix<Type, 3, 3>;
```

### 1.2 Array Class (`Array.h`)

The `Array` class provides coefficient-wise operations for element-by-element manipulation:

```cpp
template<typename _Scalar, int _Rows, int _Cols, int _Options, int _MaxRows, int _MaxCols>
class Array : public PlainObjectBase<Array<_Scalar, _Rows, _Cols, _Options, _MaxRows, _MaxCols>>
{
public:
  typedef PlainObjectBase<Array> Base;
  EIGEN_DENSE_PUBLIC_INTERFACE(Array)
  
  // Constructors similar to Matrix class
  EIGEN_DEVICE_FUNC inline Array() : Base() { ... }
  EIGEN_DEVICE_FUNC explicit Array(Index dim) { ... }
  EIGEN_DEVICE_FUNC Array(const Scalar& value) { ... }
  EIGEN_DEVICE_FUNC Array(Index rows, Index cols) { ... }
  
  // Assignment operators
  template<typename OtherDerived>
  EIGEN_DEVICE_FUNC Array& operator=(const EigenBase<OtherDerived>& other) { return Base::operator=(other); }
  EIGEN_DEVICE_FUNC Array& operator=(const Array& other) { return Base::_set(other); }
  EIGEN_DEVICE_FUNC Array& operator=(const Scalar& value) { Base::setConstant(value); return *this; }
  
  // Stride information
  EIGEN_DEVICE_FUNC EIGEN_CONSTEXPR inline Index innerStride() const EIGEN_NOEXCEPT { return 1; }
  EIGEN_DEVICE_FUNC EIGEN_CONSTEXPR inline Index outerStride() const EIGEN_NOEXCEPT { return this->innerSize(); }
};
```

Key differences from Matrix:
- Designed for coefficient-wise operations rather than linear algebra
- Provides element-wise multiplication, division, etc.
- No matrix multiplication operator
- Can be easily converted to/from Matrix objects

Similar to Matrix, Array provides typedefs for common array types:
```cpp
typedef Array<float, 2, 2> Array22f;
typedef Array<double, Dynamic, Dynamic> ArrayXXd;
typedef Array<int, 3, 1> Array3i;
```

## 2. Assignment Mechanisms (`Assign.h`)

Eigen implements sophisticated assignment mechanisms to handle different types of expressions efficiently:

```cpp
template<typename Derived>
template<typename OtherDerived>
EIGEN_DEVICE_FUNC EIGEN_STRONG_INLINE Derived& DenseBase<Derived>::lazyAssign(const DenseBase<OtherDerived>& other)
{
  // Static assertions to check compatibility
  EIGEN_STATIC_ASSERT_LVALUE(Derived)
  EIGEN_STATIC_ASSERT_SAME_MATRIX_SIZE(Derived,OtherDerived)
  EIGEN_STATIC_ASSERT(SameType,YOU_MIXED_DIFFERENT_NUMERIC_TYPES__YOU_NEED_TO_USE_THE_CAST_METHOD_OF_MATRIXBASE_TO_CAST_NUMERIC_TYPES_EXPLICITLY)

  // Runtime assertion for dynamic-size matrices
  eigen_assert(rows() == other.rows() && cols() == other.cols());
  
  // Perform the actual assignment
  internal::call_assignment_no_alias(derived(), other.derived());
  
  return derived();
}

template<typename Derived>
template<typename OtherDerived>
EIGEN_DEVICE_FUNC EIGEN_STRONG_INLINE Derived& DenseBase<Derived>::operator=(const DenseBase<OtherDerived>& other)
{
  internal::call_assignment(derived(), other.derived());
  return derived();
}
```

The assignment system:
1. Performs static and runtime compatibility checks
2. Handles aliasing (when the destination overlaps with the source)
3. Dispatches to specialized implementations based on expression types
4. Optimizes for different storage orders and vectorization opportunities

The `internal::call_assignment` function is the central dispatcher that selects the appropriate implementation based on the expression types and properties.

## 3. Transpose Operation (`Transpose.h`)

Eigen implements transpose as an expression template that defers actual computation:

```cpp
template<typename MatrixType> class Transpose
  : public TransposeImpl<MatrixType, typename internal::traits<MatrixType>::StorageKind>
{
public:
  typedef typename internal::ref_selector<MatrixType>::non_const_type MatrixTypeNested;
  typedef typename TransposeImpl<MatrixType, typename internal::traits<MatrixType>::StorageKind>::Base Base;
  EIGEN_GENERIC_PUBLIC_INTERFACE(Transpose)
  
  EIGEN_DEVICE_FUNC explicit EIGEN_STRONG_INLINE Transpose(MatrixType& matrix) : m_matrix(matrix) {}
  
  EIGEN_DEVICE_FUNC EIGEN_STRONG_INLINE EIGEN_CONSTEXPR Index rows() const EIGEN_NOEXCEPT { return m_matrix.cols(); }
  EIGEN_DEVICE_FUNC EIGEN_STRONG_INLINE EIGEN_CONSTEXPR Index cols() const EIGEN_NOEXCEPT { return m_matrix.rows(); }
  
  EIGEN_DEVICE_FUNC EIGEN_STRONG_INLINE const typename internal::remove_all<MatrixTypeNested>::type&
  nestedExpression() const { return m_matrix; }
  
protected:
  typename internal::ref_selector<MatrixType>::non_const_type m_matrix;
};
```

Key aspects:
1. `Transpose` is a lightweight wrapper that references the original matrix
2. It swaps rows and columns in all access operations
3. No data is actually copied or rearranged until the result is used
4. For lvalue expressions, it provides write access to the transposed elements

The `transposeInPlace()` method efficiently transposes a matrix in-place:

```cpp
template<typename Derived>
EIGEN_DEVICE_FUNC inline void DenseBase<Derived>::transposeInPlace()
{
  eigen_assert((rows() == cols() || (RowsAtCompileTime == Dynamic && ColsAtCompileTime == Dynamic))
               && "transposeInPlace() called on a non-square non-resizable matrix");
  internal::inplace_transpose_selector<Derived>::run(derived());
}
```

The implementation uses specialized algorithms:
- For small fixed-size matrices: unrolled element swapping
- For larger matrices: blocked algorithms that optimize cache usage
- For non-square matrices: creates a temporary copy

## 4. Diagonal Operations

### 4.1 Diagonal Extraction (`Diagonal.h`)

The `Diagonal` class represents a diagonal or sub/super-diagonal of a matrix:

```cpp
template<typename MatrixType, int DiagIndex> class Diagonal
   : public internal::dense_xpr_base<Diagonal<MatrixType, DiagIndex>>::type
{
public:
  typedef typename internal::dense_xpr_base<Diagonal>::type Base;
  EIGEN_DENSE_PUBLIC_INTERFACE(Diagonal)
  
  EIGEN_DEVICE_FUNC explicit inline Diagonal(MatrixType& matrix, Index a_index = DiagIndex)
    : m_matrix(matrix), m_index(a_index) {}
  
  EIGEN_DEVICE_FUNC inline Index rows() const { /* Implementation */ }
  EIGEN_DEVICE_FUNC inline Index cols() const { return 1; }
  
  EIGEN_DEVICE_FUNC inline Scalar& coeffRef(Index row, Index) {
    return m_matrix.coeffRef(row+rowOffset(), row+colOffset());
  }
  
  EIGEN_DEVICE_FUNC inline const Scalar& coeffRef(Index row, Index) const {
    return m_matrix.coeffRef(row+rowOffset(), row+colOffset());
  }
  
protected:
  typename internal::ref_selector<MatrixType>::non_const_type m_matrix;
  const internal::variable_if_dynamicindex<Index, DiagIndex> m_index;
  
private:
  EIGEN_DEVICE_FUNC EIGEN_STRONG_INLINE EIGEN_CONSTEXPR
  Index rowOffset() const EIGEN_NOEXCEPT { return m_index.value()>0 ? 0 : -m_index.value(); }
  
  EIGEN_DEVICE_FUNC EIGEN_STRONG_INLINE EIGEN_CONSTEXPR
  Index colOffset() const EIGEN_NOEXCEPT { return m_index.value()>0 ? m_index.value() : 0; }
};
```

Key features:
- Extracts main diagonal when `DiagIndex = 0`
- Extracts super-diagonal when `DiagIndex > 0`
- Extracts sub-diagonal when `DiagIndex < 0`
- Provides read/write access to diagonal elements
- Implemented as a view - no data copying

The `diagonal()` method in `MatrixBase` returns a `Diagonal` object:

```cpp
template<typename Derived>
EIGEN_DEVICE_FUNC inline typename MatrixBase<Derived>::DiagonalReturnType
MatrixBase<Derived>::diagonal()
{
  return DiagonalReturnType(derived());
}

template<typename Derived>
template<int Index_>
EIGEN_DEVICE_FUNC inline typename MatrixBase<Derived>::template DiagonalIndexReturnType<Index_>::Type
MatrixBase<Derived>::diagonal()
{
  return typename DiagonalIndexReturnType<Index_>::Type(derived());
}
```

### 4.2 Diagonal Matrix (`DiagonalMatrix.h`)

The `DiagonalMatrix` class represents a diagonal matrix efficiently:

```cpp
template<typename _Scalar, int SizeAtCompileTime, int MaxSizeAtCompileTime>
class DiagonalMatrix
  : public DiagonalBase<DiagonalMatrix<_Scalar, SizeAtCompileTime, MaxSizeAtCompileTime>>
{
public:
  typedef typename internal::traits<DiagonalMatrix>::DiagonalVectorType DiagonalVectorType;
  typedef _Scalar Scalar;
  
protected:
  DiagonalVectorType m_diagonal;
  
public:
  // Constructors
  EIGEN_DEVICE_FUNC inline DiagonalMatrix() {}
  EIGEN_DEVICE_FUNC explicit inline DiagonalMatrix(Index dim) : m_diagonal(dim) {}
  EIGEN_DEVICE_FUNC inline DiagonalMatrix(const Scalar& x, const Scalar& y) : m_diagonal(x,y) {}
  
  // Access to diagonal vector
  EIGEN_DEVICE_FUNC inline const DiagonalVectorType& diagonal() const { return m_diagonal; }
  EIGEN_DEVICE_FUNC inline DiagonalVectorType& diagonal() { return m_diagonal; }
  
  // Special operations
  EIGEN_DEVICE_FUNC inline void setIdentity() { m_diagonal.setOnes(); }
  EIGEN_DEVICE_FUNC inline void setZero() { m_diagonal.setZero(); }
};
```

Key features:
- Stores only the diagonal elements, not the full matrix
- Provides efficient matrix operations that exploit diagonal structure
- Special methods for identity and zero matrices
- Optimized matrix-vector multiplication

The `asDiagonal()` method converts a vector to a diagonal matrix:

```cpp
template<typename Derived>
EIGEN_DEVICE_FUNC inline const DiagonalWrapper<const Derived>
MatrixBase<Derived>::asDiagonal() const
{
  return DiagonalWrapper<const Derived>(derived());
}
```

## 5. Matrix Products

### 5.1 General Matrix-Matrix Product (`GeneralMatrixMatrix.h`)

Eigen implements highly optimized matrix-matrix multiplication using a blocked algorithm based on Goto's approach:

```cpp
template<typename Index, typename LhsScalar, int LhsStorageOrder, bool ConjugateLhs,
         typename RhsScalar, int RhsStorageOrder, bool ConjugateRhs, int ResInnerStride>
struct general_matrix_matrix_product<Index,LhsScalar,LhsStorageOrder,ConjugateLhs,
                                    RhsScalar,RhsStorageOrder,ConjugateRhs,ColMajor,ResInnerStride>
{
  static void run(Index rows, Index cols, Index depth,
                 const LhsScalar* _lhs, Index lhsStride,
                 const RhsScalar* _rhs, Index rhsStride,
                 ResScalar* _res, Index resIncr, Index resStride,
                 ResScalar alpha,
                 level3_blocking<LhsScalar,RhsScalar>& blocking,
                 GemmParallelInfo<Index>* info = 0)
  {
    // Implementation of blocked matrix multiplication
    // Uses cache blocking, register blocking, and vectorization
    // ...
  }
};
```

Key optimizations:
1. **Cache blocking**: Divides matrices into blocks that fit in L1/L2/L3 cache
2. **Register blocking**: Further divides blocks to maximize register usage
3. **Vectorization**: Uses SIMD instructions for parallel computation
4. **Parallelization**: Multi-threaded implementation for large matrices
5. **Specialized kernels**: Different implementations for different matrix sizes and types

The implementation uses a sophisticated blocking strategy:
```cpp
// For each block of the output matrix
for(Index i2=0; i2<rows; i2+=mc) {
  const Index actual_mc = (std::min)(i2+mc,rows)-i2;
  
  for(Index k2=0; k2<depth; k2+=kc) {
    const Index actual_kc = (std::min)(k2+kc,depth)-k2;
    
    // Pack a panel of lhs into contiguous memory
    pack_lhs(blockA, lhs.getSubMapper(i2,k2), actual_kc, actual_mc);
    
    // For each block of the rhs
    for(Index j2=0; j2<cols; j2+=nc) {
      const Index actual_nc = (std::min)(j2+nc,cols)-j2;
      
      // Pack a panel of rhs into contiguous memory
      pack_rhs(blockB, rhs.getSubMapper(k2,j2), actual_kc, actual_nc);
      
      // Call the micro-kernel for matrix multiplication
      gebp(res.getSubMapper(i2, j2), blockA, blockB, actual_mc, actual_kc, actual_nc, alpha);
    }
  }
}
```

### 5.2 General Matrix-Vector Product (`GeneralMatrixVector.h`)

Eigen also optimizes matrix-vector multiplication:

```cpp
template<typename Index, typename LhsScalar, typename LhsMapper, bool ConjugateLhs,
         typename RhsScalar, typename RhsMapper, bool ConjugateRhs, int Version>
struct general_matrix_vector_product<Index,LhsScalar,LhsMapper,ColMajor,ConjugateLhs,
                                    RhsScalar,RhsMapper,ConjugateRhs,Version>
{
  static void run(Index rows, Index cols,
                 const LhsMapper& lhs,
                 const RhsMapper& rhs,
                 ResScalar* res, Index resIncr,
                 RhsScalar alpha)
  {
    // Implementation of optimized matrix-vector multiplication
    // Uses vectorization and loop unrolling
    // ...
  }
};
```

Key optimizations:
1. **Vectorization**: Processes multiple elements in parallel using SIMD
2. **Loop unrolling**: Reduces loop overhead for small to medium matrices
3. **Cache optimization**: Processes the matrix in column-major order for better cache usage
4. **Multiple accumulators**: Uses multiple accumulators to reduce dependency chains

The implementation uses aggressive loop unrolling:
```cpp
// Process 8 rows at once
for(; i<n8; i+=ResPacketSize*8) {
  ResPacket c0 = pset1<ResPacket>(ResScalar(0)),
            c1 = pset1<ResPacket>(ResScalar(0)),
            // ... c2 through c7
  
  // Accumulate contributions from each column
  for(Index j=j2; j<jend; j+=1) {
    RhsPacket b0 = pset1<RhsPacket>(rhs(j,0));
    c0 = pcj.pmadd(lhs.template load<LhsPacket,LhsAlignment>(i+LhsPacketSize*0,j),b0,c0);
    c1 = pcj.pmadd(lhs.template load<LhsPacket,LhsAlignment>(i+LhsPacketSize*1,j),b0,c1);
    // ... c2 through c7
  }
  
  // Store results
  pstoreu(res+i+ResPacketSize*0, pmadd(c0,palpha,ploadu<ResPacket>(res+i+ResPacketSize*0)));
  pstoreu(res+i+ResPacketSize*1, pmadd(c1,palpha,ploadu<ResPacket>(res+i+ResPacketSize*1)));
  // ... and so on
}

// Process 4 rows at once
for(; i<n4; i+=ResPacketSize*4) {
  // Similar implementation with 4 accumulators
}

// Process 2 rows at once
// ...

// Process remaining rows one by one
// ...
```

## 6. Other Key Operations

### 6.1 Reduction Operations (`Redux.h`)

Eigen provides efficient reduction operations like sum, product, min, max:

```cpp
template<typename Derived>
EIGEN_DEVICE_FUNC EIGEN_STRONG_INLINE typename internal::traits<Derived>::Scalar
DenseBase<Derived>::sum() const
{
  if(SizeAtCompileTime==0 || (SizeAtCompileTime==Dynamic && size()==0))
    return Scalar(0);
  return derived().redux(Eigen::internal::scalar_sum_op<Scalar,Scalar>());
}

template<typename Derived>
template<typename Func>
EIGEN_DEVICE_FUNC EIGEN_STRONG_INLINE typename internal::traits<Derived>::Scalar
DenseBase<Derived>::redux(const Func& func) const
{
  typedef typename internal::redux_evaluator<Derived> ThisEvaluator;
  ThisEvaluator thisEval(derived());
  
  return internal::redux_impl<Func, ThisEvaluator>::run(thisEval, func, derived());
}
```

The implementation uses:
1. **Vectorization**: Parallel reduction using SIMD instructions
2. **Tree reduction**: Hierarchical approach to minimize dependencies
3. **Specialized algorithms**: Different implementations based on matrix size and layout

### 6.2 Dot Product and Norms (`Dot.h`)

Eigen implements dot products and various norms:

```cpp
template<typename Derived>
template<typename OtherDerived>
EIGEN_DEVICE_FUNC EIGEN_STRONG_INLINE
typename ScalarBinaryOpTraits<typename internal::traits<Derived>::Scalar,
                             typename internal::traits<OtherDerived>::Scalar>::ReturnType
MatrixBase<Derived>::dot(const MatrixBase<OtherDerived>& other) const
{
  EIGEN_STATIC_ASSERT_VECTOR_ONLY(Derived)
  EIGEN_STATIC_ASSERT_VECTOR_ONLY(OtherDerived)
  EIGEN_STATIC_ASSERT_SAME_VECTOR_SIZE(Derived,OtherDerived)
  
  eigen_assert(size() == other.size());
  
  return internal::dot_nocheck<Derived,OtherDerived>::run(*this, other);
}

template<typename Derived>
EIGEN_DEVICE_FUNC EIGEN_STRONG_INLINE typename NumTraits<typename internal::traits<Derived>::Scalar>::Real
MatrixBase<Derived>::norm() const
{
  return numext::sqrt(squaredNorm());
}
```

Key features:
- Handles complex numbers correctly (conjugation)
- Avoids underflow/overflow in norm calculations
- Provides specialized implementations for different vector sizes

### 6.3 Triangular Solvers (`SolveTriangular.h`)

Eigen provides efficient triangular system solvers:

```cpp
template<typename MatrixType, unsigned int Mode>
template<int Side, typename OtherDerived>
EIGEN_DEVICE_FUNC void TriangularViewImpl<MatrixType,Mode,Dense>::solveInPlace(
  const MatrixBase<OtherDerived>& _other) const
{
  OtherDerived& other = _other.const_cast_derived();
  eigen_assert(derived().cols() == derived().rows() && 
              ((Side==OnTheLeft && derived().cols() == other.rows()) || 
               (Side==OnTheRight && derived().cols() == other.cols())));
  
  // Implementation details...
}
```

The implementation:
1. Handles both upper and lower triangular matrices
2. Supports unit diagonal option
3. Works for both left and right multiplication
4. Uses vectorization and blocking for performance

### 6.4 Self-Adjoint Views (`SelfAdjointView.h`)

Eigen provides a view for symmetric/Hermitian matrices:

```cpp
template<typename _MatrixType, unsigned int UpLo> class SelfAdjointView
  : public TriangularBase<SelfAdjointView<_MatrixType, UpLo>>
{
public:
  typedef _MatrixType MatrixType;
  typedef TriangularBase<SelfAdjointView> Base;
  
  EIGEN_DEVICE_FUNC explicit inline SelfAdjointView(MatrixType& matrix) : m_matrix(matrix)
  {
    EIGEN_STATIC_ASSERT(UpLo==Lower || UpLo==Upper, SELFADJOINTVIEW_ACCEPTS_UPPER_AND_LOWER_MODE_ONLY);
  }
  
  // Special operations for self-adjoint matrices
  template<typename DerivedU, typename DerivedV>
  EIGEN_DEVICE_FUNC SelfAdjointView& rankUpdate(const MatrixBase<DerivedU>& u, 
                                              const MatrixBase<DerivedV>& v, 
                                              const Scalar& alpha = Scalar(1));
  
  // Eigendecomposition methods
  EIGEN_DEVICE_FUNC EigenvaluesReturnType eigenvalues() const;
  EIGEN_DEVICE_FUNC RealScalar operatorNorm() const;
  
  // Cholesky decomposition methods
  const LLT<PlainObject, UpLo> llt() const;
  const LDLT<PlainObject, UpLo> ldlt() const;
  
protected:
  MatrixTypeNested m_matrix;
};
```

Key features:
- Stores only half of the matrix (upper or lower triangle)
- Provides specialized algorithms for symmetric/Hermitian matrices
- Supports rank updates, eigenvalue computation, and Cholesky decomposition
- Ensures symmetry is maintained in all operations

### 6.5 Reshaping (`Reshaped.h`)

Eigen provides a view for reshaping matrices:

```cpp
template<typename XprType, int Rows, int Cols, int Order> class Reshaped
  : public ReshapedImpl<XprType, Rows, Cols, Order, typename internal::traits<XprType>::StorageKind>
{
public:
  typedef ReshapedImpl<XprType, Rows, Cols, Order, typename internal::traits<XprType>::StorageKind> Impl;
  typedef Impl Base;
  
  // Fixed-size constructor
  EIGEN_DEVICE_FUNC inline Reshaped(XprType& xpr) : Impl(xpr) { ... }
  
  // Dynamic-size constructor
  EIGEN_DEVICE_FUNC inline Reshaped(XprType& xpr, Index reshapeRows, Index reshapeCols)
    : Impl(xpr, reshapeRows, reshapeCols) { ... }
};
```

Key features:
- Provides a view of a matrix with different dimensions
- No data copying - just reinterprets the existing data
- Supports both fixed-size and dynamic-size reshaping
- Handles row-major and column-major storage orders

## 7. Reference Wrapper (`Ref.h`)

The `Ref` class provides a way to write non-template functions that accept Eigen expressions:

```cpp
template<typename PlainObjectType, int Options, typename StrideType> class Ref
  : public RefBase<Ref<PlainObjectType, Options, StrideType>>
{
public:
  typedef RefBase<Ref> Base;
  EIGEN_DENSE_PUBLIC_INTERFACE(Ref)
  
  template<typename Derived>
  EIGEN_DEVICE_FUNC inline Ref(PlainObjectBase<Derived>& expr,
                             typename internal::enable_if<bool(internal::traits<Ref>::template match<Derived>::MatchAtCompileTime),Derived>::type* = 0)
  {
    EIGEN_STATIC_ASSERT(bool(internal::traits<Ref>::template match<Derived>::MatchAtCompileTime), STORAGE_LAYOUT_DOES_NOT_MATCH);
    const bool success = Base::construct(expr.derived());
    EIGEN_UNUSED_VARIABLE(success)
    eigen_assert(success);
  }
  
  // Other constructors and assignment operators
};
```

Key features:
- Provides a non-template function parameter type for Eigen expressions
- Enforces constraints on the accepted expressions (storage order, alignment, etc.)
- Creates a temporary copy if the input doesn't match constraints (for const references)
- Avoids unnecessary copies when possible

## Implementation Patterns and Optimizations

### 1. Expression Templates

Eigen uses expression templates extensively to:
- Defer evaluation until results are needed
- Eliminate temporary objects
- Enable expression fusion (combining multiple operations)
- Optimize evaluation order

### 2. Vectorization

Matrix operations are heavily vectorized:
- Uses SIMD instructions (SSE, AVX, NEON, etc.)
- Handles alignment requirements automatically
- Falls back to scalar code when vectorization isn't possible
- Provides different packet sizes for different operations

### 3. Memory Layout and Access Patterns

Eigen optimizes memory access:
- Default column-major storage for cache-friendly matrix operations
- Optional row-major storage when appropriate
- Stride information for efficient traversal
- Blocked algorithms to maximize cache usage

### 4. Static vs. Dynamic Sizing

Eigen handles both fixed-size and dynamic-size matrices:
- Fixed-size matrices have sizes known at compile time
- Dynamic-size matrices have sizes determined at runtime
- Hybrid matrices have some dimensions fixed and others dynamic
- Compile-time optimizations for small fixed-size matrices

### 5. Lazy Evaluation

Operations are evaluated lazily:
- Views like `Transpose`, `Diagonal`, and `Reshaped` don't copy data
- Operations are combined when possible
- Evaluation happens only when results are needed
- Temporary objects are created only when necessary

## Conclusion

Eigen's matrix and array operations are built on a sophisticated foundation that balances ease of use with high performance. The library uses advanced C++ techniques like expression templates, template metaprogramming, and SFINAE to provide an intuitive API while enabling aggressive optimizations.

Key strengths include:
1. Comprehensive set of matrix and array operations
2. Efficient implementation of common linear algebra operations
3. Flexible expression system that minimizes temporaries
4. Extensive vectorization and cache optimization
5. Support for both fixed-size and dynamic-size matrices
6. Specialized algorithms for different matrix structures

These components work together to provide a high-performance linear algebra library with a clean, intuitive interface that rivals the performance of hand-optimized code while maintaining the flexibility and expressiveness of a high-level library.

## Referenced Context Files

- `Eigen/src/Core/Assign.h`: Provided assignment mechanisms for matrices and arrays
- `Eigen/src/Core/Matrix.h`: Defined the core Matrix class and related typedefs
- `Eigen/src/Core/Array.h`: Defined the Array class for coefficient-wise operations
- `Eigen/src/Core/Transpose.h`: Implemented transpose operations and in-place transposition
- `Eigen/src/Core/DiagonalMatrix.h`: Defined diagonal matrix representation
- `Eigen/src/Core/Diagonal.h`: Implemented diagonal extraction and manipulation
- `Eigen/src/Core/Redux.h`: Provided reduction operations like sum, product, min, max
- `Eigen/src/Core/Ref.h`: Implemented reference wrapper for non-template functions
- `Eigen/src/Core/Reshaped.h`: Provided matrix reshaping functionality
- `Eigen/src/Core/Dot.h`: Implemented dot products and vector norms
- `Eigen/src/Core/SolveTriangular.h`: Provided triangular system solvers
- `Eigen/src/Core/SelfAdjointView.h`: Implemented symmetric/Hermitian matrix views
- `Eigen/src/Core/products/GeneralMatrixMatrix.h`: Optimized matrix-matrix multiplication
- `Eigen/src/Core/products/GeneralMatrixVector.h`: Optimized matrix-vector multiplication