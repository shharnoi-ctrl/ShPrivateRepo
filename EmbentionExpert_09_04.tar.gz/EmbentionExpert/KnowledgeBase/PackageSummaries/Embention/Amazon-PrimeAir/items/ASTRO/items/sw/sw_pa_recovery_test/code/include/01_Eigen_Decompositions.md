# Generated from:

- Eigen/src/LU/FullPivLU.h (8095 tokens)
- Eigen/src/LU/PartialPivLU.h (5517 tokens)
- Eigen/src/LU/Determinant.h (859 tokens)
- Eigen/src/LU/InverseImpl.h (3931 tokens)
- Eigen/src/Cholesky/LLT.h (4690 tokens)
- Eigen/src/Cholesky/LDLT.h (6233 tokens)
- Eigen/src/QR/HouseholderQR.h (3660 tokens)
- Eigen/src/QR/FullPivHouseholderQR.h (6692 tokens)
- Eigen/src/QR/ColPivHouseholderQR.h (6374 tokens)
- Eigen/src/SVD/JacobiSVD.h (8247 tokens)
- Eigen/src/SVD/BDCSVD.h (13553 tokens)
- Eigen/src/Eigenvalues/SelfAdjointEigenSolver.h (8795 tokens)
- Eigen/src/Eigenvalues/EigenSolver.h (5742 tokens)

## With context from:

- Amazon-PrimeAir/items/ASTRO/items/sw/sw_pa_recovery_test/code/include/08_Eigen_Matrix_Operations.md (6944 tokens)

---

# High-Fidelity Semantic Knowledge Graph: Eigen Matrix Decomposition Algorithms

This document provides a comprehensive analysis of Eigen's matrix decomposition algorithms, focusing on LU, Cholesky, QR, SVD, and eigenvalue decompositions. These decompositions form the foundation for solving linear systems, computing determinants, inverses, and eigenvalues/eigenvectors.

## 1. LU Decomposition

Eigen provides two main LU decomposition classes:

### 1.1 FullPivLU

`FullPivLU` implements a rank-revealing LU decomposition with complete pivoting, decomposing a matrix A as:

```
A = P^{-1} L U Q^{-1}
```

where:
- L is unit-lower-triangular
- U is upper-triangular
- P and Q are permutation matrices

```cpp
template<typename _MatrixType> class FullPivLU : public SolverBase<FullPivLU<_MatrixType>>
{
public:
  // Constructors
  FullPivLU();
  explicit FullPivLU(Index size);
  template<typename InputType> explicit FullPivLU(const EigenBase<InputType>& matrix);
  template<typename InputType> explicit FullPivLU(EigenBase<InputType>& matrix);
  
  // Core functionality
  template<typename InputType> FullPivLU& compute(const EigenBase<InputType>& matrix);
  
  // Matrix access
  const MatrixType& matrixLU() const;
  const PermutationType& colsPermutation() const;
  const IntDiagSizeVectorType& rowsTranspositions() const;
  
  // Numerical properties
  Index rank() const;
  Index dimensionOfKernel() const;
  bool isInjective() const;
  bool isSurjective() const;
  bool isInvertible() const;
  typename MatrixType::RealScalar absDeterminant() const;
  typename MatrixType::RealScalar logAbsDeterminant() const;
  
  // Solving systems
  template<typename Rhs> inline const Solve<FullPivLU, Rhs> solve(const MatrixBase<Rhs>& b) const;
  inline const Inverse<FullPivLU> inverse() const;
  
  // Kernel and image
  inline const internal::kernel_retval<FullPivLU> kernel() const;
  inline const internal::image_retval<FullPivLU> image(const MatrixType& originalMatrix) const;
  
  // Threshold control
  FullPivLU& setThreshold(const RealScalar& threshold);
  FullPivLU& setThreshold(Default_t);
  RealScalar threshold() const;
  
  // Additional information
  inline Index nonzeroPivots() const;
  RealScalar maxPivot() const;
};
```

Key implementation details:
- Uses a greedy algorithm to find the largest pivot at each step
- Performs row and column permutations to maximize numerical stability
- Tracks the number of non-zero pivots to determine rank
- Provides threshold control to determine when a pivot is considered zero
- Computes determinant as the product of diagonal entries of U, adjusted by permutation sign

### 1.2 PartialPivLU

`PartialPivLU` implements a more efficient LU decomposition with partial (row) pivoting, decomposing a matrix A as:

```
A = P L U
```

where:
- L is unit-lower-triangular
- U is upper-triangular
- P is a permutation matrix

```cpp
template<typename _MatrixType> class PartialPivLU : public SolverBase<PartialPivLU<_MatrixType>>
{
public:
  // Constructors
  PartialPivLU();
  explicit PartialPivLU(Index size);
  template<typename InputType> explicit PartialPivLU(const EigenBase<InputType>& matrix);
  template<typename InputType> explicit PartialPivLU(EigenBase<InputType>& matrix);
  
  // Core functionality
  template<typename InputType> PartialPivLU& compute(const EigenBase<InputType>& matrix);
  
  // Matrix access
  const MatrixType& matrixLU() const;
  const PermutationType& permutationP() const;
  
  // Numerical properties
  typename MatrixType::RealScalar rcond() const;
  typename MatrixType::Scalar determinant() const;
  
  // Solving systems
  template<typename Rhs> inline const Solve<PartialPivLU, Rhs> solve(const MatrixBase<Rhs>& b) const;
  inline const Inverse<PartialPivLU> inverse() const;
  
  // Reconstruction
  MatrixType reconstructedMatrix() const;
};
```

Key implementation details:
- Uses a blocked algorithm for better cache performance
- Searches only for the largest element in each column (partial pivoting)
- More efficient than FullPivLU but potentially less numerically stable
- Assumes the matrix is invertible (not rank-revealing)
- Optimized for square matrices

The implementation uses specialized algorithms for different matrix sizes:
```cpp
template<typename Scalar, int StorageOrder, typename PivIndex, int SizeAtCompileTime>
struct partial_lu_impl
{
  static const int UnBlockedBound = 16;
  
  static Index unblocked_lu(MatrixTypeRef& lu, PivIndex* row_transpositions, PivIndex& nb_transpositions);
  static Index blocked_lu(Index rows, Index cols, Scalar* lu_data, Index luStride, 
                         PivIndex* row_transpositions, PivIndex& nb_transpositions, Index maxBlockSize=256);
};
```

## 2. Cholesky Decomposition

Eigen provides two Cholesky decomposition variants for symmetric positive-definite matrices:

### 2.1 LLT (Cholesky)

`LLT` computes the standard Cholesky decomposition of a symmetric positive-definite matrix A as:

```
A = L L^*
```

where L is lower triangular.

```cpp
template<typename _MatrixType, int _UpLo> class LLT : public SolverBase<LLT<_MatrixType, _UpLo>>
{
public:
  // Constructors
  LLT();
  explicit LLT(Index size);
  template<typename InputType> explicit LLT(const EigenBase<InputType>& matrix);
  template<typename InputType> explicit LLT(EigenBase<InputType>& matrix);
  
  // Core functionality
  template<typename InputType> LLT& compute(const EigenBase<InputType>& matrix);
  
  // Matrix access
  inline typename Traits::MatrixU matrixU() const;
  inline typename Traits::MatrixL matrixL() const;
  
  // Numerical properties
  RealScalar rcond() const;
  
  // Solving systems
  template<typename Rhs> inline const Solve<LLT, Rhs> solve(const MatrixBase<Rhs>& b) const;
  template<typename Derived> void solveInPlace(const MatrixBase<Derived> &bAndX) const;
  
  // Reconstruction
  MatrixType reconstructedMatrix() const;
  
  // Update
  template<typename VectorType> LLT & rankUpdate(const VectorType& vec, const RealScalar& sigma = 1);
  
  // Information
  ComputationInfo info() const;
};
```

Key implementation details:
- Supports both lower and upper triangular storage
- Uses a blocked algorithm for better cache performance
- Provides rank-1 update functionality
- Checks for positive definiteness during computation
- Optimized for symmetric matrices

The implementation uses specialized algorithms for different matrix sizes:
```cpp
template<typename Scalar, int UpLo> struct llt_inplace
{
  template<typename MatrixType> static bool unblocked(MatrixType& mat);
  template<typename MatrixType> static bool blocked(MatrixType& m);
  template<typename MatrixType, typename VectorType>
  static Index rankUpdate(MatrixType& mat, const VectorType& vec, const RealScalar& sigma);
};
```

### 2.2 LDLT (Robust Cholesky)

`LDLT` computes a robust Cholesky decomposition with pivoting for positive or negative semidefinite matrices:

```
A = P^T L D L^* P
```

where:
- L is unit lower triangular
- D is diagonal (possibly with 2x2 blocks)
- P is a permutation matrix

```cpp
template<typename _MatrixType, int _UpLo> class LDLT : public SolverBase<LDLT<_MatrixType, _UpLo>>
{
public:
  // Constructors
  LDLT();
  explicit LDLT(Index size);
  template<typename InputType> explicit LDLT(const EigenBase<InputType>& matrix);
  template<typename InputType> explicit LDLT(EigenBase<InputType>& matrix);
  
  // Core functionality
  template<typename InputType> LDLT& compute(const EigenBase<InputType>& matrix);
  void setZero();
  
  // Matrix access
  inline typename Traits::MatrixU matrixU() const;
  inline typename Traits::MatrixL matrixL() const;
  inline const TranspositionType& transpositionsP() const;
  inline Diagonal<const MatrixType> vectorD() const;
  
  // Matrix properties
  inline bool isPositive() const;
  inline bool isNegative() const;
  RealScalar rcond() const;
  
  // Solving systems
  template<typename Rhs> inline const Solve<LDLT, Rhs> solve(const MatrixBase<Rhs>& b) const;
  template<typename Derived> bool solveInPlace(MatrixBase<Derived> &bAndX) const;
  
  // Reconstruction
  MatrixType reconstructedMatrix() const;
  
  // Update
  template<typename Derived> LDLT& rankUpdate(const MatrixBase<Derived>& w, const RealScalar& alpha=1);
  
  // Information
  ComputationInfo info() const;
};
```

Key implementation details:
- More robust than LLT for matrices that are nearly singular
- Uses pivoting to ensure stability
- Can handle both positive and negative semidefinite matrices
- Avoids computing square roots, making it more stable
- Provides rank-1 update functionality

The implementation uses specialized algorithms for different matrix sizes:
```cpp
template<int UpLo> struct ldlt_inplace
{
  template<typename MatrixType, typename TranspositionType, typename Workspace>
  static bool unblocked(MatrixType& mat, TranspositionType& transpositions, Workspace& temp, SignMatrix& sign);
  
  template<typename MatrixType, typename TranspositionType, typename Workspace, typename WType>
  static bool update(MatrixType& mat, const TranspositionType& transpositions, Workspace& tmp, 
                    const WType& w, const typename MatrixType::RealScalar& sigma=1);
};
```

## 3. QR Decomposition

Eigen provides three QR decomposition variants with different trade-offs between speed and numerical stability:

### 3.1 HouseholderQR

`HouseholderQR` implements the standard QR decomposition using Householder reflections:

```
A = Q R
```

where:
- Q is orthogonal/unitary
- R is upper triangular

```cpp
template<typename _MatrixType> class HouseholderQR : public SolverBase<HouseholderQR<_MatrixType>>
{
public:
  // Constructors
  HouseholderQR();
  HouseholderQR(Index rows, Index cols);
  template<typename InputType> explicit HouseholderQR(const EigenBase<InputType>& matrix);
  template<typename InputType> explicit HouseholderQR(EigenBase<InputType>& matrix);
  
  // Core functionality
  template<typename InputType> HouseholderQR& compute(const EigenBase<InputType>& matrix);
  
  // Matrix access
  HouseholderSequenceType householderQ() const;
  const MatrixType& matrixQR() const;
  const HCoeffsType& hCoeffs() const;
  
  // Numerical properties
  typename MatrixType::RealScalar absDeterminant() const;
  typename MatrixType::RealScalar logAbsDeterminant() const;
  
  // Solving systems
  template<typename Rhs> inline const Solve<HouseholderQR, Rhs> solve(const MatrixBase<Rhs>& b) const;
};
```

Key implementation details:
- Uses Householder reflections to zero out elements below the diagonal
- No pivoting, so not suitable for rank-deficient matrices
- Fastest QR variant but potentially less numerically stable
- Stores the Householder reflectors in the lower triangular part of the matrix
- Stores the Householder coefficients separately

The implementation uses specialized algorithms for different matrix sizes:
```cpp
template<typename MatrixQR, typename HCoeffs>
void householder_qr_inplace_unblocked(MatrixQR& mat, HCoeffs& hCoeffs, typename MatrixQR::Scalar* tempData = 0);

template<typename MatrixQR, typename HCoeffs, typename MatrixQRScalar, bool InnerStrideIsOne>
struct householder_qr_inplace_blocked
{
  static void run(MatrixQR& mat, HCoeffs& hCoeffs, Index maxBlockSize=32, typename MatrixQR::Scalar* tempData = 0);
};
```

### 3.2 ColPivHouseholderQR

`ColPivHouseholderQR` implements a QR decomposition with column pivoting:

```
A P = Q R
```

where:
- P is a permutation matrix
- Q is orthogonal/unitary
- R is upper triangular

```cpp
template<typename _MatrixType> class ColPivHouseholderQR : public SolverBase<ColPivHouseholderQR<_MatrixType>>
{
public:
  // Constructors
  ColPivHouseholderQR();
  ColPivHouseholderQR(Index rows, Index cols);
  template<typename InputType> explicit ColPivHouseholderQR(const EigenBase<InputType>& matrix);
  template<typename InputType> explicit ColPivHouseholderQR(EigenBase<InputType>& matrix);
  
  // Core functionality
  template<typename InputType> ColPivHouseholderQR& compute(const EigenBase<InputType>& matrix);
  
  // Matrix access
  HouseholderSequenceType householderQ() const;
  HouseholderSequenceType matrixQ() const;
  const MatrixType& matrixQR() const;
  const PermutationType& colsPermutation() const;
  
  // Numerical properties
  typename MatrixType::RealScalar absDeterminant() const;
  typename MatrixType::RealScalar logAbsDeterminant() const;
  Index rank() const;
  Index dimensionOfKernel() const;
  bool isInjective() const;
  bool isSurjective() const;
  bool isInvertible() const;
  
  // Solving systems
  template<typename Rhs> inline const Solve<ColPivHouseholderQR, Rhs> solve(const MatrixBase<Rhs>& b) const;
  inline const Inverse<ColPivHouseholderQR> inverse() const;
  
  // Threshold control
  ColPivHouseholderQR& setThreshold(const RealScalar& threshold);
  ColPivHouseholderQR& setThreshold(Default_t);
  RealScalar threshold() const;
  
  // Additional information
  inline Index nonzeroPivots() const;
  RealScalar maxPivot() const;
  ComputationInfo info() const;
};
```

Key implementation details:
- Uses column pivoting to improve numerical stability
- Rank-revealing, suitable for rank-deficient matrices
- Balances numerical stability and performance
- Uses a column norm updating strategy to efficiently select pivots
- Provides threshold control to determine when a pivot is considered zero

### 3.3 FullPivHouseholderQR

`FullPivHouseholderQR` implements a QR decomposition with full pivoting:

```
P A Q = Q R
```

where:
- P and Q are permutation matrices
- Q is orthogonal/unitary
- R is upper triangular

```cpp
template<typename _MatrixType> class FullPivHouseholderQR : public SolverBase<FullPivHouseholderQR<_MatrixType>>
{
public:
  // Constructors
  FullPivHouseholderQR();
  FullPivHouseholderQR(Index rows, Index cols);
  template<typename InputType> explicit FullPivHouseholderQR(const EigenBase<InputType>& matrix);
  template<typename InputType> explicit FullPivHouseholderQR(EigenBase<InputType>& matrix);
  
  // Core functionality
  template<typename InputType> FullPivHouseholderQR& compute(const EigenBase<InputType>& matrix);
  
  // Matrix access
  MatrixQReturnType matrixQ() const;
  const MatrixType& matrixQR() const;
  const PermutationType& colsPermutation() const;
  const IntDiagSizeVectorType& rowsTranspositions() const;
  
  // Numerical properties
  typename MatrixType::RealScalar absDeterminant() const;
  typename MatrixType::RealScalar logAbsDeterminant() const;
  Index rank() const;
  Index dimensionOfKernel() const;
  bool isInjective() const;
  bool isSurjective() const;
  bool isInvertible() const;
  
  // Solving systems
  template<typename Rhs> inline const Solve<FullPivHouseholderQR, Rhs> solve(const MatrixBase<Rhs>& b) const;
  inline const Inverse<FullPivHouseholderQR> inverse() const;
  
  // Threshold control
  FullPivHouseholderQR& setThreshold(const RealScalar& threshold);
  FullPivHouseholderQR& setThreshold(Default_t);
  RealScalar threshold() const;
  
  // Additional information
  inline Index nonzeroPivots() const;
  RealScalar maxPivot() const;
};
```

Key implementation details:
- Uses both row and column pivoting for maximum numerical stability
- Most numerically stable QR variant but also the slowest
- Fully rank-revealing, suitable for ill-conditioned matrices
- Searches for the largest element in the entire remaining submatrix at each step
- Provides threshold control to determine when a pivot is considered zero

## 4. Singular Value Decomposition (SVD)

Eigen provides two SVD implementations with different trade-offs:

### 4.1 JacobiSVD

`JacobiSVD` implements a two-sided Jacobi SVD algorithm:

```
A = U S V*
```

where:
- U is orthogonal/unitary
- S is a diagonal matrix of singular values
- V is orthogonal/unitary

```cpp
template<typename _MatrixType, int QRPreconditioner> class JacobiSVD
 : public SVDBase<JacobiSVD<_MatrixType, QRPreconditioner>>
{
public:
  // Constructors
  JacobiSVD();
  JacobiSVD(Index rows, Index cols, unsigned int computationOptions = 0);
  template<typename InputType> explicit JacobiSVD(const EigenBase<InputType>& matrix, unsigned int computationOptions = 0);
  
  // Core functionality
  template<typename InputType> JacobiSVD& compute(const EigenBase<InputType>& matrix, unsigned int computationOptions);
  JacobiSVD& compute(const MatrixType& matrix) { return compute(matrix, m_computationOptions); }
  
  // Matrix access
  const MatrixUType& matrixU() const { return householderQ(); }
  HouseholderSequenceType householderQ() const;
  const MatrixType& matrixQR() const;
  const HCoeffsType& hCoeffs() const;
};
```

Key implementation details:
- Uses a two-sided Jacobi iteration to diagonalize the matrix
- Optionally uses QR decomposition as a preconditioner for rectangular matrices
- Very accurate, especially for computing small singular values
- Slower than bidiagonalization-based methods for large matrices
- Supports different QR preconditioners (ColPivHouseholderQR, FullPivHouseholderQR, HouseholderQR)

The implementation uses specialized algorithms for different matrix sizes:
```cpp
template<typename MatrixType, int QRPreconditioner, int Case, bool DoAnything>
struct qr_preconditioner_impl
{
  void allocate(const JacobiSVD<MatrixType, QRPreconditioner>&);
  bool run(JacobiSVD<MatrixType, QRPreconditioner>&, const MatrixType&);
};

template<typename MatrixType, int QRPreconditioner, bool IsComplex>
struct svd_precondition_2x2_block_to_be_real;
```

### 4.2 BDCSVD

`BDCSVD` implements a divide-and-conquer SVD algorithm:

```
A = U S V*
```

where:
- U is orthogonal/unitary
- S is a diagonal matrix of singular values
- V is orthogonal/unitary

```cpp
template<typename _MatrixType> class BDCSVD : public SVDBase<BDCSVD<_MatrixType>>
{
public:
  // Constructors
  BDCSVD();
  BDCSVD(Index rows, Index cols, unsigned int computationOptions = 0);
  template<typename InputType> explicit BDCSVD(const EigenBase<InputType>& matrix, unsigned int computationOptions = 0);
  
  // Core functionality
  template<typename InputType> BDCSVD& compute(const EigenBase<InputType>& matrix, unsigned int computationOptions);
  BDCSVD& compute(const MatrixType& matrix) { return compute(matrix, this->m_computationOptions); }
  
  // Configuration
  void setSwitchSize(int s);
};
```

Key implementation details:
- First reduces the matrix to bidiagonal form
- Uses a divide-and-conquer approach to compute the SVD of the bidiagonal matrix
- Uses JacobiSVD for small subproblems
- Much faster than JacobiSVD for large matrices
- Highly accurate, especially for computing small singular values
- Provides control over the switching size between divide-and-conquer and direct methods

The implementation uses specialized algorithms for different matrix sizes:
```cpp
void divide(Index firstCol, Index lastCol, Index firstRowW, Index firstColW, Index shift);
void computeSVDofM(Index firstCol, Index n, MatrixXr& U, VectorType& singVals, MatrixXr& V);
void computeSingVals(const ArrayRef& col0, const ArrayRef& diag, const IndicesRef& perm, 
                    VectorType& singVals, ArrayRef shifts, ArrayRef mus);
void perturbCol0(const ArrayRef& col0, const ArrayRef& diag, const IndicesRef& perm, 
                const VectorType& singVals, const ArrayRef& shifts, const ArrayRef& mus, ArrayRef zhat);
void computeSingVecs(const ArrayRef& zhat, const ArrayRef& diag, const IndicesRef& perm, 
                    const VectorType& singVals, const ArrayRef& shifts, const ArrayRef& mus, 
                    MatrixXr& U, MatrixXr& V);
```

## 5. Eigenvalue Decomposition

Eigen provides specialized eigensolvers for different matrix types:

### 5.1 SelfAdjointEigenSolver

`SelfAdjointEigenSolver` computes eigenvalues and eigenvectors of self-adjoint (symmetric/Hermitian) matrices:

```
A = V D V^{-1}
```

where:
- V is orthogonal/unitary
- D is a diagonal matrix of eigenvalues

```cpp
template<typename _MatrixType> class SelfAdjointEigenSolver
{
public:
  // Constructors
  SelfAdjointEigenSolver();
  explicit SelfAdjointEigenSolver(Index size);
  template<typename InputType> explicit SelfAdjointEigenSolver(const EigenBase<InputType>& matrix, int options = ComputeEigenvectors);
  
  // Core functionality
  template<typename InputType> SelfAdjointEigenSolver& compute(const EigenBase<InputType>& matrix, int options = ComputeEigenvectors);
  SelfAdjointEigenSolver& computeDirect(const MatrixType& matrix, int options = ComputeEigenvectors);
  SelfAdjointEigenSolver& computeFromTridiagonal(const RealVectorType& diag, const SubDiagonalType& subdiag, int options = ComputeEigenvectors);
  
  // Results access
  const EigenvectorsType& eigenvectors() const;
  const RealVectorType& eigenvalues() const;
  
  // Matrix functions
  MatrixType operatorSqrt() const;
  MatrixType operatorInverseSqrt() const;
  
  // Information
  ComputationInfo info() const;
  
  // Configuration
  SelfAdjointEigenSolver& setMaxIterations(Index maxIters);
  Index getMaxIterations();
};
```

Key implementation details:
- First reduces the matrix to tridiagonal form using Householder transformations
- Then computes eigenvalues and eigenvectors of the tridiagonal matrix using QR iterations
- Provides direct solvers for 2x2 and 3x3 matrices
- Sorts eigenvalues in increasing order
- Exploits symmetry for better performance and accuracy
- Returns real eigenvalues (guaranteed for self-adjoint matrices)

The implementation uses specialized algorithms for different matrix sizes:
```cpp
template<typename SolverType, int Size, bool IsComplex>
struct direct_selfadjoint_eigenvalues;

template<typename MatrixType, typename DiagType, typename SubDiagType>
ComputationInfo computeFromTridiagonal_impl(DiagType& diag, SubDiagType& subdiag, 
                                          const Index maxIterations, bool computeEigenvectors, 
                                          MatrixType& eivec);

template<int StorageOrder, typename RealScalar, typename Scalar, typename Index>
static void tridiagonal_qr_step(RealScalar* diag, RealScalar* subdiag, Index start, Index end, 
                              Scalar* matrixQ, Index n);
```

### 5.2 EigenSolver

`EigenSolver` computes eigenvalues and eigenvectors of general square matrices:

```
A = V D V^{-1}
```

where:
- V contains the eigenvectors
- D is a block diagonal matrix with the eigenvalues

```cpp
template<typename _MatrixType> class EigenSolver
{
public:
  // Constructors
  EigenSolver();
  explicit EigenSolver(Index size);
  template<typename InputType> explicit EigenSolver(const EigenBase<InputType>& matrix, bool computeEigenvectors = true);
  
  // Core functionality
  template<typename InputType> EigenSolver& compute(const EigenBase<InputType>& matrix, bool computeEigenvectors = true);
  
  // Results access
  EigenvectorsType eigenvectors() const;
  const EigenvalueType& eigenvalues() const;
  const MatrixType& pseudoEigenvectors() const;
  MatrixType pseudoEigenvalueMatrix() const;
  
  // Information
  ComputationInfo info() const;
  
  // Configuration
  EigenSolver& setMaxIterations(Index maxIters);
  Index getMaxIterations();
};
```

Key implementation details:
- First reduces the matrix to real Schur form using the RealSchur class
- Then computes eigenvalues and eigenvectors from the Schur form
- Handles complex eigenvalues and eigenvectors
- Returns complex eigenvalues for non-symmetric matrices
- Provides pseudo-eigendecomposition with real matrices for easier handling
- Less efficient than SelfAdjointEigenSolver for symmetric matrices

The implementation uses specialized algorithms:
```cpp
void doComputeEigenvectors();
```

## Implementation Patterns and Optimizations

### 1. Blocked Algorithms

Many decompositions use blocked algorithms to improve cache efficiency:
- Divide the matrix into blocks that fit in cache
- Process blocks to maximize data reuse
- Use different block sizes based on matrix dimensions and hardware

Example from PartialPivLU:
```cpp
for (Index k=0; k<size; k+=blockSize) {
  Index bs = (std::min)(size-k,blockSize);  // actual size of the block
  Index rs = size - k - bs;                 // trailing rows
  
  // Process the diagonal block with unblocked algorithm
  unblocked_lu(A11, ...);
  
  // Update the trailing submatrix
  A12 = A11.triangularView<UnitLower>().solve(A12);
  A22 -= A21 * A12;
}
```

### 2. Specialized Algorithms for Small Matrices

Eigen provides specialized implementations for small fixed-size matrices:
- Direct formulas for 2x2 and 3x3 matrices
- Unrolled loops for small matrices
- Compile-time optimizations for fixed-size matrices

Example from SelfAdjointEigenSolver:
```cpp
template<typename SolverType> struct direct_selfadjoint_eigenvalues<SolverType,2,false>
{
  static inline void run(SolverType& solver, const MatrixType& mat, int options)
  {
    // Direct formula for 2x2 symmetric eigenvalue problem
    const Scalar t0 = Scalar(0.5) * sqrt(numext::abs2(mat(0,0)-mat(1,1)) + Scalar(4)*numext::abs2(mat(1,0)));
    const Scalar t1 = Scalar(0.5) * (mat(0,0) + mat(1,1));
    solver.m_eivalues(0) = t1 - t0;
    solver.m_eivalues(1) = t1 + t0;
    
    // Compute eigenvectors if requested
    if(computeEigenvectors) {
      // Implementation details...
    }
  }
};
```

### 3. Numerical Stability Techniques

Eigen employs various techniques to enhance numerical stability:
- Pivoting strategies (partial, full) to reduce error propagation
- Scaling to avoid overflow/underflow
- Threshold-based rank determination
- Iterative refinement for improved accuracy
- Careful handling of edge cases (zero pivots, etc.)

Example from JacobiSVD:
```cpp
// Scaling factor to reduce over/under-flows
RealScalar scale = matrix.cwiseAbs().template maxCoeff<PropagateNaN>();
if (!(numext::isfinite)(scale)) {
  m_isInitialized = true;
  m_info = InvalidInput;
  return *this;
}
if(scale==RealScalar(0)) scale = RealScalar(1);
MatrixX copy = matrix / scale;
```

### 4. Lazy Evaluation and Expression Templates

Decomposition results are often computed lazily:
- Matrices U, V, etc. are computed only when requested
- Intermediate results are reused when possible
- Expression templates avoid unnecessary temporaries

Example from FullPivLU:
```cpp
template<typename DstXprType, typename MatrixType>
struct Assignment<DstXprType, Inverse<FullPivLU<MatrixType>>, internal::assign_op<...>, Dense2Dense>
{
  static void run(DstXprType &dst, const SrcXprType &src, const internal::assign_op<...> &)
  {
    // Compute inverse only when needed
    dst = src.nestedExpression().solve(MatrixType::Identity(src.rows(), src.cols()));
  }
};
```

### 5. Vectorization and Parallelization

Eigen leverages SIMD instructions and multi-threading:
- Vectorized inner loops for matrix operations
- Parallel implementations for large matrices
- Architecture-specific optimizations

Example from BDCSVD:
```cpp
// Structured update using vectorization
void structured_update(Block<MatrixXr,Dynamic,Dynamic> A, const MatrixXr &B, Index n1)
{
  // Implementation exploits sparsity pattern and uses vectorization
}
```

## Mathematical Principles and Applications

### 1. LU Decomposition

**Mathematical Principles:**
- Gaussian elimination with pivoting
- Forward and backward substitution for solving systems
- Determinant as product of diagonal elements

**Applications:**
- Solving linear systems: `A x = b`
- Computing matrix inverse: `A^{-1}`
- Computing determinant: `det(A)`
- Determining matrix rank and kernel

### 2. Cholesky Decomposition

**Mathematical Principles:**
- Exploits positive definiteness for more efficient factorization
- Square root-free variant (LDLT) for improved stability
- Rank-1 updates for incremental computation

**Applications:**
- Solving linear systems with symmetric positive-definite matrices
- Monte Carlo simulations (generating correlated random variables)
- Nonlinear optimization (Newton and quasi-Newton methods)
- Kalman filtering

### 3. QR Decomposition

**Mathematical Principles:**
- Householder reflections to zero out elements below diagonal
- Pivoting strategies for rank-revealing decompositions
- Orthogonal transformations preserve vector norms

**Applications:**
- Solving linear least squares problems
- Computing orthogonal bases for subspaces
- QR algorithm for eigenvalue computation
- Solving underdetermined systems

### 4. Singular Value Decomposition

**Mathematical Principles:**
- Bidiagonalization followed by diagonalization
- Divide-and-conquer approach for large matrices
- Jacobi iterations for high accuracy

**Applications:**
- Low-rank approximation
- Computing pseudoinverse
- Principal Component Analysis (PCA)
- Image compression
- Signal processing

### 5. Eigenvalue Decomposition

**Mathematical Principles:**
- Reduction to Hessenberg/tridiagonal form
- QR algorithm with shifts for eigenvalue computation
- Inverse iteration for eigenvectors
- Specialized algorithms for symmetric matrices

**Applications:**
- Vibration analysis
- Principal Component Analysis
- Spectral clustering
- Quantum mechanics
- Stability analysis of dynamical systems

## Referenced Context Files

The following files were analyzed to create this knowledge graph:

- `Eigen/src/LU/FullPivLU.h`: Implements LU decomposition with full pivoting
- `Eigen/src/LU/PartialPivLU.h`: Implements LU decomposition with partial pivoting
- `Eigen/src/LU/Determinant.h`: Implements determinant computation using LU decomposition
- `Eigen/src/LU/InverseImpl.h`: Implements matrix inversion using LU decomposition
- `Eigen/src/Cholesky/LLT.h`: Implements standard Cholesky decomposition
- `Eigen/src/Cholesky/LDLT.h`: Implements robust Cholesky decomposition with pivoting
- `Eigen/src/QR/HouseholderQR.h`: Implements QR decomposition using Householder reflections
- `Eigen/src/QR/FullPivHouseholderQR.h`: Implements QR decomposition with full pivoting
- `Eigen/src/QR/ColPivHouseholderQR.h`: Implements QR decomposition with column pivoting
- `Eigen/src/SVD/JacobiSVD.h`: Implements SVD using Jacobi iterations
- `Eigen/src/SVD/BDCSVD.h`: Implements SVD using bidiagonalization and divide-and-conquer
- `Eigen/src/Eigenvalues/SelfAdjointEigenSolver.h`: Implements eigendecomposition for symmetric/Hermitian matrices
- `Eigen/src/Eigenvalues/EigenSolver.h`: Implements eigendecomposition for general matrices