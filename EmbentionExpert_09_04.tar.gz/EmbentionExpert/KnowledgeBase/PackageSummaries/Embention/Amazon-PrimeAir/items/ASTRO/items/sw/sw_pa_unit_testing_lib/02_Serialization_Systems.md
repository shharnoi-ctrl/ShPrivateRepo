# Generated from:

- include/serialization/Recovery_wrapper_output_serialization_test.h (206 tokens)
- include/serialization/Serialization_test.h (595 tokens)
- include/serialization/Recovery_wrapper_input_serialization_test.h (279 tokens)
- include/Protobuf/protobuf_test.h (277 tokens)
- source/serialization/Serialization_test.cpp (6786 tokens)
- source/serialization/Recovery_wrapper_input_serialization_test.cpp (12051 tokens)
- source/serialization/Recovery_wrapper_output_serialization_test.cpp (20207 tokens)
- source/Protobuf/protobuf_test.cpp (3387 tokens)
- source/controllers/Protobuf_smoke_test.cpp (950 tokens)
- include/controllers/Protobuf_smoke_test.h (51 tokens)
- data/serialization/txt/vms_monitored_data.txt (145 tokens)
- data/serialization/txt/meas_ground_lidar_msg.txt (36 tokens)
- data/serialization/txt/recovery_telemetry_msg.txt (104 tokens)
- data/serialization/txt/meas_accel_gyro_compact.txt (68 tokens)
- data/serialization/txt/meas_dynamic_pressure_single_msg.txt (41 tokens)
- data/serialization/txt/nav_introspect_compact_msg.txt (602 tokens)
- data/serialization/txt/meas_static_pressure_msg.txt (33 tokens)
- data/serialization/txt/state_estimate_compact_msg.txt (151 tokens)

## With context from:

- Amazon-PrimeAir/items/ASTRO/items/sw/sw_pa_unit_testing_lib/03_Mission_Planning.md (3930 tokens)

---

# Drone Serialization Systems: Comprehensive Summary

This document provides a detailed analysis of the drone serialization framework, focusing on how the system handles binary data serialization/deserialization for various message types and validates protobuf-encoded mission plans.

## 1. Serialization Test Framework Architecture

The serialization framework implements a consistent pattern of create-serialize-deserialize-compare to validate data integrity across serialization boundaries. This pattern is critical for ensuring reliable communication between system components.

### 1.1 Core Testing Pattern

The framework follows a consistent testing methodology:

1. **Create**: Instantiate a message object with known values
2. **Serialize**: Convert the object to binary representation
3. **Deserialize**: Parse the binary data back into an object
4. **Compare**: Verify the deserialized object matches the original

This pattern is implemented across multiple test classes:
- `Serialization_test`: Tests basic message types
- `Recovery_wrapper_input_serialization_test`: Tests recovery system input messages
- `Recovery_wrapper_output_serialization_test`: Tests recovery system output messages
- `Protobuf_unit_test`: Tests protobuf mission plan encoding/decoding

### 1.2 Binary Data Handling

The framework uses several key classes for binary data manipulation:

- **`Base::Lossy`**: Core serialization stream that handles endianness and data alignment
- **`Base::Mblock<Uint16>`**: Memory block for storing serialized data
- **`Binary_io`**: Utility for reading/writing binary files
- **`Serialization_test_utils`**: Helper functions for common serialization operations

Example of binary data handling:
```cpp
// Serialize an object to binary
Base::Lossy str(Ku32::u512, Base::Memmgr::external);
object.cget(str);

// Deserialize from binary back to object
str.reuse();
deserialized_object.cset(str);
```

## 2. Message Type Serialization

The framework tests serialization for a wide range of message types, each with specific serialization requirements.

### 2.1 State and Telemetry Messages

#### 2.1.1 VMS Monitored Data

`Vms_monitored_data` contains critical vehicle mission state information:
- Unique message ID
- Mission validity flags
- Geographic coordinates (takeoff and delivery points)
- Mission phase information
- Contingency action status

Serialization includes boolean flags, geographic coordinates, and enumerated types:
```cpp
str.put_bool1(obj.has_valid_mission_been_received);
str.put_bool1(obj.is_mission_plan_delivery_point_available);
str.align_bytes();
Cyphal_common_types::serialize_tllh(obj.takeoff_ground_point_lla, str);
```

#### 2.1.2 Recovery Telemetry

`Recovery_telemetry` contains flight state information from the recovery system:
- Geographic position (latitude, longitude, altitude)
- Speed information (airspeed, ground speed)
- Control status flags
- Flight phase tracking

The serialization preserves high-precision floating-point values:
```cpp
ret &= EXPECT_NEAR(obj.latitude_rad, 0.829861640697, 1E-9);
ret &= EXPECT_NEAR(obj.longitude_rad, -2.1350892082826, 1E-9);
```

#### 2.1.3 State Estimate Compact

`State_estimate_compact` contains the vehicle's estimated state:
- Position (latitude, longitude, altitude)
- Velocity vector
- Orientation quaternion
- Air data (dynamic pressure, air density)
- Status flags for various subsystems

The serialization handles quaternions and status enumerations:
```cpp
ret &= EXPECT_NEAR(obj.q_ned_from_vf[0U], 0.77188104391098F, Comparison_constants::k_near_eq_tol);
ret &= EXPECT_TRUE(obj.status_posvel_horiz == static_cast<State_estimate_field_status::Type>(2));
```

### 2.2 Sensor Measurements

#### 2.2.1 IMU Data

`Measurements::Imu` contains accelerometer and gyroscope readings:
- Timestamp
- Acceleration vector (3D)
- Angular velocity vector (3D)
- Sensor status flags

The serialization handles high-frequency sensor data with nanosecond timestamps:
```cpp
obj.time_s = Base::Ttime(str.get_float64() * Const::E1000000000);
Cyphal_common_types::deserialize_float32_fixed_array(obj.f, str);
Cyphal_common_types::deserialize_float32_fixed_array(obj.w, str);
```

#### 2.2.2 Pressure Sensors

The framework tests both dynamic and static pressure sensors:
- `Measurements::Meas_dyn_pressure_single`: Air pressure for airspeed calculation
- `Measurements::Meas_static_pressure`: Atmospheric pressure for altitude calculation

Serialization includes pressure values and validity flags:
```cpp
ret &= EXPECT_NEAR(obj.data.pressure_Pa, 33.1811637878418F, Comparison_constants::k_near_eq_tol);
ret &= EXPECT_TRUE(obj.data.is_valid == true);
```

#### 2.2.3 Ground Lidar

`Measurements::Meas_ground_lidar` contains ground distance measurements:
- Distance to ground
- Return signal strength

The serialization handles centimeter-precision measurements:
```cpp
ret &= EXPECT_NEAR(obj.data.last_z_lidar_lidar2target_m, 59.0F * Const::CM2M, Comparison_constants::k_near_eq_tol);
```

### 2.3 Control System Messages

#### 2.3.1 Controller Commands

`MonRec_controller_command` contains commands for the recovery controller:
- Command type (takeoff, land, etc.)
- Takeoff parameters
- Landing parameters
- Route information
- Deviation parameters

The serialization handles complex nested structures:
```cpp
str.put_uint64(obj.id.id);
str.put_uint32(static_cast<Uint8>(obj.controller_cmd_seq_id));
str.put_uint8(static_cast<Uint8>(obj.command_type.type));
str.put_float64(obj.takeoff_command.takeoff_agl_m);
```

#### 2.3.2 Motor Commands

`Motor_rpm_cmd` contains motor control commands:
- RPM values for each motor
- Motor state requests (enable/disable, arm/disarm)

The serialization handles arrays of motor commands:
```cpp
for (Uint16 ii = Ku16::u0; ii < Motor_rpm_cmd::num_motors; ++ii) {
    ret &= EXPECT_EQ(m.rpm_commands[ii], m_round_trip.rpm_commands[ii]);
}
```

#### 2.3.3 Recovery Controller Telemetry

`Recovery_controller_telemetry` contains extensive controller state information:
- State estimator data
- Controller parameters
- Force and torque requests
- Mission phase tracking
- Route construction status

This is one of the most complex messages, with deep nesting and many fields:
```cpp
Cyphal_common_types::deserialize_float32_fixed_array(m_round_trip.recovery_controllers_telemetry.sep.q_trim0ncg_from_vtolncg, str);
Cyphal_common_types::deserialize_float32_fixed_array(m_round_trip.recovery_controllers_telemetry.sep.q_est_vtolncg_from_ned, str);
```

## 3. Mission Plan Protobuf Serialization

The framework includes specialized testing for protobuf-encoded mission plans, which represent the most complex serialized structures in the system.

### 3.1 Protobuf Testing Architecture

The `Protobuf_unit_test` class tests the serialization and deserialization of mission plans using Google Protocol Buffers:

```cpp
bool Protobuf_unit_test::test_all() {
    const Uint32 n_missions = Ku32::u10;
    const std::string missions_names[n_missions] = {
        "0dbe532e-3783-4b3d-8ced-e687dc2d224a.pb",
        "1e773572-4295-4b6b-8b19-2ced83758b1f.pb",
        // Additional mission files...
    };
    
    for (Uint32 ii = Ku32::u0; ii < n_missions; ++ii) {
        // Test each mission file
        Protobuf_reader mission_parser(missions_names[ii]);
        // Parse binary file
        // Validate against reference JSON
    }
}
```

### 3.2 Mission Plan Validation

The framework validates mission plans by:
1. Reading binary protobuf data from files
2. Parsing the binary data into mission plan objects
3. Comparing against reference JSON data for correctness

Key validation checks include:
- Version information
- Reference time
- Environmental parameters
- Vehicle parameters
- Coordinate reference system
- Bounding volumes
- Initial flight plan
- Alternate plans

```cpp
bool Protobuf_reader::check_mission_content(const Mission_plan_msg::Mission& parsed_mission, bool verbose) {
    // Parse reference JSON
    Json::Value obj;
    reader.parse(file, obj);
    
    // Check version
    ret &= EXPECT_TRUE(Protobuf_test_utils::check_version(parsed_mission.version_.value, obj["version"]));
    
    // Check environment
    ret &= EXPECT_TRUE(Protobuf_test_utils::check_environment(parsed_mission.environment_.value, obj["environment"]));
    
    // Check vehicle parameters
    ret &= EXPECT_TRUE(Protobuf_test_utils::check_vehicle_parameters(parsed_mission.vehicle_parameters_.value, obj["vehicle_parameters"]));
    
    // Additional checks...
}
```

### 3.3 Mission Plan Data Structure

The mission plans contain hierarchical data structures:
- Top-level mission metadata
- Coordinate reference system
- Initial flight plan with sequenced mission steps
- Alternate plans for contingencies
- Environmental parameters
- Vehicle performance parameters

The framework validates the correct serialization of this complex structure, ensuring all fields are preserved across the serialization boundary.

## 4. Error Handling and Validation

The serialization framework implements robust error handling and validation:

### 4.1 Validation Mechanisms

- **Equality Checks**: Simple value comparison for integers and booleans
- **Near-Equality Checks**: Floating-point comparison with tolerance
- **Array Equality**: Element-by-element comparison for arrays and vectors
- **Structure Validation**: Field-by-field comparison for complex structures

```cpp
ret &= EXPECT_EQ(m.id.id, m_round_trip.id.id);  // Exact equality
ret &= EXPECT_NEAR(obj.latitude_rad, 0.797653, Comparison_constants::k_near_eq_tol);  // Near equality
ret &= EXPECT_TRUE(Utils::are_equal(m.v_ned_ned2vf_m_per_s, m_round_trip.v_ned_ned2vf_m_per_s));  // Array equality
```

### 4.2 Error Reporting

The framework provides detailed error reporting:
- Test name and ID
- Expected vs. actual values
- Pass/fail status for each test
- Summary of all test results

```cpp
std::cout << "Test " << ii << ": " << tests_names[ii] << " - ";
if (individual_result[ii]) {
    std::cout << "PASSED";
} else {
    if (tests_to_xfail[ii]) {
        std::cout << "X-FAIL";
    } else {
        std::cout << "FAILED";
    }
}
```

### 4.3 Known Failure Handling

The framework handles known failures with an "X-FAIL" mechanism:
```cpp
Base::Tnarray<bool, n_tests> tests_to_xfail;
tests_to_xfail.set_all(false);
tests_to_xfail[Ku16::u5] = true;  // Mark test 5 as expected to fail
```

## 5. Serialization Utilities and Helpers

The framework includes several utility classes and functions to facilitate serialization testing:

### 5.1 Serialization Test Utils

The `Serialization_test_utils` namespace provides helper functions:
```cpp
// Execute deserialization from file to object
template<typename T>
bool execute_deserialization(std::string filename, T& obj) {
    Pa_blocks::Binary_io reader(filename);
    bool ret = reader.readFile();
    if (ret) {
        Base::Lossy str(reader.getSize(), Base::Memmgr::external);
        str.set_endian(Base::endian_little);
        reader.parse_data(str);
        obj.cset(str);
        ret &= str.size() == reader.getSize();
    }
    return ret;
}

// Execute serialization from object to file
template<typename T>
bool execute_serialization(std::string filename_in, std::string filename_out, T& obj) {
    // Implementation...
}
```

### 5.2 Binary I/O

The `Binary_io` class handles reading and writing binary files:
```cpp
bool Protobuf_reader::open_file(Base::Mblock<Uint16>& buffer, std::string filename, Uint32& file_sz) {
    Base::Lossy str(buffer);
    std::ifstream myfile(filename, std::ios::binary);
    myfile.seekg(0, std::ios::end);
    file_sz = static_cast<Uint32>(myfile.tellg());
    myfile.seekg(0, std::ios::beg);
    std::vector<char> somedata(file_sz);
    myfile.read(somedata.data(), file_sz);
    // Copy data to buffer...
}
```

### 5.3 Type-Specific Serialization Helpers

The framework includes helpers for specific data types:
```cpp
// Serialize quaternion
Cyphal_common_types::serialize_float32_fixed_array(obj.q_ned_from_vf, str);

// Serialize geographic coordinates
Cyphal_common_types::serialize_tllh(obj.takeoff_ground_point_lla, str);

// Serialize boolean array
Cyphal_common_types::serialize_bool16(obj.is_left_probe_healthy, str);
```

## 6. Data Flow and Serialization Boundaries

The serialization framework tests data flow across several key system boundaries:

### 6.1 Recovery System Interface

The recovery system has well-defined input and output interfaces:

**Inputs:**
- Controller commands
- Mission reset commands
- State estimates
- Battery information
- Mission phase notifications
- Mission plans
- Contingency commands

**Outputs:**
- Recovery alerts
- Recovery telemetry
- Motor RPM commands
- Controller telemetry
- Mission readiness signals
- Pre-flight check status

### 6.2 Sensor Data Flow

Sensor data follows a consistent flow:
1. Raw sensor readings are serialized into compact messages
2. Messages are transmitted between components
3. Receiving components deserialize and process the data
4. Processed data is serialized into state estimates
5. State estimates are transmitted to control systems

### 6.3 Mission Plan Processing

Mission plans follow a complex flow:
1. Protobuf-encoded mission plan is received
2. Plan is deserialized and validated
3. Plan is processed into internal route structures
4. Route commands are serialized and sent to controllers
5. Execution status is serialized and reported back

## 7. Critical Serialization Patterns

The framework reveals several critical patterns in the serialization system:

### 7.1 Compact Representation

Many messages use compact representations to minimize bandwidth:
- Fixed-point encoding for some floating-point values
- Bit-level packing for boolean flags
- Enumeration types for state values
- Alignment padding for efficient memory access

```cpp
str.put_ubits(static_cast<Uint64>(obj.input_voltage_dV), Ku16::u10);  // 10-bit encoding
str.put_bool1(obj.is_on_external_power);  // Single-bit boolean
str.align_bytes();  // Alignment padding
```

### 7.2 Nested Structure Handling

Complex messages with deep nesting require careful serialization:
```cpp
// Serialize nested structure
void serialize_MonRec_controller_command(const MonRec_controller_command& obj, Base::Lossy& str) {
    str.put_uint64(obj.id.id);
    // Serialize takeoff command
    str.put_float64(obj.takeoff_command.takeoff_agl_m);
    Cyphal_common_types::serialize_tllh(obj.takeoff_command.initial_tracking_point, str);
    // Serialize initial velocity
    str.put_float64(obj.takeoff_command.initial_velocity.velocity_east_m_per_s);
    str.put_float64(obj.takeoff_command.initial_velocity.velocity_north_m_per_s);
    str.put_float64(obj.takeoff_command.initial_velocity.velocity_up_m_per_s);
    // Additional fields...
}
```

### 7.3 Versioned Protocol Support

The system supports multiple protocol versions, particularly for mission plans:
- Version 3.0 includes vehicle parameters in the mission plan
- Version 4.0 moves vehicle parameters out of the mission plan

```cpp
// Check version-specific fields
if (obj["version"]["major_version"] == 4) {
    if (obj.isMember("takeoff_bounding_volume")) {
        ret &= EXPECT_TRUE(parsed_mission.bounding_volume_.is_present());
    }
}
```

## 8. Importance of Serialization Framework

The serialization framework is critical to system reliability for several reasons:

1. **Data Integrity**: Ensures data is preserved exactly across component boundaries
2. **Protocol Compatibility**: Validates that all components interpret messages consistently
3. **Error Detection**: Identifies serialization bugs before they affect flight operations
4. **Performance Optimization**: Enables efficient binary encoding of complex data structures
5. **System Evolution**: Supports versioned protocols as the system evolves

The comprehensive test coverage across message types provides confidence in the system's ability to maintain data integrity during mission-critical operations.

## Referenced Context Files

The following context files provided valuable information for this summary:

- `include/serialization/Recovery_wrapper_output_serialization_test.h`: Defines tests for recovery system output messages
- `include/serialization/Serialization_test.h`: Core serialization test framework
- `include/serialization/Recovery_wrapper_input_serialization_test.h`: Defines tests for recovery system input messages
- `include/Protobuf/protobuf_test.h`: Defines tests for protobuf mission plan serialization
- `source/serialization/Serialization_test.cpp`: Implements tests for basic message types
- `source/serialization/Recovery_wrapper_input_serialization_test.cpp`: Implements tests for recovery input messages
- `source/serialization/Recovery_wrapper_output_serialization_test.cpp`: Implements tests for recovery output messages
- `source/Protobuf/protobuf_test.cpp`: Implements tests for protobuf mission plans
- `source/controllers/Protobuf_smoke_test.cpp`: Implements basic functionality tests for protobuf parsing
- `include/controllers/Protobuf_smoke_test.h`: Defines protobuf smoke tests
- Various data files containing serialized message examples