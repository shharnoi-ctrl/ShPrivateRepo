# Generated from:

- _sw_Veronte/code/vblocks/code/include/Blk_nav.h (1428 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_nav.cpp (2223 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_pnav.h (303 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_pnav.cpp (386 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_pnav_base.h (607 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_pnav_base.cpp (558 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_modpnav.h (410 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_modpnav.cpp (870 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_ekfalt.h (821 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_ekfalt.cpp (1255 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_ekfdem.h (898 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_ekfdem.cpp (689 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_ekfmis.h (1755 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_ekfmis.cpp (3078 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_ekfpos.h (1070 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_ekfpos.cpp (1662 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_ekfsplit.h (513 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_ekfsplit.cpp (855 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_ekfstp.h (1377 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_ekfstp.cpp (2032 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_ekfvel.h (993 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_ekfvel.cpp (1999 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_ekfvdn.h (948 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_ekfvdn.cpp (1192 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_ekfadapter.h (826 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_ekfadapter.cpp (1130 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_drnmis.h (718 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_drnmis.cpp (1547 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_wind.h (1539 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_wind.cpp (2544 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_magfield.h (616 tokens)
- _sw_Veronte/code/vblocks/code/source/Blk_magfield.cpp (317 tokens)
- _sw_Veronte/code/vblocks/code/include/Fix_validity.h (427 tokens)
- _sw_Veronte/code/vblocks/code/source/Fix_validity.cpp (610 tokens)

## With context from:

- PackageSummaries/Embention/Amazon-PrimeAir/items/ASTRO/items/sw/sw_Astro/items/04_VBlocks_Core.md (5729 tokens)
- PackageSummaries/Embention/Amazon-PrimeAir/items/ASTRO/items/sw/sw_Astro/items/03_VBlocks_Sensor_Blocks.md (9064 tokens)

---

# Navigation and State Estimation in VBlocks Library

This comprehensive analysis examines the Extended Kalman Filter (EKF) implementation and related navigation blocks in the VBlocks library, focusing on how sensor measurements are processed to estimate the UAV's state.

## 1. Navigation Block Architecture (Blk_nav)

The `Blk_nav` class is the central navigation block that receives processed sensor information and computes the current state estimation.

### 1.1 Core Components

```cpp
class Blk_nav : public Blocks::Iblock {
public:
    Blk_nav(Vpgnc::Vpunav& vpu0,
            const volatile Base::Hmeasnavsim& navsim0,
            const volatile Base::Hmeasnav& navext0,
            const volatile Base::Hmeasnav& rvn3000,
            const volatile Base::Hmeasnav& navextsen0,
            Base::Allocator& alloc0,
            Base::Checklist& ini_chlist);
    
    // Methods
    virtual void on_focus();
    virtual void step();
    virtual const Blocks::Ipin* get_out(Uint16 i) const;
    virtual void cset(Base::Lossy_error& str, Csetpm& params);

private:
    // Input Manager for EKF inputs
    class Inputmgr {
        // Methods and members for managing EKF inputs
    };

    static bool first;                       // Block already exists flag
    Vpgnc::Vpunav& vpu;                      // Reference to UAV's state
    const Base::Evar<Base::Navtype> nav_cmd; // Navigation requested by command
    Base::Navtype prev_nav_cmd;              // Previous navigation requested by command

    // Navigation source getters
    Base::Mreadernavsim rsim;                // Simulated navigation getter
    Base::Mreadernav rext;                   // External navigation getter
    Base::Mreadernav rvn300;                 // VectorNav VN-300 navigation getter
    Base::Mreadernav rextsen;                // External sensor navigation getter

    Inputmgr inmgr;                          // EKF inputs manager
    Blocks::Pin<Uint16> sensel;              // Output indicating used sensor in current step

    Base::Chrono clk;                        // Chrono for computing EKF time increments
    Vpgnc::Navextvar navextvar;              // External variable navigation getter
    Vpgnc::Posfix pfix;                      // Manager for position fix bit

    void step_ekf(const Real dt);            // EKF step method
};
```

### 1.2 Navigation Source Selection

The `Blk_nav` block can update the navigation state according to different sources:

1. **Internal EKF** (`Base::nav_ekf`): Uses processed measurements to compute navigation estimation
2. **Simulated Navigation** (`Base::nav_sim_state`): Uses simulated navigation data
3. **External Navigation** (`Base::nav_external`): Uses external navigation data
4. **Navigation from System Variables** (`Base::nav_ext_var`): Uses navigation data from system variables
5. **Navigation from VectorNAV VN-300** (`Base::nav_vn300`): Uses VN-300 navigation data
6. **External Sensor Navigation** (`Base::nav_extsen`): Uses external sensor navigation data

The navigation source is selected through the `nav_cmd` variable, which is bound to the system variable `Base::vu_nav_source`.

### 1.3 EKF Input Manager

The `Inputmgr` class manages inputs to the EKF:

```cpp
class Inputmgr {
public:
    Inputmgr();
    void clear();                                      // Clears all cached EKF inputs
    const Gnc::Irainsld::Rawposvel& update_posvel();   // Updates position and velocity data
    Uint16 step(const bool is_full, Gnc::Irainsld::Data& ldat); // Processes inputs and loads data
    Base::Mblock<const Gnc::Irainsld::Alig_data*> get_alignment(); // Gets alignment sensors
    bool cset(Base::Lossy_error& str, Csetpm& params); // Deserializes from PDI

private:
    Base::Dynarray<Blocks::Pin_ptr<Gnc::Irainsld> > ins;  // Inputs to the EKF
    Base::Dynarray<const Gnc::Irainsld*> update_list;     // List of inputs for update
    Base::Dynarray<const Gnc::Irainsld::Alig_data*> alig; // List for alignment update
    Uint32 alig_size;                                     // Number of elements for alignment update
    Gnc::Irainsld::Rawposvel pv;                          // Last raw position and velocity measurements
};
```

The `Inputmgr` handles:
1. Storing references to EKF input blocks
2. Determining which inputs have new data
3. Selecting the highest priority input for the current step
4. Collecting alignment data from sensors
5. Managing position and velocity fix information

### 1.4 Navigation Block Execution Flow

The `step()` method implements the main execution flow:

```cpp
void Blk_nav::step() {
    const Real dt = clk.step();
    sensel.val = 0U;
    const Base::Navtype nav = nav_cmd.get();
    
    switch (nav) {
        case Base::nav_ekf:
            // Internal EKF navigation
            if (prev_nav_cmd != Base::nav_ekf) {
                inmgr.clear();
                vpu.relekf.reset_from_external();
            }
            step_ekf(dt);
            pfix.step_ekf();
            break;
            
        case Base::nav_sim_state:
            // Simulated navigation
            pfix.step_sim();
            vpu.step_nav_sim_state(rsim, dt);
            break;
            
        case Base::nav_external:
            // External navigation
            pfix.step_ext();
            vpu.step_nav_ext_state(rext, dt);
            break;
            
        case Base::nav_ext_var:
            // Navigation from system variables
            navextvar.step();
            pfix.step_ext_var();
            vpu.step_nav_extvar_state(dt);
            break;
            
        case Base::nav_vn300:
            // Navigation from VectorNAV VN-300
            pfix.step_ext_vn300();
            vpu.step_nav_ext_sensor(rvn300, dt);
            break;
            
        case Base::nav_extsen:
            // Navigation from external sensor
            pfix.step_ext_sen();
            vpu.step_nav_ext_sensor(rextsen, dt);
            break;
    }
    
    prev_nav_cmd = nav;
}
```

### 1.5 EKF Step Processing

The `step_ekf()` method handles the EKF update process:

```cpp
void Blk_nav::step_ekf(const Real dt) {
    static Bsp::Hbvar ins_nav(Base::kbit_insnav);  // INS or full EKF bit

    // Update position fix status based on available position measurements
    vpu.relekf.compute_posfix(inmgr.update_posvel());
    
    // Set INS/full EKF mode bit
    ins_nav.set(!vpu.relekf.is_xfull());

    // Process all inputs to check for updates
    sensel.val = inmgr.step(vpu.relekf.is_xfull(), vpu.relekf.ldat);
    
    // Get alignment data from sensors
    const Base::Mblock<const Gnc::Irainsld::Alig_data*> alig = inmgr.get_alignment();

    if (vpu.get_init_alignment_done()) {
        // If initial alignment is complete, run normal EKF
        vpu.step_attins(dt, vpu.relekf.is_xfull(), alig);
        vpu.relekf.step(dt);

        if (sensel.val) {
            // If a sensor was used in this step, load its data
            vpu.relekf.load();
            vpu.on_ekf_load(vpu.relekf);
        }

        vpu.post_ekf(dt);
        vpu.relekf.commit_variances();
    }
    else {
        // If initial alignment is not complete, try to perform it
        if (alig.size() > 0U) {
            vpu.alignment(alig[0U]->vb_raw, alig[0U]->vn_raw);
        }
    }
}
```

## 2. EKF Sensor Input Blocks

The VBlocks library provides several blocks that process sensor measurements and feed them into the EKF.

### 2.1 Common Interface: Irainsld

All EKF input blocks implement the `Gnc::Irainsld` interface:

```cpp
class Irainsld {
public:
    // Data structure for EKF input
    struct Data {
        Uint16 ny;                // Size of measurement
        bool aglmea;              // True if this is an AGL measurement
        Maverick::Rvector3 y;     // Measurement vector
        Maverick::Rvector3 R;     // Measurement variance
        Maverick::Rvector3 kappa; // Safety parameter for measurements far from current state
        
        // Observation matrices for different state components
        struct {
            Maverick::Rmatrix3 drn;  // Position observation matrix
            Maverick::Rmatrix3 dvn;  // Velocity observation matrix
            Maverick::Rmatrix3 mis;  // Misalignment observation matrix
            Maverick::Rmatrix3 dwb;  // Angular velocity bias observation matrix
            Maverick::Rmatrix3 dfb;  // Specific force bias observation matrix
        } H;
        
        void zeros();  // Initialize all values to zero
    };
    
    // Structure for alignment data
    struct Alig_data {
        Maverick::Rvector3 vn_raw;    // Raw measurement in NED frame
        Maverick::Rvector3 vb_raw;    // Raw measurement in body frame
        Maverick::Rvector3 vn;        // Normalized measurement in NED frame
        Maverick::Rvector3 vbn;       // Normalized body measurement rotated to NED frame
        Real mgd_gain;                // Madgwick gain
    };
    
    // Structure for raw position and velocity data
    struct Rawposvel {
        bool pos_fix;             // True if there is position fix
        bool vel_fix;             // True if there is velocity fix
        Geo::Apos pos;            // Position measurement
        Maverick::Rvector3 vel;   // Velocity measurement
        Real e2v;                 // Vertical position variance
        
        void clear();
        void set_pos_fix(const Geo::Apos& pos0, const Real e2v0);
        void set_vel_fix(const Maverick::Rvector3& vel0);
    };
    
    Irainsld(const bool use_reduced0);
    virtual ~Irainsld();
    
    bool get_is_new() const;
    bool get_use_reduced() const;
    virtual bool valid() const;
    virtual void load(Data& d0) const = 0;
    virtual const Alig_data* get_alignment() const;
    virtual void update_posvel(Rawposvel& pv) const;
    
protected:
    bool is_new;                // True if there is a new measurement
    const bool use_reduced;     // True if this sensor can be used in reduced mode
};
```

This interface defines:
1. The `Data` structure for EKF measurements, including observation matrices and variances
2. The `Alig_data` structure for alignment data
3. The `Rawposvel` structure for raw position and velocity data
4. Methods for loading data into the EKF and checking validity

### 2.2 Altimeter EKF Block (Blk_ekfalt)

The `Blk_ekfalt` block loads altimeter measurements into the EKF:

```cpp
class Blk_ekfalt : public Blocks::Iblock, public Gnc::Irainsld {
public:
    Blk_ekfalt(const Dynamics::Rigidbody& body0);
    
    virtual void step();
    virtual const Blocks::Ipin* get_out(Uint16 i) const;
    virtual void cset(Base::Lossy_error& str, Csetpm& params);
    virtual void load(Data& d0) const;

private:
    const Dynamics::Rigidbody& body;  // Reference to body (for tilt check)
    Stepdec dec;                      // Measurement decimation
    
    bool lim_h;                       // Measured altitude limit function enabled
    Real height_min;                  // Minimum measured altitude
    Real height_max;                  // Maximum measured altitude
    
    bool lim_tilt;                    // Tilt limit function enabled
    Real tilt_max;                    // Maximum angle to use measurement
    
    bool correct_tilt;                // True if pitch/roll tilt shall be corrected
    Maverick::Rvector3 gl;            // Vector from g to sensor l (body frame)
    
    Real rng;                         // Last correct range measurement
    Real e2;                          // Variance of last correct range measurement
    
    Pin_ptr_watch<Signals::Alt::Mea> in;  // Input altitude measurement
    Blocks::Pin_ptr_opt<bool> enable;      // Input to enable/disable block
    Blocks::Pin<Gnc::Irainsld&> out;       // Output DEM measurement data
    
    bool on_range(const Real agl0) const;  // Checks if altitude is within range
};
```

Key features:
1. Processes altimeter measurements with configurable limits for height and tilt
2. Can correct measurements for sensor position and tilt
3. Provides altitude measurements to the EKF

### 2.3 Terrain EKF Block (Blk_ekfdem)

The `Blk_ekfdem` block loads terrain height measurements into the EKF:

```cpp
class Blk_ekfdem : public Blocks::Iblock, public Gnc::Irainsld {
public:
    Blk_ekfdem(const Dynamics::Rigidbody& body0);
    
    virtual void step();
    virtual const Blocks::Ipin* get_out(Uint16 i) const;
    virtual void cset(Base::Lossy_error& str, Csetpm& params);
    virtual void load(Data& d0) const;

private:
    const Dynamics::Rigidbody& body;  // Reference to body
    
    Real h;                           // Last correct DEM measurement
    Real e2;                          // Last correct DEM measurement variance
    
    Stepdec dec;                      // Measurement decimation
    
    Pin_ptr_watch<Signals::Dem::Mea> in;   // Input DEM measurement
    Blocks::Pin_ptr_opt<bool> enable;       // Input to enable/disable block
    Blocks::Pin<Gnc::Irainsld&> out;        // Output DEM measurement data
};
```

Key features:
1. Processes terrain height measurements
2. Provides terrain height measurements to the EKF for AGL (Above Ground Level) estimation

### 2.4 Misalignment EKF Block (Blk_ekfmis)

The `Blk_ekfmis` block processes misalignment measurements for attitude estimation:

```cpp
class Blk_ekfmis : public Blocks::Iblock, public Gnc::Irainsld {
public:
    Blk_ekfmis(const Dynamics::Rigidbody& body0);
    
    virtual void on_focus();
    virtual void step();
    virtual const Blocks::Ipin* get_out(Uint16 i) const;
    virtual void cset(Base::Lossy_error& str, Csetpm& params);
    virtual bool valid() const;
    virtual void load(Data& d0) const;
    virtual const Alig_data* get_alignment() const;

private:
    const Dynamics::Rigidbody& body;  // Reference to current state
    
    Stepdec dec;                      // Measurement decimation
    
    bool use3d;                       // True if measurements affect pitch and roll
    Real minnorm;                     // Minimum norm to consider measurements as OK
    Real ndthr;                       // Normalized norm difference threshold
    
    Base::Timeout mea_timeout;        // Time out for measurements
    Gnc::Irainsld::Alig_data alig;    // Data for alignment
    Real e2;                          // Variance of combined measurement
    Gnc::Madgwick::Gain mdggain;      // Madgwick measurement gain computer
    
    Pin_ptr_watch<Signals::Mis::Mea> in_nedmea;   // Measurement in NED frame
    Pin_ptr_watch<Signals::Mis::Mea> in_bodymea;  // Measurement in Body frame
    Blocks::Pin_ptr_opt<bool> enable;              // Input to enable/disable block
    Blocks::Pin<Gnc::Irainsld&> out;               // Output EKF measurement data
    Blocks::Pin<bool> ok;                          // Last measurement was OK
    Blocks::Pin<Real> norm_err;                    // Normalized norm error
    
    bool update_ready();              // Checks if there is an update in measurements
};
```

Key features:
1. Takes the same 3D measurement (with variance) in two reference systems: body and NED
2. Computes attitude estimation corrections
3. Can operate in 2D mode (affecting only yaw) or 3D mode (affecting pitch, roll, and yaw)
4. Provides alignment data for initial attitude determination

### 2.5 Position EKF Block (Blk_ekfpos)

The `Blk_ekfpos` block processes absolute position measurements:

```cpp
class Blk_ekfpos : public Blocks::Iblock, public Gnc::Irainsld {
public:
    Blk_ekfpos(const Dynamics::Rigidbody& body0,
               const Ver::Cum_fifo& acc_int0,
               const volatile Base::Permission& p0);
    
    virtual void step();
    virtual const Blocks::Ipin* get_out(Uint16 i) const;
    virtual void cset(Base::Lossy_error& str, Csetpm& params);
    virtual bool valid() const;
    virtual void load(Data& d0) const;
    virtual void update_posvel(Rawposvel& pv) const;

private:
    const Dynamics::Rigidbody& body;      // Reference to current state
    const Ver::Cum_fifo& acc_int;         // Reference for measurement delay compensation
    
    bool attitude_mode;                   // True if correct attitude is enabled
    E2acc accvar;                         // Variance increment manager for high acceleration
    Vpgnc::Operator_pos::License poslic;  // License manager for position distance from operator
    
    Pin_ptr_watch<Signals::Pos::Mea> in;  // Input sensor measurement
    Blocks::Pin_ptr_opt<bool> enable;      // Input to enable/disable block
    Blocks::Pin<Gnc::Irainsld&> out;       // Output EKF measurement data
    Fix_validity fix_st;                   // Fix state
    
    Real kappa_h;                         // Safety horizontal protection parameter
    Real kappa_v;                         // Safety vertical protection parameter
};
```

Key features:
1. Processes absolute position measurements
2. Compensates for measurement delay using acceleration integration
3. Can affect attitude estimation if configured
4. Implements safety parameters to handle measurements far from current state
5. Manages position fix status

### 2.6 Velocity EKF Block (Blk_ekfvel)

The `Blk_ekfvel` block processes velocity measurements:

```cpp
class Blk_ekfvel : public Blocks::Iblock, public Gnc::Irainsld {
public:
    Blk_ekfvel(const Dynamics::Rigidbody& body0,
               const Ver::Cum_fifo& acc_int0);
    
    virtual void step();
    virtual const Blocks::Ipin* get_out(Uint16 i) const;
    virtual void cset(Base::Lossy_error& str, Csetpm& params);
    virtual bool valid() const;
    virtual void load(Data& d0) const;
    virtual void update_posvel(Rawposvel& pv) const;

private:
    const Dynamics::Rigidbody& body;       // Reference to current state
    const Ver::Cum_fifo& acc_int;          // Reference for measurement delay compensation
    
    bool attitude_mode;                    // True if correct attitude is enabled
    E2acc accvar;                          // Variance increment manager for high acceleration
    
    Pin_ptr_watch<Signals::Vel::Mea> in;   // Input sensor measurement
    Blocks::Pin_ptr_opt<bool> enable;       // Input to enable/disable block
    Blocks::Pin<Gnc::Irainsld&> out;        // Output EKF measurement data
    Fix_validity fix_st;                    // Fix state
    
    Real kappa_h;                          // Safety horizontal protection parameter
    Real kappa_v;                          // Safety vertical protection parameter
};
```

Key features:
1. Processes velocity measurements
2. Compensates for measurement delay using acceleration integration
3. Can affect attitude estimation if configured
4. Implements safety parameters to handle measurements far from current state
5. Manages velocity fix status

### 2.7 Velocity Down EKF Block (Blk_ekfvdn)

The `Blk_ekfvdn` block processes vertical velocity measurements:

```cpp
class Blk_ekfvdn : public Blocks::Iblock, public Gnc::Irainsld {
public:
    Blk_ekfvdn(const Dynamics::Rigidbody& body0);
    
    virtual void step();
    virtual const Blocks::Ipin* get_out(Uint16 i) const;
    virtual void cset(Base::Lossy_error& str, Csetpm& params);
    virtual void load(Data& d0) const;

private:
    const Dynamics::Rigidbody& body;  // Reference to body (for tilt check)
    Stepdec dec;                      // Measurement decimation
    Real e2;                          // Variance of last correct velocity down measurement
    
    bool lim_v;                       // Measured velocity limit function enabled
    Real v_min;                       // Minimum measured velocity down
    Real v_max;                       // Maximum measured velocity down
    
    bool lim_tilt;                    // Tilt limit function enabled
    Real tilt_max;                    // Maximum angle to use measurement
    
    Real vdown;                       // Last correct velocity down measurement
    
    Blocks::Pin_ptr<Real> in;         // Input velocity down measurement
    Blocks::Pin_ptr_opt<bool> enable;  // Input to enable/disable block
    Blocks::Pin<Gnc::Irainsld&> out;   // Output DEM measurement data
    
    bool on_range(const Real vdn0) const;  // Checks if velocity is within range
};
```

Key features:
1. Processes vertical velocity measurements with configurable limits for velocity and tilt
2. Provides vertical velocity measurements to the EKF

### 2.8 Static Pressure EKF Block (Blk_ekfstp)

The `Blk_ekfstp` block processes static pressure measurements:

```cpp
class Blk_ekfstp : public Blocks::Iblock, public Gnc::Irainsld {
public:
    Blk_ekfstp(const Dynamics::Aircraft& body0);
    
    virtual void step();
    virtual const Blocks::Ipin* get_out(Uint16 i) const;
    virtual void cset(Base::Lossy_error& str, Csetpm& params);
    virtual void load(Data& d0) const;

private:
    const Dynamics::Aircraft& body;         // Reference to current state
    const Geo::Ussa76& atm;                 // Reference to atmosphere
    const Bsp::Hbvar geoid_valid;           // True if the geoid is valid
    
    // Ground Effect Compensation (GEC) variables
    static const Uint16 ncols = 8U;         // Number of columns in GEC table
    Maverick::Rtablen<1U,ncols> gec_ctab;   // Correction adjustment on GEC
    Real gec_r_dh;                          // Altitude correction to apply on GEC
    Real gec_e2;                            // Variance for ground effect compensation
    
    Maverick::Ratelimiter e2rl;             // Limitation on error square changes
    Stepdec dec;                            // Measurement decimation
    
    Base::Chrono clk;                       // Clock for rate limiter
    Real y;                                 // Computed y correction from last measurement
    Real r;                                 // Computed variance from last measurement
    
    Pin_ptr_watch<Signals::Stp::Mea> in_mea;  // Input sensor measurement
    Blocks::Pin_ptr_opt<bool> enable;          // Input to enable/disable block
    Blocks::Pin_ptr_opt<bool> use_gec_y;       // Input to enable GEC on measurement
    Blocks::Pin_ptr_opt<bool> use_gec_r;       // Input to enable GEC on variance
    Blocks::Pin<Gnc::Irainsld&> out;           // Output EKF measurement data
    Blocks::Pin<Real> hqnh;                    // MSL height from QNH and pressure
    Blocks::Pin<Real> hisa;                    // MSL height for ISA and pressure
    Real kappa;                                // Safety scaler for measurements
    
    Real compute_e2(const bool hdown, const Real sen_e2);  // Computes measurement variance
    Real compute_e2_atm();                                 // Computes atmosphere variance
};
```

Key features:
1. Processes static pressure measurements
2. Implements Ground Effect Compensation (GEC) for measurements and variances
3. Computes MSL heights based on pressure measurements
4. Implements safety parameters for measurements far from current state

### 2.9 EKF Adapter Block (Blk_ekfadapter)

The `Blk_ekfadapter` block allows custom measurements to be fed into the EKF:

```cpp
class Blk_ekfadapter : public Blocks::Iblock, public Gnc::Irainsld {
public:
    Blk_ekfadapter();
    
    virtual void step();
    virtual const Blocks::Ipin* get_out(Uint16 i) const;
    virtual void cset(Base::Lossy_error& str, Csetpm& params);
    virtual void load(Data& d0) const;

private:
    Stepdec dec;                      // Decimator
    Data data;                        // Data to save new measurements
    
    Blocks::Pin_ptr<Real> in_y;       // "y" sensor measurement
    Blocks::Pin_ptr<Real> in_r;       // "R" sensor variance
    Blocks::Pin_ptr<Real> in_hdrn;    // "H" matrix for drn state
    Blocks::Pin_ptr<Real> in_hdvn;    // "H" matrix for dvn state
    Blocks::Pin_ptr<Real> in_hmis;    // "H" matrix for mis state
    Blocks::Pin_ptr<Real> in_hdwb;    // "H" matrix for dwb state
    Blocks::Pin_ptr<Real> in_hdfb;    // "H" matrix for dfb state
    Blocks::Pin_ptr<Uint16> in_ny;    // Dimension of input
    Blocks::Pin_ptr<bool> in_isagl;   // Is AGL measurement input
    Blocks::Pin_ptr_opt<bool> in_enable;  // Input to enable/disable block
    Blocks::Pin<Gnc::Irainsld&> out;      // Output custom measurement data
};
```

Key features:
1. Allows custom measurements to be fed into the EKF
2. Provides complete control over measurement vector, observation matrices, and variances

### 2.10 EKF Split Block (Blk_ekfsplit)

The `Blk_ekfsplit` block decomposes EKF inputs into their components:

```cpp
class Blk_ekfsplit : public Blocks::Iblock {
public:
    Blk_ekfsplit();
    
    virtual void step();
    virtual const Blocks::Ipin* get_out(Uint16 i) const;
    virtual void cset(Base::Lossy_error& str, Csetpm& params);

private:
    Gnc::Irainsld::Data data;         // Last read data from EKF
    
    Blocks::Pin_ptr<Gnc::Irainsld> in;  // Input EKF data
    Blocks::Pin<bool> is_new;           // True if measurement is new
    Blocks::Pin<Maverick::Irvector3> y;  // "y" sensor measurement
    Blocks::Pin<Maverick::Irvector3> r;  // "R" sensor variance
    Blocks::Pin<Maverick::Irmatrix3> hdrn;  // "H" matrix for drn state
    Blocks::Pin<Maverick::Irmatrix3> hdvn;  // "H" matrix for dvn state
    Blocks::Pin<Maverick::Irmatrix3> hmis;  // "H" matrix for mis state
    Blocks::Pin<Maverick::Irmatrix3> hdwb;  // "H" matrix for dwb state
    Blocks::Pin<Maverick::Irmatrix3> hdfb;  // "H" matrix for dfb state
};
```

Key features:
1. Splits EKF input data into separate components
2. Provides access to measurement vector, observation matrices, and variances

## 3. Sensor Measurement Conversion Blocks

### 3.1 Relative Position to Misalignment Block (Blk_drnmis)

The `Blk_drnmis` block converts relative position measurements to misalignment data:

```cpp
class Blk_drnmis : public Blocks::Iblock {
public:
    Blk_drnmis();
    
    virtual void on_focus();
    virtual void step();
    virtual const Blocks::Ipin* get_out(Uint16 i) const;
    virtual void cset(Base::Lossy_error& str, Csetpm& params);

private:
    typedef Vblocks::Pin_ptr_watch<Signals::Drn::Mea> Intype;
    Intype in_drn0;                         // First input relative measurement
    Intype in_drn1;                         // Second input relative measurement
    Blocks::Pin<Signals::Mis::Mea> mned;    // Measurement in NED frame
    Blocks::Pin<Signals::Mis::Mea> mbody;   // Measurement in Body frame
    
    void rover_base(Intype& r, Intype& b);  // Process rover-base configuration
    void rover_rover(Intype& r0, Intype& r1);  // Process rover-rover configuration
};
```

Key features:
1. Converts relative position measurements to misalignment data
2. Supports both rover-base and rover-rover configurations
3. Provides misalignment measurements in both NED and body frames

### 3.2 Magnetic Field Block (Blk_magfield)

The `Blk_magfield` block provides magnetic field measurements:

```cpp
class Blk_magfield : public Blocks::Iblock {
public:
    Blk_magfield(const Geo::Imagfield& mfield0,
                 const Base::Lonlat& uav_pos0);
    
    virtual void step();
    virtual const Blocks::Ipin* get_out(Uint16 i) const;
    virtual void cset(Base::Lossy_error& str, Csetpm& params);

private:
    const Geo::Imagfield& mfield;        // Reference to magnetic field interface
    const Base::Lonlat& uav_pos;         // Current position of the UAV
    Blocks::Pin<Signals::Mis::Mea> out;  // Read measurement
    Maverick::Irvector3 out_field;       // Output field (points to out)
};
```

Key features:
1. Provides magnetic field measurements in the NED frame
2. Uses the format for misalignment measurements

## 4. Wind Estimation Block (Blk_wind)

The `Blk_wind` block estimates wind speed from True Air Speed measurements:

```cpp
class Blk_wind: public Blocks::Iblock {
public:
    Blk_wind(const Dynamics::Aircraft& body0,
             const Vpgnc::Windcmd& cmd0);
    
    virtual void on_focus();
    virtual void step();
    virtual const Blocks::Ipin* get_out(Uint16 i) const;
    virtual void cset(Base::Lossy_error& str, Csetpm& params);

private:
    static bool first;                                // Block already exists flag
    
    const Dynamics::Aircraft& body;                   // Reference to physical variables
    const Vpgnc::Windcmd& cmd;                        // Command to reset estimation
    Base::Dsync::Reader rd;                           // Reader for changes in command
    
    Maverick::Irvector3 ak;                           // Wind velocity (navigation frame)
    Maverick::Irmatrix3 Pk;                           // Wind estimation uncertainty
    // Many more state variables for Kalman filter implementation
    
    Pin_ptr_watch<Signals::Wind::Mea> in;             // Input measurement
    Blocks::Pin_ptr_opt<Real> in_ak0;                 // Optional initial velocity
    Blocks::Pin_ptr_opt<Real> in_Pk0;                 // Optional initial uncertainty
    Blocks::Pin<Base::Rv3> out_vel;                   // Wind estimated vector
    Blocks::Pin<Base::Tnarray<Real, sz_p> > out_var;  // Wind estimation uncertainty matrix
    
    bool step_decimation();                           // Updates decimator
    void compute_dep();                               // Computes dependent variables
    bool cmd_changed();                               // Detects command changes
};
```

Key features:
1. Implements a Kalman filter to estimate wind velocity
2. Uses True Air Speed measurements and aircraft velocity
3. Computes wind direction and aerodynamic angles

## 5. Proportional Navigation Blocks

### 5.1 Base Proportional Navigation Block (Blk_pnav_base)

The `Blk_pnav_base` class provides the base functionality for proportional navigation:

```cpp
class Blk_pnav_base : public Blocks::Iblock {
public:
    Blk_pnav_base(const Dynamics::Aircraft& uav0);
    
    virtual void on_focus();
    virtual void step();
    virtual const Blocks::Ipin* get_out(Uint16 i) const;

protected:
    const Dynamics::Aircraft& uav;              // Reference to UAV body
    Blocks::Pin<Maverick::Rvector3> ab;         // Output desired body acceleration
    
    // Work variables
    Real tgo;                                   // Time to go
    Real vel_cl;                                // Closing velocity
    Maverick::Rvector3 r;                       // Work vector
    Maverick::Rvector3 lambda;                  // LOS unit vector
    Maverick::Rvector3 anormal;                 // Acceleration normal to velocity difference
    
    virtual void compute_pn()=0;                // Specific PN computation
    virtual void cset(Base::Lossy_error& str, Csetpm& params);

private:
    Real max_acc;                               // Maximum acceleration
    Blocks::Pin_ptr<Geo::Apos> target;          // Input target position
};
```

Key features:
1. Computes the acceleration needed to impact a target
2. Provides base functionality for proportional navigation
3. Derived classes implement specific proportional navigation algorithms

### 5.2 Proportional Navigation Block (Blk_pnav)

The `Blk_pnav` class implements standard proportional navigation:

```cpp
class Blk_pnav : public Blk_pnav_base {
public:
    Blk_pnav(const Dynamics::Aircraft& uav0);
    
    virtual void compute_pn();
    virtual void cset(Base::Lossy_error& str, Csetpm& params);

private:
    Real n;  // Proportional scaler
};
```

Key features:
1. Implements standard proportional navigation
2. Uses a proportional factor to scale the acceleration

### 5.3 Modified Proportional Navigation Block (Blk_modpnav)

The `Blk_modpnav` class implements modified proportional navigation:

```cpp
class Blk_modpnav : public Blk_pnav_base {
public:
    Blk_modpnav(const Dynamics::Aircraft& uav0);
    
    virtual void compute_pn();
    virtual void cset(Base::Lossy_error& str, Csetpm& params);

private:
    static const Uint16 cd_t_sz = 11U;          // Number of points in CD table
    Real tau;                                   // System's response time
    Real s_ref;                                 // S ref
    Real weight;                                // Weight in Newtons
    Maverick::Rtablen<1,cd_t_sz> cd_table;      // CD table
};
```

Key features:
1. Implements modified proportional navigation with air drag corrections
2. Uses a drag coefficient table to account for aerodynamic effects

## 6. Position Fix Management

The `Fix_validity` class manages the validity of position and velocity fixes:

```cpp
class Fix_validity {
public:
    Fix_validity();
    
    static void set_init_time(const Real init_seconds);
    void step(const bool fix);
    bool is_valid() const;

private:
    Base::Logicfsm st;        // State of the fix, to detect transitions
    static Base::Ttime init;  // Time of initial continuity in tics
    Base::Ttime min_time;     // Start of validity period
    Base::Ttime max_time;     // End of validity period
    
    bool in_time() const;     // Checks if current time is within validity period
};
```

Key features:
1. Manages the validity of position and velocity fixes
2. Requires a continuous fix for a configurable period before considering it valid
3. Implements a timeout (2.5 seconds) after which the fix is considered invalid

## 7. Navigation State Flow

### 7.1 EKF Input Processing Flow

The flow of sensor measurements through the EKF system:

1. **Sensor Blocks** (`Blk_senimu`, `Blk_senalt`, etc.) read raw sensor data
2. **EKF Input Blocks** (`Blk_ekfalt`, `Blk_ekfpos`, etc.) process sensor data and implement the `Irainsld` interface
3. **Navigation Block** (`Blk_nav`) collects inputs from EKF input blocks and updates the navigation state
4. **EKF Algorithm** (`vpu.relekf`) processes the inputs and updates the state estimate

### 7.2 Navigation Source Selection Flow

The navigation source selection process:

1. **Command System** sets the `nav_cmd` variable
2. **Navigation Block** (`Blk_nav`) reads the `nav_cmd` variable in its `step()` method
3. **Navigation Block** selects the appropriate navigation source based on `nav_cmd`
4. **Navigation Block** updates the navigation state using the selected source

### 7.3 Position Fix Management Flow

The position fix management process:

1. **EKF Input Blocks** (`Blk_ekfpos`, `Blk_ekfvel`) update their `Fix_validity` instances
2. **EKF Input Blocks** provide position and velocity fix information through the `update_posvel()` method
3. **Navigation Block** (`Blk_nav`) collects position and velocity fix information through `inmgr.update_posvel()`
4. **EKF Algorithm** (`vpu.relekf`) updates its position fix status through `compute_posfix()`
5. **Position Fix Manager** (`pfix`) updates the position fix bit based on the navigation source

## 8. Cross-Component Relationships

### 8.1 Navigation Block and EKF Input Blocks

The `Blk_nav` block interacts with EKF input blocks through the `Inputmgr` class:

```
Blk_nav
   |
   +--> Inputmgr
          |
          +--> Gnc::Irainsld (interface)
                  |
                  +--> Blk_ekfalt
                  +--> Blk_ekfdem
                  +--> Blk_ekfmis
                  +--> Blk_ekfpos
                  +--> Blk_ekfvel
                  +--> Blk_ekfvdn
                  +--> Blk_ekfstp
                  +--> Blk_ekfadapter
```

The `Inputmgr` manages a collection of `Gnc::Irainsld` objects, which are implemented by the various EKF input blocks.

### 8.2 Sensor Blocks and EKF Input Blocks

Sensor blocks provide measurements to EKF input blocks:

```
Blk_senimu -----> Signals::Imu::Mea -----> Blk_ekfmis
Blk_senalt -----> Signals::Alt::Mea -----> Blk_ekfalt
Blk_sengnss ----> Signals::Pos::Mea -----> Blk_ekfpos
Blk_sengnss ----> Signals::Vel::Mea -----> Blk_ekfvel
Blk_senstp -----> Signals::Stp::Mea -----> Blk_ekfstp
Blk_sensrtm ----> Signals::Dem::Mea -----> Blk_ekfdem
```

Sensor blocks read raw sensor data and convert it to structured measurement types, which are then processed by EKF input blocks.

### 8.3 Navigation Block and Navigation State

The `Blk_nav` block updates the navigation state through the `Vpgnc::Vpunav` class:

```
Blk_nav
   |
   +--> Vpgnc::Vpunav
          |
          +--> Vpgnc::Relekf (EKF algorithm)
          +--> Navigation State (position, velocity, attitude)
```

The `Vpgnc::Vpunav` class contains the navigation state and the EKF algorithm.

## 9. Key Algorithms

### 9.1 EKF Update Process

The EKF update process in `Blk_nav::step_ekf()`:

1. Update position fix status based on available position measurements
2. Set INS/full EKF mode bit
3. Process all inputs to check for updates
4. Get alignment data from sensors
5. If initial alignment is complete:
   a. Run attitude and INS update
   b. Run EKF prediction step
   c. If a sensor was used, run EKF update step
   d. Run post-EKF processing
   e. Commit updated variances
6. If initial alignment is not complete:
   a. Try to perform initial alignment with available data

### 9.2 Sensor Measurement Processing

The general pattern for sensor measurement processing in EKF input blocks:

1. Check if the block is enabled
2. Check if there are new measurements
3. Apply decimation to limit update frequency
4. Apply range and validity checks
5. Process the measurement (apply calibration, corrections, etc.)
6. Update the output

### 9.3 Position Fix Management

The position fix management algorithm in `Fix_validity`:

1. On rising edge (from no fix to fix):
   a. Set minimum time to current time plus initial continuity time
   b. Set maximum time to current time plus timeout
2. On high level (fix = true):
   a. Set maximum time to current time plus timeout
3. Check if fix is valid:
   a. State must be positive level or positive edge
   b. Current time must be greater than or equal to minimum time
   c. Current time must be less than maximum time

## 10. Summary

The navigation and state estimation system in the VBlocks library is built around the Extended Kalman Filter (EKF) algorithm, with a flexible architecture that supports multiple sensor inputs and navigation sources.

### 10.1 Key Components

1. **Navigation Block (`Blk_nav`)**: Central block that manages navigation source selection and EKF updates
2. **EKF Input Blocks**: Process sensor measurements and provide them to the EKF
   - `Blk_ekfalt`: Altimeter measurements
   - `Blk_ekfdem`: Terrain height measurements
   - `Blk_ekfmis`: Misalignment measurements
   - `Blk_ekfpos`: Absolute position measurements
   - `Blk_ekfvel`: Velocity measurements
   - `Blk_ekfvdn`: Vertical velocity measurements
   - `Blk_ekfstp`: Static pressure measurements
   - `Blk_ekfadapter`: Custom measurements
3. **Sensor Conversion Blocks**: Convert between different measurement types
   - `Blk_drnmis`: Converts relative position to misalignment
   - `Blk_magfield`: Provides magnetic field measurements
4. **Wind Estimation Block (`Blk_wind`)**: Estimates wind speed from True Air Speed measurements
5. **Proportional Navigation Blocks**: Compute guidance commands for target interception
   - `Blk_pnav`: Standard proportional navigation
   - `Blk_modpnav`: Modified proportional navigation with air drag corrections

### 10.2 Navigation Sources

The system supports multiple navigation sources:
1. **Internal EKF** (`Base::nav_ekf`): Uses processed measurements and the EKF algorithm
2. **Simulated Navigation** (`Base::nav_sim_state`): Uses simulated navigation data
3. **External Navigation** (`Base::nav_external`): Uses external navigation data
4. **Navigation from System Variables** (`Base::nav_ext_var`): Uses navigation data from system variables
5. **Navigation from VectorNAV VN-300** (`Base::nav_vn300`): Uses VN-300 navigation data
6. **External Sensor Navigation** (`Base::nav_extsen`): Uses external sensor navigation data

### 10.3 EKF Architecture

The EKF architecture is designed to be flexible and extensible:
1. **Common Interface (`Gnc::Irainsld`)**: All EKF input blocks implement this interface
2. **Input Manager (`Blk_nav::Inputmgr`)**: Manages EKF inputs and selects the highest priority input
3. **EKF Algorithm (`Vpgnc::Relekf`)**: Implements the Extended Kalman Filter algorithm
4. **Position Fix Management (`Fix_validity`)**: Manages the validity of position and velocity fixes

This architecture allows for easy addition of new sensor types and navigation sources, making the system highly adaptable to different UAV configurations and mission requirements.