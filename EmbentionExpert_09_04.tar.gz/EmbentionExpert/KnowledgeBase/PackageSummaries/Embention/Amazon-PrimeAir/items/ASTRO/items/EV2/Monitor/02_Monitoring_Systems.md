# Generated from:

- items/pdi_Monitor/setup/ver_spdif_mbit.xml (5486 tokens)
- items/pdi_Monitor/setup/ver_spdif_tm.xml (21278 tokens)
- items/pdi_Monitor/setup/ver_spdif_amz_mon_param.xml (8762 tokens)
- items/pdi_Monitor/setup/ver_spdif_mrvar.xml (24738 tokens)
- items/pdi_Monitor/setup/ver_spdif_muvar.xml (2010 tokens)
- items/pdi_Monitor/setup/ver_spdif_mexvar.xml (58 tokens)
- items/pdi_Monitor/setup/ver_spdif_mvars.xml (270 tokens)
- items/pdi_Monitor/setup/ver_spdif_status.xml (72 tokens)
- items/pdi_Monitor/setup/ver_spdif_varini.xml (642 tokens)
- items/pdi_Monitor/setup/ver_spdif_varacc.xml (237 tokens)
- items/pdi_Monitor/setup/ver_spdif_vargyr.xml (237 tokens)
- items/pdi_Monitor/setup/ver_spdif_varmag.xml (237 tokens)
- items/pdi_Monitor/setup/ver_spdif_varstp.xml (198 tokens)
- items/pdi_Monitor/setup/ver_spdif_varqinf.xml (198 tokens)
- items/pdi_Monitor/setup/ver_spdif_cbitcfg.xml (68 tokens)
- items/pdi_Monitor/setup/ver_spdif_chklist.xml (52 tokens)
- items/pdi_Monitor/operation/ver_opdif_tmcompl.xml (1978 tokens)

---

# Comprehensive Analysis of the Drone Control Platform Monitoring System

## 1. Monitoring System Overview

The monitoring system in the drone control platform is a comprehensive framework designed to track, evaluate, and respond to the operational status of various drone subsystems. It consists of several interconnected components that collectively ensure the safe and reliable operation of the drone through continuous monitoring of critical parameters, interfaces, and system states.

## 2. Monitor Bits Configuration (ver_spdif_mbit.xml)

The monitoring system uses an extensive set of monitor bits (mbits) to track various system states and conditions. These bits are organized with unique IDs and descriptions, providing a comprehensive status mapping of the drone's operational state.

### 2.1 System State Flags

The system includes numerous state flags (IDs 1300-1321) that track fundamental drone states:

- `is_onground` (ID 1300): Indicates whether the drone is on the ground
- `control status` (ID 1301): Tracks the current control status
- `ctr_switchover_signaled` (ID 1302): Signals when a control system switchover is requested
- `ttcg wp is valid` (ID 1303): Indicates if the trajectory tracking control guidance waypoint is valid
- `self arm enabled` (ID 1304): Shows if self-arming is enabled
- `mixer is saturated` (ID 1305): Indicates if the motor mixer is at saturation limits

### 2.2 Recovery System Status Flags

A significant portion of the monitor bits (IDs 1306-1317) is dedicated to tracking the recovery system status:

- `recovery is in control` (ID 1306): Indicates if the recovery system has taken control
- `recovery tracking has started` (ID 1307): Shows if recovery tracking has initiated
- `recovery is armed allowed` (ID 1308): Indicates if recovery arming is permitted
- `recovery arming disallowed` (ID 1309): Shows if recovery arming is prohibited
- `recovery takeoff executed` (ID 1310): Tracks if recovery takeoff has been performed
- `recovery initial tracking point set` (ID 1311): Indicates if the initial recovery tracking point is established
- `recovery pre takeoff cmd` (ID 1317): Shows if pre-takeoff commands for recovery are active

### 2.3 Interface Monitoring Flags

The system extensively monitors interface activity (IDs 1401-1421) to detect communication issues:

- Motor RPM command interface monitoring:
  - `mon_pri_motor_rpm_cmd_aic_active` (ID 1401): Primary motor RPM command AIC interface active
  - `mon_pri_motor_rpm_cmd_mrc_active` (ID 1402): Primary motor RPM command MRC interface active
  - `mon_rec_motor_rpm_cmd_aic_active` (ID 1409): Recovery motor RPM command AIC interface active

- State estimation interface monitoring:
  - `mon_pri_state_estimate_aic_active` (ID 1403): Primary state estimate AIC interface active
  - `mon_rec_state_estimate_aic_active` (ID 1410): Recovery state estimate AIC interface active

- Heartbeat monitoring:
  - `mon_pri_ccp_hrtbt_aic_active` (ID 1406): Primary CCP heartbeat AIC interface active
  - `mon_pri_onground_hrtbt_aic_active` (ID 1407): Primary onground heartbeat AIC interface active
  - `mon_air_data_hrtbt_aic_active` (ID 1408): Air data heartbeat AIC interface active

- Other monitoring interfaces:
  - `mon_pri_ctrl_monit_data_aic_active` (ID 1404): Primary control monitoring data AIC interface active
  - `mon_vms_monit_data_aic_active` (ID 1405): VMS monitoring data AIC interface active

### 2.4 Performance and Test Flags

Several flags track system performance and test states:

- `mon_motor_perf_chk_active` (ID 1411): Motor performance check active
- `mon_motor_perf_chk_failed` (ID 1412): Motor performance check failed
- `mon_exec_pret_swo_test` (ID 1413): Execute pre-takeoff switchover test

### 2.5 Inhibit Flags

Multiple inhibit flags (IDs 1414-1421) control when certain monitoring functions are suppressed:

- `mon_disarm_inhibit_active` (ID 1414): Disarm inhibit active
- `mon_power_on_inhibit_active` (ID 1415): Power-on inhibit active
- `mon_ul_inhibit_active` (ID 1416): Uplink inhibit active
- `mon_rec_unhealthy_inhibit_active` (ID 1417): Recovery unhealthy inhibit active
- `mon_mep_out_inhibit_active` (ID 1418): MEP output inhibit active
- `mon_ads_fault_inhibit_active` (ID 1419): Air data system fault inhibit active
- `mon_gps_out_inhibit_active` (ID 1420): GPS output inhibit active
- `mon_imu_sat_inhibit_active` (ID 1421): IMU saturation inhibit active

### 2.6 Check Failure Flags

The system includes flags that indicate when specific checks have failed:

- `mon_loss_check_fail` (ID 1423): Loss check failure
- `mon_vms_check_fail` (ID 1424): VMS check failure
- `mon_pri_nav_pos_check_fail` (ID 1425): Primary navigation position check failure
- `mon_pri_nav_att_check_fail` (ID 1426): Primary navigation attitude check failure
- `mon_tp_check_fail` (ID 1427): TP check failure
- `mon_vehicle_state_check_fail` (ID 1428): Vehicle state check failure

### 2.7 Navigation Status Flags

Several flags track navigation system status:

- `Enable Monitor Nav` (ID 1430): Enable navigation monitoring
- `Monitor Navigation Rate OK` (ID 1470): Navigation rate is acceptable
- `Monnav send full state estimate` (ID 1471): Monitor navigation sending full state estimate

### 2.8 GNSS and Navigation Flags

The system includes numerous flags for GNSS and navigation status:

- GNSS velocity flags (IDs 1322-1326):
  - `gnss_vel_consumable` (ID 1322): GNSS velocity is consumable
  - `gnss_vel_gnss_posvel_match` (ID 1323): GNSS position and velocity match
  - `gnss_vel_gnss_check_accuracies` (ID 1324): GNSS accuracy check
  - `gnss_vel_idx_present` (ID 1325): GNSS velocity index present
  - `gnss_vel_chi` (ID 1326): GNSS velocity chi value

- RAIM (Receiver Autonomous Integrity Monitoring) flags:
  - `mon_raim_use_dgnss_corrections` (ID 1475): Use DGNSS corrections in RAIM
  - `mon_raim_shot_position_is_success` (ID 1478): RAIM shot position calculation successful
  - `mon_raim_solver_vel_is_success` (ID 1479): RAIM velocity solver successful

### 2.9 Vehicle State Monitoring Flags

The system includes flags for monitoring vehicle position status:

- Position monitoring flags (IDs 1480-1484):
  - `vs_pos_alongtrack_failed` (ID 1480): Along-track position check failed
  - `vs_pos_crosstrack_failed` (ID 1481): Cross-track position check failed
  - `vs_pos_altitude_failed` (ID 1482): Altitude position check failed
  - `vs_pos_contingency_active` (ID 1483): Position contingency active
  - `vs_pos_is_check_activ` (ID 1484): Position check active

### 2.10 Drone State Machine Flags

Several flags track the drone state machine status, particularly related to takeoff operations:

- `mmdp_has_top_of_takeoff_llh` (ID 1485): Has top of takeoff latitude/longitude/height
- `dsm_takeoff_completed` (ID 1486): Takeoff completed
- `dsm_is_takeoff_to_delivery_route` (ID 1487): Is takeoff to delivery route
- `dsm_is_takeoff_hae_below_threshold` (ID 1488): Takeoff height above ellipsoid below threshold
- `dsm_is_previous_route_takeoff_route` (ID 1489): Previous route was takeoff route
- `dsm_is_current_route_takeoff_route` (ID 1490): Current route is takeoff route
- `dsm_completed_takeoff_route` (ID 1491): Completed takeoff route
- `dsm_is_takeoff_maneuver_condition_met` (ID 1492): Takeoff maneuver condition met
- `dsm_completed_top_of_takeoff_maneuver` (ID 1493): Completed top of takeoff maneuver

## 3. Telemetry Stream Configuration (ver_spdif_tm.xml)

The monitoring system configures three telemetry streams, each operating at 20Hz (0.05s period) and addressed to UAV ID 2. These streams transmit different sets of monitoring data:

### 3.1 First Telemetry Stream

The first telemetry stream includes:
- System status flags (IDs 1400, 1430)
- Motor performance monitoring (ID 1201)
- Navigation data (IDs 3300, 3301)
- Interface activity status (IDs 1401-1421)
- Check failure flags (IDs 1423-1429)
- Control switchover status (ID 1302)
- GNSS velocity status (IDs 1322-1326)
- Various navigation and position data (IDs 2046-2055)
- Motor RPM data (IDs 505-508)

### 3.2 Second Telemetry Stream

The second telemetry stream focuses on navigation performance metrics:
- Navigation step timing (IDs 3242-3243)
- Navigation state estimates (IDs 3302-3317)
- RAIM performance metrics (IDs 3419-3440)
- Navigation initialization counters (IDs 1151-1152)

### 3.3 Third Telemetry Stream

The third telemetry stream includes:
- Navigation initialization counter (ID 1150)
- Interface failure flags (IDs 1431-1440)
- Output manager performance (IDs 3332-3333)
- Navigation timing metrics (IDs 3225-3226)
- Interface frequency monitoring (IDs 3400-3407)
- RAIM status flags (IDs 1478-1493)
- RAIM performance data (IDs 3444-3486)
- Vehicle state position data (IDs 3462-3486)
- Drone state machine timing data (IDs 3489-3495)

## 4. Monitor Parameters Configuration (ver_spdif_amz_mon_param.xml)

The monitor parameters configuration defines thresholds, timeouts, and behavior for the monitoring system.

### 4.1 General Configuration

- `is_switchover_enabled`: 1 (enabled)
- `monitor_frequency_hz`: 50.0 Hz (monitoring runs at 50Hz)

### 4.2 Switchover Logic

- `is_switchover_test_enabled`: 1 (enabled)
- `is_mep_out_test`: 0 (disabled)
- `threshold_since_pre_flight_check_ms`: 500.0 ms (minimum time since pre-flight check)

### 4.3 Loss Checks

The system defines timeouts for various interface checks:

- Primary motor RPM command: 80.0 ms timeout
- Primary CCP heartbeat: 1000.0 ms timeout
- VMS monitored data: 1000.0 ms timeout
- Primary state estimate: 100.0 ms timeout
- Recovery state estimate: 200.0 ms timeout
- Primary control monitored data: 100.0 ms timeout
- Primary onground heartbeat: 500.0 ms timeout
- Air data heartbeat: 500.0 ms timeout
- Monitor recovery controller command: 1000.0 ms timeout
- Recovery motor RPM command: 200.0 ms timeout

Motor performance loss check:
- Maximum inactive time: 80.0 ms
- Maximum number of timed-out motors: 1

### 4.4 Navigation Checks

#### 4.4.1 Primary Attitude Check
- Maximum absolute heading error: 20.0 degrees
- Maximum absolute tilt error: 7.0 degrees
- Low-pass filter parameters for error smoothing

#### 4.4.2 Recovery Attitude Check
- Maximum absolute heading error: 15.0 degrees
- Maximum absolute tilt error: 5.0 degrees
- Low-pass filter parameters for error smoothing

#### 4.4.3 Position Checks
Primary position checks:
- Maximum horizontal difference: 30.0 m
- Maximum vertical difference: 30.0 m
- Maximum horizontal difference with DGNSS: 2.0 m
- Maximum vertical difference with DGNSS: 5.0 m
- Worst-case delay: 120.0 ms

Recovery position checks:
- Maximum horizontal difference: 30.0 m
- Maximum vertical difference: 30.0 m
- Maximum horizontal difference with DGNSS: 30.0 m
- Maximum vertical difference with DGNSS: 30.0 m
- Worst-case delay: 60.0 ms

#### 4.4.4 Velocity Check
- Maximum velocity error norm: 1.5 m/s
- Count increment: 1
- Count decrement: 1
- Maximum fault detection count: 3

### 4.5 Vehicle State Checks

#### 4.5.1 Position Check
- Active during stop and hover: Yes
- Active during evasive maneuver: Yes
- Maximum VTOL along-track error: 6.0 m (16.0 m in contingency)
- Maximum transition along-track error: 20.0 m (30.0 m in contingency)
- Maximum WBF along-track error: 5.0 m (30.0 m in contingency)
- Maximum VTOL cross-track error: 6.0 m (12.0 m in contingency)
- Maximum transition cross-track error: 12.0 m (20.0 m in contingency)
- Maximum WBF cross-track error: 12.0 m (20.0 m in contingency)
- Maximum VTOL altitude error: 6.0 m (8.0 m in contingency)
- Maximum transition altitude error: 10.0 m (20.0 m in contingency)
- Maximum WBF altitude error: 10.0 m (20.0 m in contingency)

#### 4.5.2 Linear Velocity Check
- Active during stop and hover: Yes
- Active during evasive maneuver: Yes
- Maximum azimuth error: 10.0 degrees (16.0 degrees in contingency)
- Maximum flight path angle error: 10.0 degrees (16.0 degrees in contingency)
- Maximum horizontal velocity error: 6.0 m/s (13.0 m/s in contingency)
- Maximum vertical velocity error: 5.0 m/s (10.0 m/s in contingency)
- Low-pass filter parameters for error smoothing

#### 4.5.3 Angular Velocity Check
- Active during stop and hover: Yes
- Active during evasive maneuver: Yes
- Roll rate error thresholds based on airspeed breakpoints
- Maximum roll rate errors: 50.0-140.0 deg/s (160.0-300.0 deg/s in contingency)
- Maximum VTOL pitch rate error: 50.0 deg/s (160.0 deg/s in contingency)
- Maximum outbound transition pitch rate error: 40.0 deg/s (75.0 deg/s in contingency)
- Maximum inbound transition pitch rate error: 50.0 deg/s (90.0 deg/s in contingency)
- Maximum WBF pitch rate error: 60.0 deg/s (100.0 deg/s in contingency)
- Maximum WBF pitch rate error (low-pass filtered): 25.0 deg/s (50.0 deg/s in contingency)
- Yaw rate error thresholds based on airspeed breakpoints
- Maximum yaw rate errors: 35.0-70.0 deg/s (70.0-140.0 deg/s in contingency)
- Low-speed/high-speed yaw logic thresholds: 13.0 m/s and 20.0 m/s

#### 4.5.4 Attitude Check
- Active during stop and hover: Yes
- Active during evasive maneuver: Yes
- Maximum bank angle error: 40.0 degrees (70.0 degrees in contingency)
- VTOL pitch limits: -40.0 to 50.0 degrees (-70.0 to 70.0 degrees in contingency)
- Transition pitch limits: -50.0 to 60.0 degrees (-65.0 to 70.0 degrees in contingency)
- WBF pitch limits: -25.0 to 25.0 degrees (-40.0 to 40.0 degrees in contingency)
- Undefined POF pitch limits: -90.0 to 90.0 degrees
- VTOL yaw limit: 181.0 degrees (181.0 degrees in contingency)
- Transition yaw limit: 55.0 degrees (70.0 degrees in contingency)
- WBF yaw limit: 40.0 degrees (70.0 degrees in contingency)
- Undefined POF yaw limit: 181.0 degrees

#### 4.5.5 Edge Delay Parameters
- Stop and hover falling edge delay: 5000 ms
- Evasive maneuver falling edge delay: 15000 ms

### 4.6 Locker Delivery Check

- Enabled: Yes
- Minimum height above target: 1.3 m
- Maximum downward velocity: 3.0 m/s
- Minimum recovery height: 1.3 m
- Switchover delay: 0.120 s
- Minimum downward acceleration: -2.45 m/s²
- Minimum downward jerk: -6.0 m/s³

### 4.7 Disarm Check

- Enabled: Yes
- Position check enabled: Yes
- Horizontal distance to takeoff point threshold: 75.0 m
- Horizontal distance to landing point threshold: 30.0 m
- Horizontal distance to landing point threshold with DGNSS: 5.0 m
- Horizontal distance to takeoff point threshold with DGNSS: 75.0 m
- Vertical distance to landing point threshold: 30.0 m
- Vertical distance to landing point threshold with DGNSS: 5.0 m
- Maximum absolute VTOL roll: 30.0 degrees
- Maximum absolute VTOL pitch: 30.0 degrees
- Jerk check lookback time: 3000.0 ms
- Disarm check timeout: 100.0 ms
- Minimum ground contact pseudo-jerk: 1.8 m/s²
- Landing disarm timeout: 10.0 s

### 4.8 Drone State Machine Parameters

- Hazardous operations light timer expiration: 2700 ms
- Attitude check parameters:
  - Roll/pitch enable: Yes
  - Nominal roll VTOL from NED: 0.0 degrees
  - Nominal pitch VTOL from NED: -2.3 degrees
  - Maximum deviation roll/pitch: 5.0 degrees
- Bounding volume check enabled: Yes
- Switchover test timeout: 0.12 s
- Switchover test enabled: Yes
- Takeoff timing window check enabled: No
- Enabling propulsion start before takeoff: 20000 ms
- Takeoff window error threshold: 1000 ms
- Close door timer: 6000 ms
- Climb rate command backyard exit: 0.5 m/s
- Estimated height above ellipsoid error: 2.0 m
- Command height above ellipsoid error: 3.0 m
- Maximum allowed delivery height (MLD): 8.0 m
- Maximum allowed delivery height (PAL): 4.0 m
- Delivery height power on: 8.0 m
- HAE-based land AGL: 8.0 m
- Heading check tolerances:
  - Heading initialization: 10.0 degrees
  - Mission plan: 1.0 degrees
  - Heading check: 10.0 degrees
- Takeoff completed HAE difference threshold: 30.0 m
- Flight to landing completed horizontal threshold: 30.0 m
- Flight to landing completed vertical threshold: 30.0 m
- DGNSS thresholds:
  - Takeoff completed HAE difference: 3.0 m
  - Flight to landing completed horizontal: 3.0 m
  - Flight to landing completed vertical: 3.0 m

### 4.9 VMS Checks

- Inadvertent takeoff check: Disabled (maximum test motor RPM: 2200)
- Enacted contingency checks: Enabled (detection timeout: 2.0 s)
- Reset check: Disabled
- Motor arm check: Disabled
- Mission phase check: Disabled (monitor primary sync offset: 1000.0 ms)
- Land command check:
  - Enabled: Yes
  - Height above landing point threshold: 19.0 m
  - Height above landing point threshold with DGNSS: 9.0 m

### 4.10 PDS Control

- PDS command generator:
  - Enabled: Yes
  - Command active time: 4.0 s
  - Power-on delay: 0.1 s
  - Maximum height above MLD point: 8.0 m
  - Maximum height above locker: 4.0 m
  - Maximum horizontal distance to locker: 1.25 m

### 4.11 Scheduler Inputs

- Initial air density: 1.225 kg/m³
- Initial dynamic pressure: 0.0 Pa
- Dynamic pressure low-pass filter parameters

### 4.12 DGNSS Unavailable Falling Edge Delay

- Time delay: 30000 ms (30 seconds)

## 5. Monitor Runtime Variables (ver_spdif_mrvar.xml)

The monitor runtime variables file defines a large set of variables (IDs 3100-3495) that are used to track system performance and state. These variables include:

### 5.1 Navigation Performance Metrics

- Navigation step timing metrics (max/avg):
  - `mon_nav_step_max` (ID 3200)
  - `mon_nav_step_avg` (ID 3201)
  - `mlogctrl_max` (ID 3202)
  - `mlogctrl_avg` (ID 3203)
  - `nav_pre_max` (ID 3204)
  - `nav_pre_avg` (ID 3205)
  - `nav_step_max` (ID 3206)
  - `nav_step_avg` (ID 3207)
  - `nav_post_max` (ID 3208)
  - `nav_post_avg` (ID 3209)

### 5.2 Estimator Performance Metrics

- Estimator timing metrics:
  - `est_beg_max` (ID 3210)
  - `est_beg_avg` (ID 3211)
  - `covprop_max` (ID 3212)
  - `covprop_avg` (ID 3213)
  - `input_meas_max` (ID 3214)
  - `input_meas_avg` (ID 3215)
  - `est_end_max` (ID 3216)
  - `est_end_avg` (ID 3217)
  - `covprop_full_max` (ID 3218)
  - `covprop_full_avg` (ID 3219)

### 5.3 Input Processing Metrics

- Input processing timing metrics:
  - `in_vel_max` (ID 3220)
  - `in_vel_avg` (ID 3221)
  - `in_pos_max` (ID 3222)
  - `in_pos_avg` (ID 3223)
  - `in_stp_max` (ID 3224)
  - `in_stp_avg` (ID 3225)
  - `in_lidar_max` (ID 3226)
  - `in_lidar_avg` (ID 3227)
  - `in_dynpres_max` (ID 3228)
  - `in_dynpres_avg` (ID 3229)

### 5.4 Interface Monitoring Metrics

- Interface frequency and timing metrics:
  - `mon_pri_motor_rpm_cmd_freq_hz` (ID 3300)
  - `mon_pri_motor_rpm_cmd_prev_ts_s` (ID 3301)
  - `mon_pri_motor_rpm_cmd_delta_t_ms` (ID 3318)
  - `mon_pri_motor_rpm_cmd_max_delta_t_ms` (ID 3319)

### 5.5 Motor Performance Monitoring

- Motor performance timing metrics:
  - `mon_motor_perf_1_time_since_last_msg_ms` (ID 3320)
  - `mon_motor_perf_2_time_since_last_msg_ms` (ID 3321)
  - `mon_motor_perf_3_time_since_last_msg_ms` (ID 3322)
  - `mon_motor_perf_4_time_since_last_msg_ms` (ID 3323)
  - `mon_motor_perf_5_time_since_last_msg_ms` (ID 3324)
  - `mon_motor_perf_6_time_since_last_msg_ms` (ID 3325)
  - Maximum timing metrics for each motor (IDs 3326-3331)

### 5.6 RAIM Performance Metrics

- RAIM timing metrics:
  - `mon_raim_full_max` (ID 3419)
  - `mon_raim_full_avg` (ID 3420)
  - `mon_raim_pre_step_max` (ID 3421)
  - `mon_raim_pre_step_avg` (ID 3422)
  - `mon_raim_step_max` (ID 3423)
  - `mon_raim_step_avg` (ID 3424)
  - `mon_raim_post_step_max` (ID 3425)
  - `mon_raim_post_step_avg` (ID 3426)

- RAIM phase timing metrics:
  - `mon_raim_phase_kMea_max` (ID 3427)
  - `mon_raim_phase_kMea_avg` (ID 3428)
  - `mon_raim_phase_kFul_max` (ID 3429)
  - `mon_raim_phase_kFul_avg` (ID 3430)
  - `mon_raim_phase_kSin_max` (ID 3431)
  - `mon_raim_phase_kSin_avg` (ID 3432)
  - `mon_raim_phase_kGal_max` (ID 3433)
  - `mon_raim_phase_kGal_avg` (ID 3434)
  - `mon_raim_phase_kGps_max` (ID 3435)
  - `mon_raim_phase_kGps_avg` (ID 3436)
  - `mon_raim_phase_kFau_max` (ID 3437)
  - `mon_raim_phase_kFau_avg` (ID 3438)

### 5.7 Position Monitoring Variables

- Vehicle state position variables:
  - `vs_pos_lon_origin` (ID 3462)
  - `vs_pos_lat_origin` (ID 3463)
  - `vs_pos_h_origin` (ID 3464)
  - `vs_pos_lon_est` (ID 3465)
  - `vs_pos_lat_est` (ID 3466)
  - `vs_pos_h_est` (ID 3467)
  - `vs_pos_roll_pos_from_ned_deg` (ID 3468)
  - `vs_pos_pitch_pos_from_ned_deg` (ID 3469)
  - `vs_pos_yaw_pos_from_ned_deg` (ID 3470)
  - Position vectors in different frames (IDs 3471-3476)
  - Position error metrics:
    - `vs_pos_alongtrack_err_m` (ID 3477)
    - `vs_pos_crosstrack_err_m` (ID 3478)
    - `vs_pos_altitude_err_m` (ID 3479)
    - Maximum error values (IDs 3480-3482)

### 5.8 Takeoff and Landing Variables

- Takeoff point variables:
  - `mmdp_top_of_takeoff_lon` (ID 3483)
  - `mmdp_top_of_takeoff_lat` (ID 3484)
  - `mmdp_top_of_takeoff_h` (ID 3485)
  - `dsm_takeoff_hae_diff_m` (ID 3489)

- Locker delivery check variables:
  - `mon_locker_del_chk_min_hat_m` (ID 3486)
  - `mon_locker_del_chk_v_down_max_m_per_s` (ID 3487)
  - `mon_locker_del_chk_min_recovery_hat_m` (ID 3488)

### 5.9 Switchover Test Timing Variables

- Switchover test timing variables:
  - `sol_t_switchover_test_start_ms` (ID 3490)
  - `dsm_t_switchover_test_start_ms` (ID 3491)
  - `dsm_t_switchover_test_failed_ms` (ID 3492)
  - `dsm_t_switchover_test_passed_ms` (ID 3493)
  - `loss_checks_t_pri_rpm_failed_ms` (ID 3494)
  - `loss_checks_t_last_primary_rpm_ms` (ID 3495)

## 6. Monitor User Variables (ver_spdif_muvar.xml)

The monitor user variables file defines variables that track user-visible system states:

### 6.1 Control System Variables

- `control motor enable intent` (ID 1000)
- `control disabled motor` (ID 1001)
- `control motor arm intent` (ID 1002)
- `control motor source` (ID 1003)

### 6.2 Controller Mode Variables

- `controllers mode` (ID 1100)
- `ttcg tracked phase` (ID 1101)
- `ttcg route id` (ID 1102)
- `ttcg route status` (ID 1103)
- `ttcg maneuver id` (ID 1104)
- `ttcg maneuver status` (ID 1105)
- `ttcg transition tracking method` (ID 1106)
- `ttcg transition speed mode` (ID 1107)
- `tsc tracking mode` (ID 1108)

### 6.3 State Machine Variables

- `sm integrators mode` (ID 1109)
- `sm land mode` (ID 1110)
- `sm takeoff mode` (ID 1111)
- `sm controllers mode` (ID 1112)
- `sm degradation level` (ID 1113)
- `sm gain type` (ID 1114)
- `mixer solver status` (ID 1115)
- `recovery previous track phase` (ID 1116)

### 6.4 Monitor Status Variables

- `mon_motor_perf_chk_num_timed_out` (ID 1201)
- `mon_drone_mode` (ID 1202)

### 6.5 Navigation Variables

- `Initializer imu measurements count` (ID 1150)
- `nav_imu_meas_avg` (ID 1151)
- `nav_imu_meas_max` (ID 1152)

### 6.6 RAIM Status Variables

- `mon_raim_num_valid_gps_svs` (ID 1138)
- `mon_raim_num_valid_galileo_svs` (ID 1139)
- `mon_raim_phase` (ID 1140)
- `mon_raim_status` (ID 1141)
- `mon_raim_dgnss_corrections_status` (ID 1142)
- `mon_raim_num_consecutive_successful_solutions` (ID 1143)
- `mon_raim_week` (ID 1144)
- `mon_raim_n_sv_used` (ID 1145)

### 6.7 Takeoff Variables

- `mmdp_top_of_takeoff_maneuver_id` (ID 1203)

## 7. Status Reporting Configuration (ver_spdif_status.xml)

The status reporting configuration enables VCP (Vehicle Control Protocol) transmission with a period of 1.0 second.

## 8. Variable Initialization (ver_spdif_varini.xml)

The variable initialization file sets initial values for several monitoring variables:

- GPS output inhibit active: Enabled (ID 1420, value 1.0)
- Enable Monitor Nav: Enabled (ID 1430, value 1.0)
- Navigation parameter scaling factors:
  - Position horizontal scaling: 0.5 (ID 3244)
  - Position vertical scaling: 0.5 (ID 3245)
  - Velocity scaling: 0.9 (ID 3246)
  - GNSS agreement threshold: 10.0 (ID 3247)
- RAIM DGNSS corrections: Enabled (ID 1475, value 1.0)

## 9. Error Handling and Contingency Logic

The monitoring system implements comprehensive error handling and contingency logic:

### 9.1 Interface Loss Detection

The system continuously monitors interface activity and triggers failures when timeouts occur:
- Primary motor RPM command: 80ms timeout
- Primary state estimate: 100ms timeout
- Primary control monitored data: 100ms timeout
- Recovery state estimate: 200ms timeout
- Recovery motor RPM command: 200ms timeout
- Primary CCP heartbeat: 1000ms timeout
- VMS monitored data: 1000ms timeout
- Primary onground heartbeat: 500ms timeout
- Air data heartbeat: 500ms timeout
- Monitor recovery controller command: 1000ms timeout

### 9.2 Motor Performance Monitoring

The system monitors motor performance and triggers a failure if more than one motor times out (80ms timeout).

### 9.3 Navigation Checks

The system performs multiple navigation checks:
- Primary attitude check: Verifies heading error (max 20°) and tilt error (max 7°)
- Recovery attitude check: Verifies heading error (max 15°) and tilt error (max 5°)
- Position checks: Verifies horizontal and vertical position differences
- Velocity check: Verifies velocity error norm (max 1.5 m/s)

### 9.4 Vehicle State Checks

The system performs extensive vehicle state checks:
- Position check: Verifies along-track, cross-track, and altitude errors
- Linear velocity check: Verifies azimuth, flight path angle, horizontal velocity, and vertical velocity errors
- Angular velocity check: Verifies roll rate, pitch rate, and yaw rate errors
- Attitude check: Verifies bank angle, pitch, and yaw errors

### 9.5 Contingency Thresholds

The system defines two sets of thresholds for each check:
- Normal thresholds: Used for standard operation
- Contingency thresholds: Higher limits used during contingency operations

### 9.6 Inhibit Logic

The system includes multiple inhibit flags that can suppress specific checks:
- Disarm inhibit
- Power-on inhibit
- Uplink inhibit
- Recovery unhealthy inhibit
- MEP output inhibit
- Air data system fault inhibit
- GPS output inhibit
- IMU saturation inhibit

### 9.7 Switchover Logic

The system includes logic to switch from primary to recovery control:
- Switchover test before takeoff
- Switchover triggered by interface losses
- Switchover triggered by navigation check failures
- Switchover triggered by vehicle state check failures

### 9.8 Locker Delivery Check

Special checks for package delivery operations:
- Minimum height above target: 1.3m
- Maximum downward velocity: 3.0 m/s
- Minimum recovery height: 1.3m
- Switchover delay: 120ms
- Minimum downward acceleration: -2.45 m/s²
- Minimum downward jerk: -6.0 m/s³

### 9.9 Disarm Check

Checks performed before disarming:
- Position relative to takeoff/landing points
- Maximum roll/pitch angles
- Ground contact detection via jerk

## 10. Relationship Between Monitoring and Recovery System

The monitoring system is tightly integrated with the recovery system:

1. **Detection and Triggering**: The monitoring system continuously checks for anomalies and triggers the recovery system when necessary.

2. **Recovery Status Tracking**: Multiple monitor bits track recovery system status:
   - `recovery is in control` (ID 1306)
   - `recovery tracking has started` (ID 1307)
   - `recovery is armed allowed` (ID 1308)
   - `recovery arming disallowed` (ID 1309)
   - `recovery takeoff executed` (ID 1310)
   - `recovery initial tracking point set` (ID 1311)
   - `recovery pre takeoff cmd` (ID 1317)

3. **Recovery Interface Monitoring**: The system monitors recovery interfaces:
   - `mon_rec_motor_rpm_cmd_aic_active` (ID 1409)
   - `mon_rec_state_estimate_aic_active` (ID 1410)

4. **Recovery Inhibit Control**: The system can inhibit recovery activation:
   - `mon_rec_unhealthy_inhibit_active` (ID 1417)

5. **Recovery Attitude Checks**: Specific checks for recovery system attitude:
   - Maximum heading error: 15.0 degrees
   - Maximum tilt error: 5.0 degrees

6. **Recovery Position Checks**: Specific checks for recovery system position:
   - Maximum horizontal difference: 30.0 m
   - Maximum vertical difference: 30.0 m
   - Maximum horizontal difference with DGNSS: 30.0 m
   - Maximum vertical difference with DGNSS: 30.0 m
   - Worst-case delay: 60.0 ms

7. **Switchover Logic**: The monitoring system determines when to switch from primary to recovery control based on various failure conditions.

8. **Recovery Tracking**: The system tracks recovery system phase:
   - `recovery previous track phase` (ID 1116)

## 11. File-by-File Breakdown

### 11.1 ver_spdif_mbit.xml
Defines the monitor bits configuration with IDs and descriptions for system state flags, recovery status, interface monitoring, performance tests, inhibit flags, check failures, navigation status, GNSS status, vehicle state monitoring, and drone state machine flags.

### 11.2 ver_spdif_tm.xml
Configures three telemetry streams operating at 20Hz, each transmitting different sets of monitoring data including system status, motor performance, navigation data, interface activity, check failures, GNSS status, position data, and RAIM performance metrics.

### 11.3 ver_spdif_amz_mon_param.xml
Defines monitoring parameters including switchover logic, loss checks, navigation checks, vehicle state checks, locker delivery check, disarm check, drone state machine parameters, VMS checks, PDS control, scheduler inputs, and DGNSS unavailable delay.

### 11.4 ver_spdif_mrvar.xml
Defines monitor runtime variables for tracking navigation performance, estimator performance, input processing, interface monitoring, motor performance, RAIM performance, position monitoring, takeoff and landing, and switchover test timing.

### 11.5 ver_spdif_muvar.xml
Defines monitor user variables for tracking control system state, controller modes, state machine variables, monitor status, navigation variables, RAIM status, and takeoff variables.

### 11.6 ver_spdif_mexvar.xml
Defines an empty map for monitor external variables.

### 11.7 ver_spdif_mvars.xml
Defines variable name arrays for different variable types.

### 11.8 ver_spdif_status.xml
Configures status reporting with VCP transmission enabled and a period of 1.0 second.

### 11.9 ver_spdif_varini.xml
Initializes monitoring variables including GPS output inhibit, navigation monitoring, and parameter scaling factors.

### 11.10 ver_spdif_varacc.xml, ver_spdif_vargyr.xml, ver_spdif_varmag.xml, ver_spdif_varstp.xml, ver_spdif_varqinf.xml
Define variable access configurations for different sensor types, all currently disabled.

### 11.11 ver_spdif_cbitcfg.xml
Defines an empty configuration for continuous built-in tests.

### 11.12 ver_spdif_chklist.xml
Defines an empty checklist configuration.

### 11.13 ver_opdif_tmcompl.xml
Configures a complementary telemetry stream operating at 10Hz (0.1s period) with various system status and performance metrics.

## 12. Cross-Component Relationships

The monitoring system interacts with several other drone subsystems:

1. **Primary Control System**: Monitored through interfaces for motor RPM commands, state estimates, control monitoring data, and heartbeats.

2. **Recovery Control System**: Monitored through interfaces for motor RPM commands and state estimates.

3. **Navigation System**: Monitored through position, attitude, and velocity checks.

4. **Vehicle State Machine**: Monitored through various state flags and timing parameters.

5. **Motor System**: Monitored through performance checks and RPM command interfaces.

6. **Air Data System**: Monitored through heartbeat interface.

7. **GNSS System**: Monitored through RAIM status and position checks.

8. **Package Delivery System (PDS)**: Monitored through locker delivery checks.

The monitoring system serves as a central oversight mechanism that ensures all these components operate within their specified parameters and triggers appropriate responses when anomalies are detected.