# Generated from:

- sw_vbootloader_astro/code/include/Bootloader_astro.h (413 tokens)
- sw_vbootloader_astro/code/source_astro/Bootloader_astro.cpp (944 tokens)
- sw_vbootloader_astro/code/source_astro/Bootloader_pa.cpp (1245 tokens)
- sw_vbootloader_astro/code/source_astro/main_2838x_bldr_astro.cpp (1333 tokens)

---

# Astro Bootloader Architecture: High-Fidelity Semantic Knowledge Graph

## Core Architecture Overview

The Astro bootloader system is a multi-core bootloader implementation designed for the Astro platform. It follows a hierarchical class structure with `Bootloader_astro` inheriting from `Bootloader_dual`, which likely inherits from a base `Bootloader` class. The system manages three processor cores: C1 (main CPU), C2 (secondary CPU), and CM (communication/management core).

## Class Hierarchy and Structure

### Bootloader_astro Class

`Bootloader_astro` extends the `Bootloader_dual` class with Astro-specific functionality:

```cpp
class Bootloader_astro : public Bootloader_dual {
public:
    Bootloader_astro(Bldr_mgr::Params par, Base::IAddress_handler& addr_handler);

private:
    SPI spic;                               // SPI-C device
    Base::Tport<SPI, SPI> spic_port;        // Itport interface to wrap a SPI-C device
    GPIOv flash_cs;                         // Chip Select for SPI-C, connected to flash memory
    Devices::MX66L drv;                     // MX66L driver (flash memory)
    DFS2::DFS2_fs fs;                       // File System
    Base::Timeprovider_null tprov_null;     // Null Time Provider instance
    Base::Reset_null rnull;                 // Null Reset instance
    Media::HformatSD format_hnd;            // File system format handler
};
```

The class manages:
- SPI communication with flash memory
- File system operations
- GPIO control for chip select
- Format handling for storage

### Constructor Implementation

The `Bootloader_astro` constructor initializes the hardware interfaces and configures the system:

1. Initializes the parent `Bootloader_dual` class
2. Sets up GPIO pins for SPI-C communication
3. Configures SPI-C with specific parameters:
   - 12.5 MHz speed
   - 8-bit data width
   - SPI mode 0
4. Registers the format handler with the STANAG message manager
5. Initializes the file system

```cpp
Bootloader_astro::Bootloader_astro(Bldr_mgr::Params par, Base::IAddress_handler& addr_handler) :
    Bootloader_dual(par, addr_handler),
    flash_cs(GPIOname::gpio_spic_cs),
    spic(SPI::spi_id_c),
    spic_port(spic, spic),
    drv(spic_port, flash_cs),
    tprov_null(),
    fs(drv, tprov_null, Base::vu_none, Base::kbit_none),
    rnull(),
    format_hnd(fs, rnull)
{
    // SPI configuration
    static const Uint32 spic_usd_speed = 12500000UL;
    static const Uint8 spi_nbits = 8;
    
    // Configure GPIO pins for SPI-C
    GPIOdev::apply4_spi<mux_spic, GPIOname::gpio_spic_simo, GPIOname::gpio_spic_somi,
        GPIOname::gpio_spic_sclk, GPIOname::gpio_spic_cs>();
    
    // Configure SPI-C
    spic.config(SPIcfg(true, SPIcfg::smode0, spic_usd_speed, spi_nbits));
    
    // Configure chip select GPIO
    GPIOioctl::apply_output(GPIOname::gpio_spic_cs);
    
    // Register format handler
    stg_msg_mgr.add_rx_tx_hdl(Stanag_msg_type::stg_fs_format, format_hnd);
    
    // Initialize file system
    fs.init();
}
```

### Factory Method

The `Bootloader_dual::build` static method serves as a factory method to create a `Bootloader_astro` instance:

```cpp
Bootloader_dual& Bootloader_dual::build(Bldr_mgr::Params par, Base::IAddress_handler & addr_handler)
{
    static Bootloader_astro bldr2(par, addr_handler);
    return bldr2;
}
```

This pattern ensures a single instance of the bootloader is created and returned.

## GPIO Configuration

The bootloader defines specific GPIO pins for transceiver control:

```cpp
GPIOid Bootloader::get_gpio_taba_en()   { return Dsp28335_ent::gpio_100; }
GPIOid Bootloader::get_gpio_taba_nstb() { return Dsp28335_ent::gpio_113; }
GPIOid Bootloader::get_gpio_tabb_en()   { return Dsp28335_ent::gpio_131; }
GPIOid Bootloader::get_gpio_tabb_nstb() { return Dsp28335_ent::gpio_132; }
```

## CAN Communication Configuration

The bootloader implements CAN communication with security features:

### CAN Input Configuration

```cpp
void Bootloader::set_can_in_cfg(CANin_p::Config& in_cfg)
{
    static const Uint32 base_rx_id = 0x740;
    const Uint32 id = Bsp::get_uid().phy;
    in_cfg.port = static_cast<CANport::Port>(CANport::can_all);
    in_cfg.filter.can_filter.id.extended = false;
    in_cfg.filter.can_filter.id.id = base_rx_id + id;
    in_cfg.filter.can_filter.msk = CANid::id_msk_std;
}
```

### CAN Configuration

```cpp
void Bootloader::set_can_cfg(CANin_p::Config& in_cfg,
                             CANout_c::Config& out_cfg,
                             SerialCAN::Config& sc_cfg)
{
    static const Uint32 base_tx_id = 0x700;
    const Uint32 id = Bsp::get_uid().phy;
    
    set_can_in_cfg(in_cfg);
    out_cfg.port = in_cfg.port;
    sc_cfg.timeout = SerialCAN_consts::def_115K_timeout;
    sc_cfg.id.extended = false;
    sc_cfg.id.id = base_tx_id + id;
}
```

### Secure CAN Configuration

The `config_can` method configures CAN communication with security features:

1. Sets up GPIO pins for CAN communication
2. Configures transceivers with security settings
3. Sets up CAN filters and baudrates
4. Enables different CAN interfaces based on the system type (Astro or IPC)

```cpp
void Bootloader::config_can(bool as_master)
{
    // Configure GPIO pins for CAN
    Dsp28335_ent::GPIOdev::apply_can<mux_canfd_a, Dsp28335_ent::gpio_018, Dsp28335_ent::gpio_019>();
    
    // Configure transceiver control pins
    GPIOioctl::apply_output(get_gpio_taba_en());
    GPIOioctl::apply_output(get_gpio_taba_nstb());
    GPIOioctl::apply_output(get_gpio_tabb_en());
    GPIOioctl::apply_output(get_gpio_tabb_nstb());
    
    // Default CAN configuration
    CANcfg cfg_can = {0,0};
    Midlevel::Default_cfg::set_default_can_500(cfg_can, false, as_master);
    
    // Configure CAN input
    CANin_p::Config can_in_cfg;
    set_can_in_cfg(can_in_cfg);
    
    // Apply filter configuration
    CANcfg cancfg_stab = cfg_can;
    cancfg_stab.rx[0].flt = can_in_cfg.filter.can_filter;
    cancfg_stab.rx[0].sz = Midlevel::Default_cfg::def_nb_rx_mboxes;
    
    // Configure secure CAN transceivers
    Secure_CAN stab_b(get_gpio_tabb_en(), get_gpio_tabb_nstb());
    
    // Different configuration based on system type
    if(Bsp::is_astro(static_cast<Bsp::Sysapp>(Bsp::get_uid().app)))
    {
        stab_b.enable_transceiver(hal.cana, Secure_CAN::cfg_open_commands);
        hal.cana.config(cancfg_stab);
        hal.canb.config(cfg_can);
    }
    else
    {
        // IPC configuration
        stab_b.enable_transceiver(hal.canb, Secure_CAN::cfg_open_commands);
        hal.canb.config(cancfg_stab);
    }
    
    // Configure CAN-FD
    Secure_CAN stab_a(get_gpio_taba_en(), get_gpio_taba_nstb());
    stab_a.enable_transceiver(hal.can_fd, Secure_CAN::cfg_open_commands);
    
    CAN_FD_cfg cfg;
    Midlevel::Default_cfg::set_default_can_fd(cfg,
                                             CAN_FD_cfg::bd_500K,
                                             CAN_FD_cfg::bd_2M,
                                             false,
                                             as_master);
    
    cfg.rx_cfg[0].flt = can_in_cfg.filter.can_filter;
    cfg.rx_cfg[0].sz = Midlevel::Default_cfg::def_nb_rx_mboxes;
    
    hal.can_fd.config(cfg);
}
```

## Security Features

The bootloader includes security features through the `ECSL_only` function, which manages the Device Control Security Module (DCSM):

```cpp
void ECSL_only()
{
    using namespace Dsp28335_ent;
    DCSM::Zone& z1_regs = *reinterpret_cast<DCSM::Zone*>(DCSM::zone1_base_addr);
    DCSM::Zone& z2_regs = *reinterpret_cast<DCSM::Zone*>(DCSM::zone2_base_addr);
    
    // If unsecured, secure again and leave just JTAG available
    static const Uint32 def_value = 0xFFFFFFFF;
    static const Uint32 def_z1_value = 0x4d7fffff;
    static const Uint32 def_z2_value = 0x1F7fffff;
    
    if(z1_regs.ctrl.unsecure)
    {
        // Configure Zone 1 security keys
        if((z1_regs.key.key0 != def_value) ||
           (z1_regs.key.key1 != def_z1_value) ||
           (z1_regs.key.key2 != def_value) ||
           (z1_regs.key.key3 != def_value))
        {
            z1_regs.key.key0 = def_value;
            z1_regs.key.key1 = def_z1_value;
            z1_regs.key.key2 = def_value;
            z1_regs.key.key3 = def_value;
            z1_regs.ctrl.forze_sec = 1;
        }
        
        // Configure Zone 2 security keys
        if((z2_regs.key.key0 != def_value) ||
           (z2_regs.key.key1 != def_z2_value) ||
           (z2_regs.key.key2 != def_value) ||
           (z2_regs.key.key3 != def_value))
        {
            z2_regs.key.key0 = def_value;
            z2_regs.key.key1 = def_z2_value;
            z2_regs.key.key2 = def_value;
            z2_regs.key.key3 = def_value;
            z2_regs.ctrl.forze_sec = 1;
        }
    }
}
```

This function checks if the security zones are unsecured and, if so, applies security keys and forces security mode, while still allowing JTAG access.

## Main Application Entry Point

The `main` function serves as the entry point for the bootloader:

```cpp
int main()
{
    // Uncomment to enable JTAG only security
    // ECSL_only();
    
    // Memory layout constants
    static const Uint32 flash_start = 0x80000UL;        // Flash starting address
    static const Uint32 flash_size  = 0x40000UL;        // Flash size (in words)
    static const Uint32 bldr_start  = flash_start;      // Address where bootloader starts
    static const Uint32 bldr_size   = 0x10000UL;        // Bootloader max size (in words)
    static const Uint32 user_start  = bldr_start + bldr_size;  // Address where user code starts
    static const Uint32 user_size   = 0x40000UL - bldr_size;   // User code size (in words)
    
    // Check bootloader header
    if(App_blr_hdr_inst<0, bldr_size, Bsp::sapp_uapp, 0U>::instance.bld_hdr_mark != Base::App_blr_hdr::hdr_bldr_mark_v)
    {
        Bsp::warning();
    }
    
    // Configure bootloader parameters
    static Bldr_mgr::Params par =
    {
        { bldr_start, words16_to_bytes_c<bldr_size>::value },    // Bootloader data block (in bytes)
        {
            3,  // Number of cores
            {
                {
                    { user_start,    words16_to_bytes_c<user_size>::value },  // User data block in C1 (in bytes)
                    { flash_start,   words16_to_bytes_c<flash_size>::value},  // User data block in C2 (in bytes)
                    { cm_user_start, cm_user_size }                           // User data block in CM (in bytes)
                }
            }
        },
        { (1U << Bldr_mgr::c1_core_index) | (1U << Bldr_mgr::c2_core_index) }  // Managed cores bitmask
    };
    
    // Initialize shared memory for inter-core communication
    CPU1_CM_shared& shared_c1 = get_c1_writer();
    shared_c1.uid      = Bsp::get_uid();
    shared_c1.sys_addr = shared_c1.uid.phy;
    
    // Configure Ethernet MAC address based on device UID
    static const Uint32 mask24 = 0x00FFFFFFUL;
    shared_c1.eth_mac  = 0xA863F2000000 | (shared_c1.uid.phy & mask24);
    
    // Configure IP address and network mask
    Bsp::get_ip_cfg_pa(shared_c1.uid, shared_c1.ip_addr, shared_c1.net_mask);
    
    // Configure communication ports
    shared_c1.port_stg = Routing_table_data<0,0>::def_stg_port;
    shared_c1.port_cy  = Routing_table_data<0,0>::def_cyphal_port;
    
    // Adjust ports based on application type
    const Bsp::Sysapp app_id = static_cast<Bsp::Sysapp>(Bsp::get_uid().app);
    switch(app_id)
    {
        case Bsp::sapp_pam:
            shared_c1.port_stg += 10U;
            break;
        case Bsp::sapp_par_nav:
            shared_c1.port_stg += 11U;
            break;
        case Bsp::sapp_par_ctrl:
            shared_c1.port_stg += 12U;
            break;
    }
    
    // Configure heartbeat LED
    shared_c1.heartbeat_led_id = Dsp28335_ent::gpio_129;  // Blue LED pin ID
    
    // Initialize CM core
    Ipc::turn_off_cm();
    CM_helpers::cm_init_start(Halsuite::get_eth_cfg());
    
    // Configure heartbeat LED GPIO
    GPIOioctl::apply_output(static_cast<GPIOid>(shared_c1.heartbeat_led_id), GPIOioctl::cm);
    
    // Boot CM core with bootloader command
    Ipc::set_cm_command(Bsp::bldr_force_bldr_cmd);
    Dsp28335_ent::Delay::ms(1);
    CM_helpers::cm_boot();
    Dsp28335_ent::Delay::ms(1);
    Ipc::set_cm_command(0);  // Clear command
    
    // Create address handler and bootloader instance
    Address_handler addr_handler(Bsp::sysaddr(), par.cores_managed, true);
    Bootloader_dual& bldr = Bootloader_dual::build(par, addr_handler);
    
    // Complete CM initialization
    CM_helpers::cm_init_end();
    
    // Run the bootloader
    bldr.run();
}
```

## Memory Management and Layout

The bootloader defines a specific memory layout for the system:

```
Flash memory:
- Start address: 0x80000
- Total size: 0x40000 words

Bootloader:
- Start address: 0x80000 (same as flash start)
- Size: 0x10000 words

User application:
- Start address: 0x90000 (flash_start + bldr_size)
- Size: 0x30000 words (flash_size - bldr_size)

CM core has its own memory region:
- Start address: cm_user_start (defined elsewhere)
- Size: cm_user_size (defined elsewhere)
```

## Multi-Core Management

The bootloader manages three cores:
1. **C1 (Core 1)**: Main CPU, runs the bootloader
2. **C2 (Core 2)**: Secondary CPU
3. **CM (Communication Module)**: Handles communication tasks

The cores are managed through:

1. **Shared Memory**: `CPU1_CM_shared` structure for inter-core communication
2. **IPC (Inter-Processor Communication)**: Commands sent between cores
3. **Core Boot Sequence**:
   - CM core is initialized with `CM_helpers::cm_init_start`
   - CM core is booted with `CM_helpers::cm_boot`
   - CM initialization is completed with `CM_helpers::cm_init_end`

## Network Configuration

The bootloader configures network parameters for the system:

1. **Ethernet MAC Address**: Derived from the device UID
   ```cpp
   shared_c1.eth_mac = 0xA863F2000000 | (shared_c1.uid.phy & mask24);
   ```

2. **IP Address and Network Mask**: Configured based on device UID
   ```cpp
   Bsp::get_ip_cfg_pa(shared_c1.uid, shared_c1.ip_addr, shared_c1.net_mask);
   ```

3. **Communication Ports**: Configured based on application type
   ```cpp
   shared_c1.port_stg = Routing_table_data<0,0>::def_stg_port;
   shared_c1.port_cy = Routing_table_data<0,0>::def_cyphal_port;
   
   // Adjust ports based on application type
   switch(app_id) {
       case Bsp::sapp_pam:
           shared_c1.port_stg += 10U;
           break;
       case Bsp::sapp_par_nav:
           shared_c1.port_stg += 11U;
           break;
       case Bsp::sapp_par_ctrl:
           shared_c1.port_stg += 12U;
           break;
   }
   ```

## Boot Sequence

The complete boot sequence is:

1. Check and potentially configure security settings (ECSL_only - commented out)
2. Verify bootloader header
3. Configure bootloader parameters with memory layout
4. Initialize shared memory for inter-core communication
5. Configure network parameters (Ethernet MAC, IP, ports)
6. Initialize and boot the CM core
7. Create the bootloader instance using the factory method
8. Complete CM initialization
9. Run the bootloader

## Conclusion

The Astro bootloader is a sophisticated multi-core bootloader system with:

1. **Hierarchical Class Structure**: `Bootloader_astro` extends `Bootloader_dual`
2. **Multi-Core Management**: Manages C1, C2, and CM cores
3. **Memory Management**: Defines specific memory regions for bootloader and user applications
4. **Communication Interfaces**: Configures SPI, CAN, and network interfaces
5. **Security Features**: Includes DCSM security configuration
6. **File System Support**: Integrates with DFS2 file system for flash storage

The bootloader provides a robust foundation for booting the Astro platform, managing multiple cores, and ensuring secure operation.