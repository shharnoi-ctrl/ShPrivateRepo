# Generated from:

- items/pdi_Monitor/setup/ver_spdif_amz_rec_param.xml (3196 tokens)
- items/pdi_Monitor/setup/ver_spdif_amz_lights.xml (24431 tokens)
- items/pdi_Monitor/setup/ver_spdif_amz_site_config.xml (165 tokens)
- items/pdi_Monitor/setup/ver_spdif_amz_activated_prescription_config.xml (95 tokens)
- items/pdi_Monitor/setup/ver_spdif_amz_pds_offset.xml (110 tokens)
- items/pdi_Monitor/setup/ver_spdif_amz_route.xml (60 tokens)
- items/pdi_Monitor/setup/ver_spdif_pdi_mode.xml (63 tokens)
- items/pdi_Monitor/setup/ver_spdif_overwrit.xml (92 tokens)
- items/pdi_Monitor/setup/ver_spdif_pfields.xml (52 tokens)
- items/pdi_Monitor/setup/Cage Flight/ver_spdif_varini.xml (91 tokens)
- items/pdi_Monitor/setup/HILSim/ver_spdif_varini.xml (91 tokens)
- items/pdi_Monitor/operation/ver_opdif_obstacle.xml (70 tokens)
- items/pdi_Monitor/operation/ver_opdif_polymgr.xml (189 tokens)
- items/pdi_Monitor/operation/ver_opdif_flyto-setup-map.xml (58 tokens)
- items/pdi_Monitor/operation/ver_opdif_fmgr.xml (63 tokens)
- items/pdi_Monitor/operation/ver_opdif_runway.xml (62 tokens)
- items/pdi_Monitor/operation/ver_opdif_marks.xml (50 tokens)
- items/pdi_Monitor/operation/ver_opdif_arctrim0.xml (367 tokens)
- items/pdi_Monitor/operation/ver_opdif_arctrim1.xml (367 tokens)
- items/pdi_Monitor/operation/ver_opdif_arctrim2.xml (367 tokens)
- items/pdi_Monitor/operation/ver_opdif_arctrim3.xml (367 tokens)
- items/pdi_Monitor/operation/ver_opdif_rrefs.xml (50 tokens)
- items/pdi_Monitor/operation/ver_opdif_evt-wp-groups.xml (56 tokens)
- items/pdi_Monitor/operation/ver_opdif_mgeocage.xml (83 tokens)
- items/pdi_Monitor/operation/ver_opdif_troute.xml (66 tokens)
- items/pdi_Monitor/production/ver_ppdif_arbaddr.xml (79 tokens)

## With context from:

- Amazon-PrimeAir/items/ASTRO/items/EV2/Monitor/02_Monitoring_Systems.md (8166 tokens)
- Amazon-PrimeAir/items/ASTRO/items/EV2/Monitor/02_Control_Systems.md (3437 tokens)
- Amazon-PrimeAir/items/ASTRO/items/EV2/Monitor/02_Navigation_Systems.md (3723 tokens)

---

# Comprehensive Analysis of Mission Management Systems in the Drone Control Platform

## 1. Recovery System Configuration (ver_spdif_amz_rec_param.xml)

The recovery system configuration defines parameters for mission phase detection, route planning, and control system behavior during normal and contingency operations.

### 1.1 General Recovery Configuration

- **Version**: 7.3.1
- **Switchover Control**:
  - `is_switchover_enabled`: 1 (enabled)
  - `enable_preflight_switchover_test`: 0 (disabled)
  - `enable_preflight_health_checks`: 0 (disabled)
  - `dt_to_arm_motors_after_mrs_s`: 5.0 seconds
  - `dt_to_disarm_after_in_air_motors_disabled_low_rpm_s`: 0.0 seconds
  - `recovery_alerts_output_dt_s`: 0.0 seconds
  - `use_cx3_wind_estimates`: 1 (enabled)

### 1.2 Recovery Mission Phase Detection (RMPF)

The system uses multiple parameters to detect different mission phases:

```xml
<rmpf>
    <altitude_agl_on_ground_vf_origin_m>0.48</altitude_agl_on_ground_vf_origin_m>
    <pretakeoff_to_takeoff_agl_threshold_m>1.0</pretakeoff_to_takeoff_agl_threshold_m>
    <pretakeoff_to_takeoff_velocity_threshold_m_per_s>0.5</pretakeoff_to_takeoff_velocity_threshold_m_per_s>
    <pretakeoff_to_takeoff_acceleration_threshold_m_per_s2>2.6</pretakeoff_to_takeoff_acceleration_threshold_m_per_s2>
    <takeoff_to_flight_altitude_offset_threshold_m>0.5</takeoff_to_flight_altitude_offset_threshold_m>
    <takeoff_to_landing_vertical_velocity_threshold_m_per_s>0.5</takeoff_to_landing_vertical_velocity_threshold_m_per_s>
    <flight_to_landing_altitude_offset_threshold_m>1.0</flight_to_landing_altitude_offset_threshold_m>
    <flight_to_landing_final_position_horz_threshold_m>10.0</flight_to_landing_final_position_horz_threshold_m>
    <flight_to_landing_groundspeed_threshold_m_per_s>0.5</flight_to_landing_groundspeed_threshold_m_per_s>
</rmpf>
```

These parameters define thresholds for detecting transitions between:
- Pre-takeoff to takeoff (based on altitude, velocity, and acceleration)
- Takeoff to flight (based on altitude offset)
- Flight to landing (based on altitude, position, and groundspeed)

### 1.3 Recovery Route Configuration (RRC)

```xml
<rrc>
    <v_min_for_route_planning_m_per_s>0.2</v_min_for_route_planning_m_per_s>
</rrc>
```

This defines the minimum velocity (0.2 m/s) required for route planning in the recovery system.

### 1.4 Recovery Control Parameters

```xml
<min_battery_soc_for_use_cp>1000</min_battery_soc_for_use_cp>
<max_battery_soc_for_land_cp>2300</max_battery_soc_for_land_cp>
<enable_oic_commanded_land_contingency>0</enable_oic_commanded_land_contingency>
<enable_bounding_box_protection>1</enable_bounding_box_protection>
<bounding_box_logging_dt_s>1.0</bounding_box_logging_dt_s>
<use_mission_bounding_box_dimensions>0</use_mission_bounding_box_dimensions>
<bounding_box_half_length_m>5.0</bounding_box_half_length_m>
<bounding_box_half_width_m>5.0</bounding_box_half_width_m>
<bounding_box_half_height_m>10.0</bounding_box_half_height_m>
```

Key features:
- Battery state-of-charge thresholds for control decisions
- Bounding box protection enabled with 5m x 5m x 10m dimensions
- OIC commanded land contingency disabled

### 1.5 Logging Configuration

```xml
<logging>
    <suppress_control_log_output>0</suppress_control_log_output>
    <suppress_recovery_telemetry_output>1</suppress_recovery_telemetry_output>
    <recovery_telemetry_output_dt_s>0.0</recovery_telemetry_output_dt_s>
    <suppress_recovery_controller_telemetry_output>0</suppress_recovery_controller_telemetry_output>
    <recovery_controller_telemetry_output_dt_s>0.1</recovery_controller_telemetry_output_dt_s>
</logging>
```

The configuration enables control logs and recovery controller telemetry (at 10Hz) but suppresses general recovery telemetry.

### 1.6 GNSS Configuration

```xml
<gnss>
    <use_receiver_pvt>0</use_receiver_pvt>
    <use_gnss_A_true_B_false>1</use_gnss_A_true_B_false>
    <max_vert_pos_accuracy_m>75.0</max_vert_pos_accuracy_m>
    <max_horiz_pos_accuracy_m>45.0</max_horiz_pos_accuracy_m>
</gnss>
```

The system is configured to:
- Use GNSS receiver A (primary)
- Not use receiver PVT directly
- Accept vertical position accuracy up to 75m
- Accept horizontal position accuracy up to 45m

### 1.7 Navigation Configuration

The navigation section includes detailed parameters for:

#### 1.7.1 Wind Estimation
```xml
<wind_estimate_source>
    <value>1</value>
</wind_estimate_source>
<wind_params>
    <tau_s>10.0</tau_s>
    <latch_ias_threshold_m_per_s>25.0</latch_ias_threshold_m_per_s>
</wind_params>
```

#### 1.7.2 Installation Geometry
Defines the transformation matrices and vectors between vehicle frame (VF) and various sensors:
- IMU position and orientation
- GNSS antenna positions (A and B)
- Laser sensor position and orientation

#### 1.7.3 Air Data Processing
```xml
<air_data>
    <dynpres_lpf_tau_s>0.6168</dynpres_lpf_tau_s>
</air_data>
```

#### 1.7.4 Heading Updates
```xml
<heading>
    <max_update_innovation_threshold_rad>0.7854</max_update_innovation_threshold_rad>
    <enable_heading_updates>1</enable_heading_updates>
</heading>
```

#### 1.7.5 Ground Detection
```xml
<onground>
    <jerk_threshold_m_per_s3>3.5</jerk_threshold_m_per_s3>
    <jerk_window_s>0.75</jerk_window_s>
    <num_motors_to_takeoff>4</num_motors_to_takeoff>
    <takeoff_rpm>1500</takeoff_rpm>
    <land_threshold_vel_m_per_s>0.25</land_threshold_vel_m_per_s>
    <land_threshold_vel_cmd_m_per_s>0.75</land_threshold_vel_cmd_m_per_s>
    <land_threshold_vel_cmd_timeout_s>2.0</land_threshold_vel_cmd_timeout_s>
    <recovery_in_control_timeout_s>2.0</recovery_in_control_timeout_s>
</onground>
```

### 1.8 Control System Configuration

The recovery configuration includes detailed parameters for multiple control subsystems:

#### 1.8.1 Attitude Augmentation Control Generator (AACG)
```xml
<aacg>
    <use_attitude_contingency_mode_blending>1</use_attitude_contingency_mode_blending>
    <attitude_contingency_mode_blending_total_time_s>2.0</attitude_contingency_mode_blending_total_time_s>
    <use_blending_based_takeoff_logic>1</use_blending_based_takeoff_logic>
</aacg>
```

#### 1.8.2 Specific Energy Processor (SEP)
```xml
<sep>
    <use_attitude_contingency_mode_blending>1</use_attitude_contingency_mode_blending>
    <attitude_contingency_mode_blending_total_time_s>2.0</attitude_contingency_mode_blending_total_time_s>
    <position_lpf_dt_gain_A_lat>0.1</position_lpf_dt_gain_A_lat>
    <!-- Additional position filter gains for different axes -->
</sep>
```

#### 1.8.3 Tracking Spline Controller (TSC)
```xml
<tsc>
    <bypass_a_hf_during_pristine>0</bypass_a_hf_during_pristine>
    <bypass_a2a_during_takeoff_and_landing>0</bypass_a2a_during_takeoff_and_landing>
    <is_v2a_output_connected_to_a2a_input>1</is_v2a_output_connected_to_a2a_input>
    <is_a_ff_cmd_connected_to_a2a_input>0</is_a_ff_cmd_connected_to_a2a_input>
    <a2a_bypass_switch_blender>
        <max_time_limit_s>2.5</max_time_limit_s>
    </a2a_bypass_switch_blender>
</tsc>
```

#### 1.8.4 Trajectory Control Generator (TCG)
```xml
<tcg>
    <waypoint_cmd_blending_time_s>3.0</waypoint_cmd_blending_time_s>
    <p_err_pos_ncg2pos_x_m_blending_rate_limit_m_per_s>2.0</p_err_pos_ncg2pos_x_m_blending_rate_limit_m_per_s>
    <!-- Additional position error blending parameters -->
    
    <ttcg>
        <inbound_transition_hs_integration_dt_override_s>0.5</inbound_transition_hs_integration_dt_override_s>
        <eas_wbf_nominal_pristine_m_per_s>30.0</eas_wbf_nominal_pristine_m_per_s>
    </ttcg>
    
    <waca>
        <airspeed_cmd_mode_blending_time_s>5.0</airspeed_cmd_mode_blending_time_s>
    </waca>
    
    <atcg>
        <is_weathervaning_enabled>1</is_weathervaning_enabled>
        <tas_awv_min_engaged_m_per_s>2.0</tas_awv_min_engaged_m_per_s>
        <tas_awv_max_rate_m_per_s>3.0</tas_awv_max_rate_m_per_s>
        <yaw_rate_max_awv_rad_per_s>0.7853982</yaw_rate_max_awv_rad_per_s>
        <yaw_rate_max_awv_land_slow_descent_rad_per_s>0.0</yaw_rate_max_awv_land_slow_descent_rad_per_s>
        <threshold_min_a_lf_cmd_z_trimncg_g>-1.5</threshold_min_a_lf_cmd_z_trimncg_g>
        <threshold_max_a_lf_cmd_z_trimncg_g>-0.6</threshold_max_a_lf_cmd_z_trimncg_g>
        <!-- Additional pitch augmentation parameters -->
    </atcg>
</tcg>
```

#### 1.8.5 Mixer Configuration
```xml
<mixer>
    <enable_state_reset>0</enable_state_reset>
    <use_actuator_hysteresis_override>0</use_actuator_hysteresis_override>
    <rotor_speed_hysteresis_half_width_krpm>0.0</rotor_speed_hysteresis_half_width_krpm>
    <use_scheduler_contingency_mode_blending>1</use_scheduler_contingency_mode_blending>
    <scheduler_contingency_mode_blending_total_time_s>2.0</scheduler_contingency_mode_blending_total_time_s>
    <mixer_params>
        <vehicle_params>
            <num_motors>6</num_motors>
            <num_control_surfaces>0</num_control_surfaces>
            <art_min_dynamic_pressure_pa>0</art_min_dynamic_pressure_pa>
        </vehicle_params>
    </mixer_params>
</mixer>
```

#### 1.8.6 State Machine (SM)
```xml
<sm>
    <track_spline>
        <max_attitude_tracking_error_rad>3.1415</max_attitude_tracking_error_rad>
        <max_angular_rate_magnitude_rad_per_s>3.1415</max_angular_rate_magnitude_rad_per_s>
        <max_horizontal_tracking_error_m>9999.0</max_horizontal_tracking_error_m>
        <max_vertical_tracking_error_m>99.0</max_vertical_tracking_error_m>
        <max_vtol_horizontal_tracking_error_m>10.0</max_vtol_horizontal_tracking_error_m>
        <max_vtol_vertical_tracking_error_m>5.0</max_vtol_vertical_tracking_error_m>
        <max_vertical_speed_m_per_s>10.0</max_vertical_speed_m_per_s>
        <max_vtol_agl_m>20.0</max_vtol_agl_m>
    </track_spline>
</sm>
```

#### 1.8.7 Command Manager (CM)
```xml
<cm>
    <takeoffmanager>
        <run_horizontal_controllers_in_onground_mode>1</run_horizontal_controllers_in_onground_mode>
    </takeoffmanager>
    <tracksplinemanager>
        <wind_gust_threshold_m_per_s>12.8</wind_gust_threshold_m_per_s>
        <wind_gust_counter_threshold>3</wind_gust_counter_threshold>
        <enable_wind_threshold_monitor_to_command_skip_delivery>1</enable_wind_threshold_monitor_to_command_skip_delivery>
    </tracksplinemanager>
    <landmanager>
        <climb_rate_fast_descent_m_per_s>-1.0</climb_rate_fast_descent_m_per_s>
    </landmanager>
</cm>
```

## 2. Lights Configuration (ver_spdif_amz_lights.xml)

The lights configuration defines the behavior of the drone's lighting system, including register settings, light states, and sequences.

### 2.1 Register Configuration

The configuration includes 40 register settings that control the light system's behavior:

```xml
<config>
    <str-tunarray-element>
        <reg>128</reg>
        <value>56</value>
    </str-tunarray-element>
    <str-tunarray-element>
        <reg>0</reg>
        <value>96</value>
    </str-tunarray-element>
    <!-- Additional register settings -->
</config>
```

Key register settings include:
- Register 128: 56 (system configuration)
- Register 0: 96 (primary control register)
- Register 129: 7 (light mode control)
- Register 130: 66 (light pattern control)
- Registers 112-127: All set to 94 (light intensity settings)

### 2.2 Light States Configuration

The configuration defines 13 different light states for both left and right light arrays. Each state includes:

1. **Phases**: Timing values that determine when lights activate within a sequence
2. **Widths**: Duration values that determine how long each light remains active

Example light state:
```xml
<str-tunarray-element>
    <phases>
        <str-tunarray-element>0</str-tunarray-element>
        <str-tunarray-element>0</str-tunarray-element>
        <!-- Additional phase values -->
        <str-tunarray-element>45</str-tunarray-element>
        <!-- Additional phase values -->
    </phases>
    <widths>
        <str-tunarray-element>0</str-tunarray-element>
        <str-tunarray-element>0</str-tunarray-element>
        <!-- Additional width values -->
        <str-tunarray-element>25</str-tunarray-element>
        <!-- Additional width values -->
    </widths>
</str-tunarray-element>
```

### 2.3 Light Sequences

The configuration defines 11 different light sequences, each specifying which light states to use for left and right light arrays:

```xml
<sequences>
    <str-tunarray-element>
        <str-tunarray-element>
            <left>11</left>
            <right>11</right>
        </str-tunarray-element>
        <!-- Additional sequence steps -->
    </str-tunarray-element>
    <!-- Additional sequences -->
</sequences>
```

Each sequence contains 10 steps, allowing for complex light patterns that can indicate different drone states and operations.

## 3. Site Configuration (ver_spdif_amz_site_config.xml)

The site configuration contains parameters related to the operational site:

```xml
<data>
    <persistent_pdi_data>
        <is_persistent_pdi>1</is_persistent_pdi>
        <is_pdi_config_valid>1</is_pdi_config_valid>
    </persistent_pdi_data>
    <site_config_guid>UNKNOWN</site_config_guid>
    <operating_region>UNKNOWN</operating_region>
    <operator_registration_number>UNKNOWN</operator_registration_number>
    <nav_init_heading_degrees>0</nav_init_heading_degrees>
</data>
```

Key features:
- Persistent PDI (Platform Data Interface) is enabled
- PDI configuration is valid
- Site GUID, operating region, and operator registration are set to "UNKNOWN"
- Initial navigation heading is set to 0 degrees

## 4. Activated Prescription Configuration (ver_spdif_amz_activated_prescription_config.xml)

```xml
<data>
    <activated-prescription-filename>UNKNOWN</activated-prescription-filename>
</data>
```

This configuration indicates that no prescription file is currently activated.

## 5. PDS Offset Configuration (ver_spdif_amz_pds_offset.xml)

```xml
<data>
    <persistent_pdi_data>
        <is_persistent_pdi>1</is_persistent_pdi>
        <is_pdi_config_valid>0</is_pdi_config_valid>
    </persistent_pdi_data>
    <offset>0.0</offset>
</data>
```

This configuration:
- Enables persistent PDI
- Marks PDI configuration as invalid
- Sets the Package Delivery System (PDS) offset to 0.0

## 6. Route Configuration (ver_spdif_amz_route.xml)

```xml
<data>
    <data/>
</data>
```

The route configuration is currently empty, indicating no predefined routes.

## 7. PDI Mode Configuration (ver_spdif_pdi_mode.xml)

```xml
<data>
    <pdi_mode>0</pdi_mode>
</data>
```

The PDI mode is set to 0, indicating standard operation mode.

## 8. Overwrite Configuration (ver_spdif_overwrit.xml)

```xml
<data>
    <enabled>0</enabled>
    <cfg/>
    <period>0.0</period>
    <arb_addr>
        <uav>4278190080</uav>
    </arb_addr>
</data>
```

The overwrite functionality is disabled (enabled=0).

## 9. Obstacle Configuration (ver_opdif_obstacle.xml)

```xml
<data>
    <polygons/>
    <cylinders/>
    <spheres/>
</data>
```

The obstacle configuration is empty, indicating no predefined obstacles.

## 10. Polygon Manager Configuration (ver_opdif_polymgr.xml)

```xml
<data>
    <volumeOp/>
    <polygons/>
    <circles/>
    <spheres/>
    <groups/>
    <geoCage>
        <geoIdx>
            <contingency>0</contingency>
            <emergency>0</emergency>
            <emergencyMargin>0</emergencyMargin>
            <prohibited>0</prohibited>
        </geoIdx>
        <geoDist>
            <cont-dist>0.0</cont-dist>
            <emer-dist>0.0</emer-dist>
            <emer-mar-dist>0.0</emer-mar-dist>
        </geoDist>
    </geoCage>
</data>
```

The polygon manager configuration defines the geo-cage parameters, all currently set to 0, indicating no active geo-cage restrictions.

## 11. ARC Trim Configurations (ver_opdif_arctrim0.xml through ver_opdif_arctrim3.xml)

All four ARC trim configurations contain arrays of 20 zero values:

```xml
<data>
    <u0>
        <str-tunarray-element>0.0</str-tunarray-element>
        <str-tunarray-element>0.0</str-tunarray-element>
        <!-- 18 more zero elements -->
    </u0>
</data>
```

These configurations store trim values for different flight conditions, currently all set to zero.

## 12. Special Mode Configurations

### 12.1 Cage Flight Configuration (ver_spdif_varini.xml in Cage Flight folder)

```xml
<data>
    <str-tunarray-element>
        <vtype>0</vtype>
        <id>3200</id>
        <val0>43200.0</val0>
    </str-tunarray-element>
</data>
```

This configuration sets variable ID 3200 to 43200.0 for cage flight mode.

### 12.2 HILSim Configuration (ver_spdif_varini.xml in HILSim folder)

```xml
<data>
    <str-tunarray-element>
        <vtype>0</vtype>
        <id>3200</id>
        <val0>43200.0</val0>
    </str-tunarray-element>
</data>
```

This configuration is identical to the cage flight configuration, setting variable ID 3200 to 43200.0 for hardware-in-the-loop simulation.

## 13. Waypoint Group Configuration (ver_opdif_evt-wp-groups.xml)

```xml
<data/>
```

The waypoint group configuration is empty, indicating no predefined waypoint groups.

## 14. Geo-Cage Configuration (ver_opdif_mgeocage.xml)

```xml
<data>
    <data>
        <polygonType>0</polygonType>
        <auxPolygon>0</auxPolygon>
    </data>
</data>
```

The geo-cage configuration specifies polygon type 0 and auxiliary polygon 0, indicating a basic geo-cage setup.

## 15. Temporary Route Configuration (ver_opdif_troute.xml)

```xml
<data>
    <first>65535</first>
    <patches/>
</data>
```

The temporary route configuration has first index set to 65535 (maximum value) and no patches, indicating no active temporary route.

## 16. Arbiter Address Configuration (ver_ppdif_arbaddr.xml)

```xml
<data>
    <arbaddr>
        <uav>999</uav>
    </arbaddr>
    <apaddrs/>
</data>
```

The arbiter address configuration sets the UAV address to 999.

## 17. Integrated Mission Management Analysis

### 17.1 Mission Phase Detection and Handling

The mission management system uses sophisticated parameter sets to detect and handle different mission phases:

1. **Pre-takeoff Phase**:
   - Detected when the drone is on the ground (altitude_agl_on_ground_vf_origin_m = 0.48m)
   - Transitions to takeoff when:
     - AGL altitude exceeds 1.0m
     - Velocity exceeds 0.5 m/s
     - Acceleration exceeds 2.6 m/s²

2. **Takeoff Phase**:
   - Requires at least 4 active motors with RPM > 1500
   - Transitions to flight when altitude offset exceeds 0.5m
   - Horizontal controllers can run even in on-ground mode

3. **Flight Phase**:
   - Normal mission execution phase
   - Weathervaning enabled when airspeed > 2.0 m/s
   - Wind gust monitoring with 12.8 m/s threshold

4. **Landing Phase**:
   - Triggered when:
     - Altitude offset < 1.0m from landing point
     - Horizontal distance < 10.0m from landing point
     - Groundspeed < 0.5 m/s
   - Fast descent rate set to -1.0 m/s

### 17.2 Recovery System Integration

The recovery system is tightly integrated with mission management:

1. **Switchover Logic**:
   - Switchover enabled (is_switchover_enabled = 1)
   - Pre-flight switchover test disabled
   - 5.0 second delay to arm motors after recovery system activation

2. **Bounding Box Protection**:
   - Enabled (enable_bounding_box_protection = 1)
   - 5m x 5m x 10m dimensions
   - 1.0 second logging interval

3. **Battery Management**:
   - Minimum SoC for control: 1000
   - Maximum SoC for landing: 2300

### 17.3 Navigation and Control Integration

The mission management system integrates navigation and control systems:

1. **GNSS Configuration**:
   - Primary GNSS receiver (use_gnss_A_true_B_false = 1)
   - Position accuracy thresholds: 45m horizontal, 75m vertical

2. **Wind Handling**:
   - CX3 wind estimates enabled
   - Weathervaning enabled with 0.7854 rad/s maximum yaw rate
   - Wind gust threshold of 12.8 m/s with counter threshold of 3

3. **Tracking Parameters**:
   - Maximum VTOL horizontal tracking error: 10.0m
   - Maximum VTOL vertical tracking error: 5.0m
   - Maximum vertical speed: 10.0 m/s
   - Maximum VTOL AGL: 20.0m

### 17.4 Lighting System Integration

The lighting system provides visual indicators of mission status:

1. **Light States**:
   - 13 different light states for both left and right arrays
   - Complex phase and width patterns for different visual indications

2. **Light Sequences**:
   - 11 different sequences with 10 steps each
   - Synchronized left and right patterns

### 17.5 Obstacle Avoidance and Geo-Cage

The mission management system includes obstacle avoidance and geo-cage capabilities:

1. **Obstacle Configuration**:
   - Currently empty, allowing for dynamic obstacle definition

2. **Polygon Manager**:
   - Support for volumetric operations, polygons, circles, and spheres
   - Geo-cage with contingency, emergency, and prohibited zones
   - Currently all set to 0 (inactive)

3. **Geo-Cage Configuration**:
   - Basic setup with polygon type 0
   - Ready for dynamic configuration

### 17.6 Route and Waypoint Management

The mission management system supports route and waypoint management:

1. **Route Configuration**:
   - Currently empty, allowing for dynamic route definition
   - Minimum velocity for route planning: 0.2 m/s

2. **Waypoint Groups**:
   - Support for event-triggered waypoint groups
   - Currently empty, allowing for dynamic definition

3. **Temporary Routes**:
   - Support for temporary route patches
   - Currently inactive (first = 65535)

## 18. Summary

The mission management system in the drone control platform is a sophisticated, integrated system that coordinates multiple subsystems:

1. **Recovery System**: Handles contingency operations with configurable parameters for mission phase detection, route planning, and control.

2. **Lighting System**: Provides visual indicators through complex light patterns and sequences.

3. **Site Configuration**: Manages site-specific parameters and navigation initialization.

4. **Obstacle Avoidance**: Supports dynamic obstacle definition and avoidance.

5. **Geo-Cage**: Implements geographical boundaries with contingency, emergency, and prohibited zones.

6. **Route Planning**: Supports dynamic route definition and waypoint groups.

7. **Special Modes**: Includes configurations for cage flight and hardware-in-the-loop simulation.

The system is designed to be highly configurable while providing robust mission execution capabilities, with particular emphasis on safety through the recovery system, bounding box protection, and geo-cage features.