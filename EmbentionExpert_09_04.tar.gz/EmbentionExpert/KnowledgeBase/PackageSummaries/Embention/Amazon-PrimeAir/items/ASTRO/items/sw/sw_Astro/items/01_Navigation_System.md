# Generated from:

- _sw_Veronte/code/veronte/code/include/Ext_nav.h (1196 tokens)
- _sw_Veronte/code/veronte/code/source/Ext_nav.cpp (421 tokens)
- _sw_Veronte/code/veronte/code/include/Ext_nav_cfg.h (219 tokens)
- _sw_Veronte/code/veronte/code/source/Ext_nav_cfg.cpp (197 tokens)
- _sw_Veronte/code/veronte/code/include/Ext_nav_cfg_fw.h (29 tokens)
- _sw_Veronte/code/veronte/code/include/Ext_mea_base.h (669 tokens)
- _sw_Veronte/code/veronte/code/source/Ext_mea_base.cpp (793 tokens)
- _sw_Veronte/code/veronte/code/include/Ext_mea_3d.h (751 tokens)
- _sw_Veronte/code/veronte/code/source/Ext_mea_3d.cpp (612 tokens)
- _sw_Veronte/code/veronte/code/include/Ext_mea_3d_cfg.h (245 tokens)
- _sw_Veronte/code/veronte/code/source/Ext_mea_3d_cfg.cpp (408 tokens)
- _sw_Veronte/code/veronte/code/include/pa/Hnav_inputs.h (299 tokens)
- _sw_Veronte/code/veronte/code/include/pa/Hmon_nav_inputs.h (1255 tokens)
- _sw_Veronte/code/veronte/code/source/pa/mon/Hmon_nav_inputs.cpp (463 tokens)
- _sw_Veronte/code/veronte/code/include/pa/Hnav_introspect_compact.h (375 tokens)
- _sw_Veronte/code/veronte/code/source/pa/rec0/Hnav_inputs.cpp (63 tokens)
- _sw_Veronte/code/veronte/code/source/cpu1/pa/rec0/Hnav_introspect_compact_cpu1.cpp (90 tokens)
- _sw_Veronte/code/veronte/code/source/cpu2/pa/mon/Hnav_introspect_compact_cpu2.cpp (124 tokens)
- _sw_Veronte/code/veronte/code/source/cpu2/pa/rec0/Hnav_introspect_compact_cpu2.cpp (72 tokens)
- _sw_Veronte/code/veronte/code/include/pa/Hstate_estimate.h (344 tokens)
- _sw_Veronte/code/veronte/code/source/pa/rec0/Hstate_estimate.cpp (109 tokens)
- _sw_Veronte/code/veronte/code/source/pa/rec1/Hstate_estimate.cpp (73 tokens)
- _sw_Veronte/code/veronte/code/include/pa/Hstate_estimate_compact.h (368 tokens)
- _sw_Veronte/code/veronte/code/source/cpu1/pa/rec0/Hstate_estimate_cpu1.cpp (98 tokens)
- _sw_Veronte/code/veronte/code/source/cpu1/pa/rec1/Hstate_estimate_cpu1.cpp (63 tokens)
- _sw_Veronte/code/veronte/code/source/cpu2/pa/mon/Hstate_estimate_compact_cpu2.cpp (126 tokens)
- _sw_Veronte/code/veronte/code/source/cpu2/pa/rec0/Hstate_estimate_compact_cpu2.cpp (126 tokens)
- _sw_Veronte/code/veronte/code/include/pa/Hx_nav_msg.h (tokens unknown)
- _sw_Veronte/code/veronte/code/source/cpu1/pa/mon/Hx_nav_msg_cpu1.cpp (73 tokens)
- _sw_Veronte/code/veronte/code/source/cpu2/pa/mon/Hx_nav_msg_cpu2.cpp (110 tokens)
- _sw_Veronte/code/veronte/code/source/cpu2/pa/rec0/Hx_nav_msg_cpu2.cpp (200 tokens)
- _sw_Veronte/code/veronte/code/include/pa/Hx_imu_fifo.h (127 tokens)
- _sw_Veronte/code/veronte/code/source/cpu1/pa/mon/Hx_imu_fifo_wr.cpp (151 tokens)
- _sw_Veronte/code/veronte/code/source/cpu2/pa/mon/Hx_imu_fifo_rd.cpp (238 tokens)
- _sw_Veronte/code/veronte/code/source/cpu2/pa/rec0/Hx_imu_rec0.cpp (572 tokens)
- _sw_Veronte/code/veronte/code/source/cpu1/pa/rec0/Hx_navraw_cpu1.cpp (155 tokens)
- _sw_Veronte/code/veronte/code/source/cpu2/pa/rec0/Hx_navraw_cpu2.cpp (155 tokens)
- _sw_Veronte/code/veronte/code/include/pa/Raw_meas_sync_getter.h (177 tokens)
- _sw_Veronte/code/veronte/code/source/pa/Raw_meas_sync_getter.cpp (130 tokens)
- _sw_Veronte/code/veronte/code/include/Rawpos.h (221 tokens)
- _sw_Veronte/code/veronte/code/source/pa/Rawpos_amz.cpp (62 tokens)
- _sw_Veronte/code/veronte/code/source/ver/Rawpos_ver.cpp (1942 tokens)

## With context from:

- PackageSummaries/Embention/Amazon-PrimeAir/items/ASTRO/items/sw/sw_Astro/items/09_System_Architecture.md (5081 tokens)
- PackageSummaries/Embention/Amazon-PrimeAir/items/ASTRO/items/sw/sw_Astro/items/02_Hardware_Abstraction_Layer.md (8636 tokens)

---

# External Navigation Sensor System in Veronte Software

This document provides a comprehensive analysis of the external navigation sensor system in the Veronte software, focusing on how it processes, validates, and distributes navigation data from various sources.

## 1. External Measurement Base Class

The `Ext_mea_base` class serves as the foundation for all external sensor measurement handling in the Veronte system.

### 1.1 Core Structure and Functionality

```cpp
class Ext_mea_base : public Base::Interface_nv {
public:
    Ext_mea_base(volatile bool& mea_ok0, volatile Real& mea_freq0);
    bool step(bool ready);

protected:
    Real desired_freq;                // Desired frequency for the sensor
    virtual bool push_measurement() = 0; // Pure virtual method for measurement handling

private:
    volatile bool& mea_ok;            // Sensor health BIT
    volatile Real& mea_freq;          // Measurement update frequency
    Base::Freqmetric freq_metric;     // To measure the reception frequency
};
```

### 1.2 Frequency Monitoring and Validation

The `Ext_mea_base` class implements a robust frequency monitoring system that:

1. Tracks the actual reception frequency of sensor measurements
2. Compares it against the desired frequency
3. Sets the sensor health BIT to false if reception frequency falls below 90% of expected

```cpp
bool Ext_mea_base::step(bool ready) {
    bool ret = false;

    if (ready) {
        // Measurement is ready to be processed
        ret = true;
        mea_ok = push_measurement();
        
        if (mea_ok) {
            // Count valid measurement for frequency estimation
            freq_metric.count();
            mea_freq = freq_metric.get_freq();
        } else {
            // Update frequency without counting new measurement
            mea_freq = freq_metric.step();
        }
    } else {
        // No new measurement, just update frequency
        mea_freq = freq_metric.step();
    }
    
    // Check if frequency is below threshold (90% of desired)
    static const Real freq_deviation = 0.9F;
    if (mea_freq < (freq_deviation*desired_freq)) {
        mea_ok = false;
        ret = true;  // Discard measurement due to low frequency
    }
    
    return ret;
}
```

The frequency estimator uses an EWMA filter with the following parameters:
- Filter coefficient: 1/128 (equivalent to τ = 0.1270 seconds at 1kHz)
- Minimum time to consider frequency measurements: 0.0025 seconds
- Minimum frequency estimation: 0.1 Hz

## 2. External Navigation Sensor Parser

The `Ext_nav` class extends `Ext_mea_base` to specifically handle navigation data from external sources.

### 2.1 Class Structure

```cpp
class Ext_nav : public Ext_mea_base {
public:
    struct Irequired_fields : public Base::Interface_nv {
        virtual void status0_required() = 0;
    };

    Ext_nav(const volatile Real* rvars0,
            const volatile Uint16& nav_status0,
            const Base::Tnarray<Real64, Ku16::u3>& nav_pos0,
            Base::Hmeasnav& meas0,
            volatile Base::Feature& fpos0,
            volatile bool& mea_ok0,
            volatile Real& mea_freq0,
            Irequired_fields& req_fields0);

    void config(const Ext_nav_cfg& cfg0);

private:
    enum Rvar_id {
        ri_yaw   =  0U,  // (0) Yaw [rad]
        ri_pitch =  1U,  // (1) Pitch [rad]
        ri_roll  =  2U,  // (2) Roll [rad]
        ri_p     =  3U,  // (3) p (angular velocity in x-body axis) [rad/s]
        ri_q     =  4U,  // (4) q (angular velocity in y-body axis) [rad/s]
        ri_r     =  5U,  // (5) r (augular velocity in z-body axis) [rad/s]
        ri_vn    =  6U,  // (6) North velocity [m/s]
        ri_ve    =  7U,  // (7) East velocity [m/s]
        ri_vd    =  8U,  // (8) Down velocity [m/s]
        ri_ax    =  9U,  // (9) Acceleration x-body axis [m/s^2]
        ri_ay    = 10U,  // (10) Acceleration y-body axis [m/s^2]
        ri_az    = 11U   // (11) Acceleration z-body axis [m/s^2]
    };

    Base::Hmeasnav& meas;                // Reference to publish received navigation
    const volatile Real* const rvars;    // Pointer to first real variable in navigation
    const volatile Uint16& nav_status;   // Reference to received navigation status
    const Base::Tnarray<Real64, Ku16::u3>& nav_pos; // Reference to received navigation position
    volatile Base::Feature& fpos;        // Reference to publish the received navigation position
    Irequired_fields& req_fields;        // Reference to set more fields as mandatory

    Base::Optional<Uint16> req_nav_status0; // Required navigation status to consider nav as OK

    bool push_measurement();
};
```

### 2.2 Navigation Data Processing

The `Ext_nav` class processes navigation data by:

1. Validating the navigation status against a configured expected value (if specified)
2. Constructing a navigation message (`Base::Mnav`) from the raw variables
3. Publishing the navigation data through the measurement handler
4. Publishing the position as a system feature

```cpp
bool Ext_nav::push_measurement() {
    // Check if navigation status matches required value (if configured)
    const bool ret = (!req_nav_status0.is_present()) || (nav_status == req_nav_status0.value);
    
    if (ret) {
        // Create position structure from raw position data
        const Base::Tllh pos = {{nav_pos[Ku16::u0], nav_pos[Ku16::u1]}, nav_pos[Ku16::u2]};
        
        // Create navigation message from all raw variables
        const Base::Mnav nav = {
            {{rvars[ri_yaw], rvars[ri_pitch], rvars[ri_roll]}},
            {{rvars[ri_p],   rvars[ri_q],     rvars[ri_r]}},
            pos,
            {{rvars[ri_vn],  rvars[ri_ve],    rvars[ri_vd]}},
            {{rvars[ri_ax],  rvars[ri_ay],    rvars[ri_az]}},
            true
        };
        
        // Publish navigation data
        meas.write(nav);
        fpos.build_abs(pos);
    }
    
    return ret;
}
```

### 2.3 Configuration

The `Ext_nav` class can be configured with:

1. Desired update frequency
2. Optional required navigation status value

```cpp
void Ext_nav::config(const Ext_nav_cfg& cfg0) {
    desired_freq = cfg0.desired_freq;
    req_nav_status0 = cfg0.req_status0;
    
    // If navigation status is required, notify the caller
    if (req_nav_status0.is_present()) {
        req_fields.status0_required();
    }
}
```

The configuration is deserialized from a PDI (Parameter Definition Interface) with the following structure:

```
| Type                         | Name           | Content                                            | Range |
| ---------------------------- | -------------- | -------------------------------------------------- | ----- |
| Real                         | desired_freq   | Desired frequency for the navigation messages [Hz] | >=0   |
| Base::Tun_optional<Uint16>   | req_status0    | Optional navigation status                         | -     |
```

## 3. External 3D Measurement Handler

The `Ext_mea_3d` class extends `Ext_mea_base` to handle 3D sensor measurements (like accelerometers, gyroscopes, etc.).

### 3.1 Class Structure

```cpp
class Ext_mea_3d : public Ext_mea_base {
public:
    Ext_mea_3d(const Real* mea0,
               volatile bool& mea_ok0,
               volatile Real& mea_freq0,
               Base::Hmeas3& meas0,
               const volatile Base::Xcal3D::Type_kpodsync& calcfg0,
               const volatile Real& temp0);

    void config(const Ext_mea_3d_cfg& cfg0);

private:
    Maverick::Irvector3::K mea;        // Pointer to current raw measurement
    Maverick::IIR3_2 flt;              // IIR 3D filter
    Base::Rangedeltacheck3_nv dcheck;  // Delta check (to check that the sensor changes)
    const volatile bool& enable_cal;    // Reference bit to enable calibration
    Base::Tmeas3D cal_meas;            // Handler to publish the measurements
    const volatile Real& temp;         // Actual temperature [K]

    bool push_measurement();
};
```

### 3.2 3D Measurement Processing

The `Ext_mea_3d` class processes 3D measurements by:

1. Checking if the sensor values have changed (using delta check)
2. Applying a low-pass filter to the measurements
3. Applying temperature calibration
4. Publishing the filtered and calibrated measurements

```cpp
bool Ext_mea_3d::push_measurement() {
    // Check if sensor values have changed in the last three steps
    const bool ret = (dcheck.check_var(mea.kvec, false) && dcheck.get_nv());

    if (ret) {
        // Copy raw measurements
        Base::Rv3 val_data;
        Maverick::Irvector3 val(val_data);
        val.copy(mea.kvec);
        
        // Apply low pass filter
        flt.step(val);
        
        // Apply temperature calibration
        cal_meas.get_cal().set_temp(temp);
        
        // Publish filtered calibrated measurement
        cal_meas.write(val);
    }
    
    return ret;
}
```

### 3.3 Configuration

The `Ext_mea_3d` class can be configured with:

1. Desired update frequency
2. Filter configuration
3. Minimum and maximum allowed values
4. Maximum allowed increment (delta)
5. Maximum non-variation count to discard measurement

```cpp
void Ext_mea_3d::config(const Ext_mea_3d_cfg& cfg0) {
    // Set desired frequency
    desired_freq = cfg0.desired_freq;
    
    // Configure filter
    flt.config(cfg0.flt_cfg);
    flt.set_freq(desired_freq);
    
    // Configure delta check
    dcheck.set_max_count(cfg0.max_count_nv);
    dcheck.set_max_delta(cfg0.max_delta);
    dcheck.set_range(cfg0.min_value, cfg0.max_value);
}
```

## 4. Cross-Core Navigation Data Distribution

The Veronte system distributes navigation data across multiple cores (CPU1 and CPU2) using cross-core data structures.

### 4.1 State Estimate Distribution

The `Hstate_estimate` class provides access to state estimation data across cores:

```cpp
struct Hstate_estimate {
public:
    typedef Pa_blocks::Cyphal_rx_msg_xcd<Pa_blocks::State_estimate::payload_sz> Rx_state_estimate;
    typedef Rx_state_estimate::Xcd_obj Tdsync_estimate;
    
    // Read-only access for both CPU1 and CPU2
    static const volatile Tdsync_estimate& get_kstate_estimate();
    
    // Read-write access for CPU1 only
    static Tdsync_estimate& get_state_estimate();
};
```

The implementation ensures proper cross-core data access:

```cpp
// Common to CPU1 and CPU2: both CPUs allowed to read
const volatile Hstate_estimate::Tdsync_estimate& Hstate_estimate::get_kstate_estimate() {
    return Xc::get_xcd_cpu1().priv_impl.state_estimate;
}

// CPU1: Only CPU1 can write
Hstate_estimate::Tdsync_estimate& Hstate_estimate::get_state_estimate() {
    return Xc::get_xcd_cpu1().priv_impl.state_estimate;
}
```

### 4.2 Compact State Estimate Distribution

The `Hstate_estimate_compact` class provides access to a compact version of the state estimate:

```cpp
struct Hstate_estimate_compact {
public:
    // Read-only access for both CPU1 and CPU2
    static const volatile Cyphal::Cy_tdsync_can_sender<Pa_blocks::State_estimate_compact::payload_sz>::Xct& get_kstate_estimate_compact();
    
    // Read-write access for CPU2 only
    static Cyphal::Cy_tdsync_can_sender<Pa_blocks::State_estimate_compact::payload_sz>::Xct& get_state_estimate_compact();
};
```

### 4.3 Navigation Introspection Data

The `Hnav_introspect_compact` class provides access to navigation introspection data:

```cpp
struct Hnav_introspect_compact {
public:
    typedef Cyphal::Cy_tdsync_can_sender<Pa_blocks::Nav_introspect_compact::payload_sz>::Xct Buftype;
    
    // Read-only access for both CPU1 and CPU2
    static const volatile Buftype& get_knav_introspect_compact();
    
    // Read-write access for CPU2 only
    static Buftype& get_nav_introspect_compact();
};
```

### 4.4 Navigation Message Distribution

The `Hx_nav_msg` namespace provides access to navigation messages:

```cpp
namespace Hx_nav_msg {
    // Read-only access for both CPU1 and CPU2
    const volatile Cyphal::Cy_tdsync_can_sender<Pa_blocks::State_estimate::payload_sz>::Xct& get_nav_msg_k();
    
    // Read-write access for CPU2 only
    Cyphal::Cy_tdsync_can_sender<Pa_blocks::State_estimate::payload_sz>::Xct& get_nav_msg();
}
```

## 5. IMU Data Processing and Distribution

The Veronte system processes IMU data through a FIFO (First-In-First-Out) buffer to ensure proper synchronization between cores.

### 5.1 IMU FIFO Structure

The `Hx_imu_fifo` class provides access to the IMU FIFO:

```cpp
class Hx_imu_fifo {
public:
    static Pa_blocks::Fifo_imu::Imu_ffwr_t& get_imu_fifo_wr();
    static Pa_blocks::Fifo_imu::Imu_ffrd_t& get_imu_fifo_rd();
};
```

### 5.2 IMU Data Writing (CPU1)

CPU1 writes IMU data to the FIFO:

```cpp
Pa_blocks::Fifo_imu::Imu_ffwr_t& Hx_imu_fifo::get_imu_fifo_wr() {
    static Pa_blocks::Fifo_imu::Imu_ffwr_t xw(
        Xc::get_xcd_cpu2().priv_impl.imu_ffrd, 
        Xc::get_xcd_cpu1().priv_impl.imu_ffwr
    );
    return xw;
}
```

### 5.3 IMU Data Reading (CPU2)

CPU2 reads IMU data from the FIFO:

```cpp
Pa_blocks::Fifo_imu::Imu_ffrd_t& Hx_imu_fifo::get_imu_fifo_rd() {
    static Pa_blocks::Fifo_imu::Imu_ffrd_t xr(
        Xc::get_xcd_cpu2().priv_impl.imu_ffrd, 
        Xc::get_xcd_cpu1().priv_impl.imu_ffwr
    );
    return xr;
}
```

### 5.4 IMU Data Processing

The IMU data is processed with filtering before being used:

```cpp
bool Measurements::get_imu_meas(Imu& data) {
    static const Uint8 num_axis = 3U;
    static Base::Tnarray<Fifo_imu::Writer::Filter_t, num_axis> acc_filters = {
        Fifo_imu::Writer::Filter_t(Fifo_imu::Writer::in_coefs, Fifo_imu::Writer::out_coefs),
        Fifo_imu::Writer::Filter_t(Fifo_imu::Writer::in_coefs, Fifo_imu::Writer::out_coefs),
        Fifo_imu::Writer::Filter_t(Fifo_imu::Writer::in_coefs, Fifo_imu::Writer::out_coefs)
    };
    static Base::Tnarray<Fifo_imu::Writer::Filter_t, num_axis> gyr_filters = {
        Fifo_imu::Writer::Filter_t(Fifo_imu::Writer::in_coefs, Fifo_imu::Writer::out_coefs),
        Fifo_imu::Writer::Filter_t(Fifo_imu::Writer::in_coefs, Fifo_imu::Writer::out_coefs),
        Fifo_imu::Writer::Filter_t(Fifo_imu::Writer::in_coefs, Fifo_imu::Writer::out_coefs)
    };

    Base::Imu_output_data imu_data;
    static Base::Dsync::Reader rd = Ver::Hmeas::get_kmeas().imu_adis165053.read(imu_data);
    const bool new_meas = !rd.is_valid();
    
    if (new_meas) {
        rd = Ver::Hmeas::get_kmeas().imu_adis165053.read(imu_data);
        
        // Filter each axis
        for(Uint16 i=0; i<num_axis; i++) {
            data.f[i] = acc_filters[i].Filter(imu_data.acc_m_per_s2[i]);
            data.w[i] = gyr_filters[i].Filter(imu_data.gyr_rad_per_s[i]);
        }

        data.time_s = imu_data.timestamp_tics;
        data.railed = imu_data.has_railed();
    }
    
    return new_meas;
}
```

## 6. Raw Position Access

The `Rawpos` class provides access to the raw position data from various navigation sources.

### 6.1 Raw Position Structure

```cpp
class Rawpos {
public:
    static bool get_pos(Geo::Apos& pos);
};
```

### 6.2 Raw Position Retrieval

The implementation retrieves raw position data from the currently selected navigation source:

```cpp
bool Rawpos0::get_pos(Geo::Apos& raw) const {
    bool ret = false;
    
    if (navig_ok.get()) {
        switch (static_cast<Base::Navtype>(navsrc.get())) {
            case Base::nav_ekf:
            {
                static const Bsp::Hfvar fpos(Base::c_vpu);
                Base::Feature ftr;
                fpos.get(ftr);
                raw.set_llh(ftr.data.llh);
                break;
            }
            case Base::nav_sim_state:
            {
                Base::Mnavsim sim;
                navsim.read(sim);
                raw.set_llh(sim.nav.pos_llh);
                ret = true;
                break;
            }
            case Base::nav_external:
            {
                Base::Mnav ext;
                navext.read(ext);
                raw.set_llh(ext.pos_llh);
                ret = true;
                break;
            }
            case Base::nav_ext_var:
            {
                Base::Feature ftr;
                varpos.get(ftr);
                if (ftr.is_abs()) {
                    raw.set_llh(ftr.data.llh);
                    ret = true;
                }
                break;
            }
            case Base::nav_vn300:
            {
                Base::Mnav ext;
                navig_vn300.read(ext);
                raw.set_llh(ext.pos_llh);
                ret = true;
                break;
            }
            default:
                Bsp::warning();
                break;
        }
    }
    
    return ret;
}
```

## 7. Navigation Input Handlers

The Veronte system provides handlers for various navigation inputs.

### 7.1 Monitor Navigation Inputs

The `Hmon_nav_inputs` struct provides access to navigation inputs:

```cpp
struct Hmon_nav_inputs {
public:
    typedef Pa_blocks::Cyphal_rx_msg_xcd<76> Rx_meas_gnss;
    typedef Pa_blocks::Cyphal_rx_msg_xcd<11> Rx_meas_ground_lidar;
    typedef Pa_blocks::Cyphal_rx_msg_xcd<13> Rx_meas_dynamic_pressure;
    typedef Pa_blocks::Cyphal_rx_msg_xcd<13> Rx_meas_static_pressure_left;

    // GNSS measurements
    static const volatile Rx_meas_gnss::Xcd_obj& get_kmeas_gnss();
    static Rx_meas_gnss::Xcd_obj& get_meas_gnss();

    // Ground lidar measurements
    static const volatile Rx_meas_ground_lidar::Xcd_obj& get_kmeas_ground_lidar();
    static Rx_meas_ground_lidar::Xcd_obj& get_meas_ground_lidar();

    // Dynamic pressure measurements
    static const volatile Rx_meas_dynamic_pressure::Xcd_obj& get_kmeas_dynamic_pressure_left();
    static Rx_meas_dynamic_pressure::Xcd_obj& get_meas_dynamic_pressure_left();
    static const volatile Rx_meas_dynamic_pressure::Xcd_obj& get_kmeas_dynamic_pressure_right();
    static Rx_meas_dynamic_pressure::Xcd_obj& get_meas_dynamic_pressure_right();

    // Static pressure measurements
    static const volatile Rx_meas_static_pressure_left::Xcd_obj& get_kmeas_static_pressure_left();
    static Rx_meas_static_pressure_left::Xcd_obj& get_meas_static_pressure_left();
};
```

### 7.2 Raw GNSS Measurements

The `Raw_meas_sync_getter` struct provides access to raw GNSS measurements:

```cpp
struct Raw_meas_sync_getter {
    static Cyphal::Cy_raw_meas_gnss_compact::Raw_meas_gnss_compact_sync& raw_meas_sync_getter();
};
```

## 8. Cross-Core Navigation Data Flow

The navigation data flows through the system as follows:

1. **External Sensors → CPU1**:
   - External sensors provide raw measurements
   - `Ext_nav` and `Ext_mea_3d` classes process and validate these measurements
   - Measurements are published to measurement handlers

2. **CPU1 → CPU2**:
   - Processed measurements are stored in cross-core data structures
   - IMU data is written to the IMU FIFO
   - Raw GNSS data is written to the GNSS FIFO

3. **CPU2 → State Estimation**:
   - CPU2 reads measurements from cross-core data structures
   - State estimation algorithms process these measurements
   - Resulting state estimate is stored in cross-core data structures

4. **State Estimate → Applications**:
   - Applications on both CPU1 and CPU2 can access the state estimate
   - The `Rawpos` class provides access to raw position data
   - Navigation inputs are available through various handlers

## 9. Data Validation and Quality Control

The external navigation sensor system implements several validation mechanisms:

1. **Frequency Monitoring**:
   - Tracks actual reception frequency
   - Flags measurements as invalid if frequency drops below 90% of expected

2. **Status Validation**:
   - Can require specific navigation status values
   - Rejects measurements with incorrect status

3. **Delta Checking**:
   - Ensures sensor values are changing appropriately
   - Detects stuck or frozen sensors

4. **Range Checking**:
   - Validates measurements against configured min/max values
   - Rejects out-of-range measurements

5. **Filtering**:
   - Applies low-pass filtering to reduce noise
   - Configurable filter parameters

## 10. System Integration Diagram

```
External Sensors
      │
      ▼
┌─────────────┐
│   Ext_nav   │
│ Ext_mea_3d  │  CPU1
│             │
└──────┬──────┘
       │
       ▼
┌─────────────┐
│ Cross-Core  │
│    Data     │
└──────┬──────┘
       │
       ▼
┌─────────────┐
│    State    │
│ Estimation  │  CPU2
│             │
└──────┬──────┘
       │
       ▼
┌─────────────┐
│ Applications│
└─────────────┘
```

## 11. Referenced Context Files

The following context files provided valuable information for understanding the external navigation sensor system:

1. `09_System_Architecture.md` - Provided overall system architecture context, showing how the navigation system integrates with the rest of the Veronte system.
2. `02_Hardware_Abstraction_Layer.md` - Provided information about the hardware abstraction layer that interfaces with the physical sensors.

## 12. Summary

The external navigation sensor system in the Veronte software provides a robust framework for processing, validating, and distributing navigation data from various sources. Key components include:

1. The `Ext_mea_base` class that provides common functionality for frequency monitoring and validation
2. The `Ext_nav` class that specifically handles navigation data
3. The `Ext_mea_3d` class that handles 3D sensor measurements
4. Cross-core data structures for distributing navigation data between CPU1 and CPU2
5. FIFO buffers for synchronizing IMU data between cores
6. The `Rawpos` class for accessing raw position data from various navigation sources
7. Various handlers for accessing navigation inputs and state estimates

The system implements multiple validation mechanisms to ensure data quality and provides a flexible configuration interface through PDIs. This architecture enables the Veronte system to reliably process navigation data from external sensors and use it for state estimation and control.