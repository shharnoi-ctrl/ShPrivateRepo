# Generated from:

- code/PA_SIL/include/Wrapper_mission_input.h (469 tokens)
- code/PA_SIL/include/Recovery_messages.h (12373 tokens)
- code/PA_SIL/include/Dummy_msg_sender.h (138 tokens)
- code/PA_SIL/include/Knobs_cfg.h (3013 tokens)
- code/PA_SIL/include/PVT_wrapper.h (395 tokens)
- code/PA_SIL/include/Recovery_lane_step1_wrapper.h (266 tokens)
- code/PA_SIL/include/Emb_wrapper_serial_message.h (549 tokens)
- code/PA_SIL/include/Emb_navigation_wrapper.h (875 tokens)
- code/PA_SIL/include/private/Emb_serial_message_utils.h (482 tokens)
- code/PA_SIL/include/private/Wrap_messages.h (594 tokens)
- code/PA_SIL/source/Recovery_lane_step1_wrapper.cpp (616 tokens)
- code/PA_SIL/source/Wrap_messages.cpp (5812 tokens)
- code/PA_SIL/source/Emb_navigation_wrapper.cpp (5291 tokens)
- code/PA_SIL/source/main.cpp (9 tokens)

---

# High-Fidelity Semantic Knowledge Graph: SIL Framework Components

## 1. Core Framework Architecture

The SIL (Software-In-the-Loop) framework is designed to support simulation and testing of various vehicle control components, with particular focus on navigation, recovery functionality, and message handling. The framework consists of several key components that work together to simulate the behavior of the vehicle's systems.

### 1.1 Framework Components Overview

The framework is organized around several core components:

1. **Message Handling System**: Facilitates communication between different components through a standardized message format
2. **Navigation System**: Processes sensor data and provides state estimation
3. **Recovery System**: Handles contingency situations and recovery actions
4. **Controllers**: Manage vehicle control including trajectory planning and motor commands
5. **Wrapper Classes**: Bridge between the simulation environment and the embedded software components

### 1.2 Simulation Time Management

The simulation time is managed through the `Emb_navigation_wrapper` class, which:

- Tracks simulation time in nanoseconds via the `simulation_time_ns` member variable
- Schedules execution intervals using the `ExecuteAndScheduleNextExecutionInNs` method
- Sets the system time using `Bsp::Htimehelper::set_time_us` with a conversion from nanoseconds to microseconds
- Typically runs at a 2ms execution rate (500Hz), as seen in the execution interval calculation:
  ```cpp
  interval_ns = static_cast<uint64_t>(2.0F * Const::E1000 * Const::FROM_NANO);
  ```

## 2. Message Handling System

The framework implements a comprehensive message handling system to facilitate communication between components.

### 2.1 Message Types and Structure

Messages are defined in `Recovery_messages.h` and include:

- **Navigation Messages**: State estimates, introspection data
- **Control System Messages**: Actuator commands, controller status
- **Route Tracking Messages**: Route and maneuver information
- **Sensor Data Messages**: IMU, GNSS, pressure sensors

Each message type has a specific structure with fields relevant to its purpose. For example, the `StateEstimate` structure contains position, velocity, orientation, and status information.

### 2.2 Message Processing Flow

1. Messages are received through the `PutMessage` method in `Emb_navigation_wrapper`
2. The message type is determined by its port ID
3. Message data is deserialized using the `cset` method
4. The data is processed by the appropriate component
5. Output messages are generated and queued for transmission
6. Messages are retrieved through the `GetMessage` method

### 2.3 Message Serialization and Deserialization

The framework uses several utilities for message serialization:

- `Emb_serial_message_utils` namespace provides functions for serializing and deserializing messages
- `Lossy` class is used for binary serialization
- `U8istream` and `U8ostream` classes handle byte-level I/O operations

Example of message deserialization:
```cpp
Pa_blocks::Measurements::Meas_acc_gyr meas;
meas.cset(str);  // Deserialize from binary stream
```

## 3. Navigation System

The navigation system is responsible for estimating the vehicle's state based on sensor inputs.

### 3.1 State Estimation

The state estimation process:

1. Collects sensor data (IMU, GNSS, barometer, lidar)
2. Processes the data through filtering algorithms
3. Produces a state estimate containing position, velocity, orientation
4. Provides status information about the validity of different state components

Key state estimation structures:
- `StateEstimate`: Complete state information
- `StateEstimateCompact`: Reduced state information for efficient transmission
- `NavIntrospect`: Detailed internal state for debugging

### 3.2 Sensor Integration

The navigation system integrates data from multiple sensors:

- **IMU**: Accelerometer and gyroscope data processed in `cyp_meas_accel_gyro` message handler
- **GNSS**: Position and velocity data processed in `cyp_meas_gnss_secondary` message handler
- **Lidar**: Ground distance measurements processed in `cyp_pa_meas_ground_lidar` message handler
- **Pressure Sensors**: Static and dynamic pressure processed in respective message handlers

### 3.3 Navigation Status Tracking

The navigation system tracks its status through the `NavStatus` structure, which includes:

- Initialization status
- Validity of altitude above ground level (AGL)
- IMU saturation status
- Horizontal and vertical channel validity
- Time synchronization status

## 4. Recovery Functionality

The recovery system is designed to handle contingency situations and ensure safe operation.

### 4.1 Recovery Lane Step 1

The `Recovery_lane_step1_wrapper` class provides an interface to the recovery system:

```cpp
bool Recovery_lane_step1_wrapper::step(const Inputs& in, Outputs& out)
{
    Mission_input emb_in_mission_input;
    Recovery_lane_step1::Input emb_in(emb_in_mission_input);
    
    // Set input parameters
    emb_in.state_estimate.on_ground = in.state_estimate_on_ground;
    emb_in.state_estimate.lla_rrm = Base::Tllh::build(in.state_estimate_lla_rrm[1],
                                                      in.state_estimate_lla_rrm[0],
                                                      in.state_estimate_lla_rrm[2]);
    // ... more parameter setting ...
    
    get_object().step1(emb_in);
    Recovery_lane_step1::Output emb_out = get_object().get_outputs();
    
    // Extract output parameters
    out.motor_state_enable = emb_out.motor_state_request.enable_intent;
    out.motor_state_arm_intent = emb_out.motor_state_request.arm_intent;
    out.state_machine_recovery_state = emb_out.state_machine.recovery_state;
    out.state_machine_contingency_action = emb_out.state_machine.contingency_action;
    out.ramp_down_motors = emb_out.ramp_down_motors;

    return true;
}
```

### 4.2 Recovery State Machine

The recovery system uses a state machine to manage recovery actions:

- States are tracked in `state_machine_recovery_state`
- Contingency actions are determined by `state_machine_contingency_action`
- Motor control is managed through `motor_state_enable` and `motor_state_arm_intent`
- When necessary, motors can be ramped down using the `ramp_down_motors` flag

### 4.3 Switchover Mechanism

The framework includes a switchover mechanism to transition between primary and recovery systems:

- Switchover is triggered through the `cyp_fail_over_trigger` message
- The GPIO signal is set using `data->hgpio_switch_fb.set(is_switch_over)`
- The switchover status is tracked in `has_switchover_been_signalled_to_recovery`

## 5. Configuration System

The framework includes a configuration system to customize behavior.

### 5.1 Knobs Configuration

The `Knobs` class in `Knobs_cfg.h` defines configurable parameters:

- Navigation parameters (timeouts, thresholds)
- Vehicle parameters (calibration values, frame transformations)
- On-ground detection parameters
- Sensor filtering parameters

Example parameters:
```cpp
nav_params_gnss_outage_duration_before_degraded_s = 4.5F;
nav_params_gnss_outage_duration_before_invalid_s = 10.0F;
nav_params_lidar_duration_stale_s = 1.0F;
nav_params_baro_duration_stale_s = 1.0F;
```

### 5.2 PDI (Parameter Data Interface) Loading

The framework loads configuration data from PDI files during initialization:

```cpp
bool Emb_navigation_wrapper::Init(const FirmwareInitData & init_data)
{
    // Load variable initialization data
    const std::vector<uint8_t>& pdi_varini = init_data.configuration_data[std::to_string(static_cast<Uint16>(Base::Cfg::cfg_vmgr))];
    if(pdi_varini.size() > 0U)
    {
        Base::Lossy_error str(reinterpret_cast<uint16_t*>(const_cast<unsigned char*>(pdi_varini.data())), (pdi_varini.size() + 1) / 2);
        str.skip_bytes(6U); // Skip bytes of major, minor and revision
        Vpgnc::Varinit varinit;
        varinit.cset(str);
    }
    
    // Load recovery parameters
    const std::vector<uint8_t>& pdi_rec = init_data.configuration_data[std::to_string(static_cast<Uint16>(Base::Cfg::cfg_amz_rec_param))];
    if(pdi_rec.size() > 0U)
    {
        // Similar deserialization process
    }
    
    // Load site configuration
    const std::vector<uint8_t>& pdi_site_cfg = init_data.configuration_data[std::to_string(static_cast<Uint16>(Base::Cfg::cfg_amz_site_cfg))];
    if(pdi_site_cfg.size() > 0U)
    {
        // Similar deserialization process
    }

    return true;
}
```

## 6. Mission and Route Management

The framework includes components for mission planning and route tracking.

### 6.1 Mission Input Structure

The `Wrapper_mission_input` structure defines mission parameters:

- Waypoints with latitude, longitude, and height
- Maneuver types (takeoff, hover, land, etc.)
- Velocity and course information
- Turn parameters (direction, radius)

### 6.2 Route Tracking

Route tracking is managed through several structures:

- `RouteTrackingData`: Tracks the current route and maneuver status
- `Route_msg`: Contains the complete route definition
- `Maneuver_msg`: Defines individual maneuvers within a route

The route tracking system supports different maneuver types:
```cpp
enum Type // ManeuverType
{
    type_undefined = 0,
    type_hover     = 1,
    type_straight  = 2,
    type_turn      = 3,
    type_roll      = 4,
    type_evasive   = 5
};
```

### 6.3 Trajectory Generation

Trajectories are generated using polynomial representations:

```cpp
struct Polynomial
{
    static const Uint16 num_coeffs = 8;
    typedef Real Polynomial_coeffs[num_coeffs]; // Array containing coefficients of polynomial
    bool is_valid;
    Polynomial_coeffs coefficients[5]; // Array with consecutive derivations of coefficients
    Polynomial_coeffs coefficients_i1;
};
```

Waypoints are connected using these polynomials to create smooth trajectories.

## 7. Controller System

The controller system manages vehicle control based on the current state and desired trajectory.

### 7.1 Controller Components

The controller system includes several components:

- **State Estimate Processor (SEP)**: Processes state estimates for control use
- **Trajectory Command Generator (TCG)**: Generates trajectory commands
- **Angular State Controller (ASC)**: Controls vehicle orientation
- **Translational State Controller (TSC)**: Controls vehicle position and velocity
- **Mixer**: Allocates control commands to actuators

### 7.2 Controller State Machines

The controller uses multiple state machines to manage different aspects of control:

```cpp
struct State
{
    Uint8 integrators_mode;     ///< The integrators state machine state
    Land::State land;           ///< The land state machine state
    Uint8 takeoff_mode;         ///< The takeoff state machine state
    Mode::State mode;           ///< The controlers mode state machine state
};
```

These state machines handle:
- Takeoff sequence
- Landing sequence
- Controller mode transitions
- Integrator reset and management

### 7.3 Motor Control

Motor control is managed through the `MotorRpmCommand` structure:

```cpp
struct MotorRpmCommand
{
    int rpm_commands[6]; ///< Array of RPM reference value commands for all motors on a vehicle
    MotorStateRequest motor_state_request;
};
```

The `MotorStateRequest` structure controls motor state:
```cpp
struct MotorStateRequest
{
    Uint8 enable_intent;     ///< The intended "enabled" state for the ESCs - enabled, disabled, etc.
    Uint8 disabled_motor;    ///< Which motor, if any, is disabled during MEP-out.
    Uint8 arm_intent;        ///< Should the system be in the armed state, or not.
    Uint8 source;            ///< The expected command source - primary or recovery.
};
```

## 8. Wrapper Classes

The framework includes wrapper classes to bridge between the simulation environment and the embedded software.

### 8.1 Emb_navigation_wrapper

The `Emb_navigation_wrapper` class implements the `FirmwareSimulation` interface:

- `Init`: Initializes the firmware with configuration data
- `ExecuteAndScheduleNextExecutionInNs`: Executes a simulation step and schedules the next execution
- `GetErrorString`: Returns error information
- `Reset`: Resets the firmware state
- `PutMessage`: Sends a message to the firmware
- `GetMessage`: Retrieves a message from the firmware

### 8.2 Recovery_lane_step1_wrapper

The `Recovery_lane_step1_wrapper` provides a simplified interface to the recovery system:

- Takes inputs including state estimate and mission parameters
- Processes these through the recovery system
- Returns outputs including motor state and recovery actions

### 8.3 PVT_wrapper

The `PVT_wrapper` class wraps the Position, Velocity, and Time processing functionality:

```cpp
class PVT_wrapper {
public:
    struct Inputs {
        bool process_nav_msg;
        Uint8 svid;
        Uint32 raw_words[10];
        bool process_raw_msg;
        AdnNavigation_Raw_Meas AdnNavigation_Raw_Meas_po3n;
    };
    
    PVT_wrapper();
    void config(const Knobs& config0);
    void step(const Inputs& in);
};
```

## 9. Data Structures and Relationships

### 9.1 State Estimate Structure

The state estimate is a central data structure used throughout the framework:

```cpp
struct StateEstimate
{
    Real dynamic_pressure_Pa;
    Rv3 v_est_ned_ned2wind_m_per_s;
    Real64 altitude_hae_wgs84_m;
    Real64 latitude_rad;
    Real64 longitude_rad;
    bool is_onground;
    Rv3 v_ned_ned2vf_m_per_s;
    Real air_density_kg_per_m3;
    Rv3 rpy_vf_from_ned_rad;
    Rv3 w_vf_ned2vf_average_rad_per_s;
    Rv4 q_ned_from_vf;
    Real altitude_agl_m;
    Rv3 a_vf_ned2vf_average_m_per_s2;
    StateEstimateFieldStatus::Status status_agl;
    StateEstimateFieldStatus::Status status_posvel_horiz;
};
```

### 9.2 Controller Input/Output

The controller input and output structures define the interface to the controller system:

```cpp
struct Input
{
    MissionResetCommand controllers_reset_command;
    NavigationAndSensingSystem::StateEstimate state_estimate;
    PaalHealthSummary paal_health_summary;
    Mixer_return mixer_return;
    MixerAllocationData mixer_allocation_data;
    Vms::LandCommandParams land_command;
    Airspeed_modulation_command airspeed_modulation_command;
    Route_command_and_control route_command_and_control;
    Vms::TakeoffCommandParams takeoff_command;
};

struct Output
{
    MissionResetCommand mixer_reset_command;
    ForcesAndTorquesRequest forces_and_torques_request;
    SchedulerData scheduler_data;
    ControllerStatus controller_status;
};
```

### 9.3 Message Flow Relationships

The framework defines a complex message flow between components:

1. Sensor data flows into the navigation system
2. Navigation system produces state estimates
3. State estimates flow to the controller system
4. Controller system produces actuator commands
5. Actuator commands flow to the motor control system
6. Status information flows back to monitoring components

## Referenced Context Files

The following context files provided useful information for understanding the SIL framework:

1. `code/PA_SIL/include/Recovery_messages.h` - Defined the message structures used throughout the system
2. `code/PA_SIL/include/Knobs_cfg.h` - Provided configuration parameters for the system
3. `code/PA_SIL/include/Wrapper_mission_input.h` - Defined mission input structure
4. `code/PA_SIL/source/Emb_navigation_wrapper.cpp` - Showed the implementation of the navigation wrapper
5. `code/PA_SIL/source/Recovery_lane_step1_wrapper.cpp` - Demonstrated the recovery system interface