# Generated from:

- src/AdnVehicleRecoveryWrapperAlgorithms/algorithm/RecoveryWrapper/src/RouteTracker.h (2769 tokens)
- src/AdnVehicleRecoveryWrapperAlgorithms/algorithm/RecoveryWrapper/src/RouteTracker.cc (12006 tokens)

---

# RouteTracker Component: Comprehensive Analysis

## 1. Overview and Core Responsibilities

The RouteTracker is a critical component of the vehicle recovery system responsible for managing routes during recovery operations. It serves as the primary route management system when the recovery system takes control of the vehicle, handling route selection, tracking, and landing decision-making.

Key responsibilities include:
- Managing and tracking mission routes (takeoff-to-delivery, delivery-to-landing, takeoff-to-landing)
- Identifying and executing return-home routes when recovery takes control
- Making landing decisions based on route completion, battery state, and position validity
- Coordinating with the State Estimate Processor (SEP) and Trajectory Command Generator (TCG)
- Validating routes and ensuring arming conditions are met

## 2. State Machine and Route Management Workflow

### Route Status State Machine

The RouteTracker maintains routes in one of four states:
- `UNAVAILABLE`: Route has not been received or failed validation
- `READY`: Route has been received and validated, but tracking has not started
- `TRACKING`: Route is currently being tracked by the vehicle
- `COMPLETED`: Route has been successfully completed

### Route Management Workflow

1. **Route Reception Phase**:
   - Routes are received via `HandleRouteCommandAndControlInput()`
   - Only routes received before pre-takeoff or arm commands are accepted
   - Routes are categorized by ID:
     - `kTakeoffToDeliveryRouteId` (1): Takeoff to delivery point
     - `kDeliveryToLandingRouteId` (2): Delivery to landing point
     - `kTakeoffToLandingRouteId` (3): Direct takeoff to landing
     - IDs ≥ 1000: Return home routes

2. **Route Validation Phase**:
   - Routes are validated via `SetRouteInfoData()`
   - Checks include:
     - Route must have at least one maneuver
     - Number of maneuvers must not exceed storage capacity
   - End points are calculated and stored

3. **Arming Validation Phase**:
   - `VerifyIfArmingIsAllowed()` checks if arming should be permitted
   - Valid route combinations:
     - One takeoff-to-land route, OR
     - One takeoff-to-delivery route AND one delivery-to-land route
   - Arming is blocked if:
     - Both takeoff-to-land and takeoff-to-delivery routes are received
     - Both takeoff-to-land and delivery-to-land routes are received
     - Only takeoff-to-delivery without delivery-to-land (or vice versa)
     - Any validation errors occurred during route processing

4. **Route Tracking Phase**:
   - After pre-takeoff command, tracking begins with:
     - Takeoff-to-delivery route if available, or
     - Takeoff-to-landing route if available
   - When takeoff-to-delivery completes, switches to delivery-to-land route
   - Route completion is determined by:
     - TCG reporting route as completed
     - Distance to endpoint below threshold (for delivery routes)
     - Controller's route tracking data (after recovery takes control)

5. **Recovery Takeover Phase**:
   - When recovery takes control, it identifies the best return-home route
   - Selection criteria: shortest route (by number of maneuvers) that includes current maneuver
   - If tracking error exceeds threshold, commands immediate landing

6. **Landing Decision Phase**:
   - Landing is commanded when:
     - Route is completed
     - Position estimate becomes invalid
     - Battery state of charge falls below threshold
     - No valid return route is found after recovery takeover

## 3. Key Algorithms and Logic

### Route Selection Logic

```
If pre-takeoff command received AND tracking not started:
    If takeoff-to-delivery route is READY:
        Start tracking takeoff-to-delivery route
    Else if takeoff-to-landing route is READY:
        Start tracking takeoff-to-landing route
    Else:
        Log warning and disallow arming
```

### Return Home Route Selection

```
When recovery takes control:
    Set min_maneuvers = MAX_INT
    Set selected_route = NONE
    
    For each return_home_route:
        If current_maneuver_id exists in return_home_route:
            If return_home_route.maneuver_count < min_maneuvers:
                min_maneuvers = return_home_route.maneuver_count
                selected_route = return_home_route
    
    If selected_route != NONE:
        Start tracking selected_route from current_maneuver_id
    Else:
        Continue on current route
```

### Route Completion Detection

```
Function CheckIfRouteIsCompleted(tcg_output, state_estimate, is_first_cycle_after_recovery_in_control, controllers_route_tracking_data, route_information):
    route_completed = false
    
    If recovery_in_control AND not first_cycle AND tcg_output.route_id == controllers_route_tracking_data.route_id:
        route_completed |= (controllers_route_tracking_data.route_status == COMPLETED)
    Else:
        If route_id == kTakeoffToDeliveryRouteId:
            distance_to_end = calculate_distance(state_estimate, route_information.end_point)
            route_completed |= (distance_to_end <= min_north_east_distance_to_mark_route_completed_m AND 
                               phase_of_flight == VTOL AND 
                               is_recovery_in_control)
        
        route_completed |= (tcg_output.route_tracking_data.route_status == COMPLETED)
    
    If route_completed:
        route_information.status = COMPLETED
```

### Landing Decision Making

```
Function CheckIfStraightLandIsRequired(tcg_output, state_estimate, is_first_cycle_after_recovery_in_control, controllers_route_tracking_data):
    command_straight_land = false
    
    If recovery_in_control AND not first_cycle:
        horizontal_error = controllers_route_tracking_data.tracking_error_horizontal_m
        vertical_error = controllers_route_tracking_data.tracking_error_vertical_m
        total_error = sqrt(horizontal_error^2 + vertical_error^2)
        
        command_straight_land |= total_error > straight_land_on_switchover_total_tracking_threshold_m
    
    If command_straight_land:
        SetStraightLandCommand()
```

## 4. Interaction with State Estimate Processor and Trajectory Command Generator

### State Estimate Processor (SEP) Integration

The RouteTracker initializes and runs the SEP to:
- Process vehicle state information from the state estimate
- Determine the current phase of flight (VTOL, etc.)
- Filter velocity and acceleration data
- Calculate air-relative quantities needed for trajectory generation

SEP inputs include:
- Position (latitude, longitude, altitude)
- Velocity in NED frame
- Acceleration in vehicle frame
- Angular rates
- Wind velocity estimates
- Quaternion orientation

SEP outputs feed directly into the TCG for trajectory generation.

### Trajectory Command Generator (TCG) Integration

The RouteTracker initializes and runs the TCG to:
- Store and process route information
- Generate trajectory commands for route tracking
- Determine route completion status
- Provide tracking error information

The RouteTracker customizes TCG parameters:
```cpp
::controllers::tcg::Param RouteTracker::CreateTcgParameters(const ::controllers::tcg::Param& nominal_tcg_param) const {
    ::controllers::tcg::Param src_tcg_param(nominal_tcg_param);
    // Set the TTCG to always use search for the closest point
    src_tcg_param.ttcg.always_perform_search_for_closest_point = true;
    return src_tcg_param;
}
```

This ensures the TCG always searches for the closest point on the route, which is critical for recovery operations where the vehicle may need to join a route at an arbitrary point.

## 5. Contingency Handling

### Low Battery Handling

```cpp
if (input.is_recovery_in_control) {
    if (state_estimate.status_posvel_horiz.value != StateEstimateFieldStatus::VALID) {
        VSDK_LOG_INFO_ONCE(logger_, "Horizontal position is not valid, a straight land will be commanded.");
        SetStraightLandCommand();
    } else if (input.battery_soc_received && input.pack_state_of_charge_cp < param_.max_state_of_charge_for_land_cp) {
        VSDK_LOG_INFO_ONCE(logger_, "Battery state of charge %d is below minimum %d, a straight land will be commanded.",
            input.pack_state_of_charge_cp,
            param_.max_state_of_charge_for_land_cp);
        SetStraightLandCommand();
    }
}
```

When battery state of charge falls below the configured threshold, the RouteTracker immediately commands a straight land at the current position.

### Position Estimate Loss

If the horizontal position estimate becomes invalid, the RouteTracker immediately commands a straight land:

```cpp
if (input.is_recovery_in_control) {
    if (state_estimate.status_posvel_horiz.value != StateEstimateFieldStatus::VALID) {
        VSDK_LOG_INFO_ONCE(logger_, "Horizontal position is not valid, a straight land will be commanded.");
        SetStraightLandCommand();
    }
}
```

### Excessive Tracking Error

After recovery takes control, if the tracking error exceeds a threshold, the RouteTracker commands a straight land:

```cpp
const float horizontal_tracking_error = controllers_route_tracking_data.tracking_error_horizontal_m;
const float vertical_tracking_error = controllers_route_tracking_data.tracking_error_vertical_m;
const float total_tracking_error = std::sqrt(horizontal_tracking_error*horizontal_tracking_error + vertical_tracking_error*vertical_tracking_error);

command_straight_land |= total_tracking_error > param_.straight_land_on_switchover_total_tracking_threshold_m;
```

### Missing or Invalid Routes

If required routes are missing or invalid:
- Arming is disallowed before takeoff
- A straight land is commanded if recovery takes control and no valid return route is found

## 6. Route Transitions

### Takeoff to Delivery Transition

When the takeoff-to-delivery route completes, the RouteTracker transitions to the delivery-to-land route:

```cpp
if (state_.takeoff_to_delivery_route_info.status.value == RecoveryRouteStatus::COMPLETED) {
    if (state_.delivery_to_land_route_info.status.value == RecoveryRouteStatus::READY) {
        // Reached delivery, switch to track delivery to land
        SetCurrentRouteTrackingData(state_.delivery_to_land_route_info);
        state_.command_delivery_to_land_route = true;
        VSDK_LOG_INFO(logger_,
                     "Take Off To Delivivery Route Completed. \n Issuing command to TCG to start tracking Delivery To Landing Route (route ID %d, maneuver start ID %d)",
                     state_.current_route_information.command_route_id,
                     state_.current_route_information.tracking_start_maneuver_id);
    } else if (state_.delivery_to_land_route_info.status.value == RecoveryRouteStatus::UNAVAILABLE) {
        VSDK_LOG_INFO_ONCE(logger_, "No route after delivery, if Switchover happens recovery will land immediately!");
        SetStraightLandCommand();
    }
}
```

### Transition to Return Home

When recovery takes control, it identifies and transitions to the most appropriate return home route:

```cpp
if (first_cycle_after_recovery_in_control) {
    VSDK_LOG_INFO(logger_,"Searching for a return home route.")
    SetReturnHomeRouteCommand(tcg_output);
}
```

The `SetReturnHomeRouteCommand` function finds the shortest return home route that includes the current maneuver and begins tracking it from the current position.

### Transition to Landing

Landing is commanded in several scenarios:
1. After completing a route that ends in landing:
   ```cpp
   if (state_.takeoff_to_land_route_info.status.value == RecoveryRouteStatus::COMPLETED){
       VSDK_LOG_INFO_ONCE(logger_, "Completed Take Off To Landing route. Starting Land.");
       SetStraightLandCommand();
   }
   ```

2. After completing a return home route:
   ```cpp
   if (return_home_route_info.status.value == RecoveryRouteStatus::COMPLETED){
       VSDK_LOG_INFO_ONCE(logger_, "Completed Return Home Route, ID: %d", return_home_route_info.route_id);
       SetStraightLandCommand();
   }
   ```

3. In contingency situations (low battery, invalid position, excessive tracking error)

## 7. Data Structures and State Management

### Key State Variables

```cpp
// Route status tracking
RecoveryRouteInformation takeoff_to_delivery_route_info;
RecoveryRouteInformation delivery_to_land_route_info;
RecoveryRouteInformation takeoff_to_land_route_info;
vsdk::StaticVector<RecoveryRouteInformation> return_home_route_info;

// Current tracking state
bool tracking_has_started;
RouteTrackingData current_route_information;
bool return_home_route_identified;
uint32_t idx_min_return_home_route_info;

// Command state
bool land_command_set;
LandCommand land_command;
bool command_delivery_to_land_route;

// Control state
bool is_recovery_in_control;
bool pre_take_off_cmd_received;
uint32_t max_controller_cmd_seq_id_to_accept_routes;

// Arming state
bool is_arming_allowed;
bool arming_disallowed_event_encountered;
```

### RecoveryRouteInformation Structure

```cpp
struct RecoveryRouteInformation_0_1 {
    RecoveryRouteStatus_0_1 status;
    uint32_t route_id;
    uint32_t tracking_start_maneuver_id;
    vsdk::StaticVector<uint32_t> maneuver_id_list;
    vsdk::message::adn::vehicle::common::Wgs84Location_0_1 lla_end_point;
    vsdk::message::adn::vehicle::common::Wgs84Location_0_1 lla_ned_origin;
};
```

## 8. Parameters and Configuration

Key configurable parameters:
- `min_north_east_distance_to_mark_route_completed_m`: Distance threshold to consider a delivery route completed
- `max_state_of_charge_for_land_cp`: Battery threshold below which landing is commanded
- `straight_land_on_switchover_total_tracking_threshold_m`: Maximum allowed tracking error before commanding a straight land
- `vms_takeoff_agl_m`: Assumed takeoff altitude above ground level

## 9. File-by-File Breakdown

### RouteTracker.h

Defines the RouteTracker class interface with:
- Constructor/destructor and deleted copy/move constructors
- Main `Run()` method for route tracking logic
- Input handling methods:
  - `HandleRouteCommandAndControlInput()`
  - `HandleControllerCommandInput()`
- State accessor methods:
  - `GetSepState()`, `GetTcgState()`
  - `IsLandCommandSet()`, `GetLandCommand()`
  - `IsReturnHomeCommandSet()`, `GetRouteCommand()`
  - `IsDeliveryToLandCommandSet()`, `IsArmingAllowed()`
- Protected methods for internal logic:
  - Route management: `SetRouteInfoData()`, `SetCurrentRouteTrackingData()`
  - Route completion: `CheckIfRouteIsCompleted()`, `CheckIfStraightLandIsRequired()`
  - Command generation: `SetLandCommand()`, `SetStraightLandCommand()`, `SetReturnHomeRouteCommand()`
  - Validation: `VerifyIfArmingIsAllowed()`, `IsSpecificationValid()`

### RouteTracker.cc

Implements the RouteTracker class with:
- Constructor initialization of state variables and component objects (SEP, TCG)
- Main `Run()` method implementation with route tracking workflow
- Route handling logic for different route types
- SEP and TCG integration
- Route completion detection and transition logic
- Return home route selection algorithm
- Landing decision making
- Arming validation logic

## 10. Cross-Component Relationships

The RouteTracker interacts with several other components:

1. **State Estimate Processor (SEP)**:
   - Receives vehicle state information
   - Processes and filters state data for trajectory generation

2. **Trajectory Command Generator (TCG)**:
   - Receives route information and tracking commands
   - Generates trajectory commands for route tracking
   - Reports route completion status and tracking errors

3. **RecoveryWrapper**:
   - Parent component that provides inputs to RouteTracker
   - Receives land commands and route tracking decisions

4. **RecoveryLane**:
   - C interface for communicating with the Simulink-based recovery system
   - Receives mission inputs including takeoff data

## Referenced Context Files

The RouteTracker implementation references several important context files:

1. **StateEstimateProcessor.h/cc**: Provides the interface and implementation for processing vehicle state estimates
2. **TrajectoryCommandGenerator.h/cc**: Provides the interface and implementation for generating trajectory commands
3. **Geographic.h**: Contains utilities for geographic coordinate transformations
4. **TypeConversions.h**: Contains utilities for converting between different data types
5. **RecoveryLane.h**: C interface for the Simulink-based recovery system

## Summary

The RouteTracker is a sophisticated component responsible for managing routes during recovery operations. It maintains a state machine for route tracking, makes intelligent decisions about route selection and landing, and handles various contingencies like low battery and position loss. It integrates closely with the State Estimate Processor and Trajectory Command Generator to ensure smooth and safe vehicle operation during recovery scenarios. The component is designed with safety as a priority, with multiple checks and fallbacks to ensure the vehicle can safely return home or land in any situation.