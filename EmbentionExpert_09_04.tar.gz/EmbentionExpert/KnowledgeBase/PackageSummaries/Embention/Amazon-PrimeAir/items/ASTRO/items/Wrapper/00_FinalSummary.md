# Generated from:

- Amazon-PrimeAir/items/ASTRO/items/Wrapper/03_Recovery_GNSS_Processing.md (2400 tokens)
- Amazon-PrimeAir/items/ASTRO/items/Wrapper/03_Recovery_Route_Tracking.md (4308 tokens)
- Amazon-PrimeAir/items/ASTRO/items/Wrapper/03_Recovery_Message_Handling.md (2328 tokens)
- Amazon-PrimeAir/items/ASTRO/items/Wrapper/03_Recovery_Wrapper_Core.md (4298 tokens)
- Amazon-PrimeAir/items/ASTRO/items/Wrapper/02_Recovery_System_Integration.md (2771 tokens)
- Amazon-PrimeAir/items/ASTRO/items/Wrapper/01_Recovery_Testing.md (5007 tokens)

---

# Amazon Prime Air Recovery System Knowledge Graph

## System Overview

The Amazon Prime Air Recovery System is a comprehensive backup navigation and control solution designed to take over vehicle operation when the primary flight control system fails. It provides a complete, independent path from sensor inputs to motor commands, ensuring continued safe operation and mission completion or safe landing.

## System Architecture

The Recovery System consists of four major components working together:

1. **Recovery Wrapper Core** - The central coordination component that integrates navigation, controllers, and actuator allocation components to provide a complete backup flight control solution.

2. **GNSS Processing** - Handles satellite navigation data, processing both navigation messages and raw GNSS measurements to generate position/velocity solutions.

3. **Route Tracking** - Manages mission routes and landing decisions, selecting appropriate routes based on mission phase and making landing decisions based on route completion, battery state, and position validity.

4. **Message Handling** - Transforms data between system components, converting between VSDK message formats and Simulink data structures.

## Data Flow

The system follows a clear data flow path:

1. **Sensor Input to State Estimation**:
   - Collects sensor data (IMU, GNSS, pressure sensors, LIDAR)
   - Processes GNSS data to generate position/velocity solutions
   - Fuses all sensor data to produce a complete state estimate

2. **State Estimation to Control Commands**:
   - Converts navigation output to controller-compatible format
   - Manages mission routes and selects appropriate routes
   - Generates trajectory commands based on route

3. **Control Commands to Motor Output**:
   - Converts force and torque commands to motor RPM commands
   - Sets motor RPM values and controls motor arming states
   - Applies safety checks before commanding motors

## Key Components

### Recovery Wrapper Core

The RecoveryWrapperObject serves as the central component, with responsibilities including:
- Switchover detection from primary to recovery control
- Navigation processing using sensor inputs
- Control logic execution after switchover
- Motor command generation for vehicle control
- Route tracking management

The core runs at two main frequencies:
- 500Hz for navigation processing (triggered by IMU data)
- 100Hz for control processing (triggered by state estimate updates)

For more details, see [Recovery Wrapper Core](items/ASTRO/items/Wrapper/03_Recovery_Wrapper_Core.md).

### GNSS Processing

The RecoveryGnssProcessorObject is responsible for processing GNSS data for vehicle recovery systems, serving as a wrapper around a PVT (Position, Velocity, Time) model that processes:
- Navigation messages from satellites
- Raw GNSS measurements

It generates position and velocity solutions and provides logging data for debugging and analysis.

For more details, see [Recovery GNSS Processing](items/ASTRO/items/Wrapper/03_Recovery_GNSS_Processing.md).

### Route Tracking

The RouteTracker manages routes during recovery operations, handling:
- Mission routes (takeoff-to-delivery, delivery-to-landing, takeoff-to-landing)
- Return-home routes when recovery takes control
- Landing decisions based on route completion, battery state, and position validity
- Coordination with the State Estimate Processor (SEP) and Trajectory Command Generator (TCG)

For more details, see [Recovery Route Tracking](items/ASTRO/items/Wrapper/03_Recovery_Route_Tracking.md).

### Message Handling

The message handling functionality serves as the data transformation layer, handling:
- Conversion between VSDK message formats and Simulink data structures
- GNSS data transformation
- Measurement data population
- Navigation introspect data processing
- State estimate functions
- Controller logs population

For more details, see [Recovery Message Handling](items/ASTRO/items/Wrapper/03_Recovery_Message_Handling.md).

## System States and Transitions

The Recovery System implements a state machine with the following states:

1. **Initializing**: System startup, initializes components
2. **Idle**: Waiting for commands after navigation is initialized
3. **ReadyForTakeOff**: Ready for mission after pre-flight checks
4. **ReadyForInAirTakeOver**: Ready for in-air control before switchover
5. **DepartureRecovery**: Initial recovery control after switchover
6. **FlyMission**: Following mission route after vehicle is stabilized
7. **Land**: Executing landing procedure
8. **Landed**: On ground after landing
9. **KillHazOps**: Shutdown sequence after mission completion

## Contingency Handling

The system includes robust contingency handling for various scenarios:

1. **Low Battery Handling**: Commands immediate landing when battery state of charge falls below threshold
2. **Position Estimate Loss**: Commands immediate landing if horizontal position estimate becomes invalid
3. **Excessive Tracking Error**: Commands landing if tracking error exceeds threshold after recovery takes control
4. **Missing or Invalid Routes**: Disallows arming before takeoff or commands landing if no valid return route is found

## Testing Approach

The recovery system is tested through:

1. **Unit Tests**: Validating individual components like GNSS processing and route tracking
2. **Integration Tests**: Verifying the complete system's ability to detect switchover, process navigation data, and generate control commands
3. **Switchover Simulation**: Testing the system's response to switchover signals
4. **Route Management Testing**: Verifying proper handling of different route types
5. **Command Sequence Validation**: Ensuring proper handling of command sequencing

For more details, see [Recovery Testing](items/ASTRO/items/Wrapper/01_Recovery_Testing.md).

## System Integration

The Recovery System integrates with the broader vehicle control architecture through:

1. **Switchover Detection**: Monitoring a system file for a "RECOVERY" signal
2. **Sensor Integration**: Processing inputs from IMU, GNSS, pressure sensors, and LIDAR
3. **Control Output**: Generating motor RPM commands for vehicle control
4. **Route Management**: Handling mission routes and coordinating with trajectory generation

For a comprehensive overview of system integration, see [Recovery System Integration](items/ASTRO/items/Wrapper/02_Recovery_System_Integration.md).

## Conclusion

The Amazon Prime Air Recovery System provides a comprehensive backup navigation and control capability that can take over vehicle operation when the primary system fails. Its modular design with specialized components enables efficient operation and clear separation of concerns, while its robust contingency handling ensures the vehicle can safely complete its mission or land in various failure scenarios.