# Generated from:

- items/pdi_Monitor/setup/ver_spdif_imu0.xml (241 tokens)
- items/pdi_Monitor/setup/ver_spdif_imu1.xml (241 tokens)
- items/pdi_Monitor/setup/ver_spdif_imu2.xml (137 tokens)
- items/pdi_Monitor/setup/ver_spdif_imu3.xml (128 tokens)
- items/pdi_Monitor/setup/ver_spdif_imugeom.xml (122 tokens)
- items/pdi_Monitor/setup/ver_spdif_imupos.xml (78 tokens)
- items/pdi_Monitor/setup/ver_spdif_gyr0filt.xml (172 tokens)
- items/pdi_Monitor/setup/ver_spdif_gyr1filt.xml (172 tokens)
- items/pdi_Monitor/setup/ver_spdif_gyr2filt.xml (172 tokens)
- items/pdi_Monitor/setup/ver_spdif_gyr3filt.xml (172 tokens)
- items/pdi_Monitor/setup/ver_spdif_gyrlps.xml (334 tokens)
- items/pdi_Monitor/setup/ver_spdif_gyrsuite.xml (325 tokens)
- items/pdi_Monitor/setup/ver_spdif_acc0filt.xml (172 tokens)
- items/pdi_Monitor/setup/ver_spdif_acc1filt.xml (172 tokens)
- items/pdi_Monitor/setup/ver_spdif_acc2filt.xml (172 tokens)
- items/pdi_Monitor/setup/ver_spdif_acc3filt.xml (172 tokens)
- items/pdi_Monitor/setup/ver_spdif_acclps.xml (334 tokens)
- items/pdi_Monitor/setup/ver_spdif_accsuite.xml (325 tokens)
- items/pdi_Monitor/setup/ver_spdif_mag0filt.xml (105 tokens)
- items/pdi_Monitor/setup/ver_spdif_mag2filt.xml (105 tokens)
- items/pdi_Monitor/setup/ver_spdif_mag3filt.xml (105 tokens)
- items/pdi_Monitor/setup/ver_spdif_mag4filt.xml (105 tokens)
- items/pdi_Monitor/setup/ver_spdif_mag5filt.xml (105 tokens)
- items/pdi_Monitor/setup/ver_spdif_mag6filt.xml (105 tokens)
- items/pdi_Monitor/setup/ver_spdif_mag7filt.xml (107 tokens)
- items/pdi_Monitor/setup/ver_spdif_magResfilt.xml (106 tokens)
- items/pdi_Monitor/setup/ver_spdif_maglps.xml (684 tokens)
- items/pdi_Monitor/setup/ver_spdif_extacc0.xml (136 tokens)
- items/pdi_Monitor/setup/ver_spdif_extacc1.xml (136 tokens)
- items/pdi_Monitor/setup/ver_spdif_extgyr0.xml (136 tokens)
- items/pdi_Monitor/setup/ver_spdif_extgyr1.xml (136 tokens)
- items/pdi_Monitor/setup/ver_spdif_extmag0.xml (136 tokens)
- items/pdi_Monitor/setup/ver_spdif_extmag1.xml (136 tokens)
- items/pdi_Monitor/setup/ver_spdif_extnavsen.xml (92 tokens)
- items/pdi_Monitor/setup/ver_spdif_extobs.xml (82 tokens)
- items/pdi_Monitor/setup/ver_spdif_stp0filt.xml (103 tokens)
- items/pdi_Monitor/setup/ver_spdif_stp1filt.xml (103 tokens)
- items/pdi_Monitor/setup/ver_spdif_stp2filt.xml (104 tokens)
- items/pdi_Monitor/setup/ver_spdif_qinffilt.xml (103 tokens)
- items/pdi_Monitor/setup/ver_spdif_att.xml (105 tokens)
- items/pdi_Monitor/setup/ver_spdif_kf.xml (166 tokens)
- items/pdi_Monitor/setup/ver_spdif_grav_ext_ahrs.xml (76 tokens)
- items/pdi_Monitor/installation/ver_ipdif_calmag0.xml (191 tokens)
- items/pdi_Monitor/installation/ver_ipdif_calmag2.xml (191 tokens)
- items/pdi_Monitor/installation/ver_ipdif_calmag3.xml (191 tokens)
- items/pdi_Monitor/installation/ver_ipdif_calmag4.xml (191 tokens)
- items/pdi_Monitor/installation/ver_ipdif_calmag5.xml (191 tokens)
- items/pdi_Monitor/installation/ver_ipdif_calmag6.xml (191 tokens)
- items/pdi_Monitor/installation/ver_ipdif_calmag7.xml (192 tokens)
- items/pdi_Monitor/installation/ver_ipdif_extcalmag0.xml (193 tokens)
- items/pdi_Monitor/installation/ver_ipdif_extcalmag1.xml (193 tokens)
- items/pdi_Monitor/installation/ver_ipdif_extcalacc0.xml (193 tokens)
- items/pdi_Monitor/installation/ver_ipdif_extcalacc1.xml (193 tokens)
- items/pdi_Monitor/installation/ver_ipdif_extcalgyr0.xml (193 tokens)
- items/pdi_Monitor/installation/ver_ipdif_extcalgyr1.xml (193 tokens)
- items/pdi_Monitor/installation/ver_ipdif_gyrocal.xml (1045 tokens)
- items/pdi_Monitor/installation/ver_ipdif_acclbu.xml (106 tokens)
- items/pdi_Monitor/production/ver_ppdif_calacc0.xml (191 tokens)
- items/pdi_Monitor/production/ver_ppdif_calacc1.xml (191 tokens)
- items/pdi_Monitor/production/ver_ppdif_calacc2.xml (191 tokens)
- items/pdi_Monitor/production/ver_ppdif_calacc3.xml (191 tokens)
- items/pdi_Monitor/production/ver_ppdif_calgyr0.xml (191 tokens)
- items/pdi_Monitor/production/ver_ppdif_calgyr1.xml (191 tokens)
- items/pdi_Monitor/production/ver_ppdif_calgyr2.xml (191 tokens)
- items/pdi_Monitor/production/ver_ppdif_calgyr3.xml (191 tokens)
- items/pdi_Monitor/production/ver_ppdif_calmag_res.xml (192 tokens)
- items/pdi_Monitor/production/ver_ppdif_calstp0.xml (112 tokens)
- items/pdi_Monitor/production/ver_ppdif_calstp1.xml (112 tokens)
- items/pdi_Monitor/production/ver_ppdif_calstp2.xml (112 tokens)
- items/pdi_Monitor/production/ver_ppdif_calqinf.xml (112 tokens)

---

# Comprehensive Analysis of Drone Control Platform Sensor Systems

## 1. Sensor Hierarchy and Organization

The drone control platform implements a sophisticated sensor system with multiple layers of redundancy and sensor fusion capabilities. The system is organized as follows:

### 1.1 IMU Configuration Overview

The platform incorporates four distinct Inertial Measurement Units (IMUs), each with unique configurations:

| IMU ID | File | Version | Primary Characteristics |
|--------|------|---------|-------------------------|
| IMU0 (ID: 102) | imu0.bin | 7.3.1 | Accelerometer: 4g range, 160Hz sample rate<br>Gyroscope: 12°/s range, 128Hz sample rate |
| IMU1 (ID: 103) | imu1.bin | 7.3.1 | Accelerometer: 4g range, 160Hz sample rate<br>Gyroscope: 12°/s range, 128Hz sample rate |
| IMU2 (ID: 256) | imu2.bin | 7.3.1 | Accelerometer: 2g range, 160Hz bandwidth<br>Gyroscope: Custom ODR/BW settings |
| IMU3 (ID: 360) | imu3.bin | 7.3.1 | Minimal configuration with error thresholds |

The IMU configuration demonstrates a strategic approach to sensor redundancy, with IMU0 and IMU1 having identical configurations, while IMU2 and IMU3 provide alternative sensing capabilities with different ranges and sampling characteristics.

### 1.2 Sensor Suite Organization

The sensor system is organized into several distinct suites:

1. **Accelerometer Suite** (accsuite.bin)
   - Manages up to 8 accelerometer sensors (s0-s7)
   - Default sensor selection (def-sen: 0)
   - Fusion time constants: tau_v = 2.0, tau_s2 = 20.0

2. **Gyroscope Suite** (gyrsuite.bin)
   - Manages up to 8 gyroscope sensors (s0-s7)
   - Default sensor selection (def-sen: 0)
   - Identical fusion time constants to accelerometer suite

3. **Magnetometer System**
   - Multiple magnetometer configurations (mag0filt.bin through mag7filt.bin)
   - Additional specialized magnetometer (magResfilt.bin)

4. **External Sensor Interfaces**
   - External accelerometers (extacc0.bin, extacc1.bin)
   - External gyroscopes (extgyr0.bin, extgyr1.bin)
   - External magnetometers (extmag0.bin, extmag1.bin)
   - External navigation sensor (extnavsen.bin)

## 2. Sensor Specifications and Parameters

### 2.1 Accelerometer Configurations

#### 2.1.1 Internal Accelerometers

| Parameter | IMU0/IMU1 | IMU2 | IMU3 |
|-----------|-----------|------|------|
| Range | 4g | 2g | Not specified |
| Sample Rate | 160Hz | 12 (ODR) | Not specified |
| Bandwidth | 0 (accelbw) | 160Hz (accBWP) | Not specified |
| Max Non-Valid Samples | 10 | 30 | 0 |
| Max Delta Threshold | 313.8128 | 235.3596 | 156.8 |
| DSO LPF Enable | 0 (disabled) | Not specified | Not specified |

#### 2.1.2 External Accelerometers

External accelerometers (extacc0.bin, extacc1.bin) are configured with:
- Desired frequency: 0.0 (adaptive)
- Filter configuration: disabled (enable: 0)
- No value limits (-3.4028235E38 to 3.4028235E38)
- Max non-valid samples: 10

### 2.2 Gyroscope Configurations

#### 2.2.1 Internal Gyroscopes

| Parameter | IMU0/IMU1 | IMU2 | IMU3 |
|-----------|-----------|------|------|
| Range | 12°/s | 0 (custom) | Not specified |
| Sample Rate | 128Hz | 2 (gyrOdrBw) | Not specified |
| HPF Enable | 0 (disabled) | Not specified | Not specified |
| DSO LPF Enable | 0 (disabled) | Not specified | Not specified |
| Max Non-Valid Samples | 10 | 30 | 0 |
| Max Delta Threshold | 69.81317 | 69.81317 | 69.81317 |

#### 2.2.2 External Gyroscopes

External gyroscopes (extgyr0.bin, extgyr1.bin) are configured with:
- Desired frequency: 0.0 (adaptive)
- Filter configuration: disabled (enable: 0)
- No value limits (-3.4028235E38 to 3.4028235E38)
- Max non-valid samples: 10

### 2.3 Magnetometer Configurations

All magnetometers (mag0filt.bin through mag7filt.bin and magResfilt.bin) share similar configurations:
- IIR filter: disabled (enable: 0)
- Cutoff frequency: 1.0 (when enabled)
- Max non-valid samples: 0
- Max delta: 3.4028235E38 (effectively unlimited)

### 2.4 Additional Sensors

1. **Static Pressure Sensors** (stp0filt.bin, stp1filt.bin, stp2filt.bin)
   - IIR filter: disabled
   - Max non-valid samples: 10
   - Max delta thresholds: 450.0, 113.4, and 177.1875 respectively

2. **Dynamic Pressure Sensor** (qinffilt.bin)
   - IIR filter: disabled
   - Max non-valid samples: 10
   - Max delta threshold: 200.0

## 3. Filtering Strategies

### 3.1 Accelerometer Filtering

Each accelerometer has multiple filtering options:

1. **Notch Filters** (acc0filt.bin through acc3filt.bin)
   - Number of harmonics: 0 (disabled)
   - Center frequency reference: 100.0
   - Bandwidth: 20.0
   - Notch gain: 0.5
   - Currently disabled across all accelerometers

2. **Butterworth Filters**
   - Enable: 0 (disabled)
   - Cutoff frequency: 1.0 Hz
   - Currently disabled across all accelerometers

3. **Digital Signal Output (DSO) Filters**
   - Low-pass filter 2 (LPF2): disabled
   - Configurable cutoff frequency (when enabled)

### 3.2 Gyroscope Filtering

Gyroscopes have similar filtering options to accelerometers:

1. **Notch Filters** (gyr0filt.bin through gyr3filt.bin)
   - Identical configuration to accelerometer notch filters
   - Currently disabled across all gyroscopes

2. **Butterworth Filters**
   - Enable: 0 (disabled)
   - Cutoff frequency: 1.0 Hz
   - Currently disabled across all gyroscopes

3. **Hardware Filters**
   - High-pass filter (HPF): disabled
   - Digital Signal Output (DSO) LPF1: disabled

### 3.3 Magnetometer Filtering

Magnetometers use a simpler filtering approach:

1. **IIR Filters**
   - Enable: 0 (disabled)
   - Cutoff frequency: 1.0 Hz
   - Currently disabled across all magnetometers

### 3.4 External Sensor Filtering

External sensors (accelerometers, gyroscopes, magnetometers) all use the same filtering approach:
- IIR filter configuration
- Enable: 0 (disabled)
- Cutoff frequency: 1.0 Hz

## 4. Calibration Parameters and Temperature Compensation

### 4.1 Calibration Matrix Structure

All sensor calibration files follow a consistent structure with:

1. **Temperature Hysteresis** (temp_hyst)
   - Values range from 0.5 to 1.0 depending on sensor

2. **Calibration Data Elements**
   - Temperature reference point
   - Bias vector (b0, b1, b2)
   - Scale/alignment matrix (3x3 matrix with elements a00-a22)

### 4.2 Accelerometer Calibration

#### 4.2.1 Internal Accelerometers

| Accelerometer | File | Temp Reference | Temp Hysteresis |
|---------------|------|----------------|-----------------|
| ACC0 | calacc0.bin | 320.0 | 0.5 |
| ACC1 | calacc1.bin | 320.0 | 0.5 |
| ACC2 | calacc2.bin | 320.0 | 1.0 |
| ACC3 | calacc3.bin | 0.0 | 1.0 |

All accelerometers use identity matrices (1.0 on diagonal, 0.0 elsewhere) for their calibration matrices, indicating either factory calibration or pending calibration.

#### 4.2.2 External Accelerometers

External accelerometers (extcalacc0.bin, extcalacc1.bin) use:
- Temperature reference: 0.0
- Temperature hysteresis: 1.0
- Identity calibration matrices

### 4.3 Gyroscope Calibration

#### 4.3.1 Internal Gyroscopes

| Gyroscope | File | Temp Reference | Temp Hysteresis |
|-----------|------|----------------|-----------------|
| GYR0 | calgyr0.bin | 320.0 | 0.5 |
| GYR1 | calgyr1.bin | 320.0 | 0.5 |
| GYR2 | calgyr2.bin | 320.0 | 1.0 |
| GYR3 | calgyr3.bin | 0.0 | 1.0 |

All gyroscopes use identity matrices for their calibration matrices.

#### 4.3.2 Extended Gyroscope Calibration

The system includes an extended gyroscope calibration file (gyrocal.bin) that provides additional calibration parameters for up to 8 gyroscopes (c0-c7):
- Bias
- Scale factor
- Variance

All values are currently set to 0.0, indicating either factory calibration or pending calibration.

### 4.4 Magnetometer Calibration

| Magnetometer | File | Temp Reference | Temp Hysteresis |
|--------------|------|----------------|-----------------|
| MAG0 | calmag0.bin | 320.0 | 0.5 |
| MAG2 | calmag2.bin | 1.0 | 1.0 |
| MAG3 | calmag3.bin | 1.0 | 1.0 |
| MAG4 | calmag4.bin | 1.0 | 1.0 |
| MAG5 | calmag5.bin | 1.0 | 1.0 |
| MAG6 | calmag6.bin | 1.0 | 1.0 |
| MAG7 | calmag7.bin | 0.0 | 1.0 |
| MAG_RES | calmag_res.bin | 0.0 | 1.0 |

All magnetometers use identity matrices for their calibration matrices.

### 4.5 Pressure Sensor Calibration

Static pressure sensors (calstp0.bin, calstp1.bin, calstp2.bin) and dynamic pressure sensor (calqinf.bin) use a different calibration structure:
- Temperature hysteresis: 0.0
- Calibration data with x, y1, y2 values (all set to 0.0)

## 5. Sensor Fusion and Integration

### 5.1 Sensor Suite Fusion Parameters

Both accelerometer and gyroscope suites use identical fusion parameters:

1. **Selection Parameters**
   - use: 1 (enabled)
   - def-sen: 0 (default sensor)

2. **Time Constants**
   - tau_v: 2.0 (velocity time constant)
   - tau_s2: 20.0 (variance time constant)

3. **Variance Parameters** (for each sensor s0-s7)
   - ini_s2: 1.0 (initial variance)
   - min_s2: 1.0E-4 (minimum variance)

### 5.2 Linear Projection and Scale Matrices

The system uses multiple linear projection and scale matrices to transform sensor data:

1. **IMU Geometry Matrix** (imugeom.bin)
   - 3x3 identity matrix defining the IMU coordinate system

2. **IMU Position Vector** (imupos.bin)
   - Zero vector (0.0, 0.0, 0.0) defining the IMU position relative to the body frame

3. **Sensor-Specific Linear Projection Matrices**
   - Accelerometer LPS (acclps.bin): Identity matrices for 4 sensors
   - Gyroscope LPS (gyrlps.bin): Identity matrices for 4 sensors
   - Magnetometer LPS (maglps.bin): Identity matrices for 9 sensors
   - Accelerometer Body Unit (acclbu.bin): Identity matrix

### 5.3 Attitude Estimation Parameters

The attitude estimation system (att.bin) uses the following parameters:
- beta: 0.025
- zeta: 0.003
- beta0: 10.0
- zeta0: 0.0
- filt-steps: 50
- kfg: 2.0
- norm-filt: 0.1

### 5.4 Kalman Filter Parameters

The Kalman filter (kf.bin) uses the following parameters:
- gpsok-time: 5.0
- Process noise covariance matrices (Qnfb, Qnwb, Qdwb, Qdfb): Zero vectors
- Measurement noise covariance (Qdem): 1.0

## 6. Error Handling and Fault Detection

### 6.1 Non-Valid Sample Limits

The system implements non-valid sample counting to detect sensor failures:

| Sensor Type | IMU0/IMU1 | IMU2 | IMU3 | External |
|-------------|-----------|------|------|----------|
| Accelerometer | 10 | 30 | 0 | 10 |
| Gyroscope | 10 | 30 | 0 | 10 |
| Magnetometer | 0 | 0 | 0 | 10 |
| Static Pressure | 10 | 10 | 10 | N/A |
| Dynamic Pressure | 10 | N/A | N/A | N/A |

### 6.2 Maximum Delta Thresholds

The system implements maximum delta thresholds to detect sudden changes or spikes in sensor data:

| Sensor Type | IMU0/IMU1 | IMU2 | IMU3 |
|-------------|-----------|------|------|
| Accelerometer | 313.8128 | 235.3596 | 156.8 |
| Gyroscope | 69.81317 | 69.81317 | 69.81317 |
| Magnetometer | 3.4028235E38 (unlimited) | 3.4028235E38 | 3.4028235E38 |
| Static Pressure | 450.0, 113.4, 177.1875 (different sensors) | N/A | N/A |
| Dynamic Pressure | 200.0 | N/A | N/A |

### 6.3 External Sensor Validation

External navigation sensor (extnavsen.bin) includes additional validation parameters:
- Desired frequency: 100.0 Hz
- Status validation: disabled (req_status0_present: 0)

## 7. Redundancy Strategy

The sensor system implements a comprehensive redundancy strategy:

1. **Multiple IMUs**
   - Four distinct IMUs with different configurations
   - IMU0 and IMU1 have identical configurations (primary redundancy)
   - IMU2 and IMU3 provide alternative sensing capabilities

2. **Multiple Sensor Types**
   - Multiple accelerometers (4 internal + 2 external)
   - Multiple gyroscopes (4 internal + 2 external)
   - Multiple magnetometers (8 internal + 2 external)
   - Multiple pressure sensors (3 static + 1 dynamic)

3. **Sensor Suite Management**
   - Accelerometer and gyroscope suites manage up to 8 sensors each
   - Automatic selection of default sensor (def-sen: 0)
   - Variance-based sensor quality assessment

4. **Fault Detection**
   - Non-valid sample counting
   - Maximum delta thresholds
   - Temperature monitoring and compensation

## 8. File-by-File Breakdown

### 8.1 IMU Configuration Files

#### 8.1.1 IMU0 Configuration (ver_spdif_imu0.xml)
- ID: 102
- Filename: imu0.bin
- Version: 7.3.1
- Accelerometer: 4g range, 160Hz sample rate, bandwidth 0
- Gyroscope: 12°/s range, 128Hz sample rate
- Temperature sensing enabled
- Maximum non-valid samples: 10 for both accelerometer and gyroscope
- Maximum delta thresholds: 313.8128 for accelerometer, 69.81317 for gyroscope

#### 8.1.2 IMU1 Configuration (ver_spdif_imu1.xml)
- ID: 103
- Filename: imu1.bin
- Version: 7.3.1
- Identical configuration to IMU0

#### 8.1.3 IMU2 Configuration (ver_spdif_imu2.xml)
- ID: 256
- Filename: imu2.bin
- Version: 7.3.1
- Accelerometer: 2g range, ODR 12, bandwidth 160Hz
- Gyroscope: Range 0, ODR/BW 2
- Maximum non-valid samples: 30 for both accelerometer and gyroscope
- Maximum delta thresholds: 235.3596 for accelerometer, 69.81317 for gyroscope

#### 8.1.4 IMU3 Configuration (ver_spdif_imu3.xml)
- ID: 360
- Filename: imu3.bin
- Version: 7.3.1
- Minimal configuration with no non-valid sample counting
- Maximum delta thresholds: 156.8 for accelerometer, 69.81317 for gyroscope

### 8.2 Sensor Suite Configuration Files

#### 8.2.1 Accelerometer Suite (ver_spdif_accsuite.xml)
- ID: 2
- Filename: accsuite.bin
- Version: 7.3.1
- Selection parameters: use=1, def-sen=0
- Time constants: tau_v=2.0, tau_s2=20.0
- Variance parameters for 8 sensors (s0-s7): ini_s2=1.0, min_s2=1.0E-4

#### 8.2.2 Gyroscope Suite (ver_spdif_gyrsuite.xml)
- ID: 3
- Filename: gyrsuite.bin
- Version: 7.3.1
- Identical configuration to accelerometer suite

### 8.3 Filter Configuration Files

#### 8.3.1 Accelerometer Filters (ver_spdif_acc0filt.xml through ver_spdif_acc3filt.xml)
- IDs: 97, 107, 257, 363
- Filenames: acc0filt.bin through acc3filt.bin
- Version: 7.3.1
- Notch filter: disabled (num-harmonics: 0)
- Butterworth filter: disabled (enable: 0)

#### 8.3.2 Gyroscope Filters (ver_spdif_gyr0filt.xml through ver_spdif_gyr3filt.xml)
- IDs: 98, 108, 258, 364
- Filenames: gyr0filt.bin through gyr3filt.bin
- Version: 7.3.1
- Notch filter: disabled (num-harmonics: 0)
- Butterworth filter: disabled (enable: 0)

#### 8.3.3 Magnetometer Filters (ver_spdif_mag0filt.xml through ver_spdif_magResfilt.xml)
- IDs: 99, 124, 253, 262, 268, 355, 366, 368
- Filenames: mag0filt.bin through mag7filt.bin, magResfilt.bin
- Version: 7.3.1
- IIR filter: disabled (enable: 0)
- Maximum delta: 3.4028235E38 (effectively unlimited)

### 8.4 Calibration Files

#### 8.4.1 Accelerometer Calibration (ver_ppdif_calacc0.xml through ver_ppdif_calacc3.xml)
- IDs: 109, 110, 259, 361
- Filenames: calacc0.bin through calacc3.bin
- Version: 7.3.1
- Temperature hysteresis: 0.5 or 1.0
- Temperature reference points: 320.0 or 0.0
- Identity calibration matrices

#### 8.4.2 Gyroscope Calibration (ver_ppdif_calgyr0.xml through ver_ppdif_calgyr3.xml)
- IDs: 111, 112, 260, 362
- Filenames: calgyr0.bin through calgyr3.bin
- Version: 7.3.1
- Temperature hysteresis: 0.5 or 1.0
- Temperature reference points: 320.0 or 0.0
- Identity calibration matrices

#### 8.4.3 Magnetometer Calibration (ver_ipdif_calmag0.xml through ver_ppdif_calmag_res.xml)
- Various IDs
- Filenames: calmag0.bin through calmag7.bin, calmag_res.bin
- Version: 7.3.1
- Temperature hysteresis: 0.5 or 1.0
- Temperature reference points: 320.0, 1.0, or 0.0
- Identity calibration matrices

### 8.5 External Sensor Configuration Files

#### 8.5.1 External Accelerometers (ver_spdif_extacc0.xml, ver_spdif_extacc1.xml)
- IDs: 156, 157
- Filenames: extacc0.bin, extacc1.bin
- Version: 7.3.1
- Desired frequency: 0.0 (adaptive)
- Filter: disabled
- Maximum non-valid samples: 10

#### 8.5.2 External Gyroscopes (ver_spdif_extgyr0.xml, ver_spdif_extgyr1.xml)
- IDs: 158, 159
- Filenames: extgyr0.bin, extgyr1.bin
- Version: 7.3.1
- Identical configuration to external accelerometers

#### 8.5.3 External Magnetometers (ver_spdif_extmag0.xml, ver_spdif_extmag1.xml)
- IDs: 160, 161
- Filenames: extmag0.bin, extmag1.bin
- Version: 7.3.1
- Identical configuration to external accelerometers

#### 8.5.4 External Navigation Sensor (ver_spdif_extnavsen.xml)
- ID: 168
- Filename: extnavsen.bin
- Version: 7.3.1
- Desired frequency: 100.0 Hz
- Status validation: disabled

### 8.6 Attitude and Navigation Files

#### 8.6.1 Attitude Estimation (ver_spdif_att.xml)
- ID: 45
- Filename: att.bin
- Version: 7.3.1
- Beta parameters: beta=0.025, beta0=10.0
- Zeta parameters: zeta=0.003, zeta0=0.0
- Filter steps: 50
- Additional parameters: kfg=2.0, norm-filt=0.1

#### 8.6.2 Kalman Filter (ver_spdif_kf.xml)
- ID: 46
- Filename: kf.bin
- Version: 7.3.1
- GPS OK time: 5.0
- Process noise covariance matrices: zero vectors
- Measurement noise covariance: 1.0

## 9. Cross-Component Relationships

### 9.1 Sensor Hierarchy

```
Sensor System
├── IMU Subsystem
│   ├── IMU0 (ID: 102)
│   │   ├── Accelerometer (4g, 160Hz)
│   │   └── Gyroscope (12°/s, 128Hz)
│   ├── IMU1 (ID: 103)
│   │   ├── Accelerometer (4g, 160Hz)
│   │   └── Gyroscope (12°/s, 128Hz)
│   ├── IMU2 (ID: 256)
│   │   ├── Accelerometer (2g, BW 160Hz)
│   │   └── Gyroscope (custom settings)
│   └── IMU3 (ID: 360)
│       ├── Accelerometer
│       └── Gyroscope
├── Sensor Suites
│   ├── Accelerometer Suite (accsuite.bin)
│   └── Gyroscope Suite (gyrsuite.bin)
├── Magnetometer Subsystem
│   ├── MAG0-MAG7
│   └── MAG_RES (Resolution Magnetometer)
├── Pressure Sensors
│   ├── Static Pressure (STP0-STP2)
│   └── Dynamic Pressure (QINF)
└── External Sensors
    ├── External Accelerometers (EXTACC0-1)
    ├── External Gyroscopes (EXTGYR0-1)
    ├── External Magnetometers (EXTMAG0-1)
    └── External Navigation Sensor
```

### 9.2 Data Flow

```
Raw Sensor Data
    ↓
Calibration (Temperature Compensation)
    ↓
Filtering (Notch, Butterworth, IIR)
    ↓
Linear Projection (LPS Matrices)
    ↓
Sensor Suite Fusion
    ↓
Attitude Estimation
    ↓
Kalman Filter
    ↓
Navigation Solution
```

### 9.3 Calibration Relationships

```
Sensor Calibration
├── Temperature Reference Points
├── Temperature Hysteresis
├── Bias Vectors
└── Scale/Alignment Matrices
```

## 10. Conclusion

The drone control platform implements a sophisticated sensor system with multiple layers of redundancy and sensor fusion capabilities. The system includes four IMUs, multiple accelerometers, gyroscopes, and magnetometers, each with specific configurations and calibration parameters. The sensor data is processed through a series of filters and fusion algorithms to provide a robust navigation solution.

Key features of the sensor system include:
- Multiple redundant sensors for fault tolerance
- Comprehensive calibration with temperature compensation
- Configurable filtering options for each sensor
- Sensor fusion with variance-based quality assessment
- Error detection through non-valid sample counting and maximum delta thresholds

The system is designed to provide reliable sensor data even in the presence of sensor failures or environmental disturbances, making it suitable for critical drone control applications.