# Generated from:

- items/pdi_Recovery0/setup/ver_spdif_maction.xml (376 tokens)
- items/pdi_Recovery0/setup/ver_spdif_mevact.xml (261 tokens)
- items/pdi_Recovery0/setup/ver_spdif_mevent.xml (1074 tokens)
- items/pdi_Recovery0/setup/ver_spdif_mfmgr.xml (57 tokens)
- items/pdi_Recovery0/setup/ver_spdif_mmission.xml (53 tokens)
- items/pdi_Recovery0/setup/ver_spdif_mmodes.xml (51 tokens)
- items/pdi_Recovery0/setup/ver_spdif_mnotif.xml (58 tokens)
- items/pdi_Recovery0/setup/ver_spdif_mstep.xml (57 tokens)
- items/pdi_Recovery0/setup/ver_spdif_mstick.xml (51 tokens)
- items/pdi_Recovery0/setup/ver_spdif_mname.xml (57 tokens)
- items/pdi_Recovery0/setup/ver_spdif_mcheck.xml (156 tokens)
- items/pdi_Recovery0/setup/ver_spdif_mdev.xml (86 tokens)
- items/pdi_Recovery0/setup/ver_spdif_mchannel.xml (61 tokens)
- items/pdi_Recovery0/setup/ver_spdif_mxplane.xml (76 tokens)
- items/pdi_Recovery0/setup/ver_spdif_mvxmap.xml (62 tokens)
- items/pdi_Recovery0/setup/ver_spdif_m4xow.xml (62 tokens)
- items/pdi_Recovery0/setup/ver_spdif_mexvar.xml (58 tokens)
- items/pdi_Recovery0/setup/ver_spdif_mvars.xml (270 tokens)
- items/pdi_Recovery0/setup/ver_spdif_events.xml (317 tokens)
- items/pdi_Recovery0/setup/ver_spdif_actions.xml (435 tokens)
- items/pdi_Recovery0/setup/ver_spdif_evact.xml (818 tokens)
- items/pdi_Recovery0/operation/ver_opdif_fmgr.xml (63 tokens)
- items/pdi_Recovery0/operation/ver_opdif_polymgr.xml (189 tokens)
- items/pdi_Recovery0/operation/ver_opdif_flyto-setup-map.xml (58 tokens)
- items/pdi_Recovery0/operation/ver_opdif_evt-wp-groups.xml (56 tokens)
- items/pdi_Recovery0/operation/ver_opdif_troute.xml (66 tokens)
- items/pdi_Recovery0/setup/ver_spdif_amz_route.xml (60 tokens)

---

# Recovery System Event Management and Mission Configuration Analysis

This document provides a comprehensive analysis of the Recovery System's event-driven architecture, focusing on event types, action definitions, event-action mappings, and related mission management components.

## 1. System Architecture Overview

The Recovery System implements an event-driven architecture for system control, where events trigger specific actions based on predefined mappings. The system is designed to handle commands, contingencies, and system state changes through a structured event-action framework.

### 1.1 Core Components

The system consists of several interconnected components:
- **Events**: System stimuli that trigger responses
- **Actions**: Responses executed when events occur
- **Event-Action Mappings**: Connections between events and their corresponding actions
- **Mission Management**: Configuration for system operation

## 2. Event Types and Definitions

The system defines four distinct event types in `ver_spdif_mevent.xml`:

| Event ID | Event Name | Data Type | Description |
|----------|------------|-----------|-------------|
| 0 | ISC DComms cmd received | Type 1 (var id: 4101) | Triggered when an Inter-System Communication command is received through DComms |
| 1 | Contingency command | Type 1 (var id: 4101) | Triggered when a contingency command is received |
| 2 | OK to deliver command | Type 1 (var id: 4101) | Triggered when system is ready to deliver a command |
| 3 | Contingency response | Type 1 (var id: 4101) | Triggered when a response to a contingency is needed |

Each event has the following properties:
- **Name**: Descriptive identifier
- **dataTypeColor**: Data type configuration with typeColor=1 and variable reference (id=4101)
- **check**: Configuration with icon=10, timeControl=0.0, check=0, checkTime=0

### 2.2 Event Implementation

The `ver_spdif_events.xml` file defines three event implementations:

| Key | Type | Duration | Indexes |
|-----|------|----------|---------|
| 0 | 15 | 0.0 | 514 |
| 1 | 15 | 0.0 | 513 |
| 3 | 16 | 0.0 | 149 |

These events are mapped to specific system functions through their type and index values:
- Type 15 events (keys 0 and 1) likely represent command-related events
- Type 16 event (key 3) likely represents a response event

## 3. Action Definitions

The system defines five action types in `ver_spdif_maction.xml`:

| Action ID | Action Name |
|-----------|-------------|
| 0 | Send response |
| 1 | Send contingency cyphal message |
| 2 | Send ISC Cyphal msg |
| 3 | DComms response |
| 4 | Cyphal contingency |

### 3.1 Action Implementation

The `ver_spdif_actions.xml` file defines three action implementations:

| Action ID | Type | Configuration |
|-----------|------|---------------|
| 0 | acset-tx | idCfg=185, producer=0, custom-message=0 |
| 1 | msg-sender-cmd | idCfg=199, message_type=57485, address=24 |
| 2 | msg-sender-cmd | idCfg=199, message_type=57491, address=24 |

These actions implement specific communication behaviors:
- Action 0: Transmits a message using configuration 185
- Action 1: Sends a command message of type 57485 to address 24
- Action 2: Sends a command message of type 57491 to address 24

## 4. Event-Action Mappings

The system defines three event-action mappings in `ver_spdif_mevact.xml`:

| Mapping ID | Name | Group | Order |
|------------|------|-------|-------|
| 0 | DComms Conteingency | 0 | 0 |
| 1 | ISC Command | 0 | 2 |
| 2 | DComms Contingency response | 0 | 1 |

### 4.1 Event-Action Execution Configuration

The `ver_spdif_evact.xml` file defines three event-action execution configurations:

| Key | Enabled | Delay | Event Type | Event Param | Actions |
|-----|---------|-------|------------|-------------|---------|
| 0 | 1 | 0.0 | 2 | 1 | [1] |
| 1 | 1 | 0.0 | 2 | 0 | [2] |
| 2 | 1 | 0.0 | 2 | 3 | [0] |

These configurations establish the following event-action relationships:
- When event type 2, param 1 occurs → Execute action 1 (Send contingency cyphal message)
- When event type 2, param 0 occurs → Execute action 2 (Send ISC Cyphal msg)
- When event type 2, param 3 occurs → Execute action 0 (Send response)

Each mapping has:
- **enabled**: Set to 1 (enabled)
- **delay**: Set to 0.0 (immediate execution)
- **delay_max**: Set to 0
- **xclk**: Clock configuration with mode=0 and type=0
- **node**: Event mapping configuration
- **actions**: List of action IDs to execute

## 5. Command Processing Flow

Based on the configuration files, the command processing flow in the Recovery System follows this pattern:

1. **Command Reception**:
   - System receives an ISC DComms command (event 0)
   - System receives a contingency command (event 1)

2. **Command Validation**:
   - System checks if it's OK to deliver command (event 2)

3. **Command Execution**:
   - Based on the event-action mappings, the system:
     - Sends ISC Cyphal messages (action 2)
     - Sends contingency Cyphal messages (action 1)

4. **Response Handling**:
   - System generates contingency responses (event 3)
   - System sends appropriate responses (action 0)

## 6. Communication Protocols

The Recovery System uses multiple communication protocols:

### 6.1 Cyphal Protocol

Used for inter-system communication with specific message types:
- Message type 57485 (address 24): Likely used for contingency messages
- Message type 57491 (address 24): Likely used for ISC commands

### 6.2 DComms Protocol

Used for command reception and response handling:
- Receives ISC commands
- Handles contingency commands
- Sends responses

## 7. Mission Management Components

The system includes several mission management components that support the event-action framework:

### 7.1 Mission Configuration (`ver_spdif_mmission.xml`)
- Contains basic mission configuration (empty in this instance)

### 7.2 Mission Modes (`ver_spdif_mmodes.xml`)
- Defines operational modes for the system (empty in this instance)

### 7.3 Mission Checks (`ver_spdif_mcheck.xml`)
- Contains one check configuration with icon=46, timeControl=0.0, check=0, checkTime=0

### 7.4 Device Configuration (`ver_spdif_mdev.xml`)
- Contains camera and drop system configurations (empty arrays)

### 7.5 File Manager (`ver_opdif_fmgr.xml`)
- Contains generic and specified operation configurations (empty)

### 7.6 Polygon Manager (`ver_opdif_polymgr.xml`)
- Contains geofencing configuration with contingency, emergency, and prohibited zones (all set to 0)

## 8. Event-Driven Architecture Analysis

The Recovery System implements a classic event-driven architecture with these key characteristics:

### 8.1 Decoupled Components
- Events and actions are defined separately
- Mappings connect events to actions
- This allows for flexible reconfiguration without changing core logic

### 8.2 Command-Response Pattern
- Commands trigger events
- Events trigger actions
- Actions generate responses
- This creates a complete command processing cycle

### 8.3 Contingency Handling
- Dedicated events for contingency commands
- Dedicated actions for contingency responses
- Specific mappings for contingency handling

### 8.4 Communication Integration
- Actions are primarily communication-focused
- Multiple protocols supported (Cyphal, DComms)
- Message types and addresses are explicitly defined

## 9. System Response to Stimuli

The Recovery System responds to various stimuli as follows:

### 9.1 Command Stimuli
- **ISC DComms Commands**: Received through DComms, processed, and responded to with ISC Cyphal messages
- **Contingency Commands**: Received, processed, and responded to with contingency Cyphal messages

### 9.2 System State Changes
- **OK to Deliver Command**: When system state allows command delivery, appropriate actions are triggered

### 9.3 Response Generation
- **Contingency Response**: Generated when contingencies require responses, sent through appropriate channels

## 10. Version Information

All configuration files share the same version information:
- Major: 7
- Minor: 3
- Revision: 1

This indicates a consistent configuration baseline across all components.

## Referenced Context Files

The following context files provided useful information for understanding the system:

- `ver_spdif_events.xml`: Provided event implementation details
- `ver_spdif_actions.xml`: Provided action implementation details
- `ver_spdif_evact.xml`: Provided event-action execution configuration
- `ver_opdif_fmgr.xml`: Provided insight into file management operations
- `ver_opdif_polymgr.xml`: Provided geofencing configuration details