# Generated from:

- State_machines_pa_test.cpp (10087 tokens)

---

# State Machine Implementation for Flight Mode Management

This document provides a detailed summary of the state machine implementation for flight mode management, focusing on different states, transition conditions, and interactions with other components.

## 1. State Machine Overview

The state machine manages different flight modes and transitions between them, including:
- Takeoff
- Land
- Track Spline
- In-Flight Test
- Ground Idle
- Ground Motor Rampdown
- Init
- Uninitialized

The implementation includes sub-state machines for specific flight phases like takeoff and landing, with their own internal states and transition logic.

## 2. Takeoff State Machine

### States
- `UNINITIALIZED`: Initial state before takeoff process begins
- `ON_GROUND`: Vehicle is on the ground, ready for takeoff
- `ATTITUDE_IN_AIR`: Vehicle has left the ground and is in initial climb
- `POSITION_HOLD_CLIMBING`: Vehicle is climbing to target altitude with position hold
- `TAKEOFF_COMPLETE`: Takeoff process is complete

### Transition Conditions
- `ON_GROUND` → `ATTITUDE_IN_AIR`: When vehicle is no longer on ground
- `ATTITUDE_IN_AIR` → `POSITION_HOLD_CLIMBING`: When vehicle is above position hold altitude
- `POSITION_HOLD_CLIMBING` → `TAKEOFF_COMPLETE`: When vehicle reaches target altitude and speed is below threshold

### Initialization
```cpp
void InitializeTakeoffStateMachine(State_machines_state::Takeoff_mode::Mode& takeoff_mode) {
    takeoff_mode = State_machines_state::Takeoff_mode::Mode::ON_GROUND;
}
```

### Reset
```cpp
void ResetTakeoffStateMachine(State_machines_state::Takeoff_mode::Mode& takeoff_mode) {
    takeoff_mode = State_machines_state::Takeoff_mode::Mode::UNINITIALIZED;
}
```

### Key Parameters
- `takeoff.position_hold_agl_m`: Altitude threshold for transitioning to position hold (default: 10.0f)
- `takeoff.complete_altitude_threshold_m`: Threshold for determining takeoff completion (default: 0.1f)
- `takeoff.complete_total_inertial_speed_threshold_m_per_s`: Speed threshold for takeoff completion (default: 0.5f)

## 3. Land State Machine

### States
- `UNINITIALIZED`: Initial state before landing process begins
- `SLOW_DOWN_TO_HOVER`: Vehicle slows down horizontal movement before descent
- `FAST_DESCENT`: Rapid descent from higher altitudes
- `SLOW_DESCENT`: Careful descent at lower altitudes

### Transition Conditions
- `SLOW_DOWN_TO_HOVER` → `FAST_DESCENT`: When ground speed is low enough
- `FAST_DESCENT` → `SLOW_DESCENT`: When below slow descent altitude threshold
- `SLOW_DESCENT` → `UNINITIALIZED`: When vehicle touches the ground

### Initialization
```cpp
void InitializeLandStateMachine(State_machines_state::Mode::Controllers_mode last_controllers_mode,
                              Pa_blocks::Phase_of_flight tracked_phase_of_flight,
                              State_machines_state::Land& land_state) {
    // Different initialization based on previous mode
    if (last_controllers_mode == State_machines_state::Mode::Controllers_mode::TAKEOFF) {
        land_state.land_mode = State_machines_state::Land::Type::SLOW_DESCENT;
    } else {
        land_state.land_mode = State_machines_state::Land::Type::SLOW_DOWN_TO_HOVER;
    }
}
```

### Reset
```cpp
void ResetLandStateMachine(State_machines_state::Land& land_state) {
    land_state.land_mode = State_machines_state::Land::Type::UNINITIALIZED;
}
```

### Key Parameters
- `land.slow_descent_agl_m`: Altitude threshold for transitioning to slow descent (default: 15.0f)
- `land.max_time_in_slow_down_vtol_s`: Maximum time allowed in slow down phase (default: 5.0f)
- `land.slow_down_max_ground_speed_m_per_s`: Speed threshold for transitioning from slow down (default: 1.0f)

## 4. Main State Machine Transitions

### Mode Transitions
- `GROUND_IDLE` → `TAKEOFF`: When takeoff command received and PBIT passed
- `TAKEOFF` → `TRACK_SPLINE`: When takeoff complete or when track spline command received during position hold
- `TRACK_SPLINE` → `LAND`: When land command received
- `LAND` → `TRACK_SPLINE`: When track spline command received and either AGL is invalid or above 3m
- `LAND` → `GROUND_MOTOR_RAMPDOWN`: When vehicle touches ground during landing
- Any mode → `GROUND_IDLE`: When vehicle is detected on ground

### Evaluation Functions
The state machine uses numerous evaluation functions to determine transitions:

```cpp
bool EvalModeTakeoff() {
    return command_received_types.primary_command == Command_received_types::TAKEOFF;
}

bool EvalModeLand() {
    return command_received_types.primary_command == Command_received_types::LAND;
}

bool EvalModeTrackSpline() {
    return command_received_types.primary_command == Command_received_types::TRACK_SPLINE;
}

bool EvalModeInFlightTest() {
    return command_received_types.primary_command == Command_received_types::IN_FLIGHT_TEST;
}

bool EvalModePBITDonePassed() {
    return controllers_state->power_on_built_in_test.power_on_built_in_test_passed;
}

bool EvalModeTakeoffComplete() {
    return controllers_state->state_machine.takeoff_mode == State_machines_state::Takeoff_mode::Mode::TAKEOFF_COMPLETE;
}

bool EvalModeOnGround() {
    return state_estimate.is_onground;
}
```

## 5. Degradation Level Management

The state machine tracks vehicle health and adjusts behavior based on degradation levels:

### Degradation Levels
- Normal operation: All rotors operational
- Level 1: One rotor inoperative
- Level 2+: More than one rotor inoperative

### Evaluation Functions
```cpp
bool EvalDegradationLevelOneRotorInoperative() {
    return controllers_state->health_status.rotors_health_status.number_of_rotors_inoperative == 1;
}

bool EvalDegradationLevelMoreThanOneRotorInoperative() {
    return controllers_state->health_status.rotors_health_status.number_of_rotors_inoperative > 1;
}
```

## 6. Gain Type Management

The state machine manages controller gain types based on flight mode and conditions:

### Gain Types
- `PRECISE`: Used for low-speed maneuvers, landing, and precise control
- `ROBUST`: Used for high-speed maneuvers and more aggressive control

### Transition Logic
- Transitions to `ROBUST` when in high-speed segments
- Transitions to `PRECISE` when in low-speed segments, landing, or takeoff
- For track spline mode in robust mode, transitions to precise mode when dynamic pressure drops below threshold

```cpp
bool EvalGainTypeLowSpeedManeuver() {
    // Always low speed maneuver in takeoff or land
    if (controllers_state->state_machine.mode.controllers_mode == State_machines_state::Mode::Controllers_mode::TAKEOFF ||
        controllers_state->state_machine.mode.controllers_mode == State_machines_state::Mode::Controllers_mode::LAND) {
        return true;
    }
    
    // In track spline mode, depends on segment type and dynamic pressure
    if (controllers_state->state_machine.mode.controllers_mode == State_machines_state::Mode::Controllers_mode::TRACK_SPLINE) {
        if (controllers_state->trajectory_position_finder.segment_type == 
            Trajectory_position_finder::State::Spline_segment_type::LOW_SPEED) {
            
            // In precise mode, always consider low speed
            if (controllers_state->state_machine.gain_type == State_machines_state::Gain_type::PRECISE) {
                return true;
            }
            
            // In robust mode, check dynamic pressure
            if (state_estimate.dynamic_pressure_Pa < 
                state_machines_parameters.gain_type.max_dynamic_pressure_for_low_speed_maneuver_Pa) {
                return true;
            }
        }
    }
    
    return false;
}
```

## 7. Integrator Management

The state machine controls when integrators are active or reset:

### Integrator Control Logic
- Integrators are reset when on ground
- Integrators are forced on in certain flight modes (TRACK_SPLINE, IN_FLIGHT_TEST)
- Integrators are managed differently based on flight phase

```cpp
bool EvalIntegratorsOnGround() {
    return state_estimate.is_onground;
}

bool EvalIntegratorsModeForceOn() {
    return controllers_state->state_machine.mode.controllers_mode == State_machines_state::Mode::Controllers_mode::TRACK_SPLINE ||
           controllers_state->state_machine.mode.controllers_mode == State_machines_state::Mode::Controllers_mode::IN_FLIGHT_TEST;
}
```

## 8. Testing Approach

The test file demonstrates a comprehensive testing strategy for the state machine:

### Test Categories
1. **Initialization and Reset Tests**: Verify proper initialization and reset of state machines
   - Test_1: ResetTakeoffStateMachine
   - Test_2: ResetState_machines_state
   - Test_4: InitializeTakeoffStateMachine

2. **Evaluation Function Tests**: Verify correct behavior of condition evaluation functions
   - Test_5: EvalIntegratorsOnGround
   - Test_6: EvalIntegratorsModeForceOn
   - Test_8: EvalModeCommands
   - Test_9: EvalModePBITDonePassed

3. **State Transition Tests**: Verify correct state transitions under various conditions
   - Test_15: TakeoffSubStateMachine
   - Test_16: LandSubStateMachine
   - Test_34-36: EvalModeLandToTrackSpline transitions

4. **Degradation Level Tests**: Verify correct detection of vehicle health states
   - Test_17: EvalDegradationLevelOneRotorInoperative
   - Test_18: EvalDegradationLevelMoreThanOneRotorInoperative

5. **Gain Type Tests**: Verify correct gain type selection based on flight conditions
   - Test_19-21: Basic gain type evaluation
   - Test_22-30: Complex gain type transitions based on speed and maneuver type

### Test Implementation Pattern
Each test follows a similar pattern:
1. Create a state machine test instance
2. Set up the initial conditions
3. Execute the function or state transition being tested
4. Verify the expected outcome

Example:
```cpp
bool State_machines_pa_test::Test_15() {      //TakeoffSubStateMachine
    bool ret = true;

    State_machines_pa_test state_machines;
    State_machines::State& state_machines_state = state_machines.controllers_state->state_machine;

    // Set initial conditions
    state_machines_state.mode.controllers_mode = State_machines_state::Mode::Controllers_mode::GROUND_IDLE;
    state_machines.timestamp_ns.add_tics(10);
    state_machines.state_machines_parameters.takeoff.position_hold_agl_m = 10.0f;
    state_machines.controllers_state->commands_processor.takeoff_command.initial_tracking_point.h = 20.0;
    state_machines.processed_inputs.altitude_agl_lowest_point_m = 0;
    state_machines.state_estimate.is_onground = true;
    state_machines.command_received_types.primary_command = Command_received_types::TAKEOFF;

    // Execute state machine
    state_machines.run_all_state_machines();
    
    // Verify expected outcome
    ret &= (State_machines_state::Takeoff_mode::Mode::ON_GROUND == state_machines_state.takeoff_mode);
    
    // Continue with more test steps...
    
    return ret;
}
```

## 9. Error Handling

The state machine implements several error handling and contingency mechanisms:

### Contingency Behaviors
1. **Ground Detection**: Automatically transitions to ground modes when on-ground state is detected
2. **Degradation Handling**: Adjusts control strategy based on vehicle health status
3. **Altitude Thresholds**: Prevents unsafe mode transitions at low altitudes (e.g., land to track spline)
4. **Timeout Handling**: Manages timeouts in phases like slow down to hover

### Safety Checks
- Prevents takeoff if PBIT (Power-on Built-in Test) has not passed
- Ensures proper sequencing of takeoff and landing phases
- Monitors vehicle state during critical transitions

## 10. Cross-Component Relationships

The state machine interacts with several other system components:

### Inputs from Other Components
- **State Estimate**: Provides vehicle position, velocity, attitude, and ground detection
- **Command Processor**: Provides flight commands and parameters
- **Health Status**: Provides vehicle health information
- **Trajectory Position Finder**: Provides information about the current trajectory segment

### Outputs to Other Components
- **Controllers Mode**: Determines which flight controllers are active
- **Gain Type**: Determines controller gain settings
- **Integrator Control**: Manages integrator behavior in controllers

## 11. Key Data Structures

### State_machines_state
Contains the current state of all state machines:
- `mode.controllers_mode`: Main flight mode
- `takeoff_mode`: Takeoff sub-state
- `land.land_mode`: Landing sub-state
- `gain_type`: Current controller gain type

### Command_received_types
Tracks received commands:
- `primary_command`: Current primary command (TAKEOFF, LAND, TRACK_SPLINE, etc.)

### State_estimate
Contains vehicle state information:
- `is_onground`: Ground detection flag
- `altitude_hae_wgs84_m`: Altitude above ellipsoid
- `v_ned_ned2vf_m_per_s`: Velocity vector
- `dynamic_pressure_Pa`: Dynamic pressure for airspeed estimation
- `status_agl`: Validity of above-ground-level measurements

## Referenced Context Files

None provided in the input.