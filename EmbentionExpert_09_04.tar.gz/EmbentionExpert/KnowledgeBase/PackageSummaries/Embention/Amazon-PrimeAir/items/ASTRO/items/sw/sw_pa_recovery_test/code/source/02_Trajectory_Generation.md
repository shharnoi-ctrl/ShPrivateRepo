# Generated from:

- Amazon-PrimeAir/items/ASTRO/items/sw/sw_pa_recovery_test/code/source/03_Trajectory_Command_Generation.md (4772 tokens)
- Amazon-PrimeAir/items/ASTRO/items/sw/sw_pa_recovery_test/code/source/03_Attitude_Control.md (2716 tokens)

---

# Comprehensive Trajectory Generation and Attitude Control System

This knowledge graph synthesizes the trajectory generation and attitude control systems, explaining how they work together to generate and track trajectories across different flight phases.

## 1. System Architecture Overview

The trajectory generation and attitude control system consists of four primary components working in a hierarchical structure:

1. **Trajectory Command Generator (TCG)** - Top-level component that coordinates trajectory generation
2. **Time-based Trajectory Command Generator (TTCG)** - Generates time-based trajectory commands
3. **Translational Stability Controller (TSC)** - Generates acceleration commands based on position/velocity errors
4. **Attitude Trajectory Command Generator (ATCG)** - Generates attitude commands based on trajectory information
5. **Attitude Acceleration Command Generator (AACG)** - Transforms acceleration commands to attitude commands

These components form a cascaded control architecture:
- TCG coordinates the overall trajectory generation process
- TTCG generates position, velocity, and acceleration references
- TSC generates corrective acceleration commands based on tracking errors
- ATCG generates attitude references based on trajectory information
- AACG transforms acceleration commands to attitude commands for the flight control system

## 2. Trajectory Generation Components

### 2.1 Trajectory Command Generator (TCG)

The TCG serves as the primary interface between route planning and flight control systems, coordinating the generation of trajectory commands.

```
TCG Input → TTCG → TSC → TCG Output → ATCG → AACG → Flight Control System
```

#### 2.1.1 Key Responsibilities
- Coordinates trajectory generation across flight phases
- Manages transitions between flight phases
- Determines appropriate tracking modes
- Generates position, velocity, and acceleration commands

#### 2.1.2 Interface with Other Components
```cpp
struct Output {
    Base::Rv3 p_err_pos_ncg2pos_m;        // Position error
    Base::Rv3 v_ff_cmd_pos_ned2pos_m_per_s; // Velocity command
    Base::Rv3 a_ff_cmd_pos_ned2pos_m_per_s2; // Acceleration command
    Base::Rv4 q_vel_from_ned;             // Attitude command (passed to ATCG)
    Tsc::Tsc_tracking_mode::Type tsc_tracking_mode_cmd; // Tracking mode
    Phase_of_flight tracked_phase_of_flight; // Current flight phase
};
```

### 2.2 Time-based Trajectory Command Generator (TTCG)

The TTCG generates time-based trajectory commands by tracking routes and managing transitions between different flight phases.

#### 2.2.1 Route Tracking
- Maintains current route index, maneuver index, and time
- Evaluates route at current time to generate trajectory commands
- Performs closest point search to determine tracking point

#### 2.2.2 Trajectory Polynomials
The TTCG uses polynomial trajectories to generate smooth transitions:
```cpp
class Polynomial {
public:
    void construct_trajectory_polynomial(const Base::Rv4& si, const Base::Rv4& sf, Real ts);
    Real eval_der(Real t, Der_coeffs der) const; // Evaluates position, velocity, acceleration
};
```

### 2.3 Translational Stability Controller (TSC)

The TSC generates acceleration commands based on position and velocity errors to maintain stability during trajectory tracking.

#### 2.3.1 Tracking Modes
```cpp
namespace Tsc_tracking_mode {
    enum Type {
        UNDEFINED = 0,
        GROUNDSPEED = 1, // Used during VTOL, transitions, and speed changes
        AIRSPEED = 2     // Used during normal WBF operation
    };
}
```

#### 2.3.2 Control Structure
The TSC implements a cascaded control structure:
1. Position error → Velocity command
2. Velocity error → Acceleration command
3. Acceleration filtering → Final acceleration command

## 3. Attitude Control Components

### 3.1 Attitude Trajectory Command Generator (ATCG)

The ATCG generates attitude commands based on trajectory information and handles transitions between flight modes.

#### 3.1.1 Key Outputs
- `q_vel_from_ned`: Attitude command for velocity frame relative to NED frame
- `q_pos_from_ned`: Attitude command for position frame relative to NED frame
- `q_grtraj_from_ned`: Attitude command for gravity-compensated trajectory frame

#### 3.1.2 Flight Mode Handling
- **VTOL Mode**: Used for low-speed flight
- **WBF Mode**: Used for high-speed flight
- **Intermediate Mode**: Blends between VTOL and WBF modes based on airspeed

#### 3.1.3 Weathervaning Logic
Aligns the vehicle with the relative wind direction:
```cpp
run_vtol_hysteresis_logic(v_ne_wind2pos_m_per_s, heading_cmd_no_weathervaning_rad, land_mode)
```

### 3.2 Attitude Acceleration Command Generator (AACG)

The AACG transforms acceleration commands from the velocity frame to the trim frame and generates appropriate attitude commands.

#### 3.2.1 Key Outputs
- High-frequency acceleration commands in the TRIM0NCG frame
- Low-frequency acceleration commands in the TRIMNCG frame
- Feedforward angular velocity commands
- Attitude commands for the TRIM0NCG frame

#### 3.2.2 Control Modes
- `POSITION_WITH_FIXED_ATTITUDE`: Uses a fixed attitude command
- `POSITION`: Uses trajectory-derived attitude commands
- Special handling for `TAKEOFF` and `LAND` modes

## 4. Flight Phase Management

The system manages four distinct flight phases with specific trajectory generation approaches for each:

### 4.1 VTOL (Vertical Take-Off and Landing)

During VTOL phase:
- TCG uses GROUNDSPEED tracking mode
- TTCG generates vertical or hover trajectories
- ATCG uses VTOL-specific attitude generation with weathervaning
- Position control prioritizes vertical stability

### 4.2 Outbound Transition (VTOL to WBF)

During outbound transition:
- Vehicle accelerates from hover to wing-borne flight
- TTCG generates acceleration profile with three phases:
  1. Initial acceleration phase
  2. Constant acceleration phase
  3. Final acceleration phase
- ATCG blends between VTOL and WBF attitudes based on airspeed
- TSC uses GROUNDSPEED tracking mode

```cpp
bool Ttcg::evaluate_outbound_transition_logic(const Input& input, Waypoint_msg& wp_ned_ned2pos) {
    // Update outbound maneuver time
    // Generate acceleration profile for transition
    // Update waypoint based on transition progress
}
```

### 4.3 Wing-Borne Flight (WBF)

During WBF phase:
- TCG typically uses AIRSPEED tracking mode
- TTCG follows route waypoints with spline interpolation
- ATCG uses WBF-specific attitude generation aligned with air-relative velocity
- TSC optimizes for efficient forward flight

### 4.4 Inbound Transition (WBF to VTOL)

During inbound transition:
- Vehicle decelerates from wing-borne flight to hover
- TTCG manages two distinct phases:
  1. **High-speed phase**: Deceleration from cruise speed to critical speed
  2. **Low-speed phase**: Deceleration from critical speed to hover
- ATCG gradually transitions from WBF to VTOL attitude control
- TSC uses GROUNDSPEED tracking mode

```cpp
bool Ttcg::evaluate_inbound_transition_highspeed_logic(Waypoint_msg& wp_ned_ned2pos) {
    // Generate high-speed deceleration profile
    // Update waypoint based on transition progress
}

bool Ttcg::evaluate_inbound_transition_lowspeed_logic(Waypoint_msg& wp_ned_ned2pos) {
    // Generate low-speed deceleration profile
    // Update waypoint based on transition progress
}
```

## 5. Reference Frame Transformations

The system uses multiple reference frames with transformations between them:

### 5.1 Key Reference Frames
- **NED (North-East-Down)**: Global reference frame
- **VTOLNCG**: VTOL navigation control frame
- **TRIM0NCG**: Trim navigation control frame (zero trim)
- **VEL**: Velocity-aligned frame
- **POS**: Position-aligned frame
- **GRTRAJ**: Gravity-compensated trajectory frame

### 5.2 Frame Transformation Flow
1. TCG generates commands in NED frame
2. ATCG transforms to velocity, position, and gravity-compensated frames
3. AACG transforms to trim frames for flight control

```
NED → VEL → POS → GRTRAJ → TRIM0NCG → Flight Control
```

## 6. Trajectory Types and Generation Methods

The system supports multiple trajectory types:

### 6.1 Polynomial Trajectories
Used for smooth transitions between waypoints:
```cpp
void Polynomial::construct_trajectory_polynomial(const Base::Rv4& si, const Base::Rv4& sf, Real ts) {
    // si: Initial state [position, velocity, acceleration, jerk]
    // sf: Final state
    // ts: Time span
    // Constructs polynomial coefficients for smooth interpolation
}
```

### 6.2 Spline Trajectories
Used for route tracking with continuous derivatives:
```cpp
void Maneuver_coordinate::evaluate_at_time(Real t, Waypoint_coordinate& wc) const {
    // Evaluates spline at time t
    // Updates waypoint coordinate with position, velocity, acceleration
}
```

### 6.3 Transition Trajectories
Specialized trajectories for phase transitions:
- **Outbound**: Acceleration profile from hover to cruise speed
- **Inbound**: Deceleration profile from cruise speed to hover

## 7. Interfaces Between Components

### 7.1 TCG to TTCG Interface
```cpp
struct Ttcg::Input {
    Current_route_information current_route_information;
    Route_msg route;
    Base::Tllh lla_est_ncg;
    Real groundspeed_est_m_per_s;
    State_machines_state::Mode::Controllers_mode controllers_mode;
};

struct Ttcg::Output {
    Waypoint_msg wp_ned_ned2pos;
    Phase_of_flight tracked_phase_of_flight;
    Real displacement_planned_m;
    Real speed_planned_m_per_s;
};
```

### 7.2 TCG to TSC Interface
```cpp
struct Tsc::Input {
    Base::Rv3 p_err_pos_ncg2pos_m;
    Base::Rv3 v_err_pos_ned2pos_m_per_s;
    Base::Rv3 a_ff_cmd_pos_ned2pos_m_per_s2;
    Tsc_tracking_mode::Type tsc_tracking_mode;
};

struct Tsc::Output {
    Base::Rv3 a_fb_cmd_pos_ned2pos_m_per_s2;
    Base::Rv3 a_cmd_pos_ned2pos_m_per_s2;
};
```

### 7.3 TCG to ATCG Interface
```cpp
struct Atcg::Input {
    Base::Rv3 v_est_pos_ned2ncg_m_per_s;
    Base::Rv3 v_filt_ned_ned2wind_m_per_s;
    Base::Rv3 a_cmd_pos_ned2pos_m_per_s2;
    Phase_of_flight phase_of_flight;
    Heading_cmd heading_vel_from_ned;
};

struct Atcg::Output {
    Base::Rv4 q_vel_from_ned;
    Base::Rv4 q_pos_from_ned;
    Base::Rv4 q_grtraj_from_ned;
};
```

### 7.4 ATCG to AACG Interface
```cpp
struct Aacg::Input {
    Base::Rv3 a_lf_cmd_vel_m_per_s2;
    Base::Rv3 a_hf_cmd_vel_m_per_s2;
    Base::Rv4 q_vel_from_ned;
    Base::Rv4 q_est_trim0_from_ned;
    Real dynamic_pressure_pa;
    Real density_kg_per_m3;
    State_machines_state::Mode::Controllers_mode controllers_mode;
};

struct Aacg::Output {
    Base::Rv3 a_lf_cmd_trim_m_per_s2;
    Base::Rv3 a_hf_cmd_trim0_m_per_s2;
    Base::Rv3 w_ff_cmd_trim0_rad_per_s;
    Base::Rv4 q_cmd_trim0_from_ned;
};
```

## 8. Key Algorithms

### 8.1 Closest Point Search
Used by TTCG to find the closest point on the trajectory to the current vehicle position:
```cpp
bool Ttcg::search_for_closest_point_on_trajectory(const Base::Tllh& lla_est_ncg,
                                                 Real& tracked_maneuver_time_s) {
    // Binary search to find closest point
    // Updates tracked_maneuver_time_s with result
}
```

### 8.2 Weathervaning Logic
Used by ATCG to align the vehicle with the relative wind direction:
```cpp
bool Atcg::run_vtol_hysteresis_logic(const Base::Rv3& v_ne_wind2pos_m_per_s,
                                    Real heading_cmd_no_weathervaning_rad,
                                    bool land_mode) {
    // Determines if VTOL hysteresis should be enabled
    // Updates low-speed velocity reference vector
    // Applies rate limiting to prevent abrupt attitude changes
}
```

### 8.3 Transition Displacement Calculation
Used by TTCG to calculate the displacement required for transitions:
```cpp
bool Ttcg::compute_inbound_transition_route_time_required(const Input& input,
                                                        Real& route_time_at_inbound_complete_s,
                                                        Maneuver_coordinate& mc_hs,
                                                        Maneuver_coordinate& mc_ls) {
    // Calculates displacement required for inbound transition
    // Generates maneuver coordinates for high-speed and low-speed phases
}
```

### 8.4 Quaternion-Based Attitude Blending
Used by ATCG to blend between different attitude references:
```cpp
Pa_irquat::quaternion_slerp(q_vtol_grtraj_from_ned, q_wbf_grtraj_from_ned, 
                           attitude_logic_interp_param, q_exp_grtraj_from_ned);
```

## 9. System Integration and Coordination

### 9.1 Flight Phase Coordination
The TCG determines the current flight phase and coordinates the appropriate trajectory generation strategy:
```cpp
bool Tcg::step(const Input& input, Output& output) {
    // Determine current flight phase
    // Select appropriate trajectory generation strategy
    // Coordinate between TTCG and TSC
    // Generate output commands
}
```

### 9.2 Tracking Mode Selection
The TCG determines the appropriate tracking mode based on flight phase and conditions:
```cpp
bool Tcg::update_tsc_tracking_mode(Phase_of_flight pof, 
                                  Real eas_sched_m_per_s,
                                  Real eas_cmd_m_per_s,
                                  Speed_change_phase::Type speed_change_phase) {
    // Determine appropriate tracking mode
    // Update state.tsc_tracking_mode
}
```

### 9.3 Attitude Control Integration
The ATCG and AACG work together to generate appropriate attitude commands:
```cpp
// ATCG generates reference attitudes
uut->vel_from_ned_attitude(in.input, attitude_logic_interp_param, out.output.q_vel_from_ned);
uut->pos_from_ned_attitude(in.input, out.output.q_vel_from_ned, attitude_logic_interp_param, out.output.q_pos_from_ned);

// AACG transforms acceleration commands to attitude commands
aacg->transform_acceleration_commands(a_lf_cmd_vel_m_per_s2, a_hf_cmd_vel_m_per_s2, 
                                     q_vel_from_ned, q_est_trim0_from_ned);
```

## 10. Conclusion

The trajectory generation and attitude control system forms a comprehensive framework for generating and tracking trajectories across different flight phases. The system's modular architecture allows for specialized handling of each flight phase while maintaining smooth transitions between them. The integration between trajectory generation and attitude control ensures that the vehicle can accurately follow commanded trajectories while maintaining appropriate attitude for each flight regime.

Key strengths of the system include:
1. Specialized handling of different flight phases (VTOL, WBF, transitions)
2. Smooth transitions between flight phases
3. Multiple tracking modes optimized for different conditions
4. Comprehensive frame transformations for accurate control
5. Robust error handling and contingency logic

This integrated system enables the vehicle to perform complex flight maneuvers while maintaining stability and tracking accuracy across its entire flight envelope.