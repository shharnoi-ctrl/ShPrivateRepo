# Generated from:

- Amazon-PrimeAir/items/ASTRO/items/sw/sw_pa_unit_testing/02_Unit_Testing_Framework.md (2574 tokens)
- Amazon-PrimeAir/items/ASTRO/items/sw/sw_pa_unit_testing/02_Project_Configuration.md (2565 tokens)

---

# Comprehensive System-Level Overview: sw_pa_unit_testing Project

## Executive Summary

The `sw_pa_unit_testing` project is a sophisticated unit testing framework designed specifically for testing a complex Guidance, Navigation, and Control (GNC) system. The framework provides a comprehensive test harness that enables systematic verification of various subsystems including controllers, navigation components, trajectory planning, state space models, and recovery systems. The architecture supports both individual component testing and integrated system validation through a modular, extensible design that can be executed in both hardware-targeted and Software-In-Loop (SIL) environments.

## Core Architecture and Design Philosophy

### Framework Structure

The unit testing framework is built around a central test harness (`Pa_main.cpp`) that orchestrates test registration, execution, and result reporting. The architecture follows these key design principles:

1. **Modular Test Organization**: Tests are organized by functional subsystem (controllers, navigation, trajectory planning, etc.), allowing for targeted validation of specific components.

2. **Consistent Test Interface**: All test functions follow a standardized interface, returning boolean success indicators, enabling uniform handling and reporting.

3. **Flexible Execution Model**: Tests can be run individually (by specifying a test name as a command-line argument) or as a complete suite (with no arguments), supporting both focused debugging and comprehensive validation.

4. **Resource Management**: The framework implements custom memory management to ensure sufficient resources for test execution, allocating 5MB for internal memory and 100MB for external memory.

5. **Clear Result Reporting**: Test results are systematically collected and reported, with detailed summaries of failures to facilitate debugging.

6. **Test Splitting**: Complex test suites are divided into multiple functions (e.g., `test_all0`, `test_all1`) to manage complexity and potentially enable parallel execution.

7. **Selective Test Enabling/Disabling**: Individual tests can be disabled when needed, allowing for incremental development and testing.

## Test Registry and Execution Flow

The framework implements a test registry system through the `Test_list` class, which maintains a collection of test functions mapped to their names. The main execution flow follows this sequence:

1. **Test Registration**: All available test functions are registered with the test registry using `tests.add_test()`, which associates each test name with its implementation function.

2. **Memory Expansion**: Before test execution, memory allocators are expanded to provide sufficient resources for testing.

3. **Test Execution**: Based on command-line arguments, either all registered tests or a specific test is executed.

4. **Result Collection**: Test results are collected, with failed tests tracked by name.

5. **Result Reporting**: A summary of test results is generated, with detailed information about any failures.

6. **Exit Status**: The program returns an exit code indicating overall success (0) or failure (1).

## Subsystem Test Coverage

The framework provides comprehensive test coverage across multiple subsystems of the GNC architecture:

### 1. Controllers (Control Systems)

Tests for various control systems components including:
- Attitude Control Guidance (`Atcg_unit_test`)
- Trajectory Tracking Control Guidance (`Ttcg_unit_test`)
- Wind-Aware Control Adaptation (`Waca_unit_test`)
- Control Modes (`Cm_pa_unit_test`)
- Autonomous Flight Control (`Afc_unit_test`)
- Autonomous Emergency Escape (`Aee_unit_test`)
- Attitude Stability Control (`Asc_unit_test`)
- Trajectory Stability Control (`Tsc_unit_test`)
- Autonomous Attitude Control Guidance (`Aacg_unit_test`)
- Trajectory Control Guidance (`Tcg_unit_test`)
- Control Mixing (`Mixer_unit_test`)

### 2. Navigation Systems

Tests for navigation components including:
- System Initialization (`Initializer_test`)
- Heading Determination (`Heading_unit_test`)
- Vehicle Management System (`Vms_reset_test`)
- Sensor Data Processing (`Moving_avg_imu_unit_test`)
- State Persistence (`Persistence_test`)
- Motion Detection (`Quiescence_unit_test`, `Detect_pseudo_jerk_unit_test`)
- Ground Detection (`On_ground_unit_test`, `On_ground_g2a_unit_test`, `A2g_unit_test`)
- State History Management (`State_history_unit_test`)
- State Estimation Status (`State_estimate_status_logic_unit_test`)
- External Data Integration (`Input_uplink_heading_test`)
- Update Mechanisms (`Update_ud_unit_test`, `Lidar_update_ned2gnd_unit_test`)

### 3. Trajectory Planning

Tests for trajectory generation and planning:
- Waypoint Management (`Waypoint_unit_test`, `Waypoint_coordinate_unit_test`)
- Maneuver Coordination (`Maneuver_coordinate_unit_test`)
- Specific Maneuver Types:
  - Roll Maneuvers (`Roll_maneuver_unit_test`)
  - Straight Maneuvers (`Straight_maneuver_unit_test`)
  - Hover Maneuvers (`Hover_maneuver_unit_test`)
  - Turn Maneuvers (`Turn_maneuver_unit_test`)
- General Maneuver Handling (`Maneuver_unit_test`)
- Trajectory Planning (`Trajectory_planner_test`)
- Planning Utilities (`Trajectory_planner_utilities`)

### 4. GNC Utilities

Tests for supporting utilities and transformations:
- Geographic Calculations (`Geographic_utilities_tests`)
- Flight Dynamics (`Flight_dynamics_unit_test`)
- Rotation Handling (`Rotation_utilities_tests`)
- Operational Mode Management (`Takeoff_manager_unit_test`, `Land_manager_unit_test`)
- Vector Operations (`Vector_saturation_unit_test`, `Gnc_vector_saturation_unit_test`)
- Coordinate Transformations (`Test_transformation`, `Body_transformation_unit_test`)
- Geometric Calculations (`Geometric_unit_test`)
- Signal Processing (`Switch_blender_unit_test`)

### 5. State Space Models

Tests for system modeling components:
- Basic Models (`Model_unit_test`)
- Gain-Scheduled Models (`Gnc_model_gain_unit_test`)
- Dynamic Models (`Model_dynamic_unit_test`)
- MATLAB-Generated Models (`Model_dynamic_matlab_test`)

### 6. Recovery Systems

Tests for system recovery mechanisms:
- Recovery Controls (`Recovery_controls_command_processor_test`)
- Route Construction (`Recovery_route_constructor_unit_test`)
- Mission Phase Management (`Recovery_mission_phase_of_flight_test`)
- Controls Integration (`Recovery_wrapper_controls_test`)
- Mission Data Processing (`Recovery_mission_data_processor_test`)

### 7. State Machines

Tests for state management:
- General State Machines (`State_machines_tests`)
- Controller Status Management (`Controller_Status_test`)

### 8. Serialization and Data Handling

Tests for data serialization and processing:
- General Serialization (`Serialization_test`)
- Recovery Data Serialization (`Recovery_wrapper_output_serialization_test`, `Recovery_wrapper_input_serialization_test`)
- Protocol Buffer Handling (`Protobuf_test`)

## Build Environment and Project Configuration

The project is configured as an Eclipse CDT (C/C++ Development Tooling) project with a focus on debugging and testing capabilities:

### Build Configuration

- **Primary Configuration**: Headless_Debug (optimized for automated testing without GUI)
- **Build Artifact**: Executable (.exe)
- **Build Type**: Debug (with maximum debug information and no optimization)
- **Parallel Build**: Enabled for faster compilation

### Project Dependencies

The testing framework has extensive dependencies on other system components, reflecting the complex architecture of the GNC system being tested:

1. **Hardware Abstraction Layer**:
   - Board Support Package (`bsp`)
   - Digital Signal Processor support (`DSP28x`, `DSP2837x_ent`, `DSP2838x_ent`)
   - Device interfaces (`devices`)

2. **Core System Components**:
   - Base functionality (`base`)
   - Foundation components (`first`)
   - System components (`maverick`, `veronte`)

3. **Functional Components**:
   - System blocks (`blocks`, `vblocks`)
   - Guidance, Navigation, and Control (`gnc`)
   - System dynamics (`dynamics`)
   - Geographical modeling (`geomodel`)
   - Standardization components (`stanag`)

4. **Testing Infrastructure**:
   - SIL base (`PA_SIL_base`)
   - Testing library (`sw_pa_unit_testing_lib`)
   - Monitoring tests (`PA_monitor_tests`)

### Dual-Targeting Approach

The project supports both hardware-targeted and Software-In-Loop (SIL) testing environments, as evidenced by the inclusion of both regular `include` and `include_SIL` directories in the build configuration. This dual-targeting approach allows tests to be run:

1. On actual hardware for final validation
2. In a simulated environment for rapid development and debugging

## Technical Features for Embedded System Testing

The framework incorporates several technical features specifically designed for testing embedded GNC systems:

### 1. Memory Management

Custom memory management is implemented to ensure sufficient resources for test execution:
```cpp
void expand_memmgr_memory()
{
    Base::Memmgr& memmgr = Base::Memmgr::get_instance();
    Base::Allocator& int_allocator = memmgr.get_allocator(Base::Memmgr::internal);
    Base::Allocator& ext_allocator = memmgr.get_allocator(Base::Memmgr::external);

    Uint32 int_allocator_total_mem = 1024*1024*5; // 5 megabytes
    Uint16* int_allocator_pbuf = new Uint16[int_allocator_total_mem / sizeof(Uint16)];
    Uint32 ext_allocator_total_mem = 1024*1024*100; // 100 megabytes
    Uint16* ext_allocator_pbuf = new Uint16[ext_allocator_total_mem / sizeof(Uint16)];

    new (&int_allocator) Base::Allocator(int_allocator_pbuf, int_allocator_total_mem / sizeof(Uint16));
    new (&ext_allocator) Base::Allocator(ext_allocator_pbuf, ext_allocator_total_mem / sizeof(Uint16));
}
```

This approach:
- Allocates dedicated memory pools for testing (5MB internal, 100MB external)
- Uses placement new to reinitialize allocators with expanded memory
- Ensures tests have sufficient resources without modifying production code

### 2. Test Registry System

The framework uses a registry system (`Test_list` class) that:
- Maintains a collection of test functions mapped to their names
- Provides a consistent interface for test registration and execution
- Enables selective test execution based on command-line arguments

### 3. Comprehensive Result Reporting

Test results are systematically collected and reported:
```cpp
if (argc == 1)  // No arguments -> Run all tests
{
    std::vector<std::string> failed_test_names;
    for (const auto& pair : tests.tests)
    {
        const bool this_test_passed = tests.run(pair.first);
        if (!this_test_passed)
        {
            failed_test_names.emplace_back(pair.first);
        }
        passed &= this_test_passed;
        std::cout << '\n';
    }
    // Print summary of results
}
```

This approach:
- Tracks individual test results
- Collects names of failed tests
- Generates a comprehensive summary
- Provides clear pass/fail status for CI/CD integration

### 4. Software-In-Loop Testing Support

The framework supports Software-In-Loop (SIL) testing through:
- Dedicated include paths for SIL environments (`include_SIL`)
- SIL-specific base components (`PA_SIL_base`)
- Configuration optimized for headless execution

This enables:
- Testing without physical hardware
- Rapid iteration during development
- Integration with automated testing pipelines

## Relationship to Prime Air GNC System

Based on the test categories and component names, this testing framework appears to be designed for a sophisticated aerial system, likely the Amazon Prime Air delivery drone platform. The framework tests critical components for autonomous flight:

1. **Flight Control**: Components like Attitude Control Guidance, Trajectory Control, and Autonomous Flight Control suggest a system capable of precise autonomous flight.

2. **Navigation**: Tests for heading determination, ground detection, and state estimation indicate a system that must maintain accurate positioning awareness.

3. **Trajectory Planning**: Tests for various maneuvers (hover, turn, straight) and waypoint handling suggest a system designed for complex flight paths.

4. **Recovery Systems**: Components for recovery controls and mission phase management indicate safety-critical systems for handling contingencies.

5. **State Machines**: Tests for state management suggest a complex operational model with different flight modes and transitions.

The comprehensive nature of the testing framework reflects the safety-critical requirements of an autonomous aerial delivery system, where robust verification of all components is essential.

## Conclusion

The `sw_pa_unit_testing` project represents a sophisticated testing framework designed specifically for validating a complex GNC system. Its architecture supports comprehensive testing of all system components, from low-level utilities to high-level controllers, in both hardware-targeted and simulated environments. The framework's modular design, consistent interfaces, and flexible execution model enable both focused debugging and comprehensive validation, making it a critical tool for ensuring the reliability and safety of the Prime Air delivery drone platform.

The framework's extensive test coverage across multiple subsystems, combined with its robust technical features for memory management, test registration, and result reporting, demonstrates a commitment to thorough validation of safety-critical embedded systems. This approach is essential for autonomous aerial systems where software reliability directly impacts operational safety.