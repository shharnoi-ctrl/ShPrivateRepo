# Generated from:

- _sw_Veronte/code/vpgnc/code/include/Guidance.h (3163 tokens)
- _sw_Veronte/code/vpgnc/code/source/Guidance.cpp (7717 tokens)
- _sw_Veronte/code/vpgnc/code/include/Guidance_fw.h (23 tokens)
- _sw_Veronte/code/vpgnc/code/include/Guid_pid.h (547 tokens)
- _sw_Veronte/code/vpgnc/code/source/Guid_pid.cpp (658 tokens)
- _sw_Veronte/code/vpgnc/code/include/Orthodrome.h (598 tokens)
- _sw_Veronte/code/vpgnc/code/source/Orthodrome.cpp (734 tokens)
- _sw_Veronte/code/vpgnc/code/include/Alt2D.h (480 tokens)
- _sw_Veronte/code/vpgnc/code/source/Alt2D.cpp (673 tokens)

## With context from:

- PackageSummaries/Embention/Amazon-PrimeAir/items/ASTRO/items/sw/sw_Astro/items/06_VPGNC_Core.md (7671 tokens)
- PackageSummaries/Embention/Amazon-PrimeAir/items/ASTRO/items/sw/sw_Astro/items/05_VPGNC_Navigation.md (8463 tokens)

---

# Guidance Algorithms and Path Following Components in VPGNC Framework

This analysis provides a detailed examination of the guidance algorithms and path following components in the VPGNC framework, focusing on the Guidance class, Guid_pid class, Orthodrome class, and Alt2D class.

## 1. Guidance Class: Core Guidance System Implementation

The `Guidance` class is the central component responsible for computing desired velocity and position commands to follow a specified path or maintain a desired position.

### 1.1 Core Components and Responsibilities

```
+----------------+         +----------------+         +----------------+
|    Guidance    |-------->|    Track       |-------->|   Patchsets    |
| (Guidance      |         | (Path          |         | (Route         |
|  Computer)     |         |  Tracking)     |         |  Management)   |
+----------------+         +----------------+         +----------------+
       |                          |                          |
       v                          v                          v
+----------------+         +----------------+         +----------------+
| Obstacle       |         | PID            |         | Arcade         |
| Avoidance      |         | Controllers    |         | Controls       |
+----------------+         +----------------+         +----------------+
```

The `Guidance` class:
- Computes desired velocity and position for path following
- Implements obstacle avoidance algorithms
- Manages different guidance modes (cruise, hover)
- Processes PID control for guidance
- Handles aerodynamic parameters for control

### 1.2 Key Member Variables

```cpp
static const Real k_alpha;              // Proportional gain for line attraction achievability
static const Real max_d_t_ratio;        // Maximum d-t guidance ratio (limited to follow obstacle walls)

Arcxset arcx;                           // Arcade axis
Track track;                            // Track

Patchsets patchsets;                    // Patchsets manager
Polymgr_impl& obstacles;                // Reference to polygons and obstacle manager
Base::Patchid achieved;                 // Last achieved patch

Maverick::Rvector3 shv;                 // shv (h is horizontal separation, v is vertical separation)

// Work variables for track computation
const volatile Real& dt;                // GNC step duration
Bsp::Hrvar d_err;                       // Cross-track coordinate (navigation error)
Real avlambda;                          // Obstacle avoidance lambda memory (current selected avoidance stream direction)
Maverick::Rvector3 kh;                  // Down unit-vector
Maverick::Rmatrix3 Lns;                 // Matrix from shv to xyz NED
Maverick::Irvector3 us;                 // Along-track unit-vector
Maverick::Irvector3 uh;                 // Horizontal unit-vector (perpendicular to us)
Maverick::Irvector3 uv;                 // Unit-vector (perpendicular to us and uh)

Maverick::Rvector3 prev_vn;             // Previous desired velocity in navigation frame
Real v_ias;                             // Desired Indicated Air Speed after bounding
Maverick::Rvector3 pid_vc;              // PID desired velocity (NED)

Maverick::Irvector3::K wn;              // Estimated wind velocity expressed in NED frame
Maverick::Rvector3 mod_az_vars;         // Aerodynamic Azimuth Variables (Desired, Actual, and Error)
Maverick::Rvector3 mod_el_vars;         // Aerodynamic Elevation Variables (Desired, Actual, and Error)

Varguide vars;                          // Dedicated system variables

Guid_pid::State npidst;                 // North guidance PID state
Guid_pid::State epidst;                 // East guidance PID state
Guid_pid::State dpidst;                 // Down guidance PID state
```

### 1.3 Constructor Implementation

The constructor initializes all guidance components:

```cpp
Guidance::Guidance(Media::Cfgmgr& cfg,
                   Tpatchset& route0,
                   const Vpunav& uav0,
                   Base::Checklist& opchlist,
                   Polymgr_impl& poly,
                   Airframe_action_wp_publish& aac_publish0):
    uav(uav0),
    arcx(uav0, *this),
    track(cfg,uav,*this,achieved,opchlist,aac_publish0),
    patchsets(cfg,
              uav0,
              route0,
              *this,
              track,
              achieved,
              aac_publish0),
    obstacles(poly),
    dt(Bsp::Hrvar(Base::v_dt_gnc).get_kref()),
    d_err(Base::v_routedev),
    avlambda(Const::ZERO),
    us(&Lns[u0]),
    uh(&Lns[u3]),
    uv(&Lns[u6]),
    v_ias(0.0F),
    vars(*this),
    mode(*this),
    wn(Bsp::Hrvar::get_kblock(Base::v_wn, Base::v_wd).to_non_volatile())
{
    d_err.set(Const::ZERO);
    kh.zeros();
    kh[u2]=Const::ONE;

    shv.zeros();

    prev_vn.zeros();
    an.zeros();
    pid_vc.zeros();
    mod_az_vars.zeros();
    mod_el_vars.zeros();

    cfg.add_cmd(Base::Cfg::cfg_cmd_speed,       track.build_speedcmdtun());
    cfg.add_cmd(Base::Cfg::cfg_cmd_gtrack,      Base::Tunbuild::build(track));

    cfg.add(Base::Cfg::cfg_arcx,                arcx.build_cfg_arcx());

    altitude=Const::ONE_HUNDRED_THOUSAND;
    height=Const::ONE_HUNDRED_THOUSAND;
    track.reset();
}
```

### 1.4 Guidance Deviation Algorithm

The `deviation` method is the core guidance algorithm that computes the desired velocity and position:

```cpp
void Guidance::deviation(const Guid_pid& hpid,
                         const Guid_pid& vpid,
                         const Envelope& env,
                         const bool hvr,
                         const Dynamics::Aircraft::Tspeed vtype,
                         const Real v_cruise,
                         const Real speedc)
{
    // Get tangent and distance vectors from track
    const Irvector3& t = track.get_tangent();
    const Irvector3& d = track.get_distance();
    const Real D0 = d.norm2();
    d_err.set(D0);
    
    // Set up coordinate system for guidance
    us.copy(t);
    uh.cross(kh,us);
    uh.norm2alize();
    uv.cross(us,uh);
    
    // Compute route-guidance distance components
    shv[u0]=d.dot(us);  // Tangential component
    shv[u1]=d.dot(uh);  // Horizontal component
    shv[u2]=d.dot(uv);  // Perpendicular component
    
    // Compute obstacle repulsion field slope
    const Base::Rv2 slope = build_obstacle_slope(env, v_cruise);
    vars.obst_effect_dist.set(1.0F / slope[0]);
    
    // Choose guidance mode based on hover flag
    if (hvr) {
        hover_guidance(v_cruise, slope, hpid, vpid);
    } else {
        cruise_guidance(speedc, D0, slope, hpid, vpid);
    }
    
    // Update velocity magnitude based on control mode
    Maverick::Rvector3 vn0;
    vn0.copy(vn.get());
    update_magnitude(vtype, vn0, speedc);
    
    // Apply flight envelope constraints
    apply_envelope(env, vtype, speedc, vn0);
    
    // Apply acceleration bounds
    if (env.bound_accel(prev_vn, an, dt, uav, 0, vn0)) {
        update_magnitude(Dynamics::Aircraft::speed, vn0, 0.0F);
    }
    
    // Update aerodynamic parameters
    vn0.azeld(vhfb[u0], vhfb[u1], V);
    
    // Compute acceleration and store velocity
    an.vecres(vn0, prev_vn);
    an.scale(1.0F/dt);
    prev_vn.copy(vn0);
    
    // Compute body-frame velocity and ground speed
    uav.n2b(vn0, uvw);
    uav.compute_gs(vn0, gsb0, gsb1, GS);
    
    // Get altitude information
    pos.get_ah(altitude, height);
    
    // Update aerodynamic guidance parameters
    update_aerodynamic_params(vn0);
    
    // Set final desired velocity
    vn.copy(vn0);
}
```

This method:
1. Gets the tangent and distance vectors from the current track
2. Sets up a coordinate system for guidance calculations
3. Computes route-guidance distance components
4. Calculates obstacle repulsion field slope
5. Executes either hover or cruise guidance based on the mode
6. Updates velocity magnitude based on the control mode
7. Applies flight envelope constraints
8. Applies acceleration bounds
9. Updates aerodynamic parameters
10. Computes acceleration and stores velocity
11. Computes body-frame velocity and ground speed
12. Gets altitude information
13. Updates aerodynamic guidance parameters
14. Sets the final desired velocity

### 1.5 Cruise Guidance Algorithm

The `cruise_guidance` method implements guidance for cruise flight mode:

```cpp
void Guidance::cruise_guidance(const Real Vc,
                               const Real D0,
                               const Base::Rv2& slope,
                               const Guid_pid& hpid,
                               const Guid_pid& vpid)
{
    // Compute line attraction parameter
    Real kd = hpid.get_gain(Gnc::Pid::gain_kp);
    if ((kd*D0) > max_d_t_ratio) {
        kd = max_d_t_ratio/D0;
    }
    
    // Compute desired velocity vector
    Rvector3 vf;
    vf.copy(track.get_tangent());  // t vector
    vf.lincmb_add(-kd, track.get_distance());
    
    // Force module to desired speed
    vf.scale(Vc/vf.norm2());
    
    // Apply obstacle avoidance
    Rvector3 vo;
    obstacles.obstacle_deviation(pos, height, slope, vo);
    Rvector3 vfp;
    obstacle_avoidance(vf, vo, Vc, false, vfp);
    
    // Compute local tangent vector
    Rvector3 upc;
    upc.copy(vfp);
    upc.norm2alize();
    
    // Compute vector from UAV to desired position
    Rvector3 d1;
    uav.get_pos().relthis_drn(pos, d1);
    
    // Project d1 onto upc direction
    Real drpc = Const::ZERO;
    if (track.get_prj() == Patchset::prj_3d) {
        drpc = -d1.dot(upc);
    } else {
        const Rvector3 hpc(upc[u0], upc[u1], Const::ZERO);
        const Real nhpc2 = hpc.norm22xy();
        drpc = (nhpc2 > Const::ZERO) ? (-d1.dot(hpc)/nhpc2) : Const::ZERO;
    }
    
    // Only forward movement of desired position in upc direction is allowed
    if (drpc >= Const::ZERO) {
        d1.lincmb_add(drpc, upc);
    } else {
        d1.zeros();
    }
    
    // Update position error system variables for PIDs
    vars.ne.set(d1[u0]);
    vars.ee.set(d1[u1]);
    vars.de.set(d1[u2]);
    
    // Guidance control using PIDs
    pid_vc[u0] = npidst.step(hpid, d1[u0], pid_vc[u0], dt);  // North
    pid_vc[u1] = epidst.step(hpid, d1[u1], pid_vc[u1], dt);  // East
    pid_vc[u2] = dpidst.step(vpid, d1[u2], pid_vc[u2], dt);  // Down
    
    // Move desired point in curve for next iteration
    pos.copynr(uav.get_pos());
    pos.move_drn(d1);
    
    // Compose desired velocity and force cruise speed
    Rvector3 vn0;
    vn0.vecsum(upc, pid_vc);
    vn0.scale(Vc/vn0.norm2());
    vn.copy(vn0);
}
```

This method:
1. Computes a line attraction parameter based on PID gain
2. Calculates the desired velocity vector using the tangent and distance vectors
3. Applies obstacle avoidance to the desired velocity
4. Computes the local tangent vector
5. Calculates the vector from the UAV to the desired position
6. Projects this vector onto the tangent direction
7. Updates position error variables for PID controllers
8. Applies PID control to generate correction velocities
9. Updates the desired position for the next iteration
10. Composes the final desired velocity by combining the tangent and PID velocities

### 1.6 Hover Guidance Algorithm

The `hover_guidance` method implements guidance for hover flight mode:

```cpp
void Guidance::hover_guidance(const Real v_cruise,
                              const Base::Rv2& slope,
                              const Guid_pid& hpid,
                              const Guid_pid& vpid)
{
    // Compute total distance vector to current desired position
    Maverick::Rvector3 dist;
    dist.lincmb(-1.0F, track.get_distance());
    
    // Update desired position to desired hover position
    pos.move_drn(dist);
    
    // Compute vector from UAV to desired position
    Maverick::Rvector3 d1;
    uav.get_pos().relthis_drn(pos, d1);
    
    // Horizontal guidance
    if (track.apply_h_arcade(pid_vc)) {
        vars.ne.set(Const::ZERO);
        vars.ee.set(Const::ZERO);
    } else {
        // Update horizontal position error system variables for PIDs
        vars.ne.set(d1[u0]);
        vars.ee.set(d1[u1]);
        
        // Horizontal guidance control
        pid_vc[u0] = npidst.step(hpid, d1[u0], pid_vc[u0], dt);  // North
        pid_vc[u1] = epidst.step(hpid, d1[u1], pid_vc[u1], dt);  // East
    }
    
    // Vertical guidance
    if (track.apply_v_arcade(pid_vc)) {
        vars.de.set(Const::ZERO);
    } else {
        // Update vertical position error system variables for PIDs
        vars.de.set(d1[u2]);
        
        // Vertical guidance control
        pid_vc[u2] = dpidst.step(vpid, d1[u2], pid_vc[u2], dt);  // Down
    }
    
    // Apply obstacle avoidance
    Rvector3 vo;
    obstacles.obstacle_deviation(uav.get_pos(), uav.get_AGL(), slope, vo);
    Rvector3 vn0;
    vn0.copy(vn.get());
    obstacle_avoidance(pid_vc, vo, v_cruise, true, vn0);
    
    // Limit speed if higher than configured cruise speed
    const Real nvn = vn0.norm2();
    if (nvn > v_cruise) {
        vn0.scale(v_cruise/nvn);
    }
    vn.copy(vn0);
}
```

This method:
1. Computes the total distance vector to the desired hover position
2. Updates the desired position
3. Calculates the vector from the UAV to the desired position
4. Handles horizontal guidance using either arcade controls or PID controllers
5. Handles vertical guidance using either arcade controls or PID controllers
6. Applies obstacle avoidance to the desired velocity
7. Limits the speed to the configured cruise speed

### 1.7 Obstacle Avoidance Algorithm

The `obstacle_avoidance` method implements the algorithm to avoid obstacles:

```cpp
void Guidance::obstacle_avoidance(const Irvector3& vf,
                                  const Irvector3& vo,
                                  const Real Vcr,
                                  const bool hover,
                                  Irvector3& vn)
{
    // Save the value of actual guidance speed vf into vn
    vn.copy(vf);
    
    // Compute the norm of obstacle avoidance field vo
    const Real nvo = vo.norm2();
    
    // If the actual norm is greater than zero
    if (nvo > Const::ZERO) {
        // Compute the avoidance gain as the minus dot product between normalized vo and vf
        Real vfuo = -vf.dot(vo)/nvo;
        
        // If the gain is negative (body moving away of obstacle), set the gain to zero
        if (vfuo < Const::ZERO) {
            vfuo = Const::ZERO;
        }
        
        // If the norm of vo is greater than one (body inside of obstacle)
        if (nvo > Const::ONE) {
            // Add to the repulsion gain: Vcr * (nvo - 1) / nvo
            vfuo += (Vcr*(nvo - Const::ONE) / nvo);
        }
        
        // Add to vn the product of the repulsion gain and vo
        vn.lincmb_add(vfuo, vo);
        
        // If not in hover mode, add horizontal speed for obstacle avoidance
        if (!hover) {
            // Compute a horizontal unit vector normal to vo
            Rvector3 uot;
            uot[u0] = vo[u1];
            uot[u1] = -vo[u0];
            uot[u2] = Const::ZERO;
            uot.norm2alize();
            
            // Compute projections and squared norms
            const Real vnuot = vn.dot(uot);
            const Real nvnxy2 = vn.norm22xy();
            const Real vcrxy2 = vf.norm22xy();
            
            // Compute the factor sq
            Real sq = vnuot*vnuot - nvnxy2 + vcrxy2;
            Real dlambda1 = Const::ZERO;
            Real dlambda2 = Const::ZERO;
            
            // If sq factor is greater than zero
            if (sq >= Const::ZERO) {
                // Compute the two possible horizontal avoidance factors
                sq = sqrtr(sq);
                dlambda1 = -vnuot + sq - avlambda;
                dlambda2 = -vnuot - sq - avlambda;
            }
            
            // Select the valid horizontal avoidance factor with lowest absolute value
            const Real dlambda = (fabsr(dlambda1) < fabsr(dlambda2)) ? dlambda1 : dlambda2;
            
            // Add to avlambda the previous factor
            avlambda += dlambda;
            
            // Add to vn the product of avlambda and uot
            vn.lincmb_add(avlambda, uot);
        }
    }
}
```

This method:
1. Initializes the output velocity with the input velocity
2. Computes the norm of the obstacle avoidance field
3. If obstacles are present:
   a. Calculates a repulsion gain based on the dot product of velocity and obstacle field
   b. Adds extra repulsion if inside an obstacle
   c. Applies the repulsion to the velocity vector
   d. For non-hover mode, adds a lateral velocity component to help navigate around obstacles

### 1.8 Aerodynamic Parameters Update

The `update_aerodynamic_params` method updates the aerodynamic guidance states:

```cpp
void Guidance::update_aerodynamic_params(const Maverick::Rvector3 & vn0)
{
    Rvector3 vgdn;
    
    // Initialize vgdn (used for calculation of aerodynamic heading)
    vgdn.copy(vn0);
    
    // Calculate aerodynamic velocity vector: v_g_des_mod = v_g_des - v_w
    vgdn.vecsub(wn.kvec);
    
    Rvector3 vgn;
    
    // Get the ground velocity vector in ned frame
    vgn.copy(uav.get_vn());
    
    // Obtain v_g_mod in NED frame (Aerodynamic Velocity Vector)
    vgn.vecsub(wn.kvec);
    
    // Obtain the corresponding headings and FPAs from the aerodynamic velocity vectors
    Real temp;
    vgn.azeld(mod_az_vars[1], mod_el_vars[1], temp);
    vgdn.azeld(mod_az_vars[0], mod_el_vars[0], temp);
    
    // Obtain the aerodynamic errors for control
    mod_az_vars[2] = mod_az_vars[0] - mod_az_vars[1];
    mod_el_vars[2] = mod_el_vars[0] - mod_el_vars[1];
    
    // Publish the variables
    vars.modaz.commit();
    vars.model.commit();
}
```

This method:
1. Calculates the desired aerodynamic velocity vector by subtracting wind from the desired ground velocity
2. Calculates the actual aerodynamic velocity vector by subtracting wind from the actual ground velocity
3. Computes the aerodynamic heading and flight path angles for both vectors
4. Calculates the errors between desired and actual aerodynamic parameters
5. Publishes the variables to the system

### 1.9 Velocity Magnitude Update

The `update_magnitude` method updates the magnitude of the desired velocity vector:

```cpp
void Guidance::update_magnitude(const Dynamics::Aircraft::Tspeed vtype,
                                Maverick::Irvector3 &vn0,
                                Real v_ias_d)
{
    if (vtype == Dynamics::Aircraft::ias) {
        // For IAS control mode
        Rvector3 wn_trimmed;
        wn_trimmed.copy(wn.kvec);
        Real nwn = wn.kvec.norm2();
        static const Real ias_max_ratio = 0.95F;
        v_ias = v_ias_d;
        const Real ias_max = ias_max_ratio * v_ias;
        const static Real v_crit = 1.0e-16;
        
        // Trim wind if it's too strong
        if (nwn > ias_max && nwn > v_crit) {
            wn_trimmed.scale(ias_max / nwn);
        }
        
        // Normalize velocity vector if possible
        if (vn0.norm22() > v_crit) {
            vn0.norm2alize();
        } else {
            // Use wind direction if velocity is too small
            Rvector3 vwhat;
            vwhat.copy(wn.kvec);
            if (nwn > v_crit) {
                vwhat.norm2alize();
                vn0.copy(vwhat);
            }
        }
        
        // Apply lambda method to get the magnitude for the desired ground speed
        Real vnw = vn0.dot(wn_trimmed);
        V = vnw + Rmath::sqrtr(vnw*vnw + v_ias*v_ias - wn_trimmed.norm22());
        vn0.scale(V);
    } else {
        // For Ground Speed Control
        Rvector3 vias;
        vias.vecres(vn0, wn.kvec);
        v_ias = vias.norm2();
        V = vn0.norm2();
    }
}
```

This method:
1. For IAS (Indicated Airspeed) control mode:
   a. Trims wind if it's too strong
   b. Normalizes the velocity vector
   c. Calculates the ground speed magnitude needed to achieve the desired airspeed
   d. Scales the velocity vector to this magnitude
2. For Ground Speed control mode:
   a. Calculates the IAS corresponding to the desired ground speed
   b. Sets the velocity magnitude to the desired ground speed

### 1.10 Flight Envelope Application

The `apply_envelope` method applies flight envelope constraints to the desired velocity:

```cpp
void Guidance::apply_envelope(const Envelope& env,
                              const Dynamics::Aircraft::Tspeed vtype,
                              Real Vc,
                              Maverick::Irvector3 &vn0)
{
    Real az = 0.0F;
    Real el = 0.0F;
    Real vel_norm = 0.0F;
    vn0.azeld(az, el, vel_norm);
    
    // Bound flight path angle
    if (env.bound_fpa(el)) {
        vn0.azeld_1(az, el, vel_norm);
        update_magnitude(vtype, vn0, Vc);
    }
    
    // Bound stall (can change module of velocity, but not direction)
    if (env.bound_stall(v_ias)) {
        update_magnitude(Dynamics::Aircraft::ias, vn0, v_ias);
    }
    
    // Bound ground speed (keeping constant velocity module if possible)
    Real GSc = vn0.norm2xy();
    if (env.bound_ground(GSc)) {
        Base::sincos(az, &vn0[u1], &vn0[u0]);
        vn0[u0] *= GSc;
        vn0[u1] *= GSc;
        update_magnitude(Dynamics::Aircraft::speed, vn0, 0.0F);
    }
    
    // Bound down velocity (keeping constant velocity module)
    if (env.bound_vdown(vn0[u2])) {
        update_magnitude(Dynamics::Aircraft::speed, vn0, 0.0F);
    }
}
```

This method:
1. Extracts azimuth, elevation, and velocity norm from the velocity vector
2. Applies flight path angle bounds
3. Applies stall speed bounds
4. Applies ground speed bounds
5. Applies vertical speed bounds
6. Updates the velocity magnitude after each bound application

### 1.11 Obstacle Slope Calculation

The `build_obstacle_slope` method calculates the inverse of the distance at which obstacles affect guidance:

```cpp
Base::Rv2 Guidance::build_obstacle_slope(const Envelope& env,
                                         const Real v_cruise)
{
    static const Real min_brake_acc_obstacles = 0.01F;
    const Real brake_acc_obstacles = Rfun::max<Real>(env.get_acc_obstacles(), min_brake_acc_obstacles);
    
    // Bound horizontal component
    Real max_v_cruise_horizontal = v_cruise;
    env.bound_ground(max_v_cruise_horizontal);
    
    // Bound vertical component
    Real max_v_cruise_down = v_cruise;
    env.bound_vdown(max_v_cruise_down);
    
    // Build horizontal and vertical obstacle slope
    const Base::Rv2 ret = {{
        brake_acc_obstacles / (max_v_cruise_horizontal * max_v_cruise_horizontal),
        brake_acc_obstacles / (max_v_cruise_down * max_v_cruise_down)
    }};
    return ret;
}
```

This method:
1. Gets the obstacle brake acceleration from the envelope
2. Applies horizontal and vertical speed bounds
3. Calculates the inverse of the distance at which obstacles affect guidance
4. Returns horizontal and vertical components of this inverse distance

## 2. Guid_pid Class: PID Controllers for Guidance

The `Guid_pid` class implements PID controllers specifically designed for guidance applications, with support for different controller types and gain scheduling.

### 2.1 Core Components and Responsibilities

```
+----------------+         +----------------+         +----------------+
|   Guid_pid     |-------->|    PID         |-------->|   Tsched       |
| (Guidance PID  |         | (Basic PID     |         | (Table         |
|  Controller)   |         |  Controller)   |         |  Scheduler)    |
+----------------+         +----------------+         +----------------+
       |                          |                          |
       v                          v                          v
+----------------+         +----------------+         +----------------+
| State          |         | Output         |         | Gain           |
| Management     |         | Limiting       |         | Management     |
+----------------+         +----------------+         +----------------+
```

The `Guid_pid` class:
- Implements PID controllers for guidance
- Supports basic PID and table scheduler PID types
- Manages controller state and output limiting
- Provides methods to access and update PID gains

### 2.2 Class Structure

The `Guid_pid` class consists of two main parts:
1. The `Guid_pid` class itself, which manages the controller configuration
2. The `Guid_pid::State` class, which manages the controller state and execution

```cpp
class Guid_pid {
public:
    class State {
    public:
        State();
        Real step(const Guid_pid& pid, const Real ep, const Real prev_u, const Real dt);
        void reset();
        
    private:
        bool on_focus;                // True if on_focus
        Real u_before_sat;            // Computed PID output before any saturation is done
        Gnc::Pidst st;                // PID state
    };
    
    Guid_pid();
    Real get_gain(Gnc::Pid::Gsettings gain_id) const;
    void step(const Real var);
    void cset(Base::Lossy_error& str);
    void cget(Base::Lossy& str) const;
    
private:
    enum Type {
        gp_pid    = 0,               // Enumerator for basic PID
        gp_tsched = 1                // Enumerator for table scheduler PID
    };
    static const Uint16 gp_all = 2U; // Number of PID types
    Type typec;                      // Type of controller
    Gnc::Pidcfg pidc;                // Basic PID controller
    Gnc::Tsched tschedc;             // Table scheduler PID controller
    Maverick::Wrapper limits;        // Output limits
};
```

### 2.3 State Class Implementation

The `Guid_pid::State` class manages the state of the PID controller and executes the control algorithm:

```cpp
Guid_pid::State::State() :
    on_focus(true),
    u_before_sat(0.0F)
{
}

Real Guid_pid::State::step(const Guid_pid& pid,
                           const Real ep,
                           const Real prev_u,
                           const Real dt)
{
    static const Gnc::Opinctrl opin; // Assumes initialization to none
    static const Base::Optional<Real> opt_disabled = {false,0.0F};
    
    // Set up PID input structure
    const Gnc::Pidst::Input in = {
        dt,
        (dt > Const::E1000000) ? (1/dt) : 0.0F,
        opin,
        ep,
        0.0F,
        opt_disabled,
        false,
        prev_u,
        true,
        on_focus ? 0.0F : (prev_u - u_before_sat),
        0.0F,
        opt_disabled
    };
    
    // Execute PID algorithm
    u_before_sat = st.pos_pid(pid.pidc, in);
    
    // Apply output limits
    Real out = u_before_sat;
    pid.limits.wrap(out);
    
    // Update state
    on_focus = false;
    
    return out;
}

void Guid_pid::State::reset()
{
    st.reset();
    u_before_sat = 0.0F;
    on_focus = true;
}
```

This implementation:
1. Sets up the PID input structure with the error, previous output, and time step
2. Executes the PID algorithm to compute the control output
3. Applies output limits to the control output
4. Updates the controller state
5. Returns the limited control output

### 2.4 Guid_pid Class Implementation

The `Guid_pid` class manages the controller configuration and provides methods to access and update PID gains:

```cpp
Guid_pid::Guid_pid() :
    typec(gp_pid),
    tschedc(pidc)
{
}

Real Guid_pid::get_gain(Gnc::Pid::Gsettings gain_id) const
{
    return pidc.get_gain(gain_id);
}

void Guid_pid::step(const Real var)
{
    if (typec == gp_tsched) {
        tschedc.update_gains(var);
    }
}

void Guid_pid::cset(Base::Lossy_error& str)
{
    bool ret = true;
    str.get_enum16(typec);
    
    switch (typec) {
        case gp_pid:
            pidc.cset(str);
            break;
        case gp_tsched:
            tschedc.cset(str);
            break;
        default:
            ret = false;
            break;
    }
    
    limits.cset(str);
    
    // PDI checks
    str.assrt(ret, Base::err_guid_pid);
}

void Guid_pid::cget(Base::Lossy& str) const
{
    str.put_uint16(typec);
    
    switch (typec) {
        case gp_pid:
        default:
            pidc.cget(str);
            break;
        case gp_tsched:
            tschedc.cget(str);
            break;
    }
    
    limits.cget(str);
}
```

This implementation:
1. Initializes the controller with default values
2. Provides a method to access PID gains
3. Updates PID gains based on a scheduling variable (for table scheduler PID)
4. Deserializes the controller configuration from a PDI
5. Serializes the controller configuration to a PDI

## 3. Orthodrome Class: Great Circle Path Tracking

The `Orthodrome` class implements great circle path tracking, which is the shortest path between two points on a sphere (Earth's surface).

### 3.1 Core Components and Responsibilities

```
+----------------+         +----------------+         +----------------+
|   Orthodrome   |-------->|  Fidposcache   |-------->|  Geomodel      |
| (Great Circle  |         | (Position      |         | (Geographic    |
|  Path Tracking)|         |  Caching)      |         |  Calculations) |
+----------------+         +----------------+         +----------------+
       |                          |                          |
       v                          v                          v
+----------------+         +----------------+         +----------------+
| Path           |         | Position       |         | Tangent        |
| Computation    |         | Tracking       |         | Calculation    |
+----------------+         +----------------+         +----------------+
```

The `Orthodrome` class:
- Implements the `Icurve` interface for path tracking
- Computes the great circle path between two points
- Calculates the distance and tangent vectors for guidance
- Manages the start and end positions of the path

### 3.2 Member Variables

```cpp
Geo::Fidposcache start_pos;    // Handler to compute the start position of the orthodrome
Geo::Fidposcache end_pos;      // Handler to compute the end position of the orthodrome
```

### 3.3 Constructor and Initialization

```cpp
Orthodrome::Orthodrome()
{
}

void Orthodrome::set(const Spatchset::Patchdata& oth0)
{
    start_pos.set(oth0.f0);
    end_pos.set(oth0.next_f0);
}
```

The constructor initializes an empty orthodrome, and the `set` method configures it with start and end positions from a patch data structure.

### 3.4 Path Initialization

The `on_focus` method initializes the orthodrome path when it becomes active:

```cpp
void Orthodrome::on_focus(const Geo::Apos& pos,
                          const Irvector3& v0,
                          On_focus_out& out)
{
    Rvector3 d;
    Base::Curvst st;
    refresh_wp();
    out.p0.copynr(start_pos.get_pos());
    compute(out.p0, d, out.t0, st);
    out.f0 = Base::Feature::build_rel(start_pos.get());
    out.f1 = Base::Feature::build_rel(end_pos.get());
}
```

This method:
1. Refreshes the waypoint positions
2. Sets the initial position to the start position
3. Computes the distance and tangent vectors
4. Sets the feature IDs for the start and end positions

### 3.5 Path Computation

The `compute2d` method computes the orthodrome path in 2D:

```cpp
void Orthodrome::compute2d(const Geo::Apos& pos,
                           Irvector3& d,
                           Irvector3& t,
                           Base::Curvst& st0)
{
    refresh_wp();
    const Geo::Apos& af = end_pos.get_pos();
    const Geo::Apos& a0 = start_pos.get_pos();
    Real64 h0 = a0.get_llh().h;
    Real64 hf = af.get_llh().h;
    
    // Convert positions to ECEF coordinates
    Geo::Tecef u0;
    a0.get_ecef(u0);
    Geo::Tecef rf;
    af.get_ecef(rf);
    
    // Normalize u0 to unit vector
    Real R = u0.norm2();
    u0.scale(Const::ONE/R);
    
    // Normalize rf to unit vector
    Rvector3 u1;
    u1.copy(rf);
    u1.norm2alize();
    
    // Compute normal vector to great circle plane
    Rvector3 n;
    n.cross(u0, u1);
    Real sin_f = n.norm2();
    n.scale(Const::ONE/sin_f);
    
    // Compute angle between start and end points
    Real thetaf = Rfun::asinw(sin_f);
    
    // Compute height change rate
    Real hf_h0_thetaf = static_cast<Real>(hf-h0)/thetaf;
    
    // Compute orthogonal vector in great circle plane
    u1.cross(n, u0);
    
    // Get current position in ECEF
    Geo::Tecef r;
    pos.get_ecef(r);
    
    // Compute angle from start point to current position
    Real theta = Rmath::atan2r(u1.dot(r), u0.dot(r));
    
    // Compute sine and cosine of theta
    Real st = Rmath::sinr(theta);
    Real ct = Rmath::cosr(theta);
    
    // Compute closest point on great circle
    Geo::Tecef rc;
    rc.lincmb(ct, u0, st, u1);
    
    // Compute tangent vector
    Rvector3 te;
    te.cross(n, rc);
    
    // Scale rc back to Earth radius
    rc.scale(R);
    
    // Create position at closest point with interpolated height
    Geo::Apos o;
    o.set_ecef(rc);
    o.set_wgs84_h(static_cast<Real>(h0) + hf_h0_thetaf*theta);
    
    // Convert tangent vector to NED frame
    Geo::Geomodel::ecef2ned(o.get_cs(), te, t);
    
    // Compute distance vector
    o.relthis(pos, d);
    
    // Compute curve state (length, total length, etc.)
    Real aux = Rmath::sqrtr(R*R + hf_h0_thetaf*hf_h0_thetaf);
    st0.set(theta*aux, thetaf*aux, theta, thetaf, 0.0F);
}
```

This method:
1. Refreshes the waypoint positions
2. Converts start and end positions to ECEF coordinates
3. Computes the normal vector to the great circle plane
4. Calculates the angle between start and end points
5. Computes the height change rate
6. Calculates the angle from the start point to the current position
7. Computes the closest point on the great circle
8. Calculates the tangent vector at this point
9. Creates a position at the closest point with interpolated height
10. Converts the tangent vector to the NED frame
11. Computes the distance vector from the current position to the closest point
12. Sets the curve state with length information

### 3.6 Waypoint Refresh

The `refresh_wp` method updates the cached positions:

```cpp
void Orthodrome::refresh_wp()
{
    start_pos.refresh();
    end_pos.refresh();
}
```

This method refreshes both the start and end position caches to ensure they have the latest position data.

## 4. Alt2D Class: 2D Altitude Management

The `Alt2D` class manages the desired altitude in 2D guidance mode, providing a mechanism to maintain a constant altitude while following a 2D path.

### 4.1 Core Components and Responsibilities

```
+----------------+         +----------------+         +----------------+
|     Alt2D      |-------->|  Heightabs     |-------->|  Arcade        |
| (2D Altitude   |         | (Height        |         | (Manual        |
|  Management)   |         |  Management)   |         |  Control)      |
+----------------+         +----------------+         +----------------+
       |                          |                          |
       v                          v                          v
+----------------+         +----------------+         +----------------+
| Altitude       |         | System         |         | Vertical       |
| Tracking       |         | Variables      |         | Velocity       |
+----------------+         +----------------+         +----------------+
```

The `Alt2D` class:
- Manages the desired altitude in 2D guidance mode
- Supports different altitude reference types (WGS84, MSL, AGL)
- Implements arcade mode for manual vertical control
- Updates system variables with altitude information

### 4.2 Member Variables

```cpp
const Dynamics::Rigidbody& uav;  // Current body state

bool on_reset;                   // Reset flag
bool arcade_on;                  // True in Arcade Mode

Geo::Heightabs::Htype type;      // Type of altitude
Real h;                          // Altitude

Bsp::Hrvar wgs842d;              // Desired WGS84 2D altitude
Bsp::Hrvar msl2d;                // Desired MSL 2D altitude
Bsp::Hrvar agl2d;                // Desired AGLevel 2D altitude

Gnc::Arcadest arc_st_v;          // Vertical arcade state
Real arc_vdownc;                 // Desired arcade velocity down
```

### 4.3 Constructor Implementation

```cpp
Alt2D::Alt2D(const Dynamics::Rigidbody& uav0) :
    uav(uav0),
    on_reset(true),
    arcade_on(false),
    type(Geo::Heightabs::wgs84),
    h(Const::ONE_HUNDRED_THOUSAND),
    wgs842d(Base::v_llh22dc),
    msl2d(Base::v_msl2dc),
    agl2d(Base::v_agl2dc),
    arc_vdownc(Const::ZERO)
{
    wgs842d.set(Const::ONE_HUNDRED_THOUSAND);
    msl2d.set(Const::ONE_HUNDRED_THOUSAND);
    agl2d.set(Const::ONE_HUNDRED_THOUSAND);
}
```

The constructor initializes the altitude management with default values and sets up system variable handlers.

### 4.4 Altitude Management Algorithm

The `step` method implements the altitude management algorithm:

```cpp
void Alt2D::step(bool use_2d,
                 const Guidance& uavc,
                 Maverick::Irvector3& d,
                 Maverick::Irvector3& t)
{
    if (use_2d) {
        if (!arcade_on) {
            arc_vdownc = 0.0F;
        }
        
        // Update arcade state
        arc_st_v.step(!Rfun::comp_real(arc_vdownc, Const::ZERO, Const::EPS), 
                      Rmath::fabsr(uav.get_vn()[Ku8::u2]));
        
        if (on_reset || arc_st_v.is_arcade()) {
            on_reset = false;
            
            // Velocity mode -> move desired height according to current UAV's height
            h = uav.get_pos().get_h(type);
            wgs842d.set(static_cast<Real>(uav.get_pos().get_llh().h));
            msl2d.set(uav.get_MSL());
            agl2d.set(uav.get_AGL());
        }
        
        // Position mode -> desired height is fixed
        d[Ku16::u2] = h - uavc.get_pos().get_h(type);
        t[Ku16::u2] = Const::ZERO;
    } else {
        arc_st_v.clear();
        arc_vdownc = 0.0F;
        on_reset = true;
    }
    arcade_on = false;
}
```

This method:
1. Checks if 2D mode is active
2. Updates the arcade state based on the desired vertical velocity
3. If in reset mode or arcade mode, updates the desired height to the current UAV height
4. Computes the vertical distance between the desired height and the current height
5. Sets the vertical tangent to zero (no vertical path following)
6. Resets state if 2D mode is not active

### 4.5 Arcade Mode Control

The `set_arc` method sets the desired vertical velocity for arcade mode:

```cpp
void Alt2D::set_arc(const Real dv)
{
    arcade_on = true;
    arc_vdownc = dv;
}
```

This method activates arcade mode and sets the desired vertical velocity.

The `apply_v_arcade` method applies the arcade mode vertical velocity:

```cpp
bool Alt2D::apply_v_arcade(Maverick::Irvector3& vn) const
{
    const bool is_arc = arc_st_v.is_arcade();
    if (is_arc) {
        vn[Ku16::u2] = arc_vdownc;
    }
    return is_arc;
}
```

This method:
1. Checks if arcade mode is active
2. If active, sets the vertical component of the velocity vector to the desired arcade velocity
3. Returns whether arcade mode is active

### 4.6 Configuration Management

The `cset` method deserializes the configuration from a PDI:

```cpp
void Alt2D::cset(Base::Lossy_error& str)
{
    str.get_enum16(type);
    str.get_float(h);
    
    // Altitude set by command only takes effect when commanded while 2D active
    Geo::Apos aux_pos;
    aux_pos.copynr(uav.get_pos());
    aux_pos.set_h(type, h);
    wgs842d.set(static_cast<Real>(aux_pos.get_llh().h));
    
    Real msl = Const::ZERO;
    Real agl = Const::ZERO;
    aux_pos.get_ah(msl, agl);
    msl2d.set(msl);
    agl2d.set(agl);
}
```

This method:
1. Reads the altitude type and value from the configuration
2. Creates a temporary position with the current UAV position
3. Sets the height of this position to the configured height
4. Updates the WGS84, MSL, and AGL altitude variables

## 5. Integration and Data Flow

### 5.1 Guidance System Architecture

The guidance system architecture integrates these components as follows:

```
+----------------+         +----------------+         +----------------+
|    Guidance    |-------->|    Track       |-------->|   Patchsets    |
| (Main Guidance)|         | (Path          |         | (Route         |
|  Controller)   |         |  Tracking)     |         |  Management)   |
+----------------+         +----------------+         +----------------+
       |                          |                          |
       v                          v                          v
+----------------+         +----------------+         +----------------+
|   Guid_pid     |-------->|   Orthodrome   |-------->|    Alt2D       |
| (PID           |         | (Great Circle  |         | (2D Altitude   |
|  Controllers)  |         |  Path)         |         |  Management)   |
+----------------+         +----------------+         +----------------+
```

The data flow through these components is as follows:

1. **Route Management**:
   - `Patchsets` manages the route and waypoints
   - `Track` tracks the current path segment
   - `Orthodrome` computes the great circle path between waypoints

2. **Guidance Computation**:
   - `Guidance` computes the desired velocity and position
   - `Guid_pid` provides PID control for guidance
   - `Alt2D` manages altitude in 2D guidance mode

3. **Obstacle Avoidance**:
   - `Guidance::obstacle_avoidance` computes obstacle avoidance velocities
   - `Guidance::build_obstacle_slope` calculates obstacle effect distances

4. **Velocity Management**:
   - `Guidance::update_magnitude` manages velocity magnitude
   - `Guidance::apply_envelope` applies flight envelope constraints
   - `Guidance::update_aerodynamic_params` updates aerodynamic parameters

### 5.2 Key Workflows

#### 5.2.1 Path Following Workflow

1. **Path Initialization**:
   - `Orthodrome::on_focus` initializes the path
   - `Orthodrome::set` configures the start and end positions

2. **Path Tracking**:
   - `Orthodrome::compute2d` computes the closest point on the path
   - `Guidance::deviation` computes the desired velocity for path following

3. **Guidance Control**:
   - `Guidance::cruise_guidance` computes guidance for cruise mode
   - `Guidance::hover_guidance` computes guidance for hover mode
   - `Guid_pid::State::step` applies PID control to generate correction velocities

4. **Altitude Management**:
   - `Alt2D::step` manages altitude in 2D guidance mode
   - `Alt2D::apply_v_arcade` applies manual vertical control

#### 5.2.2 Obstacle Avoidance Workflow

1. **Obstacle Effect Distance Calculation**:
   - `Guidance::build_obstacle_slope` calculates the inverse of the distance at which obstacles affect guidance

2. **Obstacle Repulsion Field Computation**:
   - `obstacles.obstacle_deviation` computes the obstacle repulsion field

3. **Obstacle Avoidance Velocity Computation**:
   - `Guidance::obstacle_avoidance` computes the obstacle avoidance velocity
   - Adds repulsion and lateral velocity components to avoid obstacles

4. **Velocity Integration**:
   - The obstacle avoidance velocity is integrated with the path following velocity
   - The resulting velocity is bounded by the flight envelope

#### 5.2.3 Velocity Management Workflow

1. **Velocity Computation**:
   - `Guidance::cruise_guidance` or `Guidance::hover_guidance` computes the initial desired velocity

2. **Velocity Magnitude Update**:
   - `Guidance::update_magnitude` updates the velocity magnitude based on the control mode (IAS or ground speed)

3. **Flight Envelope Application**:
   - `Guidance::apply_envelope` applies flight envelope constraints to the velocity

4. **Acceleration Bounding**:
   - `env.bound_accel` applies acceleration bounds to the velocity

5. **Aerodynamic Parameter Update**:
   - `Guidance::update_aerodynamic_params` updates aerodynamic parameters for control

## 6. Key Algorithms and Mathematical Models

### 6.1 Cruise Guidance Algorithm

The cruise guidance algorithm computes a desired velocity vector that follows a path while avoiding obstacles:

1. **Line Attraction**:
   - Compute a desired velocity vector as a combination of the tangent vector and a correction proportional to the distance from the path:
     ```
     vf = t - kd * d
     ```
   - Where `t` is the tangent vector, `d` is the distance vector, and `kd` is the line attraction parameter

2. **Obstacle Avoidance**:
   - Apply obstacle avoidance to the desired velocity vector:
     ```
     vfp = vf + vfuo * vo + avlambda * uot
     ```
   - Where `vo` is the obstacle repulsion field, `vfuo` is the repulsion gain, and `uot` is a horizontal unit vector normal to `vo`

3. **PID Control**:
   - Apply PID control to generate correction velocities:
     ```
     pid_vc[u0] = npidst.step(hpid, d1[u0], pid_vc[u0], dt)
     pid_vc[u1] = epidst.step(hpid, d1[u1], pid_vc[u1], dt)
     pid_vc[u2] = dpidst.step(vpid, d1[u2], pid_vc[u2], dt)
     ```
   - Where `d1` is the vector from the UAV to the desired position

4. **Final Velocity Composition**:
   - Compose the final desired velocity as a combination of the path following velocity and the PID correction:
     ```
     vn0 = upc + pid_vc
     ```
   - Where `upc` is the normalized path following velocity

### 6.2 Hover Guidance Algorithm

The hover guidance algorithm computes a desired velocity vector that maintains a desired position:

1. **Position Error Calculation**:
   - Compute the vector from the UAV to the desired hover position:
     ```
     d1 = pos - uav.get_pos()
     ```

2. **PID Control**:
   - Apply PID control to generate correction velocities:
     ```
     pid_vc[u0] = npidst.step(hpid, d1[u0], pid_vc[u0], dt)
     pid_vc[u1] = epidst.step(hpid, d1[u1], pid_vc[u1], dt)
     pid_vc[u2] = dpidst.step(vpid, d1[u2], pid_vc[u2], dt)
     ```

3. **Obstacle Avoidance**:
   - Apply obstacle avoidance to the PID correction velocity:
     ```
     vn0 = pid_vc + vfuo * vo
     ```
   - Where `vo` is the obstacle repulsion field and `vfuo` is the repulsion gain

4. **Speed Limiting**:
   - Limit the speed to the configured cruise speed:
     ```
     if (nvn > v_cruise) {
         vn0.scale(v_cruise/nvn)
     }
     ```

### 6.3 Obstacle Avoidance Algorithm

The obstacle avoidance algorithm computes a velocity vector that avoids obstacles:

1. **Repulsion Gain Calculation**:
   - Compute the repulsion gain as the negative dot product between the normalized obstacle field and the desired velocity:
     ```
     vfuo = -vf.dot(vo)/nvo
     ```
   - If the gain is negative (moving away from obstacle), set it to zero

2. **Inside Obstacle Handling**:
   - If inside an obstacle (nvo > 1), add extra repulsion:
     ```
     vfuo += (Vcr*(nvo - 1) / nvo)
     ```

3. **Repulsion Application**:
   - Apply the repulsion to the velocity vector:
     ```
     vn = vf + vfuo * vo
     ```

4. **Lateral Velocity Addition** (for non-hover mode):
   - Compute a horizontal unit vector normal to the obstacle field:
     ```
     uot = (vo[u1], -vo[u0], 0)
     uot.normalize()
     ```
   - Compute lateral velocity factors and select the one with the lowest absolute value
   - Apply the lateral velocity:
     ```
     vn += avlambda * uot
     ```

### 6.4 Great Circle Path Computation

The great circle path computation algorithm calculates the shortest path between two points on Earth's surface:

1. **ECEF Coordinate Conversion**:
   - Convert start and end positions to ECEF coordinates:
     ```
     a0.get_ecef(u0)
     af.get_ecef(rf)
     ```

2. **Normal Vector Calculation**:
   - Compute the normal vector to the great circle plane:
     ```
     n.cross(u0, u1)
     ```

3. **Angle Calculation**:
   - Compute the angle between start and end points:
     ```
     thetaf = asin(sin_f)
     ```

4. **Closest Point Calculation**:
   - Compute the angle from the start point to the current position:
     ```
     theta = atan2(u1.dot(r), u0.dot(r))
     ```
   - Compute the closest point on the great circle:
     ```
     rc = ct * u0 + st * u1
     ```

5. **Tangent Vector Calculation**:
   - Compute the tangent vector at the closest point:
     ```
     te.cross(n, rc)
     ```

6. **Distance Vector Calculation**:
   - Compute the distance vector from the current position to the closest point:
     ```
     o.relthis(pos, d)
     ```

## 7. Referenced Context Files

The following context files provided valuable information for understanding the VPGNC framework:

1. **06_VPGNC_Core.md** - Provided overview of the VPGNC framework core components, including the Vpu class, Vpunav class, and variable management classes. This helped establish the broader context in which the guidance algorithms operate.

2. **05_VPGNC_Navigation.md** - Provided details on the navigation algorithms and state estimation components, which are essential inputs to the guidance system. Understanding how position, velocity, and attitude are estimated is crucial for understanding how guidance algorithms use this information.

These files helped establish the relationship between the guidance components analyzed in this document and the broader VPGNC framework, particularly regarding how navigation data feeds into guidance algorithms and how guidance commands are used by control systems.