# Generated from:

- _sw_Veronte/code/vpgnc/code/include/Point.h (535 tokens)
- _sw_Veronte/code/vpgnc/code/source/Point.cpp (355 tokens)
- _sw_Veronte/code/vpgnc/code/include/Line.h (950 tokens)
- _sw_Veronte/code/vpgnc/code/source/Line.cpp (912 tokens)
- _sw_Veronte/code/vpgnc/code/include/Arc.h (1681 tokens)
- _sw_Veronte/code/vpgnc/code/source/Arc.cpp (3762 tokens)
- _sw_Veronte/code/vpgnc/code/include/Arcaxis.h (268 tokens)
- _sw_Veronte/code/vpgnc/code/source/Arcaxis.cpp (534 tokens)
- _sw_Veronte/code/vpgnc/code/include/Arcxset.h (337 tokens)
- _sw_Veronte/code/vpgnc/code/source/Arcxset.cpp (140 tokens)
- _sw_Veronte/code/vpgnc/code/include/Leg.h (1048 tokens)
- _sw_Veronte/code/vpgnc/code/source/Leg.cpp (1954 tokens)
- _sw_Veronte/code/vpgnc/code/include/Route.h (495 tokens)
- _sw_Veronte/code/vpgnc/code/source/Route.cpp (436 tokens)
- _sw_Veronte/code/vpgnc/code/include/Track.h (2348 tokens)
- _sw_Veronte/code/vpgnc/code/source/Track.cpp (4133 tokens)
- _sw_Veronte/code/vpgnc/code/include/Track_fw.h (21 tokens)
- _sw_Veronte/code/vpgnc/code/include/Gtrack.h (2711 tokens)
- _sw_Veronte/code/vpgnc/code/source/Gtrack.cpp (3048 tokens)
- _sw_Veronte/code/vpgnc/code/include/Gtrack_fw.h (22 tokens)
- _sw_Veronte/code/vpgnc/code/include/Gtrackcfg.h (596 tokens)
- _sw_Veronte/code/vpgnc/code/source/Gtrackcfg.cpp (443 tokens)
- _sw_Veronte/code/vpgnc/code/include/Gtrackcfg_fw.h (28 tokens)
- _sw_Veronte/code/vblocks/code/include/Blk_gtrackcfg.h (1439 tokens)

## With context from:

- PackageSummaries/Embention/Amazon-PrimeAir/items/ASTRO/items/sw/sw_Astro/items/06_VPGNC_Core.md (7671 tokens)
- PackageSummaries/Embention/Amazon-PrimeAir/items/ASTRO/items/sw/sw_Astro/items/04_VPGNC_Guidance.md (12551 tokens)

---

# Waypoint Navigation and Path Management System in VPGNC Framework

This document provides a comprehensive analysis of the waypoint navigation and path management system in the VPGNC framework, focusing on how navigation curves (Point, Line, Arc) are implemented and used for path following, along with the Track and Gtrack classes for track management, the Route class for route management, and the Gtrackcfg class for guidance track configuration.

## 1. Navigation Curves: Core Path Primitives

The VPGNC framework implements path following using three fundamental curve types: Point, Line, and Arc. These classes all inherit from the `Icurve` interface, which defines the common functionality for path following.

### 1.1 Icurve Interface

The `Icurve` interface defines the common methods that all curve types must implement:

```cpp
class Icurve {
public:
    struct On_focus_out {
        Geo::Apos p0;           // Initial position of the curve
        Maverick::Irvector3 t0; // Initial tangent vector
        Base::Feature f0;       // Feature ID of the initial position
        Base::Feature f1;       // Feature ID of the final position
    };

    virtual bool hoverable() const;
    virtual void on_focus(const Geo::Apos& pos, const Maverick::Irvector3& v0, On_focus_out& out);
    virtual void compute(const Geo::Apos& pos, Maverick::Irvector3& d, Maverick::Irvector3& t, Base::Curvst& st);
    virtual void compute2d(const Geo::Apos& pos, Maverick::Irvector3& d, Maverick::Irvector3& t, Base::Curvst& st);
};
```

Key methods:
- `hoverable()`: Returns whether the curve supports hovering
- `on_focus()`: Initializes the curve when it becomes active
- `compute()`: Computes the distance and tangent vectors for 3D path following
- `compute2d()`: Computes the distance and tangent vectors for 2D path following

### 1.2 Point Class: Hoverable Waypoint

The `Point` class implements a single waypoint that the vehicle can hover over.

#### 1.2.1 Member Variables

```cpp
Geo::Fidposcache point_pos;  // Handler to compute the position of the point
```

The `Fidposcache` class caches the position of a feature (waypoint) and provides methods to refresh and access it.

#### 1.2.2 Key Methods

```cpp
void Point::set(const Spatchset::Patchdata& pnt0) {
    point_pos.set(pnt0.f0);
}

void Point::on_focus(const Geo::Apos& pos, const Irvector3& v0, On_focus_out& out) {
    point_pos.refresh();
    out.p0.copynr(point_pos.get_pos());
    out.f0 = Base::Feature::build_rel(point_pos.get());
    out.f1 = out.f0;
}

void Point::compute(const Geo::Apos& pos, Irvector3& d, Irvector3& t, Base::Curvst& st) {
    point_pos.refresh();
    point_pos.get_pos().relthis_drn(pos, d);
    // Point is achieved on 1st step (smooth will make UAV get the point).
    // Point is hold as current curve when there is no next curve.
    // t is preferable to be not modified, so that (arcade) axis based on t do not get random when
    // hovering over point.
    // On hoverable platforms, t is not used on Guidance::deviation.
    // On non hoverable platforms, behavior will be like "loiter", around the point.
    // Fixed t does not make a big change.
    st.set(1.0F, 1.0F, 1.0F, 1.0F, 0.0F);
}

bool Point::hoverable() const {
    return true;
}
```

The `Point` class:
1. Stores a single position
2. Computes the distance vector from the current position to the point
3. Sets the curve state to indicate the point is achieved
4. Indicates it supports hovering

### 1.3 Line Class: Straight Line Path

The `Line` class implements a straight line path between two waypoints.

#### 1.3.1 Member Variables

```cpp
Geo::Fidposcache start_pos;   // Handler to compute the start position of the line
Geo::Fidposcache end_pos;     // Handler to compute the end position of the line
```

#### 1.3.2 Key Methods

```cpp
void Line::set(const Spatchset::Patchdata& lin0) {
    start_pos.set(lin0.f0);
    end_pos.set(lin0.next_f0);
}

void Line::on_focus(const Geo::Apos& pos, const Irvector3& v0, On_focus_out& out) {
    refresh_wp();
    const Geo::Apos& cwp = end_pos.get_pos();
    const Geo::Apos& prv = start_pos.get_pos();
    out.p0.copynr(prv);
    prv.relthis_drn(cwp, out.t0);
    out.t0.norm2alize();
    out.f0 = Base::Feature::build_rel(start_pos.get());
    out.f1 = Base::Feature::build_rel(end_pos.get());
}

void Line::compute(const Geo::Apos& pos, Irvector3& d, Irvector3& t, Base::Curvst& st) {
    refresh_wp();
    const Geo::Apos& cwp = end_pos.get_pos();
    const Geo::Apos& prv = start_pos.get_pos();
    prv.relthis_drn(pos, d);
    prv.relthis_drn(cwp, t);
    compute0(d, t, d, t, st.u, st.umax);
    st.set(st.u, st.umax, st.u, st.umax, 0.0F);
}

void Line::compute0(const Maverick::Irvector3& r0pos,
                    const Maverick::Irvector3& r01,
                    Maverick::Irvector3& d,
                    Maverick::Irvector3& t,
                    Real& s,
                    Real& smax) {
    // Implementation allows input and output parameters to be the same reference
    d.copy(r0pos);
    t.copy(r01);
    smax = t.norm2();
    if(smax > 0) {
        t.scale(Const::ONE/smax);
    }
    s = d.dot(t);
    Rvector3 x;
    if((s > 0) && (s < smax)) {
        x.copy(t);
        x.scale(s);
    } else {
        if(s <= 0) {
            x.zeros();
        } else {
            x.copy(t);
            x.scale(smax);
        }
    }
    d.vecsub(x);
}
```

The `Line` class:
1. Stores start and end positions
2. Computes the tangent vector as the normalized vector from start to end
3. Computes the closest point on the line to the current position
4. Calculates the distance vector from the closest point to the current position
5. Sets the curve state based on progress along the line

### 1.4 Arc Class: Curved Path

The `Arc` class implements a curved path defined by a circular arc.

#### 1.4.1 Member Variables

```cpp
Geo::Fidposcache start_pos;  // Handler to compute the start position of the arc
Geo::Fidposcache end_pos;    // Handler to compute the end position of the arc
Arcparams params;            // Arc specific parameters (rk vector and number of turns)
```

The `Arcparams` structure contains:
- `rk`: A 2D vector that defines the control point of the arc
- `nturns`: Number of complete turns to make around the arc

#### 1.4.2 Key Methods

```cpp
void Arc::set(const Spatchset::Patchdata& arc0) {
    start_pos.set(arc0.f0);
    end_pos.set(arc0.next_f0);
    params = arc0.cfg.type_cfg.arc;
}

void Arc::on_focus(const Geo::Apos& pos, const Irvector3& v0, On_focus_out& out) {
    refresh_wp();
    const Geo::Apos& apos0 = start_pos.get_pos();
    out.p0.copynr(apos0);

    Rvector3 r01;
    apos0.relthis_drn(end_pos.get_pos(), r01);

    Rvector3 r02(params.rk[0], params.rk[1], 0);
    r02.lincmb_add(Const::ONEHALF, r01);

    Rvector3 rc0;
    Real angle0 = 0.0F;
    Real angle = 0.0F;
    Real R = 0.0F;
    compute0(r01, r02, rc0, angle0, angle, R);

    Real sp = Rmath::sinr(angle0);
    Real cp = Rmath::cosr(angle0);

    if(angle > 0) {
        out.t0[Ku16::u0] = -sp;
        out.t0[Ku16::u1] = cp;
    } else {
        out.t0[Ku16::u0] = sp;
        out.t0[Ku16::u1] = -cp;
    }
    out.t0[Ku16::u2] = r01[Ku16::u2]/fabsr(R*angle);

    out.t0.norm2alize();
    out.f0 = Base::Feature::build_rel(start_pos.get());
    out.f1 = Base::Feature::build_rel(end_pos.get());
}

void Arc::compute2d(const Geo::Apos& pos, Irvector3& d, Irvector3& t, Base::Curvst& st) {
    refresh_wp();
    const Geo::Apos& apos0 = start_pos.get_pos();
    Rvector3 r01;
    apos0.relthis_drn(end_pos.get_pos(), r01);

    Rvector3 r02(params.rk[0], params.rk[1], 0);
    r02.lincmb_add(Const::ONEHALF, r01);
    r02[Maverick::Irvector3::vz] = 0;

    Rvector3 rc0;
    Real angle0 = 0.0F;
    Real angle = 0.0F;
    Real R = 0.0F;
    if(compute0(r01, r02, rc0, angle0, angle, R)) { // false on null arc singularity
        // compute curve
        apos0.relthis_drn(pos, d);   // r0 to pos
        d.vecadd(rc0);          // rc to pos

        Real sp = 0.0F;
        Real cp = 0.0F;

        Real angle1 = 0.0F;
        d.azeld(angle1, sp, cp);
        Real u_signed = (angle > 0) ? (st.u) : (-st.u); // has not sign in st
        u_signed += Rfun::wrap2pi(angle1-(u_signed+angle0)); // unwrap
        if((angle*u_signed) < 0) {
            u_signed = 0;
            angle1 = angle0;
        } else if(((angle < 0) && (u_signed < angle)) || ((angle > 0) && (u_signed > angle))) {
            u_signed = angle;
            angle1 = angle0 + angle;
        }
        sp = Rmath::sinr(angle1);
        cp = Rmath::cosr(angle1);

        Rvector3 x; // projection inside arc from center
        x[Ku16::u0] = R*cp;
        x[Ku16::u1] = R*sp;
        x[Ku16::u2] = r01[Ku16::u2]*u_signed/angle;

        t[0] = -sp;
        t[1] = cp;

        Real t2_t01 = r01[2]/fabsr(R*angle);     // value of t2 before normalize, with current t0, t1
        Real r_cose = R*sqrtr(1+t2_t01*t2_t01);  // radius divided by cosine of elevation of t

        if(angle < 0) {
            t.signinv();
            st.set(-r_cose*u_signed, -r_cose*angle, -u_signed, -angle, -1.0F/R);
        } else {
            st.set(r_cose*u_signed, r_cose*angle, u_signed, angle, 1.0F/R);
        }

        t[Ku16::u2] = t2_t01;
        t.norm2alize();

        d.vecsub(x);
    } else {
        st.set_achieved(); //null arc, make arc to be achieved on first step
    }
}

bool Arc::compute0(const Irvector3& r01,
                   const Irvector3& r02,
                   Irvector3& rc0,
                   Real& angle0,
                   Real& angle,
                   Real& radio) const {
    // compute angle wrapped to +/-pi
    Rvector3 r21;
    r21.vecres(r01, r02);
    Real az02 = atan2r(r02[1], r02[0]);
    Real az21 = atan2r(r21[1], r21[0]);
    angle = Ku16::u2*Rfun::wrap2pi(az21-az02); // diff angle of rc0 to rc1 (end-start angle)

    // compute angle0, radio
    Real d01 = r01.norm2xy();

    bool ret = true;

    if(d01 <= eps_dist) { // r01 is null vector, compute circunference using r02 as diameter
        Real d21 = r21.norm2xy();
        if(d21 <= eps_dist) { // avoid 3 points of arc in same location singularity
            ret = false;
        } else {
            angle0 = r21.azimuth();
            radio = Const::ONEHALF*d21;
            angle = (angle >= 0) ? (Const::PI2) : (-Const::PI2);
        }
    } else if(angle >= 0) {
        if(angle < eps_angle) { // avoid infinite radio
            angle = eps_angle;
        }
        radio = Const::ONEHALF*d01/sinr(Const::ONEHALF*angle);
        angle0 = r01.azimuth() - Const::ONEHALF*angle - Const::PI05; // azimuth from center to f0
    } else {
        if(angle > -eps_angle) { // avoid infinite radio
            angle = -eps_angle;
        }
        radio = -Const::ONEHALF*d01/sinr(Const::ONEHALF*angle);
        angle0 = r01.azimuth() - Const::ONEHALF*angle + Const::PI05; // azimuth from center to f0
    }

    if(ret) {
        angle0 = Rfun::wrap2pi(angle0);

        // compute center
        rc0.azeld_1(angle0, 0, radio);

        // sum turns
        angle += Const::PI2*((angle > 0) ? static_cast<Real>(params.nturns) : -static_cast<Real>(params.nturns));
    }

    return ret;
}
```

The `Arc` class:
1. Stores start and end positions, plus arc parameters
2. Computes the center, radius, and angles of the arc
3. Calculates the closest point on the arc to the current position
4. Computes the tangent vector at this point
5. Sets the curve state based on progress along the arc
6. Includes helper methods for arc geometry calculations

### 1.5 Helper Classes for Arc Geometry

The `Arc` class includes several helper methods for arc geometry calculations:

```cpp
static void compute_line_circle(const Maverick::Irvector3& r0,    // initial point of line
                                const Maverick::Irvector3& r1,    // final point of arc
                                Real az1,               // tangent on r1
                                Real radio,             // radio of arc
                                Maverick::Irvector3& rc1,         // center
                                Maverick::Irvector3& rx,          // join point line-arc
                                Maverick::Irvector3& rk,          // control point
                                Real& angle);           // angle of arc covered

static void compute_circle_circle(const Maverick::Irvector3& r1c,
                                  const Maverick::Irvector3& r4a,
                                  const Maverick::Irvector3& ur,
                                  const Real azur,
                                  const Real r1,
                                  const Real r3,
                                  Maverick::Irvector3& r3c,
                                  Maverick::Irvector3& r2a,
                                  Maverick::Irvector3& r3a,
                                  Maverick::Irvector3& rk,
                                  Real& angle);

static bool compute_center(const Maverick::Irvector3& r10,
                           Real az1,
                           Real radio,
                           Maverick::Irvector3& rc1,
                           Real& azc1);

static void compute_arc(Real az0,
                        const Maverick::Irvector3& rc1,
                        Real radio,
                        bool cw,
                        Maverick::Irvector3& rc0,
                        Maverick::Irvector3& rck,
                        Real& angle);

static Real compute_az_tangent(const Maverick::Irvector3& rc0,
                               Real radio,
                               bool cw);
```

These methods provide functionality for:
1. Computing a smooth transition from a line to a circle
2. Computing a smooth transition between two circles
3. Computing the center of an arc given a point, tangent direction, and radius
4. Computing an arc given start angle, center, radius, and direction
5. Computing the tangent to a circle at a given point

## 2. Arcade Axis System for Manual Control

The VPGNC framework includes an arcade axis system that allows manual control inputs to be integrated with automated path following.

### 2.1 Arcaxis Class: Single Axis Definition

The `Arcaxis` class defines a single arcade axis with a reference direction and offset.

#### 2.1.1 Member Variables

```cpp
enum Reference {
    ref_yaw     = 0,    // Current yaw
    ref_fixed   = 1,    // Fixed azimuth
    ref_feature = 2,    // Direction to some point
    ref_hdg     = 3,    // Current heading
    ref_hdgc    = 4,    // Current desired heading
    ref_rtg     = 5,    // Route tangent direction
    ref_yawc    = 6,    // Current desired yaw
};

Reference ref;          // Reference direction
Real offset;            // Angle offset
Geo::Frefcache f;       // Feature reference (for ref_feature)
```

#### 2.1.2 Key Methods

```cpp
void Arcaxis::refresh() {
    if(ref == ref_feature) {
        f.refresh();
    }
}

Real Arcaxis::get_angle_axis0(const Dynamics::Rigidbody& uav, const Guidance& uavc) const {
    Real axis_angle = 0;
    switch(ref) {
        case ref_fixed:
            axis_angle = 0;
            break;
        case ref_yaw:
            axis_angle = uav.get_ypr()[0];
            break;
        case ref_yawc:
            axis_angle = uavc.get_ypr()[0];
            break;
        case ref_hdg:
            axis_angle = uav.get_vhfb()[0];
            break;
        case ref_hdgc:
            axis_angle = uavc.get_vhfb()[0];
            break;
        case ref_feature:
            Maverick::Rvector3 aux;
            uav.get_pos().relthis(f.get_pos(), aux);
            axis_angle = aux.azimuth();
            break;
        case ref_rtg:
            const Maverick::Irvector3& t = uavc.get_track().get_tangent();
            axis_angle = t.azimuth();
            break;
    }
    return Rfun::wrap2pi(offset + axis_angle);
}
```

The `Arcaxis` class:
1. Defines different reference directions for an arcade axis
2. Computes the axis angle based on the selected reference
3. Applies an offset to the computed angle

### 2.2 Arcxset Class: Arcade Axis Set

The `Arcxset` class manages a set of arcade axes for manual control.

#### 2.2.1 Member Variables

```cpp
static const Uint16 cfg_sz = 5;     // Maximum number of configurable arcade axis
const Dynamics::Rigidbody& uav;     // Reference to uav state
const Guidance& uavc;               // Reference to desired uav state
Base::Tunarray<Arcaxis> cfg;        // List of axis configurations
```

#### 2.2.2 Key Methods

```cpp
void Arcxset::refresh() {
    for(Uint16 i = 0; i < cfg.size(); ++i) {
        if(cfg.is_enabled(i)) {
            cfg[i].refresh();
        }
    }
}

Real Arcxset::get_angle_axis0(Uint16 idx) const {
    return cfg.is_enabled(idx) ? cfg[idx].get_angle_axis0(uav, uavc) : 0;
}

Base::Ideserializable& Arcxset::build_cfg_arcx() {
    return Base::Tunbuild::build_des(cfg);
}
```

The `Arcxset` class:
1. Manages a set of up to 5 arcade axes
2. Provides methods to refresh and access the axes
3. Builds a configuration interface for the axes

## 3. Leg Class: Landing/Climbing Path Segments

The `Leg` class implements path segments for landing and climbing operations, with support for loiter patterns.

### 3.1 Member Variables

```cpp
struct Cfg {
    Geo::Rwymgr::Id osid;               // Opsite identifier in Rwymgr list
    Base::Vref td;                      // touch direction (2D)
    Base::Fref loipos;                  // Loides reference position
    bool loipos_is_center;              // true if position means center, false when it belongs to circle
    Oprvar dxy;                         // horizontal distance for descending
    Oprvar taxi_ext;                    // Horizontal taxi extension at 5a touching point
    Oprvar radius3;                     // Radius of head turn
    Oprvar R1;                          // Radius of helix
};

// work variables
Maverick::Rvector3 r0a;                 // current position wrt touch point (Approach)
Maverick::Rvector3 r1a;                 // Loi arc extreme
Maverick::Rvector3 r1c;                 // Loi arc center
Maverick::Rvector3 r2a;                 // meet start
Maverick::Rvector3 r3a;                 // head start (wrt r3c)
Maverick::Rvector3 r3c;                 // head center
Maverick::Rvector3 r4a;                 // initial point for descending wrt touch point
Maverick::Rvector3 r5b;                 // descend extension wrt touch point

static const Uint16 nwpoints = 5U;      // Number of waypoints
Base::Tnarray<Real,nwpoints> len;       // Length of each patch over the horizontal plane

Geo::Frefcache loipos;                  // Loides reference position
```

### 3.2 Key Methods

```cpp
void Leg::compute_xscend(const Leg::Cfg& c, const Maverick::Irvector3& ur) {
    const Real dxyv = c.dxy.get();
    const Real d2 = c.taxi_ext.get();
    r4a.lincmb(-dxyv, ur);
    r5b.lincmb(d2, ur);
    len[Ku8::u4] = dxyv;
}

void Leg::compute_head(const Leg::Cfg& c, const Maverick::Irvector3& ur, Maverick::Irvector3& rk) {
    // Compute head in case no loiter
    const Real R3v = c.radius3.get();
    const Real Az = ur.azimuth();
    Real angle = Const::ZERO;
    Arc::compute_line_circle(r0a, r4a, Az, R3v, r3c, r3a, rk, angle);

    const Real R1v = c.R1.get();
    if (!c.loipos_is_center) {
        Arc::compute_line_circle(r2a, r4a, Az, R3v, r3c, r3a, rk, angle);

        Rvector3 aux;
        aux.vecres(r2a, r3a);
        Rvector3 drc;
        drc[Rvector3::vx] = -aux[Rvector3::vy];
        drc[Rvector3::vy] = aux[Rvector3::vx];
        drc[Rvector3::vz] = Const::ZERO;
        drc.norm2alize();
        drc.scale(R1v);

        // aux vector is reused here
        aux.vecres(r0a, r3a);
        if (drc.dot(aux) < Const::ZERO) {
            drc.signinv();
        }
        r1c.vecsum(r2a, drc);
    } else {
        Arc::compute_circle_circle(r1c, r4a, ur, Az, R1v, R3v, r3c, r2a, r3a, rk, angle);
    }
    len[Ku16::u3] = Rmath::fabsr(angle)*R3v;
    Rvector3 r3a_r2a;
    r3a_r2a.vecres(r2a, r3a);
    len[Ku16::u2] = r3a_r2a.norm2xy();
}

void Leg::compute_loix(const Leg::Cfg& c, const bool climb, Maverick::Irvector3& rk) {
    // Compute direction of loix spin (clockwise/counterclockwise)
    Rvector3 rc1;
    rc1.vecres(r2a, r1c); // Vector from loix center to arc end
    Rvector3 t;
    t.vecres(r3a, r2a);   // Vector from arc end with tangent direction
    Rvector3 spin;
    spin.cross(rc1, t);   // Loix spin vector
    const bool loix_clockwise = (spin[Rvector3::vz] > Const::ZERO); // Clockwise is direction down positive

    const Real R1v = c.R1.get();
    Rvector3 rc0;
    rc0.vecres(r0a, r1c); // vector from loix center to uav
    Real azc1a = Arc::compute_az_tangent(rc0, R1v, loix_clockwise); // start azimuth

    Real angle = Const::ZERO;
    Arc::compute_arc(azc1a, rc1, R1v, loix_clockwise, r1a, rk, angle);
    // at this point, r1a is center to start of arc
    r1a.vecadd(r1c); // now, r1a is not referenced by center

    // Compute lengths
    len[Ku16::u1] = Rmath::fabsr(angle)*R1v;
    if (climb) {
        // In climb there is no final 1a-0a segment
        r0a.copy(r1a);
        len[Ku16::u0] = Const::ZERO;
    } else {
        Rvector3 r1a_r0a;
        r1a_r0a.vecres(r0a, r1a);
        len[Ku16::u0] = r1a_r0a.norm2xy();
    }
}

void Leg::compute_heights_landing(const Leg::Cfg& c,
                                  const Real tfpa0,
                                  const Real tfpa1,
                                  const Real tfpa2_3,
                                  const Real tfpa4,
                                  Uint16& nloops) {
    // Assign heights
    r5b[Rvector3::vz] = Const::ZERO;
    r4a[Rvector3::vz] = len[Ku16::u4]*tfpa4;
    r3a[Rvector3::vz] = r4a[Rvector3::vz] + len[Ku16::u3]*tfpa2_3;
    r3c[Rvector3::vz] = r3a[Rvector3::vz];
    r2a[Rvector3::vz] = r3a[Rvector3::vz] + len[Ku16::u2]*tfpa2_3;

    //Compute aprox to loiter.
    //Check if calculated tfpa can not be reached so we use the maximum stablished.
    r1a[Rvector3::vz] = r2a[Rvector3::vz];

    Real tfpa_calc = (r0a[Rvector3::vz] - r1a[Rvector3::vz]) / len[Ku16::u0];

    if (Rfun::wrap(-Rmath::fabsr(tfpa0), Rmath::fabsr(tfpa0), tfpa_calc, tfpa_calc)) {
        r1a[Rvector3::vz] = r0a[Rvector3::vz] - len[Ku16::u0]*tfpa_calc;
    }

    compute_n_loops(c, tfpa1, nloops);

    //Assign loiter center height.
    r1c[Rvector3::vz] = r1a[Rvector3::vz];
}

void Leg::compute_n_loops(const Leg::Cfg& c,
                          const Real tfpa1,
                          Uint16& nloops) {
    //Calculate number of loops for loiter.
    //Eq: n = abs(Deltah / (Ln * tfpa1)) - (L0 * (tfpa1))/(Ln * (tfpa1)).
    //Deltah = altitude step; Ln = loiter arc length; L0 = partial arc length;
    //Ceil for rounding number of laps, always up.

    const Real lap_len = Const::PI2 * c.R1.get(); // Horizontal length of one lap in loiter R1.

    nloops = static_cast<Uint16>(Rmath::ceilr(Rmath::fabsr(
            (r2a[Rvector3::vz] - r1a[Rvector3::vz])/(lap_len*tfpa1)) - len[Ku16::u1]/lap_len));
    len[Ku16::u1] += static_cast<Real>(nloops)*lap_len;  //Add loiter distance based on number of laps needed
}
```

The `Leg` class:
1. Defines a complex path for landing or climbing operations
2. Computes the geometry of the path segments
3. Calculates heights for each segment based on flight path angles
4. Determines the number of loiter loops needed for altitude changes

## 4. Track Class: Path Tracking Management

The `Track` class manages path tracking, selecting the appropriate path segment to follow and computing guidance parameters.

### 4.1 Member Variables

```cpp
enum Ps {
    ps_approach   = 0,
    ps_climb      = 1,
    ps_route      = 2,
    ps_taxi       = 3,
    ps_vtol       = 4,
    ps_rendezvous = 5,
    ps_detour     = 6  // Detour shall always be the last because it is used as number of Gtracks
};

enum Stage {
    stg_off          = 0,
    stg_routing      = 1,
    stg_cmd          = 3,
};

const Guidance& uavc;
Alt2D a2d;                       // Guidance altitude in 2D mode
Patchset::Prjtype prj;           // Projection type
Detour cmd;                      // Track command (loiter, flyto...)
Base::Evar<Stage> stg;           // Current stage
bool flyroute;                   // If true, we need to fly to the route (we are not on it)
bool flyto_closest;              // If true, we have to fly to the closest patch of the route

Maverick::Rvector3 d;            // Deviation wrt curve
Maverick::Rvector3 t;            // Along-track unit-vector tangent to curve at x and expressed in NED at x
Bsp::Hrvar hpath_tangent_az;     // Handler to publish the azimuth of the tangent to the route
Bsp::Hrvar hpath_tangent_el;     // Handler to publish the elevation of the tangent to the route
Bsp::Hfvar hxabs;                // Handler to publish nearest curve position (assumed absolute)
Bsp::Hfvar hwp0;                 // Handler to publish start waypoint of current curve
Bsp::Hfvar hwp1;                 // Handler to publish end waypoint of current curve

Base::Trackst tst;               // Track state
Bsp::Huvar uv_psid;              // Current patchset id
Bsp::Hrvar rv_s;                 // arc-parameter within curve (m)
Bsp::Hrvar rv_smax;              // s where curve ends
Bsp::Hrvar rv_u;                 // nominal parameter curve (curve dependent units)
Bsp::Hrvar rv_umax;              // u where curve ends
Bsp::Hrvar rv_s2ach;             // Distance to achieve
Bsp::Hrvar rv_u2ach;             // Curve parameter to achieve
Bsp::Hrvar rv_hc;                // Horizontal curvature
Bsp::Hbvar hvr;                  // Handler for hovering bit
Bsp::Hbvar bv_finished;          // Handler for the patchset finished bit
```

### 4.2 Key Methods

```cpp
void Track::reset() {
    stg.set(stg_off);
    hvr.set(false);
    cmd.reset();
    tst.cst.reset();
    refresh_vars();
    uv_psid.set(Base::Patchid::invalid_patchset);
    flyroute = false;
}

bool Track::step(const Gtrackcfg& gcfg, const Envelope& env, Patchset& route) {
    Patchset& path = compute_stg(env.hover_on_point(), route);
    const Geo::Apos& pos = uavc.get_pos();
    path.path_compute(gcfg.pcfg, pos, d, t);
    tst = path.get_tst();
    refresh_vars();
    bv_finished.set(path.is_finished());
    prj = path.get_prj();
    a2d.step(prj == Patchset::prj_2d, uavc, d, t);
    hpath_tangent_az.set(Rmath::atan2r(t[1], t[0]));
    hpath_tangent_el.set(Rmath::atan2r(-t[Ku16::u2], t.norm2xy()));
    hxabs.set(uavc.get_pos().frelthis(Rvector3(-d[Ku16::u0], -d[Ku16::u1], -d[Ku16::u2])));
    hwp0.set(path.get_on_focus_data().f0);
    hwp1.set(path.get_on_focus_data().f1);
    return path.hoverable();
}

Patchset& Track::compute_stg(const bool hvr_permitted, Patchset& route) {
    const Stage stg0 = stg.get();
    bool commanding = stg0 == stg_cmd;
    const bool running = stg0 != stg_off;

    // stage transitions
    if (flyroute && (route.is_closest_found() || (!flyto_closest))) {
        cmd.set_flyroute_start(route, flyto_closest);
        flyroute = false;
    }

    Patchset& current_ps = cmd.is_active() ? cmd : route;

    if (!current_ps.current_check()) {
        cmd.set_no_patch(hvr_permitted);
    }

    bool commanding_next = cmd.is_active();
    bool cmd_changed = cmd.is_compute_pending() && (commanding || commanding_next);
    commanding = commanding_next;
    Patchset& ps = commanding ? cmd : route;
    
    if(!running) {
        a2d.reset();
        ps_on_focus(ps);
    } else if(cmd_changed) {
        ps_on_focus(ps);
    } else if(ps.is_patch_changed()) {
        ps.clear_patch_changed(); // Change accounted
        ps_on_focus(ps);
    } else if(ps.get_tst().cst.is_achieved()) {
        if(ps.flyto_next()) { // false when there is no next
            ps_on_focus(ps);
        }
    }
    
    const bool hover_nok = (ps.hoverable() && (!hvr_permitted));
    if (hover_nok) {
        cmd.set_no_patch(hvr_permitted);
        ps_on_focus(cmd);
        commanding = true;
    }
    
    stg.set(commanding ? stg_cmd : stg_routing);
    return hover_nok ? cmd : ps;
}

void Track::ps_on_focus(Patchset& ps) const {
    ps.on_focus(uavc.get_pos(), uavc.get_vn());
}

void Track::refresh_vars() {
    rv_s2ach.set(tst.cst.sdist2achieve());
    rv_u2ach.set(tst.cst.udist2achieve());
    rv_s.set(tst.cst.s);
    rv_smax.set(tst.cst.smax);
    rv_u.set(tst.cst.u);
    rv_umax.set(tst.cst.umax);
    rv_hc.set(tst.cst.hc);
    uv_psid.set(tst.current.patchset_id);
}

void Track::set_arc(const bool hconnected,
                    const Real fv,
                    const Real lv,
                    const bool vconnected,
                    const Real dv) {
    if (hconnected) {
        cmd.set_arc(fv, lv);
    }
    if (vconnected && (prj == Patchset::prj_2d)) {
        a2d.set_arc(dv);
    }
}

bool Track::dist2achieve(Real& d) const {
    bool result = (stg.get() != stg_off);
    if(result) {
        d = rv_s2ach.get();
    }
    return result;
}

void Track::set_speed_cmd(const Speedcmd& speed_cmd) {
    cmd.set_speed_cmd(speed_cmd);
}

const Speedcmd& Track::get_speed_cmd() const {
    return cmd.get_speed_cmd();
}

void Track::set_cane(const Loiter_data& data) {
    cmd.set_cane(data);
}

void Track::set_hover(const Hover_data& data) {
    cmd.set_hover(data);
}
```

The `Track` class:
1. Manages the current path tracking state
2. Selects the appropriate path segment to follow
3. Computes guidance parameters for the selected path
4. Handles transitions between different path segments
5. Manages special commands like loiter and hover
6. Updates system variables with path tracking information

## 5. Route Class: Route Management

The `Route` class manages a route, which is a sequence of waypoints and path segments.

### 5.1 Member Variables

```cpp
struct Cfg : public Patchsetcfg {
    Cfg();
    void step();
    void cset(Base::Lossy_error& str);
    void operation_check(Base::Error& err) const;
};

Tpatchset& route;  // Reference to route
Tunpatchset tun;   // Tunable route
```

### 5.2 Key Methods

```cpp
Route::Route(Tpatchset& route0,
             const Vpunav& uav0,
             Base::Patchid& last_achieved0,
             Airframe_action_wp_publish& aac_publish0):
        Patchset(route0,
                 last_achieved0,
                 Track::ps_route,
                 Patchset::prj_2d5,
                 Patchset::prj_2d_allowed | Patchset::prj_2d5_allowed | Patchset::prj_3d_allowed,
                 aac_publish0),
        route(route0),
        tun(route0)
{
    uchanged.set(0U);
}

Base::Async_sres Route::cset(Base::Lossy_error& str) {
    const int16 prev_first = route.get_first();
    Base::Async_sres res = tun.cset(str);
    if(res == Base::asyncs_done) {
        if(prev_first != route.get_first()) {
            refresh_first();
        }
        refresh_current();
        set_patch_changed();
        uchanged.set(uchanged.get() + 1U); // Set approach patchset as updated
    }
    return res;
}
```

The `Route` class:
1. Inherits from `Patchset` to provide route management functionality
2. Manages a sequence of waypoints and path segments
3. Handles route configuration changes
4. Updates system variables when the route changes

## 6. Gtrack Class: Guidance Track Management

The `Gtrack` class manages guidance track operations, coordinating between route following and special maneuvers.

### 6.1 Member Variables

```cpp
const Vpunav& uav;                // UAV navigation data
Guidance& uavc;                    // UAV guidance data
Track& track;                      // Guidance manager to manage detours from the main route
Patchset& route;                   // Set of curves
Bsp::Hbvar hhvr;                   // Handler to publish the hovering state
bool track_reset;                  // True if track shall be reset in the next step

Fly_to_operation_cmd flyto_operation_cmd;  // Manager for operation flyto commands
Fly_to_setup_cmd flyto_setup_cmd;          // Manager for setup flyto commands
// Map from setup fly to commands to actual waypoints
Base::Twrapdes<Base::Tuntraits::Desdefault<Base::Tunarray<Base::Tdes<int16> > > > map;

struct Des_speed {
    Dynamics::Aircraft::Tspeed type;  // Type of speed
    Real vlink;                       // Between waypoints speed
    Real v;                           // Current desired speed having into account waypoint reach
};
```

### 6.2 Key Methods

```cpp
void Gtrack::on_focus(const Gtrackcfg& gcfg,
                      const bool gstart,
                      const bool gtrack_prev) {
    if (gcfg.do_flyto) {
        fly_to_setup_wp(gcfg.flyto_patch);
    }

    track.set_speed_cmd(gcfg.spdcmd);
    track.set_arclim(gcfg.harclim, gcfg.varclim); // Arcade position/speed transition limits
    route.request_prj(static_cast<Patchset::Prjtype>(gcfg.prj));

    route.calculate(gcfg);

    if (gstart) {
        track_reset = true;
    }
    if (!gtrack_prev) {
        uavc.reset_guidance(true);
    }
}

void Gtrack::step(const Gtrackcfg& gcfg, const Envelope& env) {
    track.set_arc(gcfg.fv.is_connected() || gcfg.lv.is_connected(),
                  gcfg.fv.read(0.0F),
                  gcfg.lv.read(0.0F),
                  gcfg.dv.is_connected(),
                  gcfg.dv.read(0.0F));

    route.compute_closest(uav.get_pos());

    if (track_reset) {
        track_reset = false;
        track.reset();
        track.enable_flyroute(false);
    }

    const bool hvr = track.step(gcfg, env, route);
    hhvr.set(hvr);

    const Gtrack::Des_speed speed = get_desired_speed(gcfg.spd.read(0.0F), gcfg.a_brake);

    uavc.deviation(gcfg.hpid,
                   gcfg.vpid,
                   env,
                   hvr,
                   speed.type,
                   speed.vlink,
                   hvr ? speed.vlink : speed.v);
    uavc.commit_gtrack();
}

Real Gtrack::wp_reach(const Speed_cfg& speed_cfg,
                      const Real arc_inc_spd,
                      const Real a_brake) const {
    static const Real min_vc0 = 1.0E-6F; // Minimum cruise speed
    Real vc0 = Rfun::max<Real>(speed_cfg.data.speed.vlink + arc_inc_spd, min_vc0);
    // detect on fly_over distance to switch from speed to wpspeed
    if (speed_cfg.get_reach_mode() == Speed_cfg::rm_reach) {
        Real d2a = 0.0F;
        if (track.dist2achieve(d2a)) {
            const Real vc0_brake = ((a_brake*d2a)/vc0) + speed_cfg.data.speed.vpoint;
            vc0 = Rfun::min<Real>(vc0, vc0_brake);
        }
    }
    return vc0;
}

Gtrack::Des_speed Gtrack::get_desired_speed(const Real arc_inc_spd, const Real a_brake) const {
    const Speedcmd spdcmd = track.get_speed_cmd();
    Speed_cfg speed_cfg = spdcmd.overwrite_route ?
            spdcmd.get_speed_cfg() :
            route.get_current_patch().cfg.speed_cfg;

    Gtrack::Des_speed ret;
    switch (speed_cfg.get_speed_type()) {
        case Speed_cfg::st_ias:
            ret.type = Dynamics::Aircraft::ias;
            ret.vlink = speed_cfg.data.speed.vlink;
            ret.v = wp_reach(speed_cfg, arc_inc_spd, a_brake);
            break;
        case Speed_cfg::st_tas:
            const Real TAS_to_IAS = uav.get_TAS_to_IAS();
            speed_cfg.data.speed.vlink *= TAS_to_IAS;
            speed_cfg.data.speed.vpoint *= TAS_to_IAS;
            ret.type = Dynamics::Aircraft::ias;
            ret.vlink = speed_cfg.data.speed.vlink;
            ret.v = wp_reach(speed_cfg, arc_inc_spd, a_brake);
            break;
        case Speed_cfg::st_ground:
            ret.type = Dynamics::Aircraft::speed;
            ret.vlink = speed_cfg.data.speed.vlink;
            ret.v = wp_reach(speed_cfg, arc_inc_spd, a_brake);
            break;
        case Speed_cfg::st_arrival:
            // Default velocity when the computation of the distance is not possible
            static const Real default_vel = 30.0F;
            static const Real min_time = 0.001F;   // Minimum time to be considered in seconds
            const Real time_to_arrive =
                    Rfun::max<Real>(min_time,
                                    Base::Stimestamp::time_between_secs(Base::Stimestamp::get_current(),
                                                                        speed_cfg.data.arrival_time));
            ret.type = Dynamics::Aircraft::speed;
            Real d2a = 0.0F;
            ret.vlink = track.dist2achieve(d2a) ? (d2a / time_to_arrive) : default_vel;
            ret.v = ret.vlink;
            break;
    }
    return ret;
}

bool Gtrack::fly_to_wp(const int16 wp) {
    const bool ret = Base::Assertions::runtime(route.flyto(wp));
    if (ret) {
        track_reset = true;
        route.reset_laps(wp);
    }
    return ret;
}

bool Gtrack::fly_to_setup_wp(const Uint16 idx) {
    bool ret = map.value.is_enabled(idx);
    if (ret) {
        ret = fly_to_wp(map.value[idx].value);
    }
    return ret;
}

void Gtrack::set_cane(const Loiter_data& data) {
    track.set_cane(data);
}

void Gtrack::set_hover(const Hover_data& data) {
    track.set_hover(data);
}

void Gtrack::set_speed_cmd(const Speedcmd& cmd) {
    track.set_speed_cmd(cmd);
}
```

The `Gtrack` class:
1. Manages guidance track operations
2. Coordinates between route following and special maneuvers
3. Handles speed commands and waypoint navigation
4. Computes desired speed based on waypoint reach mode
5. Provides methods for flying to specific waypoints
6. Manages special maneuvers like loiter and hover

## 7. Gtrackcfg Class: Guidance Track Configuration

The `Gtrackcfg` class manages the configuration for guidance track operations.

### 7.1 Member Variables

```cpp
const Uint16 idx;                  // Index for patchset

Blocks::Pin_ptr_opt<Real> fv;      // Arcade front velocity
Blocks::Pin_ptr_opt<Real> lv;      // Arcade lateral velocity
Blocks::Pin_ptr_opt<Real> dv;      // Arcade down velocity
Blocks::Pin_ptr_opt<Real> spd;     // Arcade cruise speed velocity
Blocks::Pin_ptr_opt<Real> hvar;    // Variable for horizontal table PID
Blocks::Pin_ptr_opt<Real> vvar;    // Variable for vertical table PID

bool do_flyto;                     // True if has to do fly to in on_focus
Uint16 flyto_patch;                // Setup waypoint to fly to in on_focus
Real a_brake;                      // Acceleration used to brake (for vpoint velocity)
Speedcmd spdcmd;                   // Cruise speed
Real harclim;                      // Horizontal arcade transition threshold
Real varclim;                      // Vertical arcade transition threshold
Guid_pid hpid;                     // Horizontal PID configuration
Guid_pid vpid;                     // Vertical PID configuration
Uint16 prj;                        // Projection type
const Patchsetcfg& pcfg;           // Patchset configuration
```

### 7.2 Key Methods

```cpp
Gtrackcfg::Gtrackcfg(const Uint16 idx0, const Patchsetcfg& pcfg0) :
    idx(idx0),
    do_flyto(false),
    flyto_patch(0),
    a_brake(0.0F),
    harclim(0.0F),
    varclim(0.0F),
    prj(Patchset::prj_3d),
    pcfg(pcfg0)
{
}

void Gtrackcfg::step() {
    hpid.step(hvar.read(0.0F));
    vpid.step(vvar.read(0.0F));
}

void Gtrackcfg::cset(Base::Lossy_error& str, Blocks::Iblock::Csetpm& params) {
    bool ret = fv.cset(str, params.accpins, 1U, 1U);
    ret &= lv.cset(str, params.accpins, 1U, 1U);
    ret &= dv.cset(str, params.accpins, 1U, 1U);
    ret &= spd.cset(str, params.accpins, 1U, 1U);
    ret &= hvar.cset(str, params.accpins, 1U, 1U);
    ret &= vvar.cset(str, params.accpins, 1U, 1U);

    str.get_bool16(do_flyto);
    if (do_flyto) {
        str.get_uint16(flyto_patch);
    }
    str.get_float(a_brake);
    spdcmd.cset(str);

    str.get_float(harclim);
    str.get_float(varclim);

    hpid.cset(str);
    vpid.cset(str);

    str.get_uint16(prj);

    str.assrt(ret &&
              (a_brake > 0.0F) &&
              (harclim >= 0.0F) &&
              (varclim >= 0.0F) &&
              (prj < Patchset::prj_num), Base::err_cmd_gtrack2);
}

void Gtrackcfg::operation_check(Base::Error& err) const {
    spdcmd.check(err);
}
```

The `Gtrackcfg` class:
1. Manages configuration for guidance track operations
2. Handles arcade control inputs
3. Configures PID controllers for guidance
4. Sets up projection type and speed commands
5. Validates configuration parameters

## 8. Blk_gtrackcfg Class: Guidance Track Configuration Block

The `Blk_gtrackcfg` class is a block that provides guidance track configuration in the block system.

### 8.1 Member Variables

```cpp
T routecfg;                        // Route configuration
Blocks::Pin<Vpgnc::Gtrackcfg> gcfg; // Complete gtrack configuration
```

### 8.2 Key Methods

```cpp
template <typename T, Uint16 IDX>
inline void Blk_gtrackcfg<T,IDX>::step() {
    gcfg.val.step();
    routecfg.step();
}

template <typename T, Uint16 IDX>
inline const Blocks::Ipin* Blk_gtrackcfg<T,IDX>::get_out(Uint16 i) const {
    return Base::Assertions::runtime(i == 0) ? &gcfg : 0;
}

template <typename T, Uint16 IDX>
inline void Blk_gtrackcfg<T,IDX>::cset(Base::Lossy_error& str, Csetpm& params) {
    gcfg.val.cset(str, params);
    routecfg.cset(str);
}

template <typename T, Uint16 IDX>
inline void Blk_gtrackcfg<T,IDX>::check(Base::Error& err) const {
    gcfg.val.operation_check(err);
    routecfg.operation_check(err);
}
```

The `Blk_gtrackcfg` class:
1. Provides a block interface for guidance track configuration
2. Manages both the guidance configuration and route configuration
3. Validates configuration parameters
4. Outputs the guidance track configuration for use by other blocks

## 9. Integration and Data Flow

### 9.1 Path Following Architecture

The path following system in the VPGNC framework is organized in a hierarchical structure:

```
+----------------+         +----------------+         +----------------+
|    Gtrack      |-------->|    Track       |-------->|   Patchset     |
| (Guidance      |         | (Path          |         | (Path          |
|  Track Manager)|         |  Tracking)     |         |  Management)   |
+----------------+         +----------------+         +----------------+
       |                          |                          |
       v                          v                          v
+----------------+         +----------------+         +----------------+
|   Gtrackcfg    |-------->|    Icurve      |-------->|   Curve Types  |
| (Configuration)|         | (Path          |         | (Point, Line,  |
|                |         |  Interface)    |         |  Arc)          |
+----------------+         +----------------+         +----------------+
```

The data flow through these components is as follows:

1. **Configuration**:
   - `Gtrackcfg` provides configuration for guidance track operations
   - `Blk_gtrackcfg` exposes this configuration to the block system

2. **Path Management**:
   - `Patchset` manages a set of path segments
   - `Route` manages a route as a sequence of waypoints and path segments

3. **Path Tracking**:
   - `Track` selects the appropriate path segment to follow
   - `Icurve` provides a common interface for path following
   - `Point`, `Line`, and `Arc` implement specific path types

4. **Guidance Management**:
   - `Gtrack` coordinates between route following and special maneuvers
   - `Leg` implements complex path segments for landing and climbing

### 9.2 Key Workflows

#### 9.2.1 Path Following Workflow

1. **Path Initialization**:
   - `Gtrack::on_focus` initializes the guidance track
   - `Track::ps_on_focus` initializes the path segment
   - `Icurve::on_focus` initializes the curve

2. **Path Tracking**:
   - `Gtrack::step` executes one step of guidance track operations
   - `Track::step` computes guidance parameters for the selected path
   - `Icurve::compute` or `Icurve::compute2d` computes distance and tangent vectors

3. **Path Transition**:
   - `Track::compute_stg` selects the appropriate path segment to follow
   - `Patchset::flyto_next` transitions to the next path segment when the current one is achieved

4. **Speed Management**:
   - `Gtrack::get_desired_speed` computes the desired speed
   - `Gtrack::wp_reach` adjusts speed for waypoint reaching

#### 9.2.2 Waypoint Navigation Workflow

1. **Waypoint Selection**:
   - `Gtrack::fly_to_wp` selects a waypoint to fly to
   - `Gtrack::fly_to_setup_wp` selects a waypoint from the setup map

2. **Route Calculation**:
   - `Route::cset` configures the route
   - `Patchset::calculate` calculates the path segments

3. **Closest Waypoint Calculation**:
   - `Patchset::compute_closest` finds the closest waypoint to the current position

4. **Waypoint Achievement**:
   - `Patchset::flyto_next` transitions to the next waypoint when the current one is achieved
   - `Track::refresh_vars` updates system variables with waypoint information

#### 9.2.3 Special Maneuvers Workflow

1. **Loiter Maneuver**:
   - `Track::set_cane` sets up a loiter maneuver
   - `Leg::compute_loix` computes the loiter geometry
   - `Leg::compute_n_loops` calculates the number of loops needed

2. **Hover Maneuver**:
   - `Track::set_hover` sets up a hover maneuver
   - `Point::hoverable` indicates that a point supports hovering

3. **Arcade Control**:
   - `Track::set_arc` sets arcade control inputs
   - `Arcxset::get_angle_axis0` computes the arcade axis angle
   - `Alt2D::apply_v_arcade` applies vertical arcade control

## 10. Key Algorithms and Mathematical Models

### 10.1 Line Path Following Algorithm

The line path following algorithm computes the closest point on a line to the current position:

1. **Vector Calculation**:
   ```cpp
   prv.relthis_drn(pos, d);    // Vector from start to current position
   prv.relthis_drn(cwp, t);    // Vector from start to end
   ```

2. **Projection Calculation**:
   ```cpp
   s = d.dot(t);               // Projection of d onto t
   smax = t.norm2();           // Length of the line
   t.scale(Const::ONE/smax);   // Normalize t
   ```

3. **Closest Point Calculation**:
   ```cpp
   if((s > 0) && (s < smax)) {
       x.copy(t);
       x.scale(s);             // Vector from start to closest point
   } else {
       if(s <= 0) {
           x.zeros();          // Closest point is start
       } else {
           x.copy(t);
           x.scale(smax);      // Closest point is end
       }
   }
   ```

4. **Distance Vector Calculation**:
   ```cpp
   d.vecsub(x);                // Vector from closest point to current position
   ```

### 10.2 Arc Path Following Algorithm

The arc path following algorithm computes the closest point on an arc to the current position:

1. **Arc Parameters Calculation**:
   ```cpp
   Rvector3 r01;
   apos0.relthis_drn(end_pos.get_pos(), r01);

   Rvector3 r02(params.rk[0], params.rk[1], 0);
   r02.lincmb_add(Const::ONEHALF, r01);

   Rvector3 rc0;
   Real angle0 = 0.0F;
   Real angle = 0.0F;
   Real R = 0.0F;
   compute0(r01, r02, rc0, angle0, angle, R);
   ```

2. **Current Position Relative to Arc Center**:
   ```cpp
   apos0.relthis_drn(pos, d);   // Vector from start to current position
   d.vecadd(rc0);               // Vector from center to current position
   ```

3. **Angle Calculation**:
   ```cpp
   Real angle1 = 0.0F;
   d.azeld(angle1, sp, cp);     // Azimuth of current position from center
   Real u_signed = (angle > 0) ? (st.u) : (-st.u);
   u_signed += Rfun::wrap2pi(angle1-(u_signed+angle0)); // Unwrap angle
   ```

4. **Closest Point Calculation**:
   ```cpp
   if((angle*u_signed) < 0) {
       u_signed = 0;
       angle1 = angle0;
   } else if(((angle < 0) && (u_signed < angle)) || ((angle > 0) && (u_signed > angle))) {
       u_signed = angle;
       angle1 = angle0 + angle;
   }
   sp = Rmath::sinr(angle1);
   cp = Rmath::cosr(angle1);

   Rvector3 x; // projection inside arc from center
   x[Ku16::u0] = R*cp;
   x[Ku16::u1] = R*sp;
   x[Ku16::u2] = r01[Ku16::u2]*u_signed/angle;
   ```

5. **Tangent Vector Calculation**:
   ```cpp
   t[0] = -sp;
   t[1] = cp;
   t[Ku16::u2] = t2_t01;
   t.norm2alize();
   ```

6. **Distance Vector Calculation**:
   ```cpp
   d.vecsub(x);                // Vector from closest point to current position
   ```

### 10.3 Waypoint Reach Speed Algorithm

The waypoint reach speed algorithm computes the desired speed to reach a waypoint:

```cpp
Real Gtrack::wp_reach(const Speed_cfg& speed_cfg,
                      const Real arc_inc_spd,
                      const Real a_brake) const {
    static const Real min_vc0 = 1.0E-6F; // Minimum cruise speed
    Real vc0 = Rfun::max<Real>(speed_cfg.data.speed.vlink + arc_inc_spd, min_vc0);
    // detect on fly_over distance to switch from speed to wpspeed
    if (speed_cfg.get_reach_mode() == Speed_cfg::rm_reach) {
        Real d2a = 0.0F;
        if (track.dist2achieve(d2a)) {
            const Real vc0_brake = ((a_brake*d2a)/vc0) + speed_cfg.data.speed.vpoint;
            vc0 = Rfun::min<Real>(vc0, vc0_brake);
        }
    }
    return vc0;
}
```

This algorithm:
1. Computes the initial cruise speed as the configured speed plus any arcade increment
2. If waypoint reach mode is enabled:
   a. Gets the distance to achieve the waypoint
   b. Computes the speed needed to brake to the waypoint speed
   c. Uses the minimum of the cruise speed and brake speed

### 10.4 Loiter Path Calculation Algorithm

The loiter path calculation algorithm computes the geometry of a loiter pattern:

```cpp
void Leg::compute_loix(const Leg::Cfg& c, const bool climb, Maverick::Irvector3& rk) {
    // Compute direction of loix spin (clockwise/counterclockwise)
    Rvector3 rc1;
    rc1.vecres(r2a, r1c); // Vector from loix center to arc end
    Rvector3 t;
    t.vecres(r3a, r2a);   // Vector from arc end with tangent direction
    Rvector3 spin;
    spin.cross(rc1, t);   // Loix spin vector
    const bool loix_clockwise = (spin[Rvector3::vz] > Const::ZERO); // Clockwise is direction down positive

    const Real R1v = c.R1.get();
    Rvector3 rc0;
    rc0.vecres(r0a, r1c); // vector from loix center to uav
    Real azc1a = Arc::compute_az_tangent(rc0, R1v, loix_clockwise); // start azimuth

    Real angle = Const::ZERO;
    Arc::compute_arc(azc1a, rc1, R1v, loix_clockwise, r1a, rk, angle);
    // at this point, r1a is center to start of arc
    r1a.vecadd(r1c); // now, r1a is not referenced by center

    // Compute lengths
    len[Ku16::u1] = Rmath::fabsr(angle)*R1v;
    if (climb) {
        // In climb there is no final 1a-0a segment
        r0a.copy(r1a);
        len[Ku16::u0] = Const::ZERO;
    } else {
        Rvector3 r1a_r0a;
        r1a_r0a.vecres(r0a, r1a);
        len[Ku16::u0] = r1a_r0a.norm2xy();
    }
}
```

This algorithm:
1. Determines the direction of the loiter (clockwise or counterclockwise)
2. Computes the start azimuth for the loiter arc
3. Calculates the arc parameters (center, radius, angle)
4. Computes the length of the loiter arc
5. Handles the special case for climbing maneuvers

### 10.5 Number of Loiter Loops Calculation

The algorithm to calculate the number of loiter loops needed for altitude changes:

```cpp
void Leg::compute_n_loops(const Leg::Cfg& c,
                          const Real tfpa1,
                          Uint16& nloops) {
    //Calculate number of loops for loiter.
    //Eq: n = abs(Deltah / (Ln * tfpa1)) - (L0 * (tfpa1))/(Ln * (tfpa1)).
    //Deltah = altitude step; Ln = loiter arc length; L0 = partial arc length;
    //Ceil for rounding number of laps, always up.

    const Real lap_len = Const::PI2 * c.R1.get(); // Horizontal length of one lap in loiter R1.

    nloops = static_cast<Uint16>(Rmath::ceilr(Rmath::fabsr(
            (r2a[Rvector3::vz] - r1a[Rvector3::vz])/(lap_len*tfpa1)) - len[Ku16::u1]/lap_len));
    len[Ku16::u1] += static_cast<Real>(nloops)*lap_len;  //Add loiter distance based on number of laps needed
}
```

This algorithm:
1. Calculates the horizontal length of one complete loiter lap
2. Computes the number of loops needed to achieve the desired altitude change
3. Updates the loiter arc length to include the additional loops

## 11. Summary

The waypoint navigation and path management system in the VPGNC framework provides a comprehensive solution for path following, waypoint navigation, and special maneuvers. The system is built around several key components:

1. **Navigation Curves**: The `Point`, `Line`, and `Arc` classes implement the fundamental path primitives used for path following.

2. **Track Management**: The `Track` class manages path tracking, selecting the appropriate path segment to follow and computing guidance parameters.

3. **Route Management**: The `Route` class manages a route as a sequence of waypoints and path segments.

4. **Guidance Track Configuration**: The `Gtrackcfg` class manages the configuration for guidance track operations.

5. **Guidance Track Management**: The `Gtrack` class coordinates between route following and special maneuvers.

6. **Arcade Control**: The `Arcaxis` and `Arcxset` classes provide manual control integration with automated path following.

7. **Landing/Climbing Path Segments**: The `Leg` class implements complex path segments for landing and climbing operations.

The system supports various path following modes, including 2D, 2.5D, and 3D, as well as special maneuvers like loiter and hover. It also provides mechanisms for speed control, waypoint reaching, and obstacle avoidance.

The mathematical models and algorithms implemented in the system enable precise path following, smooth transitions between path segments, and efficient waypoint navigation. The system is highly configurable, allowing for adaptation to different vehicle types and mission requirements.