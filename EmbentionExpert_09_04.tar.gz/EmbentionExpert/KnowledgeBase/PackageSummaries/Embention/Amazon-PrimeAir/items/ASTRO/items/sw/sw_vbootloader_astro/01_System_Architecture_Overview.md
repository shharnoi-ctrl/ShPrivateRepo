# Generated from:

- PackageSummaries/Amazon-PrimeAir/items/ASTRO/items/sw/sw_vbootloader_astro/04_Bootloader_Core_Architecture.md (2297 tokens)
- PackageSummaries/Amazon-PrimeAir/items/ASTRO/items/sw/sw_vbootloader_astro/02_Hardware_Abstraction_Layer.md (3301 tokens)
- PackageSummaries/Amazon-PrimeAir/items/ASTRO/items/sw/sw_vbootloader_astro/03_Memory_Layout_Configuration.md (2769 tokens)
- PackageSummaries/Amazon-PrimeAir/items/ASTRO/items/sw/sw_vbootloader_astro/02_Storage_Management.md (1722 tokens)
- PackageSummaries/Amazon-PrimeAir/items/ASTRO/items/sw/sw_vbootloader_astro/02_Build_Configuration.md (3348 tokens)
- PackageSummaries/Amazon-PrimeAir/items/ASTRO/items/sw/sw_vbootloader_astro/02_Testing_Framework.md (5056 tokens)

---

# Astro Bootloader System Architecture: Comprehensive Overview

## 1. Multi-Core Architecture

The Astro bootloader operates on a sophisticated multi-core platform with three distinct processor cores:

### 1.1 Core Architecture and Responsibilities

| Core | Processor Type | Primary Responsibilities |
|------|---------------|--------------------------|
| **C1 (Core 1)** | TI C2000 DSP | - Main bootloader execution<br>- Application verification<br>- Core management<br>- Security enforcement<br>- Flash memory management |
| **C2 (Core 2)** | TI C2000 DSP | - Secondary processing<br>- Managed by C1<br>- Application-specific functionality |
| **CM (Cortex-M)** | ARM Cortex-M | - Network communication<br>- Ethernet interface management<br>- lwIP TCP/IP stack<br>- Secondary bootloader execution |

### 1.2 Memory Architecture

Each core operates with its own memory space, with careful coordination for shared regions:

#### C1 (DSP) Memory Map
- **FLASH**: 0x80000 - 0xBFFFF (16-bit word addressing)
  - **Bootloader**: 0x80000 - 0x8FFFF (64KB)
  - **Application**: 0x90000 - 0xBFFFF (192KB)
- **RAM**: Multiple regions including RAMM, RAML, RAMS
  - **RAMFUNCS**: Special region for performance-critical functions

#### CM (ARM) Memory Map
- **FLASH**: 0x200000 - 0x27FFFF (8-bit byte addressing)
  - **Bootloader**: 0x200000 - 0x21FFFF (128KB)
  - **Application**: 0x220000 - 0x27FFFF (384KB)
- **RAM**: C0RAM, C1RAM, ESRAM regions

#### Inter-Processor Communication Regions
- **CPUTOCMRAM**: C1 to CM communication (0x039000 - 0x0397FF)
- **CMTOCPURAM**: CM to C1 communication (0x038000 - 0x0387FF)
- Additional message RAM regions for comprehensive inter-core communication

### 1.3 Addressing Scheme Differences

A critical architectural feature is the different addressing schemes used by the cores:

- **C1/C2 (DSP)**: Uses 16-bit word addressing (`SIZE_FACTOR = 2`)
- **CM (ARM)**: Uses 8-bit byte addressing (`SIZE_FACTOR = 1`)

This difference requires careful coordination when sharing memory addresses between cores.

## 2. Bootloader Initialization Sequence

The bootloader follows a precise initialization sequence:

### 2.1 System Security Setup
1. Optional DCSM (Device Configuration and Security Module) configuration
2. Security zone setup and key configuration
3. JTAG access limitation if required

### 2.2 Core Initialization Process
1. **C1 Core Initialization**:
   - Parameter and memory region configuration
   - Shared memory structure initialization
   - Hardware interface configuration (SPI, CAN, GPIO)
   - File system initialization

2. **CM Core Initialization**:
   - CM core is initially turned off
   - C1 configures CM parameters in shared memory
   - C1 boots CM core with specific configuration
   - CM initializes network interfaces if configured

3. **C2 Core Management**:
   - Managed through the core management bitmap
   - Initialized as needed based on application requirements

### 2.3 Factory Pattern Implementation

The bootloader uses a factory pattern for instantiation:

```cpp
Bootloader_dual& Bootloader_dual::build(Bldr_mgr::Params par, Base::IAddress_handler & addr_handler)
{
    static Bootloader_astro bldr2(par, addr_handler);
    return bldr2;
}
```

This pattern ensures a single bootloader instance with polymorphic behavior.

## 3. Inter-Core Communication

The cores communicate through a sophisticated shared memory architecture:

### 3.1 Shared Memory Structures

- **CPU1_CM_shared**: Structure for data sharing between C1 and CM cores
  - System UID (Unique Identifier)
  - System address
  - Ethernet MAC address
  - IP configuration
  - Communication ports
  - Heartbeat LED ID

### 3.2 IPC Mechanisms

- **IPC Class**: Manages inter-processor communication
  - Controls core state (turn off, boot)
  - Sends commands between cores
  - Synchronizes initialization
  - Transfers status information

### 3.3 Message Passing

The system implements a comprehensive message passing architecture:
- Dedicated memory regions for each direction of communication
- Status flags for synchronization
- Command and response structures
- Heartbeat mechanisms for health monitoring

## 4. Hardware Abstraction Layer

The Astro bootloader implements a sophisticated hardware abstraction layer:

### 4.1 Hardware Identification System

The platform uses GPIO pins to determine hardware variants:
- Four GPIO pins identify hardware revision (ev1, ev1_res, ev2, dv1)
- Two configuration pins determine application type
- This information forms a Unique Identifier (UID) for the device

### 4.2 GPIO Configuration Mapping

The `Halsuite` class maps functional requirements to hardware-specific configurations:
- LED control (red, green, blue)
- Serial communication interfaces (SCI-A through SCI-D)
- CAN bus interfaces (CAN-A, CAN-B, CAN-FD)
- Ethernet MII interface (for CM core)

### 4.3 Peripheral Configuration Tables

The system maintains comprehensive configuration tables for all peripherals:
- GPIO pin assignments
- Multiplexer settings
- Pull-up/pull-down configurations
- Direction (input/output)
- Signal qualification settings

## 5. Storage Management

### 5.1 Flash Memory Interface

The bootloader manages flash memory through multiple layers:

1. **Hardware Interface**: SPI-C communication at 12.5MHz
2. **Flash Driver**: MX66L driver for low-level operations
3. **File System**: DFS2 (Dual File System 2) implementation

### 5.2 DFS2 File System

The DFS2 file system provides structured storage:
- 2000 files maximum
- 8 sectors per file descriptor
- 120 sectors per file
- PDIF (Portable Data Interchange Format) partition type
- Approximately 117MB total storage

### 5.3 Storage Operations

The file system supports:
- Application image storage
- Configuration data management
- Update package handling
- System logs and diagnostics

## 6. Security Architecture

The Astro bootloader implements comprehensive security features:

### 6.1 Secure Boot Process

1. **DCSM Configuration**: Secures device access and limits JTAG functionality
2. **Application Verification**: Validates application header and integrity
3. **ECDSA Signature Verification**: Cryptographically verifies firmware authenticity
4. **SHA-256 Hashing**: Ensures data integrity throughout the boot process

### 6.2 Security Components

Both cores include security-related components:
- C1 DSP: `vbootloader/2838x_ecdsa` and `crypto_c28`
- CM ARM: `vbootloader/2838x_ecdsa_arm` and `crypto/2838x_arm`

### 6.3 Secure Communication

- **Secure CAN Implementation**: Manages CAN transceivers with security measures
- **Encrypted Communication**: Supports secure protocols for external interfaces
- **Access Control**: Implements permission checks for sensitive operations

## 7. Network Capabilities

The CM core provides comprehensive networking functionality:

### 7.1 Ethernet Interface

- **MII Configuration**: Detailed GPIO and multiplexer settings for Ethernet
- **PHY Management**: MDIO interface for physical layer configuration
- **MAC Address Management**: Configurable through shared memory

### 7.2 TCP/IP Stack

The CM core implements the lwIP TCP/IP stack with:
- TCP/IP protocol implementation
- Socket API
- Network interface management
- DHCP client functionality
- DNS resolution

### 7.3 Network Services

The bootloader supports network-based services:
- Firmware updates over Ethernet
- Remote monitoring and diagnostics
- Configuration management
- Status reporting

## 8. Application Management

### 8.1 Application Verification Process

The bootloader implements a rigorous application verification process:
1. Header validation (magic number, version compatibility)
2. CRC32 integrity check
3. ECDSA signature verification
4. Memory boundary validation
5. Core compatibility check

### 8.2 Multi-Core Application Loading

The bootloader can load applications to multiple cores:
- C1 application from main flash
- C2 application from flash region
- CM application from CM-specific memory region

### 8.3 Application Header Structure

Applications include headers with:
- Magic number for identification
- Version information
- Target core information
- Memory requirements
- CRC32 checksum
- ECDSA signature

## 9. Update Mechanisms

The bootloader supports comprehensive update capabilities:

### 9.1 Update Process

1. Receive update package via network or CAN interface
2. Verify package integrity and authenticity
3. Store package in flash memory
4. Verify application headers and signatures
5. Update bootloader if required
6. Update applications for each core
7. Restart system with new firmware

### 9.2 Failsafe Updates

The system implements failsafe update mechanisms:
- Verification before committing changes
- Backup of critical components
- Recovery from interrupted updates
- Fallback to previous version on failure

### 9.3 Testing Framework

A comprehensive testing framework validates update functionality:
- 21 distinct test cases covering nominal and error scenarios
- Binary manipulation for security testing
- CAN bus monitoring during updates
- Endurance testing (1000 cycles)

## 10. Build System

The build system creates a coordinated dual-core bootloader:

### 10.1 Hierarchical Configuration

- JSON-based configuration files define build parameters
- Separate configurations for C1 (DSP) and CM (ARM) cores
- Shared libraries through _Vlibs submodule

### 10.2 Core-Specific Builds

Each core has specialized build configurations:
- C1 DSP: TI C2000 toolchain with DSP-specific libraries
- CM ARM: ARM toolchain with networking components

### 10.3 Memory Layout Configuration

The build system generates linker command files that:
- Define memory regions for each core
- Configure shared memory for inter-core communication
- Set up RAM functions for performance-critical code
- Generate appropriate binary images for each core

## 11. System Integration Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│                      Astro Bootloader System                     │
├───────────────┬─────────────────────────────┬───────────────────┤
│   C1 (DSP)    │        Shared Memory        │    CM (ARM)       │
│  Core Manager │                             │  Network Manager  │
├───────────────┤  ┌─────────────────────┐    ├───────────────────┤
│ - Main control│  │ - System UID        │    │ - Ethernet        │
│ - App verify  │  │ - System address    │    │ - lwIP stack      │
│ - Security    │◄─┼─► - MAC address     │◄─┬─┤ - TCP/IP          │
│ - Flash mgmt  │  │ - IP configuration  │  │ │ - DHCP client     │
│ - Core mgmt   │  │ - Command/status    │  │ │ - Network services│
└───────────┬───┘  └─────────────────────┘  │ └─────────┬─────────┘
            │                                │           │
            ▼                                ▼           ▼
┌───────────────────┐              ┌─────────────────────────────┐
│  Hardware Layer   │              │      External Interfaces     │
├───────────────────┤              ├─────────────────────────────┤
│ - SPI Flash       │              │ - Ethernet                  │
│ - DFS2 filesystem │              │ - CAN bus                   │
│ - GPIO control    │              │ - Serial ports              │
│ - CAN interfaces  │              │ - Debug interfaces          │
└───────────────────┘              └─────────────────────────────┘
```

## 12. Memory Layout Diagram

```
┌───────────────────────┐           ┌───────────────────────┐
│    C1 (DSP) Memory    │           │    CM (ARM) Memory    │
├───────────────────────┤           ├───────────────────────┤
│ FLASH (16-bit words)  │           │ FLASH (8-bit bytes)   │
│                       │           │                       │
│ 0x80000 ┌───────────┐ │           │ 0x200000┌───────────┐ │
│         │ Bootloader│ │           │         │ Bootloader│ │
│         │  (64KB)   │ │           │         │  (128KB)  │ │
│ 0x8FFFF └───────────┘ │           │ 0x21FFFF└───────────┘ │
│         ┌───────────┐ │           │         ┌───────────┐ │
│ 0x90000 │Application│ │           │ 0x220000│Application│ │
│         │  (192KB)  │ │           │         │  (384KB)  │ │
│ 0xBFFFF └───────────┘ │           │ 0x27FFFF└───────────┘ │
├───────────────────────┤           ├───────────────────────┤
│ RAM                   │           │ RAM                   │
│                       │           │                       │
│ RAMM_DAT  (M0-M1)     │           │ C0RAM                │
│ RAML      (Local)     │           │ C1RAM                │
│ RAMS      (Shared)    │           │ ESRAM                │
│ RAMFUNCS  (Functions) │           │                       │
└───────────────────────┘           └───────────────────────┘
        │       ▲                           ▲       │
        │       │                           │       │
        ▼       │                           │       ▼
┌─────────────────────┐           ┌─────────────────────┐
│    CPUTOCMRAM       │◄─────────►│   CMTOCPU1MSGRAM    │
│  (C1 to CM comm)    │           │   (CM to C1 comm)   │
└─────────────────────┘           └─────────────────────┘
```

## 13. Boot Sequence Diagram

```
┌────────┐          ┌────────┐          ┌────────┐
│   C1   │          │   C2   │          │   CM   │
└───┬────┘          └───┬────┘          └───┬────┘
    │                   │                   │
    │ Power-on          │                   │
    ├───────────────────┼───────────────────┤
    │                   │                   │
    │ Initialize security (DCSM)            │
    ├───────────────────┼───────────────────┤
    │                   │                   │
    │ Configure memory regions              │
    ├───────────────────┼───────────────────┤
    │                   │                   │
    │ Initialize hardware interfaces        │
    ├───────────────────┼───────────────────┤
    │                   │                   │
    │ Setup shared memory                   │
    ├───────────────────┼───────────────────┤
    │                   │                   │
    │ Turn off CM core  │                   │
    ├───────────────────┼───────────────────┼──────┐
    │                   │                   │      │
    │ Configure CM parameters               │      │
    ├───────────────────┼───────────────────┤      │
    │                   │                   │      │
    │ Boot CM core      │                   │      │
    ├───────────────────┼───────────────────┼──────┘
    │                   │                   │
    │                   │                   │ Initialize
    │                   │                   ├─────┐
    │                   │                   │     │ Setup network
    │                   │                   │     │ interfaces
    │                   │                   │<────┘
    │                   │                   │
    │ Verify application images             │
    ├───────────────────┼───────────────────┼─────┐
    │                   │                   │     │
    │ If valid, load applications           │     │
    ├───────────────────┼───────────────────┤     │
    │                   │                   │     │
    │ Boot C2 if needed │                   │     │
    ├─────────────────┬─┘                   │     │
    │                 │                     │     │
    │ Execute application or stay in bootloader   │
    └─────────────────┴─────────────────────┴─────┘
```

## 14. Conclusion

The Astro bootloader represents a sophisticated multi-core system with comprehensive security features, network capabilities, and robust update mechanisms. Its architecture carefully manages the complexities of coordinating different processor cores with distinct memory architectures while providing a secure and reliable foundation for application execution. The system's modular design, hardware abstraction layer, and comprehensive testing framework ensure reliable operation across different hardware variants and use cases.