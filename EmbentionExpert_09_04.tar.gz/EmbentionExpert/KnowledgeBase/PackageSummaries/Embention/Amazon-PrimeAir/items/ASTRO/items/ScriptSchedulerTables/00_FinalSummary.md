# Generated from:

- Amazon-PrimeAir/items/ASTRO/items/ScriptSchedulerTables/02_Scheduler_Table_Generation.md (4009 tokens)
- Amazon-PrimeAir/items/ASTRO/items/ScriptSchedulerTables/01_VTOL_Control_Parameters.md (2545 tokens)

---

# ASTRO System Architecture Overview

This document provides a high-level overview of the ASTRO system, a sophisticated control system for VTOL (Vertical Take-Off and Landing) aircraft. It serves as an entry point to understand the system's architecture, components, and how they interact.

## System Purpose and Overview

ASTRO appears to be a comprehensive flight control system designed specifically for VTOL aircraft operations. The system handles the complex task of controlling aircraft through multiple flight phases:
- Vertical takeoff and landing
- Transition between vertical and horizontal flight
- Horizontal cruise flight

The control system uses a sophisticated parameter-based approach with scheduler tables that adapt control strategies based on flight conditions, aircraft configuration, and operational requirements.

## Core System Components

### 1. Scheduler Table Generation System

The system includes scripts that generate scheduler tables used by the flight control system. These tables contain critical parameters that define how the aircraft should behave across different flight regimes.

**Key Components:**
- **Table Generation Scripts**:
  - `GenerateSchedulerTables.py`: Creates text-based parameter tables
  - `GenerateSchedulerTablesPDI.py`: Creates PDI XML format parameter tables for embedded systems

**Parameter Categories:**
1. **Category 1: Trim and Operating Point Parameters**
   - Defines equilibrium conditions across flight regimes
   - Includes motor speeds, trim parameters, and resulting forces/moments
   - Structured as 9×13×12 dimensional data (9 flight conditions × 13 flight parameters × 12 aircraft configurations)

2. **Category 2: Actuator Allocation and Effectiveness Parameters**
   - Maps motor inputs to aircraft forces and moments
   - Contains 590 different operating configurations
   - Includes 6×6 matrices mapping motor speeds to forces/moments

3. **Category 3: Control Constraints and Optimization Parameters**
   - Defines operational limits and control priorities
   - Includes motor speed limits and optimization weighting matrices
   - Ensures safe operation within physical constraints

For more detailed information on these parameter categories, see [VTOL Control Parameter Structure](./ScriptSchedulerTables/01_VTOL_Control_Parameters.md).

### 2. Control System Architecture

Based on the parameter structure, the control system likely implements:

1. **Hierarchical Control Framework**:
   - Reference operating points define desired aircraft states
   - Dynamic control allocation distributes commands to actuators
   - Constraint enforcement ensures safe operation

2. **Optimization-Based Control**:
   - Uses weighting matrices for control prioritization
   - Implements constrained optimization for control allocation
   - Balances multiple control objectives (stability, efficiency, etc.)

3. **Transition Management**:
   - Comprehensive parameter space (590 configurations) for transition phase
   - Smooth blending between vertical and horizontal flight control modes
   - Adaptation of control effectiveness as aerodynamic conditions change

## Data Flow Architecture

The system processes control parameters through a structured pipeline:

```
Input Parameter Files
    │
    ├─── Category 1 Processing
    │    │
    │    ├─── Motor speeds at operating points
    │    ├─── Trim parameters
    │    └─── Forces and moments at equilibrium
    │
    ├─── Category 2 Processing
    │    │
    │    ├─── Actuator dynamics matrices
    │    └─── Allocation parameters
    │
    └─── Category 3 Processing
         │
         ├─── Motor speed limits
         └─── Control optimization weights
         
         ↓
         
Output Scheduler Tables
    │
    ├─── Text Format (.txt files)
    │    For analysis and debugging
    │
    └─── PDI XML Format (.xml files)
         For embedded flight control system
```

## Mathematical Relationships

The system implements sophisticated mathematical relationships:

1. **Motor Speed to Force/Moment Mapping**:
   - Uses squared motor speeds (krpm²) proportional to thrust
   - Applies 6×6 transformation matrices to map inputs to outputs
   - Captures partial derivatives of forces/moments with respect to motor speeds

2. **Trim Parameter Integration**:
   - Combines motor speeds and trim settings to achieve equilibrium
   - Balances forces: F_motors + F_trim = F_gravity + F_aerodynamic

3. **Dynamic Control Allocation**:
   - Solves constrained optimization problems for control distribution
   - Minimizes weighted error between desired and actual aircraft motion
   - Respects physical limitations of actuators

## System Adaptability

The ASTRO system demonstrates sophisticated adaptability across flight phases:

1. **Vertical Flight (Hover)**:
   - Emphasizes differential thrust for attitude control
   - Maintains sufficient thrust margin for stability

2. **Transition Phase**:
   - Provides fine-grained control during critical transition
   - Adapts control effectiveness as aerodynamics change
   - Shifts priorities between thrust-based and aerodynamic control

3. **Horizontal Flight**:
   - Optimizes for efficiency in wing-borne flight
   - Blends control between rotors and aerodynamic surfaces

## Technical Implementation Details

The scheduler table generation system handles large datasets with specific techniques:

1. **Large Dataset Management**:
   - Splits data across multiple PDI XML files when exceeding 10,000 elements
   - Uses sequential configuration IDs for related files
   - Maintains traceability through consistent naming conventions

2. **Matrix Manipulation**:
   - Implements specialized functions for matrix operations:
     - `flatten_matrix()`: Transposes and flattens matrices
     - `get_diag()`: Extracts diagonal elements from square matrices

3. **Output Formats**:
   - Text files: Simple comma-separated values for analysis
   - PDI XML files: Structured format for embedded systems with size limitations

## Further Information

For more detailed information on specific aspects of the ASTRO system, refer to:

- [Scheduler Table Generation](./ScriptSchedulerTables/02_Scheduler_Table_Generation.md): Detailed analysis of the scripts that generate control parameter tables
- [VTOL Control Parameters](./ScriptSchedulerTables/01_VTOL_Control_Parameters.md): In-depth explanation of the control parameter structure and relationships

This overview provides a starting point for understanding the ASTRO system architecture. The linked documents contain more detailed information on specific components and their implementation.