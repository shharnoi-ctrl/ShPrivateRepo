# Generated from:

- Amazon-PrimeAir/items/ASTRO/items/ScriptSchedulerTables/02_Scheduler_Table_Generation.md (4009 tokens)

---

# VTOL Control Parameter Structure and Processing in Scheduler Table Generation

## 1. Three Categories of Control Parameters and Their Purpose

The scheduler table generation scripts reveal a sophisticated control system architecture for VTOL aircraft that organizes parameters into three distinct categories, each serving a specific purpose in flight control:

### Category 1: Trim and Operating Point Parameters
- **Structure**: 9×13×12 dimensional data (9 flight conditions × 13 flight parameters × 12 aircraft configurations)
- **Components**:
  - `cat1_u0_krpm2.txt`: Motor speeds squared (krpm²) at equilibrium points
  - `cat1_q_trim_from_vtol.txt`: Trim parameters for stable flight
  - `cat1_w0_vtol_N_and_N_m.txt`: Forces (N) and moments (N·m) at equilibrium
- **Purpose**: These parameters define the aircraft's equilibrium or trim conditions across different flight regimes. They establish baseline motor settings needed to maintain stable flight at specific operating points without requiring active control inputs. These reference points serve as the foundation for linearized control around stable operating conditions.

### Category 2: Actuator Allocation and Effectiveness Parameters
- **Structure**: 590 different operating configurations
- **Components**:
  - `dfm_dactuator_vtol_N_and_N_m_from_krpm2_and_rad.txt`: 6×6 matrices mapping motor speeds to forces/moments
  - `cat2_q_alloc_from_vtol.txt`: 4-value allocation parameters per configuration
- **Purpose**: These parameters define the control effectiveness matrices that map actuator inputs (motor speeds) to resulting aircraft forces and moments. They enable the flight controller to determine precisely how to distribute control commands among multiple motors to achieve desired aircraft motion. This is particularly critical during transition phases between vertical and horizontal flight, where control authority must shift between different actuator sets.

### Category 3: Control Constraints and Optimization Parameters
- **Structure**: 9 flight conditions with various constraints
- **Components**:
  - `cat3_upper_bound_krpm2.txt`: Maximum allowable motor speeds
  - `cat3_lower_bound_krpm2.txt`: Minimum allowable motor speeds
  - `cat3_W_wrench.txt`: 6×6 weighting matrices for control optimization
- **Purpose**: These parameters define the operational envelope and optimization priorities for the control system. They ensure that control commands remain within physical limitations of the motors while prioritizing certain control axes over others. The weighting matrices are particularly important for resolving control allocation in over-actuated systems (where there are more actuators than degrees of freedom), allowing the controller to make optimal trade-offs when multiple solutions exist.

## 2. Relationship Between Motor Speeds, Forces, Moments, and Trim Parameters

The scripts reveal a sophisticated mathematical relationship between different physical quantities in VTOL control:

### Motor Speed to Force/Moment Mapping
- **Squared Relationship**: Motor speeds are represented as squared values (krpm²), which is directly proportional to thrust according to propeller aerodynamics (F ∝ ω²)
- **Transformation Matrix**: The `dfm_dactuator_vtol_N_and_N_m_from_krpm2_and_rad.txt` file contains 6×6 matrices that map six motor inputs to six outputs (3 forces and 3 moments)
- **Physical Interpretation**: Each element in these matrices represents the partial derivative of a force or moment with respect to a specific motor's squared speed, essentially capturing how each motor contributes to aircraft motion

### Trim Parameter Integration
- **Equilibrium Definition**: The combination of `cat1_u0_krpm2` (motor speeds), `cat1_q_trim_from_vtol` (trim parameters), and `cat1_w0_vtol_N_and_N_m` (resulting forces/moments) defines equilibrium points
- **Trim Parameter Role**: The 4-value trim parameters likely represent additional control factors beyond motor speeds, such as:
  - Control surface deflections
  - Rotor tilt angles
  - Wing configuration settings
  - Center of gravity adjustments
- **Balance Equation**: At each operating point, the motor speeds and trim settings combine to produce forces and moments that maintain the aircraft in equilibrium: F_motors + F_trim = F_gravity + F_aerodynamic

### Dynamic Control Allocation
- **Allocation Parameters**: The 4-value allocation parameters in `cat2_q_alloc_from_vtol` likely define how control authority should be distributed
- **Optimization Framework**: When combined with the weighting matrices (`cat3_W_wrench`), these parameters enable the controller to solve the constrained optimization problem:
  - Minimize: (Desired_Wrench - Actual_Wrench)ᵀ × W × (Desired_Wrench - Actual_Wrench)
  - Subject to: Lower_Bound ≤ Motor_Speeds² ≤ Upper_Bound

## 3. Significance of Matrix Dimensions

The specific dimensions of the parameter matrices reveal important aspects of the VTOL control architecture:

### Category 1 Dimensions (9×13×12)
- **9 Flight Conditions**: Likely represents distinct flight regimes such as:
  - Hover
  - Transition (multiple stages)
  - Forward flight (at different speeds)
  - Descent/landing approach
  - Emergency modes
- **13 Flight Parameters**: Probably captures variations in:
  - Airspeed
  - Angle of attack
  - Sideslip angle
  - Altitude/air density
  - Aircraft weight/loading
- **12 Aircraft Configurations**: May represent:
  - Different rotor tilt angles
  - Wing positions (extended, retracted, intermediate)
  - Control surface settings
  - Payload or weight distribution configurations

### Category 2 Dimensions (590 configurations)
- **High Configuration Count**: The large number (590) suggests this covers a comprehensive mapping of the aircraft's entire flight envelope
- **6×6 Matrices**: Represents the complete mapping from 6 motor inputs to 6 degrees of freedom (3 translational, 3 rotational)
- **Significance**: This detailed mapping enables precise control throughout the transition from vertical to horizontal flight, where aerodynamic forces and control effectiveness change dramatically

### Category 3 Dimensions
- **9 Flight Conditions**: Matches the first dimension of Category 1, ensuring constraints are appropriately defined for each flight regime
- **6×6 Weighting Matrices**: Full matrices allow for capturing cross-coupling effects between different control axes
- **Diagonal Extraction**: The extraction of diagonal elements suggests that while cross-coupling is modeled, the primary optimization weights focus on the direct relationship between each input and its primary output

## 4. Support for VTOL Operation Across Flight Phases

The parameter structure reveals how the control system adapts across different flight phases:

### Vertical Flight (Hover) Phase
- **Trim Conditions**: Specific trim settings ensure stable hover with balanced forces and moments
- **Control Allocation**: Likely emphasizes differential thrust for attitude control
- **Constraints**: Motor speed limits ensure sufficient thrust margin for stability and maneuverability

### Transition Phase
- **Multiple Operating Points**: The large number of configurations (590) provides fine-grained control during the critical transition
- **Changing Effectiveness**: The 6×6 matrices capture how control effectiveness evolves as the aircraft transitions from vertical to horizontal flight
- **Optimization Priorities**: Weighting matrices likely shift priorities from thrust-based control to aerodynamic control surfaces

### Horizontal Flight Phase
- **Trim Parameters**: Different trim settings accommodate the shift to wing-borne flight
- **Efficiency Optimization**: Motor speed constraints likely change to optimize for efficiency rather than maximum control authority
- **Control Blending**: The allocation parameters enable smooth blending between different control effectors (rotors, control surfaces)

### Adaptive Control Framework
- **Comprehensive Coverage**: The three-category approach ensures the control system has appropriate reference data for any flight condition
- **Interpolation Capability**: The structured data allows for interpolation between defined operating points
- **Constraint Enforcement**: Upper and lower bounds ensure the control system respects physical limitations across all flight regimes

## Conclusion: Control System Architecture Insights

The scheduler table generation scripts reveal a sophisticated control architecture designed specifically for the unique challenges of VTOL aircraft:

1. **Hierarchical Structure**: The three-category approach creates a hierarchical control framework:
   - Category 1 defines reference operating points
   - Category 2 provides dynamic control allocation
   - Category 3 ensures safe and optimal operation

2. **Transition Management**: The comprehensive parameter space (especially the 590 configurations) demonstrates a focus on the critical transition phase between vertical and horizontal flight, where control characteristics change dramatically.

3. **Optimization-Based Control**: The presence of weighting matrices and constraints indicates an optimization-based control approach, likely using techniques such as Model Predictive Control or Control Allocation.

4. **Data-Driven Design**: The extensive parameter tables suggest a data-driven approach to control design, where empirical or simulation-derived data defines the control behavior rather than purely analytical models.

5. **Computational Considerations**: The file splitting in the PDI XML script indicates awareness of computational constraints in the flight control hardware, ensuring efficient processing of large parameter sets.

This control parameter structure enables a VTOL aircraft to achieve stable, efficient flight across its entire operating envelope, from vertical takeoff through transition to horizontal flight and back to vertical landing, while maintaining precise control throughout.