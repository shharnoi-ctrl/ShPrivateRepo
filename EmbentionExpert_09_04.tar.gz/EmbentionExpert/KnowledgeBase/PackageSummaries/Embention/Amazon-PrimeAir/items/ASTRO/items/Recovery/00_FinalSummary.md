# Generated from:

- Amazon-PrimeAir/items/ASTRO/items/Recovery/02_Recovery_Navigation_System.md (2926 tokens)
- Amazon-PrimeAir/items/ASTRO/items/Recovery/02_Recovery_Documentation_Tools.md (2796 tokens)
- Amazon-PrimeAir/items/ASTRO/items/Recovery/01_Recovery_System_Overview.md (2549 tokens)

---

# Amazon Prime Air System Overview

This document provides a comprehensive overview of the Amazon Prime Air drone system, focusing on the Recovery subsystem. It serves as an entry point for understanding the system architecture and finding more detailed information about specific components.

## System Architecture Overview

The Amazon Prime Air drone system appears to be a sophisticated autonomous delivery platform with multiple subsystems working together to ensure safe and reliable operation. Based on the available information, the system includes:

1. **Recovery System** - Responsible for safely managing the drone's return to base or controlled landing in various scenarios
2. **Navigation System** - Provides positioning, orientation, and route planning capabilities
3. **Communication System** - Handles diverse communication protocols and message types
4. **GNC (Guidance, Navigation, and Control)** - Manages flight dynamics and control
5. **Documentation and Requirements Management** - Ensures traceability between implementation and requirements

The system follows a modular architecture with well-defined interfaces between components, enabling robust operations while maintaining clear documentation of requirements and implementation details.

## Recovery System

The Recovery system is a critical component responsible for safely managing the drone's return to base or controlled landing. It consists of two primary components:

### Recovery Navigation System

Implemented through the `Blockfactory` class in the `Vblocks` namespace, which serves as a central component factory orchestrating navigation-related functionality. Key features include:

- **Component Management**: Creates and manages navigation components
- **Communication Handling**: Processes diverse communication protocols
- **Command Processing**: Handles contingency and in-flight speed change commands
- **Site Configuration**: Manages location-specific parameters
- **Maintenance Actions**: Coordinates system maintenance operations

For more detailed information, see [Recovery Navigation System](./02_Recovery_Navigation_System.md).

### Navigation Builder

The core component responsible for navigation functionality during recovery operations, initialized with:

- Vehicle processing interface
- Communication parser
- State estimation components
- Navigation introspection components
- Vector data
- Navigation message handlers
- Output manager parameters
- Site configuration

### Communication and Message Handling

The recovery system implements extensive message handling capabilities for:

- **Received Messages**: Telemetry, command responses, maintenance requests
- **Transmitted Messages**: Contingency commands, speed change commands, maintenance responses

### Contingency Handling

Dedicated contingency handling through the `Command_contingency_wrapper_ser` component allows sending contingency commands when needed, critical for managing off-nominal situations during recovery operations.

## Requirements Management and Documentation

The system implements a sophisticated requirements management approach with:

- **Requirements Hierarchy**: High-level requirements linked to low-level technical requirements
- **Verification Status**: Requirements include verification status tracking
- **Traceability**: Requirements are linked across projects and to implementation
- **Documentation Generation**: Automated process using Polarion work item scripts

For more detailed information, see [Recovery Documentation Tools](./02_Recovery_Documentation_Tools.md).

## Key System Capabilities

### Navigation and Positioning

- GNSS signal processing (with preference for real GNSS signals)
- State estimation and introspection
- Position and rotation matrix management
- Site configuration handling

### In-Flight Speed Change Management

Parameters for managing speed changes include:
- Request ID ranges
- Flight identifier
- Time windows (earliest, nominal, latest)
- Compliance deadline
- Speed change mode

### Maintenance Actions

- Setting and retrieving site configuration
- Handling maintenance action requests and responses

### Switchover Handling

Tracks recovery switchover status through the `has_switchover_been_signalled_to_recovery` variable.

## Integration Points

The recovery system integrates with the broader drone operation through:

- **Diverse Communications**: Standardized message types for telemetry and commands
- **Maintenance Interface**: Configuration and status information access
- **GNC Interface**: Coordination with main guidance, navigation, and control systems

## System Parameters

Key parameters affecting system behavior include:

- **Frequency Parameters**: Base frequency for recovery GNC operations and message output frequencies
- **Speed Change Parameters**: Window shift times, compliance deadline, speed change mode
- **GNSS Selection**: Configuration for real GNSS signal usage
- **Site Configuration**: Dynamic radio configuration and device PDI settings

## Project Organization

Requirements are organized by project modules, including:
- Veronte
- GNC (Guidance, Navigation, and Control)
- Base
- DEVICES
- Dynamics
- Geomodel
- Media
- Tunables
- VPGNC

## Further Information

For more detailed information about specific components:

1. [Recovery Navigation System](./02_Recovery_Navigation_System.md) - Details about the navigation component implementation
2. [Recovery Documentation Tools](./02_Recovery_Documentation_Tools.md) - Information about the requirements management and documentation process

This overview provides a high-level understanding of the Amazon Prime Air system architecture, with a focus on the Recovery subsystem. The modular design, comprehensive communication interfaces, and robust contingency handling make it a sophisticated platform for autonomous drone delivery operations.