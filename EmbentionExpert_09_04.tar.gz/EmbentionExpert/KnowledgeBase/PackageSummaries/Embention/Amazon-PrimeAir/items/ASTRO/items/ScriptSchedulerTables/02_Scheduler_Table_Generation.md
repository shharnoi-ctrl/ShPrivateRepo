# Generated from:

- GenerateSchedulerTables.py (748 tokens)
- GenerateSchedulerTablesPDI.py (797 tokens)

---

# High-Fidelity Semantic Knowledge Graph: VTOL Aircraft Control System Scheduler Table Generation

This analysis covers two Python scripts that generate scheduler tables for VTOL (Vertical Take-Off and Landing) aircraft control systems. The scripts process various control parameters and output them in different formats: plain text files and PDI XML files.

## 1. Shared Matrix Manipulation Functions

Both scripts share identical utility functions for matrix manipulation:

### `flatten_matrix(m0)`
- **Purpose**: Converts a matrix in the format `M = [[file1], [file2], ...]` to a continuous array where columns are in consecutive order
- **Implementation**: Uses nested list comprehension to iterate through the matrix
- **Logic**: `[m0[i][j] for j in range(len(m0)) for i in range(len(m0[0]))]`
- **Behavior**: Transposes and flattens the matrix, iterating through columns first, then rows
- **Usage**: Applied to `dfm_dactuator_vtol_N_and_N_m_from_krpm2_and_rad` matrices in both Category 2 data processing

### `get_diag(m)`
- **Purpose**: Extracts diagonal values from a square matrix
- **Implementation**: Uses list comprehension to iterate through diagonal indices
- **Logic**: `[m[i][i] for i in range(len(m))]`
- **Assumption**: The function assumes the input matrix is square
- **Usage**: Applied to `cat3_W_wrench` matrices in Category 3 data processing (only in the text output script)

## 2. Output Format Differences

### Text Output (`GenerateSchedulerTables.py`)

#### `write_to_file(data, name)`
- **Purpose**: Writes processed data to a text file
- **Format**: Comma-separated values with each row on a new line
- **File naming**: Appends ".txt" to the provided name
- **Implementation**:
  ```python
  with open(name + ".txt", "w") as f:
      for line in data:
          for n in line:
              s = f'{n}, '
              f.write(s)
          f.write('\n')
  ```
- **Output files**: `data_cat1.txt`, `data_cat2.txt`, `data_cat3.txt`

### PDI XML Output (`GenerateSchedulerTablesPDI.py`)

#### `write_to_pdi(data, name, idx, cfg_id)`
- **Purpose**: Writes data to a PDI XML file with specific formatting
- **Format**: XML structure with tunarray elements
- **File naming**: Creates files named `ver_spdif_{name}{idx}.xml`
- **XML structure**:
  - Contains ID, filename reference (`{name}{idx}.bin`), version information (7.1.1)
  - Each data element wrapped in `<str-tunarray-element>` tags
- **Implementation**:
  ```python
  with open('ver_spdif_' + name + str(idx) + ".xml", "w") as f:
      filename = name + str(idx) + '.bin'
      header = f'<entry-{name}{idx}>\n    <id>{cfg_id}</id>\n    <filename>{filename}</filename>\n    <version>\n        <major>7</major>\n        <minor>1</minor>\n        <revision>1</revision>\n    </version>\n    <data>\n'
      f.write(header)
      for n in data:
          s = f'        <str-tunarray-element>{n}</str-tunarray-element>\n'
          f.write(s)
      f.write(f'    </data>\n</entry-{name}{idx}>\n')
  ```

#### `write_to_several_pdi(data, name, max_n_per_file, first_cfg_id)`
- **Purpose**: Splits large datasets across multiple PDI XML files
- **Logic**:
  - Calculates number of files needed based on `max_n_per_file` (10,000 elements per file)
  - Iteratively writes chunks of data to separate files
  - Increments configuration IDs sequentially
- **Implementation**:
  ```python
  n_files = ceil(len(data) / max_n_per_file)
  idx = 0
  for i in range(n_files):
      first = idx * max_n_per_file
      last = first + min(max_n_per_file, len(data) - first)
      write_to_pdi(data[first: last], name, idx, first_cfg_id + i)
      print(first, last)  # Debug output showing chunk boundaries
      idx += 1
  ```
- **Output files**: Multiple files named `ver_spdif_sched0-interp{idx}.xml` and `ver_spdif_sched1-interp{idx}.xml`

## 3. Data Categories and Their Significance

The scripts process three distinct categories of data related to VTOL aircraft control:

### Category 1: Trim and Operating Point Data
- **Files processed**:
  - `cat1_w0_vtol_N_and_N_m.txt` (9×13×12×6): Wrench values (forces and moments) at operating points
  - `cat1_u0_krpm2.txt` (9×13×12×6): Motor speeds squared (krpm²) at operating points
  - `cat1_q_trim_from_vtol.txt` (9×13×12×4): Trim parameters derived from VTOL configuration
- **Dimensions**: 9 flight conditions × 13 parameters × 12 configurations × (6+6+4) values
- **Significance**: 
  - Represents trim conditions and operating points for different flight configurations
  - Combines motor speeds, trim parameters, and wrench values (forces and moments)
  - Likely used for baseline control settings across different flight regimes

### Category 2: Actuator Allocation and Dynamics
- **Files processed**:
  - `dfm_dactuator_vtol_N_and_N_m_from_krpm2_and_rad.txt` (590×6×6): Actuator dynamics mapping motor speeds to forces/moments
  - `cat2_q_alloc_from_vtol.txt` (590×4): Allocation parameters derived from VTOL configuration
  - `cat2_ax_az_indices.txt` (9×4): Indices for x and z axes (not directly used in processing)
  - `cat2_num_jacobians.txt` (9): Number of Jacobian matrices (not directly used in processing)
- **Dimensions**: 590 operating points × (36+4) values
- **Significance**:
  - Maps motor speeds and control inputs to resulting forces and moments
  - Represents the actuator allocation matrix for control distribution
  - Critical for translating desired aircraft motion into appropriate motor commands

### Category 3: Control Constraints and Weights (Text Output Only)
- **Files processed**:
  - `cat3_upper_bound_krpm2.txt` (9×6): Upper limits for motor speeds squared
  - `cat3_lower_bound_krpm2.txt` (9×6): Lower limits for motor speeds squared
  - `cat3_W_wrench.txt` (9×6×6): Weighting matrices for wrench optimization
- **Dimensions**: 9 flight conditions × (6+6+6) values
- **Significance**:
  - Defines operational limits for motor speeds
  - Provides weighting factors for control optimization
  - Used for constrained control allocation to prioritize certain control axes
- **Note**: This category is only processed in the text output script, not in the PDI XML script

## 4. Input Data Structure and Flight Configuration Representation

### Dimensional Analysis

1. **First dimension (9)**: Appears in multiple files and likely represents different flight conditions or modes:
   - Appears in `cat1_*` files (first dimension)
   - Appears in `cat2_ax_az_indices.txt` (first dimension)
   - Appears in `cat2_num_jacobians.txt` (length)
   - Appears in `cat3_*` files (first dimension)

2. **Second dimension (13)** in Category 1 files:
   - Likely represents different flight parameters or states
   - Consistent across all Category 1 files

3. **Third dimension (12)** in Category 1 files:
   - Possibly represents different aircraft configurations or control modes
   - Consistent across all Category 1 files

4. **Fourth dimensions**:
   - 6 values in `cat1_w0_vtol_N_and_N_m.txt` and `cat1_u0_krpm2.txt`: Likely 3 forces (Fx, Fy, Fz) and 3 moments (Mx, My, Mz)
   - 4 values in `cat1_q_trim_from_vtol.txt`: Possibly trim parameters for different control axes

5. **Category 2 dimensions (590)**:
   - Represents a large number of operating points or flight conditions
   - Each point has a 6×6 actuator matrix and 4 allocation parameters

### Flight Configuration Representation

The data structure suggests a comprehensive model of VTOL aircraft dynamics:

1. **Flight Conditions (9)**: Different flight regimes such as hover, transition, forward flight, etc.

2. **Parameter Space (13)**: Likely represents variations in flight parameters such as:
   - Airspeed
   - Angle of attack
   - Sideslip angle
   - Altitude
   - Weight/loading conditions

3. **Configuration Modes (12)**: Possibly different aircraft configurations:
   - Different rotor tilt angles
   - Wing positions
   - Control surface settings
   - Payload configurations

4. **Control Dimensions**:
   - 6 motor/actuator outputs (hexacopter or similar configuration)
   - 6 controlled degrees of freedom (3 forces, 3 moments)
   - 4 allocation parameters (possibly representing control priorities or constraints)

## 5. Large Dataset Management

The PDI XML script specifically addresses the challenge of managing large datasets:

### Size Limitation Handling
- **Constant**: `max_float_per_pdi = 10000` defines the maximum number of floating-point values per PDI file
- **Function**: `write_to_several_pdi()` splits large datasets across multiple files
- **Logic**:
  ```python
  n_files = ceil(len(data) / max_n_per_file)
  ```
- **File naming**: Sequential indices appended to base names (`sched0-interp0`, `sched0-interp1`, etc.)
- **Configuration IDs**: Sequential IDs starting from a base value:
  - Category 1: Starting from ID 460
  - Category 2: Starting from ID 466

### Data Processing Differences

The data processing approach differs slightly between the two scripts:

#### Text Output Script:
- Creates nested lists of data rows
- Each category's data is a list of lists
- Example:
  ```python
  data_cat1.append(cat1_u0_krpm2[i][j][k] + cat1_q_trim_from_vtol[i][j][k] + cat1_w0_vtol_N_and_N_m[i][j][k])
  ```

#### PDI XML Script:
- Creates flat lists of all data elements
- Each category's data is a single flat list
- Example:
  ```python
  data_cat1 = data_cat1 + cat1_u0_krpm2[i][j][k] + cat1_q_trim_from_vtol[i][j][k] + cat1_w0_vtol_N_and_N_m[i][j][k]
  ```

## 6. Relationship Between Control Parameters

The scripts reveal important relationships between various control parameters in VTOL aircraft operation:

### Motor Speeds and Wrench Values
- Motor speeds are represented as squared values (krpm²), which is proportional to thrust
- The `dfm_dactuator_vtol_N_and_N_m_from_krpm2_and_rad.txt` file maps these squared motor speeds to forces (N) and moments (N·m)
- This mapping is critical for control allocation and represents the actuator effectiveness matrix

### Trim Parameters and Operating Points
- Category 1 data combines:
  - Base motor speeds (`cat1_u0_krpm2`)
  - Trim parameters (`cat1_q_trim_from_vtol`)
  - Resulting wrench values (`cat1_w0_vtol_N_and_N_m`)
- This represents the equilibrium or trim conditions for different flight configurations
- These operating points serve as the baseline for control linearization

### Control Constraints and Optimization
- Category 3 data defines:
  - Upper and lower bounds for motor speeds
  - Weighting matrices for control allocation optimization
- The diagonal values of the weighting matrices (`get_diag(cat3_W_wrench[i])`) are extracted, suggesting that the optimization prioritizes certain axes over others
- These constraints ensure the control system operates within physical limitations while achieving desired performance

### Allocation Parameters
- The `cat2_q_alloc_from_vtol` parameters (4 values per operating point) likely represent allocation priorities or constraints
- These parameters determine how control commands are distributed among multiple actuators
- They work in conjunction with the actuator dynamics matrix to achieve desired aircraft motion

## 7. File-by-File Breakdown

### GenerateSchedulerTables.py
- **Purpose**: Processes control system data and outputs it in text format
- **Key Functions**:
  - `flatten_matrix(m0)`: Transposes and flattens matrices
  - `get_diag(m)`: Extracts diagonal elements from square matrices
  - `write_to_file(data, name)`: Writes data to text files
- **Data Processing**:
  - Loads 10 input files containing various control parameters
  - Processes data into three categories
  - Outputs three text files: `data_cat1.txt`, `data_cat2.txt`, `data_cat3.txt`
- **Unique Feature**: Processes Category 3 data (constraints and weights)

### GenerateSchedulerTablesPDI.py
- **Purpose**: Processes control system data and outputs it in PDI XML format
- **Key Functions**:
  - `flatten_matrix(m0)`: Same as in the text output script
  - `get_diag(m)`: Same as in the text output script
  - `write_to_pdi(data, name, idx, cfg_id)`: Writes data to a single PDI XML file
  - `write_to_several_pdi(data, name, max_n_per_file, first_cfg_id)`: Splits and writes data to multiple PDI XML files
- **Data Processing**:
  - Loads 7 input files (excludes Category 3 files)
  - Processes data into two categories
  - Outputs multiple PDI XML files with sequential indices
- **Unique Feature**: Handles large datasets by splitting them across multiple files

## 8. Cross-Component Relationships

### Data Flow Diagram

```
Input Files (7-10 files)
    │
    ├─── Category 1 Processing
    │    │
    │    ├─── cat1_u0_krpm2.txt (9×13×12×6)
    │    │    Motor speeds squared at operating points
    │    │
    │    ├─── cat1_q_trim_from_vtol.txt (9×13×12×4)
    │    │    Trim parameters
    │    │
    │    └─── cat1_w0_vtol_N_and_N_m.txt (9×13×12×6)
    │         Wrench values (forces and moments)
    │
    ├─── Category 2 Processing
    │    │
    │    ├─── dfm_dactuator_vtol_N_and_N_m_from_krpm2_and_rad.txt (590×6×6)
    │    │    Actuator dynamics matrix
    │    │
    │    ├─── cat2_q_alloc_from_vtol.txt (590×4)
    │    │    Allocation parameters
    │    │
    │    ├─── cat2_ax_az_indices.txt (9×4) [Not directly used]
    │    │    Axis indices
    │    │
    │    └─── cat2_num_jacobians.txt (9) [Not directly used]
    │         Number of Jacobian matrices
    │
    └─── Category 3 Processing [Text output only]
         │
         ├─── cat3_upper_bound_krpm2.txt (9×6)
         │    Upper limits for motor speeds
         │
         ├─── cat3_lower_bound_krpm2.txt (9×6)
         │    Lower limits for motor speeds
         │
         └─── cat3_W_wrench.txt (9×6×6)
              Weighting matrices for optimization
```

### Functional Relationships

1. **Input Processing**:
   - Both scripts read input files using the same approach
   - File content is parsed using `eval()` after replacing `{{` with `[` and `}}` with `]`
   - This suggests the input files contain Mathematica or similar notation

2. **Data Transformation**:
   - Category 1: Combines motor speeds, trim parameters, and wrench values
   - Category 2: Combines flattened actuator matrices with allocation parameters
   - Category 3: Combines motor speed limits with diagonal elements of weighting matrices

3. **Output Generation**:
   - Text output: Simple comma-separated values in text files
   - PDI XML output: Structured XML with specific tags and file splitting for large datasets

## 9. Referenced Context Files

No additional context files were provided beyond the two main Python scripts analyzed.

## Summary of Key Insights

1. **Control System Structure**: The scripts process data for a VTOL aircraft control system with multiple flight conditions, parameters, and configurations.

2. **Three-Category Approach**:
   - Category 1: Operating points and trim conditions
   - Category 2: Actuator dynamics and allocation
   - Category 3: Control constraints and optimization weights

3. **Matrix Relationships**:
   - Motor speeds (krpm²) → Forces and moments (N and N·m)
   - Trim parameters → Stable operating conditions
   - Weighting matrices → Control prioritization

4. **Data Dimensions**:
   - 9 flight conditions or modes
   - 13 flight parameters
   - 12 aircraft configurations
   - 590 operating points for actuator dynamics
   - 6 control inputs/outputs (likely hexacopter or similar)

5. **Output Formats**:
   - Text files: Simple, comma-separated values
   - PDI XML files: Structured format with size limitations handled through file splitting

6. **Large Dataset Management**: The PDI XML script specifically addresses the challenge of large datasets by splitting them across multiple files with sequential configuration IDs.

This comprehensive analysis reveals the structure and function of a sophisticated VTOL aircraft control system scheduler, showing how motor commands are mapped to aircraft motion across various flight regimes and configurations.