# Generated from:

- _sw_Veronte/code/vblocks/code/include/Blocktype.h (2113 tokens)
- _sw_Veronte/code/vblocks/code/include/Blockfactory.h (788 tokens)
- _sw_Veronte/code/vblocks/code/source/Blockfactory_ver.cpp (10297 tokens)
- _sw_Veronte/code/vblocks/code/source/Blockfactory_amz.cpp (253 tokens)
- _sw_Veronte/code/vblocks/code/include/Basic_blockfactory.h (685 tokens)
- _sw_Veronte/code/vblocks/code/source/Basic_blockfactory.cpp (2868 tokens)
- _sw_Veronte/code/vblocks/code/include/Signals.h (2033 tokens)
- _sw_Veronte/code/vblocks/code/source/Signals.cpp (273 tokens)
- _sw_Veronte/code/vblocks/code/include/Pin_ptr_watch.h (1228 tokens)

## With context from:

- PackageSummaries/Embention/Amazon-PrimeAir/items/ASTRO/items/sw/sw_Astro/items/09_System_Architecture.md (5081 tokens)

---

# VBlocks Library: Core Components and Architecture

This document provides a comprehensive analysis of the VBlocks library's core components, focusing on the block factory system, block type definitions, and signal types. It explains how blocks are created, configured, and connected, and how signals are defined and used for communication between blocks.

## 1. Block Type System

### 1.1 Block Type Enumeration

The VBlocks library defines a comprehensive enumeration of block types in `Blocktype.h`. These types are organized into functional categories:

```cpp
enum Blocktype {
    bt_empty         = 0,    // Empty block

    // Flow control blocks
    bt_batch         = 1,    // Batch of blocks
    bt_switch        = 2,    // Switch between several batches of blocks
    bt_ifelse        = 3,    // If/else conditional execution of blocks
    bt_onfocus       = 4,    // On focus detector block
    bt_phase         = 5,    // Phase specialization of switch
    
    // Array handling blocks
    bt_array_real    = 6,    // Build array of reals
    bt_array_real_split = 7, // Real array splitter
    bt_array_bool_split = 8, // Boolean array splitter
    
    // System variable access blocks
    bt_rvarget       = 9,    // Real variable getter
    bt_rvarset       = 10,   // Real variable setter
    bt_uvarget       = 11,   // Unsigned variable getter
    bt_uvarset       = 12,   // Unsigned variable setter
    bt_bvarget       = 13,   // Boolean variable getter
    bt_bvarset       = 14,   // Boolean variable setter
    bt_posget        = 15,   // Position getter
    bt_posset        = 16,   // Position setter
    
    // ... (many more block types)
    
    bt_monitor       = 122   // Monitor block
};
```

The enumeration includes over 120 different block types, covering:
- Flow control and logic blocks
- Variable access blocks
- Type conversion blocks
- Mathematical function blocks
- Signal processing blocks
- Navigation and guidance blocks
- Control system blocks
- Sensor interface blocks
- And many specialized blocks for specific applications

### 1.2 Block Categories

The block types can be grouped into several functional categories:

1. **Flow Control Blocks** (1-5): Control execution flow within the block system
2. **Array Handling Blocks** (6-8): Create and manipulate arrays of values
3. **System Variable Access Blocks** (9-20): Get and set system variables
4. **Type Casting Blocks** (21-24): Convert between different data types
5. **Constant Value Blocks** (25-26): Provide constant values
6. **Mathematical Function Blocks** (27-46): Perform mathematical operations
7. **Signal Processing Blocks** (47-48): Process signals (filters, FFT)
8. **Control System Blocks** (49-62): Implement control algorithms (PID, fuzzy logic)
9. **Signal Generation Blocks** (63-64): Generate signals (ramps, hysteresis)
10. **Navigation and Guidance Blocks** (72-79): Handle navigation and guidance
11. **Sensor Interface Blocks** (80-96): Interface with various sensors
12. **Specialized Application Blocks** (97-122): Handle specific applications

## 2. Block Factory System

### 2.1 Block Factory Architecture

The `Blockfactory` class is responsible for creating and managing blocks in the VBlocks system. It follows a factory pattern design to instantiate blocks based on their type identifiers.

```cpp
class Blockfactory {
public:
    Blockfactory(Vpgnc::Vpu& uav0,
                 Media::Cfgmgr& cfg,
                 Base::Stepmgr& smgr,
                 Midlevel::Irxfw::Parser& irxfw_parser,
                 const Uint32 block_allocator_size_words16,
                 Base::Checklist& opchlist,
                 Vpgnc::Polymgr_impl& poly,
                 Vpgnc::Airframe_action_wp_publish& aac_publish0);

    Vpgnc::Imarks& get_marks_mgr();
    const Geo::Apos& get_nav_pos() const;
    void post_pdi_load();
    void step_pre_gnc();
    void step_gnc();

private:
    struct Data;
    Data& data;
    const Geo::Apos& nav_pos;
};
```

The `Blockfactory` uses a private implementation pattern with a nested `Data` struct that contains all the implementation details. This pattern helps manage complexity and provides a clean interface.

### 2.2 Block Factory Implementation

The `Blockfactory::Data` struct implements the `Base::Ifactory<Blocks::Iblock>` interface, which defines the `build` method for creating blocks:

```cpp
struct Blockfactory::Data : public Base::Ifactory<Blocks::Iblock> {
    // Constructor and member variables
    
    virtual Blocks::Iblock* build(const Uint16 e, Base::Allocator& alloc);
    
    // Many member variables for different subsystems
    const Ver::HWversion_ver::Id hw_id;
    Vpgnc::Vpu& uav;
    Vpgnc::Vpunav nav;
    Vpgnc::Vcmd cmd;
    Vpgnc::Guidance guid;
    Vpgnc::Rmarkmgr marks;
    // ... (many more components)
    Basic_blockfactory basic_blocks;
};
```

The `build` method is the core of the factory pattern, creating blocks based on their type identifier:

```cpp
Blocks::Iblock* Blockfactory::Data::build(const Uint16 e, Base::Allocator& alloc) {
    Blocks::Iblock* p = 0;
    switch(e) {
        case bt_poly:
            p = alloc.allocate_new<Blk_poly>();
            break;
        case bt_fft:
            p = alloc.allocate_new<Blk_fft>(cyclest);
            break;
        // ... (many more cases)
        default:
            p = basic_blocks.build(e, alloc);
            break;
    }
    return p;
}
```

The factory delegates the creation of basic blocks to a `Basic_blockfactory` instance, which handles common block types.

### 2.3 Basic Block Factory

The `Basic_blockfactory` class handles the creation of fundamental block types:

```cpp
class Basic_blockfactory : public Base::Ifactory<Blocks::Iblock> {
public:
    Basic_blockfactory(Vpgnc::Vpu& uav0,
                       const Geo::Apos& nav_pos0,
                       const Maverick::Irmatrix3& lnb0,
                       Iautotune& iautotune0,
                       const Geo::Icheck_valid_fid& operation_fid_checker0);

    virtual Blocks::Iblock* build(const Uint16 e, Base::Allocator& alloc);

private:
    Vpgnc::Vpu& uav;
    const Geo::Apos& nav_pos;
    const Maverick::Irmatrix3& lnb;
    Iautotune& iautotune;
    Blocks::Libmgr libs;
    const Geo::Icheck_valid_fid& operation_fid_checker;
};
```

The `Basic_blockfactory::build` method creates basic blocks like flow control, variable access, and mathematical function blocks:

```cpp
Blocks::Iblock* Basic_blockfactory::build(const Uint16 e, Base::Allocator& alloc) {
    Blocks::Iblock* p = 0;
    switch (e) {
        case bt_batch:
            p = alloc.allocate_new<Blk_batch>(libs.get_metas());
            break;
        case bt_switch:
            p = alloc.allocate_new<Blk_switch>();
            break;
        // ... (many more cases)
        default:
            break;
    }
    return p;
}
```

### 2.4 Block Memory Allocation

The block factory system uses a custom memory allocator for block creation:

```cpp
// In Blockfactory constructor
block_allocator(Base::Memmgr::get_external_allocator().allocate_mblock<Uint16>(
        block_allocator_size_words16)),
blkmgr(*this, block_allocator),
```

This allocator reserves a fixed-size memory pool for block creation, which helps prevent memory fragmentation and provides deterministic memory usage.

### 2.5 Block Manager

The `Blocks::Blockmgr` class manages the created blocks and their execution:

```cpp
Blocks::Blockmgr blkmgr;  // Block manager
Blockmgr_tun blkmgr_tun;  // Block manager tunable (for extra parameters)
```

The block manager is responsible for:
1. Storing references to created blocks
2. Executing blocks in the correct order
3. Managing block connections
4. Handling block configuration

## 3. Block Initialization and Configuration

### 3.1 Block Factory Constructor

The `Blockfactory` constructor initializes all the components needed for block creation and execution:

```cpp
Blockfactory::Blockfactory(Vpgnc::Vpu& uav0,
                           Media::Cfgmgr& cfg,
                           Base::Stepmgr& smgr,
                           Midlevel::Irxfw::Parser& irxfw_parser,
                           const Uint32 block_allocator_size_words16,
                           Base::Checklist& opchlist,
                           Vpgnc::Polymgr_impl& poly,
                           Vpgnc::Airframe_action_wp_publish& aac_publish0)
```

It takes references to various system components:
- `uav0`: The main UAV data structure
- `cfg`: Configuration manager for system configuration
- `smgr`: Step manager for task scheduling
- `irxfw_parser`: Parser for forwarding messages
- `block_allocator_size_words16`: Size of the block allocator memory pool
- `opchlist`: Operation checklist
- `poly`: Polygon manager
- `aac_publish0`: Airframe action waypoint publisher

### 3.2 Configuration Registration

The constructor registers numerous configuration items with the configuration manager:

```cpp
cfg.add(Base::Cfg::cfg_marks, data.marks.build_tun());
cfg.add(Base::Cfg::cfg_dpqre, data.nav.build_dpqretun());
cfg.add(Base::Cfg::cfg_grav_ext, data.nav.build_gravity_extractor_tun());
// ... (many more configuration registrations)
```

These configurations allow blocks to be configured through the PDI (Parameter Definition Interface) system.

### 3.3 Post-PDI Load Initialization

The `post_pdi_load` method performs initialization steps that must occur after the PDI has been loaded:

```cpp
void Blockfactory::post_pdi_load() {
    data.nav.set_nav_pos(data.ini_pos.get_pos().get_llh());
    Base::Assertions::runtime(Base::Stepmgr::get_instance().get_taskmgr().add_task(data.start0));
}
```

This includes setting the initial navigation position and adding startup tasks to the task manager.

### 3.4 Execution Steps

The `Blockfactory` provides methods for executing blocks in the GNC (Guidance, Navigation, and Control) loop:

```cpp
void Blockfactory::step_pre_gnc() {
    data.nav.sen.step();  // Process sensor step
    data.umis.step();     // Process UAV mission step
}

void Blockfactory::step_gnc() {
    data.gpio_hnd.step_read();
    data.stickrd.step();
    data.blkmgr.step();
    data.gpio_hnd.step_write();
}
```

These methods ensure that blocks are executed in the correct order, with sensor data processing happening before block execution, and output writing happening after block execution.

## 4. Signal Types and Communication

### 4.1 Signal Type Definitions

The VBlocks library defines various signal types in the `Signals.h` file:

```cpp
namespace Signals {
    // Helper for determining the update state of a real array with a real value
    struct Rarrayst {
        static bool set_updated(const bool b, Real& v);
        static bool is_updated(const Real v);
    };

    // Static pressure measurement information
    namespace Stp {
        enum Elems {
            stp_new = 0, // Index of update flag
            stp_p   = 1, // Index of pressure measurement
            stp_e2  = 2  // Index of measurement variance
        };
        static const Uint32 size = 3U;
        typedef Base::Tnarray<Real,size> Mea;
    }

    // Position measurement information
    namespace Pos {
        struct Mea {
            bool is_new;    // True if new measurement was produced in this step
            bool fix;       // True if there is fix, false otherwise
            Geo::Apos pos;  // Measured absolute position
            Base::Rv3 e2;   // Position variance (NED frame)
            Base::Rv3 rb;   // Position of the antenna with respect to center of mass (body frame)
            Real delay;     // Delay of position measurement
            // Methods
        };
    }

    // ... (other signal types)
}
```

The library defines signal types for various measurements:
- Static pressure (`Stp`)
- Position (`Pos`)
- Velocity (`Vel`)
- Relative position (`Drn`)
- Misalignment (`Mis`)
- Terrain height (`Dem`)
- Altimeter (`Alt`)
- Wind (`Wind`)
- IMU (`Imu`)

### 4.2 Signal Update Detection

Each signal type includes a mechanism to detect when it has been updated:

```cpp
// For simple Real values
bool Rarrayst::set_updated(const bool b, Real& v) {
    v = b ? 1.0F : 0.0F;
    return b;
}

bool Rarrayst::is_updated(const Real v) {
    return (v != 0.0F);
}

// For structured types
bool Mea::is_updated(const Mea& v) {
    return v.is_new;
}
```

This allows blocks to detect when their inputs have been updated with new data.

### 4.3 Pin Pointer Watch

The `Pin_ptr_watch` template class provides a mechanism for blocks to monitor their inputs for updates:

```cpp
template <typename T, Uint32 n, typename NW>
class Pin_ptr_watch0 {
public:
    Pin_ptr_watch0();
    bool step();
    bool is_new() const;
    void mark_read();
    const T& read() const;
    const T& operator[](const Uint32 i) const;
    bool cset(Base::Lossy_error& str, const Blocks::Accessiblepins& accpins);

private:
    Blocks::Pin_ptr<T> pinptr;  // Wrapped pin pointer
    const T* cache;             // Cached last pointer
    bool is_newv;               // True if the measurement is new
};
```

This class:
1. Connects to an output pin of another block
2. Monitors the pin for updates
3. Caches the updated value
4. Provides methods to check if the value is new and to read the value

The `step` method checks if the pin has been updated:

```cpp
template <typename T, Uint32 n, typename NW>
inline bool Pin_ptr_watch0<T,n,NW>::step() {
    const T& d = pinptr.read();   // Read only once for performance
    if (NW::is_updated(d))        // Copy address of data only if it is a new measurement
    {
        is_newv = true;
        cache = &d;
    }
    return is_newv;
}
```

### 4.4 Block Connection Configuration

Blocks are connected through a configuration process that uses the `cset` method:

```cpp
template <typename T, Uint32 n, typename NW>
inline bool Pin_ptr_watch0<T,n,NW>::cset(Base::Lossy_error& str, const Blocks::Accessiblepins& accpins) {
    const bool ret = pinptr.cset(str, accpins, n, n);
    if (ret) {
        cache = &pinptr.read();
    }
    return ret;
}
```

This method:
1. Deserializes connection information from a PDI
2. Connects the pin to the requested block's output
3. Checks that the connection is possible (type compatibility, etc.)
4. Initializes the cache with the current value

## 5. Block Execution Flow

### 5.1 Block Manager Step

The block execution flow is controlled by the `Blockmgr::step` method, which is called from `Blockfactory::step_gnc`:

```cpp
void Blockfactory::step_gnc() {
    data.gpio_hnd.step_read();
    data.stickrd.step();
    data.blkmgr.step();  // Execute blocks
    data.gpio_hnd.step_write();
}
```

The block manager executes blocks in a specific order determined by their dependencies.

### 5.2 Block Execution Sequence

The typical block execution sequence is:

1. Read inputs from sensors and system variables
2. Process data through blocks
3. Write outputs to actuators and system variables

This sequence ensures that blocks have access to the latest input data and that their outputs are used in the current control cycle.

### 5.3 Block Libraries

The system supports loading block libraries dynamically:

```cpp
Blocks::Libmgr libs(Base::Memmgr::external, libs_size_words, max_num_libs);

// Register library configurations
for (Uint32 i = 0; i < max_num_libs; ++i) {
    uav0.cfg.add(static_cast<Base::Cfg::Id>(Base::Cfg::cfg_blklib00 + i), libs.build_tun(i));
}
```

These libraries can contain custom block implementations that extend the system's capabilities.

## 6. System Integration

### 6.1 Integration with Navigation System

The block factory integrates with the navigation system through the `Vpgnc::Vpunav` class:

```cpp
Vpgnc::Vpunav nav(Ver::Hmeas::get_kmeas(),
                 Ver::Hlicense::get_kpermissions(),
                 grids.get_gref());
```

This provides blocks with access to navigation data such as position, velocity, and attitude.

### 6.2 Integration with Guidance System

The block factory integrates with the guidance system through the `Vpgnc::Guidance` class:

```cpp
Vpgnc::Guidance guid(cfg,
                  get_route(),
                  nav,
                  opchlist,
                  poly,
                  aac_publish0);
```

This provides blocks with access to guidance data such as waypoints, routes, and guidance modes.

### 6.3 Integration with Command System

The block factory integrates with the command system through the `Vpgnc::Vcmd` class:

```cpp
Vpgnc::Vcmd cmd(cfg,
                 nav,
                 umis,
                 grids.get_gref());
```

This provides blocks with access to command data such as control modes and command inputs.

### 6.4 Integration with STANAG Protocol

The block factory registers handlers for STANAG protocol messages:

```cpp
irxfw_parser.add_rx_hdl(Base::Stanag_msg_type::mission_trans,    data.mt_cmd);
irxfw_parser.add_rx_hdl(Base::Stanag_msg_type::ua_route,         data.ua_route);
// ... (other message handlers)
```

This allows blocks to interact with STANAG protocol messages for mission planning and execution.

## 7. Block Type Implementations

### 7.1 Flow Control Blocks

Flow control blocks manage the execution flow of other blocks:

```cpp
case bt_batch:
    p = alloc.allocate_new<Blk_batch>(libs.get_metas());
    break;
case bt_switch:
    p = alloc.allocate_new<Blk_switch>();
    break;
case bt_ifelse:
    p = alloc.allocate_new<Blk_ifelse>();
    break;
```

These blocks allow for conditional execution, batching of blocks, and switching between different execution paths.

### 7.2 Mathematical Function Blocks

Mathematical function blocks perform various mathematical operations:

```cpp
case bt_fun_r1xr1:
    p = alloc.allocate_new<Blk_fun_r1xr1>();
    break;
case bt_fun_r2xr1:
    p = alloc.allocate_new<Blk_fun_r2xr1>();
    break;
case bt_fun_rnxr1:
    p = alloc.allocate_new<Blk_fun_rnxr1>();
    break;
```

These blocks implement functions with one or more real inputs and one real output.

### 7.3 Control System Blocks

Control system blocks implement various control algorithms:

```cpp
case bt_pid_static:
    p = alloc.allocate_new<Blk_pid_static>(iautotune);
    break;
case bt_pid_tsched:
    p = alloc.allocate_new<Blk_pid_tsched>();
    break;
case bt_fuzzy:
    p = alloc.allocate_new<Blk_fuzzy>();
    break;
```

These blocks implement PID controllers, fuzzy logic controllers, and other control algorithms.

### 7.4 Navigation and Guidance Blocks

Navigation and guidance blocks handle navigation and guidance tasks:

```cpp
case bt_navigation:
    p = alloc.allocate_new<Blk_nav>(nav,
                                    Ver::Hmeas::get_kmeas().navsim,
                                    Ver::Hmeas::get_kmeas().navext,
                                    Ver::Hmeas::get_kmeas().navig_vn300,
                                    Ver::Hmeas::get_kmeas().navextsen,
                                    alloc,
                                    uav.ini_chlist);
    break;
case bt_guidance:
    p = alloc.allocate_new<Blk_guid>(guid);
    break;
```

These blocks provide navigation and guidance functionality for the UAV.

### 7.5 Sensor Interface Blocks

Sensor interface blocks connect to various sensors:

```cpp
case bt_senstp:
    p = alloc.allocate_new<Blk_senstp>(Ver::Hmeas::get_kmeas().stp,
                                       hw_id);
    break;
case bt_senmag:
    p = alloc.allocate_new<Blk_senmag>(Ver::Hmeas::get_kmeas().mag,
                                       nav.sen.get_mag_calibrations(),
                                       hw_id);
    break;
```

These blocks interface with sensors such as static pressure sensors, magnetometers, and GNSS receivers.

## 8. Cross-Component Relationships

### 8.1 Block Factory and Block Manager

The block factory creates blocks and passes them to the block manager:

```
Blockfactory
    |
    v
Blockmgr
    |
    v
Blocks
```

The block manager then executes the blocks in the correct order.

### 8.2 Blocks and Signals

Blocks communicate with each other through signals:

```
Block A
    |
    v
Signal
    |
    v
Block B
```

Signals carry data between blocks and provide a mechanism for detecting updates.

### 8.3 Blocks and System Components

Blocks interact with various system components:

```
Blocks <---> Navigation System
       <---> Guidance System
       <---> Command System
       <---> Sensor System
       <---> Actuator System
```

These interactions allow blocks to access system data and control system behavior.

## 9. Variant-Specific Implementations

### 9.1 Amazon/PA Implementation

The VBlocks library includes a variant-specific implementation for Amazon/PA:

```cpp
struct No_marks : public Vpgnc::Imarks {
    virtual void step() {}
    virtual bool mark_event(const Base::Mblock<Uint16>& marks) const {
        return false;
    }
};

Vpgnc::Imarks& Blockfactory::get_marks_mgr() {
    static No_marks ret;
    return ret;
}
```

This implementation provides a null implementation of the `Imarks` interface for the Amazon/PA variant.

## 10. Summary

The VBlocks library provides a flexible and extensible system for creating, configuring, and connecting blocks that implement various functions for UAV control. Key components include:

1. **Block Type System**: A comprehensive enumeration of block types organized into functional categories.
2. **Block Factory System**: A factory pattern implementation for creating blocks based on their type identifiers.
3. **Signal Types**: A set of signal types for various measurements and data types.
4. **Pin Pointer Watch**: A mechanism for blocks to monitor their inputs for updates.
5. **Block Execution Flow**: A system for executing blocks in the correct order based on their dependencies.
6. **System Integration**: Integration with various system components such as navigation, guidance, and command systems.

The library's architecture allows for easy extension with new block types and signal types, making it a powerful tool for implementing complex control systems for UAVs.