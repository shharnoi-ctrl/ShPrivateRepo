# Generated from:

- include/GncUtilities/Takeoff_manager_unit_test.h (114 tokens)
- include/GncUtilities/Trajectory_planner_utilities_unit_test.h (1419 tokens)
- include/GncUtilities/Geographic_utilities_unit_test.h (130 tokens)
- include/GncUtilities/Body_transformation_unit_test.h (182 tokens)
- include/GncUtilities/Switch_blender_unit_test.h (590 tokens)
- include/GncUtilities/Land_manager_unit_test.h (265 tokens)
- include/GncUtilities/Gnc_vector_saturation_unit_test.h (4393 tokens)
- include/GncUtilities/Flight_dynamics_unit_test.h (507 tokens)
- include/GncUtilities/Vector_saturation_unit_test.h (411 tokens)
- include/GncUtilities/Geometric_utilities_unit_test.h (987 tokens)
- include/GncUtilities/Test_transformation.h (168 tokens)
- include/GncUtilities/Rotation_utilities_unit_test.h (643 tokens)
- source/GncUtilities/Body_transformation_unit_test.cpp (3707 tokens)
- source/GncUtilities/Geographic_utilities_unit_test.cpp (1020 tokens)
- source/GncUtilities/Test_transformation.cpp (11829 tokens)
- source/GncUtilities/Switch_blender_unit_test.cpp (7949 tokens)
- source/GncUtilities/Geometric_utilities_unit_test.cpp (6374 tokens)
- source/GncUtilities/Takeoff_manager_unit_test.cpp (6245 tokens)
- source/GncUtilities/Land_manager_unit_test.cpp (12937 tokens)
- source/GncUtilities/Vector_saturation_unit_test.cpp (46435 tokens)
- source/GncUtilities/Rotation_utilities_unit_test.cpp (9083 tokens)
- source/GncUtilities/Flight_dynamics_unit_test.cpp (42297 tokens)
- source/GncUtilities/Trajectory_planner_utilities_unit_test.cpp (34591 tokens)
- source/utils/Gnc_vector_saturation_unit_test.cpp (60358 tokens)

---

# Comprehensive Analysis of Drone GNC Vector Saturation Utilities

This document provides a detailed analysis of the vector saturation algorithms implemented in the drone Guidance, Navigation, and Control (GNC) system, based on the unit test file `Gnc_vector_saturation_unit_test.cpp`.

## 1. Vector Saturation Overview

The `Gnc_vector_saturation` class implements sophisticated vector saturation mechanisms that constrain control inputs within safe operational limits while preserving desired control characteristics. This is a critical component for ensuring stable flight control by preventing excessive control commands.

### 1.1 Core Saturation Architecture

The vector saturation system applies three sequential types of saturation:

1. **Direction Saturation**: Limits the angular deviation of a vector
2. **Minimum Magnitude Saturation**: Ensures vector components meet minimum magnitude requirements
3. **Maximum Magnitude Saturation**: Constrains vector components to not exceed maximum limits

Each saturation type can be independently enabled or disabled, and the system supports various saturation algorithms for each type.

### 1.2 Direction Saturation Types

Five direction saturation modes are implemented:

1. `PASS_THROUGH`: No direction saturation applied
2. `EULER_CLIPPING`: Constrains Euler angles (pitch and yaw) within specified limits
3. `QUATERNION_ONE_NORM`: Limits quaternion rotation using 1-norm
4. `QUATERNION_TWO_NORM`: Limits quaternion rotation using 2-norm (Euclidean)
5. `QUATERNION_INF_NORM`: Limits quaternion rotation using infinity norm (max component)

### 1.3 Magnitude Saturation Types

Eight magnitude saturation modes are implemented for both minimum and maximum magnitude constraints:

1. `PASS_THROUGH`: No magnitude saturation applied
2. `INDEPENDENT_AXIS_CLIPPING`: Independently clips each axis to its limit
3. `XYZ_DIRECTION_PRESERVING_ONE_NORM`: Preserves direction while limiting magnitude using 1-norm
4. `XYZ_DIRECTION_PRESERVING_TWO_NORM`: Preserves direction while limiting magnitude using 2-norm
5. `XYZ_DIRECTION_PRESERVING_INF_NORM`: Preserves direction while limiting magnitude using infinity norm
6. `XY_DIRECTION_PRESERVING_ONE_NORM_Z_CLIPPING`: Preserves XY direction while independently limiting Z using 1-norm
7. `XY_DIRECTION_PRESERVING_TWO_NORM_Z_CLIPPING`: Preserves XY direction while independently limiting Z using 2-norm
8. `XY_DIRECTION_PRESERVING_INF_NORM_Z_CLIPPING`: Preserves XY direction while independently limiting Z using infinity norm

## 2. Saturation Parameters and Configuration

### 2.1 Interpolable Saturation Limits

The system supports dynamic saturation limits through interpolation tables:

```cpp
// Direction saturation limits (for Euler approach)
// Format: [min_pitch_rad, max_pitch_rad, min_yaw_rad, max_yaw_rad]
euler_direction_saturation_limits_interpolation_table

// Direction saturation limits (for quaternion approach)
// Format: [theta_y_max_rad, theta_z_max_rad]
quat_direction_saturation_limits_interpolation_table

// Minimum magnitude saturation limits
// Format: [x_min, y_min, z_min]
min_magnitude_saturation_limits_interpolation_table

// Maximum magnitude saturation limits
// Format: [x_max, y_max, z_max]
max_magnitude_saturation_limits_interpolation_table
```

These limits can be interpolated based on a parameter (e.g., airspeed), allowing for adaptive constraints.

### 2.2 Compatibility Requirements

The system enforces several compatibility requirements:

1. If both min and max magnitude saturation are enabled, they must use the same saturation type
2. If direction saturation is enabled, magnitude saturation must use fully direction-preserving algorithms
3. Interpolation tables must have the correct dimensions for each saturation type
4. Saturation limits must be valid (e.g., min ≤ max, angles within proper ranges)

## 3. Direction Saturation Implementation

### 3.1 Euler Clipping

The Euler clipping approach constrains pitch and yaw angles within specified limits:

```cpp
// Pseudocode for Euler clipping
void apply_vec_dir_saturation_euler(vec_dirsat, min_pitch_rad, max_pitch_rad, min_yaw_rad, max_yaw_rad) {
    // Extract pitch and yaw from vector
    pitch = atan2(-vec_dirsat[2], vec_dirsat[0]);
    yaw = atan2(vec_dirsat[1], vec_dirsat[0] * cos(pitch) - vec_dirsat[2] * sin(pitch));
    
    // Apply saturation
    pitch_sat = clamp(pitch, min_pitch_rad, max_pitch_rad);
    yaw_sat = clamp(yaw, min_yaw_rad, max_yaw_rad);
    
    // Reconstruct vector
    vec_dirsat[0] = cos(pitch_sat) * cos(yaw_sat);
    vec_dirsat[1] = cos(pitch_sat) * sin(yaw_sat);
    vec_dirsat[2] = -sin(pitch_sat);
}
```

The Euler clipping approach is particularly useful for constraining the pitch and yaw angles of a control vector, such as a thrust direction or attitude command.

### 3.2 Quaternion-Based Direction Saturation

The quaternion-based approaches limit the rotation angle between the input vector and the reference direction:

```cpp
// Pseudocode for quaternion-based direction saturation
void apply_vec_dir_saturation_quaternion(norm_type, vec_dirsat, theta_y_max_rad, theta_z_max_rad) {
    // Compute rotation from reference direction to input vector
    q_rotation = compute_rotation_from_reference_to_vector(vec_dirsat);
    
    // Extract y and z rotation components
    theta_y = extract_y_rotation(q_rotation);
    theta_z = extract_z_rotation(q_rotation);
    
    // Apply saturation based on norm type
    if (norm_type == ONE_NORM) {
        scale = min(1.0, (theta_y_max_rad + theta_z_max_rad) / (abs(theta_y) + abs(theta_z)));
    } else if (norm_type == TWO_NORM) {
        scale = min(1.0, sqrt(theta_y_max_rad^2 + theta_z_max_rad^2) / sqrt(theta_y^2 + theta_z^2));
    } else if (norm_type == INF_NORM) {
        scale_y = min(1.0, theta_y_max_rad / abs(theta_y));
        scale_z = min(1.0, theta_z_max_rad / abs(theta_z));
        scale = min(scale_y, scale_z);
    }
    
    // Apply scaling to rotation
    theta_y_sat = theta_y * scale;
    theta_z_sat = theta_z * scale;
    
    // Reconstruct quaternion and apply to reference direction
    q_rotation_sat = construct_quaternion_from_rotations(theta_y_sat, theta_z_sat);
    vec_dirsat = apply_quaternion_to_reference(q_rotation_sat);
}
```

The quaternion-based approaches provide more flexibility in constraining rotations and are particularly useful for complex 3D control applications.

## 4. Magnitude Saturation Implementation

### 4.1 Independent Axis Clipping

The independent axis clipping approach simply clamps each component independently:

```cpp
// Pseudocode for independent axis clipping (minimum)
void apply_vec_mag_saturation_min_independent(vec, limits) {
    vec[0] = sign(vec[0]) * max(abs(vec[0]), limits[0]);
    vec[1] = sign(vec[1]) * max(abs(vec[1]), limits[1]);
    vec[2] = sign(vec[2]) * max(abs(vec[2]), limits[2]);
}

// Pseudocode for independent axis clipping (maximum)
void apply_vec_mag_saturation_max_independent(vec, limits) {
    vec[0] = sign(vec[0]) * min(abs(vec[0]), limits[0]);
    vec[1] = sign(vec[1]) * min(abs(vec[1]), limits[1]);
    vec[2] = sign(vec[2]) * min(abs(vec[2]), limits[2]);
}
```

This approach is simple but does not preserve the direction of the vector.

### 4.2 Direction-Preserving Saturation

The direction-preserving approaches scale the vector to meet magnitude constraints while maintaining its direction:

```cpp
// Pseudocode for direction-preserving saturation (minimum)
void apply_vec_mag_saturation_min_direction_preserving(vec, limits, norm_type) {
    // Compute vector magnitude based on norm type
    if (norm_type == ONE_NORM) {
        mag = abs(vec[0]) + abs(vec[1]) + abs(vec[2]);
        limit = limits[0] + limits[1] + limits[2];
    } else if (norm_type == TWO_NORM) {
        mag = sqrt(vec[0]^2 + vec[1]^2 + vec[2]^2);
        limit = sqrt(limits[0]^2 + limits[1]^2 + limits[2]^2);
    } else if (norm_type == INF_NORM) {
        mag = max(abs(vec[0]), max(abs(vec[1]), abs(vec[2])));
        limit = max(limits[0], max(limits[1], limits[2]));
    }
    
    // Apply scaling if magnitude is below limit
    if (mag < limit && mag > 0) {
        scale = limit / mag;
        vec[0] *= scale;
        vec[1] *= scale;
        vec[2] *= scale;
    }
}

// Pseudocode for direction-preserving saturation (maximum)
void apply_vec_mag_saturation_max_direction_preserving(vec, limits, norm_type) {
    // Similar to minimum case but with opposite comparison
    // and scaling down instead of up
}
```

The direction-preserving approaches are particularly useful for control applications where the direction of the control vector is more important than its individual components.

### 4.3 Partially Direction-Preserving Saturation

The partially direction-preserving approaches preserve the direction in the XY plane while independently limiting the Z component:

```cpp
// Pseudocode for partially direction-preserving saturation (minimum)
void apply_vec_mag_saturation_min_direction_preserving3dXY(vec, limits, norm_type) {
    // Handle XY components with direction preservation
    if (norm_type == ONE_NORM) {
        mag_xy = abs(vec[0]) + abs(vec[1]);
        limit_xy = limits[0] + limits[1];
    } else if (norm_type == TWO_NORM) {
        mag_xy = sqrt(vec[0]^2 + vec[1]^2);
        limit_xy = sqrt(limits[0]^2 + limits[1]^2);
    } else if (norm_type == INF_NORM) {
        mag_xy = max(abs(vec[0]), abs(vec[1]));
        limit_xy = max(limits[0], limits[1]);
    }
    
    // Apply scaling to XY if needed
    if (mag_xy < limit_xy && mag_xy > 0) {
        scale_xy = limit_xy / mag_xy;
        vec[0] *= scale_xy;
        vec[1] *= scale_xy;
    }
    
    // Handle Z component independently
    vec[2] = sign(vec[2]) * max(abs(vec[2]), limits[2]);
}

// Pseudocode for partially direction-preserving saturation (maximum)
void apply_vec_mag_saturation_max_direction_preserving3dXY(vec, limits, norm_type) {
    // Similar to minimum case but with opposite comparison
    // and scaling down instead of up
}
```

These approaches are particularly useful for VTOL aircraft where horizontal and vertical control may need different constraints.

## 5. Saturation Process Flow

The complete saturation process follows this sequence:

1. Transform input vector to direction saturation frame
2. Apply direction saturation if enabled
3. Transform vector to magnitude saturation frame
4. Apply minimum magnitude saturation if enabled
5. Apply maximum magnitude saturation if enabled
6. Transform vector back to input frame

```cpp
// Pseudocode for complete saturation process
void saturate(vec_in_io, q_dirsat_from_io, q_magsat_from_io, interpolation_point) {
    // Check for valid inputs
    if (!is_valid() || vec_in_io.norm() < epsilon || !q_dirsat_from_io.is_valid() || !q_magsat_from_io.is_valid()) {
        return error_state;
    }
    
    // Get saturation limits for current interpolation point
    dir_limits = interpolate_direction_limits(interpolation_point);
    min_mag_limits = interpolate_min_magnitude_limits(interpolation_point);
    max_mag_limits = interpolate_max_magnitude_limits(interpolation_point);
    
    // Apply direction saturation
    vec_dirsat = transform_to_dirsat_frame(vec_in_io, q_dirsat_from_io);
    if (direction_saturation_enabled) {
        apply_direction_saturation(vec_dirsat, dir_limits);
    }
    vec_io = transform_from_dirsat_frame(vec_dirsat, q_dirsat_from_io);
    
    // Apply magnitude saturation
    vec_magsat = transform_to_magsat_frame(vec_io, q_magsat_from_io);
    if (min_magnitude_saturation_enabled) {
        apply_min_magnitude_saturation(vec_magsat, min_mag_limits);
    }
    if (max_magnitude_saturation_enabled) {
        apply_max_magnitude_saturation(vec_magsat, max_mag_limits);
    }
    vec_out_io = transform_from_magsat_frame(vec_magsat, q_magsat_from_io);
    
    // Update state and return result
    previous_output = vec_out_io;
    return {vec_out_io, activated_saturation, status};
}
```

## 6. Validation and Error Handling

The system implements extensive validation to ensure proper configuration:

1. Validates saturation types are compatible with each other
2. Ensures interpolation tables have correct dimensions
3. Validates saturation limits (e.g., min ≤ max, angles within proper ranges)
4. Handles edge cases like zero-magnitude vectors or invalid quaternions

Error handling includes:
- Returning previous valid output when inputs are invalid
- Setting status flags to indicate saturation activation
- Providing detailed error information for debugging

## 7. Applications in Drone Control

The vector saturation system is particularly valuable for drone control applications:

1. **Attitude Control**: Limiting attitude commands to prevent excessive pitch or roll
2. **Thrust Vector Control**: Constraining thrust direction while preserving intent
3. **Rate Limiting**: Ensuring angular rates stay within safe limits
4. **Transition Management**: Providing different constraints during different flight phases (e.g., takeoff, hover, forward flight)
5. **Adaptive Control**: Adjusting limits based on flight conditions (e.g., airspeed)

## 8. Key Implementation Details

### 8.1 Saturation Output Structure

```cpp
struct Output {
    Maverick::Irvector3 vec_out_io;       // Saturated output vector
    bool activated_saturation;            // Whether any saturation was applied
    bool activated_dir_saturation;        // Whether direction saturation was applied
    bool activated_min_mag_saturation;    // Whether min magnitude saturation was applied
    bool activated_max_mag_saturation;    // Whether max magnitude saturation was applied
    bool status;                          // Whether saturation operation was valid
};
```

### 8.2 Interpolation Mechanism

The system uses interpolation tables to determine saturation limits based on a parameter (e.g., airspeed):

```cpp
// Example interpolation table structure
struct InterpolationTable {
    std::vector<Real> breakpoints;        // Parameter values
    std::vector<std::vector<Real>> values; // Corresponding limit values
};
```

This allows for adaptive saturation limits that change based on flight conditions.

### 8.3 Frame Transformations

The system applies saturation in specific reference frames and then transforms back:

```cpp
// Transform to saturation frame
void transform_to_frame(const Maverick::Irvector3& vec_in, 
                        const Maverick::Irquat& q_frame_from_in,
                        Maverick::Irvector3& vec_frame) {
    q_frame_from_in.b2n(vec_in, vec_frame);
}

// Transform from saturation frame
void transform_from_frame(const Maverick::Irvector3& vec_frame,
                         const Maverick::Irquat& q_frame_from_in,
                         Maverick::Irvector3& vec_out) {
    Maverick::Irquat q_in_from_frame;
    q_in_from_frame.copy(q_frame_from_in);
    q_in_from_frame.conjugate();
    q_in_from_frame.b2n(vec_frame, vec_out);
}
```

This allows saturation to be applied in the most appropriate reference frame for each type of constraint.

## 9. Conclusion

The `Gnc_vector_saturation` class provides a comprehensive framework for constraining control vectors in drone applications. Its flexible architecture supports various saturation algorithms, adaptive limits, and frame transformations, making it a powerful tool for ensuring safe and stable flight control.

The implementation is thoroughly tested with unit tests covering various configurations, edge cases, and saturation behaviors, ensuring robust performance across different flight conditions and control scenarios.

## Referenced Context Files

The following context files provided valuable insights:

- `Vector_saturation_unit_test.h`: Showed implementation of vector saturation algorithms
- `Gnc_vector_saturation_unit_test.h`: Provided detailed information on saturation types and algorithms
- `Rotation_utilities_unit_test.h`: Listed rotation operations and quaternion manipulations