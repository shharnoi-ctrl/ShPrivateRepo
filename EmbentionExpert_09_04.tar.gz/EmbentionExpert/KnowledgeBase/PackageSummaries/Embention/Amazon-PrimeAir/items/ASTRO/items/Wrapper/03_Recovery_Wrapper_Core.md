# Generated from:

- src/AdnVehicleRecoveryWrapperAlgorithms/algorithm/RecoveryWrapper/src/RecoveryWrapperObject.hpp (1741 tokens)
- src/AdnVehicleRecoveryWrapperAlgorithms/algorithm/RecoveryWrapper/src/RecoveryWrapperObject.cc (14996 tokens)
- src/AdnVehicleRecoveryWrapperAlgorithms/algorithm/RecoveryWrapper/src/ConsoleLogging.cpp (4884 tokens)

---

# RecoveryWrapperObject: Comprehensive System Summary

## 1. Functional Behavior and Logic

The RecoveryWrapperObject serves as a backup navigation and control system for a vehicle, designed to take over when the primary system fails. It integrates navigation, controllers, and actuator allocation components to provide a complete backup flight control solution.

### Main Responsibilities

1. **Switchover Detection**: Monitors a system file for a "RECOVERY" signal that triggers switchover from primary to recovery control
2. **Navigation Processing**: Processes sensor inputs (IMU, GNSS, pressure sensors, LIDAR) to maintain state estimation
3. **Control Logic**: Executes flight control algorithms after switchover
4. **Motor Command Generation**: Produces motor RPM commands for vehicle control
5. **Route Tracking**: Manages mission routes and landing procedures

### Core Execution Flow

1. **Initialization Phase**:
   - Initializes navigation, controllers, and mixer components
   - Sets up parameters and installations
   - Configures navigation knobs and parameters

2. **Run Cycle (500Hz)**:
   - Processes sensor inputs (IMU, GNSS, pressure sensors, LIDAR)
   - Checks for switchover signal
   - Runs navigation algorithms
   - Outputs navigation introspection data

3. **Control Cycle (100Hz)**:
   - Processes state estimates
   - Runs route tracker
   - Executes control system algorithms
   - Runs controllers and mixer components
   - Generates motor commands
   - Outputs telemetry and logs

## 2. Control Flow and State Transitions

The RecoveryWrapperObject implements a state machine that manages the vehicle's flight phases:

| State | Trigger | Actions | Next State | Location |
|-------|---------|---------|------------|----------|
| Initializing | System startup | Initialize components | Idle | RecoveryWrapperObject.cc |
| Idle | Navigation initialized | Wait for commands | ReadyForTakeOff | RecoveryWrapperObject.cc |
| ReadyForTakeOff | Pre-flight checks complete | Prepare for takeoff | ReadyForInAirTakeOver | RecoveryWrapperObject.cc |
| ReadyForInAirTakeOver | Switchover signal | Take control from primary | DepartureRecovery | RecoveryWrapperObject.cc |
| DepartureRecovery | Initial control established | Stabilize vehicle | FlyMission | RecoveryWrapperObject.cc |
| FlyMission | Route tracking | Follow mission plan | Land (on command) | RecoveryWrapperObject.cc |
| Land | Landing command or completion | Execute landing procedure | Landed | RecoveryWrapperObject.cc |
| Landed | On ground detection | Disarm motors | KillHazOps | RecoveryWrapperObject.cc |
| KillHazOps | Mission complete | Shutdown systems | - | RecoveryWrapperObject.cc |

### Switchover Logic

```cpp
bool RecoveryWrapperObject::HasSwitchoverBeenSignalled() {
    constexpr int SWITCHOVER_BUFFER_SIZE = 16;
    constexpr auto RECOVERY_STR = "RECOVERY";
    constexpr int REC_STR_SIZE = strlen(RECOVERY_STR);

    char buffer[SWITCHOVER_BUFFER_SIZE];
    int retval = read(fd_notify_, buffer, SWITCHOVER_BUFFER_SIZE);
    if (retval < 0) {
        VSDK_LOG_ERROR_ONCE(GetTextLogger(), "Error reading from %s. Retval: %li. Errno: %s",
                                                switchover_filename_.c_str(),
                                                retval,
                                                strerror(errno));
        return false;
    }
    int offset = lseek(fd_notify_, 0, SEEK_SET);
    if (offset == -1) {
        VSDK_LOG_ERROR_ONCE(GetTextLogger(), "Error seeking to start of file. Retval: %i. Errno: %s", retval, strerror(errno));
        return false;
    }
    return strncmp(buffer, RECOVERY_STR, REC_STR_SIZE) == 0;
}
```

### State Machine Transition Logic

The state machine transitions are primarily managed in the `run()` method, with specific state transitions triggered by:

1. **Switchover detection**: Triggers transition to DepartureRecovery
2. **Controller state**: Determines transitions between FlyMission, Land, and KillHazOps
3. **On-ground detection**: Influences transitions to Landed state

## 3. Inputs and Stimuli

### Sensor Inputs

1. **IMU Data** (`meas_accelgyro`):
   - Accelerometer and gyroscope measurements
   - Used for attitude estimation and navigation
   - Processed at 500Hz in `SetNavigationInputs()`

2. **GNSS Data** (`meas_gnss_A`, `meas_gnss_B`, `meas_gnss_bus_A`, `meas_gnss_bus_B`):
   - Position, velocity, and time information
   - Used for absolute position reference
   - Processed in `PopulateGnssFromVsdkMessage()`

3. **Pressure Sensors** (`meas_dyn_pressure_A/B`, `meas_static_pressure_A/B`):
   - Dynamic and static pressure measurements
   - Used for airspeed and altitude estimation
   - Processed in `SetNavigationInputs()`

4. **LIDAR** (`meas_ground_lidar`):
   - Ground distance measurements
   - Used for precise altitude above ground level
   - Processed in `SetNavigationInputs()`

5. **Time Synchronization** (`timesync_offset_A/B`):
   - GPS to monotonic time offsets
   - Used to synchronize sensor measurements
   - Processed in `SetNavigationInputs()`

### Control Inputs

1. **Controller Commands** (`controller_command`):
   - Commands from higher-level systems
   - Processed by `route_tracker_.HandleControllerCommandInput()`

2. **Route Commands** (`route_command_and_control`):
   - Mission and route information
   - Processed by `route_tracker_.HandleRouteCommandAndControlInput()`

3. **Switchover Signal** (file-based):
   - Trigger to activate recovery system
   - Detected by `HasSwitchoverBeenSignalled()`

4. **Battery Status** (`battery_status`):
   - Battery state of charge
   - Used for mission planning and emergency procedures

## 4. Outputs and Effects

### Primary Outputs

1. **Motor Commands** (`recovery_motor_rpm_command`):
   - RPM commands for each motor
   - Motor arming and enabling states
   - Generated in `run()` method after control processing

2. **Navigation Data** (`state_estimate_debug`, `state_estimate_compact`):
   - Vehicle position, velocity, attitude
   - Navigation status and quality metrics
   - Generated from `PopulateStateEstimateLogOutput()` and `PopulateStateEstimateCompactOutput()`

3. **Navigation Introspection** (`nav_introspect`, `nav_introspect_compact`):
   - Detailed navigation system internal state
   - Sensor fusion information and filter states
   - Generated from `PopulateNavIntrospectFromSimulink()` and `PopulateNavIntrospectCompact()`

4. **Controller Logs** (`recovery_controller_logs`):
   - Control system state and performance metrics
   - State machine status
   - Generated from `PopulateRecoveryControllerLogs()`

### Console Logging

The system provides extensive console logging for debugging and monitoring:
- Parameter and installation information via `ConsoleLogParamsAndInstallations()`
- Navigation integration information via `ConsoleLogIntegrationInfo()`
- GNSS time synchronization via `ConsoleLogGnssTimeSyncOffset()`
- State estimate information via `ConsoleLogStateEstimate()`
- Navigation introspection via `ConsoleLogNavIntrospect()`
- Controller logs via `ConsoleLogRecoveryControllerLogs()`

## 5. Parameters and Configuration

### Navigation Parameters

1. **GNSS Configuration**:
   - `use_receiver_pvt`: Whether to use receiver PVT solution
   - `use_gnss_A`: Whether to use GNSS A or B
   - `use_override_accuracies`: Whether to override GNSS accuracy values
   - `override_horizontal_accuracy_m`: Override value for horizontal accuracy
   - `override_vertical_accuracy_m`: Override value for vertical accuracy
   - `override_speed_accuracy_m_per_s`: Override value for speed accuracy

2. **Time Synchronization**:
   - `use_timesync_A/B`: Which time sync source to use
   - `enable_timesync_override`: Whether to override time sync
   - `debug_timesync_constant_latency_s`: Constant latency for debugging

3. **Navigation Features**:
   - `enable_gravity_aiding`: Whether to use gravity for navigation aiding
   - `enable_bounding_box_protection`: Whether to enable bounding box protection

4. **On-Ground Detection**:
   - `num_votes_to_takeoff`: Number of votes needed to detect takeoff
   - `takeoff_agl_m`: AGL threshold for takeoff detection
   - `takeoff_threshold_vel_m_per_s`: Velocity threshold for takeoff
   - `land_agl_m`: AGL threshold for landing detection
   - `land_threshold_vel_cmd_m_per_s`: Command velocity threshold for landing
   - `land_threshold_vel_m_per_s`: Velocity threshold for landing
   - Various other thresholds for landing detection in different scenarios

### Control Parameters

1. **Guidance Parameters**:
   - `three_d_half_plane_guidance_threshold_m`: 3D half-plane guidance threshold
   - `two_d_waypoint_halfplane_threshold_m`: 2D waypoint half-plane threshold
   - `takeoff_wp_distance_threshold_m`: Takeoff waypoint distance threshold
   - `wp_distance_threshold_m`: Waypoint distance threshold

2. **Landing Parameters**:
   - `land_rate_slow_m_per_s`: Slow landing rate
   - `land_rate_fast_m_per_s`: Fast landing rate

3. **Motor Control**:
   - `rotor_reversal_enabled`: Whether rotor reversal is enabled
   - `rpm_test_params`: Parameters for RPM testing

### Installation Parameters

1. **IMU Installation**:
   - `t_vf_vf2imu_m`: Translation from vehicle frame to IMU
   - `R_imu_from_vf`: Rotation from vehicle frame to IMU

2. **GNSS Installation**:
   - `t_vf_vf2antA/B_m`: Translation from vehicle frame to GNSS antenna

3. **LIDAR Installation**:
   - `t_vf_vf2laser_m`: Translation from vehicle frame to LIDAR
   - `q_vf_from_laser`: Rotation from LIDAR to vehicle frame

## 6. Error Handling and Contingency Logic

### Switchover File Handling

```cpp
int RecoveryWrapperObject::CheckAndOpenSwitchoverFile(const std::string filename) {
    int fd = open(filename.c_str(), O_RDONLY);
    if (fd < 0) {
        VSDK_LOG_ERROR_ONCE(GetTextLogger(), "Error opening %s. Retval: %i. Errno: %s",
                        switchover_filename_.c_str(), fd_notify_, strerror(errno));
    }
    return fd;
}
```

### Navigation Failure Handling

The system tracks navigation initialization status and quality metrics:
- `status.initialized`: Whether navigation is initialized
- `status.posvel_horiz`: Horizontal position/velocity quality
- `status.posvel_vert`: Vertical position/velocity quality
- `status.agl`: Above ground level measurement quality

### Control System Failure Handling

```cpp
const vsdk::Status ctrl_status = ctrl_object_.run(controllers_input, controllers_output);
if (ctrl_status != Status::Success) {
    state_.pri_control_failures++;
    if (state_.pri_control_failures % 10 == 0) {
        VSDK_LOG_ERROR(GetTextLogger(), "Primary Control failed %d times.", state_.pri_control_failures);
    }
}
```

### Mixer Failure Handling

```cpp
const vsdk::Status mixer_status = mixer_object_.run(mixer_input, mixer_output);
vsdk::message::adn::vehicle::controlsystem::ActuatorSetpoints_0_1 pri_setpoints = mixer_output.actuator_setpoints.back();
state_.mixer_return = mixer_output.mixer_return.back();
if (mixer_status != Status::Success) {
    state_.pri_mixer_failures++;
    if (state_.pri_mixer_failures % 10 == 0) {
        VSDK_LOG_ERROR(GetTextLogger(), "Primary Mixer failed %d times.", state_.pri_mixer_failures);
    }
}
```

### Navigation Bypass

For testing or emergency scenarios, the system can bypass its own navigation:
```cpp
if (bypass_nav_) {
    VSDK_LOG_INFO_ONCE(GetTextLogger(), "Recovery NAV is bypassed.");
    // Store Nav's SE, and replace it with the input SE.
    simulink_state_estimate = RecoveryLane_DW.RateTransition_Buffer;
    RecoveryLane_DW.RateTransition_Buffer = buffered_state_estimate_;
}
```

### Arming Protection

The system includes safety checks before arming motors:
```cpp
if (!route_tracker_.IsArmingAllowed()) {
    RecoveryLane_Y.rpm_commands_rpm.MotorStateRequest.MotorStateRequestEnableIntent = MotorStateRequestEnableIntent::Disable;
    RecoveryLane_Y.rpm_commands_rpm.MotorStateRequest.MotorStateRequestArmIntent = MotorStateRequestArmIntent::Disarm;
}
```

## 7. File-by-File Breakdown

### RecoveryWrapperObject.hpp

- Defines the `RecoveryWrapperObject` class that implements the `RecoveryWrapperObjectInterface`
- Includes headers for navigation, controllers, and actuator allocation
- Declares methods for switchover detection, state management, and sensor processing
- Defines helper methods for message population and console logging
- Contains member variables for state tracking, navigation, controllers, and mixer components

### RecoveryWrapperObject.cc

- Implements the constructor, destructor, and core `run()` method
- Handles initialization of navigation, controllers, and mixer components
- Processes sensor inputs and runs navigation algorithms
- Executes control system logic after switchover
- Generates motor commands and outputs telemetry
- Manages state machine transitions and motor arming

### ConsoleLogging.cpp

- Implements console logging methods for debugging and monitoring
- Provides detailed logging of parameters, installations, and system state
- Logs navigation integration information and state estimate data
- Tracks and reports state machine transitions and motor commands
- Provides periodic status updates for key system components

## 8. Cross-Component Relationships

### Navigation and Control Integration

The RecoveryWrapperObject integrates three main components:

1. **Navigation** (Embention navigation wrapper):
   - Processes sensor inputs to produce state estimates
   - Maintains vehicle position, velocity, and attitude
   - Provides input to the control system

2. **Controllers** (ControllersObject):
   - Uses state estimates to generate force and torque commands
   - Follows routes and handles mission planning
   - Manages flight phases and contingency actions

3. **Actuator Allocator** (ActuatorAllocatorObject):
   - Converts force and torque commands to motor RPM commands
   - Handles motor mixing and allocation
   - Provides feedback to the controllers via mixer return

### Data Flow

1. **Sensor Data → Navigation**:
   ```cpp
   SetNavigationInputs(current_time_s, input, inputs_emb);
   emb_nav_wrap.step(inputs_emb);
   RecoveryLane_step0();
   ```

2. **Navigation → Controllers**:
   ```cpp
   controllers_input.state_estimate.emplace_back();
   controllers_input.state_estimate.back().message = std::move(state_estimate_input_msg);
   ```

3. **Controllers → Mixer**:
   ```cpp
   mixer_input.forces_and_torques_request.emplace_back();
   mixer_input.forces_and_torques_request.back().message = std::move(forces_and_torques_request);
   ```

4. **Mixer → Motor Commands**:
   ```cpp
   for(int i = 0; i < rpm_command.kNumMotors; i++){
       rpm_command.rpm_commands[i] = static_cast<int16_t>(pri_setpoints.motor_commanded_rpm.at(i));
   }
   ```

5. **Mixer → Controllers Feedback**:
   ```cpp
   state_.mixer_return = mixer_output.mixer_return.back();
   controllers_input.mixer_return.emplace_back();
   controllers_input.mixer_return.back().message = std::move(state_.mixer_return);
   ```

### Route Tracker Integration

The RouteTracker component manages mission routes and provides commands to the Controllers:

```cpp
route_tracker_input.state_estimate = state_estimate_input_msg;
route_tracker_input.is_recovery_in_control = RecoveryLane_U.do_switchover;
route_tracker_input.pack_state_of_charge_cp = state_.last_battery_soc_cp;
route_tracker_input.battery_soc_received = state_.battery_soc_received;
route_tracker_input.controllers_route_tracking_data = state_.controllers_route_tracking_data;

RouteTrackerOutput route_tracker_output;
route_tracker_.Run(route_tracker_input, route_tracker_output);
```

## 9. Referenced Context Files

No context files were provided in the input.

## Summary

The RecoveryWrapperObject is a comprehensive backup navigation and control system designed to take over vehicle control when the primary system fails. It integrates navigation, controllers, and actuator allocation components to provide a complete flight control solution. The system monitors for a switchover signal, processes sensor inputs, maintains state estimation, executes control algorithms, and generates motor commands.

The system follows a state machine architecture that manages flight phases from initialization through mission execution to landing. It includes extensive error handling, parameter configuration, and console logging capabilities. The integration between navigation, controllers, and actuator allocation components enables seamless control handover and mission continuation after switchover.

The RecoveryWrapperObject runs at two main frequencies: 500Hz for navigation processing (triggered by IMU data) and 100Hz for control processing (triggered by state estimate updates). This dual-rate architecture ensures responsive attitude control while maintaining efficient computational resource usage.