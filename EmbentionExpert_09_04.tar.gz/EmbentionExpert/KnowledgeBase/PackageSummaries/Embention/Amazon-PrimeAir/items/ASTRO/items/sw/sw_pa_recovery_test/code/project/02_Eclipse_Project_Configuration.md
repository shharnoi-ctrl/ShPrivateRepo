# Generated from:

- eclipse/.project (442 tokens)
- eclipse/.cproject (10035 tokens)

---

# Eclipse Project Configuration Analysis for PA_SIL_recovery_test

## 1. Project Overview and Structure

### Project Identity and Nature
- **Project Name**: PA_SIL_recovery_test
- **Project Type**: C/C++ executable project
- **Build System**: CDT Managed Build with GNU toolchain
- **Project Natures**:
  - C Nature (`org.eclipse.cdt.core.cnature`)
  - C++ Nature (`org.eclipse.cdt.core.ccnature`)
  - Managed Build Nature (`org.eclipse.cdt.managedbuilder.core.managedBuildNature`)
  - Scanner Config Nature (`org.eclipse.cdt.managedbuilder.core.ScannerConfigNature`)

### Project Structure
- **Linked Resources**:
  - `include` directory: Links to `PARENT-2-PROJECT_LOC/include`
  - `source` directory: Links to `PARENT-2-PROJECT_LOC/source`
  - These are external directories outside the project's immediate location

### Build Configurations
- **Debug Configuration** (ID: `cdt.managedbuild.config.gnu.exe.debug.251406408`)
  - No optimization (`gnu.cpp.compiler.optimization.level.none`)
  - Maximum debugging information (`gnu.cpp.compiler.debugging.level.max`)
  
- **Release Configuration** (ID: `cdt.managedbuild.config.gnu.exe.release.1799091705`)
  - Maximum optimization (`gnu.cpp.compiler.optimization.level.most`)
  - No debugging information (`gnu.cpp.compiler.debugging.level.none`)

## 2. Project Dependencies

### Referenced Projects
The project has dependencies on 23 other projects:
```
PA_monitor_tests, bsp, first, maverick, base, vpgnc, vblocks, blocks, gnc, dynamics, 
DFS2, DSP2837x_ent, DSP28x, DSP2837x_usb, DSP2838x_ent, pring, devices, geomodel, 
stanag, media, midlevel, veronte, pa_blocks
```

### External Settings
The project imports settings from all dependent projects, including:
- Include paths
- Library paths
- Library files

## 3. Build System Configuration

### Build Commands
- **Primary Build Command**: `org.eclipse.cdt.managedbuilder.core.genmakebuilder`
  - Triggers: clean, full, incremental
- **Secondary Build Command**: `org.eclipse.cdt.managedbuilder.core.ScannerConfigBuilder`
  - Triggers: full, incremental

### Toolchain Configuration
- **Toolchain**: Linux GCC (`cdt.managedbuild.toolchain.gnu.exe.debug.1362929331`)
- **Target Platform**: Debug Platform (`cdt.managedbuild.target.gnu.platform.exe.debug.46801967`)
- **Builder**: GNU Make Builder with parallel build enabled (optimal parallelization)

### Compiler Settings

#### C++ Compiler (Debug Configuration)
- **Tool ID**: `cdt.managedbuild.tool.gnu.cpp.compiler.exe.debug.32261599`
- **Optimization Level**: None (`gnu.cpp.compiler.optimization.level.none`)
- **Debug Level**: Maximum (`gnu.cpp.compiler.debugging.level.max`)
- **Include Paths**: 57 include paths defined, including:
  - Project-specific paths (e.g., `${workspace_loc:/${ProjName}/include}`)
  - Dependent project paths (e.g., `${workspace_loc:/pa_blocks}`)
  - Specialized include directories (e.g., `${workspace_loc:/bsp/include_SIL}`)
  - Test-specific paths (e.g., `${workspace_loc:/pa_blocks/test_pa/database}`)

#### C Compiler (Debug Configuration)
- **Tool ID**: `cdt.managedbuild.tool.gnu.c.compiler.exe.debug.1943033986`
- **Optimization Level**: None (`gnu.c.optimization.level.none`)
- **Debug Level**: Maximum (`gnu.c.debugging.level.max`)
- **Include Paths**: 23 include paths defined, primarily project root directories

### Linker Settings

#### C++ Linker (Debug Configuration)
- **Tool ID**: `cdt.managedbuild.tool.gnu.cpp.linker.exe.debug.426228339`
- **Library Search Paths**: 22 library paths defined, all pointing to Default or Default_recv1 directories of dependent projects
- **Libraries**: 22 libraries linked:
  ```
  pa_blocks, veronte, midlevel, media, stanag, geomodel, devices, pring, DSP2838x_ent, 
  DSP2837x_usb, DSP28x, DSP2837x_ent, DFS2, dynamics, gnc, blocks, vblocks, vpgnc, 
  base, maverick, first, bsp
  ```
- **Group Libraries**: Enabled (`-Wl,--start-group ... -Wl,--end-group`)
  - This resolves circular dependencies between libraries

### Assembler Settings
- **Tool ID**: `cdt.managedbuild.tool.gnu.assembler.exe.debug.473148464`
- **Include Paths**: 26 include paths defined

## 4. Binary Parser and Error Parsers

### Binary Parser
- **Parser**: GNU ELF (`org.eclipse.cdt.core.GNU_ELF`)

### Error Parsers
- GAS Error Parser (`org.eclipse.cdt.core.GASErrorParser`)
- Gmake Error Parser (`org.eclipse.cdt.core.GmakeErrorParser`)
- GLD Error Parser (`org.eclipse.cdt.core.GLDErrorParser`)
- CWD Locator (`org.eclipse.cdt.core.CWDLocator`)
- GCC Error Parser (`org.eclipse.cdt.core.GCCErrorParser`)

## 5. Source Entry Configuration

### Source Entries
- Only the `source` directory is included as a source entry
- This directory is linked to an external location (`PARENT-2-PROJECT_LOC/source`)

## 6. Build Artifact Configuration

### Artifact Settings
- **Artifact Name**: `${ProjName}` (resolves to "PA_SIL_recovery_test")
- **Artifact Type**: Executable (`org.eclipse.cdt.build.core.buildArtefactType.exe`)
- **Clean Command**: `rm -rf`

## 7. External Settings Imports

The project imports external settings from all 23 dependent projects. For each project, it imports:
- Include paths
- Library paths
- Library files

For example, from the `pa_blocks` project:
```xml
<externalSetting>
    <entry flags="VALUE_WORKSPACE_PATH" kind="includePath" name="/pa_blocks"/>
    <entry flags="VALUE_WORKSPACE_PATH" kind="libraryPath" name="/pa_blocks/Default"/>
    <entry flags="RESOLVED" kind="libraryFile" name="pa_blocks" srcPrefixMapping="" srcRootPath=""/>
</externalSetting>
```

## 8. Release Configuration Details

### C++ Compiler (Release Configuration)
- **Optimization Level**: Most (`gnu.cpp.compiler.optimization.level.most`)
- **Debug Level**: None (`gnu.cpp.compiler.debugging.level.none`)
- **Include Paths**: Limited to test-specific paths:
  - `${workspace_loc:/media/sf_sw/sw_Astro/code/pa_blocks/code/test_pa}`
  - `/media/sf_sw/sw_Astro/code/pa_blocks/code/test_pa/database`

### C Compiler (Release Configuration)
- **Optimization Level**: Most (`gnu.c.optimization.level.most`)
- **Debug Level**: None (`gnu.c.debugging.level.none`)
- **Include Paths**: Limited to:
  - `${workspace_loc:/media/sf_sw/sw_Astro/code/pa_blocks/code/test_pa}`

## 9. Build System Relationships

### Dependency Chain
The project has a complex dependency chain with 23 other projects. The build system ensures:
1. All dependent projects are built first
2. Include paths from all projects are available during compilation
3. Library paths from all projects are available during linking
4. All required libraries are linked in the correct order (using library grouping)

### Build Process Flow
1. Scanner configuration runs to detect include paths and symbols
2. C/C++ files are compiled with appropriate include paths
3. Object files are linked with libraries from dependent projects
4. Final executable is produced

## Referenced Context Files

No context files were provided in the input, so this section is not applicable.