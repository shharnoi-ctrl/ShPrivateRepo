# Generated from:

- include/TrajectoryPlanner/Maneuver_coordinate_unit_test.h (1375 tokens)
- include/TrajectoryPlanner/Roll_maneuver_unit_test.h (370 tokens)
- include/TrajectoryPlanner/Turn_maneuver_unit_test.h (548 tokens)
- include/TrajectoryPlanner/Straight_maneuver_unit_test.h (244 tokens)
- include/TrajectoryPlanner/Hover_maneuver_unit_test.h (178 tokens)
- include/TrajectoryPlanner/Waypoint_unit_test.h (264 tokens)
- include/TrajectoryPlanner/Waypoint_coordinate_unit_test.h (276 tokens)
- include/TrajectoryPlanner/Maneuver_unit_test.h (229 tokens)
- include/ControlsCommandProcessor/Trajectory_planner_test.h (2132 tokens)
- include/ControlsCommandProcessor/Imu_batch_loop_test.cpp (2034 tokens)
- source/TrajectoryPlanner/Waypoint_unit_test.cpp (5032 tokens)
- source/TrajectoryPlanner/Waypoint_coordinate_unit_test.cpp (1120 tokens)
- source/TrajectoryPlanner/Hover_maneuver_unit_test.cpp (4771 tokens)
- source/TrajectoryPlanner/Maneuver_coordinate_unit_test.cpp (13234 tokens)
- source/TrajectoryPlanner/Turn_maneuver_unit_test.cpp (10002 tokens)
- source/TrajectoryPlanner/Straight_maneuver_unit_test.cpp (8737 tokens)
- source/TrajectoryPlanner/Roll_maneuver_unit_test.cpp (10201 tokens)
- source/TrajectoryPlanner/Maneuver_unit_test.cpp (7702 tokens)
- source/ControlsCommandProcessor/Trajectory_planner_test.cpp (26091 tokens)

---

# Drone Trajectory Planning System: Comprehensive Summary

This document provides a detailed analysis of the drone trajectory planning system, focusing on the class hierarchy, coordinate transformations, maneuver types, and trajectory generation mechanisms.

## 1. System Architecture Overview

The trajectory planning system is designed to generate smooth flight paths for drones, supporting different flight phases including:

- **VTOL (Vertical Take-Off and Landing)** operations
- **WBF (Wing-Borne Flight)** operations
- **Transition phases** between VTOL and WBF

The system follows a hierarchical structure:

1. **Waypoints** - Basic position/velocity/acceleration points in 3D space
2. **Waypoint Coordinates** - Mathematical representation of waypoints in a coordinate system
3. **Maneuver Coordinates** - Collections of waypoint coordinates with polynomial trajectories
4. **Maneuvers** - Flight segments with specific behaviors (hover, straight, turn, roll)
5. **Routes** - Sequences of maneuvers forming complete flight paths

## 2. Core Data Structures

### 2.1 Waypoint

`Waypoint_msg` represents a point in 3D space with:

```
- p_m[3]: Position vector (North, East, Down) in meters
- v_m_per_s[3]: Velocity vector in meters per second
- a_m_per_s2[3]: Acceleration vector in meters per second squared
- is_valid: Validity flag
```

Key operations:
- Addition of waypoints (vector addition of position, velocity, acceleration)
- Multiplication by scalar (scaling position, velocity, acceleration)
- Setting turning acceleration for curved flight paths

### 2.2 Waypoint Coordinate

`Waypoint_coordinate` represents a waypoint in a transformed coordinate system:

```
- time: Time parameter
- kin[4]: Kinematic state (position, velocity, acceleration, jerk)
- is_valid: Validity flag
```

This abstraction allows representing waypoints in different coordinate frames, facilitating trajectory generation.

### 2.3 Maneuver Coordinate

`Maneuver_coordinate` manages collections of waypoint coordinates and the polynomials connecting them:

```
- wp_coord: Array of waypoint coordinates
- polynomial_list: Array of polynomials defining trajectories between waypoints
- poly_constructed: Flags indicating if polynomials are constructed
- time_scale_factor: Factor for time scaling
- is_valid: Validity flag
```

Key operations:
- Constructing polynomials between waypoint coordinates
- Evaluating position/velocity/acceleration at specific times
- Integrating trajectories
- Scaling time
- Flipping sign of coefficients
- Shifting coordinates

## 3. Maneuver Types

The system implements several maneuver types, each with specific behaviors:

### 3.1 Hover Maneuver

`Hover_maneuver` represents stationary flight:

- Maintains position with zero velocity and acceleration
- Requires identical initial and target positions
- Supports specified heading
- Duration is explicitly set

Validation rules:
- Must be in VTOL phase
- Initial and target positions must be identical
- Velocities and accelerations must be zero

### 3.2 Straight Maneuver

`Straight_maneuver` represents linear motion:

- Supports both VTOL and WBF phases
- Defines a direction vector for movement
- Handles both horizontal and vertical motion

Validation rules:
- For WBF, horizontal speed must be constant
- For VTOL, speeds can vary

### 3.3 Turn Maneuver

`Turn_maneuver` represents curved flight paths:

- Supports both left and right turns
- Maintains constant turn radius
- Defines center of turn and direction
- Handles both level turns and climbing/descending turns

Validation rules:
- Turn radius must be positive
- Turn direction must be defined
- Waypoints must be consistent with turn geometry

### 3.4 Roll Maneuver

`Roll_maneuver` handles transitions between straight flight and turns:

- Manages changing turn radius (0 to R or R to 0)
- Supports both left and right roll directions
- Calculates appropriate acceleration profiles

Validation rules:
- Initial and final turn radii must be valid
- Turn direction must be defined
- Only valid in WBF phase

## 4. Trajectory Generation

### 4.1 Polynomial Construction

The system uses 7th-order polynomials to generate smooth trajectories between waypoints:

```
p(t) = a₀ + a₁t + a₂t² + a₃t³ + a₄t⁴ + a₅t⁵ + a₆t⁶ + a₇t⁷
```

These polynomials satisfy boundary conditions for:
- Position
- Velocity
- Acceleration
- Jerk

The polynomial coefficients are calculated by solving a system of equations based on the boundary conditions at the start and end points.

### 4.2 Coordinate Transformations

The system performs several coordinate transformations:

1. **NED (North-East-Down)** - Global reference frame
2. **Maneuver-specific coordinates** - Local frames for each maneuver type:
   - For straight maneuvers: along-track and cross-track coordinates
   - For turn maneuvers: angular and radial coordinates
   - For roll maneuvers: specialized coordinates for handling changing turn radius

### 4.3 Time Scaling

Trajectories can be time-scaled to adjust the execution speed without changing the spatial path:

```
t_scaled = t / time_scale_factor
```

This affects velocity, acceleration, and jerk appropriately:
- v_scaled = v * time_scale_factor
- a_scaled = a * time_scale_factor²
- j_scaled = j * time_scale_factor³

## 5. Route Planning

### 5.1 Route Construction

A complete route consists of:
- Initial conditions (position, velocity)
- Sequence of maneuvers
- Phase transitions (VTOL to WBF, WBF to VTOL)
- Environment data (pressure, temperature, altitude)

The `Trajectory_planner` class handles:
- Processing route commands
- Constructing maneuvers from route specifications
- Validating route feasibility
- Managing transitions between flight phases

### 5.2 Phase Transitions

The system carefully manages transitions between flight phases:
- VTOL to WBF transitions (outbound)
- WBF to VTOL transitions (inbound)

These transitions are critical points in the route and require special handling to ensure smooth flight behavior.

### 5.3 Environment Data

The system incorporates environmental data:
- Static pressure
- Static temperature
- Reference altitude

This data can be provided externally or defaulted to standard day conditions, affecting flight performance calculations.

## 6. Validation and Error Handling

The system implements extensive validation:

1. **Waypoint validation**:
   - Position, velocity, and acceleration constraints
   - Consistency between consecutive waypoints

2. **Maneuver validation**:
   - Phase-specific constraints
   - Geometric feasibility
   - Speed and acceleration limits

3. **Route validation**:
   - NED origin validity
   - Maneuver sequence consistency
   - Phase transition validity

When validation fails, the system:
- Sets appropriate validity flags to false
- Returns error status codes
- Prevents construction of invalid trajectories

## 7. Coordinate System Details

### 7.1 Maneuver-Specific Coordinate Systems

Each maneuver type uses specialized coordinate systems:

#### Straight Maneuver Coordinates
- X-axis: Along the direction of travel
- Y-axis: Perpendicular to direction of travel
- Z-axis: Vertical direction

#### Turn Maneuver Coordinates
- Angular coordinate: Position along the turn
- Radial coordinate: Distance from turn center
- Vertical coordinate: Height

#### Roll Maneuver Coordinates
- Specialized system handling changing turn radius
- Manages crosstrack acceleration changes

### 7.2 Polynomial Evaluation

For a given time t, the system:
1. Determines which segment contains t
2. Evaluates the corresponding polynomial
3. Transforms the result back to the global frame

This provides position, velocity, and acceleration at any time along the trajectory.

## 8. Implementation Details

### 8.1 Memory Management

The system uses custom array types:
- `Base::Tnarrayresz<T, N>`: Resizable arrays with maximum size N
- `Base::Mblock<T>`: Memory blocks for efficient data passing

### 8.2 Error Tolerance

The system defines several tolerance constants:
- `k_near_eq_tol`: General floating-point comparison tolerance
- `k_near_eq_angle_to_rad`: Angular comparison tolerance
- `k_near_eq_position_tol_m`: Position comparison tolerance

### 8.3 Lane Configuration

The system supports multiple "lanes" for trajectory planning:
- PRIMARY: Main flight path
- MONITOR: Monitoring path
- RECOVERY: Emergency recovery path

Each lane can have different parameters and constraints.

## 9. VTOL-WBF Transition Handling

The transition between VTOL and WBF flight phases is particularly complex:

### 9.1 Outbound Transition (VTOL to WBF)
1. Start with hover or slow VTOL flight
2. Accelerate horizontally
3. Transition to wing-borne flight
4. Roll into WBF straight or turn maneuver

### 9.2 Inbound Transition (WBF to VTOL)
1. Roll out of WBF maneuver
2. Decelerate horizontally
3. Transition to VTOL flight
4. End with hover or slow VTOL flight

These transitions are managed through carefully constructed sequences of maneuvers with appropriate boundary conditions.

## 10. Conclusion

The drone trajectory planning system provides a comprehensive framework for generating smooth, feasible flight paths across different flight phases. Its hierarchical structure, from waypoints to complete routes, enables complex flight behaviors while maintaining physical feasibility and smoothness constraints.

The polynomial-based trajectory generation, coupled with specialized coordinate transformations for each maneuver type, allows for precise control of the drone's motion throughout its flight envelope, ensuring safe and efficient operations in various flight regimes.

## Referenced Context Files

The following context files were particularly helpful in understanding the system:
- `Waypoint_unit_test.h/cpp`: Basic waypoint operations and validation
- `Waypoint_coordinate_unit_test.h/cpp`: Coordinate transformation details
- `Maneuver_coordinate_unit_test.h/cpp`: Polynomial construction and evaluation
- `Hover_maneuver_unit_test.h/cpp`: VTOL hover behavior
- `Straight_maneuver_unit_test.h/cpp`: Linear motion in VTOL and WBF
- `Turn_maneuver_unit_test.h/cpp`: Curved flight paths
- `Roll_maneuver_unit_test.h/cpp`: Transition between straight and turning flight
- `Trajectory_planner_test.h/cpp`: Overall route planning and validation