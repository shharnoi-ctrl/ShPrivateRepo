# Generated from:

- pa_blocks/code/include/Cyphal_com_stats.h (968 tokens)
- pa_blocks/code/source/Cyphal_com_stats.cpp (482 tokens)

## With context from:

- PackageSummaries/Embention/Amazon-PrimeAir/items/ASTRO/items/sw/sw_Astro/code/04_Communication_Systems.md (4759 tokens)

---

# Cyphal Communication Statistics Monitoring System

## 1. Functional Behavior and Logic

### Cyphal_com_stats Class Overview

The `Cyphal_com_stats` class implements a comprehensive communication statistics monitoring system for the drone's Cyphal communication channels. This class tracks and reports various metrics about the communication system's performance, focusing on:

- Reception FIFO occupancy (average and maximum)
- Transmission FIFO occupancy (average and maximum)
- Error event counters for various communication processes

The class monitors multiple elements of the Cyphal communication system:
- `CyphalCAN_in`: Manages reception and reconstruction of Cyphal messages from CAN-bus
- `Cyphal_rx_mgr`: Routes received messages to pre-registered deserializers
- `Cy_forwarder`: Handles transmission of received messages
- `Cyphal_tx_mgr`: Manages transmission of messages from the application and pre-registered serializers

#### Key Responsibilities
- Collect real-time occupancy metrics from communication FIFOs and pools
- Apply Exponentially Weighted Moving Average (EWMA) filtering to smooth metrics
- Track error events across different communication processes
- Periodically publish metrics to system variables for monitoring and diagnostics

#### Implementation Details
- Located in `pa_blocks/code/include/Cyphal_com_stats.h` and `pa_blocks/code/source/Cyphal_com_stats.cpp`
- Uses EWMA filtering to provide stable metrics that reflect recent trends
- Maintains separate filters for reception and transmission occupancy
- Publishes metrics at configurable intervals to system variables

### Initialization and Configuration

The `Cyphal_com_stats` constructor initializes the monitoring system with:
- A reference to the Cyphal suite to monitor (`cy_suite0`)
- A publication period for updating system variables (`pub_per0`)
- A structure containing references to system variables for publishing metrics (`pub_vars0`)

During initialization, all system variables are reset to zero values:
```cpp
pub_vars.rx_ravg = Const::ZERO;
pub_vars.rx_rmax = Const::ZERO;
pub_vars.tx_ravg = Const::ZERO;
pub_vars.tx_rmax = Const::ZERO;
pub_vars.tx_drpcnt = Ku16::u0;
pub_vars.rx_nfdisc = Ku16::u0;
pub_vars.rx_ntabrt = Ku16::u0;
```

### High-Priority Task Execution

The `step_hi()` method is designed to be called from a high-priority task and performs the following operations:
1. Updates the transmission occupancy filter with the current occupancy from `cy_suite.cy_tx_mgr_canfd.get_tx_occ()`
2. Updates the reception occupancy filter with the current occupancy from `cy_suite.cy_in.get_rcv_fifo_occ()`
3. Checks if the publication timeout has expired, and if so:
   - Updates all system variables with the latest metrics
   - Restarts the publication timeout
4. Resets the chronometer for the next filter step calculation

## 2. Control Flow and State Transitions

### Metrics Collection and Publication Flow

The control flow for metrics collection and publication follows a simple periodic pattern:

1. **Initialization**:
   - Reset all system variables to zero
   - Initialize EWMA filters with default parameters
   - Start chronometer for time tracking

2. **Regular Execution** (in `step_hi()`):
   - Calculate time delta since last execution using chronometer
   - Update filters with current occupancy values
   - Check if publication timeout has expired
   - If timeout expired, publish metrics to system variables
   - Reset chronometer for next cycle

3. **Publication Event**:
   - Copy filtered metrics to system variables
   - Copy error counters to system variables
   - Restart publication timeout

This creates a continuous monitoring cycle where metrics are constantly updated internally but only published to system variables at the configured interval.

## 3. Inputs and Stimuli

### Occupancy Metrics
- **Transmission Occupancy**: Retrieved from `cy_suite.cy_tx_mgr_canfd.get_tx_occ()`
  - Represents the current occupancy level of the transmission message pool
  - Used to update the transmission occupancy EWMA filter
  - Located in `Cyphal_com_stats::step_hi()`

- **Reception Occupancy**: Retrieved from `cy_suite.cy_in.get_rcv_fifo_occ()`
  - Represents the current occupancy level of the reception FIFO
  - Used to update the reception occupancy EWMA filter
  - Located in `Cyphal_com_stats::step_hi()`

### Error Counters
- **Transmission Dropped Message Count**: Retrieved from `cy_suite.cy_tx_mgr_canfd.get_drop_count()`
  - Counts messages that couldn't be transmitted due to resource constraints
  - Published directly to system variables
  - Located in `Cyphal_com_stats::step_hi()`

- **Reception Discarded Frame Count**: Retrieved from `cy_suite.cy_in.get_nf_discarded()`
  - Counts CAN frames that were discarded during reception
  - Published to system variables with modulo operation to fit in Uint16
  - Located in `Cyphal_com_stats::step_hi()`

- **Reception Aborted Message Count**: Retrieved from `cy_suite.cy_in.get_nt_discarded()`
  - Counts Cyphal message reconstructions that were aborted
  - Published to system variables with modulo operation to fit in Uint16
  - Located in `Cyphal_com_stats::step_hi()`

### Time Inputs
- **Filter Time Step**: Calculated using `cr_filter.toc()`
  - Provides the time delta for EWMA filter calculations
  - Ensures proper time-based weighting in the filters
  - Located in `Cyphal_com_stats::step_hi()`

- **Publication Timeout**: Managed by `pub_tout.expired()`
  - Determines when to publish metrics to system variables
  - Configured during initialization with `pub_per0`
  - Located in `Cyphal_com_stats::step_hi()`

## 4. Outputs and Effects

### System Variable Updates
- **Reception FIFO Average Occupancy**: Updated in `pub_vars.rx_ravg`
  - Provides a smoothed measure of reception FIFO utilization
  - Updated when publication timeout expires
  - Located in `Cyphal_com_stats::step_hi()`

- **Reception FIFO Maximum Occupancy**: Updated in `pub_vars.rx_rmax`
  - Tracks the filtered maximum of reception FIFO utilization
  - Updated when publication timeout expires
  - Located in `Cyphal_com_stats::step_hi()`

- **Transmission Pool Average Occupancy**: Updated in `pub_vars.tx_ravg`
  - Provides a smoothed measure of transmission pool utilization
  - Updated when publication timeout expires
  - Located in `Cyphal_com_stats::step_hi()`

- **Transmission Pool Maximum Occupancy**: Updated in `pub_vars.tx_rmax`
  - Tracks the filtered maximum of transmission pool utilization
  - Updated when publication timeout expires
  - Located in `Cyphal_com_stats::step_hi()`

- **Transmission Dropped Message Count**: Updated in `pub_vars.tx_drpcnt`
  - Reports the number of messages dropped during transmission
  - Updated when publication timeout expires
  - Located in `Cyphal_com_stats::step_hi()`

- **Reception Discarded Frame Count**: Updated in `pub_vars.rx_nfdisc`
  - Reports the number of CAN frames discarded during reception
  - Modulo operation ensures it fits within Uint16 range
  - Updated when publication timeout expires
  - Located in `Cyphal_com_stats::step_hi()`

- **Reception Aborted Message Count**: Updated in `pub_vars.rx_ntabrt`
  - Reports the number of Cyphal message reconstructions aborted
  - Modulo operation ensures it fits within Uint16 range
  - Updated when publication timeout expires
  - Located in `Cyphal_com_stats::step_hi()`

## 5. Parameters and Configuration

### EWMA Filter Parameters
- **Average Filter Time Constant**: `tau_avr = 0.125F`
  - Defines the time constant for the average occupancy EWMA filter
  - Smaller values make the filter more responsive to recent changes
  - Located in anonymous namespace in `Cyphal_com_stats.cpp`

- **Maximum Filter Time Constant**: `tau_max = 1.0F`
  - Defines the time constant for the maximum occupancy EWMA filter
  - Larger value makes maximum values persist longer
  - Located in anonymous namespace in `Cyphal_com_stats.cpp`

### Publication Parameters
- **Publication Period**: Passed as `pub_per0` to constructor
  - Defines how often metrics are published to system variables
  - Controls the timeout used to trigger publication
  - Located in `Cyphal_com_stats` constructor

### System Variables Structure
- **Vars Structure**: Contains references to all system variables
  - Includes variables for averages, maximums, and error counters
  - Passed to constructor as `pub_vars0`
  - Located in `Cyphal_com_stats.h`

## 6. Error Handling and Contingency Logic

### Counter Overflow Protection
- **Modulo Operation for Uint16 Counters**: Applied to `rx_nfdisc` and `rx_ntabrt`
  - Prevents overflow when counters exceed Uint16 maximum value
  - Ensures counters wrap around cleanly
  - Located in `Cyphal_com_stats::step_hi()`
  ```cpp
  pub_vars.rx_nfdisc = cy_suite.cy_in.get_nf_discarded() % Ku16::uMAX;
  pub_vars.rx_ntabrt = cy_suite.cy_in.get_nt_discarded() % Ku16::uMAX;
  ```

### Resource Protection
- **Copy Constructor and Assignment Operator**: Marked as private
  - Prevents accidental copying of the statistics object
  - Ensures single instance manages the statistics
  - Located in `Cyphal_com_stats.h`
  ```cpp
  Cyphal_com_stats(const Cyphal_com_stats& orig); ///< = delete
  Cyphal_com_stats& operator=(const Cyphal_com_stats& orig); ///< = delete
  ```

## 7. File-by-File Breakdown

### Cyphal_com_stats.h
- Defines the `Cyphal_com_stats` class for monitoring Cyphal communication statistics
- Declares the `Vars` structure for system variable references
- Declares the `Occ_ewma` structure for occupancy filtering
- Provides methods for high-priority task execution
- Contains documentation explaining the purpose and metrics tracked

Key components:
- `Cyphal_com_stats` class: Main class for statistics monitoring
- `Vars` structure: Contains references to system variables for publishing metrics
- `Occ_ewma` structure: Handles occupancy filtering with EWMA
- `step_hi()` method: High-priority task for updating and publishing metrics

### Cyphal_com_stats.cpp
- Implements the `Cyphal_com_stats` class methods
- Defines EWMA filter parameters in an anonymous namespace
- Implements occupancy filtering logic
- Handles periodic publication of metrics to system variables

Key implementations:
- `Occ_ewma::step()`: Updates filters with new occupancy values
- `Cyphal_com_stats::Cyphal_com_stats()`: Initializes monitoring system
- `Cyphal_com_stats::step_hi()`: Updates filters and publishes metrics

## 8. Cross-Component Relationships

### Relationship with Cyphal_suite
- `Cyphal_com_stats` monitors the `Cyphal_suite` through a constant reference
- Accesses occupancy and error metrics from various components:
  - `cy_suite.cy_tx_mgr_canfd`: Provides transmission occupancy and drop count
  - `cy_suite.cy_in`: Provides reception FIFO occupancy and error counts
- This relationship allows comprehensive monitoring without modifying the communication components

### Relationship with System Variables
- `Cyphal_com_stats` publishes metrics to system variables through the `Vars` structure
- System variables are provided externally, allowing flexible integration with monitoring systems
- The publication period is configurable, allowing adaptation to different monitoring requirements

### Integration with Filtering Components
- Uses `Maverick::Ewma` for average filtering
- Uses `Maverick::Ewma0::compute_max` for maximum filtering
- These filtering components ensure metrics are smoothed appropriately for monitoring

### Time Management Integration
- Uses `Base::Chrono` for precise time measurement between filter updates
- Uses `Base::Timeout` for controlling publication frequency
- These time management components ensure accurate filtering and consistent publication

## 9. Referenced Context Files

The following context files provided useful information for understanding the Cyphal communication statistics system:

- **04_Communication_Systems.md**: Provided broader context about the drone's communication systems
  - Helped understand how the statistics monitoring fits into the overall communication architecture
  - Showed the relationship between Cyphal communication and other communication systems
  - Explained the purpose of components being monitored (Cy_forwarder, Cyphal_tx_mgr, etc.)
  - Detailed the error handling and message processing that generates the statistics being monitored

This context file was particularly helpful in understanding the broader communication architecture that the statistics monitoring system observes and reports on.