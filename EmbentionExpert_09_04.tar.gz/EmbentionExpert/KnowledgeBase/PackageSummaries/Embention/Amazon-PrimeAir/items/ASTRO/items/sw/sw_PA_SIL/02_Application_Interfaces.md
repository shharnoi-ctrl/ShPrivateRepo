# Generated from:

- code/AstroConsole/AstroConsole.cpp (812 tokens)
- code/AstroConsole/stdafx.h (76 tokens)
- code/AstroConsole/targetver.h (76 tokens)
- code/AstroConsole/stdafx.cpp (73 tokens)
- code/AstroDLL/Astro_dll_wrapper.h (434 tokens)
- code/AstroDLL/AstroDLL.cpp (948 tokens)
- code/AstroDLL/stdafx.h (100 tokens)
- code/AstroDLL/AstroDLL.h (887 tokens)
- code/AstroDLL/targetver.h (76 tokens)
- code/AstroDLL/stdafx.cpp (72 tokens)
- code/AstroDLL/Astro_dll_wrapper.cpp (1864 tokens)
- code/AstroLinux/source/main.cpp (789 tokens)
- code/AstroSO/include/Astro_so_wrapper.h (446 tokens)
- code/AstroSO/include/AstroSO.h (241 tokens)
- code/AstroSO/source/Astro_so_wrapper.cpp (1782 tokens)
- code/AstroSO/source/AstroSO.cpp (756 tokens)

---

# SIL System Application Interfaces Analysis

This document provides a comprehensive analysis of the SIL (Software-In-the-Loop) system application interfaces, including the console application, DLL interface, and shared object implementations. The analysis covers how these interfaces provide access to the SIL functionality across different platforms.

## 1. System Architecture Overview

The SIL system consists of several key components that work together to provide simulation capabilities:

### 1.1 Core Components

1. **Console Applications**:
   - `AstroConsole` (Windows): Entry point for Windows-based simulation
   - `AstroLinux` (Linux): Entry point for Linux-based simulation

2. **Interface Libraries**:
   - `AstroDLL` (Windows): Dynamic Link Library providing the SIL interface on Windows
   - `AstroSO` (Linux): Shared Object providing the SIL interface on Linux

3. **Wrapper Classes**:
   - `Astro_dll_wrapper`: Manages the Windows DLL interface
   - `Astro_so_wrapper`: Manages the Linux shared object interface

4. **Core Simulation Engine**:
   - `SilBlock`: Internal class that manages threads and I/O for the Veronte software simulation

### 1.2 Cross-Platform Architecture

The system is designed with a consistent cross-platform architecture:

- Common interface definitions (`Sil_io.h`) shared between platforms
- Platform-specific implementations (DLL vs SO) with identical function signatures
- Wrapper classes that abstract platform differences
- Console applications that follow the same execution pattern

## 2. Console Applications

### 2.1 AstroConsole (Windows)

The Windows console application (`AstroConsole.cpp`) serves as the main entry point for the SIL system on Windows platforms.

#### 2.1.1 Initialization Process

1. **Command-Line Parameter Processing**:
   ```cpp
   // Read input parameters
   std::string image_path;
   std::string dll_path;
   std::string hw_version;
   uint16_t id_version;
   for (int i = 1; i < argc; ++i)
   {
       if (strcmp(argv[i], "\\dll") == 0)
       {
           dll_path = argv[++i];
       }
       else if (strcmp(argv[i], "\\image") == 0)
       {
           image_path = argv[++i];
       }
       else if (strcmp(argv[i], "\\hwversion") == 0)
       {
           hw_version = argv[++i];
       }
       else if (strcmp(argv[i], "\\idversion") == 0)
       {
           id_version = isdigit(argv[++i][0]) ? std::stoi(argv[i]) : 0;
       }
   }
   ```

2. **DLL Wrapper Creation**:
   ```cpp
   const std::unique_ptr<Vdll::Astro_dll_wrapper> verdll = std::make_unique<Vdll::Astro_dll_wrapper>(
       dll_path, image_path, hw_version, id_version, stderr);
   ```

3. **Input/Output Structure Initialization**:
   ```cpp
   std::unique_ptr<Ver_input_dll> in_dll = std::make_unique<Ver_input_dll>();
   std::unique_ptr<Ver_output_dll> out_dll = std::make_unique<Ver_output_dll>();
   in_dll->use_input_sensor_data = false; // Do not start simulated sensors
   ```

4. **DLL Loading**:
   ```cpp
   if (!verdll->load_dll())
   {
       return -1;
   }
   ```

#### 2.1.2 Communication Setup

The console application sets up UDP communication for data exchange:

```cpp
static const uint16_t local_udp_port = 56777;
static const uint16_t remote_udp_port = 12345;
static const char* localhost = "127.0.0.1";
Vconsole::Udp_server udp; // UDP manager
udp.listen(localhost, local_udp_port);
```

#### 2.1.3 Simulation Loop

The main simulation loop runs continuously, performing these steps:

1. **Real-time Synchronization**:
   ```cpp
   while (t < next_time)
   {
       const auto pc_time_now = std::chrono::high_resolution_clock::now();
       t = std::chrono::duration<double>(pc_time_now - pc_time_start).count();
   }
   ```

2. **Input Processing**:
   ```cpp
   in_dll->usb.length += udp.read(in_dll->usb.data + in_dll->usb.length, ver_buff_size_bytes - in_dll->usb.length);
   ```

3. **Simulation Step Execution**:
   ```cpp
   next_time = verdll->step(t, in_dll.get(), out_dll.get());
   ```

4. **Output Processing**:
   ```cpp
   udp.write(localhost, remote_udp_port, out_dll->usb.data, out_dll->usb.length);
   ```

5. **Reset Handling**:
   ```cpp
   if (verdll->reset_requested())
   {
       printf_s("\nReset requested\n");
       verdll->free_dll();
       if (!verdll->load_dll())
       {
           return -2;
       }
       next_time = 0;
       t = 0;
       pc_time_start = std::chrono::high_resolution_clock::now();
   }
   ```

### 2.2 AstroLinux (Linux)

The Linux console application (`main.cpp` in AstroLinux) follows the same pattern as the Windows version with platform-specific adaptations.

#### 2.2.1 Key Differences from Windows Version

1. **Shared Object Path Parameter**:
   ```cpp
   if (strcmp(argv[i], "\\so") == 0)
   {
       dll_path = argv[++i];
   }
   ```

2. **Wrapper Class**:
   ```cpp
   const std::unique_ptr<Vdll::Astro_so_wrapper> verdll = std::make_unique<Vdll::Astro_so_wrapper>(
       dll_path, image_path, hw_version, id_version, stderr);
   ```

3. **Input/Output Structure Initialization**:
   ```cpp
   Ver_input_dll in_dll = {};   // DLL inputs
   Ver_output_dll out_dll = {}; // DLL outputs
   ```

4. **UDP Communication**:
   The Linux version has UDP communication code commented out, but the structure is identical to the Windows version.

## 3. DLL Interface (Windows)

### 3.1 AstroDLL Interface Definition

The `AstroDLL.h` file defines the interface for the Windows DLL:

```cpp
extern "C"
{
    static const uint16_t ver_lib_interface_version = 2;
    
    static const Ver_lib_version ver_interface_version = 
    {
        ver_io_interface_version,
        ver_lib_interface_version
    };

    VERONTEDLL_API Ver_lib_version get_dll_interface_version();
    VERONTEDLL_API uint16_t init(char* image_path, char* hw_ver, uint16_t id_ver, FILE* log, Ver_init_out* v);
    VERONTEDLL_API double step(double t, Ver_input_dll* in, Ver_output_dll* out);
    VERONTEDLL_API double get_gnc_period();
    VERONTEDLL_API double get_cio_hi_period();
    VERONTEDLL_API bool reset_requested();

    typedef VERONTEDLL_API Ver_lib_version(*Get_dll_interface_version)();
    typedef VERONTEDLL_API uint16_t(*Init_func)(char* image_path, char* hw_ver, uint16_t id_ver, FILE* log, Ver_init_out* v);
    typedef VERONTEDLL_API double(*Step_func)(double t, Ver_input_dll* in, Ver_output_dll* out);
    typedef VERONTEDLL_API double(*Get_period)();
    typedef VERONTEDLL_API bool(*Reset_requested)();
}
```

### 3.2 AstroDLL Implementation

The `AstroDLL.cpp` file implements the DLL interface:

#### 3.2.1 Global State Variables

```cpp
static SIL::SilBlock* sil = 0;           // Manager of threads and outputs/inputs to Veronte Sw
std::string astro_config = "0";    // Hardware version of Veronte
Uint16 uaddress_ver = 0;                 // Uaddress for hardware version
FILE* veronte_log_file = stderr;         // File used for error loging
bool veronte_reset_request = false;      // Reset requested
```

#### 3.2.2 Key Functions

1. **Initialization**:
   ```cpp
   uint16_t init(char* image_path, char* hw_ver, uint16_t id_ver, FILE* log, Ver_init_out* v)
   {
       if (image_path)
       {
           get_veronte_image_path() = image_path;
       }
       if(!(hw_ver[0] == '\0'))
       {
           astro_config = hw_ver;
       }
       uaddress_ver = id_ver;
       if (log)
       {
           veronte_log_file = log;
       }
       if ((!get_veronte_image_path().empty()) || compute_image_path())
       {
           sil = new SIL::SilBlock(*v);
       }
       return sil ? sil->get_error() : 0xFFFF;
   }
   ```

2. **Simulation Step**:
   ```cpp
   double step(double t, Ver_input_dll* in, Ver_output_dll* out)
   {
       return sil ? sil->step(t, *in, *out) : 0.0F;
   }
   ```

3. **Period Getters**:
   ```cpp
   double get_gnc_period()
   {
       return sil ? sil->get_gnc_period() : 0.0F;
   }

   double get_cio_hi_period()
   {
       return sil ? sil->get_ciohi_period() : 0.0F;
   }
   ```

4. **Reset Status**:
   ```cpp
   bool reset_requested()
   {
       return veronte_reset_request;
   }
   ```

### 3.3 Astro_dll_wrapper Class

The `Astro_dll_wrapper` class provides a C++ wrapper around the DLL interface:

#### 3.3.1 Class Structure

```cpp
class Astro_dll_wrapper
{
public:
    Astro_dll_wrapper(std::string& dll_path0, 
                        std::string& image_path0,
                        std::string& hw_version0,
                        uint16_t& id_version0,
                        FILE* log0);
    ~Astro_dll_wrapper();

    bool load_dll();
    void free_dll();
    bool is_loaded();

    /// Function pointers to access the DLL
    Step_func step;
    Get_period get_cio_hi_period;
    Get_period get_gnc_period;
    Reset_requested reset_requested;

    const Ver_init_out& get_uav_ini_data() const;

private:
    struct Data;                      ///< Forward declaration of internal data (platform dependent)
    const std::unique_ptr<Data> data; ///< Pointer to platform dependent data
    std::string& dll_path;            ///< Path to dll
    std::string& image_path;          ///< Path to image
    std::string& hw_version;          ///< Desired hardware version
    uint16_t& id_version;             ///< Desired uaddress for hardware version
    FILE* log;                        ///< Log file (managed by client class)

    Get_dll_interface_version get_dll_interface_version;
    Init_func init;
    Ver_init_out iout;
};
```

#### 3.3.2 DLL Loading Process

The `load_dll` method handles loading the DLL and setting up function pointers:

```cpp
bool Astro_dll_wrapper::load_dll()
{
    // Find DLL path if not provided
    if (dll_path.empty())
    {
        // Get path to executable and construct DLL path
        // ...
    }

    // Load the DLL
    data->hdll = LoadLibraryA(dll_path.c_str());
    if (data->hdll == NULL)
    {
        print_flush(log, "Could not open Astro.dll, error %d\n", GetLastError());
        return false;
    }

    // Get function pointers
    get_dll_interface_version = (Get_dll_interface_version)GetProcAddress(data->hdll, "get_dll_interface_version");
    init = (Init_func)GetProcAddress(data->hdll, "init");
    step = (Step_func)GetProcAddress(data->hdll, "step");
    get_cio_hi_period = (Get_period)GetProcAddress(data->hdll, "get_cio_hi_period");
    get_gnc_period = (Get_period)GetProcAddress(data->hdll, "get_gnc_period");
    reset_requested = (Reset_requested)GetProcAddress(data->hdll, "reset_requested");

    // Check function pointers
    if ((get_dll_interface_version == NULL) || /* other checks */)
    {
        print_flush(log, "Could not load functions, error %d\n", GetLastError());
        this->free_dll();
        return false;
    }

    // Check interface version
    const Ver_lib_version idllver = get_dll_interface_version();
    if ((idllver.lib_version != ver_interface_version.lib_version) || 
        (idllver.io_version != ver_interface_version.io_version))
    {
        print_flush(log, "Error: Versions do not match\n");
        this->free_dll();
        return false;
    }

    // Initialize the DLL
    const uint16_t error = init(const_cast<char*>(image_path.c_str()), 
                               const_cast<char*>(hw_version.c_str()), 
                               id_version, log, &iout);
    // ...
    return true;
}
```

#### 3.3.3 DLL Unloading Process

```cpp
void Astro_dll_wrapper::free_dll()
{
    if (data->hdll)
    {
        bool freed_once = false;
        const auto start = std::chrono::steady_clock::now();
        while (FreeLibrary(data->hdll) && 
            (std::chrono::duration_cast<std::chrono::seconds>(std::chrono::steady_clock::now() - start).count() < 1))
        {
            print_flush(log, "DLL freed\n");
            freed_once = true;
        }
        // ...
        data->hdll = NULL;
        // Reset function pointers
        // ...
    }
}
```

## 4. Shared Object Interface (Linux)

### 4.1 AstroSO Interface Definition

The `AstroSO.h` file defines the interface for the Linux shared object:

```cpp
#ifdef __cplusplus
extern "C" {
#endif

    static const uint16_t ver_lib_interface_version = 2;

    static const Ver_lib_version ver_interface_version =
    {
        ver_io_interface_version,
        ver_lib_interface_version
    };

    Ver_lib_version get_dll_interface_version();
    uint16_t init(char* image_path, char* hw_ver, uint16_t id_ver, FILE* log, Ver_init_out* v);
    double step(double t, Ver_input_dll* in, Ver_output_dll* out);
    double get_gnc_period();
    double get_cio_hi_period();
    bool reset_requested();

    typedef Ver_lib_version(*Get_dll_interface_version)();
    typedef uint16_t(*Init_func)(char* image_path, char* hw_ver, uint16_t id_ver, FILE* log, Ver_init_out* v);
    typedef double(*Step_func)(double t, Ver_input_dll* in, Ver_output_dll* out);
    typedef double(*Get_period)();
    typedef bool(*Reset_requested)();

#ifdef __cplusplus
}
#endif
```

### 4.2 AstroSO Implementation

The `AstroSO.cpp` file implements the shared object interface:

#### 4.2.1 Global State Variables

```cpp
static SIL::SilBlock* sil = 0;           // Manager of threads and outputs/inputs to Astro Sw
std::string astro_hw_version = "0";    // Hardware version of astro
Uint16 uaddress_ver = 0;                 // Uaddress for hardware version
FILE* veronte_log_file = stderr;         // File used for error loging
bool veronte_reset_request = false;      // Reset requested
```

#### 4.2.2 Key Functions

The implementation of the core functions (`init`, `step`, `get_gnc_period`, `get_cio_hi_period`, `reset_requested`) is identical to the Windows DLL implementation, with the same behavior and error handling.

### 4.3 Astro_so_wrapper Class

The `Astro_so_wrapper` class provides a C++ wrapper around the shared object interface:

#### 4.3.1 Class Structure

```cpp
class Astro_so_wrapper
{
public:
    Astro_so_wrapper(const std::string& so_path0,
                       const std::string& image_path0,
                       const std::string& hw_version0,
                       const uint16_t id_version0,
                       FILE* log0);
    ~Astro_so_wrapper();

    bool load_dll();
    void free_dll();
    bool is_loaded();

    /// Function pointers to access the SO
    Step_func step;
    Get_period get_cio_hi_period;
    Get_period get_gnc_period;
    Reset_requested reset_requested;

    const Ver_init_out& get_uav_ini_data() const;

private:
    struct Data;                      ///< Forward declaration of internal data (platform dependent)
    const std::unique_ptr<Data> data; ///< Pointer to platform dependent data
    std::string so_path;              ///< Path to so
    std::string image_path;           ///< Path to image
    std::string hw_version;           ///< Desired hardware version
    uint16_t id_version;              ///< Desired uaddress for hardware version
    FILE* log;                        ///< Log file (managed by client class)

    Get_dll_interface_version get_dll_interface_version;
    Init_func init;
    Ver_init_out iout;
};
```

#### 4.3.2 Shared Object Loading Process

The `load_dll` method handles loading the shared object and setting up function pointers:

```cpp
bool Astro_so_wrapper::load_dll()
{
    // Find SO path if not provided
    if (so_path.empty())
    {
        // Get path to executable and construct SO path using readlink
        // ...
    }

    // Load the shared object
    data->hdll = dlopen(so_path.c_str(), RTLD_NOW);
    if (data->hdll == nullptr)
    {
        print_flush(log, "Could not open libAstroSO.so, error %s\n", dlerror());
        return false;
    }

    // Get function pointers
    get_dll_interface_version = reinterpret_cast<Get_dll_interface_version>(dlsym(data->hdll, "get_dll_interface_version"));
    init = reinterpret_cast<Init_func>(dlsym(data->hdll, "init"));
    step = reinterpret_cast<Step_func>(dlsym(data->hdll, "step"));
    get_cio_hi_period = reinterpret_cast<Get_period>(dlsym(data->hdll, "get_cio_hi_period"));
    get_gnc_period = reinterpret_cast<Get_period>(dlsym(data->hdll, "get_gnc_period"));
    reset_requested = reinterpret_cast<Reset_requested>(dlsym(data->hdll, "reset_requested"));

    // Check function pointers
    // ...

    // Check interface version
    // ...

    // Initialize the shared object
    const uint16_t error = init(const_cast<char*>(image_path.c_str()), 
                               const_cast<char*>(hw_version.c_str()), 
                               id_version, log, &iout);
    // ...
    return true;
}
```

#### 4.3.3 Shared Object Unloading Process

```cpp
void Astro_so_wrapper::free_dll()
{
    if (data->hdll)
    {
        bool freed_once = false;
        const auto start = std::chrono::steady_clock::now();
        while (dlclose(data->hdll) &&
            (std::chrono::duration_cast<std::chrono::seconds>(std::chrono::steady_clock::now() - start).count() < 1))
        {
            print_flush(log, "SO freed\n");
            freed_once = true;
        }
        // ...
        data->hdll = NULL;
        // Reset function pointers
        // ...
    }
}
```

## 5. Cross-Platform Considerations

### 5.1 Interface Consistency

The system maintains consistent interfaces across platforms:

1. **Function Signatures**: Both Windows and Linux implementations use identical function signatures
2. **Version Checking**: Both platforms use the same version checking mechanism
3. **Error Handling**: Error codes and reporting are consistent across platforms
4. **Configuration Parameters**: Both platforms accept the same configuration parameters

### 5.2 Platform-Specific Differences

Key differences between the Windows and Linux implementations:

1. **Library Loading**:
   - Windows: Uses `LoadLibraryA` and `GetProcAddress`
   - Linux: Uses `dlopen` and `dlsym`

2. **Path Handling**:
   - Windows: Uses backslashes (`\`) and Windows-specific path functions
   - Linux: Uses forward slashes (`/`) and Linux-specific path functions (`readlink`)

3. **Library Unloading**:
   - Windows: Uses `FreeLibrary`
   - Linux: Uses `dlclose`

4. **Error Reporting**:
   - Windows: Uses `GetLastError()`
   - Linux: Uses `dlerror()`

### 5.3 Common Configuration Mechanism

Both platforms support reading configuration from a `dll_config.vcfg` file:

```cpp
std::ifstream config_file("dll_config.vcfg", std::ifstream::in);
if (config_file.is_open())
{
    print_flush(log, "Reading configuration from \"dll_config.vcfg\" file\n");
    std::string line;
    Cfg_param cfg_dll_path("\\dll ", dll_path);  // or "\\so " for Linux
    Cfg_param cfg_image_path("\\image ", image_path);
    Cfg_param cfg_hw_version("\\hwversion ", hw_version);
    std::string aux_id;
    Cfg_param cfg_id_version("\\idversion ", aux_id);
    while (std::getline(config_file, line))
    {
        cfg_dll_path.parse(line);
        cfg_image_path.parse(line);
        cfg_hw_version.parse(line);
        cfg_id_version.parse(line);
    }
    // ...
}
```

## 6. Message Passing and Communication

### 6.1 Input/Output Structures

The system uses common input/output structures defined in `Sil_io.h`:

```cpp
// Ver_input_dll: Contains all inputs to the SIL system
// Ver_output_dll: Contains all outputs from the SIL system
```

### 6.2 UDP Communication

The Windows console application uses UDP for external communication:

```cpp
// Setup
Vconsole::Udp_server udp;
udp.listen(localhost, local_udp_port);

// Input
in_dll->usb.length += udp.read(in_dll->usb.data + in_dll->usb.length, ver_buff_size_bytes - in_dll->usb.length);

// Output
udp.write(localhost, remote_udp_port, out_dll->usb.data, out_dll->usb.length);
```

The Linux version has similar code but it's commented out in the provided source.

## 7. Error Handling

### 7.1 Initialization Errors

Both platforms handle initialization errors by:

1. Checking if the library was loaded successfully
2. Verifying that all function pointers were obtained
3. Comparing interface versions
4. Checking the return code from the `init` function

### 7.2 Runtime Errors

Runtime error handling includes:

1. Checking if the SIL object exists before calling methods
2. Returning default values (0.0 or false) when the SIL object is not available
3. Monitoring for reset requests

### 7.3 Reset Mechanism

Both platforms implement a reset mechanism:

```cpp
if (verdll->reset_requested())
{
    printf("\nReset requested\n");
    verdll->free_dll();
    if (!verdll->load_dll())
    {
        return -2;
    }
    next_time = 0;
    t = 0;
    pc_time_start = std::chrono::high_resolution_clock::now();
}
```

## 8. Initialization Process

### 8.1 Initialization Sequence

The initialization process follows these steps:

1. **Parse Command-Line Arguments**: Get paths, versions, and other configuration
2. **Create Wrapper Object**: Instantiate the appropriate wrapper class
3. **Load Library**: Load the DLL or shared object
4. **Get Function Pointers**: Obtain pointers to the library functions
5. **Check Interface Version**: Verify compatibility
6. **Initialize SIL**: Call the `init` function with the provided parameters
7. **Check Initialization Result**: Verify that initialization was successful

### 8.2 Configuration Parameters

The system accepts these configuration parameters:

1. **Library Path**: Path to the DLL or shared object
2. **Image Path**: Path to the Veronte SD image
3. **Hardware Version**: Desired hardware version
4. **ID Version**: Desired uaddress for hardware version

These can be provided via command-line arguments or a configuration file.

## 9. Referenced Context Files

The following context files were helpful in understanding the system:

- `Sil_io.h`: Contains definitions for the input/output structures used by the SIL system
- `SilBlock.h`: Defines the core simulation engine class that manages threads and I/O
- `Udp_server.h`: Provides UDP communication capabilities for the Windows console application

## 10. Summary

The SIL system provides a consistent interface for simulation across Windows and Linux platforms. The architecture uses platform-specific implementations (DLL and shared object) with identical function signatures, wrapped by C++ classes that abstract the platform differences. The console applications provide the entry point for simulation, handling initialization, communication, and the simulation loop.

The system is designed for flexibility, allowing configuration through command-line arguments or a configuration file. Error handling is comprehensive, covering initialization errors, runtime errors, and providing a reset mechanism.

The cross-platform design ensures that the same simulation capabilities are available on both Windows and Linux, with minimal differences in the code.