# Generated from:

- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/geomodel/06_Core_Geometric_Models.md (4404 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/geomodel/05_Coordinate_Systems.md (3935 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/geomodel/04_Height_And_Terrain.md (6008 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/geomodel/03_Field_Models.md (4642 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/geomodel/02_Obstacle_Management.md (6426 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/geomodel/02_Spatial_Data_Management.md (5572 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/geomodel/01_Testing_Framework.md (4884 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/geomodel/01_Build_System.md (3406 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/geomodel/01_System_Architecture.md (3715 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/geomodel/01_Navigation_And_Guidance.md (4527 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/geomodel/01_Safety_And_Compliance.md (8740 tokens)

---

# Geomodel Library: System Overview and Architecture

This document provides a comprehensive overview of the Geomodel library, a sophisticated geospatial modeling system designed for drone navigation and control. It serves as the primary reference for understanding the system's architecture, components, and capabilities.

## System Purpose and Scope

The Geomodel library provides a comprehensive geospatial modeling framework that enables safe and efficient drone navigation. It integrates position management, obstacle avoidance, terrain following, and geocaging capabilities to address the complex challenges of autonomous flight.

Key capabilities include:
- Precise position representation and manipulation in multiple coordinate systems
- Comprehensive obstacle detection and avoidance
- Terrain modeling and height management
- Geocaging validation and enforcement
- Environmental modeling (gravity, magnetic fields)
- Landing and takeoff site management

## System Architecture

The Geomodel library consists of six major subsystems that work together to provide a complete geospatial modeling solution:

### 1. Core Geometric Models

This foundational subsystem provides the basic geometric primitives and position management capabilities:

- **Apos Class**: Manages absolute positions in 3D space using longitude, latitude, and height coordinates in the WGS84 reference system
- **Geometric Primitives**: Implements Circle, Polygon, Sphere, Prism, and Gellipsoid classes
- **Coordinate Transformations**: Handles conversions between different coordinate systems
- **Position Manipulation**: Provides methods for moving positions and calculating relative vectors

### 2. Spatial Data Management

This subsystem efficiently manages spatial data access and caching:

- **Feature Identifier Caching**: Tracks dependencies between feature identifiers
- **Moving Buffer Map**: Implements a 2D circular buffer for efficient geographic data access
- **Position Buffering**: Manages position history for path following
- **Volume Management**: Organizes 3D volumes for obstacle avoidance
- **SD Card Map Access**: Provides efficient access to map data stored on SD cards

### 3. Obstacle Management

This subsystem handles detection and avoidance of obstacles:

- **Static Obstacle Representation**: Manages fixed obstacles in the environment
- **Moving Obstacle Management**: Tracks dynamic obstacles with velocity information
- **Repulsion Field Combination**: Combines repulsion vectors from multiple obstacles
- **Geocaging Validation**: Ensures compliance with ED270 standard for geofencing
- **Operational Site Management**: Handles runways and landing spots

### 4. Height and Terrain Management

This subsystem manages vertical positioning and terrain information:

- **Height Representation**: Provides unified representation for relative and absolute heights
- **Terrain Data Management**: Accesses and interpolates terrain elevation data
- **Atmospheric Model**: Implements the U.S. Standard Atmosphere 1976 model
- **Height Reference Integration**: Connects different height reference systems (WGS84, MSL, AGL)

### 5. Coordinate Systems

This subsystem handles transformations between different coordinate frames:

- **Geographic Reference Integration**: Unifies multiple geographic data sources
- **Earth-Centered Earth-Fixed Coordinates**: Manages ECEF coordinate representation
- **Coordinate Transformations**: Provides methods for converting between reference frames
- **Local Terrain Model**: Maintains terrain height information near the UAV

### 6. Environmental and Field Models

This subsystem models environmental factors affecting navigation:

- **Gravity Field Management**: Computes gravity with position corrections
- **Magnetic Field Management**: Provides magnetic field vectors for navigation
- **ADS-B Data Processing**: Handles aircraft detection and tracking
- **Feature Configuration**: Manages feature values and coordinate transformations

## Key Data Flows

### Position Management Flow

1. **Position Initialization**:
   - Raw position data (GPS, etc.) enters the system as WGS84 coordinates
   - `Apos` class initializes with these coordinates
   - Height information is resolved through the `Iheight_computer` interface

2. **Position Transformation**:
   - `Gellipsoid` and `Geomodel` classes transform between coordinate systems
   - LLH coordinates are converted to ECEF or NED as needed
   - Small displacements use optimized approximations

3. **Position Caching**:
   - `Fidposcache` caches absolute positions for features
   - `Fidcache` resolves dependency chains for relative features
   - `Frefcache` handles feature references with relative positions

### Obstacle Avoidance Flow

1. **Obstacle Detection**:
   - Static obstacles are defined through configuration
   - Moving obstacles are detected through ADS-B data
   - Terrain obstacles are identified using height data

2. **Repulsion Field Computation**:
   - Each obstacle computes its repulsion vector
   - `Obsadder` combines these vectors into a unified repulsion field
   - The combined field guides the UAV away from obstacles

3. **Geocaging Enforcement**:
   - `Geocage_check` validates polygon configurations against ED270 standard
   - Polygons define operational boundaries (contingency, emergency areas)
   - Inside checking determines if the UAV is within allowed areas

### Terrain Following Flow

1. **Terrain Data Access**:
   - `Srtm_grid` provides terrain height from SRTM data
   - `Geoid_grid` provides geoid height for MSL calculations
   - `Moving_buffer_map` efficiently buffers terrain data around the UAV

2. **Height Reference Management**:
   - WGS84 height is the fundamental reference
   - MSL height is computed as WGS84 - GeoidHeight
   - AGL height is computed as MSL - TerrainHeight

3. **Terrain Avoidance**:
   - `Odem` generates repulsion fields for terrain
   - `Heightbounds` defines vertical limits for 3D volumes
   - Repulsion fields guide the UAV to maintain safe altitude

## Safety Features

The Geomodel library incorporates numerous safety and reliability features:

### Geocaging Validation

The `Geocage_check` class validates that polygons used for geocaging comply with the ED270 standard requirements:

- **Four-Layer Safety Boundary System**:
  - Contingency Area (CA): Primary operating area
  - Emergency Area (EA): Buffer around CA
  - Emergency Security Margin Area (ESMA): Additional buffer
  - Prohibited Area (PA): Absolute boundary

- **Geometric Requirements Validation**:
  - Minimum 30-degree angles between adjacent edges
  - Area size between 200 m² and 100,000 km²
  - Proper spacing between different areas

### Collision Avoidance

- **Time-to-Impact Calculation**: Computes time until potential collision for moving obstacles
- **Repulsion Field Generation**: Creates virtual forces to guide the UAV away from obstacles
- **Multiple Obstacle Types**: Handles static obstacles, moving obstacles, and terrain

### Height Management

- **Multiple Reference Systems**: Supports WGS84, MSL, and AGL height references
- **Vertical Limits**: Enforces upper and lower height bounds
- **Terrain Clearance**: Maintains safe distance above terrain

## Coordinate Systems

The library manages multiple coordinate systems:

1. **LLH (Longitude, Latitude, Height)**:
   - Longitude: Angular distance east/west from prime meridian (-π to π radians)
   - Latitude: Angular distance north/south from equator (-π/2 to π/2 radians)
   - Height: Distance above WGS84 ellipsoid (meters)

2. **ECEF (Earth-Centered Earth-Fixed)**:
   - Origin at Earth's center of mass
   - X-axis through intersection of prime meridian and equator
   - Z-axis through North Pole
   - Y-axis completes right-handed system

3. **NED (North-East-Down)**:
   - Local tangent plane coordinate system
   - North along local meridian
   - East perpendicular to North (eastward)
   - Down toward Earth's center

## Key Components Reference

### Apos Class
Manages absolute positions in 3D space using longitude, latitude, and height coordinates in the WGS84 reference system. Provides methods for position manipulation, coordinate transformations, and height management.

### Geometric Primitives
- **Circle**: 2D horizontal circular area
- **Polygon**: 2D horizontal polygon with up to 75 vertices
- **Sphere**: 3D spherical volume
- **Prism**: 3D volume created by extending a 2D area with height bounds

### Obstacle Management
- **Obstmgr**: Integrates all obstacle management components
- **Movobstacle**: Represents dynamic obstacles with velocity information
- **Obscmd**: Manages a collection of moving obstacles
- **Obsadder**: Combines repulsion fields from multiple obstacles

### Height Management
- **Heightabs**: Represents absolute heights in different reference systems
- **Heightbounds**: Represents upper and lower vertical limits
- **Georef**: Integrates multiple geographic data sources for height information
- **Ussa76**: Implements the U.S. Standard Atmosphere 1976 model

### Coordinate Systems
- **Gellipsoid**: Provides coordinate transformations based on the WGS84 ellipsoid
- **Tecef**: Represents positions in Earth-Centered Earth-Fixed coordinates
- **Geomodel**: Provides rotations between NED and ECEF reference frames

### Operational Sites
- **Rwymgr**: Manages runways and landing spots
- **Runway**: Represents a runway with bidirectional support
- **Spot**: Represents a point for takeoff/landing operations

## Further Information

For more detailed information on specific subsystems, please refer to the following documents:

- [Core Geometric Models](06_Core_Geometric_Models.md)
- [Coordinate Systems](05_Coordinate_Systems.md)
- [Height and Terrain Management](04_Height_And_Terrain.md)
- [Field Models](03_Field_Models.md)
- [Obstacle Management](02_Obstacle_Management.md)
- [Spatial Data Management](02_Spatial_Data_Management.md)
- [Navigation and Guidance](01_Navigation_And_Guidance.md)
- [Safety and Compliance](01_Safety_And_Compliance.md)
- [Testing Framework](01_Testing_Framework.md)
- [Build System](01_Build_System.md)