# Generated from:

- code/include/Apos.h (2566 tokens)
- code/include/Circle.h (1249 tokens)
- code/include/Polygon.h (2195 tokens)
- code/include/Sphere.h (816 tokens)
- code/include/Prism.h (1154 tokens)
- code/include/Gellipsoid.h (1241 tokens)
- code/include/Center_radius.h (192 tokens)
- code/include/Spot.h (592 tokens)
- code/include/Rpos.h (499 tokens)
- code/source/Apos.cpp (3796 tokens)
- code/source/Circle.cpp (682 tokens)
- code/source/Polygon.cpp (4191 tokens)
- code/source/Sphere.cpp (446 tokens)
- code/source/Prism.cpp (981 tokens)
- code/source/Gellipsoid.cpp (1268 tokens)
- code/source/Center_radius.cpp (83 tokens)
- code/source/Spot.cpp (709 tokens)
- code/source/Rpos.cpp (158 tokens)

---

# Comprehensive Summary of Geomodel Library Geometric Models

## 1. Apos Class: Absolute Position Management

The `Apos` class is a fundamental component of the geomodel library that manages absolute positions in 3D space using longitude, latitude, and height coordinates in the WGS84 reference system. It provides extensive functionality for position manipulation, coordinate transformations, and height management.

### Core Functionality

#### Position Representation
- Inherits from `Base::Apos_data` which stores the basic position data
- Maintains pre-computed sines and cosines of latitude and longitude for faster operations
- Supports different height types: WGS84, MSL (Mean Sea Level), and AGL (Above Ground Level)

#### Position Initialization
```cpp
Apos();                                  // Default constructor
explicit Apos(const Base::Tllh& llh0);   // Constructor from high-precision LLH
explicit Apos(const Base::Tllhcompressed& llh0); // Constructor from compressed LLH
```

#### Height Management
```cpp
static void set_height_helper(Iheight_computer& hhlp);  // Set helper for height calculations
Real get_h(Heightabs::Htype type) const;                // Get height of specified type
void set_h(Heightabs::Htype type, Real h);              // Set height of specified type
void get_ah(Real& msl, Real& agl) const;                // Get MSL and AGL heights
```

#### Position Movement and Displacement
```cpp
void move_rn(const Maverick::Irvector3& rn);            // Move position by NED displacement vector
void move_drn(const Maverick::Irvector3& drn);          // Move position by small NED displacement
void geoevol(const Maverick::Irvector3& drn, Base::Tllh_low_res& dllh) const; // Compute LLH displacement
```

#### Relative Position Calculations
```cpp
static void relthis(const Base::Apos_data& pos0, const Base::Apos_data& pos, Maverick::Irvector3& rn); // Calculate NED vector between positions
void relthis(const Base::Apos_data& pos, Maverick::Irvector3& rn) const; // Calculate NED vector to destination
void relthis_drn(const Apos& pos, Maverick::Irvector3& rn) const;        // Calculate NED vector for near positions
Base::Feature frelthis(const Maverick::Irvector3& rn) const;             // Get Feature at displacement
```

#### Coordinate System Transformations
```cpp
void set_ecef(const Tecef& ecef0);                      // Update position from ECEF coordinates
void get_ecef(Tecef& ecef0) const;                      // Get position in ECEF coordinates
void abswrt(const Apos& ref, const Maverick::Irvector3& rn); // Set position from reference + displacement
```

### Implementation Details

#### Height Calculation
The class uses an external height helper (`Iheight_computer`) to calculate different height types:
- WGS84: Raw ellipsoid height
- MSL: Height above mean sea level (WGS84 - sea level offset)
- AGL: Height above ground level (MSL - ground elevation)

#### Position Movement Logic
For small displacements (`move_drn`):
1. Computes LLH displacement using `geoevol`
2. Updates longitude with bounds checking (-π to π)
3. Updates latitude with bounds checking (-π/2 to π/2)
4. Updates height directly
5. Recomputes dependent values (sines/cosines)

For large displacements (`move_rn`):
1. Converts current position to ECEF
2. Transforms displacement from NED to ECEF
3. Adds displacement to current ECEF position
4. Converts back to LLH

#### Relative Position Calculation
For small distances:
- Uses small angle approximation with `geoevol_1`
- Faster but less accurate for large distances

For large distances:
- Converts both positions to ECEF
- Computes vector difference in ECEF
- Transforms result to NED frame

## 2. Geometric Primitives

### 2.1 Circle Class

The `Circle` class represents a 2D horizontal circular area that can be used for events or obstacles.

#### Core Functionality
```cpp
explicit Circle(const Apos* uav_pos0);           // Constructor with UAV position pointer
bool is_inside_obstacle();                       // Check if UAV is inside circle
Real field(const Real vdist, Obsadder& rep);     // Compute repulsion field
void cset(Base::Lossy_error& str);               // Deserialize from PDI
```

#### Inside Checking
The `Inside_checker` nested class provides task-based inside checking:
```cpp
Inside_checker(const Apos& pos0, bool& inside0); // Constructor
void init(Circle& circle0);                      // Initialize with circle
bool step_task();                                // Perform check step
```

#### Implementation Details
- Uses `Center_radius` structure to store center position and radius
- Inside check compares squared distance to squared radius for efficiency
- Repulsion field calculation:
  - For points outside: Creates repulsion vector pointing away from circle
  - For points inside: Creates repulsion vector pointing toward nearest edge

### 2.2 Polygon Class

The `Polygon` class represents a 2D horizontal polygon with up to 75 vertices, supporting both inward (clockwise) and outward (counter-clockwise) directions.

#### Core Functionality
```cpp
explicit Polygon(const Apos* uav_pos0);          // Constructor with UAV position pointer
bool is_inside_obstacle();                       // Check if UAV is inside polygon
Real field(const Real vdist, Obsadder& rep);     // Compute repulsion field
bool step();                                     // Update closest edges
void cset(Base::Lossy_error& str);               // Deserialize from PDI
Fid_array& get_fid();                            // Get array of vertices
```

#### Inside Checking
The `Inside_checker` nested class implements the "ray casting" algorithm:
```cpp
Inside_checker(const Apos& pos0, bool& inside0, bool& outwards0); // Constructor
void init(Polygon& poly0);                       // Initialize with polygon
bool step_task();                                // Perform check step
```

#### Implementation Details
- Stores vertices as an array of `Fidposcache` objects
- Maintains array of closest edges for efficient repulsion calculation
- Edge scanning:
  - Computes distance and direction to each edge
  - Updates array of closest edges
  - Handles special cases for corners
- Inside checking:
  - Uses ray casting algorithm (count intersections with horizontal ray)
  - Determines polygon direction (inward/outward) by calculating signed area

### 2.3 Sphere Class

The `Sphere` class represents a 3D spherical volume in space.

#### Core Functionality
```cpp
Sphere();                                        // Default constructor
Real field(const Apos& uavpos, Obsadder& rep);   // Compute 3D repulsion field
void cset(Base::Lossy_error& str);               // Deserialize from PDI
```

#### Inside Checking
```cpp
Inside_checker(const Apos& pos0, bool& inside0); // Constructor
void init(Sphere& sphere0);                      // Initialize with sphere
bool step_task();                                // Perform check step
```

#### Implementation Details
- Uses `Center_radius` structure to store center position and radius
- Inside check compares squared distance to squared radius
- Repulsion field calculation:
  - Computes vector from sphere center to UAV
  - Calculates signed distance (positive outside, negative inside)
  - Creates normalized repulsion vector

### 2.4 Prism Class

The `Prism` class extends a 2D area (like Circle or Polygon) with height bounds to create a 3D volume.

#### Core Functionality
```cpp
explicit Prism(Iarea& area0);                    // Constructor with base area
void cset(Base::Lossy_error& str);               // Deserialize from PDI
Real field(const Apos& uav_pos, Obsadder& rep);  // Compute prism repulsion
const Heightbounds::Heightlim& get_hlim(bool upper) const; // Get height limit
```

#### Inside Checking
```cpp
Inside_checker(const Apos& pos0, const bool& inside_area0, bool& inside0, const bool& is_outwards0); // Constructor
void init(Prism& prism0, Base::Itask& area0);    // Initialize with prism and area
bool step_task();                                // Perform check step
```

#### Implementation Details
- Combines a horizontal area (`Iarea`) with vertical limits (`Heightbounds`)
- Repulsion field calculation:
  - Checks if UAV is inside vertical bounds
  - Checks if UAV is inside horizontal area
  - Combines repulsions from both horizontal and vertical bounds
- Inside checking:
  - For inward polygons: inside if within both horizontal area and height bounds
  - For outward polygons: inside if within horizontal area OR outside both horizontal area and height bounds

### 2.5 Center_radius Structure

A utility structure used by Circle and Sphere classes to store center position and radius information.

```cpp
struct Center_radius {
    Center_radius();                             // Default constructor
    void cset(Base::Lossy_error& str);           // Deserialize from PDI
    
    Fidposcache f;                               // Center position
    Real r;                                      // Radius
    Real r2;                                     // Squared radius (pre-computed)
};
```

## 3. Gellipsoid Class: Coordinate Transformations

The `Gellipsoid` class provides static methods for coordinate transformations and calculations related to the WGS84 ellipsoid model of the Earth.

### Core Functionality

#### Coordinate System Transformations
```cpp
static void geo2ecef(const Base::Tllcs& cs, const Real h, Tecef& r); // LLH to ECEF conversion
static void ecef2geo3(const Maverick::Irvector3& x, Base::Tllh& llh); // ECEF to LLH conversion
```

#### Earth Angular Velocity
```cpp
static void geow(const Base::Tllcs& cs, Real h, const Maverick::Irvector3& vn,
                Maverick::Irvector3& wen1n, Maverick::Irvector3& wie1n); // Compute Earth angular velocity
```

#### Displacement Calculations
```cpp
static void geoevol(const Real h, const Real clat, const Real slat,
                   const Maverick::Irvector3& dxyz, Base::Tllh_low_res& dgeod); // NED to LLH displacement
                   
static void geoevol_1(const Real h, const Real clat, const Real slat,
                     const Base::Tllh_low_res& dgeod, Maverick::Irvector3& dxyz); // LLH to NED displacement
```

### Implementation Details

#### WGS84 Constants
- Equatorial radius (`a`): `Kgeo::wgs84_re`
- Flattening (`f`): `Kgeo::wgs84_f0`
- Square of first numerical eccentricity (`e2`): `Kgeo::e2`

#### Helper Functions
- `rp(Real slat)`: Computes prime vertical radius of curvature
- `ecoradius2(Real slat, Real& rp0, Real& rm0)`: Computes both prime vertical and meridian radii of curvature

#### Coordinate Transformation Algorithms
- LLH to ECEF:
  1. Calculate prime vertical radius of curvature
  2. Apply standard ellipsoid transformation equations

- ECEF to LLH:
  1. Start with initial guess of latitude
  2. Iteratively refine latitude estimate
  3. Compute final longitude and height

#### Displacement Calculations
- Small displacement approximation:
  - Uses local radii of curvature to convert between NED and LLH
  - Valid for displacements where curvature effects are negligible

## 4. Rpos Class: Relative Position Management

The `Rpos` class manages relative position vectors between absolute positions.

```cpp
class Rpos {
public:
    Rpos();                                      // Default constructor
    
    Apos origin;                                 // Cached absolute reference
    Maverick::Rvector3 rn;                       // Cached relative vector
    
    void relthis(const Apos& pos, Maverick::Irvector3& drn) const; // Compute relative vector
    void relthis(const Maverick::Irvector3& rn, Apos& pos) const;  // Compute absolute position
};
```

### Implementation Details
- Stores an absolute reference position (`origin`)
- Stores a relative position vector in NED coordinates (`rn`)
- Can compute relative vector from absolute position
- Can compute absolute position from relative vector

## 5. Spot Class: Landing/Takeoff Site

The `Spot` class represents a point for takeoff/landing operations with a range of allowed approach angles.

```cpp
class Spot : public Opsite {
public:
    explicit Spot(const Uint16 id);              // Constructor with spot ID
    
    void compute(const Maverick::Irvector3& t, Maverick::Irvector3& ur,
                Geo::Apos& touch, Geo::Apos& dst); // Compute touch point and direction
                
    void cset(Base::Lossy_error& str);           // Deserialize from PDI
    void cget(Base::Lossy& str) const;           // Serialize to PDI
    
private:
    Base::Vref az;                               // Center of range of landing directions
    Base::Radrng rng;                            // Angle range of spot
    Fidposcache location;                        // Location of spot (touch point)
};
```

### Implementation Details
- Defines a touch point location for landing/takeoff
- Specifies a range of allowed approach angles
- Can compute touch point and direction based on current conditions

## 6. Mathematical Foundations

### Coordinate Systems
1. **LLH (Longitude, Latitude, Height)**:
   - Longitude: Angular distance east/west from prime meridian (-π to π radians)
   - Latitude: Angular distance north/south from equator (-π/2 to π/2 radians)
   - Height: Distance above WGS84 ellipsoid (meters)

2. **ECEF (Earth-Centered Earth-Fixed)**:
   - Origin at Earth's center of mass
   - X-axis through intersection of prime meridian and equator
   - Z-axis through North Pole
   - Y-axis completes right-handed system

3. **NED (North-East-Down)**:
   - Local tangent plane coordinate system
   - North along local meridian
   - East perpendicular to North (eastward)
   - Down toward Earth's center

### Key Algorithms

#### Inside/Outside Checking
1. **Circle**: Point is inside if squared distance to center < squared radius
2. **Sphere**: Point is inside if squared distance to center < squared radius
3. **Polygon**: Uses ray casting algorithm
   - Project horizontal ray from point
   - Count intersections with polygon edges
   - Inside if odd number of intersections

#### Repulsion Field Computation
1. **Circle**:
   - Outside: Repulsion vector points away from circle
   - Inside: Repulsion vector points toward nearest edge

2. **Sphere**:
   - Repulsion vector points away from center
   - Magnitude based on distance to surface

3. **Polygon**:
   - Tracks closest edges
   - Combines repulsion from multiple edges when outside
   - Uses single strongest repulsion when inside

4. **Prism**:
   - Combines horizontal (area) and vertical (height) repulsions
   - Different behavior based on whether point is inside horizontal area, vertical bounds, or both

#### Coordinate Transformations
1. **LLH to ECEF**:
   ```
   N = a / sqrt(1 - e² * sin²(lat))
   X = (N + h) * cos(lat) * cos(lon)
   Y = (N + h) * cos(lat) * sin(lon)
   Z = (N * (1 - e²) + h) * sin(lat)
   ```

2. **ECEF to LLH**:
   - Iterative algorithm to solve for latitude
   - Longitude directly from arctan(Y/X)
   - Height computed from distance to ellipsoid surface

3. **Small Displacement Approximation**:
   - For small movements where Earth's curvature is negligible
   - Uses local radii of curvature to convert between NED and LLH
   - Much faster than full coordinate transformation

## 7. System Integration

The geometric models in the geomodel library work together to provide a comprehensive system for position management and obstacle avoidance:

1. `Apos` provides the foundation for absolute position representation and manipulation
2. Geometric primitives (Circle, Polygon, Sphere, Prism) define shapes and volumes in 3D space
3. `Gellipsoid` enables accurate coordinate transformations between reference frames
4. `Rpos` simplifies management of relative positions between objects
5. Inside/outside checking mechanisms determine if positions are within defined areas
6. Repulsion field computation creates forces to guide movement away from obstacles

This integrated system allows for:
- Precise positioning in global coordinates
- Definition of complex 3D shapes for restricted areas or obstacles
- Efficient collision detection and avoidance
- Smooth navigation through 3D space while respecting defined boundaries

## Referenced Context Files

The following context files provided useful information for understanding the geometric models:

- `code/include/Apos_fw.h`: Forward declaration of the Apos class
- `code/include/Obsadder_fw.h`: Forward declaration of the Obsadder class for repulsion field management
- `code/include/Iarea.h`: Interface for 2D areas
- `code/include/Heightbounds.h`: Class for vertical height limits
- `code/include/Fidposcache.h`: Position caching mechanism
- `code/include/Tecef_fw.h`: Forward declaration of ECEF coordinate representation
- `code/include/Tllh_fw.h`: Forward declaration of LLH coordinate representation
- `code/include/Irvector3_fw.h`: Forward declaration of 3D vector class