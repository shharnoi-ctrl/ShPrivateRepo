# Generated from:

- code/include/Fidcache.h (2267 tokens)
- code/include/Fidposcache.h (1117 tokens)
- code/include/Fidposcache_fw.h (30 tokens)
- code/include/Frefcache.h (534 tokens)
- code/include/Moving_buffer_map.h (3614 tokens)
- code/include/Aposbuffer.h (584 tokens)
- code/include/Polymgr.h (2872 tokens)
- code/include/Polymgr_fw.h (23 tokens)
- code/include/Cached_rd_file.h (967 tokens)
- code/include/Base_sd_map.h (952 tokens)
- code/include/Gen_sd_map.h (1685 tokens)
- code/include/Srtm_sd_map.h (1590 tokens)
- code/include/Grid_vertex.h (1502 tokens)
- code/include/Igeomesh.h (158 tokens)
- code/source/Fidcache.cpp (2000 tokens)
- code/source/Frefcache.cpp (254 tokens)
- code/source/Moving_buffer_map.cpp (3340 tokens)
- code/source/Aposbuffer.cpp (816 tokens)
- code/source/Polymgr.cpp (3338 tokens)
- code/source/Cached_rd_file.cpp (1759 tokens)
- code/source/Base_sd_map.cpp (503 tokens)
- code/source/Gen_sd_map.cpp (1760 tokens)
- code/source/Srtm_sd_map.cpp (983 tokens)
- code/source/Grid_vertex.cpp (128 tokens)

## With context from:

- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/geomodel/06_Core_Geometric_Models.md (4404 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/geomodel/05_Coordinate_Systems.md (3935 tokens)

---

# Spatial Data Management in the Geomodel Library

This comprehensive analysis details how the geomodel library manages spatial data for drone navigation, focusing on feature identification tracking, geographic data buffering, volume management, and file access patterns.

## 1. Feature Identifier Caching and Dependency Management

### Fidcache: Feature Identifier Dependency Tracker

The `Fidcache` class manages and tracks relative dependencies between feature identifiers, providing a mechanism to compute absolute positions from a chain of relative references.

#### Core Data Structures

```cpp
class Fidcache {
private:
    struct Node {
        Base::Dsync::Reader rd;     // Reader for synchronization of feature data
        Base::Feature       ftr;    // Feature data associated with this node
    };
    static const Uint16 path_sz = 4;  // Maximum number of nodes in the path
    
    Base::Fid id;                   // Current feature identifier being cached
    Node      path[path_sz];        // Sequence of features from id to origin
    const Node* node_origin;        // Last element on path (always absolute)
};
```

#### Key Algorithms

1. **Path Computation**:
   - `compute_path_loop`: Iteratively builds a path from the current feature ID to an absolute reference
   - `compute_path0`: Attempts to build a path in a single pass, following feature references
   - Limited to `max_iterations` (10) to prevent infinite loops in circular references

2. **Relative Position Computation**:
   - `compute_rn`: Accumulates relative vectors along the path to compute the effective displacement
   - `compute_origin`: Retrieves the absolute position of the origin feature
   - `compute_rpos`: Combines origin position and relative vector into a complete relative position

3. **Position Refresh**:
   - `refresh`: Updates the cached path if the feature ID has changed or if any node is invalid
   - `refresh_pos`: Refreshes the path and computes the final absolute position
   - `refresh_posrel`: Similar to `refresh_pos` but adds an additional relative vector

#### Dependency Resolution

The class resolves feature dependencies by:
1. Starting with the target feature ID
2. Reading the feature data using `Bsp::Hfvar(id).get(feature)`
3. If the feature is relative (`wrt != wrt_abs`), following the reference to the next feature
4. Continuing until an absolute feature is found or max iterations is reached
5. Storing the entire chain in the `path` array for efficient reuse

### Fidposcache: Position Caching for Features

The `Fidposcache` class extends `Fidcache` to cache the absolute position associated with a feature identifier.

```cpp
class Fidposcache {
private:
    Fidcache fcache;  // Feature identifier cache
    Apos final;       // Cached absolute position
};
```

This class provides:
1. Simple interface to get/set feature IDs
2. Cached absolute position computation
3. Serialization/deserialization support

### Frefcache: Feature Reference Caching

The `Frefcache` class manages feature references that can be either direct feature IDs or feature data with relative positions.

```cpp
class Frefcache {
private:
    Base::Fref fr;         // Position representation
    bool has_fid;          // Indicates if Fref depends on any Fid
    Fidcache fcache;       // FID cache
    Apos final;            // Position cache
};
```

Key functionality:
1. Handles both direct feature IDs and feature data with relative positions
2. Maintains a flag indicating whether the reference depends on a feature ID
3. Updates the internal state when the reference changes
4. Provides position refresh and serialization support

## 2. Moving Buffer Map for Efficient Geographic Data Management

### Moving_buffer_map: 2D Circular Buffer for Geographic Data

The `Moving_buffer_map` class implements a 2D circular buffer to efficiently manage geographic data around the UAV's position, optimizing memory usage and file access patterns.

#### Core Data Structure

```cpp
class Moving_buffer_map : public Base::Itask {
private:
    Base_sd_map& sd_map;                   // SD map provider
    bool pos_to_vtx_ready;                 // True if lon/lat to vertex conversion is possible
    const Uint16 rows;                     // Number of rows
    const Uint16 cols;                     // Number of columns
    const Grid_vertex::Delta dc;           // Delta vertices to center
    Base::Mblock<Base::Async_res> st_grid; // Grid of states for points
    Mblock_grid grid;                      // Grid of data for points
    Grid_vertex bl;                        // Coordinates of the zero position of the grid
    
    Uint16 rc;                             // Index of first row (lower row)
    Uint16 cc;                             // Index of first column (left column)
};
```

#### 2D Circular Buffer Implementation

The buffer is implemented as a 2D grid with circular indexing in both dimensions:
1. The physical buffer is a linear array of size `rows * cols`
2. Logical indices are mapped to physical indices using modulo arithmetic
3. When the buffer moves, only the affected rows/columns are updated
4. The `rc` and `cc` variables track the current offset of the circular buffer

For example, with `rc = 1` and `cc = 2`, the logical grid:
```
[0,0] [0,1] [0,2] [0,3] [0,4] [0,5]
[1,0] [1,1] [1,2] [1,3] [1,4] [1,5]
[2,0] [2,1] [2,2] [2,3] [2,4] [2,5]
[3,0] [3,1] [3,2] [3,3] [3,4] [3,5]
[4,0] [4,1] [4,2] [4,3] [4,4] [4,5]
[5,0] [5,1] [5,2] [5,3] [5,4] [5,5]
```

Maps to the physical buffer:
```
[4,2] [4,3] [4,4] [4,5] [4,0] [4,1]
[5,2] [5,3] [5,4] [5,5] [5,0] [5,1]
[0,2] [0,3] [0,4] [0,5] [0,0] [0,1]
[1,2] [1,3] [1,4] [1,5] [1,0] [1,1]
[2,2] [2,3] [2,4] [2,5] [2,0] [2,1]
[3,2] [3,3] [3,4] [3,5] [3,0] [3,1]
```

#### Key Algorithms

1. **Buffer Movement**:
   - `move`: Moves the buffer to keep the UAV position centered
   - `move_north`, `move_south`, `move_east`, `move_west`: Move the buffer in specific directions
   - `flush_rows`, `flush_cols`: Mark rows/columns as needing to be refilled

2. **Data Access**:
   - `to_index`: Converts logical grid coordinates to physical buffer index
   - `get_data_at`: Retrieves data for a specific position with interpolation ratios
   - `recompute_fill`: Updates the next vertex to be filled

3. **Asynchronous Loading**:
   - `step_task`: Incrementally loads data from the SD card
   - `Pos_updater`: Helper class to update position and fill the buffer

#### Optimization Techniques

1. **Hysteresis in Buffer Movement**:
   - `min_r_shift` and `min_c_shift` define minimum movement thresholds
   - Buffer only moves when UAV position exceeds these thresholds
   - Reduces unnecessary data reloading

2. **Incremental Loading**:
   - Data is loaded asynchronously in small chunks
   - `points_left` tracks how many grid points still need to be loaded
   - Allows the system to remain responsive during loading

3. **Bilinear Interpolation Support**:
   - `Out` structure provides the four corner points and interpolation ratios
   - Enables smooth interpolation between discrete grid points

## 3. Position and Path Buffering

### Aposbuffer: Position Buffer for Path Following

The `Aposbuffer` class implements a buffer of positions that can be used for path following or trajectory recording.

```cpp
class Aposbuffer : public Base::Itunable {
private:
    class Fpoint {
        Base::Tllh_low_res llh;  // Absolute position (longitude, latitude, height)
        Real dist;               // Distance to previous point
    };
    
    static const Uint16 max_buff_size = 50;  // Max elements in buffer
    Base::Array<Fpoint> buffer;              // Buffer
    Fpoint* rd;                              // Read pointer
    Fpoint* wr;                              // Write pointer
    
    Real dt_min;                             // Minimum time between points
    Base::Vref ds_min;                       // Minimum distance between points
    Base::Vref target_dist;                  // Target pursue distance
};
```

Key functionality:
1. Circular buffer implementation with read and write pointers
2. Distance-based and time-based filtering of input positions
3. Target distance tracking for path following

The buffer implements:
1. `push_back`: Adds a position to the buffer if time/distance thresholds are met
2. `pop_front`: Retrieves a position from the buffer when target distance is reached
3. Configurable parameters for minimum time, minimum distance, and target distance

## 4. Volume Management for Obstacle Avoidance

### Polymgr: Polygon and Volume Manager

The `Polymgr` class manages a collection of 3D volumes (polygonal prisms, cylinders, and spheres) used for obstacle avoidance and geofencing.

#### Core Data Structures

```cpp
class Polymgr : public Base::Ideserializable_async, public Base::Istep {
public:
    enum Volume_type {
        polygon  = 0U,  // 3D polygon (prism)
        cylinder = 1U,  // Cylinder
        sphere   = 2U,  // Sphere
        // Additional auxiliary fields...
    };
    
    static const Uint16 num_volume_types = 3U;  // Number of types
    static const Uint16 n = 20U;                // Number of volumes of each type
    static const Uint16 max_poly = num_volume_types * n; // Maximum number of polygons
    static const Uint16 max_polgrp = 16U;       // Maximum number of polygons per group
    
private:
    Base::Dsync sync;                           // Sync state for configuration changes
    Base::Dsync::Reader rd;                     // Reader for configuration
    Base::Tunarray_async<Frefresh> opv;         // List of operation volume features
    Base::Array<Polygon> polygon_bases;         // Polygon bases
    Base::Tunarray_async<Prism> polygon_prisms; // Set of polygons
    Base::Array<Circle> circle_bases;           // Circle bases
    Base::Tunarray_async<Prism> cylinders;      // Set of cylinders
    Base::Tunarray_async<Sphere> spheres;       // Set of spheres
    Base::Tunarray<Base::U8pkrszarray_tun<max_polgrp>> polygrp; // Groups of polygons
};
```

#### Volume Management

The class manages three types of volumes:
1. **Polygonal Prisms**: 3D volumes with polygon bases and height limits
2. **Cylinders**: 3D volumes with circular bases and height limits
3. **Spheres**: 3D spherical volumes

Each volume type has:
- Up to 20 instances
- Enable/disable functionality
- Serialization/deserialization support

#### Volume Groups

Volumes can be organized into groups for different purposes:
1. Each group can contain up to 16 volumes
2. Groups are stored in the `polygrp` array
3. Volume indices in groups must be sorted in ascending order
4. Groups can be used for different operational scenarios or events

#### Key Algorithms

1. **Obstacle Repulsion Field**:
   - `field`: Computes the repulsion field for a set of volumes
   - Combines repulsion from all enabled volumes
   - Updates the distance to the closest obstacle

2. **Inside Checking**:
   - `Inside_checker`: Helper class to check if a position is inside a volume
   - Supports all volume types (prism, cylinder, sphere)
   - Implements task-based asynchronous checking

3. **Scanning for Closest Edges**:
   - `step`: Periodically scans polygon edges to find the closest ones to the UAV
   - Optimizes repulsion field computation by focusing on relevant edges

#### Geocage Checking

The `Geocage_check` integration allows for:
1. Checking if the UAV is inside designated geofence areas
2. Asynchronous checking to avoid blocking the main control loop
3. Integration with the polygon group system

## 5. SD Card Map Data Access

### Base_sd_map: Base Class for SD Card Map Access

The `Base_sd_map` class provides a foundation for accessing map data stored on the SD card, with efficient caching to minimize file operations.

```cpp
class Base_sd_map {
public:
    struct Dec_part {
        Real lon;  // Decimal part of longitude discretization
        Real lat;  // Decimal part of latitude discretization
    };
    
protected:
    Cached_rd_file file;  // Cached file
    
private:
    Grid_vertex cached_vtx;            // Cached vertex for detecting changes
    Base::Ifile::Uid cached_tile_uid;  // Tile UID for the cached vertex
    Uint32 cached_tile_offset_words;   // Offset to obtain data for cached vertex
    bool cached_vtx_ok;                // True if cached vertex is valid
    bool header_ok;                    // True if header reading succeeded
};
```

Key functionality:
1. Asynchronous vertex data reading with caching
2. Position to vertex conversion with interpolation ratios
3. Vertex addition for grid navigation

### Cached_rd_file: Efficient File Access with Caching

The `Cached_rd_file` class implements a caching layer for file access, reducing the number of SD card operations.

```cpp
class Cached_rd_file {
private:
    struct Cache_desc {
        Base::Ifile::Uid uid;           // UID from which the data was read
        Uint32 offset_words;            // Offset in words from start of file
    };
    
    Base::Ifile& file;                  // Reference to file to use
    Base::Mblock_u16 cache_data;        // Cached data from file
    Uint32 cache_sz_words;              // Size of cached data
    Cache_desc cache;                   // Current cache descriptor
    Cache_desc next_cache;              // Next cache descriptor
    
    enum State {
        st_opening,    // Opening file
        st_offsetting, // Offsetting file
        st_reading,    // Reading file
        st_closing,    // Closing file
        st_canceling,  // Canceling file
        st_failed,     // Failed
        st_done        // Done
    };
};
```

Key algorithms:
1. **Asynchronous Reading**:
   - `read`: Asynchronously reads data from a file with caching
   - State machine implementation for non-blocking operation
   - Handles file opening, seeking, reading, and closing

2. **Cache Management**:
   - Caches more data than requested to speed up subsequent reads
   - Tracks current and next cache descriptors
   - Supports cache invalidation when reading from different files or offsets

3. **Error Handling**:
   - `check_async_error`: Manages asynchronous errors during file operations
   - `check_cancel`: Handles cancellation requests for ongoing operations

### Specialized Map Implementations

#### Gen_sd_map: Generic SD Map Reader

The `Gen_sd_map` class implements `Base_sd_map` for reading generic map data with configurable resolution and range.

```cpp
class Gen_sd_map : public Base_sd_map {
private:
    const Base::Ifile::Part_index partition;  // Partition
    const Uint16 elem_sz;                     // Element size
    
    Real tl_lon;                              // Top-left corner longitude
    Real tl_lat;                              // Top-left corner latitude
    Real lon_rad_to_vtx;                      // Longitude resolution
    Real lat_rad_to_vtx;                      // Latitude resolution
    Uint32 nlonfiles;                         // Number of files per column
    Uint32 nlatfiles;                         // Number of files per row
    Uint32 nlondiv;                           // Horizontal partitions within file
    Uint32 nlatdiv;                           // Vertical partitions within file
    bool wraplon;                             // True if longitude can be wrapped
};
```

Key functionality:
1. Reads header file to determine map parameters
2. Converts between longitude/latitude and vertex indices
3. Handles longitude wrapping for global maps
4. Computes file indices and offsets for efficient data access

#### Srtm_sd_map: SRTM Data Reader

The `Srtm_sd_map` class implements `Base_sd_map` specifically for Shuttle Radar Topography Mission (SRTM) data.

```cpp
class Srtm_sd_map : public Base_sd_map {
private:
    const Base::Ifile::Part_index partition;  // Partition
    const int32 deg_to_vtx;                   // Degrees to vertex conversion factor
    const int32 one_turn_vtx;                 // One turn in vertex representation
    const int32 half_turn_vtx;                // Half turn in vertex representation
    const Real rad_to_vtx;                    // Radians to vertex conversion factor
    
    int32 cached_header_offset;               // Cached header offset
    Base::Ifile::Uid cached_tile_uid;         // Cached tile UID
    int32 cached_tile_offset;                 // Cached tile offset
};
```

Key functionality:
1. Fixed-resolution implementation for SRTM data
2. Efficient conversion between degrees and vertex indices
3. Specialized header and tile offset computation
4. Longitude wrapping for global coverage

### Grid_vertex: Terrain Grid Vertex Representation

The `Grid_vertex` class represents a point in the terrain grid using integer coordinates.

```cpp
class Grid_vertex {
public:
    class Delta {
    public:
        int32 dlon;   // Delta longitude index
        int32 dlat;   // Delta latitude index
    };
    
private:
    int32 lon;        // Longitude index
    int32 lat;        // Latitude index
};
```

Key functionality:
1. Integer-based representation for efficient storage and comparison
2. Delta class for representing differences between vertices
3. Static methods for converting between floating-point coordinates and integer indices

## 6. Data Flow and System Integration

### Feature Identification and Position Resolution

1. **Feature ID Resolution Flow**:
   - Application requests position for a feature ID
   - `Fidcache` resolves the dependency chain to an absolute reference
   - Relative vectors are accumulated along the chain
   - Final absolute position is computed and cached

2. **Position Caching Hierarchy**:
   - `Fidcache`: Caches feature dependency chains
   - `Fidposcache`: Caches absolute positions for features
   - `Frefcache`: Caches positions for feature references

### Geographic Data Management Flow

1. **Map Data Loading**:
   - UAV position is used to center the `Moving_buffer_map`
   - Buffer determines which grid cells need to be loaded
   - `Base_sd_map` implementations handle file access
   - `Cached_rd_file` optimizes SD card operations

2. **Data Interpolation**:
   - Application requests data at a specific position
   - `Moving_buffer_map` finds the surrounding grid cells
   - Interpolation ratios are computed for smooth data access
   - Bilinear interpolation can be performed with the returned data

### Obstacle Avoidance Integration

1. **Volume Definition and Management**:
   - Volumes (polygons, cylinders, spheres) are defined in configuration
   - `Polymgr` manages these volumes and their grouping
   - Volumes can be enabled/disabled as needed

2. **Repulsion Field Computation**:
   - UAV position is checked against enabled volumes
   - Repulsion vectors are computed for nearby obstacles
   - Combined repulsion field guides the UAV away from obstacles

## 7. Optimization Techniques

### Memory Optimization

1. **Circular Buffers**:
   - `Moving_buffer_map` uses 2D circular buffer to avoid data copying
   - `Aposbuffer` uses 1D circular buffer for position history

2. **Caching Strategies**:
   - `Fidcache` caches feature dependency chains
   - `Cached_rd_file` caches file data beyond immediate needs
   - `Base_sd_map` caches vertex information and file references

### Performance Optimization

1. **Asynchronous Operations**:
   - File reading is performed asynchronously
   - Inside checking for volumes is implemented as tasks
   - Buffer filling is done incrementally to maintain responsiveness

2. **Spatial Locality Exploitation**:
   - `Moving_buffer_map` loads data around the current position
   - Hysteresis in buffer movement reduces unnecessary reloading
   - Closest edge tracking in `Polygon` optimizes repulsion calculation

3. **Computation Optimization**:
   - Pre-computed squared values for distance comparisons
   - Integer-based grid vertex representation
   - Efficient coordinate transformations for small displacements

## Referenced Context Files

The following context files provided valuable information for understanding the spatial data management system:

1. **06_Core_Geometric_Models.md**: Provided details on the `Apos` class, coordinate transformations, and geometric primitives used for obstacle avoidance. This helped understand how the spatial data management integrates with the position representation and geometric modeling systems.

2. **05_Coordinate_Systems.md**: Offered insights into the coordinate system management, which is essential for understanding how positions are represented and transformed in the spatial data management system.

These context files helped establish the relationship between the spatial data management components and the broader geomodel library architecture, particularly how position data flows through the system and how geometric models interact with the spatial data structures.