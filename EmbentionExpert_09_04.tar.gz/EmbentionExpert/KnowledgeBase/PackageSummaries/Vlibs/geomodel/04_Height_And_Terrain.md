# Generated from:

- code/include/Height.h (227 tokens)
- code/include/Heightabs.h (302 tokens)
- code/include/Heightbounds.h (2134 tokens)
- code/include/Iheight_computer.h (99 tokens)
- code/include/Terrain_height.h (284 tokens)
- code/include/Srtm_grid.h (479 tokens)
- code/include/Geoid_grid.h (490 tokens)
- code/include/Ussa76.h (2260 tokens)
- code/include/Ussa76_fw.h (22 tokens)
- code/source/Height.cpp (123 tokens)
- code/source/Heightabs.cpp (110 tokens)
- code/source/Heightbounds.cpp (837 tokens)
- code/source/Terrain_height.cpp (68 tokens)
- code/source/Srtm_grid.cpp (336 tokens)
- code/source/Geoid_grid.cpp (339 tokens)
- code/source/Ussa76.cpp (2280 tokens)

## With context from:

- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/geomodel/06_Core_Geometric_Models.md (4404 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/geomodel/05_Coordinate_Systems.md (3935 tokens)

---

# Height and Terrain Management System in the Geomodel Library

This comprehensive analysis details the height and terrain management system in the geomodel library, focusing on height representation classes, terrain data access, and atmospheric modeling.

## 1. Height Representation Classes

### 1.1 Height Class

The `Height` class provides a unified representation for both relative and absolute heights in the system.

```cpp
struct Height {
    enum Htype {
        relative = 0,  // Relative height
        absolute = 1   // Absolute height
    };
    
    Htype type;                // Type of height (relative or absolute)
    Base::Vref hdown;          // Relative height (positive is down)
    Geo::Heightabs habs;       // Absolute height
    
    Height();                  // Default constructor
    void cset(Base::Lossy_error& str);  // Deserialization method
};
```

#### Key Features:
- **Dual Representation**: Can represent either relative heights (distance from a reference point) or absolute heights (in a specific reference system)
- **Downward Convention**: For relative heights, positive values indicate downward direction
- **Default Initialization**: Initializes as relative height with a large value (100,000)
- **Serialization Support**: Provides `cset` method for deserialization from binary data

#### Implementation Details:
- The `cset` method deserializes the height type and then the appropriate height value based on the type
- Performs validation to ensure the type is either relative or absolute
- Copy constructor and assignment operator are deleted to prevent unintended copying

### 1.2 Heightabs Class

The `Heightabs` class represents absolute heights in different reference systems.

```cpp
struct Heightabs {
    enum Htype {
        agl   = 1,  // Above Ground Level
        msl   = 2,  // Mean Sea Level
        wgs84 = 3,  // WGS84 Ellipsoid
        none  = 4   // No reference system
    };
    
    Heightabs();                // Default constructor
    void cset(Base::Lossy_error& str);  // Deserialization method
    Real get_h() const;         // Height value getter
    Htype get_type() const;     // Height type getter
    
private:
    Htype type;                 // Altitude type
    Base::Vref h;               // Altitude value
};
```

#### Key Features:
- **Multiple Reference Systems**:
  - **AGL**: Height above the ground level (terrain)
  - **MSL**: Height above mean sea level (geoid)
  - **WGS84**: Height above the WGS84 reference ellipsoid
- **Default Initialization**: Initializes as WGS84 height with a large value (100,000)
- **Accessor Methods**: Provides getters for height value and type

#### Implementation Details:
- The `cset` method deserializes the height type and value
- Performs validation to ensure the type is within valid range
- Copy constructor and assignment operator are deleted to prevent unintended copying

### 1.3 Heightbounds Class

The `Heightbounds` class represents upper and lower vertical limits for 3D volumes like prisms and cylinders.

```cpp
class Heightbounds {
public:
    // Height field for repulsion information
    struct Height_field {
        bool limited;           // True if height is limited
        Real rep_dir;           // Repulsion direction (down positive)
        Real dist;              // Signed distance (positive outside, negative inside)
        
        bool is_inside() const;  // Check if inside vertical border
        void add_field(Obsadder& rep) const;  // Add vertical component to repulsion
    };
    
    // Individual height limit (upper or lower)
    class Heightlim {
    public:
        explicit Heightlim(const bool up_in0);  // Constructor (true for lower limit)
        bool is_inside(const Apos& p0) const;   // Check if position is inside limit
        Height_field field(const Apos& uav_pos) const;  // Compute repulsion field
        
        // Accessor methods
        bool is_limited() const;                // Check if limit is enabled
        bool get_dir() const;                   // Get repulsion direction
        const Heightabs& get_lim() const;       // Get height limit
        bool is_abs() const;                    // Check if limit is absolute
        
        void cset(Base::Lossy_error& str);      // Deserialization method
        
    private:
        const Real rep_dir;     // Repulsion direction (down positive)
        bool limited;           // True if limit is enabled
        Base::Fid fidrel;       // Relative position reference
        Heightabs lim;          // Height limit
        
        Real get_distance(const Apos& p0) const;  // Get signed distance to limit
        Real get_relheight(const Apos& p0) const; // Get relative height
    };
    
    Heightbounds();             // Default constructor
    bool is_inside(const Apos& p0) const;  // Check if position is inside bounds
    Height_field field(const Apos& uav_pos) const;  // Compute repulsion field
    void cset(Base::Lossy_error& str);  // Deserialization method
    const Heightlim& get_hlim(bool upper) const;  // Get height limit
    
private:
    Heightlim upper_bound;      // Upper vertical limit
    Heightlim lower_bound;      // Lower vertical limit
};
```

#### Key Features:
- **Dual Limits**: Maintains both upper and lower height bounds
- **Repulsion Fields**: Generates repulsion vectors for obstacle avoidance
- **Relative References**: Can define heights relative to other features
- **Inside Checking**: Provides methods to check if a position is inside the bounds

#### Implementation Details:
- **Height_field**: Contains repulsion information including direction and distance
- **Heightlim**: Represents a single height limit (upper or lower)
  - Can be absolute or relative to another feature
  - Computes signed distance to the limit
  - Generates repulsion vectors for obstacle avoidance
- **is_inside**: A position is inside if it's within both upper and lower bounds
- **field**: Returns repulsion information for the closest limit

## 2. Terrain Data Management

### 2.1 Iheight_computer Interface

The `Iheight_computer` interface defines methods for computing heights in different reference systems.

```cpp
struct Iheight_computer {
    virtual Real wgs84_height(const Base::Lonlat& pos) const = 0;
    virtual Real msl_height(const Base::Lonlat& pos) const = 0;
};
```

#### Key Features:
- **Abstract Interface**: Defines methods that must be implemented by concrete height providers
- **Multiple Reference Systems**: Supports both WGS84 and MSL height calculations
- **Position-Based**: Heights are computed based on longitude/latitude position

### 2.2 Terrain_height Structure

The `Terrain_height` structure represents terrain height data with source information.

```cpp
struct Terrain_height {
    enum Source {
        processing = 0,  // Height still not valid (in process)
        invalid    = 1,  // Invalid source (out of current mesh)
        acs3       = 2,  // 3-arc second SRTM (90m resolution at equator)
        acs1       = 3   // 1-arc second SRTM (30m resolution at equator)
    };
    
    Source s;            // Source of height data
    Real h;              // Height of terrain
    
    explicit Terrain_height(const Source s0);  // Constructor with source
    Terrain_height(const Source s0, const Real h0);  // Constructor with parameters
    bool is_ready() const;  // Check if height is ready to use
};
```

#### Key Features:
- **Source Tracking**: Identifies the source of terrain data
- **Resolution Information**: Distinguishes between different SRTM resolutions
- **Validity Checking**: Provides method to check if height data is valid and ready to use

#### Implementation Details:
- Height is considered ready if the source is either `acs3` or `acs1` (valid SRTM data)
- Default constructor initializes height to zero

### 2.3 Srtm_grid Class

The `Srtm_grid` class provides access to SRTM (Shuttle Radar Topography Mission) terrain data.

```cpp
class Srtm_grid : public Moving_buffer_map {
public:
    Srtm_grid(Base::Ifile& file0,
              const Base::Ifile::Part_index partition0,
              const int32 deg_to_vtx0,
              const Uint16 grid_size0,
              Base::Bvar st_ok0);
              
    Base::Async_data<Real> srtm_height(const Base::Lonlat& pos) const;
    
private:
    Srtm_sd_map sd;  // SD map manager
};
```

#### Key Features:
- **Buffered Access**: Inherits from `Moving_buffer_map` to efficiently buffer terrain data
- **SD Card Storage**: Reads SRTM data from SD card storage
- **Interpolation**: Performs bilinear interpolation for positions between data points
- **Asynchronous Results**: Returns height data wrapped in `Async_data` to indicate validity

#### Implementation Details:
- Uses a grid buffer to cache terrain data for efficient access
- Performs bilinear interpolation between the four nearest points for smooth height values
- Returns height in meters above the WGS84 ellipsoid

### 2.4 Geoid_grid Class

The `Geoid_grid` class provides access to geoid height data (the difference between WGS84 and MSL).

```cpp
class Geoid_grid : public Moving_buffer_map, public Geo::Igeosrc {
public:
    Geoid_grid(Base::Ifile& file0,
               const Base::Ifile::Part_index partition0,
               const Uint16 geoid_grid_sz,
               Base::Bvar st_ok0);
               
    Base::Async_data<Real> get(const Base::Lonlat& pos) const;
    
private:
    Gen_sd_map sd;  // Generic SD mapped data provider
};
```

#### Key Features:
- **Buffered Access**: Inherits from `Moving_buffer_map` for efficient data buffering
- **SD Card Storage**: Reads geoid data from SD card storage
- **Interpolation**: Performs bilinear interpolation for positions between data points
- **Asynchronous Results**: Returns height data wrapped in `Async_data` to indicate validity

#### Implementation Details:
- Uses a grid buffer to cache geoid data for efficient access
- Performs bilinear interpolation between the four nearest points for smooth height values
- Returns the geoid height (difference between WGS84 ellipsoid and mean sea level)

## 3. Atmospheric Model (USSA76)

### 3.1 Ussa76 Class

The `Ussa76` class implements the U.S. Standard Atmosphere 1976 model for atmospheric properties.

```cpp
class Ussa76 {
public:
    enum Layer {
        layer0_11   = 0,  // 0-11 km
        layer11_20  = 1,  // 11-20 km
        layer20_32  = 2,  // 20-32 km
        layer32_47  = 3,  // 32-47 km
        layer47_inf = 4   // 47+ km
    };
    static const Uint16 num_layers = 5;  // Number of atmospheric layers
    
    // Atmospheric layer parameters
    struct Atm {
        static const Real g_eps;  // Epsilon for comparing lapse rate
        Layer layer;              // Layer identifier
        Real msl0T;               // Reference temperature at h altitude (K)
        Real msl0p;               // Reference pressure at h altitude (Pa)
        Real h;                   // Reference altitude (km)
        Real g;                   // Temperature lapse rate (K/km)
        
        bool gzero() const;       // Check if lapse rate is zero
        Real altitude(const Real p) const;  // Get altitude for pressure
        void temppress_pext(const Real h1, Real& temp, Real& press, const Real ext_msl0p) const;
        void temppress(const Real h1, Real& temp, Real& press) const;
    };
    
    // Calibration helper class
    class Atm_cal {
    public:
        explicit Atm_cal(Atm& model0);
        void step(const Real alpha);
        bool check_temppress(const Real temp1, const Real press1) const;
        void calibrate(const Real h1, const Real temp1, const Real press1);
        void calibrate_isa();
        Real get_msl0p_target() const;
        
    private:
        Atm& model;            // Layer parameters
        Real inc_msl0p;        // Pressure increment for filtering
        Real msl0p_target;     // Target pressure (unfiltered)
    };
    
    // Constants
    static const Real Rg;       // Gas constant (Nm/(kg K))
    static const Real gmr;      // Hydrostatic constant (K/km)
    static const Real r0;       // Earth radius at g0 (km)
    static const Real gam;      // Specific heat ratio for sound speed
    static const Real rho0;     // ISA density at sea level
    
    Ussa76();  // Constructor
    
    // Atmospheric model methods
    bool calibrate(const Real z1, Real temp1, Real press1);
    static Real altitude_isa(const Real p);
    Real altitude_cal(const Real p) const;
    void compute(const Real z, Real& T, Real& p, Real& dp, Real& rho, Real& drho, Real& a14);
    Real get_cal_press0_diff() const;
    void calibrate_isa();
    
private:
    Layer layer;              // Current layer
    typedef Base::Tnarray<Atm, num_layers> Layers;
    Layers model;             // Current atmospheric model
    Base::Array<Atm_cal> cal; // Model calibration
    Bsp::Hrvar hp0;           // Air pressure at g0 (Pa)
    Base::Chrono clk;         // Clock for filtering
    
    // Helper methods
    static const Layers& get_isa();
    static Real altitude(const Layers& model, const Real p);
    static Layer layer_from_altitude(const Layers& model, const Real h);
    static Layer temppress(const Layers& model, const Real h, Real& temp, Real& press);
    static Real density(const Real temp, const Real p);
    static Real sound(const Real T);
    static Real geom2press(const Real z);
};
```

#### Key Features:
- **Layered Model**: Implements the five-layer U.S. Standard Atmosphere 1976 model
- **Calibration**: Supports calibration based on measured temperature and pressure
- **Comprehensive Outputs**: Computes temperature, pressure, density, and speed of sound
- **Gradient Information**: Provides pressure and density gradients for aerodynamic calculations
- **Geometric/Pressure Altitude**: Converts between geometric and pressure altitudes

#### Implementation Details:
- **Atmospheric Layers**:
  1. **0-11 km**: Troposphere with negative lapse rate (-6.5 K/km)
  2. **11-20 km**: Lower stratosphere with zero lapse rate
  3. **20-32 km**: Middle stratosphere with positive lapse rate (1.0 K/km)
  4. **32-47 km**: Upper stratosphere with positive lapse rate (2.8 K/km)
  5. **47+ km**: Lower mesosphere with zero lapse rate

- **Calibration Process**:
  1. Identifies the layer containing the calibration point
  2. Adjusts the layer parameters to match the measured temperature and pressure
  3. Propagates changes to adjacent layers to maintain continuity
  4. Applies filtering to smooth transitions between calibration updates

- **Computation Algorithm**:
  1. Applies filtered calibration changes to all layers
  2. Computes temperature and pressure at the requested altitude
  3. Calculates density using the ideal gas law
  4. Computes speed of sound based on temperature
  5. Calculates pressure and density gradients using numerical differentiation
  6. Updates system variables with the current model parameters

## 4. Height Reference System Integration

The height management system integrates multiple reference systems to provide a comprehensive vertical positioning capability:

### 4.1 Reference Systems Hierarchy

1. **WGS84 Height**: The fundamental height reference, measured from the WGS84 ellipsoid
   - Used as the base reference for all other height systems
   - Directly related to GPS altitude measurements

2. **MSL Height**: Height above mean sea level (geoid)
   - Computed as: MSL = WGS84 - GeoidHeight
   - More intuitive for human understanding (traditional altitude)
   - Used for aviation and navigation purposes

3. **AGL Height**: Height above ground level (terrain)
   - Computed as: AGL = MSL - TerrainHeight
   - Critical for terrain avoidance and low-altitude operations
   - Most relevant for obstacle clearance

### 4.2 Data Flow Between Components

1. **Height Calculation Flow**:
   - `Apos` class requests height information through `Iheight_computer` interface
   - `Georef` (implementing `Iheight_computer`) integrates multiple data sources
   - `Geoid_grid` provides the offset between WGS84 and MSL
   - `Srtm_grid` provides terrain height data for AGL calculations

2. **Vertical Limits Flow**:
   - `Heightbounds` defines upper and lower vertical limits
   - Limits can be specified in any reference system (WGS84, MSL, AGL)
   - `Heightlim` computes distances to these limits
   - Repulsion fields are generated based on these distances

3. **Atmospheric Model Integration**:
   - `Ussa76` provides atmospheric properties based on altitude
   - Pressure altitude is computed from standard or calibrated atmospheric model
   - Density and temperature information can be used for aerodynamic calculations

## 5. System Capabilities and Applications

### 5.1 Terrain Following and Obstacle Avoidance

The height management system enables sophisticated terrain following and obstacle avoidance:

1. **Terrain Awareness**:
   - `Srtm_grid` provides terrain height information from SRTM data
   - Different resolution sources (1-arc second, 3-arc second) provide appropriate detail
   - Bilinear interpolation ensures smooth terrain representation

2. **Vertical Obstacle Avoidance**:
   - `Heightbounds` defines vertical limits for 3D volumes
   - Repulsion fields guide the UAV away from vertical obstacles
   - Signed distance calculations provide precise proximity information

3. **Reference System Flexibility**:
   - Heights can be specified in any reference system (WGS84, MSL, AGL)
   - System automatically handles conversions between reference systems
   - Enables intuitive specification of constraints (e.g., "stay 100m above ground")

### 5.2 Atmospheric Modeling for Navigation

The `Ussa76` atmospheric model provides critical information for navigation and flight performance:

1. **Altitude Determination**:
   - Converts between pressure altitude and geometric altitude
   - Supports barometric altimeter calibration
   - Accounts for non-standard atmospheric conditions

2. **Flight Performance Calculations**:
   - Provides air density for aerodynamic calculations
   - Computes speed of sound for Mach number determination
   - Calculates density and pressure gradients for stability analysis

3. **Sensor Fusion**:
   - Enables integration of barometric altitude with GPS altitude
   - Supports calibration based on measured atmospheric conditions
   - Provides a consistent atmospheric model across the system

## 6. Mathematical Foundations

### 6.1 Height Reference Systems

The mathematical relationships between height reference systems are:

1. **WGS84 to MSL**:
   ```
   MSL_height = WGS84_height - geoid_height
   ```
   Where `geoid_height` is the local height of the geoid above the WGS84 ellipsoid.

2. **MSL to AGL**:
   ```
   AGL_height = MSL_height - terrain_height
   ```
   Where `terrain_height` is the local terrain elevation above mean sea level.

### 6.2 Atmospheric Model Equations

The U.S. Standard Atmosphere 1976 model uses the following key equations:

1. **Temperature Profile**:
   ```
   T = T0 + g * (h - h0)
   ```
   Where:
   - `T` is temperature at height `h`
   - `T0` is reference temperature at height `h0`
   - `g` is temperature lapse rate

2. **Pressure Profile (Non-Zero Lapse Rate)**:
   ```
   p = p0 * (T/T0)^(-gmr/g)
   ```
   Where:
   - `p` is pressure at height `h`
   - `p0` is reference pressure at height `h0`
   - `gmr` is hydrostatic constant

3. **Pressure Profile (Zero Lapse Rate)**:
   ```
   p = p0 * exp(-(h-h0)*gmr/T0)
   ```

4. **Density Calculation**:
   ```
   rho = p/(Rg*T)
   ```
   Where:
   - `rho` is air density
   - `Rg` is gas constant

5. **Speed of Sound**:
   ```
   a = sqrt(gamma*Rg*T)
   ```
   Where:
   - `a` is speed of sound
   - `gamma` is specific heat ratio (1.4)

### 6.3 Geometric to Pressure Altitude Conversion

The conversion between geometric altitude and pressure altitude accounts for Earth's curvature:

```
h_pressure = h_geometric / (1 + h_geometric/r0)
```

Where:
- `h_pressure` is pressure altitude (km)
- `h_geometric` is geometric altitude (km)
- `r0` is Earth's radius (6356.766 km)

## 7. System Integration and Data Flow

The height and terrain management system integrates with other components of the geomodel library to provide a comprehensive spatial awareness capability:

### 7.1 Integration with Position Management

1. **Apos Class Integration**:
   - `Apos` uses `Iheight_computer` interface to access height information
   - Height information is used for position representation and movement
   - Different height types (WGS84, MSL, AGL) are available for different operations

2. **Coordinate System Integration**:
   - Height is the vertical component of the LLH coordinate system
   - Height transformations are part of the coordinate system transformations
   - Vertical and horizontal components work together for complete 3D positioning

### 7.2 Integration with Obstacle Avoidance

1. **Heightbounds Integration**:
   - `Heightbounds` defines vertical limits for 3D volumes
   - Used by `Prism` class to extend 2D areas into 3D volumes
   - Generates repulsion fields for obstacle avoidance

2. **Terrain Avoidance**:
   - Terrain height from `Srtm_grid` is used to maintain safe altitude
   - AGL height calculations ensure clearance from terrain
   - Repulsion fields guide the UAV away from terrain obstacles

### 7.3 Data Flow for Height Management

1. **Height Calculation Flow**:
   - UAV position (longitude, latitude) is determined
   - `Georef` is queried for height information at that position
   - `Geoid_grid` provides geoid height for MSL calculation
   - `Srtm_grid` provides terrain height for AGL calculation
   - Height information is used for navigation and obstacle avoidance

2. **Atmospheric Model Flow**:
   - Altitude is input to `Ussa76` model
   - Model computes atmospheric properties (temperature, pressure, density)
   - Properties are used for flight performance calculations
   - Barometric measurements can calibrate the model for local conditions

## Referenced Context Files

The following context files provided valuable information for understanding the height and terrain management system:

1. **06_Core_Geometric_Models.md**: Provided details on the `Apos` class and its integration with the height management system. Explained how the `Iheight_computer` interface is used to access height information and how different coordinate systems are transformed.

2. **05_Coordinate_Systems.md**: Provided information on the `Georef` class which implements the `Iheight_computer` interface and integrates multiple height data sources. Explained the relationship between different height reference systems and how they are used in the coordinate system transformations.

These context files helped clarify how the height and terrain management components integrate with the broader geomodel library to provide a comprehensive spatial awareness capability for UAV navigation.