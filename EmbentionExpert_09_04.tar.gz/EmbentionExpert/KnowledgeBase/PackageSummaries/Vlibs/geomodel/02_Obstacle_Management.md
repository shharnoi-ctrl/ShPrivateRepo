# Generated from:

- code/include/Obstacle.h (385 tokens)
- code/include/Obstmgr.h (599 tokens)
- code/include/Obsadder.h (426 tokens)
- code/include/Obsadder_fw.h (23 tokens)
- code/include/Obscmd.h (880 tokens)
- code/include/Movobstacle.h (792 tokens)
- code/include/Geocage_check.h (1286 tokens)
- code/include/Opsite.h (431 tokens)
- code/include/Runway.h (458 tokens)
- code/include/Rwymgr.h (430 tokens)
- code/source/Obstacle.cpp (321 tokens)
- code/source/Obstmgr.cpp (376 tokens)
- code/source/Obsadder.cpp (305 tokens)
- code/source/Obscmd.cpp (1073 tokens)
- code/source/Movobstacle.cpp (1317 tokens)
- code/source/Geocage_check.cpp (3250 tokens)
- code/source/Opsite.cpp (324 tokens)
- code/source/Runway.cpp (536 tokens)
- code/source/Rwymgr.cpp (1051 tokens)

## With context from:

- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/geomodel/06_Core_Geometric_Models.md (4404 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/geomodel/04_Height_And_Terrain.md (6008 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/geomodel/03_Field_Models.md (4642 tokens)

---

# Obstacle Management System in the Geomodel Library

This comprehensive summary details the obstacle management system in the geomodel library, focusing on static and moving obstacles, repulsion fields, geocaging validation, and operational site management.

## 1. Static Obstacle Representation (Obstacle Class)

The `Obstacle` class serves as the foundation for representing static obstacles in the environment.

```cpp
class Obstacle : public Base::Itunable {
public:
    Obstacle();
    explicit Obstacle(Base::Fid id0);
    
    void set_rtype(const Real R0, const Base::Obs_type::Type t0);
    void field(const Apos& p0, Obsadder& obadr) const;
    void refresh();
    const Apos& get_pos() const;
    
protected:
    Base::Obs_type::Type type;  // Type of obstacle (2D or 3D)
    Real R;                     // Distance parameter (radius/size)
    
private:
    Fidposcache fr;             // Obstacle position
};
```

### Core Functionality

- **Position Management**: Uses `Fidposcache` to store and efficiently access the obstacle's position
- **Type Configuration**: Supports different obstacle types (2D or 3D) via the `type` parameter
- **Size Configuration**: Defines the obstacle's size/radius via the `R` parameter
- **Repulsion Field Generation**: Computes repulsion vectors to guide UAVs away from the obstacle

### Repulsion Field Computation

The `field` method computes the repulsion field for a static obstacle:

1. Calculates the vector from obstacle to UAV position
2. For 2D obstacles, zeroes the vertical (Z) component to create a vertical cylinder
3. Computes the distance to the obstacle's border: `d = |vector| - R`
4. Normalizes the direction vector
5. Adds the repulsion to the obstacle adder with the computed distance and direction

This creates a virtual force that pushes the UAV away from the obstacle when it gets too close.

## 2. Moving Obstacle Management (Movobstacle and Obscmd Classes)

### 2.1 Movobstacle Class

The `Movobstacle` class extends `Obstacle` to represent dynamic obstacles with velocity and tracking information.

```cpp
class Movobstacle : public Obstacle {
public:
    explicit Movobstacle(Base::Fid id0);
    
    void mov_field(const Apos& uav_pos, const Maverick::Irvector3& uav_vel, Obsadder& obadr);
    Uint32 get_id() const;
    Real get_tti() const;       // Time to impact
    Real get_tslc() const;      // Time since last communication
    bool is_pos_ok() const;     // Position validity check
    
private:
    Uint32 id;                  // Obstacle ID
    Maverick::Rvector3 obs_vel; // Current obstacle speed
    Real heading;               // Current obstacle heading
    bool moving;                // True when obstacle has non-zero velocity
    Real relvel;                // Relative velocity between obstacle and UAV
    Real tti;                   // Time to impact
    
    // ADS-B related data
    Base::Mobs_data::Flags data_flags;
    Base::ADSB_Mavlink::Emitter_type emitter_type;
    Base::Chrono tslc;          // Time since last communication
    Uint16 squawk;              // Squawk code
    Base::Mobs_data::Callsign callsign;
    
    void compute_impact(const Apos& uav_pos, const Maverick::Irvector3& uav_vel, const Apos& obs_pos);
    void update_pos(Base::Feature& pos0);
};
```

#### Key Features

- **Velocity Tracking**: Stores and uses obstacle velocity for prediction
- **Time-to-Impact Calculation**: Computes time until potential collision
- **Communication Monitoring**: Tracks time since last data update
- **ADS-B Integration**: Stores ADS-B specific data (emitter type, squawk code, callsign)
- **Data Validity Management**: Tracks which data fields are valid and handles partial updates

#### Moving Obstacle Repulsion Field

The `mov_field` method computes the repulsion field for a moving obstacle:

1. For moving obstacles:
   - Creates an elliptical field that extends in the direction of movement
   - Computes equivalent distance based on both current position and projected position
   - Generates repulsion vector that accounts for obstacle's movement direction

2. For stationary obstacles:
   - Falls back to the static obstacle field computation

3. Additionally computes impact metrics:
   - Calculates relative velocity between UAV and obstacle
   - Computes time-to-impact if they are on a collision course

### 2.2 Obscmd Class

The `Obscmd` class manages a collection of moving obstacles and processes commands to add or update them.

```cpp
class Obscmd : public Base::Istep {
public:
    explicit Obscmd(const Maverick::Irvector3& vn0);
    
    void field(const Apos& p0, Obsadder& obadr);
    Real get_min_tti() const;
    void obs_add_cmd(Base::Lossy_error& str);
    void step();
    Uint16 get_changed_counter() const;
    
private:
    Base::Tunarray<Movobstacle, true> tun;  // Moving obstacles array
    static const Uint16 nobscomm = Base::c_movobs_all - Base::c_movobs_00;
    static const Real max_tslc;      // Max time before deleting obstacle
    const Maverick::Irvector3& uav_vel;  // Aircraft speed
    Bsp::Hrvar min_tti;              // Closest time to impact
    
    class Mobsaddcmd : public Base::Itunable {
        // Command processor for adding/updating obstacles
    };
    
    Mobsaddcmd cmd_add;
    Movobstacle mo_tmp;
    Uint16 changed_counter;
    
    int32 find_by_id(Uint32 id);
    int32 find_next_avail();
    int32 find_oldest(const Real tlsc);
    void delete_old_mobs();
    Uint32 get_num_mobs();
};
```

#### Key Features

- **Obstacle Collection**: Manages an array of up to `nobscomm` moving obstacles
- **Command Processing**: Handles commands to add or update obstacles
- **Obstacle Aging**: Removes obstacles that haven't been updated for `max_tslc` seconds (40s)
- **Collision Prediction**: Tracks minimum time-to-impact across all obstacles
- **Change Tracking**: Maintains a counter that increments when obstacles are added, updated, or removed

#### Obstacle Management Logic

The `obs_add_cmd` method processes commands to add or update obstacles:

1. Extracts obstacle ID from the command
2. Checks if an obstacle with this ID already exists
3. For new obstacles:
   - Deserializes obstacle data into a temporary object
   - Checks if the position is valid
   - Finds an available slot or replaces the oldest obstacle if full
4. Updates the obstacle data and enables it in the array
5. Increments the change counter

The `step` method performs periodic maintenance:

1. Removes obstacles that haven't been updated for too long
2. Updates the system variable with the current obstacle count

The `field` method computes the combined repulsion field from all moving obstacles:

1. Iterates through all enabled obstacles
2. Calls each obstacle's `mov_field` method to compute its repulsion
3. Tracks the minimum time-to-impact across all obstacles
4. Updates the `min_tti` system variable

## 3. Repulsion Field Combination (Obsadder Class)

The `Obsadder` class combines repulsion fields from multiple obstacles to create a unified avoidance vector.

```cpp
class Obsadder {
public:
    static const Real min_dist_in;  // Minimum distance to consider inside
    
    explicit Obsadder(const Real ik0);
    void add(const Real dist, const Maverick::Irvector3& udir);
    void compute(Maverick::Irvector3& rep) const;
    
private:
    const Real ik;              // Inverse of distance at which obstacles lose effect
    bool outside;               // True if outside all added obstacles
    Maverick::Rvector3 num;     // Numerator of weighted repulsion
    Real den;                   // Denominator of weighted repulsion
    Real rep_in;                // Repulsion strength for closest inside edge
};
```

### Repulsion Field Combination Algorithm

The `add` method adds the effect of one obstacle:

1. Determines if the point is outside the obstacle based on the distance
2. For points outside all obstacles:
   - Computes repulsion strength based on distance: `rep = max(1 - (ik * dist), 0)`
   - Weights the repulsion by inverse squared distance: `weight = 1 / dist²`
   - Adds weighted repulsion to the numerator
   - Adds weight to the denominator
3. For points inside any obstacle:
   - Tracks the obstacle with the smallest repulsion value
   - Sets numerator to the repulsion direction of that obstacle
   - Sets denominator to 1

The `compute` method calculates the final repulsion vector:

1. If denominator is positive, computes `rep = num / den`
2. Otherwise, sets repulsion to zero

This approach creates a weighted average of repulsions from all obstacles when outside, and uses the strongest repulsion when inside any obstacle.

## 4. Geocaging Validation (Geocage_check Class)

The `Geocage_check` class validates that polygons used for geocaging comply with the ED270 standard requirements.

```cpp
class Geocage_check : public Base::Ideserializable {
public:
    enum geocag_area {
        conting   = 0,  // Contingency Area (CA)
        emer      = 1,  // Emergency Area (EA)
        emer_marg = 2,  // Emergency Security Margin Area (ESMA)
        prohib    = 3   // Prohibited area (PA)
    };
    static const Uint16 n_geo_area = 4U;
    
    explicit Geocage_check(Polymgr& poly0);
    Base::Async_sres check();
    
private:
    Base::Tnarray<Real, n_geo_area-1> geo_dist;  // Distances between areas
    Base::Tnarray<Uint16, n_geo_area> idx_poly;  // Indices of geocage polygons
    Bsp::Hbvar geo_ok;                           // Validation result
    Polymgr& poly;                               // Reference to polygon manager
    Uint16 nv;                                   // Current vertex to check
    bool valid;                                  // Validation flag
    
    void check_area();
    void check_height();
};
```

### ED270 Standard Requirements

The `Geocage_check` class validates the following requirements:

1. **Vertical Limits**:
   - Only one vertical upper limit, no vertical lower limit (except for contingency area)
   - All heights must be absolute and in the same reference system

2. **Vertex Positions**:
   - Vertices must have correct positions according to configured offsets
   - Offsets between different areas must match the configured distances

3. **Area Size**:
   - Contingency area must have between 200 m² and 100,000 km² of surface

4. **Angle Requirements**:
   - Minimum angle between two contiguous edges must be 30 degrees

### Validation Process

The `check` method performs the validation asynchronously:

1. If the contingency area polygon is valid and not all vertices have been checked:
   - Calls `check_area` to validate the current vertex
   - Increments the vertex counter
   - Returns "ongoing" status

2. If all vertices have been checked:
   - Calculates the total area
   - Validates that the area is within required limits
   - Calls `check_height` to validate vertical limits
   - Returns "done" status

3. Updates the `geo_ok` system variable with the validation result

The `check_area` method validates polygon geometry:

1. Checks that all vertices are absolute features
2. For the contingency area:
   - Computes the area using the shoelace formula
   - Checks minimum angles between edges
   - Computes offset vectors for vertex positioning

3. For other areas:
   - Verifies that vertices are positioned correctly relative to the contingency area
   - Checks that offsets match the configured distances

The `check_height` method validates vertical limits:

1. Checks that all upper heights are absolute and of the same type
2. Verifies that heights match the required values
3. Ensures that only the contingency area has a lower limit

## 5. Operational Site Management (Opsite, Runway, and Rwymgr Classes)

### 5.1 Opsite Class

The `Opsite` class serves as a base class for operational sites like runways and landing spots.

```cpp
class Opsite : public Base::Itunable {
public:
    static const Uint16 nalarms = 6;
    
    explicit Opsite(const Base::Fid fid_loides);
    
    virtual void compute(const Maverick::Irvector3& t,
                         Maverick::Irvector3& ur,
                         Geo::Apos& touch,
                         Geo::Apos& dst) = 0;
                         
    void compute_alarms();
    const Base::Set<Base::Bvar>& get_alarms() const;
    const Apos& get_loides() const;
    
protected:
    void loides_refresh();
    
private:
    Fidposcache loides;                 // Site position
    Base::Set<Base::Bvar> alarms_cfg;   // Configured alarms
    Base::Set<Base::Bvar> alarms;       // Active alarms
};
```

#### Key Features

- **Position Management**: Stores the site's position using `Fidposcache`
- **Alarm Management**: Tracks configured and active alarms for the site
- **Virtual Computation**: Defines an interface for computing approach vectors and touch points

The `compute_alarms` method evaluates alarm conditions:

1. Resets the active alarms set
2. Checks each configured alarm
3. Adds alarms that are not OK to the active set

### 5.2 Runway Class

The `Runway` class extends `Opsite` to represent runway-specific properties and behavior.

```cpp
class Runway : public Opsite {
public:
    enum Rtype {
        direct  = 0,  // Direct direction (from start to end)
        inverse = 1,  // Inverse direction (from end to start)
        best    = 2   // Best direction from current position
    };
    static const Uint16 direction_all = 3U;
    
    explicit Runway(const Uint16 id);
    
    virtual void compute(const Maverick::Irvector3& t,
                         Maverick::Irvector3& ur,
                         Geo::Apos& touch,
                         Geo::Apos& dst);
                         
private:
    Fidposcache fstart;         // Start position of runway
    Fidposcache fend;           // End position of runway
    Rtype preferred;            // Preferred direction
    Real margin_ratio;          // Ratio of unused distance after head point
    Real margin_reverse_ratio;  // Margin when runway is inverted
};
```

#### Key Features

- **Bidirectional Support**: Can be used in either direction (direct or inverse)
- **Automatic Direction Selection**: Can choose the best direction based on current position
- **Margin Configuration**: Configurable margins for approach and touchdown points
- **Position Computation**: Calculates approach vector, touch point, and destination based on current conditions

The `compute` method determines runway approach parameters:

1. Refreshes position data for the runway
2. Computes the runway direction vector
3. Determines whether to use the runway in direct or inverse direction:
   - Based on the preferred direction setting
   - Or based on the dot product between desired direction and runway vector
4. Calculates touch point and destination based on the selected direction and margins

### 5.3 Rwymgr Class

The `Rwymgr` class manages a collection of runways and landing spots, selecting the most appropriate one based on current conditions.

```cpp
class Rwymgr : public Base::Ideserializable_async {
public:
    static const Uint16 runway_all = ((Base::c_rwy_all - Base::c_rwy0_start) / Ku16::u3);
    static const Uint16 spot_all = ((Base::c_spot_all - Base::c_spot0_loc) / Ku16::u2);
    
    enum Id {
        id_runway_0 = 0,
        id_spot_0   = id_runway_0 + runway_all,
        id_all      = id_spot_0 + spot_all
    };
    
    static Rwymgr& get_instance();
    
    bool calculate(Id id, const Apos& pos, const Maverick::Irvector3& uw);
    bool is_available(Uint16 id);
    
private:
    Base::Tunarray_async<Runway> runways;
    Base::Tunarray_async<Spot> spots;
    Base::Array<Opsite*> places;
    
    // Referenced variables
    Maverick::Rvector3 ur;
    Bsp::Hrvar hur;
    Base::Set<Base::Bvar> alarms;
    
    // Work variables
    Maverick::Rvector3 rn;
    Apos p;
    Apos d;
    Uint16 selected;
    
    Base::Fvar::Abs floides;
    Base::Fvar::Abs ftouch;
    Base::Fvar::Abs fdst;
};
```

#### Key Features

- **Singleton Pattern**: Provides global access through `get_instance()`
- **Mixed Collection**: Manages both runways and landing spots
- **Alarm-Based Selection**: Can select sites based on active alarms
- **Asynchronous Configuration**: Loads configuration data asynchronously to prevent blocking

The `calculate` method selects and computes parameters for an operational site:

1. Computes alarms for all available sites
2. Selects the best site based on:
   - Matching alarm conditions
   - Proximity to current position
   - If no match is found, uses the specified nominal site
3. Computes approach parameters for the selected site
4. Updates system variables with the computed values
5. Returns success/failure status

## 6. Obstacle Management System Integration

### 6.1 Obstmgr Class

The `Obstmgr` class integrates all obstacle management components into a unified system.

```cpp
class Obstmgr {
public:
    Obstmgr(const Maverick::Irvector3& vn0, Polymgr& poly0);
    
    void step(const Apos& pos, const Real agl, const Real ik, Maverick::Irvector3& vn);
    Uint16 get_mov_obstacle_changed_counter() const;
    
    Base::Ideserializable& build_cfg_obstacles();
    Base::Itunable& build_cmd_odem();
    Base::Itunable& build_cmd_obsact();
    Base::Itunable& build_cmd_obscmd();
    Base::Itunable& build_cmd_mobs_add();
    
private:
    class Obsenable : public Base::Itunable {
        // Controls which obstacle types are enabled
    };
    
    Base::Tnarray<Polymgr::Volume_ids, Polymgr::num_volume_types> tun;
    
    Odem dem;                // Terrain obstacle manager
    Obscmd oscmd;            // External obstacles manager
    Obsenable obsenable;     // Obstacle enablement flags
    Polymgr& poly;           // Polygon manager
};
```

#### Key Features

- **Unified Interface**: Provides a single entry point for obstacle avoidance
- **Multiple Obstacle Types**: Integrates static obstacles (polygons), terrain obstacles, and moving obstacles
- **Selective Enablement**: Allows enabling/disabling different obstacle types
- **Configuration Access**: Provides access to configuration interfaces for all obstacle components

The `step` method computes the combined repulsion field:

1. Creates an `Obsadder` with the specified influence distance
2. If configured obstacles are enabled, adds repulsions from polygon volumes
3. Adds repulsions from terrain obstacles
4. If external obstacles are enabled, adds repulsions from moving obstacles
5. Computes the final combined repulsion vector

### 6.2 Data Flow in the Obstacle Management System

1. **Configuration Flow**:
   - Static obstacles are configured through the polygon manager
   - Terrain obstacle parameters are configured through `Odem`
   - Moving obstacles are added/updated through `Obscmd`
   - Enablement flags control which obstacle types are active

2. **Repulsion Computation Flow**:
   - `Obstmgr::step` is called with current position and parameters
   - Each obstacle type computes its repulsion field
   - `Obsadder` combines all repulsions into a unified vector
   - The resulting vector guides the UAV away from obstacles

3. **Moving Obstacle Flow**:
   - ADS-B data is processed by `FMCP_adsb_v` (from Field Models)
   - Moving obstacle commands are sent to `Obscmd`
   - `Obscmd` manages the collection of moving obstacles
   - Obstacles that aren't updated are eventually removed

4. **Operational Site Flow**:
   - `Rwymgr` manages runways and landing spots
   - Alarm conditions affect site selection
   - Selected site parameters guide approach and landing

## 7. Obstacle Avoidance Algorithms

### 7.1 Static Obstacle Avoidance

Static obstacles create repulsion fields based on distance:

1. **Distance Calculation**:
   - For 2D obstacles: Horizontal distance to the obstacle border
   - For 3D obstacles: 3D distance to the obstacle border

2. **Repulsion Strength**:
   - Decreases linearly with distance: `rep = max(1 - (ik * dist), 0)`
   - Zero beyond the influence distance: `1/ik`

3. **Repulsion Direction**:
   - Points directly away from the obstacle
   - For 2D obstacles, only has horizontal components

### 7.2 Moving Obstacle Avoidance

Moving obstacles create elliptical repulsion fields that account for motion:

1. **Elliptical Field**:
   - Extends in the direction of obstacle movement
   - Size increases with obstacle velocity
   - Creates larger avoidance margin in the direction of movement

2. **Time-to-Impact Calculation**:
   - Computes relative velocity between UAV and obstacle
   - Calculates time until potential collision
   - Provides early warning of potential conflicts

3. **Aging Mechanism**:
   - Tracks time since last update for each obstacle
   - Removes obstacles that haven't been updated for too long
   - Prevents acting on stale information

### 7.3 Repulsion Field Combination

The `Obsadder` combines multiple repulsion fields using a weighted approach:

1. **Outside All Obstacles**:
   - Weighted average based on inverse squared distance
   - Closer obstacles have stronger influence
   - Creates smooth transitions between obstacle influences

2. **Inside Any Obstacle**:
   - Uses the repulsion from the closest obstacle boundary
   - Creates strong avoidance behavior to exit the obstacle

3. **Transition Handling**:
   - Maintains "inside" state once any obstacle is entered
   - Prevents oscillation at obstacle boundaries

## 8. Practical Applications

### 8.1 Collision Avoidance

The obstacle management system provides comprehensive collision avoidance:

1. **Static Obstacle Avoidance**:
   - Avoids buildings, no-fly zones, and other static obstacles
   - Respects geocaging boundaries defined by ED270 standard
   - Maintains safe distance from terrain

2. **Dynamic Obstacle Avoidance**:
   - Detects and avoids other aircraft via ADS-B
   - Predicts future positions based on velocity
   - Prioritizes avoidance based on time-to-impact

3. **Terrain Avoidance**:
   - Maintains safe height above ground
   - Creates upward repulsion when approaching terrain
   - Integrates with height management system

### 8.2 Landing and Takeoff Management

The operational site management system facilitates safe landing and takeoff:

1. **Runway Operations**:
   - Selects appropriate runway based on conditions
   - Determines optimal approach direction
   - Computes touch point and approach vector

2. **Landing Spot Operations**:
   - Supports vertical takeoff and landing sites
   - Defines allowed approach directions
   - Integrates with alarm system for condition-based selection

3. **Alarm-Based Selection**:
   - Selects sites based on current conditions (wind, visibility, etc.)
   - Falls back to nominal site when no alarms are active
   - Provides flexibility for changing conditions

### 8.3 Geocaging Compliance

The geocaging validation ensures compliance with safety standards:

1. **ED270 Standard Compliance**:
   - Validates polygon geometry against requirements
   - Ensures proper spacing between different areas
   - Verifies vertical limits are correctly configured

2. **Area Hierarchy**:
   - Contingency Area (CA): Primary operating area
   - Emergency Area (EA): Buffer around CA
   - Emergency Security Margin Area (ESMA): Additional buffer
   - Prohibited Area (PA): Absolute boundary

3. **Safety Validation**:
   - Ensures minimum angles between edges
   - Verifies area size is within limits
   - Confirms proper vertical limits

## 9. Referenced Context Files

The following context files provided valuable information for understanding the obstacle management system:

1. **06_Core_Geometric_Models.md**: Provided details on the `Apos` class and geometric primitives that form the foundation for obstacle representation. Explained how polygons, circles, and prisms are used to define obstacle volumes.

2. **04_Height_And_Terrain.md**: Detailed the height management system that supports terrain obstacle avoidance and vertical limit checking for geocaging validation.

3. **03_Field_Models.md**: Explained the ADS-B data processing that feeds into the moving obstacle management system, as well as the terrain height management that supports ground obstacle avoidance.

These context files helped clarify how the obstacle management system integrates with the broader geomodel library to provide comprehensive obstacle avoidance capabilities.