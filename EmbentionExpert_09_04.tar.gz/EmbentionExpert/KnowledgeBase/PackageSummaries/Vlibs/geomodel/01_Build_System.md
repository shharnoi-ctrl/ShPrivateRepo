# Generated from:

- code/project/eclipse/.project (271 tokens)
- code/project/eclipse/.cproject (2405 tokens)
- code/Vcast_projects/VTC-10477/VTC-10477.bat (120 tokens)
- code/Vcast_projects/VTC-10479/VTC-10479.bat (120 tokens)
- code/Vcast_projects/VTC-10480/VTC-10480.bat (201 tokens)
- code/Vcast_projects/VTC-10488/VTC-10488.bat (81 tokens)
- code/Vcast_projects/VTC-10489/VTC-10489.bat (82 tokens)
- code/Vcast_projects/VTC-136/Readme.md (933 tokens)
- code/Vcast_projects/VTC-136/VTC-136.bat (77 tokens)
- code/Vcast_projects/VTC-140/Readme.md (571 tokens)
- code/Vcast_projects/VTC-140/VTC-140.bat (77 tokens)
- code/Vcast_projects/VTC-144/Readme.md (982 tokens)
- code/Vcast_projects/VTC-144/VTC-144.bat (78 tokens)
- code/Vcast_projects/VTC-147/Readme.md (195 tokens)
- code/Vcast_projects/VTC-147/VTC-147.bat (62 tokens)
- code/Vcast_projects/VTC-149/VTC-149.bat (74 tokens)
- code/Vcast_projects/VTC-149/Readme.md (552 tokens)
- code/Vcast_projects/VTC-15465/VTC-15465.bat (64 tokens)
- code/Vcast_projects/VTC-16200/VTC-16200.bat (80 tokens)
- code/Vcast_projects/VTC-16277/VTC-16277.bat (79 tokens)
- code/Vcast_projects/VTC-16599/VTC-16599.bat (80 tokens)
- code/Vcast_projects/VTC-17080-10478/VTC-17080-10478.bat (128 tokens)
- code/Vcast_projects/VTC-179/Readme.md (145 tokens)
- code/Vcast_projects/VTC-179/VTC-179.bat (74 tokens)
- code/Vcast_projects/VTC-21220/VTC-21220.bat (82 tokens)
- code/Vcast_projects/VTC-2372/VTC-2372.bat (80 tokens)
- code/Vcast_projects/VTC-24330-24365/VTC-24330-24365.bat (88 tokens)
- code/Vcast_projects/VTC-25614/VTC-25614.bat (90 tokens)
- code/Vcast_projects/VTC-319/Readme.md (492 tokens)
- code/Vcast_projects/VTC-319/VTC-319.bat (74 tokens)
- code/Vcast_projects/VTC-373/VTC-373.bat (77 tokens)
- code/Vcast_projects/VTC-377/VTC-377.bat (78 tokens)
- code/Vcast_projects/VTC-380/VTC-380.bat (77 tokens)
- code/Vcast_projects/VTC-388/VTC-388.bat (77 tokens)
- code/Vcast_projects/VTC-398/VTC-398.bat (78 tokens)
- code/Vcast_projects/VTC-400/VTC-400.bat (74 tokens)
- code/Vcast_projects/VTC-401/VTC-401.bat (78 tokens)
- code/Vcast_projects/VTC-78/VTC-78.bat (105 tokens)
- code/Vcast_projects/VTC-78/Readme.md (579 tokens)

---

# Geomodel Library Build System Analysis

This document provides a comprehensive analysis of the build system for the geomodel library, focusing on Eclipse project configuration, VectorCAST test infrastructure, and the integration between development and testing environments.

## 1. Eclipse Project Configuration

### 1.1 Project Structure

The geomodel library is configured as an Eclipse C/C++ project with the following characteristics:

- **Project Name**: `geomodel`
- **Project Type**: C/C++ project with managed build nature
- **Source Organization**:
  - Uses linked resources to reference source code outside the project directory:
    - `include` directory linked to `../../include`
    - `source` directory linked to `../../source`

### 1.2 Build Configuration

The project is configured to build a static library (`libgeomodel.a`) with the following settings:

- **Build System**: GNU Make-based build system managed by Eclipse CDT
- **Build Commands**:
  - `org.eclipse.cdt.managedbuilder.core.genmakebuilder` - Generates makefiles
  - `org.eclipse.cdt.managedbuilder.core.ScannerConfigBuilder` - Analyzes include paths

### 1.3 Compiler Settings

The project uses GCC with the following configuration:

- **C++ Standard**: C++17 (`gnu.cpp.compiler.dialect.c++17`)
- **Build Flags**:
  - Position Independent Code (`-fPIC`)
  - pthread support (`-pthread`)
- **Include Paths**:
  - `${workspace_loc:/geomodel/include}`
  - `${workspace_loc:/base/include_SIL}`
  - `${workspace_loc:/base/include}`
  - `${workspace_loc:/first/include_SIL}`
  - `${workspace_loc:/first/include}`
  - `${workspace_loc:/bsp/include_SIL}`
  - `${workspace_loc:/bsp/include}`
  - `${workspace_loc:/FPU/include_SIL}`
  - `${workspace_loc:/FPU/include}`
  - `${workspace_loc:/maverick/include}`

### 1.4 Build Artifacts

- **Output Type**: Static Library (`.a` file)
- **Output Name**: `${ProjName}` (resolves to `geomodel.a`)
- **Build Directory**: `${workspace_loc:/geomodel}/Default`

### 1.5 Project Dependencies

Based on the include paths, the geomodel library depends on several other components:
- `base` - Base library (both regular and SIL versions)
- `first` - First library (both regular and SIL versions)
- `bsp` - Board Support Package (both regular and SIL versions)
- `FPU` - Floating Point Unit library (both regular and SIL versions)
- `maverick` - Maverick library

## 2. VectorCAST Test Infrastructure

### 2.1 Test Project Organization

The geomodel library has an extensive test suite implemented using VectorCAST, organized into multiple test projects:

| Test Project ID | Description/Purpose |
|----------------|---------------------|
| VTC-10477 | Tests for Heightabs component |
| VTC-10479 | Tests for Obstacle component |
| VTC-10480 | Tests for Endian16, Endian32, Endian64, and Runway components |
| VTC-10488 | Tests for Apos component |
| VTC-10489 | Tests for Fidcache component |
| VTC-136 | Tests for Polygon class |
| VTC-140 | Tests for Circle class |
| VTC-144 | Tests for Polymgr class |
| VTC-147 | Tests for Prism and Heightbounds serialization/deserialization |
| VTC-149 | Tests for Prism and Heightbounds functionality |
| VTC-15465 | General test project |
| VTC-16200 | Tests for Obstmgr component |
| VTC-16277 | Tests for Georef component |
| VTC-16599 | Tests for Grid_vertex component |
| VTC-17080-10478 | Tests for Endian64 and Height components |
| VTC-179 | Tests for Gellipsoid class |
| VTC-21220 | Tests for Geomodel component |
| VTC-2372 | Tests for Tecef component |
| VTC-24330-24365 | Tests for Feabs and Fid components |
| VTC-25614 | Tests for Fidposcache component |
| VTC-319 | Tests for Sphere class |
| VTC-373 | Tests for Ussa76 component |
| VTC-377 | Tests for Aposbuffer component |
| VTC-380 | Tests for Gfield component |
| VTC-388 | Tests for Vgeoref component |
| VTC-398 | Tests for Magfield component |
| VTC-400 | General test project |
| VTC-401 | Tests for Srtm_grid component |
| VTC-78 | Tests for Frefcache component |

### 2.2 Test Execution Structure

Each VectorCAST test project follows a common structure:

1. **Batch Files**: Each test project contains a `.bat` file that:
   - Builds the test environment (`environment build <project>.env`)
   - Runs test scripts (`tools script run <project>.tst`)
   - Copies configuration files from `%GIT_PATH%\code\test\Config\CCAST_.CFG`
   - Executes tests using the VectorCAST CLI tool (`CLICAST`)
   - Configures coverage options

2. **Common Test Flow**:
   ```
   1. Build environment
   2. Run test script
   3. Copy configuration files
   4. Execute tests
   5. Generate coverage reports
   ```

3. **Coverage Configuration**:
   - Most tests use statement and MC/DC coverage metrics
   - Some tests disable UUT (Unit Under Test) coverage for specific components

### 2.3 Test Components

Based on the test projects, the geomodel library contains the following major components:

1. **Geometric Primitives**:
   - Circle - Circular area representation
   - Polygon - Polygonal area representation
   - Sphere - Spherical volume representation
   - Prism - Volumetric extension of 2D shapes

2. **Reference Systems**:
   - Gellipsoid - Earth model and coordinate transformations
   - Georef - Geographic reference system
   - Tecef - Earth-Centered Earth-Fixed coordinate system
   - Vgeoref - Vector-based geographic reference

3. **Data Management**:
   - Fidcache - Feature ID cache
   - Frefcache - Feature reference cache
   - Aposbuffer - Absolute position buffer
   - Fidposcache - Feature ID position cache

4. **Environmental Models**:
   - Ussa76 - US Standard Atmosphere 1976 model
   - Magfield - Magnetic field model
   - Gfield - Gravitational field model
   - Srtm_grid - Shuttle Radar Topography Mission grid data

5. **Obstacle Management**:
   - Obstmgr - Obstacle manager
   - Polymgr - Polygon manager
   - Heightabs - Height abstraction
   - Obstacle - Obstacle representation

6. **Utility Components**:
   - Endian16/32/64 - Endianness conversion utilities
   - Grid_vertex - Grid vertex representation
   - Runway - Runway representation
   - Height - Height representation

### 2.4 Test Coverage Strategy

The test suite employs different coverage strategies:

1. **Full Coverage Tests**:
   - Many tests use `TO COV STATEMENT+MCDC ALL` to ensure complete statement and MC/DC coverage

2. **Component-Specific Coverage**:
   - Some tests disable coverage for specific components using `Tools Cover UUT_Disable`
   - Some tests suppress coverage for specific files using `VCAST_SUPPRESS_COVERABLE_FUNCTIONS`

3. **Endianness Testing**:
   - Multiple tests specifically target both big and little endian representations:
     - `Endian16_big`, `Endian16_little`
     - `Endian32_big`, `Endian32_little`
     - `Endian64_big`, `Endian64_little`

## 3. Test Case Details

### 3.1 Geometric Primitives Testing

#### 3.1.1 Polygon (VTC-136)
Tests polygon area creation, point containment checking, and repulsion vector generation:
- `is_inside()` - Tests if a point is inside the polygon
- `is_inside_obstacle()` - Tests if a UAV is on one of the edges
- `field()` - Tests repulsion vector calculation
- `step()` - Tests edge updates
- `cset()/cget()` - Tests serialization/deserialization

#### 3.1.2 Circle (VTC-140)
Tests circular area creation and point containment:
- `is_inside()` - Tests if a point is inside the circle
- `field()` - Tests repulsion vector calculation
- `cset()/cget()` - Tests serialization/deserialization

#### 3.1.3 Sphere (VTC-319)
Tests spherical volume creation and point containment:
- `is_inside()` - Tests if a point is inside the sphere
- `field()` - Tests 3D repulsion field generation
- `cset()/cget()` - Tests serialization/deserialization

### 3.2 Volume Management Testing

#### 3.2.1 Prism and Heightbounds (VTC-147, VTC-149)
Tests prism volumes (extruded 2D shapes) and height boundaries:
- Initialization of height bounds
- Serialization/deserialization
- Point containment checking
- Height boundary checking
- Field calculation

#### 3.2.2 Polymgr (VTC-144)
Tests the polygon manager that handles multiple volume types:
- Management of prisms, cylinders, and spheres
- Point containment checking
- Repulsion vector calculation
- Volume ID management
- Configuration serialization/deserialization

### 3.3 Reference System Testing

#### 3.3.1 Gellipsoid (VTC-179)
Tests Earth model and coordinate transformations:
- `geo2ecef()` - Geodetic to Earth-Centered Earth-Fixed conversion
- `ecef2geo3()` - Earth-Centered Earth-Fixed to Geodetic conversion
- `geowh()` - Earth angular velocity calculation
- `geoevol()` - Displacement vector calculation in LLA
- `geoevol_1()` - Displacement vector from LLA displacement

## 4. Build System Integration

### 4.1 Development to Testing Workflow

The build system integrates development and testing through:

1. **Source Code Organization**:
   - Main source code in `code/include` and `code/source`
   - Test code in `code/Vcast_projects/<test-id>`

2. **Configuration Sharing**:
   - Test configurations reference the main code path using `%GIT_PATH%`
   - Common test configuration in `code/test/Config/CCAST_.CFG`

3. **Environment Variables**:
   - `GIT_PATH` - Points to the root of the source code repository
   - `VECTORCAST_DIR` - Points to the VectorCAST installation directory

### 4.2 Build Dependencies

The build system manages several types of dependencies:

1. **Library Dependencies**:
   - The geomodel library depends on base, first, bsp, FPU, and maverick libraries
   - Include paths are configured in the Eclipse project

2. **Test Dependencies**:
   - Tests depend on the main library code
   - Tests share common configuration files

3. **Tool Dependencies**:
   - Eclipse CDT for development
   - VectorCAST for testing
   - GNU Make for building

## 5. Key Build Targets and Operations

### 5.1 Main Library Build

The Eclipse project is configured to build the geomodel static library with:
- C++17 standard
- Position-independent code
- pthread support
- Comprehensive include paths for dependent libraries

### 5.2 Test Execution

Each test project follows a standard execution pattern:
1. Build the test environment
2. Run the test script
3. Execute tests with VectorCAST CLI
4. Generate coverage reports

### 5.3 Coverage Analysis

The build system supports different coverage configurations:
- Statement and MC/DC coverage for most components
- Selective coverage disabling for specific components
- Coverage suppression for test files

## 6. Summary of Geomodel Library Components

Based on the build system and test configuration, the geomodel library appears to be a comprehensive geospatial modeling system for drone control with the following major components:

1. **Geometric Primitives**: Circle, Polygon, Sphere, Prism
2. **Volume Management**: Polymgr, Heightbounds, Obstmgr
3. **Reference Systems**: Gellipsoid, Georef, Tecef, Vgeoref
4. **Data Management**: Fidcache, Frefcache, Aposbuffer
5. **Environmental Models**: Ussa76, Magfield, Gfield, Srtm_grid
6. **Obstacle Management**: Obstmgr, Polymgr, Heightabs
7. **Utility Components**: Endian16/32/64, Grid_vertex, Runway

The build system effectively supports both development and comprehensive testing of these components, with a focus on ensuring correctness across different endianness configurations and achieving high code coverage.

## Referenced Context Files

No context files were provided in the input.