# Generated from:

- code/include/Gfield.h (224 tokens)
- code/include/Magfield.h (512 tokens)
- code/include/Imagfield.h (103 tokens)
- code/include/Ftrop.h (397 tokens)
- code/include/Feabs.h (276 tokens)
- code/include/Fmemcmd.h (725 tokens)
- code/include/Frefresh.h (154 tokens)
- code/include/Odem.h (210 tokens)
- code/include/FMCP_adsb_v.h (1013 tokens)
- code/include/Iarea.h (137 tokens)
- code/include/Igeosrc.h (244 tokens)
- code/include/Kgeo.h (291 tokens)
- code/source/Gfield.cpp (339 tokens)
- code/source/Magfield.cpp (730 tokens)
- code/source/Ftrop.cpp (413 tokens)
- code/source/Feabs.cpp (234 tokens)
- code/source/Fmemcmd.cpp (1248 tokens)
- code/source/Frefresh.cpp (71 tokens)
- code/source/Odem.cpp (171 tokens)
- code/source/FMCP_adsb_v.cpp (4127 tokens)

## With context from:

- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/geomodel/06_Core_Geometric_Models.md (4404 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/geomodel/05_Coordinate_Systems.md (3935 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/geomodel/04_Height_And_Terrain.md (6008 tokens)

---

# Environmental and Field Models in the Geomodel Library

This comprehensive summary details the environmental and field models in the geomodel library, focusing on gravity computation, magnetic field management, ADS-B data processing, and feature configuration capabilities.

## 1. Gravity Field Management (Gfield)

The `Gfield` class provides gravity computation with position corrections, accounting for Earth's non-uniform gravitational field.

### Core Functionality

```cpp
class Gfield {
public:
    static const Real gravity0;   // Acceleration of gravity at 45.5425 deg lat (m/s2)
    static void gravity_c(Maverick::Irvector3& gn, const Apos& pos);
};
```

### Gravity Computation Algorithm

The `gravity_c` method computes the actual gravity acceleration in the navigation frame (NED) based on the current position:

1. Sets North and East components to zero (gravity acts downward)
2. Calculates local gravity based on latitude using the formula:
   ```
   g_0 = g_E * (1 + k * sin²(φ)) / sqrt(1 - e² * sin²(φ))
   ```
   Where:
   - `g_E` is equatorial gravity (`Kgeo::ge` = 9.7803253359 m/s²)
   - `k` is a gravity constant (`Kgeo::k`)
   - `e²` is squared eccentricity (`Kgeo::e2`)
   - `φ` is latitude

3. Computes the Down gravity component accounting for altitude:
   ```
   g_N = g_0 * (R_M² / (R_M + h)²)
   ```
   Where:
   - `R_M` is Earth's mean radius (`Kgeo::wgs84_rm` = 6,371,000 m)
   - `h` is the actual WGS84 altitude

This implementation accounts for both latitude variation (gravity increases from equator to poles) and altitude variation (gravity decreases with height).

## 2. Magnetic Field Management (Magfield)

The `Magfield` class manages magnetic field data for navigation purposes, providing magnetic field vectors in NED components for a longitude-latitude mesh.

### Core Components

```cpp
class Magfield : public Moving_buffer_map, public Imagfield {
public:
    Magfield(Base::Ifile& file0, const Base::Ifile::Part_index partition0);
    bool compute(const Base::Lonlat& pos, Maverick::Irvector3& bn) const;
private:
    Gen_sd_map sd;  // Magnetic field SD reader manager
    // Work vectors for interpolation
    mutable Maverick::Rvector3 a, b, top, bottom;
};
```

### Magnetic Field Computation

The `compute` method retrieves and interpolates magnetic field data for a given position:

1. Retrieves magnetic field data from the buffered map for the requested position
2. Performs bilinear interpolation between the four nearest grid points:
   - First interpolates along longitude for top and bottom grid rows
   - Then interpolates between top and bottom results along latitude
3. Returns the interpolated magnetic field vector in NED coordinates

### Data Storage and Access

- Magnetic field data is stored on SD card in a grid format
- The `Moving_buffer_map` base class provides efficient buffered access to this data
- Each grid element contains three single-precision values (6 bytes) representing the magnetic field vector components
- The grid has a size of 3x3 squares, allowing for efficient interpolation

### Helper Functions

- `get_real`: Casts a Uint16 array (little-endian) to a Real number
- `get_vector`: Extracts a 3D vector from a Uint16 array
- `interpolate`: Performs linear interpolation between two vectors using the formula: `(1.0 - r) * a + r * b`

## 3. ADS-B Data Processing (FMCP_adsb_v)

The `FMCP_adsb_v` class processes ADS-B (Automatic Dependent Surveillance-Broadcast) data for moving obstacle detection and tracking.

### Core Components

```cpp
class FMCP_adsb_v : public Base::IFMCP {
public:
    explicit FMCP_adsb_v(Base::Icmdfw& cmd0);
    virtual void process(Base::Vrefdstbuff& data, Base::Iset& dst);
private:
    // Data structures
    struct Spherical_position {
        struct Pos { Real azm, elv, dst; };
        struct Flags { bool sph_ok, azm_ok, elv_ok, dst_ok; };
        Pos data;
        Flags flags;
        bool is_valid() const;
    };
    
    Base::Icmdfw& cmd;          // Command forwarder
    Base::Mobs_data mobsdata;   // Moving obstacle data
    Bsp::Hfvar h_pos;           // Moving obstacle feature handler
    Base::Tllh conv_pos;        // 3D position
    bool id_ok;                 // ID validity flag
    bool geo_ok;                // Geodetic position validity flag
    bool is_persistent;         // Data persistence flag
    Spherical_position sph_pos; // Spherical position handler
    
    // Processing methods
    void init_data();
    void parse_fields(const Base::Stlvector<Base::Vref_wr>& vrefs);
    void compute_from_spherical();
    void compute_position();
    void compute_velocity();
};
```

### ADS-B Data Processing Flow

The `process` method handles incoming ADS-B data:

1. **Initialization**: Resets data structures if not in persistent mode
2. **Field Parsing**: Processes each field in the incoming data buffer
3. **Position Computation**: Calculates the obstacle's position based on available data
4. **Velocity Computation**: Calculates the obstacle's velocity vector
5. **Obstacle Creation**: Creates a moving obstacle command with the processed data

### Data Sources and Formats

The system supports multiple ADS-B data sources:

1. **MAVLINK Format**:
   - Position in latitude/longitude/altitude
   - Velocity in horizontal/vertical components
   - Heading information
   - Aircraft identification (ICAO address, callsign)
   - Status flags for data validity

2. **Sagetech Format**:
   - Position in latitude/longitude/altitude
   - Velocity in north/east/vertical components
   - Status flags for data validity

3. **Daedalean Format** (Camera-based detection):
   - Position in spherical coordinates (azimuth, elevation, distance)
   - Target classification information

### Position Computation Methods

The class implements two position computation methods:

1. **Geodetic Position**: Uses directly provided latitude/longitude/altitude
2. **Spherical Position**: Converts spherical coordinates to geodetic:
   - Converts azimuth/elevation/distance to cartesian coordinates
   - Transforms coordinates from UAV-relative to global frame
   - Sets the moving obstacle position to the computed location

### Moving Obstacle Data Structure

The processed data populates a `Mobs_data` structure containing:
- Unique identifier (ID)
- Position in geodetic coordinates
- Velocity vector
- Heading information
- Aircraft type information (emitter type)
- Callsign and squawk code
- Data validity flags

## 4. Feature Configuration Management

### 4.1 Ftrop: Generic Operation and Named Features Setter

The `Ftrop` class configures absolute generic operation features and named features via the PDI interface.

```cpp
class Ftrop : public Base::Ideserializable_async {
public:
    Ftrop();
    virtual Base::Async_sres cset(Base::Lossy_error& str);
private:
    Base::Tunarray_async<Feabs> opg;    // List of operation generic features
    Base::Tunarray_async<Feabs> opn;    // List of operation named features
    static const Uint16 max_elems = 8;  // Max elements to load per call
    enum Astate { ast_opg, ast_opn };   // Async state
    Astate ast;
};
```

#### Asynchronous Configuration Process

The `cset` method implements an asynchronous two-stage configuration process:

1. First configures operation generic features (`opg`)
2. Then configures operation named features (`opn`)
3. Returns completion status for asynchronous processing

This approach allows loading up to 8 elements per call, preventing blocking of the system during configuration.

### 4.2 Feabs: Absolute Feature Tunable

The `Feabs` class configures global features of absolute type via the PDI interface.

```cpp
class Feabs {
public:
    explicit Feabs(const Base::Fid id0);
    void cset(Base::Lossy_error& str);
private:
    Bsp::Hfvar id;  // ID of the feature to tune
};
```

#### Feature Configuration Process

The `cset` method deserializes absolute position data:

1. Reads compressed longitude, latitude, and WGS84 height values
2. Builds an absolute feature with these coordinates
3. Sets the feature identified by the stored ID

This allows configuring waypoints, home positions, and other location-based features.

### 4.3 Fmemcmd: Feature Memory Command Manager

The `Fmemcmd` class manages and executes feature memory commands, allowing storage and manipulation of feature values.

```cpp
class Fmemcmd : public Base::Itunable {
public:
    Fmemcmd();
    virtual void cset(Base::Lossy_error& str);
    virtual void cget(Base::Lossy& str) const;
private:
    // Command parameters
    Base::Fref f;       // Value to write
    Uint16 mem_idx;     // Feature index to write
    bool respect_wrt;   // Use same wrt as f
    Uint16 wrt;         // Value if respect_wrt is false
    
    // Data storage
    Base::Array<Base::Fvar_commit> mem; // Array for memory operations
    
    // Work variables
    Fidcache fcache;        // Feature identifier cache
    Rpos rp;                // Relative position for transformations
    Maverick::Rvector3 rn;  // Relative vector for orientation
    Apos pos;               // Absolute position for representation
    
    void apply0();          // Apply the memory command
};
```

#### Memory Command Execution

The `apply0` method executes the memory command:

1. Checks if the target memory index is valid
2. Retrieves the value to write from the feature reference
3. Handles coordinate transformations if needed:
   - Relative to absolute: Transforms relative coordinates to absolute
   - Absolute to relative: Transforms absolute coordinates to relative
4. Commits the value to the target memory location

#### Coordinate Transformation Logic

The class implements sophisticated coordinate transformation logic:

1. **Relative to Absolute Transformation**:
   - Refreshes the reference position from the feature cache
   - Computes the relative position
   - Transforms the relative vector to absolute coordinates
   - Updates the feature data with absolute coordinates

2. **Absolute to Relative Transformation**:
   - Refreshes the reference position from the feature cache
   - Computes the relative position from absolute coordinates
   - Updates the feature data with relative coordinates

### 4.4 Frefresh: Feature Refresh Manager

The `Frefresh` class provides a mechanism to refresh feature values.

```cpp
class Frefresh : public Base::Ideserializable {
public:
    explicit Frefresh(Base::Fid id);
    virtual void cset(Base::Lossy_error& str);
private:
    Base::Fvar_commit fv;  // Feature variable to commit
};
```

The `cset` method deserializes a value and commits it to the specified feature, providing a simple way to update feature values.

## 5. Terrain Obstacle Management (Odem)

The `Odem` class represents terrain obstacles and computes repulsion fields for obstacle avoidance.

```cpp
class Odem : public Base::Itunable {
public:
    Odem();
    void field(const Real AGLevel, Obsadder& obadr) const;
    virtual void cset(Base::Lossy_error& str);
    virtual void cget(Base::Lossy& str) const;
private:
    bool active;   // Enable flag
    Base::Vref r;  // Distance parameter
};
```

### Repulsion Field Computation

The `field` method computes the repulsion field for terrain:

1. Checks if the obstacle is active
2. Creates a downward-pointing repulsion vector
3. Calculates the signed distance to the terrain (AGLevel - r)
4. Adds the repulsion to the obstacle adder

This creates a virtual force pushing the UAV away from the terrain when it gets too close.

## 6. Integration with Core Geometric Models

The environmental and field models integrate with the core geometric models to provide a complete environmental model for drone navigation:

### 6.1 Position Management Integration

- `Gfield` uses the `Apos` class to compute gravity based on current position
- `Magfield` uses the `Base::Lonlat` position to retrieve magnetic field data
- `FMCP_adsb_v` converts between different position representations (spherical, geodetic)
- `Fmemcmd` uses `Apos` and `Rpos` for coordinate transformations

### 6.2 Height Management Integration

- `Odem` uses Above Ground Level (AGL) height for terrain obstacle avoidance
- `FMCP_adsb_v` processes altitude data from ADS-B messages
- `Feabs` configures absolute positions including height information

### 6.3 Coordinate System Integration

- `Gfield` works in the NED (North-East-Down) coordinate frame
- `Magfield` provides magnetic field vectors in NED coordinates
- `FMCP_adsb_v` transforms between spherical, cartesian, and geodetic coordinates
- `Fmemcmd` handles transformations between relative and absolute coordinate systems

## 7. Mathematical Models and Algorithms

### 7.1 Gravity Model

The gravity model accounts for Earth's non-uniform gravitational field:

1. **Latitude Variation**: Gravity increases from equator to poles due to Earth's oblate shape
   ```
   g_0 = g_E * (1 + k * sin²(φ)) / sqrt(1 - e² * sin²(φ))
   ```

2. **Altitude Variation**: Gravity decreases with height according to inverse square law
   ```
   g = g_0 * (R_M² / (R_M + h)²)
   ```

### 7.2 Magnetic Field Interpolation

The magnetic field interpolation uses bilinear interpolation:

1. **Longitude Interpolation**:
   ```
   top = (1-r_lon) * tl + r_lon * tr
   bottom = (1-r_lon) * bl + r_lon * br
   ```

2. **Latitude Interpolation**:
   ```
   result = (1-r_lat) * bottom + r_lat * top
   ```

Where `r_lon` and `r_lat` are interpolation ratios between 0 and 1.

### 7.3 Spherical to Cartesian Conversion

The spherical to cartesian conversion used in ADS-B processing:

```
x = distance * cos(elevation) * cos(azimuth)
y = distance * cos(elevation) * sin(azimuth)
z = -distance * sin(elevation)
```

## 8. Data Flow in Environmental Modeling

### 8.1 Gravity Field Data Flow

1. UAV position (`Apos`) is input to `Gfield::gravity_c`
2. Latitude is extracted to compute latitude-dependent gravity
3. Altitude is used to compute altitude-dependent gravity
4. Resulting gravity vector is output in NED frame

### 8.2 Magnetic Field Data Flow

1. UAV position (`Base::Lonlat`) is input to `Magfield::compute`
2. Position is used to retrieve nearest magnetic field data points from SD card
3. Bilinear interpolation computes the magnetic field at the exact position
4. Resulting magnetic field vector is output in NED frame

### 8.3 ADS-B Data Flow

1. ADS-B data is received in various formats (MAVLINK, Sagetech, Daedalean)
2. `FMCP_adsb_v::parse_fields` extracts relevant fields (position, velocity, identification)
3. Position is computed based on available data (geodetic or spherical)
4. Velocity is computed from velocity components or derived from position changes
5. Moving obstacle data is created and forwarded to the obstacle management system

### 8.4 Feature Configuration Data Flow

1. Configuration data is received via PDI interface
2. `Ftrop` distributes configuration to operation generic and named features
3. `Feabs` configures absolute features with position information
4. `Fmemcmd` executes memory commands, potentially involving coordinate transformations
5. Updated feature values affect navigation and obstacle avoidance behavior

## 9. Practical Applications in Flight Control

### 9.1 Navigation Applications

- **Magnetic Heading**: `Magfield` provides magnetic field data for compass heading calculation
- **Gravity Compensation**: `Gfield` provides accurate gravity vector for inertial navigation
- **Position Features**: `Feabs` and `Ftrop` configure waypoints and other position-based features
- **Memory Operations**: `Fmemcmd` allows storing and manipulating position data during flight

### 9.2 Obstacle Avoidance Applications

- **Moving Obstacle Detection**: `FMCP_adsb_v` processes ADS-B data to detect and track other aircraft
- **Terrain Avoidance**: `Odem` generates repulsion fields to avoid terrain
- **Obstacle Configuration**: Feature configuration system allows defining static obstacles

### 9.3 Sensor Fusion Applications

- **Position Integration**: Different position sources (GPS, ADS-B, visual) are integrated
- **Coordinate Transformations**: Various coordinate systems are transformed as needed
- **Height Reference Systems**: Different height references (WGS84, MSL, AGL) are managed

## 10. Referenced Context Files

The following context files provided valuable information for understanding the environmental and field models:

1. **06_Core_Geometric_Models.md**: Provided details on the `Apos` class and its position management capabilities, which are used by `Gfield` for gravity computation and by `FMCP_adsb_v` for position transformations.

2. **05_Coordinate_Systems.md**: Explained the coordinate system management capabilities that underpin the environmental models, particularly the transformations between different reference frames used in `Magfield` and `FMCP_adsb_v`.

3. **04_Height_And_Terrain.md**: Detailed the height management system that supports terrain obstacle avoidance in `Odem` and altitude processing in `FMCP_adsb_v`.

These context files helped clarify how the environmental and field models integrate with the broader geomodel library to provide a comprehensive environmental model for drone navigation.