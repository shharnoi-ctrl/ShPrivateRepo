# Generated from:

- code/include/Georef.h (469 tokens)
- code/include/Georef_fw.h (22 tokens)
- code/include/Vgeoref.h (736 tokens)
- code/include/Tecef.h (528 tokens)
- code/include/Tecef_fw.h (74 tokens)
- code/include/Geomodel.h (544 tokens)
- code/source/Georef.cpp (163 tokens)
- code/source/Vgeoref.cpp (489 tokens)
- code/source/Tecef.cpp (85 tokens)
- code/source/Geomodel.cpp (597 tokens)

## With context from:

- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/geomodel/06_Core_Geometric_Models.md (4404 tokens)

---

# Geomodel Library Coordinate System Management

This comprehensive analysis details the coordinate system management capabilities in the geomodel library, focusing on geographic reference systems, terrain height information, and coordinate transformations essential for UAV navigation.

## 1. Georef: Geographic Reference Integration

The `Georef` class serves as a central integration point for multiple geographic data sources, providing a unified interface for terrain height information.

### Core Components and Functionality

```cpp
class Georef : public Igeomesh, public Iheight_computer {
public:
    Georef(const Igeosrc& geoid0, const Igeosrc& dem0, const Igeomesh& srtmsrc0);
    
    // Height information methods
    virtual Real wgs84_height(const Base::Lonlat& pos) const;
    virtual Real msl_height(const Base::Lonlat& pos) const;
    virtual Terrain_height srtm_height(const Base::Lonlat& pos) const;
    
    // Geoid boundary checking
    bool inside_geoid(const Base::Lonlat& pos) const;
    
private:
    const Igeosrc& geoid;      // WGS84 ellipsoid to MSL length for each point
    const Igeosrc& dem;        // MSL geoid to AGL length (estimated)
    const Igeomesh& srtmsrc;   // SRTM source
};
```

### Data Sources Integration

`Georef` integrates three critical geographic data sources:

1. **Geoid Model** (`geoid`): Provides the offset between WGS84 ellipsoid and mean sea level (MSL)
2. **Digital Elevation Model** (`dem`): Provides estimated terrain height above MSL
3. **SRTM Data** (`srtmsrc`): Provides Shuttle Radar Topography Mission terrain data

### Height Calculation Logic

The class implements a hierarchical approach to height information:

```cpp
Real Georef::msl_height(const Base::Lonlat& pos) const {
    const Base::Async_data<Real> dem_height = dem.get(pos);
    return (dem_height.async_st == Base::async_done_ok) ? 
           dem_height.data : srtm_height(pos).h;
}
```

This implementation shows that:
1. The system first attempts to get height from the DEM source
2. If DEM data is unavailable or invalid, it falls back to SRTM height data
3. The method returns height above mean sea level (MSL)

### System Integration

The constructor registers itself as the height helper for the `Apos` class:

```cpp
Georef::Georef(const Igeosrc& geoid0, const Igeosrc& dem0, const Igeomesh& srtmsrc0) :
    geoid(geoid0), dem(dem0), srtmsrc(srtmsrc0) {
    Apos::set_height_helper(*this);
}
```

This integration allows the absolute position (`Apos`) system to query height information directly from `Georef`, creating a seamless connection between position management and terrain data.

## 2. Vgeoref: UAV-Centric Terrain Height Management

The `Vgeoref` class provides specialized terrain height information near the UAV's position, incorporating both SRTM data and real-time measurements like LIDAR.

### Core Components and Functionality

```cpp
class Vgeoref : public Igeosrc {
public:
    Vgeoref();
    
    // Height information methods
    Base::Async_data<Real> get(const Base::Lonlat& pos) const;
    void dem_set(const Base::Lonlat& pos, const Real dem0);
    
    // Configuration
    void cset(Base::Lossy_error& str);
    
private:
    Bsp::Hrvar hdem;           // Estimated DEM value
    Real dem_drn;              // Delta on meters (north and east) around pos where dem is valid
    Base::Radrng dem_rlon;     // Longitude range where dem is valid
    Base::Radrng dem_rlat;     // Latitude range where dem is valid
};
```

### Local Terrain Model

`Vgeoref` maintains a local terrain model centered on the UAV's position:

1. **Valid Region Definition**: Defines a rectangular region (in latitude/longitude) around the UAV where the terrain model is valid
2. **Terrain Height Storage**: Stores the estimated terrain height in the `hdem` variable
3. **Validity Range**: Uses `dem_drn` (default 10 meters) to define how far from the UAV position the terrain model is considered valid

### Dynamic Terrain Model Updates

The `dem_set` method updates the terrain model when new information is available:

```cpp
void Vgeoref::dem_set(const Base::Lonlat& pos, const Real dem0) {
    // Update dem pos
    Base::Tllh_low_res dllh;
    {
        Geo::Apos p;
        p.set_llh(Base::Tllh::build(pos, 0.0F));
        Rvector3 drn(dem_drn,dem_drn,0);
        p.geoevol(drn, dllh);
    }
    dem_rlon.set(static_cast<Real>(pos.lon),dllh.lon);
    dem_rlat.set(static_cast<Real>(pos.lat),dllh.lat);

    // Update dem
    hdem.set(dem0);
}
```

This method:
1. Calculates the latitude/longitude range where the terrain model is valid
2. Updates the stored terrain height value
3. Uses `geoevol` to convert the distance in meters to latitude/longitude deltas

### Terrain Height Queries

The `get` method provides terrain height information for a given position:

```cpp
Base::Async_data<Real> Vgeoref::get(const Base::Lonlat& pos) const {
    const bool is_in = (dem_rlon.is_in(static_cast<Real>(pos.lon)) &&
                        dem_rlat.is_in(static_cast<Real>(pos.lat)));
    return Base::Async_data<Real>(is_in ? Base::async_done_ok : Base::async_done_error, hdem.get());
}
```

This implementation:
1. Checks if the requested position is within the valid region
2. Returns the stored terrain height if valid, with appropriate status flag
3. Returns an error status if the position is outside the valid region

## 3. Tecef: Earth-Centered, Earth-Fixed Coordinate Representation

The `Tecef` class provides a container for Earth-Centered, Earth-Fixed (ECEF) coordinates and methods for converting between ECEF and geodetic (LLH) coordinate systems.

### Core Components and Functionality

```cpp
class Tecef : public Maverick::Rvector3 {
public:
    Tecef();
    Tecef(const Base::Apos_data& apos);
    
    // Coordinate conversion methods
    void set_wgs84(const Base::Apos_data &apos);
    void get_wgs84(Base::Tllh& llh0) const;
};
```

### ECEF Representation

`Tecef` inherits from `Maverick::Rvector3`, representing ECEF coordinates as a 3D vector:
- X-axis: Through the intersection of the prime meridian and equator
- Y-axis: Through the equator at 90° east longitude
- Z-axis: Through the North Pole

### Coordinate Conversion

The class provides bidirectional conversion between geodetic (LLH) and ECEF coordinates:

```cpp
void Tecef::set_wgs84(const Base::Apos_data& apos) {
    Gellipsoid::geo2ecef(apos.get_cs(), static_cast<Real>(apos.get_llh().h), *this);
}

void Tecef::get_wgs84(Base::Tllh& llh0) const {
    Gellipsoid::ecef2geo3(*this, llh0);
}
```

These methods:
1. Leverage the `Gellipsoid` class for the actual mathematical transformations
2. Handle the conversion between different data types and structures
3. Provide a clean interface for working with different coordinate systems

## 4. Geomodel: Coordinate Transformation Functions

The `Geomodel` class provides static methods for coordinate transformations, particularly rotations between NED (North-East-Down) and ECEF (Earth-Centered, Earth-Fixed) reference frames.

### Core Components and Functionality

```cpp
class Geomodel {
public:
    // Coordinate transformation methods
    static void ned2ecef(const Base::Tllcs& cs, const Maverick::Irvector3& ned, Maverick::Irvector3& ecef);
    static void ecef2ned(const Base::Tllcs& cs, const Maverick::Irvector3& ecef, Maverick::Irvector3& ned);
};
```

### NED to ECEF Transformation

The `ned2ecef` method transforms a vector from the local NED frame to the global ECEF frame:

```cpp
void Geomodel::ned2ecef(const Base::Tllcs& cs, const Irvector3& ned, Irvector3& ecef) {
    ecef[pos_x] = (-cs.slat*cs.clon*ned[north]) - (cs.slon*ned[east]) - (cs.clat*cs.clon*ned[down]);
    ecef[pos_y] = ((-cs.slat*cs.slon*ned[north]) + (cs.clon*ned[east])) - (cs.clat*cs.slon*ned[down]);
    ecef[pos_z] = (cs.clat*ned[north]) - (cs.slat*ned[down]);
}
```

This transformation uses the rotation matrix:

$$
\mathbf{v}^e = \begin{bmatrix}
-\sin \phi \cos \lambda & -\sin \lambda & -\cos \phi \cos \lambda \\
-\sin \phi \sin \lambda & \cos \lambda & -\cos \phi \sin \lambda \\
\cos \phi & 0 & -\sin \phi
\end{bmatrix} \mathbf{v}^n
$$

Where:
- $\phi$ is latitude
- $\lambda$ is longitude
- $\mathbf{v}^n$ is the vector in NED coordinates
- $\mathbf{v}^e$ is the resulting vector in ECEF coordinates

### ECEF to NED Transformation

The `ecef2ned` method transforms a vector from the global ECEF frame to the local NED frame:

```cpp
void Geomodel::ecef2ned(const Base::Tllcs& cs, const Irvector3& ecef, Irvector3& ned) {
    ned[north] = ((-cs.slat*cs.clon*ecef[pos_x]) - (cs.slat*cs.slon*ecef[pos_y])) + (cs.clat*ecef[pos_z]);
    ned[east] = ((-cs.slon*ecef[pos_x]) + (cs.clon*ecef[pos_y]));
    ned[down] = ((-cs.clat*cs.clon*ecef[pos_x]) - (cs.clat*cs.slon*ecef[pos_y])) - (cs.slat*ecef[pos_z]);
}
```

This transformation uses the rotation matrix:

$$
\mathbf{v}^n = \begin{bmatrix}
-\sin \phi \cos \lambda & -\sin \phi \sin \lambda & \cos \phi \\
-\sin \lambda & \cos \lambda & 0 \\
-\cos \phi \cos \lambda & -\cos \phi \sin \lambda & -\sin \phi
\end{bmatrix} \mathbf{v}^e
$$

Where:
- $\phi$ is latitude
- $\lambda$ is longitude
- $\mathbf{v}^e$ is the vector in ECEF coordinates
- $\mathbf{v}^n$ is the resulting vector in NED coordinates

## 5. Integration with Core Geometric Models

The coordinate system management components integrate with the Core Geometric Models to provide a complete spatial reference system for UAV navigation.

### Data Flow Between Components

1. **Position Representation**:
   - `Apos` class (from Core Geometric Models) represents absolute positions in LLH coordinates
   - `Tecef` provides ECEF representation of positions
   - `Geomodel` enables transformations between coordinate frames

2. **Height Information Flow**:
   - `Georef` integrates multiple height data sources (geoid, DEM, SRTM)
   - `Vgeoref` provides local terrain height near the UAV
   - `Apos` queries height information through the `Iheight_computer` interface

3. **Coordinate Transformations**:
   - `Gellipsoid` (from Core Geometric Models) provides base transformations between LLH and ECEF
   - `Geomodel` provides vector rotations between NED and ECEF frames
   - `Tecef` encapsulates ECEF coordinates and conversion methods

### Mathematical Framework Integration

The coordinate system components form a cohesive mathematical framework:

1. **Position Representation**:
   - LLH (Longitude, Latitude, Height): Geographic coordinates on WGS84 ellipsoid
   - ECEF (Earth-Centered, Earth-Fixed): Cartesian coordinates with origin at Earth's center
   - NED (North-East-Down): Local tangent plane coordinates

2. **Transformation Chain**:
   - LLH ⟷ ECEF: Handled by `Gellipsoid` and encapsulated in `Tecef`
   - ECEF ⟷ NED: Handled by `Geomodel` rotation functions
   - Small displacements in NED: Handled by `Apos::geoevol` functions

3. **Height Reference Systems**:
   - WGS84 Height: Height above WGS84 ellipsoid
   - MSL Height: Height above mean sea level (geoid)
   - AGL Height: Height above ground level (terrain)

## 6. Practical Applications in Drone Navigation

The coordinate system management capabilities in the geomodel library support several critical drone navigation functions:

### Terrain Following and Obstacle Avoidance

1. **Terrain Height Awareness**:
   - `Georef` provides terrain height information from multiple sources
   - `Vgeoref` provides high-precision local terrain model near the UAV
   - These enable the drone to maintain safe altitude above terrain

2. **Position Transformation for Sensors**:
   - `Geomodel` rotation functions allow sensor data in different reference frames to be integrated
   - LIDAR or radar data can be transformed between body frame, NED, and ECEF as needed

### Navigation and Path Planning

1. **Global-to-Local Conversion**:
   - Waypoints defined in global coordinates (LLH) can be converted to local NED frame for path planning
   - `Tecef` and `Geomodel` provide the necessary transformations

2. **Displacement Calculations**:
   - Small displacements can be efficiently calculated using `Apos::geoevol` functions
   - Large displacements use full coordinate transformations through ECEF

### Sensor Fusion and Localization

1. **Multi-sensor Integration**:
   - GPS provides position in LLH coordinates
   - IMU provides orientation and acceleration in body frame
   - `Geomodel` transformations allow these to be combined in a common reference frame

2. **Terrain-Relative Navigation**:
   - `Vgeoref` provides terrain height information that can be used for terrain-relative navigation
   - This is especially useful in GPS-denied environments

## 7. System Architecture and Data Flow

The coordinate system management components form a layered architecture:

1. **Base Layer**: Mathematical transformations and coordinate system definitions
   - `Gellipsoid`: Basic ellipsoid model and coordinate transformations
   - `Geomodel`: Vector rotations between reference frames

2. **Representation Layer**: Data structures for different coordinate systems
   - `Tecef`: ECEF coordinate representation
   - `Tllh`: LLH coordinate representation (from Core Geometric Models)

3. **Integration Layer**: Components that combine multiple data sources
   - `Georef`: Integration of multiple height data sources
   - `Vgeoref`: Local terrain model near UAV

4. **Application Layer**: Components that use coordinate systems for specific functions
   - `Apos`: Absolute position management
   - Navigation and path planning components (not shown in provided files)

### Data Flow for Position Updates

1. UAV receives position update from GPS in LLH coordinates
2. Position is stored in `Apos` object
3. If needed, position is converted to ECEF using `Tecef`
4. Local NED frame is established using `Geomodel` transformations
5. Terrain height is queried from `Georef` or `Vgeoref`
6. Navigation decisions are made based on position and terrain information

### Data Flow for Terrain Height Updates

1. UAV receives terrain measurements from sensors (LIDAR, radar)
2. Measurements are transformed to global coordinates
3. `Vgeoref` is updated with new terrain height information
4. Updated terrain model is used for navigation decisions

## Referenced Context Files

The following context file provided valuable information for understanding the coordinate system management capabilities:

- **Core_Geometric_Models.md**: Provided detailed information about the `Apos` class, `Gellipsoid` class, and their role in coordinate transformations. The document explained how these components work with the coordinate system management classes to provide a complete spatial reference system. It was particularly helpful for understanding the mathematical foundations of the coordinate transformations and how they integrate with the broader geomodel library.

The Core_Geometric_Models document helped clarify:
1. How `Apos` uses the height helper interface implemented by `Georef`
2. How `Gellipsoid` provides the fundamental transformations between LLH and ECEF
3. The mathematical basis for coordinate transformations and small displacement calculations