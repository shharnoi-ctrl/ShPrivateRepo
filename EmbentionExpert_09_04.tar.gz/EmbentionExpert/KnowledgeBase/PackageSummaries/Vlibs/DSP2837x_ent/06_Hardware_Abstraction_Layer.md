# Generated from:

- code/include/Devcfg_regs.h (5750 tokens)
- code/include/ADC_regs.h (10028 tokens)
- code/include/Ipc_regs.h (379 tokens)
- code/include/PWM_dev_regs.h (14380 tokens)
- code/include/Sys_regs.h (168 tokens)
- code/source/common/Emif1_regs.h (3628 tokens)

---

# Hardware Abstraction Layer for DSP28335 Microcontroller

This document provides a comprehensive summary of the hardware abstraction layer (HAL) for the DSP28335 microcontroller, focusing on register structures, memory maps, and hardware interfaces defined in the provided files. The HAL serves as a foundation for higher-level peripheral drivers by providing structured access to the microcontroller's hardware resources.

## 1. Functional Behavior and Logic

### 1.1 Register Access Architecture

The DSP28335 HAL implements a consistent pattern for hardware register access across all peripherals:

- **Register Bit Fields**: Each register's individual bits or bit groups are defined as bit-field structures
- **Register Unions**: Each register combines a full-word access (`all`) with structured bit-field access (`bit`)
- **Register Maps**: Complete peripheral register sets are defined as structures containing all relevant registers
- **Memory-Mapped Access**: Peripheral registers are accessed through pointers to predefined memory addresses

This architecture allows both bit-level and word-level access to hardware registers, providing flexibility for different access patterns while maintaining type safety and readability.

### 1.2 Namespace Organization

All hardware definitions are encapsulated within the `Dsp28335_ent` namespace, providing isolation from other code components and preventing naming conflicts. This namespace contains:

- Register bit-field definitions
- Register union types
- Peripheral register map structures
- Hardware-specific constants and enumerations

## 2. Control Flow and State Transitions

### 2.1 Register Access Patterns

The HAL implements several common patterns for register manipulation:

| Operation | Pattern | Example |
|-----------|---------|---------|
| Read full register | `reg.all` | `value = ADC_regs->ADCCTL1.all;` |
| Read specific bits | `reg.bit.FIELD` | `status = ADC_regs->ADCCTL1.bit.ADCBSY;` |
| Write full register | `reg.all = value` | `ADC_regs->ADCCTL1.all = 0x8000;` |
| Write specific bits | `reg.bit.FIELD = value` | `ADC_regs->ADCCTL1.bit.ADCPWDNZ = 1;` |
| Atomic bit set | `reg.all \|= mask` | `ADC_regs->ADCCTL1.all \|= 0x0080;` |
| Atomic bit clear | `reg.all &= ~mask` | `ADC_regs->ADCCTL1.all &= ~0x0080;` |

### 2.2 Hardware State Transitions

The register structures support various hardware state transitions, including:

- Power state management (power-up/down sequences)
- Peripheral initialization and configuration
- Interrupt enabling/disabling
- Hardware triggering and synchronization
- Error detection and handling

## 3. Inputs and Stimuli

The HAL defines structures for handling various inputs and stimuli:

### 3.1 Interrupt Management

Interrupt-related registers are consistently structured across peripherals:

- **Flag Registers**: Indicate which interrupts are pending (e.g., `ADCINTFLG`)
- **Clear Registers**: Clear specific interrupt flags (e.g., `ADCINTFLGCLR`)
- **Enable Registers**: Enable/disable specific interrupts (e.g., `TZEINT`)
- **Overflow Registers**: Indicate interrupt overflow conditions (e.g., `ADCINTOVF`)

### 3.2 Hardware Triggers

The HAL defines structures for configuring hardware triggers:

- **Trigger Selection**: Registers for selecting trigger sources (e.g., `ADCINTSOCSEL1`)
- **Trigger Force**: Registers for software-forcing of hardware triggers (e.g., `ADCSOCFRC1`)
- **Trigger Status**: Registers for monitoring trigger status (e.g., `ADCSOCFLG1`)

## 4. Outputs and Effects

### 4.1 Control Outputs

The HAL provides structures for controlling hardware outputs:

- **PWM Output Control**: Registers for controlling PWM outputs (e.g., `AQCTLAB`)
- **Digital Output Control**: Registers for controlling digital outputs
- **Analog Output Control**: Registers for controlling analog outputs

### 4.2 Status Outputs

The HAL defines structures for monitoring hardware status:

- **Status Registers**: Indicate peripheral status (e.g., `ADCCTL1.bit.ADCBSY`)
- **Event Registers**: Indicate hardware events (e.g., `ADCEVTSTAT`)
- **Counter Registers**: Provide counter values (e.g., `ADCCOUNTER`)

## 5. Parameters and Configuration

### 5.1 Device Configuration Registers

The `Devcfg_regs.h` file defines structures for device-level configuration:

- **Device Capability Registers**: Indicate available hardware features (DC0-DC20)
- **Peripheral Software Reset Registers**: Control peripheral resets (softpres)
- **CPU Select Registers**: Control which CPU accesses peripherals (cpusel)
- **Device Identification Registers**: Provide device identification (PARTIDL, PARTIDH)

Key structures include:

```cpp
struct Devcfg::Registers {
    union DEVCFGLOCK1_REG DEVCFGLOCK1;      // Lock bit for CPUSELx registers
    Uint32 DEVCFGLOCK2;                     // Lock bit for CPUSELx registers
    // ... many other registers
    union DC0_REG DC0;                      // Device Capability: Device Information
    union DC1_REG DC1;                      // Device Capability: Processing Block Customization
    // ... more device capability registers
    Softpres_regs softpres;                 // Peripheral Software Reset registers
    Cpusel_regs cpusel;                     // CPU Select register for common peripherals
    // ... other control registers
};
```

### 5.2 Peripheral Configuration

Each peripheral has specific configuration registers:

#### 5.2.1 ADC Configuration

The `ADC_regs.h` file defines structures for ADC configuration:

- **Control Registers**: Configure ADC operation (e.g., `ADCCTL1`, `ADCCTL2`)
- **Sampling Registers**: Configure ADC sampling (e.g., `ADCSOC_CTL`)
- **Post-Processing Registers**: Configure post-processing (e.g., `ADCPPB1CONFIG`)

#### 5.2.2 PWM Configuration

The `PWM_dev_regs.h` file defines structures for PWM configuration:

- **Time Base Control**: Configure PWM timing (e.g., `TBCTL`, `TBPRD`)
- **Compare Registers**: Configure PWM duty cycles (e.g., `CMPA`, `CMPB`)
- **Action Qualifiers**: Configure PWM output actions (e.g., `AQCTLA`, `AQCTLB`)
- **Dead Band Control**: Configure dead band generation (e.g., `DBCTL`, `DBRED`, `DBFED`)
- **Trip Zone Control**: Configure PWM protection (e.g., `TZCTL`, `TZSEL`)

#### 5.2.3 EMIF Configuration

The `Emif1_regs.h` file defines structures for External Memory Interface configuration:

- **SDRAM Control**: Configure SDRAM operation (e.g., `SDRAM_CR`, `SDRAM_TR`)
- **Asynchronous Memory Control**: Configure asynchronous memory (e.g., `ASYNC_CS2_CR`)
- **Timing Control**: Configure memory timing (e.g., `SDRAM_TR`, `SDR_EXT_TMNG`)

## 6. Error Handling and Contingency Logic

### 6.1 Error Detection

The HAL provides structures for error detection:

- **Error Flags**: Indicate error conditions (e.g., `FUSEERR`)
- **Overflow Flags**: Indicate overflow conditions (e.g., `ADCINTOVF`)
- **Status Flags**: Indicate abnormal status (e.g., `TZFLG`)

### 6.2 Error Handling

The HAL provides structures for error handling:

- **Error Clear Registers**: Clear error conditions (e.g., `ADCINTOVFCLR`)
- **Trip Zone Control**: Configure protection responses (e.g., `TZCTL`)
- **Force Registers**: Force protection actions (e.g., `TZFRC`)

## 7. File-by-File Breakdown

### 7.1 Devcfg_regs.h

This file defines device configuration registers that control system-level features and provide device identification.

Key components:
- Device capability registers (`DC0` through `DC20`) that indicate which peripherals are available
- Device identification registers (`PARTIDL`, `PARTIDH`, `REVID`)
- Peripheral software reset registers (`softpres`)
- CPU select registers (`cpusel`) for controlling which CPU accesses peripherals
- System debug control register (`SYSDBGCTL`)

Example structure:
```cpp
struct PARTIDL_BITS {                   // bits description
    Uint16 rsvd1:3;                     // 2:0 Reserved
    Uint16 rsvd2:2;                     // 4:3 Reserved
    Uint16 rsvd3:1;                     // 5 Reserved
    Uint16 QUAL:2;                      // 7:6 Qualification Status
    Uint16 PIN_COUNT:3;                 // 10:8 Device Pin Count
    // ... more fields
};
```

### 7.2 ADC_regs.h

This file defines Analog-to-Digital Converter (ADC) registers for configuring and controlling analog-to-digital conversion.

Key components:
- ADC control registers (`ADCCTL1`, `ADCCTL2`) for basic configuration
- Start-of-conversion (SOC) control registers for configuring conversion triggers
- Interrupt control registers for configuring ADC interrupts
- Post-processing block registers for configuring post-processing operations
- Result registers for reading conversion results

Example structure:
```cpp
struct ADCCTL1_BITS {                   // bits description
    Uint16 rsvd1:2;                     // 1:0 Reserved
    Uint16 INTPULSEPOS:1;               // 2 ADC Interrupt Pulse Position
    Uint16 rsvd2:4;                     // 6:3 Reserved
    Uint16 ADCPWDNZ:1;                  // 7 ADC Power Down
    Uint16 ADCBSYCHN:4;                 // 11:8 ADC Busy Channel
    Uint16 rsvd3:1;                     // 12 Reserved
    Uint16 ADCBSY:1;                    // 13 ADC Busy
    Uint16 rsvd4:2;                     // 15:14 Reserved
};
```

### 7.3 Ipc_regs.h

This file defines Inter-Processor Communication (IPC) registers for communication between multiple CPU cores.

Key components:
- IPC flag registers (`ipcack`, `ipcsts`, `ipcset`, `ipcclr`, `ipcflg`) for signaling between cores
- IPC data registers (`ipc1to2data`, `ipc2to1data`) for data exchange
- IPC address registers (`ipc1to2addr`, `ipc2to1addr`) for sharing memory addresses
- IPC command registers (`ipc1to2com`, `ipc2to1com`) for command exchange
- IPC boot control registers (`ipcbootsts`, `ipcbootmode`) for boot control

Example structure:
```cpp
struct Ipc_regs {
    Uint32      ipcack;         // IPC incoming flag clear (acknowledge) register
    Uint32      ipcsts;         // IPC incoming flag status register
    Uint32      ipcset;         // IPC remote flag set register
    // ... more registers
};
```

### 7.4 PWM_dev_regs.h

This file defines Enhanced Pulse Width Modulator (EPWM) registers for generating PWM signals.

Key components:
- Time base control registers (`TBCTL`, `TBPRD`) for configuring PWM timing
- Compare registers (`CMPA`, `CMPB`) for configuring PWM duty cycles
- Action qualifier registers (`AQCTLA`, `AQCTLB`) for configuring PWM output actions
- Dead band registers (`DBCTL`, `DBRED`, `DBFED`) for configuring dead band generation
- Trip zone registers (`TZCTL`, `TZSEL`) for configuring PWM protection
- Event trigger registers (`ETSEL`, `ETPS`) for configuring PWM events

Example structure:
```cpp
struct TBCTL_BITS {
    /// CTRMODE bits
    enum Ctrmode {
        ctrmode_count_up     = 0x0,
        ctrmode_count_down   = 0x1,
        ctrmode_count_updown = 0x2,
        ctrmode_freeze       = 0x3
    };
    
    Ctrmode CTRMODE:2;                  // 1:0 Counter Mode
    Phsen PHSEN:1;                      // 2 Phase Load Enable
    // ... more fields
};
```

### 7.5 Sys_regs.h

This file defines system-level functions for accessing system information.

Key components:
- `get_cpu_id()` function for determining which CPU core is executing
- `get_flash_pump_reg()` function for accessing the flash pump register

Example structure:
```cpp
struct Sys_regs {
    static Uint16 get_cpu_id();
    static Uint32& get_flash_pump_reg();
};
```

### 7.6 Emif1_regs.h

This file defines External Memory Interface (EMIF) registers for configuring external memory access.

Key components:
- SDRAM control registers (`SDRAM_CR`, `SDRAM_RCR`) for configuring SDRAM operation
- Asynchronous memory control registers (`ASYNC_CS2_CR`, `ASYNC_CS3_CR`, `ASYNC_CS4_CR`) for configuring asynchronous memory
- Timing control registers (`SDRAM_TR`, `SDR_EXT_TMNG`) for configuring memory timing
- Interrupt control registers for configuring EMIF interrupts
- Access protection registers for controlling memory access permissions

Example structure:
```cpp
struct SDRAM_CR_BITS {                    // bits description
    Uint16 PAGESIGE:3;                  // 2:0 Page Size.
    Uint16 rsvd1:1;                     // 3 Reserved
    Uint16 IBANK:3;                     // 6:4 Internal Bank setup of SDRAM devices.
    // ... more fields
};
```

## 8. Cross-Component Relationships

### 8.1 Register Access Patterns

The HAL implements consistent register access patterns across all peripherals:

1. **Bit-Field Access**: Access individual bits or bit groups through the `bit` structure
   ```cpp
   ADC_regs->ADCCTL1.bit.ADCPWDNZ = 1;  // Power up ADC
   ```

2. **Full-Word Access**: Access the entire register through the `all` field
   ```cpp
   ADC_regs->ADCCTL1.all = 0x0080;  // Set ADCPWDNZ bit
   ```

3. **Atomic Operations**: Perform atomic operations on registers
   ```cpp
   ADC_regs->ADCCTL1.all |= 0x0080;  // Set ADCPWDNZ bit without affecting others
   ```

### 8.2 Hardware Interfaces

The HAL defines interfaces for various hardware components:

1. **CPU Interface**: Registers for controlling CPU behavior and accessing CPU information
   - `Sys_regs::get_cpu_id()` for determining which CPU core is executing
   - CPU select registers (`cpusel`) for controlling which CPU accesses peripherals

2. **Memory Interface**: Registers for configuring memory access
   - EMIF registers for configuring external memory access
   - Memory protection registers for controlling memory access permissions

3. **Peripheral Interface**: Registers for configuring and controlling peripherals
   - ADC registers for configuring analog-to-digital conversion
   - PWM registers for configuring pulse width modulation
   - IPC registers for inter-processor communication

4. **Interrupt Interface**: Registers for configuring and controlling interrupts
   - Interrupt flag registers for indicating pending interrupts
   - Interrupt clear registers for clearing interrupt flags
   - Interrupt enable registers for enabling/disabling interrupts

### 8.3 Common Register Patterns

The HAL implements common register patterns across peripherals:

1. **Control Registers**: Configure peripheral operation
   - `ADCCTL1`, `ADCCTL2` for ADC
   - `TBCTL`, `CMPCTL` for PWM
   - `SDRAM_CR` for EMIF

2. **Status Registers**: Indicate peripheral status
   - `ADCCTL1.bit.ADCBSY` for ADC
   - `TBSTS` for PWM
   - `INT_RAW` for EMIF

3. **Flag Registers**: Indicate events or conditions
   - `ADCINTFLG` for ADC
   - `TZFLG` for PWM
   - `INT_RAW` for EMIF

4. **Clear Registers**: Clear flags or conditions
   - `ADCINTFLGCLR` for ADC
   - `TZCLR` for PWM
   - `INT_MSK_CLR` for EMIF

5. **Force Registers**: Force events or conditions
   - `ADCSOCFRC1` for ADC
   - `TZFRC` for PWM
   - `INT_MSK_SET` for EMIF

## 9. Referenced Context Files

The following context files provided useful information for understanding the hardware abstraction layer:

- `Entypes.h`: Defines basic data types used throughout the HAL (Uint16, Uint32, etc.)
- `Tnarray.h`: Defines template array classes used in register arrays
- `Hregmap.h`: Likely defines hardware register mapping utilities
- `Ku16.h`: Defines constants used in the EMIF register definitions

## Summary

The DSP28335 hardware abstraction layer provides a comprehensive foundation for accessing and controlling the microcontroller's hardware resources. The HAL implements consistent register access patterns across all peripherals, with detailed bit-field definitions that enable precise control of hardware behavior. The register structures are organized into logical groups that reflect the hardware architecture, making it easier to understand and use the hardware resources.

Common patterns in register access and manipulation are evident across different peripherals, including bit-field access, full-word access, and atomic operations. The HAL also provides consistent structures for handling interrupts, hardware triggers, and error conditions.

The HAL serves as a foundation for higher-level peripheral drivers by providing structured access to the microcontroller's hardware resources, enabling developers to build more complex functionality on top of this foundation.