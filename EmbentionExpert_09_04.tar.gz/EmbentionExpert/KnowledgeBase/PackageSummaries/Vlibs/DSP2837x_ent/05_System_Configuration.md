# Generated from:

- code/include/Devcfg.h (1514 tokens)
- code/include/Memcfg.h (241 tokens)
- code/include/PLL.h (140 tokens)
- code/include/System.h (291 tokens)
- code/include/Cpusys.h (2723 tokens)
- code/include/Uidreg.h (304 tokens)
- code/source/common/Cpusys.cpp (10078 tokens)
- code/source/common/Memcfg.cpp (10897 tokens)
- code/source/common/Clkcfgb.h (487 tokens)
- code/source/common/Clkcfgb.cpp (1623 tokens)
- code/source/cpu1/Devcfg.cpp (1264 tokens)
- code/source/cpu1/Devcfg_2837x.cpp (312 tokens)
- code/source/cpu1/PLL_cpu1_2837x.cpp (15434 tokens)
- code/source/cpu1/Sys_regs_2837x.cpp (125 tokens)
- code/source/cpu1/System_cpu1.cpp (5323 tokens)
- code/source/cpu1/Uidreg.cpp (651 tokens)
- code/source/cpu1/Uidreg_2837x.h (183 tokens)
- code/source/cpu1/Uid_reg_pimpl.cpp (1542 tokens)
- code/source/cpu2/System_cpu2.cpp (1129 tokens)
- code/source/cpu2/Sysuid_cpu2.cpp (41 tokens)
- code/source_FPA/cpu1/Sysuid_cpu1.cpp (302 tokens)

## With context from:

- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/DSP2837x_ent/06_Hardware_Abstraction_Layer.md (4115 tokens)

---

# Comprehensive System Configuration and Initialization for DSP28335 Microcontroller

This document provides a detailed analysis of the system configuration and initialization components for the DSP28335 microcontroller, focusing on the boot sequence, clock configuration, memory management, and peripheral initialization processes.

## 1. System Architecture Overview

The DSP28335 microcontroller features a dual-core architecture with CPU1 (main processor) and CPU2 (auxiliary processor). The initialization process differs between these cores, with CPU1 typically handling most of the system configuration before CPU2 becomes operational.

### 1.1 Key System Components

- **Device Configuration (Devcfg)**: Manages device-level configuration registers, CPU control, and peripheral ownership
- **Memory Configuration (Memcfg)**: Controls memory ownership and access between CPU1 and CPU2
- **Phase-Locked Loop (PLL)**: Configures system clock frequencies and sources
- **CPU System (Cpusys)**: Manages CPU-specific settings and peripheral clock gating
- **External Memory Interface (EMIF1)**: Configures external memory access
- **System Identification (Uidreg)**: Provides device identification and unique identifiers

## 2. Boot Sequence and Initialization Flow

The boot sequence follows a carefully orchestrated process to ensure proper system initialization:

### 2.1 CPU1 Boot Sequence

1. **Pre-Initialization (`init_sys_cpu1_0`)**: 
   - Disables interrupts
   - Initializes system PLL for clock configuration
   
2. **Main Initialization (`init_sys_cpu1`)**: 
   - Initializes external memory interface (EMIF1)
   - Configures global shared RAM ownership (GSRAM)
   - Wipes memory to ensure clean state
   
3. **Post-Initialization (`post_init_sys_cpu1`)**: 
   - Sets system unique identifier
   - Enables peripheral clocks
   - Applies analog subsystem calibration if needed
   - Configures EMIF1 ownership (CPU1 or CPU2)
   - Resets IPC flags
   - Boots CPU2 if in dual-core mode
   - Initializes flash wait states
   - Configures interrupt controllers

### 2.2 CPU2 Boot Sequence

1. **Pre-Initialization (`init_sys_cpu2_0`)**: 
   - Wipes CPU2 memory
   - Resets IPC flags
   - Waits for unlock signal from CPU1
   
2. **Main Initialization (`init_sys_cpu2`)**: 
   - Checks EMIF1 configuration
   - Grabs EMIF1 for CPU2 if needed
   - Locks access protection settings
   
3. **Post-Initialization (`post_init_sys_cpu2`)**: 
   - Initializes interrupt controllers
   - Configures flash wait states

### 2.3 Bootloader Mode Initialization

For bootloader operation, a specialized initialization sequence is used:

1. **Bootloader Pre-Initialization (`init_sys_cpu1_bldr`)**: 
   - Configures system PLL
   - Holds CPU2 in reset state
   - Configures GSRAM for CPU1 use
   
2. **Bootloader Post-Initialization (`post_init_sys_cpu1_bldr`)**: 
   - Sets system unique identifier
   - Initializes flash wait states
   - Configures interrupt controllers

## 3. Clock Configuration System

The clock configuration system is a critical component that establishes the operating frequencies for the CPU and peripherals.

### 3.1 PLL Configuration

The system uses Phase-Locked Loops (PLLs) to generate stable clock signals:

#### 3.1.1 System PLL (`pll_sys_init`)

```cpp
void PLL::pll_sys_init() {
    // Default configuration for DSP2837x
    pll_sys_init(xtal_osc, imult_020, fmult_0, pllclk_by_02);
}
```

This configures:
- Clock source: External crystal oscillator
- Integer multiplier: 20x
- Fractional multiplier: 0
- Output divider: Divide by 2

The detailed implementation includes:
1. Clock source selection (internal oscillator, external crystal)
2. PLL bypass during configuration
3. PLL multiplier setting
4. Lock detection and stabilization
5. Output divider configuration
6. Watchdog monitoring during configuration

#### 3.1.2 Auxiliary PLL (`pll_aux_init`)

```cpp
void PLL::pll_aux_init() {
    // Set USB clock to 60MHz
    pll_aux_init(xtal_osc, imult_012, fmult_0, auxpllrawclk_by_4);
}
```

This configures:
- Clock source: External crystal oscillator
- Integer multiplier: 12x
- Fractional multiplier: 0
- Output divider: Divide by 4

The auxiliary PLL configuration includes additional verification using Timer2 to ensure proper operation.

### 3.2 Peripheral Clock Control

The `Cpusys` class manages peripheral clock gating through the `PCLKCR` registers:

```cpp
void Cpusys::clk_enable(Peripheral p) {
    asm_eallow();
    regs.pclkcr.v[get_clk_reg_idx(p)] |= get_clk_dev(p);
    asm_edis();
}
```

This enables selective activation of peripheral clocks to minimize power consumption. Peripherals include:
- EMIF (External Memory Interface)
- PWM modules
- Communication interfaces (SCI, SPI, I2C, CAN)
- Analog modules (ADC, DAC)
- Timer modules

### 3.3 Clock Divider Configuration

The `Clkcfgb` class manages clock divider settings for specific peripherals:

```cpp
void Clkcfgb::set_emif1_clk_div_sel(Emif1_clk_div_sel sel) {
    asm_eallow();
    regs.PERCLKDIVSEL.bit.EMIF1CLKDIV = sel;
    asm_edis();
}
```

This allows fine-tuning of clock frequencies for peripherals like EMIF1 and PWM modules.

## 4. Memory Management and Configuration

The memory management system controls how memory resources are allocated between CPU1 and CPU2.

### 4.1 Global Shared RAM (GSRAM) Configuration

The `Memcfg` class manages ownership of global shared memory blocks:

```cpp
void Memcfg::gsram_msel_set(Uint16 value) {
    // Configure ownership of GSRAM blocks
    // 0 = CPU1 ownership, 1 = CPU2 ownership
    while(regs.GSxMSEL.all != value) {
        asm_eallow();
        regs.GSxMSEL.all = value;
        asm_edis();
    }
}
```

This function configures which CPU has ownership of each GSRAM block. During initialization, CPU1 typically claims all GSRAM blocks (`gsram_msel_set(0)`) before selectively assigning blocks to CPU2 if needed.

### 4.2 Memory Initialization

Both CPU1 and CPU2 perform memory wiping during initialization:

```cpp
void wipe_memory_c1(const Base::Mblock<const Base::Mem_range> mem_ranges);
void wipe_memory_c2();
```

These functions ensure that memory starts in a clean, known state before program execution begins.

### 4.3 External Memory Interface (EMIF1)

The system supports external memory through the EMIF1 interface:

```cpp
void init_emif1(System::Ext_mem_size size) {
    // Reset EMIF1 module
    Devcfg dc;
    dc.soft_reset(Devcfg::spr_emif1);
    
    // Configure CPU ownership
    Emif1 em1;
    em1.cpu1_grab();
    
    // Enable clock
    Cpusys cs;
    cs.clk_enable(Cpusys::clk_emif1);
    
    // Configure clock divider
    Clkcfgb ccfgb;
    ccfgb.set_emif1_clk_div_sel(Clkcfgb::emif1_div_by_1);
    
    // Configure GPIO pins for EMIF1
    switch(size) {
        case System::mem_1MW:
            setup_emif1_pinmux_async_16bit_20_21_addr(gpio_092, GPIOmux16::mux_3, gpio_091);
            break;
        case System::mem_2MW:
            setup_emif1_pinmux_async_16bit_20_21_addr(gpio_094, GPIOmux16::mux_9, gpio_092);
            break;
        // ...
    }
    
    // Configure timing parameters
    em1.set_async_cs2_cr_veronte4();
}
```

This configures:
1. EMIF1 module reset
2. CPU ownership (CPU1 or CPU2)
3. Clock enabling and divider settings
4. GPIO pin multiplexing for address and data lines
5. Memory timing parameters

## 5. Device Configuration and CPU Control

The `Devcfg` class manages device-level configuration and CPU control.

### 5.1 CPU2 Control

CPU1 can control the state of CPU2:

```cpp
void Devcfg::cpu2_hold_reset() {
    static const Uint32 varCPU2_reset_hold = 0xA5A50001UL;
    volatile Registers& regs(Hregmap::get<Registers, devcfg_regs_addr>());
    
    asm_eallow();
    regs.CPU2RESCTL.all = varCPU2_reset_hold;
    asm_edis();
    
    while(regs.RSTSTAT.bit.CPU2RES != 0) {
        // Wait for reset
    }
}

void Devcfg::cpu2_reset_deactivate() {
    static const Uint32 varCPU2_deactivate_reset = 0xA5A50000UL;
    volatile Registers& regs(Hregmap::get<Registers, devcfg_regs_addr>());
    
    asm_eallow();
    regs.CPU2RESCTL.all = varCPU2_deactivate_reset;
    asm_edis();
}
```

These functions allow CPU1 to hold CPU2 in reset state or release it to begin execution.

### 5.2 Peripheral Ownership

The `Devcfg` class manages peripheral ownership between CPU1 and CPU2:

```cpp
void Devcfg::set_cpu1_ownership(Cpusel_dev c_dev, Uint16 dev_bits) {
    volatile Uint32& cpusel = regs.cpusel[c_dev];
    asm_eallow();
    cpusel &= ~dev_bits; // Sets ownership to CPU1
    asm_edis();
}

void Devcfg::set_cpu2_ownership(Cpusel_dev c_dev, Uint16 dev_bits) {
    volatile Uint32& cpusel = regs.cpusel[c_dev];
    asm_eallow();
    cpusel |= dev_bits; // Sets ownership to CPU2
    asm_edis();
}
```

These functions configure which CPU has access to specific peripherals, such as:
- PWM modules
- ECAP modules
- EQEP modules
- Communication interfaces (SCI, SPI, I2C, CAN)
- ADC modules

### 5.3 Peripheral Reset Control

The `Devcfg` class provides soft reset capability for peripherals:

```cpp
void Devcfg::soft_reset(Sprid spr) {
    volatile Uint16& softpres = regs.softpres[spr >> Ku16::u16];
    const Uint16 msk = spr & Ku32::u0xFFFF;
    
    asm_eallow();
    softpres |= msk;      // Assert reset
    asm_nop();            // Wait for reset to take effect
    asm_nop();
    asm_nop();
    asm_nop();
    softpres &= (~msk);   // Release reset
    asm_edis();
}
```

This allows controlled reset of specific peripherals without affecting the entire system.

## 6. System Identification

The system provides mechanisms to identify the device and retrieve unique identifiers.

### 6.1 Device Identification

The `Devcfg` class provides access to device identification registers:

```cpp
Uint32 Devcfg::get_partid_h() const {
    return regs.PARTIDH.all;
}

Uint32 Devcfg::get_partid_l() const {
    return regs.PARTIDL.all;
}

Uint32 Devcfg::get_revid() const {
    return regs.REVID;
}
```

These functions retrieve the part ID and revision ID of the device.

### 6.2 Unique Identifier

The `Uidreg` class provides access to a unique identifier stored in OTP memory:

```cpp
Uidreg::Uidreg() :
    partidh(Devcfg().get_partid_h()),
    partidl(Devcfg().get_partid_l()),
    revid(Devcfg().get_revid()),
    uidotp(reg_uid.read())
{
    // Validate UID using Fletcher-32 checksum
    Uint32 sum1=0;
    Uint32 sum2=0;
    
    for(Uint16 i=0; i< (otp_sz-Ku16::u2); ++i) {
        sum1 = sum1 + otp_block->block[i];
        sum2 = (sum2 + sum1) % 0xFFFF;
        sum1 = sum1 % 0xFFFF;
    }
    
    uidvalid = (otp_block->block[Ku16::u14]==sum1&0xFFFF) && 
               (otp_block->block[Ku16::u15]==sum2&0xFFFF);
}
```

This constructor reads the device part ID, revision ID, and a unique identifier from OTP memory, then validates the identifier using a Fletcher-32 checksum.

## 7. Inter-Processor Communication (IPC)

The system uses IPC mechanisms to coordinate between CPU1 and CPU2.

### 7.1 CPU2 Boot Process

CPU1 initiates the CPU2 boot process:

```cpp
// In post_init_sys_cpu1
if((!cs.is_jtag_connected()) || cs.is_reset_wdog_flag() || (!Devcfg::is_cpu2_running())) {
    cs.clear_reset_wdog_flag();
    if(is_dual_core) {
        // Send boot command to allow the CPU2 application to begin execution
        Ipc::cpu1_boot_cpu2();
    }
}

// If dual-core mode, unlock CPU2 to continue execution
if(is_dual_core) {
    Ipc::cpu2_unlock();
}
```

CPU2 waits for the unlock signal from CPU1:

```cpp
// In init_sys_cpu2_0
Ipc::reset_flags();
Ipc::cpu2_wait_for_unlock();
```

This coordination ensures that CPU1 completes necessary system initialization before CPU2 begins execution.

## 8. Dual-Core Operation Differences

The initialization sequence differs significantly between CPU1 and CPU2:

### 8.1 CPU1-Specific Initialization

- PLL configuration
- Device configuration
- Memory ownership setup
- External memory interface configuration
- CPU2 control (reset/release)
- System-wide peripheral initialization

### 8.2 CPU2-Specific Initialization

- Memory wiping
- IPC flag handling
- EMIF1 configuration (if assigned to CPU2)
- Local peripheral initialization

### 8.3 Coordination Between Cores

1. CPU1 initializes system-wide components
2. CPU1 holds CPU2 in reset during critical initialization
3. CPU1 releases CPU2 from reset
4. CPU2 waits for unlock signal from CPU1
5. CPU1 sends unlock signal when system is ready
6. CPU2 begins normal execution

## 9. System Reset and Bootloader Mode

### 9.1 System Reset

The `System::cpu_reset()` function provides a mechanism to reset the entire system:

```cpp
void System::cpu_reset() {
    while(true) {
        Watchdog::setup_for_reset();
    }
}
```

This triggers a watchdog reset, which will restart the entire system.

### 9.2 Bootloader Mode

The system can enter bootloader mode under specific conditions:

```cpp
bool System::force_bootloader_mode() {
    // Implementation not provided in the code
    // Returns true if "force bootloader" has been set
}

bool Bsp::get_force_bootloader() {
    return (Dsp28335_ent::Ipc::get_command() == bldr_force_bldr_cmd);
}
```

The bootloader mode uses a specialized initialization sequence (`init_sys_cpu1_bldr` and `post_init_sys_cpu1_bldr`) that configures only essential components needed for the bootloader operation.

## 10. Relationship Between Configuration Components

The system configuration components work together in a hierarchical manner:

1. **Device Configuration (Devcfg)**
   - Controls CPU2 reset state
   - Manages peripheral ownership
   - Provides device identification

2. **PLL Configuration (PLL)**
   - Configures system clock sources and frequencies
   - Depends on device configuration for proper operation

3. **CPU System Configuration (Cpusys)**
   - Controls peripheral clock gating
   - Depends on PLL configuration for clock sources

4. **Memory Configuration (Memcfg)**
   - Manages memory ownership between CPUs
   - Depends on device configuration for proper operation

5. **External Memory Interface (EMIF1)**
   - Configures external memory access
   - Depends on CPU system configuration for clock settings
   - Depends on device configuration for ownership settings

6. **System Initialization**
   - Orchestrates the initialization sequence
   - Coordinates between all configuration components

This hierarchical relationship ensures that components are initialized in the correct order, with dependencies satisfied before dependent components are configured.

## Conclusion

The DSP28335 microcontroller's system configuration and initialization components provide a comprehensive framework for establishing a working system environment. The boot sequence carefully orchestrates the initialization of various components, with CPU1 handling most of the system-wide configuration before CPU2 becomes operational.

The clock configuration system provides flexible control over system frequencies, while the memory management system enables efficient allocation of resources between the two CPU cores. The device configuration system provides fine-grained control over peripheral ownership and operation, and the system identification components enable unique identification of each device.

In dual-core operation, the coordination between CPU1 and CPU2 ensures proper system initialization and operation, with clear separation of responsibilities between the cores. The bootloader mode provides a specialized initialization sequence for firmware updates and system recovery.

Overall, the system configuration and initialization components form a robust foundation for applications running on the DSP28335 microcontroller, enabling efficient use of the device's capabilities while maintaining system stability and reliability.