# Generated from:

- code/include/Pwmdev.h (2666 tokens)
- code/include/Piectrl.h (1177 tokens)
- code/source/common/Pwmdev.cpp (5026 tokens)
- code/source/common/Pwmdev_2837x.cpp (371 tokens)
- code/source/common/Pwmdev_mc_28377.cpp (2285 tokens)
- code/source/common/Piectrl.cpp (1454 tokens)
- code/source/common/Timer_2837x.cpp (501 tokens)
- code/source/common/ECAP_2837x.cpp (298 tokens)
- code/source/cpu1/ECAP_ioctl_2837x.cpp (1236 tokens)

## With context from:

- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/DSP2837x_ent/06_Hardware_Abstraction_Layer.md (4115 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/DSP2837x_ent/05_System_Configuration.md (4236 tokens)

---

# PWM and Timing Control Subsystem for DSP28335 Microcontroller

This comprehensive summary details the Pulse Width Modulation (PWM) subsystem and timing control mechanisms for the DSP28335 microcontroller, focusing on architecture, configuration, and operational behaviors.

## 1. PWM Subsystem Architecture

### 1.1 PWM Module Organization

The DSP28335 microcontroller features an extensive PWM subsystem with the following organization:

- **Total PWM Channels**: Up to 32 PWM outputs (`Pwmdev::nb_pwms`)
- **PWM Modules**: Up to 16 modules (`Pwmdev::nb_mods`), each containing two channels (A and B)
- **Channel Pairing**: Each module contains two PWM channels (e.g., EPWM1 has channels 1A and 1B)
- **Enumeration**: PWM channels are enumerated from `epwm1` (0) to `epwm32` (31)

```cpp
enum PWMid {
    epwm1   =  0,    // 1a
    epwm2   =  1,    // 1b
    epwm3   =  2,    // 2a
    epwm4   =  3,    // 2b
    // ... continues to epwm32 (31)
};
```

### 1.2 Register Structure

Each PWM module contains a comprehensive set of registers for configuration and control:

- **Time Base Control**: `TBCTL`, `TBPRD`, `TBPHS`, `TBCTR` registers control timing parameters
- **Compare Units**: `CMPA`, `CMPB` registers determine duty cycle
- **Action Qualifiers**: `AQCTLA`, `AQCTLB` registers define output actions
- **Dead Band Generator**: `DBCTL`, `DBRED`, `DBFED` registers control dead time insertion
- **Trip Zone Control**: `TZCTL`, `TZSEL`, `TZFLG` registers manage protection features
- **Event Trigger**: `ETSEL`, `ETPS`, `ETFLG` registers control event generation

## 2. PWM Configuration and Operation

### 2.1 PWM Initialization

The PWM subsystem requires initialization before individual modules can be configured:

```cpp
void Pwmdev::init_all() {
    // Configure EPWM clock divisor
    Clkcfgb ccb;
    ccb.set_pwm_clk_div_sel(Clkcfgb::pwm_div_by_2);
}
```

This sets the global clock divisor for all PWM modules, typically dividing the system clock by 2 to establish the base PWM clock.

### 2.2 Individual PWM Configuration

Each PWM channel is configured through a multi-step process:

1. **Module Frequency Setting**:
   ```cpp
   void Pwmdev::set_module_freq(Uint16 freq) {
       // Sets frequency for both A and B channels in a module
       // Calculates appropriate clock dividers and period values
   }
   ```

   This method configures the time base for a PWM module by:
   - Calculating appropriate `CLKDIV` and `HSPCLKDIV` values
   - Setting the period register (`TBPRD`)
   - Configuring the counter mode (up, down, or up-down)

2. **PWM Configuration Structure**:
   ```cpp
   struct Config {
       bool active_high;  // If FALSE PWM is active low, otherwise active high
       Rmode rmod;        // Range mode (us or duty)
       Real cfg_low;      // Configured minimum value
       Real cfg_high;     // Configured maximum value
   };
   ```

3. **Applying Configuration**:
   ```cpp
   void Pwmdev::config(const Config& cfg) {
       // Stores configuration parameters
       // Computes dependent configuration values
       // Applies settings to hardware registers
   }
   ```

   This method configures:
   - Output polarity (active high or low)
   - Range mode (microseconds or duty cycle)
   - Minimum and maximum output values
   - Shadow register loading behavior

### 2.3 PWM Output Control

Once configured, PWM outputs can be controlled through several methods:

1. **Setting PWM Value**:
   ```cpp
   void Pwmdev::set(Real value) {
       // Sets PWM with normalized (0 to 1) value
       // Converts normalized value to appropriate compare register value
   }
   ```

   This method:
   - Clamps input value between 0.0 and 1.0
   - Converts normalized value to appropriate compare register value based on configuration
   - Updates the compare register (CMPA or CMPB)

2. **Enabling/Disabling PWM**:
   ```cpp
   void Pwmdev::set_enabled(bool en0) {
       // Enables or disables PWM output
       // When disabled, sets compare value to 0
   }
   ```

3. **Retrieving PWM Status**:
   ```cpp
   bool Pwmdev::get_enabled() const;
   Real Pwmdev::get_frequency() const;
   ```

   These methods provide feedback on the current PWM state and configuration.

### 2.4 PWM Value Calculation

The PWM subsystem converts between normalized values (0.0-1.0) and hardware register values:

```cpp
Uint16 Pwmdev::denormalize(Real a) const {
    return static_cast<Uint16>(static_cast<Real>((pmax-pmin))*a + static_cast<Real>(pmin));
}
```

This conversion depends on the configured range mode:
- **Microseconds Mode**: Converts time in microseconds to counter values
- **Duty Cycle Mode**: Converts duty cycle (0.0-1.0) directly to counter values

## 3. Advanced PWM Features

### 3.1 PWM Synchronization

The PWM modules support synchronization for coordinated operation:

```cpp
void Pwmdev::synchronize_with(Uint8 sync_source) {
    regs.TBCTL.bit.PHSEN = TBCTL_BITS::phsen_enable;
    regs.EPWMSYNCINSEL.SEL = sync_source;
}
```

This enables phase synchronization between PWM modules, with one module acting as master and others as slaves.

### 3.2 Trip Zone Protection

The PWM subsystem includes comprehensive trip zone protection features:

```cpp
enum Tzctl {
    tzctl_hi_z     = 0,  // High impedance
    tzctl_force_hi = 1,  // Force high state
    tzctl_force_lo = 2,  // Force low state
    tzctl_nothing  = 3   // Do nothing
};

enum Trip_mode {
    cbc1,    // TZ1 CBC select
    // ... other trip sources
    dcbevt1  // One-shot DCBEVT1 select
};

void Pwmdev_mc::enable_trip_zone(Trip_mode mode, Tzctl ctl, bool enable) {
    // Enables selected trip zone mode with specified action
}

bool Pwmdev::is_ost_latched() const {
    return regs.TZFLG.bit.OST;  // Check if one-shot trip has occurred
}
```

Trip zones provide hardware protection by forcing PWM outputs to predefined states when fault conditions occur. The system supports:
- **Cycle-by-cycle (CBC) trip**: Affects single PWM cycles
- **One-shot trip (OST)**: Latches the PWM in safe state until cleared
- **Digital compare trip**: Triggers based on digital compare events

### 3.3 Motor Control Extensions

The `Pwmdev_mc` class extends basic PWM functionality with features specifically for motor control:

```cpp
void Pwmdev_mc::mc_init(Real pwm_freq,
                        bool master,
                        const Real deadband,
                        const Uint16 adc_div,
                        bool int_on_high);
```

This specialized initialization:
- Configures up-down counting mode for center-aligned PWM
- Sets up complementary outputs for half-bridge control
- Configures dead band generation to prevent shoot-through
- Establishes synchronization between modules
- Sets up ADC triggering for synchronized sampling

### 3.4 Phase Shift Control

For multi-phase applications, phase shifting between PWM modules is supported:

```cpp
void Pwmdev_mc::set_phase_shift(Uint16 degrees) {
    // Calculates phase shift value based on degrees (0-359)
    // Updates TBPHS register to implement phase shift
}
```

This enables precise phase control for multi-phase motor drives and power converters.

## 4. Timing Control Mechanisms

### 4.1 Peripheral Interrupt Expansion (PIE) Control

The DSP28335 uses a Peripheral Interrupt Expansion (PIE) controller to manage interrupts from peripherals:

```cpp
struct Piectrl {
    enum Group {
        grp01 =  0,  // Group 1
        // ... other groups
        grp12 = 11   // Group 12
    };

    enum Flag {
        flag_int01 = 0x0001U,  // Integer flag 1
        // ... other flags
        flag_int16 = 0x8000U   // Integer flag 16
    };

    struct Mid {
        Group grp;  // Group to which the interrupt belongs
        Flag  flg;  // Flag representing the interrupt ID
    };
};
```

The PIE controller:
- Organizes interrupts into 12 groups
- Provides individual enable/disable control for each interrupt
- Supports interrupt acknowledgment and flag clearing
- Enables prioritization of interrupts

Key PIE control functions:
```cpp
static void Piectrl::init();              // Initialize PIE control registers
static void Piectrl::enable_pie();        // Enable PIE vector table
static void Piectrl::disable_pie();       // Disable PIE vector table
static void Piectrl::enable(Mid id);      // Enable specific interrupt
static void Piectrl::disable(Mid id);     // Disable specific interrupt
static void Piectrl::ack(Group grp0);     // Acknowledge interrupt group
static void Piectrl::clear_isr_flag(Mid id); // Clear specific interrupt flag
```

### 4.2 PWM Event Triggering

PWM modules can generate events for timing control:

```cpp
// In Pwmdev_mc::mc_init:
regs.ETSEL.bit.SOCAEN  = master;     // Enable SOCA event
regs.ETSEL.bit.SOCASEL = soc_event;  // Select event trigger point
regs.ETPS.bit.SOCPSSEL = 1;          // Use divider
regs.ETSOCPS.bit.SOCAPRD2 = adc_div; // Set event frequency divider
```

These events can:
- Trigger ADC conversions at precise points in the PWM cycle
- Generate interrupts for synchronized processing
- Coordinate actions between multiple peripherals

### 4.3 Enhanced Capture (ECAP) Module

The Enhanced Capture (ECAP) module provides precise timing measurement capabilities:

```cpp
class ECAP {
public:
    static const Uint16 num_ecaps_2837x = 6;  // Number of ECAP modules
    
    enum Id {
        ecap1 = 0,
        // ... other ECAP IDs
    };
    
    static volatile ECAP_regs& get_regs(Id ecap_id);
};
```

The ECAP module:
- Captures time stamps of external events
- Measures pulse widths and periods
- Supports up to 4 capture events
- Can operate in absolute or differential mode

ECAP configuration:
```cpp
void ECAP_ioctl::config(ECAP& ecap, const ECAPcfg& cfg) {
    // Configure GPIO for ECAP input
    // Enable ECAP clock
    // Configure capture mode, events, and triggers
}
```

This configuration:
- Connects a GPIO pin to the ECAP module via the GPIO crossbar
- Sets up capture event polarity (rising/falling edge)
- Configures absolute or differential operation
- Establishes event wrapping behavior

## 5. PWM and Timer Integration

### 5.1 Timer-Based Interrupts

The DSP28335 includes CPU timers that can be used for periodic interrupts:

```cpp
void Timer::pie_enable(Id id0, Isrptr p_isr) {
    switch (id0) {
        case timer0:
            Piectrl::enable_pie();
            ISRmgr::set_isr(ISRmgr::timer0_int, p_isr);
            static const Piectrl::Mid mid_tmr0 = { Piectrl::grp01, Piectrl::flag_int07 };
            Piectrl::enable(mid_tmr0);
            break;
        // ... cases for timer1 and timer2
    }
}
```

These timers provide:
- Periodic interrupt generation
- Background timing for non-critical tasks
- System tick functionality for scheduling

### 5.2 PWM-Based Interrupts

PWM modules can generate interrupts at specific points in their cycles:

```cpp
void Pwmdev_mc::enable_isr(Isrptr func) {
    Piectrl::enable_pie();      // Ensure PIE is enabled
    ISRmgr::set_isr(ISRmgr::epwm1_int, func);
    clear_irq_flags();
    Piectrl::enable(mid_pwm);
}

void Pwmdev_mc::irq_ack() {
    Piectrl::ack(mid_pwm.grp);
}

void Pwmdev_mc::clear_irq_flags() {
    irq_ack();
    Piectrl::clear_isr_flag(mid_pwm);
    regs.ETCLR.all = 0xF; // Clear all flags
}
```

These interrupts enable:
- Synchronized processing with PWM cycles
- Precise timing for control algorithms
- Coordinated multi-phase control

## 6. Cross-Component Relationships

### 6.1 PWM and ADC Synchronization

The PWM modules can trigger ADC conversions at precise points in the PWM cycle:

```cpp
// In Pwmdev_mc::mc_init:
regs.ETSEL.bit.SOCAEN  = master;     // Enable SOCA event
regs.ETSEL.bit.SOCASEL = soc_event;  // Select event trigger point
```

This synchronization enables:
- Phase-current sampling at optimal points
- Synchronized voltage measurements
- Precise control timing for motor drives and power converters

### 6.2 PWM and GPIO Integration

PWM outputs are routed through the GPIO system:

```cpp
// In ECAP_ioctl::config:
bool config_gpio(const ECAP::Id ecap_id, const Uint16 gpio_id) {
    bool result = is_gpioid_valid(gpio_id);
    if(result) {
        const GPIOxbar_in::Id xbar_id = static_cast<GPIOxbar_in::Id>(ecap_id + GPIOxbar_in::id_ecap1);
        GPIOxbar_in::apply(static_cast<GPIOid>(gpio_id), xbar_id);
    }
    return result;
}
```

This flexible routing allows:
- Assignment of PWM functions to different pins
- Multiplexing of peripheral functions
- Configuration of input capture sources

### 6.3 PWM and Clock System Integration

The PWM timing is derived from the system clock through configurable dividers:

```cpp
// In Pwmdev::init_all:
Clkcfgb ccb;
ccb.set_pwm_clk_div_sel(Clkcfgb::pwm_div_by_2);

// In Pwmdev::set_module_freq:
const Real pwm_clk = Bsp::Kclk::get_sysclkfreq_r32()/2.0F;
```

This clock hierarchy ensures:
- Consistent timing across all PWM modules
- Configurable frequency ranges
- Synchronization with the overall system timing

## 7. Detailed PWM Configuration Process

### 7.1 Frequency Configuration

The PWM frequency configuration involves several steps:

1. **Clock Divider Selection**:
   ```cpp
   // Find appropriate CLKDIV value
   while((clk_div<7) && (lowest_freq>static_cast<Real>(freq))) {
       div<<=1;
       clk_div++;
       lowest_freq=base_freq/static_cast<Real>(div);
   }
   
   // Find appropriate HSPCLKDIV value
   while((hspclk_div<7) && (lowest_freq>static_cast<Real>(freq))) {
       div+=2;
       hspclk_div++;
       lowest_freq = base_freq/static_cast<Real>(div);
   }
   ```

2. **Period Register Calculation**:
   ```cpp
   Uint16 tbprd = static_cast<Uint16>((0xFFFF*lowest_freq)/static_cast<Real>(freq));
   ```

3. **Register Configuration**:
   ```cpp
   regs.TBPRD = tbprd;
   regs.TBCTL.bit.HSPCLKDIV = hspclk_div;
   regs.TBCTL.bit.CLKDIV = clk_div;
   ```

This process ensures:
- Optimal divider selection for the requested frequency
- Maximum resolution within hardware constraints
- Accurate frequency generation

### 7.2 Duty Cycle Control

The duty cycle control process involves:

1. **Range Configuration**:
   ```cpp
   void Pwmdev::compute_dep_cfg() {
       switch(cfg.rmod) {
           case us:
               // Calculate pmin/pmax based on microseconds
               Real periode_us = Const::ONE_MILLION/static_cast<Real>(freq);
               pmin = static_cast<Uint32>((cfg.cfg_low * static_cast<Real>(regs.TBPRD)) / periode_us);
               pmax = static_cast<Uint32>((cfg.cfg_high * static_cast<Real>(regs.TBPRD)) / periode_us);
               break;
           case duty:
               // Calculate pmin/pmax based on duty cycle
               pmin = static_cast<Uint32>(cfg.cfg_low * static_cast<Real>(regs.TBPRD));
               pmax = static_cast<Uint32>(cfg.cfg_high * static_cast<Real>(regs.TBPRD));
               break;
       }
   }
   ```

2. **Value Normalization**:
   ```cpp
   Uint16 Pwmdev::denormalize(Real a) const {
       return static_cast<Uint16>(static_cast<Real>((pmax-pmin))*a + static_cast<Real>(pmin));
   }
   ```

3. **Compare Register Update**:
   ```cpp
   void Pwmdev::write_cmp(Uint16 regvalue) {
       if(is_portA()) {
           regs.CMPA.bit.CMPA = regvalue;
       } else {
           regs.CMPB.bit.CMPB = regvalue;
       }
   }
   ```

This process ensures:
- Accurate conversion between normalized values and hardware registers
- Support for both microsecond and duty cycle specifications
- Proper handling of A and B channels

### 7.3 Output Action Configuration

The PWM output actions are configured based on the active polarity:

```cpp
void Pwmdev::apply_settings() {
    if(is_portA()) {
        regs.CMPCTL.bit.SHDWAMODE = CMPCTL_BITS::shdwmode_shadow;
        regs.CMPCTL.bit.LOADAMODE = CMPCTL_BITS::loadmode_ctr_zero;
        
        regs.AQCTLA.bit.ZRO = (cfg.active_high==0) ? AQCTLAB_BITS::aq_clear : AQCTLAB_BITS::aq_set;
        regs.AQCTLA.bit.CAU = (cfg.active_high==0) ? AQCTLAB_BITS::aq_set : AQCTLAB_BITS::aq_clear;
    } else {
        regs.CMPCTL.bit.SHDWBMODE = CMPCTL_BITS::shdwmode_shadow;
        regs.CMPCTL.bit.LOADBMODE = CMPCTL_BITS::loadmode_ctr_zero;
        
        regs.AQCTLB.bit.ZRO = (cfg.active_high==0) ? AQCTLAB_BITS::aq_clear : AQCTLAB_BITS::aq_set;
        regs.AQCTLB.bit.CBU = (cfg.active_high==0) ? AQCTLAB_BITS::aq_set : AQCTLAB_BITS::aq_clear;
    }
}
```

This configuration:
- Sets up shadow register behavior for smooth transitions
- Configures when compare values are loaded
- Sets appropriate actions at zero and compare-up events
- Handles active-high and active-low polarity

## 8. Motor Control PWM Configuration

### 8.1 Complementary PWM Setup

For motor control applications, complementary PWM outputs with dead time are configured:

```cpp
void Pwmdev_mc::mc_init(Real pwm_freq, bool master, const Real deadband, const Uint16 adc_div, bool int_on_high) {
    // Configure up-down counting for center-aligned PWM
    regs.TBCTL.bit.CTRMODE = TBCTL_BITS::ctrmode_count_updown;
    
    // Configure action qualifiers for complementary outputs
    regs.AQCTLA.bit.CAD = AQCTLAB_BITS::aq_set;
    regs.AQCTLA.bit.CAU = AQCTLAB_BITS::aq_clear;
    
    // Configure dead band generation
    if(deadband > 0.0F) {
        regs.DBCTL.bit.OUT_MODE = DBCTL_BITS::dbout_db_full_enable;
    } else {
        regs.DBCTL.bit.OUT_MODE = DBCTL_BITS::dbout_db_disable;
    }
    regs.DBCTL.bit.POLSEL = DBCTL_BITS::dbactv_hic;
    
    // Calculate and set dead band time
    const Uint16 deadband_tics = Rmath::ceilr(static_cast<Uint16>(deadband * pwm_clk));
    regs.DBFED.all = deadband_tics;
    regs.DBRED.all = deadband_tics;
    
    // Configure trip zone behavior
    regs.TZCTL.bit.TZA = tzctl_hi_z;
    regs.TZCTL.bit.TZB = tzctl_hi_z;
    
    // Set period for up-down counting (doubled for same frequency)
    const Uint32 prd = pwm_clk / (pwm_freq*2);
    regs.TBPRD = prd;
}
```

This configuration:
- Uses up-down counting for center-aligned PWM (better for motor control)
- Sets up complementary outputs (one high when the other is low)
- Configures dead band insertion to prevent shoot-through
- Sets up trip zone protection for fault handling
- Adjusts period calculation for up-down counting mode

### 8.2 ADC Synchronization

For synchronized current sampling in motor control:

```cpp
// In Pwmdev_mc::mc_init:
const Uint16 soc_event = int_on_high ? 1 : 2;  // 1=middle of high, 2=middle of low
regs.ETSEL.bit.SOCAEN = master;                // Enable SOCA on master
regs.ETSEL.bit.SOCASEL = soc_event;            // Select trigger point
regs.ETCLR.bit.SOCA = 1;                       // Clear SOCA flag

// Configure SOCA event period
regs.ETPS.bit.SOCPSSEL = 1;                    // Use divider
regs.ETSOCPS.bit.SOCAPRD2 = adc_div;           // Set divider value
```

This configuration:
- Triggers ADC conversions at optimal points in the PWM cycle
- Allows sampling in the middle of PWM on or off time
- Provides divider capability for reduced sampling rates
- Synchronizes ADC sampling with PWM switching events

### 8.3 Multi-PWM Synchronization

For coordinated multi-phase operation:

```cpp
// In Pwmdev_mc::mc_init:
// Sync: Master, no sync, slave: synchronized
regs.TBCTL.bit.PHSEN = master ? TBCTL_BITS::phsen_disable : TBCTL_BITS::phsen_enable;

// Setup sync output (master)/input(slaves)
regs.TBCTL.bit.SYNCOUTSEL = master ? TBCTL_BITS::syncosel_ctr_zero : TBCTL_BITS::syncosel_sync_in;

// For 2838X, enable the Zero trigger
regs.EPWMSYNCOUTEN.bit.ZEROEN = master;

static const Uint8 ext_sync1_in_pwm1 = 0x1;  // PWM1 sync out
regs.EPWMSYNCINSEL.SEL = ext_sync1_in_pwm1;  // SYNCINSEL == pwm1
```

This configuration:
- Designates one PWM module as master and others as slaves
- Configures master to generate synchronization signals
- Configures slaves to receive synchronization signals
- Enables phase shifting between synchronized modules

## 9. Enhanced Capture (ECAP) Configuration

### 9.1 ECAP Module Setup

The Enhanced Capture module is configured for timing measurement:

```cpp
void ECAP_ioctl::config(ECAP& ecap, const ECAPcfg& cfg) {
    // Enable or disable ECAP clock
    bool enable = cfg.en;
    
    if(enable) {
        enable = config_gpio(ecap.id, cfg.gpio_id);
        Base::Assertions::runtime(enable);
    }
    
    // Enable clock for this ECAP
    Cpusys cs;
    cs.clk_enable_set(Cpusys::clk_ecap, static_cast<Uint8>(ecap.id), enable);
    
    if(enable) {
        // Configure capture events
        ecap.events.resize(cfg.wrap+1);
        for(Uint16 i=0; i<ecap.events.size(); ++i) {
            ecap.events[i] = cfg.get_datatype(i);
        }
        ecap.ievt = 0; // reset counter
        
        // Configure ECAP registers
        volatile ECAP_regs& regs = ecap.regs;
        regs.ECEINT.all = 0x0000;             // Disable all capture interrupts
        regs.ECCLR.all = Ku16::u0xFFFF;       // Clear all CAP interrupt flags
        regs.ECCTL0.bit.INPUTSEL = 0x7F;      // Select 127 CAP Input
        
        // Configure capture mode
        regs.ECCTL2.bit.CAP_APWM = 0;         // Capture mode (not APWM)
        regs.ECCTL2.bit.CONT_ONESHT = 0;      // Continuous mode
        regs.ECCTL2.bit.STOP_WRAP = cfg.wrap; // Stop after "wrap" events
        
        // Configure edge detection
        regs.ECCTL1.bit.CAP1POL = cfg.triggers[Ku16::u0]; // Rising/falling edge
        regs.ECCTL1.bit.CAP2POL = cfg.triggers[Ku16::u1]; // Rising/falling edge
        regs.ECCTL1.bit.CAP3POL = cfg.triggers[Ku16::u2]; // Rising/falling edge
        regs.ECCTL1.bit.CAP4POL = cfg.triggers[Ku16::u3]; // Rising/falling edge
        
        // Configure counter reset behavior
        regs.ECCTL1.bit.CTRRST1 = !cfg.abs_mode; // Absolute/differential mode
        regs.ECCTL1.bit.CTRRST2 = !cfg.abs_mode;
        regs.ECCTL1.bit.CTRRST3 = !cfg.abs_mode;
        regs.ECCTL1.bit.CTRRST4 = !cfg.abs_mode;
        
        // Configure synchronization
        regs.ECCTL2.bit.SYNCI_EN = 0;         // Enable sync in
        regs.ECCTL2.bit.SYNCO_SEL = Ku16::u2; // Pass through
        
        // Enable capture units
        regs.ECCTL1.bit.CAPLDEN = 1;          // Enable capture units
        regs.ECCTL1.bit.PRESCALE = 0;         // No prescale
        regs.ECCTL1.bit.FREE_SOFT = Ku16::u2; // Emulation mode
        
        // Start counter
        regs.ECCTL2.bit.TSCTRSTOP = 1;        // Start Counter
    }
}
```

This configuration:
- Connects a GPIO pin to the ECAP module
- Sets up edge detection polarity for up to 4 events
- Configures absolute or differential timing mode
- Establishes event wrapping behavior
- Enables the capture units and starts the counter

### 9.2 GPIO Configuration for ECAP

The ECAP module requires GPIO configuration:

```cpp
bool config_gpio(const ECAP::Id ecap_id, const Uint16 gpio_id) {
    bool result = is_gpioid_valid(gpio_id);
    if(result) {
        // Get input XBAR ID from ECAP ID
        const GPIOxbar_in::Id xbar_id = static_cast<GPIOxbar_in::Id>(ecap_id + GPIOxbar_in::id_ecap1);
        // Connect the GPIO to the ECAP
        GPIOxbar_in::apply(static_cast<GPIOid>(gpio_id), xbar_id);
    }
    return result;
}
```

This process:
- Validates the GPIO ID
- Determines the appropriate crossbar input ID
- Connects the GPIO to the ECAP module through the crossbar

## 10. Peripheral Interrupt Expansion (PIE) Configuration

### 10.1 PIE Initialization

The PIE controller requires initialization before use:

```cpp
void Piectrl::init() {
    // Disable Interrupts at the CPU level
    asm_dint();
    
    // Construct a Piectrl instance
    Piectrl pie;
    
    // Disable the PIE
    pie.regs.ctrl.bit.enpie = 0;
    
    // Clear all PIEIER and PIEIFR registers
    Base::Tmem::set<sizeof(pie.regs.ef)>(const_cast<Pie_ef_reg*>(pie.regs.ef), 0);
    
    // Clear IER, IFR
    IER = 0;
    IFR = 0;
}
```

This process:
- Disables CPU interrupts
- Disables the PIE controller
- Clears all PIE interrupt enable and flag registers
- Clears the CPU interrupt enable and flag registers

### 10.2 Interrupt Configuration

Individual interrupts are configured through the PIE controller:

```cpp
void Piectrl::enable(Mid id) {
    // Enable the interrupt group in the CPU IER
    IER |= Base::Bitutils::get_mask_1bit<Uint16>(id.grp);
    
    // Enable the specific interrupt in the PIE
    Piectrl pie;
    pie.regs.ef[id.grp].ier |= id.flg;
}

void Piectrl::disable(Mid id) {
    // Disable the specific interrupt in the PIE
    Piectrl pie;
    pie.regs.ef[id.grp].ier &= (~id.flg);
}
```

This configuration:
- Enables/disables specific interrupts in the PIE controller
- Manages the CPU interrupt enable register (IER)
- Provides granular control over individual interrupt sources

### 10.3 Interrupt Handling

Interrupt handling involves acknowledgment and flag clearing:

```cpp
void Piectrl::ack(Group grp0) {
    // Acknowledge the interrupt group
    Piectrl pie;
    const Uint16 msk = Base::Bitutils::get_mask_1bit<Uint16>(grp0);
    pie.regs.ack |= msk;
}

void Piectrl::clear_isr_flag(Mid id) {
    // Clear the interrupt flag
    Piectrl pie;
    pie.regs.ef[id.grp].ifr = pie.regs.ef[id.grp].ifr & ~id.flg;
}
```

This process:
- Acknowledges interrupts at the group level
- Clears specific interrupt flags
- Prepares the system for subsequent interrupts

## Conclusion

The DSP28335 microcontroller provides a sophisticated PWM subsystem and timing control mechanisms that enable precise control for motor drives, power converters, and other applications requiring accurate timing. The PWM modules offer extensive configuration options, including frequency control, duty cycle management, dead time insertion, and protection features. The Enhanced Capture modules provide precise timing measurement capabilities, while the Peripheral Interrupt Expansion controller enables efficient interrupt management.

The integration between these components—PWM, ECAP, PIE, and GPIO—creates a flexible and powerful platform for implementing complex control systems. The motor control extensions to the PWM modules are particularly valuable for applications requiring precise motor control, such as robotics, industrial automation, and electric vehicles.

The comprehensive configuration options and synchronization capabilities enable sophisticated multi-phase control strategies, while the protection features ensure safe operation even under fault conditions. Overall, the PWM and timing control subsystem of the DSP28335 microcontroller provides a robust foundation for implementing high-performance control systems.