# Generated from:

- code/include/Emif1.h (1017 tokens)
- code/source/common/Emif1.cpp (5655 tokens)
- code/source/common/Emif1_2837x.cpp (244 tokens)
- code/source/common/Flash_2837x.cpp (4298 tokens)
- code/source/cpu1/Flash_wr_2837x.cpp (7657 tokens)
- code/source/cpu1/Flash_wr_2837x_cbs.cpp (423 tokens)
- code/source/cpu1/User_otp_2837x.cpp (175 tokens)
- code/cmd/2837x_FLASH_lnk_cpu_common.cmd (563 tokens)

## With context from:

- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/DSP2837x_ent/06_Hardware_Abstraction_Layer.md (4115 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/DSP2837x_ent/05_System_Configuration.md (4236 tokens)

---

# External Memory Interface (EMIF) and Flash Memory Management for DSP28335 Microcontroller

This comprehensive summary details the External Memory Interface (EMIF) and Flash memory management capabilities of the DSP28335 microcontroller, focusing on configuration, control, and programming operations.

## 1. EMIF1 Interface Architecture

The DSP28335 provides an External Memory Interface (EMIF1) for connecting to external memory devices such as RAM and Flash. The EMIF1 module is implemented through the `Emif1` class in the `Dsp28335_ent` namespace.

### 1.1 EMIF1 Register Structure

The EMIF1 peripheral uses two main register sets:
- `Emif_regs`: Core EMIF registers for timing and control
- `Emif1_config_regs`: Configuration registers for access protection and ownership

```cpp
struct Emif1 {
private:
    struct Emif_regs;            // Core EMIF registers
    struct Emif1_config_regs;    // Configuration registers
    
    volatile Emif_regs& emif1_regs;
    volatile Emif1_config_regs& emif1_cfg_regs;
};
```

### 1.2 EMIF1 Memory Mapping

The EMIF1 registers are memory-mapped at specific addresses:

```cpp
// In Emif1_2837x.cpp
static const Uint32 emif1_regs_addr = 0x047000UL;
static const Uint32 emif1_config_regs_addr = 0x05F480UL;
```

These addresses are used to access the register structures:

```cpp
volatile Emif1::Emif_regs& Emif1::get_emif1_regs() {
    return Hregmap::get<Emif_regs, emif1_regs_addr>();
}

volatile Emif1::Emif1_config_regs& Emif1::get_emif1_config_regs() {
    return Hregmap::get<Emif1_config_regs, emif1_config_regs_addr>();
}
```

## 2. EMIF1 Configuration and Control

### 2.1 Asynchronous Memory Configuration

The EMIF1 interface supports asynchronous memory access with configurable timing parameters. The `set_async_cs2_cr_veronte4()` method configures the timing for the Veronte 4 external RAM:

```cpp
void Emif1::set_async_cs2_cr_veronte4() {
    emif1_regs.ASYNC_CS2_CR.bit.ASIZE    = emif_async_asize_16;    // 16-bit memory interface
    emif1_regs.ASYNC_CS2_CR.bit.TA       = emif_async_ta_1;        // Turnaround time: 1 cycle
    emif1_regs.ASYNC_CS2_CR.bit.R_HOLD   = emif_async_rhold_1;     // Read hold time: 1 cycle
    emif1_regs.ASYNC_CS2_CR.bit.R_STROBE = emif_async_rstrobe_04;  // Read strobe time: 4 cycles
    emif1_regs.ASYNC_CS2_CR.bit.R_SETUP  = emif_async_rsetup_01;   // Read setup time: 1 cycle
    emif1_regs.ASYNC_CS2_CR.bit.W_HOLD   = emif_async_whold_1;     // Write hold time: 1 cycle
    emif1_regs.ASYNC_CS2_CR.bit.W_STROBE = emif_async_wstrobe_03;  // Write strobe time: 3 cycles
    emif1_regs.ASYNC_CS2_CR.bit.W_SETUP  = emif_async_wsetup_01;   // Write setup time: 1 cycle
    emif1_regs.ASYNC_CS2_CR.bit.EW       = emif_async_ew_disable;  // Extended wait disabled
    emif1_regs.ASYNC_CS2_CR.bit.SS       = emif_async_ss_disable;  // Strobe select mode disabled
}
```

These timing parameters are critical for reliable communication with external memory devices and are defined through detailed enumerations:

```cpp
enum Emif_async_asize {
    emif_async_asize_8  = 0,    // 8-bit address size
    emif_async_asize_16 = 1,    // 16-bit address size
    emif_async_asize_32 = 2     // 32-bit address size
};

enum Emif_async_ta {
    emif_async_ta_1 = 0,        // Turnaround time of 1 cycle
    emif_async_ta_2 = 1,        // Turnaround time of 2 cycles
    emif_async_ta_3 = 2,        // Turnaround time of 3 cycles
    emif_async_ta_4 = 3         // Turnaround time of 4 cycles
};

// Additional timing parameter enumerations for read/write operations
```

### 2.2 EMIF1 Ownership Management

In the dual-core architecture of the DSP28335, the EMIF1 peripheral can be controlled by either CPU1 or CPU2. The ownership is managed through the MSEL register:

```cpp
void Emif1::cpu1_grab() {
    Hdual::assert_is_cpu1();                  // Ensure this is called from CPU1
    set_msel(msel_cpu1_wr, msel_cpu1_rd);     // Set ownership to CPU1
}

void Emif1::cpu2_grab() {
    Hdual::assert_is_cpu2();                  // Ensure this is called from CPU2
    set_msel(msel_cpu2_wr, msel_cpu2_rd);     // Set ownership to CPU2
}

void Emif1::ungrab() {
    set_msel(msel_free_wr, msel_free_rd);     // Release ownership
}
```

The ownership values are defined as constants:

```cpp
static const Uint64 msel_free_wr = 0x93A5CE70UL;  // Mask for free write operations
static const Uint32 msel_free_rd = 0x0UL;         // Mask for free read operations
static const Uint64 msel_cpu1_wr = 0x93A5CE71UL;  // Mask for CPU1 write operations
static const Uint32 msel_cpu1_rd = 0x1UL;         // Mask for CPU1 read operations
static const Uint32 msel_cpu2_wr = 0x93A5CE72UL;  // Mask for CPU2 write operations
static const Uint32 msel_cpu2_rd = 0x2UL;         // Mask for CPU2 read operations
```

### 2.3 EMIF1 Access Protection

The EMIF1 interface includes access protection features that can be configured and locked:

```cpp
void Emif1::lock() {
    asm_eallow();
    
    // Disable Access Protection (CPU_FETCH/CPU_WR/DMA_WR)
    emif1_cfg_regs.EMIF1ACCPROT0.all = 0x0;
    Base::Assertions::runtime(emif1_cfg_regs.EMIF1ACCPROT0.all == 0x0);

    // Commit the configuration related to protection
    emif1_cfg_regs.EMIF1COMMIT.all = 0x1;
    Base::Assertions::runtime(emif1_cfg_regs.EMIF1COMMIT.all == 0x1);

    // Lock the configuration so that EMIF1COMMIT register can't be changed anymore
    emif1_cfg_regs.EMIF1LOCK.all = 0x1;
    Base::Assertions::runtime(emif1_cfg_regs.EMIF1LOCK.all == 1);
    
    asm_edis();
}
```

Once locked, the protection settings cannot be changed until the next system reset.

## 3. Flash Memory Architecture

The DSP28335 includes internal Flash memory organized into sectors of different sizes. The Flash memory is used for program storage and non-volatile data.

### 3.1 Flash Memory Organization

The Flash memory is organized into 14 sectors with varying sizes:

```cpp
namespace Sectors {
    // Number of sectors (DSP2837x microcontroller)
    static const Uint16 nsectors = 14;

    // Start address of the flash memory
    static const Uint16* flash_start = reinterpret_cast<Uint16*>(0x080000);
    
    // Flash sector sizes
    enum Sector_sizes {
        sector8Kwords  = 0x2000,     // Size of an 8K words sector
        sector32Kwords = 0x8000      // Size of a 32K words sector
    };

    // Offset of each sector (A to N) followed by flash address end plus one
    static const Uint16* sector_addresses[nsectors + 1] = {
        flash_start,                                                          // Sector  0: size =  8K words
        flash_start + Ku32::u1 * sector8Kwords,                               // Sector  1: size =  8K words
        flash_start + Ku32::u2 * sector8Kwords,                               // Sector  2: size =  8K words
        flash_start + Ku32::u3 * sector8Kwords,                               // Sector  3: size =  8K words
        flash_start + Ku32::u4 * sector8Kwords,                               // Sector  4: size = 32K words
        flash_start + Ku32::u4 * sector8Kwords + Ku32::u1 * sector32Kwords,   // Sector  5: size = 32K words
        flash_start + Ku32::u4 * sector8Kwords + Ku32::u2 * sector32Kwords,   // Sector  6: size = 32K words
        flash_start + Ku32::u4 * sector8Kwords + Ku32::u3 * sector32Kwords,   // Sector  7: size = 32K words
        flash_start + Ku32::u4 * sector8Kwords + Ku32::u4 * sector32Kwords,   // Sector  8: size = 32K words
        flash_start + Ku32::u4 * sector8Kwords + Ku32::u5 * sector32Kwords,   // Sector  9: size = 32K words
        flash_start + Ku32::u4 * sector8Kwords + Ku32::u6 * sector32Kwords,   // Sector 10: size =  8K words
        flash_start + Ku32::u5 * sector8Kwords + Ku32::u6 * sector32Kwords,   // Sector 11: size =  8K words
        flash_start + Ku32::u6 * sector8Kwords + Ku32::u6 * sector32Kwords,   // Sector 12: size =  8K words
        flash_start + Ku32::u7 * sector8Kwords + Ku32::u6 * sector32Kwords,   // Sector 13: size =  8K words
        flash_start + Ku32::u8 * sector8Kwords + Ku32::u6 * sector32Kwords    // End of flash plus one
    };
}
```

The Flash memory starts at address 0x080000 and consists of:
- Sectors 0-3: 8K words each (16-bit words)
- Sectors 4-9: 32K words each
- Sectors 10-13: 8K words each

### 3.2 Flash Memory Control Registers

The Flash memory is controlled through a set of registers defined in the `FLASH_CTRL_REGS` structure:

```cpp
struct FLASH_CTRL_REGS {
    union FRDCNTL_REG FRDCNTL;           // Flash Read Control Register
    Uint16 rsvd1[Ku16::u28];             // Reserved
    union FBAC_REG FBAC;                 // Flash Bank Access Control Register
    union FBFALLBACK_REG FBFALLBACK;     // Flash Bank Fallback Power Register
    union FBPRDY_REG FBPRDY;             // Flash Bank Pump Ready Register
    union FPAC1_REG FPAC1;               // Flash Pump Access Control Register 1
    Uint16 rsvd2[Ku16::u4];              // Reserved
    union FMSTAT_REG FMSTAT;             // Flash Module Status Register
    Uint16 rsvd3[Ku16::u340];            // Reserved
    union FRD_INTF_CTRL_REG FRD_INTF_CTRL; // Flash Read Interface Control Register
};
```

These registers control various aspects of Flash operation, including:
- Read timing and wait states
- Power management
- Status monitoring
- Interface control

### 3.3 Flash Memory ECC (Error Correction Code)

The Flash memory includes ECC functionality for error detection and correction, controlled through the `FLASH_ECC_REGS` structure:

```cpp
struct FLASH_ECC_REGS {
    union ECC_ENABLE_REG ECC_ENABLE;           // ECC Enable
    Uint32 SINGLE_ERR_ADDR_LOW;                // Single Error Address Low
    Uint32 SINGLE_ERR_ADDR_HIGH;               // Single Error Address High
    Uint32 UNC_ERR_ADDR_LOW;                   // Uncorrectable Error Address Low
    Uint32 UNC_ERR_ADDR_HIGH;                  // Uncorrectable Error Address High
    union ERR_STATUS_REG ERR_STATUS;           // Error Status
    union ERR_POS_REG ERR_POS;                 // Error Position
    union ERR_STATUS_CLR_REG ERR_STATUS_CLR;   // Error Status Clear
    union ERR_CNT_REG ERR_CNT;                 // Error Control
    union ERR_THRESHOLD_REG ERR_THRESHOLD;     // Error Threshold
    union ERR_INTFLG_REG ERR_INTFLG;           // Error Interrupt Flag
    union ERR_INTCLR_REG ERR_INTCLR;           // Error Interrupt Flag Clear
    // Additional test registers
};
```

These registers enable ECC functionality and provide error detection, reporting, and management capabilities.

## 4. Flash Memory Initialization and Configuration

### 4.1 Flash Initialization

The Flash memory requires initialization before use to configure proper timing and power settings:

```cpp
void Flash::init() {
    static const Uint16 setDelay = static_cast<Uint16>(0x14);
    static const Uint16 setFPAC = static_cast<Uint16>(0x1);
    static const Uint16 setFB = static_cast<Uint16>(0x3);
    static const Uint16 setFlash = static_cast<Uint16>(0x3);
    static const Uint16 setEn = static_cast<Uint16>(0xA);

    static const Uint32 flash0_ctrl_regs_addr = 0x05F800UL;
    volatile FLASH_CTRL_REGS& flash0_ctrl_regs = Hregmap::get<FLASH_CTRL_REGS, flash0_ctrl_regs_addr>();

    asm_eallow();
    
    // Set VREADST to the proper value for the flash banks to power up properly
    flash0_ctrl_regs.FBAC.bit.VREADST = setDelay;

    // Power up Flash bank and pump
    flash0_ctrl_regs.FPAC1.bit.PMPPWR = setFPAC;
    flash0_ctrl_regs.FBFALLBACK.bit.BNKPWR0 = setFB;

    // Disable Cache and prefetch mechanism before changing wait states
    flash0_ctrl_regs.FRD_INTF_CTRL.bit.DATA_CACHE_EN = 0;
    flash0_ctrl_regs.FRD_INTF_CTRL.bit.PREFETCH_EN = 0;

    // Set waitstates according to frequency (0x3 for 150-200MHz)
    flash0_ctrl_regs.FRDCNTL.bit.RWAIT = setFlash;

    // Enable Cache and prefetch mechanism to improve performance
    flash0_ctrl_regs.FRD_INTF_CTRL.bit.DATA_CACHE_EN = 1;
    flash0_ctrl_regs.FRD_INTF_CTRL.bit.PREFETCH_EN = 1;

    // Enable ECC
    static const Uint32 flash0_ecc_regs_addr = 0x05FB00UL;
    volatile FLASH_ECC_REGS& flash0_ecc_regs = Hregmap::get<FLASH_ECC_REGS, flash0_ecc_regs_addr>();
    flash0_ecc_regs.ECC_ENABLE.bit.ENABLE = setEn;

    asm_edis();
    
    // Force a pipeline flush
    asm_pipeline_flush7();
}
```

This initialization sequence:
1. Sets bank power-up delay
2. Powers up the Flash bank and pump
3. Configures wait states based on CPU frequency
4. Enables cache and prefetch for improved performance
5. Enables Error Correction Code (ECC)

### 4.2 Flash API Initialization

Before performing Flash operations, the Flash API must be initialized:

```cpp
void flash_init0() {
    Flash::init();  // Ensure flash wait states are properly set

    // Initialize Flash API based on System frequency
    Fapi_StatusType res = Fapi_initializeAPI(F021_CPU0_BASE_ADDRESS, 200);
    if(res != Fapi_Status_Success) {
        flash_api_error(res);
    }

    flash_check_api_ver();
}
```

The initialization includes:
1. Setting proper Flash wait states
2. Initializing the Flash API with the system frequency
3. Checking the API version for compatibility

## 5. Flash Memory Access Control

### 5.1 Flash Pump Semaphore

In the dual-core architecture, Flash operations require exclusive access to the Flash pump. This is managed through a semaphore mechanism:

```cpp
void flash_semgrab_cpu1() {
    asm_eallow();
    while(Sys_regs::get_flash_pump_reg() != 0x2) {
        Sys_regs::get_flash_pump_reg() = (ipc_pump_key | 0x2);
    }
    asm_edis();
}

void flash_semgrab_cpu2() {
    asm_eallow();
    while(Sys_regs::get_flash_pump_reg() != 0x1) {
        Sys_regs::get_flash_pump_reg() = (ipc_pump_key | 0x1);
    }
    asm_edis();
}

void flash_sem_release() {
    asm_eallow();
    while(Sys_regs::get_flash_pump_reg() != 0x0) {
        Sys_regs::get_flash_pump_reg() = (ipc_pump_key | 0x0);
    }
    asm_edis();
}
```

These functions ensure that only one CPU can access the Flash pump at a time, preventing conflicts during Flash operations.

### 5.2 CPU-Specific Initialization

The Flash initialization process is CPU-specific:

```cpp
void flash_init() {
    // Determine which CPU is executing
    Uint16 cpu_id = Sys_regs::get_cpu_id();
    
    // Grab the appropriate semaphore based on CPU ID
    switch(cpu_id) {
        case 1:
            flash_semgrab_cpu1();
            break;
        case 2:
            flash_semgrab_cpu2();
            break;
        default:
            warning();
    }
    
    // Initialize Flash
    flash_init0();
}
```

This ensures that the Flash initialization is properly synchronized between the two CPUs.

## 6. Flash Memory Programming Operations

### 6.1 Sector Erasure

Before writing to Flash memory, the target sector must be erased:

```cpp
bool flash_erase_sector(const void* const addr0, Uint32 size16) {
    Uint32* addr32 = static_cast<Uint32*>(const_cast<void*>(addr0));
    
    asm_eallow();
    
    // Issue erase command
    Fapi_StatusType res_t = Fapi_issueAsyncCommandWithAddress(Fapi_EraseSector, addr32);
    bool res = (res_t == Fapi_Status_Success);
    
    if(res) {
        // Wait for erase operation to complete
        while(Fapi_checkFsmForReady() != Fapi_Status_FsmReady) {
        }

        // Verify that sector is erased
        Fapi_FlashStatusWordType oFlashStatusWord;
        res_t = Fapi_doBlankCheck(addr32, size16>>1, &oFlashStatusWord);
        res = (res_t == Fapi_Status_Success);
    }
    
    asm_edis();
    return res;
}
```

This function:
1. Issues an asynchronous erase command to the Flash memory
2. Waits for the erase operation to complete
3. Verifies that the sector is properly erased

### 6.2 Block Writing

After erasing a sector, data can be written to Flash memory:

```cpp
bool flash_write_block(const Uint32 sz16,
                      const void* const flash_start,
                      const void* const buffer0) {
    const uint16* addr = static_cast<const Uint16*>(flash_start);
    uint16* buffer = static_cast<Uint16*>(const_cast<void*>(buffer0));
    Fapi_StatusType res_t;
    Uint8 dc = 8;
    
    asm_eallow();
    
    bool res = true;
    for(Uint32 i=0; (i<sz16) && res; i+=dc) {
        // Issue programming command
        res_t = Fapi_issueProgrammingCommand(
            reinterpret_cast<Uint32 *>(const_cast<Uint16 *>(addr)),
            buffer, dc, 0, 0, Fapi_AutoEccGeneration);
        res = (res_t == Fapi_Status_Success);
        
        if(res) {
            // Wait for write operation to complete
            while(Fapi_checkFsmForReady() == Fapi_Status_FsmBusy) {
            }

            addr += dc;
            buffer += dc;
            if(i+dc>sz16) {
                dc = sz16-i;
            }
        }
    }
    
    asm_edis();
    return res;
}
```

This function:
1. Writes data to Flash memory in blocks of 8 words
2. Waits for each write operation to complete
3. Automatically generates ECC data for error detection and correction

### 6.3 Sector Operations

The `Flash_wr` class provides high-level operations for Flash memory:

```cpp
bool Flash_wr::erase_sectors(const void* dst, Uint32 sz16) {
    const Fsector sect(Sectors::sector_addresses);
    Fsector::Idx_pair sector_ids = { {0, 0} };
    
    // Check if sectors are valid
    bool res = check_sectors(sect, dst, sz16, sector_ids);
    
    if(res) {
        // Initialize Flash
        flash_init();
        
        // Erase each sector in the range
        for(int16 idx = sector_ids[0]; (idx <= sector_ids[1]) && res; ++idx) {
            const void* const sector_start = sect.get_start(idx);
            const Uint32 sector_size16 = sect.get_size16(idx);
            res = flash_erase_sector(sector_start, sector_size16);
        }
        
        flash_sem_release();
    }
    
    return res;
}

bool Flash_wr::write_data(const void* dst, const void* src, Uint32 sz16) {
    const Fsector sect(Sectors::sector_addresses);
    Fsector::Idx_pair sector_ids = { {0, 0} };
    
    // Check if sectors are valid
    bool res = check_sectors(sect, dst, sz16, sector_ids);
    
    if(res) {
        // Initialize Flash
        flash_init();
        
        // Write data to Flash
        flash_write_block(sz16, dst, src);
        
        flash_sem_release();
    }
    
    return res;
}

bool Flash_wr::write_sector(const void* dst, const void* src, Uint32 sz16) {
    const Fsector sect(Sectors::sector_addresses);
    Fsector::Idx_pair sector_ids = { {0, 0} };
    
    // Check if sectors are valid
    bool res = check_sectors(sect, dst, sz16, sector_ids);
    
    if(res) {
        // Initialize Flash
        flash_init();
        
        // Erase and write each sector in the range
        for(int16 idx = sector_ids[0]; idx <= sector_ids[1]; ++idx) {
            const void* const sector_start = sect.get_start(idx);
            const Uint32 sector_size16 = sect.get_size16(idx);
            res = flash_erase_sector(sector_start, sector_size16);
            if(res) {
                flash_write_block(sz16, dst, src);
            }
        }
        
        flash_sem_release();
    }
    
    return res;
}
```

These methods provide different operations:
- `erase_sectors`: Erases the sectors containing the specified memory range
- `write_data`: Writes data to Flash memory (assumes sectors are already erased)
- `write_sector`: Erases sectors and then writes data to Flash memory

### 6.4 OTP Memory Programming

The DSP28335 includes One-Time Programmable (OTP) memory for storing permanent data:

```cpp
bool Flash_wr::write_otp(Uint32* dst_ptr, Uint16* src_ptr, Uint16 src_sz16) {
    flash_init();
    asm_eallow();
    
    // Program OTP memory
    Fapi_StatusType res = Fapi_issueProgrammingCommand(
        dst_ptr, src_ptr, src_sz16, 0, 0, Fapi_AutoEccGeneration);
    if(res != Fapi_Status_Success) {
        flash_api_error(res);
    }
    
    // Wait for programming to complete
    while(Fapi_checkFsmForReady() == Fapi_Status_FsmBusy) {
    }
    
    asm_edis();
    flash_sem_release();
    return true;
}
```

The OTP memory is used for storing permanent unique system identifiers:

```cpp
namespace {
    // From SPRUHM8I - TMS320F2837xD technical reference manual
    // On figure 3-22 (DCSM registers into User configurable OTP)
    static const Uint32 otp_z1_start = 0x78000;
    static const Uint32 otp_z2_start = 0x78200;

    // Range to store permanent unique system identifier
    static const Uint32 otp_uid_start = 0x782A0;
    static const Uint32 otp_z2_end = 0x78400;
}

const Uint32 User_otp::user_otp_start = otp_uid_start;
const Uint32 User_otp::user_otp_end = otp_z2_end;
```

## 7. Memory Map and Linker Configuration

The DSP28335 memory map is defined in the linker command file, organizing both internal and external memory regions:

```
// Memory constants
#define LSRAM_START   (0x008000)
#define LSRAM_END     (0x00AFFF)
#define DRAM_START    (0x00B000)
#define DRAM_END      (0x00BFFF)
#define GSRAM_START   (0x00C000)
#define GSRAM_END     (0x01BFFF)

#define ERAM_START_ADDR (0x100000)
#define ERAM_TOTAL_SZ   (0x100000)

#define ERAM_VBLK_SZ      (0x8000)
#define ERAM_VBLK_DATA_SZ (0x8000)

#define ERAM_END (ERAM_START_ADDR + ERAM_TOTAL_SZ - 1 - ERAM_VBLK_SZ - ERAM_VBLK_DATA_SZ)

#define ERAM_VBLK_ST      (ERAM_END + 1)
#define ERAM_VBLK_DATA_ST (ERAM_VBLK_ST + ERAM_VBLK_SZ)

// CPU-specific memory regions
#define XCCPU1_SZ    (0x000C40)
#define XCCPU2_SZ    (0x33B5E)
#define XCCPU1_START (1+GSRAM_END-XCCPU1_SZ)
#define XCCPU2_START (ERAM_START_ADDR)
#define ERAM_CPU2_START (XCCPU2_START + XCCPU2_SZ)
#define ERAM_CPU2_SIZE  (1 + ERAM_END - ERAM_CPU2_START)
```

The memory map defines:
- Internal RAM regions (LSRAM, DRAM, GSRAM)
- External RAM regions (ERAM)
- CPU-specific memory allocations
- Inter-processor communication regions

The memory regions are organized into pages:
- Page 0: Program Memory (including ERAM_VBLOCK)
- Page 1: Data Memory (including CPU-specific regions and IPC regions)

```
MEMORY
{
PAGE 0 :  /* Program Memory */
    ERAM_VBLOCK:      origin = ERAM_VBLK_ST,    length = ERAM_VBLK_SZ

PAGE 1 : /* Data Memory */
    ERAM_VBLOCK_DATA: origin = ERAM_VBLK_DATA_ST, length = ERAM_VBLK_DATA_SZ
    XCCPU1:           origin = XCCPU1_START,      length = XCCPU1_SZ
    XCCPU2:           origin = XCCPU2_START,      length = XCCPU2_SZ
    CPU2TOCPU1RAM:    origin = 0x03F800,          length = 0x000400
    CPU1TOCPU2RAM:    origin = 0x03FC00,          length = 0x000400
    ERAM_CPU2:        origin = ERAM_CPU2_START,   length = ERAM_CPU2_SIZE
}
```

## 8. Cross-Component Relationships

### 8.1 EMIF1 and System Configuration

The EMIF1 configuration is closely tied to the system configuration:

1. **Device Configuration**: The EMIF1 module must be reset and configured by the Device Configuration module
2. **CPU Ownership**: The EMIF1 ownership must be properly set based on which CPU will access external memory
3. **Clock Configuration**: The EMIF1 clock must be enabled and properly divided for reliable operation
4. **GPIO Configuration**: The GPIO pins must be properly configured for EMIF1 operation

### 8.2 Flash Memory and System Initialization

The Flash memory initialization is part of the system initialization process:

1. **Early Initialization**: Flash wait states must be configured early in the boot process
2. **CPU Coordination**: In dual-core operation, Flash access must be coordinated between CPUs
3. **Memory Protection**: Flash memory protection settings must be configured as part of system security

### 8.3 Flash API and Flash Controller

The Flash API provides a high-level interface to the Flash controller:

1. **API Initialization**: The Flash API must be initialized with the correct system frequency
2. **API Version Check**: The API version must be checked for compatibility
3. **Error Handling**: Flash API errors must be properly handled to prevent system corruption

## 9. Referenced Context Files

The following context files provided valuable information for understanding the EMIF and Flash memory systems:

- **06_Hardware_Abstraction_Layer.md**: Provided details on the register structure and hardware abstraction approach used in the DSP28335 microcontroller
- **05_System_Configuration.md**: Provided information on system initialization, clock configuration, and CPU coordination that affects EMIF and Flash operation

## Summary

The DSP28335 microcontroller provides comprehensive support for external memory interfaces and Flash memory management. The EMIF1 peripheral enables connection to external memory devices with configurable timing parameters and access protection. The Flash memory system provides reliable non-volatile storage with error correction capabilities and a comprehensive API for programming operations.

In dual-core operation, both EMIF1 and Flash access are carefully coordinated between CPUs to prevent conflicts. The memory map is organized to provide efficient allocation of resources between the two CPUs, with dedicated regions for inter-processor communication.

The combination of EMIF1 for external memory access and internal Flash memory provides a flexible memory architecture that can be tailored to the needs of specific applications, from small embedded systems to complex control applications requiring large memory resources.