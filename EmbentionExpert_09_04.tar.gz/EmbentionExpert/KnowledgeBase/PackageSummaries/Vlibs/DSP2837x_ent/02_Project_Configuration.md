# Generated from:

- code/project/eclipse/.project (336 tokens)
- code/project/eclipse/.cproject (5382 tokens)

---

# Eclipse Project Configuration for DSP28335 Microcontroller Codebase

## Project Overview

The Eclipse project configuration for the DSP28335 microcontroller codebase is defined in two main files: `.project` and `.cproject`. These files establish the project structure, build settings, include paths, and compiler options for the development environment.

## Project Structure

### Project Name and Nature
- **Project Name**: DSP2837x_ent
- **Project Natures**:
  - C Nature (`org.eclipse.cdt.core.cnature`)
  - C++ Nature (`org.eclipse.cdt.core.ccnature`)
  - Managed Build Nature (`org.eclipse.cdt.managedbuilder.core.managedBuildNature`)
  - Scanner Config Nature (`org.eclipse.cdt.managedbuilder.core.ScannerConfigNature`)

### Linked Resources
The project uses linked resources to reference directories outside the project folder:

| Resource Name | Type | Location |
|---------------|------|----------|
| include | Directory | `PARENT-2-PROJECT_LOC/include` |
| include_SIL | Directory | `PARENT-2-PROJECT_LOC/include_SIL` |
| source | Directory | `PARENT-2-PROJECT_LOC/source` |
| source_SIL | Directory | `PARENT-2-PROJECT_LOC/source_SIL` |

### Build Commands
The project uses two build commands:
1. `org.eclipse.cdt.managedbuilder.core.genmakebuilder` - Triggered on clean, full, and incremental builds
2. `org.eclipse.cdt.managedbuilder.core.ScannerConfigBuilder` - Triggered on full and incremental builds

## Build Configurations

The project has two build configurations:

### 1. Default Configuration
- **Build Artifact Type**: Static Library (`.a`)
- **Artifact Name**: `${ProjName}` (DSP2837x_ent)
- **Toolchain**: Linux GCC
- **Builder**: GNU Make Builder with clean build target `--silent clean`

### 2. 2838x Configuration
- **Build Artifact Type**: Static Library (`.a`)
- **Artifact Name**: `${ProjName}` (DSP2837x_ent)
- **Toolchain**: Linux GCC
- **Builder**: Same as Default configuration

## Compiler Settings

### C++ Compiler Settings (Both Configurations)
- **Language Standard**: C++17
- **Position Independent Code**: Enabled (-fPIC)
- **pthread Support**: Enabled (-pthread)
- **Other Flags**: `-c -fmessage-length=0 -fpermissive`

### C Compiler Settings (Both Configurations)
- **Position Independent Code**: Enabled (-fPIC)
- **pthread Support**: Enabled (-pthread)

### Preprocessor Definitions (Both Configurations)
Both C and C++ compilers use the following preprocessor definitions:
- `interrupt=""` 
- `__cregister=""`
- `__TI_COMPILER_VERSION__=18012005`
- `byte_peripheral=1`

## Include Paths

The project includes numerous include paths for both configurations:

```
${workspace_loc:/DSP2837x_ent/include_SIL}
${workspace_loc:/DSP2837x_ent/include}
${workspace_loc:/DSP2837x_ent/common}
${workspace_loc:/bsp/include_SIL}
${workspace_loc:/bsp/include}
${workspace_loc:/DSP28x/include_SIL}
${workspace_loc:/DSP28x/include}
${workspace_loc:/DSP28x/source}
${workspace_loc:/first/include_SIL}
${workspace_loc:/first/include}
${workspace_loc:/base/include_SIL}
${workspace_loc:/base/include}
${workspace_loc:/FPU/include_SIL}
${workspace_loc:/FPU/include}
${workspace_loc:/bsp/include/2837x}
${workspace_loc:/coreSIL/include}
```

## Source Exclusions

### Default Configuration Source Exclusions
The project excludes specific files from the build in the source directory:
```
common/DMA_2837x.cpp
cpu1/Flash_wr_2837x.cpp
cpu1/Flashif_cpu1.cpp
cpu1/Hdual_cpu1.cpp
cpu1/System_cpu1.cpp
cpu1/Reset_2837x.cpp
cpu1/Flash_wr_2837x_cbs.cpp
cpu2/Hdual.cpp
cpu2/System_cpu2.cpp
cpu2/Default_isr_cpu2.cpp
cpu2/Sysuid_cpu2.cpp
common/CAN.cpp
common/ADC_2837x.cpp
```

### 2838x Configuration Source Exclusions
The 2838x configuration excludes the above files plus additional ones:
```
common/ECAP_2837x.cpp
common/Emif1_2837x.cpp
common/Ipc_2837x.cpp
common/Pwmdev_2837x.cpp
common/SPI_2837x.cpp
cpu1/Devcfg_2837x.cpp
cpu1/ECAP_ioctl_2837x.cpp
cpu1/PLL_cpu1_2837x.cpp
cpu1/Sys_regs_2837x.cpp
cpu1/User_otp_2837x.cpp
cpu1/Sysuid_cpu1.cpp
common/ADC_mc_28377.cpp
common/GPIO.cpp
common/CAN_FD_dummy.cpp
```

Additionally, the 2838x configuration excludes `cpu1/Sysuid_cpu1.cpp` from the source_SIL directory.

## Binary Parser and Error Parsers

- **Binary Parser**: GNU ELF (`org.eclipse.cdt.core.GNU_ELF`)
- **Error Parsers**:
  - GAS Error Parser (`org.eclipse.cdt.core.GASErrorParser`)
  - Gmake Error Parser (`org.eclipse.cdt.core.GmakeErrorParser`)
  - CWD Locator (`org.eclipse.cdt.core.CWDLocator`)
  - GCC Error Parser (`org.eclipse.cdt.core.GCCErrorParser`)

## Summary

This Eclipse project is configured for developing software for the DSP28335 microcontroller with two build configurations: Default and 2838x. It uses the GNU GCC toolchain on Linux and builds a static library. The project references source code and include files from multiple external directories and defines specific preprocessor symbols to support the microcontroller environment. The configuration excludes certain files from the build process depending on the selected configuration, allowing for targeted builds for different hardware variants.