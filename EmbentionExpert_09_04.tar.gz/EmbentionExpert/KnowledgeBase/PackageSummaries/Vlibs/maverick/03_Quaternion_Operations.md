# Generated from:

- code/include/Irquat.h (3489 tokens)
- code/include/Irquat_fw.h (23 tokens)
- code/include/Rquat.h (605 tokens)
- code/source/Irquat.cpp (2484 tokens)
- code/source/Rquat.cpp (195 tokens)

## With context from:

- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/maverick/05_Core_Vector_Operations.md (2763 tokens)

---

# Maverick Quaternion Library: Comprehensive Summary

## 1. Class Hierarchy and Memory Management

The Maverick quaternion library provides a comprehensive set of quaternion classes with a clear hierarchical structure designed for efficient memory management and mathematical operations. The library follows the same design pattern as the vector library, with two main types of quaternions:

### Memory-less Quaternions (Irquat)

`Irquat` is a memory-less quaternion class that operates on externally provided memory:

```cpp
class Irquat : public Ivector<Real>
{
public:
    explicit Irquat(Real* v0);
    explicit Irquat(Base::Rv4& v);
    // Operations and methods...
private:
    static const Uint16 sz = 4U;
    // Private constructors for const access
    explicit Irquat(const Real* v0);
    explicit Irquat(const Base::Rv4& v);
};
```

Key characteristics:
- Inherits from `Ivector<Real>`, leveraging the vector infrastructure
- Does not own its memory but operates on externally provided 4-element arrays
- Size is always 4 elements (scalar part + 3 imaginary parts)
- Provides a nested `K` structure for const-correct access

### Memory-owning Quaternions (Rquat)

`Rquat` is a memory-owning quaternion class that inherits from `Irquat`:

```cpp
class Rquat: public Irquat
{
public:
    Rquat();
    explicit Rquat(const Irquat& q0);
    explicit Rquat(const Base::Rv4& q0);
    Rquat(const Real r_qs, const Real r_qi, const Real r_qj, const Real r_qk);
private:
    Real data[Ku16::u4];  // 4-dimensional array with data
};
```

Key characteristics:
- Inherits from `Irquat`, providing all quaternion operations
- Owns its memory through a static array `data[4]`
- Provides multiple constructors for different initialization scenarios
- Copy constructor and assignment operator are deleted to prevent unintended copying

### Const-Correctness Pattern

The quaternion library uses the same const-correctness pattern as the vector library through the `K` structure:

```cpp
struct Irquat::K
{
    const Irquat kquat;
    explicit K(const Base::Rv4& v);
    explicit K(const Real* v0);
};
```

This allows creating read-only views of quaternions without copying data, ensuring const-correctness while maintaining efficiency.

## 2. Quaternion Structure and Representation

### Quaternion Components

Quaternions in the library are represented as 4-dimensional vectors with the following components:

```cpp
enum quat_base      
{
    qs = 0,         // Scalar part
    qi = 1,         // First imaginary part (i)
    qj = 2,         // Second imaginary part (j)
    qk = 3          // Third imaginary part (k)
};
```

A quaternion q is represented as: q = qs + qi·i + qj·j + qk·k

### Memory Layout

The quaternion data is stored in a contiguous 4-element array with the following layout:
- `v[0]` = scalar part (qs)
- `v[1]` = first imaginary part (qi)
- `v[2]` = second imaginary part (qj)
- `v[3]` = third imaginary part (qk)

This layout allows efficient access to components and compatibility with vector operations.

## 3. Quaternion Operations

### Initialization Operations

- **`identity()`**: Sets the quaternion to represent no rotation (1, 0, 0, 0)
  ```cpp
  void identity() {
      Base::Tmem::set<Ku16::u3*sizeof(Real)>(&v[qi], 0);
      v[qs] = Const::ONE;
  }
  ```

- **`zeros()`**: Sets all quaternion components to zero
  ```cpp
  void zeros() {
      Ivector::zeros0<sz>();
  }
  ```

- **`copy(const Irquat& q0)`**: Copies values from another quaternion
  ```cpp
  void copy(const Irquat& q0) {
      Ivector::copy0<sz>(q0);
  }
  ```

- **`copy(const Base::Rv4& q0)`**: Copies values from a 4-element array
  ```cpp
  void copy(const Base::Rv4& q0) {
      Ivector::copy0<sz>(q0.v);
  }
  ```

### Quaternion-Quaternion Operations

- **`quatmult(const Irquat& q, const Irquat& p)`**: Multiplies two quaternions (q × p)
  ```cpp
  void quatmult(const Irquat& q, const Irquat& p) {
      v[qs] = q[qs]*p[qs] - q[qi]*p[qi] - q[qj]*p[qj] - q[qk]*p[qk];
      v[qi] = q[qi]*p[qs] + q[qs]*p[qi] - q[qk]*p[qj] + q[qj]*p[qk];
      v[qj] = q[qj]*p[qs] + q[qk]*p[qi] + q[qs]*p[qj] - q[qi]*p[qk];
      v[qk] = q[qk]*p[qs] - q[qj]*p[qi] + q[qi]*p[qj] + q[qs]*p[qk];
  }
  ```

- **`thisquat(const Irquat& q)`**: Multiplies this quaternion by another (this × q)
  ```cpp
  void thisquat(const Irquat& q) {
      Base::Rv4 cv;
      cv.copy_all(&v[0U]);
      quatmult(Irquat::K(cv).kquat, q);
  }
  ```

- **`quatthis(const Irquat& q)`**: Multiplies another quaternion by this (q × this)
  ```cpp
  void quatthis(const Irquat& q) {
      Base::Rv4 cv;
      cv.copy_all(&v[0U]);
      quatmult(q, Irquat::K(cv).kquat);
  }
  ```

- **`quat_add(const Irquat& q)`**: Adds another quaternion to this
  ```cpp
  void quat_add(const Irquat& q) {
      v[qs] += q[qs];
      v[qi] += q[qi];
      v[qj] += q[qj];
      v[qk] += q[qk];
  }
  ```

### Quaternion-Vector Operations

- **`quavec(const Irquat& q, const Irvector3& w)`**: Computes quaternion-vector product (q × w)
  ```cpp
  void quavec(const Irquat& q, const Irvector3& w) {
      v[qs] = -q[qi]*w[x] - q[qj]*w[y] - q[qk]*w[z];
      v[qi] = q[qs]*w[x] + q[qj]*w[z] - q[qk]*w[y];
      v[qj] = q[qs]*w[y] - q[qi]*w[z] + q[qk]*w[x];
      v[qk] = q[qs]*w[z] + q[qi]*w[y] - q[qj]*w[x];
  }
  ```

- **`n2b(const Irvector3& n, Irvector3& b) const`**: Rotates a vector from NED frame to body frame
  ```cpp
  void n2b(const Irvector3& n, Irvector3& b) const {
      // Detailed implementation with optimized quaternion rotation formula
      // Computes b = q * n * q^(-1)
  }
  ```

- **`b2n(const Irvector3& b, Irvector3& n) const`**: Rotates a vector from body frame to NED frame
  ```cpp
  void b2n(const Irvector3& b, Irvector3& n) const {
      // Detailed implementation with optimized quaternion rotation formula
      // Computes n = q^(-1) * b * q
  }
  ```

### Norm and Normalization Operations

- **`norm22() const`**: Computes the squared Euclidean norm
  ```cpp
  Real norm22() const {
      return (v[qs]*v[qs]) + (v[qi]*v[qi]) + (v[qj]*v[qj]) + (v[qk]*v[qk]);
  }
  ```

- **`norm2() const`**: Computes the Euclidean norm
  ```cpp
  Real norm2() const {
      return Rmath::sqrtr(norm22());
  }
  ```

- **`norm2alize()`**: Normalizes the quaternion to unit length
  ```cpp
  void norm2alize() {
      static const Real min_norm = 1e-8F;
      scale(1.0F/Rfun::max<Real>(norm2(), min_norm));
  }
  ```

### Quaternion Transformations

- **`conjugate()`**: Computes the conjugate of the quaternion
  ```cpp
  void conjugate() {
      v[qi] = -v[qi];
      v[qj] = -v[qj];
      v[qk] = -v[qk];
  }
  ```

- **`invert()`**: Computes the inverse of the quaternion
  ```cpp
  void invert() {
      const Real den = 1.0F / norm22();
      v[qs] *=  den;
      v[qi] *= -den;
      v[qj] *= -den;
      v[qk] *= -den;
  }
  ```

- **`rectify()`**: Ensures the quaternion has a positive scalar part
  ```cpp
  void rectify() {
      if(v[qs] < 0.0F) {
          scale(-1.0F);
      }
  }
  ```

### Rotation Creation Operations

- **`ypr2quat(Real y, Real p, Real r)`**: Creates a quaternion from yaw, pitch, roll angles
  ```cpp
  void ypr2quat(Real y, Real p, Real r) {
      // Implementation converts Euler angles to quaternion
  }
  ```

- **`qrot(const Irvector3& k, const Real alpha)`**: Creates a quaternion from rotation axis and angle
  ```cpp
  void qrot(const Irvector3& k, const Real alpha) {
      const Real half_alpha = 0.5F * alpha;
      const Real s2a = Rmath::sinr(half_alpha);
      v[qs] = Rmath::cosr(half_alpha);
      v[qi] = s2a * k[Irvector3::vx];
      v[qj] = s2a * k[Irvector3::vy];
      v[qk] = s2a * k[Irvector3::vz];
  }
  ```

- **`qrotfromaxis(const Irvector3& k)`**: Creates a quaternion from an axis-angle vector
  ```cpp
  void qrotfromaxis(const Irvector3& k) {
      Maverick::Rvector3 ku;
      ku.copy(k);
      Real angle = ku.norm2alize();
      qrot(ku, angle);
  }
  ```

### Miscellaneous Operations

- **`scale(Real a)`**: Scales all quaternion components
  ```cpp
  void scale(Real a) {
      v[qs] *= a;
      v[qi] *= a;
      v[qj] *= a;
      v[qk] *= a;
  }
  ```

- **`gradient(const Maverick::Rmatrix& J, const Irvector3& f)`**: Computes quaternion gradient
  ```cpp
  void gradient(const Maverick::Rmatrix& J, const Irvector3& f) {
      v[qs] = J[a00]*f[x] + J[a10]*f[y] + J[a20]*f[z];
      v[qi] = J[a01]*f[x] + J[a11]*f[y] + J[a21]*f[z];
      v[qj] = J[a02]*f[x] + J[a12]*f[y] + J[a22]*f[z];
      v[qk] = J[a03]*f[x] + J[a13]*f[y] + J[a23]*f[z];
  }
  ```

- **`add_lincmb(Real a, const Irquat& a1, Real b, const Irquat& b1, Real c, const Irquat& c1) const`**: Adds linear combination of quaternions
  ```cpp
  void add_lincmb(Real a, const Irquat& a1, Real b, const Irquat& b1, Real c, const Irquat& c1) const {
      // Implementation adds a*a1 + b*b1 + c*c1 to this quaternion
  }
  ```

## 4. Integration with Vector Library

The quaternion library is tightly integrated with the vector library, particularly for operations involving rotations and transformations:

### Vector Rotation

The quaternion class provides methods to rotate 3D vectors using quaternions:

1. **NED to Body Frame Rotation**:
   ```cpp
   void n2b(const Irvector3& n, Irvector3& b) const
   ```
   This method rotates a vector from the NED (North-East-Down) reference frame to the body frame using the quaternion. The implementation uses an optimized form of the quaternion rotation formula:
   ```
   b = q * n * q^(-1)
   ```
   where `*` represents quaternion multiplication and `q^(-1)` is the quaternion inverse.

2. **Body to NED Frame Rotation**:
   ```cpp
   void b2n(const Irvector3& b, Irvector3& n) const
   ```
   This method rotates a vector from the body frame to the NED reference frame using the quaternion. It implements the inverse rotation:
   ```
   n = q^(-1) * b * q
   ```

### Quaternion-Vector Multiplication

The `quavec` method implements quaternion-vector multiplication:
```cpp
void quavec(const Irquat& q, const Irvector3& w)
```

This operation treats the 3D vector as a pure quaternion (with scalar part 0) and computes the quaternion product.

### Vector-Based Quaternion Creation

Several methods create quaternions from vector inputs:

1. **Rotation from Axis and Angle**:
   ```cpp
   void qrot(const Irvector3& k, const Real alpha)
   ```
   Creates a quaternion representing a rotation of `alpha` radians around the axis `k`.

2. **Rotation from Axis-Angle Vector**:
   ```cpp
   void qrotfromaxis(const Irvector3& k)
   ```
   Creates a quaternion from a vector whose direction represents the rotation axis and whose magnitude represents the rotation angle.

### Gradient Computation

The `gradient` method computes the quaternion gradient using a Jacobian matrix and a direction vector:
```cpp
void gradient(const Maverick::Rmatrix& J, const Irvector3& f)
```

This is useful for optimization problems involving quaternions.

## 5. Error Handling and Parameter Validation

The quaternion library implements several error handling and validation mechanisms:

### Numerical Stability

1. **Normalization with Minimum Threshold**:
   ```cpp
   void norm2alize() {
       static const Real min_norm = 1e-8F;
       scale(1.0F/Rfun::max<Real>(norm2(), min_norm));
   }
   ```
   This prevents division by zero when normalizing quaternions with very small norms.

2. **Precondition for Inversion**:
   ```cpp
   /// \pre
   /// This method shall only be used when the squared norm of the quaternion is greater than 
   /// 1E-8 to avoid indetermination.
   void invert()
   ```
   The `invert` method has an explicit precondition that the quaternion's squared norm must be greater than 1E-8.

### Const-Correctness

The library ensures const-correctness through:

1. **Private Constructors with Const Parameters**:
   ```cpp
   explicit Irquat(const Real* v0);
   explicit Irquat(const Base::Rv4& v);
   ```
   These private constructors prevent accidental modification of const data.

2. **K Structure for Const Access**:
   ```cpp
   struct Irquat::K {
       const Irquat kquat;
       // ...
   };
   ```
   This structure provides a const-correct way to access quaternion data.

### Memory Safety

1. **Deleted Copy Constructor and Assignment Operator**:
   ```cpp
   Irquat(const Irquat& src);             ///< = delete.
   Irquat& operator=(const Irquat& src);  ///< = delete.
   ```
   These are deleted to prevent unintended copying of memory-less quaternions.

2. **Deleted Default Constructor**:
   ```cpp
   Irquat();                              ///< = delete.
   ```
   This is deleted because an Irquat must always be constructed with external memory.

## 6. Mathematical Foundation and Quaternion Properties

### Quaternion Algebra

The quaternion library implements the standard quaternion algebra:

1. **Quaternion Multiplication**:
   ```cpp
   void quatmult(const Irquat& q, const Irquat& p)
   ```
   Implements the quaternion multiplication formula:
   ```
   (q₀ + q₁i + q₂j + q₃k)(p₀ + p₁i + p₂j + p₃k) = 
   (q₀p₀ - q₁p₁ - q₂p₂ - q₃p₃) + 
   (q₀p₁ + q₁p₀ + q₂p₃ - q₃p₂)i + 
   (q₀p₂ - q₁p₃ + q₂p₀ + q₃p₁)j + 
   (q₀p₃ + q₁p₂ - q₂p₁ + q₃p₀)k
   ```

2. **Quaternion Conjugate**:
   ```cpp
   void conjugate()
   ```
   Implements the quaternion conjugate formula:
   ```
   q* = q₀ - q₁i - q₂j - q₃k
   ```

3. **Quaternion Inverse**:
   ```cpp
   void invert()
   ```
   Implements the quaternion inverse formula:
   ```
   q⁻¹ = q* / |q|²
   ```

### Rotation Representation

The quaternion library uses unit quaternions to represent 3D rotations:

1. **Unit Quaternion Property**:
   A unit quaternion (|q| = 1) represents a rotation in 3D space.

2. **Rotation Formula**:
   The rotation of a vector v by a quaternion q is computed as:
   ```
   v' = q * v * q⁻¹
   ```
   where v is treated as a pure quaternion (0 + v₁i + v₂j + v₃k).

3. **Composition of Rotations**:
   The composition of rotations is represented by quaternion multiplication:
   ```
   q₃ = q₁ * q₂
   ```
   where q₃ represents the rotation obtained by first applying q₂ and then q₁.

4. **Euler Angle Conversion**:
   The `ypr2quat` method converts Euler angles (yaw, pitch, roll) to a quaternion:
   ```cpp
   void ypr2quat(Real y, Real p, Real r)
   ```

## 7. File-by-File Breakdown

### Irquat.h

This header file defines the `Irquat` class, which is the memory-less quaternion class:

- **Class Definition**: Defines `Irquat` as a subclass of `Ivector<Real>`
- **Constructors**: Provides constructors for external memory
- **Nested K Structure**: Defines the `K` structure for const-correct access
- **Enumerations**: Defines `quat_base` for component access and `jacob_pos`/`f_pos` for gradient computation
- **Method Declarations**: Declares all quaternion operations
- **Inline Implementations**: Implements simple methods inline

Key responsibilities:
- Provides the interface for quaternion operations
- Ensures const-correctness through the K structure
- Defines the quaternion component layout

### Irquat_fw.h

This is a forward declaration file for the `Irquat` class:

```cpp
namespace Maverick
{
    class Irquat;
}
```

Its purpose is to allow other files to reference the `Irquat` class without including the full header.

### Rquat.h

This header file defines the `Rquat` class, which is the memory-owning quaternion class:

- **Class Definition**: Defines `Rquat` as a subclass of `Irquat`
- **Constructors**: Provides constructors for different initialization scenarios
- **Data Member**: Declares the `data` array for storing quaternion components
- **Inline Implementations**: Implements constructors inline

Key responsibilities:
- Provides memory ownership for quaternions
- Inherits all quaternion operations from `Irquat`
- Offers convenient constructors for creating quaternions

### Irquat.cpp

This source file implements the non-inline methods of the `Irquat` class:

- **Norm Operations**: Implements `norm22()` and `norm2alize()`
- **Quaternion-Quaternion Operations**: Implements `quat_add()`, `quatmult()`, `thisquat()`, `quatthis()`, `conjugate()`, `invert()`
- **Quaternion-Vector Operations**: Implements `quavec()`, `n2b()`, `b2n()`
- **Rotation Operations**: Implements `qrot()`, `qrotfromaxis()`, `ypr2quat()`
- **Miscellaneous Operations**: Implements `scale()`, `gradient()`, `add_lincmb()`, `rectify()`

Key responsibilities:
- Implements the core quaternion algebra
- Provides rotation functionality
- Ensures numerical stability

### Rquat.cpp

This source file implements the non-inline methods of the `Rquat` class:

- **Constructor Implementation**: Implements the constructor that takes individual quaternion components

Key responsibilities:
- Initializes memory-owning quaternions with specific values

## 8. Numerical Stability and Performance Considerations

### Numerical Stability

The quaternion library includes several features for numerical stability:

1. **Normalization with Minimum Threshold**:
   ```cpp
   void norm2alize() {
       static const Real min_norm = 1e-8F;
       scale(1.0F/Rfun::max<Real>(norm2(), min_norm));
   }
   ```
   This prevents division by zero when normalizing quaternions with very small norms.

2. **Quaternion Rectification**:
   ```cpp
   void rectify() {
       if(v[qs] < 0.0F) {
           scale(-1.0F);
       }
   }
   ```
   This ensures that the scalar part of the quaternion is positive, which can help avoid numerical issues in some applications.

3. **Use of Specialized Math Functions**:
   ```cpp
   Rmath::sqrtr(norm22())
   Rmath::cosr(half_alpha)
   Rmath::sinr(half_alpha)
   ```
   The library uses specialized math functions from the `Rmath` namespace, which may be optimized for numerical stability.

### Performance Optimizations

The quaternion library includes several performance optimizations:

1. **Optimized Rotation Formulas**:
   The `n2b()` and `b2n()` methods use optimized formulas for quaternion rotation that avoid explicit quaternion multiplication.

2. **Precomputation of Common Subexpressions**:
   ```cpp
   Real q1q1 = v[qi]*v[qi];
   Real q2q2 = v[qj]*v[qj];
   Real q3q3 = v[qk]*v[qk];
   Real q0q1 = v[qs]*v[qi];
   // ...
   ```
   Common subexpressions are precomputed to avoid redundant calculations.

3. **Inline Simple Methods**:
   Simple methods like `identity()`, `zeros()`, and `copy()` are implemented inline to reduce function call overhead.

4. **Memory-less Design**:
   The memory-less design of `Irquat` allows operating on externally provided memory without copying, which can improve performance in some scenarios.

## Referenced Context Files

The following context file provided useful information for understanding the quaternion library:

1. **05_Core_Vector_Operations.md**: This file provided context about the vector library, which is closely integrated with the quaternion library. It helped understand the relationship between vectors and quaternions, particularly for operations involving rotations and transformations.

## Summary

The Maverick quaternion library provides a comprehensive set of quaternion classes with a clear hierarchical structure. It separates memory-less quaternions (`Irquat`) from memory-owning quaternions (`Rquat`), enabling efficient memory management for different use cases. The library supports a wide range of quaternion operations, from basic algebra to advanced rotations, with careful attention to numerical stability and performance. The integration with the vector library enables seamless operations between quaternions and vectors, particularly for 3D rotations and transformations. The const-correctness pattern using the K structure ensures safe access to quaternion data while maintaining efficiency.