# Generated from:

- code/include/Dyn_rtable.h (665 tokens)
- code/include/Rtable.h (3418 tokens)
- code/include/Rtable_fw.h (52 tokens)
- code/include/Rtable3d.h (2016 tokens)
- code/include/Rtablen.h (1055 tokens)
- code/source/Dyn_rtable.cpp (1899 tokens)
- code/source/Rtable.cpp (2495 tokens)
- code/source/Rtable3d.cpp (1819 tokens)

## With context from:

- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/maverick/05_Core_Vector_Operations.md (2763 tokens)

---

# Maverick Table Operations Library: Comprehensive Summary

## 1. Library Overview and Architecture

The Maverick table operations library provides a comprehensive set of classes for handling tabulated data with interpolation capabilities. The library is organized around four main classes:

1. **`Rtable`**: Core class for one-dimensional interpolation tables mapping x values to vector y values
2. **`Rtable3d`**: Class for two-dimensional interpolation tables (3D data - x, y, z)
3. **`Rtablen<nrows, ncols>`**: Template class for serializable fixed-size tables
4. **`Dyn_rtable`**: Class for dynamically allocated tables built from serialized data

The library follows a consistent design pattern where tables can be constructed from different data sources:
- Memory blocks (`Mblock<const Real>`)
- Cross tables (`Xrtable`, `Xrtable3d`)
- Serialized data (via `Lossy_error`)

## 2. Rtable Class: One-Dimensional Interpolation

### 2.1 Core Structure and Memory Management

`Rtable` is the fundamental class for one-dimensional interpolation tables, mapping a list of sorted x values to corresponding y vectors:

```cpp
class Rtable {
private:
    const Base::Mblock<const Real> x;      // x Real values of table
    const Base::Mblock<const Real> y;      // y Real values of table
    const Uint16 esz;                      // Entry size (y rows)
    const Uint32& nentries;                // Number of entries (x size, y cols)
};
```

Key characteristics:
- Stores x values as a sorted array
- Stores y values as a matrix (each column corresponds to an x value)
- Does not own memory (uses `Mblock<const Real>` references)
- Supports vector-valued outputs (multiple y values per x value)

### 2.2 Construction and Initialization

`Rtable` can be constructed from:

1. **Xrtable template**:
   ```cpp
   template <Uint32 nrows, Uint32 ncols>
   explicit Rtable(const Base::Xrtable<nrows, ncols>& xrt);
   ```

2. **Memory blocks**:
   ```cpp
   Rtable(const Base::Mblock<const Real> xin,
          const Base::Mblock<const Real> yin);
   ```

During construction, the class validates that:
- The number of elements in y matches the product of entry size and number of entries
- The x values are sorted in non-descending order (enforced in `Dyn_rtable::build_from_PDI`)

### 2.3 Boundary Handling

`Rtable` provides methods to check and handle boundary conditions:

- **`wrap_x(Real& xi)`**: Wraps an input value within the table's x-range
- **`is_lower_bound(Real xi)`**: Checks if xi is below the table's minimum x value
- **`is_upper_bound(Real xi)`**: Checks if xi is above the table's maximum x value

### 2.4 Linear Interpolation Capabilities

`Rtable` offers multiple linear interpolation methods:

1. **Standard linear interpolation**:
   ```cpp
   bool interp1_linear(Real xi, Rvector& yi) const;
   bool interp1_linear(Real xi, Real& y) const;
   ```
   - Returns true if extrapolation was performed
   - Handles scalar and vector outputs

2. **Forced extrapolation**:
   ```cpp
   void interp1_linear_extrapolate(Real xi, Rvector& yi) const;
   void interp1_linear_extrapolate(Real xi, Real& y) const;
   ```
   - Always extrapolates if input is out of range
   - Handles scalar and vector outputs

3. **Previous point interpolation**:
   ```cpp
   bool interp1_prev(Real xi, Rvector& yi) const;
   ```
   - Uses the y values at the x point immediately preceding xi

4. **Inverse interpolation**:
   ```cpp
   void interp1_linear_1(Uint16 k, const Real& yi, Real& xi, bool extrapolate) const;
   ```
   - Finds x value corresponding to a given y value
   - Supports extrapolation if requested

### 2.5 Search Algorithms

`Rtable` implements efficient search algorithms:

1. **Binary search for x values**:
   ```cpp
   Uint32 xi_search(const Real xi) const;
   ```
   - Uses `Binary_search_lt` to find the index of the largest entry ≤ xi
   - O(log n) complexity

2. **Binary search for y values**:
   ```cpp
   Uint32 yi_search(Uint16 k, Real yi) const;
   ```
   - Finds the index of y value within a specific column
   - Handles both ascending and descending y values

### 2.6 Internal Helper Methods

`Rtable` includes several internal helper methods:

- **`interp1_linear0`**: Core linear interpolation implementation
- **`y_colref`**: Retrieves a memory block for a specific column
- **`intlin_1`**: Performs inverse linear interpolation

### 2.7 Numerical Stability Considerations

The implementation includes safeguards for numerical stability:

- **Overflow protection**: Checks if denominator is too small before division
- **Epsilon comparisons**: Uses `Const::EPS` for floating-point comparisons
- **Fallback mechanisms**: Provides safe defaults when interpolation is not possible

## 3. Rtable3d Class: Two-Dimensional Interpolation

### 3.1 Core Structure and Memory Management

`Rtable3d` extends the interpolation capabilities to two-dimensional tables, mapping (x,y) coordinates to z values:

```cpp
class Rtable3d {
private:
    const Base::Xrtable3d_params& params;  // Parameters for Xrtable3d
    const Base::Mblock<const Real> x;      // Memory block for x values
    const Base::Mblock<const Real> y;      // Memory block for y values
    const Base::Mblock<const Real> z;      // Memory block for z values
};
```

Key characteristics:
- Stores x, y, and z values as memory blocks
- Supports different interpolation methods via `params.i2method`
- Does not own memory (uses `Mblock<const Real>` references)

### 3.2 Construction and Initialization

`Rtable3d` can be constructed from:

1. **Xrtable3d template**:
   ```cpp
   template <Uint32 nxmax, Uint32 nymax>
   explicit Rtable3d(const Base::Xrtable3d<nxmax, nymax>& x3);
   ```

2. **Ixrtable3d_ref**:
   ```cpp
   explicit Rtable3d(const Base::Ixrtable3d_ref& x3);
   ```

### 3.3 Interpolation Methods

`Rtable3d` provides multiple interpolation methods:

1. **Method selection**:
   ```cpp
   Real interp2(Real x_i, Real y_j) const;
   ```
   - Selects interpolation method based on `params.i2method`

2. **Bilinear interpolation**:
   ```cpp
   Real interp2_bilinear(Real x_i, Real y_j) const;
   ```
   - Performs bilinear interpolation using a 2×2 subtable

3. **Nearest point interpolation**:
   ```cpp
   Real interp2_nearest(Real x_i, Real y_j) const;
   ```
   - Returns the z value at the nearest grid point

### 3.4 Helper Structures

`Rtable3d` uses two helper structures:

1. **`Htable`**: Header for subtable handling
   ```cpp
   struct Htable {
       Real value;     // Value queried
       Uint32 iprv;    // Index of lower element
       Uint32 inxt;    // Index of greater element
       Real vprv;      // Value at iprv
       Real vnxt;      // Value at inxt
   };
   ```
   - Stores indices and values for interpolation
   - Provides methods to calculate interpolation ratios

2. **`Subtable`**: Represents a 2×2 subtable for bilinear interpolation
   ```cpp
   struct Subtable {
       Htable xhead;   // x columns header
       Htable yhead;   // y rows header
       Real z00;       // z value for xprv, yprv
       Real z01;       // z value for xprv, ynxt
       Real z10;       // z value for xnxt, yprv
       Real z11;       // z value for xnxt, ynxt
   };
   ```
   - Extracts the four corner points needed for bilinear interpolation

### 3.5 Boundary Handling

`Rtable3d` provides methods to check and handle boundary conditions:

- **`is_in(Real x_i, Real y_j)`**: Checks if coordinates are within table bounds
- **`wrap_if_needed(Real& x_i, Real& y_j)`**: Wraps coordinates if extrapolation is disabled

## 4. Rtablen Class: Serializable Fixed-Size Tables

### 4.1 Core Structure and Memory Management

`Rtablen<nrows, ncols>` is a template class that combines an `Xrtable` with an `Rtable` to provide serialization capabilities:

```cpp
template <Uint32 nrows, Uint32 ncols>
class Rtablen {
public:
    Rtable t;                                  // Rtable instance
private:
    Base::Xrtable<nrows, ncols> x;             // Xrtable (Tnarray table)
};
```

Key characteristics:
- Fixed size determined by template parameters
- Owns its memory through the `Xrtable` member
- Provides a public `Rtable` instance for interpolation operations

### 4.2 Construction and Initialization

`Rtablen` is constructed with default values:

```cpp
Rtablen() : t(x) {
    x.nentries = 0;
}
```

### 4.3 Serialization and Deserialization

`Rtablen` provides comprehensive serialization capabilities:

1. **Full table serialization**:
   ```cpp
   void cget(Base::Lossy& str) const;
   void cset(Base::Lossy_error& str);
   ```
   - Serializes/deserializes the entire table

2. **Column-specific serialization**:
   ```cpp
   void cget_col(Base::Lossy& str, Uint16 col_cmd) const;
   void cset_col(Base::Lossy_error& str, Uint16 col_cmd);
   ```
   - Serializes/deserializes a specific column

All serialization operations delegate to the underlying `Xrtable` member.

## 5. Dyn_rtable Class: Dynamic Table Allocation

### 5.1 Core Structure and Memory Management

`Dyn_rtable` provides dynamic allocation of `Rtable` objects from serialized data:

```cpp
class Dyn_rtable {
private:
    const Rtable* rtable;                      // Pointer to dynamically allocated object
};
```

Key characteristics:
- Manages a pointer to a dynamically allocated `Rtable`
- Supports building tables from PDI (Protocol Data Interface) data
- Uses an external allocator for memory management

### 5.2 Construction and Initialization

`Dyn_rtable` can be constructed in two ways:

1. **Default constructor**:
   ```cpp
   Dyn_rtable();
   ```
   - Initializes with a singleton empty table

2. **From serialized data**:
   ```cpp
   void cset(Base::Lossy_error& str,
             Base::Allocator& alloc,
             const Uint16 vec_dim,
             const bool required_bijective);
   ```
   - Builds a table from serialized data
   - Uses the provided allocator for memory management

### 5.3 Table Building

`Dyn_rtable` provides a static method to build tables:

```cpp
static Rtable* build_from_PDI(Base::Lossy_error& str,
                              Base::Allocator& alloc,
                              const Uint16 vec_dim,
                              const bool required_bijective);
```

This method:
1. Deserializes the number of interpolation points
2. Allocates memory for x and y values
3. Deserializes x and y values
4. Validates that x values are sorted
5. Optionally validates bijectivity (monotonicity of y values)
6. Creates and returns a new `Rtable` instance

### 5.4 Table Access

`Dyn_rtable` provides access to the stored table:

```cpp
inline const Rtable& get() const {
    return *rtable;
}
```

## 6. Interpolation Algorithms in Detail

### 6.1 Linear Interpolation (1D)

The core linear interpolation algorithm in `Rtable::interp1_linear0` works as follows:

1. Calculate the denominator `den = x[j] - x[j-1]`
2. Calculate the numerator `num = xi - x[j-1]`
3. Check for potential overflow: `(amax_abs*Rmath::fabsr(den)) > Rmath::fabsr(num)`
4. If safe, calculate interpolation coefficient `a = num/den`
5. Compute linear combination: `yi = a*y[j] + (1-a)*y[j-1]`
6. If unsafe, use the value at index j

This algorithm includes safeguards against division by zero and numerical overflow.

### 6.2 Bilinear Interpolation (2D)

The bilinear interpolation algorithm in `Rtable3d::interp2_bilinear` works as follows:

1. Create a `Subtable` containing the four corner points
2. Calculate interpolation ratios for x and y dimensions
3. Apply the bilinear interpolation formula:
   ```
   z = z00 + (z10 - z00)*xf + (z01 - z00)*yf + ((z11 + z00) - z10 - z01)*xf*yf
   ```

This formula efficiently computes the interpolated value using only 7 arithmetic operations.

### 6.3 Nearest Point Interpolation (2D)

The nearest point algorithm in `Rtable3d::interp2_nearest` works as follows:

1. Find the nearest x index using `Htable::get_inear()`
2. Find the nearest y index using `Htable::get_inear()`
3. Return the z value at the combined index

### 6.4 Inverse Interpolation (1D)

The inverse interpolation algorithm in `Rtable::intlin_1` works as follows:

1. Calculate `num = yi - y[j-1]`
2. Calculate `div = y[j] - y[j-1]`
3. If `div` is significant, calculate interpolation coefficient `a = num/div`
4. Compute the interpolated x value: `x[j-1] + a*(x[j] - x[j-1])`

This algorithm handles the case where y values are used to find corresponding x values.

## 7. Error Handling and Parameter Validation

The library implements several error handling and validation mechanisms:

### 7.1 Runtime Assertions

- Memory block size validation: `Base::Assertions::runtime(y.sz == (esz*nentries))`
- Used to ensure memory blocks have the expected size

### 7.2 PDI Error Handling

- `str.assrt(ret != 0, Base::err_dyn_rtable_build_pdi)` in `Dyn_rtable::build_from_PDI`
- Raises a PDI error if table building fails

### 7.3 Input Validation

- Sorted x values: `ok &= (x[i-1] <= x[i])`
- Bijectivity check for y values when required

### 7.4 Numerical Safeguards

- Overflow protection: `(amax_abs*Rmath::fabsr(den)) > Rmath::fabsr(num)`
- Epsilon comparisons: `Rfun::comp_real(div, Const::ZERO, Const::EPS)`
- Division by zero protection

### 7.5 Boundary Handling

- Wrapping: `Rfun::wrap(x[0], x[params.nx-1], x_i, x_i)`
- Boundary checks: `is_lower_bound`, `is_upper_bound`, `is_in`

## 8. Serialization and Deserialization Format

### 8.1 Rtablen Serialization Format

The serialization format for `Rtablen` follows the `Xrtable` format:

```
[nentries: Uint16]
[x values: Array of Real with size nentries]
[y values: Array of Real with size nentries*nrows]
```

### 8.2 Dyn_rtable Serialization Format

The serialization format for `Dyn_rtable::build_from_PDI`:

```
[num_interp_points: Uint16]
[x values: Array of Real with size num_interp_points]
[y values: Array of Real with size num_interp_points*vec_dim]
```

## 9. Integration with Maverick Library Ecosystem

The table operations library integrates with other Maverick components:

### 9.1 Vector Operations

- Uses `Rvector` for vector-valued outputs
- Leverages vector operations like `copy()` and `lincmb()`

### 9.2 Memory Management

- Uses `Mblock` for memory block representation
- Uses `Allocator` for dynamic memory allocation

### 9.3 Serialization Framework

- Uses `Lossy` and `Lossy_error` for serialization/deserialization
- Compatible with PDI (Protocol Data Interface)

### 9.4 Mathematical Utilities

- Uses `Rfun` for mathematical operations
- Uses `Binary_search_lt` for efficient searching

## 10. Performance Considerations

The library includes several optimizations for performance:

### 10.1 Search Optimization

- Binary search for x values: O(log n) complexity
- Custom search algorithm for y values

### 10.2 Memory Efficiency

- Memory-less design: `Rtable` and `Rtable3d` don't own memory
- Fixed-size tables: `Rtablen` uses template parameters for compile-time sizing

### 10.3 Computational Efficiency

- Precomputed indices and values in `Htable` and `Subtable`
- Efficient bilinear interpolation formula
- Early exit conditions in search algorithms

### 10.4 Singleton Pattern

- `get_rtable()` provides a singleton empty table for initialization

## Referenced Context Files

The following context files provided useful information for understanding the table operations library:

- **05_Core_Vector_Operations.md**: Provided information about the Rvector class used for vector-valued outputs in the table operations library

## Summary

The Maverick table operations library provides a comprehensive set of classes for handling tabulated data with interpolation capabilities. The library supports one-dimensional and two-dimensional interpolation with various methods including linear, bilinear, and nearest point interpolation. It includes robust error handling, parameter validation, and numerical safeguards. The serialization capabilities enable efficient storage and transmission of table data. The library integrates seamlessly with the broader Maverick ecosystem, leveraging components like vectors, memory management, and serialization frameworks.