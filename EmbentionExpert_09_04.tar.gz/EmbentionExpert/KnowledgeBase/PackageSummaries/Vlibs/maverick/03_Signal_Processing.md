# Generated from:

- code/include/Biquad_iir_3d.h (627 tokens)
- code/include/Biquad_notch_lpf_3d.h (1381 tokens)
- code/include/Butterw_2.h (189 tokens)
- code/include/Diff_finite.h (361 tokens)
- code/include/Ewma.h (750 tokens)
- code/include/Ewma0.h (1009 tokens)
- code/include/Ewma_avgvar.h (903 tokens)
- code/include/Fastatan2.h (44 tokens)
- code/include/Fast_tanh.h (80 tokens)
- code/include/Fir.h (290 tokens)
- code/include/Fir3.h (252 tokens)
- code/include/IIR_2.h (1579 tokens)
- code/include/IIR_2cfg.h (180 tokens)
- code/include/IIR3_2.h (329 tokens)
- code/include/Iir.h (1021 tokens)
- code/include/Moving_average.h (408 tokens)
- code/include/Nllpf.h (203 tokens)
- code/include/Nllpfcfg.h (706 tokens)
- code/include/Notch_cfg.h (438 tokens)
- code/include/Notch_lpf_cfg.h (215 tokens)
- code/include/Ratelimiter.h (342 tokens)
- code/include/Rv1mean.h (200 tokens)
- code/include/Rv1means2.h (282 tokens)
- code/include/Weighted_average_filter.h (1185 tokens)
- code/source/Biquad_iir_3d.cpp (115 tokens)
- code/source/Biquad_notch_lpf_3d.cpp (1866 tokens)
- code/source/Butterw_2.cpp (547 tokens)
- code/source/Diff_finite.cpp (195 tokens)
- code/source/Ewma.cpp (144 tokens)
- code/source/Ewma_avgvar.cpp (899 tokens)
- code/source/Fast_tanh.cpp (144 tokens)
- code/source/Fastatan2.cpp (264 tokens)
- code/source/Fir.cpp (573 tokens)
- code/source/Fir3.cpp (408 tokens)
- code/source/IIR_2.cpp (890 tokens)
- code/source/IIR_2cfg.cpp (160 tokens)
- code/source/IIR3_2.cpp (245 tokens)
- code/source/Iir.cpp (1031 tokens)
- code/source/Moving_average.cpp (509 tokens)
- code/source/Nllpf.cpp (105 tokens)
- code/source/Nllpfcfg.cpp (726 tokens)
- code/source/Notch_cfg.cpp (1033 tokens)
- code/source/Notch_lpf_cfg.cpp (154 tokens)
- code/source/Ratelimiter.cpp (287 tokens)
- code/source/Rv1mean.cpp (119 tokens)
- code/source/Rv1means2.cpp (141 tokens)

## With context from:

- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/maverick/05_Core_Vector_Operations.md (2763 tokens)

---

# Comprehensive Summary of the Maverick Signal Processing Library

## 1. Functional Behavior and Logic

The Maverick signal processing library provides a comprehensive set of digital filters and signal processing utilities for real-time applications. The library implements various filter types with different characteristics and applications:

### Filter Types Overview

1. **IIR Filters**
   - **IIR_2**: Second-order IIR filter (biquad) with 2 poles and 2 zeros
   - **Biquad_iir_3d**: Applies biquad IIR filtering to 3D vector measurements
   - **Biquad_notch_lpf_3d**: Multiple biquad filters for notch filtering and low-pass filtering of 3D vectors
   - **IIR3_2**: Second-order IIR filter for 3D vectors
   - **Butterw_2**: Butterworth second-order filter coefficient calculator

2. **FIR Filters**
   - **Fir**: Base class for FIR filters with configurable order
   - **Fir3**: FIR filter for 3D vectors
   - **Weighted_average_filter**: Filter using weighted averages of inputs and outputs

3. **EWMA Filters**
   - **Ewma0**: Helper functions for EWMA filter calculations
   - **Ewma**: EWMA filter with configurable time constant
   - **Ewma_avgvar**: EWMA-based mean and variance estimator

4. **Specialized Filters**
   - **Diff_finite**: First-order finite difference method for numerical derivatives
   - **Moving_average**: Simple moving average filter
   - **Nllpf**: Non-linear low-pass filter
   - **Ratelimiter**: Limits the rate of change of a signal
   - **Notch_cfg**: Notch filter configuration

5. **Statistical Processing**
   - **Rv1mean**: Simple mean calculator
   - **Rv1means2**: Mean and variance calculator

6. **Fast Math Functions**
   - **Fast_tanh**: Fast approximation of hyperbolic tangent
   - **Fastatan2**: Fast approximation of atan2 function

### Common Filter Patterns

Most filters in the library follow similar patterns:
1. **Initialization**: Constructor sets up initial state and parameters
2. **Configuration**: Methods to set filter parameters (cutoff frequency, time constants, etc.)
3. **Processing**: Step functions that process inputs and update filter state
4. **Reset**: Methods to reset filter state to a known value
5. **Serialization**: Methods to save/load filter configuration from PDI (Parameter Data Interface)

## 2. Control Flow and State Transitions

### IIR Filter Processing Flow

```
[Input Signal] → [Apply Coefficients to Input] → [Combine with Previous States] → [Update States] → [Output Signal]
```

For IIR_2 filters:
1. Calculate output using current input and previous states:
   ```
   y0 = (u0*b0) + (u1*b1) + (u2*b2) - (y1*a1) - (y2*a2)
   ```
2. Update state variables:
   ```
   y2 = y1
   y1 = y0
   u2 = u1
   u1 = u0
   ```
3. Return filtered output

### Filter Initialization Flow

```
[Constructor] → [Set Default Parameters] → [Initialize States to Zero]
```

For filters with dynamic configuration:
```
[Constructor] → [Set Default Parameters] → [Initialize States] → [Config Method Called] → [Update Parameters] → [Recompute Coefficients]
```

### Notch Filter with Decimated Coefficient Updates

The `Biquad_notch_lpf_3d` class implements a special pattern for efficient coefficient updates:

| State | Trigger | Actions | Next State |
|-------|---------|---------|------------|
| Normal Operation | Decimation counter hits mask value | Recompute notch filter coefficients | Normal Operation |
| Normal Operation | Input received | Apply filters to input | Normal Operation |
| Uninitialized | First input received | Reset all filter states with input | Normal Operation |

## 3. Inputs and Stimuli

### Scalar Inputs

Most filters accept scalar `Real` inputs in their `step()` methods:

- **IIR_2**: `Real step(Real u0)` - Processes a single scalar input
- **Ewma**: `Real step(Real dt, Real in)` - Processes input with time step
- **Nllpf**: `Real step(Real dt, Real in)` - Processes input with time step
- **Ratelimiter**: `Real step(Real dt, Real in)` - Limits rate of change with time step
- **Diff_finite**: `Real step(const Real input)` - Computes derivative of input

### Vector Inputs

Several filters process 3D vector inputs:

- **Biquad_iir_3d**: `void step(Irvector3& x)` - Filters each component of 3D vector
- **Biquad_notch_lpf_3d**: `void step(Irvector3& x)` - Applies notch and LPF to 3D vector
- **IIR3_2**: `void step(Irvector3& x)` - Applies IIR filter to 3D vector
- **Fir3**: `void step3(const Irvector3& xyzk, Irvector3& dxyzk)` - Applies FIR filter to 3D vector

### Configuration Inputs

Filters are configured through dedicated configuration structures:

- **IIR_2cfg**: Configures IIR filters with enable flag and cutoff frequency
- **Notch_cfg**: Configures notch filters with harmonics, center frequency, bandwidth, and gain
- **Notch_lpf_cfg**: Combines notch and low-pass filter configurations
- **Nllpfcfg**: Configures non-linear low-pass filter with delta thresholds and alpha values

## 4. Outputs and Effects

### Filter Outputs

Most filters return the filtered value directly:

- **IIR_2**: Returns filtered scalar value
- **Ewma**: Returns filtered scalar value
- **Diff_finite**: Returns computed derivative

Vector filters typically modify the input vector in-place:

- **Biquad_iir_3d**: Modifies input vector with filtered values
- **IIR3_2**: Modifies input vector with filtered values

Some filters provide separate output parameters:

- **Fir3**: Takes input vector and separate output vector for derivatives

### Statistical Outputs

Statistical processors provide computed statistics:

- **Ewma_avgvar**: Provides estimated mean and variance through getter methods
- **Rv1means2**: Provides mean and can calculate bias and variance

## 5. Parameters and Configuration

### IIR Filter Parameters

**IIR_2::Coeffs**:
- `b0`, `b1`, `b2`: Numerator coefficients (current, previous, and two steps ago inputs)
- `a1`, `a2`: Denominator coefficients (previous and two steps ago outputs)

**IIR_2cfg**:
- `enable`: Boolean to enable/disable the filter
- `cutoff_freq`: Cutoff frequency in Hz

**Butterworth Filter Parameters** (computed by `Butterw_2::compute_coeffs`):
- Sampling frequency (`sampling_freq`)
- Cutoff frequency (`cutoff_freq`)
- Error handler for validation

### Notch Filter Parameters

**Notch_cfg**:
- `num_harmonics`: Number of harmonics to attenuate (0-2)
- `center_freq`: Center notch frequency in Hz
- `bandwidth`: Bandwidth of notch in Hz
- `notch_gain`: Desired gain of attenuated frequencies (0-1)

### EWMA Filter Parameters

**Ewma**:
- `tau`: Filter time constant in seconds
- `out_1`: Previous output value

**Ewma_avgvar::Time_cts**:
- `tau_v`: Time constant for mean's EWMA (default: 2s)
- `tau_s2`: Time constant for variance's EWMA (default: 20s)

### Non-linear Low-pass Filter Parameters

**Nllpfcfg**:
- `delta_min`: Minimum difference where filter acts
- `delta_max`: Maximum difference where filter acts
- `delta_min_alpha`: Effective alpha for delta_min
- `delta_max_alpha`: Effective alpha for delta_max
- `delta2alpha`: Precomputed factor for alpha computation

## 6. Error Handling and Contingency Logic

### Parameter Validation

Most filters validate their parameters and handle invalid inputs:

1. **IIR_2 and Butterworth Filters**:
   - Validate that cutoff frequency is greater than 0 and less than or equal to 1/4 of sampling frequency
   - If validation fails, reset coefficients to pass-through values and report error

2. **Notch Filter**:
   - Validate that center frequency is greater than bandwidth and less than sampling frequency
   - Validate that number of harmonics is within allowed range (0-2)
   - If validation fails, reset coefficients and report error

3. **EWMA Filter**:
   - Validate that time constant is non-negative
   - If negative, set to zero (pass-through)

### Filter State Management

Filters track their initialization state to handle the first input properly:

1. **IIR_2 and Biquad Filters**:
   - Track initialization with `int_state_ok` flag
   - On first input, reset filter state with input value
   - Prevents transient responses from zero initial conditions

2. **Ewma_avgvar**:
   - Uses internal chronometer to track initialization
   - On first input, sets mean to input and variance to initial value
   - Starts chronometer for subsequent time-based updates

### Numerical Stability

Several mechanisms ensure numerical stability:

1. **Butterworth Filter**:
   - Frequency range validation prevents unstable filter designs
   - Coefficient calculation uses stable bilinear transform

2. **Notch Filter**:
   - Validates Q factor calculations to prevent division by zero
   - Ensures bandwidth is positive and gain is between 0 and 1

3. **Moving Average**:
   - Implements incremental sum updates to minimize numerical errors

## 7. File-by-File Breakdown

### IIR Filter Files

#### `IIR_2.h/cpp`
- Defines `IIR_2` class for second-order IIR (biquad) filtering
- Provides `Coeffs` structure for filter coefficients
- Provides `State` class for managing filter state
- Implements step function for filtering scalar values

#### `IIR_2cfg.h/cpp`
- Defines configuration structure for IIR_2 filters
- Provides serialization/deserialization for filter parameters

#### `Biquad_iir_3d.h/cpp`
- Extends IIR_2 for filtering 3D vectors
- Maintains separate filter states for each vector component
- Provides reset and step functions for 3D vector processing

#### `Biquad_notch_lpf_3d.h/cpp`
- Implements multiple biquad filters for notch filtering and low-pass filtering
- Supports multiple harmonics for notch filtering
- Uses decimation for efficient coefficient updates
- Implements IFilter interface for 3D vectors

#### `IIR3_2.h/cpp`
- Wrapper for applying IIR_2 filters to 3D vectors
- Provides simplified interface for 3D vector filtering

#### `Butterw_2.h/cpp`
- Implements coefficient calculation for second-order Butterworth filters
- Validates frequency parameters for stability
- Computes coefficients using bilinear transform

### EWMA Filter Files

#### `Ewma0.h`
- Provides static helper functions for EWMA filter calculations
- Implements core EWMA algorithm with different parameter forms
- Includes special variant for maximum tracking

#### `Ewma.h/cpp`
- Implements EWMA filter with configurable time constant
- Provides methods for setting parameters and resetting state
- Supports serialization/deserialization

#### `Ewma_avgvar.h/cpp`
- Implements EWMA-based mean and variance estimator
- Tracks mean and variance of 3D signals
- Uses different time constants for mean and variance

### FIR Filter Files

#### `Fir.h/cpp`
- Base class for FIR filters
- Manages filter coefficients and input history
- Supports different filter orders (first, second, fourth)

#### `Fir3.h/cpp`
- Extends Fir for 3D vector filtering
- Maintains separate filter states for each vector component
- Provides methods for computing derivatives of 3D signals

#### `Weighted_average_filter.h`
- Template class for weighted average filtering
- Combines weighted inputs and outputs for filtering
- Supports arbitrary filter order

### Specialized Filter Files

#### `Diff_finite.h/cpp`
- Implements first-order finite difference method
- Computes numerical derivatives with filtering
- Configurable time step and cutoff frequency

#### `Moving_average.h/cpp`
- Implements simple moving average filter
- Uses circular buffer for efficient computation
- Maintains running sum for performance

#### `Nllpf.h/cpp` and `Nllpfcfg.h/cpp`
- Implements non-linear low-pass filter
- Adjusts filter response based on signal change rate
- Configurable thresholds and response curves

#### `Ratelimiter.h/cpp`
- Limits rate of change of signals
- Separate rising and falling rate limits
- Time-based limiting with configurable rates

#### `Notch_cfg.h/cpp` and `Notch_lpf_cfg.h/cpp`
- Configuration structures for notch and combined notch/LPF filters
- Implements coefficient calculation for notch filters
- Supports multiple harmonics

### Statistical Processing Files

#### `Rv1mean.h/cpp`
- Simple mean calculator for scalar values
- Implements recursive mean calculation

#### `Rv1means2.h/cpp`
- Calculates both mean and variance
- Implements numerically stable recursive algorithm

### Fast Math Files

#### `Fast_tanh.h/cpp`
- Fast approximation of hyperbolic tangent
- Uses polynomial approximation for performance

#### `Fastatan2.h/cpp`
- Fast approximation of atan2 function
- Uses polynomial approximation for performance

## 8. Cross-Component Relationships

### Filter Hierarchy

```
IIR_2 ─────┬─── Biquad_iir_3d ─── Biquad_notch_lpf_3d
           └─── IIR3_2

Fir ─────── Fir3

Ewma0 ───── Ewma ───── Ewma_avgvar
```

### Configuration Hierarchy

```
IIR_2cfg

Notch_cfg ─── Notch_lpf_cfg

Nllpfcfg
```

### Vector Library Integration

The signal processing library integrates with the vector library through:

1. **3D Vector Filters**:
   - `Biquad_iir_3d`, `IIR3_2`, and `Fir3` operate directly on `Irvector3` objects
   - They process each component (x, y, z) separately using the same filter parameters
   - Vector components are accessed using the vector library's indexing system

2. **Vector Operations**:
   - `Fir3` uses vector operations like `zeros()` and `scale()`
   - `Ewma_avgvar` uses vector operations for component-wise processing

3. **Memory Management**:
   - Filters respect the vector library's memory management patterns
   - Memory-less vectors are modified in-place
   - Memory-owning vectors are used for internal state

## 9. Referenced Context Files

The vector library context file provided valuable information about:

1. **Vector Class Hierarchy**:
   - Understanding of `Irvector3` and `Rvector3` classes used by the filters
   - Memory management patterns for vectors

2. **Vector Operations**:
   - Available operations that filters can use on vectors
   - Element access patterns for processing vector components

3. **Numerical Stability Considerations**:
   - Precision control mechanisms that complement filter stability measures
   - Error handling patterns consistent with the signal processing library

## Filter Initialization and Configuration Flow

The filter initialization and configuration flow follows a consistent pattern across the library:

1. **Construction**:
   - Initialize internal state variables
   - Set default parameters
   - Prepare memory for filter states

2. **Configuration**:
   - Receive configuration parameters
   - Validate parameters
   - Update internal configuration
   - Compute derived parameters (coefficients, etc.)

3. **Coefficient Calculation**:
   - Transform user parameters (frequency, time constant) to filter coefficients
   - Apply appropriate filter design formulas
   - Validate results for stability

4. **State Management**:
   - Track initialization state
   - Handle first input specially to avoid transients
   - Reset states when configuration changes

5. **Processing**:
   - Apply filter algorithm to inputs
   - Update internal states
   - Return filtered outputs

## Filter Processing Algorithms

### IIR Filter Algorithm

The core IIR filter algorithm implemented in `IIR_2::State::step`:

```cpp
Real y0 = (u0*c.b0) + (u1*c.b1) + (u2*c.b2) - (y1*c.a1) - (y2*c.a2);
y2 = y1;
y1 = y0;
u2 = u1;
u1 = u0;
return y0;
```

This implements the difference equation:
y[n] = b0*x[n] + b1*x[n-1] + b2*x[n-2] - a1*y[n-1] - a2*y[n-2]

### EWMA Filter Algorithm

The core EWMA algorithm implemented in `Ewma0::compute`:

```cpp
return out_prev + alpha*(in-out_prev);
```

This implements the exponentially weighted moving average:
y[n] = y[n-1] + α(x[n] - y[n-1])

Where α is calculated from time constant τ and time step dt:
α = dt/(τ+dt)

### Notch Filter Coefficient Calculation

The notch filter coefficients are calculated in `Notch_cfg::compute_coeffs`:

```cpp
const Real sqrtpow2octaves = two_center_freq / (two_center_freq - har_bandwidth);
const Real q = sqrtpow2octaves / ((sqrtpow2octaves*sqrtpow2octaves) - 1.0F);
const Real omega = (Const::PI * two_center_freq) / sample_freq;
const Real alpha = Rmath::sinr(omega) / (Const::TWO * q);
const Real a0_inv =  1.0F / (1.0F + alpha);
c.b0 = (1.0F + (alpha*notch_gain))*a0_inv;
c.b1 = -Const::TWO*Rmath::cosr(omega)*a0_inv;
c.b2 =  (1.0F - (alpha*notch_gain))*a0_inv;
c.a1 = c.b1;
c.a2 =  (1.0F - alpha)*a0_inv;
```

This implements a biquad notch filter with configurable center frequency, bandwidth, and notch depth.

### Butterworth Filter Coefficient Calculation

The Butterworth filter coefficients are calculated in `Butterw_2::compute_coeffs`:

```cpp
const Real fr = (cutoff_freq / sampling_freq);
const Real ohm = Rmath::tanr(Const::PI * fr);
const Real ohm2 = ohm*ohm;
const Real z = (Const::TWO*Rmath::cosr(Const::PI / Const::FOUR)*ohm) + ohm2;
const Real k = 1.0F + z;
c.b0 = ohm2 / k;
c.b1 = Const::TWO * c.b0;
c.b2 = c.b0;
c.a1 = Const::TWO*(ohm2 - 1.0F) / k;
c.a2 = (1.0F - z) / k;
```

This implements a second-order Butterworth low-pass filter using the bilinear transform.

## Conclusion

The Maverick signal processing library provides a comprehensive set of digital filters and signal processing utilities for real-time applications. It includes IIR filters (including biquad, Butterworth, and notch filters), FIR filters, EWMA filters, and specialized filters like rate limiters and non-linear low-pass filters. The library is designed for efficiency and numerical stability, with careful parameter validation and state management. It integrates seamlessly with the vector library for processing 3D vector signals, making it suitable for applications like sensor fusion, control systems, and signal conditioning in embedded systems.