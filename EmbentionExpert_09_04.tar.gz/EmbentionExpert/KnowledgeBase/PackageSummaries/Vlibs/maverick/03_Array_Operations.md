# Generated from:

- code/include/Find.h (1062 tokens)
- code/include/Find_scalar_zero_interval.h (653 tokens)
- code/include/Normalizer.h (335 tokens)
- code/include/Qsort.h (1182 tokens)
- code/include/Tarray.h (5709 tokens)
- code/source/Find_scalar_zero_interval.cpp (4317 tokens)

## With context from:

- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/maverick/05_Core_Vector_Operations.md (2763 tokens)

---

# Maverick Array Operations Library: Comprehensive Summary

## 1. Find Class - Binary Search Implementation

The `Find` class provides utilities for searching within sorted data structures, implementing an efficient binary search algorithm.

### Core Functionality
- **Binary Search**: The `sorted()` method locates the closest elements before and after a given value in a sorted array
- **Template Design**: Works with any data type through template parameters
- **Custom Comparators**: Supports custom comparison traits via the `LT_TRAIT` template parameter

### Algorithm Details
The `sorted()` method implements a binary search algorithm with the following steps:
1. Initialize search bounds (`imin` and `imax`)
2. Handle edge cases:
   - If target value is less than the first element, both indices point to the first element
   - If target value is greater than or equal to the last element, both indices point to the last element
3. Perform binary search by repeatedly:
   - Finding the midpoint between current bounds
   - Comparing the target value with the midpoint value
   - Adjusting search bounds accordingly
4. Return the indices of elements just before (`iprev`) and after (`inext`) the target value

### Usage Pattern
```cpp
Base::Mblock<T> sortedData;
Uint32 iprev, inext;
Find::sorted(sortedData, targetValue, iprev, inext);
```

### Special Cases
- **Exact Match**: When an exact match is found, `iprev` will have the index of the matching element
- **Out of Range**: 
  - If value < first element: both `iprev` and `inext` will be 0
  - If value ≥ last element: both `iprev` and `inext` will be size-1

## 2. Find_scalar_zero_interval Class - Root Finding

The `Find_scalar_zero_interval` class implements Brent's method for finding zeros (roots) of scalar functions within a closed interval.

### Core Functionality
- **Root Finding**: Locates where a function crosses zero within a specified interval
- **Brent's Method**: Combines bisection, secant method, and inverse quadratic interpolation for efficient and robust convergence
- **Configurable Tolerances**: Accepts function value tolerance and interval tolerance parameters

### Algorithm Details
The `find()` method implements Brent's method with the following key components:
1. **Initialization**:
   - Evaluate function at interval endpoints
   - Handle invalid intervals (when `x_min > x_max`)
   - Check for trivial solutions (endpoints near zero)

2. **Iterative Process**:
   - Maintain a bracketing interval [a, b] where f(a) and f(b) have opposite signs
   - Track previous step sizes for convergence acceleration
   - Choose between bisection and interpolation methods based on convergence criteria
   - Use inverse quadratic interpolation when possible for faster convergence
   - Fall back to bisection when interpolation is unreliable

3. **Convergence Criteria**:
   - Function value below tolerance: |f(x)| < tol_f
   - Interval width below tolerance: |a-b| < tol_x
   - Maximum iterations reached (100)

4. **Special Case Handling**:
   - When function values don't straddle zero, return the endpoint with smallest function value

### Usage Pattern
```cpp
// Create a derived class implementing the f(x) function
class MyFunction : public Find_scalar_zero_interval {
public:
    MyFunction(Real tol_f, Real tol_x) : Find_scalar_zero_interval(tol_f, tol_x) {}
    Real f(Real x) const override { return x*x - 4; } // Example: find sqrt(4)
};

// Use the finder
MyFunction finder(1e-6, 1e-6);
Real solution;
bool success = finder.find(0, 5, solution);
```

### Numerical Stability Features
- Careful handling of interpolation acceptance criteria
- Fallback to bisection when interpolation might be unstable
- Tolerance checks for both function value and interval width
- Special handling for cases where function values don't straddle zero

## 3. Normalizer Class - Value Normalization

The `Normalizer` class provides functionality to normalize values from an arbitrary range [min, max] to the standard range [0, 1].

### Core Functionality
- **Normalization**: Maps values from [min, max] to [0, 1]
- **Clamping**: Ensures output values stay within [0, 1] even if input is outside [min, max]

### Algorithm Details
The `normalize()` method implements a simple linear transformation:
1. Calculate the normalized position: (v - min) / (max - min)
2. Clamp the result to [0, 1] using `Rfun::wrap`

### Usage Pattern
```cpp
Real normalizedValue = Normalizer::normalize(minValue, maxValue, inputValue);
```

## 4. Qsort Class - Quick Sort Implementation

The `Qsort` class provides a template-based implementation of the quicksort algorithm for sorting arrays.

### Core Functionality
- **Array Sorting**: Sorts arrays of any type that defines comparison operators
- **Template Design**: Works with any array type that provides `[]` operator and `size()` method
- **Non-recursive Implementation**: Uses an explicit stack to avoid recursion

### Algorithm Details
The `sort()` method implements quicksort with the following components:

1. **Partitioning** (via `part()` method):
   - Selects the last element as pivot
   - Rearranges elements so that:
     - Elements less than or equal to pivot are on the left
     - Elements greater than pivot are on the right
   - Returns the final position of the pivot

2. **Iterative Sorting**:
   - Uses an explicit stack to track subarray bounds
   - Processes subarrays in order of decreasing size for efficiency
   - Partitions each subarray and pushes resulting subarrays onto the stack

### Usage Pattern
```cpp
ARRAY myArray;  // Any array-like type with [] and size()
Base::Mblock<int16> stack(myArray.size());  // Stack for non-recursive implementation
Qsort<ARRAY>::sort(myArray, stack);
```

### Memory Management
- Requires an external stack to be provided
- Stack size must be at least equal to the array size
- Uses runtime assertions to validate stack size

## 5. Tarray Class - Advanced Array Operations

The `Tarray` class extends the `Base::Array` class with a comprehensive set of array manipulation operations.

### Core Functionality
- **Array Creation**: Multiple constructors for different memory management strategies
- **Element-wise Operations**: Addition, subtraction, multiplication, division
- **Statistical Operations**: Finding minimum/maximum values and their positions
- **Linear Algebra**: Linear combinations, scaling, and vector operations

### Key Methods

#### Construction and Memory Management
- **Constructors**:
  - From memory block: `Tarray(Base::Mblock<T2> mb)`
  - From pointer and size: `Tarray(T* v0, Uint32 n0)`
  - With allocation: `Tarray(Uint32 n0, Base::Memmgr::Type memtype)`
  - With custom allocator: `Tarray(Uint32 n0, Base::Allocator& alloc)`

#### Statistical Operations
- **Value Range**:
  - `min_value()`: Returns minimum value in array
  - `max_value()`: Returns maximum value in array
  - `max_abs_value()`: Returns maximum absolute value
  - `span()`: Returns difference between last and first elements
  
- **Value Location**:
  - `find_min(T& a)`: Finds minimum value and its position
  - `find_max(T& a)`: Finds maximum value and its position

#### Element-wise Operations
- **Addition**:
  - `sum(y1, y2)`: Sets array to y1 + y2
  - `add(y1)`: Adds array y1 to this array
  - `add(y1)`: Adds constant y1 to all elements
  - `add(a1, y1)`: Adds scaled array a1*y1 to this array

- **Subtraction**:
  - `subtract(y1)`: Subtracts constant y1 from all elements
  - `subtract(y1, y2)`: Sets array to y1 - y2
  - `subtract(y1)`: Subtracts array y1 from this array

- **Multiplication/Division**:
  - `scale(a)`: Multiplies all elements by scalar a
  - `mul_wise(a)`: Element-wise multiplication with array a
  - `div_wise(a)`: Element-wise division by array a
  - `signinv()`: Inverts the sign of all elements

#### Linear Combinations
- `lincmb(a1, y1)`: Sets array to a1*y1
- `lincmb_add(a1, y1)`: Adds a1*y1 to this array
- `lincmb(a1, y1, a2, y2)`: Sets array to a1*y1 + a2*y2

### Implementation Details
- Uses pointer arithmetic for efficient traversal
- Implements operations using direct memory access for performance
- Supports template specialization for different data types
- Provides both in-place and result-producing operations

### Usage Pattern
```cpp
// Create arrays
Tarray<Real> arr1(10, Base::Memmgr::Type::HEAP);
Tarray<Real> arr2(10, Base::Memmgr::Type::HEAP);
Tarray<Real> result(10, Base::Memmgr::Type::HEAP);

// Fill with data
// ...

// Perform operations
result.sum(arr1, arr2);                // result = arr1 + arr2
result.lincmb(2.0, arr1, 3.0, arr2);   // result = 2*arr1 + 3*arr2
result.scale(0.5);                     // result *= 0.5

// Find statistics
Real minVal = result.min_value();
Real maxVal;
Uint32 maxPos = result.find_max(maxVal);
```

## 6. Integration and Error Handling

### Error Handling Patterns
1. **Runtime Assertions**:
   - Used to validate input parameters (e.g., stack size in `Qsort`)
   - Implemented via `Base::Assertions::runtime()`

2. **Return Values**:
   - `Find_scalar_zero_interval::find()` returns a boolean success indicator
   - Allows caller to handle failure cases appropriately

3. **Parameter Validation**:
   - Edge case handling in `Find::sorted()` for out-of-range values
   - Special case handling in `Find_scalar_zero_interval::find()` for invalid intervals

4. **Deleted Constructors/Operators**:
   - All classes prevent unintended copying with deleted copy constructors and assignment operators
   - Default constructors are deleted where they don't make sense

### Numerical Stability Considerations
1. **Tolerance Parameters**:
   - `Find_scalar_zero_interval` uses explicit tolerances for both function values and intervals
   - Allows application-specific control over precision requirements

2. **Brent's Method Implementation**:
   - Combines multiple root-finding techniques for robust convergence
   - Includes safeguards against numerical instability in interpolation

3. **Clamping in Normalization**:
   - `Normalizer::normalize()` ensures outputs stay within [0, 1]
   - Prevents downstream issues from out-of-range values

4. **Absolute Value Handling**:
   - `max_abs_value()` in `Tarray` uses `Rmath::fabsr()` for numerically stable absolute value calculation

## 7. Library Integration

The array operations library integrates with the broader Maverick ecosystem through:

1. **Base Types and Constants**:
   - Uses `Real`, `Uint32`, etc. from `Entypes.h`
   - Uses mathematical constants from `Const` namespace

2. **Memory Management**:
   - Integrates with `Base::Mblock` for memory blocks
   - Uses `Base::Allocator` for custom memory allocation
   - Supports different memory types via `Base::Memmgr::Type`

3. **Mathematical Utilities**:
   - Uses `Rmath` namespace for numerically stable math operations
   - Uses `Rfun` namespace for utility functions like `min`, `max`, `swap`

4. **Array Base Classes**:
   - `Tarray` extends `Base::Array` with additional functionality
   - Maintains compatibility with base array interfaces

5. **Template Patterns**:
   - Consistent use of templates allows integration with various data types
   - Support for custom comparison traits enables domain-specific sorting

## Summary

The Maverick array operations library provides a comprehensive set of utilities for array manipulation, searching, sorting, and numerical operations. The library is designed with a focus on efficiency, numerical stability, and flexibility through template-based implementations.

Key components include:
- `Find`: Binary search implementation for sorted arrays
- `Find_scalar_zero_interval`: Robust root-finding using Brent's method
- `Normalizer`: Value normalization and clamping
- `Qsort`: Non-recursive quicksort implementation
- `Tarray`: Extensive array manipulation operations

These components work together to provide a foundation for higher-level mathematical operations in the Maverick library ecosystem, supporting vector and matrix operations, numerical algorithms, and data processing tasks with a consistent interface and robust implementation.

## Referenced Context Files

The following context file provided useful information for understanding the array operations library:

1. **05_Core_Vector_Operations.md**: Provided context about how the array operations integrate with the vector operations in the Maverick library, particularly how `Tarray` serves as a foundation for vector classes.