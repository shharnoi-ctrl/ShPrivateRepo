# Generated from:

- code/include/Ivector.h (1158 tokens)
- code/include/Ivector2.h (1788 tokens)
- code/include/Ivector3.h (3180 tokens)
- code/include/Irvector2.h (1057 tokens)
- code/include/Irvector3.h (4398 tokens)
- code/include/Irvector3_fw.h (25 tokens)
- code/include/Ir64vector3.h (1313 tokens)
- code/include/Ir64vector3_fw.h (26 tokens)
- code/include/Rvector.h (1617 tokens)
- code/include/Rvector_fw.h (23 tokens)
- code/include/Rvector2.h (255 tokens)
- code/include/Rvector3.h (465 tokens)
- code/include/Rvector3_fw.h (24 tokens)
- code/include/Rvectorn.h (383 tokens)
- code/include/R64vector3.h (377 tokens)
- code/include/Tvector.h (5047 tokens)
- code/include/Tvectorn.h (428 tokens)
- code/include/Uvector.h (32 tokens)
- code/source/Rvector.cpp (446 tokens)
- code/source/Rvector2.cpp (163 tokens)
- code/source/Rvector3.cpp (416 tokens)
- code/source/R64vector3.cpp (395 tokens)
- code/source/Irvector3.cpp (2967 tokens)
- code/source/Ir64matrix3.cpp (619 tokens)

---

# Maverick Vector Library: Comprehensive Summary

## 1. Class Hierarchy and Design Patterns

The Maverick vector library provides a comprehensive set of vector classes with a clear hierarchical structure designed for efficient memory management and mathematical operations. The library is organized around two main types of vectors:

### Memory-less Vectors (Ivector Family)

These vectors don't own their memory but operate on externally provided memory:

- **`Ivector<T>`**: Base template class for memory-less vectors of any type and size
  - **`Ivector2<T>`**: Specialized for 2D vectors
    - **`Irvector2`**: Specialized for 2D Real vectors
  - **`Ivector3<T>`**: Specialized for 3D vectors
    - **`Irvector3`**: Specialized for 3D Real vectors
    - **`Ir64vector3`**: Specialized for 3D Real64 (double precision) vectors

### Memory-owning Vectors (Tvector/Rvector Family)

These vectors own and manage their memory:

- **`Tvector<T>`**: Base template class for memory-owning vectors of any type
  - **`Tvectorn<T, sz>`**: Fixed-size templated vector
  - **`Rvector`**: Specialized for Real values
    - **`Rvectorn<sz>`**: Fixed-size Real vector
    - **`Rvector2`**: 2D Real vector
    - **`Rvector3`**: 3D Real vector
  - **`Uvector`**: Specialized for Uint16 values
  - **`R64vector`**: Specialized for Real64 values
    - **`R64vector3`**: 3D Real64 vector

### Memory Management Patterns

1. **Memory-less Pattern**: 
   - Ivector family classes operate on externally provided memory
   - They don't allocate or deallocate memory
   - Used when memory is managed elsewhere or for temporary operations

2. **Memory-owning Pattern**:
   - Tvector/Rvector family classes manage their own memory
   - They can allocate memory using different strategies:
     - Static allocation (for fixed-size vectors)
     - Dynamic allocation with memory type
     - Dynamic allocation with custom allocator

3. **Constant Access Pattern**:
   - Each vector class has a nested `K` structure for constant access
   - Allows creating read-only views of vectors
   - Ensures const-correctness while maintaining efficiency

## 2. Vector Operations

### Element Access Operations

- **Indexing**: All vector classes support zero-based indexing via `operator[]`
- **Named Components**: 2D and 3D vectors provide named component access via enums:
  - 2D: `vx`, `vy`
  - 3D: `vx`, `vy`, `vz`

### Element-wise Operations

- **Initialization**:
  - `zeros()`: Set all elements to zero
  - `set_all()`: Set all elements to a given value
  - `copy()`: Copy from another vector or pointer

- **Arithmetic**:
  - `scale()`: Multiply all elements by a scalar
  - `signinv()`: Invert the sign of all elements
  - `inv()`: Compute the reciprocal of all elements
  - `abs()`: Compute the absolute value of all elements
  - `mul_wise()`: Element-wise multiplication of two vectors
  - `div_wise()`: Element-wise division by another vector

### Vector-Vector Operations

- **Addition/Subtraction**:
  - `vecsum()`: Add two vectors
  - `vecadd()`: Add another vector to this one
  - `vecres()`: Subtract one vector from another
  - `vecsub()`: Subtract another vector from this one
  - `vecresxy()`: Subtract only x and y components

- **Products**:
  - `dot()`: Compute dot product
  - `dotxy()`: Compute dot product of only x and y components
  - `cross()`: Compute cross product (3D vectors only)
  - `cross_axkn()`: Cross product with a vertical vector

### Norm Operations

- **Norm Calculations**:
  - `norm2()`: Euclidean (L2) norm
  - `norm22()`: Squared Euclidean norm
  - `norm2xy()`: Euclidean norm of x and y components
  - `norm22xy()`: Squared Euclidean norm of x and y components
  - `norm1()`: L1 norm (sum of absolute values)
  - `norminf()`: L∞ norm (maximum absolute value)

- **Normalization**:
  - `norm2alize()`: Normalize vector to unit length

### Matrix-Vector Operations

- **Matrix Multiplication**:
  - `matvec()`: Multiply matrix by vector
  - `matTvec()`: Multiply transpose of matrix by vector
  - `matthis()`: Multiply matrix by this vector
  - `matvec_add()`: Add result of matrix-vector multiplication
  - `matvec_sub()`: Subtract result of matrix-vector multiplication

### Linear Combination Operations

- **Linear Combinations**:
  - `lincmb(a, v)`: Compute a*v
  - `lincmb(a, v1, b, v2)`: Compute a*v1 + b*v2
  - `lincmb_add(a, v)`: Add a*v to this vector

### Coordinate Transformations

- **Spherical Coordinates**:
  - `azeld()`: Convert from Cartesian to spherical (azimuth, elevation, distance)
  - `azeld_1()`: Convert from spherical to Cartesian
  - `azimuth()`: Get azimuth angle
  - `elevation()`: Get elevation angle

### Quaternion Operations

- `qcq()`: Compute q1* × v × q2 (conjugate-quaternion-quaternion product)

### Filtering Operations

- `ewma_add()`: Add filtered increments with an EWMA filter

### Polynomial Evaluation

- `polynomial()`: Evaluate polynomial with vector coefficients

### Serialization/Deserialization

- `compress()`: Serialize vector to a PDIC
- `uncompress()`: Deserialize vector from a PDIC
- `cget()`: Serialize vector configuration
- `cset()`: Deserialize vector configuration

## 3. Memory Management Details

### Ivector Memory Management

The Ivector family doesn't own memory but operates on externally provided memory:

```cpp
template <typename T>
class Ivector {
protected:
    T* v; // Pointer to template where the elements of the vector are stored
};
```

Memory is provided through constructors:
```cpp
explicit Ivector(T* v0); // Points to externally provided memory
```

### Tvector Memory Management

The Tvector family inherits from Base::Tarray and manages its own memory:

```cpp
template <class T>
class Tvector: public Tarray<T> {
    // Memory management handled by Tarray
};
```

Memory can be allocated in several ways:
```cpp
Tvector(T* v0, Uint16 n0);                      // Use pre-allocated memory
Tvector(Uint16 n0, Base::Memmgr::Type memtype); // Allocate with memory type
Tvector(Uint16 n0, Base::Allocator& alloc);     // Allocate with custom allocator
```

### Fixed-Size Vector Memory Management

Fixed-size vectors like Rvector2, Rvector3, and Tvectorn<T, sz> use static arrays:

```cpp
template <Uint32 sz>
class Rvectorn : public Rvector {
private:
    Real data[sz]; // Static array for vector data
};
```

### Constant Access Pattern

The K structure pattern enables const-correct access to vectors:

```cpp
struct Irvector3::K {
    const Irvector3 kvec; // Constant handle for Irvector3
    
    explicit K(const Real* v);      // Construct from const pointer
    explicit K(const Base::Rv3& v); // Construct from const reference
};
```

This allows creating read-only views of vectors without copying data.

## 4. Error Handling and Parameter Validation

The library implements several error handling and validation mechanisms:

1. **Runtime Assertions**:
   - Memory block size validation: `Base::Assertions::runtime(mb.sz==sz);`
   - Used to ensure memory blocks have the expected size

2. **Preconditions**:
   - Some methods have explicit preconditions, e.g., `inv()` requires no zero elements
   - These are documented in comments but not enforced at runtime

3. **Const-correctness**:
   - The K structure pattern ensures const-correctness
   - Private constructors with const parameters prevent accidental modification

4. **Deleted Functions**:
   - Copy constructors and assignment operators are deleted to prevent unintended copying
   - Default constructors are deleted where they don't make sense

## 5. Numerical Stability Considerations

The library includes several features for numerical stability:

1. **Precision Control**:
   - Support for both single precision (Real) and double precision (Real64)
   - Conversion functions between precisions: `set_low_res()`

2. **Normalization**:
   - `norm2alize()` includes checks to avoid division by zero

3. **Zero Testing**:
   - `is_zero()` with configurable epsilon for floating-point comparisons

4. **Specialized Math Functions**:
   - Uses `Rmath` namespace functions optimized for numerical stability
   - `sqrtr()`, `sinr()`, `cosr()`, `atan2r()`, etc.

5. **EWMA Filtering**:
   - Exponentially Weighted Moving Average filtering for smooth updates

## 6. Vector Specializations

### 2D Vectors

2D vectors are specialized for operations in 2D space:

- **Components**: `vx`, `vy`
- **Special Operations**:
  - `dotxy()`: Dot product in 2D
  - `norm2xy()`: Norm in 2D

### 3D Vectors

3D vectors are specialized for operations in 3D space:

- **Components**: `vx`, `vy`, `vz`
- **Special Operations**:
  - `cross()`: Cross product
  - `azeld()`: Spherical coordinates
  - `qcq()`: Quaternion operations

### Real64 Vectors

Double precision vectors provide higher accuracy:

- **Precision**: 64-bit floating point
- **Conversion**: Can convert to/from single precision

## Referenced Context Files

The following context files provided useful information for understanding the vector library:

1. **Irmatrix3_fw.h**: Forward declaration of the Irmatrix3 class, used in matrix-vector operations
2. **Irquat_fw.h**: Forward declaration of the Irquat class, used in quaternion operations
3. **Lossy_fw.h**: Forward declaration for serialization support
4. **Mblock.h**: Memory block definitions used throughout the vector classes
5. **Tmem.h**: Memory operations used by vector classes
6. **Tarray.h**: Base array class for Tvector
7. **Tmatrix.h**: Matrix class used in matrix-vector operations

## Summary

The Maverick vector library provides a comprehensive set of vector classes with a clear hierarchical structure. It separates memory-less vectors (Ivector family) from memory-owning vectors (Tvector/Rvector family), enabling efficient memory management for different use cases. The library supports a wide range of vector operations, from basic arithmetic to advanced transformations, with specialized implementations for 2D and 3D vectors in both single and double precision. The constant access pattern using the K structure ensures const-correctness while maintaining efficiency.