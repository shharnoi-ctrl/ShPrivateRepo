# Generated from:

- code/include/Clarke.h (261 tokens)
- code/include/Inv_clarke.h (430 tokens)
- code/include/Inv_park.h (422 tokens)
- code/include/Park.h (406 tokens)
- code/include/Svgen.h (170 tokens)
- code/source/Clarke.cpp (161 tokens)
- code/source/Svgen.cpp (244 tokens)

## With context from:

- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/maverick/05_Core_Vector_Operations.md (2763 tokens)

---

# Maverick Coordinate Transformation Library: Comprehensive Summary

## 1. Overview of Coordinate Transformations in Motor Control

The Maverick library provides a comprehensive set of coordinate transformation classes essential for motor control and power electronics applications. These transformations convert between different reference frames, enabling efficient control of three-phase electrical systems. The library implements five key transformation classes:

1. **Clarke Transformation**: Converts three-phase stationary reference frame quantities (a,b,c) to two-phase stationary reference frame quantities (α,β)
2. **Inverse Clarke Transformation**: Converts two-phase stationary reference frame quantities (α,β) back to three-phase quantities (a,b,c)
3. **Park Transformation**: Converts two-phase stationary reference frame quantities (α,β) to rotating reference frame quantities (d,q)
4. **Inverse Park Transformation**: Converts rotating reference frame quantities (d,q) back to stationary reference frame quantities (α,β)
5. **Space Vector Generator (SVGEN)**: Generates three-phase switching functions from two-phase stationary reference frame quantities (α,β)

These transformations form a chain commonly used in field-oriented control (FOC) of motors and grid-connected power converters.

## 2. Clarke Transformation

### Purpose and Mathematical Foundation

The Clarke transformation converts three-phase quantities (a,b,c) in a stationary reference frame to two-phase orthogonal quantities (α,β) in a stationary reference frame. This reduces the dimensionality of the system while preserving all information.

### Class Structure and Implementation

```cpp
class Clarke {
public:
    Real alpha;     // Stationary d-axis stator variable
    Real beta;      // Stationary q-axis stator variable
    
    Clarke();       // Default constructor
    void step(const Real as, const Real bs, const Real cs);  // Transformation computation
    
private:
    Clarke(const Clarke& orig);                 // = delete
    Clarke& operator=(const Clarke& orig);      // = delete
};
```

### Initialization

The constructor initializes both output variables to zero:

```cpp
Clarke::Clarke() : alpha(0), beta(0)
{
}
```

### Transformation Algorithm

The `step` method implements the Clarke transformation using the following equations:

```cpp
void Clarke::step(const Real as, const Real bs, const Real cs)
{
    alpha = Const::ONETHIRD * (Const::TWO * as - bs - cs);
    beta = Const::ISQRT3 * (bs - cs);
}
```

Where:
- `Const::ONETHIRD` is 1/3
- `Const::TWO` is 2
- `Const::ISQRT3` is 1/√3

The mathematical transformation is:
- α = (2/3) × (a - (1/2)b - (1/2)c)
- β = (1/√3) × (b - c)

### Error Handling and Parameter Validation

The Clarke transformation does not include explicit error handling or parameter validation. It assumes valid input values and performs the transformation directly.

## 3. Inverse Clarke Transformation

### Purpose and Mathematical Foundation

The Inverse Clarke transformation converts two-phase orthogonal quantities (α,β) in a stationary reference frame back to three-phase quantities (a,b,c) in a stationary reference frame.

### Class Structure and Implementation

```cpp
class Inv_clarke {
public:
    Real a;        // Phase A voltage
    Real b;        // Phase B voltage
    Real c;        // Phase C voltage
    
    Inv_clarke();  // Default constructor
    void step(Real alpha, Real beta);  // Transformation computation
    
private:
    Inv_clarke(const Inv_clarke& orig);            // = delete
    Inv_clarke& operator=(const Inv_clarke& orig); // = delete
};
```

### Initialization

The constructor initializes all output variables to zero:

```cpp
inline Inv_clarke::Inv_clarke() : a(0), b(0), c(0)
{
}
```

### Transformation Algorithm

The `step` method implements the Inverse Clarke transformation using the following equations:

```cpp
inline void Inv_clarke::step(Real alpha, Real beta)
{
    a = alpha;
    b = Const::ONEHALF * (-alpha + Const::SQRT3 * beta);
    c = Const::ONEHALF * (-alpha - Const::SQRT3 * beta);
}
```

Where:
- `Const::ONEHALF` is 1/2
- `Const::SQRT3` is √3

The mathematical transformation is:
- a = α
- b = -0.5α + (√3/2)β
- c = -0.5α - (√3/2)β

### Error Handling and Parameter Validation

Like the Clarke transformation, the Inverse Clarke transformation does not include explicit error handling or parameter validation. It assumes valid input values and performs the transformation directly.

## 4. Park Transformation

### Purpose and Mathematical Foundation

The Park transformation converts two-phase quantities (α,β) in a stationary reference frame to two-phase quantities (d,q) in a rotating reference frame. This transformation is essential for field-oriented control as it allows control variables to appear as DC quantities in steady state.

### Class Structure and Implementation

```cpp
class Park {
public:
    Real ds;   // Rotating d-axis stator variable
    Real qs;   // Rotating q-axis stator variable
    
    Park();    // Default constructor
    void step(Real alpha, Real beta, const Maverick::Sincos& eangle);  // Transformation computation
    
private:
    Park(const Park& orig);                 // = delete
    Park& operator=(const Park& orig);      // = delete
};
```

### Initialization

The constructor initializes both output variables to zero:

```cpp
inline Park::Park() : ds(0), qs(0)
{
}
```

### Transformation Algorithm

The `step` method implements the Park transformation using the following equations:

```cpp
inline void Park::step(Real alpha, Real beta, const Maverick::Sincos& eangle)
{
    ds = eangle.dot(alpha, beta);
    qs = eangle.dot(beta, -alpha);
}
```

The transformation uses the `Sincos` class to perform the rotation, where:
- `eangle` contains the sine and cosine of the electrical angle
- `eangle.dot(alpha, beta)` computes α×cos(θ) + β×sin(θ)
- `eangle.dot(beta, -alpha)` computes β×cos(θ) - α×sin(θ)

The mathematical transformation is:
- d = α×cos(θ) + β×sin(θ)
- q = β×cos(θ) - α×sin(θ)

### Error Handling and Parameter Validation

The Park transformation relies on the `Sincos` class for angle representation and does not include explicit error handling or parameter validation. It assumes valid input values and a properly initialized `Sincos` object.

## 5. Inverse Park Transformation

### Purpose and Mathematical Foundation

The Inverse Park transformation converts two-phase quantities (d,q) in a rotating reference frame back to two-phase quantities (α,β) in a stationary reference frame.

### Class Structure and Implementation

```cpp
class Inv_park {
public:
    Real alpha;       // Stationary d-axis stator variable
    Real beta;        // Stationary q-axis stator variable
    
    Inv_park();       // Default constructor
    void step(Real ds, Real qs, const Maverick::Sincos& eangle);  // Transformation computation
    
private:
    Inv_park(const Inv_park& orig);                 // = delete
    Inv_park& operator=(const Inv_park& orig);      // = delete
};
```

### Initialization

The constructor initializes both output variables to zero:

```cpp
inline Inv_park::Inv_park() : alpha(0), beta(0)
{
}
```

### Transformation Algorithm

The `step` method implements the Inverse Park transformation using the following equations:

```cpp
inline void Inv_park::step(Real ds, Real qs, const Maverick::Sincos& eangle)
{
    alpha = eangle.dot(ds, -qs);
    beta = eangle.dot(qs, ds);
}
```

The transformation uses the `Sincos` class to perform the rotation, where:
- `eangle` contains the sine and cosine of the electrical angle
- `eangle.dot(ds, -qs)` computes d×cos(θ) - q×sin(θ)
- `eangle.dot(qs, ds)` computes q×cos(θ) + d×sin(θ)

The mathematical transformation is:
- α = d×cos(θ) - q×sin(θ)
- β = q×cos(θ) + d×sin(θ)

### Error Handling and Parameter Validation

Like the Park transformation, the Inverse Park transformation relies on the `Sincos` class and does not include explicit error handling or parameter validation. It assumes valid input values and a properly initialized `Sincos` object.

## 6. Space Vector Generator (SVGEN)

### Purpose and Mathematical Foundation

The Space Vector Generator (SVGEN) converts two-phase stationary reference frame quantities (α,β) into three-phase switching functions (ta, tb, tc) for pulse width modulation (PWM) in three-phase inverters. It implements the space vector modulation (SVM) technique, which optimizes harmonic performance and DC bus utilization.

### Class Structure and Implementation

```cpp
struct Svgen {
public:
    Real ta;   // reference phase-a switching function
    Real tb;   // reference phase-b switching function
    Real tc;   // reference phase-c switching function
    
    Svgen();   // Default constructor
    void step(Real ualpha, Real ubeta);  // Transformation computation
    
private:
    Svgen(const Svgen& orig);            // = delete
    Svgen& operator=(const Svgen& orig); // = delete
};
```

### Initialization

The constructor initializes all output variables to zero:

```cpp
Svgen::Svgen() : ta(0), tb(0), tc(0)
{
}
```

### Transformation Algorithm

The `step` method implements the Space Vector Generator using a sector identification and switching time calculation approach:

```cpp
void Svgen::step(Real ualpha, Real ubeta)
{
    static const Real bf = 0.5F;
    static const Real af = 0.866F;  // √3/2
    
    // Calculate intermediate values for sector identification
    Real tmp1 = ubeta;
    Real tmp2 = (ubeta * bf) + (af * ualpha);
    Real tmp3 = tmp2 - tmp1;

    // Identify sector (1-6) based on the location of the voltage vector
    int16 vsector = 3;
    vsector = (tmp2 > 0) ? (vsector-1) : vsector;
    vsector = (tmp3 > 0) ? (vsector-1) : vsector;
    vsector = (tmp1 < 0) ? (7-vsector) : vsector;

    // Calculate switching times based on the sector
    if ((vsector == 1) || (vsector == 4))
    {
        ta =  tmp2;
        tb =  tmp1 - tmp3;
        tc = -tmp2;
    }
    else if ((vsector == 2) || (vsector == 5))
    {
        ta =  tmp3 + tmp2;
        tb =  tmp1;
        tc = -tmp1;
    }
    else  // sectors 3 or 6
    {
        ta =  tmp3;
        tb = -tmp3;
        tc = -(tmp1 + tmp2);
    }
}
```

The algorithm:
1. Calculates intermediate values for sector identification
2. Determines which of the six sectors the voltage vector falls into
3. Calculates the switching times (ta, tb, tc) based on the sector

### Error Handling and Parameter Validation

The SVGEN implementation does not include explicit error handling or parameter validation. It assumes valid input values and performs the transformation directly.

## 7. Transformation Chain in Motor Control Applications

In motor control applications, these transformations are typically used in the following sequence:

1. **Measurement**: Three-phase currents (ia, ib, ic) are measured
2. **Clarke Transformation**: Converts (ia, ib, ic) to (iα, iβ)
3. **Park Transformation**: Converts (iα, iβ) to (id, iq) using rotor angle
4. **Control Algorithm**: Processes (id, iq) to produce (vd, vq)
5. **Inverse Park Transformation**: Converts (vd, vq) to (vα, vβ)
6. **Space Vector Generator**: Converts (vα, vβ) to switching signals (ta, tb, tc)
7. **PWM Generation**: Uses (ta, tb, tc) to generate PWM signals for the inverter

This chain allows for efficient control of AC motors using DC-like control variables (id, iq) in the rotating reference frame.

## 8. Mathematical Constants and Dependencies

The transformations rely on several mathematical constants defined in the `Const` namespace:

- `Const::ONETHIRD`: 1/3
- `Const::ONEHALF`: 1/2
- `Const::TWO`: 2
- `Const::SQRT3`: √3
- `Const::ISQRT3`: 1/√3

Additionally, the Park and Inverse Park transformations depend on the `Sincos` class, which encapsulates sine and cosine values of an angle and provides a `dot` method for efficient rotation calculations.

## 9. Numerical Stability Considerations

The implementation includes several considerations for numerical stability:

1. **Constant Definitions**: Using predefined constants like `ONETHIRD` and `SQRT3` ensures consistent values throughout the code
2. **Inline Functions**: Critical transformations are implemented as inline functions to reduce function call overhead
3. **Efficient Dot Product**: The `Sincos` class provides an optimized `dot` method for rotation calculations
4. **Sector-based Calculation**: The SVGEN implementation uses a sector-based approach to minimize computational complexity

## 10. Error Handling and Parameter Validation

The transformation classes do not implement explicit error handling or parameter validation. They assume:

1. Valid input values within the expected range
2. Properly initialized `Sincos` objects for Park and Inverse Park transformations
3. Correct usage of the transformation sequence

In a production environment, additional validation might be necessary depending on the application requirements.

## 11. Memory Management and Performance Considerations

The transformation classes are designed for efficiency in embedded systems:

1. **Minimal Memory Footprint**: Each class contains only the necessary output variables
2. **No Dynamic Memory Allocation**: All classes use static memory allocation
3. **Inline Functions**: Critical transformations are implemented as inline functions
4. **Deleted Copy Operations**: Copy constructors and assignment operators are deleted to prevent unintended copying
5. **Direct Output Access**: Output variables are public members for efficient access

## 12. Applications in Power Electronics

These transformations are fundamental in various power electronics applications:

1. **Field-Oriented Control (FOC)** of AC motors
2. **Direct Torque Control (DTC)** of AC motors
3. **Grid-Connected Inverters** for renewable energy systems
4. **Active Front End (AFE)** rectifiers
5. **Static VAR Compensators (SVC)** for power factor correction
6. **Uninterruptible Power Supplies (UPS)**

## Referenced Context Files

The following context file provided useful information for understanding the vector operations used in the coordinate transformations:

1. **05_Core_Vector_Operations.md**: Provided information about the vector operations used in the Maverick library, particularly the dot product operation used in Park and Inverse Park transformations.