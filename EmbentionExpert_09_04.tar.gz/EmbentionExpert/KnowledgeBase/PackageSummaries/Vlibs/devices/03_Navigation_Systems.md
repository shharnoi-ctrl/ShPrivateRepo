# Generated from:

- code/include/Garminlite.h (1001 tokens)
- code/include/Vn300.h (412 tokens)
- code/include/Vn300pkt.h (1107 tokens)
- code/include/Rawmea3.h (309 tokens)
- code/include/Rawpcfg.h (936 tokens)
- code/source/Garminlite.cpp (1685 tokens)
- code/source/Vn300.cpp (596 tokens)
- code/source/Vn300pkt.cpp (3640 tokens)
- code/source/Rawmea3.cpp (91 tokens)
- code/source/Rawpcfg.cpp (1404 tokens)

## With context from:

- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/devices/04_Sensor_Device_Framework.md (3568 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/devices/04_Communication_Protocols.md (3756 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/devices/04_Simulation_Framework.md (3965 tokens)

---

# Navigation System Drivers: Comprehensive Architecture and Functionality Analysis

This document provides a detailed analysis of the navigation system drivers, focusing on their architecture, functionality, and integration with the simulation framework. The drivers handle position, velocity, and attitude data from various navigation devices, implementing sophisticated state machines and parsing logic.

## 1. Garmin Lidar Lite v3 Driver

The `Garminlite` class implements a driver for the Garmin Lidar Lite v3 distance sensor, which communicates over I2C.

### 1.1 Architecture and Initialization

```cpp
class Garminlite : public Dsp28335_ent::I2Cdevice
{
public:
    Garminlite(const Lidar_i2c_params& params);
    // Methods and members...
};
```

The driver inherits from `I2Cdevice`, providing a standardized interface for I2C communication. It's initialized with `Lidar_i2c_params` that include:
- I2C interface reference
- Device address (default 0x62)
- Measurement output reference
- Filter reference
- Simulation device reference

### 1.2 State Machine Implementation

The driver implements a comprehensive state machine to manage the sensor's operation cycle:

```cpp
enum State
{
    s_cfg1,               // Initial configuration state
    s_cfg2,               // Second configuration state
    s_cfg3,               // Third configuration state
    s_start_measure,      // Start measurement command
    s_start_acquire,      // Start acquisition command
    s_query_busy,         // Query busy status
    s_read_busy,          // Read busy status
    s_check_busy,         // Check if device is busy
    s_read,               // Read measurement data
    s_gather,             // Process measurement data
    s_error,              // Error handling state
    s_error_disabled      // Permanently disabled after repeated errors
};
```

The state transitions are managed in the `do_step()` method, which is called periodically:

```cpp
void Garminlite::do_step()
{
    switch(state)
    {
        case s_cfg1:
            // Initialize device with acquisition count
            break;
        case s_cfg2:
            // Configure acquisition mode
            break;
        case s_cfg3:
            // Configure threshold bypass
            break;
        case s_start_acquire:
            // Start acquisition process
            break;
        case s_start_measure:
            // Trigger measurement
            break;
        case s_read:
            // Read measurement data
            break;
        case s_gather:
            // Process measurement data
            break;
        case s_error:
            // Handle errors with retry mechanism
            break;
        // Other states...
    }
}
```

### 1.3 Device Configuration Options

The driver supports multiple configuration profiles through the `Garmin_cfg` enumeration:

```cpp
enum Garmin_cfg
{
    balanced,     // Default mode, balanced performance
    sr_hs,        // Short range, high speed
    dr_hs,        // Default range, higher speed short range
    max_range,    // Maximum range
    high_sens,    // High sensitivity detection, high erroneous measurements
    low_sens      // Low sensitivity detection, low erroneous measurements
};
```

Each configuration profile sets specific values for:
- `adq_count`: Acquisition count register (0x02)
- `adq_mode`: Acquisition mode register (0x04)
- `threshold_bypass`: Threshold bypass register (0x1C)

### 1.4 Measurement Processing and Filtering

The driver implements sophisticated measurement processing:

1. **Range Delta Check**: Uses `Rangedeltacheck_nv` to validate measurements:
   - Checks if measurement is within valid range
   - Detects and handles non-varying measurements
   - Filters outliers

2. **IIR Filtering**: Applies a second-order IIR filter to smooth measurements

3. **Measurement Conversion**: Converts raw centimeter values to meters:
   ```cpp
   void Garminlite::set_meas(Real value)
   {
       simdev.replace_measure(value);
       if(dcheck.check_var(value, false) && dcheck.get_nv())
       {
           value = filter.step(value);
           measure.write(value);
           add_call();
       }
   }
   ```

### 1.5 Error Handling and Recovery

The driver implements a robust error handling mechanism:

1. **Retry Logic**: Attempts to recover from transient errors:
   ```cpp
   if(initialized && (retries_error < max_retries_error))
   {
       state = s_start_acquire;
       retries_error++;
       chr.tic();
   }
   ```

2. **Initialization Failure Handling**: Tracks consecutive initialization failures:
   ```cpp
   if(n_init_fails < max_fails)
   {
       state = s_cfg1;
       chr.tic();
       ++n_init_fails;
   }
   else
   {
       state = s_error_disabled;
   }
   ```

3. **Permanent Disabling**: After repeated failures, the device is permanently disabled

### 1.6 Simulation Integration

The driver seamlessly integrates with the simulation framework:

```cpp
void Garminlite::set_meas(Real value)
{
    simdev.replace_measure(value);
    // Process measurement...
}
```

This allows the driver to work with both real hardware and simulated values without changing its core logic.

## 2. VectorNav VN300 Driver

The `Vn300` class implements a driver for the VectorNav VN300 GNSS-aided inertial navigation system, which provides high-precision position, velocity, and attitude data.

### 2.1 Architecture and Initialization

```cpp
class Vn300: public Base::Itconsumer_u8
{
public:
    struct Params
    {
        Base::Hmeasnav& hm;
        volatile Real& freqvar;
        volatile Real& rawacc0;
        // Additional parameters...
    };
    explicit Vn300(const Params& par);
    // Methods...
};
```

The driver inherits from `Itconsumer_u8`, providing a byte-oriented consumer interface for receiving serial data. It's initialized with a `Params` structure that includes:
- Navigation measurement output reference
- Frequency variance reference
- Raw accelerometer and gyroscope data references
- Status flags references
- GNSS time reference

### 2.2 Data Reception and Processing

The driver receives data through the `write()` method, which passes bytes to the packet parser:

```cpp
bool Vn300::write(Uint8 data8)
{
    if (pkt.push(data8))
    {
        pkt.nav.gravity_included = true;
        data.hm.write(pkt.nav);
        data.rawacc0 = pkt.rawacc0;
        // Process additional data...
        
        const Uint16 filtered_status = pkt.status & status_mask;
        data.navigation_ok = (filtered_status == status_tracking_ok) ||
                        (data.navigation_ok && (filtered_status == status_aligning_ok));
        wdog.tic();
        freq.count();
    }
    return true;
}
```

When a complete packet is received and parsed, the driver:
1. Updates the navigation measurement structure
2. Updates raw accelerometer and gyroscope values
3. Updates status flags
4. Resets the watchdog timer
5. Updates the frequency counter

### 2.3 Status Monitoring

The driver monitors several status flags:

```cpp
static const Uint16 status_aligning_ok = 0x0001; // No errors and mode aligning
static const Uint16 status_tracking_ok = 0x0002; // No errors and mode tracking
static const Uint16 status_mask  = 0x0073;
static const Uint16 mode_mask    = 0x0003;
static const Uint16 gps_fix_mask = 0x0004;
static const Uint16 imu_err_mask = 0x0010;
static const Uint16 mp_err_mask  = 0x0020;
static const Uint16 gps_err_mask = 0x0040;
```

These flags are used to determine:
1. Current navigation mode (aligning or tracking)
2. GPS fix status
3. Error conditions (IMU, magnetometer/pressure, GPS)
4. Overall navigation validity

### 2.4 Watchdog Timer

The driver implements a watchdog timer to detect communication loss:

```cpp
void Vn300::step()
{
    if (!wdog.watch())
    {
        data.navigation_ok = false;
    }
    if (is_enabled())
    {
        data.freqvar = freq.step();
    }
}
```

If no valid packets are received within the timeout period (0.4 seconds), the navigation status is marked as invalid.

### 2.5 Frequency Monitoring

The driver monitors the packet reception frequency:

```cpp
Base::Freqmetric freq;
```

This allows the system to detect if the sensor is operating at the expected data rate.

## 3. VN300 Packet Parser

The `Vn300pkt` class implements a sophisticated parser for VectorNav binary protocol packets.

### 3.1 Architecture and Initialization

```cpp
class Vn300pkt
{
public:
    explicit Vn300pkt(volatile Base::Systime& gnsstime0);
    bool push(const Uint8 data);
    
    Base::Mnav nav;       // Navigation data structure
    Real rawacc0;         // Raw accelerometer measurements
    // Additional members...
};
```

The parser is initialized with a reference to the system time structure, which is updated with GNSS time when valid packets are received.

### 3.2 Packet Parsing State Machine

The parser implements a state machine to handle the VectorNav binary protocol:

```cpp
enum Pkt_sync
{
    pkt_sync0,        // Looking for sync byte (0xFA)
    pkt_sync1,        // Parsing common group mask
    pkt_sync2,        // Parsing common group first byte
    pkt_sync3,        // Parsing common group second byte
    pkt_sync4         // Parsing payload
};
```

The state transitions are managed in the `push()` method, which processes each incoming byte:

```cpp
bool Vn300pkt::push(const Uint8 data)
{
    bool ret = false;
    switch (static_cast<Pkt_sync>(sync_ok))
    {
        case pkt_sync0:
            // Check for sync byte (0xFA)
            break;
        case pkt_sync1:
            // Check for common group mask (0x01)
            break;
        case pkt_sync2:
            // Check for common group first byte (0xEA)
            break;
        case pkt_sync3:
            // Check for common group second byte
            break;
        case pkt_sync4:
            // Process payload bytes
            break;
    }
    return ret;
}
```

### 3.3 Partial Parsing State Machine

The parser uses a second state machine to handle the sequential parsing of different data fields:

```cpp
enum Partial_parsing
{
    pp_timegps,      // GPS time parsing
    pp_nav_ori_1,    // Orientation component 1 parsing
    pp_nav_ori_2,    // Orientation component 2 parsing
    // Additional states...
    pp_crc           // CRC value parsing
};
```

This state machine is driven by the `partial_parsing()` method, which is called as bytes are received:

```cpp
void Vn300pkt::partial_parsing()
{
    switch (parsing_st)
    {
        case pp_timegps:
            // Parse GPS time
            break;
        case pp_nav_ori_1:
            // Parse yaw angle
            break;
        // Additional cases...
    }
}
```

### 3.4 Data Extraction and Conversion

The parser extracts various navigation data fields from the packet:

1. **Time**: GPS time in nanoseconds
2. **Orientation**: Yaw, pitch, roll angles (converted from degrees to radians)
3. **Angular Velocity**: Body-frame angular rates
4. **Position**: Latitude, longitude, height (converted from degrees to radians for lat/lon)
5. **Velocity**: North, east, down velocity components
6. **Acceleration**: Body-frame accelerations
7. **Raw IMU Data**: Raw accelerometer and gyroscope readings
8. **Status**: Navigation status flags

### 3.5 CRC Validation

The parser validates packet integrity using a CRC-16 checksum:

```cpp
Uint16 crc_calc = crc.get_value();
if (crc_calc == crc_rx)
{
    // Process valid packet
    ret = true;
}
```

The CRC is configured with specific parameters:
- 16-bit CRC
- Polynomial: 33800
- Initial value: 0
- Final XOR: 0

### 3.6 GNSS Time Synchronization

When a valid packet with GPS fix is received, the parser updates the system time:

```cpp
Uint16 gpsweek = static_cast<Uint16>(timegps/weekns);
Uint64 gpstow = timegps - gpsweek*weekns;
static const Uint16 gps_fix_mask = 0x0004;  // GPS fix
if (status & gps_fix_mask)
{
    gnsstime.init(Base::Ubxtime::build(gpsweek,
                                       static_cast<Uint32>((gpstow)/nanotomillisec),
                                       0));
}
```

This synchronizes the system time with the GNSS time reference.

## 4. Raw Measurement Containers

### 4.1 Rawmea3 Structure

The `Rawmea3` structure provides a container for 3D raw measurements:

```cpp
struct Rawmea3
{
public:
    volatile Real& x;    // X raw measurement
    volatile Real& y;    // Y raw measurement
    volatile Real& z;    // Z raw measurement
    
    Rawmea3(volatile Real& x0, volatile Real& y0, volatile Real& z0);
    void zeros();
};
```

This structure is used to hold raw sensor measurements, such as accelerometer or gyroscope readings, and provides a method to reset all values to zero.

## 5. Raw Port Configuration

The `Rawpcfg` class provides a generic mechanism for configuring devices connected to a communication port:

```cpp
class Rawpcfg
{
public:
    Rawpcfg(Base::Itport_u8& port0, Uint16 cfgwords);
    bool on_start(const Base::Lossy& cfg);
    bool step_task();
    // Additional members...
};
```

### 5.1 Command Structure

The class defines several command types:

```cpp
enum Command
{
    cmd_wait  = 0,  // Wait for a specified time
    cmd_tx    = 1,  // Transmit data
    cmd_txurx = 2,  // Transmit and wait for response
    cmd_rx    = 3,  // Receive data
    cmd_none  = 0xFFFF
};
```

### 5.2 Command Processing

The class processes commands through a state machine:

```cpp
bool Rawpcfg::step_task()
{
    bool ret = true;
    switch(cmd)
    {
        case cmd_wait:
            ret = st.wait.step(*this) && !parse_nxt();
            break;
        case cmd_tx:
            ret = st.tx.step(*this) && !parse_nxt();
            break;
        case cmd_txurx:
            ret = st.txurx.step(*this) && !parse_nxt();
            break;
        case cmd_rx:
            ret = st.rx.step(*this) && !parse_nxt();
            break;
        default:
            Bsp::warning();
            break;
    }
    return ret;
}
```

### 5.3 Command Implementations

The class implements several command handlers:

1. **Wait Command**: Waits for a specified time
   ```cpp
   struct Rwait
   {
       Real timeout;
       bool cset(Rawpcfg& raw);
       bool step(const Rawpcfg& raw) const;
   };
   ```

2. **Transmit Command**: Sends data to the port
   ```cpp
   struct Rtx
   {
       Uint16 ntx;
       Uint8 buf[buffersz];
       Uint16 i;
       bool cset(Rawpcfg& raw);
       bool step(const Rawpcfg& raw);
       void reset(const Rawpcfg& raw);
   };
   ```

3. **Receive Command**: Waits for specific data from the port
   ```cpp
   struct Rrx
   {
       bool ignore_all;
       Uint8 ignore0;
       Uint8 ignore1;
       Real timeout;
       Uint16 nrx;
       Uint8 buf[buffersz];
       Uint16 i;
       bool cset(Rawpcfg& raw);
       bool step(Rawpcfg& raw);
       void reset(Rawpcfg& raw);
   };
   ```

4. **Transmit-Until-Receive Command**: Sends data and waits for a response
   ```cpp
   struct Rtxrx
   {
       Rtx tx;
       Rrx rx;
       bool txpending;
       bool cset(Rawpcfg& raw);
       bool step(Rawpcfg& raw);
       void reset(Rawpcfg& raw);
       bool success() const;
   };
   ```

5. **Retry Wrapper**: Adds retry capability to any command
   ```cpp
   template<typename T>
   struct Rretry
   {
       T base;
       Uint16 retries;
       Uint16 r;
       bool cset(Rawpcfg& raw);
       bool step(Rawpcfg& raw);
   };
   ```

## 6. Cross-Component Integration

### 6.1 Integration with Simulation Framework

The navigation drivers integrate with the simulation framework to support both real hardware and simulated operation:

1. **Garmin Lidar Integration**:
   ```cpp
   void Garminlite::set_meas(Real value)
   {
       simdev.replace_measure(value);
       // Process measurement...
   }
   ```

2. **VN300 Integration**:
   The VN300 driver doesn't directly integrate with the simulation framework, as it's primarily a data consumer. However, the system can be configured to use simulated navigation data instead of the VN300 driver.

### 6.2 Integration with Measurement System

Both drivers integrate with the measurement system to provide processed sensor data:

1. **Garmin Lidar**:
   ```cpp
   measure.write(value);
   ```

2. **VN300**:
   ```cpp
   data.hm.write(pkt.nav);
   ```

### 6.3 Integration with Communication Framework

The drivers integrate with different communication interfaces:

1. **Garmin Lidar**: Uses I2C communication through the `I2Cdevice` base class
2. **VN300**: Uses serial communication through the `Itconsumer_u8` interface

## 7. Error Handling and Validation

### 7.1 Garmin Lidar Error Handling

1. **Retry Mechanism**: Attempts to recover from transient errors
   ```cpp
   if(initialized && (retries_error < max_retries_error))
   {
       state = s_start_acquire;
       retries_error++;
       chr.tic();
   }
   ```

2. **Initialization Failure Handling**: Tracks consecutive initialization failures
   ```cpp
   if(n_init_fails < max_fails)
   {
       state = s_cfg1;
       chr.tic();
       ++n_init_fails;
   }
   else
   {
       state = s_error_disabled;
   }
   ```

3. **Measurement Validation**: Uses `Rangedeltacheck_nv` to validate measurements
   ```cpp
   if(dcheck.check_var(value, false) && dcheck.get_nv())
   {
       // Process valid measurement
   }
   ```

### 7.2 VN300 Error Handling

1. **Watchdog Timer**: Detects communication loss
   ```cpp
   if (!wdog.watch())
   {
       data.navigation_ok = false;
   }
   ```

2. **Status Monitoring**: Tracks various error conditions
   ```cpp
   data.imu_error = pkt.status & imu_err_mask;
   data.mp_error  = pkt.status & mp_err_mask;
   data.gps_error = pkt.status & gps_err_mask;
   ```

3. **CRC Validation**: Ensures packet integrity
   ```cpp
   Uint16 crc_calc = crc.get_value();
   if (crc_calc == crc_rx)
   {
       // Process valid packet
   }
   ```

## 8. Performance Considerations

### 8.1 Garmin Lidar Performance

1. **Sampling Rate**: Operates at approximately 10 Hz
   ```cpp
   static const Uint16 desired_rate_u = 10U;
   static const Real desired_rate = static_cast<Real>(desired_rate_u);
   ```

2. **Filtering**: Uses a second-order IIR filter to smooth measurements
   ```cpp
   value = filter.step(value);
   ```

3. **Startup Time**: Accounts for device startup time
   ```cpp
   static const Real start_time = 0.025F;  // 25ms startup
   ```

### 8.2 VN300 Performance

1. **Frequency Monitoring**: Tracks packet reception frequency
   ```cpp
   data.freqvar = freq.step();
   ```

2. **Timeout Handling**: Uses a 0.4-second timeout for communication loss detection
   ```cpp
   static const Real tout0 = 0.4F;
   ```

3. **Filtering**: No explicit filtering in the driver, as the VN300 performs internal filtering

## 9. State Machine Diagrams

### 9.1 Garmin Lidar State Machine

```
[s_cfg1] --> [s_cfg2] --> [s_cfg3] --> [s_start_acquire]
    ^                                        |
    |                                        v
[s_error] <-- [s_gather] <-- [s_read] <-- [s_start_measure]
    |
    v
[s_error_disabled]
```

### 9.2 VN300 Packet Parser State Machine

```
[pkt_sync0] --> [pkt_sync1] --> [pkt_sync2] --> [pkt_sync3] --> [pkt_sync4]
    ^                                                               |
    |                                                               v
    +---------------------------------------------------------------+
```

## 10. Referenced Context Files

The following context files provided useful information for understanding the navigation system drivers:

1. **Sensor Device Framework**: Provided context on the overall sensor device architecture, including I2C device management and filtering mechanisms.

2. **Communication Protocols**: Provided context on the communication interfaces used by the navigation drivers, including I2C and UART protocols.

3. **Simulation Framework**: Provided context on how the navigation drivers integrate with the simulation system, allowing for testing without physical hardware.

These context files helped to understand how the navigation drivers fit into the broader system architecture and how they interact with other components.