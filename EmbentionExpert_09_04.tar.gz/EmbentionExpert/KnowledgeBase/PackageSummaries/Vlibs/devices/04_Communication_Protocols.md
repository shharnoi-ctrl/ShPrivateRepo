# Generated from:

- code/include/SC18IM704.h (2568 tokens)
- code/include/Sxp.h (1493 tokens)
- code/include/Sxp_ioctl.h (278 tokens)
- code/source/SC18IM704.cpp (6292 tokens)
- code/source/Sxp.cpp (880 tokens)

---

# Communication Protocol Implementations in Device Drivers

This document provides a comprehensive analysis of the communication protocol implementations used by device drivers in the system, focusing on I2C, SPI, and UART interfaces.

## 1. Overview of Communication Architecture

The system implements a layered communication architecture that abstracts hardware-specific details from higher-level device drivers. The code reveals two primary communication interface implementations:

1. **SC18IM704** - A UART-to-I2C bridge controller that allows I2C device communication over a UART interface
2. **Sxp (SCI Expander)** - A dual-UART controller implementation using the XR20M1172 chip

These implementations provide standardized interfaces for device drivers to communicate with hardware peripherals without needing to understand the underlying protocol details.

## 2. SC18IM704 UART-to-I2C Bridge Implementation

### 2.1 Architecture and Abstraction

The `SC18IM704` class implements the `Base::Itport_u8` interface, providing a byte-oriented port abstraction for I2C communication over UART. This allows I2C devices to be accessed through a standard UART interface.

```cpp
class SC18IM704 : public Base::Itport_u8
{
    // Implementation details
};
```

### 2.2 Device Registration and Management

The SC18IM704 supports multiple I2C devices through a registration mechanism:

```cpp
bool add_device(Base::Itport_u8& dev, Uint16 address);
```

Devices are stored in an array with their I2C addresses:

```cpp
struct Device
{
    Uint8 i2c_read_len;     ///< Number of bytes to read from I2C device.
    Base::Itport_u8* port;  ///< Port to transmit/receive data to device.
    Uint8 address;          ///< I2C address for the given device.
};

Base::Array<Device> devices;  ///< Devices array.
```

The implementation limits the number of devices to a maximum of 2:

```cpp
static const Uint8 max_devices = 2;  ///< Max number of devices that can be added.
```

### 2.3 Communication State Machine

The SC18IM704 implements a sophisticated state machine to manage the communication flow between UART and I2C interfaces:

```cpp
enum States
{
    st_idle,            ///< Idle state.
    st_i2c_writing,     ///< Reading data from current device and writing to i2c bus.
    st_transfer,        ///< Transfer state.
    st_i2c_reading,     ///< Reading data from i2c device and writing to device.
    st_write_reg,       ///< Writing to internal register.
    st_read_reg,        ///< Reading internal register.
    st_error            ///< Error.
};
```

The state machine is driven by the `step_hi()` method, which is called as a high-priority task to process communication:

```cpp
void step_hi();
```

#### State Machine Transitions

1. **Idle State (`st_idle`)**: 
   - Checks if there are registered devices and if configuration is complete
   - Initiates I2C read or write operations based on device needs
   - Transitions to appropriate states based on operation type

2. **I2C Writing State (`st_i2c_writing`)**: 
   - Reads data from the device port
   - Writes data to the I2C bus
   - Transitions to `st_transfer` when complete

3. **Transfer State (`st_transfer`)**: 
   - Waits for the send operation to complete
   - Transitions back to `st_idle` when done

4. **I2C Reading State (`st_i2c_reading`)**: 
   - Reads data from the I2C bus
   - Writes data to the device port
   - Transitions to `st_idle` when all bytes are read

5. **Register Operations (`st_write_reg`, `st_read_reg`)**: 
   - Handles internal register access operations
   - Transitions to `st_idle` when complete

6. **Error State (`st_error`)**: 
   - Entered when communication errors occur
   - Triggers a warning

### 2.4 Configuration State Machine

In addition to the communication state machine, the SC18IM704 implements a separate configuration state machine to handle device initialization:

```cpp
enum Config_state
{
    cfg_start,          ///< Start device configuration.
    cfg_check_id,       ///< Check identifier configuration.
    cfg_i2c_speed,      ///< Configure I2C speed.
    cfg_i2c_timeout,    ///< Configure I2C timeout.
    cfg_baud,           ///< Configure baudrate.
    cfg_gpio,           ///< Configure GPIOs.
    cfg_ready           ///< Configuration ready.
};
```

This state machine ensures proper initialization sequence:
1. Start configuration
2. Check device ID
3. Configure I2C speed (375 kHz)
4. Configure I2C timeout
5. Configure UART baudrate (9600 baud)
6. Configure GPIO pins
7. Mark configuration as ready

### 2.5 I2C Command Protocol

The SC18IM704 uses a specific command protocol to communicate with I2C devices:

```cpp
enum Commands
{
    I2C_start = 0x53,   ///< I2C-bus START.
    End_frame = 0x50,   ///< I2C-bus STOP and end frame command.
    Read_reg = 0x52,    ///< Read SC18IM704 internal register.
    Write_reg = 0x57,   ///< Write to SC18IM704 internal register.
    Read_gpio = 0x49,   ///< Read GPIO port.
    Write_gpio = 0x4F,  ///< Write to GPIO port.
    Power_down = 0x5A   ///< Power down.
};
```

I2C operations are initiated with specific command sequences:

```cpp
void start_i2c_request(Uint8 address, Uint8 len)
{   
    if (state == st_idle)
    {
        send_buffer.write(I2C_start);
        send_buffer.write(address << 1U);
        send_buffer.write(len);
        state = st_i2c_writing;
    }
}

void start_i2c_read(Uint8 address, Uint8 len)
{   
    if (len > 0)
    {
        send_buffer.write(I2C_start);
        send_buffer.write((address << 1U) | 0x01U);
        send_buffer.write(len);
        state = st_i2c_reading;
    }
    send_buffer.write(End_frame);
}
```

### 2.6 Error Handling and Status Monitoring

The SC18IM704 implements error detection through I2C status codes:

```cpp
enum I2C_status
{
    I2C_OK = 0xF0,                  ///< I2C frame transmitted correctly.
    I2C_NACK_ON_ADDRESS = 0xF1,     ///< I2C nack on address error.
    I2C_NACK_ON_DATA = 0xF2,        ///< I2C nack on data error.
    I2C_TIME_OUT = 0xF8             ///< I2C timeout error.
};
```

The implementation also uses timeouts to detect and recover from communication failures:

```cpp
Base::Timeout res_tout;            ///< Timeout to reset to ::st_idle if bytes are not sent/received.
Base::Timeout init_cfg_tout;       ///< Timeout for detecting invalid baudrate
```

If a timeout occurs during communication, the state machine resets to idle:

```cpp
if ((state != st_idle) && res_tout.expired())
{
    state = st_idle;
    res_tout.start();
}
```

### 2.7 Data Buffering

The SC18IM704 uses FIFO buffers for data transfer:

```cpp
Base::U8pkfifospsc send_buffer;    ///< FIFO to send the data.
Base::U8pkfifospsc recv_buffer;    ///< Receive buffer
```

These buffers are initialized with specific sizes:

```cpp
static const Uint8 recv_buffer_sz = dev_id_len;     ///< Receive buffer size.
static const Uint8 send_buffer_sz = 12U;            ///< Send buffer size.
```

## 3. SXP (SCI Expander) Implementation

### 3.1 Architecture and Abstraction

The `Sxp` class provides a higher-level abstraction for dual UART communication using the XR20M1172 chip:

```cpp
class Sxp
{
    // Implementation details
};
```

It exposes two UART ports through a `Tport` interface:

```cpp
typedef Base::Tport<Base::U8pkfifospsc, Base::U8pkfifospsc> Tport_uart;
typedef Base::Port_stats_itport_wrap<Tport_uart> Tport_uart_sts;
```

### 3.2 Port Configuration and Management

The SXP implementation manages two UART channels:

```cpp
Tport_uart port0;                                   ///< Port0 Rx/Tx port.
Tport_uart port1;                                   ///< Port1 Rx/Tx port.

Tport_uart_sts port0_sts;                           ///< Port0 Rx/Tx statistics port.
Tport_uart_sts port1_sts;                           ///< Port1 Rx/Tx statistics port.
```

Each port can be configured independently:

```cpp
bool config(Dsp28335_ent::SCIcfg cfg, Xr20m1172::Channel chn);
```

The `Sxp_ioctl` class provides an adapter that implements the `ISCI_ioctl` interface for each channel:

```cpp
class Sxp_ioctl: public Dsp28335_ent::ISCI_ioctl
{
public:
    Sxp_ioctl(Sxp& sxp0, Xr20m1172::Channel chn0);
    virtual void config(const Dsp28335_ent::SCIcfg& cfg0);
    Sxp::Tport_uart_sts& get_port();
private:
    Sxp& sxp;                       ///< SCI Expander handler
    Xr20m1172::Channel chn_id;      ///< SCI Expander channel identifier
};
```

### 3.3 Data Transfer and Buffering

The SXP implementation uses FIFO buffers for each channel:

```cpp
Base::Array<Base::U8pkfifospsc> fifos_rx;           ///< FIFO for received data on both ports.
Base::Array<Base::U8pkfifospsc> fifos_tx;           ///< FIFO for transmission data on both ports.
```

It also uses a working memory block for data transfer:

```cpp
Base::U8pkrszarray<max_bytes_step> buf;             ///< Working memory block (use to handle data).
```

### 3.4 Communication Processing

The SXP implementation processes communication through the `step()` method:

```cpp
void step();
```

This method calls `step_ch()` for each UART channel:

```cpp
void step_ch(Xr20m1172::Channel chn_id);
```

The `step_ch()` method handles data transfer between the FIFO buffers and the hardware:

1. **Transmit Path**:
   - Checks if there's data to transmit in the TX FIFO
   - Transfers data from the TX FIFO to the working buffer
   - Sends data through the SPI interface to the XR20M1172

2. **Receive Path**:
   - Checks if the RX FIFO has space available
   - Reads data from the XR20M1172 through SPI
   - Transfers data from the working buffer to the RX FIFO

### 3.5 Performance Monitoring

The SXP implementation includes performance monitoring through port statistics:

```cpp
volatile Real& rxr_ch0;         ///< Channel 0 RX rate.
volatile Real& txr_ch0;         ///< Channel 0 TX rate.
volatile Real& rxr_ch1;         ///< Channel 1 RX rate.
volatile Real& txr_ch1;         ///< Channel 1 TX rate.
```

These statistics are updated through the `Port_stats_itport_wrap` class.

## 4. Common Communication Patterns

### 4.1 Interface Abstraction

Both implementations use interface abstraction to provide a consistent API for device drivers:

- `SC18IM704` implements the `Base::Itport_u8` interface
- `Sxp` provides access to ports that implement the `Tport_uart` interface

This abstraction allows device drivers to use a common interface regardless of the underlying communication protocol.

### 4.2 State Machine-Based Communication

Both implementations use state machines to manage communication flow:

- `SC18IM704` uses a complex state machine for UART-to-I2C bridging
- `Sxp` uses a simpler approach with the `step_ch()` method for each channel

### 4.3 Buffering and Data Transfer

Both implementations use FIFO buffers for data transfer:

- `SC18IM704` uses `send_buffer` and `recv_buffer`
- `Sxp` uses arrays of FIFOs for each channel

### 4.4 Error Handling

Both implementations include error handling mechanisms:

- `SC18IM704` uses timeouts and status codes
- `Sxp` uses assertions and a PBIT (Power-on Built-in Test) flag

## 5. Integration with Higher-Level Device Drivers

### 5.1 Device Registration

The `SC18IM704` allows device drivers to register through the `add_device()` method:

```cpp
bool add_device(Base::Itport_u8& dev, Uint16 address);
```

This method associates a device with an I2C address and adds it to the device list.

### 5.2 Port Access

The `Sxp` allows device drivers to access UART ports through the `get_port()` method:

```cpp
Tport_uart_sts& get_port(Xr20m1172::Channel chn_id);
```

This method returns a port that implements the `Tport_uart_sts` interface.

### 5.3 Configuration

Both implementations allow device drivers to configure communication parameters:

- `SC18IM704` is configured through the constructor and internal state machine
- `Sxp` is configured through the `config()` method

## 6. Communication Protocol Details

### 6.1 I2C Protocol (SC18IM704)

The SC18IM704 implements the I2C protocol with the following features:

- Support for multiple I2C devices (up to 2)
- I2C speed configuration (375 kHz)
- I2C timeout configuration
- Support for I2C read and write operations
- Error detection through status codes

### 6.2 UART Protocol (Sxp)

The Sxp implements the UART protocol with the following features:

- Support for two UART channels
- Configurable UART parameters (baud rate, data bits, stop bits, parity)
- Performance monitoring through statistics
- Error detection through the PBIT flag

### 6.3 SPI Protocol (Underlying XR20M1172 Communication)

The Sxp uses SPI to communicate with the XR20M1172 chip:

- Maximum transfer size of 26 bytes per step
- SPI FIFO size of 16 bytes
- Data transfer through a working buffer

## 7. Timing and Performance Considerations

### 7.1 Timeouts

The SC18IM704 uses timeouts to detect and recover from communication failures:

```cpp
static const Real max_res_time = 1.6F;              ///< Max time allowed for sending and receiving each byte.
static const Real init_res_time = 1.0F;             ///< Initial response time.
```

### 7.2 Transfer Sizes

The Sxp limits the maximum transfer size per step:

```cpp
static const Uint16 max_bytes_step = 26U;           ///< SPI FIFOs size = 16 bytes.
```

### 7.3 Performance Monitoring

The Sxp includes performance monitoring through port statistics:

```cpp
volatile Real& rxr_ch0;         ///< Channel 0 RX rate.
volatile Real& txr_ch0;         ///< Channel 0 TX rate.
volatile Real& rxr_ch1;         ///< Channel 1 RX rate.
volatile Real& txr_ch1;         ///< Channel 1 TX rate.
```

## 8. Summary of Communication Protocol Implementations

The system implements a layered communication architecture that abstracts hardware-specific details from higher-level device drivers:

1. **SC18IM704 (UART-to-I2C Bridge)**:
   - Implements the `Base::Itport_u8` interface
   - Supports multiple I2C devices (up to 2)
   - Uses a complex state machine for communication
   - Includes error detection and recovery mechanisms
   - Configurable I2C parameters (speed, timeout)

2. **Sxp (SCI Expander)**:
   - Provides two UART ports through the `Tport_uart` interface
   - Uses SPI to communicate with the XR20M1172 chip
   - Includes performance monitoring through statistics
   - Configurable UART parameters
   - Uses a simpler approach with the `step_ch()` method

Both implementations provide standardized interfaces for device drivers to communicate with hardware peripherals without needing to understand the underlying protocol details.

## Referenced Context Files

No context files were provided in this analysis. The summary is based solely on the provided source files:

1. `code/include/SC18IM704.h`
2. `code/include/Sxp.h`
3. `code/include/Sxp_ioctl.h`
4. `code/source/SC18IM704.cpp`
5. `code/source/Sxp.cpp`