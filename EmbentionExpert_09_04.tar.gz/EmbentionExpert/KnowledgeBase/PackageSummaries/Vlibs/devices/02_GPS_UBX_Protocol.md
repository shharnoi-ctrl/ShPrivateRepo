# Generated from:

- code/include/Ubxcfgdata.h (831 tokens)
- code/include/Ubxcfggnss.h (3054 tokens)
- code/include/Ubxcfgitfm.h (869 tokens)
- code/include/Ubxcfgmsgrate.h (1161 tokens)
- code/include/Ubxcfgnav5.h (1777 tokens)
- code/include/Ubxcfgnavx5.h (1122 tokens)
- code/include/Ubxcfgport.h (904 tokens)
- code/include/Ubxcfgrate.h (825 tokens)
- code/include/Ubxcfgsbas.h (909 tokens)
- code/include/Ubxcfgtp5.h (1433 tokens)
- code/include/Ubxcfgtmode3.h (1128 tokens)
- code/include/Ubxdefs.h (744 tokens)
- code/include/Ubxdop.h (297 tokens)
- code/include/Ubxhp.h (986 tokens)
- code/include/Ubxmonhw.h (386 tokens)
- code/include/Ubxpkt.h (567 tokens)
- code/include/Ubxpvt.h (2416 tokens)
- code/include/Ubxreset.h (824 tokens)
- code/include/Ubxrned.h (454 tokens)
- code/include/Ubxrtcminst.h (325 tokens)
- code/include/Ubxrxmsfrbx.h (1082 tokens)
- code/include/Ubxstatus.h (287 tokens)
- code/include/Ubxsvin.h (423 tokens)
- code/include/Ubxtgps.h (510 tokens)
- code/include/Ubxtimtp.h (270 tokens)
- code/include/Ubxtutc.h (413 tokens)
- code/source/Ubxcfgdata.cpp (1078 tokens)
- code/source/Ubxcfgitfm.cpp (478 tokens)
- code/source/Ubxcfgmsgrate.cpp (809 tokens)
- code/source/Ubxcfgnav5.cpp (2250 tokens)
- code/source/Ubxcfgnavx5.cpp (2349 tokens)
- code/source/Ubxcfgport.cpp (1181 tokens)
- code/source/Ubxcfgrate.cpp (454 tokens)
- code/source/Ubxcfgsbas.cpp (801 tokens)
- code/source/Ubxcfgtp5.cpp (1699 tokens)
- code/source/Ubxcfgtmode3.cpp (1583 tokens)
- code/source/Ubxdop.cpp (147 tokens)
- code/source/Ubxhp.cpp (302 tokens)
- code/source/Ubxmonhw.cpp (1044 tokens)
- code/source/Ubxpkt.cpp (1633 tokens)
- code/source/Ubxpvt.cpp (1114 tokens)
- code/source/Ubxreset.cpp (324 tokens)
- code/source/Ubxrned.cpp (441 tokens)
- code/source/Ubxrtcminst.cpp (327 tokens)
- code/source/Ubxrxmsfrbx.cpp (622 tokens)
- code/source/Ubxstatus.cpp (132 tokens)
- code/source/Ubxsvin.cpp (718 tokens)
- code/source/Ubxtgps.cpp (338 tokens)
- code/source/Ubxtimtp.cpp (347 tokens)
- code/source/Ubxtutc.cpp (458 tokens)

## With context from:

- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/devices/03_Navigation_Systems.md (5296 tokens)

---

# UBX Protocol Implementation for GPS Receivers: Comprehensive Analysis

This document provides a detailed analysis of the UBX protocol implementation for GPS receivers, focusing on the architecture, configuration structures, message parsing, and data extraction mechanisms.

## 1. Overall Architecture

The UBX protocol implementation is organized as a comprehensive set of classes and structures within the `Devices::Ubx` namespace. The system is designed to handle communication with u-blox GPS receivers, supporting configuration, message parsing, and data extraction.

### 1.1 Core Components

The UBX protocol implementation consists of several key components:

1. **Configuration Structures**: A collection of specialized structures for configuring different aspects of the GPS receiver
2. **Message Parsing**: Classes for parsing UBX protocol messages
3. **Data Extraction**: Structures for extracting and processing navigation data
4. **Hardware Compatibility**: Support for different hardware versions and capabilities

### 1.2 Configuration Hierarchy

The configuration system is hierarchically organized with `Ubxcfgdata` at the top level, which contains all configuration sub-structures:

```cpp
struct Ubxcfgdata
{
    Ubxcfgport portdata_spi;          // Port Configuration for SPI Port
    Ubxcfgport portdata_sci;          // Port Configuration for UART Port
    Ubxcfgnav5 nav5data;              // Navigation Engine Settings
    Ubxcfgnavx5 navx5data;            // Navigation Engine Expert Settings
    Ubxcfggnss<Ku16::u3> gnssdata;    // GNSS constellation configuration
    Ubxcfgtmode3 tmode3data;          // Time Mode Settings 3
    Ubxcfgsbas sbasdata;              // SBAS Configuration
    Ubxcfgitfm itfmdata;              // Jamming/interference monitor configuration
    Ubxcfgrate cfgrate;               // Navigation/Measurement Rate Settings
    Ubxcfgtp5 cfgtp5;                 // Time pulse configuration
    Ubxcfgmsgrate msg_status_data;    // Status message rate
    // Additional message rate configurations...
    
    bool is_rtk_rover;                // Indicates if device is in RTK rover mode
    
    void init(bool use_spi0);         // Initialize configuration
    void cset(Base::Lossy_error& str); // Deserialize configuration
};
```

## 2. Message Handling and Protocol Structure

### 2.1 UBX Protocol Definitions

The UBX protocol is defined in `Ubxdefs.h`, which includes message identifiers, synchronization bytes, and other protocol constants:

```cpp
namespace Ubx
{
    // Maximum payload size in bytes of compatible Ublox messages
    static const Uint16 max_payload_size = 688;

    // Extra bytes needed in a Ublox M8 message (6 bytes header, 2 bytes CRC)
    static const Uint16 extra_bytes = 8;

    enum Sync
    {
        hdr_ubx_1  = 0xB5,  // First UBX sync byte
        hdr_ubx_2  = 0x62   // Second UBX sync byte
    };

    // Supported Ublox message IDs
    enum Msgid
    {
        msg_ack          = 0x0501, // Message Acknowledged
        msg_nak          = 0x0500, // Message Not-Acknowledged
        msg_tutc         = 0x0121, // UTC Time Solution
        // Additional message IDs...
    };
}
```

### 2.2 Packet Parsing

The `Ubxpkt` class handles the parsing of UBX protocol messages:

```cpp
class Ubxpkt
{
public:
    enum Pstate
    {
        pst_reset,      // Parser reset state
        pst_ongoing,    // Parsing in progress
        pst_completed   // Parsing completed successfully
    };

    Uint16 len;                 // Length of the payload
    Msgid  classid;             // Message class and ID
    Base::Lossy_error payload;  // Payload data container

    Ubxpkt();
    Pstate parse(Uint8 data);   // Parse incoming data byte
};
```

The parser implements a state machine to handle the UBX protocol format:

1. **Sync Detection**: Looks for the UBX sync bytes (0xB5, 0x62)
2. **Header Parsing**: Extracts message class, ID, and length
3. **Payload Collection**: Gathers payload bytes
4. **Checksum Verification**: Validates the message using Fletcher checksum

## 3. Configuration Structures

### 3.1 Navigation Engine Configuration

#### 3.1.1 Basic Navigation Settings (Ubxcfgnav5)

The `Ubxcfgnav5` structure configures the core navigation engine settings:

```cpp
struct Ubxcfgnav5
{
    static const Uint16 payload_length = 36;
    static const Msgid id = Ubx::msg_cfg_nav5;

    enum DynModel
    {
        portable    = 0,   // Portable
        stationary  = 2,   // Stationary
        pedestrian  = 3,   // Pedestrian
        // Additional dynamic models...
    };

    enum FixMode
    {
        only_2d      = 1,  // Only 2D fix
        only_3d      = 2,  // Only 3D fix
        automode     = 3,  // Auto
        fix_mode_all = 4   // Number of fix modes
    };

    enum Utcstandard
    {
        automatic = 0, // Automatic selection based on GNSS configuration
        gps       = 3, // GPS time
        galileo   = 5, // Galileo time
        glonass   = 6, // GLONASS time
        beidou    = 7  // BeiDou time
    };

    Uint16 mask;              // Parameters Bitmask
    DynModel dynmodel;        // Dynamic platform model
    FixMode fixmode;          // Position Fixing Mode
    // Additional configuration parameters...

    void cset(Base::Lossy_error& str);
    void cget(Base::Lossy& str) const volatile;
    static void cget_poll(const Base::Lossy& str);
    bool check(Base::Lossy_error& str) const volatile;
    static bool permit_nak();
    Uint16 get_payload_len() const volatile;
};
```

#### 3.1.2 Extended Navigation Settings (Ubxcfgnavx5)

The `Ubxcfgnavx5` structure provides advanced navigation engine settings:

```cpp
struct Ubxcfgnavx5
{
    static const Uint16 payload_length = 40;
    static const Msgid id = Ubx::msg_cfg_navx5;

    Uint16 version;         // Message version
    Uint16 mask1;           // First parameters bitmask
    Uint32 mask2;           // Second parameters bitmask
    Uint8 minsvs;           // Minimum number of satellites for navigation
    Uint8 maxsvs;           // Maximum number of satellites for navigation
    // Additional configuration parameters...

    void cset(Base::Lossy_error& str);
    void cget(Base::Lossy& str) const volatile;
    static void cget_poll(const Base::Lossy& str);
    bool check(Base::Lossy_error& str) const volatile;
    static bool permit_nak();
    Uint16 get_payload_len() const volatile;
};
```

### 3.2 GNSS Constellation Configuration

The `Ubxcfggnss` template structure configures the GNSS constellations used by the receiver:

```cpp
template <Uint16 hwv>
struct Ubxcfggnss
{
    static const Uint16 maxcfgblocks = Ku16::u6;        // Block number for F9P (>= v4.7)
    static const Uint16 maxcfgblocks_std = Ku16::u3;    // Block number for M8P (< v4.7)
    static const Uint16 payload_length = Ku16::u4 + maxcfgblocks * Ku16::u8;
    static const Msgid id = Ubx::msg_cfg_gnss;

    // Configuration block for each constellation
    struct Cfgblock
    {
        Uint8 gnssid;   // GNSS id
        Uint8 restrkch; // Minimum reserved tracking channels
        Uint8 maxtrkch; // Maximum reserved tracking channels
        Uint32 flags;   // Bit field of flags
        Uint8 enabled;  // Constellation enabled flag
        
        void cset(Base::Lossy_error& str);
        void cget(Base::Lossy& str) const volatile;
    };

    Uint8 msgver;                                       // Message version
    Uint8 numtrkchhw;                                   // Available tracking channels
    Uint8 numtrkchuse;                                  // Tracking channels to use
    Uint8 numblks;                                      // Number of configuration blocks
    Base::Tnarray<Cfgblock, maxcfgblocks> cfgblocks;    // Configuration blocks

    void cset(Base::Lossy_error& str);
    void cget(Base::Lossy& str) const volatile;
    void cget_poll(Base::Lossy& str) const volatile;
    bool check(Base::Lossy_error& str) const volatile;
    static bool permit_nak();
    Uint16 get_payload_len() const volatile;
};
```

The template parameter `hwv` allows for hardware version-specific behavior:

```cpp
// In Ubxcfgdata
Ubxcfggnss<Ku16::u3> gnssdata;    // GNSS constellation configuration with galileo (>=4.7)
```

### 3.3 Port Configuration

The `Ubxcfgport` structure configures the communication ports (SPI, UART):

```cpp
struct Ubxcfgport
{
    static const Uint16 payload_length = 20;
    static const Uint16 poll_length = 1;
    static const Msgid id = Ubx::msg_cfg_port;

    Uint8 port_id;          // Port Identifier Number (= 4 for SPI port)
    Uint16 tx_ready;        // TX ready PIN configuration
    Uint32 mode;            // SPI Mode Flags
    Uint16 in_proto_mask;   // Input protocols mask
    Uint16 out_proto_mask;  // Output protocols mask
    Uint16 flags;           // Flags bit mask
    Uint32 baudRate;        // Baud Rate

    void cset(Base::Lossy_error& str);
    void cget(Base::Lossy& str) const volatile;
    void cget_poll(Base::Lossy& str) const volatile;
    bool check(Base::Lossy_error& str) const volatile;
    static bool permit_nak();
    Uint16 get_payload_len() const volatile;
};
```

### 3.4 Message Rate Configuration

The `Ubxcfgmsgrate` structure configures the output rate for specific UBX messages:

```cpp
struct Ubxcfgmsgrate
{
    static const Uint16 payload_length = 8;
    static const Uint16 poll_length = 2;
    static const Msgid id = Ubx::msg_cfg_msg_rate;

    Uint8 msgclass; // Message class
    Uint8 msgid;    // Message identifier
    Uint8 i2c;      // Send rate on I2C port
    Uint8 uart1;    // Send rate on UART1 port
    Uint8 uart2;    // Send rate on UART2 port
    Uint8 usb;      // Send rate on USB port
    Uint8 spi;      // Send rate on SPI port
    Uint8 port5;    // Send rate on PORT 5

    void cset(Base::Lossy& str);
    void cget(Base::Lossy& str) const volatile;
    void cget_poll(Base::Lossy& str) const volatile;
    bool check(Base::Lossy& str) const volatile;
    bool permit_nak() const volatile;
    Uint16 get_payload_len() const volatile;
    void init(const Msgid id);
    bool is_msg_enabled() const volatile;
};
```

### 3.5 Time Mode Configuration

The `Ubxcfgtmode3` structure configures the time mode settings, particularly for RTK base stations:

```cpp
struct Ubxcfgtmode3
{
    static const Uint16 payload_length = 40;
    static const Msgid id = Ubx::msg_cfg_tmode3;

    enum Modeflags
    {
        disabled    = 0,    // Survey-in disabled
        survey_in   = 1     // Survey-in enabled
    };

    Uint8 version;          // Message version
    Modeflags flags;        // Receiver mode flags
    Uint32 ecefxorlat;      // ECEF X coordinate or latitude
    Uint32 ecefyorlon;      // ECEF Y coordinate or longitude
    Uint32 ecefzoralt;      // ECEF Z coordinate or altitude
    // Additional high-precision coordinates and settings...
    Uint32 fixedposacc;     // Fixed position 3D accuracy
    Uint32 svinmindur;      // Survey-in minimum duration
    Uint32 svinacclimit;    // Survey-in position accuracy limit

    void cset(Base::Lossy_error& str);
    void cget(Base::Lossy& str) const volatile;
    static void cget_poll(const Base::Lossy& str);
    bool check(Base::Lossy_error& str) const volatile;
    static bool permit_nak();
    Uint16 get_payload_len() const volatile;
};
```

### 3.6 Time Pulse Configuration

The `Ubxcfgtp5` structure configures the time pulse output:

```cpp
struct Ubxcfgtp5
{
    static const Uint16 payload_length = 32;
    static const Msgid id = Ubx::msg_cfg_tp5;

    enum Flag_ids
    {
        active           = 0, // Time pulse active/inactive
        lock_gps_freq    = 1, // Lock to GPS frequency
        locked_other_set = 2, // Locked other set
        is_freq          = 3, // Check frequency field
        is_length        = 4, // Check pulse length field
        align_to_tow     = 5, // Align pulse to top of second
        polarity         = 6, // Pulse polarity
        grid_utc_gps     = 7  // Time grid (UTC or GPS)
    };

    static const Uint32 req_flags = /* combination of flags */;
    static const Uint32 req_pulse_len = 5000U; // 5ms pulse length

    Uint8 tpidx;                  // Time pulse selection
    Uint8 version;                // Message version
    int16 ant_cable_delay;        // Antenna cable delay (ns)
    int16 rf_group_delay;         // RF group delay (ns)
    Uint32 freq_period;           // Frequency or period (Hz/us)
    Uint32 freq_period_lock;      // Frequency/period when locked
    Uint32 pulse_len_ratio;       // Pulse length or duty cycle
    Uint32 pulse_len_ratio_lock;  // Pulse length when locked
    int32 user_config_delay;      // User configurable delay
    Uint32 flags;                 // Configuration flags

    void init();
    void cset(Base::Lossy_error& str);
    void cget(Base::Lossy& str) const volatile;
    static void cget_poll(const Base::Lossy& str);
    bool check(Base::Lossy_error& str) const volatile;
    static bool permit_nak();
    Uint16 get_payload_len() const volatile;
};
```

### 3.7 Interference Monitor Configuration

The `Ubxcfgitfm` structure configures the jamming/interference monitor:

```cpp
struct Ubxcfgitfm
{
    static const Uint16 payload_length = 8;
    static const Msgid id = Ubx::msg_cfg_itfm;

    Uint32 config;      // Interference configuration word
    Uint32 config2;     // Extra settings for jamming/interference monitor

    void cset(Base::Lossy_error& str);
    void cget(Base::Lossy& str) const volatile;
    void cget_poll(Base::Lossy& str) const volatile;
    bool check(Base::Lossy_error& str) const volatile;
    static bool permit_nak();
    Uint16 get_payload_len() const volatile;
};
```

## 4. Navigation Data Structures

### 4.1 Position, Velocity, Time (PVT) Data

The `Ubxpvt` structure handles position, velocity, and time data:

```cpp
struct Ubxpvt
{
    enum Fixtype
    {
        no_fix              = 0, // No fix available
        dead_reckoning_only = 1, // Dead reckoning only
        fix_2d              = 2, // 2D fix
        fix_3d              = 3, // 3D fix
        GNSS_dead_reckoning = 4, // GNSS and dead reckoning combined
        time_only           = 5  // Time only solution
    };

    Uint32 itow_ms;                // GPS time of week
    Fixtype fixtype;               // GNSS fix type
    bool fixok;                    // Valid fix flag
    bool diffsol;                  // Differential corrections applied
    Cpsol cpsolution;              // Carrier phase solution
    int8 num_sv;                   // Number of satellites used
    int32 lon;                     // Longitude (degrees * 1e7)
    int32 lat;                     // Latitude (degrees * 1e7)
    int32 height;                  // Height above ellipsoid (mm)
    int32 msl;                     // Height above mean sea level (mm)
    Uint32 hacc;                   // Horizontal accuracy (mm)
    Uint32 vacc;                   // Vertical accuracy (mm)
    int32 veln;                    // North velocity (mm/s)
    int32 vele;                    // East velocity (mm/s)
    int32 veld;                    // Down velocity (mm/s)
    Uint32 saccuracy;              // Speed accuracy (mm/s)
    Uint16 pdop;                   // Position DOP (*0.01)

    void cset(Base::Lossy& str);
    
    // Accessor methods
    bool is_fix3d() const;
    bool is_fix() const;
    Real64 get_longitude() const;
    Real64 get_latitude() const;
    Real64 get_height() const;
    Real get_hmsl() const;
    Real get_hacc() const;
    Real get_vacc() const;
    Real get_vnorth() const;
    Real get_veast() const;
    Real get_vdown() const;
    Real get_sacc() const;
    Real get_pdop() const;
    
    static const Real pdop_scaling;
    static const Real64 ubxlltorad;
};
```

### 4.2 High-Precision Position Data

The `Ubxhp` structure handles high-precision position data:

```cpp
struct Ubxhp
{
    // Low precision (centimeter) position data
    struct Lowp_data
    {
        int32 centimeters[Ku16::u3];  // Value in cm
        void cset(Base::Lossy& str);
    };

    // High precision (0.1mm) position data
    struct Highp_data
    {
        int8 hp_01mm[Ku16::u3];       // 0.1 mm precision
        void cset(Base::Lossy& str);
    };

    Lowp_data cmpc;     // Centimeter precision components
    Highp_data hpc;     // High precision components

    void get_ned(Maverick::Irvector3& ned) const;
    void cset(Base::Lossy& str);
};
```

### 4.3 Relative Position Data

The `Ubxrned` structure handles relative position data in NED (North, East, Down) coordinates:

```cpp
struct Ubxrned
{
    Uint32 itow_ms;
    Ubxhp ned;                     // Relative to base NED
    Uint32 acc_ned_4[Ku32::u3];    // Accuracy scaled by 0.1mm
    bool gps_fix_ok;
    bool dif_soln;
    bool rel_pos_valid;
    bool mov_baseline;
    Cpsol cpsolution;

    Ubxrned();
    void get_ned_acc(Maverick::Irvector3& ned) const;
    bool cset(Base::Lossy& str);
};
```

### 4.4 Time Data

Several structures handle different aspects of time data:

```cpp
// GPS Time
struct Ubxtgps
{
    Uint32 itow_ms;     // Milliseconds since week start
    int16 week;         // Weeks since January 6, 1980
    bool towvalid;      // Validity of milliseconds
    bool weekvalid;     // Validity of week number

    Ubxtgps();
    bool is_tgps_ok() const;
    void cset(Base::Lossy& str);
};

// UTC Time
class Ubxtutc
{
    Uint32 itow_ms;  // GPS time of week
    Uint16 year;     // Year (UTC)
    Uint8 month;     // Month, range 1..12 (UTC)
    Uint8 day;       // Day of month, range 1..31 (UTC)
    Uint8 hour;      // Hour of day, range 0..23 (UTC)
    Uint8 minute;    // Minute of hour, range 0..59 (UTC)
    Uint8 second;    // Seconds of minute, range 0..59 (UTC)
    bool itowvalid;  // Validity flag for GPS time
    bool utcvalid;   // Validity flag for UTC time

    Ubxtutc();
    void cset(Base::Lossy& str);
};

// Time Pulse Information
struct Ubxtimtp
{
    Uint32 tow_ms;     // Time of week in milliseconds
    Uint32 tow_subms;  // Time of week in sub milliseconds
    int32 qerr;        // Quantization error
    Uint16 week;       // Week number
    Uint8 flags;       // Bitmask
    Uint8 ref_info;    // Time reference information

    bool cset(Base::Lossy& str);
};
```

### 4.5 Status and Monitoring Data

Several structures handle status and monitoring information:

```cpp
// Navigation Status
struct Ubxstatus
{
    Uint32 itow_ms;         // GPS time
    bool gps_fix_ok;        // Position and velocity valid
    bool dif_soln;          // Differential corrections
    Uint32 spoof_det_state; // Spoofing detection state
    bool dgps_istat;        // DGPS input status

    Ubxstatus();
    void cset(Base::Lossy& str);
};

// Hardware Monitor
struct Ubxmonhw
{
    Uint8 jammst;     // Jamming/interference monitor status
    Uint8 jammind;    // CW jamming indicator

    Ubxmonhw();
    void cset(Base::Lossy_error& str);
};

// Survey-In Data
struct Ubxsvin
{
    Uint32 itow_ms;         // GPS time of week
    Uint32 dur;             // Survey-in observation time
    Ubxhp mean_ecef;        // Survey-in mean position
    Uint32 mean_acc_01mm;   // Survey-in mean position accuracy
    Uint32 nobs;            // Number of position observations
    bool valid;             // Survey-in position validity
    bool inprogress;        // Survey-in in progress

    Ubxsvin();
    bool cset(Base::Lossy& str);
};

// RTCM Input Status
struct Ubxrtcminst
{
    Uint16 msg_type;  // RTCM message type
    bool crc_failed;  // CRC check failed flag

    Ubxrtcminst();
    void cset(Base::Lossy& str);
};
```

### 4.6 Raw Navigation Data

The `Ubxrxmsfrbx` structure handles raw navigation data subframes:

```cpp
struct Ubxrxmsfrbx
{
    Uint8 gnssId;       // GNSS identifier
    Uint8 svId;         // Satellite identifier
    Uint8 sigId;        // Signal identifier
    Uint8 freqId;       // Only used for GLONASS
    Uint8 numWords;     // Number of data words
    Uint8 chn;          // Tracking channel number
    Base::Gnss_nav_raw::data_t dwrd;  // Subframe data words

    Ubxrxmsfrbx();
    void cset(Base::Lossy& str);
    bool is_gps_gal();
    const Base::Gnss_nav_raw::Gnss_nav_raw_t get_nav_data_t();
    Uint8 get_sigId() const;
};
```

## 5. Device Control and Reset

The `Ubxreset` structure provides functionality to reset the GPS receiver:

```cpp
struct Ubxreset
{
    enum NavBbrMask
    {
        hot_start   = 0x0000,  // Use all available data
        warm_start  = 0x0001,  // No ephemeris info
        cold_start  = 0xFFFF   // No info of any type
    };
    
    enum ResetMode
    {
        hw_rst              = 0,  // Hardware reset
        sw_rst              = 1,  // Software reset
        sw_rst_gnss_only    = 2,  // Only reset GNSS tasks
        hw_rst_sdwn         = 4,  // Hardware reset after shutdown
        gnss_stop           = 8,  // Stop GNSS tasks
        gnss_start          = 9   // Start GNSS tasks
    };
    
    static const Uint16 payload_length = 4;
    static const Msgid id = Ubx::msg_cfg_reset;

    Ubxreset();
    void cget(Base::Lossy& str) const;
    void set_rst_data(Uint16 mask);
    void set_rst_mode(Uint8 mode);
    
private:
    Uint16 navbrbmask;  // Navigation BBR mask
    Uint8 rstmode;      // Reset mode
};
```

## 6. Common Patterns and Design Principles

### 6.1 Serialization/Deserialization Pattern

All configuration structures follow a common pattern for serialization and deserialization:

1. **cset**: Deserializes configuration from a data stream
2. **cget**: Serializes configuration to a data stream
3. **cget_poll**: Generates a polling message to request current configuration
4. **check**: Validates if a data stream matches the current configuration
5. **permit_nak**: Determines if a NAK response is acceptable for this message
6. **get_payload_len**: Returns the payload length for the message

### 6.2 Hardware Version Compatibility

The implementation handles different hardware versions through:

1. **Template Parameters**: The `Ubxcfggnss` structure uses a template parameter to adapt to different hardware versions
2. **Runtime Checks**: Many structures check the hardware version at runtime:
   ```cpp
   if(Bsp::get_uid().hwv < hwv) // hardware version < 4.7
   {
       numblks = maxcfgblocks_std;
       // Apply hardware-specific adjustments
   }
   ```

### 6.3 Error Handling

The implementation uses several error handling mechanisms:

1. **Assertions**: Validates configuration parameters:
   ```cpp
   str.assrt((flags == disabled) || (flags == survey_in), Base::err_Ubxcfgtmode3);
   ```

2. **NAK Handling**: Determines if NAK responses are acceptable:
   ```cpp
   bool Ubxcfgmsgrate::permit_nak() const volatile
   {
       bool ret = false;
       // Special handling for RTCM 4072 message
       if ((msgclass == class_rtcm4072) && (msgid == id_rtcm4072))
       {
           ret = (!is_msg_enabled());
       }
       return ret;
   }
   ```

3. **Validation Checks**: Ensures configuration values are within valid ranges:
   ```cpp
   str.assrt(((aoporbmaxerr >= min_aoporbmaxerr) && (aoporbmaxerr < max_aoporbmaxerr))
           || (aoporbmaxerr == 0), Base::err_Ubxcfgnavx5);
   ```

### 6.4 Packet Parsing State Machine

The `Ubxpkt` class implements a state machine for parsing UBX protocol messages:

```cpp
enum Pkt_parse_cnt
{
    pkt_cnt0,   // First packet parsing counter
    pkt_cnt1,   // Second packet parsing counter
    pkt_cnt2,   // Third packet parsing counter
    pkt_cnt3,   // Fourth packet parsing counter
    pkt_cnt4,   // Fifth packet parsing counter
    pkt_cnt5    // Sixth packet parsing counter
};
```

The state machine transitions through these states to parse the UBX protocol format:

1. **pkt_cnt0**: Looks for the first sync byte (0xB5)
2. **pkt_cnt1**: Looks for the second sync byte (0x62)
3. **pkt_cnt2**: Parses the message class
4. **pkt_cnt3**: Parses the message ID
5. **pkt_cnt4**: Parses the payload length (first byte)
6. **pkt_cnt5**: Parses the payload length (second byte)
7. **Default**: Processes payload bytes and checksum

## 7. RTK and High-Precision Features

The implementation supports RTK (Real-Time Kinematics) and high-precision positioning:

### 7.1 RTK Mode Detection

The `Ubxcfgdata` structure includes an `is_rtk_rover` flag to indicate if the device is operating as an RTK rover:

```cpp
bool is_rtk_rover; // Dependent value that is true if the message 1005 and 4072 is disabled in all ports

void Ubxcfgdata::cset(Base::Lossy_error& str)
{
    // Deserialize configuration...
    
    // Set the RTK rover flag based on RTCM message configuration
    is_rtk_rover = (!msg_rtcm1005_data.is_msg_enabled()) &&
                   (!msg_rtcm4072_data.is_msg_enabled());
}
```

### 7.2 High-Precision Position Handling

The `Ubxhp` structure handles high-precision position data with centimeter and sub-millimeter components:

```cpp
struct Ubxhp
{
    struct Lowp_data
    {
        int32 centimeters[Ku16::u3];  // Value in cm
    };

    struct Highp_data
    {
        int8 hp_01mm[Ku16::u3];       // 0.1 mm precision
    };

    Lowp_data cmpc;     // Centimeter precision components
    Highp_data hpc;     // High precision components

    void get_ned(Maverick::Irvector3& ned) const
    {
        ned[Base::Coord::north] = static_cast<Real>(cmpc.centimeters[Ku16::u0])*Const::E100 +
            static_cast<Real>(hpc.hp_01mm[Ku16::u0])*Const::E10000;
        ned[Base::Coord::east] = static_cast<Real>(cmpc.centimeters[Ku16::u1])*Const::E100 +
            static_cast<Real>(hpc.hp_01mm[Ku16::u1])*Const::E10000;
        ned[Base::Coord::down] = static_cast<Real>(cmpc.centimeters[Ku16::u2])*Const::E100 +
            static_cast<Real>(hpc.hp_01mm[Ku16::u2])*Const::E10000;
    }
};
```

### 7.3 Survey-In Mode

The `Ubxcfgtmode3` structure configures the survey-in mode for RTK base stations:

```cpp
struct Ubxcfgtmode3
{
    enum Modeflags
    {
        disabled    = 0,    // Survey-in disabled
        survey_in   = 1     // Survey-in enabled
    };

    Uint8 version;          // Message version
    Modeflags flags;        // Receiver mode flags
    Uint32 ecefxorlat;      // ECEF X coordinate or latitude
    Uint32 ecefyorlon;      // ECEF Y coordinate or longitude
    Uint32 ecefzoralt;      // ECEF Z coordinate or altitude
    // Additional high-precision coordinates...
    Uint32 fixedposacc;     // Fixed position 3D accuracy
    Uint32 svinmindur;      // Survey-in minimum duration
    Uint32 svinacclimit;    // Survey-in position accuracy limit
};
```

The `Ubxsvin` structure provides survey-in status information:

```cpp
struct Ubxsvin
{
    Uint32 itow_ms;         // GPS time of week
    Uint32 dur;             // Survey-in observation time
    Ubxhp mean_ecef;        // Survey-in mean position
    Uint32 mean_acc_01mm;   // Survey-in mean position accuracy
    Uint32 nobs;            // Number of position observations
    bool valid;             // Survey-in position validity
    bool inprogress;        // Survey-in in progress
};
```

## 8. RTCM Message Handling

The implementation supports RTCM (Radio Technical Commission for Maritime Services) messages for RTK corrections:

### 8.1 RTCM Message Rate Configuration

The `Ubxcfgdata` structure includes several message rate configurations for RTCM messages:

```cpp
Ubxcfgmsgrate msg_rtcm1005_data;  // RTCM 1005 message rate
Ubxcfgmsgrate msg_rtcm1087_data;  // RTCM 1087 message rate
Ubxcfgmsgrate msg_rtcm1077_data;  // RTCM 1077 message rate
Ubxcfgmsgrate msg_rtcm1127_data;  // RTCM 1127 message rate
Ubxcfgmsgrate msg_rtcm1230_data;  // RTCM 1230 message rate
Ubxcfgmsgrate msg_rtcm4072_data;  // RTCM 4072 message rate
```

### 8.2 RTCM Input Status

The `Ubxrtcminst` structure provides status information for received RTCM messages:

```cpp
struct Ubxrtcminst
{
    Uint16 msg_type;  // RTCM message type
    bool crc_failed;  // CRC check failed flag

    void cset(Base::Lossy& str)
    {
        str.skip_bytes(1U);        // Skip version
        str.get_bool1(crc_failed);
        str.skip_bits(Ku16::u7);   // Skip reserved bits
        str.skip_bytes(Ku16::u4);  // Skip reserved1 and Reference station ID
        str.get_uint16(msg_type);
    }
};
```

## 9. Jamming/Interference Monitoring

The implementation includes jamming and interference monitoring capabilities:

### 9.1 Interference Monitor Configuration

The `Ubxcfgitfm` structure configures the jamming/interference monitor:

```cpp
struct Ubxcfgitfm
{
    Uint32 config;      // Interference configuration word
    Uint32 config2;     // Extra settings for jamming/interference monitor
};
```

### 9.2 Hardware Monitor Status

The `Ubxmonhw` structure provides hardware status information, including jamming detection:

```cpp
struct Ubxmonhw
{
    Uint8 jammst;     // Jamming/interference monitor status
                      // 0 = unknown or disabled
                      // 1 = ok - no significant jamming
                      // 2 = warning - interference visible but fix Ok
                      // 3 = critical - interference visible and no fix
    Uint8 jammind;    // CW jamming indicator (0-255)

    void cset(Base::Lossy_error& str)
    {
        // Skip various hardware status fields...
        Uint8 flags;
        str.get_uint8(flags);
        str.skip_bytes(Ku8::u1);
        str.skip_bytes(Ku8::u4);
        str.skip_bytes(Ku8::u17);
        str.get_uint8(jammind);
        
        // Extract jamming status from flags
        jammst = flags >> Ku8::u2 & Base::Lsbmask<Uint8, Ku8::u2>::value;
    }
};
```

## 10. Integration with Navigation System

### 10.1 Configuration Initialization

The `Ubxcfgdata` structure provides an `init` method to initialize the configuration:

```cpp
void Ubxcfgdata::init(bool use_spi0)
{
    cfgtp5.init();
    use_spi = use_spi0;
}
```

### 10.2 Time Pulse Configuration

The `Ubxcfgdata` structure configures the time pulse output based on the navigation rate:

```cpp
void Ubxcfgdata::cset(Base::Lossy_error& str)
{
    // Deserialize configuration...
    
    // Configure time pulse message rate
    msg_timetp_data.init(Ubx::msg_tim_tp);
    
    if(use_spi)
    {
        msg_timetp_data.spi = (msg_pvt_data.is_msg_enabled() || (msg_rned_data.is_msg_enabled())) ?
                Rfun::max<Uint8>(1, Ku16::u1000 / cfgrate.measrate) : 0;
    }
    else
    {
        static const Uint8 tp_rate_amz = 4U;
        msg_timetp_data.uart1 = tp_rate_amz;
    }
}
```

### 10.3 Navigation Data Processing

The various data structures (`Ubxpvt`, `Ubxrned`, etc.) provide methods to extract and convert navigation data for use by the navigation system:

```cpp
// Position conversion
Real64 Ubxpvt::get_longitude() const
{
    return ubxlltorad*static_cast<Real64>(lon);
}

Real64 Ubxpvt::get_latitude() const
{
    return ubxlltorad*static_cast<Real64>(lat);
}

Real64 Ubxpvt::get_height() const
{
    return Const::MM2M*static_cast<Real64>(height);
}

// Velocity conversion
Real Ubxpvt::get_vnorth() const
{
    return Const::MM2M*static_cast<Real>(veln);
}

Real Ubxpvt::get_veast() const
{
    return Const::MM2M*static_cast<Real>(vele);
}

Real Ubxpvt::get_vdown() const
{
    return Const::MM2M*static_cast<Real>(veld);
}
```

## 11. Referenced Context Files

The analysis was informed by the following context files:

1. **Navigation Systems**: Provided context on how the UBX protocol implementation integrates with other navigation systems like Garmin Lidar and VectorNav VN300.

2. **Sensor Device Framework**: Helped understand how the UBX protocol implementation fits into the broader sensor device architecture.

3. **Communication Protocols**: Provided context on the communication interfaces used by the UBX protocol implementation.

4. **Simulation Framework**: Helped understand how the UBX protocol implementation integrates with the simulation system.

These context files were valuable for understanding the broader system architecture and how the UBX protocol implementation interacts with other components.