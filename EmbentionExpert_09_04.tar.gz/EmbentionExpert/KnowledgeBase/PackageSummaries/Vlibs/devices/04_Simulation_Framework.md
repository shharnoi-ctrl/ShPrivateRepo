# Generated from:

- code/include/Internestsimdev.h (1368 tokens)
- code/include/Magnsimdev.h (428 tokens)
- code/include/Noisegen.h (315 tokens)
- code/include/Noisegen3D.h (363 tokens)
- code/include/Sim_noise.h (300 tokens)
- code/include/Sim_noise_fw.h (25 tokens)
- code/include/Simdev.h (1116 tokens)
- code/include/Simdev3D.h (1127 tokens)
- code/include/Lidarsimdev.h (1183 tokens)
- code/include/Lidarsimdev_fw.h (32 tokens)
- code/include/Rtksimdev.h (740 tokens)
- code/source/Internestsimdev.cpp (1377 tokens)
- code/source/Noisegen.cpp (534 tokens)
- code/source/Noisegen3D.cpp (202 tokens)
- code/source/Sim_noise.cpp (231 tokens)
- code/source/Simdev.cpp (218 tokens)
- code/source/Simdev3D.cpp (315 tokens)
- code/source/Lidarsimdev.cpp (873 tokens)
- code/source/Rtksimdev.cpp (1294 tokens)

---

# Comprehensive Summary of Sensor Simulation Framework

This document provides a detailed analysis of the sensor simulation framework used to replace real sensor measurements with simulated values. The framework enables testing without physical hardware by providing a consistent approach to sensor simulation across different device types.

## 1. Core Simulation Architecture

The simulation framework follows a consistent pattern across different sensor types, with specialized implementations for different dimensionality requirements:

### 1.1 Common Simulation Components

All simulation device classes share these common characteristics:

- **Simulation Enable/Disable Control**
  - Each simulation device has a `sim_enabled` boolean flag
  - `set_enable(bool)` method to enable/disable simulation
  - `is_enabled()` method to check simulation status

- **Measurement Replacement Pattern**
  - Each class implements a `replace_measure()` method that:
    - Checks if simulation is enabled
    - If enabled, replaces the real measurement with simulated values
    - Often adds noise to the simulated values for realism

- **Configuration Deserialization**
  - `cset()` methods to deserialize simulation parameters from a `Base::Lossy` stream
  - Allows setting both simulated values and noise characteristics

### 1.2 Noise Generation

The framework provides two primary noise generation classes:

#### 1.2.1 `Noisegen` Class (1D Noise)

```cpp
class Noisegen {
public:
    Noisegen();
    Real gen_noise(const Real real_measurement, const Sim_noise& noise);
private:
    bool first_step;
    Random_nmspc::Gaussian gnoise;
    Real mean;
};
```

- Generates one-dimensional noise
- Supports two noise types:
  - `real_noise`: Uses an exponential weighted moving average (EWMA) filter to extract noise from real measurements
  - `synthetic_noise`: Generates Gaussian noise with specified variance

#### 1.2.2 `Noisegen3D` Class (3D Noise)

```cpp
class Noisegen3D {
public:
    Noisegen3D();
    void gen_noise(const Maverick::Irvector3& real_measurement,
                   const Sim_noise& noise_cfg,
                   Maverick::Irvector3& noise);
private:
    Noisegen noisegen_x;
    Noisegen noisegen_y;
    Noisegen noisegen_z;
};
```

- Generates three-dimensional noise
- Uses three separate `Noisegen` instances (one per axis)
- Applies the same noise configuration to all three dimensions

### 1.3 Noise Configuration

The `Sim_noise` structure defines the noise characteristics:

```cpp
struct Sim_noise {
    enum NoiseType {
        real_noise      = 0U,  // Get noise from real sensor
        synthetic_noise = 1U,  // Use Gaussian pseudo random generator
        none            = 2U   // No noise
    };
    
    Sim_noise(const Real sigma0, const NoiseType type0);
    void cset(Base::Lossy& str);
    
    Real sigma;       // Variance (only used in synthetic noise)
    NoiseType type;   // Noise type selection
};
```

- Defines three noise types:
  1. `real_noise`: Extracts noise from real sensor measurements
  2. `synthetic_noise`: Generates synthetic Gaussian noise
  3. `none`: No noise added

- Deserialization format:
  - `Uint8` for noise type
  - `Real` for variance (sigma)

## 2. Simulation Device Types

The framework provides different simulation device classes based on dimensionality and specific sensor requirements:

### 2.1 One-Dimensional Simulation (`Simdev`)

```cpp
class Simdev {
public:
    struct Meas {
        Meas();
        void cset(Base::Lossy& str);
        Real val;   // Value to replace
        Real temp;  // Temperature to replace
    };
    
    Simdev(Real deviation, Sim_noise::NoiseType noise = Sim_noise::real_noise);
    void set_mea(const Meas& mea0);
    void cset_mea(Base::Lossy& str);
    void cset_noise(Base::Lossy& str);
    void set_enable(const bool enable);
    bool is_enabled() const;
    void replace_measure(Real& value);
    void replace_simtemp(volatile Real& value);
    
private:
    bool sim_enabled;
    Noisegen noisegen;
    Meas mea;
    Sim_noise noise;
};
```

- Used for single-value sensors
- Stores both measurement value and temperature
- Provides methods to:
  - Set simulated measurement values
  - Configure noise characteristics
  - Replace real measurements with simulated ones

### 2.2 Three-Dimensional Simulation (`Simdev3D`)

```cpp
class Simdev3D {
public:
    struct Meas {
        Meas();
        void cset(Base::Lossy& str);
        Base::Rv3 val;  // 3D value to replace
        Real temp;      // Sensor temperature to replace
    };
    
    Simdev3D(const Real deviation0, const Sim_noise::NoiseType type0 = Sim_noise::real_noise);
    void set_mea(const Meas& mea0);
    void cset_mea(Base::Lossy& str);
    void cset_noise(Base::Lossy& str);
    void set_enable(const bool enable);
    bool is_enabled() const;
    void replace_measure(Maverick::Irvector3& value);
    void replace_simtemp(volatile Real& value);
    
private:
    bool sim_enabled;
    Noisegen3D noisegen3D;
    Meas mea;
    Sim_noise noise;
};
```

- Used for three-dimensional vector sensors (e.g., accelerometers, magnetometers)
- Similar interface to `Simdev` but works with 3D vectors
- Uses `Noisegen3D` for noise generation

### 2.3 Specialized Simulation Devices

#### 2.3.1 LIDAR Simulation (`Lidar_simdev`)

```cpp
class Lidar_simdev {
public:
    Lidar_simdev(const Real deviation, const Sim_noise::NoiseType type0 = Sim_noise::real_noise);
    void set_enable(const bool enable);
    bool is_enabled() const;
    void cset(Base::Lossy& str, const Sim_cset_id id);
    void replace_measure(Real& value);
    
private:
    bool sim_enabled;
    Sim_noise noise;
    int16 dist_cm;
    Noisegen noisegen;
};
```

- Specialized for LIDAR distance measurements
- Stores distance in centimeters
- Converts to meters when replacing measurements

#### 2.3.2 LIDAR Array (`Lidar_array`)

```cpp
struct Lidar_array {
    Lidar_array(Real deviation, Sim_noise::NoiseType noise);
    Lidar_simdev lidar_sim0;
    Lidar_simdev lidar_sim1;
    Lidar_simdev lidar_sim2;
    Lidar_simdev lidar_sim3;
    Lidar_simdev lidar_sim4;
    void cset(Base::Lossy& str, Sim_cset_id id);
};
```

- Manages an array of 5 LIDAR simulation devices
- Provides a unified interface to configure multiple LIDAR sensors

#### 2.3.3 RTK GPS Simulation (`Rtksimdev`)

```cpp
struct Rtk_data {
    bool rel_pos_valid;
    Base::Tnarray<int32, Ku32::u3> rned;
    Base::Tnarray<int8, Ku32::u3> hp_01mm;
    Base::Tnarray<Uint32, Ku32::u3> acc_ned;
};

class Rtksimdev {
public:
    Rtksimdev();
    void set_enable(const bool enable);
    bool is_enabled() const;
    void cset(Base::Lossy& str);
    void replace_measure(Ubx::Ubxrned& value) const;
    
private:
    bool sim_enabled;
    Rtk_data meas;
};
```

- Specialized for RTK GPS position data
- Stores position in NED (North-East-Down) coordinates
- Includes high-precision components and accuracy metrics

#### 2.3.4 Magnetometer Simulation (`Magn_simdev`)

```cpp
class Magn_simdev {
public:
    Magn_simdev(Real deviation);
    void set_enable(const bool enable);
    bool is_enabled() const;
    void cset(Base::Lossy& str, const Sim_cset_id id);
    void replace_measure(Maverick::Irvector3& value);
    
private:
    bool sim_enabled;
    NoiseType noise_type;
    Maverick::Rvector3 magmeas;
    Real temp;
    Real sigma;
    Noisegen3D noisegen;
};
```

- Specialized for magnetometer measurements
- Stores magnetic field values in Teslas
- Uses 3D noise generation

#### 2.3.5 Internest Simulation (`Internest_simdev`)

```cpp
class Internest_simdev {
public:
    struct Inest_stref {
        volatile Uint16& raw_status;
        volatile Real& pos_x;
        volatile Real& pos_y;
        volatile Real& pos_z;
        volatile Real& angle;
        volatile Real& dev_xy;
        volatile Real& dev_z;
        volatile Real& dev_angle;
        
        Inest_stref(volatile Uint16& raw_status0, volatile Real& pos_x0, /* ... */);
    };
    
    struct Inest_data {
        Uint16 raw_status;
        Real pos_x;
        Real pos_y;
        Real pos_z;
        Real angle;
        Real dev_xy;
        Real dev_z;
        Real dev_angle;
    };
    
    Internest_simdev();
    void set_enable(const bool enable);
    bool is_enabled() const;
    void cset(Base::Lossy& str);
    void replace_measure(const Inest_stref& value) const;
    
private:
    bool sim_enabled;
    Inest_data inest_meas;
};
```

- Specialized for Internest positioning system
- Stores 3D position, angle, and standard deviations
- Uses a reference structure to update multiple values at once

## 3. Simulation Workflow

### 3.1 Enabling Simulation

1. Create a simulation device instance with appropriate parameters:
   ```cpp
   // For 1D sensor with synthetic noise (sigma = 0.1)
   Simdev pressure_sim(0.1F, Sim_noise::synthetic_noise);
   
   // For 3D sensor with real noise extraction
   Simdev3D accel_sim(0.05F, Sim_noise::real_noise);
   ```

2. Enable simulation explicitly or implicitly:
   ```cpp
   // Explicit enable
   pressure_sim.set_enable(true);
   
   // Implicit enable (when setting measurement values)
   Simdev::Meas meas;
   meas.val = 101325.0F;  // Pascal
   meas.temp = 25.0F;     // Celsius
   pressure_sim.set_mea(meas);  // Also enables simulation
   ```

### 3.2 Configuring Simulated Values

Values can be set programmatically or deserialized from a data stream:

```cpp
// Programmatic setting
Simdev3D::Meas accel_meas;
accel_meas.val[0] = 0.0F;  // X-axis (m/s²)
accel_meas.val[1] = 0.0F;  // Y-axis (m/s²)
accel_meas.val[2] = 9.81F; // Z-axis (m/s²)
accel_meas.temp = 22.5F;   // Celsius
accel_sim.set_mea(accel_meas);

// Deserialization from data stream
Base::Lossy stream;
// ... (stream is populated with data)
accel_sim.cset_mea(stream);
```

### 3.3 Configuring Noise

Noise configuration can also be set programmatically or deserialized:

```cpp
// Deserialization from data stream
Base::Lossy stream;
// ... (stream is populated with noise config)
accel_sim.cset_noise(stream);
```

### 3.4 Replacing Measurements

In the sensor driver code, measurements are replaced when simulation is enabled:

```cpp
// Example for 1D sensor
Real pressure_reading = read_pressure_from_hardware();
pressure_sim.replace_measure(pressure_reading);
// pressure_reading now contains simulated value if simulation is enabled

// Example for 3D sensor
Maverick::Irvector3 accel_reading = read_accel_from_hardware();
accel_sim.replace_measure(accel_reading);
// accel_reading now contains simulated values if simulation is enabled
```

## 4. Deserialization Formats

### 4.1 Noise Configuration

```
| Type  | Name  | Content        | Range                                      |
|-------|-------|----------------|-------------------------------------------|
| Uint8 | type  | Type of noise  | (0): Real noise, (1): Synthetic, (2): None |
| Real  | sigma | Noise variance | -                                          |
```

### 4.2 1D Measurement

```
| Type | Name | Content                  |
|------|------|--------------------------|
| Real | val  | Value to replace         |
| Real | temp | Temperature to replace   |
```

### 4.3 3D Measurement

```
| Type    | Name | Content                  |
|---------|------|--------------------------|
| Real[3] | val  | 3D value to replace      |
| Real    | temp | Temperature to replace   |
```

### 4.4 Internest Measurement

```
| Type   | Name       | Description                         |
|--------|------------|-------------------------------------|
| Uint16 | raw_status | Raw status                          |
| Real   | pos_x      | X position in meters                |
| Real   | pos_y      | Y position in meters                |
| Real   | pos_z      | Z position in meters                |
| Real   | angle      | Angle in radians                    |
| Real   | dev_xy     | XY standard deviation in meters     |
| Real   | dev_z      | Z standard deviation in meters      |
| Real   | dev_angle  | Angle standard deviation in radians |
```

### 4.5 RTK GPS Measurement

```
| Type   | Name           | Description                                       |
|--------|----------------|---------------------------------------------------|
| Bool8  | rel_pos_valid  | Relative position fix                             |
| Int32  | rned[0]        | NED relative position x-component                 |
| Int32  | rned[1]        | NED relative position y-component                 |
| Int32  | rned[2]        | NED relative position z-component                 |
| int8   | hp_01mm[0]     | NED relative position 10s of mm x-component       |
| int8   | hp_01mm[1]     | NED relative position 10s of mm y-component       |
| int8   | hp_01mm[2]     | NED relative position 10s of mm z-component       |
| Uint32 | acc_ned[0]     | NED relative position x-component accuracy        |
| Uint32 | acc_ned[1]     | NED relative position y-component accuracy        |
| Uint32 | acc_ned[2]     | NED relative position z-component accuracy        |
```

## 5. Integration with Sensor Drivers

The simulation framework is designed to integrate seamlessly with sensor drivers. The typical integration pattern is:

1. Create a simulation device instance as a member of the sensor driver class
2. In the measurement reading method:
   - Read the actual hardware value (if available)
   - Call `replace_measure()` to potentially replace with simulated value
   - Use the resulting value (either real or simulated)

This approach allows the same driver code to work with both real and simulated sensors, with the simulation layer being transparent to higher-level code.

## 6. Common Patterns Across Simulation Components

### 6.1 Consistent Interface

All simulation devices provide:
- Enable/disable control
- Measurement replacement
- Configuration deserialization

### 6.2 Noise Generation Strategy

- Real noise: Extracts noise characteristics from actual measurements
- Synthetic noise: Generates Gaussian noise with specified variance
- No noise: Uses exact simulated values

### 6.3 Dimensionality Handling

- 1D: Single value + temperature (`Simdev`)
- 3D: Vector + temperature (`Simdev3D`)
- Specialized: Custom data structures for specific sensors

### 6.4 Implicit Simulation Enabling

Setting measurement values typically enables simulation automatically, simplifying the API usage.

## 7. Referenced Context Files

The following context files were helpful in understanding the simulation framework:

- `Lossy.h`/`Lossy_fw.h`: Provides serialization/deserialization capabilities
- `Irvector3.h`/`Irvector3_fw.h`: 3D vector implementation
- `Rvector3.h`: Real-valued 3D vector
- `gaussian.h`: Gaussian random number generation
- `Ewma0.h`: Exponential weighted moving average filter
- `Ubxrned.h`: RTK GPS data structure
- `Sensimdefines.h`: Defines simulation-related constants and enumerations

These files provide the supporting infrastructure for the simulation framework, including data structures, mathematical operations, and serialization capabilities.