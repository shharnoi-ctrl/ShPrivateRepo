# Generated from:

- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/devices/04_Sensor_Device_Framework.md (3568 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/devices/04_Communication_Protocols.md (3756 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/devices/04_Simulation_Framework.md (3965 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/devices/03_IMU_Sensors.md (5369 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/devices/03_Magnetometer_Sensors.md (3741 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/devices/03_Pressure_Sensors.md (4233 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/devices/02_Temperature_Sensors.md (5200 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/devices/02_Distance_Sensors.md (4446 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/devices/03_Storage_Devices.md (5465 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/devices/03_Navigation_Systems.md (5296 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/devices/02_GPS_UBX_Protocol.md (8581 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/devices/02_Specialized_Sensors.md (4172 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/devices/02_Cellular_Communication.md (3133 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/devices/02_SIL_Implementations.md (8358 tokens)

---

# Comprehensive Sensor System Architecture Overview

This document provides a high-level architectural overview of the entire sensor system, explaining how different components interact and the design principles that unify the system.

## 1. Overall System Architecture

The sensor system follows a layered architecture with clear separation of concerns, enabling hardware abstraction, consistent error handling, and support for both real hardware and simulation:

```
┌─────────────────────────────────────────────────────────────────┐
│                     Application Layer                           │
└───────────────────────────────┬─────────────────────────────────┘
                                │
┌───────────────────────────────▼─────────────────────────────────┐
│                     Measurement System                          │
└───────────────────────────────┬─────────────────────────────────┘
                                │
┌───────────────────────────────▼─────────────────────────────────┐
│                     Sensor Driver Layer                         │
├─────────────┬─────────────┬───────────────┬────────────┬────────┤
│ IMU Drivers │ Pressure    │ Magnetometer  │ Distance   │ Other  │
│             │ Drivers     │ Drivers       │ Drivers    │ Drivers│
└─────────────┴─────────────┴───────────────┴────────────┴────────┘
                                │
┌───────────────────────────────▼─────────────────────────────────┐
│                Communication Protocol Layer                     │
├─────────────┬─────────────┬───────────────┬────────────┬────────┤
│ I2C         │ SPI         │ UART          │ ADC        │ Other  │
└─────────────┴─────────────┴───────────────┴────────────┴────────┘
                                │
┌───────────────────────────────▼─────────────────────────────────┐
│                     Hardware Abstraction Layer                  │
└───────────────────────────────┬─────────────────────────────────┘
                                │
┌───────────────────────────────▼─────────────────────────────────┐
│                     Hardware / Simulation                       │
└─────────────────────────────────────────────────────────────────┘
```

## 2. Key Architectural Components

### 2.1 Sensor Device Framework

The sensor device framework provides common interfaces and base classes that all sensor drivers implement:

- **Base Classes**: `I2Cdevice`, `Itport_u8`, `Iblock_device`
- **Common Interfaces**: `Ithermistor`, `Isincos_signal`, `Iangular_estimator`
- **Configuration Structures**: `Dev_common_cfg`, `Imu_params`
- **Measurement Containers**: `Tmeas1D`, `Tmeas3D`, `Rawmea3`

This framework ensures consistent behavior across different sensor types and enables code reuse.

### 2.2 Communication Protocols

The system implements multiple communication protocols to interface with various sensors:

- **I2C**: Used by most sensors (magnetometers, pressure sensors, temperature sensors)
- **SPI**: Used by high-speed sensors (IMUs, storage devices)
- **UART**: Used by navigation systems and cellular communication
- **ADC**: Used by analog sensors (thermistors, position sensors)

Each protocol implementation provides:
- Hardware abstraction
- Error detection and recovery
- Timing management
- Buffer handling

### 2.3 Simulation Framework

The simulation framework enables testing without physical hardware:

- **Simdev/Simdev3D**: Provides simulated sensor values
- **Noise Generation**: Adds realistic noise to simulated values
- **Measurement Replacement**: Seamlessly replaces real measurements with simulated ones
- **SIL Implementations**: Software-in-the-loop versions of all drivers

This framework allows comprehensive testing in both development and production environments.

### 2.4 Measurement System

The measurement system provides a unified interface for accessing sensor data:

- **Calibration**: Applies sensor-specific calibration
- **Filtering**: Reduces noise and improves data quality
- **Validation**: Ensures data is within valid ranges
- **Timestamping**: Associates measurements with system time

## 3. Common Design Patterns

### 3.1 State Machine Pattern

All sensor drivers implement state machines to manage their lifecycle:

1. **Initialization States**: Configure the sensor with appropriate settings
2. **Measurement States**: Trigger measurements and read results
3. **Error States**: Handle communication failures and recovery

This pattern provides:
- Clear separation of concerns
- Robust error handling
- Predictable behavior

### 3.2 Measurement Processing Pipeline

All sensors follow a consistent measurement processing pipeline:

```
Raw Data → Conversion → Validation → Filtering → Output
```

1. **Raw Data Acquisition**: Read raw data from the sensor
2. **Conversion**: Convert to physical units (m/s², Tesla, Pascal, etc.)
3. **Validation**: Check if measurements are within valid ranges
4. **Filtering**: Apply IIR filtering to reduce noise
5. **Output**: Make measurements available through a shared interface

### 3.3 Error Handling and Validation

The system implements comprehensive error handling and validation:

1. **Range Checking**: Ensures measurements are within valid ranges
2. **Delta Checking**: Limits the maximum change between consecutive measurements
3. **Non-Variation Detection**: Detects when sensors are stuck
4. **Communication Error Detection**: Detects protocol-specific errors
5. **Recovery Mechanisms**: Implements strategies to recover from errors

### 3.4 Configuration Management

The system provides a consistent approach to configuration:

1. **Default Configurations**: Reasonable defaults for all sensors
2. **Configuration Structures**: Type-safe configuration parameters
3. **Validation**: Ensures configuration parameters are valid
4. **Deserialization**: Loads configuration from data streams

## 4. Sensor Types and Implementations

### 4.1 IMU Sensors

The system supports multiple IMU sensors with different capabilities:

- **ADIS165053**: High-precision IMU with 16/32-bit data modes
- **BMI088**: Separate accelerometer and gyroscope components
- **LSM6DSX**: Supports multiple communication protocols (SPI, I2C, MCBSP)

Common features:
- 3D accelerometer and gyroscope measurements
- Temperature compensation
- Configurable filtering
- Self-test capabilities

### 4.2 Magnetometer Sensors

The system supports multiple magnetometer sensors:

- **HSCDTD008A**: 3-axis magnetometer with 15-bit resolution
- **LIS3MDL**: Configurable performance modes and data rates
- **MMC5883MA/MMC5983MA**: Auto-detection of hardware variants
- **RM3100**: High-resolution 24-bit magnetometer

Common features:
- 3D magnetic field measurements
- Temperature compensation
- Configurable filtering
- Calibration for hard/soft iron effects

### 4.3 Pressure Sensors

The system supports multiple pressure sensors:

- **DPS310**: Digital pressure sensor with temperature compensation
- **HSCpress**: Supports both absolute and differential pressure
- **HSCpress_adc**: ADC-based pressure sensor
- **MS561101BA03**: High-precision barometric pressure sensor
- **Honeywell_press**: UART-based pressure sensor

Common features:
- Pressure measurements in Pascal
- Temperature compensation
- Configurable filtering
- Range and delta validation

### 4.4 Distance Sensors

The system supports multiple distance sensors:

- **Garminlite**: Lidar-based distance sensor with multiple configuration modes
- **SFLidar**: Supports both SF11 and SF20 lidar sensors

Common features:
- Distance measurements in meters
- Configurable filtering
- Range and delta validation
- Bias reading mechanisms

### 4.5 Temperature Sensors

The system supports multiple temperature sensors:

- **TMP112**: Digital I2C temperature sensor
- **STLM20/LMT86**: Analog temperature sensors
- **Ntcs0603/Thermistor_b/Thermistor_2nd**: Thermistor-based temperature sensors

Common features:
- Temperature measurements in Kelvin
- Different mathematical models for conversion
- Support for both digital and analog sensors

### 4.6 Navigation Systems

The system supports sophisticated navigation systems:

- **VN300**: GNSS-aided inertial navigation system
- **UBX Protocol**: Comprehensive support for u-blox GPS receivers
- **Internest**: External positioning system for absolute position

Common features:
- Position, velocity, and attitude data
- Time synchronization
- Status monitoring
- Error detection

### 4.7 Storage Devices

The system supports multiple storage devices:

- **EEPROM_24CS**: I2C-based EEPROM storage
- **MX66L**: SPI-based NOR Flash storage
- **USDdrv**: SPI-based MicroSD card storage

Common features:
- Block-based storage operations
- Sector addressing
- Asynchronous operations
- Error detection and recovery

### 4.8 Specialized Sensors

The system supports various specialized sensors:

- **PMIC_TPS65381A**: Power management IC
- **Sincos_sensor**: Analog encoder for position
- **Speed_hall**: Hall effect speed sensor
- **Transponder**: ADS-B/Remote ID functionality
- **Arinc_hi_3210**: ARINC 429 controller

## 5. Error Handling and Validation Approaches

### 5.1 Range and Delta Checking

All sensors implement range and delta checking using `Rangedeltacheck_nv` or `Rangedeltacheck3_nv`:

```cpp
Base::Rangedeltacheck_nv dcheck(min_value, max_value, max_delta, max_no_variation);

// Usage
if(dcheck.check_var(value, false) && dcheck.get_nv()) {
    // Process valid measurement
}
```

This ensures:
- Measurements are within valid ranges
- Changes between measurements are not too large
- Sensors are not stuck (non-variation detection)

### 5.2 Communication Error Handling

The system implements protocol-specific error handling:

- **I2C**: Detects NAK, bus errors, and timeouts
- **SPI**: Detects transfer errors and timeouts
- **UART**: Detects framing errors, parity errors, and timeouts
- **ADC**: Detects conversion errors and timeouts

When errors occur, drivers transition to error states and implement recovery mechanisms.

### 5.3 Initialization Failure Handling

Most drivers implement initialization failure handling:

```cpp
if(n_init_fails < max_fails) {
    state = s_init;
    ++n_init_fails;
} else {
    state = s_error_disabled;
}
```

This prevents endless initialization attempts when hardware is faulty.

### 5.4 Watchdog Mechanisms

Some drivers implement watchdog mechanisms to detect communication loss:

```cpp
if (!wdog.watch()) {
    data.navigation_ok = false;
}
```

This ensures that stale data is not used when communication is lost.

## 6. Simulation and Testing Support

### 6.1 Simulation Integration

All sensor drivers integrate with the simulation framework:

```cpp
// For 1D sensors
simdev.replace_measure(value);
simdev.replace_simtemp(temp);

// For 3D sensors
simdev.replace_measure(vector);
simdev.replace_simtemp(temp);
```

This allows seamless switching between real and simulated sensors.

### 6.2 SIL Implementations

The system provides Software-in-the-Loop (SIL) implementations of all drivers:

- Maintain the same public interfaces
- Preserve state machine architecture
- Simulate communication protocols
- Generate realistic sensor data

This enables comprehensive testing without physical hardware.

### 6.3 Noise Generation

The simulation framework provides realistic noise generation:

- **Real Noise**: Extracts noise characteristics from actual measurements
- **Synthetic Noise**: Generates Gaussian noise with specified variance
- **No Noise**: Uses exact simulated values

This ensures that simulated data has realistic characteristics.

## 7. Key Architectural Decisions and Their Implications

### 7.1 Interface-Based Design

**Decision**: Use interface-based design with abstract base classes.

**Implications**:
- **Positive**: Enables polymorphism and code reuse
- **Positive**: Simplifies testing with mock implementations
- **Positive**: Allows for future hardware changes without affecting higher layers
- **Challenge**: Requires careful interface design to accommodate all sensor types

### 7.2 State Machine Architecture

**Decision**: Implement state machines for all sensor drivers.

**Implications**:
- **Positive**: Clear separation of concerns
- **Positive**: Robust error handling
- **Positive**: Predictable behavior
- **Challenge**: Increased complexity for simple sensors
- **Challenge**: Requires careful state transition design

### 7.3 Common Measurement Processing Pipeline

**Decision**: Use a consistent measurement processing pipeline for all sensors.

**Implications**:
- **Positive**: Consistent behavior across sensors
- **Positive**: Simplified integration with higher layers
- **Positive**: Easier maintenance and debugging
- **Challenge**: May be overkill for simple sensors
- **Challenge**: Requires careful tuning of validation parameters

### 7.4 Simulation Framework Integration

**Decision**: Integrate all sensors with the simulation framework.

**Implications**:
- **Positive**: Enables comprehensive testing without hardware
- **Positive**: Simplifies development and debugging
- **Positive**: Supports hardware-in-the-loop testing
- **Challenge**: Requires maintaining both real and simulated implementations
- **Challenge**: Ensuring simulated data accurately represents real-world conditions

### 7.5 Protocol Abstraction

**Decision**: Abstract communication protocols behind interfaces.

**Implications**:
- **Positive**: Shields sensor drivers from protocol details
- **Positive**: Allows for protocol changes without affecting sensor drivers
- **Positive**: Simplifies testing with mock protocols
- **Challenge**: May hide protocol-specific optimizations
- **Challenge**: Requires careful interface design to accommodate all protocols

## 8. System Reliability and Maintainability

### 8.1 Reliability Features

The sensor system implements several reliability features:

1. **Redundancy**: Support for multiple sensors of the same type
2. **Validation**: Comprehensive data validation
3. **Error Recovery**: Robust error detection and recovery mechanisms
4. **Watchdog Mechanisms**: Detection of communication loss
5. **Graceful Degradation**: Continued operation with reduced functionality

### 8.2 Maintainability Features

The system is designed for maintainability:

1. **Consistent Architecture**: Common patterns across all sensors
2. **Clear Separation of Concerns**: Each component has a well-defined responsibility
3. **Interface-Based Design**: Allows for component replacement without affecting other parts
4. **Comprehensive Testing**: Support for both unit and integration testing
5. **Simulation Support**: Testing without physical hardware

### 8.3 Extensibility Features

The system is designed for extensibility:

1. **Abstract Interfaces**: New sensor types can implement existing interfaces
2. **Configuration Management**: New configuration parameters can be added
3. **Protocol Abstraction**: New communication protocols can be added
4. **Simulation Framework**: New sensors can be simulated
5. **State Machine Architecture**: New states can be added for additional functionality

## 9. Conclusion

The sensor system architecture provides a robust, maintainable, and extensible foundation for integrating diverse sensor types. By following consistent design patterns and implementing comprehensive error handling, the system ensures reliable operation in both normal and off-nominal conditions.

The integration with the simulation framework enables thorough testing without physical hardware, while the state machine architecture provides clear separation of concerns and robust error handling. The common measurement processing pipeline ensures consistent behavior across all sensor types, simplifying integration with higher layers.

This architecture successfully balances the competing requirements of reliability, maintainability, and extensibility, creating a system that can adapt to changing requirements and hardware configurations while maintaining high reliability standards.