# Generated from:

- code/include/Sara.h (762 tokens)
- code/include/Sara_cfg.h (150 tokens)
- code/include/Sara_cfg_fw.h (23 tokens)
- code/source/Sara.cpp (436 tokens)
- code/source/Sara_cfg.cpp (65 tokens)

## With context from:

- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/devices/04_Communication_Protocols.md (3756 tokens)

---

# Sara Cellular Communication Driver

This document provides a comprehensive analysis of the Sara cellular communication driver, which manages the Sara modem for cellular connectivity. The driver handles power control, SIM selection, configuration, and communication through multiple ports.

## 1. Core Architecture and Components

The Sara driver is implemented in the `Devices` namespace and consists of the following key components:

### 1.1 Class Structure

```cpp
class Sara {
public:
    typedef Tpcutdtsk<Base::Itport_u8,Uint8,Rawpcfg> Tport_4g;
    typedef Base::Tport<Base::Itport_u8> Tport_aux;
    
    // Public methods
    Tport_4g& get_4g_port();
    Tport_aux& get_aux_port();
    
    Sara(Base::Itport_u8& port_4g,
         Base::Itport_u8& port_aux,
         Base::IGpio& gpio_sim_select0,
         Dsp28335_ent::GPIO& gpio_3Gon0,
         Dsp28335_ent::GPIO& gpio_reset0,
         Dsp28335_ent::GPIO& gpio_pwron0);
    
    void config(const Sara_cfg& cfg);
    void set_enabled(bool en);
    void sim_select(Sara_cfg::Simchoice sc);
    
private:
    Tport_4g port_4g;                              // 4G Port
    Base::Tdtask<Tport_4g, Base::Lossy> dtsk;      // Dynamic task for configuration
    bool pending;                                  // Flag to apply cfg (only applied once)
    Tport_aux port_aux;                            // Auxiliary Port
    
    Base::IGpio& gpio_sim_select;                  // SIM/ESIM select GPIO
    Dsp28335_ent::GPIO& gpio_3Gon;                 // 3G on GPIO
    Dsp28335_ent::GPIO& gpio_reset;                // Reset GPIO
    Dsp28335_ent::GPIO& gpio_pwron;                // Power on GPIO
    
    // Deleted constructors/operators
    Sara();
    Sara(const Sara& orig);
    Sara& operator=(const Sara& orig);
};
```

### 1.2 Configuration Structure

```cpp
struct Sara_cfg {
    enum Simchoice {
        sc_esim,    // Virtual SIM
        sc_sim      // Physical SIM
    };

    static const Uint16 cfg_words = 300;

    bool en;                              // SARA enable flag
    Simchoice sim;                        // SIM type selected
    Base::Tnuarray<cfg_words> rawcfg;     // Raw configuration data
    
    void cset(Base::Lossy_error& str);
};
```

## 2. Communication Ports and Interfaces

The Sara driver manages two communication ports:

### 2.1 4G Port (Main Communication Port)

```cpp
Tport_4g port_4g;  // 4G Port
```

- Implemented as a `Tpcutdtsk<Base::Itport_u8,Uint8,Rawpcfg>` type
- Used for primary communication with the Sara modem
- Configured at build-time through `Xcfgmgr` with `Rawpcfg`
- Accessed at runtime through `Xpcu8suite` interface
- Supports a dynamic task mechanism for configuration

### 2.2 Auxiliary Port

```cpp
Tport_aux port_aux;  // Auxiliary Port
```

- Implemented as a `Base::Tport<Base::Itport_u8>` type
- Provides secondary communication channel with the Sara modem
- Used for auxiliary functions and diagnostics

### 2.3 Port Access Methods

```cpp
Tport_4g& get_4g_port();
Tport_aux& get_aux_port();
```

These methods provide access to the communication ports for external components to interact with the Sara modem.

## 3. Modem Operation Modes

The Sara driver documentation describes the operational modes of the modem:

```
Sara configuration and connection is different from what we expected:
By default Sara starts in command mode even if we setup SocketAlwaysOn.
If a successful connection is made then it switches to data mode.
If there is no connection, we cannot go to data mode (remains in command mode).
If we are already in data mode and connection is lost, it remains in data mode.
```

This behavior indicates:

1. **Command Mode** - Default startup mode for configuration and control
2. **Data Mode** - Active communication mode after successful connection
3. **Mode Transitions**:
   - Command → Data: Occurs after successful connection
   - Data → Command: Does not occur automatically on connection loss

## 4. Hardware Control and Power Management

The Sara driver controls the modem hardware through four GPIO pins:

### 4.1 GPIO Pins

```cpp
Base::IGpio& gpio_sim_select;   // SIM/ESIM select GPIO
Dsp28335_ent::GPIO& gpio_3Gon;  // 3G on GPIO
Dsp28335_ent::GPIO& gpio_reset; // Reset GPIO
Dsp28335_ent::GPIO& gpio_pwron; // Power on GPIO
```

### 4.2 Power Control Implementation

```cpp
void Sara::set_enabled(bool en) {
    if(en) {
        gpio_3Gon.set_hi();
        gpio_reset.set_hi();
        gpio_pwron.set_hi();
    } else {
        gpio_3Gon.set_lo();
        gpio_reset.set_lo();
        gpio_pwron.set_lo();
    }
}
```

This method controls the power state of the Sara modem by manipulating the GPIO pins:
- When enabled (`en = true`): All control pins are set high, powering on the modem
- When disabled (`en = false`): All control pins are set low, powering off the modem

## 5. SIM Selection and Management

The Sara driver supports two SIM options: a physical SIM card and an embedded SIM (eSIM).

### 5.1 SIM Choice Enumeration

```cpp
enum Simchoice {
    sc_esim,    // Virtual SIM
    sc_sim      // Physical SIM
};
```

### 5.2 SIM Selection Implementation

```cpp
void Sara::sim_select(Sara_cfg::Simchoice sc) {
    switch(sc) {
        case Sara_cfg::sc_esim:
            gpio_sim_select.set_lo();
            break;
        case Sara_cfg::sc_sim:
            gpio_sim_select.set_hi();
            break;
    }
}
```

This method controls which SIM is active by manipulating the `gpio_sim_select` pin:
- For eSIM (`sc_esim`): The GPIO is set low
- For physical SIM (`sc_sim`): The GPIO is set high

## 6. Configuration Management

The Sara driver implements a sophisticated configuration mechanism that applies settings to the modem.

### 6.1 Configuration Structure

```cpp
struct Sara_cfg {
    static const Uint16 cfg_words = 300;
    
    bool en;                              // SARA enable flag
    Simchoice sim;                        // SIM type selected
    Base::Tnuarray<cfg_words> rawcfg;     // Raw configuration data
    
    void cset(Base::Lossy_error& str);
};
```

The configuration includes:
- Enable flag (`en`): Controls whether the modem is powered on
- SIM selection (`sim`): Selects between physical SIM and eSIM
- Raw configuration data (`rawcfg`): Contains up to 300 words of configuration data

### 6.2 Configuration Validation

```cpp
void Sara_cfg::cset(Base::Lossy_error& str) {
    str.get_bool16(en);
    str.get_enum16(sim);
    rawcfg.cset(str);

    str.assrt((sim == sc_esim) || (sim == sc_sim), Base::err_sara);
}
```

This method:
1. Reads configuration values from the provided `Lossy_error` object
2. Validates that the SIM choice is valid (either `sc_esim` or `sc_sim`)
3. Reports an error if validation fails

### 6.3 Configuration Application

```cpp
void Sara::config(const Sara_cfg& cfg) {
    sim_select(cfg.sim);
    set_enabled(cfg.en);

    if(pending && cfg.en) { // only write to Sara once and only if enabled
        pending = false;
        dtsk.start(Base::Lossy(const_cast<Sara_cfg&>(cfg).rawcfg.to_mblock()));
    }
}
```

This method:
1. Applies SIM selection based on configuration
2. Sets the power state based on the enable flag
3. If configuration is pending and the modem is enabled:
   - Marks configuration as no longer pending
   - Starts a dynamic task to apply the raw configuration data to the modem

## 7. Dynamic Task Mechanism

The Sara driver uses a dynamic task mechanism to apply configuration to the modem asynchronously.

### 7.1 Dynamic Task Components

```cpp
Tport_4g port_4g;                              // 4G Port
Base::Tdtask<Tport_4g, Base::Lossy> dtsk;      // Dynamic task for configuration
bool pending;                                  // Flag to apply cfg (only applied once)
```

### 7.2 Dynamic Task Initialization

```cpp
Sara::Sara(...) :
    port_4g(port_4g0, Sara_cfg::cfg_words),
    dtsk(port_4g),
    pending(true),
    ...
{
    set_enabled(false);
    sim_select(Sara_cfg::sc_esim);
}
```

The dynamic task is initialized with:
- A reference to the 4G port
- The `pending` flag set to true, indicating configuration needs to be applied

### 7.3 Dynamic Task Execution

```cpp
if(pending && cfg.en) { // only write to Sara once and only if enabled
    pending = false;
    dtsk.start(Base::Lossy(const_cast<Sara_cfg&>(cfg).rawcfg.to_mblock()));
}
```

When configuration is applied:
1. The `pending` flag is set to false to prevent multiple configurations
2. The dynamic task is started with the raw configuration data
3. The configuration is only applied if the modem is enabled

## 8. Error Handling and Validation

The Sara driver implements several error handling and validation mechanisms:

### 8.1 Configuration Validation

```cpp
str.assrt((sim == sc_esim) || (sim == sc_sim), Base::err_sara);
```

This assertion ensures that the SIM choice is valid, reporting an error if not.

### 8.2 One-Time Configuration

```cpp
if(pending && cfg.en) { // only write to Sara once and only if enabled
    pending = false;
    dtsk.start(Base::Lossy(const_cast<Sara_cfg&>(cfg).rawcfg.to_mblock()));
}
```

The `pending` flag ensures that configuration is only applied once, preventing potential issues from multiple configuration attempts.

### 8.3 Power State Management

```cpp
void Sara::set_enabled(bool en) {
    if(en) {
        gpio_3Gon.set_hi();
        gpio_reset.set_hi();
        gpio_pwron.set_hi();
    } else {
        gpio_3Gon.set_lo();
        gpio_reset.set_lo();
        gpio_pwron.set_lo();
    }
}
```

This method ensures that all power control pins are set consistently, preventing undefined hardware states.

## 9. Integration with Communication System

The Sara driver integrates with the broader communication system through:

### 9.1 Port Interfaces

```cpp
Tport_4g& get_4g_port();
Tport_aux& get_aux_port();
```

These methods expose the communication ports to other components in the system.

### 9.2 Configuration Interface

```cpp
void config(const Sara_cfg& cfg);
```

This method allows the system to configure the Sara modem with specific settings.

### 9.3 Dynamic Task Integration

```cpp
typedef Tpcutdtsk<Base::Itport_u8,Uint8,Rawpcfg> Tport_4g;
```

The 4G port is implemented as a `Tpcutdtsk` type, which integrates with the dynamic task system to allow blocking operations until configuration is complete.

## 10. Initialization Sequence

The Sara driver follows a specific initialization sequence:

1. **Constructor Initialization**:
   ```cpp
   Sara::Sara(...) :
       port_4g(port_4g0, Sara_cfg::cfg_words),
       dtsk(port_4g),
       pending(true),
       port_aux(port_aux, port_aux),
       gpio_sim_select(gpio_sim_select0),
       gpio_3Gon(gpio_3Gon0),
       gpio_reset(gpio_reset0),
       gpio_pwron(gpio_pwron0)
   {
       set_enabled(false);
       sim_select(Sara_cfg::sc_esim);
   }
   ```
   - Initializes ports and GPIO references
   - Sets the modem to disabled state
   - Selects the eSIM by default

2. **Configuration Application**:
   ```cpp
   void Sara::config(const Sara_cfg& cfg) {
       sim_select(cfg.sim);
       set_enabled(cfg.en);

       if(pending && cfg.en) {
           pending = false;
           dtsk.start(Base::Lossy(const_cast<Sara_cfg&>(cfg).rawcfg.to_mblock()));
       }
   }
   ```
   - Applies SIM selection
   - Sets power state
   - Applies raw configuration if needed

## 11. Referenced Context Files

The following context file was helpful in understanding the communication architecture:

- `Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/devices/04_Communication_Protocols.md`
  - Provided insights into the communication protocol implementations used in the system
  - Helped understand how the Sara driver fits into the broader communication architecture
  - Explained the pattern of using interface abstraction for device drivers

This context file showed that the Sara driver follows similar patterns to other communication drivers in the system, using interface abstraction, state machines, and buffering mechanisms.