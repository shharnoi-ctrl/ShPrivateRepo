# Generated from:

- code/include/EEPROM_24CS.h (2398 tokens)
- code/include/MX66L.h (2816 tokens)
- code/include/USDdrv.h (7867 tokens)
- code/source/EEPROM_24CS.cpp (2338 tokens)
- code/source/MX66L.cpp (5511 tokens)
- code/source/USDdrv.cpp (17436 tokens)

## With context from:

- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/devices/04_Communication_Protocols.md (3756 tokens)

---

# Storage Device Drivers: Common Interface and Implementation Details

This comprehensive analysis examines the storage device drivers in the system, focusing on their common interface (`Iblock_device`) and specific implementations for different storage technologies: EEPROM (24CS), NOR Flash (MX66L), and MicroSD (USDdrv). The document details how these drivers handle block-based storage operations, manage sector addressing, and implement both synchronous and asynchronous operations.

## 1. Common Interface: `Iblock_device`

All storage device drivers implement the `Base::Iblock_device` interface, which provides a unified API for block-based storage operations:

```cpp
class Iblock_device {
public:
    virtual bool init_medium();
    virtual bool is_init() const;
    virtual Uint32 get_sector_size() const;
    virtual Uint32 get_sector_count() const;
    
    // Synchronous operations
    virtual bool read_sector(Uint32 sector, Base::U8pkmblock& buffer);
    virtual bool write_sector(Uint32 SectorNo, const Base::U8pkmblock_k& buffer);
    
    // Asynchronous operations
    virtual Base::Async_res read_sector_start(Uint32 sector);
    virtual Base::Async_res read_sector_get_data(Base::U8pkmblock& buffer);
    virtual Base::Async_res write_sector_start(Uint32 sector, const Base::U8pkmblock_k& buffer);
    virtual Base::Async_res write_sector_ended();
};
```

This interface enables consistent access to different storage technologies through a common set of operations.

## 2. EEPROM_24CS Driver

### 2.1 Overview and Architecture

The `EEPROM_24CS` class implements both the `Dsp28335_ent::I2Cdevice` and `Base::Iblock_device` interfaces, providing access to a 24CS256 I2C EEPROM:

```cpp
class EEPROM_24CS: public Dsp28335_ent::I2Cdevice, public Base::Iblock_device
```

Key characteristics:
- Uses I2C protocol for communication
- Fixed sector size of 64 bytes
- 500 pages (sectors) total
- Total capacity of 32,000 bytes (64 bytes × 500 pages)

### 2.2 State Machine

The EEPROM driver implements a state machine to manage operations:

```cpp
enum State {
    st_por,  // Power-on reset state, wait for mandatory time
    st_ini,  // Initialized state, do nothing
    st_crd,  // Read state, start read command
    st_cwr,  // Write state, start write command
    st_wop,  // Wait state, just forward to st_ini when called
    st_err   // Error state
};
```

The state transitions are handled in the `do_step()` method:

```cpp
void do_step() {
    if(is_enabled()) {
        switch(state) {
            case st_por:
                if(chr.toc() > wait_por_s) {
                    state = st_ini;
                }
                break;
            case st_ini:
                callst.call();
                break;
            case st_crd:
                read(page_sz);
                state = st_wop;
                break;
            case st_cwr:
                if(to_write == 0) {
                    Bsp::warning();
                    state = st_err;
                } else {
                    send(*to_write);
                    state = st_wop;
                }
                break;
            case st_wop:
                to_write = 0;
                state = st_ini;
                break;
            case st_err:
                // can only change by calling I2Cdevice::set_ok with parameter at true
                break;
        }
    }
}
```

### 2.3 Asynchronous Operations

The EEPROM driver implements asynchronous operations through state machine transitions:

1. **Read Operation**:
   ```cpp
   Async_res read_sector_start(Uint32 sector) {
       Async_res res = async_busy_error;
       if(is_init0() && start_request(sector)) {
           res = async_done_ok;
           state = st_crd;
       }
       return res;
   }
   
   Async_res read_sector_get_data(U8pkmblock& buffer) {
       Async_res res = async_ongoing;
       if(is_init0()) {
           buffer.write(I2Cdevice::get_buffer());
           res = async_done_ok;
       } else if(state == st_err) {
           res = async_done_error;
       }
       return res;
   }
   ```

2. **Write Operation**:
   ```cpp
   Async_res write_sector_start(Uint32 sector, const U8pkmblock_k& buffer) {
       Async_res res = async_busy_error;
       if(is_init0() && start_request(sector)) {
           Assertions::runtime(to_write == 0);
           to_write = &buffer;
           res = async_done_ok;
           state = st_crd;
       }
       return res;
   }
   
   Async_res write_sector_ended() {
       Async_res res = async_busy_error;
       if(is_init0()) {
           res = async_done_ok;
       } else if(state == st_err) {
           res = async_done_error;
       } else {
           res = async_ongoing;
       }
       return res;
   }
   ```

### 2.4 I2C Communication

The EEPROM driver uses I2C communication with a fixed address:

```cpp
static const Uint8 eeprom_addr = 0x50;  // I2C address for EEPROM
```

The driver handles I2C communication through the `start_request()` method:

```cpp
bool start_request(Uint16 page_idx) {
    bool ret = check_idx(page_idx);
    if(ret) {
        Base::U8ostream ostr(cmd_mb);
        ostr.put_uint16_le(page_idx*page_sz);
        ret = send(cmd_mb);
    }
    return ret;
}
```

### 2.5 Timing Considerations

The EEPROM driver implements specific timing requirements:

```cpp
// From datasheet TABLE 1-4: TPOFF Minimum time at VCC = 0V between power cycles 1 ms
static const Real wait_por_s = Const::E1000;

// From datasheet TABLE 1-2: TWC Write Cycle Time (byte or page) 5 ms
static const Real wait_wrt_s = 5E-3F;
```

## 3. MX66L NOR Flash Driver

### 3.1 Overview and Architecture

The `MX66L` class implements the `Base::Iblock_device` interface, providing access to MX66L NOR Flash memory:

```cpp
class MX66L : public Base::Iblock_device
```

Key characteristics:
- Uses SPI protocol for communication
- Hardware sector size of 256 bytes
- Virtual sector size of 512 bytes (compatible with DFS2)
- Minimum erase block is 4KB (16 sectors)
- Total capacity of 134,217,728 bytes (128 MB)

### 3.2 State Machine

The MX66L driver implements a state machine to manage operations:

```cpp
enum Status_t {
    st_not_init,        // Not initialized
    st_err_not_found,   // Error: Device not found
    st_idle,            // Initialized and waiting for commands
    st_reading,         // Waiting for reading to complete
    st_writing_start,   // Writing start
    st_writing,         // Waiting data to flash
    st_writing_wait,    // Waiting for writing to complete
    st_erasing          // Waiting for erase to complete
};
```

### 3.3 Flash Commands and Registers

The MX66L driver defines commands for interacting with the flash memory:

```cpp
enum Cmd {
    cmd_nop             = 0x00, // No-operation
    cmd_wrsr            = 0x01, // Write status register
    cmd_rdsr            = 0x05, // Read status register
    cmd_read_id         = 0x9F, // Read device id
    cmd_write_dis       = 0x04, // Write disable
    cmd_write_en        = 0x06, // Write enable
    cmd_page_program4b  = 0x12, // Page program, up to 256 Bytes (4byte address)
    cmd_read4b          = 0x13, // Read request (4byte address)
    cmd_sector_erase4b  = 0x21, // Sector(4KB) erase request (4byte address)
    cmd_chip_erase      = 0xC7  // Whole chip erase
};
```

It also defines register structures for status and configuration:

```cpp
union Status_reg {
    Uint8 all;          // Full field value in Status_reg
    struct {
        Uint8 wip:1;    // Write in progress
        Uint8 wel:1;    // Write enabled
        Uint8 bp0:1;    // Level of protected block
        Uint8 bp1:1;    // Level of protected block
        Uint8 bp2:1;    // Level of protected block
        Uint8 bp3:1;    // Level of protected block
        Uint8 qe: 1;    // Quad mode enabled
        Uint8 srwd:1;   // Status register write protect (1==disabled)
    };
};

union Config_reg {
    Uint8 all;          // Full field value in Config_reg
    struct {
        Uint8 ods:3;    // Output driver strength
        Uint8 tb:1;     // Top/bottom selected
        Uint8 pbe:1;    // Preamble bit enable
        Uint8 fam:1;    // 4 byte addressing mode enabled
        Uint8 dummy_c:2;// Dummy cycles
    };
};
```

### 3.4 Erase Block Management

The MX66L driver manages erase blocks (4KB) separately from sectors (512B):

```cpp
static const Uint32 hw_erase_blk_sz   =  16UL;
static const Uint32 hw_erase_blk_mask = ~(hw_erase_blk_sz-1);

inline Uint32 get_sector(Uint32 sector) {
    return (sector & hw_erase_blk_mask);
}
```

This is used during write operations to ensure proper erase cycles:

```cpp
Async_res write_sector_ended() {
    Async_res res = async_busy_error;
    switch(status) {
        case st_writing_start: {
            const Uint32 sector_base = get_sector(wr_sector);
            if(sector_base == erased_sector) { // Was already erased?
                status = st_writing;
                res = async_ongoing;
            } else {
                send_write_en(); // enable write
                U8ostream os(tx_cmd);
                os.put_uint8(cmd_sector_erase4b);
                os.put_uint32_be(sector_base * hw_bytes_per_sector);
                const bool bres = spi_aux.write(tx_cmd); // Write the command
                if(bres) {
                    status = st_erasing;
                    res = async_ongoing;
                } else {
                    status = st_idle;
                    res = async_done_error;
                }
            }
            break;
        }
        // Other cases...
    }
    return res;
}
```

### 3.5 SPI Communication

The MX66L driver uses SPI communication through the `SPI_port_util` class:

```cpp
Dsp28335_ent::SPI_port_util spi_aux;    // Read/Write buffers and setup
```

The driver implements specific timing requirements for chip select operations:

```cpp
static const Uint32 cs_en_ns = 10U;     // Time to wait after CS enable (ns)
static const Uint32 cs_dis_ns = 10U;    // Time to wait before CS disable (ns)
```

## 4. USDdrv MicroSD Driver

### 4.1 Overview and Architecture

The `USDdrv` class implements the `Base::Iblock_device` interface, providing access to MicroSD cards:

```cpp
class USDdrv : public Base::Iblock_device
```

Key characteristics:
- Uses SPI protocol for communication
- Fixed sector size of 512 bytes
- Supports multiple card types: MMC, SD, and SDHC
- Variable capacity based on card size

### 4.2 Card Initialization and Detection

The USDdrv driver implements a complex initialization sequence to detect and configure different card types:

```cpp
bool init_medium() {
    bool r = true;
    if(!is_init()) {
        if(init()) {
            status = st_idle; // Ready
        } else {
            Bsp::warning();
            r = false;
        }
    }
    return r;
}

bool init() {
    static const Uint16 STARTUPFREQ = 400;     // Max. startup frequency (hardware specific)
    Uint16 currfrec = 0;
    bool r = false;

    currfrec = set_max_speed(STARTUPFREQ); // set initial speed for SPI
    if (currfrec <= STARTUPFREQ) {
        // Initialize card...
        // Try different card types...
        if(r) {
            read_card_id();
        }
    }
    return r;
}
```

The driver attempts to initialize the card as different types:

```cpp
// Send CMD8 to card, SD HC or SD cards V2.00 card will accept the command
response = exec_cmd8();

if ((response & Ku8::u4)) {
    // Illegal command, not a SD V2 card
    r = init_SDv1();   // Try to init as SDv1 card
    if(!r) {
        r = init_MMC();  // It is not a SDv1 card, try to init as MMC
    }
} else {
    // Check if it's a V2 SD card
    if ((aResponse7[Ku8::u3] == Pattern[0]) && ((aResponse7[Ku8::u2] & mask_0x0F) == Pattern[1])) {
        r = init_SDV2();
    }
}
```

### 4.3 Card Commands and Responses

The USDdrv driver defines commands for interacting with SD/MMC cards:

```cpp
enum Card_cmd {
    CMD_GO_IDLE_STATE        =  0,  // Go idle state command
    CMD_SEND_OP_COND         =  1,  // Send operation condition command
    CMD_ALL_SEND_CID         =  2,  // All send CID command
    CMD_SET_REL_ADDR         =  3,  // Set relative address command
    CMD_SWITCH_FUNC          =  6,  // Switch function command
    CMD_SELECT_CARD          =  7,  // Select card command
    CMD_SEND_IF_COND         =  8,  // Send interface condition command
    CMD_SEND_CSD             =  9,  // Send CSD (card specific data) command
    CMD_SEND_CID             = 10,  // Send CID (card identification) command
    CMD_STOP_TRANSMISSION    = 12,  // Stop transmission command
    CMD_SEND_STATUS          = 13,  // Send status command
    CMD_SET_BLOCKLEN         = 16,  // Set block length command
    CMD_READ_SINGLE_BLOCK    = 17,  // Read single block command
    CMD_READ_MULTIPLE_BLOCKS = 18,  // Read multiple blocks command
    CMD_WRITE_BLOCK          = 24,  // Write block command
    CMD_WRITE_MULTIPLE_BLOCK = 25,  // Write multiple blocks command
    CMD_ACMD_CMD             = 55,  // Application specific command
    CMD_READ_OCR             = 58,  // Read OCR (operation conditions register) command
    ACMD_SEND_OP_COND        = 41   // Application command: send operation condition
};
```

It also defines response tokens:

```cpp
static const Uint8 TOKEN_BLOCK_WRITE_START=0xFE;        // MMC/SD response token indicating the start of a block write operation
static const Uint8 TOKEN_BLOCK_READ_START=0xFE;         // MMC/SD response token indicating the start of a block read operation
static const Uint8 TOKEN_MULTI_BLOCK_WRITE_START=0xFC;  // MMC/SD response token indicating the start of a multi-block write operation
static const Uint8 TOKEN_MULTI_BLOCK_WRITE_STOP=0xFD;   // MMC/SD response token indicating the stop of a multi-block write operation
```

### 4.4 Card Information Extraction

The USDdrv driver extracts card information from the CSD (Card Specific Data) register:

```cpp
bool apply_CSD(const CSD& pCSD) {
    Uint8 ccs = 0;
    bool ret = true;

    if(check_card_OCR(ccs)) {
        // Extract card parameters from CSD
        Uint32 CSDVersion = (inst.CardType == CARD_TYPE_SD) ? CSD_STRUCTURE(pCSD) : 0;
        
        if (CSDVersion == 0) {
            // Calculate parameters for V1 cards
            // ...
        } else if (CSDVersion == 1) {
            // Calculate parameters for V2 cards
            // ...
        }
    } else {
        ret = false;
    }
    return ret;
}
```

The driver extracts various parameters from the CSD register:

```cpp
static Uint32 CSD_STRUCTURE(const CSD& pCSD);
static Uint32 CSD_WRITE_PROTECT(const CSD& pCSD);
static Uint32 CSD_R2W_FACTOR(const CSD& pCSD);
static Uint32 CSD_C_SIZE_MULT(const CSD& pCSD);
static Uint32 CSD_C_SIZE(const CSD& pCSD);
static Uint32 CSD_READ_BL_LEN(const CSD& pCSD);
static Uint32 CSD_C_SIZE_V2(const CSD& pCSD);
static const Uint8& CSD_TRAN_SPEED(const CSD& pCSD);
static const Uint8& CSD_NSAC(const CSD& pCSD);
static const Uint8& CSD_TAAC(const CSD& pCSD);
```

### 4.5 State Machine

The USDdrv driver implements a state machine to manage operations:

```cpp
enum Status_t {
    st_not_init,    // Not initialized
    st_idle,        // Initialized and waiting for commands
    st_reading,     // Waiting for reading to complete
    st_writing      // Waiting for writing to complete
};
```

### 4.6 SPI Communication

The USDdrv driver uses SPI communication through the `SPI` class:

```cpp
Dsp28335_ent::SPI& spi; // SPI peripheral used for SD communications
```

The driver implements specific methods for SPI communication:

```cpp
void enableCS() const;
void disableCS() const;
Uint8 read_byte() const;
void write_byte(const Uint8 pData) const;
void send_empty_cycles(Uint16 n) const;
```

## 5. Common Patterns Across Storage Drivers

### 5.1 Asynchronous Operation Pattern

All drivers implement a common pattern for asynchronous operations:

1. **Start Operation**:
   - Check if the device is initialized and idle
   - Prepare the operation (set up addresses, commands)
   - Update the state machine
   - Return `async_done_ok` if successful

2. **Check Operation Status**:
   - Check if the operation is in progress
   - Return `async_ongoing` if still in progress
   - Return `async_done_ok` if completed successfully
   - Return `async_done_error` if an error occurred

3. **Complete Operation**:
   - Finalize the operation (clean up resources)
   - Update the state machine to idle
   - Return the final status

### 5.2 Synchronous Operation Pattern

All drivers implement synchronous operations by wrapping asynchronous operations:

```cpp
bool read_sector(Uint32 sector, Base::U8pkmblock& buffer) {
    Async_res res = read_sector_start(sector);
    if(res == async_done_ok) {
        res = async_ongoing;
        // Wait for operation to complete with timeout
        while((res == async_ongoing) && (timeout not reached)) {
            res = read_sector_get_data(buffer);
        }
        // Handle timeout
        if(res == async_ongoing) {
            status = st_idle;
            res = async_busy_error;
        }
    }
    return (res == async_done_ok);
}
```

### 5.3 State Machine Pattern

All drivers implement state machines to manage operations:

1. **Initialization States**:
   - `st_not_init`: Device not initialized
   - `st_idle`: Device initialized and ready

2. **Operation States**:
   - Read states (e.g., `st_reading`, `st_crd`)
   - Write states (e.g., `st_writing`, `st_cwr`)
   - Wait states (e.g., `st_wop`, `st_writing_wait`)

3. **Error States**:
   - `st_err`: Error occurred
   - `st_err_not_found`: Device not found

### 5.4 Error Handling Pattern

All drivers implement error handling through:

1. **Status Codes**:
   - `async_done_ok`: Operation completed successfully
   - `async_done_error`: Operation failed
   - `async_ongoing`: Operation in progress
   - `async_busy_error`: Device busy or error

2. **Timeouts**:
   - Timeouts for operations to prevent hanging
   - Reset to idle state if timeout occurs

3. **Warnings**:
   - `Bsp::warning()` to indicate errors

## 6. Protocol-Specific Implementations

### 6.1 I2C Protocol (EEPROM_24CS)

The EEPROM driver uses I2C protocol with:
- Fixed I2C address (0x50)
- Two-byte addressing for pages
- Page-based operations (64 bytes per page)
- Timing requirements for power-on reset and write cycles

### 6.2 SPI Protocol (MX66L and USDdrv)

Both MX66L and USDdrv use SPI protocol but with different command sets:

1. **MX66L**:
   - 4-byte addressing for read/write operations
   - Specific commands for flash operations (erase, program)
   - Status register polling for operation completion

2. **USDdrv**:
   - SD/MMC command protocol over SPI
   - Response token handling
   - CRC handling (though not required in SPI mode)

## 7. Performance and Resource Considerations

### 7.1 Memory Usage

Each driver has different memory requirements:

1. **EEPROM_24CS**:
   - Small command buffer (2 bytes)
   - Page buffer (64 bytes)

2. **MX66L**:
   - Command buffer (5 bytes)
   - Sector buffer (256 bytes)

3. **USDdrv**:
   - Command buffer (6 bytes)
   - Sector buffer (512 bytes)
   - CSD buffer (16 bytes)

### 7.2 Timing Considerations

Each driver has specific timing requirements:

1. **EEPROM_24CS**:
   - Power-on reset time: 1 ms
   - Write cycle time: 5 ms

2. **MX66L**:
   - Chip select timing: 10 ns
   - Erase time: variable (monitored through status register)
   - Write time: variable (monitored through status register)

3. **USDdrv**:
   - Initialization timing: variable based on card type
   - Read/write timing: variable based on card parameters (extracted from CSD)

### 7.3 Error Recovery

Each driver implements different error recovery mechanisms:

1. **EEPROM_24CS**:
   - Error state that requires explicit reset

2. **MX66L**:
   - Status register polling for error detection
   - Automatic retry for read/write operations

3. **USDdrv**:
   - Response token checking for error detection
   - Multiple initialization attempts for different card types

## 8. Summary

The storage device drivers in the system implement a common interface (`Iblock_device`) while providing specialized implementations for different storage technologies:

1. **EEPROM_24CS**:
   - I2C-based EEPROM access
   - 64-byte sectors, 500 pages
   - Simple state machine for operations

2. **MX66L**:
   - SPI-based NOR Flash access
   - 512-byte virtual sectors (256-byte hardware sectors)
   - 4KB erase blocks
   - Complex state machine for erase/write operations

3. **USDdrv**:
   - SPI-based MicroSD card access
   - 512-byte sectors
   - Support for multiple card types
   - Complex initialization sequence

All drivers implement both synchronous and asynchronous operations, with the synchronous operations built on top of the asynchronous ones. They use state machines to manage operations and implement error handling through status codes, timeouts, and warnings.

## Referenced Context Files

The following context file was helpful in understanding the broader system architecture:
- `Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/devices/04_Communication_Protocols.md` - Provided insights into the communication protocols used by the storage drivers, particularly the I2C and SPI interfaces.