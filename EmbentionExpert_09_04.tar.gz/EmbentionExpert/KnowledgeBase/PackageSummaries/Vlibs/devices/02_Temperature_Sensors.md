# Generated from:

- code/include/TMP112.h (1227 tokens)
- code/include/STLM20.h (130 tokens)
- code/include/LMT86.h (205 tokens)
- code/include/Ntcs0603.h (264 tokens)
- code/include/Thermistor_b.h (1098 tokens)
- code/include/Thermistor_2nd.h (476 tokens)
- code/source/TMP112.cpp (1349 tokens)
- code/source/STLM20.cpp (145 tokens)
- code/source/LMT86.cpp (222 tokens)
- code/source/Ntcs0603.cpp (768 tokens)
- code/source/Thermistor_b.cpp (585 tokens)
- code/source/Thermistor_2nd.cpp (465 tokens)

## With context from:

- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/devices/04_Sensor_Device_Framework.md (3568 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/devices/04_Communication_Protocols.md (3756 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/devices/04_Simulation_Framework.md (3965 tokens)

---

# Comprehensive Summary of Temperature Sensor Drivers and Conversion Utilities

This document provides a detailed analysis of the temperature sensor drivers and conversion utilities in the system, focusing on their common architecture, differences, and integration with the simulation framework.

## 1. Temperature Sensor Architecture Overview

The system implements a modular architecture for temperature sensors with several key components:

1. **Sensor Drivers**: Concrete implementations for specific temperature sensor hardware (e.g., TMP112)
2. **Temperature Converters**: Utilities that convert voltage readings to temperature for various sensor types
3. **Thermistor Models**: Classes that implement different mathematical models for thermistor behavior
4. **Common Interfaces**: Abstract base classes that define standard behavior for temperature sensors

### 1.1 Common Architectural Patterns

All temperature sensor implementations share these common patterns:

- **Interface-Based Design**: Sensors implement common interfaces like `ITemp_getter` for temperature conversion
- **Voltage-to-Temperature Conversion**: Each sensor type has specific mathematical formulas to convert voltage readings to temperature
- **Kelvin Temperature Scale**: All temperature values are stored and returned in Kelvin
- **Error Handling**: Boundary checking and validation of input values
- **Simulation Support**: Integration with the simulation framework for testing without physical hardware

## 2. Temperature Sensor Drivers

### 2.1 TMP112 Temperature Sensor Driver

The `TMP112` class implements a driver for the Texas Instruments TMP112 digital temperature sensor, which communicates over I2C.

```cpp
class TMP112: public Dsp28335_ent::I2Cdevice
{
public:
    enum I2Caddr { addr_TMP112A = 0x48, addr_TMP112B = 0x49 };
    
    struct Params {
        Dsp28335_ent::I2Cif& i2c_hdlr;
        const I2Caddr i2c_addr;
        volatile bool& var_buit;
        volatile Real& var_meas;
    };
    
    explicit TMP112(Params params);
    Real get_desired_rate() const;
    Real get_period() const;
    Real get_default_period() const;
    void set_period(const Real& period0);
    bool is_meas_updated() const;
    
protected:
    void do_step();
    void set_ok(bool ok);
    
private:
    enum State { st_init, st_request, st_read, st_gather, st_error };
    
    static const Uint16 i2c_buff_size = 2U;
    static const Uint16 desired_rate = 2U;
    static const Uint16 req_steps = 2U;
    
    Real period_current;
    State state;
    Base::Timeout tout;
    volatile Real& tmp;
    
    void step0(bool ok, State next, State err = st_error);
    void gather_data();
};
```

#### 2.1.1 Communication Protocol

The TMP112 driver uses a finite state machine (FSM) to manage I2C communication:

1. **Initialization State (`st_init`)**: 
   - Waits for a 26ms reset delay after power-up
   - Transitions to `st_request` when timeout expires

2. **Request State (`st_request`)**: 
   - Sends an I2C write command to select the temperature register (0x00)
   - Transitions to `st_read` on success, `st_error` on failure

3. **Read State (`st_read`)**: 
   - Requests an I2C read operation to retrieve 2 bytes of temperature data
   - Transitions to `st_gather` on success, `st_error` on failure

4. **Gather State (`st_gather`)**: 
   - Processes the received temperature data
   - Transitions back to `st_request` to prepare for the next measurement

5. **Error State (`st_error`)**: 
   - Clears the status bit
   - Attempts to recover by transitioning back to `st_request`

#### 2.1.2 Temperature Conversion

The TMP112 driver converts raw sensor data to temperature in Kelvin:

```cpp
void TMP112::gather_data()
{
    // Read 16-bit value in big-endian format
    Uint16 raw_value = Base::U8istream(get_buffer()).get_uint16_be();
    
    // Shift by 4 bits to get 12-bit temperature value
    raw_value >>= Ku16::u4;
    
    // Handle negative temperatures (2's complement)
    static const Uint16 msk_i16 = 0xF000U;
    raw_value |= (raw_value >> Ku16::u11) * (msk_i16);
    
    // Convert to temperature (0.0625°C per bit) and add Kelvin offset
    static const Real conv_fct = 0.0625F;
    tmp = conv_fct * raw_value + Const::C2KELVIN;
    
    // Update statistics and status bit
    callst.call();
    
    // Prepare for next measurement
    state = st_request;
}
```

Key aspects of the conversion:
- The TMP112 provides 12-bit temperature data with 0.0625°C resolution
- The driver handles 2's complement for negative temperatures
- The result is converted to Kelvin by adding 273.15 (C2KELVIN constant)

#### 2.1.3 Timing and Sampling

The TMP112 driver manages its sampling rate:

- Default sampling rate is 2 samples per second
- Each sample requires 2 steps (request and read)
- The driver allows configuring the sampling period via `set_period()`
- The `is_meas_updated()` method indicates when a new measurement is available

## 3. Temperature Conversion Utilities

The system includes several temperature conversion utilities that implement the `ITemp_getter` interface for different sensor types.

### 3.1 Common Interface

```cpp
class ITemp_getter
{
public:
    virtual Real get_temp(Real volt) const = 0;
protected:
    virtual ~ITemp_getter();
};
```

This interface defines a single method `get_temp()` that converts a voltage reading to temperature in Kelvin.

### 3.2 STLM20 Temperature Converter

The `STLM20` class converts voltage readings from an STLM20 analog temperature sensor to temperature:

```cpp
class STLM20 : public Base::ITemp_getter
{
public:
    STLM20();
    virtual Real get_temp(Real volt) const;
};

Real STLM20::get_temp(Real volt) const
{
    static const Real offset = -1481.96F;
    static const Real q1     = 2.1962e6F;
    static const Real q2     = 1.8639F;
    static const Real q3     = 3.88e-6F;
    return offset + Rmath::sqrtr(q1 + (q2 - volt)/(q3)) + Const::C2KELVIN;
}
```

The STLM20 uses a square root formula derived from the sensor's datasheet to convert voltage to temperature.

### 3.3 LMT86 Temperature Converter

The `LMT86` class converts voltage readings from an LMT86 analog temperature sensor to temperature:

```cpp
class LMT86 : public Base::ITemp_getter
{
public:
    LMT86();
    virtual Real get_temp(Real volt) const;
};

Real LMT86::get_temp(Real volt) const
{
    static const Real offset = 30.0F;
    static const Real q0 = 10.888F;
    static const Real q1 = 0.00347F;
    static const Real q2 = 1777.3;
    const Real a = q0;
    const Real b = Rmath::sqrtr((q0*q0) + (4*q1) * (q2 - (volt * Const::ONE_THOUSAND)));
    const Real c = 2 * (-q1);
    return (((a - b) / c) + offset) + Const::C2KELVIN;
}
```

The LMT86 uses a quadratic formula to convert voltage to temperature, based on the sensor's datasheet.

### 3.4 Ntcs0603 Temperature Converter

The `Ntcs0603` class converts voltage readings from an NTCS0603E3103FMT thermistor to temperature:

```cpp
class Ntcs0603 : public Base::ITemp_getter
{
public:
    Ntcs0603();
    virtual Real get_temp(Real volt) const;
};

Real Ntcs0603::get_temp(Real volt) const
{
    static const Real max_adc_voltage = 3.3F;
    static const Real divisor_resist = 13000.0F;
    static const Real inv_temp_ref = 3.35401643468053E-3F;
    static const Real B = 3610.0F;
    static const Real ref_resist = 10000.0F;
    static const Real min_sensor_temp = 218.15F;
    static const Real max_sensor_temp = 423.15F;
    static const Real min_sensor_voltage = 0.06608F;
    static const Real max_sensor_voltage = 3.234F;
    static const Real poly[] = {
        -3.51539395083514E-4F,
        0.231794391540713F,
        -37.8872385908591F
    };

    Real temp;
    if (volt < min_sensor_voltage)
    {
        temp = min_sensor_temp;
    }
    else if (volt > max_sensor_voltage)
    {
        temp = max_sensor_temp;
    }
    else
    {
        temp = divisor_resist * ((max_adc_voltage / volt) - 1.0F);
        temp = inv_temp_ref + (Rmath::logr(temp / ref_resist)) / B;
        temp = 1.0f / temp;
        temp = temp + poly[Ku16::u2] + (poly[Ku16::u1] + poly[Ku16::u0] * temp) * temp;
    }
    return temp;
}
```

The Ntcs0603 implementation:
1. Checks if the voltage is within valid range
2. Converts voltage to resistance using the voltage divider equation
3. Applies the Steinhart-Hart thermistor equation to convert resistance to temperature
4. Applies a polynomial correction for improved accuracy
5. Returns the temperature in Kelvin

## 4. Thermistor Models

The system includes two thermistor model implementations that provide more general-purpose temperature conversion capabilities.

### 4.1 Beta Parameter Thermistor Model

The `Thermistor_b` class implements the beta parameter model for thermistors:

```cpp
class Thermistor_b : public Ithermistor
{
public:
    struct Config
    {
        Resistor_div::Config r_div_cfg;
        Real beta;
        Real t0;
        Real r0;
        Config();
    };
    
    Thermistor_b();
    Thermistor_b(const Config& cfg);
    void config(const Config& cfg);
    Config get_config() const;
    Resistor_div get_resistor() const;
    virtual Real compute_temp(Real vt_norm) const;
    
private:
    Config cfg;
    Resistor_div r_div;
};
```

The beta parameter model uses the equation:
```
R_T = R_0 * e^(B * (1/T - 1/T_0))
```

Where:
- R_T is the thermistor resistance at temperature T
- R_0 is the reference resistance at temperature T_0
- B is the beta parameter
- T is the temperature in Kelvin
- T_0 is the reference temperature in Kelvin

The implementation:
1. Converts normalized voltage to resistance using the `Resistor_div` class
2. Applies the beta parameter equation to convert resistance to temperature
3. Returns the temperature in Kelvin

```cpp
Real Thermistor_b::compute_temp(Real vt_norm) const
{
    const Real rt = r_div.compute_r(vt_norm);
    const Real res = cfg.beta / (Rmath::logr(rt/cfg.r0) + cfg.beta/cfg.t0);
    return res;
}
```

### 4.2 Second-Order Polynomial Thermistor Model

The `Thermistor_2nd` class implements a second-order polynomial model for thermistors:

```cpp
class Thermistor_2nd : public Ithermistor
{
public:
    struct Config
    {
        Resistor_div::Config r_div_cfg;
        Real a;
        Real b;
        Real t0;
        Real r0;
        Config();
    };
    
    Thermistor_2nd();
    Thermistor_2nd(const Config& cfg);
    void config(const Config& cfg);
    virtual Real compute_temp(Real vt_norm) const;
    
private:
    Config cfg;
    Resistor_div r_div;
};
```

The second-order polynomial model uses the equation:
```
R_T = R_0 * [1 + A * (T - T_0) + B * (T - T_0)^2]
```

Where:
- R_T is the thermistor resistance at temperature T
- R_0 is the reference resistance at temperature T_0
- A is the first-order coefficient
- B is the second-order coefficient
- T is the temperature in Kelvin
- T_0 is the reference temperature in Kelvin

The implementation:
1. Converts normalized voltage to resistance using the `Resistor_div` class
2. Solves the quadratic equation to find temperature
3. Selects the physically meaningful solution within a reasonable temperature range
4. Returns the temperature in Kelvin

```cpp
Real Thermistor_2nd::compute_temp(Real vt_norm) const
{
    const Real rt = r_div.compute_r(vt_norm);
    
    const Real b_4 = 4*cfg.b;
    const Real sqrt_v = cfg.r0*(cfg.r0*cfg.a*cfg.a + b_4*rt - b_4*cfg.r0);
    const Real sq_el = Rmath::sqrtr(sqrt_v);
    
    const Real a_r0      = cfg.a*cfg.r0;
    const Real b_r0_2    = Const::TWO*cfg.b*cfg.r0;
    const Real b_r0_2_t0 = b_r0_2*cfg.t0;
    const Real i_b_r0_2  = Const::ONE/b_r0_2;
    
    const Real nres = -(sq_el + a_r0 - b_r0_2_t0) * i_b_r0_2;
    const Real pres =  (sq_el - a_r0 + b_r0_2_t0) * i_b_r0_2;
    
    static const Real min_temp = 173.15F; // -100C
    static const Real max_temp = 623.15F; // +350C
    const Real res = ((min_temp <= nres) && (nres <= max_temp)) ? nres : pres;
    return res;
}
```

## 5. Resistor Divider Utility

The `Resistor_div` class provides functionality for calculating the variable resistance in a voltage divider circuit, which is commonly used with thermistors:

```cpp
class Resistor_div
{
public:
    struct Config
    {
        enum Conn_type
        {
            c_high,  // Variable resistor on high side of voltage divider
            c_low    // Variable resistor on low side of voltage divider
        };
        
        Conn_type conn_type;
        Real rs;  // Serial, fixed resistance
        Real r1;  // Additional resistance
        
        Config();
    };
    
    Config cfg;
    
    Real compute_r(Real vt_norm) const;
    
private:
    Real compute_r_high(Real vt_norm) const;
    Real compute_r_low(Real vt_norm) const;
};
```

The `Resistor_div` class supports two configurations:
1. **High-Side Configuration**: Variable resistor connected between supply voltage and output
2. **Low-Side Configuration**: Variable resistor connected between output and ground

The class provides methods to compute the variable resistance based on the normalized output voltage (0.0 to 1.0).

## 6. Comparison of Temperature Conversion Approaches

The system implements several approaches for converting voltage to temperature:

| Sensor Type | Conversion Method | Mathematical Model | Temperature Range | Accuracy |
|-------------|------------------|-------------------|------------------|----------|
| TMP112 | Digital I2C | Linear (0.0625°C per bit) | -40°C to +125°C | ±0.5°C |
| STLM20 | Analog Voltage | Square Root Formula | -40°C to +125°C | ±1.5°C |
| LMT86 | Analog Voltage | Quadratic Formula | -50°C to +150°C | ±0.4°C |
| Ntcs0603 | Thermistor | Exponential + Polynomial | -50°C to +150°C | ±1.0°C |
| Thermistor_b | Thermistor | Beta Parameter Model | Configurable | Depends on parameters |
| Thermistor_2nd | Thermistor | Second-Order Polynomial | Configurable | Depends on parameters |

### 6.1 Key Differences

1. **Digital vs. Analog**:
   - TMP112 is a digital sensor that provides temperature directly over I2C
   - Other sensors are analog and require voltage-to-temperature conversion

2. **Mathematical Models**:
   - Linear: TMP112 uses a simple linear conversion
   - Square Root: STLM20 uses a square root formula
   - Quadratic: LMT86 uses a quadratic formula
   - Exponential: Ntcs0603 and Thermistor_b use exponential models
   - Polynomial: Thermistor_2nd uses a second-order polynomial model

3. **Configurability**:
   - Specific sensor models (TMP112, STLM20, LMT86, Ntcs0603) have fixed parameters
   - Generic thermistor models (Thermistor_b, Thermistor_2nd) are configurable

4. **Error Handling**:
   - TMP112 has a state machine for error recovery
   - Ntcs0603 has boundary checking for voltage inputs
   - Thermistor_2nd selects physically meaningful solutions within a temperature range

## 7. Integration with Simulation Framework

The temperature sensor drivers integrate with the simulation framework to support testing without physical hardware.

### 7.1 TMP112 Integration with Simulation

The TMP112 driver is designed to work with the simulation framework through:

1. **Measurement Variable Reference**:
   ```cpp
   volatile Real& tmp;  // Reference to system variable for measurement
   ```

2. **Built-in Test Flag**:
   ```cpp
   volatile bool& var_buit;  // System variable flag for BIT
   ```

3. **State Machine Integration**:
   - The state machine can be influenced by simulation by manipulating the I2C communication results

### 7.2 Temperature Converter Integration

The temperature converters (`ITemp_getter` implementations) can be used with simulated voltage inputs:

```cpp
// Example of using a temperature converter with simulated voltage
Real simulated_voltage = 1.25F;  // Simulated voltage from sensor
LMT86 converter;
Real temperature = converter.get_temp(simulated_voltage);  // Converts to temperature
```

### 7.3 Thermistor Model Integration

The thermistor models can be used with simulated normalized voltage inputs:

```cpp
// Example of using a thermistor model with simulated normalized voltage
Real simulated_norm_voltage = 0.5F;  // Simulated normalized voltage (0.0 to 1.0)
Thermistor_b thermistor;
Real temperature = thermistor.compute_temp(simulated_norm_voltage);  // Converts to temperature
```

## 8. Error Handling and Validation

### 8.1 TMP112 Error Handling

The TMP112 driver implements error handling through its state machine:

1. **Error Detection**:
   - I2C communication failures are detected by checking the return value of `send()` and `read()` methods
   - Timeouts are used to detect initialization failures

2. **Error Recovery**:
   - When an error occurs, the driver transitions to the `st_error` state
   - In the error state, it clears the status bit and attempts to restart communication

3. **Status Reporting**:
   - The driver updates a status bit to indicate sensor health
   - The `is_meas_updated()` method indicates when a new measurement is available

### 8.2 Temperature Converter Validation

The temperature converters implement input validation:

1. **Ntcs0603 Boundary Checking**:
   ```cpp
   if (volt < min_sensor_voltage)
   {
       temp = min_sensor_temp;
   }
   else if (volt > max_sensor_voltage)
   {
       temp = max_sensor_temp;
   }
   ```

2. **Thermistor_2nd Solution Selection**:
   ```cpp
   static const Real min_temp = 173.15F; // -100C
   static const Real max_temp = 623.15F; // +350C
   const Real res = ((min_temp <= nres) && (nres <= max_temp)) ? nres : pres;
   ```

## 9. Cross-Component Relationships

The temperature sensor components interact with several other system components:

1. **I2C Communication Framework**:
   - TMP112 extends `I2Cdevice` and uses the I2C communication infrastructure
   - It registers with an I2C handler and participates in the I2C communication cycle

2. **Simulation Framework**:
   - All temperature sensors can be simulated using the simulation framework
   - The drivers are designed to work with both real and simulated inputs

3. **Resistor Divider Utility**:
   - Thermistor models use the `Resistor_div` class to convert voltage to resistance
   - This utility supports both high-side and low-side configurations

4. **Mathematical Utilities**:
   - Temperature converters use mathematical functions like `sqrtr()` and `logr()`
   - These functions are provided by the `Rmath` namespace

## 10. Summary of Temperature Sensor Architecture

The temperature sensor architecture in the system is designed with these key principles:

1. **Modularity**: Each sensor type is implemented as a separate class
2. **Interface-Based Design**: Common interfaces define standard behavior
3. **Mathematical Models**: Different mathematical models are used for different sensor types
4. **Error Handling**: Robust error detection and recovery mechanisms
5. **Simulation Support**: Integration with the simulation framework
6. **Configurability**: Generic models support different thermistor parameters

This architecture allows the system to support a wide range of temperature sensors while providing a consistent interface for higher-level components.

## Referenced Context Files

The following context files provided useful information for understanding the temperature sensor architecture:

1. **Sensor Device Framework**: Provided information about the common sensor device architecture, including I2C device management and configuration patterns.

2. **Communication Protocols**: Provided details about the I2C communication protocol used by the TMP112 sensor.

3. **Simulation Framework**: Provided information about how sensors integrate with the simulation framework for testing without physical hardware.