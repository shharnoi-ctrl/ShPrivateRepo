# Generated from:

- code/include/Dps310.h (3334 tokens)
- code/include/HSCpress.h (1297 tokens)
- code/include/HSCpress_adc.h (527 tokens)
- code/include/Honeywell_press.h (2046 tokens)
- code/include/Ms561101ba03.h (1585 tokens)
- code/source/Dps310.cpp (3236 tokens)
- code/source/HSCpress.cpp (2140 tokens)
- code/source/HSCpress_adc.cpp (878 tokens)
- code/source/Honeywell_press.cpp (2162 tokens)
- code/source/Ms561101ba03.cpp (3363 tokens)

## With context from:

- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/devices/04_Sensor_Device_Framework.md (3568 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/devices/04_Communication_Protocols.md (3756 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/devices/04_Simulation_Framework.md (3965 tokens)

---

# Comprehensive Analysis of Pressure Sensor Drivers

This document provides a detailed examination of the pressure sensor driver architecture, focusing on common patterns, differences, and implementation details across multiple sensor types.

## 1. Common Architecture and Design Patterns

All pressure sensor drivers share a consistent architectural approach with the following common elements:

### 1.1 Base Class Inheritance

- **I2C-based sensors** (`Dps310`, `HSCpress`, `MS561101BA03`) inherit from `Dsp28335_ent::I2Cdevice`
- **ADC-based sensors** (`HSCpress_adc`) implement a standalone class
- **UART-based sensors** (`Honeywell_press`) implement the `Base::Itport_u8` interface

### 1.2 Core Functionality Components

All pressure sensor drivers implement:

1. **State Machine Management**: Each driver implements a finite state machine (FSM) to handle initialization, configuration, and measurement
2. **Measurement Processing**: Raw data conversion, filtering, and validation
3. **Temperature Compensation**: Reading and applying temperature corrections to pressure measurements
4. **Simulation Integration**: Interface with the simulation framework via `Simdev` objects
5. **Configuration Management**: Common configuration structure (`Dev_common_cfg`)
6. **Error Handling**: Detection and reporting of sensor failures

### 1.3 Common Data Flow Pattern

```
Raw Data → Conversion → Validation → Filtering → Output
```

With these common steps:
1. Read raw binary data from sensor
2. Convert to physical units (Pascals)
3. Validate range and rate of change
4. Apply IIR filtering
5. Store in output measurement object

## 2. Sensor-Specific Implementations

### 2.1 Dps310 (I2C Digital Pressure Sensor)

#### 2.1.1 Key Characteristics
- I2C addresses: 0x76 (default) or 0x77
- Pressure range: 30,000 to 120,000 Pa
- Desired sampling rate: 32 Hz
- Configurable oversampling (1 to 128 samples)

#### 2.1.2 State Machine
The Dps310 implements a comprehensive FSM with states for:
- Initialization (`s_init`)
- Reset handling (`s_reset_wait`)
- Product ID verification (`s_product_req`, `s_product_read`)
- Coefficient source reading (`s_coeff_src_req`, `s_coeff_src_read`)
- Configuration (`s_temp_cfg`, `s_press_cfg`, `s_meas_cfg`, `s_cfg_cfg`)
- Calibration coefficient reading (`s_read_temp_coeffs_req`, `s_read_temp_coeffs`, `s_read_press_coeffs_req`, `s_read_press_coeffs`)
- Measurement reading (`s_read_init`, `s_read_req`, `s_read`)
- Error handling (`s_error`, `s_error_disabled`)

#### 2.1.3 Calibration and Compensation
The Dps310 uses a complex compensation algorithm with multiple coefficients:
```cpp
// Temperature compensation
last_traw_sc = static_cast<Real>(raw) * comp_factors[Ku16::u0];
temp = (c0*Const::ONEHALF) + (c1*last_traw_sc);
temp += Const::C2KELVIN;

// Pressure compensation
v = c00 + v * (c10 + v * (c20 + v * c30)) + last_traw_sc * (c01 + v * (c11 + v * c21));
```

#### 2.1.4 Configuration Options
- Pressure oversampling (1 to 128 samples)
- Pressure rate (1 to 128 samples)
- Temperature oversampling (1 to 128 samples)
- Temperature rate (1 to 128 samples)
- Temperature source (internal or external)

### 2.2 HSCpress (I2C Honeywell Pressure Sensor)

#### 2.2.1 Key Characteristics
- Supports both absolute (HSCabs_015_38) and differential (HSCdif_001_28) pressure sensors
- I2C addresses: 0x38 (absolute) or 0x28 (differential)
- Absolute range: 0 to 15 PSI (0 to 103,421 Pa)
- Differential range: -1 to 1 PSI (-6,895 to 6,895 Pa)
- Sampling rate: 50 Hz

#### 2.2.2 State Machine
The HSCpress implements a simpler FSM with states for:
- Initialization (`s_init`)
- Measurement request (`s_request`)
- Error handling (`s_error`, `s_error_disabled`)

#### 2.2.3 Data Processing
The HSCpress uses a linear conversion from raw counts to pressure:
```cpp
Real v = static_cast<Real>(press-out_min)*press_factor + pmin;
```

Where:
- `out_min` is the output at 10% of range (0x0666)
- `out_max` is the output at 90% of range (0x399A)
- `press_factor` is the conversion factor: `(pmax-pmin)/(out_max-out_min)`

#### 2.2.4 Status Monitoring
The HSCpress monitors sensor status through status bits in the data:
```cpp
enum Error_state {
    es_valid,           // Normal operation
    es_command_mode,    // Device in command mode
    es_stale_data,      // Stale data
    es_diagnostic       // Diagnostic error
};
```

### 2.3 HSCpress_adc (ADC-based Honeywell Pressure Sensor)

#### 2.3.1 Key Characteristics
- Uses ADC instead of I2C for communication
- Pressure range: 0 to 15 PSI (0 to 103,421 Pa)
- Sampling rate: 50 Hz

#### 2.3.2 Implementation
Unlike the I2C-based sensors, HSCpress_adc:
- Does not implement a state machine
- Reads directly from the ADC
- Uses a simpler linear conversion from normalized ADC values to pressure

```cpp
Real norm = adc.get_sample_norm(adc_ch);
Real v = sensit * (norm - norm_min);
```

Where:
- `norm_min` is 0.1 (10% of range)
- `norm_max` is 0.9 (90% of range)
- `sensit` is `(pmax - pmin) / (norm_max - norm_min)`

### 2.4 MS561101BA03 (I2C MS5611 Pressure Sensor)

#### 2.4.1 Key Characteristics
- I2C addresses: 0x76 or 0x77
- Pressure range: 1,000 to 120,000 Pa
- Sampling rate: 50 Hz
- Configurable oversampling ratio (OSR)

#### 2.4.2 State Machine
The MS561101BA03 implements a comprehensive FSM with states for:
- Initialization (`s_init`)
- Reset handling (`s_reset`)
- PROM reading (`s_prom_select`, `s_prom_read`)
- Temperature measurement (`s_start_temp`, `s_get_temp`, `s_read_temp`)
- Pressure measurement (`s_start_press`, `s_get_press`, `s_read_press`)
- Error recovery (`s_reset_recover`, `s_error`)

#### 2.4.3 Calibration and Compensation
The MS561101BA03 uses a complex temperature compensation algorithm:
```cpp
// First-order compensation
dtemp = raw - (static_cast<int32>(cal_values[cal5]) << Ku16::u8);
temp_r = k2000 + static_cast<int32>((static_cast<int64>(dtemp) * static_cast<int64>(cal_values[cal6])) >> Ku16::u23);

// Calculate calibration factors
cal_off = (static_cast<int64>(cal_values[cal2]) << Ku16::u16) + ((static_cast<int64>(cal_values[cal4]) * static_cast<int64>(dtemp)) >> Ku16::u7);
cal_sens = static_cast<int64>(cal_values[cal1]) << Ku16::u15;
cal_sens += (static_cast<int64>(cal_values[cal3]) * static_cast<int64>(dtemp)) >> Ku16::u8;

// Second-order compensation for temperatures below 20°C
temp_compensation_2nd();
```

The pressure calculation uses these calibration factors:
```cpp
int64 aux = raw;
aux = (aux * cal_sens) >> Ku8::u21;
Real v = static_cast<Real>((aux - cal_off) >> Ku8::u15);
```

#### 2.4.4 CRC Verification
The MS561101BA03 implements CRC verification for calibration values:
```cpp
bool check_factory_crc() {
    // CRC calculation algorithm
    // ...
    return (n_rem == (crc_read & Ku16::u0x0F));
}
```

### 2.5 Honeywell_press (UART-based Honeywell Pressure Sensor)

#### 2.5.1 Key Characteristics
- Uses UART communication via the `Itport_u8` interface
- Configurable pressure and temperature ranges
- Supports both pressure-only and pressure+temperature modes

#### 2.5.2 Communication Protocol
The Honeywell_press uses a custom communication protocol:
- Request command: 0xAA
- Response includes status byte and measurement data
- Status byte contains error flags and sensor status

#### 2.5.3 Data Processing
The Honeywell_press uses linear conversion formulas:
```cpp
// Pressure conversion
Real counts_to_pressure(Uint32 counts) {
    return (((static_cast<Real>(counts - params.min_counts) * (params.max_press - params.min_press))/
            static_cast<Real>(params.max_counts - params.min_counts)) + params.min_press);
}

// Temperature conversion
Real counts_to_temp(Uint32 counts) {
    const Real p2p24 = 16777215.0F;  // 2 ^ 24
    return ((((static_cast<Real>(counts)*(params.t_max - params.t_min))/(p2p24 - Const::ONE)) + params.t_min) + Const::C2KELVIN);
}
```

## 3. Common Data Processing Patterns

### 3.1 Measurement Validation

All pressure sensors implement range and rate-of-change validation using the `Rangedeltacheck_nv` class:

```cpp
Base::Rangedeltacheck_nv dcheck(min_press, max_press, max_dp, n_max_outliers);

// Usage
if(dcheck.check_var(v, false) && dcheck.get_nv()) {
    v = filter.step(v);
    pressure.write(v);
    add_call();
}
```

This validation:
1. Checks if the measurement is within the valid range
2. Checks if the rate of change is within limits
3. Detects "stuck" sensors by counting consecutive identical readings

### 3.2 IIR Filtering

All sensors apply a second-order IIR filter to smooth measurements:

```cpp
Maverick::IIR_2 filter(desired_rate);

// Usage
v = filter.step(v);
```

The filter is configured through the common configuration structure:

```cpp
filter.config(cfg.iir_cfg);
```

### 3.3 Temperature Compensation

All sensors read temperature and apply temperature compensation:

```cpp
// Store temperature
temp = calculated_temperature;
simdev.replace_simtemp(temp);
pressure.get_cal().set_temp(temp);
```

### 3.4 Simulation Integration

All sensors integrate with the simulation framework:

```cpp
// Replace measurements with simulated values if simulation is enabled
simdev.replace_measure(v);
simdev.replace_simtemp(temp);
```

### 3.5 Configuration Management

All sensors use the `Dev_common_cfg` structure for configuration:

```cpp
void config(const Dev_common_cfg& cfg0) {
    cfg = cfg0;
    filter.config(cfg.iir_cfg);
    dcheck.set_max_delta(cfg.max_delta);
    dcheck.set_max_count(cfg.max_nv_samples);
    
    // Validate configuration
    if(cfg.max_delta > max_dp) {
        Base::Error err;
        err.failed(Base::err_press_xxx);
        Base::PDIcheck::commit(err);
    }
}
```

## 4. Error Handling and Recovery

### 4.1 Error Detection

Pressure sensors detect errors through:
1. Communication failures (I2C, UART, ADC)
2. Invalid device IDs or calibration values
3. Status flags in sensor data
4. Timeouts during initialization or measurement

### 4.2 Error Recovery

Most sensors implement a recovery strategy:
1. Transition to an error state
2. Attempt to reinitialize the sensor
3. If initialization fails repeatedly, disable the sensor

```cpp
case s_error:
{
    if(initialized) {
        // Continue reading if already initialized
        if(send(reg_psr_b2)) {
            state = s_read_req;
            chr.tic();
        }
    }
    else {
        // Try to initialize again
        if(Base::Assertions::runtime(n_init_fails < max_fails)) {
            state = s_init;
            ++n_init_fails;
        }
        else {
            state = s_error_disabled;
        }
    }
    break;
}
```

### 4.3 Built-In Test

All sensors maintain a BIT (Built-In Test) flag that indicates sensor health:

```cpp
volatile bool& bit;  // BIT flag reference

// Update BIT status
void set_ok(bool b) {
    if(!b) {
        state = s_error;
    }
}
```

## 5. State Machine Implementations

### 5.1 Common State Machine Pattern

All I2C-based sensors implement a state machine in the `do_step()` method:

```cpp
void do_step() {
    switch(state) {
        case s_init:
            // Initialization logic
            break;
        case s_read:
            // Reading logic
            break;
        // ...
        case s_error:
            // Error handling logic
            break;
    }
}
```

### 5.2 State Transitions

State transitions are triggered by:
1. Successful I2C operations
2. Timeouts
3. Error conditions
4. Completion of processing steps

```cpp
if(send(cmd_reset)) {
    state = s_reset;
    chr.tic();
}
```

### 5.3 Timing Management

All sensors use the `Chrono` class to manage timing:

```cpp
Base::Chrono chr;

// Start timing
chr.tic();

// Check elapsed time
if(chr.toc() > reset_time) {
    // Perform action after timeout
}
```

## 6. Communication Protocol Handling

### 6.1 I2C Communication

I2C-based sensors use the `I2Cdevice` base class for communication:

```cpp
// Send command
if(send(reg_address, data)) {
    state = next_state;
}

// Read data
if(read(data_size)) {
    state = next_state;
}

// Process data
Base::U8istream bstr(get_buffer());
int32 data = bstr.get_int24_be();
```

### 6.2 UART Communication

The Honeywell_press implements the `Itport_u8` interface for UART communication:

```cpp
// Read (send request)
bool read(Uint8& data) {
    data = write_handler.get_uint8();
    // ...
}

// Write (receive response)
bool write(Uint8 data) {
    response_buffer.append(data);
    // ...
}
```

### 6.3 ADC Communication

The HSCpress_adc reads directly from the ADC:

```cpp
Real norm = adc.get_sample_norm(adc_ch);
Real v = sensit * (norm - norm_min);
```

## 7. Differences Between Sensor Implementations

### 7.1 Communication Protocols

- **I2C**: Dps310, HSCpress, MS561101BA03
- **ADC**: HSCpress_adc
- **UART**: Honeywell_press

### 7.2 State Machine Complexity

- **Complex**: Dps310, MS561101BA03 (many states for initialization, calibration, and measurement)
- **Simple**: HSCpress (few states, simpler operation)
- **None**: HSCpress_adc (direct reading without state machine)

### 7.3 Calibration Approaches

- **Complex Polynomial**: Dps310, MS561101BA03 (multiple coefficients, second-order compensation)
- **Linear**: HSCpress, HSCpress_adc, Honeywell_press (simple linear conversion)

### 7.4 Temperature Compensation

- **Integrated**: Dps310, MS561101BA03 (temperature affects pressure calculation)
- **External**: HSCpress, HSCpress_adc, Honeywell_press (temperature stored separately)

### 7.5 Error Recovery

- **Sophisticated**: Dps310, MS561101BA03 (multiple recovery attempts, reset handling)
- **Basic**: HSCpress, Honeywell_press (simple retry mechanism)
- **Minimal**: HSCpress_adc (relies on ADC reliability)

## 8. Integration with Simulation Framework

All pressure sensors integrate with the simulation framework through the `Simdev` class:

```cpp
Simdev& simdev;  // Reference to simulation device

// Replace measurements with simulated values
simdev.replace_measure(v);
simdev.replace_simtemp(temp);
```

This allows:
1. Replacing real sensor readings with simulated values
2. Adding realistic noise to simulated values
3. Testing sensor drivers without physical hardware

## 9. Cross-Component Relationships

### 9.1 Relationship with I2C Framework

I2C-based sensors depend on the `I2Cdevice` base class, which provides:
- I2C communication primitives
- Buffer management
- Error handling

### 9.2 Relationship with Measurement Framework

All sensors output to measurement objects:

```cpp
Base::Tmeas1D& pressure;  // Pressure measurement object

// Write measurement
pressure.write(v);
```

These measurement objects provide:
- Timestamping
- Unit conversion
- Access control

### 9.3 Relationship with Configuration Framework

All sensors use the common configuration structure:

```cpp
Dev_common_cfg cfg;  // Configuration

// Apply configuration
void config(const Dev_common_cfg& cfg0) {
    cfg = cfg0;
    // ...
}
```

This provides consistent configuration across different sensor types.

## 10. Summary of Key Architectural Patterns

1. **Layered Architecture**:
   - Hardware abstraction (I2C, ADC, UART)
   - Device-specific logic
   - Common processing (validation, filtering)
   - Simulation integration

2. **State Machine Pattern**:
   - Clear separation of states
   - Explicit transitions
   - Error recovery paths

3. **Validation Chain**:
   - Range checking
   - Rate-of-change validation
   - Non-variation detection

4. **Configuration Management**:
   - Common configuration structure
   - Validation of configuration parameters
   - Runtime reconfiguration support

5. **Simulation Integration**:
   - Transparent replacement of real measurements
   - Temperature simulation
   - Noise addition

These patterns create a robust, maintainable, and testable pressure sensor driver architecture that supports multiple sensor types while providing consistent behavior and error handling.