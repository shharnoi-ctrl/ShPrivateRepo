# Generated from:

- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/devices/04_Sensor_Device_Framework.md (3568 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/devices/04_Communication_Protocols.md (3756 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/devices/04_Simulation_Framework.md (3965 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/devices/03_IMU_Sensors.md (5369 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/devices/03_Magnetometer_Sensors.md (3741 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/devices/03_Pressure_Sensors.md (4233 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/devices/02_Temperature_Sensors.md (5200 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/devices/02_Distance_Sensors.md (4446 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/devices/03_Storage_Devices.md (5465 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/devices/03_Navigation_Systems.md (5296 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/devices/02_GPS_UBX_Protocol.md (8581 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/devices/02_Specialized_Sensors.md (4172 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/devices/02_Cellular_Communication.md (3133 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/devices/02_SIL_Implementations.md (8358 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/devices/01_Sensor_System_Architecture.md (4694 tokens)

---

# Amazon Prime Air Software System Overview

This document provides a comprehensive overview of the software system architecture for Amazon Prime Air's Battery Management System (BMS) and related components. It serves as the entry point for understanding the system's structure, components, and their interactions.

## System Architecture Overview

The Prime Air software system follows a layered architecture with clear separation of concerns, enabling hardware abstraction, consistent error handling, and support for both real hardware and simulation:

```
┌─────────────────────────────────────────────────────────────────┐
│                     Application Layer                           │
└───────────────────────────────┬─────────────────────────────────┘
                                │
┌───────────────────────────────▼─────────────────────────────────┐
│                     Measurement System                          │
└───────────────────────────────┬─────────────────────────────────┘
                                │
┌───────────────────────────────▼─────────────────────────────────┐
│                     Sensor Driver Layer                         │
├─────────────┬─────────────┬───────────────┬────────────┬────────┤
│ IMU Drivers │ Pressure    │ Magnetometer  │ Distance   │ Other  │
│             │ Drivers     │ Drivers       │ Drivers    │ Drivers│
└─────────────┴─────────────┴───────────────┴────────────┴────────┘
                                │
┌───────────────────────────────▼─────────────────────────────────┐
│                Communication Protocol Layer                     │
├─────────────┬─────────────┬───────────────┬────────────┬────────┤
│ I2C         │ SPI         │ UART          │ ADC        │ Other  │
└─────────────┴─────────────┴───────────────┴────────────┴────────┘
                                │
┌───────────────────────────────▼─────────────────────────────────┐
│                     Hardware Abstraction Layer                  │
└───────────────────────────────┬─────────────────────────────────┘
                                │
┌───────────────────────────────▼─────────────────────────────────┐
│                     Hardware / Simulation                       │
└─────────────────────────────────────────────────────────────────┘
```

## Key Architectural Components

### 1. Sensor Device Framework

The sensor device framework provides common interfaces and base classes that all sensor drivers implement:

- **Base Classes**: `I2Cdevice`, `Itport_u8`, `Iblock_device`
- **Common Interfaces**: `Ithermistor`, `Isincos_signal`, `Iangular_estimator`
- **Configuration Structures**: `Dev_common_cfg`, `Imu_params`
- **Measurement Containers**: `Tmeas1D`, `Tmeas3D`, `Rawmea3`

This framework ensures consistent behavior across different sensor types and enables code reuse. For more details, see [Sensor Device Framework](./04_Sensor_Device_Framework.md).

### 2. Communication Protocols

The system implements multiple communication protocols to interface with various sensors:

- **I2C**: Used by most sensors (magnetometers, pressure sensors, temperature sensors)
- **SPI**: Used by high-speed sensors (IMUs, storage devices)
- **UART**: Used by navigation systems and cellular communication
- **ADC**: Used by analog sensors (thermistors, position sensors)

Each protocol implementation provides hardware abstraction, error detection and recovery, timing management, and buffer handling. For more details, see [Communication Protocols](./04_Communication_Protocols.md).

### 3. Simulation Framework

The simulation framework enables testing without physical hardware:

- **Simdev/Simdev3D**: Provides simulated sensor values
- **Noise Generation**: Adds realistic noise to simulated values
- **Measurement Replacement**: Seamlessly replaces real measurements with simulated ones
- **SIL Implementations**: Software-in-the-loop versions of all drivers

This framework allows comprehensive testing in both development and production environments. For more details, see [Simulation Framework](./04_Simulation_Framework.md) and [SIL Implementations](./02_SIL_Implementations.md).

## Sensor Types and Implementations

### 1. IMU Sensors

The system supports multiple IMU sensors with different capabilities:

- **ADIS165053**: High-precision IMU with 16/32-bit data modes
- **BMI088**: Separate accelerometer and gyroscope components
- **LSM6DSX**: Supports multiple communication protocols (SPI, I2C, MCBSP)

Common features include 3D accelerometer and gyroscope measurements, temperature compensation, configurable filtering, and self-test capabilities. For more details, see [IMU Sensors](./03_IMU_Sensors.md).

### 2. Magnetometer Sensors

The system supports multiple magnetometer sensors:

- **HSCDTD008A**: 3-axis magnetometer with 15-bit resolution
- **LIS3MDL**: Configurable performance modes and data rates
- **MMC5883MA/MMC5983MA**: Auto-detection of hardware variants
- **RM3100**: High-resolution 24-bit magnetometer

For more details, see [Magnetometer Sensors](./03_Magnetometer_Sensors.md).

### 3. Pressure Sensors

The system supports multiple pressure sensors:

- **DPS310**: Digital pressure sensor with temperature compensation
- **HSCpress**: Supports both absolute and differential pressure
- **HSCpress_adc**: ADC-based pressure sensor
- **MS561101BA03**: High-precision barometric pressure sensor
- **Honeywell_press**: UART-based pressure sensor

For more details, see [Pressure Sensors](./03_Pressure_Sensors.md).

### 4. Temperature Sensors

The system supports multiple temperature sensors:

- **TMP112**: Digital I2C temperature sensor
- **STLM20/LMT86**: Analog temperature sensors
- **Ntcs0603/Thermistor_b/Thermistor_2nd**: Thermistor-based temperature sensors

For more details, see [Temperature Sensors](./02_Temperature_Sensors.md).

### 5. Distance Sensors

The system supports multiple distance sensors:

- **Garminlite**: Lidar-based distance sensor with multiple configuration modes
- **SFLidar**: Supports both SF11 and SF20 lidar sensors

For more details, see [Distance Sensors](./02_Distance_Sensors.md).

### 6. Navigation Systems

The system supports sophisticated navigation systems:

- **VN300**: GNSS-aided inertial navigation system
- **UBX Protocol**: Comprehensive support for u-blox GPS receivers
- **Internest**: External positioning system for absolute position

For more details, see [Navigation Systems](./03_Navigation_Systems.md) and [GPS UBX Protocol](./02_GPS_UBX_Protocol.md).

### 7. Storage Devices

The system supports multiple storage devices:

- **EEPROM_24CS**: I2C-based EEPROM storage
- **MX66L**: SPI-based NOR Flash storage
- **USDdrv**: SPI-based MicroSD card storage

For more details, see [Storage Devices](./03_Storage_Devices.md).

### 8. Specialized Sensors and Communication

The system includes various specialized sensors and communication modules:

- **PMIC_TPS65381A**: Power management IC
- **Sincos_sensor**: Analog encoder for position
- **Speed_hall**: Hall effect speed sensor
- **Transponder**: ADS-B/Remote ID functionality
- **Sara**: Cellular communication module

For more details, see [Specialized Sensors](./02_Specialized_Sensors.md) and [Cellular Communication](./02_Cellular_Communication.md).

## Common Design Patterns

### 1. State Machine Pattern

All sensor drivers implement state machines to manage their lifecycle:

1. **Initialization States**: Configure the sensor with appropriate settings
2. **Measurement States**: Trigger measurements and read results
3. **Error States**: Handle communication failures and recovery

This pattern provides clear separation of concerns, robust error handling, and predictable behavior.

### 2. Measurement Processing Pipeline

All sensors follow a consistent measurement processing pipeline:

```
Raw Data → Conversion → Validation → Filtering → Output
```

1. **Raw Data Acquisition**: Read raw data from the sensor
2. **Conversion**: Convert to physical units (m/s², Tesla, Pascal, etc.)
3. **Validation**: Check if measurements are within valid ranges
4. **Filtering**: Apply IIR filtering to reduce noise
5. **Output**: Make measurements available through a shared interface

### 3. Error Handling and Validation

The system implements comprehensive error handling and validation:

1. **Range Checking**: Ensures measurements are within valid ranges
2. **Delta Checking**: Limits the maximum change between consecutive measurements
3. **Non-Variation Detection**: Detects when sensors are stuck
4. **Communication Error Detection**: Detects protocol-specific errors
5. **Recovery Mechanisms**: Implements strategies to recover from errors

## System Reliability and Maintainability

The sensor system implements several reliability features:

1. **Redundancy**: Support for multiple sensors of the same type
2. **Validation**: Comprehensive data validation
3. **Error Recovery**: Robust error detection and recovery mechanisms
4. **Watchdog Mechanisms**: Detection of communication loss
5. **Graceful Degradation**: Continued operation with reduced functionality

The system is designed for maintainability with consistent architecture, clear separation of concerns, interface-based design, comprehensive testing support, and simulation capabilities.

## Further Documentation

For more detailed information on specific components, please refer to the individual documentation files linked throughout this overview. Each file provides in-depth analysis of the component's architecture, functionality, and integration with the rest of the system.