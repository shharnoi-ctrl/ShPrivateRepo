# Generated from:

- code/include/SFLidar.h (1537 tokens)
- code/include/Lidar_i2c_params.h (154 tokens)
- code/include/Lidar_i2c_params_fw.h (30 tokens)
- code/include/Garminlite.h (1001 tokens)
- code/source/SFLidar.cpp (1638 tokens)
- code/source/Garminlite.cpp (1685 tokens)

## With context from:

- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/devices/04_Sensor_Device_Framework.md (3568 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/devices/04_Communication_Protocols.md (3756 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/devices/04_Simulation_Framework.md (3965 tokens)

---

# Distance Sensor Driver Architecture: SFLidar and Garminlite

This document provides a comprehensive analysis of the distance sensor drivers in the system, focusing on the `SFLidar` and `Garminlite` classes. These drivers share a common architectural approach while handling different sensor types with their unique requirements.

## 1. Common Architecture and Design Patterns

Both the `SFLidar` and `Garminlite` drivers follow a consistent architectural pattern:

### 1.1 Inheritance Hierarchy

Both drivers inherit from the `I2Cdevice` base class:

```cpp
class SFLidar : public Dsp28335_ent::I2Cdevice
class Garminlite : public Dsp28335_ent::I2Cdevice
```

This inheritance provides common I2C communication functionality, including:
- I2C bus access
- Read/write operations
- Device addressing
- Status monitoring

### 1.2 State Machine Pattern

Both drivers implement state machines to manage their operational lifecycle:

1. **Initialization States**: Configure the sensor with appropriate settings
2. **Measurement States**: Trigger measurements and read results
3. **Error States**: Handle communication failures and recovery

### 1.3 Measurement Processing Pipeline

Both drivers implement a consistent measurement processing pipeline:
1. **Raw Data Acquisition**: Read raw data from the sensor
2. **Conversion**: Convert raw data to meaningful units (meters)
3. **Validation**: Check if measurements are within valid ranges
4. **Filtering**: Apply IIR filtering to reduce noise
5. **Simulation Integration**: Support replacement with simulated values
6. **Output**: Make measurements available through a shared interface

### 1.4 Error Handling

Both drivers implement similar error handling mechanisms:
- Retry mechanisms for transient errors
- State transitions to error states when problems occur
- Recovery procedures to reinitialize after errors
- Timeout detection for unresponsive devices

### 1.5 Configuration Parameters

Both drivers expose similar configuration parameters:
- Measurement rate control
- Period settings
- Filter configurations
- Range validation parameters

## 2. SFLidar Driver Implementation

The `SFLidar` class implements drivers for SF11 and SF20 Lidar sensors, which are I2C-based distance sensors.

### 2.1 Class Structure and Polymorphism

The `SFLidar` class uses an internal polymorphic design to support different sensor variants:

```cpp
class SFLidar : public Dsp28335_ent::I2Cdevice {
public:
    enum Type {
        t_lidar_sf11 = 2,
        t_lidar_sf20 = 3
    };
    
    // Interface for SF11/SF20 implementations
    class ISFLidar {
    public:
        virtual void conf_buffer(State st, Tconf_buff& b) = 0;
        virtual Real get_measure(const Base::U8pkmblock_k& b) = 0;
        virtual Real get_min_dist() const = 0;
        virtual Real get_max_dist() const = 0;
    protected:
        ISFLidar();
    };
    
    // Concrete implementations
    class SF11 : public ISFLidar { /* implementation */ };
    class SF20 : public ISFLidar { /* implementation */ };
    
private:
    SF11 sf_11;
    SF20 sf_20;
    ISFLidar* sf_lidar;  // Points to either sf_11 or sf_20
};
```

This design allows the driver to:
1. Share common code between SF11 and SF20 variants
2. Handle device-specific differences through polymorphism
3. Switch between device types at runtime using `set_type()`

### 2.2 State Machine

The `SFLidar` implements a state machine with the following states:

```cpp
enum State {
    s_init,         // Initial state
    s_start_read,   // Start read state
    s_read,         // Reading state
    s_error         // Error state
};
```

#### 2.2.1 State Transitions

The state machine transitions are implemented in the `do_step()` method:

1. **s_init**: 
   - Wait for initialization time (1.5 seconds)
   - Configure the device
   - Transition to `s_start_read` on success

2. **s_start_read**:
   - Wait for the configured period
   - Prepare and send read command
   - Transition to `s_read` on success or `s_init` on failure

3. **s_read**:
   - Process received data
   - Extract distance measurement
   - Apply filtering and validation
   - Prepare for next read
   - Stay in `s_read` for continuous operation

4. **s_error**:
   - Attempt recovery if initialized and within retry limit
   - Transition to `s_start_read` for retry or `s_init` for reinitialization
   - Increment retry counter

### 2.3 Device-Specific Implementations

#### 2.3.1 SF11 Implementation

The SF11 implementation handles:
- Buffer configuration for different states
- Measurement extraction from raw data
- Range validation (0.2m to 120.0m)

```cpp
void SFLidar::SF11::conf_buffer(State st, Tconf_buff& b) {
    switch(st) {
        case s_init:
            b.resize(Ku8::u1);
            b.set(Ku8::u0, 0);
            break;
        case s_start_read:
        case s_read:
            b.resize(Ku8::u2);
            break;
        default:
            break;
    }
}

Real SFLidar::SF11::get_measure(const U8pkmblock_k& b) {
    Base::U8istream bstr(b);
    return static_cast<Real>(bstr.get_uint16_be()) * Const::CM2M;
}

Real SFLidar::SF11::get_min_dist() const {
    static const Real min_dist = 0.2F;
    return min_dist;
}

Real SFLidar::SF11::get_max_dist() const {
    static const Real max_dist = 120.0F;
    return max_dist;
}
```

#### 2.3.2 SF20 Implementation

The SF20 implementation handles:
- Buffer configuration for different states
- Measurement extraction from raw data
- Range validation (0.05m to 100.0m)

```cpp
void SFLidar::SF20::conf_buffer(State st, Tconf_buff& b) {
    switch(st) {
        case s_init:
            b.resize(0); // No action required
            break;
        case s_start_read:
        case s_read:
            b.resize(data_sz);
            break;
        default:
            break;
    }
}

Real SFLidar::SF20::get_measure(const U8pkmblock_k& b) {
    Real res = 0.0F;
    if (Assertions::runtime(b.size() == data_sz)) {
        const Uint16 u = Bitutils::get_u16(b.get(0), b.get(1));
        res = static_cast<Real>(u) * Const::CM2M;
    }
    return res;
}

Real SFLidar::SF20::get_min_dist() const {
    static const Real min_dist = 0.05F;
    return min_dist;
}

Real SFLidar::SF20::get_max_dist() const {
    static const Real max_dist = 100.0F;
    return max_dist;
}
```

### 2.4 Measurement Processing

The `set_meas()` method implements the measurement processing pipeline:

```cpp
void SFLidar::set_meas(Real v) {
    simdev.replace_measure(v);  // Integration with simulation framework
    if(dcheck.check_var(v, false) && dcheck.get_nv()) {
        v = filter.step(v);     // Apply IIR filtering
        measure.write(v);       // Output measurement
        add_call();             // Update call statistics
    }
}
```

This method:
1. Integrates with the simulation framework
2. Validates the measurement using `dcheck`
3. Applies IIR filtering to reduce noise
4. Writes the processed measurement to the output
5. Updates call statistics

## 3. Garminlite Driver Implementation

The `Garminlite` class implements a driver for the Garmin Lidar Lite v3 sensor, which is also an I2C-based distance sensor but with different communication protocol.

### 3.1 Register Map

The `Garminlite` class defines a register map for the sensor:

```cpp
enum Regs {
    r_acquire   = 0x00,  // Acquisition command
    r_status    = 0x01,  // Status register
    r_adq_count = 0x02,  // Acquisition count
    r_adq_mode  = 0x04,  // Acquisition mode
    r_loop_cnt  = 0x11,  // Loop count
    r_th_bypass = 0x1c,  // Threshold bypass
    r_measure   = 0x8f   // Measurement register
};
```

### 3.2 State Machine

The `Garminlite` implements a more complex state machine with the following states:

```cpp
enum State {
    s_cfg1,             // First configuration step
    s_cfg2,             // Second configuration step
    s_cfg3,             // Third configuration step
    s_start_measure,    // Start measurement
    s_start_acquire,    // Start acquisition
    s_query_busy,       // Query busy status
    s_read_busy,        // Read busy status
    s_check_busy,       // Check busy status
    s_read,             // Read measurement
    s_gather,           // Process measurement
    s_error,            // Error state
    s_error_disabled    // Permanently disabled after too many failures
};
```

#### 3.2.1 State Transitions

The state machine transitions are implemented in the `do_step()` method:

1. **Configuration States** (s_cfg1, s_cfg2, s_cfg3):
   - Configure acquisition count, mode, and threshold bypass
   - Transition through configuration states sequentially
   - Move to `s_start_acquire` when configuration is complete

2. **Acquisition States** (s_start_acquire, s_start_measure):
   - Send acquisition command
   - Prepare to read measurement
   - Transition to `s_read` when ready

3. **Reading States** (s_read, s_gather):
   - Read measurement data
   - Process and validate measurement
   - Apply filtering
   - Transition back to `s_start_acquire` for next measurement

4. **Error States** (s_error, s_error_disabled):
   - Attempt recovery if within retry limit
   - Transition to `s_start_acquire` for retry or `s_cfg1` for reinitialization
   - If too many consecutive initialization failures, transition to `s_error_disabled`

### 3.3 Configuration Modes

The `Garminlite` supports different configuration modes:

```cpp
enum Garmin_cfg {
    balanced,    // Default mode, balanced performance
    sr_hs,       // Short range, high speed
    dr_hs,       // Default range, higher speed short range
    max_range,   // Maximum range
    high_sens,   // High sensitivity detection, high erroneous measurements
    low_sens     // Low sensitivity detection, low erroneous measurements
};
```

Each mode configures different parameters:
- `adq_count`: Acquisition count
- `adq_mode`: Acquisition mode
- `threshold_bypass`: Threshold bypass value

```cpp
void Garminlite::get_conf_values(Garmin_cfg configuration) {
    static const Uint8 default_adq_count = 0x80;
    static const Uint8 default_adq_mode = 0x08;

    switch (configuration) {
        case balanced:
            adq_count = default_adq_count;
            adq_mode = default_adq_mode;
            threshold_bypass = Ku8::u0;
            break;
        case sr_hs:
            adq_count = 0x1D;
            adq_mode = default_adq_mode;
            threshold_bypass = Ku8::u0;
            break;
        // Other cases...
    }
}
```

### 3.4 Measurement Processing

The `set_meas()` method implements the measurement processing pipeline:

```cpp
void Garminlite::set_meas(Real value) {
    simdev.replace_measure(value);  // Integration with simulation framework
    if(dcheck.check_var(value, false) && dcheck.get_nv()) {
        value = filter.step(value);  // Apply IIR filtering
        measure.write(value);        // Output measurement
        add_call();                  // Update call statistics
    }
}
```

This method follows the same pattern as the `SFLidar` implementation.

### 3.5 Bias Reading

The `Garminlite` implements a bias reading mechanism to periodically perform a biased acquisition:

```cpp
Uint8 Garminlite::get_adq_cmd() {
    Uint8 res = Ku8::u3;  // Default acquisition command
    bias_read_count++;
    if(bias_read_count >= bias_count_trigger) {
        res = Ku16::u4;   // Biased acquisition command
        bias_read_count = Ku8::u0;
    }
    return res;
}
```

This mechanism:
1. Counts the number of regular acquisitions
2. Periodically (every 100 samples) performs a biased acquisition
3. Resets the counter after a biased acquisition

## 4. Measurement Validation and Filtering

Both drivers implement similar measurement validation and filtering mechanisms:

### 4.1 Range and Delta Checking

Both drivers use the `Rangedeltacheck_nv` class to validate measurements:

```cpp
Base::Rangedeltacheck_nv dcheck;
```

This class performs three types of validation:
1. **Range Checking**: Ensures measurements are within valid min/max ranges
2. **Delta Checking**: Limits the maximum change between consecutive measurements
3. **Non-Variation Detection**: Detects when measurements don't change (sensor stuck)

### 4.2 IIR Filtering

Both drivers use a second-order IIR filter to reduce measurement noise:

```cpp
Maverick::IIR_2& filter;
```

The filter is configured externally and passed to the driver through the constructor.

## 5. Simulation Integration

Both drivers integrate with the simulation framework through the `Lidar_simdev` class:

```cpp
Lidar_simdev& simdev;
```

The `replace_measure()` method is called before processing measurements:

```cpp
simdev.replace_measure(value);
```

This allows the simulation framework to replace real measurements with simulated values when simulation is enabled.

## 6. Error Handling and Recovery

Both drivers implement similar error handling and recovery mechanisms:

### 6.1 Error Detection

Errors are detected through:
1. I2C communication failures
2. Timeout detection
3. Invalid measurement values

### 6.2 Recovery Mechanisms

Both drivers implement recovery mechanisms:
1. Retry attempts for transient errors
2. Reinitialization for persistent errors
3. Permanent disabling after too many failures (Garminlite only)

```cpp
// SFLidar error recovery
if(initialized && (retries_error < max_retries_error)) {
    state = s_start_read;
    retries_error++;
} else {
    state = s_init;
}

// Garminlite error recovery
if(initialized && (retries_error < max_retries_error)) {
    state = s_start_acquire;
    retries_error++;
} else {
    if(n_init_fails < max_fails) {
        state = s_cfg1;
        ++n_init_fails;
    } else {
        state = s_error_disabled;
    }
}
```

## 7. Performance and Timing Considerations

Both drivers implement similar performance and timing considerations:

### 7.1 Measurement Rate Control

Both drivers control the measurement rate through period settings:

```cpp
static const Uint16 desired_rate_u = 10U;  // 10 Hz
static const Real desired_rate = static_cast<Real>(desired_rate_u);
static const Real period_default = 1.0F / desired_rate;
```

### 7.2 Timing Management

Both drivers use chronometers to manage timing:

```cpp
Base::Chrono chr;
```

The chronometer is used to:
1. Control initialization timing
2. Enforce measurement periods
3. Detect timeouts

## 8. Key Differences Between Drivers

Despite their architectural similarities, the drivers have several key differences:

### 8.1 Device Support

- **SFLidar**: Supports multiple device types (SF11, SF20) through polymorphism
- **Garminlite**: Supports a single device type with multiple configuration modes

### 8.2 State Machine Complexity

- **SFLidar**: Simpler state machine (4 states)
- **Garminlite**: More complex state machine (12 states)

### 8.3 Configuration Approach

- **SFLidar**: Uses polymorphism to handle device-specific configuration
- **Garminlite**: Uses configuration modes to adapt to different use cases

### 8.4 Error Handling

- **SFLidar**: Simple retry mechanism with reinitialization
- **Garminlite**: More sophisticated error handling with permanent disabling after too many failures

### 8.5 Measurement Ranges

- **SF11**: 0.2m to 120.0m
- **SF20**: 0.05m to 100.0m
- **Garminlite**: 0.05m to 40.0m

## 9. Integration with the Sensor Device Framework

Both drivers integrate with the sensor device framework through:

1. **I2C Communication**: Both inherit from `I2Cdevice` for I2C communication
2. **Measurement Output**: Both use `Base::Hmeas1` for measurement output
3. **Filtering**: Both use `Maverick::IIR_2` for filtering
4. **Simulation**: Both integrate with `Lidar_simdev` for simulation

The drivers are registered with the I2C arbiter through the `I2Cdevices` class, which manages all I2C-based sensors in the system.

## 10. Cross-Component Relationships

The distance sensor drivers interact with several other components:

1. **I2C Communication Framework**: Provides I2C bus access
2. **Measurement System**: Stores and processes measurements
3. **Filtering Framework**: Provides noise reduction
4. **Simulation Framework**: Enables testing without physical hardware
5. **Device Management**: Registers devices with the system

## Referenced Context Files

The following context files provided useful information for understanding the distance sensor drivers:

1. **04_Sensor_Device_Framework.md**: Provided context on the overall sensor device framework, including I2C device management and registration.
2. **04_Communication_Protocols.md**: Provided context on the I2C communication protocols used by the distance sensor drivers.
3. **04_Simulation_Framework.md**: Provided context on the simulation framework that integrates with the distance sensor drivers.

These context files helped establish how the distance sensor drivers fit into the broader system architecture and interact with other components.