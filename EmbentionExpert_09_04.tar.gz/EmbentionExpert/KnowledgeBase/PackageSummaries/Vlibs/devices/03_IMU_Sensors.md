# Generated from:

- code/include/Adis165053.h (4615 tokens)
- code/include/Adis165053_cfg.h (437 tokens)
- code/include/Bmi088.h (2283 tokens)
- code/include/Bmi088_cfg.h (1414 tokens)
- code/include/Bmi088_spi.h (1121 tokens)
- code/include/Imu_handler.h (352 tokens)
- code/include/Imu_params.h (458 tokens)
- code/include/Lsm6dsx.h (2331 tokens)
- code/include/Lsm6dsx_cfg.h (2041 tokens)
- code/include/Lsm6dsx_i2c.h (768 tokens)
- code/include/Lsm6dsx_mcbsp.h (488 tokens)
- code/include/Lsm6dsx_spi.h (520 tokens)
- code/source/Adis165053.cpp (9641 tokens)
- code/source/Adis165053_cfg.cpp (916 tokens)
- code/source/Bmi088.cpp (2772 tokens)
- code/source/Bmi088_cfg.cpp (1262 tokens)
- code/source/Bmi088_spi.cpp (3408 tokens)
- code/source/Imu_params.cpp (156 tokens)
- code/source/Lsm6dsx.cpp (5659 tokens)
- code/source/Lsm6dsx_cfg.cpp (2382 tokens)
- code/source/Lsm6dsx_i2c.cpp (558 tokens)
- code/source/Lsm6dsx_mcbsp.cpp (688 tokens)
- code/source/Lsm6dsx_spi.cpp (778 tokens)

## With context from:

- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/devices/04_Sensor_Device_Framework.md (3568 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/devices/04_Communication_Protocols.md (3756 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/devices/04_Simulation_Framework.md (3965 tokens)

---

# IMU Sensor Driver Architecture: Comprehensive Analysis

This document provides a detailed analysis of the IMU (Inertial Measurement Unit) sensor drivers in the system, focusing on their common architecture, implementation patterns, and specific behaviors.

## 1. Common IMU Driver Architecture

The system implements a consistent architecture across different IMU sensor drivers, with specialized implementations for different hardware devices. All IMU drivers share a common pattern:

### 1.1 Core Components and Interfaces

All IMU drivers include:

- **Accelerometer and Gyroscope Data Handling**
  - Raw measurement storage in SI units (m/s² for accelerometer, rad/s for gyroscope)
  - Calibrated measurement processing through `Tmeas3D` objects
  - Temperature measurement in Kelvin

- **Filtering and Validation**
  - Biquad notch low-pass filters for both accelerometer and gyroscope data
  - Range and delta checking to validate measurements
  - Non-variation detection to identify stuck sensors

- **Simulation Integration**
  - References to simulation devices for both accelerometer and gyroscope
  - Seamless replacement of real measurements with simulated values when enabled

- **Built-in Test (BIT)**
  - Call statistics tracking to ensure proper sampling rate
  - Status reporting through a boolean reference

### 1.2 Common Parameters Structure

All IMU drivers use a common `Imu_params` structure to initialize shared components:

```cpp
struct Imu_params {
    Base::Tmeas3D& accTmeas;    // Accelerometer calibration
    Base::Tmeas3D& gyrTmeas;    // Gyroscope calibration
    Rawmea3& rawacc0;           // Accelerometer raw measure
    Rawmea3& rawgyr0;           // Gyroscope raw measure
    volatile Real& temp;        // Temperature measure
    Simdev3D& simrefa;          // Simulation accelerometer sensor data
    Simdev3D& simrefg;          // Simulation gyroscope sensor data
};
```

This structure centralizes the references to measurement, calibration, and simulation components, ensuring consistent initialization across different IMU implementations.

### 1.3 Configuration Structures

Each IMU driver has a corresponding configuration structure that follows a consistent pattern:

```cpp
struct IMU_cfg {
    // Range and sampling rate settings
    Enum accel_range;          // Accelerometer range
    Enum accel_sample_rate;    // Accelerometer sampling rate
    
    // Filter settings
    // (Implementation-specific filter parameters)
    
    // Validation parameters
    Uint16 acc_max_nv_samples; // Accelerometer max non-variation samples
    Uint16 gyr_max_nv_samples; // Gyroscope max non-variation samples
    Real acc_max_delta;        // Maximum allowed increment in accelerometer measurements
    Real gyr_max_delta;        // Maximum allowed increment in gyroscope measurements
    
    // Deserialization method
    void cset(Base::Lossy_error& str);
    
    // Default configuration builder
    static IMU_cfg build_default();
};
```

These configuration structures provide a consistent way to configure IMU parameters across different hardware implementations.

## 2. State Machine-Based Initialization and Operation

All IMU drivers implement a state machine to manage initialization, configuration, and data acquisition:

### 2.1 Common State Machine Pattern

```cpp
enum State {
    st_init,                // Initial state
    st_reset,               // Reset the device
    st_reset_wait,          // Wait for reset to complete
    st_id_read,             // Read device ID
    st_configure,           // Configure device parameters
    st_request,             // Request data
    st_read_data,           // Read data
    st_error                // Error state
};
```

The state machine ensures proper initialization sequence and handles error recovery:

1. **Initialization Phase**:
   - Reset the device
   - Wait for reset to complete
   - Read and verify device ID
   - Configure device parameters

2. **Operation Phase**:
   - Request data
   - Read and process data
   - Handle errors and recovery

3. **Error Handling**:
   - Track error state
   - Implement recovery mechanisms
   - Limit retry attempts

### 2.2 Step Method Pattern

All IMU drivers implement a `step()` method that drives the state machine:

```cpp
bool step() {
    // Update call statistics
    callst.step();
    
    // Process current state
    switch(state) {
        case st_init:
            // Initialize device
            break;
        case st_reset:
            // Reset device
            break;
        // Additional states...
        case st_request:
            // Request data
            break;
        case st_read_data:
            // Read and process data
            break;
        case st_error:
            // Handle error and recovery
            break;
    }
    
    return result; // Indicates if data transmission is ongoing
}
```

This method is called periodically to advance the state machine and process IMU data.

## 3. Communication Protocol Abstraction

The IMU drivers support multiple communication protocols through abstraction layers:

### 3.1 Protocol-Specific Implementations

The system includes IMU drivers for different communication protocols:

- **SPI**: Direct SPI communication with IMU sensors
  - Uses chip select signals to select the device
  - Implements protocol-specific data formatting
  - Handles timing requirements for SPI communication

- **I2C**: I2C communication with IMU sensors
  - Uses I2C addresses to identify devices
  - Implements I2C-specific command sequences
  - Integrates with the I2C arbiter for bus sharing

- **MCBSP**: Multi-Channel Buffered Serial Port communication
  - Uses a port abstraction for data transfer
  - Implements MCBSP-specific timing and control

### 3.2 Communication Abstraction

For some IMU drivers (like LSM6DSX), a protocol abstraction layer is implemented:

```cpp
class Imu_handler {
public:
    // Send a write command to the IMU
    virtual bool write_imu(const Base::U8pkmblock_k& tx_data, Uint8 rx_len) = 0;
    
    // Send a read command to the IMU
    virtual bool read_imu(Uint8 rx_len) = 0;
    
    // Get the data buffer
    virtual const Base::U8pkmblock_k get_imu_data() const = 0;
    
    // Step on specific FSM for data reading
    virtual Data_res step_data_imu() = 0;
    
    // Possible return values for step_data
    enum Data_res {
        r_error    = 0, // Error
        r_queried  = 1, // Data has been queried
        r_read     = 2  // Data has been read
    };
};
```

This interface allows the core IMU logic to be implemented independently of the communication protocol, with protocol-specific implementations handling the details of data transfer.

## 4. Specific IMU Driver Implementations

### 4.1 ADIS165053 Driver

The ADIS165053 driver supports the ADIS16505-3 and ADIS16475-2 IMU sensors:

#### 4.1.1 Key Features

- **SPI Communication**:
  - Uses a blocking port for data transfer
  - Implements chip select and reset GPIO control
  - Supports both 16-bit and 32-bit data modes

- **Advanced Configuration**:
  - Configurable filter stages (0-6)
  - Optional 370Hz bandwidth limitation
  - Point of percussion alignment
  - Linear acceleration compensation for gyroscopes

- **Self-Test and Diagnostics**:
  - Flash memory test
  - Sensor self-test
  - Diagnostic status monitoring
  - Error detection and recovery

#### 4.1.2 State Machine

The ADIS165053 implements a detailed state machine:

```cpp
enum State {
    st_request,         // Request data state
    st_read_data,       // Read data (only for asynchronous data read)
    st_init,            // Initial State
    st_hwreset,         // Reset the Acc
    st_swreset,         // Reset by Software
    st_reset_wait,      // Wait for Acc. Reset
    st_flash_test,      // Self flash memory test state
    st_flash_test_res,  // Self flash memory test result state
    st_sens_test,       // Self sensor test result
    st_sens_test_res,   // Self sensor test state result
    st_id_read,         // Retrieve the Acc ID
    st_cfg_read0,       // Read initial configuration
    st_cfg,             // Configure state
    st_cfg_read,        // Read configuration
    st_cfg_filter,      // Barlet filter configuration
    st_cfg_filter_read, // Barlet filter configuration
    st_request_start,   // Request start
    st_error            // Error state
};
```

This state machine ensures proper initialization, configuration, and data acquisition.

#### 4.1.3 Data Processing

The ADIS165053 processes data from the SPI bus:

1. **Data Request**:
   - Sends a burst mode command
   - Sets up the read buffer

2. **Data Reading**:
   - Reads data from the SPI bus
   - Processes diagnostic status
   - Extracts accelerometer and gyroscope measurements
   - Extracts temperature measurement
   - Validates data using range and delta checks
   - Applies filtering to measurements
   - Updates calibrated measurements

3. **Error Handling**:
   - Detects communication errors
   - Monitors diagnostic status
   - Implements reset and recovery mechanisms

### 4.2 BMI088 Driver

The BMI088 driver supports the Bosch BMI088 IMU sensor:

#### 4.2.1 Key Features

- **Separate Accelerometer and Gyroscope**:
  - Treats accelerometer and gyroscope as separate devices
  - Configures each component independently
  - Uses separate chip select signals for each component

- **Configuration Options**:
  - Multiple accelerometer ranges (3g, 6g, 12g, 24g)
  - Multiple gyroscope ranges (125°/s to 2000°/s)
  - Configurable output data rates and bandwidths
  - Power management options

#### 4.2.2 State Machine

The BMI088 implements a state machine that handles both accelerometer and gyroscope initialization:

```cpp
enum State {
    st_request,             // Request data state
    st_init,                // Initial State
    st_acc_reset,           // Reset the Acc
    st_acc_reset_wait,      // Wait for Acc. Reset
    st_acc_id,              // Retrieve the Acc ID
    st_acc_pwr_ctrl,        // Power up the Acc
    st_acc_pwr_ctrl_wait,   // Wait for powering up
    st_acc_pwr_ctrl_check,  // Check if power mode is the selected one
    st_acc_pwr_conf,        // Set in normal mode
    st_acc_conf,            // Configure Acc sampling rate and bandwidth
    st_acc_range,           // Configure Acc range
    st_acc_range_wait,      // Wait for Configure Acc range time
    st_gyr_reset,           // Reset the Gyro
    st_gyr_reset_wait,      // Wait for Gyro. reset
    st_gyr_pwr_dis,         // Set Gyro power mode as disabled
    st_gyr_id,              // Retrieve the Gyro ID
    st_gyr_range,           // Configure Gyro sampling rate and bandwidth
    st_gyr_bw_odr,          // Configure Gyro range
    st_error,               // Error found
    s_error_disabled        // Disabled. Reached after many consecutive fails
};
```

This state machine ensures proper initialization of both accelerometer and gyroscope components.

#### 4.2.3 SPI Implementation

The BMI088_spi class implements the SPI communication for the BMI088:

```cpp
class Bmi088_spi {
public:
    Bmi088_spi(Base::Itport_u16& port0,             // Blocking port
               Dsp28335_ent::GPIO& gpio_acc,        // Accelerometer CS gpio
               Dsp28335_ent::GPIO& gpio_gyro,       // Gyroscope CS gpio
               volatile bool& bit0,                 // BIT reference
               const Imu_params& params);           // IMU building parameters
    
    Bmi088& get_base(); // Returns the base instance for BMI088
    bool get_bit() const; // Returns the BIT
    bool step(); // Returns true if a new data arrived
    
private:
    // Implementation details
};
```

This class handles the SPI communication details while delegating the core IMU logic to the base BMI088 class.

### 4.3 LSM6DSX Driver

The LSM6DSX driver supports both LSM6DS3 and LSM6DSO IMU sensors:

#### 4.3.1 Key Features

- **Protocol Abstraction**:
  - Uses the `Imu_handler` interface to abstract communication details
  - Supports SPI, I2C, and MCBSP communication protocols
  - Implements protocol-specific classes for each communication method

- **Device Type Detection**:
  - Automatically detects LSM6DS3 or LSM6DSO variants
  - Adapts configuration based on detected device type
  - Implements device-specific filter configurations

- **Advanced Filtering**:
  - Configurable high-pass and low-pass filters
  - Device-specific filter configurations
  - Bandwidth and cutoff frequency options

#### 4.3.2 State Machine

The LSM6DSX implements a state machine for initialization and data acquisition:

```cpp
enum State {
    s_boot,             // boot command
    s_sw_reset,         // sw-reset command
    s_id_req,           // who_am_i request
    s_id_read,          // who_am_i read
    s_id_check,         // who_am_i check
    s_acc_rate_odr,     // Acc sample_rate, range and bandwidth
    s_auto_inc,         // Auto increment on read and Block data update
    s_acc_lpf2_bw,      // Acc LPF2 for DSO or bw mode for DS3
    s_gyro_odr_rng,     // Gyro sample_rate and range
    s_gyr_cfg_wait,     // Wait for gyro setup time
    s_gyr_hpf,          // Gyro high pass filter
    s_dso_gyro_lpf1_bw, // Gyro LPF1 and BW (only DSO)
    s_dso_acce_lpf2_fc, // Acc. lpf2  (only DSO)
    s_acc_lpf_en,       // Acc LPF2_XL_EN=1, HP_SLOPE_XL_EN=1 (only DS3)
    s_acc_lpf2_en,      // Acc accel_lpf2 enable (only DS3)
    s_stabilization_wait,// Final wait for stabilization
    s_request_start,    // Start data request and read
    s_request,          // Data request and read
    s_request_read,     // Data request and read
    s_error,            // Error detected
    s_error_disabled    // Disabled. Reached after many consecutive fails
};
```

This state machine handles device initialization, configuration, and data acquisition.

#### 4.3.3 Protocol-Specific Implementations

The LSM6DSX driver includes protocol-specific implementations:

1. **SPI Implementation** (`Lsm6dsx_spi`):
   - Uses SPI for communication
   - Implements chip select control
   - Handles SPI-specific data formatting

2. **I2C Implementation** (`Lsm6dsx_i2c`):
   - Uses I2C for communication
   - Implements I2C address selection
   - Integrates with the I2C arbiter

3. **MCBSP Implementation** (`Lsm6dsx_mcbsp`):
   - Uses MCBSP for communication
   - Implements chip select control
   - Handles MCBSP-specific timing requirements

All implementations conform to the `Imu_handler` interface, allowing the core LSM6DSX logic to be reused across different communication protocols.

## 5. Data Processing and Filtering

### 5.1 Measurement Processing Pipeline

All IMU drivers implement a consistent measurement processing pipeline:

1. **Raw Data Reading**:
   - Read raw data from the sensor
   - Convert to SI units (m/s² for accelerometer, rad/s for gyroscope)
   - Store in raw measurement structures

2. **Validation**:
   - Check if measurements are within valid ranges
   - Check if measurements have changed (non-variation detection)
   - Check if changes are within acceptable limits (delta checking)

3. **Filtering**:
   - Apply biquad notch low-pass filters to reduce noise
   - Filter accelerometer and gyroscope data separately
   - Use configurable filter parameters

4. **Calibration**:
   - Apply calibration to filtered measurements
   - Update calibrated measurement structures
   - Apply temperature compensation if available

### 5.2 Biquad Notch Low-Pass Filters

All IMU drivers use `Maverick::Biquad_notch_lpf_3d` filters for both accelerometer and gyroscope data:

```cpp
Maverick::Biquad_notch_lpf_3d accf;  // Accelerometer filter
Maverick::Biquad_notch_lpf_3d gyrf;  // Gyroscope filter
```

These filters provide:
- Notch filtering to remove specific frequencies
- Low-pass filtering to reduce high-frequency noise
- Three-dimensional filtering for vector measurements

### 5.3 Range and Delta Checking

All IMU drivers implement range and delta checking using `Base::Rangedeltacheck3_nv`:

```cpp
Base::Rangedeltacheck3_nv dcheck_a;   // Accelerometer range-delta check
Base::Rangedeltacheck3_nv dcheck_g;   // Gyroscope range-delta check
```

These checks ensure:
- Measurements are within valid ranges
- Changes between consecutive measurements are within acceptable limits
- Sensors are not stuck (non-variation detection)

## 6. Error Handling and Recovery

### 6.1 Error Detection

IMU drivers implement multiple error detection mechanisms:

1. **Communication Errors**:
   - Timeout detection for communication operations
   - Protocol-specific error detection (e.g., I2C NAK, SPI transfer errors)
   - Data validation errors (CRC, checksums)

2. **Sensor Errors**:
   - Device ID verification
   - Diagnostic status monitoring
   - Self-test failures

3. **Data Validation Errors**:
   - Range violations
   - Excessive deltas between measurements
   - Non-variation detection (stuck sensors)

### 6.2 Error Recovery

IMU drivers implement error recovery strategies:

1. **Reset Mechanisms**:
   - Hardware reset using reset GPIO
   - Software reset using reset commands
   - Limited number of reset attempts

2. **State Machine Recovery**:
   - Transition to error state on detection
   - Attempt recovery based on error type
   - Return to initialization state if necessary

3. **Disabling After Repeated Failures**:
   - Track consecutive initialization failures
   - Disable device after exceeding maximum failures
   - Prevent continuous reset attempts

## 7. Simulation Integration

### 7.1 Simulation Device References

All IMU drivers include references to simulation devices:

```cpp
Simdev3D& simdeva;     // Reference to simulated accelerometer data
Simdev3D& simdevg;     // Reference to simulated gyroscope data
```

These references are provided through the `Imu_params` structure during initialization.

### 7.2 Measurement Replacement

IMU drivers replace real measurements with simulated values when simulation is enabled:

```cpp
// In set_acc_raw method
simdeva.replace_measure(vs);
rawacc.x = vs[Rvector3::vx];
rawacc.y = vs[Rvector3::vy];
rawacc.z = vs[Rvector3::vz];

// In set_gyro_raw method
simdevg.replace_measure(vs);
rawgyr.x = vs[Rvector3::vx];
rawgyr.y = vs[Rvector3::vy];
rawgyr.z = vs[Rvector3::vz];

// In set_temp_raw method
simdeva.replace_simtemp(temp);
simdevg.replace_simtemp(temp);
```

This approach allows seamless switching between real and simulated measurements without changing the higher-level code.

## 8. Cross-Component Relationships

The IMU drivers interact with several other components of the system:

1. **Communication Interfaces**:
   - SPI, I2C, and MCBSP interfaces for data transfer
   - GPIO interfaces for chip select and reset control
   - Communication arbiters for bus sharing

2. **Measurement System**:
   - Raw measurement structures for unprocessed data
   - Calibrated measurement structures for processed data
   - Temperature measurement for sensor temperature

3. **Simulation System**:
   - Simulation devices for accelerometer and gyroscope
   - Measurement replacement mechanism
   - Noise generation for realistic simulation

4. **Configuration System**:
   - Configuration structures for device parameters
   - Deserialization methods for loading configurations
   - Default configuration builders

## 9. Referenced Context Files

The following context files provided useful information for understanding the IMU drivers:

- **Sensor Device Framework**: Provides context on the common sensor device architecture
- **Communication Protocols**: Explains the communication protocol implementations
- **Simulation Framework**: Details the sensor simulation framework

These files helped establish the broader context in which the IMU drivers operate, including the common patterns, interfaces, and supporting infrastructure.