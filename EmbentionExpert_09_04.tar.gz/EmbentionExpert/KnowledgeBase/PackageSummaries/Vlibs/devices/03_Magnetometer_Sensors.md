# Generated from:

- code/include/Hscdtd008a.h (2721 tokens)
- code/include/Lis3mdl.h (1954 tokens)
- code/include/Mmc5883ma.h (2892 tokens)
- code/include/RM3100.h (2417 tokens)
- code/source/Hscdtd008a.cpp (2196 tokens)
- code/source/Lis3mdl.cpp (2411 tokens)
- code/source/Mmc5883ma.cpp (3055 tokens)
- code/source/RM3100.cpp (1911 tokens)

## With context from:

- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/devices/04_Sensor_Device_Framework.md (3568 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/devices/04_Communication_Protocols.md (3756 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/devices/04_Simulation_Framework.md (3965 tokens)

---

# Comprehensive Analysis of Magnetometer Sensor Drivers

This document provides a detailed examination of the magnetometer sensor drivers in the system, focusing on their common architecture, operational patterns, and specific implementations.

## 1. Common Magnetometer Driver Architecture

All magnetometer drivers in the system follow a consistent architectural pattern, inheriting from the `I2Cdevice` base class and implementing a state machine-based approach to sensor communication and data processing.

### 1.1 Class Hierarchy and Common Interfaces

```
I2Cdevice
    ├── HSCDTD008A
    ├── LIS3MDL
    ├── Mmc5883ma
    └── RM3100
```

Each magnetometer driver:
- Inherits from `Dsp28335_ent::I2Cdevice`
- Implements a finite state machine for initialization and operation
- Provides methods for configuration, measurement, and error handling
- Integrates with the simulation framework via `Simdev3D`

### 1.2 Common Member Variables

All magnetometer drivers share these key member variables:

```cpp
Base::Rangedeltacheck3_nv dcheck;  // Range and delta checking for validation
Base::Tmeas3D& s;                  // 3-axis measurement storage
Maverick::IIR3_2 filter;           // 2nd order IIR filter for each axis
State state;                       // Current state machine state
bool initialized;                  // Initialization status flag
Rawmea3& rawmag;                   // Raw magnetic field measurements
volatile Real& temp;               // Sensor temperature (except RM3100)
Simdev3D& simdev;                  // Simulation device reference
Real period_current;               // Current sampling period
```

### 1.3 Common Methods

All magnetometer drivers implement these methods:

```cpp
Real get_desired_rate() const;     // Get desired sampling rate
Real get_period() const;           // Get current sampling period
Real get_default_period() const;   // Get default sampling period
void set_period(const Real&);      // Set sampling period
void config(const Dev_common_cfg&); // Configure the sensor
void do_step();                    // State machine step function
void set_ok(bool);                 // Set device status
```

### 1.4 Common Configuration Structure

All magnetometer drivers use the `Dev_common_cfg` structure for configuration:

```cpp
struct Dev_common_cfg {
    Maverick::IIR_2cfg iir_cfg;    // Filter configuration
    Uint16 max_nv_samples;         // Maximum non-variation samples
    Real max_delta;                // Maximum allowed increment
};
```

## 2. State Machine Implementation

### 2.1 Common State Machine Pattern

All magnetometer drivers implement a state machine with these common states:

```
s_init              → Initial state
s_reset             → Reset the device
s_*_req/s_*_read    → Request/read device data
s_*_gather          → Process received data
s_error             → Error handling state
s_error_disabled    → Permanently disabled state
```

### 2.2 State Machine Flow

The typical state machine flow follows this pattern:

1. **Initialization Sequence**:
   - Check device ID/whoami register
   - Configure device registers
   - Set measurement parameters
   - Transition to operational mode

2. **Operational Sequence**:
   - Request measurement
   - Wait for measurement completion
   - Read measurement data
   - Process and validate data
   - Periodically read temperature

3. **Error Handling**:
   - Attempt recovery if already initialized
   - Count consecutive initialization failures
   - Disable device after max failures

### 2.3 Error Recovery Mechanism

All drivers implement a similar error recovery approach:

```cpp
case s_error:
{
    callst.set_ready(true);  // Init to compute bit
    if(initialized) //try to recover from error
    {
        state = s_init_req; // Or equivalent operational state
    }
    else
    {
        if(n_init_fails < max_fails)
        {
            state = s_init;
            ++n_init_fails;
        }
        else
        {
            state = s_error_disabled;
        }
    }
    break;
}
```

## 3. Measurement Processing Pipeline

All magnetometer drivers follow a similar measurement processing pipeline:

### 3.1 Data Acquisition

1. **Request Measurement**:
   - Send command to start measurement
   - Wait for measurement completion
   - Request data read

2. **Read Raw Data**:
   - Read raw register values
   - Convert to SI units (Tesla)

### 3.2 Data Processing

1. **Simulation Integration**:
   ```cpp
   simdev.replace_measure(vs);  // Replace with simulated values if enabled
   ```

2. **Store Raw Values**:
   ```cpp
   rawmag.x = vs[Maverick::Rvector3::vx];
   rawmag.y = vs[Maverick::Rvector3::vy];
   rawmag.z = vs[Maverick::Rvector3::vz];
   ```

3. **Validation**:
   ```cpp
   bool res = dcheck.check_var(vs, false) && dcheck.get_nv();
   ```
   - Checks if values are within valid range
   - Checks if values have changed (stuck sensor detection)

4. **Filtering and Output**:
   ```cpp
   if(res) {
       filter.step(vs);      // Apply IIR filter
       s.write(vs);          // Write to measurement structure
       add_call();           // Update call statistics
   }
   ```

### 3.3 Temperature Handling

Most magnetometers also measure temperature:

1. **Temperature Reading**:
   - Periodically request temperature measurement
   - Convert raw value to Kelvin

2. **Temperature Processing**:
   ```cpp
   temp = converted_value;
   simdev.replace_simtemp(temp);  // Replace with simulated temperature if enabled
   s.get_cal().set_temp(temp);    // Update calibration temperature
   ```

## 4. Device-Specific Implementations

### 4.1 HSCDTD008A Magnetometer

**Key Characteristics:**
- I2C address: 0x0C
- Range: ±1.2 mT (±12 Gauss)
- Resolution: 15 bits
- Sensitivity: 0.15 μT/LSB

**Unique Features:**
- Forced/manual measurement mode
- Temperature sensor with 1°C/LSB resolution
- Soft reset capability
- Offset calibration

**State Machine:**
```
s_init → s_reset → s_whoami → s_whoami_ck → s_cfg1 → s_cfg4 → s_init_req →
s_data_read_req → s_data_read → s_data_gather → [repeat] or
s_temp_read_req → s_temp_read → s_temp_gather → [back to data]
```

**Register Configuration:**
```cpp
// Control register 1
send(reg_ctrl1, pm_active | odr_100 | m_forced)

// Control register 4
send(reg_ctrl4, reg4_def | static_cast<Uint8>(range))
```

### 4.2 LIS3MDL Magnetometer

**Key Characteristics:**
- I2C addresses: 0x1C or 0x1E
- Range: ±4/8/12/16 Gauss (configurable)
- Output data rate: Up to 80 Hz
- Performance modes: Low, Medium, High, Ultra

**Unique Features:**
- Configurable performance modes
- Fast ODR option
- Block data update mode
- Temperature sensor with 0.125°C resolution

**State Machine:**
```
s_init → s_reset → s_cfg1 → s_cfg1_r → s_init_request →
s_request → s_read → [repeat] or
s_read_temp → s_gather_temp → [back to data]
```

**Register Configuration:**
```cpp
// Multiple registers configured at once
buffer.set(Ku8::u1, (static_cast<Uint8>(Ku8::u1) << Ku8::u7) | (output_mode << Ku8::u5) | odr | fodr);
buffer.set(Ku8::u2, range);
buffer.set(Ku8::u3, Ku8::u0);  // Continuous mode
buffer.set(Ku8::u4, output_mode << Ku8::u2);
buffer.set(Ku8::u5, Ku8::u64); // 0x40 Block data update
```

### 4.3 MMC5883MA/MMC5983MA Magnetometer

**Key Characteristics:**
- I2C address: 0x30
- Range: ±8 Gauss
- Resolution: 16 bits (MMC5883) or 18 bits (MMC5983)
- Output data rate: 100 Hz

**Unique Features:**
- SET/RESET coil operation for bias compensation
- Cannot sample temperature and magnetic field simultaneously
- Two hardware variants supported (5883/5983)
- Auto-detection of hardware variant

**State Machine:**
```
s_init → s_product_id_rd → s_product_id_ck → s_sw_reset → s_cfg1 → s_cfg2 → s_temp_req →
s_temp_sampling → s_temp_read → s_temp_gather → s_coil_set → s_coil_reset →
s_data_sampling → s_data_read → s_data_gather → [repeat]
```

**Hardware Variant Detection:**
```cpp
switch(id_read) {
    case product_id_5883:
        mod = mod_5883;
        data_size_mag = data_size_5883;
        reg_ctrl0 = reg_ctrl0_5883;
        range_factor = range_factor_5883;
        break;
    case product_id_5983:
        mod = mod_5983;
        data_size_mag = data_size_5983;
        reg_ctrl0 = reg_ctrl0_5983;
        range_factor = range_factor_5983;
        break;
}
```

### 4.4 RM3100 Magnetometer

**Key Characteristics:**
- I2C addresses: 0x20, 0x21, 0x22, or 0x23
- Range: ±800 μT (±8 Gauss)
- Resolution: 24 bits per axis
- No internal temperature sensor

**Unique Features:**
- Uses board temperature for calibration
- Continuous measurement mode
- Configurable cycle count registers for resolution/rate tradeoff
- Status register polling for data readiness

**State Machine:**
```
s_init → s_cfg1 → s_cfg2 → s_product_id_req → s_product_id_read → s_product_id_ck → s_status_read_req →
s_status_read → s_status_check → s_data_read → s_data_gather → [repeat]
```

**Register Configuration:**
```cpp
// Cycle count registers
send_cfg1();  // Sets CCR registers to 0x00C8 for all axes

// TMRC register (measurement rate)
send(reg_tmrc, tmrc_150);  // 150 Hz in continuous measurement mode

// Continuous measurement mode
send(reg_ccm, ccm_on);
```

## 5. Calibration and Filtering

### 5.1 Calibration

All magnetometers use temperature-dependent calibration:

```cpp
// Update calibration with current temperature
s.get_cal().set_temp(temp);
```

The RM3100, which lacks an internal temperature sensor, uses board temperature:

```cpp
// Since this sensor does not measure temp, it is calibrated with board temp
s.get_cal().set_temp(btemp.get());
```

### 5.2 Filtering

All magnetometers use a 2nd order IIR filter:

```cpp
Maverick::IIR3_2 filter;  // 2nd order IIR filter for 3D data

// During measurement processing
filter.step(vs);  // Apply filter to measurement vector
```

The filter is configured through the common configuration structure:

```cpp
void config(const Dev_common_cfg& cfg0) {
    filter.config(cfg0.iir_cfg);
    // ...
}
```

## 6. Validation and Error Detection

### 6.1 Range and Delta Checking

All magnetometers use `Rangedeltacheck3_nv` for validation:

```cpp
Base::Rangedeltacheck3_nv dcheck;

// Configuration
dcheck.set_range(min_meas, max_meas);
dcheck.set_max_delta(max_meas-min_meas);
dcheck.set_max_count(max_no_variation);

// Usage
bool res = dcheck.check_var(vs, false) && dcheck.get_nv();
```

This checks:
1. Values are within valid range
2. Changes between measurements are within limits
3. Sensor is not stuck (values are changing)

### 6.2 Error Detection and Recovery

All magnetometers implement error detection and recovery:

```cpp
// Error detection
if(!b) {
    state = s_error;
}

// Recovery attempt
if(initialized) {
    // Try to recover by returning to operational state
} else {
    // Try initialization again, up to max_fails times
    if(n_init_fails < max_fails) {
        state = s_init;
        ++n_init_fails;
    } else {
        state = s_error_disabled;
    }
}
```

## 7. Simulation Integration

All magnetometers integrate with the simulation framework:

```cpp
// Replace measurement with simulated value if simulation is enabled
simdev.replace_measure(vs);

// Replace temperature with simulated value if simulation is enabled
simdev.replace_simtemp(temp);
```

This allows testing without physical hardware by providing simulated sensor values.

## 8. Communication Protocol Usage

### 8.1 I2C Communication Pattern

All magnetometers use a similar I2C communication pattern:

1. **Register Write**:
   ```cpp
   send(register_address, value);
   ```

2. **Register Read Request**:
   ```cpp
   send(register_address);
   ```

3. **Data Read**:
   ```cpp
   read(data_size);
   ```

4. **Data Processing**:
   ```cpp
   Base::U8istream bstr(get_buffer());
   int16 rawx = bstr.get_int16_le();  // Or other appropriate format
   ```

### 8.2 Protocol Differences

- **HSCDTD008A**: Uses little-endian 16-bit values
- **LIS3MDL**: Uses little-endian 16-bit values with auto-increment
- **MMC5883MA**: Uses little-endian (5883) or big-endian (5983) values
- **RM3100**: Uses big-endian 24-bit values

## 9. Cross-Component Relationships

The magnetometer drivers interact with several other system components:

1. **I2C Communication Layer**: All drivers use the `I2Cdevice` base class
2. **Measurement System**: All drivers update a `Tmeas3D` structure
3. **Simulation Framework**: All drivers integrate with `Simdev3D`
4. **Filtering System**: All drivers use `IIR3_2` filters
5. **Validation System**: All drivers use `Rangedeltacheck3_nv`

## 10. Summary of Key Differences

| Feature | HSCDTD008A | LIS3MDL | MMC5883MA | RM3100 |
|---------|------------|---------|-----------|--------|
| I2C Address | 0x0C | 0x1C/0x1E | 0x30 | 0x20-0x23 |
| Range | ±1.2 mT | ±4/8/12/16 G | ±8 G | ±800 μT |
| Resolution | 15-bit | 16-bit | 16/18-bit | 24-bit |
| Temp Sensor | Yes | Yes | Yes | No |
| Data Format | LE 16-bit | LE 16-bit | LE/BE 16/18-bit | BE 24-bit |
| Special Features | Forced mode | Performance modes | SET/RESET coil | CCR registers |
| Max Rate | 100 Hz | 80 Hz | 80 Hz | 80 Hz |

## 11. Error Handling Mechanisms

All magnetometer drivers implement these error handling mechanisms:

1. **Initialization Failure Counting**:
   ```cpp
   if(n_init_fails < max_fails) {
       state = s_init;
       ++n_init_fails;
   } else {
       state = s_error_disabled;
   }
   ```

2. **Device ID Verification**:
   ```cpp
   check_step(get_buffer().get(0) == who_am_i, s_cfg1);
   ```

3. **Communication Timeout**:
   ```cpp
   if(chr.toc() > reset_time) {
       // Proceed with next step
   }
   ```

4. **Stuck Sensor Detection**:
   ```cpp
   dcheck.set_max_count(max_no_variation);
   bool res = dcheck.check_var(vs, false) && dcheck.get_nv();
   ```

5. **Range Validation**:
   ```cpp
   dcheck.set_range(min_meas, max_meas);
   bool res = dcheck.check_var(vs, false) && dcheck.get_nv();
   ```

These mechanisms ensure robust operation even in the presence of hardware failures or communication issues.