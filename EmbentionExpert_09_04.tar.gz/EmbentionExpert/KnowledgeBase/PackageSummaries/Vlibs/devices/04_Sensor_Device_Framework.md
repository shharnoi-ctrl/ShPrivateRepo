# Generated from:

- code/include/I2Cdevices.h (796 tokens)
- code/include/I2Cdev_cfg.h (519 tokens)
- code/include/Ithermistor.h (232 tokens)
- code/include/Resistor_div.h (1052 tokens)
- code/include/Dev_common_cfg.h (186 tokens)
- code/source/I2Cdevices.cpp (2642 tokens)
- code/source/I2Cdev_cfg.cpp (325 tokens)
- code/source/Dev_press_cfg.cpp (274 tokens)

---

# Sensor Device Framework Summary

This document provides a comprehensive overview of the sensor device framework that serves as the foundation for all sensor drivers in the system. The framework defines common interfaces, patterns, and utilities that are reused across different sensor types.

## 1. Core Framework Architecture

The sensor device framework is built around a modular architecture that supports various sensor types through common interfaces and configuration patterns. The framework is designed to handle both real hardware sensors and simulated devices.

### 1.1 Key Components

The framework consists of several key components:

1. **Device Interfaces**: Abstract base classes that define common functionality for sensor types
2. **Device Configuration**: Structures for configuring sensor parameters
3. **I2C Device Management**: Classes for handling I2C-based sensors
4. **Signal Processing**: Filtering and validation mechanisms
5. **Device Registration**: Methods to register devices with the system

## 2. I2C Device Management

The I2C device management system provides a unified approach to handling various I2C-based sensors.

### 2.1 I2Cdevices Class

The `I2Cdevices` class serves as a container and manager for I2C-based external devices. It handles device registration, configuration, and integrity checking.

```cpp
class I2Cdevices {
public:
    I2Cdevices(Dsp28335_ent::I2Carbiter& arb,
               Devices::Lidar_array& lidar_sim,
               Base::Tnarray<volatile bool*, I2Cdev_cfg::max_i2c_devs>& bits,
               Base::Meas::Type_array_range& measures);
    
    void add_to_arbiter(const Real& period0);
    void config(const XI2Cdev_array& cfg0);
    bool get_bit() const;
    
private:
    bool first_cfg;
    Base::Array<Maverick::IIR_2> filters;
    Dsp28335_ent::I2Carbiter& arb;
    Base::Array<Devices::SFLidar> ldr_SF;
    Base::Array<Devices::Garminlite> ldr_glite;
    XI2Cdev_array cfg;
};
```

#### 2.1.1 Constructor

The constructor initializes the I2Cdevices container with:
- A reference to the I2C arbiter that manages the configured external devices
- An array of simulated lidars
- An array of status bits
- An array of measurement ranges

It sets up the necessary arrays for filters and different types of lidar devices.

#### 2.1.2 Device Registration

The `add_to_arbiter` method registers configured I2C devices with the I2C arbiter:

```cpp
void I2Cdevices::add_to_arbiter(const Real& period0) {
    for(Uint16 i=0; i<cfg.size();i++) {
        if(cfg.is_enabled(i)) {
            switch(cfg.data[i].type) {
                case I2Cdev_cfg::t_lidar_glite:
                    ldr_glite[i].set_period(period0);
                    arb.reg(ldr_glite[i]);
                    break;
                case I2Cdev_cfg::t_lidar_sf11:
                case I2Cdev_cfg::t_lidar_sf20:
                    ldr_SF[i].set_period(period0);
                    arb.reg(ldr_SF[i]);
                    break;
                default:
                    Bsp::warning();
            }
        }
    }
}
```

This method:
1. Iterates through all configured devices
2. Checks if each device is enabled
3. Sets the calling period for each device
4. Registers the device with the I2C arbiter

#### 2.1.3 Device Configuration

The `config` method configures I2C devices based on provided parameters:

```cpp
void I2Cdevices::config(const XI2Cdev_array& cfg0) {
    cfg = cfg0;
    Real max_period = ldr_glite[0].get_default_period();
    Uint16 nb_sensors = Ku16::u0;
    
    // Configure each device
    for(Uint16 i=0; i<cfg.size(); i++) {
        if(cfg.is_enabled(i)) {
            nb_sensors++;
            switch(cfg.data[i].type) {
                case I2Cdev_cfg::t_lidar_glite:
                    ldr_glite[i].set_address(cfg.data[i].address);
                    ldr_glite[i].set_enabled(true);
                    break;
                case I2Cdev_cfg::t_lidar_sf11:
                case I2Cdev_cfg::t_lidar_sf20:
                    max_period = ldr_SF[i].get_default_period();
                    ldr_SF[i].set_type(I2Cdev_cfg::type_to_sf_type(cfg.data[i].type));
                    ldr_SF[i].set_address(cfg.data[i].address);
                    ldr_SF[i].set_enabled(true);
                    break;
                default:
                    nb_sensors--;
                    Bsp::warning();
            }
            filters[i].config(cfg.data[i].iir_cfg);
        }
        else {
            ldr_glite[i].set_enabled(false);
            ldr_SF[i].set_enabled(false);
        }
    }
    
    // First-time configuration
    if(first_cfg) {
        first_cfg = false;
        Real cpt_period = max_period*static_cast<Real>(nb_sensors);
        add_to_arbiter(cpt_period);
    }
}
```

This method:
1. Loads the provided configuration
2. Determines the maximum period based on device types
3. Configures each enabled device with its specific parameters
4. Sets up filters for each device
5. For first-time configuration, calculates the appropriate calling period and registers devices with the arbiter

#### 2.1.4 Integrity Checking

The `get_bit` method checks the integrity of all enabled external devices:

```cpp
bool I2Cdevices::get_bit() const {
    bool res = true;
    for(Uint16 i=0; (i<cfg.size()) && res; i++) {
        if(cfg.is_enabled(i)) {
            switch(cfg.data[i].type) {
                case I2Cdev_cfg::t_lidar_glite:
                    res &= ldr_glite[i].get_bit();
                    break;
                case I2Cdev_cfg::t_lidar_sf11:
                case I2Cdev_cfg::t_lidar_sf20:
                    res &= ldr_SF[i].get_bit();
                    break;
                default:
                    res = false;
            }
        }
    }
    return res;
}
```

This method:
1. Iterates through all configured devices
2. For each enabled device, checks its integrity bit
3. Returns false if any device has failed, true otherwise

### 2.2 I2Cdev_cfg Structure

The `I2Cdev_cfg` structure defines the configuration for I2C devices:

```cpp
struct I2Cdev_cfg {
    static const Uint16 max_i2c_devs = Base::Meas::mlidar_all;

    enum Type {
        t_lidar_glite = 1,
        t_lidar_sf11 = Devices::SFLidar::t_lidar_sf11,
        t_lidar_sf20 = Devices::SFLidar::t_lidar_sf20
    };
    
    Type type;
    Uint8 address;
    Maverick::IIR_2cfg iir_cfg;

    void cset(Base::Lossy_error& str);
    static Devices::SFLidar::Type type_to_sf_type(Type type);
};
```

#### 2.2.1 Configuration Deserialization

The `cset` method deserializes the configuration from a PDIC (Parameter Data Interface Container):

```cpp
void I2Cdev_cfg::cset(Base::Lossy_error& str) {
    str.get_enum16(type);
    str.get_uint8(address);
    iir_cfg.cset(str);
    str.assrt((type == t_lidar_glite) || (type == t_lidar_sf11) || (type == t_lidar_sf20), Base::err_i2cdevs);
}
```

This method:
1. Reads the device type from the PDIC
2. Reads the I2C address
3. Deserializes the IIR filter configuration
4. Validates that the device type is one of the supported types

#### 2.2.2 Type Conversion

The `type_to_sf_type` method converts an I2Cdev_cfg type to an SFLidar type:

```cpp
inline Devices::SFLidar::Type I2Cdev_cfg::type_to_sf_type(Type type) {
    return (type == t_lidar_sf20) ? Devices::SFLidar::t_lidar_sf20 : Devices::SFLidar::t_lidar_sf11;
}
```

## 3. Sensor Interfaces

The framework provides interfaces for different types of sensors to ensure consistent behavior across implementations.

### 3.1 Ithermistor Interface

The `Ithermistor` class defines an interface for thermistor sensors:

```cpp
class Ithermistor {
public:
    virtual Real compute_temp(Real volt) const = 0;
protected:
    virtual ~Ithermistor();
};
```

This interface:
1. Declares a pure virtual function `compute_temp` that derived classes must implement
2. Provides a protected virtual destructor to ensure proper cleanup of derived classes

### 3.2 Resistor Divider

The `Resistor_div` class provides functionality for resistor divider calculations, which is commonly used in analog sensor circuits:

```cpp
class Resistor_div {
public:
    struct Config {
        enum Conn_type {
            c_high,  // Variable resistor on high side of voltage divider
            c_low    // Variable resistor on low side of voltage divider
        };
        
        Config();
        
        Conn_type conn_type;
        Real rs;  // Serial, fixed resistance
        Real r1;  // Additional resistance
    };
    
    Config cfg;
    
    Real compute_r(const Real vt_norm) const;
    
private:
    Real compute_r_high(Real vt_norm) const;
    Real compute_r_low(Real vt_norm) const;
};
```

This class:
1. Defines a configuration structure for resistor divider parameters
2. Provides methods to compute the resistance of the variable resistor based on the normalized output voltage
3. Supports both high-side and low-side configurations

## 4. Common Device Configuration

The `Dev_common_cfg` structure provides a common configuration pattern for devices that require filtering and validation:

```cpp
struct Dev_common_cfg {
    Maverick::IIR_2cfg iir_cfg;  // Filter configuration
    Uint16 max_nv_samples;       // Maximum non-variation samples
    Real max_delta;              // Maximum allowed increment
    
    void cset(Base::Lossy_error& str);
};
```

### 4.1 Configuration Deserialization

The `cset` method deserializes the configuration from a PDIC:

```cpp
void Dev_common_cfg::cset(Base::Lossy_error& str) {
    iir_cfg.cset(str);
    str.get_uint16(max_nv_samples);
    str.get_float(max_delta);
    
    str.assrt(max_delta > 0.0F, Base::err_press_dev);
}
```

This method:
1. Deserializes the IIR filter configuration
2. Reads the maximum non-variation samples parameter
3. Reads the maximum allowed increment parameter
4. Validates that the maximum delta is positive

## 5. Signal Processing and Filtering

The framework incorporates signal processing capabilities to improve sensor data quality.

### 5.1 IIR Filtering

The framework uses second-order IIR (Infinite Impulse Response) filters for sensor data processing. The `IIR_2` class from the Maverick namespace is used throughout the framework:

```cpp
Base::Array<Maverick::IIR_2> filters;
```

Each sensor can be configured with its own filter parameters through the `IIR_2cfg` structure:

```cpp
Maverick::IIR_2cfg iir_cfg;
```

### 5.2 Data Validation

The framework includes mechanisms for validating sensor data:

1. **Maximum Non-Variation Samples**: Detects when a sensor is stuck by counting consecutive samples with no significant change
2. **Maximum Delta**: Limits the maximum change between consecutive samples to filter out noise and spurious readings

## 6. Hardware and Simulation Support

The framework is designed to support both real hardware sensors and simulated devices.

### 6.1 Hardware Support

The framework supports various hardware sensor types:

1. **I2C Sensors**:
   - Garmin Lite lidar
   - SF11 lidar
   - SF20 lidar
   - Thermistors

### 6.2 Simulation Support

The framework includes simulation capabilities for testing and development:

```cpp
Devices::Lidar_array& lidar_sim
```

The `Lidar_array` structure contains simulated lidar devices that can be used when hardware is not available.

## 7. Error Handling and Validation

The framework implements several error handling and validation mechanisms.

### 7.1 Integrity Checking

The `get_bit` method in the `I2Cdevices` class checks the integrity of all enabled devices:

```cpp
bool I2Cdevices::get_bit() const
```

This method returns false if any device has failed, allowing the system to detect and respond to sensor failures.

### 7.2 Parameter Validation

The framework validates configuration parameters during deserialization:

```cpp
str.assrt((type == t_lidar_glite) || (type == t_lidar_sf11) || (type == t_lidar_sf20), Base::err_i2cdevs);
str.assrt(max_delta > 0.0F, Base::err_press_dev);
```

These assertions ensure that the configuration parameters are within valid ranges.

### 7.3 Warning Generation

The framework generates warnings for unsupported device types:

```cpp
default:
    Bsp::warning();
```

## 8. Device Registration and Management

The framework provides a mechanism for registering devices with the system and managing their lifecycle.

### 8.1 Device Registration

Devices are registered with the I2C arbiter using the `reg` method:

```cpp
arb.reg(ldr_glite[i]);
arb.reg(ldr_SF[i]);
```

### 8.2 Period Management

The framework calculates appropriate calling periods for devices based on their requirements:

```cpp
Real cpt_period = max_period*static_cast<Real>(nb_sensors);
```

This ensures that each device is called at an appropriate rate, taking into account the limitations of the I2C bus and the requirements of each device.

## 9. Cross-Component Relationships

The sensor device framework interacts with several other components of the system:

1. **I2C Arbiter**: Manages access to the I2C bus and schedules device operations
2. **Measurement System**: Stores and processes sensor measurements
3. **Configuration System**: Provides configuration parameters for sensors
4. **Simulation System**: Provides simulated sensor data when hardware is not available

## Referenced Context Files

The following context files provided useful information for understanding the sensor device framework:

- `I2Cdevices.h`: Defines the I2Cdevices class for managing I2C-based sensors
- `I2Cdev_cfg.h`: Defines the configuration structure for I2C devices
- `Ithermistor.h`: Defines the interface for thermistor sensors
- `Resistor_div.h`: Provides functionality for resistor divider calculations
- `Dev_common_cfg.h`: Defines a common configuration pattern for devices
- `I2Cdevices.cpp`: Implements the I2Cdevices class
- `I2Cdev_cfg.cpp`: Implements the I2Cdev_cfg structure
- `Dev_press_cfg.cpp`: Implements the Dev_common_cfg structure