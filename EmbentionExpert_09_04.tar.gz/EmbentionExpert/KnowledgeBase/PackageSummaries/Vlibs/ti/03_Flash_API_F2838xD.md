# Generated from:

- code/FlashAPI_F2838xD/include/F021.h (1854 tokens)
- code/FlashAPI_F2838xD/include/Types.h (2727 tokens)
- code/FlashAPI_F2838xD/include/Registers.h (563 tokens)
- code/FlashAPI_F2838xD/include/F021_F2838x_C28x.h (560 tokens)
- code/FlashAPI_F2838xD/include/Init.h (563 tokens)
- code/FlashAPI_F2838xD/include/FlashAPI.h (38 tokens)
- code/FlashAPI_F2838xD/include/Constants/F2838x.h (1093 tokens)
- code/FlashAPI_F2838xD/include/Constants/Constants.h (596 tokens)
- code/FlashAPI_F2838xD_CM/include/F021.h (1708 tokens)
- code/FlashAPI_F2838xD_CM/include/Types.h (2703 tokens)
- code/FlashAPI_F2838xD_CM/include/Registers.h (563 tokens)
- code/FlashAPI_F2838xD_CM/include/F021_F2838x_CM.h (548 tokens)
- code/FlashAPI_F2838xD_CM/include/Init.h (563 tokens)
- code/FlashAPI_F2838xD_CM/include/FlashAPI.h (36 tokens)
- code/FlashAPI_F2838xD_CM/include/Constants/F2838x_CM.h (1061 tokens)
- code/FlashAPI_F2838xD_CM/include/Constants/Constants.h (597 tokens)

---

# F021 Flash API for F2838xD Microcontrollers: Comprehensive Analysis

## Overview

The F021 Flash API provides a comprehensive interface for accessing and manipulating flash memory on F2838xD microcontrollers. The API supports both C28x and Cortex-M processor variants with processor-specific implementations to accommodate their architectural differences. This analysis details the API structure, memory maps, data types, and operational characteristics for both processor variants.

## API Structure and Organization

The F021 Flash API is organized into several header files that define the interface, data types, constants, and register definitions. The API is split into two main implementations:

1. **C28x Implementation** (`FlashAPI_F2838xD/`)
2. **Cortex-M Implementation** (`FlashAPI_F2838xD_CM/`)

Each implementation maintains a similar structure but with processor-specific adaptations:

### Common Header Files Structure
- `F021.h` - Main include file defining the API functions
- `Types.h` - Data type definitions
- `Registers.h` - Flash register mappings
- `Init.h` - Initialization structures
- `Constants/Constants.h` - Common constants
- `Constants/F2838x.h` (C28x) or `Constants/F2838x_CM.h` (Cortex-M) - Processor-specific constants
- `FlashAPI.h` - Application interface wrapper
- `F021_F2838x_C28x.h` (C28x) or `F021_F2838x_CM.h` (Cortex-M) - Processor-specific definitions

## Data Type Differences Between C28x and Cortex-M

### Integer Types

**C28x Implementation:**
```c
typedef unsigned int           uint8;  // This is 16bits in C28x
typedef unsigned int           uint16;
typedef unsigned long int      uint32;
typedef unsigned long long int uint64;
```

**Cortex-M Implementation:**
```c
typedef unsigned char          uint8;
typedef unsigned short         uint16;
typedef unsigned int           uint32;
typedef unsigned long long int uint64;
```

The most significant difference is that `uint8` in C28x is actually 16 bits wide, while in Cortex-M it's the standard 8 bits. This reflects the C28x architecture's 16-bit word orientation.

### Programming Command Function Signatures

**C28x Implementation:**
```c
extern Fapi_StatusType Fapi_issueProgrammingCommand(
                                            uint32 *pu32StartAddress,
                                            uint16 *pu16DataBuffer,
                                            uint16  u16DataBufferSizeInWords,
                                            uint16 *pu16EccBuffer,
                                            uint16  u16EccBufferSizeInBytes,
                                            Fapi_FlashProgrammingCommandsType oMode
                                            );
```

**Cortex-M Implementation:**
```c
extern Fapi_StatusType Fapi_issueProgrammingCommand(
                                                   uint32 *pu32StartAddress,
                                                   uint8  *pu8DataBuffer,
                                                   uint8  u8DataBufferSizeInBytes,
                                                   uint8  *pu8EccBuffer,
                                                   uint8  u8EccBufferSizeInBytes,
                                                   Fapi_FlashProgrammingCommandsType oMode
                                                   );
```

The C28x implementation uses 16-bit data buffers and sizes, while the Cortex-M implementation uses 8-bit data buffers and sizes, reflecting the natural word size of each architecture.

### Additional Cortex-M Functions

The Cortex-M implementation includes additional byte-oriented functions not present in the C28x version:

```c
extern Fapi_StatusType Fapi_doBlankCheckByByte(
                                              uint8 *pu8StartAddress,
                                              uint32 u32Length,
                                              Fapi_FlashStatusWordType *poFlashStatusWord
                                              );

extern Fapi_StatusType Fapi_doVerifyByByte(
                                          uint8 *pu8StartAddress,
                                          uint32 u32Length,
                                          uint8 *pu8CheckValueBuffer,
                                          Fapi_FlashStatusWordType *poFlashStatusWord
                                          );
```

The C28x version has a 16-bit oriented verify function instead:

```c
extern Fapi_StatusType Fapi_doVerifyBy16bits(
                             uint16 *pu16StartAddress,
                             uint32 u16Length,
                             uint16 *pu16CheckValueBuffer,
                             Fapi_FlashStatusWordType *poFlashStatusWord
                             );
```

## Memory Map Differences

### Flash Memory Map

**C28x Implementation:**
```c
#define F021_FLASH_MAP_BEGIN      0x80000
#define F021_FLASH_MAP_END        0xBFFFF
#define F021_OTP_MAP_BEGIN        0x78000  // Customer OTP start
#define F021_OTP_MAP_END          0x783FF  // Customer OTP End
#define F021_OTPECC_MAP_BEGIN     0x1071000
#define F021_OTPECC_MAP_END       0x107107F
#define F021_FLASHECC_MAP_BEGIN   0x1080000
#define F021_FLASHECC_MAP_END     0x1087FFF
```

**Cortex-M Implementation:**
```c
#define F021_FLASH_MAP_BEGIN      0x200000
#define F021_FLASH_MAP_END        0x27FFFF
#define F021_OTP_MAP_BEGIN        0x3C0000  // USER OTP start
#define F021_OTP_MAP_END          0x3C07FF  // USER OTP End
#define F021_OTPECC_MAP_BEGIN     0x888000
#define F021_OTPECC_MAP_END       0x8880FF
#define F021_FLASHECC_MAP_BEGIN   0x800000
#define F021_FLASHECC_MAP_END     0x80FFFF
```

The memory maps are completely different between the two processors, reflecting their separate memory spaces in the F2838xD architecture.

### TI OTP Offset

**C28x Implementation:**
```c
#define F021_PROGRAM_TIOTP_OFFSET    0x00070000  // TI OTP start on C28x
```

**Cortex-M Implementation:**
```c
#define F021_PROGRAM_TIOTP_OFFSET    0x00380000
```

### FMC Register Base Address

**C28x Implementation:**
```c
#define F021_CPU0_REGISTER_ADDRESS 0x0005F800
```

**Cortex-M Implementation:**
```c
#define F021_CPU0_REGISTER_ADDRESS 0x400FA000
```

### TI OTP Bank Size

**C28x Implementation:**
```c
#define F021_TIOTP_PER_BANK_SIZE 0x800
```

**Cortex-M Implementation:**
```c
#define F021_TIOTP_PER_BANK_SIZE 0x1000
```

The comment in the C28x implementation notes: "Even though TI OTP is 2K, Size is mentioned here as 0x800 (4K) because code uses this to find the offset of TI OTP (1, 2) relative to OTP Base address"

## Flash State Machine (FSM) Interface

Both implementations provide the same interface to the Flash State Machine, which is the hardware controller that performs flash operations:

```c
/* Flash State Machine commands */
extern Fapi_FlashStatusType Fapi_getFsmStatus(void);
extern Fapi_StatusType Fapi_checkFsmForReady(void);
extern Fapi_StatusType Fapi_setActiveFlashBank(Fapi_FlashBankType oNewFlashBank);
extern Fapi_StatusType Fapi_issueFsmSuspendCommand(void);
extern void Fapi_flushPipeline(void);
```

The FSM commands are defined in the `Fapi_FlashStateCommandsType` enum:

```c
typedef enum
{
   Fapi_ProgramData    = 0x0002,
   Fapi_EraseSector    = 0x0006,
   Fapi_ClearStatus    = 0x0010,
   Fapi_ProgramResume  = 0x0014,
   Fapi_EraseResume    = 0x0016,
   Fapi_ClearMore      = 0x0018
} ATTRIBUTE_PACKED Fapi_FlashStateCommandsType;
```

## API Function Categories

The F021 Flash API functions can be categorized as follows:

### 1. Flash State Machine Commands
- `Fapi_getFsmStatus` - Gets the current status of the Flash State Machine
- `Fapi_checkFsmForReady` - Checks if the FSM is ready for a new command
- `Fapi_setActiveFlashBank` - Sets the active flash bank for operations
- `Fapi_issueFsmSuspendCommand` - Suspends the current FSM operation
- `Fapi_flushPipeline` - Flushes the flash pipeline

### 2. Device-Specific FSM Commands
- `Fapi_remapEccAddress` - Remaps an ECC address to its corresponding data address
- `Fapi_isAddressEcc` - Checks if an address is in the ECC address space

### 3. Asynchronous Commands
- `Fapi_issueAsyncCommandWithAddress` - Issues an asynchronous command with an address
- `Fapi_issueAsyncCommand` - Issues an asynchronous command without an address

### 4. Information Commands
- `Fapi_getLibraryInfo` - Gets information about the F021 library

### 5. Initialization
- `Fapi_initializeAPI` - Initializes the F021 API

### 6. Read Commands
- `Fapi_doBlankCheck` - Checks if a flash region is blank (erased)
- `Fapi_doVerify` - Verifies flash contents against a buffer
- `Fapi_calculatePsa` - Calculates a PSA (Parallel Signature Analysis) value
- `Fapi_doPsaVerify` - Verifies a PSA value

### 7. Programming Commands
- `Fapi_issueProgrammingCommand` - Programs data to flash
- `Fapi_issueProgrammingCommandForEccAddresses` - Programs ECC data

### 8. Utility Commands
- `Fapi_calculateFletcherChecksum` - Calculates a Fletcher checksum
- `Fapi_calculateEcc` - Calculates ECC for a data value

## Error Handling

The API uses a comprehensive error handling system defined in the `Fapi_StatusType` enum:

```c
typedef enum
{
   Fapi_Status_Success=0,           /* Function completed successfully */
   Fapi_Status_FsmBusy,             /* FSM is Busy */
   Fapi_Status_FsmReady,            /* FSM is Ready */
   Fapi_Status_AsyncBusy,           /* Async function operation is Busy */
   Fapi_Status_AsyncComplete,       /* Async function operation is Complete */
   Fapi_Error_Fail=500,             /* Generic Function Fail code */
   Fapi_Error_StateMachineTimeout,  /* State machine polling never returned ready and timed out */
   Fapi_Error_OtpChecksumMismatch,  /* Returned if OTP checksum does not match expected value */
   Fapi_Error_InvalidDelayValue,    /* Returned if the Calculated RWAIT value exceeds 15  - Legacy Error */
   Fapi_Error_InvalidHclkValue,     /* Returned if FClk is above max FClk value - FClk is a calculated from HClk and RWAIT/EWAIT */
   Fapi_Error_InvalidCpu,           /* Returned if the specified Cpu does not exist */
   Fapi_Error_InvalidBank,          /* Returned if the specified bank does not exist */
   Fapi_Error_InvalidAddress,       /* Returned if the specified Address does not exist in Flash or OTP */
   Fapi_Error_InvalidReadMode,      /* Returned if the specified read mode does not exist */
   Fapi_Error_AsyncIncorrectDataBufferLength,
   Fapi_Error_AsyncIncorrectEccBufferLength,
   Fapi_Error_AsyncDataEccBufferLengthMismatch,
   Fapi_Error_FeatureNotAvailable,  /* FMC feature is not available on this device */
   Fapi_Error_FlashRegsNotWritable,  /* Returned if Flash registers are not writable due to security */
   Fapi_Error_InvalidCPUID          /* Returned if OTP has an invalid CPUID */ 
} ATTRIBUTE_PACKED Fapi_StatusType;
```

This enum provides detailed error codes that help diagnose issues during flash operations.

## Flash Programming Modes

The API supports different programming modes defined in the `Fapi_FlashProgrammingCommandsType` enum:

```c
typedef enum
{
   Fapi_AutoEccGeneration, /* This is the default mode for the command and will auto generate the ecc for the provided data buffer */
   Fapi_DataOnly,       /* Command will only process the data buffer */
   Fapi_EccOnly,        /* Command will only process the ecc buffer */
   Fapi_DataAndEcc         /* Command will process data and ecc buffers */
} ATTRIBUTE_PACKED Fapi_FlashProgrammingCommandsType;
```

These modes control how ECC (Error Correction Code) is handled during programming operations:
- `Fapi_AutoEccGeneration` - Automatically generates ECC for the data
- `Fapi_DataOnly` - Programs only the data, not the ECC
- `Fapi_EccOnly` - Programs only the ECC, not the data
- `Fapi_DataAndEcc` - Programs both data and ECC from provided buffers

## Initialization Structure

The API uses an initialization structure to configure the flash controller:

```c
typedef struct 
{
   Fapi_FmcRegistersType *m_poFlashControlRegisters;
   uint8 m_u8MainBankWidth;
   uint8 m_u8EeBankWidth;
   uint8 m_u8MainEccWidth;
   uint8 m_u8EeEccWidth;
   uint8 m_u8CurrentRwait;
   uint8 m_u8CurrentEwait;
   uint16 m_u16HclkFrequency;
} Fapi_InitStruct;
```

This structure holds:
- Pointer to the flash controller registers
- Width parameters for main bank and EE (EEPROM) bank
- ECC width parameters
- Current RWAIT and EWAIT values (timing parameters)
- HCLK frequency

## TI OTP (One-Time Programmable) Memory Structure

The API defines a detailed structure for accessing the TI OTP memory:

```c
typedef union
{
    volatile struct
    {
        uint32 ChecksumLength:16;  /* 0x150 bits 15:0 */
        uint32 OtpVersion:16;      /* 0x150 bits 31:16 */
        uint32 OtpChecksum;        /* 0x154 bits 31:0 */
        uint32 NumberOfBanks:16;   /* 0x158 bits 15:0 */
        uint32 NumberOfSectors:16; /* 0x158 bits 31:16 */
        uint32 MemorySize:16;      /* 0x15C bits 15:0 */
        uint32 Package:16;         /* 0x15C bits 31:16 */
        /* ... many more fields ... */
    } OTP_VALUE;
    volatile uint32 au32OtpWord[0x18];
} Fapi_TiOtpBytesType;
```

This structure provides access to device-specific parameters stored in OTP memory, including:
- Checksum information
- Flash configuration (number of banks, sectors, memory size)
- Device identification (package, silicon revision, ASIC number)
- Manufacturing information (lot number, wafer number, coordinates)
- Flash timing parameters (EVSU, PVSU, ESU, PSU, etc.)

## Key Differences in AsicNumber Field

**C28x Implementation:**
```c
uint16 AsicNumber_23_8:8;  /* 0x160 bits 31:8 */
uint16 AsicNumber_31_24:16; /* 0x160 bits 31:8 */
```

**Cortex-M Implementation:**
```c
uint32 AsicNumber:24;       /* 0x160 bits 31:8 */
```

The C28x implementation splits the ASIC number field into two parts, while the Cortex-M implementation uses a single 24-bit field.

## Flash Register Access

Both implementations define a simple structure for accessing the flash controller registers:

```c
typedef volatile struct FMC_REGISTERS
{
    uint32 u32Register[300];
} Fapi_FmcRegistersType;
```

This structure provides a generic way to access the flash controller registers as an array of 32-bit values.

## Compiler and Platform Adaptations

The API includes adaptations for different compilers and platforms:

```c
#if defined(__ICCARM__)             /* IAR EWARM Compiler */
#define ATTRIBUTE_PACKED  __packed
#elif defined(__TMS320C28XX__)      /* TI CGT C28xx compilers */
#define ATTRIBUTE_PACKED
#else                               /* all other compilers */
#define ATTRIBUTE_PACKED    __attribute__((packed))
#endif
```

This ensures that structures are packed correctly for different compilers, which is important for register access and memory-mapped structures.

## Endianness Handling

The API includes endianness detection and handling:

```c
#if defined(_LITTLE_ENDIAN)
   #define CPU_BYTE_ORDER    LOW_BYTE_FIRST
#else
   #define CPU_BYTE_ORDER    HIGH_BYTE_FIRST
#endif
```

Both C28x and Cortex-M implementations define `_LITTLE_ENDIAN` in their respective header files, indicating that both processors use little-endian byte ordering.

## Flash State Machine (FSM) Operation

The Flash State Machine is the hardware controller that performs flash operations. The API interacts with the FSM through the following workflow:

1. Check if the FSM is ready using `Fapi_checkFsmForReady()`
2. Set the active flash bank using `Fapi_setActiveFlashBank()` if needed
3. Issue a command to the FSM using one of:
   - `Fapi_issueAsyncCommandWithAddress()` for commands that require an address
   - `Fapi_issueAsyncCommand()` for commands that don't require an address
   - `Fapi_issueProgrammingCommand()` for programming data
4. Wait for the FSM to complete the operation by polling with `Fapi_getFsmStatus()`
5. Check the status to determine if the operation was successful

For long operations like sector erase, the API provides `Fapi_issueFsmSuspendCommand()` to temporarily suspend the operation.

## Referenced Context Files

The following context files were helpful in understanding the F021 Flash API:

1. `F021.h` - Provided the main API function declarations and overall structure
2. `Types.h` - Defined the data types used by the API, revealing key differences between C28x and Cortex-M implementations
3. `Constants/F2838x.h` and `Constants/F2838x_CM.h` - Showed the memory map differences between the two processor variants
4. `F021_F2838x_C28x.h` and `F021_F2838x_CM.h` - Established processor-specific configurations

## Conclusion

The F021 Flash API for F2838xD microcontrollers provides a comprehensive interface for flash operations with separate implementations for C28x and Cortex-M processors. The key differences between the implementations are:

1. **Data Types**: C28x uses 16-bit as its smallest addressable unit, while Cortex-M uses 8-bit
2. **Memory Maps**: Completely different memory maps for flash, OTP, and ECC regions
3. **Register Addresses**: Different base addresses for flash controller registers
4. **Function Signatures**: Different parameter types for programming functions
5. **Additional Functions**: Cortex-M has byte-oriented functions not present in C28x

Despite these differences, both implementations provide the same core functionality and interface to the Flash State Machine, allowing applications to perform flash operations in a consistent manner across both processor cores.