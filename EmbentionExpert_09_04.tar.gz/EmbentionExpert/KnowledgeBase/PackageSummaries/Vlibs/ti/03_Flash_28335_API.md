# Generated from:

- code/FLASH28335_API_V210/include/Flash2833x_API_Config.h (758 tokens)
- code/FLASH28335_API_V210/include/Flash2833x_API_Library.h (2434 tokens)
- code/FLASH28335_API_V210/source/Flash2833x_CsmKeys.asm (358 tokens)

---

# Flash2833x API Library for TMS320F28335/F28334/F28332 Microcontrollers

## Overview

The Flash2833x API Library provides a programming interface for managing flash memory operations on TMS320F28335, F28334, and F28332 microcontrollers. The library includes functions for erasing, programming, and verifying flash memory, as well as handling the Code Security Module (CSM) and other device-specific features.

## API Structure and Configuration

### Device Configuration

The API supports three specific device variants, which are configured in `Flash2833x_API_Config.h`:

```c
#define FLASH_F28335   1  // Set to 1 to target F28335
#define FLASH_F28334   0  // Set to 1 to target F28334
#define FLASH_F28332   0  // Set to 1 to target F28332
```

Only one device should be set to 1 at a time. The selected device determines which sectors are available and which API functions are used.

### CPU Clock Configuration

The API requires accurate timing information to properly program flash memory. This is configured through the `CPU_RATE` parameter in `Flash2833x_API_Config.h`:

```c
#define CPU_RATE    6.667L   // for a 150MHz CPU clock speed (SYSCLKOUT)
//#define CPU_RATE   10.000L   // for a 100MHz CPU clock speed (SYSCLKOUT)
//#define CPU_RATE   13.330L   // for a 75MHz CPU clock speed (SYSCLKOUT)
// [additional options...]
```

The CPU_RATE value represents the clock period in nanoseconds. Only one rate should be uncommented. This value is used to calculate the `SCALE_FACTOR`:

```c
#define SCALE_FACTOR  1048576.0L*( (200L/CPU_RATE) )  // IQ20
```

This scaling factor is critical for timing-sensitive flash operations and is used internally by the API.

## Data Types

The API defines specific data types to ensure portability across different compilers and platforms:

```c
typedef int                 int16;
typedef long                int32;
typedef long long           int64;   
typedef unsigned int        Uint16;
typedef unsigned long       Uint32;
typedef unsigned long long  Uint64;
typedef float               float32;
typedef long double         float64;
```

## Status Codes and Error Handling

The API returns status codes to indicate the success or failure of operations:

| Status Code | Value | Description |
|-------------|-------|-------------|
| STATUS_SUCCESS | 0 | Operation completed successfully |
| STATUS_FAIL_CSM_LOCKED | 10 | Code Security Module is preventing the operation |
| STATUS_FAIL_REVID_INVALID | 11 | Device revision ID doesn't match API requirements |
| STATUS_FAIL_ADDR_INVALID | 12 | Invalid address provided to the API |
| STATUS_FAIL_INCORRECT_PARTID | 13 | Part ID mismatch (e.g., using F2806 API on F2808) |
| STATUS_FAIL_API_SILICON_MISMATCH | 14 | API version not compatible with silicon |
| STATUS_FAIL_NO_SECTOR_SPECIFIED | 20 | No flash sector specified for erase |
| STATUS_FAIL_PRECONDITION | 21 | Erase precondition failed |
| STATUS_FAIL_ERASE | 22 | Flash erase operation failed |
| STATUS_FAIL_COMPACT | 23 | Flash compaction operation failed |
| STATUS_FAIL_PRECOMPACT | 24 | Flash pre-compaction operation failed |
| STATUS_FAIL_PROGRAM | 30 | Flash program operation failed |
| STATUS_FAIL_ZERO_BIT_ERROR | 31 | Zero bit error during programming |
| STATUS_FAIL_VERIFY | 40 | Flash verification failed |
| STATUS_BUSY | 999 | API function is busy (internal use only) |

## Flash Sector Organization

The flash memory is organized into sectors that can be individually erased. The API provides macros to specify which sectors to operate on:

```c
#define SECTORA   static_cast<Uint16>(0x0001)  // Bit0 = Sector A
#define SECTORB   static_cast<Uint16>(0x0002)  // Bit1 = Sector B
#define SECTORC   static_cast<Uint16>(0x0004)  // Bit2 = Sector C
#define SECTORD   static_cast<Uint16>(0x0008)  // Bit3 = Sector D
#define SECTORE   static_cast<Uint16>(0x0010)  // Bit4 = Sector E
#define SECTORF   static_cast<Uint16>(0x0020)  // Bit5 = Sector F
#define SECTORG   static_cast<Uint16>(0x0040)  // Bit6 = Sector G
#define SECTORH   static_cast<Uint16>(0x0080)  // Bit7 = Sector H
```

Device-specific sector combinations are also defined:

```c
// F28335: All sectors (A-H)
#define SECTOR_F28335 (SECTORA|SECTORB|SECTORC|SECTORD|SECTORE|SECTORF|SECTORG|SECTORH)

// F28334: All sectors (A-H)
#define SECTOR_F28334 (SECTORA|SECTORB|SECTORC|SECTORD|SECTORE|SECTORF|SECTORG|SECTORH)

// F28332: Sectors A-D only
#define SECTOR_F28332 (SECTORA|SECTORB|SECTORC|SECTORD)
```

## Status Structure

The API uses a status structure to provide detailed information about failures:

```c
typedef struct {
    Uint32  FirstFailAddr;  // Address where the first failure occurred
    Uint16  ExpectedData;   // Expected data at failure address
    Uint16  ActualData;     // Actual data at failure address
} FLASH_ST;
```

This structure is populated by the API functions when errors occur, allowing the application to diagnose the specific cause of failures.

## API Function Interface

The library provides a device-independent interface through macros that map to device-specific implementations:

```c
#if FLASH_F28335
#define Flash_Erase(a,b)          Flash28335_Erase(a,b)
#define Flash_Program(a,b,c,d)    Flash28335_Program(a,b,c,d)
#define Flash_Verify(a,b,c,d)     Flash28335_Verify(a,b,c,d)
#define Flash_ToggleTest(a,b)     Flash28335_ToggleTest(a,b)
#define Flash_DepRecover()        Flash28335_DepRecover()
#define Flash_APIVersionHex()     Flash28335_APIVersionHex()
#define Flash_APIVersion()        Flash28335_APIVersion()
#endif
```

Similar mappings exist for F28334 and F28332 devices. This allows application code to use generic function names regardless of the target device.

### Core API Functions

The library exposes the following core functions:

```c
// Erase specified flash sectors
extern Uint16 Flash_Erase(Uint16 SectorMask, FLASH_ST *FEraseStat);

// Program flash memory with data from a buffer
extern Uint16 Flash_Program(Uint16 *FlashAddr, Uint16 *BufAddr, Uint32 Length, FLASH_ST *FProgStatus);

// Verify flash memory contents against a buffer
extern Uint16 Flash_Verify(Uint16 *StartAddr, Uint16 *BufAddr, Uint32 Length, FLASH_ST *FVerifyStat);

// Test flash toggle bit functionality
extern void Flash_ToggleTest(volatile Uint32 *ToggleReg, Uint32 Mask);

// Recover from a failed erase/program operation
extern Uint16 Flash_DepRecover();

// Get API version information
extern float32 Flash_APIVersion();
extern Uint16 Flash_APIVersionHex();
```

## Code Security Module (CSM)

The Code Security Module protects flash memory from unauthorized access. The API includes functionality to handle CSM operations:

### CSM Keys

The file `Flash2833x_CsmKeys.asm` defines the password keys used to unlock the CSM:

```assembly
.global _PRG_key0
.global _PRG_key1
.global _PRG_key2
.global _PRG_key3
.global _PRG_key4
.global _PRG_key5
.global _PRG_key6
.global _PRG_key7

.text                         
_PRG_key0  .word 0xFFFF  ; PSWD bits 15-0
_PRG_key1  .word 0xFFFF  ; PSWD bits 31-16
_PRG_key2  .word 0xFFFF  ; PSWD bits 47-32
_PRG_key3  .word 0xFFFF  ; PSWD bits 63-48
_PRG_key4  .word 0xFFFF  ; PSWD bits 79-64   
_PRG_key5  .word 0xFFFF  ; PSWD bits 95-80   
_PRG_key6  .word 0xFFFF  ; PSWD bits 111-96   
_PRG_key7  .word 0xFFFF  ; PSWD bits 127-112
```

For erased flash, all password locations contain 0xFFFF. In a secured device, these values would be programmed with the actual password.

The API checks the CSM status before performing flash operations. If the CSM is locked and the provided keys don't match, operations will fail with `STATUS_FAIL_CSM_LOCKED`.

## Callback Mechanism

The API provides a callback mechanism that allows application code to perform operations during flash programming:

```c
extern void (*Flash_CallbackPtr) (void);
```

This function pointer can be set to a user-defined function that will be called at safe times during erase, program, and verify operations. This can be used to service an external watchdog or send communications packets.

Important restrictions for the callback function:
- Flash and OTP memory are not available during the callback
- Flash/OTP cannot be read and code cannot execute from flash during the callback
- Flash API functions must not be called from within the callback

## Memory Management

The API is designed to be loaded from flash and run from SARAM (Static RAM). The linker symbols facilitate this memory management:

```c
extern Uint16 Flash28_API_LoadStart;
extern Uint16 Flash28_API_LoadEnd;
extern Uint16 Flash28_API_RunStart;
```

These symbols are defined by the linker and used to copy the flash API from flash to SARAM during initialization.

## CPU Scaling Factor

The API requires a global scaling factor for timing calculations:

```c
extern Uint32 Flash_CPUScaleFactor;
```

This factor must be provided by the calling program and is used for frequency scaling in the flash algorithms.

## Detailed Function Behavior

### Flash_Erase

```c
Uint16 Flash_Erase(Uint16 SectorMask, FLASH_ST *FEraseStat);
```

This function erases the specified flash sectors.

**Parameters:**
- `SectorMask`: Bit mask specifying which sectors to erase (SECTORA, SECTORB, etc.)
- `FEraseStat`: Pointer to a status structure that will be populated if an error occurs

**Returns:**
- `STATUS_SUCCESS` if successful
- Error code if unsuccessful

**Behavior:**
1. Checks if CSM is locked
2. Validates the sector mask
3. Performs erase precondition check
4. Erases the specified sectors
5. Performs compaction if necessary
6. Updates status structure if an error occurs

### Flash_Program

```c
Uint16 Flash_Program(Uint16 *FlashAddr, Uint16 *BufAddr, Uint32 Length, FLASH_ST *FProgStatus);
```

This function programs flash memory with data from a buffer.

**Parameters:**
- `FlashAddr`: Pointer to the flash memory location to program
- `BufAddr`: Pointer to the buffer containing data to program
- `Length`: Number of 16-bit words to program
- `FProgStatus`: Pointer to a status structure that will be populated if an error occurs

**Returns:**
- `STATUS_SUCCESS` if successful
- Error code if unsuccessful

**Behavior:**
1. Checks if CSM is locked
2. Validates the flash address and length
3. Programs the specified number of words
4. Verifies the programmed data
5. Updates status structure if an error occurs

### Flash_Verify

```c
Uint16 Flash_Verify(Uint16 *StartAddr, Uint16 *BufAddr, Uint32 Length, FLASH_ST *FVerifyStat);
```

This function verifies flash memory contents against a buffer.

**Parameters:**
- `StartAddr`: Pointer to the flash memory location to verify
- `BufAddr`: Pointer to the buffer containing expected data
- `Length`: Number of 16-bit words to verify
- `FVerifyStat`: Pointer to a status structure that will be populated if an error occurs

**Returns:**
- `STATUS_SUCCESS` if verification passes
- `STATUS_FAIL_VERIFY` if verification fails
- Other error code if unsuccessful

**Behavior:**
1. Checks if CSM is locked
2. Validates the flash address and length
3. Compares flash contents with buffer contents
4. Updates status structure with the first mismatch if verification fails

### Flash_ToggleTest

```c
void Flash_ToggleTest(volatile Uint32 *ToggleReg, Uint32 Mask);
```

This function tests flash toggle bit functionality.

**Parameters:**
- `ToggleReg`: Pointer to the register to toggle
- `Mask`: Bit mask specifying which bits to toggle

**Behavior:**
1. Toggles the specified bits in the register
2. Used for testing and diagnostics

### Flash_DepRecover

```c
Uint16 Flash_DepRecover();
```

This function attempts to recover from a failed erase or program operation.

**Returns:**
- `STATUS_SUCCESS` if recovery is successful
- Error code if unsuccessful

**Behavior:**
1. Resets internal flash state machines
2. Clears any error conditions
3. Prepares flash for subsequent operations

### Flash_APIVersion

```c
float32 Flash_APIVersion();
```

This function returns the API version as a floating-point number.

**Returns:**
- API version (e.g., 2.10)

### Flash_APIVersionHex

```c
Uint16 Flash_APIVersionHex();
```

This function returns the API version as a hexadecimal value.

**Returns:**
- API version in hexadecimal format (e.g., 0x0210 for version 2.10)

## Security Considerations

The Code Security Module (CSM) is a critical security feature that protects flash memory from unauthorized access. When the CSM is locked:

1. Flash memory cannot be read or programmed through the JTAG interface
2. Flash API functions will fail with `STATUS_FAIL_CSM_LOCKED` unless the correct password is provided
3. Code execution from flash is still possible, but reading or modifying flash contents is restricted

The CSM password consists of 128 bits divided into eight 16-bit words. These are stored in dedicated memory locations and are used to unlock the CSM when needed.

For maximum security:
- Use a strong, random password
- Store the password securely
- Consider implementing additional security measures at the application level

## Timing and Optimization

Flash operations are timing-sensitive, and the API includes several optimizations:

1. The `CPU_RATE` parameter ensures accurate timing regardless of the CPU clock frequency
2. The `SCALE_FACTOR` calculation adjusts internal timing loops based on the CPU clock
3. Flash operations are performed in small chunks with callbacks between them to allow system responsiveness
4. The API is designed to be copied from flash to SARAM for execution, improving performance and allowing flash to be modified while the API is running

## Referenced Context Files

No context files were provided in the input.