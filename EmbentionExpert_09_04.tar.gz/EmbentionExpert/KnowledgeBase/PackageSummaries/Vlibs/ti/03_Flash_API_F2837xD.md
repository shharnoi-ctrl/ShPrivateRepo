# Generated from:

- code/FlashAPI_F2837xD/include/F021.h (1697 tokens)
- code/FlashAPI_F2837xD/include/Types.h (4983 tokens)
- code/FlashAPI_F2837xD/include/Registers.h (245 tokens)
- code/FlashAPI_F2837xD/include/Registers_C28x.h (25589 tokens)
- code/FlashAPI_F2837xD/include/F021_F2837xD_C28x.h (199 tokens)
- code/FlashAPI_F2837xD/include/Init.h (220 tokens)
- code/FlashAPI_F2837xD/include/Helpers.h (362 tokens)
- code/FlashAPI_F2837xD/include/FlashAPI.h (37 tokens)
- code/FlashAPI_F2837xD/include/Constants/FMC.h (669 tokens)
- code/FlashAPI_F2837xD/include/Constants/Constants.h (272 tokens)
- code/FlashAPI_F2837xD/include/Constants/F2837xD.h (763 tokens)

---

# F021 Flash API for F2837xD Microcontrollers: Comprehensive Analysis

## 1. API Structure and Organization

The F021 Flash API is a comprehensive interface for controlling the flash memory on F2837xD microcontrollers. The API is organized into several key components:

### Core Header Files
- **F021.h**: Main include file that defines the public API functions
- **Types.h**: Defines data types used throughout the API
- **Registers.h**: Maps the Flash memory controller registers
- **Registers_C28x.h**: C28x-specific register definitions
- **F021_F2837xD_C28x.h**: F2837xD-specific configuration
- **Init.h**: Initialization structures
- **Helpers.h**: Helper macros for register access
- **Constants/Constants.h**: General constants
- **Constants/F2837xD.h**: F2837xD-specific constants
- **Constants/FMC.h**: Flash Memory Controller constants

### Memory Map and Organization

The F2837xD flash memory is organized as follows:
- **Flash Memory**: 0x80000 - 0xBFFFF
- **Customer OTP**: 0x78000 - 0x783FF
- **OTP ECC**: 0x1071000 - 0x107107F
- **Flash ECC**: 0x1080000 - 0x1087FFF

The memory is organized into banks, and each bank is divided into sectors. The API provides functions to access and manipulate these structures.

## 2. Flash State Machine (FSM) Interface

The Flash State Machine is the core component that executes flash operations. The API interacts with the FSM through a set of registers and commands.

### FSM Commands
```c
typedef enum
{
   Fapi_ProgramData    = 0x0002,
   Fapi_EraseSector    = 0x0006,
   Fapi_EraseBank      = 0x0008,
   Fapi_ValidateSector = 0x000E,
   Fapi_ClearStatus    = 0x0010,
   Fapi_ProgramResume  = 0x0014,
   Fapi_EraseResume    = 0x0016,
   Fapi_ClearMore      = 0x0018
} Fapi_FlashStateCommandsType;
```

### FSM Status Checking
```c
extern Fapi_FlashStatusType Fapi_getFsmStatus(void);
extern Fapi_StatusType Fapi_checkFsmForReady(void);
```

### FSM Control Functions
```c
extern Fapi_StatusType Fapi_setActiveFlashBank(Fapi_FlashBankType oFlashBank);
extern Fapi_StatusType Fapi_connectFlashPumpToCpu(Fapi_CpuSelectorType oFlashCpu);
extern Fapi_StatusType Fapi_enableBanksForOtpWrite(uint8 u8Banks);
extern Fapi_StatusType Fapi_disableBanksForOtpWrite(void);
extern Fapi_StatusType Fapi_issueFsmSuspendCommand(void);
```

### FSM Register Structure
The FSM registers are defined in the `Fapi_FmcRegistersType` structure, which includes:
- **FsmGlbctrl**: Global control register
- **FsmState**: State status register
- **FsmStatus**: Status register
- **FsmCommand**: Command register
- **FsmPeOsu**: Program/Erase Operation Setup register
- **FsmVstat**: Compact Operation Setup register
- **FsmPeVsu**: Program/Erase Verify Setup register
- **FsmCmpVsu**: Compare Verify Setup register
- **FsmExVal**: EXECUTEZ to Valid Data register
- **FsmRdH**: Read Mode Hold register
- **FsmPOh**: Program Hold register
- **FsmEraOh**: Erase Operation Hold register
- **FsmSavPul**: Saved Program Pulses register
- **FsmPeVh**: Program/Erase Verify Hold register
- **FsmPrgPw**: Program Pulse Width register
- **FsmEraPw**: Erase Pulse Width register
- **FsmSavEraPul**: Saved Erased Pulses register
- **FsmTimer**: Timer register
- **FsmMode**: MODE register
- **FsmPgm**: Program bits register
- **FsmEra**: Erase bits register
- **FsmPrgPul**: Maximum Programming Pulses register
- **FsmEraPul**: Maximum Erase Pulses register
- **FsmStepSize**: Step Size register
- **FsmPulCntr**: Pulse Counter register
- **FsmEcStepHeightSize**: Step Height register
- **FsmStMachine**: State Machine register
- **FsmWrEna**: Register Write Enable
- **FsmAccPp**: Accumulate Program Pulses register
- **FsmAccEp**: Accumulate Erase Pulses register
- **FsmAddr**: Address register
- **FsmSector**: Sector register
- **FmcRevId**: Revision Identification register
- **FsmErrAddr**: Error Address register
- **FsmAPgmMaxPul**: Maximum Program Pulse register
- **FsmExecute**: Command Execute register

## 3. Programming Interface

The API provides several functions for programming flash memory:

### Programming Commands
```c
extern Fapi_StatusType Fapi_issueProgrammingCommand(
    uint32 *pu32StartAddress,
    uint16 *pu16DataBuffer,
    uint16  u16DataBufferSizeInWords,
    uint16 *pu16EccBuffer,
    uint16  u16EccBufferSizeInBytes,
    Fapi_FlashProgrammingCommandsType oMode
);

extern Fapi_StatusType Fapi_issueProgrammingCommandForEccAddresses(
    uint32 *pu32StartAddress,
    uint16 *pu16EccBuffer,
    uint16 u16EccBufferSizeInBytes
);
```

### Programming Modes
```c
typedef enum
{
   Fapi_AutoEccGeneration, /* Default mode - auto generates ECC for provided data */
   Fapi_DataOnly,          /* Process only the data buffer */
   Fapi_EccOnly,           /* Process only the ECC buffer */
   Fapi_DataAndEcc         /* Process both data and ECC buffers */
} Fapi_FlashProgrammingCommandsType;
```

### Asynchronous Commands
```c
extern Fapi_StatusType Fapi_issueAsyncCommandWithAddress(
    Fapi_FlashStateCommandsType oCommand,
    uint32 *pu32StartAddress
);

extern Fapi_StatusType Fapi_issueAsyncCommand(Fapi_FlashStateCommandsType oCommand);
```

## 4. Read and Verification Functions

The API provides several functions for reading and verifying flash memory:

### Read Functions
```c
extern Fapi_StatusType Fapi_doMarginRead(
    uint32 *pu32StartAddress,
    uint32 *pu32ReadBuffer,
    uint32 u32Length,
    Fapi_FlashReadMarginModeType oReadMode
);

extern Fapi_StatusType Fapi_doMarginReadByByte(
    uint8 *pu8StartAddress,
    uint8 *pu8ReadBuffer,
    uint32 u32Length,
    Fapi_FlashReadMarginModeType oReadMode
);
```

### Verification Functions
```c
extern Fapi_StatusType Fapi_doBlankCheck(
    uint32 *pu32StartAddress,
    uint32 u32Length,
    Fapi_FlashStatusWordType *poFlashStatusWord
);

extern Fapi_StatusType Fapi_doVerify(
    uint32 *pu32StartAddress,
    uint32 u32Length,
    uint32 *pu32CheckValueBuffer,
    Fapi_FlashStatusWordType *poFlashStatusWord
);

extern uint32 Fapi_calculatePsa(
    uint32 *pu32StartAddress,
    uint32 u32Length,
    uint32 u32PsaSeed,
    Fapi_FlashReadMarginModeType oReadMode
);

extern Fapi_StatusType Fapi_doPsaVerify(
    uint32 *pu32StartAddress,
    uint32 u32Length,
    uint32 u32PsaValue,
    Fapi_FlashStatusWordType *poFlashStatusWord
);
```

### Read Margin Modes
```c
typedef enum
{
   Fapi_NormalRead = 0x0,
   Fapi_RM0        = 0x1,
   Fapi_RM1        = 0x2
} Fapi_FlashReadMarginModeType;
```

## 5. Error Handling and Status Reporting

The API provides comprehensive error handling and status reporting mechanisms:

### Status Types
```c
typedef enum
{
   Fapi_Status_Success=0,           /* Function completed successfully */
   Fapi_Status_FsmBusy,             /* FSM is Busy */
   Fapi_Status_FsmReady,            /* FSM is Ready */
   Fapi_Status_AsyncBusy,           /* Async function operation is Busy */
   Fapi_Status_AsyncComplete,       /* Async function operation is Complete */
   Fapi_Error_Fail=500,             /* Generic Function Fail code */
   Fapi_Error_StateMachineTimeout,  /* State machine polling never returned ready and timed out */
   Fapi_Error_OtpChecksumMismatch,  /* Returned if OTP checksum does not match expected value */
   Fapi_Error_InvalidDelayValue,    /* Returned if the Calculated RWAIT value exceeds 15 */
   Fapi_Error_InvalidHclkValue,     /* Returned if FClk is above max FClk value */
   Fapi_Error_InvalidCpu,           /* Returned if the specified Cpu does not exist */
   Fapi_Error_InvalidBank,          /* Returned if the specified bank does not exist */
   Fapi_Error_InvalidAddress,       /* Returned if the specified Address does not exist in Flash or OTP */
   Fapi_Error_InvalidReadMode,      /* Returned if the specified read mode does not exist */
   Fapi_Error_AsyncIncorrectDataBufferLength,
   Fapi_Error_AsyncIncorrectEccBufferLength,
   Fapi_Error_AsyncDataEccBufferLengthMismatch,
   Fapi_Error_FeatureNotAvailable  /* FMC feature is not available on this device */
} Fapi_StatusType;
```

### Status Word
```c
typedef struct
{
   uint32 au32StatusWord[4];
} Fapi_FlashStatusWordType;
```

### Status Register Fields
The `FmStat` register contains important status bits:
- **SLOCK**: Sector Lock Status
- **PSUSP**: Program Suspend
- **ESUSP**: Erase Suspend
- **VOLSTAT**: Core Voltage Status
- **CSTAT**: Command Status
- **INVDAT**: Invalid Data
- **PGM**: Program Active
- **ERS**: Erase Active
- **Busy**: Busy
- **CV**: Compact Verify
- **EV**: Erase verify
- **PCV**: Precondidition verify
- **PGV**: Program verify
- **DBF**: Disturbance Test Fail
- **ILA**: Illegal Address
- **RVF**: Read Verify Failure
- **RDVER**: Read Verify command currently underway
- **RVSUSP**: Read Verify Suspend

## 6. Memory Protection and Security Features

The API includes several registers and functions for memory protection:

### Bank Protection Register
```c
union FBPROT
{
   uint32 u32Register; /* Bank Protection Register, bits 31:0 */
   struct
   {
      uint16  PROTL1DIS              :1; /* Level 1 Protection Disabled, bit 0 */
      uint16 _FBPROT_Reserved_15_02  :15;/* Reserved, bits 31:1 */
      uint16 _FBPROT_Reserved_31_16  :16;/* Reserved, bits 31:1 */
   } FBPROT_BITS;
} Fbprot;
```

### Bank Sector Enable Register
```c
union FBSE
{
   uint32 u32Register; /* Bank Protection Register, bits 31:0 */
   struct
   {
      uint16 BSE                  :16;/* Bank Sector Enable, bits 15:0 */
      uint16 _FBSE_Reserved_31_16 :16;/* Reserved, bits 31:16 */
   } FBSE_BITS;
} Fbse;
```

### OTP Protection
```c
extern Fapi_StatusType Fapi_enableBanksForOtpWrite(uint8 u8Banks);
extern Fapi_StatusType Fapi_disableBanksForOtpWrite(void);
```

## 7. Error Correction Code (ECC) Support

The API provides extensive support for Error Correction Code (ECC):

### ECC Calculation
```c
extern uint8 Fapi_calculateEcc(
    uint32 u32Address,
    uint64 u64Data
);
```

### ECC Address Remapping
```c
extern uint32 * Fapi_remapEccAddress(uint32 u32EccAddress);
extern boolean Fapi_isAddressEcc(uint32 u32Address);
```

### ECC Control Registers
```c
union FEDACCTRL1
{
   uint32 u32Register; /* Error Correction Control Register1, bits 31:0 */
   struct
   {
      uint16 EDACEN                     :4;/* Error Detection and Correction Enable, bits 3:0 */
      uint16 EZCV                       :1;/* Zero Condition Valid, bit 4 */
      uint16 EOCV                       :1;/* One Condition Valid, bit 5 */
      uint16 _FEDACCTRL1_Reserved_07_06 :2;/* Reserved, bits 7:6 */
      uint16 EPEN                       :1;/* Error Profiling Enable, bit 8 */
      uint16 EZFEN                      :1;/* Error on Zero Fail Enable, bit 9 */
      uint16 EOFEN                      :1;/* Error on One Fail Enable, bit 10 */
      uint16 _FEDACCTRL1_Reserved_15_11 :5;/* Reserved, bits 15:11 */
      uint16 EDACMODE                   :4;/* Error Correction Mode, bits 19:16 */
      uint16 _FEDACCTRL1_Reserved_23_20 :4;/* Reserved, bits 23:20 */
      uint16 SUSP_IGNR                  :1;/* Suspend Ignore, bit 24 */
      uint16 _FEDACCTRL1_Reserved_31_25 :7;/* Reserved, bits 31:25 */
   } FEDACCTRL1_BITS;
} FedAcCtrl1;
```

### ECC Status Register
```c
union FEDACSTATUS
{
   uint32 u32Register; /* Error Status Register, bits 31:0 */
   struct
   {
      uint16 ERR_PRF_FLG                 :1;/* Error Profiling Status Flag, bit 0 */
      uint16 ERR_ZERO_FLG                :1;/* Error On Zero Fail Status Flag, bit 1 */
      uint16 ERR_ONE_FLG                 :1;/* Error On One Fail Status Flag, bit 2 */
      uint16 D_COR_ERR                   :1;/* Diagnostic Correctable Error Status Flag, bit 3 */
      uint16 ECC0_MAL_ERR                :1;/* ECC Malfunction Status Flag, bit 4 */
      uint16 ECC1_MAL_ERR                :1;/* ECC Malfunction Status Flag, bit 5 */
      uint16 COM0_MAL_GOOD               :1;/* Compare Malfunction Flag, bit 6 */
      uint16 COM1_MAL_GOOD               :1;/* Compare Malfunction Flag, bit 7 */
      uint16 ECC_MUL_ERR                 :1;/* Multiple bit ECC or Parity Error Status Flag, bit 8 */
      uint16 BUF_PAR_ERR                 :1;/* Pipeline Buffer Parity Error Status Flag, bit 9 */
      uint16 ADD_PAR_ERR                 :1;/* Address Parity Error, bit 10 */
      uint16 ADD_TAG_ERR                 :1;/* Address Tag Register Error Status Flag, bit 11 */
      uint16 D_UNC_ERR                   :1;/* Diagnostic Un-correctable Error Status Flag, bit 12 */
      uint16 B2_ERR_IS_EE                :1;/* Bus 2 Error is due to EEPROM, bit 13 */
      uint16 _FEDACSTATUS_Reserved_15_14 :2;/* Reserved, bits 15:14 */
      uint16 B2_COR_ERR                  :1;/* Bus2 Correctable Error, bit 16 */
      uint16 B2_UNC_ERR                  :1;/* Bus2 Uncorrectable Error, bit 17 */
      uint16 ECCB2_MAL_ERR               :1;/* Bus2 ECC Malfunction Status Flag, bit 18 */
      uint16 COMB2_BUS_MAL_GOOD          :1;/* Bus2 Compare Malfunction Flag, bit 19 */
      uint16 ECC2_MAL_ERR                :1;/* ECC Malfunction Status Flag, bit 20 */
      uint16 ECC3_MAL_ERR                :1;/* ECC Malfunction Status Flag, bit 21 */
      uint16 COM2_MAL_GOOD               :1;/* Compare Malfunction Flag, bit 22 */
      uint16 COM3_MAL_GOOD               :1;/* Compare Malfunction Flag, bit 23 */
      uint16 FSM_DONE                    :1;/* FSM is Finished, bit 24 */
      uint16 RVF_INT                     :1;/* FSM command Read_verify failed interrupt, bit 25 */
      uint16 _FEDACSTATUS_Reserved_31_26 :6;/* Reserved, bits 31:26 */
   } FEDACSTATUS_BITS;
} FedAcStatus;
```

## 8. Timing and Performance Considerations

The API includes several registers and parameters for controlling timing:

### Wait State Control
```c
union FRDCNTL
{
   uint32 u32Register; /* Read Control Register, bits 31:0 */
   struct
   {
      uint16 RM                      :1;/* Read Mode, bit 0 */
      uint16 _FRDCNTL_Reserved_03_01 :3;/* Reserved, bits 3:1 */
      uint16 ASWSTEN                 :1;/* Address Setup Wait State Enable, bit 4 */
      uint16 _FRDCNTL_Reserved_07_05 :3;/* Reserved, bits 7:5 */
      uint16 RWAIT                   :4;/* Random Read Wait State, bits 11:8 */
      uint16 _FRDCNTL_Reserved_15_12 :4;/* Reserved, bits 15:12 */
      uint16 IDLEN                   :1;/* Incoming Data Latch, bit 16 */
      uint16 _FRDCNTL_Reserved_23_17 :7;/* Reserved, bits 23:17 */
      uint16 IFLUSH_HOLD             :4;/* Hold off IFLUSH for this long, bits 27:24 */
      uint16 _FRDCNTL_Reserved_31_28 :4;/* Reserved, bits 31:28 */
   } FRDCNTRL_BITS;
} FrdCntl;
```

### EWAIT Control
```c
extern Fapi_StatusType Fapi_writeEwaitValue(uint32 u32Ewait);
```

### Timing Parameters in Initialization Structure
```c
typedef struct 
{
   Fapi_TiOtpBytesType   *m_poTiOtpBaseAddress;
   Fapi_FmcRegistersType *m_poFlashControlRegisters;
   uint8 m_u8MainBankWidth;
   uint8 m_u8EeBankWidth;
   uint8 m_u8MainEccWidth;
   uint8 m_u8EeEccWidth;
   uint8 m_u8CurrentRwait;
   uint8 m_u8CurrentEwait;
   uint16 m_u16HclkFrequency;
} Fapi_InitStruct;
```

### Timing Constants
- **F021_FCLK_MAX**: Maximum FClck Value (0x18)
- **F021_PGM_OSU_MAX/MIN**: Program Operation Setup Max/Min Values
- **F021_ERA_OSU_MAX/MIN**: Erase Operation Setup Max/Min Values
- **F021_ADD_EXZ_MAX/MIN**: Address to EXECUTEZ Max/Min Values
- **F021_EXE_VALD_MAX/MIN**: EXECUTEZ to Valid Data Max/Min Values
- **F021_PROG_PUL_WIDTH_MAX/MIN**: Program Pulse Width Max/Min Values
- **F021_ERA_PUL_WIDTH_MAX/MIN**: Erase Pulse Width Max/Min Values

## 9. Bank and Sector Organization

The flash memory is organized into banks and sectors, with configuration information stored in registers:

### Bank Configuration
```c
union FCFG_BANK
{
   uint32 u32Register; /* Flash Bank configuration, bits 31:0 */
   struct
   {
      uint16  MAIN_NUM_BANK                  :4; /* MAIN_NUM_BANK, bits 3:0 */
      uint16  MAIN_BANK_WIDTH                :12;/* MAIN_BANK_WIDTH, bits 15:4 */
      uint16  EE_NUM_BANK                    :4; /* EE_NUM_BANK, bits 19:16 */
      uint16  EE_BANK_WIDTH                  :12;/* EE_BANK_WIDTH, bits 31:20 */
   } FCFG_BANK_BITS;
} FcfgBank;
```

### Bank Type Configuration
```c
union FCFG_BNK_TYPE
{
   uint32 u32Register; /* Flash Bank Type configuration, bits 31:0 */
   struct
   {
      uint16  B0_TYPE                        :4;/* B0_TYPE, bits  3:0  */
      uint16  B1_TYPE                        :4;/* B1_TYPE, bits  7:4  */
      uint16  B2_TYPE                        :4;/* B2_TYPE, bits 11:8  */
      uint16  B3_TYPE                        :4;/* B3_TYPE, bits 15:12 */
      uint16  B4_TYPE                        :4;/* B4_TYPE, bits 19:16 */
      uint16  B5_TYPE                        :4;/* B5_TYPE, bits 23:20 */
      uint16  B6_TYPE                        :4;/* B6_TYPE, bits 27:24 */
      uint16  B7_TYPE                        :4;/* B7_TYPE, bits 31:28 */
   } FCFG_BNK_TYPE_BITS;
} FcfgBnkType;
```

### Bank Start Address Configuration
```c
typedef union FCFG_Bx_START
{
   uint32 u32Register; /* Flash Bank x Start configuration, bits 31:0 */
   struct
   {
      uint16  Bx_START_ADDR_15_0             :16;/* Starting Address of Bank x, bits 23:0 */
      uint16  Bx_START_ADDR_23_16            :8;/* Starting Address of Bank x, bits 23:0 */
      uint16  Bx_MUX_FACTOR                  :4;/* Mux Factor of Bank x divided by 8, bits 27:24 */
      uint16  Bx_MAX_SECTOR                  :4;/* Number of highest sector in Bank x, bits 31:28 */
   } FCFG_Bx_START_BITS;
} FcfgBxStartType;
```

### Sector Size Configuration
```c
typedef volatile struct FMC_Bx_SSIZE
{
   union FCFG_Bx_SSIZE0
   {
      uint32 u32Register; /* Flash Bank x Sector Size 0 configuration, bits 31:0 */
      struct
      {
         uint16  Bx_SECT_SIZE_0                 :8;/* Size of sector 0 of Bank x, bits 7:0 */
         uint16  Bx_SECT_SIZE_1                 :8;/* Size of sector 1 of Bank x, bits 15:8 */
         uint16  Bx_SECT_SIZE_2                 :8;/* Size of sector 2 of Bank x, bits 23:16 */
         uint16  Bx_SECT_SIZE_3                 :8;/* Size of sector 3 of Bank x, bits 31:24 */
      } FCFG_Bx_SSIZE0_STD_BITS;
      struct
      {
         uint16  Bx_SECT_SIZE                   :4;/* Size of sectors in Bank x, bits 3:0 */
         uint16  _FCFG_Bx_SSIZE0_Reserved_15_4  :12;/* Reserved, bits 15:4 */
         uint16  Bx_NUM_SECTORS                 :12;/* Number of sectors in Bank x, bits 27:16 */
         uint16  _FCFG_Bx_SSIZE0_Reserved_31_28 :4;/* Reserved, bits 31:28 */
      } FCFG_Bx_SSIZE0_FLEE_BITS;
   } FcfgBxSsize0;
   
   // Additional sector size registers (FcfgBxSsize1, FcfgBxSsize2, FcfgBxSsize3)
} FcfgBxSSizeType;
```

### Bank Information Functions
```c
extern Fapi_StatusType Fapi_getBankSectors(
    Fapi_FlashBankType oBank, 
    Fapi_FlashBankSectorsType *poFlashBankSectors
);
```

## 10. Initialization and Configuration

The API requires initialization before use:

### Initialization Function
```c
extern Fapi_StatusType Fapi_initializeAPI(
    Fapi_FmcRegistersType *poFlashControlRegister,
    uint32 u32HclkFrequency
);
```

### Global Initialization Structure
```c
extern Fapi_InitStruct Fapi_GlobalInit;
```

### Device Information Functions
```c
extern Fapi_LibraryInfoType Fapi_getLibraryInfo(void);
extern Fapi_DeviceInfoType Fapi_getDeviceInfo(void);
```

## 11. Register Access and Helper Macros

The API provides helper macros for register access:

### Register Access Macros
```c
#define REGISTER(mRegister) (* (volatile uint32 *)(mRegister))

#define FAPI_WRITE_LOCKED_FSM_REGISTER(mRegister,mValue)                                      \
    {                                                                                         \
        Fapi_GlobalInit.m_poFlashControlRegisters->FsmWrEna.FSM_WR_ENA_BITS.WR_ENA    = 0x5U; \
        mRegister = mValue;                                                                   \
        Fapi_GlobalInit.m_poFlashControlRegisters->FsmWrEna.FSM_WR_ENA_BITS.WR_ENA    = 0x2U; \
    }
```

### Endianness Handling
```c
#if defined(_LITTLE_ENDIAN)
    #define EI16(idx)            (idx ^ 1)
    #define EI8(idx)             (idx ^ 3)
#else
    #define EI16(idx)            (idx)
    #define EI8(idx)             (idx)
#endif
```

## 12. Utility Functions

The API includes several utility functions:

### Delay Function
```c
extern Fapi_StatusType Fapi_waitDelay(volatile uint32 u32WaitDelay);
```

### Checksum Calculation
```c
extern uint32 Fapi_calculateFletcherChecksum(
    uint16 const * pu16Data,
    uint16 u16Length
);
```

### Pipeline Management
```c
extern void Fapi_flushPipeline(void);
```

### User-Defined Functions
```c
extern Fapi_StatusType Fapi_serviceWatchdogTimer(void);
extern Fapi_StatusType Fapi_setupEepromSectorEnable(void);
extern Fapi_StatusType Fapi_setupBankSectorEnable(void);
```

## Referenced Context Files

The following context files provided valuable information for understanding the F021 Flash API:
- F021.h: Main include file defining the public API functions
- Types.h: Defines data types used throughout the API
- Registers.h: Maps the Flash memory controller registers
- Registers_C28x.h: C28x-specific register definitions
- F021_F2837xD_C28x.h: F2837xD-specific configuration
- Init.h: Initialization structures
- Helpers.h: Helper macros for register access
- Constants/Constants.h: General constants
- Constants/F2837xD.h: F2837xD-specific constants
- Constants/FMC.h: Flash Memory Controller constants