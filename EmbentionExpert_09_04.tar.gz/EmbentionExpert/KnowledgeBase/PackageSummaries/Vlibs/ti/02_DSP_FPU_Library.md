# Generated from:

- code/dsp/FPU/c28/include/fpu_vector.h (4271 tokens)
- code/dsp/FPU/c28/include/fpu_rfft.h (3128 tokens)
- code/dsp/FPU/c28/include/fpu_types.h (352 tokens)
- code/dsp/FPU/c28/source/fft/RFFT_f32_mag.asm (2484 tokens)
- code/dsp/FPU/c28/source/fft/RFFT_f32.asm (6279 tokens)
- code/dsp/FPU/c28/source/fft/CFFT_f32s_mag.asm (2080 tokens)
- code/dsp/FPU/c28/source/fft/CFFT_f32s_mag_TMU0.asm (3422 tokens)
- code/dsp/FPU/c28/source/fft/RFFT_f32u.asm (3242 tokens)
- code/dsp/FPU/c28/source/fft/RFFT_f32_sincostable.c (847 tokens)
- code/dsp/FPU/c28/source/utility/memset_fast.asm (482 tokens)
- code/dsp/FPU/c28/source/utility/memcpy_fast.asm (593 tokens)
- code/dsp/FPU/c28/source/vector/rnd_SP_RS.asm (617 tokens)
- code/dsp/FPU/c28/source/vector/mpy_SP_RVxRV_2.asm (851 tokens)

---

# C28x FPU Library for Digital Signal Processing

This document provides a comprehensive analysis of the C28x Floating-Point Unit (FPU) Library, focusing on the implementation of Real and Complex Fast Fourier Transforms (RFFT/CFFT) and vector operations. The library is designed to leverage the C28x floating-point unit for efficient digital signal processing.

## 1. Library Overview and Architecture

The C28x FPU Library is organized into several key components:

- **Vector Operations**: Provides fundamental mathematical operations on vectors and complex numbers
- **Real FFT (RFFT)**: Implements Fast Fourier Transform for real-valued input data
- **Complex FFT (CFFT)**: Implements Fast Fourier Transform for complex-valued input data
- **Utility Functions**: Provides memory manipulation and other support functions

The library is designed with a consistent structure using handles and structs to maintain state and configuration information across function calls. It leverages the C28x architecture's floating-point capabilities and includes optimizations for devices with the TMU (Trigonometric Math Unit) accelerator.

## 2. Data Structures and Types

### 2.1 Basic Types

```c
// Complex Float Data Type
typedef struct {
    float dat[2]; // Real part at dat[0], Imaginary part at dat[1]
} complex_float;
```

### 2.2 RFFT Structure

```c
// Structure for the Real FFT
typedef struct {
  float  *InBuf;        // Pointer to the input buffer
  float  *OutBuf;       // Pointer to the output buffer
  float  *CosSinBuf;    // Pointer to the twiddle factors
  float  *MagBuf;       // Pointer to the magnitude buffer
  float  *PhaseBuf;     // Pointer to the phase buffer
  uint16_t FFTSize;     // Size of the FFT (number of real data points)
  uint16_t FFTStages;   // Number of FFT stages
} RFFT_F32_STRUCT;

// Handle to the Real FFT object
typedef RFFT_F32_STRUCT* RFFT_F32_STRUCT_Handle;
```

### 2.3 RFFT with ADC Input Structure

```c
// Structure for the Real FFT with ADC input
typedef struct {
  uint16_t *InBuf;    // Pointer to the input buffer
  void     *Tail;     // Null pointer to the OutBuf of RFFT_F32_STRUCT
} RFFT_ADC_F32_STRUCT;

// Handle to the Real FFT (with ADC input) structure
typedef RFFT_ADC_F32_STRUCT* RFFT_ADC_F32_STRUCT_Handle;
```

## 3. Vector Operations

The library provides an extensive set of vector operations optimized for the C28x FPU. These functions serve as building blocks for more complex DSP algorithms.

### 3.1 Complex Vector Operations

#### 3.1.1 Absolute Value Operations

```c
// Absolute Value of a Complex Vector
void abs_SP_CV(float *y, const complex_float *x, const uint16_t N);

// Absolute Value of an Even Length Complex Vector
void abs_SP_CV_2(float *y, const complex_float *x, const uint16_t N);

// Absolute Value of a Complex Vector (TMU0)
void abs_SP_CV_TMU0(float *y, const complex_float *x, const uint16_t N);

// Inverse Absolute Value of a Complex Vector
void iabs_SP_CV(float *y, const complex_float *x, const uint16_t N);

// Inverse Absolute Value of an Even Length Complex Vector
void iabs_SP_CV_2(float *y, const complex_float *x, const uint16_t N);

// Inverse Absolute Value of a Complex Vector (TMU0)
void iabs_SP_CV_TMU0(float *y, const complex_float *x, const uint16_t N);
```

#### 3.1.2 Complex Arithmetic Operations

```c
// Addition (Element-Wise) of a Complex Scalar to a Complex Vector
void add_SP_CSxCV(complex_float *y, const complex_float *x, 
                 const complex_float c, const uint16_t N);

// Addition of Two Complex Vectors
void add_SP_CVxCV(complex_float *y, const complex_float *w,
                 const complex_float *x, const uint16_t N);

// Subtraction of a Complex Scalar from a Complex Vector
void sub_SP_CSxCV(complex_float *y, const complex_float *x,
                 const complex_float c, const uint16_t N);

// Subtraction of a Complex Vector and another Complex Vector
void sub_SP_CVxCV(complex_float *y, const complex_float *w,
                 const complex_float *x, const uint16_t N);

// Complex Multiply of Two Floating Point Numbers
complex_float mpy_SP_CSxCS(complex_float w, complex_float x);

// Complex Multiply of Two Complex Vectors
void mpy_SP_CVxCV(complex_float *y, const complex_float *w, 
                 const complex_float *x, const uint16_t N);

// Multiplication of a Complex Vector and the Complex Conjugate of another Vector
void mpy_SP_CVxCVC(complex_float *y, const complex_float *w,
                  const complex_float *x, const uint16_t N);
```

#### 3.1.3 Mixed Real/Complex Operations

```c
// Multiply-and-Accumulate of a Real Vector and a Complex Vector
complex_float mac_SP_RVxCV(const complex_float *w,
                 const float *x, const uint16_t N);

// Multiply-and-Accumulate of a Real Vector and a Complex Vector (16-bit integer)
complex_float mac_SP_i16RVxCV(const complex_float *w, const int16_t *x,
        const uint16_t N);

// Multiplication of a Real Vector and a Complex Vector
void mpy_SP_RVxCV(complex_float *y, const complex_float *w,
                 const float *x, const uint16_t N);

// Mean of Real and Imaginary Parts of a Complex Vector
complex_float mean_SP_CV_2(const complex_float *x, const uint16_t N);
```

### 3.2 Real Vector Operations

```c
// Index of Maximum Value of an Even Length Real Array
uint16_t maxidx_SP_RV_2(float *x, uint16_t N);

// Median of a Real Valued Array of Floats (Preserved Inputs)
float median_noreorder_SP_RV(const float *x, uint16_t N);

// Median of a real array of floats
float median_SP_RV(float *x, uint16_t N);

// Multiplication of a Real scalar and a Real Vector
void mpy_SP_RSxRV_2(float *y, const float *x, const float c,
                   const uint16_t N);

// Multiplication of a Real Scalar, a Real Vector, and another Real Vector
void mpy_SP_RSxRVxRV_2(float *y, const float *w, const float *x,
                      const float c, const uint16_t N);

// Multiplication of a Real Vector and a Real Vector
void mpy_SP_RVxRV_2(float *y, const float *w, const float *x,
                   const uint16_t N);

// Sort an Array of Floats
void qsort_SP_RV(void *x, uint16_t N);

// Rounding (Unbiased) of a Floating Point Scalar
float rnd_SP_RS(float x);
```

### 3.3 Memory Utility Functions

```c
// Optimized Memory Copy
void memcpy_fast(void *dst, const void *src, uint16_t N);

// Optimized Memory Set
void memset_fast(void* dst, int16_t value, uint16_t N);
```

## 4. Real Fast Fourier Transform (RFFT) Implementation

The RFFT module provides functions for computing the Fast Fourier Transform of real-valued data. It includes both aligned and unaligned versions, as well as support for ADC input.

### 4.1 Core RFFT Functions

```c
// Real Fast Fourier Transform (RFFT)
void RFFT_f32(RFFT_F32_STRUCT_Handle hndRFFT_F32);

// Real FFT (Unaligned)
void RFFT_f32u(RFFT_F32_STRUCT_Handle hndRFFT_F32);

// Real FFT with ADC Input
void RFFT_adc_f32(RFFT_ADC_F32_STRUCT_Handle hndRFFT_ADC_F32);

// Real FFT with ADC Input (Unaligned)
void RFFT_adc_f32u(RFFT_ADC_F32_STRUCT_Handle hndRFFT_ADC_F32);

// Windowing function for the 32-bit real FFT
void RFFT_f32_win(float *pBuffer, float *pWindow, uint16_t size);

// Generate twiddle factors for the Real FFT
void RFFT_f32_sincostable(RFFT_F32_STRUCT_Handle hndRFFT_F32);
```

### 4.2 RFFT Post-Processing Functions

```c
// Real FFT Magnitude
void RFFT_f32_mag(RFFT_F32_STRUCT_Handle hndRFFT_F32);

// Real FFT Magnitude (Scaled)
void RFFT_f32s_mag(RFFT_F32_STRUCT_Handle hndRFFT_F32);

// Real FFT Phase
void RFFT_f32_phase(RFFT_F32_STRUCT_Handle hndRFFT_F32);

// TMU-accelerated versions
void RFFT_f32_mag_TMU0(RFFT_F32_STRUCT_Handle hndRFFT_F32);
void RFFT_f32s_mag_TMU0(RFFT_F32_STRUCT_Handle hndRFFT_F32);
void RFFT_f32_phase_TMU0(RFFT_F32_STRUCT_Handle hndRFFT_F32);
```

### 4.3 RFFT Algorithm Implementation

The RFFT implementation follows a multi-stage approach:

1. **Bit Reversal and Initial Stages**: The first function (`RFFT_f32_Stages1and2and3andBitReverse`) handles bit reversal of the input data and computes stages 1, 2, and 3 of the FFT.

2. **Higher Stages Processing**: The second function (`RFFT_f32_Stages4andUp`) computes stages 4 and up.

The algorithm is implemented in assembly for maximum performance, with careful attention to register usage and pipeline optimization.

#### 4.3.1 Stages 1, 2, and 3 with Bit Reversal

The implementation computes the following operations for each group of 8 input values:

```
OutBufIndex++ = (I1 + I2) + (I3 + I4) + (I5 + I6) + (I7 + I8);      (A)
OutBufIndex++ = (I1 - I2) + COS * ((I5 - I6) + (I8 - I7));          (B)
OutBufIndex++ = (I1 + I2) - (I3 + I4);                              (C)
OutBufIndex++ = (I1 - I2) - COS * ((I5 - I6) + (I8 - I7));          (D)
OutBufIndex++ = ((I1 + I2) + (I3 + I4)) - ((I5 + I6) + (I7 + I8));  (E)
OutBufIndex++ = COS * ((I8 - I7) - (I5 - I6)) - (I4 - I3);          (F)
OutBufIndex++ = (I7 + I8) - (I5 + I6);                              (G)
OutBufIndex++ = COS * ((I8 - I7) - (I5 - I6)) + (I4 - I3);          (H)
```

Where COS = COS(1*2*PI/8) = SIN(1*2*PI/8)

#### 4.3.2 Stages 4 and Up

For stages 4 and up, the algorithm performs butterfly operations with twiddle factors:

```
Y1 = Y1 + Y3
X(I1) = X(I1) + [X(I3)*COS + X(I4)*SIN]
Y2 = Y2
X(I2) = X(I1) - [X(I3)*COS + X(I4)*SIN]
Y3 = Y1 - Y3
X(I3) = [X(I4)*COS - X(I3)*SIN] - X(I2)
Y4 = -Y4
X(I4) = [X(I4)*COS - X(I3)*SIN] + X(I2)
```

### 4.4 Twiddle Factor Generation

The `RFFT_f32_sincostable` function generates the sine and cosine tables (twiddle factors) needed for the FFT computation. The table is organized in a specific structure to support all FFT stages:

```c
void RFFT_f32_sincostable(RFFT_F32_STRUCT_Handle fft)
{
    float  tempPI, temp;
    uint16_t i, j, k, l, N;

    tempPI = 0.7853981633975;   // pi/4
    k = 1;
    l = 0;
    for(i = 3; i <= fft->FFTStages; i++)
    {
        N = 1;
        for(j=1; j <= k; j ++)
        {
            temp = (float)N * tempPI;
            fft->CosSinBuf[l++] = cosf(temp);
            fft->CosSinBuf[l++] = sinf(temp);
            N++;
        }
        fft->CosSinBuf[l++] = 0.0;
        fft->CosSinBuf[l++] = 1.0;
        k = (k * 2) + 1;
        tempPI = tempPI * 0.5;
    }
}
```

### 4.5 Magnitude and Phase Calculation

After the FFT computation, the magnitude and phase can be calculated using dedicated functions. The magnitude calculation is implemented in assembly for maximum performance:

```assembly
; Calculate magnitude squared
MOV32    R0H, *XAR6++         ; R0H = Re[i]
MPYF32   R0H, R0H, R0H        ; R0H = Re[i]*Re[i]
|| MOV32    R1H, *XAR6++      ; R1H = Im[i]

MPYF32   R1H, R1H, R1H        ; R1H = Im[i]*Im[i]
ADDF32   R0H, R1H, R0H        ; R0H = (Re[i]*Re[i]) + (Im[i]*Im[i])

; Do the sqrt using iterative approximation
EISQRTF32   R1H, R0H          ; R1H = Ye[i] = Estimate(1/sqrt(X[i]))
MPYF32      R2H, R0H, #0.5    ; R2H = X[i]*0.5
MPYF32      R3H, R1H, R1H     ; R3H = Ye[i]*Ye[i]
MPYF32      R3H, R3H, R2H     ; R3H = Ye[i]*Ye[i]*X[i]*0.5
SUBF32      R3H, #1.5, R3H    ; R3H = 1.5 - Ye[i]*Ye[i]*X[i]*0.5
MPYF32      R1H, R1H, R3H     ; R1H = Ye[i] = Ye[i]*(1.5 - Ye[i]*Ye[i]*X[i]*0.5)
MPYF32      R0H, R0H, R1H     ; R0H = Y[i] = X[i]*Ye[i] = sqrt(X[i])
```

The TMU-accelerated version uses the hardware square root function for better performance:

```assembly
MPYF32    R1H, R1H, R1H         ; R1H = Im[i+0]*Im[i+0]
ADDF32    R1H, R1H, R0H         ; R1H = (Re[i+0]*Re[i+0]) + (Im[i+0]*Im[i+0])
MPYF32    R1H, R1H, R0H         ; R1H = scale*[(Re[i+0]*Re[i+0]) + (Im[i+0]*Im[i+0])]
SQRTF32   R1H, R1H              ; R1H = sqrt[(Re[i+0]*Re[i+0]) + (Im[i+0]*Im[i+0])]
```

## 5. Complex Fast Fourier Transform (CFFT) Implementation

The library also includes Complex FFT functionality, which processes complex-valued input data. The implementation follows a similar structure to the RFFT but is optimized for complex data.

### 5.1 CFFT Magnitude Calculation

The CFFT magnitude calculation is implemented in assembly for maximum performance:

```assembly
; Compute magnitude squared
MOV32    R0H, *XAR6++         ; R0H = Re[i]
MPYF32   R0H, R0H, R0H        ; R0H = Re[i]*Re[i]
|| MOV32    R1H, *XAR6++      ; R1H = Im[i]

MOV32    R4H, *XAR6++         ; R4H = Re[i+1]
MPYF32   R4H, R4H, R4H        ; R4H = Re[i+1]*Re[i+1]
|| MOV32    R5H, *XAR6++      ; R5H = Im[i+1]

MPYF32   R1H, R1H, R1H        ; R1H = Im[i]*Im[i]
MPYF32   R5H, R5H, R5H        ; R5H = Im[i+1]*Im[i+1]

ADDF32   R0H, R1H, R0H        ; R0H = (Re[i]*Re[i]) + (Im[i]*Im[i])
ADDF32   R4H, R5H, R4H        ; R4H = (Re[i+1]*Re[i+1]) + (Im[i+1]*Im[i+1])
|| MOV32    R7H, *-SP[2]      ; R7H = scale

MPYF32   R0H, R0H, R7H        ; R0H = scale*[(Re[i]*Re[i]) + (Im[i]*Im[i])]
MPYF32   R4H, R4H, R7H        ; R4H = scale*[(Re[i+1]*Re[i+1]) + (Im[i+1]*Im[i+1])]
```

### 5.2 TMU-Accelerated CFFT Magnitude

For devices with the TMU module, a highly optimized version is provided:

```assembly
; Iteration block with TMU acceleration
MPYF32    R3H, R3H, R3H         ; R3H = Im[i+1]*Im[i+1]
|| MOV32     R0H, *-SP[2]       ; R0H = scale factor, iteration [i+0]
MPYF32    R1H, R1H, R0H         ; R1H = scale*[(Re[i+0]*Re[i+0]) + (Im[i+0]*Im[i+0])]
|| MOV32     R4H, *XAR6++       ; R4H = Re[i+2]
MPYF32    R4H, R4H, R4H         ; R4H = Re[i+2]*Re[i+2]
|| MOV32     *XAR5++,R5H        ; Store mag[i+2]
ADDF32    R3H, R3H, R2H         ; R3H = (Re[i+1]*Re[i+1]) + (Im[i+1]*Im[i+1])
|| MOV32     R5H, *XAR6++       ; R5H = Im[i+2]
SQRTF32   R1H, R1H              ; R1H = sqrt[(Re[i+0]*Re[i+0]) + (Im[i+0]*Im[i+0])]
```

## 6. Memory Utility Functions

The library includes optimized memory manipulation functions for efficient data handling:

### 6.1 Fast Memory Copy

```assembly
_memcpy_fast:
        ADDB    AL, #-1                ;Repeat "N-1" times
        BF      done, NC               ;Branch if N was zero
        MOVL    XAR7, XAR5             ;XAR7 = XAR5 = dst
        RPT     @AL
    ||  PREAD   *XAR4++, *XAR7         ;Do the copy

;Finish up
done:
        LRETR                          ;return
```

### 6.2 Fast Memory Set

```assembly
_memset_fast:
        ADDB        AH, #-1         ;Repeat "N-1" times
        BF          done, NC        ;Branch if N was zero
        RPT         @AH
    ||  MOV         *XAR4++, AL     ;Initialize the memory

;Finish up
done:
        LRETR                       ;return
```

## 7. Performance Characteristics

The library is highly optimized for the C28x architecture with FPU, with careful attention to cycle counts and memory usage:

- **RFFT_f32_mag**: 18 cycles/complex value + overhead
- **CFFT_f32s_mag**: 19 cycles/complex value + overhead
- **CFFT_f32s_mag_TMU0**: 5 cycles/complex value + overhead (with TMU acceleration)
- **mpy_SP_RVxRV_2**: 3*N + 17 cycles (including call and return)
- **memcpy_fast**: 1 cycle per copy + ~20 cycles overhead
- **rnd_SP_RS**: 18 cycles (including call and return)

## 8. Hardware Acceleration Features

The library leverages the C28x architecture's hardware features for optimal performance:

1. **Floating-Point Unit (FPU)**: All operations use the native floating-point capabilities of the C28x FPU.

2. **Trigonometric Math Unit (TMU)**: For devices with TMU support, specialized versions of functions are provided that use hardware acceleration for trigonometric and square root operations:
   - `abs_SP_CV_TMU0`
   - `iabs_SP_CV_TMU0`
   - `RFFT_f32_mag_TMU0`
   - `RFFT_f32s_mag_TMU0`
   - `RFFT_f32_phase_TMU0`
   - `CFFT_f32s_mag_TMU0`

3. **Parallel Instruction Execution**: The assembly code makes extensive use of the C28x's ability to execute multiple instructions in parallel, indicated by the `||` operator in the assembly code.

## 9. Numerical Considerations

The library implements several numerical techniques to ensure accuracy and performance:

1. **Iterative Square Root Approximation**: For devices without TMU, the square root is calculated using an iterative approximation:
   ```
   Ye = Estimate(1/sqrt(X))
   Ye = Ye*(1.5 - Ye*Ye*X*0.5)
   Ye = Ye*(1.5 - Ye*Ye*X*0.5)
   Y = X*Ye = sqrt(X)
   ```

2. **Scaling in FFT**: The RFFT and CFFT implementations include scaled versions of magnitude calculations to prevent overflow in fixed-point algorithms:
   ```
   scale = 1.0
   for i = 3 to FFTStages:
       scale = scale * 0.5
   scale = scale * scale
   ```

3. **Unbiased Rounding**: The `rnd_SP_RS` function implements unbiased rounding for floating-point values:
   ```
   if x >= 0:
       return floor(x + 0.5)
   else:
       return floor(x - 0.5)
   ```

## 10. Usage Patterns and Constraints

The library has several usage patterns and constraints that must be observed:

1. **Memory Alignment**: For optimal performance, the RFFT input buffer must be aligned to a memory address of 2N words (16-bit). If alignment is not possible, use the unaligned versions (`RFFT_f32u`, `RFFT_adc_f32u`).

2. **FFT Size Restrictions**: FFT size must be a power of 2 (32, 64, 128, etc.) and greater than or equal to 32.

3. **Buffer Requirements**:
   - InBuf, OutBuf, CosSinBuf are FFTSize in length
   - MagBuf is (FFTSize/2 + 1) in length
   - PhaseBuf is FFTSize/2 in length

4. **Function Sequence**: Certain functions must be called in sequence:
   - `RFFT_f32()` or `RFFT_f32u()` must be called before `RFFT_f32_mag()`, `RFFT_f32s_mag()`, or `RFFT_f32_phase()`

5. **Non-Interruptibility**: Some functions like `memcpy_fast()` are not interruptible and do not support memory above 22 bits address.

6. **Even Length Requirements**: Several functions require N to be even:
   - `abs_SP_CV_2()`
   - `iabs_SP_CV_2()`
   - `maxidx_SP_RV_2()`
   - `mean_SP_CV_2()`
   - `mpy_SP_RSxRV_2()`
   - `mpy_SP_RSxRVxRV_2()`
   - `mpy_SP_RVxRV_2()`

## 11. Referenced Context Files

The following context files provided valuable information for understanding the C28x FPU Library:

1. `fpu_types.h`: Defines the basic data types used throughout the library, particularly the `complex_float` structure.

2. `fpu_vector.h`: Contains prototypes for vector operations, including complex vector arithmetic, real vector operations, and utility functions.

3. `fpu_rfft.h`: Defines the RFFT structures and function prototypes for real FFT operations.

4. `RFFT_f32.asm`, `RFFT_f32u.asm`: Implement the core RFFT algorithm with optimized assembly code.

5. `RFFT_f32_mag.asm`: Implements magnitude calculation for RFFT results.

6. `CFFT_f32s_mag.asm`, `CFFT_f32s_mag_TMU0.asm`: Implement magnitude calculation for CFFT results, with and without TMU acceleration.

7. `RFFT_f32_sincostable.c`: Implements the generation of twiddle factors for RFFT.

8. `memcpy_fast.asm`, `memset_fast.asm`: Implement optimized memory operations.

9. `rnd_SP_RS.asm`, `mpy_SP_RVxRV_2.asm`: Implement basic vector operations.

## Conclusion

The C28x FPU Library provides a comprehensive set of optimized functions for digital signal processing on C28x devices with floating-point units. The library leverages the architecture's capabilities, including the FPU and TMU, to deliver high-performance implementations of common DSP operations, particularly Fast Fourier Transforms. The careful attention to optimization, including assembly implementation of critical functions, ensures efficient execution on the target platform.