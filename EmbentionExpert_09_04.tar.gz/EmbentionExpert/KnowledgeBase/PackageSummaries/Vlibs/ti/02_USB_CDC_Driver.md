# Generated from:

- code/F2837xD_usb/include/USB_CDC_if.h (593 tokens)
- code/F2837xD_usb/include/usb_cdc_serial_structs.h (272 tokens)
- code/F2837xD_usb/include/driverlib/debug.h (1025 tokens)
- code/F2837xD_usb/include/driverlib/usb.h (7918 tokens)
- code/F2837xD_usb/include/driverlib/inc/hw_types.h (1531 tokens)
- code/F2837xD_usb/include/driverlib/inc/hw_memmap.h (2359 tokens)
- code/F2837xD_usb/include/driverlib/inc/hw_usb.h (56466 tokens)
- code/F2837xD_usb/include/usb/include/usblibpriv.h (5768 tokens)
- code/F2837xD_usb/include/usb/include/usblib.h (16561 tokens)
- code/F2837xD_usb/include/usb/include/usb_ids.h (758 tokens)
- code/F2837xD_usb/include/usb/include/usbcdc.h (11353 tokens)
- code/F2837xD_usb/include/usb/include/device/usbdevicepriv.h (1868 tokens)
- code/F2837xD_usb/include/usb/include/device/usbdevice.h (2126 tokens)
- code/F2837xD_usb/include/usb/include/device/usbdcdc.h (3572 tokens)
- code/F2837xD_usb/source/usb_cdc_serial_structs.cpp (1693 tokens)
- code/F2837xD_usb/source/USB_CDC_if.cpp (1891 tokens)
- code/F2837xD_usb/source/ti/usbbuffer.cpp (7095 tokens)
- code/F2837xD_usb/source/ti/usbtick.cpp (1273 tokens)
- code/F2837xD_usb/source/ti/usb.cpp (33190 tokens)
- code/F2837xD_usb/source/ti/usbringbuf.cpp (4067 tokens)
- code/F2837xD_usb/source/ti/usbdesc.cpp (1545 tokens)
- code/F2837xD_usb/source/ti/device/usbdcdc.cpp (22508 tokens)
- code/F2837xD_usb/source/ti/device/usbdenum.cpp (22094 tokens)
- code/F2837xD_usb/source/ti/device/usbdconfig.cpp (4649 tokens)
- code/F2837xD_usb/source/ti/device/usbdhandler.cpp (333 tokens)
- code/F2837xD_usb/source/ti/device/usbdcdesc.cpp (5045 tokens)

---

# USB CDC Interface Implementation for F2837xD Microcontrollers

This document provides a comprehensive analysis of the USB CDC (Communications Device Class) interface implementation for F2837xD microcontrollers. The implementation enables the microcontroller to function as a virtual COM port when connected to a host computer via USB.

## Architecture Overview

The USB CDC implementation follows a layered architecture:

1. **Application Layer**: `USB_CDC_if` class that provides a simple API for applications
2. **Buffer Layer**: USB buffer management for transmit and receive operations
3. **CDC Device Layer**: USB CDC device class implementation
4. **USB Core Layer**: Low-level USB controller driver

## USB_CDC_if Class

The `USB_CDC_if` class serves as the main interface for applications to interact with the USB CDC functionality.

### Singleton Pattern

The class implements a singleton pattern to ensure only one instance exists:

```cpp
USB_CDC_if& USB_CDC_if::get_instance()
{
    static USB_CDC_if dev;
    return dev;
}
```

### Key Methods

1. **Initialization**:
   ```cpp
   USB_CDC_if::USB_CDC_if() :
       connected(false),
       times_tx_full(0)
   {
       // Initialize line coding parameters (baud rate, stop bits, parity, data bits)
       lineCoding.ui32Rate.MSW.MSB = 0x00;
       lineCoding.ui32Rate.MSW.LSB = 0x01;
       lineCoding.ui32Rate.LSW.MSB = 0xC2;
       lineCoding.ui32Rate.LSW.LSB = 0x00;
       lineCoding.ui8Stop = USB_CDC_STOP_BITS_1;
       lineCoding.ui8Parity = USB_CDC_PARITY_NONE;
       lineCoding.ui8Databits = Ku8::u8;

       InitCDC();
   }
   ```

2. **CDC Initialization**:
   ```cpp
   void USB_CDC_if::InitCDC()
   {
       USBBufferInit(&g_sTxBuffer);
       USBBufferInit(&g_sRxBuffer);
       USBDCDCInit(0, &g_sCDCDevice);
   }
   ```

3. **Data Transmission**:
   ```cpp
   bool USB_CDC_if::write(Uint8 data)
   {
       return USBBufferWrite(&g_sTxBuffer, reinterpret_cast<const uint8_t*>(&data), 1) == 1;
   }

   Uint32 USB_CDC_if::write(Base::Mblock<Uint8> mb)
   {
       return USBBufferWrite(&g_sTxBuffer, reinterpret_cast<const uint8_t*>(mb.v), mb.sz);
   }
   ```

4. **Data Reception**:
   ```cpp
   bool USB_CDC_if::read(Uint8& data)
   {
       return USBBufferRead(&g_sRxBuffer, reinterpret_cast<uint8_t*>(&data), 1) == 1;
   }
   ```

5. **Status Checking**:
   ```cpp
   Uint32 USB_CDC_if::rd_available()
   {
       return USBBufferDataAvailable(&g_sRxBuffer);
   }

   bool USB_CDC_if::wr_available()
   {
       const Uint32 wr_av = USBBufferSpaceAvailable(&g_sTxBuffer);
       if(wr_av == 0)
       {
           // Workaround for TI usblib bug
           times_tx_full++;
           if(times_tx_full >= max_times_tx_full)
           {
               USBBufferFlush(&g_sTxBuffer);
               times_tx_full = 0;
               connected = false;
           }
       }
       return wr_av > 0;
   }
   ```

6. **USB Event Handling**:
   ```cpp
   uint32_t USB_CDC_if::ControlHandler(const void* pvCBData,
                                      uint32_t ui32Event,
                                      Uint32 ui32MsgValue,
                                      void* pvMsgData)
   {
       // Handle USB events like connection, disconnection, line coding changes
       switch(ui32Event)
       {
           case USB_EVENT_CONNECTED:
               USBBufferFlush(&g_sTxBuffer);
               USBBufferFlush(&g_sRxBuffer);
               connected = true;
               break;
           case USB_EVENT_DISCONNECTED:
               connected = false;
               break;
           // Other event handling...
       }
       return 0;
   }
   ```

7. **Polling Function**:
   ```cpp
   void USB_CDC_if::poll()
   {
       USB0DeviceIntHandler();
   }
   ```

## USB Buffer Management

The implementation uses a ring buffer system to manage data transmission and reception:

### Buffer Structures

```cpp
typedef struct
{
    bool bTransmitBuffer;                // Is this a transmit buffer?
    tUSBCallback pfnCallback;            // Callback for buffer events
    void *pvCBData;                      // Callback data
    tUSBPacketTransfer pfnTransfer;      // Function to transfer data
    tUSBPacketAvailable pfnAvailable;    // Function to check available space
    void *pvHandle;                      // Handle for the lower layer
    uint8_t *pui8Buffer;                 // Pointer to the buffer memory
    uint32_t ui32BufferSize;             // Size of the buffer
    tUSBBufferVars sPrivateData;         // Private workspace variables
} tUSBBuffer;
```

### Buffer Initialization

```cpp
const tUSBBuffer *USBBufferInit(tUSBBuffer *psBuffer)
{
    psBuffer->sPrivateData.ui32Flags = 0;
    USBRingBufInit(&psBuffer->sPrivateData.sRingBuf, psBuffer->pui8Buffer,
                   psBuffer->ui32BufferSize);
    return psBuffer;
}
```

### Data Flow

1. **Writing to Buffer**:
   ```cpp
   uint32_t USBBufferWrite(tUSBBuffer *psBuffer, const uint8_t *pui8Data,
                          uint32_t ui32Length)
   {
       uint32_t ui32Space = USBRingBufFree(&psPrivate->sRingBuf);
       ui32Length = (ui32Length > ui32Space) ? ui32Space : ui32Length;
       
       if(ui32Length)
       {
           USBRingBufWrite(&psPrivate->sRingBuf, pui8Data, ui32Length);
       }
       
       ScheduleNextTransmission(psBuffer);
       return ui32Length;
   }
   ```

2. **Reading from Buffer**:
   ```cpp
   uint32_t USBBufferRead(tUSBBuffer *psBuffer, uint8_t *pui8Data,
                         uint32_t ui32Length)
   {
       uint32_t ui32Avail = USBRingBufUsed(&psPrivate->sRingBuf);
       uint32_t ui32Read = (ui32Avail < ui32Length) ? ui32Avail : ui32Length;
       
       if(ui32Read)
       {
           USBRingBufRead(&psPrivate->sRingBuf, pui8Data, ui32Read);
       }
       
       return ui32Read;
   }
   ```

3. **Event Handling**:
   ```cpp
   uint32_t USBBufferEventCallback(void *pvCBData, uint32_t ui32Event,
                                  uint32_t ui32MsgValue, void *pvMsgData)
   {
       // Handle various USB events like data reception, transmission completion
       switch(ui32Event)
       {
           case USB_EVENT_RX_AVAILABLE:
               // Handle received data
               break;
           case USB_EVENT_TX_COMPLETE:
               // Handle transmission completion
               break;
           // Other event handling...
       }
   }
   ```

## USB CDC Device Configuration

The CDC device is configured with descriptors and callback functions:

### Device Descriptor

```cpp
tUSBDCDCDevice g_sCDCDevice =
{
    0x04D8,                              // VID (Microchip Technology)
    0x000A,                              // PID (USB serial port)
    0,                                   // Max power (self-powered)
    USB_CONF_ATTR_SELF_PWR,              // Self-powered
    ControlHandler,                      // Control callback
    &g_sCDCDevice,                       // Control callback data
    USBBufferEventCallback,              // RX callback
    &g_sRxBuffer,                        // RX callback data
    USBBufferEventCallback,              // TX callback
    &g_sTxBuffer,                        // TX callback data
    g_pui8StringDescriptors,             // String descriptors
    NUM_STRING_DESCRIPTORS               // Number of string descriptors
};
```

### String Descriptors

```cpp
const uint8_t * const g_pui8StringDescriptors[] =
{
    g_pui8LangDescriptor,                // Language descriptor
    g_pui8ManufacturerString,            // Manufacturer
    g_pui8ProdectString,                 // Product
    g_pui8SerialNumberString,            // Serial number
    g_pui8ControlInterfaceString,        // Control interface
    g_pui8ConfigString                   // Configuration
};
```

## Event Handling and State Management

The implementation uses a callback-based event system to handle USB events:

### Connection State Management

```cpp
case USB_EVENT_CONNECTED:
    USBBufferFlush(&g_sTxBuffer);
    USBBufferFlush(&g_sRxBuffer);
    connected = true;
    break;

case USB_EVENT_DISCONNECTED:
    connected = false;
    break;
```

### Line Coding Management

```cpp
case USBD_CDC_EVENT_GET_LINE_CODING:
    *(static_cast<tLineCoding*>(pvMsgData)) = lineCoding;
    break;

case USBD_CDC_EVENT_SET_LINE_CODING:
    lineCoding = *(static_cast<tLineCoding*>(pvMsgData));
    break;
```

### Disconnection Detection Workaround

The implementation includes a workaround for a bug in the TI USB library where disconnection events are not properly reported:

```cpp
bool USB_CDC_if::wr_available()
{
    const Uint32 wr_av = USBBufferSpaceAvailable(&g_sTxBuffer);
    if(wr_av == 0)
    {
        // This is a workaround for not been informed about connections disconnections
        // after the initial one. (TI usblib bug).
        times_tx_full++;
        if(times_tx_full >= max_times_tx_full)
        {
            USBBufferFlush(&g_sTxBuffer);
            times_tx_full = 0;
            connected = false;
        }
    }
    return wr_av > 0;
}
```

## USB Enumeration Process

The USB enumeration process is handled by the USB device controller driver:

1. **Device Initialization**:
   ```cpp
   void USBDCDInit(uint32_t ui32Index, tDeviceInfo *psDevice, void *pvDCDCBData)
   {
       // Initialize the Device Info structure
       USBDCDDeviceInfoInit(ui32Index, psDevice);
       
       // Reset and enable the USB controller
       Dsp28335_ent::USB0::reset();
       Dsp28335_ent::USB0::enable();
       Dsp28335_ent::USB0::PLLenable();
       
       // Force device mode
       USBDevMode(USB_BASE);
       
       // Initialize the USB tick module
       InternalUSBTickInit();
       
       // Enable USB Interrupts
       USBIntEnableControl(USB_BASE, USB_INTCTRL_RESET |
                          USB_INTCTRL_DISCONNECT |
                          USB_INTCTRL_RESUME |
                          USB_INTCTRL_SUSPEND |
                          USB_INTCTRL_SOF);
       USBIntEnableEndpoint(USB_BASE, USB_INTEP_ALL);
       
       // Connect the device to the USB bus
       USBDevConnect(USB_BASE);
   }
   ```

2. **Enumeration Handler**:
   ```cpp
   void USBDeviceEnumHandler(tDCDInstance *pDevInstance)
   {
       // Handle different states of the endpoint 0 state machine
       switch(pDevInstance->iEP0State)
       {
           case eUSBStateStatus:
               // Handle status state
               break;
           case eUSBStateIdle:
               // Handle idle state
               break;
           case eUSBStateTx:
               // Handle transmit state
               break;
           case eUSBStateTxConfig:
               // Handle config transmit state
               break;
           case eUSBStateRx:
               // Handle receive state
               break;
           case eUSBStateStall:
               // Handle stall state
               break;
       }
   }
   ```

3. **Standard Request Handling**:
   ```cpp
   static void USBDReadAndDispatchRequest(uint32_t ui32Index)
   {
       // Process standard USB requests
       if((psRequest->bmRequestType & USB_RTYPE_TYPE_M) != USB_RTYPE_STANDARD)
       {
           // Handle non-standard requests
       }
       else
       {
           // Handle standard requests using jump table
           g_psUSBDStdRequests[psRequest->bRequest](&g_psDCDInst[0], psRequest);
       }
   }
   ```

## Buffer Management and Data Flow

### Ring Buffer Implementation

The implementation uses a ring buffer structure to manage data:

```cpp
typedef struct
{
    uint32_t ui32Size;                   // Ring buffer size
    volatile uint32_t ui32WriteIndex;    // Write index
    volatile uint32_t ui32ReadIndex;     // Read index
    uint8_t *pui8Buf;                    // Buffer pointer
} tUSBRingBufObject;
```

### Data Transmission Flow

1. Application calls `USB_CDC_if::write()`
2. Data is written to the transmit ring buffer via `USBBufferWrite()`
3. `ScheduleNextTransmission()` is called to initiate USB transmission
4. When transmission completes, `USB_EVENT_TX_COMPLETE` event is generated
5. `HandleTxComplete()` updates the buffer read pointer and schedules next transmission

### Data Reception Flow

1. USB controller receives data and generates `USB_EVENT_RX_AVAILABLE` event
2. `HandleRxAvailable()` reads data into the receive ring buffer
3. Application calls `USB_CDC_if::read()` to retrieve data from the buffer
4. `USBBufferRead()` copies data from the ring buffer to the application buffer

## Performance Considerations

1. **Buffer Sizes**: The implementation uses 512-byte buffers for both transmit and receive operations:
   ```cpp
   #define SCI_BUFFER_SIZE 512
   ```

2. **Double Buffering**: The USB controller supports double buffering for improved throughput

3. **Polling vs. Interrupt**: The implementation requires regular polling via `USB_CDC_if::poll()` to process USB events

## Error Handling and Recovery

1. **Disconnection Detection**: The implementation includes a workaround for detecting disconnections when the USB library fails to report them

2. **Buffer Overflow Protection**: The implementation checks available buffer space before writing data

3. **Warning Mechanism**: Unexpected events trigger a warning via `Bsp::warning()`

## CDC Protocol Implementation

The implementation supports the following CDC class requests:

1. **GET_LINE_CODING**: Returns the current line coding parameters (baud rate, data bits, parity, stop bits)
2. **SET_LINE_CODING**: Sets new line coding parameters
3. **SET_CONTROL_LINE_STATE**: Sets the state of the RTS and DTR control lines
4. **SEND_BREAK**: Sends a break condition on the serial line

The implementation does not support some optional CDC requests:
- SEND_ENCAPSULATED_COMMAND
- GET_ENCAPSULATED_RESPONSE
- SET_COMM_FEATURE
- GET_COMM_FEATURE
- CLEAR_COMM_FEATURE

## Endpoint Configuration

The implementation uses the following endpoints:
- **Endpoint 0**: Control endpoint for USB setup and control transfers
- **Endpoint 1**: Bulk OUT endpoint for receiving data from host and interrupt IN endpoint for notifications
- **Endpoint 2**: Bulk IN endpoint for sending data to host

## Conclusion

The USB CDC interface implementation for F2837xD microcontrollers provides a robust virtual COM port functionality. It uses a layered architecture with buffer management to handle data flow between the application and USB host. The implementation includes workarounds for known issues in the TI USB library and provides a simple API for applications to use.

Key features include:
- Singleton pattern for interface access
- Ring buffer-based data management
- Event-driven architecture
- Workarounds for library limitations
- Comprehensive error handling

This implementation allows F2837xD microcontrollers to communicate with host computers via a standard virtual COM port interface, enabling serial communication for debugging, data transfer, and control applications.