# Generated from:

- code/include/28335/GPIOid.h (1161 tokens)
- code/include/2837x/GPIOid.h (1684 tokens)
- code/include/Interrupts.h (99 tokens)

## With context from:

- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/bsp/07_Core_Type_System.md (3325 tokens)

---

# BSP Library Hardware Abstraction Components: GPIO and Interrupt Management

## 1. GPIO Identifier Enumerations

The BSP library provides platform-specific GPIO pin identifiers through the `GPIOid` enumeration, which is defined differently for each supported hardware platform. These enumerations serve as the foundation for hardware abstraction by providing consistent naming conventions while accommodating platform-specific pin assignments.

### 1.1 TMS320F28335 GPIO Identifiers (`28335/GPIOid.h`)

The TMS320F28335 platform defines GPIO pins from `gpio_000` through `gpio_087`, with a total of 88 available pins (`gpio_all = 88`). The enumeration is defined within the `Dsp28335_ent` namespace:

```cpp
namespace Dsp28335_ent
{
    enum GPIOid
    {
        gpio_000 =   0,     // GPIO1 Arbiter
        gpio_001 =   1,     // GPIO7 Arbiter / ECAP6
        gpio_002 =   2,     // GPIO2 Arbiter
        // ...
        gpio_087 =  87      // Reserved for EMIF1_A15
    };
    static const Uint16 gpio_all = 88;
}
```

#### 1.1.1 Key Characteristics of TMS320F28335 GPIO Configuration

- **Pin Count**: 88 total GPIO pins (0-87)
- **Reserved Pins**: Many pins are reserved for EMIF (External Memory Interface) functionality
- **Multi-function Pins**: Many pins serve dual purposes, indicated by comments (e.g., `gpio_001` can function as "GPIO7 Arbiter" or "ECAP6")
- **Special Function Groups**:
  - **Arbiter pins**: gpio_000 through gpio_011 are primarily designated as arbiter pins
  - **Communication interfaces**: Dedicated pins for CAN, SCI, SPI, and I2C interfaces
  - **Watchdog pins**: gpio_024 through gpio_027 are designated for watchdog functionality
  - **LED indicators**: gpio_053 (LED green) and gpio_059 (LED red)
  - **ARINC interface**: Multiple pins dedicated to ARINC communication

### 1.2 TMS320F2837x GPIO Identifiers (`2837x/GPIOid.h`)

The TMS320F2837x platform defines a much larger set of GPIO pins, from `gpio_000` through `gpio_168`, with a total of 169 available pins (`gpio_all = 169`). This enumeration is also defined within the `Dsp28335_ent` namespace:

```cpp
namespace Dsp28335_ent
{
    enum GPIOid
    {
        gpio_000 =   0,
        gpio_001 =   1,
        gpio_002 =   2,
        // ...
        gpio_168 = 168,
        gpio_all = 169
    };
}
```

#### 1.2.1 Key Characteristics of TMS320F2837x GPIO Configuration

- **Pin Count**: 169 total GPIO pins (0-168)
- **Reserved Pins**: Similar to the F28335, many pins are reserved for EMIF functionality
- **Board-Specific Annotations**: Comments indicate pin functions specific to different board versions (e.g., "V4.5", "V4.7")
- **Special Function Groups**:
  - **Communication interfaces**: Dedicated pins for CAN, SPI, USB, and other protocols
  - **LED indicators**: Multiple LED pins (gpio_116, gpio_128, gpio_129, gpio_137-139)
  - **Sensor interfaces**: Pins for IMU, BMI088 accelerometer and gyroscope
  - **Time pulse inputs**: gpio_155 and gpio_156 for time pulses from Ublox devices
  - **Expansion connectors**: Pins designated for external connections (e.g., gpio_100-103)

## 2. Functional Grouping of GPIO Pins

Both GPIO identifier enumerations organize pins into functional groups, though the specific groupings differ between platforms due to hardware differences. The comments in the source code reveal these functional groupings:

### 2.1 Common Functional Groups Across Platforms

1. **Communication Interfaces**
   - **CAN Bus**: Both platforms have dedicated CAN TX/RX pins
   - **SPI**: Both platforms have pins for SPI communication (MOSI, MISO, SCK, CS)
   - **Serial Communication (SCI)**: Both platforms have TX/RX pins for serial interfaces

2. **Status Indicators**
   - **LED Pins**: Both platforms designate pins for LED indicators

3. **External Memory Interface (EMIF)**
   - Both platforms reserve numerous pins for EMIF functionality, though they're implemented differently

### 2.2 Platform-Specific Functional Groups

#### 2.2.1 TMS320F28335 Specific Groups

1. **Arbiter System**
   - Multiple pins designated as "Arbiter" pins (gpio_000 through gpio_011)
   - Additional arbiter-related pins like M1/M2 arbiter (gpio_051, gpio_052)

2. **ARINC Interface**
   - Dedicated pins for ARINC communication (ARX1-4, SI, SO, SCK, CS, MR)

3. **Watchdog System**
   - Dedicated watchdog pins (gpio_024 through gpio_027)

4. **Enhanced Capture (ECAP)**
   - Multiple pins designated for ECAP functionality

#### 2.2.2 TMS320F2837x Specific Groups

1. **USB Interface**
   - Pins for USB communication (D+, D-, ID, PFLT, EPEN)

2. **Sensor Interfaces**
   - IMU and accelerometer/gyroscope interface pins
   - Time pulse inputs from GPS devices

3. **Cellular Modem Control**
   - Pins for controlling SARA cellular modem (PWR_ON, 3G_ON, RESET_M2M)

4. **RSSI Indicators**
   - Multiple LED pins specifically for RSSI indication (gpio_137-139)

5. **Multiplexer Control**
   - Pins for controlling multiplexers (4xV_MUX-A, 4xV_MUX-B)

## 3. Interrupt Management Functions

The BSP library provides a platform-independent interface for interrupt management through the `Interrupts.h` header file. This header defines functions for controlling global interrupts within the `Bsp::Interrupts` namespace:

```cpp
namespace Bsp
{
    namespace Interrupts
    {
        /// Disable global interrupts.
        /// \return status.
        extern Uint16 global_disable();

        /// Restore global interrupts.
        /// \param cpu_sr status to restore given by global disable.
        extern void global_restore(Uint16 cpu_sr);
    }
}
```

### 3.1 Interrupt Control Functions

1. **`global_disable()`**
   - Disables all interrupts at the global level
   - Returns the current interrupt status as a `Uint16` value
   - This status value should be stored if the interrupts need to be restored later

2. **`global_restore(Uint16 cpu_sr)`**
   - Restores the global interrupt state to what it was before `global_disable()` was called
   - Takes the status value returned by `global_disable()` as its parameter

### 3.2 Typical Usage Pattern

The interrupt management functions are typically used in a paired pattern to create critical sections of code that must not be interrupted:

```cpp
// Create a critical section
Uint16 interrupt_status = Bsp::Interrupts::global_disable();
// Perform operations that must not be interrupted
// ...
// Restore previous interrupt state
Bsp::Interrupts::global_restore(interrupt_status);
```

This pattern ensures that interrupts are properly restored to their previous state after the critical section, rather than simply being enabled or disabled without regard to their previous state.

## 4. Cross-Platform Hardware Abstraction

The BSP library provides a consistent hardware abstraction layer across different platforms through several key mechanisms:

### 4.1 Consistent Naming Conventions

Despite the significant differences between the TMS320F28335 and TMS320F2837x platforms, the BSP library maintains consistent naming conventions:

1. **Common Namespace**: Both GPIO enumerations are defined within the `Dsp28335_ent` namespace
2. **Consistent Pin Naming**: Both platforms use the `gpio_XXX` naming pattern where XXX is the pin number
3. **Common Constants**: Both define `gpio_all` to indicate the total number of available pins

### 4.2 Platform-Specific Implementation with Common Interface

The library uses platform-specific header files with identical interfaces to accommodate hardware differences:

1. **Conditional Inclusion**: The appropriate header file is included based on the target platform
2. **Identical Enumeration Names**: Both platforms define a `GPIOid` enumeration with the same name
3. **Consistent Pin Numbering**: Pin numbers match their enumeration values for straightforward mapping

### 4.3 Abstracted Interrupt Management

The interrupt management functions provide a platform-independent interface for controlling interrupts:

1. **Namespace Encapsulation**: Functions are encapsulated within the `Bsp::Interrupts` namespace
2. **Consistent Function Signatures**: The same function signatures are used across platforms
3. **Implementation Hiding**: The implementation details are hidden behind the common interface

## 5. Platform Differences and Accommodations

### 5.1 Pin Count and Availability

The most obvious difference between the platforms is the number of available GPIO pins:

- **TMS320F28335**: 88 pins (gpio_000 through gpio_087)
- **TMS320F2837x**: 169 pins (gpio_000 through gpio_168)

The BSP library accommodates this difference by defining platform-specific `gpio_all` constants and ensuring that code using GPIO pins checks against this constant.

### 5.2 Pin Functionality and Multiplexing

Both platforms implement pin multiplexing, but with different capabilities and configurations:

- **TMS320F28335**: Many pins have dual functions, particularly for communication interfaces and EMIF
- **TMS320F2837x**: More extensive multiplexing with support for newer peripherals like USB and additional sensor interfaces

The library accommodates these differences through detailed comments in the GPIO enumerations, documenting the available functions for each pin.

### 5.3 Reserved Pins and Memory Interfaces

Both platforms reserve numerous pins for the External Memory Interface (EMIF), but with different pin assignments:

- **TMS320F28335**: Reserves pins like gpio_029 through gpio_047 and gpio_064 through gpio_087 for EMIF
- **TMS320F2837x**: Reserves pins like gpio_030, gpio_031, gpio_034, gpio_037 through gpio_044, and others for EMIF

The library clearly marks these reserved pins in the comments to prevent their misuse in application code.

### 5.4 Hardware-Specific Features

The TMS320F2837x platform includes support for newer hardware features not present in the TMS320F28335:

- **USB Interface**: The F2837x includes pins for USB communication
- **Advanced Sensor Interfaces**: The F2837x has dedicated pins for IMU and other sensors
- **Cellular Modem Control**: The F2837x includes pins for controlling cellular modems

The library accommodates these differences by providing platform-specific pin definitions while maintaining a consistent naming convention.

## 6. Integration with the BSP Type System

The GPIO and interrupt management components integrate with the BSP library's type system (as seen in the context file) in several ways:

### 6.1 Use of Cross-Platform Types

Both components use the cross-platform types defined in the BSP type system:

- **`Uint16`**: Used for the interrupt status return value and parameter
- The GPIO enumerations are implicitly based on the platform's integer types

### 6.2 Namespace Organization

The components follow the BSP library's namespace organization pattern:

- **`Dsp28335_ent`**: Contains platform-specific definitions like the GPIO enumerations
- **`Bsp::Interrupts`**: Contains platform-independent functionality like interrupt management

### 6.3 Conditional Compilation

Like the type system, the GPIO definitions use conditional compilation to select the appropriate implementation for the target platform.

## 7. Conclusion

The BSP library's hardware abstraction components provide a comprehensive and consistent interface for interacting with GPIO pins and managing interrupts across different hardware platforms. Key aspects of this abstraction include:

1. **Platform-Specific GPIO Enumerations**: Detailed pin definitions for both TMS320F28335 and TMS320F2837x platforms
2. **Functional Pin Grouping**: Organization of pins into functional groups for different peripherals and interfaces
3. **Consistent Interrupt Management**: Platform-independent functions for controlling global interrupts
4. **Cross-Platform Compatibility**: Consistent naming conventions and interfaces across platforms
5. **Detailed Documentation**: Comprehensive comments documenting pin functions and restrictions

This hardware abstraction layer enables application code to interact with platform-specific hardware features through a consistent interface, reducing the need for platform-specific code and improving portability across different TI DSP platforms.

## Referenced Context Files

The following context file was helpful in understanding the BSP library's type system:

- `Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/bsp/07_Core_Type_System.md`
  - Provided information about the cross-platform type system used by the BSP library
  - Explained the platform detection mechanism and conditional inclusion of platform-specific headers
  - Detailed the type definitions and utility functions that support the hardware abstraction components