# Generated from:

- code/include/Uid64.h (292 tokens)
- code/include/Sysuid.h (243 tokens)
- code/include/Sysapp.h (560 tokens)
- code/include/Sysaddr.h (556 tokens)
- code/include/IP_cfg.h (205 tokens)

## With context from:

- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/bsp/07_Core_Type_System.md (3325 tokens)

---

# BSP System Identification Components: Comprehensive Summary

## 1. Uid64 Union Structure and Fields

The BSP library provides a union structure called `Uid64` that serves as the foundation for system identification. This structure is defined in `Uid64.h` and combines a 64-bit word with a structured representation of a unique identifier.

### 1.1 Uid64 Structure Definition

```cpp
union Uid64
{
    Uint64 all;          ///< Unique identifier (64-bit word)
    struct
    {
        Uint64 app : 8;     ///< [0] Application identifier.
        Uint64 hwv : 8;     ///< [1] Hardware version.
        Uint64 var : 8;     ///< [2] Product variant.
        Uint64 res : 8;     ///< [3] Reserved.
        Uint64 phy : 32;    ///< [4:7] Physical address.
    };
    
    // Static method to create a zero-initialized Uid64
    inline static Uid64 build_zero();
};
```

### 1.2 Uid64 Fields

The `Uid64` union contains the following fields:

1. **all** (Uint64): Represents the entire 64-bit unique identifier as a single value
2. **app** (8 bits): Application identifier, indicating the type of application running on the system
3. **hwv** (8 bits): Hardware version information
4. **var** (8 bits): Product variant identifier
5. **res** (8 bits): Reserved field for future use
6. **phy** (32 bits): Physical address, occupying the upper 32 bits of the identifier

### 1.3 Uid64 Methods

The `Uid64` union provides a static method:

- **build_zero()**: Creates and returns a `Uid64` instance with all bits set to zero
  - Implementation creates a constant `Uid64` instance initialized with `0ULL`
  - Returns this zero-initialized instance

## 2. System Unique Identifier Access Functions

The BSP library provides functions to access the system's unique identifier, defined in `Sysuid.h`.

### 2.1 Unique Identifier Location Access

```cpp
/// System unique identifier constant reference.
/// \wi{13641}
/// System shall provide the capability to retrieve its unique identifier location.
/// \rationale On multi-core platforms, shall only be implemented on the core that have read-only access.
/// \return Constant reference to Unique system identifier
extern volatile const Uid64& get_uid_location();
```

This function returns a constant reference to the system's unique identifier location. On multi-core platforms, this function is only implemented on cores that have read-only access to the identifier.

### 2.2 Unique Identifier Value Access

```cpp
/// System unique identifier.
/// \wi{13640}
/// System shall provide the capability to retrieve its internal unique identifier as UID64 (defined onto \wi{13623}).
/// \rationale System unique identifier shall be stored at internal on-chip OTP memory on TMS320F2837x and TMS32F28335 platforms.
/// \param[in] force_read Force reading the uid.
/// \return Copied value from internal unique system identifier.
extern Uid64 get_uid(bool force_read = false);
```

This function retrieves the system's internal unique identifier as a `Uid64` value. It:
- Returns a copy of the internal unique system identifier
- Has an optional `force_read` parameter to force reading the UID from storage
- On TMS320F2837x and TMS32F28335 platforms, the unique identifier is stored in internal on-chip OTP (One-Time Programmable) memory

## 3. System Application Identifiers

The BSP library defines a comprehensive set of system application identifiers in `Sysapp.h` through the `Sysapp` enumeration.

### 3.1 Sysapp Enumeration

```cpp
enum Sysapp
{
    sapp_none          =  0,  ///< (0) Undefined
    sapp_vbootloader   =  1,  ///< (1) Veronte Bootloader
    sapp_reserved      =  2,  ///< (2) Reserved
    sapp_uapp          =  3,  ///< (3) U-veronte application
    sapp_386_ccard     =  4,  ///< (4) 28388 Control card test.

    sapp_arb4xapp      =  6,  ///< (6) Arbiter app
    sapp_cex_lift_pwm  =  7,  ///< (7) CEX Lift PWM control board
    sapp_cex_jeti_tm   =  8,  ///< (8) CEX JETI telemetry board
    sapp_cex_v1_2      =  9,  ///< (9) CEX V1.2 board
    sapp_vmc_brushless = 10,  ///< (10) Veronte brushless controller
    sapp_vmc_stepper   = 11,  ///< (11) Veronte stepper controller
    sapp_cex_commex    = 12,  ///< (12) CEX commex board
    sapp_mc110         = 13,  ///< (13) MC110 brushless controller
    sapp_mc280         = 14,  ///< (14) MC280 brushless controller
    sapp_can_iso       = 15,  ///< (15) CAN Isolator
    sapp_cex2a         = 16,  ///< (16) CEX V2.0 board with Arincs
    sapp_cex2g         = 17,  ///< (17) CEX V2.0 board with GPIOs
    sapp_mc24          = 18,  ///< (18) MC24 brushless controller
    sapp_vsm           = 19,  ///< (19) Vehicle Specific Module
    sapp_mex           = 20,  ///< (20) MEX board
    sapp_mc_ipc        = 21,  ///< (21) MC IPC brushless controller
    sapp_reserved2     = 22,  ///< (22) Reserved
    sapp_mc110_v2      = 23,  ///< (23) MC110 v2 motor controller
    sapp_bms           = 24,  ///< (24) Battery Management System
    sapp_par_nav       = 25,  ///< (25) Prime Air Recovery (sensors and nav)
    sapp_pam           = 26,  ///< (26) Prime Air Monitor
    sapp_par_ctrl      = 27,  ///< (27) Prime Air Recovery (controllers)

    sapp_invalid       = 0xFE
};
```

This enumeration defines all possible application types that can be identified in the `app` field of the `Uid64` structure.

### 3.2 Application Type Utilities

The `Sysapp.h` file also provides utility functions for working with application identifiers:

```cpp
static bool is_astro(Sysapp app)
{
    return (app >= sapp_par_nav) && (app <= sapp_par_ctrl);
}

static const Uint16 sysapp_all = sapp_par_ctrl + 1U;    ///< Available Application types.
```

- **is_astro()**: Determines if an application is part of the Prime Air Recovery (PAR) family
- **sysapp_all**: Constant representing the total number of available application types

## 4. System Address Management Functions

The BSP library provides functions for managing system addresses in `Sysaddr.h`.

### 4.1 Dynamic System Address Access

```cpp
/// Dynamic system address reference.
/// \wi{13638}
/// System shall provide a method to retrieve a reference to its dynamic system address.
/// \rationale Only for multi-core platforms. Shall be implemented but only for the core which has write access to it.
/// \return Reference to the dynamic system address.
extern volatile Base::Address0& get_addr_location();
```

This function returns a reference to the system's dynamic address, allowing modification. On multi-core platforms, it's only implemented on cores with write access to the address.

### 4.2 Dynamic System Address Constant Access

```cpp
/// Dynamic system address constant reference.
/// \wi{13639}
/// System shall provide a method to retrieve a constant reference to its dynamic system address.
/// \rationale Only for multi-core platforms. Shall be implemented on all core as read-only.
/// \return Constant reference to dynamic system address.
extern volatile const Base::Address0& get_addr_location_k();

/// Dynamic system address value.
/// \wi{7689}
/// System shall provide the capability to retrieve its system address.
/// \return Dynamic internal address.
extern volatile const Base::Address0& sysaddr();
```

These functions provide read-only access to the system's dynamic address:
- **get_addr_location_k()**: Returns a constant reference to the dynamic system address
- **sysaddr()**: Returns a constant reference to the dynamic internal address

### 4.3 System Address Modification

```cpp
/// Modify dynamic system address.
/// \wi{8015}
/// System shall provide the capability to modify its system address.
/// \rationale Shall always be explicitly called to fix dynamic address for the first time.
/// \param[in] addr0        System address value to be copied.
extern void set_sysaddr(Base::Address addr0);
```

This function allows modification of the system's dynamic address. It must be explicitly called to set the dynamic address for the first time.

### 4.4 VSM Address Management

```cpp
/// Dynamic VSM Address Reference.
/// \wi{16165}
/// A function to retrieve a modifiable VSM address should be implemented in C1.
/// \return A modifiable reference to the VSM address.
extern volatile Base::Address0& get_vsmaddr();

/// Constant VSM Address Reference.
/// \wi{16166}
/// A function to retrieve a constant VSM address should be implemented in both cores.
/// \return A constant reference to the VSM address.
extern const volatile Base::Address0& get_kvsmaddr();

/// Constant VSM Address Reference.
/// \wi{16167}
/// A function to retreive a constant VSM address should be implemented in both cores.
/// \return A constant reference to the VSM address.
extern volatile const Base::Address0& vsmaddr();
```

These functions manage Vehicle Specific Module (VSM) addresses:
- **get_vsmaddr()**: Returns a modifiable reference to the VSM address (implemented in C1)
- **get_kvsmaddr()**: Returns a constant reference to the VSM address (implemented in both cores)
- **vsmaddr()**: Returns a constant reference to the VSM address (implemented in both cores)

## 5. Network IP Configuration Functions

The BSP library provides functions for network IP configuration in `IP_cfg.h`.

### 5.1 Standard IP Configuration

```cpp
/// Retrieve Network IP and Mask.
/// \wi{23898}
/// System shall provide a method to retrieve a system network IP and mask.
/// \param[in]  uid      System unique identifer.
/// \param[out] ip4      Holder for network IP.
/// \param[out] ip4_mask Holder for network mask.
void get_ip_cfg(Uid64 uid, Uint32& ip4, Uint32& ip4_mask);
```

This function retrieves the network IP and mask for a system based on its unique identifier:
- Takes a `Uid64` parameter containing the system's unique identifier
- Outputs the network IP address and mask through reference parameters

### 5.2 Prime Air IP Configuration

```cpp
/// Retrieve Network IP and Mask for PA products.
/// \wi{25361}
/// System shall provide a method to retrieve a system network IP and mask.
/// \param[in]  uid      System unique identifier.
/// \param[out] ip4      Holder for network IP.
/// \param[out] ip4_mask Holder for network mask.
void get_ip_cfg_pa(Uid64 uid, Uint32& ip4, Uint32& ip4_mask);
```

This function is specifically designed for Prime Air (PA) products:
- Takes a `Uid64` parameter containing the system's unique identifier
- Outputs the network IP address and mask through reference parameters
- Implements PA-specific IP configuration logic

## 6. System Identification Framework Integration

The BSP system identification components work together to provide a comprehensive framework for identifying and configuring systems.

### 6.1 Relationship Between Unique Identifiers and Application Types

1. The `Uid64` union structure contains an `app` field that stores an 8-bit application identifier
2. This identifier corresponds to one of the values defined in the `Sysapp` enumeration
3. The application type determines the system's functionality and behavior
4. The `is_astro()` function can be used to identify Prime Air Recovery applications

### 6.2 Relationship Between Unique Identifiers and System Addresses

1. Each system has a unique identifier (`Uid64`) that includes a 32-bit physical address in the `phy` field
2. The system also has a dynamic address (`Base::Address0`) that can be accessed and modified
3. The `set_sysaddr()` function allows setting the dynamic address based on system requirements
4. The `sysaddr()` function provides read-only access to the current dynamic address

### 6.3 Relationship Between Unique Identifiers and Network Configuration

1. The `get_ip_cfg()` and `get_ip_cfg_pa()` functions use the system's unique identifier to determine appropriate network configuration
2. These functions extract information from the `Uid64` structure to generate IP addresses and subnet masks
3. Prime Air products have specialized IP configuration logic implemented in `get_ip_cfg_pa()`

### 6.4 Multi-Core Considerations

The system identification framework includes specific provisions for multi-core platforms:

1. `get_uid_location()` is only implemented on cores with read-only access to the unique identifier
2. `get_addr_location()` is only implemented on cores with write access to the dynamic address
3. `get_addr_location_k()` is implemented on all cores as read-only
4. VSM address functions have specific core implementation requirements:
   - `get_vsmaddr()` is implemented in C1 only
   - `get_kvsmaddr()` and `vsmaddr()` are implemented in both cores

### 6.5 Complete System Identification Flow

The typical flow for system identification and configuration:

1. Retrieve the system's unique identifier using `get_uid()`
2. Extract the application type from the `app` field of the `Uid64`
3. Configure the system's dynamic address using `set_sysaddr()`
4. Determine network configuration using `get_ip_cfg()` or `get_ip_cfg_pa()` based on the application type
5. Access VSM addresses as needed using the appropriate VSM address functions

This integrated approach ensures that each system has a unique identity, appropriate addressing, and correct network configuration based on its hardware and application type.

## Referenced Context Files

The following context file was helpful in understanding the BSP library's type system:

- `Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/bsp/07_Core_Type_System.md`: Provided information about the BSP library's core type system, including the definition of basic types like `Uint32` and `Uint64` that are used in the system identification components.