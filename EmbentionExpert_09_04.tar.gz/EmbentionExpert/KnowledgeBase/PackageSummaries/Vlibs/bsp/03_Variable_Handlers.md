# Generated from:

- code/include/Hu64var.h (181 tokens)
- code/include/Hbvar.h (1211 tokens)
- code/include/Huvar.h (1218 tokens)
- code/include/Hrvar.h (1319 tokens)
- code/include/Hfvar.h (622 tokens)

## With context from:

- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/bsp/07_Core_Type_System.md (3325 tokens)

---

# BSP Library Variable Handler Components: Comprehensive Summary

## 1. Common Patterns Across Handler Classes

The BSP library implements a consistent pattern across all variable handler classes (Hu64var, Hbvar, Huvar, Hrvar, Hfvar) with the following shared characteristics:

### 1.1 Core Design Pattern

All handler classes follow a consistent design pattern:

- **Constructor with ID Parameter**: Each handler is constructed with a specific variable identifier (id) that determines which variable it will access
- **Private ID Member**: Each handler stores the variable identifier as a private member, typically as a const value
- **Disabled Copy Operations**: All handlers disable copy construction and assignment operations
- **Get/Set Interface**: Each handler provides methods to retrieve and update variable values

```cpp
// Common pattern across all handlers
class HXvar {
public:
    explicit HXvar(Base::Xvar id0);  // Constructor with ID parameter
    X get() const;                   // Value retriever
    void set(X v0);                  // Value updater
    
private:
    const Base::Xvar id;             // Variable identifier
    
    HXvar();                         // = delete
    HXvar(const HXvar& orig);        // = delete
    HXvar& operator=(const HXvar&);  // = delete
};
```

### 1.2 Reference Access Methods

Most handlers provide multiple reference access methods:

- **get_ref()**: Returns a volatile reference for write access
- **get_kref()**: Returns a const volatile reference for read-only access

### 1.3 Memory Block Operations

Handlers for array-type variables (Hbvar, Huvar, Hrvar) provide static methods for bulk operations:

- **get_block()**: Returns a volatile memory block for write access
- **get_kblock()**: Returns a const volatile memory block for read-only access

### 1.4 Range Classes

Handlers for array-type variables include nested Range classes that:

- Are constructed with a memory block and range boundaries
- Provide a commit() method to copy data to its final memory allocation
- Use Base::Tcopy with appropriate traits for type-specific memory operations

```cpp
// Common Range class pattern
class Range {
public:
    Range(Base::Mblock<const volatile X> mb, Base::Xvar from, Base::Xvar to_inclusive);
    void commit();
    
private:
    typedef Base::Tcopy<...> Type_cp;
    Type_cp cp;
    
    Range();                             // = delete
    Range& operator=(const Range& orig); // = delete
};
```

## 2. Specific Functionality of Each Handler Type

### 2.1 Hu64var - Unsigned 64-bit Integer Handler

```cpp
class Hu64var {
public:
    static const Uint16 max_id = 10;    // Maximum number of Uint64 variables
    
    explicit Hu64var(Uint16 id0);       // Constructor with ID parameter
    Uint64& get();                      // Reference retriever
    
private:
    Uint16 id;                          // Uint64 identifier
    
    // Copy operations disabled
    Hu64var(const Hu64var& orig);
    Hu64var& operator=(const Hu64var& orig);
};
```

- Simplest handler with only basic functionality
- Limited to a maximum of 10 variables (max_id = 10)
- Returns a direct reference to the Uint64 value
- Does not implement Range class or block operations

### 2.2 Hbvar - Boolean Variable Handler

```cpp
class Hbvar {
public:
    // Range class for bulk operations
    class Range {
    public:
        Range(Base::Mblock<const volatile bool> mb, Base::Bvar from, Base::Bvar to_inclusive);
        void commit();
        
    private:
        typedef Base::Tcopy<Base::Cptraits::Array_memcpybool<...>> Type_cp;
        Type_cp cp;
    };
    
    explicit Hbvar(Base::Bvar id0);
    void set(bool v0);
    bool get() const;
    const volatile bool& get_kref() const;
    volatile bool& get_ref() const;
    
    // Static methods for memory block operations
    static Base::Mblock<const volatile bool> get_kblock(Base::Bvar from, Base::Bvar to_inclusive);
    static Base::Mblock<volatile bool> get_block(Base::Bvar from, Base::Bvar to_inclusive);
    
private:
    const Base::Bvar id;
};
```

- Handles boolean variables using Base::Bvar identifiers
- Provides both value-based and reference-based access
- Implements Range class for bulk operations using Array_memcpybool trait
- Supports memory block operations for ranges of boolean variables

### 2.3 Huvar - Unsigned Integer Variable Handler

```cpp
class Huvar {
public:
    // Range class for bulk operations
    class Range {
    public:
        Range(Base::Mblock<const volatile Uint16> mb, Base::Uvar from, Base::Uvar to_inclusive);
        void commit();
        
    private:
        typedef Base::Tcopy<Base::Cptraits::Array_memcpy16<...>> Type_cp;
        Type_cp cp;
    };
    
    explicit Huvar(Base::Uvar id0);
    void set(Uint16 v0);
    Uint16 get() const;
    const volatile Uint16& get_kref() const;
    volatile Uint16& get_ref() const;
    
    // Static methods for memory block operations
    static Base::Mblock<const volatile Uint16> get_kblock(Base::Uvar from, Base::Uvar to_inclusive);
    static Base::Mblock<volatile Uint16> get_block(Base::Uvar from, Base::Uvar to_inclusive);
    
private:
    const Base::Uvar id;
};
```

- Handles 16-bit unsigned integer variables using Base::Uvar identifiers
- Provides both value-based and reference-based access
- Implements Range class for bulk operations using Array_memcpy16 trait
- Supports memory block operations for ranges of unsigned integer variables

### 2.4 Hrvar - Real (Floating Point) Variable Handler

```cpp
class Hrvar {
public:
    // Range class for bulk operations with additional functionality
    class Range {
    public:
        Range(Base::Mblock<const volatile Real> mb, Base::Rvar from, Base::Rvar to_inclusive);
        void commit();
        Real varget(Uint16 idx) const;  // Additional method to retrieve non-committed values
        
    private:
        typedef Base::Tcopy<Base::Cptraits::Array_memcpy32<...>> Type_cp;
        Type_cp cp;
    };
    
    explicit Hrvar(Base::Rvar id0);
    void set(Real v0);
    Real get() const;
    const volatile Real& get_kref() const;
    volatile Real& get_ref() const;
    
    // Static methods for memory block operations
    static Base::Mblock<const volatile Real> get_kblock(Base::Rvar from, Base::Rvar to_inclusive);
    static Base::Mblock<volatile Real> get_block(Base::Rvar from, Base::Rvar to_inclusive);
    
private:
    const Base::Rvar id;
};
```

- Handles Real (floating point) variables using Base::Rvar identifiers
- Provides both value-based and reference-based access
- Implements Range class for bulk operations using Array_memcpy32 trait
- Range class includes additional varget() method to retrieve non-committed values
- Supports memory block operations for ranges of Real variables

### 2.5 Hfvar - Feature Variable Handler

```cpp
class Hfvar {
public:
    explicit Hfvar(Base::Fid id0);
    void set(const Base::Feature& v0);
    void set(const volatile Base::Feature& v0);
    Base::Dsync::Reader get(Base::Feature& f0) const;
    Base::Fid get_id() const;
    
private:
    const Base::Fid id;
};
```

- Handles system features (absolute or relative positions) using Base::Fid identifiers
- Provides methods to set values from both const and const volatile references
- Get method returns a synchronization value (Base::Dsync::Reader) to detect updates
- Does not implement Range class or block operations
- Includes a get_id() method to retrieve the feature identifier

## 3. Range Classes and Bulk Operations

### 3.1 Range Class Structure

Range classes provide a mechanism for bulk operations on arrays of variables:

```cpp
class Range {
public:
    // Constructor with memory block and range boundaries
    Range(Base::Mblock<const volatile T> mb, Base::Tvar from, Base::Tvar to_inclusive);
    
    // Copy data to final memory allocation
    void commit();
    
    // Optional: Retrieve non-committed value (only in Hrvar)
    T varget(Uint16 idx) const;  // Only in Hrvar::Range
    
private:
    // Type-specific copy trait
    typedef Base::Tcopy<Base::Cptraits::Array_memcpyX<...>> Type_cp;
    Type_cp cp;
};
```

### 3.2 Type-Specific Copy Traits

Each Range class uses a different copy trait based on the variable type:

- **Hbvar::Range**: Uses `Base::Cptraits::Array_memcpybool` for boolean arrays
- **Huvar::Range**: Uses `Base::Cptraits::Array_memcpy16` for 16-bit unsigned integer arrays
- **Hrvar::Range**: Uses `Base::Cptraits::Array_memcpy32` for 32-bit floating point arrays

### 3.3 Commit Operation

All Range classes implement a commit() method that copies data from a source memory block to a destination memory block:

```cpp
inline void HXvar::Range::commit()
{
    // Call to Tcopy::copy for ::cp, which bulks data from source memory block to destination memory block
    cp.copy();
}
```

### 3.4 Additional Range Functionality

Hrvar::Range provides an additional varget() method to retrieve non-committed values:

```cpp
inline Real Hrvar::Range::varget(Uint16 idx) const
{
    // Read given index from source memory block (non-committed)
    return cp.get_to()[idx];
}
```

## 4. Memory Block Access Methods

### 4.1 Block Retrieval Methods

Handlers for array-type variables (Hbvar, Huvar, Hrvar) provide static methods for accessing ranges of variables as memory blocks:

```cpp
// Read-only access (const volatile)
static Base::Mblock<const volatile T> get_kblock(Base::Tvar from, Base::Tvar to_inclusive);

// Read-write access (volatile)
static Base::Mblock<volatile T> get_block(Base::Tvar from, Base::Tvar to_inclusive);
```

### 4.2 Implementation Requirements

- **get_kblock()**: Implemented in all cores with read access to the given memory block
- **get_block()**: Implemented in all cores with write access to the given memory block

### 4.3 Memory Block Usage

Memory blocks are used for:

1. Efficient bulk operations on ranges of variables
2. Creating Range objects for deferred commit operations
3. Direct access to memory regions containing variables

## 5. Variable Handler Interface Consistency

### 5.1 Common Interface Elements

All handler classes provide a consistent interface with these common elements:

- **Construction**: `explicit HXvar(Base::Xvar id0)`
- **Value Access**: `X get() const` and `void set(X v0)`
- **Disabled Copy Operations**: Copy constructor and assignment operator are disabled

### 5.2 Reference Access Pattern

Most handlers provide reference access methods with consistent naming:

- **Read-only Reference**: `const volatile X& get_kref() const`
- **Read-write Reference**: `volatile X& get_ref() const`

### 5.3 Block Access Pattern

Handlers for array-type variables provide consistent block access methods:

- **Read-only Block**: `static Base::Mblock<const volatile X> get_kblock(Base::Xvar from, Base::Xvar to_inclusive)`
- **Read-write Block**: `static Base::Mblock<volatile X> get_block(Base::Xvar from, Base::Xvar to_inclusive)`

### 5.4 Type-Specific Adaptations

While maintaining interface consistency, each handler includes type-specific adaptations:

- **Hu64var**: Simplest implementation with only basic functionality
- **Hbvar, Huvar, Hrvar**: Full implementation with Range classes and block operations
- **Hrvar::Range**: Additional varget() method for non-committed value access
- **Hfvar**: Specialized for system features with synchronization support

## 6. Relationship Between Variable Handlers and Identifiers

### 6.1 Identifier Types

Each handler class is associated with a specific identifier type:

- **Hu64var**: Uses `Uint16` as identifier type
- **Hbvar**: Uses `Base::Bvar` as identifier type
- **Huvar**: Uses `Base::Uvar` as identifier type
- **Hrvar**: Uses `Base::Rvar` as identifier type
- **Hfvar**: Uses `Base::Fid` as identifier type

### 6.2 Identifier Validation

Some handlers perform validation on the provided identifier:

```cpp
// Example from Hfvar
inline Hfvar::Hfvar(Base::Fid id0) : id(Base::Jfid::validate(id0))
{
}
```

### 6.3 Identifier Storage

All handlers store the identifier as a private member, typically as const:

```cpp
private:
    const Base::Xvar id;  // Variable identifier
```

### 6.4 Identifier Retrieval

Some handlers provide methods to retrieve the stored identifier:

```cpp
// Example from Hfvar
inline Base::Fid Hfvar::get_id() const
{
    return id;
}
```

## 7. Individual and Bulk Operations Support

### 7.1 Individual Operations

All handlers support individual variable operations:

- **Value Setting**: `void set(X v0)`
- **Value Getting**: `X get() const`
- **Reference Access**: `const volatile X& get_kref() const` and `volatile X& get_ref() const`

### 7.2 Bulk Operations

Handlers for array-type variables support bulk operations through:

1. **Range Classes**: For deferred bulk operations with commit()
2. **Memory Block Methods**: For direct access to ranges of variables
3. **Type-Specific Copy Traits**: For efficient memory operations

### 7.3 Operation Synchronization

Hfvar provides synchronization support for feature operations:

```cpp
Base::Dsync::Reader get(Base::Feature& f0) const;
```

This returns a synchronization value to detect updates in the feature.

## 8. Implementation Details and Optimizations

### 8.1 Memory Copy Optimizations

Range classes use specialized copy traits for different variable types:

- **Array_memcpybool**: Optimized for boolean arrays
- **Array_memcpy16**: Optimized for 16-bit unsigned integer arrays
- **Array_memcpy32**: Optimized for 32-bit floating point arrays

### 8.2 Inline Functions

Many methods are implemented as inline functions for performance:

```cpp
inline void Hfvar::set(const volatile Base::Feature& v0)
{
    set(const_cast<const Base::Feature&>(v0));
}

inline Base::Fid Hfvar::get_id() const
{
    return id;
}
```

### 8.3 Const Correctness

The library maintains strict const correctness throughout:

- **Read-only References**: `const volatile X&`
- **Read-write References**: `volatile X&`
- **Const Methods**: `X get() const`

### 8.4 Volatile Qualification

The library uses volatile qualification for variables that may be modified by external processes:

- **References**: `volatile X&` and `const volatile X&`
- **Memory Blocks**: `Base::Mblock<volatile X>` and `Base::Mblock<const volatile X>`

## 9. Conclusion

The BSP library's variable handler components provide a comprehensive and consistent interface for accessing different types of variables. The design follows a common pattern across all handler classes while incorporating type-specific optimizations and functionality. The handlers support both individual and bulk operations, with specialized Range classes for efficient memory operations. The consistent interface, combined with type-specific adaptations, creates a flexible and powerful system for variable access and manipulation in the BSP library.