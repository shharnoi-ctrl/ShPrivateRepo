# Generated from:

- signing/set_crc32.py (319 tokens)
- signing/set_data.py (149 tokens)
- signing/ecc256_priv.pem (56 tokens)
- signing/set_bldr_data.py (424 tokens)
- signing/inject_signature.py (316 tokens)
- signing/process_file_sign.bat (68 tokens)
- signing/_firm_with_dev_key.bat (54 tokens)
- signing/generate_signature.bat (20 tokens)
- signing/process_file_hash.bat (62 tokens)
- signing/process_file_crc32.bat (33 tokens)

---

# Firmware Signing System Analysis

This document provides a comprehensive analysis of a firmware signing system that implements three security methods: CRC32 checksums, SHA-256 hashes, and ECC-256 digital signatures. The system consists of Python utilities and batch scripts that work together to secure firmware images.

## Firmware Header Structure

The firmware header has a specific binary format with the following structure:

| Offset | Size (bytes) | Description | Notes |
|--------|--------------|-------------|-------|
| 0      | 12           | Reserved    | First 12 bytes are reserved for other data |
| 12     | 4            | CRC32       | CRC32 checksum (little-endian) |
| 16     | 4            | Size        | Total firmware size (little-endian) |
| 20     | 2            | Application ID | Application identifier (little-endian) |
| 22     | 10           | Reserved    | Additional header space |
| 32     | Variable     | Security Data | Location where signature/hash is injected |

## Security Levels and Workflows

The system implements three distinct security levels, each with its own workflow:

### 1. CRC32 Checksum (Basic Integrity)

**Workflow implemented in `process_file_crc32.bat`:**
1. Set bootloader header data (size, app ID) using `set_bldr_data.py`
2. Calculate and set CRC32 checksum using `set_crc32.py`

This provides basic integrity checking but no protection against malicious modifications.

### 2. SHA-256 Hash (Integrity Verification)

**Workflow implemented in `process_file_hash.bat`:**
1. Set bootloader header data (size, app ID) using `set_bldr_data.py`
2. Generate SHA-256 hash of the firmware using OpenSSL
3. Inject the hash into the firmware at offset 32 using `inject_signature.py`
4. Calculate and set CRC32 checksum using `set_crc32.py`

This provides stronger integrity verification but no authentication of the source.

### 3. ECC-256 Digital Signature (Authentication)

**Workflow implemented in `process_file_sign.bat`:**
1. Set bootloader header data (size, app ID) using `set_bldr_data.py`
2. Generate ECC-256 digital signature using OpenSSL via `generate_signature.bat`
3. Inject the signature into the firmware at offset 32 using `inject_signature.py`
4. Calculate and set CRC32 checksum using `set_crc32.py`

This provides both integrity verification and authentication of the firmware source.

## Core Python Utilities

### `set_data.py`

This utility provides a generic function to insert binary data at a specific position in a file:

```python
def set_data(target_data, binary_data, position):
    # Ensure position is within bounds
    if position < 0 or position > len(target_data):
        raise ValueError("Position is out of bounds of the target file.")
    
    # Split target data and insert binary data
    before_injection = target_data[:position]
    after_injection = target_data[(position + len(binary_data)):]
    modified_data = before_injection + binary_data + after_injection
    return modified_data
```

This function is used by other utilities to modify specific parts of the firmware file.

### `set_crc32.py`

This utility calculates and sets the CRC32 checksum in the firmware header:

```python
def set_crc32(byte_data, crc_offset):
    global g_crc_value
    # Build a sequence without the CRC
    crc_size = 4
    before = byte_data[:crc_offset]
    after = byte_data[(crc_offset + crc_size):]
    data = before + after

    # Compute CRC32
    crc_value = zlib.crc32(data)
    g_crc_value = crc_value

    # Insert CRC value
    crc_array = crc_value.to_bytes(4, byteorder='little')
    data = before + crc_array + after

    return data
```

When run as a standalone script, it:
1. Reads the target file
2. Calculates CRC32 over the entire file (excluding the CRC field itself)
3. Inserts the CRC32 value at offset 12 (little-endian)
4. Writes the modified file back
5. Displays the CRC32 value in hexadecimal format

### `set_bldr_data.py`

This utility initializes the firmware header with essential metadata:

```python
def inject_bldr_data(src_file, dst_file, app_id):
    # Read source file
    with open(src_file, 'rb') as target:
        target_data = target.read()

    # Set CRC to 0
    crc_offset = 12
    crc_byte_array = (0).to_bytes(4, byteorder='little')
    modified_data = set_data.set_data(target_data, crc_byte_array, crc_offset)

    # Set size to correct size
    size_offset = 16
    size = len(target_data)
    size_byte_array = size.to_bytes(4, byteorder='little')
    modified_data = set_data.set_data(modified_data, size_byte_array, size_offset)

    # Set application id if provided
    if app_id != -1:
        app_id_offset = 20
        app_id_byte_array = app_id.to_bytes(2, byteorder='little')
        modified_data = set_data.set_data(modified_data, app_id_byte_array, app_id_offset)

    # Write to destination file
    with open(dst_file, 'wb') as target:
        target.write(modified_data)
```

This function:
1. Sets the CRC32 field to zero (to be calculated later)
2. Sets the firmware size field (4 bytes, little-endian)
3. Sets the application ID if provided (2 bytes, little-endian)
4. Writes the modified data to the destination file

### `inject_signature.py`

This utility injects a binary signature or hash into the firmware:

```python
def inject_binary_in_middle(target_file, binary_file, position):
    # Read target file
    with open(target_file, 'rb') as target:
        target_data = target.read()

    # Read binary file to inject
    with open(binary_file, 'rb') as binary:
        binary_data = binary.read()

    # Insert binary data
    target_data = set_data.set_data(target_data, binary_data, position)

    # Write modified data back
    with open(target_file, 'wb') as target:
        target.write(target_data)
```

When run as a standalone script, it:
1. Takes a target file and a binary file (signature or hash)
2. Injects the binary file at position 32 in the target file
3. Writes the modified file back

## Batch Script Workflows

### `process_file_crc32.bat`

```batch
set src_file=%1
set dst_file=%2
set app_id=%3

python set_bldr_data.py %src_file% %dst_file% %app_id%
python set_crc32.py %dst_file%
```

This script:
1. Takes source file, destination file, and application ID as parameters
2. Sets up the bootloader header data
3. Calculates and sets the CRC32 checksum

### `process_file_hash.bat`

```batch
set src_file=%1
set dst_file=%2
set app_id=%3

python set_bldr_data.py %src_file% %dst_file% %app_id%
openssl dgst -binary -sha256 -out hash.bin %dst_file%
python inject_signature.py %dst_file% hash.bin
python set_crc32.py %dst_file%
```

This script:
1. Takes source file, destination file, and application ID as parameters
2. Sets up the bootloader header data
3. Generates a SHA-256 hash of the file using OpenSSL
4. Injects the hash into the firmware at offset 32
5. Calculates and sets the CRC32 checksum

### `generate_signature.bat`

```batch
@echo Key:  %1
@echo File: %2
openssl dgst -sha256 -sign %1 -out signature.bin %2
```

This script:
1. Takes a private key file and a target file as parameters
2. Uses OpenSSL to generate an ECC-256 digital signature
3. Outputs the signature to `signature.bin`

### `process_file_sign.bat`

```batch
set src_file=%1
set dst_file=%2
set app_id=%3
set prv_key_file=%4

python set_bldr_data.py %src_file% %dst_file% %app_id%
call generate_signature %prv_key_file% %dst_file%
python inject_signature.py %dst_file% signature.bin
del signature.bin
python set_crc32.py %dst_file%
```

This script:
1. Takes source file, destination file, application ID, and private key file as parameters
2. Sets up the bootloader header data
3. Generates an ECC-256 digital signature using the private key
4. Injects the signature into the firmware at offset 32
5. Deletes the temporary signature file
6. Calculates and sets the CRC32 checksum

### `_firm_with_dev_key.bat`

```batch
@echo off
echo Signing file: %1 into %~n1.firm
openssl dgst -sha256 -sign ecc256_priv.pem -out %~n1.firm %1
echo Verifying....
openssl dgst -verify ecc256_priv.pem -keyform PEM -sha256 -signature %~n1.firm -binary %1
```

This script:
1. Takes a file as parameter
2. Signs the file using the development private key (`ecc256_priv.pem`)
3. Outputs the signature to a `.firm` file
4. Immediately verifies the signature using the same key
   - Note: This is unusual as verification typically uses a public key, not the private key

## Security Considerations

### Key Management

1. **Private Key Storage**: The system includes a development private key (`ecc256_priv.pem`) directly in the repository, which is a security risk. In a production environment, private keys should be:
   - Stored securely, possibly in a Hardware Security Module (HSM)
   - Protected with strong access controls
   - Never committed to version control

2. **Key Verification**: The `_firm_with_dev_key.bat` script uses the same private key for both signing and verification, which is unusual. Typically:
   - Private keys are used for signing
   - Public keys are used for verification
   - The verification process should be separate from the signing process

### Verification Process

1. **CRC32 Limitations**: CRC32 provides only basic integrity checking and is vulnerable to:
   - Accidental corruption detection only
   - No protection against deliberate tampering
   - Collisions are relatively easy to generate

2. **SHA-256 Improvements**: SHA-256 hashing provides stronger integrity verification but:
   - Without a signature, it cannot authenticate the source
   - An attacker could modify the firmware and recalculate the hash

3. **ECC-256 Signatures**: ECC-256 digital signatures provide the strongest security:
   - Authenticates the source of the firmware
   - Verifies integrity of the firmware
   - Requires possession of the private key to create valid signatures

### Implementation Details

1. **Header Manipulation**: The system sets the CRC field to zero before calculating the CRC, which is standard practice.

2. **Size Field**: The firmware size is stored in the header, which can be used for verification during the update process.

3. **Application ID**: The system supports different application IDs, allowing for identification of different firmware types or versions.

4. **Signature Location**: The signature or hash is always injected at offset 32, which means:
   - The header structure is fixed
   - The signature/hash size must be known by the verification code
   - There's no explicit indication of which security method is used

## Workflow Comparison

| Security Level | Script | Methods Used | Security Provided |
|----------------|--------|--------------|-------------------|
| Basic | `process_file_crc32.bat` | CRC32 | Basic integrity checking |
| Medium | `process_file_hash.bat` | SHA-256 + CRC32 | Strong integrity verification |
| High | `process_file_sign.bat` | ECC-256 + CRC32 | Authentication + integrity verification |

## Referenced Context Files

The following context files were helpful in understanding the system:

- `ecc256_priv.pem`: Contains the ECC-256 private key used for signing firmware. This helped understand the cryptographic method used (ECC-256).