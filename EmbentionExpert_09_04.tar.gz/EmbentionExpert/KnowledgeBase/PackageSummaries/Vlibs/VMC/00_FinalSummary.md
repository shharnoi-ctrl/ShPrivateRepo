# Generated from:

- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/VMC/08_Hardware_Abstraction_Layer.md (3187 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/VMC/07_Encoder_System.md (3649 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/VMC/06_Angle_Management.md (4291 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/VMC/05_Mechanical_Bounds.md (3947 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/VMC/06_CAN_Communication_Base.md (3734 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/VMC/03_XPC_CAN_Suite.md (4101 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/VMC/05_Command_System.md (5298 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/VMC/04_Calibration_System.md (6218 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/VMC/03_Motor_Control_Core.md (5922 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/VMC/02_Platform_Integration.md (5555 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/VMC/01_Motor_Control_System.md (3611 tokens)

---

# Vehicle Motor Control (VMC) System: Knowledge Graph Overview

This document provides a comprehensive overview of the Vehicle Motor Control (VMC) system, serving as the entry point for understanding this software system. The VMC system is designed for precise control of brushless and stepper motors, with a focus on field-oriented control for brushless motors and position/velocity control for both motor types.

## System Architecture

The VMC system follows a layered architecture with clear separation of concerns:

```
┌─────────────────────────────────────────────────────────────────────┐
│                      Platform Integration                           │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐ │
│  │  Vmcsuite   │──│ Xpcu8suite  │──│ Mediasuite  │──│ System Status│ │
│  └─────────────┘  └─────────────┘  └─────────────┘  └─────────────┘ │
└───────────┬─────────────────────────────────┬───────────────────────┘
            │                                 │
┌───────────▼─────────────────────────────────▼───────────────────────┐
│                  Command and Communication                          │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐ │
│  │ Command Sys │──│  Mcanrx     │──│ Xpccansuite │──│ CAN Config  │ │
│  └─────────────┘  └─────────────┘  └─────────────┘  └─────────────┘ │
└───────────┬─────────────────────────────────┬───────────────────────┘
            │                                 │
┌───────────▼─────────────────────────────────▼───────────────────────┐
│                      Motor Control Core                             │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐ │
│  │Control_foc  │──│ Clarke/Park │──│ PI Control  │──│ Space Vector│ │
│  └─────────────┘  └─────────────┘  └─────────────┘  └─────────────┘ │
└───────────┬─────────────────────────────────┬───────────────────────┘
            │                                 │
┌───────────▼─────────────────────────────────▼───────────────────────┐
│                Calibration and Configuration                        │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐ │
│  │  Polecal    │──│ Current Cal │──│ Stepper Cal │──│ Config Mgmt │ │
│  └─────────────┘  └─────────────┘  └─────────────┘  └─────────────┘ │
└───────────┬─────────────────────────────────┬───────────────────────┘
            │                                 │
┌───────────▼─────────────────────────────────▼───────────────────────┐
│                     Angle Management                                │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐ │
│  │   Encoder   │──│   Eangle    │──│   Mangle    │──│   Mbounds   │ │
│  └─────────────┘  └─────────────┘  └─────────────┘  └─────────────┘ │
└───────────┬─────────────────────────────────┬───────────────────────┘
            │                                 │
┌───────────▼─────────────────────────────────▼───────────────────────┐
│                  Hardware Abstraction Layer                         │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐ │
│  │    ADC      │──│    PWM      │──│    GPIO     │──│  Comms I/F  │ │
│  └─────────────┘  └─────────────┘  └─────────────┘  └─────────────┘ │
└─────────────────────────────────────────────────────────────────────┘
```

## Key System Components

### 1. Hardware Abstraction Layer (HAL)
The HAL provides a unified interface to hardware peripherals, abstracting the details of register-level access. It manages:
- GPIO configuration for driver control and status
- PWM setup for motor control
- ADC sampling for current and voltage feedback
- Communication interfaces (CAN, SCI, SPI, I2C)

For more details, see [08_Hardware_Abstraction_Layer.md](08_Hardware_Abstraction_Layer.md).

### 2. Angle Management System
This system processes position feedback and manages both electrical and mechanical angles:
- **Encoder System**: Interfaces with Celera Zettlex IncOder Digital Encoders via SPI
- **Electrical Angle Management**: Converts mechanical angles to electrical angles using pole pairs
- **Mechanical Angle Management**: Processes raw encoder values to mechanical angles
- **Mechanical Bounds**: Ensures motor angles stay within configured limits

For more details, see:
- [07_Encoder_System.md](07_Encoder_System.md)
- [06_Angle_Management.md](06_Angle_Management.md)
- [05_Mechanical_Bounds.md](05_Mechanical_Bounds.md)

### 3. Communication Infrastructure
The communication system handles data exchange between components and with external systems:
- **CAN Communication Base**: Provides thread-safe message reception and configuration
- **XPC CAN Suite**: Orchestrates CAN communication with fair bus access
- **Byte Stream Suite**: Manages communication between different interfaces

For more details, see:
- [06_CAN_Communication_Base.md](06_CAN_Communication_Base.md)
- [03_XPC_CAN_Suite.md](03_XPC_CAN_Suite.md)

### 4. Command and Control System
This system processes commands and implements control algorithms:
- **Command System**: Handles command reception and routing
- **Calibration System**: Performs electrical angle, current sensing, and stepper motor calibration
- **Motor Control Core**: Implements field-oriented control for brushless motors

For more details, see:
- [05_Command_System.md](05_Command_System.md)
- [04_Calibration_System.md](04_Calibration_System.md)
- [03_Motor_Control_Core.md](03_Motor_Control_Core.md)

### 5. Platform Integration
These components integrate the VMC system with the broader platform:
- **VMC Suite**: Orchestrates all system components
- **Media Suite**: Manages configuration and file system operations
- **System Status**: Reports system health and status

For more details, see [02_Platform_Integration.md](02_Platform_Integration.md).

## Data Flow

### Sensor Data Flow
1. Encoder provides position data via SPI
2. Raw encoder values are converted to electrical and mechanical angles
3. Current feedback is sampled by ADC
4. Clarke and Park transforms convert currents to the rotating reference frame
5. Control algorithms use position and current feedback to generate control outputs

### Command Flow
1. Commands arrive via CAN bus
2. Thread-safe reception ensures data integrity
3. Commands are deserialized and routed to appropriate handlers
4. Control mode is selected based on command type
5. Control outputs are generated based on the selected mode

### Control Cascade
The system implements a cascaded control architecture:
```
Position Control → Velocity Control → Current Control → Voltage Control → PWM Generation
```
Each controller in the cascade generates setpoints for the next controller, allowing for precise control at multiple levels.

## Safety Mechanisms

The VMC system implements several safety mechanisms:

1. **Mechanical Bounds Protection**: Prevents motor movement beyond mechanical limits
2. **Overcurrent Protection**: Detects and responds to excessive current
3. **Command Validation**: Validates incoming commands and defaults to safe states
4. **Fault Detection**: Monitors hardware faults and responds appropriately

## Configuration Capabilities

The system supports extensive configuration:

1. **Motor Type**: Both brushless and stepper motors
2. **Control Parameters**: Tunable PI controllers for position, velocity, and current
3. **Mechanical Limits**: Configurable bounds for motor movement
4. **Communication**: Configurable CAN IDs, baudrates, and protocols

## Key Design Patterns

1. **Singleton Pattern**: Used in the HAL to ensure single access point to hardware
2. **Thread Safety Mechanisms**: Protect shared resources in communication systems
3. **State Machine Pattern**: Used in calibration and communication components
4. **Cascaded Control Architecture**: Enables precise control at multiple levels
5. **Observer Pattern**: Implemented in the variable management system

## For Further Information

To dive deeper into specific aspects of the VMC system, refer to the following documents:

- For hardware interfaces: [08_Hardware_Abstraction_Layer.md](08_Hardware_Abstraction_Layer.md)
- For position feedback: [07_Encoder_System.md](07_Encoder_System.md)
- For angle management: [06_Angle_Management.md](06_Angle_Management.md)
- For mechanical limits: [05_Mechanical_Bounds.md](05_Mechanical_Bounds.md)
- For CAN communication: [06_CAN_Communication_Base.md](06_CAN_Communication_Base.md) and [03_XPC_CAN_Suite.md](03_XPC_CAN_Suite.md)
- For command processing: [05_Command_System.md](05_Command_System.md)
- For calibration procedures: [04_Calibration_System.md](04_Calibration_System.md)
- For motor control algorithms: [03_Motor_Control_Core.md](03_Motor_Control_Core.md)
- For system integration: [02_Platform_Integration.md](02_Platform_Integration.md)
- For a comprehensive overview: [01_Motor_Control_System.md](01_Motor_Control_System.md)

This knowledge graph provides a structured understanding of the VMC system, enabling efficient navigation through its components and facilitating comprehension of its complex interactions.