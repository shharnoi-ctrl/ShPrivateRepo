# Generated from:

- code/include/Eangle.h (392 tokens)
- code/include/Eangle_fw.h (21 tokens)
- code/include/Mangle.h (425 tokens)
- code/include/Mangle_fw.h (21 tokens)
- code/include/Ccmd_mangle.h (143 tokens)
- code/include/Ccmd_mangle_rate.h (154 tokens)
- code/source/Eangle.cpp (165 tokens)
- code/source/Mangle.cpp (212 tokens)
- code/source/Ccmd_mangle.cpp (62 tokens)
- code/source/Ccmd_mangle_rate.cpp (85 tokens)

## With context from:

- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/VMC/07_Encoder_System.md (3649 tokens)

---

# Angle Management System for Brushless Motor Control

This document provides a comprehensive analysis of the angle management system used for brushless motor control. The system handles both electrical and mechanical angles, providing essential angle data for field-oriented control.

## 1. Functional Behavior and Logic

### Angle Management System Overview

The angle management system consists of several key components:

1. **Electrical Angle Management (`Eangle` class)**: 
   - Converts mechanical angles to electrical angles using pole pairs
   - Handles calibration offsets for electrical angles
   - Provides electrical angle data for field-oriented control

2. **Mechanical Angle Management (`Mangle` class)**:
   - Processes raw encoder values to mechanical angles
   - Handles inversion and calibration offsets
   - Provides mechanical angle data for position control

3. **Command Structures**:
   - `Ccmd_mangle`: Provides setpoints for mechanical angle position control
   - `Ccmd_mangle_rate`: Provides setpoints for mechanical angle velocity control

### Electrical Angle Calculation Flow

The `Eangle` class converts normalized raw encoder values to electrical angles using the following process:

1. Receive normalized raw encoder value (0 to 2π) from the encoder system
2. Apply pole pair multiplication to convert mechanical angle to electrical angle
3. Apply calibration offset to adjust for rotor-stator alignment
4. Wrap the result to the range 0 to 2π

```cpp
void Eangle::step(Real enc_norm_raw)
{
    angle = Rfun::wrap2pi(pole_pairs * enc_norm_raw - angle_cal);
}
```

The electrical angle is essential for field-oriented control, as it determines the orientation of the magnetic field relative to the rotor.

### Mechanical Angle Calculation Flow

The `Mangle` class processes raw encoder values to mechanical angles using the following process:

1. Receive raw encoder value from the encoder system
2. Apply inversion if configured (change sign of the angle)
3. Apply calibration offset to adjust for mechanical alignment
4. Wrap the result to the range 0 to 2π

```cpp
Real Mangle::convert(Real enc_raw) const
{
    if(invert)
    {
        enc_raw = -enc_raw;
    }
    return Rfun::wrap2pi(enc_raw - angle_cal);
}
```

The mechanical angle is used for position control and provides the absolute position of the rotor.

### Angle Range Conversion

The `Mangle` class also provides functionality to convert between different angle ranges:

```cpp
void Mangle::convert(const Base::Radrng& in, Base::Radrng& out) const
{
    // Caution: if this conversion changes, update Java code that
    // uses this implementation to transform between mechanical and
    // encoder raw angles in mechanical limits settings.
    out.center = convert(in.center);
    out.delta = in.delta;
}
```

This is used to transform between mechanical and encoder raw angles in mechanical limits settings.

## 2. Control Flow and State Transitions

### Electrical Angle Processing Flow

| State | Trigger | Actions | Next State | Location |
|-------|---------|---------|------------|----------|
| Idle | `step(enc_norm_raw)` called | Multiply by pole pairs, subtract calibration, wrap to 2π | Updated | `Eangle.cpp:24` |
| Calibration | `set_angle_cal(angle_elec_cal0)` called | Add new calibration to current, wrap to 2π | Updated | `Eangle.cpp:19` |
| Configuration | `set_pole_pairs(pole_pairs0)` called | Update pole pairs value | Updated | `Eangle.cpp:14` |

### Mechanical Angle Processing Flow

| State | Trigger | Actions | Next State | Location |
|-------|---------|---------|------------|----------|
| Idle | `step(enc_raw)` called | Apply inversion if needed, subtract calibration, wrap to 2π | Updated | `Mangle.h:58-61` |
| Configuration | `cset(str)` called | Update inversion flag and calibration offset | Updated | `Mangle.cpp:29-32` |

## 3. Inputs and Stimuli

### Electrical Angle Inputs

| Input | Processing | Effect | Location |
|-------|------------|--------|----------|
| `enc_norm_raw` | Multiplied by pole pairs, offset by calibration | Updates electrical angle | `Eangle.cpp:24` |
| `pole_pairs0` | Direct assignment | Updates pole pair count | `Eangle.cpp:14` |
| `angle_elec_cal0` | Added to current calibration, wrapped to 2π | Updates electrical angle calibration | `Eangle.cpp:19` |
| Configuration data | Deserialized via `cset()` | Updates pole pairs and calibration | `Eangle.cpp:29-32` |

### Mechanical Angle Inputs

| Input | Processing | Effect | Location |
|-------|------------|--------|----------|
| `enc_raw` | Inverted if needed, offset by calibration | Updates mechanical angle | `Mangle.h:58-61`, `Mangle.cpp:22-26` |
| Configuration data | Deserialized via `cset()` | Updates inversion flag and calibration | `Mangle.cpp:29-32` |

### Command Structure Inputs

| Input | Processing | Effect | Location |
|-------|------------|--------|----------|
| `sp_mangle` | Deserialized via `cset()` | Sets mechanical angle setpoint | `Ccmd_mangle.cpp:12` |
| `sp_mangle_rate` | Deserialized via `cset()` | Sets mechanical angle rate setpoint | `Ccmd_mangle_rate.cpp:12-13` |

## 4. Outputs and Effects

### Electrical Angle Outputs

| Output | Description | Calculation | Access Method | Location |
|--------|-------------|-------------|---------------|----------|
| `angle` | Electrical angle (0 to 2π) | `pole_pairs * enc_norm_raw - angle_cal` | `get_angle()` | `Eangle.h:36-39` |
| `is_inverted()` | Direction indicator | `pole_pairs < 0` | `is_inverted()` | `Eangle.h:41-44` |
| `pole_pairs` | Number of pole pairs | Direct access | `get_polepairs()` | `Eangle.h:46-49` |

### Mechanical Angle Outputs

| Output | Description | Calculation | Access Method | Location |
|--------|-------------|-------------|---------------|----------|
| `angle` | Mechanical angle (0 to 2π) | `convert(enc_raw)` | `get_angle()` | `Mangle.h:48-51` |
| `is_inverted()` | Direction indicator | Direct access to `invert` flag | `is_inverted()` | `Mangle.h:53-56` |

### Command Structure Outputs

| Output | Description | Access | Location |
|--------|-------------|--------|----------|
| `sp_mangle` | Mechanical angle setpoint | Direct member access | `Ccmd_mangle.h:12` |
| `sp_mangle_rate` | Mechanical angle rate setpoint | Direct member access | `Ccmd_mangle_rate.h:12` |

## 5. Parameters and Configuration

### Electrical Angle Parameters

| Parameter | Description | Default | Location |
|-----------|-------------|---------|----------|
| `pole_pairs` | Number of pole pairs in the motor | 1 | `Eangle.cpp:7` |
| `angle_cal` | Electrical angle calibration offset | 0 | `Eangle.cpp:8` |

### Mechanical Angle Parameters

| Parameter | Description | Default | Location |
|-----------|-------------|---------|----------|
| `invert` | Flag to invert the sign of the encoder | false | `Mangle.h:63` |
| `angle_cal` | Mechanical angle calibration offset | 0 | `Mangle.cpp:7` |

### Command Structure Parameters

| Parameter | Description | Default | Range | Location |
|-----------|-------------|---------|-------|----------|
| `sp_mangle` | Mechanical angle setpoint | 0 | 0 to 2π | `Ccmd_mangle.cpp:7` |
| `sp_mangle_rate` | Mechanical angle rate setpoint | 0 | ±1500 rad/s | `Ccmd_mangle_rate.cpp:7-12` |

## 6. Error Handling and Contingency Logic

### Serialization Error Handling

Both `Eangle` and `Mangle` classes inherit from `Base::Ideserializable` and implement the `cset()` method for configuration deserialization. The `Base::Lossy_error` class is used to handle deserialization errors:

```cpp
void Eangle::cset(Base::Lossy_error& str)
{
    str.get_int16(pole_pairs);
    str.get_float(angle_cal);
}

void Mangle::cset(Base::Lossy_error& str)
{
    str.get_bool16(invert);
    str.get_float(angle_cal);
}
```

If deserialization fails, the `Lossy_error` class will track the error, but the code doesn't show explicit error handling beyond this.

### Angle Wrapping

Both electrical and mechanical angles are wrapped to the range 0 to 2π using the `Rfun::wrap2pi()` function to ensure they stay within the valid range:

```cpp
angle = Rfun::wrap2pi(pole_pairs * enc_raw - angle_cal);
```

```cpp
return Rfun::wrap2pi(enc_raw - angle_cal);
```

## 7. File-by-File Breakdown

### Eangle.h

This header file defines the `Eangle` class for electrical angle calculation:

- Class declaration with public and private methods
- Member variables for pole pairs, calibration, and angle
- Method declarations for angle calculation, configuration, and data access
- Inline implementations of getter methods

The class inherits from `Base::Ideserializable` to support configuration deserialization.

### Eangle_fw.h

A forward declaration header that simply declares the `Eangle` class in the `VMC` namespace. This allows other files to reference the electrical angle class without including the full implementation details.

### Mangle.h

This header file defines the `Mangle` class for mechanical angle calculation:

- Class declaration with public and private methods
- Member variables for inversion flag, calibration, and angle
- Method declarations for angle calculation, configuration, and data access
- Inline implementations of getter methods and the `step()` method

The class inherits from `Base::Ideserializable` to support configuration deserialization.

### Mangle_fw.h

A forward declaration header that simply declares the `Mangle` class in the `VMC` namespace. This allows other files to reference the mechanical angle class without including the full implementation details.

### Ccmd_mangle.h

This header file defines the `Ccmd_mangle` struct for mechanical angle position control:

- Struct declaration with public methods
- Member variable for mechanical angle setpoint
- Method declarations for construction and deserialization

### Ccmd_mangle_rate.h

This header file defines the `Ccmd_mangle_rate` struct for mechanical angle velocity control:

- Struct declaration with public methods
- Member variable for mechanical angle rate setpoint
- Method declarations for construction and deserialization

### Eangle.cpp

This source file implements the functionality declared in `Eangle.h`:

- Constructor implementation with initialization of member variables
- Implementation of `set_pole_pairs()` to update the pole pair count
- Implementation of `set_angle_cal()` to update the calibration offset
- Implementation of `step()` to calculate the electrical angle
- Implementation of `cset()` for configuration deserialization

### Mangle.cpp

This source file implements the functionality declared in `Mangle.h`:

- Constructor implementation with initialization of member variables
- Implementation of `convert()` methods for angle conversion
- Implementation of `cset()` for configuration deserialization

### Ccmd_mangle.cpp

This source file implements the functionality declared in `Ccmd_mangle.h`:

- Constructor implementation with initialization of setpoint
- Implementation of `cset()` for command deserialization
- Uses `str2ufloat<Ku16::u24>` to deserialize the setpoint with a range of 0 to 2π

### Ccmd_mangle_rate.cpp

This source file implements the functionality declared in `Ccmd_mangle_rate.h`:

- Constructor implementation with initialization of setpoint
- Implementation of `cset()` for command deserialization
- Uses `str2ifloat<Ku16::u24>` to deserialize the setpoint with a range of ±1500 rad/s

## 8. Cross-Component Relationships

### Integration with Encoder System

The angle management system integrates with the encoder system through the `step()` methods:

1. The `Eangle::step()` method receives normalized raw encoder values from the encoder system:
   ```cpp
   void Eangle::step(Real enc_norm_raw)
   ```

2. The `Mangle::step()` method receives raw encoder values from the encoder system:
   ```cpp
   void Mangle::step(Real enc_raw)
   ```

These methods process the encoder values to calculate electrical and mechanical angles, respectively.

### Integration with Motor Control System

The angle management system provides essential angle data to the motor control system:

1. The `Eangle::get_angle()` method provides electrical angle data for field-oriented control:
   ```cpp
   Real Eangle::get_angle() const
   ```

2. The `Mangle::get_angle()` method provides mechanical angle data for position control:
   ```cpp
   Real Mangle::get_angle() const
   ```

3. The command structures provide setpoints for position and velocity control:
   ```cpp
   Real Ccmd_mangle::sp_mangle;
   Real Ccmd_mangle_rate::sp_mangle_rate;
   ```

## 9. Angle Calculation Details

### Electrical Angle Calculation

The electrical angle is calculated from the mechanical angle using the number of pole pairs:

```cpp
angle = Rfun::wrap2pi(pole_pairs * enc_norm_raw - angle_cal);
```

For a motor with `p` pole pairs, the electrical angle rotates `p` times faster than the mechanical angle. This is because the magnetic field must rotate `p` times for the rotor to make one complete mechanical rotation.

### Mechanical Angle Calculation

The mechanical angle is calculated from the raw encoder value with optional inversion and calibration:

```cpp
Real Mangle::convert(Real enc_raw) const
{
    if(invert)
    {
        enc_raw = -enc_raw;
    }
    return Rfun::wrap2pi(enc_raw - angle_cal);
}
```

The inversion option allows for flexibility in encoder mounting orientation, while the calibration offset allows for alignment with the mechanical system.

### Angle Range Conversion

The `Mangle::convert()` method for `Radrng` objects preserves the center and delta values while applying the mechanical angle conversion to the center:

```cpp
void Mangle::convert(const Base::Radrng& in, Base::Radrng& out) const
{
    out.center = convert(in.center);
    out.delta = in.delta;
}
```

This is used to transform between mechanical and encoder raw angles in mechanical limits settings.

## 10. Command Structure Details

### Mechanical Angle Command

The `Ccmd_mangle` struct provides a setpoint for mechanical angle position control:

```cpp
struct Ccmd_mangle
{
    Real sp_mangle;        ///< Mechanical normalized angle setpoint.
    // ...
};
```

The setpoint is deserialized using a 24-bit unsigned float with a range of 0 to 2π:

```cpp
void Ccmd_mangle::cset(Base::Lossy& str)
{
    str2ufloat<Ku16::u24>(str, Const::PI2, sp_mangle);
}
```

### Mechanical Angle Rate Command

The `Ccmd_mangle_rate` struct provides a setpoint for mechanical angle velocity control:

```cpp
struct Ccmd_mangle_rate
{
    Real sp_mangle_rate;        ///< Mechanical angle rate setpoint.
    // ...
};
```

The setpoint is deserialized using a 24-bit signed float with a range of ±1500 rad/s:

```cpp
void Ccmd_mangle_rate::cset(Base::Lossy& str)
{
    static const Real max_angle_rate = 1500;   // rad/s
    str2ifloat<Ku16::u24>(str, max_angle_rate, sp_mangle_rate);
}
```

## Summary

The angle management system provides essential angle data for brushless motor control by processing raw encoder values into electrical and mechanical angles. The system consists of the `Eangle` class for electrical angle calculation, the `Mangle` class for mechanical angle calculation, and command structures for position and velocity control.

The electrical angle is calculated by multiplying the mechanical angle by the number of pole pairs and applying a calibration offset. This angle is essential for field-oriented control, as it determines the orientation of the magnetic field relative to the rotor.

The mechanical angle is calculated by applying inversion if needed and a calibration offset to the raw encoder value. This angle is used for position control and provides the absolute position of the rotor.

The command structures provide setpoints for position and velocity control, with the `Ccmd_mangle` struct providing a mechanical angle setpoint and the `Ccmd_mangle_rate` struct providing a mechanical angle rate setpoint.

The angle management system integrates with the encoder system to receive raw encoder values and with the motor control system to provide essential angle data for field-oriented control and position control. The system is highly configurable, with options for pole pair count, inversion, and calibration offsets.

## Referenced Context Files

- `Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/VMC/07_Encoder_System.md` - Provided information about the encoder system that supplies raw angle data to the angle management system.