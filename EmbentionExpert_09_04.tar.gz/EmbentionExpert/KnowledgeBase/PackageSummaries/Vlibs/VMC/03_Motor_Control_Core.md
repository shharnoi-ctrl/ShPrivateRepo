# Generated from:

- code/include/Control_foc_enc.h (1556 tokens)
- code/include/Vars_brushless.h (753 tokens)
- code/include/Vars_brushless_fw.h (20 tokens)
- code/source/Control_foc_enc.cpp (3319 tokens)
- code/source/Vars_brushless.cpp (99 tokens)
- code/source/Hvar_brushless.cpp (463 tokens)

## With context from:

- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/VMC/08_Hardware_Abstraction_Layer.md (3187 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/VMC/07_Encoder_System.md (3649 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/VMC/06_Angle_Management.md (4291 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/VMC/05_Command_System.md (5298 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/VMC/04_Calibration_System.md (6218 tokens)

---

# Field-Oriented Control (FOC) Implementation for Brushless Motors

This document provides a comprehensive analysis of the field-oriented control (FOC) implementation for brushless motors in the Vehicle Motor Control (VMC) system, focusing on the `Control_foc_enc` class that implements the control algorithm.

## 1. Functional Behavior and Logic

### Control System Architecture

The `Control_foc_enc` class implements a complete field-oriented control system for brushless motors with encoder feedback. The system provides three primary control modes:

1. **Position Control**: Controls the mechanical angle of the motor
2. **Velocity Control**: Controls the mechanical angular velocity of the motor
3. **Current Control**: Directly controls the motor currents in the rotating reference frame

The control system follows a cascaded control architecture:
- Position control generates velocity commands
- Velocity control generates current commands
- Current control generates voltage commands
- Voltage commands are converted to PWM signals

### Control Pipeline Overview

The control pipeline consists of the following stages:

1. **Sensing**:
   - Read encoder position
   - Measure phase currents
   - Calculate electrical and mechanical angles
   - Estimate mechanical velocity

2. **Control**:
   - Position control loop (PI controller)
   - Velocity control loop (PI controller)
   - Current control loops (PI controllers for d and q axes)

3. **Coordinate Transformations**:
   - Clarke transform (3-phase to 2-phase stationary)
   - Park transform (stationary to rotating reference frame)
   - Inverse Park transform (rotating to stationary reference frame)

4. **Output Generation**:
   - Space Vector Generation (SVGEN)
   - PWM signal generation

### Control Flow

The main control flow is implemented in the `step()` method, which:

1. Updates real-time statistics
2. Checks for new commands from the CAN interface
3. Verifies system state (normal/maintenance)
4. Executes the appropriate control mode based on the command scheme

```cpp
void Control_foc_enc::step()
{
    // stats
    Type_rcstats::Scoped s(rt_stats); // RAII
    {
        rt_stats_dt_data = rt_stats_dt.compute(rt_period*1.001);
        rt_stats_data = rt_stats.stats.get_data();
    }

    bool cmd_changed = cmd_lock ? false : mcan_reader.refresh(cmd);

    cmd_lock = false; // default is set to false, it must be changed to true if needed for next step.

    // Not change state if is not in normal mode
    if(l_st != Base::lst_normal)
    {
        cmd.cmd.sch = Ccmd::sch_off;
    }

    switch(cmd.cmd.sch)
    {
        case Ccmd::sch_off:
            // Turn off motor
            break;
        case Ccmd::sch_cal_iphase:
            // Calibrate phase current
            break;
        case Ccmd::sch_mech_angle:
            // Position control
            step_sense();
            step_pos(cmd.cmd.mech_angle.sp_mangle);
            break;
        case Ccmd::sch_mech_angle_rate:
            // Velocity control
            step_sense();
            step_vel(cmd.cmd.mech_angle_rate.sp_mangle_rate);
            break;
        case Ccmd::sch_ipark:
            // Current control
            step_sense();
            step_current(cmd.ipark.id, cmd.ipark.iq);
            break;
        case Ccmd::sch_cal_elec:
            // Calibrate electrical angle
            break;
        default:
            // Not implemented
            break;
    }
}
```

## 2. Control Flow and State Transitions

### Control Mode State Machine

| Current Mode | Trigger | Actions | Next Mode | Location |
|--------------|---------|---------|-----------|----------|
| Any | `cmd.cmd.sch = sch_off` | Disable PWM, reset controllers | `sch_off` | `Control_foc_enc.cpp:89-99` |
| Any | `cmd.cmd.sch = sch_cal_iphase` | Disable PWM, calibrate current sensors | `sch_cal_iphase` | `Control_foc_enc.cpp:100-121` |
| Any | `cmd.cmd.sch = sch_mech_angle` | Run position control loop | `sch_mech_angle` | `Control_foc_enc.cpp:122-126` |
| Any | `cmd.cmd.sch = sch_mech_angle_rate` | Run velocity control loop | `sch_mech_angle_rate` | `Control_foc_enc.cpp:127-131` |
| Any | `cmd.cmd.sch = sch_ipark` | Run current control loop | `sch_ipark` | `Control_foc_enc.cpp:132-142` |
| Any | `cmd.cmd.sch = sch_cal_elec` | Run electrical angle calibration | `sch_cal_elec` | `Control_foc_enc.cpp:143-158` |
| Any | `l_st != Base::lst_normal` | Force motor off | `sch_off` | `Control_foc_enc.cpp:83-86` |

### Control Pipeline Flow

The control pipeline follows a cascaded structure:

1. **Sensing** (`step_sense()`):
   - Read phase currents
   - Read encoder position
   - Calculate electrical and mechanical angles
   - Estimate mechanical velocity

2. **Position Control** (`step_pos()`):
   - Calculate position error
   - Run position PI controller
   - Pass velocity command to velocity control

3. **Velocity Control** (`step_vel()`):
   - Apply rate limiting to velocity command
   - Calculate velocity error
   - Run velocity PI controller
   - Pass current command to current control

4. **Current Control** (`step_current()`):
   - Transform phase currents to dq frame
   - Calculate current errors
   - Run current PI controllers
   - Transform voltage commands to αβ frame
   - Pass voltage commands to output generation

5. **Output Generation** (`step_output()`):
   - Generate space vector modulation signals
   - Update PWM duty cycles

## 3. Inputs and Stimuli

### Sensor Inputs

| Input | Processing | Effect | Location |
|-------|------------|--------|----------|
| `adc_iphase_u`, `adc_iphase_v` | Sampled by ADC, processed by `iph.step()` | Provides phase current measurements | `Control_foc_enc.cpp:173` |
| `enc` | Read via SPI, processed by `enc.step()` | Provides rotor position | `Control_foc_enc.cpp:176` |
| `adc_voltage` | Sampled by ADC | Provides DC bus voltage | `Control_foc_enc.h:40` |
| `adc_bemf_u`, `adc_bemf_v`, `adc_bemf_w` | Sampled by ADC | Provides back-EMF measurements | `Control_foc_enc.h:43-45` |
| `drv_fault` | Read via GPIO | Detects driver fault condition | `Control_foc_enc.h:39` |

### Command Inputs

| Input | Processing | Effect | Location |
|-------|------------|--------|----------|
| `cmd.cmd.sch` | Received via CAN, processed in `step()` | Determines control mode | `Control_foc_enc.cpp:87` |
| `cmd.cmd.mech_angle.sp_mangle` | Received via CAN | Sets position setpoint | `Control_foc_enc.cpp:125` |
| `cmd.cmd.mech_angle_rate.sp_mangle_rate` | Received via CAN | Sets velocity setpoint | `Control_foc_enc.cpp:130` |
| `cmd.ipark.id`, `cmd.ipark.iq` | Received via CAN | Sets current setpoints | `Control_foc_enc.cpp:138` |
| `cmd.cal_elec` | Received via CAN | Sets electrical angle calibration parameters | `Control_foc_enc.cpp:143-158` |
| `cmd.cal_iphase` | Received via CAN | Sets current calibration parameters | `Control_foc_enc.cpp:100-121` |

### Configuration Inputs

| Input | Processing | Effect | Location |
|-------|------------|--------|----------|
| Controller parameters | Deserialized via `cset()` | Configures PI controllers | `Control_foc_enc.cpp:365` |
| `time_ovrcurrent` | Deserialized via `cset()` | Sets overcurrent protection timeout | `Control_foc_enc.cpp:366` |
| `max_iq` | Deserialized via `cset()` | Sets maximum quadrature current | `Control_foc_enc.cpp:367` |

## 4. Outputs and Effects

### Motor Control Outputs

| Output | Description | Trigger | Effect | Location |
|--------|-------------|---------|--------|----------|
| `pwm1a`, `pwm2a`, `pwm3a` | PWM signals | Generated by `step_output()` | Controls motor phase voltages | `Control_foc_enc.cpp:290-294` |
| `pi_pos.get_out()` | Position controller output | Generated by `step_pos()` | Sets velocity setpoint | `Control_foc_enc.cpp:198` |
| `pi_spd.get_out()` | Velocity controller output | Generated by `step_vel()` | Sets quadrature current setpoint | `Control_foc_enc.cpp:219` |
| `pi_id.get_out()`, `pi_iq.get_out()` | Current controller outputs | Generated by `step_current()` | Sets voltage commands | `Control_foc_enc.cpp:242-245` |

### Variable Management Outputs

| Output | Description | Update Location | Purpose |
|--------|-------------|-----------------|---------|
| `v_bemf_u/v/w` | Back-EMF measurements | `Control_foc_enc.cpp:180-182` | Monitoring |
| `v_iph_u/v/w` | Phase current measurements | `Control_foc_enc.cpp:183-185` | Monitoring |
| `v_rangle` | Raw encoder angle | `Control_foc_enc.cpp:186` | Monitoring |
| `v_eangle` | Electrical angle | `Control_foc_enc.cpp:187` | Monitoring |
| `v_mangle` | Mechanical angle | `Control_foc_enc.cpp:188` | Monitoring |
| `v_mangle_rate` | Mechanical angle rate | `Control_foc_enc.cpp:189` | Monitoring |
| `v_mangle_err` | Position error | `Control_foc_enc.cpp:200` | Monitoring |
| `v_manglec` | Position setpoint | `Control_foc_enc.cpp:201` | Monitoring |
| `v_cpos_out` | Position controller output | `Control_foc_enc.cpp:202` | Monitoring |
| `v_mangle_ratec` | Velocity setpoint | `Control_foc_enc.cpp:221` | Monitoring |
| `v_mangle_ratec_rlim` | Rate-limited velocity setpoint | `Control_foc_enc.cpp:222` | Monitoring |
| `v_cspd_out` | Velocity controller output | `Control_foc_enc.cpp:223` | Monitoring |
| `v_clarke_ialpha/ibeta` | Clarke transform outputs | `Control_foc_enc.cpp:247-248` | Monitoring |
| `v_park_ids/iqs` | Park transform outputs | `Control_foc_enc.cpp:249-250` | Monitoring |
| `v_park_idsc/iqsc` | Current setpoints | `Control_foc_enc.cpp:251-252` | Monitoring |
| `v_cid_out/ciq_out` | Current controller outputs | `Control_foc_enc.cpp:253-254` | Monitoring |
| `v_iclarke_ialpha/ibeta` | Inverse Park transform outputs | `Control_foc_enc.cpp:255-256` | Monitoring |
| `v_svgen_ta/tb/tc` | Space vector generator outputs | `Control_foc_enc.cpp:296-298` | Monitoring |
| `v_pwm_a/b/c` | PWM duty cycles | `Control_foc_enc.cpp:299-301` | Monitoring |

### Status Outputs

| Output | Description | Update Location | Purpose |
|--------|-------------|-----------------|---------|
| `v_hi_period` | Control loop period | `Control_foc_enc.cpp:65` | Performance monitoring |
| `v_hi_duration` | Control loop execution time | `Control_foc_enc.cpp:67` | Performance monitoring |
| `v_hi_ratio` | CPU utilization | `Control_foc_enc.cpp:69` | Performance monitoring |
| `kbit_bl_fault` | Driver fault status | `Control_foc_enc.cpp:71` | Fault monitoring |
| `kbit_health` | System health status | `Control_foc_enc.cpp:72` | Health monitoring |

## 5. Parameters and Configuration

### Controller Parameters

| Parameter | Description | Default Value | Location |
|-----------|-------------|---------------|----------|
| `pi_id` | Direct current PI controller | Kp=9.0, Ki=0.33, Limit=±0.8 | `Control_foc_enc.cpp:336` |
| `pi_iq` | Quadrature current PI controller | Kp=9.0, Ki=0.33, Limit=±0.8 | `Control_foc_enc.cpp:339` |
| `pi_spd` | Velocity PI controller | Kp=0.18, Ki=0.04, Limit=±0.4 | `Control_foc_enc.cpp:342` |
| `pi_pos` | Position PI controller | Kp=22.0, Ki=1.0, Limit=±8.0 | `Control_foc_enc.cpp:345` |
| `speed_rl` | Velocity rate limiter | -10000 to 10000 rad/s² | `Control_foc_enc.cpp:333` |
| `time_ovrcurrent` | Overcurrent protection timeout | Set via `cset()` | `Control_foc_enc.cpp:366` |
| `max_iq` | Maximum quadrature current | 1.0 (default) | `Control_foc_enc.cpp:367` |

### Angle Management Parameters

| Parameter | Description | Default Value | Location |
|-----------|-------------|---------------|----------|
| `eangle1.pole_pairs` | Number of pole pairs | 7 | `Control_foc_enc.cpp:330` |
| `bounds` | Mechanical angle bounds | Unbounded | `Control_foc_enc.cpp:327` |
| `speed_tau` | Speed estimation time constant | 0.001s | `Control_foc_enc.cpp:17` |

## 6. Error Handling and Contingency Logic

### Health Monitoring

The system implements health monitoring through the `check_health()` method:

```cpp
bool Control_foc_enc::check_health()
{
    bool ret = true;
    // Overcurrent protection
    if(Rmath::fabsr(park1.qs) > max_iq)
    {
        if (ovrcrt_to.expired())
        {
            ret  = false;
        }
    }
    else
    {
        ovrcrt_to.start();
    }

    return ret;
}
```

This method:
1. Checks if the quadrature current exceeds the maximum allowed value
2. If it does, starts a timeout timer
3. If the overcurrent condition persists beyond the timeout, sets the health status to false

### Fault Handling

The system handles faults through several mechanisms:

1. **Driver Fault Detection**:
   - Monitors the `drv_fault` GPIO input
   - Reports fault status through the variable management system

2. **Overcurrent Protection**:
   - Monitors quadrature current magnitude
   - Implements timeout-based protection
   - Sets health status to false if overcurrent persists

3. **Command Validation**:
   - Validates commands before execution
   - Prevents certain commands (e.g., `sch_ipark`) when mechanical bounds are present

4. **System State Monitoring**:
   - Monitors high-level VMC state (normal/maintenance)
   - Forces motor off when not in normal state

### Safe State Transition

When errors are detected or the system is commanded to turn off, the controller transitions to a safe state:

```cpp
case Ccmd::sch_off:
{
    pwm1a.set_enabled(false);
    pwm2a.set_enabled(false);
    pwm3a.set_enabled(false);
    pi_id.reset_ci();
    pi_iq.reset_ci();
    pi_spd.reset_ci();
    pi_pos.reset_ci();
    speed_rl.reset(0);
    step_sense();
    break;
}
```

This ensures that:
1. PWM outputs are disabled
2. Controller integrators are reset
3. Rate limiter is reset to zero
4. Sensor readings continue to be updated

## 7. File-by-File Breakdown

### Control_foc_enc.h

This header file defines the `Control_foc_enc` class, which implements the field-oriented control algorithm. Key components include:

- Class declaration with public and private methods
- Member variables for hardware interfaces (ADC, PWM, GPIO)
- Control components (Clarke/Park transforms, PI controllers, SVGEN)
- Angle management components (encoder, electrical/mechanical angle)
- Command handling and health monitoring

The class inherits from `Base::Ideserializable` to support configuration deserialization.

### Control_foc_enc.cpp

This source file implements the functionality declared in `Control_foc_enc.h`. Key components include:

- Constructor implementation with initialization of all components
- Main control loop implementation (`step()`)
- Control pipeline stages (`step_sense()`, `step_pos()`, `step_vel()`, `step_current()`, `step_output()`)
- Health monitoring (`check_health()`)
- Default configuration (`set_default()`)
- Configuration deserialization (`cset()`)

### Vars_brushless.h / Vars_brushless_fw.h

These files define the variable management system used by the controller:

- `Vars` struct with boolean, unsigned integer, and real variable ranges
- Variable initialization and access methods
- Forward declaration for use in other files

### Vars_brushless.cpp / Hvar_brushless.cpp

These files implement the variable management system:

- Constructor implementation with initialization of variable ranges
- Access methods for reading and writing variables
- Integration with the hardware abstraction layer

## 8. Cross-Component Relationships

### Hardware Abstraction Layer Integration

The FOC controller integrates with the hardware abstraction layer through:

1. **ADC Channels**:
   - Phase current measurements (`adc_iphase_u`, `adc_iphase_v`)
   - Back-EMF measurements (`adc_bemf_u`, `adc_bemf_v`, `adc_bemf_w`)
   - Voltage measurement (`adc_voltage`)

2. **PWM Outputs**:
   - Phase control (`pwm1a`, `pwm2a`, `pwm3a`)
   - Enable/disable control

3. **GPIO Interfaces**:
   - Driver fault detection (`drv_fault`)

### Encoder System Integration

The FOC controller integrates with the encoder system through:

1. **Position Feedback**:
   - Reads raw encoder position via `enc.step()`
   - Uses position for angle calculations

2. **Angle Management**:
   - Converts raw encoder values to electrical angles (`eangle1`)
   - Converts raw encoder values to mechanical angles (`mangle1`)
   - Estimates velocity from mechanical angle (`speed1`)

### Command System Integration

The FOC controller integrates with the command system through:

1. **Command Reception**:
   - Receives commands via `mcan_reader.refresh(cmd)`
   - Processes different command schemes

2. **Command Execution**:
   - Executes position control commands (`sch_mech_angle`)
   - Executes velocity control commands (`sch_mech_angle_rate`)
   - Executes current control commands (`sch_ipark`)
   - Executes calibration commands (`sch_cal_iphase`, `sch_cal_elec`)

### Variable Management Integration

The FOC controller integrates with the variable management system through:

1. **Variable Updates**:
   - Updates variables in `vars_step()` method
   - Provides monitoring data for all control stages

2. **Configuration Access**:
   - Reads system state (`l_st`)
   - Reports health status

## 9. Control Algorithm Details

### Field-Oriented Control Implementation

The field-oriented control algorithm is implemented through the following steps:

1. **Clarke Transform**:
   ```cpp
   clarke1.step(iph.get_iph_u(), iph.get_iph_v());
   ```
   Transforms three-phase currents (a,b,c) to two-phase stationary frame (α,β)

2. **Park Transform**:
   ```cpp
   park1.step(clarke1.alpha, clarke1.beta, esc);
   ```
   Transforms stationary frame currents (α,β) to rotating frame (d,q)

3. **Current Control**:
   ```cpp
   pi_id.step(rt_period, desired_id, park1.ds);
   pi_iq.step(rt_period, desired_iq, park1.qs);
   ```
   Controls direct and quadrature currents using PI controllers

4. **Inverse Park Transform**:
   ```cpp
   ipark1.step(pi_id.get_out(), pi_iq.get_out(), esc);
   ```
   Transforms rotating frame voltages (d,q) back to stationary frame (α,β)

5. **Space Vector Generation**:
   ```cpp
   svgen1.step(ipark1.alpha, ipark1.beta);
   ```
   Generates three-phase modulation signals from stationary frame voltages

6. **PWM Generation**:
   ```cpp
   pwm1a.set(svgen1.ta*Const::ONEHALF + Const::ONEHALF);
   pwm2a.set(svgen1.tb*Const::ONEHALF + Const::ONEHALF);
   pwm3a.set(svgen1.tc*Const::ONEHALF + Const::ONEHALF);
   ```
   Converts modulation signals to PWM duty cycles

### Cascaded Control Structure

The control system implements a cascaded control structure:

1. **Position Control**:
   ```cpp
   Real err_pos = bounds.step(desired_pos, mangle1.get_angle());
   pi_pos.step(rt_period, err_pos);
   ```
   Generates velocity command based on position error

2. **Velocity Control**:
   ```cpp
   Real desired_vel = speed_rl.step(rt_period, desired_vel0);
   pi_spd.step(rt_period, desired_vel, speed1.get_speed());
   ```
   Generates current command based on velocity error

3. **Current Control**:
   ```cpp
   pi_id.step(rt_period, desired_id, park1.ds);
   pi_iq.step(rt_period, desired_iq, park1.qs);
   ```
   Generates voltage commands based on current errors

This cascaded structure allows for precise control of motor position, velocity, and torque.

## 10. Performance Monitoring

The FOC controller implements comprehensive performance monitoring:

1. **Timing Statistics**:
   ```cpp
   rt_stats_dt_data = rt_stats_dt.compute(rt_period*1.001);
   rt_stats_data = rt_stats.stats.get_data();
   ```
   Tracks control loop period, execution time, and CPU utilization

2. **Variable Reporting**:
   ```cpp
   vmap.rvars.get(Base::v_hi_period)       = rt_stats_dt_data.dt;
   vmap.rvars.get(Base::v_hi_period_max)   = rt_stats_dt_data.dt_max;
   vmap.rvars.get(Base::v_hi_duration)     = rt_stats_data.dt_avg;
   vmap.rvars.get(Base::v_hi_duration_max) = rt_stats_data.dt_max;
   vmap.rvars.get(Base::v_hi_ratio)        = rt_stats_data.ratio_avg;
   vmap.rvars.get(Base::v_hi_ratio_max)    = rt_stats_data.ratio_max;
   ```
   Reports timing statistics through the variable management system

3. **Health Monitoring**:
   ```cpp
   vmap.bvars.get(Base::kbit_bl_fault)     = drv_fault.get();
   vmap.bvars.get(Base::kbit_health)       = health && drv_fault.get();
   ```
   Reports driver fault and system health status

This monitoring enables real-time diagnostics and performance optimization.

## Summary

The field-oriented control (FOC) implementation for brushless motors in the VMC system provides a comprehensive solution for high-performance motor control. The `Control_foc_enc` class implements a cascaded control architecture with position, velocity, and current control loops, along with the necessary coordinate transformations and space vector modulation.

The system integrates with the hardware abstraction layer for sensor inputs and PWM outputs, the encoder system for position feedback, the angle management system for electrical and mechanical angle calculations, the command system for control mode selection, and the variable management system for monitoring and configuration.

Key features of the FOC implementation include:
1. Multiple control modes (position, velocity, current)
2. Cascaded control architecture
3. Field-oriented control with Clarke/Park transforms
4. Space vector modulation for efficient PWM generation
5. Health monitoring and fault detection
6. Comprehensive performance monitoring
7. Configurable controller parameters

The implementation provides a robust and flexible solution for brushless motor control, capable of precise position control, smooth velocity control, and efficient torque production.

## Referenced Context Files

The analysis was informed by the following context files:

1. **Hardware Abstraction Layer**:
   - Provided information about the hardware interfaces used by the FOC controller
   - Explained how the controller integrates with the underlying hardware

2. **Encoder System**:
   - Provided details about the encoder interface and position feedback
   - Explained how raw encoder values are processed and used for control

3. **Angle Management System**:
   - Provided information about electrical and mechanical angle calculations
   - Explained the relationship between encoder position and motor angles

4. **Command System**:
   - Provided details about the command structure and processing
   - Explained how different control modes are selected and configured

5. **Calibration System**:
   - Provided information about the calibration procedures
   - Explained how the system is configured for optimal performance