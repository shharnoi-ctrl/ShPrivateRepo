# Generated from:

- code/include/Halsuite.h (850 tokens)
- code/include/Halsuite_fw.h (23 tokens)
- code/source/Halsuite.cpp (2243 tokens)

---

# Hardware Abstraction Layer (HAL) for Vehicle Motor Control System

This document provides a comprehensive analysis of the Hardware Abstraction Layer (HAL) implementation for the Vehicle Motor Control (VMC) system. The HAL serves as the foundation for all hardware interactions in the system, providing unified access to hardware peripherals and managing various motor control interfaces.

## 1. Functional Behavior and Logic

### Singleton Pattern Implementation

The HAL is implemented as a singleton to ensure a single point of access to hardware resources:

```cpp
Halsuite& Halsuite::get_instance()
{
    static Halsuite hal; // Singleton instance
    return hal;
}
```

This pattern prevents multiple instances of hardware controllers from being created, which could lead to conflicts in hardware access. The singleton instance is created on first access and persists throughout the application lifecycle.

### Hardware Initialization and Configuration

The HAL provides specialized initialization paths for different motor types:

1. **Brushless Motor Initialization** (`init_brushless`):
   - Configures GPIO pins for driver control
   - Initializes ADC module with specified sampling order
   - Sets up PWM modules with specified frequency and deadband
   - Manages driver calibration sequence

2. **Stepper Motor Initialization** (`init_stepper`):
   - Configures GPIO pins for stepper control (disable, direction, pulse)
   - Sets up PWM modules for pulse generation
   - Configures PWM frequency and duty cycle for stepper control

### Polling Mechanisms

The HAL implements two polling methods to manage peripheral state:

1. `poll_hi()`: For high-speed peripheral polling (currently empty implementation)
2. `poll()`: For regular peripheral polling
   ```cpp
   void Halsuite::poll()
   {
       can_a.manage_rx();
       scia.step();
   }
   ```
   This handles CAN message reception and SCI (Serial Communication Interface) processing.

### Interrupt Management

The HAL provides control over the global interrupt system:

```cpp
void Halsuite::enable_global_isr()
{
    asm_eint();     // Enable Global interrupt INTM
    asm_ertm();     // Enable Global realtime interrupt DBGM
    static const Uint16 dbg_val = 1UL << 0 | // Enable real-time debug interrupt for INT1 (ADC and others)
                                  1UL << 2;  // Enable real-time debug interrupt for INT3 (PWMs)
    set_DBGIER(dbg_val);
}
```

This method enables both standard and real-time interrupts, with specific configuration for ADC and PWM interrupt channels.

## 2. Control Flow and State Transitions

### Motor Control State Management

#### Brushless Motor Control Flow

1. **Initialization Sequence**:
   - Configure GPIO pins for driver interface
   - Set initial pin states (driver disabled)
   - Apply 2ms delay for stabilization
   - Set driver gain to maximum (high)
   - Configure PWM GPIO pins (0-5)
   - Initialize ADC with specified sampling configuration
   - Initialize PWM modules with specified frequency and deadband
   - Apply 2ms delay
   - Disable DC calibration

2. **Operation State**:
   - Driver enable/disable controlled via `drv_en_gate` GPIO
   - Fault detection via `drv_fault` GPIO
   - PWM signals generated through three phase outputs (U, V, W)

#### Stepper Motor Control Flow

1. **Initialization Sequence**:
   - Configure GPIO pins for stepper interface
   - Set up PWM for pulse generation
   - Configure PWM frequency and duty cycle
   - Enable PWM output with 50% duty cycle

2. **Operation State**:
   - Direction control via `stp_dir` GPIO
   - Enable/disable via `stp_disable` GPIO (active low)
   - Step pulses generated through PWM output

## 3. Inputs and Stimuli

### Hardware Interface Inputs

| Input | Type | Processing | Effect | Location |
|-------|------|------------|--------|----------|
| `drv_fault` | GPIO Input | Monitored for driver fault condition | Indicates fault in brushless driver | `Halsuite.h:58` |
| ADC Inputs | Analog | Sampled according to configured order and frequency | Provides current/voltage feedback | `Halsuite.h:19` |
| CAN Messages | CAN Bus | Processed by `can_a.manage_rx()` | Receives control commands | `Halsuite.cpp:307` |
| SCI Data | Serial | Processed by `scia.step()` | Handles serial communication | `Halsuite.cpp:308` |
| I2C Data | I2C Bus | Managed by I2C arbiter | Communicates with I2C peripherals | `Halsuite.h:67-68` |
| SPI Data | SPI Bus | Configured for encoder interface | Reads encoder position data | `Halsuite.cpp:173-179` |

### Configuration Parameters

| Parameter | Description | Effect | Location |
|-----------|-------------|--------|----------|
| `pwm_freq` | PWM frequency | Sets the PWM switching frequency | `Halsuite.h:81` |
| `adc_div` | ADC decimation | Sets ADC sampling rate relative to PWM | `Halsuite.h:82` |
| `sampling_order` | ADC channel order | Defines sequence of ADC channel sampling | `Halsuite.h:83` |
| `deadband` | PWM deadband | Sets deadtime between complementary PWM signals | `Halsuite.cpp:260` |

## 4. Outputs and Effects

### Hardware Control Outputs

| Output | Type | Trigger | Effect | Location |
|--------|------|---------|--------|----------|
| `pwm1a`, `pwm2a`, `pwm3a` | PWM | Motor control logic | Controls brushless motor phases U, V, W | `Halsuite.h:22-24` |
| `pwm4a`, `pwm4b` | PWM | Stepper control logic | Controls stepper motor pulse generation | `Halsuite.h:26-27` |
| `drv_dc_cal` | GPIO | Initialization | Controls driver DC calibration | `Halsuite.h:31` |
| `drv_en_gate` | GPIO | Motor enable/disable | Enables/disables driver gates | `Halsuite.h:32` |
| `drv_gain` | GPIO | Initialization | Sets driver gain (0: 10V/V, 1: 40V/V) | `Halsuite.h:33` |
| `stp_disable` | GPIO | Stepper enable/disable | Enables/disables stepper driver (active low) | `Halsuite.h:36` |
| `stp_dir` | GPIO | Direction control | Sets stepper direction | `Halsuite.h:38` |
| `led_green`, `led_yellow`, `led_red` | GPIO | Status indication | Controls status LEDs | `Halsuite.h:40-42` |

## 5. Parameters and Configuration

### GPIO Configuration Constants

```cpp
static const GPIOid gpio_drv_fault   = gpio_041; // GPIO for brushless driver fault
static const GPIOid gpio_drv_dc_cal  = gpio_039; // GPIO for brushless driver dc cal
static const GPIOid gpio_drv_en_gate = gpio_040; // GPIO for brushless driver enable
static const GPIOid gpio_drv_gain    = gpio_042; // GPIO for brushless driver gain

static const GPIOid gpio_stp_disable = gpio_050; // GPIO for stepper disable
static const GPIOid gpio_stp_pulse   = gpio_007; // GPIO for stepper pulse
static const GPIOid gpio_stp_dir     = gpio_011; // GPIO for stepper dir

static const GPIOid gpio_led_green   = gpio_075; // GPIO for green led
static const GPIOid gpio_led_yellow  = gpio_079; // GPIO for yellow led
static const GPIOid gpio_led_red     = gpio_077; // GPIO for red led
```

### Communication Interface Configuration

#### SPI Configuration
```cpp
static const Uint16 spi_nbits = 16;
static const Uint32 spi_baudrate = 1400000; // 1.4MHz
static const SPIcfg spi_config(true, SPIcfg::smode2, spi_baudrate, spi_nbits);
```

#### I2C Configuration
```cpp
i2ca(Dsp28335_ent::I2Cif::id_i2c_a, Dsp28335_ent::gpio_032, Dsp28335_ent::gpio_033, Dsp28335_ent::I2Cif::i2c_400Khz)
```

#### GPIO Configuration Templates
```cpp
static const Dsp28335_ent::GPIOtun gpio_cfg_out =
{
    GPIOtun::dir_output,
    GPIOtun::pu_dis,
    GPIOmux4::mux_gpio,
    GPIOtun::qsel_async
};

static const GPIOtun gpio_in_pullen_mux1_q3 =
{
    GPIOtun::dir_input,
    GPIOtun::pu_en,
    GPIOmux4::mux_1,
    GPIOtun::qsel_3samples
};
```

## 6. Error Handling and Contingency Logic

### Fault Detection

The HAL provides a GPIO input (`drv_fault`) to monitor the brushless motor driver's fault status. This signal is active high (1 indicates normal operation).

### Initialization Safeguards

1. **Brushless Motor Initialization**:
   - Driver gates are initially disabled (`drv_en_gate.set_lo()`)
   - DC calibration is performed during initialization
   - Delays are inserted for stabilization (2ms)

2. **Stepper Motor Initialization**:
   - PWM is configured with appropriate parameters before enabling

## 7. File-by-File Breakdown

### Halsuite.h

This header file defines the `Halsuite` struct, which serves as the main HAL interface for the VMC system. It contains:

- Declarations for all hardware peripheral interfaces (ADC, PWM, GPIO, timers, communication interfaces)
- Method declarations for initialization and operation
- Singleton pattern implementation
- Type definitions and member variables for hardware access

Key components:
- ADC manager for analog sampling
- PWM suite for motor control
- GPIO interfaces for driver control and status
- Communication interfaces (SPI, CAN, SCI, I2C)
- Timer resources

### Halsuite_fw.h

A forward declaration header that simply declares the `Halsuite` class in the `VMC` namespace. This allows other files to reference the HAL without including the full implementation details.

### Halsuite.cpp

This source file implements the functionality declared in `Halsuite.h`. It contains:

- Singleton instance creation and access
- Constructor implementation with hardware initialization
- GPIO configuration for all peripherals
- Communication interface setup (SPI, CAN, SCI, I2C)
- Motor-specific initialization methods
- Polling and interrupt management implementations

Key implementation details:
- GPIO pin assignments and configurations
- Communication interface parameters
- PWM and ADC initialization sequences
- Motor driver control logic

## 8. Cross-Component Relationships

### Hardware Peripheral Integration

The HAL integrates multiple hardware subsystems:

1. **Motor Control Peripherals**:
   - ADC for current/voltage sensing
   - PWM for motor phase control
   - GPIO for driver control and status

2. **Communication Interfaces**:
   - CAN for command and control
   - SCI for tunneling/debugging
   - SPI for encoder interface
   - I2C for peripheral expansion

3. **System Management**:
   - Timer for timing control
   - GPIO for status indication (LEDs)

### Dependency Structure

```
Halsuite
├── ADC_mc (Analog-to-Digital Converter)
├── Pwmsuite (PWM management)
│   └── Pwmdev_mc (PWM device instances)
├── GPIO (General Purpose I/O)
├── Timer (System timing)
├── Communication interfaces
│   ├── CAN (Controller Area Network)
│   ├── SCI (Serial Communication Interface)
│   ├── SPI (Serial Peripheral Interface)
│   └── I2C (Inter-Integrated Circuit)
│       └── I2Carbiter (I2C bus arbitration)
└── Support utilities
    ├── Delay (Timing delays)
    └── Asm (Assembly interface)
```

## 9. Hardware Abstraction Patterns

### Peripheral Access Abstraction

The HAL provides a unified interface to hardware peripherals, abstracting the details of register-level access:

1. **GPIO Abstraction**:
   - Logical pin naming (`drv_en_gate`, `led_green`, etc.)
   - Configuration templates for common pin modes
   - High-level methods (`set_hi()`, `set_lo()`)

2. **PWM Abstraction**:
   - Frequency-based configuration
   - Duty cycle control
   - Deadband management
   - Synchronization with ADC

3. **Communication Interface Abstraction**:
   - Protocol-specific configuration
   - Polling-based management
   - Pin multiplexing handling

### Motor Type Abstraction

The HAL provides specialized initialization for different motor types:

1. **Brushless Motor Support**:
   - Three-phase PWM generation
   - Driver control and monitoring
   - ADC synchronization for current sensing

2. **Stepper Motor Support**:
   - Pulse/direction interface
   - PWM-based pulse generation
   - Enable/disable control

## Summary

The Hardware Abstraction Layer (HAL) for the Vehicle Motor Control system provides a comprehensive foundation for all hardware interactions. It implements the singleton pattern to ensure unified access to hardware peripherals and offers specialized initialization paths for different motor types (brushless and stepper motors).

The HAL manages GPIO configuration, PWM setup for motor control, ADC sampling for feedback, and various communication interfaces (CAN, SCI, SPI, I2C). It provides polling mechanisms for peripheral management and controls the global interrupt system.

The implementation carefully handles initialization sequences, including proper timing delays and state transitions, to ensure reliable hardware operation. The abstraction layer effectively isolates higher-level control logic from hardware-specific details, allowing the rest of the system to interact with peripherals through a consistent interface.