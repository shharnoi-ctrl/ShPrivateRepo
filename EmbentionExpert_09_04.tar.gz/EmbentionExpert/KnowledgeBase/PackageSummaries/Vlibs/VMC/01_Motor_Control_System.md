# Generated from:

- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/VMC/08_Hardware_Abstraction_Layer.md (3187 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/VMC/07_Encoder_System.md (3649 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/VMC/06_Angle_Management.md (4291 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/VMC/05_Mechanical_Bounds.md (3947 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/VMC/06_CAN_Communication_Base.md (3734 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/VMC/03_XPC_CAN_Suite.md (4101 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/VMC/05_Command_System.md (5298 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/VMC/04_Calibration_System.md (6218 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/VMC/03_Motor_Control_Core.md (5922 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/VMC/02_Platform_Integration.md (5555 tokens)

---

# Comprehensive Overview of the Vehicle Motor Control (VMC) System

The Vehicle Motor Control (VMC) system is a sophisticated motor control solution designed for precise control of brushless and stepper motors. This overview synthesizes the key components and their interactions to provide a holistic understanding of the system architecture, data flows, and control mechanisms.

## System Architecture

The VMC system follows a layered architecture with clear separation of concerns:

1. **Platform Integration Layer** - Orchestrates system components and provides communication infrastructure
2. **Command and Communication Layer** - Handles external interfaces and command processing
3. **Motor Control Core** - Implements field-oriented control algorithms
4. **Calibration and Configuration Layer** - Manages system tuning and parameter management
5. **Angle Management Layer** - Handles coordinate transformations and position tracking
6. **Hardware Abstraction Layer** - Provides unified access to hardware peripherals

### Key Components and Their Interactions

```
┌─────────────────────────────────────────────────────────────────────┐
│                      Platform Integration                           │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐ │
│  │  Vmcsuite   │──│ Xpcu8suite  │──│ Mediasuite  │──│ System Status│ │
│  └─────────────┘  └─────────────┘  └─────────────┘  └─────────────┘ │
└───────────┬─────────────────────────────────┬───────────────────────┘
            │                                 │
┌───────────▼─────────────────────────────────▼───────────────────────┐
│                  Command and Communication                          │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐ │
│  │ Command Sys │──│  Mcanrx     │──│ Xpccansuite │──│ CAN Config  │ │
│  └─────────────┘  └─────────────┘  └─────────────┘  └─────────────┘ │
└───────────┬─────────────────────────────────┬───────────────────────┘
            │                                 │
┌───────────▼─────────────────────────────────▼───────────────────────┐
│                      Motor Control Core                             │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐ │
│  │Control_foc  │──│ Clarke/Park │──│ PI Control  │──│ Space Vector│ │
│  └─────────────┘  └─────────────┘  └─────────────┘  └─────────────┘ │
└───────────┬─────────────────────────────────┬───────────────────────┘
            │                                 │
┌───────────▼─────────────────────────────────▼───────────────────────┐
│                Calibration and Configuration                        │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐ │
│  │  Polecal    │──│ Current Cal │──│ Stepper Cal │──│ Config Mgmt │ │
│  └─────────────┘  └─────────────┘  └─────────────┘  └─────────────┘ │
└───────────┬─────────────────────────────────┬───────────────────────┘
            │                                 │
┌───────────▼─────────────────────────────────▼───────────────────────┐
│                     Angle Management                                │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐ │
│  │   Encoder   │──│   Eangle    │──│   Mangle    │──│   Mbounds   │ │
│  └─────────────┘  └─────────────┘  └─────────────┘  └─────────────┘ │
└───────────┬─────────────────────────────────┬───────────────────────┘
            │                                 │
┌───────────▼─────────────────────────────────▼───────────────────────┐
│                  Hardware Abstraction Layer                         │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐ │
│  │    ADC      │──│    PWM      │──│    GPIO     │──│  Comms I/F  │ │
│  └─────────────┘  └─────────────┘  └─────────────┘  └─────────────┘ │
└─────────────────────────────────────────────────────────────────────┘
```

## Data Flow Analysis

### Sensor Data Flow

1. **Position Feedback Path**:
   - Encoder hardware provides position data via SPI
   - `Encoder` class reads and validates data using CRC7
   - `Eangle` converts raw encoder values to electrical angles
   - `Mangle` converts raw encoder values to mechanical angles
   - `Control_foc_enc` uses these angles for field-oriented control

2. **Current Feedback Path**:
   - ADC samples phase currents
   - `Control_foc_enc` processes current measurements
   - Clarke transform converts three-phase currents to two-phase stationary frame
   - Park transform converts stationary frame to rotating frame (d-q)
   - Current controllers use d-q currents for field-oriented control

### Command Flow

1. **External Command Path**:
   - Commands arrive via CAN bus
   - `Mcanrx` provides thread-safe reception
   - `Ccmd` and derived classes deserialize commands
   - `Control_foc_enc` executes appropriate control mode
   - Control outputs are generated based on command type

2. **Control Cascade Path**:
   - Position commands generate velocity setpoints
   - Velocity commands generate current setpoints
   - Current commands generate voltage commands
   - Voltage commands are converted to PWM signals

### Configuration Flow

1. **Configuration Reception**:
   - Configuration messages arrive via communication system
   - `Mediasuite` processes configuration messages
   - Configuration is applied to system components
   - Components update behavior based on new configuration

2. **Calibration Flow**:
   - Calibration commands trigger specific procedures
   - `Polecal` performs electrical angle calibration
   - Current calibration determines sensor offsets
   - Stepper calibration determines step-to-angle ratio
   - Calibration results are stored in system configuration

## Key Design Patterns and Mechanisms

### 1. Singleton Pattern

The Hardware Abstraction Layer uses the singleton pattern to ensure a single point of access to hardware resources:

```cpp
Halsuite& Halsuite::get_instance()
{
    static Halsuite hal; // Singleton instance
    return hal;
}
```

This prevents multiple instances from conflicting when accessing hardware peripherals.

### 2. Thread Safety Mechanisms

The CAN communication system implements sophisticated thread safety for message reception:

```cpp
bool Mcanrx::write(const Base::CANframe& data) {
    // Acquire write lock
    Type_frame_sync::Wrsafe wr(frame_sync);
    // Serialize data into protected buffer
    // ...
    // Lock automatically released by RAII
    return true;
}
```

This ensures data integrity when multiple threads access shared resources.

### 3. State Machine Pattern

Multiple components use state machines for complex behaviors:

1. **Electrical Angle Calibration**:
   ```cpp
   switch(st)
   {
       case st_idle:
           // Initialize calibration
           break;
       case st_wait:
           // Wait for position stabilization
           break;
       case st_limit_low:
           // Search for lower mechanical limit
           break;
       // Additional states...
   }
   ```

2. **CAN Communication**:
   ```cpp
   switch(st)
   {
       case st_com:
           // Process communication manager messages
           break;
       case st_ext:
           // Process external serial port messages
           break;
       case st_fmsg:
           // Process custom field messages
           break;
   }
   ```

### 4. Cascaded Control Architecture

The motor control system implements a cascaded control architecture:

```
Position Control → Velocity Control → Current Control → Voltage Control → PWM Generation
```

Each controller in the cascade generates setpoints for the next controller, allowing for precise control at multiple levels.

### 5. Observer Pattern

The variable management system implements an observer pattern for system monitoring:

```cpp
vmap.rvars.get(Base::v_mangle) = mangle1.get_angle();
vmap.rvars.get(Base::v_eangle) = eangle1.get_angle();
vmap.rvars.get(Base::v_mangle_rate) = speed1.get_speed();
```

This allows multiple components to observe system state without tight coupling.

## Safety Mechanisms

### 1. Mechanical Bounds Protection

The `Mbounds` class prevents motor movement beyond mechanical limits:

```cpp
Real Mbounds::step_bounded(Real& anglec, Real angle)
{
    mang.convert(rng_raw, rng_mang);
    anglec = rng_mang.wrap(anglec);  // Constrain command to bounds
    return Rfun::wrap2pi(anglec - rng_mang.center) - Rfun::wrap2pi(angle - rng_mang.center);
}
```

This protects against physical damage by constraining commands to safe ranges.

### 2. Overcurrent Protection

The motor control system implements overcurrent protection:

```cpp
bool Control_foc_enc::check_health()
{
    bool ret = true;
    // Overcurrent protection
    if(Rmath::fabsr(park1.qs) > max_iq)
    {
        if (ovrcrt_to.expired())
        {
            ret = false;
        }
    }
    else
    {
        ovrcrt_to.start();
    }
    return ret;
}
```

This prevents motor damage by detecting and responding to excessive current.

### 3. Command Validation

The command system validates incoming commands and defaults to safe states:

```cpp
default:
{
    Bsp::warning();  // Issue warning
    cmd.sch = Ccmd::sch_off;  // Default to motor off (safe state)
    break;
}
```

This ensures that invalid commands don't cause unexpected behavior.

### 4. Fault Detection

The system monitors hardware faults and responds appropriately:

```cpp
vmap.bvars.get(Base::kbit_bl_fault) = drv_fault.get();
vmap.bvars.get(Base::kbit_health) = health && drv_fault.get();
```

This allows the system to detect and respond to hardware failures.

## Configuration Capabilities

### 1. Motor Type Configuration

The system supports both brushless and stepper motors:

```cpp
void Halsuite::init_brushless()
{
    // Configure GPIO pins for brushless driver
    // Initialize ADC for current sensing
    // Configure PWM for three-phase control
}

void Halsuite::init_stepper()
{
    // Configure GPIO pins for stepper control
    // Configure PWM for pulse generation
}
```

This flexibility allows the system to control different motor types with the same software.

### 2. Control Parameter Tuning

The system supports tuning of control parameters:

```cpp
void Control_foc_enc::cset(Base::Lossy_error& str)
{
    pi_id.cset(str);
    pi_iq.cset(str);
    pi_spd.cset(str);
    pi_pos.cset(str);
    str.get_float(time_ovrcurrent);
    str.get_float(max_iq);
}
```

This allows optimization of control performance for different applications.

### 3. Mechanical Limits Configuration

The system supports configuration of mechanical limits:

```cpp
void Mbounds::set_raw_minmax(Real angle_min, Real angle_max)
{
    rng_raw.set_minmax(angle_min, angle_max);
}

void Mbounds::set_unbounded()
{
    rng_raw.set_unbounded();
}
```

This allows adaptation to different mechanical systems with varying range of motion.

### 4. Communication Configuration

The system supports configuration of communication parameters:

```cpp
void Mcancfg::cset(Base::Lossy_error& str)
{
    str.get_uint32(br);
    scia.cset(str);
    com.cset(str);
    mcmd_rx_id.cset(str);
    str.get_uint16(mcmd_rx_size);
}
```

This allows adaptation to different communication environments and requirements.

## Conclusion

The Vehicle Motor Control (VMC) system is a comprehensive solution for precise motor control, featuring:

1. **Layered Architecture** - Clear separation of concerns with specialized components for each aspect of motor control
2. **Field-Oriented Control** - Advanced control algorithm for efficient and precise brushless motor control
3. **Flexible Configuration** - Support for different motor types, control parameters, and mechanical constraints
4. **Robust Communication** - Thread-safe CAN communication with multiple channels and protocols
5. **Comprehensive Safety** - Protection against mechanical damage, overcurrent, and invalid commands
6. **Sophisticated Calibration** - Automated procedures for electrical angle, current sensing, and stepper motor calibration

The system's modular design, robust safety mechanisms, and flexible configuration capabilities make it a versatile and reliable solution for a wide range of motor control applications. The integration of hardware abstraction, angle management, field-oriented control, and communication infrastructure creates a cohesive system that achieves precise motor control while maintaining adaptability to different hardware configurations and application requirements.