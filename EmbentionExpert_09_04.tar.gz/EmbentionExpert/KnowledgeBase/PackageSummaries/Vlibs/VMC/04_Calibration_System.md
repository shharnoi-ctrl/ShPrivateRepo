# Generated from:

- code/include/Ccmd_cal_eangle.h (227 tokens)
- code/include/Ccmd_cal_eangle_fw.h (28 tokens)
- code/include/Ccmd_cal_iphase.h (162 tokens)
- code/include/Ccmd_cal_stp.h (163 tokens)
- code/include/Polecal.h (1107 tokens)
- code/source/Ccmd_cal_eangle.cpp (129 tokens)
- code/source/Ccmd_cal_iphase.cpp (89 tokens)
- code/source/Ccmd_cal_stp.cpp (113 tokens)
- code/source/Polecal.cpp (1917 tokens)

## With context from:

- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/VMC/05_Command_System.md (5298 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/VMC/06_Angle_Management.md (4291 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/VMC/05_Mechanical_Bounds.md (3947 tokens)

---

# VMC Calibration System Analysis

This document provides a comprehensive analysis of the calibration system for the VMC (Vehicle Motor Control) system, focusing on electrical angle calibration, current sensing calibration, and stepper motor calibration procedures.

## 1. Functional Behavior and Logic

### Calibration System Overview

The VMC calibration system consists of three main calibration procedures:

1. **Electrical Angle Calibration (`Polecal` class)**:
   - Determines the relationship between mechanical and electrical angles
   - Calculates the number of pole pairs in the motor
   - Detects mechanical bounds if present
   - Computes the electrical angle offset for proper field-oriented control

2. **Current Sensing Calibration (`Ccmd_cal_iphase` struct)**:
   - Calibrates the phase current sensing system
   - Determines bias values for accurate current measurement

3. **Stepper Motor Calibration (`Ccmd_cal_stp` struct)**:
   - Calibrates the relationship between mechanical angle and stepper motor pulses
   - Determines the step-to-angle ratio for precise position control

### Electrical Angle Calibration Flow

The `Polecal` class implements a sophisticated state machine for electrical angle calibration:

1. **Initialization** (`st_idle` → `st_wait`):
   - Reset angle coverage tracking
   - Initialize electrical angle reference to 0
   - Wait for position stabilization

2. **Lower Limit Search** (`st_wait` → `st_limit_low`):
   - Rotate the motor in one direction
   - Track angle coverage
   - If a complete turn is achieved without finding a limit:
     - Mark system as unbounded
     - Calculate pole pairs
     - Proceed to electrical angle offset calibration
   - If angle coverage stops increasing for a timeout period:
     - Mark a mechanical limit found
     - Proceed to upper limit search

3. **Upper Limit Search** (`st_limit_low` → `st_limit_hgh`):
   - Reverse motor rotation direction
   - Track angle coverage
   - When angle coverage stops increasing for a timeout period:
     - Calculate mechanical bounds with margins
     - Proceed to pole pair calculation

4. **Pole Pair Calculation** (for bounded systems):
   - **Synchronization** (`st_limit_hgh` → `st_poles_sync`):
     - Reverse direction
     - Move until inside bounds
   - **Pole Pair Measurement** (`st_poles_sync` → `st_poles`):
     - Track angle coverage until reaching a bound
     - Calculate pole pairs based on electrical angle covered vs. mechanical angle covered

5. **Electrical Angle Offset Calibration**:
   - **First Sample** (`st_poles` → `st_eangle0`):
     - Reverse direction
     - Move to a position inside bounds
     - Take first sample of electrical angle offset
   - **Mean Calculation** (`st_eangle0` → `st_eangle`):
     - Reset angle coverage tracking
     - Collect multiple samples of electrical angle offset
     - Calculate mean offset
     - Apply calibration to the electrical angle system

### Current Sensing Calibration Parameters

The `Ccmd_cal_iphase` struct defines parameters for current sensing calibration:

```cpp
struct Ccmd_cal_iphase {
    Real twait;  // Time waiting for current stabilization
    Real tcal;   // Time calibrating
};
```

This calibration procedure involves:
1. Waiting for current stabilization (`twait`)
2. Collecting current samples over a period (`tcal`)
3. Computing bias values for accurate current measurement

### Stepper Motor Calibration Parameters

The `Ccmd_cal_stp` struct defines parameters for stepper motor calibration:

```cpp
struct Ccmd_cal_stp {
    Real tcal;      // Calibration time
    Real freq_ref;  // Reference output pulse frequency
};
```

This calibration procedure involves:
1. Generating pulses at a reference frequency (`freq_ref`)
2. Measuring the resulting mechanical angle change over time (`tcal`)
3. Computing the step-to-angle ratio

## 2. Control Flow and State Transitions

### Electrical Angle Calibration State Machine

| State | Description | Entry Condition | Actions | Exit Condition | Next State |
|-------|-------------|-----------------|---------|----------------|------------|
| `st_idle` | Initialization | `reset()` called | Reset angle coverage, set reference to 0 | Immediate | `st_wait` |
| `st_wait` | Position stabilization | From `st_idle` | Wait for position to stabilize | `clk.toc() > cmd.twait` | `st_limit_low` |
| `st_limit_low` | Lower limit search | From `st_wait` | Rotate motor, track angle coverage | Complete turn without limit | `st_eangle0` |
| `st_limit_low` | Lower limit search | From `st_wait` | Rotate motor, track angle coverage | Timeout with no coverage change | `st_limit_hgh` |
| `st_limit_hgh` | Upper limit search | From `st_limit_low` | Rotate motor in opposite direction, track angle coverage | Timeout with no coverage change | `st_poles_sync` |
| `st_poles_sync` | Synchronization | From `st_limit_hgh` | Rotate motor, move inside bounds | Inside bounds | `st_poles` |
| `st_poles` | Pole pair calculation | From `st_poles_sync` | Track angle coverage | Outside bounds | `st_eangle0` |
| `st_eangle0` | First offset sample | From `st_poles` or `st_limit_low` | Take first sample of electrical angle offset | Inside bounds | `st_eangle` |
| `st_eangle` | Mean offset calculation | From `st_eangle0` | Collect offset samples, calculate mean | Complete turn or outside bounds | `st_idle` |

### Angle Coverage Tracking

The `Angle_cov` struct tracks angle coverage with the following state transitions:

| State | Trigger | Actions | Next State |
|-------|---------|---------|------------|
| Initial | `reset(angle_in)` | Set initial angle, reset coverage tracking | Tracking |
| Tracking | `step(angle_in)` | Update covered angle, track min/max coverage | Tracking |
| Tracking | `step(angle_in)` returns true | Complete turn detected | Complete |

## 3. Inputs and Stimuli

### Electrical Angle Calibration Inputs

| Input | Processing | Effect | Location |
|-------|------------|--------|----------|
| `cmd.twait` | Used as timeout threshold | Determines stabilization time | `Polecal.cpp:127` |
| `cmd.svgen_module` | Used for motor control | Sets voltage magnitude during calibration | `Ccmd_cal_eangle.h:14` |
| `cmd.eangle_rate_ref` | Multiplied by `rt_period` | Determines rotation speed during calibration | `Polecal.cpp:129` |
| `cmd.bounds_margin` | Applied to detected bounds | Sets safety margin for mechanical bounds | `Polecal.cpp:196` |
| `enc.get_angle_raw()` | Used for angle tracking | Provides mechanical angle feedback | Multiple locations |
| `rt_period` | Multiplied by rate reference | Determines step size for angle reference | `Polecal.cpp:129` |

### Current Sensing Calibration Inputs

| Input | Processing | Effect | Location |
|-------|------------|--------|----------|
| `twait` | Used as timeout threshold | Determines current stabilization time | `Ccmd_cal_iphase.h:12` |
| `tcal` | Used as calibration duration | Determines sampling period for calibration | `Ccmd_cal_iphase.h:13` |

### Stepper Motor Calibration Inputs

| Input | Processing | Effect | Location |
|-------|------------|--------|----------|
| `tcal` | Used as calibration duration | Determines measurement period | `Ccmd_cal_stp.h:12` |
| `freq_ref` | Used for pulse generation | Sets reference pulse frequency | `Ccmd_cal_stp.h:13` |

## 4. Outputs and Effects

### Electrical Angle Calibration Outputs

| Output | Description | Calculation | Location |
|--------|-------------|-------------|----------|
| Pole pairs | Number of electrical cycles per mechanical revolution | `eangle_ref / raw_angle_cov.covered` | `Polecal.cpp:153`, `Polecal.cpp:213` |
| Electrical angle offset | Calibration offset for electrical angle | `eangle_cal.getmean() + eangle_cal0` | `Polecal.cpp:242` |
| Mechanical bounds | Detected mechanical limits with margins | `raw_angle_cov.initial + raw_angle_cov.covered_min/max ± margins` | `Polecal.cpp:197-204` |
| Electrical angle reference | Angle to be set during calibration | Updated by `ref_next()` | `Polecal.cpp:137` |

### Current Sensing Calibration Effects

The current sensing calibration procedure affects:
- Bias values for current sensing channels
- Accuracy of current measurement
- Performance of current control loops

### Stepper Motor Calibration Effects

The stepper motor calibration procedure affects:
- Step-to-angle ratio for stepper motor control
- Accuracy of position control using stepper motors
- Synchronization between step commands and mechanical movement

## 5. Parameters and Configuration

### Electrical Angle Calibration Parameters

| Parameter | Description | Default | Location |
|-----------|-------------|---------|----------|
| `twait` | Time to wait for position stabilization | 1.5 seconds | `Ccmd_cal_eangle.cpp:8` |
| `svgen_module` | Module used as input for SVGen module | 0.5 | `Ccmd_cal_eangle.cpp:9` |
| `eangle_rate_ref` | Electrical angle rate during calibration | 0.6 rad/s | `Ccmd_cal_eangle.cpp:10` |
| `bounds_margin` | Angle margin to detected bounds | 0 | `Ccmd_cal_eangle.cpp:11` |
| `cov_max` | Threshold for complete turn detection | 2π × 1.1 | `Polecal.cpp:9` |
| `cov_timeout` | Time threshold for limit detection | 2 seconds | `Polecal.cpp:11` |

### Current Sensing Calibration Parameters

| Parameter | Description | Default | Location |
|-----------|-------------|---------|----------|
| `twait` | Time waiting for current stabilization | 1.5 seconds | `Ccmd_cal_iphase.cpp:8` |
| `tcal` | Time calibrating | 2 seconds | `Ccmd_cal_iphase.cpp:9` |

### Stepper Motor Calibration Parameters

| Parameter | Description | Default | Location |
|-----------|-------------|---------|----------|
| `tcal` | Calibration time | 10 seconds | `Ccmd_cal_stp.cpp:8` |
| `freq_ref` | Reference output pulse frequency | 50 Hz | `Ccmd_cal_stp.cpp:7` |

## 6. Error Handling and Contingency Logic

### Mechanical Bounds Detection and Handling

The electrical angle calibration procedure includes sophisticated logic for detecting and handling mechanical bounds:

1. **Bounds Detection**:
   - If angle coverage stops increasing for `cov_timeout` seconds, a mechanical limit is detected
   - Both lower and upper limits are detected by rotating in both directions

2. **Bounds Configuration**:
   - If bounds are detected, they are configured with user-specified margins
   - If margins exceed the total detected range, a single-angle bound is configured
   - Runtime assertions verify that bounds are valid

3. **Unbounded Configuration**:
   - If a complete turn is achieved without finding limits, the system is marked as unbounded

```cpp
if(clk.toc() > cov_timeout) // mechanical limit reached
{
    // compute limits
    Real bound_delta_half = raw_angle_cov.get_delta() * Const::ONEHALF;
    Real bounds_margin = Rfun::max<Real>(cmd.bounds_margin, 0);
    Base::Assertions::runtime((bound_delta_half < Const::PI));
    if(Base::Assertions::runtime(bounds_margin < bound_delta_half))
    {
        bounds.set_raw_minmax(
                raw_angle_cov.initial + raw_angle_cov.covered_min + bounds_margin,
                raw_angle_cov.initial + raw_angle_cov.covered_max - bounds_margin);
    }
    else // margins exceed total detected range
    {
        bounds.set_raw_single_angle(Rfun::wrap2pi(raw_angle_cov.initial +
                Const::ONEHALF * (raw_angle_cov.covered_min + raw_angle_cov.covered_max)));
    }
    // inits for poles computation
    raw_angle_cov.reset(enc.get_angle_raw());
    invert_turn();
    st = st_poles_sync;
}
```

### Angle Wrapping and Normalization

The calibration system uses angle wrapping to ensure proper handling of angle values:

1. **Angle Coverage Tracking**:
   - The `Angle_cov::step` method uses `Rfun::wrap2pi` to handle angle wrapping when computing coverage
   - This ensures accurate tracking even when crossing the 0/2π boundary

2. **Electrical Angle Offset Calculation**:
   - The offset is calculated using wrapped differences to handle the circular nature of angles
   - The first sample is taken separately to ensure the mean calculation works correctly

```cpp
eangle_cal.addnewsample(Rfun::wrap2pi(eang.get_angle() - eangle_ref - eangle_cal0)); // should be ~0
```

### Runtime Assertions

The calibration system includes runtime assertions to verify critical conditions:

```cpp
Base::Assertions::runtime((bound_delta_half < Const::PI));
if(Base::Assertions::runtime(bounds_margin < bound_delta_half))
{
    // Configure bounds with margins
}
else
{
    // Fall back to single-angle bound
}
```

These assertions ensure that:
1. The detected bounds span less than 180 degrees (half circle)
2. The specified margins are smaller than half the detected range

## 7. File-by-File Breakdown

### Ccmd_cal_eangle.h / Ccmd_cal_eangle.cpp

These files define the command parameters for brushless electrical angle calibration:

- `Ccmd_cal_eangle` struct with parameters for calibration
- Default constructor initializing parameters to sensible defaults
- `cset` method for deserializing command parameters from a binary stream

The parameters include:
- `twait`: Time to wait for position stabilization
- `svgen_module`: Module used as input for SVGen module
- `eangle_rate_ref`: Electrical angle rate during calibration
- `bounds_margin`: Angle margin to detected bounds

### Ccmd_cal_iphase.h / Ccmd_cal_iphase.cpp

These files define the command parameters for current sensing bias calibration:

- `Ccmd_cal_iphase` struct with parameters for calibration
- Default constructor initializing parameters to sensible defaults
- `cset` method for deserializing command parameters from a binary stream

The parameters include:
- `twait`: Time waiting for current stabilization
- `tcal`: Time calibrating

### Ccmd_cal_stp.h / Ccmd_cal_stp.cpp

These files define the command parameters for stepper motor calibration:

- `Ccmd_cal_stp` struct with parameters for calibration
- Default constructor initializing parameters to sensible defaults
- `cset` method for deserializing command parameters from a binary stream

The parameters include:
- `tcal`: Calibration time
- `freq_ref`: Reference output pulse frequency

### Polecal.h / Polecal.cpp

These files implement the electrical angle calibration procedure:

- `Polecal` class with state machine for calibration
- `Angle_cov` helper struct for tracking angle coverage
- Methods for state transitions, angle reference generation, and calibration calculations

The class includes:
- State enumeration defining the calibration state machine
- Constructor taking command parameters, encoder, electrical angle, and bounds references
- `step` method implementing the state machine logic
- `reset` method to initialize the calibration procedure
- `get_eangle_ref` method to provide the electrical angle reference during calibration

## 8. Cross-Component Relationships

### Integration with Command System

The calibration system integrates with the command system through the command parameter structures:

1. **Command Schemes**:
   - The command system defines schemes for different calibration procedures:
     - `sch_cal_iphase`: Current sensing calibration
     - `sch_cal_elec`: Electrical angle calibration
     - `sch_cal_stp`: Stepper motor calibration

2. **Command Parameters**:
   - Each calibration procedure has its own parameter structure:
     - `Ccmd_cal_eangle`: Parameters for electrical angle calibration
     - `Ccmd_cal_iphase`: Parameters for current sensing calibration
     - `Ccmd_cal_stp`: Parameters for stepper motor calibration

3. **Command Processing**:
   - The command system deserializes calibration commands and passes parameters to the appropriate calibration procedure
   - The `cset` methods in each parameter structure handle deserialization

### Integration with Angle Management System

The electrical angle calibration procedure integrates closely with the angle management system:

1. **Electrical Angle Updates**:
   - The calibration procedure updates the electrical angle system with:
     - Pole pair count: `eang.set_pole_pairs(Rfun::roundf(eangle_ref / raw_angle_cov.covered))`
     - Angle calibration offset: `eang.set_angle_cal(eangle_cal.getmean() + eangle_cal0)`

2. **Mechanical Angle Feedback**:
   - The calibration procedure uses the encoder system for mechanical angle feedback:
     - `enc.get_angle_raw()` provides the raw mechanical angle

3. **Angle Conversion**:
   - The calibration procedure calculates the relationship between mechanical and electrical angles:
     - Pole pairs represent the ratio of electrical to mechanical angles

### Integration with Mechanical Bounds System

The electrical angle calibration procedure integrates with the mechanical bounds system:

1. **Bounds Detection**:
   - The calibration procedure detects mechanical bounds by monitoring angle coverage
   - When limits are detected, bounds are configured with user-specified margins

2. **Bounds Configuration**:
   - The calibration procedure configures the bounds system with detected limits:
     - `bounds.set_raw_minmax(min, max)` for range bounds
     - `bounds.set_raw_single_angle(center)` for single-angle bounds
     - `bounds.set_unbounded()` for unbounded systems

3. **Bounds Checking**:
   - The calibration procedure uses the bounds system to check if angles are within bounds:
     - `bounds.is_raw_inside(enc.get_angle_raw())` checks if the current angle is within bounds

## 9. Calibration Procedure Details

### Electrical Angle Calibration Procedure

The electrical angle calibration procedure follows these steps:

1. **Initialization**:
   - Reset angle coverage tracking
   - Initialize electrical angle reference to 0
   - Wait for position stabilization (`twait` seconds)

2. **Bounds Detection**:
   - Rotate the motor in one direction
   - Track angle coverage
   - If a complete turn is achieved without finding a limit:
     - Mark system as unbounded
     - Calculate pole pairs
     - Proceed to electrical angle offset calibration
   - If angle coverage stops increasing for a timeout period:
     - Mark a mechanical limit found
     - Reverse direction and find the opposite limit
     - Calculate bounds with margins

3. **Pole Pair Calculation**:
   - For unbounded systems:
     - Calculate pole pairs as the ratio of electrical angle covered to mechanical angle covered
   - For bounded systems:
     - Move to a position inside bounds
     - Track angle coverage until reaching a bound
     - Calculate pole pairs as the ratio of electrical angle covered to mechanical angle covered

4. **Electrical Angle Offset Calibration**:
   - Take first sample of electrical angle offset
   - Collect multiple samples while moving
   - Calculate mean offset
   - Apply calibration to the electrical angle system

### Angle Coverage Tracking

The `Angle_cov` struct tracks angle coverage with the following logic:

1. **Initialization**:
   ```cpp
   void Angle_cov::reset(Real angle_in)
   {
       initial = Rfun::wrap2pi(angle_in);
       angle_in_prv = initial;
       covered = 0;
       covered_min = 0;
       covered_max = 0;
   }
   ```

2. **Coverage Tracking**:
   ```cpp
   bool Angle_cov::step(Real angle_in)
   {
       covered += Rfun::wrap2pi(angle_in - angle_in_prv);
       covered_min = Rfun::min<Real>(covered, covered_min);
       covered_max = Rfun::max<Real>(covered, covered_max);
       angle_in_prv = angle_in;
       return (fabs(covered) > cov_max);
   }
   ```

3. **Delta Calculation**:
   ```cpp
   Real Angle_cov::get_delta() const
   {
       return covered_max - covered_min;
   }
   ```

This tracking mechanism handles angle wrapping correctly and detects when a complete turn has been achieved.

### Electrical Angle Reference Generation

The electrical angle reference is generated incrementally during calibration:

```cpp
void Polecal::ref_next()
{
    // advance reference
    eangle_ref += eangle_rate_ref_step;
}
```

The reference is used to:
1. Control the motor during calibration
2. Calculate the electrical angle offset
3. Determine the number of pole pairs

### Direction Reversal

The calibration procedure includes logic to reverse the direction of rotation:

```cpp
inline void Polecal::invert_turn()
{
    eangle_rate_ref_step = -eangle_rate_ref_step;
}
```

This is used when:
1. A mechanical limit is detected, to find the opposite limit
2. After pole pair calculation, to move back inside bounds for offset calibration

## 10. Calibration Results Application

### Pole Pair Configuration

The calibration procedure configures the electrical angle system with the calculated pole pairs:

```cpp
eang.set_pole_pairs(Rfun::roundf(eangle_ref / raw_angle_cov.covered));
```

This establishes the relationship between mechanical and electrical angles, which is essential for field-oriented control.

### Electrical Angle Offset Configuration

The calibration procedure configures the electrical angle system with the calculated offset:

```cpp
eang.set_angle_cal(eangle_cal.getmean() + eangle_cal0);
```

This offset ensures that the electrical angle is correctly aligned with the rotor position, which is critical for optimal torque production.

### Mechanical Bounds Configuration

The calibration procedure configures the mechanical bounds system with the detected limits:

```cpp
bounds.set_raw_minmax(
        raw_angle_cov.initial + raw_angle_cov.covered_min + bounds_margin,
        raw_angle_cov.initial + raw_angle_cov.covered_max - bounds_margin);
```

These bounds prevent the motor from moving beyond its mechanical limits, protecting against physical damage.

## Summary

The VMC calibration system provides comprehensive procedures for calibrating electrical angles, current sensing, and stepper motors. The electrical angle calibration procedure is particularly sophisticated, implementing a state machine that detects mechanical bounds, calculates pole pairs, and determines the electrical angle offset.

The calibration system integrates closely with the command system, angle management system, and mechanical bounds system to ensure accurate motor control. The electrical angle calibration procedure is especially important as it establishes the relationship between mechanical and electrical angles, which is essential for field-oriented control.

Key features of the calibration system include:
1. Sophisticated state machine for electrical angle calibration
2. Automatic detection of mechanical bounds with configurable margins
3. Accurate calculation of pole pairs for different motor types
4. Precise determination of electrical angle offset for optimal torque production
5. Robust angle coverage tracking with proper handling of angle wrapping
6. Integration with multiple subsystems for comprehensive calibration

The calibration system ensures that the VMC system can accurately control motors with different characteristics and mechanical constraints, providing a solid foundation for reliable and efficient motor control.

## Referenced Context Files

The analysis was informed by the following context files:

1. **Command System**:
   - Provided insights into the command schemes for different calibration procedures
   - Explained how calibration commands are processed and parameters are deserialized

2. **Angle Management System**:
   - Provided information about the `Eangle` and `Mangle` classes
   - Explained how electrical and mechanical angles are processed
   - Detailed the relationship between mechanical and electrical angles

3. **Mechanical Bounds System**:
   - Provided information about the `Mbounds` class
   - Explained how mechanical bounds are configured and enforced
   - Detailed the integration with the angle management system

These context files helped understand how the calibration system integrates with the broader VMC system, particularly the command system, angle management system, and mechanical bounds system.