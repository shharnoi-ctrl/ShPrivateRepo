# Generated from:

- code/include/Mbounds.h (707 tokens)
- code/include/Mbounds_fw.h (22 tokens)
- code/source/Mbounds.cpp (184 tokens)

## With context from:

- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/VMC/06_Angle_Management.md (4291 tokens)

---

# Mechanical Bounds Management System

This document provides a comprehensive analysis of the mechanical bounds management system that ensures motor angles stay within configured limits. The system is implemented through the `Mbounds` class, which manages angle ranges, applies bounds to movement commands, and handles angle wrapping.

## 1. Functional Behavior and Logic

### Mechanical Bounds System Overview

The `Mbounds` class is responsible for:

1. **Defining and enforcing mechanical limits** for motor movement
2. **Checking if angles are within bounds**
3. **Calculating shortest path errors** between desired and measured angles while respecting mechanical limits
4. **Converting between raw and mechanical angle ranges**

The class works closely with the `Mangle` class (from the Angle Management System) to handle the conversion between raw encoder angles and mechanical angles.

### Core Functionality

The `Mbounds` class provides several key functions:

1. **Setting mechanical limits** through three different methods:
   - `set_raw_minmax`: Sets bounds as a range from minimum to maximum raw angle
   - `set_unbounded`: Removes all mechanical limits
   - `set_raw_single_angle`: Sets bounds as a single center angle

2. **Bounds checking**:
   - `has_bounds`: Checks if mechanical limits are configured
   - `is_raw_inside`: Checks if a raw angle is within the configured bounds

3. **Movement command processing**:
   - `step`: Calculates the shortest path error between desired and measured angles while respecting mechanical limits
   - Modifies the desired angle (`anglec`) if it's outside the bounds

### Bounds Configuration Flow

The `Mbounds` class maintains two angle ranges:
- `rng_raw`: Range for raw encoder angles
- `rng_mang`: Range for mechanical angles

When bounds are configured:
1. The raw angle range is set directly using methods like `set_raw_minmax`
2. The mechanical angle range is derived from the raw range using the `convert` method of the associated `Mangle` object

```cpp
void Mbounds::set_raw_minmax(Real angle_min, Real angle_max)
{
    rng_raw.set_minmax(angle_min, angle_max);
}
```

### Step Processing Flow

The `step` method is the core of the bounds management system:

1. Determines if bounds are configured using `has_bounds()`
2. If bounds exist, calls `step_bounded` to calculate error while respecting limits
3. If no bounds exist, calls `step_unbounded` for simple angle difference calculation
4. Returns the shortest path error between desired and measured angles

```cpp
Real Mbounds::step(Real& anglec, Real angle)
{
    return (rng_raw.has_bounds()) ? step_bounded(anglec, angle) : step_unbounded(anglec, angle);
}
```

### Bounded Step Processing

When bounds are configured, the `step_bounded` method:

1. Converts the raw angle range to mechanical angle range using the `Mangle` object
2. Wraps the desired angle (`anglec`) to ensure it stays within the mechanical angle range
3. Calculates the shortest path error by:
   - Centering both angles around the range center
   - Computing the difference between the centered angles

```cpp
Real Mbounds::step_bounded(Real& anglec, Real angle)
{
    // Configuration internally is in encoder raw angle units to avoid dependency on mechanical
    // angle calibration settings (avoid that a change in that configurable affects this).
    mang.convert(rng_raw, rng_mang);
    anglec = rng_mang.wrap(anglec);
    return Rfun::wrap2pi(anglec - rng_mang.center) - Rfun::wrap2pi(angle - rng_mang.center);
}
```

### Unbounded Step Processing

When no bounds are configured, the `step_unbounded` method simply calculates the shortest path error between the desired and measured angles:

```cpp
Real Mbounds::step_unbounded(Real anglec, Real angle)
{
    return Rfun::wrap2pi(anglec-angle);
}
```

## 2. Control Flow and State Transitions

### Bounds Configuration Flow

| State | Trigger | Actions | Next State | Location |
|-------|---------|---------|------------|----------|
| Any | `set_raw_minmax(angle_min, angle_max)` | Configure raw angle range with min/max values | Bounded | `Mbounds.h:33` |
| Any | `set_unbounded()` | Remove all mechanical limits | Unbounded | `Mbounds.h:35` |
| Any | `set_raw_single_angle(center)` | Configure raw angle range with single center value | Bounded (single point) | `Mbounds.h:61` |
| Any | `cset(str)` | Deserialize configuration for raw angle range | Depends on config | `Mbounds.cpp:34` |

### Step Processing Flow

| State | Trigger | Actions | Next State | Location |
|-------|---------|---------|------------|----------|
| Bounded | `step(anglec, angle)` | Convert ranges, wrap desired angle, calculate error | Same | `Mbounds.cpp:15-20` |
| Unbounded | `step(anglec, angle)` | Calculate simple wrapped difference | Same | `Mbounds.h:56` |

## 3. Inputs and Stimuli

| Input | Processing | Effect | Location |
|-------|------------|--------|----------|
| `angle_min`, `angle_max` | Set as min/max values for raw angle range | Configures mechanical limits as a range | `Mbounds.h:33` |
| `center` | Set as center with zero delta for raw angle range | Configures mechanical limits as a single point | `Mbounds.h:61` |
| `anglec` (desired angle) | Wrapped to stay within bounds if bounds exist | Modified if outside bounds | `Mbounds.cpp:19` |
| `angle` (measured angle) | Used to calculate error relative to desired angle | Not modified | `Mbounds.cpp:20` |
| Configuration data | Deserialized via `cset()` | Updates raw angle range configuration | `Mbounds.cpp:34` |

## 4. Outputs and Effects

| Output | Description | Calculation | Access Method | Location |
|--------|-------------|-------------|---------------|----------|
| Error value | Shortest path error between desired and measured angles | `anglec - angle` with bounds handling | Return value of `step()` | `Mbounds.h:43` |
| Modified `anglec` | Desired angle constrained to bounds | `rng_mang.wrap(anglec)` | Reference parameter of `step()` | `Mbounds.cpp:19` |
| Bounds status | Whether mechanical limits are configured | `rng_raw.has_bounds()` | `has_bounds()` | `Mbounds.h:39` |
| Inside bounds status | Whether a raw angle is within bounds | `rng_raw.is_in(raw_angle)` | `is_raw_inside()` | `Mbounds.h:37` |

## 5. Parameters and Configuration

| Parameter | Description | Default | Location |
|-----------|-------------|---------|----------|
| `rng_raw` | Range for raw encoder angles | Unbounded | `Mbounds.cpp:7-8` |
| `rng_mang` | Range for mechanical angles | Unbounded | `Mbounds.cpp:7-8` |
| `mang` | Reference to Mangle object for angle conversion | Passed in constructor | `Mbounds.h:28` |

## 6. Error Handling and Contingency Logic

### Bounds Enforcement

The primary error handling in the `Mbounds` class is the enforcement of mechanical limits:

1. When `step_bounded` is called, the desired angle (`anglec`) is wrapped to ensure it stays within the configured mechanical angle range:
   ```cpp
   anglec = rng_mang.wrap(anglec);
   ```

2. This prevents commands from moving the motor outside its mechanical limits, protecting against potential physical damage.

### Angle Wrapping

Both the bounded and unbounded step methods use angle wrapping to ensure proper calculation of the shortest path error:

```cpp
// In step_bounded
return Rfun::wrap2pi(anglec - rng_mang.center) - Rfun::wrap2pi(angle - rng_mang.center);

// In step_unbounded
return Rfun::wrap2pi(anglec-angle);
```

This ensures that the error is always calculated along the shortest path, even when crossing the 0/2π boundary.

### Configuration Deserialization

The `cset` method handles deserialization of configuration data:

```cpp
void Mbounds::cset(Base::Lossy_error& str)
{
    rng_raw.cset(str);
}
```

Any errors during deserialization are tracked by the `Lossy_error` object, though the code doesn't show explicit error handling beyond this.

## 7. File-by-File Breakdown

### Mbounds.h

This header file defines the `Mbounds` class for mechanical bounds management:

- Class declaration with public and private methods
- Member variables for angle ranges and Mangle reference
- Method declarations for bounds configuration, checking, and step processing
- Inline implementations of several methods for efficiency

The class inherits from `Base::Ideserializable` to support configuration deserialization.

Key methods include:
- `set_raw_minmax`, `set_unbounded`, `set_raw_single_angle` for bounds configuration
- `has_bounds`, `is_raw_inside` for bounds checking
- `step`, `step_bounded`, `step_unbounded` for movement command processing

### Mbounds_fw.h

A forward declaration header that simply declares the `Mbounds` class in the `VMC` namespace. This allows other files to reference the mechanical bounds class without including the full implementation details.

### Mbounds.cpp

This source file implements the functionality declared in `Mbounds.h`:

- Constructor implementation with initialization of member variables
- Implementation of `step_bounded` for calculating error with bounds enforcement
- Implementation of `cset` for configuration deserialization

The implementation focuses on the more complex `step_bounded` method, while simpler methods are implemented inline in the header file.

## 8. Cross-Component Relationships

### Integration with Angle Management System

The `Mbounds` class integrates closely with the angle management system through the `Mangle` class:

1. The `Mbounds` constructor takes a reference to a `Mangle` object:
   ```cpp
   explicit Mbounds(const Mangle& mang0);
   ```

2. The `step_bounded` method uses the `Mangle` object to convert between raw and mechanical angle ranges:
   ```cpp
   mang.convert(rng_raw, rng_mang);
   ```

This integration ensures that mechanical bounds are properly applied regardless of angle calibration settings.

### Integration with Range Management

The `Mbounds` class uses the `Base::Radrng` class to represent and manage angle ranges:

1. Two `Radrng` objects are maintained:
   ```cpp
   Base::Radrng rng_raw;   ///< Range for raw angle.
   Base::Radrng rng_mang;  ///< Range for mechanical angle.
   ```

2. Methods like `set_raw_minmax` and `set_unbounded` delegate to the corresponding `Radrng` methods:
   ```cpp
   inline void Mbounds::set_raw_minmax(Real angle_min, Real angle_max)
   {
       rng_raw.set_minmax(angle_min, angle_max);
   }

   inline void Mbounds::set_unbounded()
   {
       rng_raw.set_unbounded();
   }
   ```

This leverages the existing range management functionality provided by the `Radrng` class.

## 9. Mechanical Bounds Management Details

### Raw vs. Mechanical Angle Ranges

The `Mbounds` class maintains two angle ranges:

1. **Raw Angle Range (`rng_raw`)**: 
   - Represents limits in raw encoder angle units
   - Configured directly through methods like `set_raw_minmax`
   - Stored internally to avoid dependency on mechanical angle calibration settings

2. **Mechanical Angle Range (`rng_mang`)**: 
   - Represents limits in mechanical angle units
   - Derived from the raw range using the `Mangle` object
   - Used for bounds checking and enforcement during step processing

This dual representation ensures that mechanical bounds remain consistent even if mechanical angle calibration settings change.

### Bounds Configuration Methods

The `Mbounds` class provides three methods for configuring mechanical bounds:

1. **Min/Max Range**:
   ```cpp
   void set_raw_minmax(Real angle_min, Real angle_max);
   ```
   Configures bounds as a range from minimum to maximum raw angle.

2. **Unbounded**:
   ```cpp
   void set_unbounded();
   ```
   Removes all mechanical limits, allowing full 360° rotation.

3. **Single Angle**:
   ```cpp
   void set_raw_single_angle(Real center);
   ```
   Configures bounds as a single center angle, effectively fixing the position.

These methods provide flexibility in how mechanical limits are defined.

### Shortest Path Error Calculation

The `step` method calculates the shortest path error between desired and measured angles while respecting mechanical limits:

1. **Unbounded Case**:
   ```cpp
   Real step_unbounded(Real anglec, Real angle)
   {
       return Rfun::wrap2pi(anglec-angle);
   }
   ```
   Simply wraps the difference to the range -π to π.

2. **Bounded Case**:
   ```cpp
   Real step_bounded(Real& anglec, Real angle)
   {
       mang.convert(rng_raw, rng_mang);
       anglec = rng_mang.wrap(anglec);
       return Rfun::wrap2pi(anglec - rng_mang.center) - Rfun::wrap2pi(angle - rng_mang.center);
   }
   ```
   Centers both angles around the range center before calculating the difference, ensuring proper handling of bounded ranges.

This approach ensures that the error is always calculated along the shortest path that respects the mechanical limits.

## 10. Implementation Details

### Constructor

The `Mbounds` constructor initializes the object with a reference to a `Mangle` object and sets both angle ranges to unbounded:

```cpp
Mbounds::Mbounds(const Mangle& mang0) :
        mang(mang0)
{
    rng_raw.set_unbounded();
    rng_mang.set_unbounded();
}
```

### Bounds Checking

The `is_raw_inside` method checks if a raw angle is within the configured bounds:

```cpp
inline bool Mbounds::is_raw_inside(Real raw_angle) const
{
    return rng_raw.is_in(raw_angle);
}
```

This delegates to the `is_in` method of the `Radrng` class.

### Single Angle Configuration

The `set_raw_single_angle` method configures bounds as a single center angle:

```cpp
inline void Mbounds::set_raw_single_angle(Real center)
{
    rng_raw.set(center, 0);
}
```

This sets the range center to the specified angle and the delta to zero, effectively creating a single-point range.

### Step Method Dispatch

The `step` method dispatches to either `step_bounded` or `step_unbounded` based on whether bounds are configured:

```cpp
inline Real Mbounds::step(Real& anglec, Real angle)
{
    return (rng_raw.has_bounds()) ? step_bounded(anglec, angle) : step_unbounded(anglec, angle);
}
```

This ensures efficient processing by avoiding unnecessary bounds enforcement when no bounds are configured.

## Summary

The mechanical bounds management system, implemented through the `Mbounds` class, provides a comprehensive solution for ensuring motor angles stay within configured limits. The system offers flexible configuration options, efficient bounds checking, and proper handling of angle wrapping when calculating shortest path errors.

Key features of the system include:
1. Multiple methods for configuring mechanical limits (min/max range, unbounded, single angle)
2. Efficient bounds checking and enforcement
3. Proper calculation of shortest path errors while respecting mechanical limits
4. Integration with the angle management system for consistent handling of raw and mechanical angles
5. Independence from mechanical angle calibration settings

The system plays a crucial role in protecting motors from physical damage by preventing movement outside their mechanical limits while still allowing for efficient and accurate position control.

## Referenced Context Files

- `Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/VMC/06_Angle_Management.md` - Provided information about the angle management system, particularly the `Mangle` class that the `Mbounds` class integrates with for angle conversion between raw and mechanical angles.