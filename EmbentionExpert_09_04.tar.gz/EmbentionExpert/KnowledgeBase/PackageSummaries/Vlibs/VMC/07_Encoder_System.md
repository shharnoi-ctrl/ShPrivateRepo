# Generated from:

- code/include/Encoder.h (540 tokens)
- code/include/Encoder_fw.h (22 tokens)
- code/include/CRC7_encoder.h (808 tokens)
- code/source/Encoder.cpp (1065 tokens)

## With context from:

- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/VMC/08_Hardware_Abstraction_Layer.md (3187 tokens)

---

# Encoder System for Position Feedback in Motor Control

This document provides a comprehensive analysis of the encoder system used for position feedback in the motor control system. The implementation focuses on communication with Celera Zettlex IncOder Digital Encoders via SPI, data validation using CRC7, and conversion of raw counts to angle values.

## 1. Functional Behavior and Logic

### Encoder System Overview

The encoder system is designed to interface with Celera Zettlex IncOder Digital Encoders through SPI communication. It provides position feedback by:

1. Communicating with the encoder via SPI to retrieve position data
2. Validating the received data using CRC7 checksums
3. Converting raw encoder counts to normalized angle values (0 to 2π)
4. Providing the angle data to the motor control system

The system supports encoders with different resolutions, from 10-bit to 22-bit precision, with a default of 17-bit resolution.

### Encoder Communication State Machine

The encoder communication follows a state machine pattern implemented in the `step()` method:

1. **Data Reception State**:
   - Attempt to read data from the SPI interface
   - Continue reading until either the frame is complete (3 words) or no more data is available
   - Track the number of words read in the current frame

2. **Frame Request State**:
   - When a frame is complete or no more data can be read, request the next frame
   - Write zeros to the SPI interface to trigger the encoder to send new data
   - Reset the read status for the next frame

3. **Data Processing State**:
   - When a complete frame is received (3 words), validate and process it
   - Check frame validity flags
   - Compute and verify CRC7 checksum
   - Extract position data and convert to angle

```cpp
void Encoder::step()
{
    if(Base::Assertions::runtime(rd_words<rd_words_max))
    {
        // try to read
        bool rdok = false;
        do
        {
            rdok = spi.read(rd[rd_words]);
            if(rdok)
            {
                ++rd_words;
            }
        }
        while(rdok && rd_words<rd_words_max);

        // request more data if...
        bool frame_complete = rd_words>=rd_words_max;
        if(frame_complete || !rdok) // frame complete or no data read in this step
        {
            // request next frame
            for(Uint16 i=0; i<rd_words_max; ++i)
            {
                spi.write(0);
            }

            // reset read status for next frame
            rd_words = 0;
        }

        // compute frame if completed
        if(frame_complete)
        {
            // Process and validate frame data
            // ...
        }
    }
}
```

### Frame Validation Process

The encoder implements a thorough validation process for received frames:

1. **Flag Validation**:
   - Checks that D47-D33 bits are 0 (first word should be 1)
   - Verifies D32 bit is 1 (Zero Point is at Factory Default)
   - Confirms D31 bit is 1 (Position Valid Flag)

2. **CRC7 Calculation and Verification**:
   - Extracts bits D7 through D32 from the frame
   - Calculates CRC7 checksum using the dedicated `CRC7_encoder` class
   - Compares calculated CRC with the received CRC (bits D0-D6)

3. **Position Data Extraction**:
   - When validation passes, extracts the position data (bits D23 to D1)
   - Aligns the data and masks unused bits
   - Converts raw counts to angle using the resolution-specific factor

```cpp
// Compute CRC.
// the CRC is generated from bits D7 through D32. It is calculated using
// a 32 bit word (or 4 bytes) with D7 shifted in to the Least Significant Bit and the
// 6 Most Significant Bits set to '0' as required
Uint32 crc_data = rd[0] & 1;   // D32
crc_data <<= Ku16::u16;
crc_data  |= rd[1];            // D31..D16
crc_data <<= Ku16::u9;
crc_data  |= rd[2] >> Ku16::u7;// D15..D07

crc_enc.reset();
crc_enc.update((crc_data >> 24) & 0xFF);
crc_enc.update((crc_data >> 16) & 0xFF);
crc_enc.update((crc_data >>  8) & 0xFF);
crc_enc.update((crc_data      ) & 0xFF);
const Uint8 crc_res = crc_enc.get_value();

static const Uint32 crc_mask = Base::Lsbmask<Uint32, 7>::value;
ok = crc_res == (rd[2] & crc_mask);
```

### Angle Calculation

The encoder converts raw position counts to normalized angle values (0 to 2π):

1. The conversion factor is calculated based on the encoder's resolution (number of bits):
   ```cpp
   Real Encoder::compute_factor(Uint16 nbits)
   {
       const Uint32 max = Base::Bitutils::get_mask_lsb<Uint32>(nbits);
       return Const::PI2 / max;
   }
   ```

2. The raw counts are extracted from the validated frame and converted to angle:
   ```cpp
   raw_counts = crc_data >> 1;
   static const Uint32 data_mask = Base::Lsbmask<Uint32, max_nbits>::value;
   raw_counts &= data_mask;
   angle_raw = static_cast<Real>(raw_counts) * factor;
   ```

## 2. Control Flow and State Transitions

### Encoder Communication State Machine

| State | Trigger | Actions | Next State | Location |
|-------|---------|---------|------------|----------|
| Idle | `step()` called | Attempt to read SPI data | Reading | `Encoder.cpp:53` |
| Reading | Data available | Read data word, increment counter | Reading (if more data available) | `Encoder.cpp:57-64` |
| Reading | No more data or frame complete | Request next frame by writing zeros to SPI | Idle | `Encoder.cpp:69-78` |
| Processing | Frame complete | Validate frame flags and CRC | Idle | `Encoder.cpp:82-121` |
| Error | Validation fails | Trigger warning | Idle | `Encoder.cpp:118-119` |

### Timing Considerations

The encoder communication system has specific timing requirements:

- The `step()` method should not be called faster than the time required for a SPI word transmission
- For SPI at 500KHz, a word is 32μs long
- For a method call rate of 20KHz, the period is 50μs
- Since 32μs < 50μs, the timing requirements are satisfied

## 3. Inputs and Stimuli

### SPI Communication

| Input | Processing | Effect | Location |
|-------|------------|--------|----------|
| SPI data words | Read via `spi.read()` | Stored in `rd[]` array | `Encoder.cpp:59` |
| Configuration parameters | Deserialized via `cset()` | Updates encoder resolution and conversion factor | `Encoder.cpp:37-46` |

### Configuration Parameters

| Parameter | Description | Default | Range | Location |
|-----------|-------------|---------|-------|----------|
| `nbits` | Encoder resolution in bits | 17 | 10-22 | `Encoder.h:33` |

## 4. Outputs and Effects

### Position Data

| Output | Description | Calculation | Access Method | Location |
|--------|-------------|-------------|---------------|----------|
| `angle_raw` | Normalized angle (0 to 2π) | `raw_counts * factor` | `get_angle_raw()` | `Encoder.h:44-47` |
| `raw_counts` | Raw encoder position | Extracted from frame | Internal only | `Encoder.h:35` |

### SPI Communication

| Output | Description | Trigger | Location |
|--------|-------------|---------|----------|
| SPI write (zeros) | Request for next frame | After frame completion or no data read | `Encoder.cpp:72-75` |

### Error Indication

| Output | Description | Trigger | Location |
|--------|-------------|---------|----------|
| Warning | System warning | Frame validation failure | `Encoder.cpp:118` |

## 5. Parameters and Configuration

### Encoder Constants

```cpp
static const Uint16 rd_words_max = 3;   // Number of 16 bit words of rx encoder frame
static const Uint16 min_nbits = 10;     // Min number of bits in an encoder
static const Uint16 max_nbits = 22;     // Max number of bits in an encoder
static const Uint16 def_nbits = 17;     // Default number of bits in an encoder
```

### CRC7 Configuration

The CRC7 implementation uses the following parameters:
- Polynomial: 0xB6 (reciprocal: 0x6D)
- Input reflected: false
- Output reflected: false
- Initial value: 0
- Final XOR value: 0

```cpp
static const Uint8  byte_mask = 0xFF;   // Mask to retrieve a byte
static const Uint16 crc_displ = 8;      // CRC calculations displacement
static const Uint8  start_value = 0;    // Start value for CRC
```

## 6. Error Handling and Contingency Logic

### Frame Validation

The encoder implements multiple validation checks to ensure data integrity:

1. **Initial Flag Validation**:
   ```cpp
   bool ok = (rd[0] == 1) && ((rd[1] & Ku16::u0x8000) == Ku16::u0x8000);
   ```
   This checks that:
   - D47-D33 bits are 0 (first word should be 1)
   - D31 bit is 1 (Position Valid Flag)

2. **CRC7 Validation**:
   ```cpp
   ok = crc_res == (rd[2] & crc_mask);
   ```
   This verifies that the calculated CRC matches the received CRC.

3. **Error Response**:
   If validation fails, a system warning is triggered:
   ```cpp
   if(!ok)
   {
       Bsp::warning();
   }
   ```

### Configuration Validation

The encoder validates configuration parameters to ensure they are within acceptable ranges:

```cpp
if(!Base::Assertions::runtime((nbits >= min_nbits) && (nbits <= max_nbits)))
{
    str.failed(Base::err_vmc_encoder_nbits);
    nbits = def_nbits;
}
```

This ensures that the encoder resolution is between 10 and 22 bits, falling back to the default of 17 bits if the configuration is invalid.

## 7. File-by-File Breakdown

### Encoder.h

This header file defines the `Encoder` class, which interfaces with Celera Zettlex IncOder Digital Encoders via SPI. Key components include:

- Class declaration with public and private methods
- Constants for encoder configuration (resolution limits, frame size)
- Member variables for SPI communication, data storage, and angle calculation
- Method declarations for initialization, communication, and data access

The class inherits from `Base::Ideserializable` to support configuration deserialization.

### Encoder_fw.h

A forward declaration header that simply declares the `Encoder` class in the `VMC` namespace. This allows other files to reference the encoder without including the full implementation details.

### CRC7_encoder.h

This header file defines the `CRC7_encoder` class, which implements a 7-bit CRC algorithm specifically designed for the encoder protocol. Key components include:

- Class declaration with methods for CRC calculation
- Constants for CRC configuration
- Lookup table for fast CRC computation
- Inline implementations of CRC methods

The CRC implementation uses a table-based approach for efficient computation, with a 256-entry lookup table containing precomputed CRC values.

### Encoder.cpp

This source file implements the functionality declared in `Encoder.h`. Key components include:

- Constructor implementation with initialization of member variables
- Configuration deserialization via `cset()`
- Conversion factor calculation based on encoder resolution
- State machine implementation for encoder communication
- Frame validation and processing logic
- Angle calculation from raw encoder counts

## 8. Cross-Component Relationships

### Integration with Hardware Abstraction Layer

The encoder system integrates with the Hardware Abstraction Layer (HAL) through the SPI interface:

1. The encoder receives an SPI interface instance from the HAL during construction:
   ```cpp
   Encoder::Encoder(Dsp28335_ent::SPI& spi0) : spi(spi0), ...
   ```

2. It uses this interface to communicate with the physical encoder device:
   ```cpp
   rdok = spi.read(rd[rd_words]);
   ```
   ```cpp
   spi.write(0);
   ```

### Position Data Flow

The encoder provides position data to the angle management system through the `get_angle_raw()` method:

```cpp
Real Encoder::get_angle_raw() const
{
    return angle_raw;
}
```

This method returns the normalized angle value (0 to 2π) calculated from the raw encoder counts.

## 9. CRC7 Implementation Details

### CRC7 Algorithm

The CRC7 implementation uses a table-based approach for efficient computation:

1. **Initialization**:
   ```cpp
   inline CRC7_encoder::CRC7_encoder() : crc(start_value)
   {
   }
   ```

2. **Reset**:
   ```cpp
   inline void CRC7_encoder::reset()
   {
       crc = start_value;
   }
   ```

3. **Update**:
   ```cpp
   inline void CRC7_encoder::update(const Uint8 b)
   {
       crc = CRC7_encoder_table::table[(crc ^ b) & byte_mask];
   }
   ```

4. **Value Retrieval**:
   ```cpp
   inline Uint8 CRC7_encoder::get_value() const
   {
       return (crc & byte_mask) >> 1;
   }
   ```

### CRC7 Lookup Table

The CRC7 implementation uses a 256-entry lookup table for efficient computation:

```cpp
static const Uint8 table[256] =
{
    0x00, 0xB6, 0xDA, 0x6C, 0x02, 0xB4, 0xD8, 0x6E, 0x04, 0xB2, 0xDE, 0x68, 0x06, 0xB0, 0xDC, 0x6A,
    // ... (full table omitted for brevity)
};
```

This table contains precomputed CRC values for all possible byte values, allowing for efficient CRC calculation with a simple lookup operation.

## 10. Encoder Frame Format

The encoder communicates using a specific frame format:

1. **Frame Size**: 3 words (48 bits total)
2. **Bit Allocation**:
   - D47-D33: Must be 0
   - D32: Zero Point Flag (1 = Factory Default)
   - D31: Position Valid Flag (1 = Valid)
   - D30-D7: Position data (up to 24 bits, depending on encoder resolution)
   - D6-D0: CRC7 checksum

3. **CRC Calculation**:
   - CRC is calculated over bits D7 through D32
   - D7 is shifted to the least significant bit
   - The 6 most significant bits are set to 0

## Summary

The encoder system provides high-precision position feedback for motor control by interfacing with Celera Zettlex IncOder Digital Encoders via SPI. It implements a robust state machine for communication, thorough validation of received data using CRC7 checksums, and accurate conversion of raw counts to normalized angle values.

The system supports encoders with different resolutions (10-bit to 22-bit) and provides a clean interface for the angle management system to access position data. The implementation includes comprehensive error handling and validation to ensure data integrity and reliable operation.

The encoder system is a critical component of the motor control system, providing essential position feedback for closed-loop control and precise motor positioning. Its integration with the Hardware Abstraction Layer allows for seamless operation within the larger control system architecture.