# Generated from:

- code/project/eclipse/.project (334 tokens)
- code/project/eclipse/.cproject (5404 tokens)
- code/source/cmd/app_hdr_with_bldr.cmd (385 tokens)
- code/source/cmd/app_hdr_no_bldr.cmd (346 tokens)

---

# DSP28335 Build System Analysis

## 1. Eclipse Project Configuration

### Project Structure Overview

The DSP28x project is configured as a C/C++ project in Eclipse with both hardware and Software-in-the-Loop (SIL) targets. The project is structured as a static library (.a) that can be built in different configurations.

### Project Resources and Organization

The project uses linked resources to reference source files and include directories from parent locations:

- **Source Code Directories**:
  - `include` - Hardware-specific header files
  - `include_SIL` - Software-in-the-Loop simulation header files
  - `source` - Hardware-specific implementation files
  - `source_SIL` - Software-in-the-Loop simulation implementation files

These linked resources point to directories in the parent project location, allowing for a clean separation between the build configuration and the actual source code.

### Build Configurations

The project has two main build configurations:

1. **Default Configuration**:
   - Builds a static library named "DSP28x.a"
   - Used for the primary target platform

2. **2838x Configuration**:
   - Specialized configuration for the 2838x processor variant
   - Shares most settings with the Default configuration but has specific file exclusions

### Compiler Settings

#### C++ Compiler Settings (Default Configuration)

- **Language Standard**: C++17
- **Include Paths**: Extensive list of include paths covering:
  - DSP28x hardware and SIL headers
  - DSP2837x_ent hardware and SIL headers
  - BSP (Board Support Package) headers
  - FPU (Floating Point Unit) headers
  - First and base library headers
  - Maverick library headers
- **Preprocessor Definitions**:
  - `interrupt=""` - Redefines the interrupt keyword to be empty (likely for SIL compatibility)
- **Compiler Flags**:
  - `-fPIC` - Position Independent Code
  - `-pthread` - Threading support
  - `-fpermissive` - Relaxed language restrictions
  - Optimization level: None (for debugging)

#### C Compiler Settings (Default Configuration)

- **Preprocessor Definitions**:
  - `interrupt=""` - Same as C++
  - `_CODE_ACCESS=""` - Likely removes special memory access qualifiers for SIL
- **Compiler Flags**:
  - `-fPIC` - Position Independent Code
  - `-pthread` - Threading support

### File Exclusions

#### Default Configuration Exclusions
- Assembly files (*.asm)
- Specific implementation files:
  - Stackchk.cpp
  - i2cif.cpp
  - SCI.cpp
  - SPI.cpp
  - User_otp.cpp

#### 2838x Configuration Additional Exclusions
- Sysaddr_sc.cpp
- I2Cif.cpp
- ECAP.cpp

These exclusions suggest platform-specific implementations that are not needed for certain targets or are replaced by alternative implementations.

## 2. Linker Command Files

The project includes two linker command files that define the memory layout for applications with and without a bootloader.

### Common Memory Layout Concepts

Both linker command files define:

- **Application Header Structure**:
  - `APP_JUMP_SIZE`: 8 bytes for BEGIN/JUMP section
  - `APP_HDR_SIZE`: 104 bytes (32+80-APP_JUMP_SIZE) for application header
  - `BLDR_HDR_SIZE`: 112 bytes (APP_JUMP_SIZE + APP_HDR_SIZE) total bootloader header size

- **Memory Sections**:
  - `APP_BEGIN`: Jump section at the beginning of flash
  - `APP_BLDR_HDR`: Application header section
  - `FLASH_PRG`: Main application flash area

### Application with Bootloader (app_hdr_with_bldr.cmd)

This configuration assumes a bootloader is present in the system:

- **Memory Layout**:
  - `BOOTLOADER_RSV`: Reserved area for bootloader (not used by applications)
  - `FLASH_START`: Begins after the bootloader area
  - `FLASH_APP_START`: Application code starts after the header sections
  - `APP_FLASH_SZ`: Available flash size for the application

- **Memory Map**:
  ```
  +-----------------+ <- BLDR_START
  | BOOTLOADER_RSV  | (BLDR_SIZE)
  +-----------------+ <- FLASH_START
  | APP_BEGIN       | (APP_JUMP_SIZE/SIZE_FACTOR)
  +-----------------+
  | APP_BLDR_HDR    | (APP_HDR_SIZE/SIZE_FACTOR)
  +-----------------+ <- FLASH_APP_START
  | FLASH_PRG       | (APP_FLASH_SZ)
  | (Application)   |
  +-----------------+
  ```

### Application without Bootloader (app_hdr_no_bldr.cmd)

This configuration is for systems without a bootloader:

- **Memory Layout**:
  - No `BOOTLOADER_RSV` section
  - `FLASH_START` begins at `FLASH_ADDR` (the start of flash memory)
  - `FLASH_APP_START` and `APP_FLASH_SZ` are calculated similarly to the bootloader version

- **Memory Map**:
  ```
  +-----------------+ <- FLASH_ADDR (FLASH_START)
  | APP_BEGIN       | (APP_JUMP_SIZE/SIZE_FACTOR)
  +-----------------+
  | APP_BLDR_HDR    | (APP_HDR_SIZE/SIZE_FACTOR)
  +-----------------+ <- FLASH_APP_START
  | FLASH_PRG       | (APP_FLASH_SZ)
  | (Application)   |
  +-----------------+
  ```

### Section Placement

Both linker command files place specific sections in the memory map:

- `codestart`: Placed at the beginning of `APP_BEGIN` with 4-byte alignment
- `.const:*App_blr_hdr_inst*instance*`: Places application header instance data in the `APP_BLDR_HDR` section

This structure ensures that:
1. The application starts with a jump section (likely containing a branch to the main code)
2. The application header follows immediately after
3. The main application code begins after the header

## 3. Build System Integration with Architecture

### Hardware vs. SIL Target Support

The build system is designed to support both hardware targets and Software-in-the-Loop simulation:

1. **Hardware Target**:
   - Uses files from `include` and `source` directories
   - Excludes certain hardware-specific files based on the target processor

2. **SIL Target**:
   - Uses files from `include_SIL` and `source_SIL` directories
   - Redefines hardware-specific keywords like `interrupt` and `_CODE_ACCESS`
   - Enables position-independent code and threading support for simulation environment

### Conditional Compilation

The build system uses several mechanisms for conditional compilation:

1. **File Exclusions**: Different files are excluded based on the build configuration
2. **Preprocessor Definitions**: Keywords like `interrupt` are redefined
3. **Include Path Selection**: Different include paths are used for different targets

### Memory Layout Flexibility

The linker command files provide flexibility for different deployment scenarios:

1. **With Bootloader**: For systems where a bootloader is present
2. **Without Bootloader**: For systems where the application runs directly from flash

This allows the same application code to be deployed in different system configurations without modification.

### Size Factor Consideration

Both linker command files use a `SIZE_FACTOR` constant (not defined in the provided files) to convert between byte counts and memory addressing units. This suggests the target processor may have a different addressing scheme than byte-addressing.

## 4. Build System Optimization and Configuration

### Optimization Settings

The default build configuration has optimization disabled (`gnu.cpp.compiler.optimization.level.none`), which is typical for development and debugging. Production builds would likely enable higher optimization levels.

### Position Independent Code

Both configurations enable position-independent code (`-fPIC`), which allows the code to be loaded at any memory address. This is important for:

1. SIL simulation where the code may be dynamically loaded
2. Systems where the application may be relocated in memory

### Threading Support

Both configurations enable threading support (`-pthread`), suggesting the system may use multiple threads, particularly in the SIL environment.

### Permissive Compilation

The C++ compiler uses the `-fpermissive` flag, which relaxes some language restrictions. This may be necessary for compatibility with older code or for working around hardware-specific constraints.

## 5. Integration with Other Components

The include paths reveal integration with several other components:

1. **DSP2837x_ent**: Likely a processor-specific support package
2. **BSP**: Board Support Package providing hardware abstraction
3. **FPU**: Floating Point Unit support library
4. **First/Base/Maverick**: Application-level libraries

This suggests a layered architecture with:
- Hardware-specific code at the bottom
- Hardware abstraction in the middle
- Application logic at the top

## 6. Build System Summary

The DSP28335 build system is designed with the following key characteristics:

1. **Dual-Target Support**: Hardware and SIL simulation targets
2. **Flexible Deployment**: Support for systems with and without bootloaders
3. **Modular Architecture**: Clear separation between hardware-specific and platform-independent code
4. **Development Focus**: Optimization disabled, permissive compilation for easier debugging
5. **Static Library Output**: Built as a static library for linking with applications

The build system demonstrates a well-structured approach to embedded system development, with clear separation of concerns and support for multiple deployment scenarios and simulation environments.

## Referenced Context Files

No context files were provided in the input.