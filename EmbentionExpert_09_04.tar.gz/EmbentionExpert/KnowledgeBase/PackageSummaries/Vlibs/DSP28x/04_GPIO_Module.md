# Generated from:

- code/include/GPIO.h (533 tokens)
- code/include/GPIO_fw.h (22 tokens)
- code/include/GPIOv.h (774 tokens)
- code/include/GPIOvalid.h (103 tokens)
- code/include/GPIONOT.h (417 tokens)
- code/include/GPIOtoggler.h (1110 tokens)
- code/include/GPIOtoggler_ex.h (343 tokens)
- code/include/GPIOpulse_action.h (668 tokens)
- code/include/GPIOxbar_in.h (651 tokens)
- code/include/TGPIOtun.h (1094 tokens)
- code/source/GPIOtoggler_ex.cpp (195 tokens)
- code/source/GPIOpulse_action.cpp (771 tokens)

## With context from:

- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/DSP28x/06_Core_Hardware_Abstraction.md (3562 tokens)

---

# DSP28335 GPIO Module: Comprehensive Summary

## 1. Functional Behavior and Logic

The DSP28335 GPIO module provides a comprehensive set of classes and templates for GPIO management, offering multiple abstraction levels for different use cases. The module is designed with flexibility, performance, and safety in mind.

### 1.1 Core GPIO Class

The `GPIO` class serves as the foundation for direct hardware control of GPIO pins:

```cpp
class GPIO {
public:
    GPIO(GPIOid id);
    GPIOid get_id() const;
    void set_hi();
    void set_lo();
    void set(bool v);
    void toggle();
    bool get() const;
private:
    const GPIOid id;
    volatile Gpio_data_regs& dregs;
    const Uint32 mask1;
};
```

This class provides direct, efficient access to GPIO hardware registers with the following capabilities:
- Pin identification via `GPIOid`
- Setting pins high/low through `set_hi()` and `set_lo()`
- Toggling pin state with `toggle()`
- Reading current pin state with `get()`
- Setting pin state based on boolean value with `set(bool)`

The class maintains direct references to hardware registers for performance optimization:
- `dregs`: Reference to GPIO data registers
- `mask1`: Pre-calculated bit mask for efficient register manipulation

### 1.2 Virtual GPIO Interface

The `GPIOv` class implements the `Base::IGpio` interface, providing a virtual abstraction layer:

```cpp
class GPIOv: public Base::IGpio {
public:
    explicit GPIOv(GPIOid id);
    GPIOid get_id() const;
    virtual void set_hi();
    virtual void set_lo();
    virtual void set(bool v);
    virtual void toggle();
    virtual bool get() const;
private:
    GPIO gpio;
};
```

This class serves as an adapter between the `Base::IGpio` interface and the concrete `GPIO` implementation, enabling polymorphic usage of GPIO functionality. All operations are delegated to the underlying `GPIO` instance.

### 1.3 Inverted GPIO Behavior

The `GPIONOT` template class provides inverted GPIO behavior:

```cpp
template<typename G>
class GPIONOT: public Base::IGpio {
public:
    explicit GPIONOT(GPIOid);
    explicit GPIONOT(G gpio);
    virtual void set_hi();
    virtual void set_lo();
    virtual void set(bool value);
    virtual void toggle();
    virtual bool get() const;
private:
    G gpio;
};
```

This template inverts all GPIO operations:
- `set_hi()` calls `gpio.set_lo()`
- `set_lo()` calls `gpio.set_hi()`
- `set(bool)` calls `gpio.set(!value)`
- `get()` returns `!gpio.get()`

The template parameter `G` allows for flexibility in the underlying GPIO implementation, which can be either:
- An inlined GPIO instance (when constructed with `GPIOid`)
- A reference to an existing GPIO (when `G` is a reference type)

### 1.4 Automatic GPIO Toggling

Two classes provide automatic GPIO toggling functionality:

#### 1.4.1 GPIOtoggler

```cpp
template<typename T>
class GPIOtoggler {
public:
    GPIOtoggler(T& gpio, Uint32 decimation);
    void step();
    void set_decimation(Uint32 dec);
    void set_running(bool value = true);
    void keep_set();
    void keep_clear();
private:
    T& gpio;
    Uint32 decimation;
    bool running;
    Uint32 count;
};
```

This template class toggles a GPIO pin at a specified rate (controlled by the `decimation` parameter):
- `step()`: Increments an internal counter and toggles the GPIO when the counter exceeds the decimation value
- `set_decimation()`: Changes the toggle rate
- `set_running()`: Enables/disables automatic toggling
- `keep_set()`: Disables toggling and sets the GPIO high
- `keep_clear()`: Disables toggling and sets the GPIO low

#### 1.4.2 GPIOtoggler_ex

```cpp
class GPIOtoggler_ex {
public:
    explicit GPIOtoggler_ex(GPIO& gpio);
    void step();
    void set_alt_mode();
    void set_std_period(Real t);
private:
    GPIO& gpio;
    Real to_std;
    Base::Timeout to;
    Base::Timeout to_alt;
};
```

This class extends the toggling concept with dual-mode operation:
- Standard mode: Toggles at a default rate of 3Hz (configurable via `set_std_period()`)
- Alternative mode: Temporarily toggles at 10Hz for 0.5 seconds when `set_alt_mode()` is called
- Uses `Base::Timeout` objects to manage timing

### 1.5 Precise Pulse Generation

The `GPIOpulse_action` class generates precise pulses on GPIO pins:

```cpp
class GPIOpulse_action {
public:
    GPIOpulse_action(GPIOid gpio0, bool idle_state0);
    void start_pulse(Real period0);
    void force_pulse(Uint16 period0);
    bool step_hi();
private:
    GPIO gpio;
    const bool idle_state;
    bool triggered;
    Base::Timeout tout;
    void step0();
};
```

This class provides two pulse generation methods:
- `start_pulse(Real period0)`: Initiates a pulse with duration specified in seconds (>1ms)
- `force_pulse(Uint16 period0)`: Generates an immediate pulse with duration specified in microseconds (≤20μs)

The class maintains the GPIO's idle state and uses a timeout mechanism to control pulse duration. The `step_hi()` method must be called from a real-time task to ensure consistent pulse timing.

### 1.6 GPIO Crossbar Configuration

The `GPIOxbar_in` class configures GPIO pins as inputs to the crossbar:

```cpp
class GPIOxbar_in {
public:
    enum Id {
        id_tz1 = 0,      // Trip Zone 1
        id_tz2 = 1,      // Trip Zone 2
        id_tz3 = 2,      // Trip Zone 3
        id_xint1 = 3,    // External interrupt 1
        // ... other peripheral inputs
    };
    
    static void apply(GPIOid gpio_id, Id id);
    static void apply(GPIOid gpio_id, Uint16 idx);
};
```

This class redirects GPIO pins to specific peripherals through the crossbar:
- `apply(GPIOid, Id)`: Connects a GPIO to a predefined peripheral input
- `apply(GPIOid, Uint16)`: Connects a GPIO to a specific crossbar input index

### 1.7 GPIO Configuration Serialization

The `TGPIOtun` template provides configuration serialization for GPIO pins:

```cpp
template <typename MUX_TRAIT>
struct TGPIOtun {
    typedef typename MUX_TRAIT::Type_mux Mux;
    
    enum Dir { dir_input = 0, dir_output = 1 };
    enum Pullup { pu_dis = 0, pu_en = 1 };
    enum Qsel {
        qsel_sync = 0,
        qsel_3samples = 1,
        qsel_6samples = 2,
        qsel_async = 3
    };
    
    Dir ioflag;      // IO flag
    Pullup pu;       // Pull-up flag
    Mux mux_sel;     // Function selection
    Qsel q;          // Qualification
    
    static TGPIOtun<MUX_TRAIT> build(Dir io0, Pullup pu0, Mux mux0, Qsel q0);
    void cset(Base::Lossy_error& str);
    bool is_valid() const;
};
```

This template handles GPIO configuration parameters:
- Direction (`Dir`): Input or output
- Pull-up resistor (`Pullup`): Enabled or disabled
- Multiplexer selection (`Mux`): Function selection (defined by `MUX_TRAIT`)
- Qualification mode (`Qsel`): Synchronous, 3-sample, 6-sample, or asynchronous

The template provides methods for:
- Building a configuration with `build()`
- Deserializing from PDIC (Peripheral Device Interface Configuration) with `cset()`
- Validating configuration with `is_valid()`

### 1.8 GPIO ID Validation

The module includes a utility function for validating GPIO IDs:

```cpp
extern bool is_gpioid_valid(Uint16 id);
```

This function checks if a given GPIO ID is valid by comparing it against the maximum allowed ID (`gpio_all`).

## 2. Control Flow and State Transitions

### 2.1 GPIO Direct Control Flow

The basic control flow for direct GPIO manipulation follows this pattern:

1. **Initialization**: Create a `GPIO` instance with a specific `GPIOid`
2. **Operation**: Call methods like `set_hi()`, `set_lo()`, `toggle()`, or `get()`
3. **Effect**: The methods directly manipulate hardware registers to change or read the GPIO state

```
[Application] → GPIO(id) → [Hardware Register Access] → [Physical Pin State Change]
```

### 2.2 Virtual GPIO Control Flow

When using the virtual interface pattern:

1. **Initialization**: Create a `GPIOv` instance with a specific `GPIOid`
2. **Interface Usage**: Use the object through the `Base::IGpio` interface
3. **Delegation**: `GPIOv` methods delegate to the underlying `GPIO` instance
4. **Effect**: Hardware registers are manipulated through the delegation chain

```
[Application] → IGpio interface → GPIOv → GPIO → [Hardware Register Access] → [Physical Pin State Change]
```

### 2.3 Inverted GPIO Control Flow

The `GPIONOT` template inverts the control flow:

1. **Initialization**: Create a `GPIONOT` instance with either a `GPIOid` or an existing GPIO object
2. **Operation**: Call methods like `set_hi()`, `set_lo()`, `toggle()`, or `get()`
3. **Inversion**: The methods invert the operation before delegating
4. **Delegation**: The inverted operation is performed on the underlying GPIO
5. **Effect**: Hardware registers are manipulated with inverted logic

```
[Application] → GPIONOT::set_hi() → GPIO::set_lo() → [Hardware Register Access] → [Physical Pin State Change]
```

### 2.4 GPIO Toggler State Machine

The `GPIOtoggler` implements a simple state machine:

| State | Trigger | Actions | Next State |
|-------|---------|---------|------------|
| Running | `step()` called, count > decimation | Toggle GPIO, reset count | Running |
| Running | `step()` called, count ≤ decimation | Increment count | Running |
| Running | `keep_set()` called | Set GPIO high | Not Running |
| Running | `keep_clear()` called | Set GPIO low | Not Running |
| Not Running | `set_running(true)` called | None | Running |

### 2.5 Extended GPIO Toggler State Machine

The `GPIOtoggler_ex` implements a more complex state machine with two toggling modes:

| State | Trigger | Actions | Next State |
|-------|---------|---------|------------|
| Standard Mode | Timeout expired | Toggle GPIO, restart timeout with standard period | Standard Mode |
| Standard Mode | `set_alt_mode()` called | Start alternative mode timeout | Alternative Mode |
| Alternative Mode | Timeout expired | Toggle GPIO, restart timeout with alternative period | Alternative Mode |
| Alternative Mode | Alternative mode timeout expired | None (next timeout will use standard period) | Standard Mode |

### 2.6 Pulse Generation State Machine

The `GPIOpulse_action` class implements a state machine for pulse generation:

| State | Trigger | Actions | Next State |
|-------|---------|---------|------------|
| Idle | `start_pulse()` called | Set triggered flag | Triggered |
| Triggered | `step_hi()` called, first time | Start timeout, set GPIO to active state | Active |
| Active | `step_hi()` called, timeout not expired | None | Active |
| Active | `step_hi()` called, timeout expired | Set GPIO to idle state, clear triggered flag | Idle |
| Any | `force_pulse()` called | Set GPIO to active state, delay, set GPIO to idle state | Same state |

## 3. Inputs and Stimuli

### 3.1 GPIO Identification

All GPIO classes accept a `GPIOid` as input, which identifies the specific GPIO pin to control:

```cpp
GPIO gpio(GPIOid::gpio_0);  // Control GPIO pin 0
```

The `GPIOid` is an enumeration that maps to physical GPIO pins on the DSP28335 processor.

### 3.2 GPIO State Control

The GPIO classes accept boolean inputs to control pin state:

```cpp
gpio.set(true);   // Set GPIO high
gpio.set(false);  // Set GPIO low
```

### 3.3 Toggler Configuration

The `GPIOtoggler` class accepts configuration inputs:

```cpp
GPIOtoggler<GPIO> toggler(gpio, 1000);  // Toggle every 1000 steps
toggler.set_decimation(500);            // Change to toggle every 500 steps
toggler.set_running(false);             // Disable toggling
```

### 3.4 Pulse Configuration

The `GPIOpulse_action` class accepts pulse duration inputs:

```cpp
GPIOpulse_action pulse(GPIOid::gpio_0, false);
pulse.start_pulse(0.01);    // 10ms pulse
pulse.force_pulse(10);      // 10μs pulse
```

### 3.5 Crossbar Configuration

The `GPIOxbar_in` class accepts GPIO routing configuration:

```cpp
GPIOxbar_in::apply(GPIOid::gpio_0, GPIOxbar_in::id_tz1);  // Route GPIO 0 to Trip Zone 1
```

### 3.6 GPIO Tunable Configuration

The `TGPIOtun` template accepts configuration parameters:

```cpp
auto config = TGPIOtun<MUX_TRAIT>::build(
    TGPIOtun<MUX_TRAIT>::dir_output,    // Direction
    TGPIOtun<MUX_TRAIT>::pu_en,         // Pull-up enabled
    MUX_TRAIT::mux_gpio,                // Function selection
    TGPIOtun<MUX_TRAIT>::qsel_sync      // Synchronous qualification
);
```

## 4. Outputs and Effects

### 4.1 Physical Pin State Changes

The primary effect of the GPIO module is changing the state of physical GPIO pins:

- `set_hi()`: Sets the pin to high voltage level
- `set_lo()`: Sets the pin to low voltage level
- `toggle()`: Inverts the current pin state
- `set(bool)`: Sets the pin to high or low based on the boolean value

These operations directly affect hardware registers, which in turn control the electrical state of the pins.

### 4.2 Pin State Reading

The `get()` method reads the current state of a GPIO pin:

```cpp
bool state = gpio.get();  // Returns true if pin is high, false if low
```

This operation reads from hardware registers to determine the current electrical state of the pin.

### 4.3 Automatic Toggling

The `GPIOtoggler` and `GPIOtoggler_ex` classes produce automatic toggling effects:

- Regular toggling at a specified rate
- Temporary alternative toggling rates
- Controlled starting and stopping of toggling

### 4.4 Pulse Generation

The `GPIOpulse_action` class generates precise pulses:

- Long pulses (>1ms) with `start_pulse()`
- Short pulses (≤20μs) with `force_pulse()`

### 4.5 Crossbar Configuration

The `GPIOxbar_in` class configures the GPIO crossbar, routing GPIO pins to specific peripheral inputs:

```cpp
GPIOxbar_in::apply(GPIOid::gpio_0, GPIOxbar_in::id_tz1);
```

This operation configures the crossbar to route GPIO 0 to Trip Zone 1, affecting how the GPIO interacts with other peripherals.

## 5. Parameters and Configuration

### 5.1 GPIO Identification

The `GPIOid` enumeration identifies specific GPIO pins:

```cpp
enum GPIOid {
    gpio_0,
    gpio_1,
    // ... other GPIO pins
    gpio_all
};
```

### 5.2 GPIO Toggler Parameters

The `GPIOtoggler` class uses these parameters:

- `decimation`: Controls the toggle rate (higher values = slower toggling)
- `running`: Controls whether toggling is active

### 5.3 Extended GPIO Toggler Parameters

The `GPIOtoggler_ex` class uses these parameters:

- `to_std`: Standard toggling period (default: 0.33s for 3Hz)
- `def_alt_tout`: Alternative toggling period (default: 0.1s for 10Hz)
- `def_alt_dur`: Duration of alternative mode (default: 0.5s)

### 5.4 Pulse Action Parameters

The `GPIOpulse_action` class uses these parameters:

- `idle_state`: The normal state of the GPIO when not pulsing
- `period0`: The duration of the pulse (in seconds for `start_pulse()`, microseconds for `force_pulse()`)

### 5.5 GPIO Tunable Parameters

The `TGPIOtun` template uses these configuration parameters:

- `Dir ioflag`: Input/output direction (input = 0, output = 1)
- `Pullup pu`: Pull-up resistor configuration (disabled = 0, enabled = 1)
- `Mux mux_sel`: Function selection (depends on `MUX_TRAIT`)
- `Qsel q`: Qualification mode (sync = 0, 3-sample = 1, 6-sample = 2, async = 3)

## 6. Error Handling and Contingency Logic

### 6.1 GPIO ID Validation

The `is_gpioid_valid()` function checks if a GPIO ID is valid:

```cpp
bool is_gpioid_valid(Uint16 id) {
    return id < gpio_all;
}
```

This function can be used to validate GPIO IDs before using them.

### 6.2 GPIO Tunable Validation

The `TGPIOtun::is_valid()` method validates GPIO configuration:

```cpp
template <typename MUX_TRAIT>
bool TGPIOtun<MUX_TRAIT>::is_valid() const {
    return (Base::Enums::is_gtez(ioflag)) && (ioflag < dir_sz)
            && (Base::Enums::is_gtez(pu)) && (pu < pu_sz)
            && (Base::Enums::is_gtez(q)) && (q < qsel_sz)
            && MUX_TRAIT::is_valid(mux_sel);
}
```

This method checks that all configuration parameters are within valid ranges.

### 6.3 Pulse Parameter Validation

The `GPIOpulse_action::start_pulse()` method validates pulse parameters:

```cpp
void GPIOpulse_action::start_pulse(Real period0) {
    Base::Assertions::runtime((period0 >= Const::E1000) && (!triggered));
    // ...
}
```

This ensures that:
- The pulse period is at least 1ms (`Const::E1000`)
- No pulse is currently in progress (`!triggered`)

Similarly, `force_pulse()` validates that the pulse duration is within limits:

```cpp
void GPIOpulse_action::force_pulse(Uint16 period0) {
    Base::Assertions::runtime(period0 <= Ku16::u20);
    // ...
}
```

This ensures that the pulse duration is at most 20μs (`Ku16::u20`).

### 6.4 Critical Section Protection

The `GPIOpulse_action::force_pulse()` method uses a mutex to protect the critical section:

```cpp
void GPIOpulse_action::force_pulse(Uint16 period0) {
    // ...
    {
        Base::Mutex mutex(true);
        gpio.set(!idle_state);
        Delay::us(period0);
        gpio.set(idle_state);
    }
}
```

This ensures that the pulse generation is not interrupted by other processes.

### 6.5 Serialization Error Handling

The `TGPIOtun::cset()` method handles deserialization errors:

```cpp
template <typename MUX_TRAIT>
void TGPIOtun<MUX_TRAIT>::cset(Base::Lossy_error& str) {
    str.get_enum16(ioflag);
    str.get_enum16(pu);
    str.get_enum16(mux_sel);
    str.get_enum16(q);
    
    str.assrt(is_valid(), Base::err_gpio);
}
```

After deserializing the configuration, it validates it and reports an error if invalid.

## 7. File-by-File Breakdown

### 7.1 GPIO.h

Defines the core `GPIO` class for direct hardware control:
- Constructor takes a `GPIOid` to identify the GPIO pin
- Methods for setting, clearing, toggling, and reading GPIO state
- Private members for efficient register access

### 7.2 GPIO_fw.h

A forward declaration file that declares the `GPIO` class in the `Dsp28335_ent` namespace, allowing other files to reference the class without including the full definition.

### 7.3 GPIOv.h

Defines the `GPIOv` class that implements the `Base::IGpio` interface:
- Wraps a `GPIO` instance and delegates all operations to it
- Provides virtual methods for polymorphic usage
- Inline implementations for performance

### 7.4 GPIOvalid.h

Declares the `is_gpioid_valid()` function for validating GPIO IDs:
- Takes a `Uint16` ID as input
- Returns `true` if the ID is valid, `false` otherwise

### 7.5 GPIONOT.h

Defines the `GPIONOT` template class for inverted GPIO behavior:
- Template parameter allows for different GPIO implementations
- Inverts all operations before delegating to the underlying GPIO
- Can be constructed with either a `GPIOid` or an existing GPIO object

### 7.6 GPIOtoggler.h

Defines the `GPIOtoggler` template class for automatic GPIO toggling:
- Template parameter allows for different GPIO implementations
- Methods for controlling toggling behavior
- Step-based timing mechanism

### 7.7 GPIOtoggler_ex.h

Defines the `GPIOtoggler_ex` class for extended toggling functionality:
- Dual-mode toggling (standard and alternative)
- Timeout-based timing mechanism
- Methods for controlling toggling behavior

### 7.8 GPIOpulse_action.h

Defines the `GPIOpulse_action` class for precise pulse generation:
- Methods for starting pulses of different durations
- Real-time step method for consistent timing
- Timeout-based pulse duration control

### 7.9 GPIOxbar_in.h

Defines the `GPIOxbar_in` class for configuring the GPIO crossbar:
- Static methods for connecting GPIOs to peripheral inputs
- Enumeration of predefined peripheral inputs
- Support for both enumerated and numeric input indices

### 7.10 TGPIOtun.h

Defines the `TGPIOtun` template for GPIO configuration serialization:
- Template parameter for multiplexer trait customization
- Enumerations for direction, pull-up, and qualification modes
- Methods for building, validating, and deserializing configurations

### 7.11 GPIOtoggler_ex.cpp

Implements the `GPIOtoggler_ex` class:
- Constructor initializes timeouts with default values
- `step()` method handles toggling logic and mode switching

### 7.12 GPIOpulse_action.cpp

Implements the `GPIOpulse_action` class:
- Constructor initializes GPIO and sets it to idle state
- `start_pulse()` method validates parameters and triggers a pulse
- `force_pulse()` method generates immediate pulses with critical section protection
- `step_hi()` method handles pulse timing in real-time tasks

## 8. Cross-Component Relationships

### 8.1 Class Hierarchy

The GPIO module uses a layered architecture with several abstraction levels:

1. **Hardware Access Layer**: `GPIO` class provides direct hardware control
2. **Interface Adaptation Layer**: `GPIOv` adapts `GPIO` to the `Base::IGpio` interface
3. **Behavior Modification Layer**: `GPIONOT` inverts GPIO behavior
4. **Automation Layer**: `GPIOtoggler` and `GPIOtoggler_ex` provide automatic toggling
5. **Specialized Action Layer**: `GPIOpulse_action` provides precise pulse generation
6. **Configuration Layer**: `GPIOxbar_in` and `TGPIOtun` handle GPIO configuration

### 8.2 Template Design Pattern

The module uses templates for flexibility and code reuse:

- `GPIONOT<G>`: Template parameter `G` allows for different GPIO implementations
- `GPIOtoggler<T>`: Template parameter `T` allows for different GPIO implementations
- `TGPIOtun<MUX_TRAIT>`: Template parameter `MUX_TRAIT` allows for customization of multiplexer traits

### 8.3 Interface Implementation

The `GPIOv` class implements the `Base::IGpio` interface, allowing for polymorphic usage:

```cpp
Base::IGpio* gpio = new GPIOv(GPIOid::gpio_0);
gpio->set_hi();  // Calls GPIOv::set_hi(), which calls GPIO::set_hi()
```

### 8.4 Composition Relationships

The module uses composition extensively:

- `GPIOv` contains a `GPIO` instance
- `GPIONOT<G>` contains a GPIO instance or reference
- `GPIOtoggler<T>` contains a reference to a GPIO instance
- `GPIOtoggler_ex` contains a reference to a `GPIO` instance
- `GPIOpulse_action` contains a `GPIO` instance

### 8.5 Dependency Relationships

The module has several dependencies:

- `GPIO` depends on `Gpio_data_regs` for hardware register access
- `GPIOv` depends on `Base::IGpio` for interface implementation
- `GPIOpulse_action` depends on `Base::Timeout` for timing control
- `GPIOtoggler_ex` depends on `Base::Timeout` for timing control
- `TGPIOtun` depends on `Base::Lossy_error` for serialization

## 9. Referenced Context Files

The following context files provided useful information for understanding the DSP28335 GPIO module:

- `code/include/DSP28x_types.h`: Defines basic data types used throughout the module
- `code/include/Hregmap.h`: Provides hardware register access mechanisms used by the `GPIO` class
- `code/include/Asm.h`: Contains assembly instruction wrappers that might be used for critical sections
- `code/include/Timeout.h`: Defines the `Base::Timeout` class used by `GPIOpulse_action` and `GPIOtoggler_ex`
- `code/include/Assertions.h`: Provides the `Base::Assertions::runtime` function used for parameter validation
- `code/include/Lossy_error.h`: Defines the `Base::Lossy_error` class used for serialization error handling
- `code/include/Enums.h`: Contains the `Base::Enums` namespace with utility functions for enumeration validation

## Summary

The DSP28335 GPIO module provides a comprehensive set of classes and templates for GPIO management, offering multiple abstraction levels for different use cases. The module is designed with flexibility, performance, and safety in mind, using object-oriented design patterns like interfaces, templates, and composition to create a modular and extensible architecture.

Key features include:
1. Direct hardware control through the `GPIO` class
2. Virtual interface implementation through the `GPIOv` class
3. Inverted GPIO behavior through the `GPIONOT` template
4. Automatic toggling through the `GPIOtoggler` and `GPIOtoggler_ex` classes
5. Precise pulse generation through the `GPIOpulse_action` class
6. Crossbar configuration through the `GPIOxbar_in` class
7. Configuration serialization through the `TGPIOtun` template

The module provides a solid foundation for GPIO-based applications on the DSP28335 platform, with support for various use cases and requirements.