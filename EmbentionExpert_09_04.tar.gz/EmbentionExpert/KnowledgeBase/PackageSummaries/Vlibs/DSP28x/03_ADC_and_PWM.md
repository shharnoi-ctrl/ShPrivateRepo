# Generated from:

- code/include/ADC_mc.h (813 tokens)
- code/include/ADCch.h (667 tokens)
- code/include/Pwmsuite.h (2686 tokens)
- code/include/Pwmdev_mc.h (1314 tokens)
- code/include/DMAtrigger.h (1637 tokens)
- code/source/DMAtrigger.cpp (38 tokens)

## With context from:

- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/DSP28x/06_Core_Hardware_Abstraction.md (3562 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/DSP28x/04_Timer_and_Capture.md (7102 tokens)

---

# DSP28335 ADC and PWM Modules: Comprehensive Summary

This summary provides a detailed analysis of the DSP28335 ADC and PWM modules, focusing on their implementation, configuration options, and integration for motor control applications.

## 1. ADC Module Architecture

### 1.1 ADC_mc Class

The `ADC_mc` class extends the base `ADC` class to provide specialized analog-to-digital conversion capabilities for motor control applications on the DSP28335 microcontroller.

```cpp
class ADC_mc : public ADC
{
public:
    explicit ADC_mc(Vref_type vref_t);
    void vmc_init(const Base::Mblock<const ADC::ADCchannel>& sampling_order);
    void mc_init(const Base::Mblock<const Base::Mblock<const ADCchannel> >& sequence_channels,
                 const Uint16 acquisition_window_size_tics,
                 const Real rs,
                 const Real cs);
    void enable_seq1_isr(Isrptr func);
    void irq_ack();
    void clear_irq_flags();
    void post_seq1();
    void set_raw_value(const ADCchannel ch, const Uint16 val);

private:
    Uint16 mod_h; ///< Module sequence with more channels to sample (only for 2837x-2838x).
};
```

#### 1.1.1 Key Features

- **Reference Voltage Configuration**: The constructor takes a `Vref_type` parameter to configure the ADC reference voltage source.
- **Motor Control Initialization**: The `mc_init` method configures the ADC for motor control applications with specific sequence channels, acquisition window size, and system parameters.
- **Interrupt Management**: Methods for enabling interrupts (`enable_seq1_isr`), acknowledging interrupts (`irq_ack`), and clearing interrupt flags (`clear_irq_flags`).
- **Sequence Control**: The `post_seq1` method allows manual triggering of the ADC priority sequence sampling task.
- **Simulation Support**: The `set_raw_value` method enables setting register values for software-in-the-loop (SIL) testing.

#### 1.1.2 Motor Control Initialization

The `mc_init` method configures the ADC for motor control applications with the following parameters:
- `sequence_channels`: Array of channel lists to read, one per ADC module
- `acquisition_window_size_tics`: Acquisition window size in clock ticks
- `rs`: System resistance in ohms
- `cs`: System capacitance in farads

This method sets up the ADC to be triggered by PWM cycles, with an interrupt raised after sequence 1 conversion is complete. Each sequence can have up to 8 channels, and the second sequence (low priority) must be started manually.

### 1.2 ADCch Template Class

The `ADCch` template class provides an interface for interacting with a single channel of an ADC.

```cpp
template <typename TADC>
class ADCch
{
public:
    ADCch(TADC& adc, const typename TADC::ADCchannel ch);
    Uint16 get_sample_raw() const;
    Real get_sample_norm() const;
    Real get_sample_volts() const;

private:
    const typename TADC::ADCchannel ch; ///< The ADC channel.
    TADC& adc;                          ///< Reference to the ADC object.
};
```

#### 1.2.1 Key Features

- **Template-Based Design**: Works with any ADC class that provides the required interface.
- **Multiple Value Formats**: Methods to retrieve samples in raw (`get_sample_raw`), normalized (`get_sample_norm`), or voltage (`get_sample_volts`) formats.
- **Channel Encapsulation**: Stores the channel identifier and ADC reference, simplifying access to a specific channel.

#### 1.2.2 Implementation Details

The implementation is straightforward, delegating calls to the underlying ADC object:

```cpp
template <typename TADC>
inline Uint16 ADCch<TADC>::get_sample_raw() const
{
    return adc.get_sample_raw(ch);
}

template <typename TADC>
inline Real ADCch<TADC>::get_sample_norm() const
{
    return adc.get_sample_norm(ch);
}

template <typename TADC>
inline Real ADCch<TADC>::get_sample_volts() const
{
    return adc.get_sample_volts(ch);
}
```

## 2. PWM Module Architecture

### 2.1 Pwmsuite Template Class

The `Pwmsuite` template class manages and controls multiple PWM devices (both physical and virtual) in the system.

```cpp
template <typename PWMDEV, Uint16 npwms = PWMDEV::nb_pwms>
class Pwmsuite: public Base::Ideserializable, public Idisable, public Base::Isetter<Real>
{
public:
    struct Config {
        static const Uint16 freq_def = Ku16::u50;
        Config();
        Uint16 freq;
        typename PWMDEV::Config cfg[2];
        void cset(Base::Lossy_error& str);
    };

    Pwmsuite(Base::Memmgr::Type mem_type, Base::Rngit<typename PWMDEV::PWMid> pwm_rng,
             Base::Range_dyn<Base::Rvar> pwm_ids0);
    PWMDEV& get(Uint16 pwmid0);
    const PWMDEV& get(Uint16 pwmid0) const;
    Real get_value(Uint16 pwmid0) const;
    virtual void set_value(Uint16 pwmid0, Real value);
    Uint16 get_nb_pwms() const;
    virtual void cset(Base::Lossy_error& str);
    virtual void disable();

protected:
    const Base::Range_dyn<Base::Rvar> pwm_ids;

private:
    static const Uint16 nb_mods = (npwms + 1) / 2;
    const Uint16 phy_pwms_sum;
    const Uint16 pwms_sum;
    Base::Array<PWMDEV> pwms;
    Base::Tunarray<Config> cfgs;
};
```

#### 2.1.1 Key Features

- **Template-Based Design**: Works with any PWM device class that provides the required interface.
- **Configuration Structure**: The nested `Config` structure holds configuration parameters for each PWM module.
- **Memory Management**: Uses the `Base::Memmgr::Type` parameter to specify memory location (external or internal).
- **Value Access**: Methods to get and set PWM output values.
- **Deserialization**: Implements the `Base::Ideserializable` interface for configuration from PDIC.
- **Disable Support**: Implements the `Idisable` interface to safely disable PWMs.

#### 2.1.2 PWM Configuration

The `Config` structure contains:
- `freq`: PWM frequency in Hz (default: 50 Hz)
- `cfg[2]`: Configuration for channels A and B of each PWM module

The `cset` method deserializes the configuration from a PDIC (Parameter Data Interface Container):

```cpp
template <typename PWMDEV, Uint16 npwms>
void Pwmsuite<PWMDEV, npwms>::Config::cset(Base::Lossy_error& str)
{
    str.get_uint16(freq);
    cfg[Ku16::u0].cset(str);    // Channel A
    cfg[Ku16::u1].cset(str);    // Channel B
}
```

#### 2.1.3 PWM Value Setting

The `set_value` method sets the output value for a specified PWM device:

```cpp
template <typename PWMDEV, Uint16 npwms>
void Pwmsuite<PWMDEV, npwms>::set_value(Uint16 pwmid0, Real value)
{
    if (Base::Assertions::runtime(pwmid0 < pwms_sum))
    {
        Bsp::Hrvar(pwm_ids.get_idx(pwmid0)).set(value);

        if(pwmid0 < pwms.size())    // Check if PWM is not virtual
        {
            pwms[pwmid0].set(value);
        }
    }
}
```

This method:
1. Checks if the PWM ID is valid
2. Sets the associated Rvar with the input value
3. If the PWM is physical (not virtual), sets the PWM output to the input value

#### 2.1.4 Safe Disable Implementation

The `disable` method safely disables all PWMs:

```cpp
template <typename PWMDEV, Uint16 npwms>
void Pwmsuite<PWMDEV, npwms>::disable()
{
    Real min_freq = Const::MAX;

    for(Uint16 i=0; i<npwms; i++)
    {
        const typename PWMDEV::PWMid id = static_cast<typename PWMDEV::PWMid>(i);
        PWMDEV& pwm0 = pwms[id];
        Real freq = pwm0.get_frequency();
        if(pwm0.get_enabled())
        {
            if(freq < min_freq)
            {
                min_freq = freq;
            }
            pwm0.set_enabled(false);
        }
    }

    Delay::ms(static_cast<Uint16>(Const::ONE/min_freq));
}
```

This method:
1. Finds the minimum frequency among all active PWMs
2. Disables all active PWMs
3. Waits for a full period of the longest PWM cycle to ensure signals are not chopped

### 2.2 Pwmdev_mc Class

The `Pwmdev_mc` class extends the base `Pwmdev` class to provide specialized PWM capabilities for motor control applications.

```cpp
class Pwmdev_mc: public Pwmdev
{
public:
    explicit Pwmdev_mc(Dsp28335_ent::Pwmdev::PWMid id0);
    void mc_init(Real pwm_freq, bool master, Real deadband, Uint16 adc_div, bool int_on_high);
    void set_sync_enabled(bool enabled);
    void mc_pwm_syncout_init(Real pwm_freq, Real pulse_width);
    void set_phase_shift(Uint16 degrees);
    void enable_trip_zone(Trip_mode mode, Tzctl ctl, bool enable);
    void enable_isr(Isrptr func);
    void irq_ack();
    void clear_irq_flags();
    void config_reload_prd();
};
```

#### 2.2.1 Key Features

- **Motor Control Initialization**: The `mc_init` method configures the PWM for motor control applications.
- **Synchronization**: Methods for enabling synchronization (`set_sync_enabled`) and configuring synchronization output (`mc_pwm_syncout_init`).
- **Phase Shifting**: The `set_phase_shift` method configures phase shift from the input synchronization source.
- **Trip Zone Protection**: The `enable_trip_zone` method configures trip zone protection for fault handling.
- **Interrupt Management**: Methods for enabling interrupts (`enable_isr`), acknowledging interrupts (`irq_ack`), and clearing interrupt flags (`clear_irq_flags`).

#### 2.2.2 Motor Control Initialization

The `mc_init` method configures the PWM for motor control with the following parameters:
- `pwm_freq`: Output module frequency in Hz
- `master`: If false, PWM will be synchronized with another PWM
- `deadband`: Dead band in seconds
- `adc_div`: ADC conversion trigger decimation with respect to PWM frequency
- `int_on_high`: Whether to trigger ADC conversion on high side (false for low side)

This method configures the PWM in up-down mode, with ADC trigger configured every `adc_div` periods, phase load enable only for slaves, and appropriate synchronization settings.

## 3. DMA Trigger Integration

The `DMAtrigger` structure encapsulates DMA triggers, which can be used to initiate DMA transfers based on various events, including ADC and PWM events.

```cpp
struct DMAtrigger
{
public:
    enum Id
    {
        dma_software =   0,
        dma_adcaint1 =   1,
        // ... many other trigger sources ...
        dma_epwm1a   =  36,
        dma_epwm1b   =  37,
        // ... more PWM triggers ...
    };

    static const Uint16 dma_trall = 158;
    const Id id;
    volatile void* const addr;

    DMAtrigger(Id id0, volatile Uint16* reg_addr);

private:
    DMAtrigger();
};
```

### 3.1 Key Features

- **Comprehensive Trigger Sources**: Enumerates all possible DMA trigger sources, including ADC events, PWM events, timer events, and more.
- **Register Access**: Stores a pointer to the register address associated with the trigger.
- **Type Safety**: Uses an enumeration to ensure only valid trigger sources are used.

### 3.2 Implementation

The implementation is straightforward, simply storing the trigger ID and register address:

```cpp
DMAtrigger::DMAtrigger(Id id0, volatile Uint16* reg_addr) : id(id0), addr(reg_addr)
{
}
```

## 4. ADC and PWM Integration for Motor Control

The ADC and PWM modules are designed to work together seamlessly for motor control applications. Here's how they integrate:

### 4.1 PWM-Triggered ADC Conversions

The `ADC_mc::mc_init` method configures the ADC to be triggered by PWM cycles:

```cpp
void mc_init(const Base::Mblock<const Base::Mblock<const ADCchannel> >& sequence_channels,
             const Uint16 acquisition_window_size_tics,
             const Real rs,
             const Real cs);
```

Similarly, the `Pwmdev_mc::mc_init` method configures the PWM to trigger ADC conversions:

```cpp
void mc_init(Real pwm_freq, bool master, Real deadband, Uint16 adc_div, bool int_on_high);
```

The `adc_div` parameter specifies how often the PWM should trigger an ADC conversion, and the `int_on_high` parameter determines whether the trigger occurs during the high or low portion of the PWM cycle.

### 4.2 Synchronized Operation

The `Pwmdev_mc` class provides methods for synchronizing multiple PWM modules:

```cpp
void set_sync_enabled(bool enabled);
void mc_pwm_syncout_init(Real pwm_freq, Real pulse_width);
void set_phase_shift(Uint16 degrees);
```

This allows for precise timing relationships between multiple PWM outputs, which is critical for motor control applications like three-phase inverters.

### 4.3 Interrupt Coordination

Both the ADC and PWM modules provide methods for interrupt management:

```cpp
// ADC_mc
void enable_seq1_isr(Isrptr func);
void irq_ack();
void clear_irq_flags();

// Pwmdev_mc
void enable_isr(Isrptr func);
void irq_ack();
void clear_irq_flags();
```

This allows for coordinated interrupt handling, where an ADC conversion completion can trigger an interrupt that processes the sampled data and updates the PWM outputs accordingly.

## 5. Control Flow and State Transitions

### 5.1 ADC Control Flow

1. **Initialization**:
   - Create an `ADC_mc` instance with the appropriate reference voltage type
   - Call `mc_init` to configure the ADC for motor control
   - Register an interrupt handler with `enable_seq1_isr`

2. **Operation**:
   - PWM triggers ADC conversion automatically
   - ADC completes conversion and raises interrupt
   - Interrupt handler processes data
   - Call `irq_ack` to acknowledge the interrupt
   - Call `clear_irq_flags` to clear interrupt flags
   - For low-priority sequences, call `post_seq1` to manually trigger conversion

### 5.2 PWM Control Flow

1. **Initialization**:
   - Create a `Pwmsuite` instance with appropriate memory type and PWM range
   - Create `Pwmdev_mc` instances for each PWM
   - Call `mc_init` to configure each PWM for motor control
   - Configure synchronization if needed
   - Register interrupt handlers if needed

2. **Operation**:
   - Set PWM values with `set_value`
   - PWM outputs generate signals and trigger ADC conversions
   - Handle interrupts as needed
   - Use `disable` to safely shut down PWMs when done

### 5.3 State Transitions

| State | Trigger | Next State | Actions |
|-------|---------|------------|---------|
| Initialization | System startup | Configuration | Create instances, configure parameters |
| Configuration | Configuration complete | Idle | Enable interrupts, set initial values |
| Idle | PWM cycle | ADC Conversion | PWM triggers ADC conversion |
| ADC Conversion | Conversion complete | Processing | ADC raises interrupt |
| Processing | Processing complete | Idle | Update PWM values, acknowledge interrupt |
| Error | Trip zone event | Safe State | PWM outputs disabled by hardware |
| Shutdown | Application request | Disabled | Call `disable` to safely shut down PWMs |

## 6. Inputs and Stimuli

### 6.1 ADC Inputs

| Input | Type | Description | Effect |
|-------|------|-------------|--------|
| Reference Voltage Type | Vref_type | ADC reference voltage source | Determines ADC conversion scaling |
| Sequence Channels | Base::Mblock<const Base::Mblock<const ADCchannel>> | Channels to sample | Configures ADC sampling sequence |
| Acquisition Window Size | Uint16 | Acquisition window size in ticks | Sets ADC sampling time |
| System Resistance | Real | System resistance in ohms | Used for ADC timing calculations |
| System Capacitance | Real | System capacitance in farads | Used for ADC timing calculations |
| Interrupt Function | Isrptr | Function to call on interrupt | Registered as interrupt handler |

### 6.2 PWM Inputs

| Input | Type | Description | Effect |
|-------|------|-------------|--------|
| PWM ID | PWMid | PWM identifier | Selects which PWM to configure |
| Frequency | Real | PWM frequency in Hz | Sets PWM output frequency |
| Master Flag | bool | Master/slave configuration | Determines synchronization behavior |
| Deadband | Real | Deadband time in seconds | Sets deadband between complementary outputs |
| ADC Division | Uint16 | ADC trigger decimation | Controls how often ADC is triggered |
| Interrupt on High | bool | Trigger on high/low | Determines when ADC is triggered |
| Phase Shift | Uint16 | Phase shift in degrees | Sets phase shift from sync source |
| Trip Mode | Trip_mode | Trip zone mode | Configures fault protection |
| Trip Control | Tzctl | Trip zone control | Defines action on fault |

## 7. Outputs and Effects

### 7.1 ADC Outputs

| Output | Type | Description | Source |
|--------|------|-------------|--------|
| Raw Sample | Uint16 | Raw ADC conversion result | get_sample_raw() |
| Normalized Sample | Real | Normalized value (0-1) | get_sample_norm() |
| Voltage Sample | Real | Value in volts | get_sample_volts() |
| Interrupt | Hardware | ADC conversion complete | Configured by enable_seq1_isr() |

### 7.2 PWM Outputs

| Output | Type | Description | Source |
|--------|------|-------------|--------|
| PWM Signal | Hardware | PWM output on pins | set_value() |
| ADC Trigger | Hardware | Signal to start ADC conversion | Configured by mc_init() |
| Synchronization | Hardware | Sync signal for other PWMs | Configured by mc_pwm_syncout_init() |
| Interrupt | Hardware | PWM cycle complete | Configured by enable_isr() |

## 8. Parameters and Configuration

### 8.1 ADC Configuration

The `ADC_mc` class is configured through its constructor and the `mc_init` method:

```cpp
explicit ADC_mc(Vref_type vref_t);
void mc_init(const Base::Mblock<const Base::Mblock<const ADCchannel> >& sequence_channels,
             const Uint16 acquisition_window_size_tics,
             const Real rs,
             const Real cs);
```

Key configuration parameters:
- `vref_t`: Reference voltage type
- `sequence_channels`: Channels to sample in each sequence
- `acquisition_window_size_tics`: Acquisition window size in clock ticks
- `rs`: System resistance in ohms
- `cs`: System capacitance in farads

### 8.2 PWM Configuration

The `Pwmsuite` class is configured through its `Config` structure and the `cset` method:

```cpp
struct Config {
    static const Uint16 freq_def = Ku16::u50;
    Config();
    Uint16 freq;
    typename PWMDEV::Config cfg[2];
    void cset(Base::Lossy_error& str);
};
```

The `Pwmdev_mc` class is configured through its `mc_init` method:

```cpp
void mc_init(Real pwm_freq, bool master, Real deadband, Uint16 adc_div, bool int_on_high);
```

Key configuration parameters:
- `freq`: PWM frequency in Hz
- `pwm_freq`: Output module frequency in Hz
- `master`: Master/slave configuration
- `deadband`: Deadband time in seconds
- `adc_div`: ADC trigger decimation
- `int_on_high`: Trigger on high/low

## 9. Error Handling and Contingency Logic

### 9.1 PWM Trip Zone Protection

The `Pwmdev_mc` class provides trip zone protection for fault handling:

```cpp
void enable_trip_zone(Trip_mode mode, Tzctl ctl, bool enable);
```

This allows the PWM outputs to be automatically disabled if a fault condition is detected, without requiring software intervention.

### 9.2 Safe Disable Implementation

The `Pwmsuite::disable` method ensures that PWMs are disabled safely:

```cpp
void disable()
{
    Real min_freq = Const::MAX;
    for(Uint16 i=0; i<npwms; i++)
    {
        // Find minimum frequency and disable PWMs
    }
    Delay::ms(static_cast<Uint16>(Const::ONE/min_freq));
}
```

By waiting for a full period of the longest PWM cycle, this method ensures that signals are not chopped and the system shuts down gracefully.

### 9.3 Runtime Assertions

The code uses runtime assertions to check for valid parameters:

```cpp
if (Base::Assertions::runtime(pwmid0 < pwms_sum))
{
    // Set PWM value
}
```

This helps catch programming errors and prevent undefined behavior.

## 10. File-by-File Breakdown

### 10.1 ADC_mc.h

Defines the `ADC_mc` class, which extends the base `ADC` class to provide specialized analog-to-digital conversion capabilities for motor control applications.

Key features:
- Constructor with reference voltage type
- Methods for initializing motor control ADC
- Interrupt management methods
- Sequence control methods
- Simulation support

### 10.2 ADCch.h

Defines the `ADCch` template class, which provides an interface for interacting with a single channel of an ADC.

Key features:
- Template-based design
- Methods for retrieving samples in different formats
- Channel encapsulation

### 10.3 Pwmsuite.h

Defines the `Pwmsuite` template class, which manages and controls multiple PWM devices in the system.

Key features:
- Template-based design
- Configuration structure
- Methods for getting and setting PWM values
- Deserialization support
- Safe disable implementation

### 10.4 Pwmdev_mc.h

Defines the `Pwmdev_mc` class, which extends the base `Pwmdev` class to provide specialized PWM capabilities for motor control applications.

Key features:
- Motor control initialization
- Synchronization methods
- Phase shifting
- Trip zone protection
- Interrupt management

### 10.5 DMAtrigger.h and DMAtrigger.cpp

Define the `DMAtrigger` structure, which encapsulates DMA triggers for initiating DMA transfers based on various events.

Key features:
- Comprehensive trigger source enumeration
- Register access
- Type safety

## 11. Cross-Component Relationships

### 11.1 ADC and PWM Integration

The ADC and PWM modules are designed to work together for motor control applications:
- PWM can trigger ADC conversions at specific points in the PWM cycle
- ADC can process samples and update PWM values through interrupts
- Both modules support synchronization for precise timing

### 11.2 DMA Trigger Integration

The `DMAtrigger` structure provides a way to initiate DMA transfers based on ADC and PWM events:
- ADC events (e.g., `dma_adcaint1`) can trigger DMA transfers of conversion results
- PWM events (e.g., `dma_epwm1a`) can trigger DMA transfers for updating PWM values
- This enables high-speed, low-CPU-overhead data movement

### 11.3 Interrupt System Integration

Both the ADC and PWM modules integrate with the interrupt system:
- They provide methods for registering interrupt handlers
- They include methods for acknowledging interrupts and clearing flags
- This enables coordinated operation through interrupt-driven processing

## 12. Referenced Context Files

The following context files provided useful information for understanding the DSP28335 ADC and PWM modules:

- `Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/DSP28x/06_Core_Hardware_Abstraction.md`: Provided information about the core hardware abstraction layer, including register access mechanisms and interrupt handling.

- `Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/DSP28x/04_Timer_and_Capture.md`: Provided details about the timer and capture peripherals, which are related to the PWM functionality.

## 13. Summary

The DSP28335 ADC and PWM modules provide a comprehensive solution for motor control applications:

1. **ADC Module**:
   - The `ADC_mc` class provides specialized ADC capabilities for motor control
   - The `ADCch` template class simplifies access to individual ADC channels
   - Support for PWM-triggered conversions and interrupt-driven processing

2. **PWM Module**:
   - The `Pwmsuite` template class manages multiple PWM devices
   - The `Pwmdev_mc` class provides specialized PWM capabilities for motor control
   - Support for synchronization, phase shifting, and trip zone protection

3. **Integration**:
   - PWM can trigger ADC conversions at specific points in the PWM cycle
   - ADC can process samples and update PWM values through interrupts
   - DMA triggers enable high-speed, low-CPU-overhead data movement
   - Both modules support safe shutdown and error handling

This architecture provides a solid foundation for implementing sophisticated motor control algorithms on the DSP28335 microcontroller, with features like:
- Precise timing control
- Synchronized sampling
- Fault protection
- Efficient data processing

The modular, template-based design allows for flexibility and reuse, while the specialized motor control classes provide optimized functionality for this specific application domain.