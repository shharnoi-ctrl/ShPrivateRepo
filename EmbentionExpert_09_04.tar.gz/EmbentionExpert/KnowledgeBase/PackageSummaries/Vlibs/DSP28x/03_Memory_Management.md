# Generated from:

- code/include/Flash.h (218 tokens)
- code/include/Fsector.h (1320 tokens)
- code/include/User_otp.h (1172 tokens)
- code/include/Stackchk.h (307 tokens)
- code/include/tiiw.h (764 tokens)
- code/include/CM_helpers.h (992 tokens)
- code/source/Fsector.cpp (423 tokens)
- code/source/User_otp.cpp (426 tokens)
- code/source/Stackchk.cpp (1143 tokens)
- code/source/Sysaddr_sc.cpp (379 tokens)
- code/source/Sysaddr_mc.cpp (80 tokens)
- code/source/Sysuid_otp.cpp (191 tokens)
- code/source/dummy_malloc.c (88 tokens)
- code/source/Warning.cpp (59 tokens)
- code/source_SIL/Stackchk.cpp (78 tokens)

## With context from:

- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/DSP28x/06_Core_Hardware_Abstraction.md (3562 tokens)

---

# DSP28335 Memory Management Subsystem

This document provides a comprehensive analysis of the DSP28335 memory management subsystem, focusing on flash memory operations, one-time programmable (OTP) memory management, system addressing, and stack usage monitoring.

## 1. Flash Memory Management

### 1.1 Flash Initialization and Configuration

The `Flash` class provides core functionality for initializing the on-chip flash memory:

```cpp
class Flash {
public:
    static const Uint32 flash_start;  // Physical Flash on-chip memory start address
    static void init();               // Initialize Flash peripheral access timings
private:
    Flash();                          // = delete
    Flash(const Flash& orig);         // = delete
    Flash& operator=(const Flash& orig); // = delete
};
```

Key characteristics:
- The class is designed as a static utility class (all constructors are private)
- The `init()` method configures flash peripheral access timings through internal registers
- Must be executed from RAM, not from OTP/Flash, to avoid unpredictable results

### 1.2 Flash Sector Management

The `Fsector` class provides comprehensive management of flash memory sectors:

```cpp
class Fsector {
public:
    template<Uint32 sz0>
    explicit Fsector(const Uint16*(&sector_addresses0)[sz0]);
    int16 get_sector(const void* const addr, const Uint32 nwords) const;
    typedef Base::Tnarray<int16, Ku16::u2> Idx_pair;
    Idx_pair get_sectors(const void* const addr, const Uint32 nwords) const;
    const void* get_start(Uint16 sector_id) const;
    Uint32 get_size16(Uint16 sector_id) const;
    Uint32 get_size16_all() const;
    Uint16 get_nsectors() const;
private:
    const Base::Mblock<const void*> saddr;
    bool is_valid(Uint16 sector_id) const;
    int16 get_idx(const void* const addr) const;
};
```

#### 1.2.1 Sector Initialization

The constructor initializes the flash sector manager with a list of sector boundaries:

```cpp
template<Uint32 sz0>
inline Fsector::Fsector(const Uint16*(&sector_addresses0)[sz0]) :
    saddr(reinterpret_cast<const void**>(&sector_addresses0[0]), sz0)
{
}
```

- Takes an array of addresses representing sector boundaries
- For example, for 2 sectors of 0x100 words starting at 0x8000, the array would be {0x8000, 0x8100, 0x8200}
- The array should contain (number of sectors + 1) elements

#### 1.2.2 Sector Lookup and Management

The class provides several methods to work with flash sectors:

```cpp
int16 Fsector::get_idx(const void* const addr) const {
    int16 result = -1;
    if((saddr.size() > 0) && (addr >= saddr[0]) && (addr < (*saddr.last()))) {
        // at this point, addr can only be inside flash
        Uint32 inxt = 0; // unused
        Uint32 iprv = 0;
        Maverick::Find::sorted(saddr, addr, iprv, inxt);
        result = static_cast<int16>(iprv); // idx between 0 and (saddr.size()-2)
    }
    return result;
}
```

- `get_idx()`: Finds the sector index containing a given address
- `get_sector()`: Determines if an address range fits within a single sector
- `get_sectors()`: Returns the range of sectors needed for a memory block
- `get_start()`: Returns the start address of a sector
- `get_size16()`: Returns the size of a sector in 16-bit words
- `get_size16_all()`: Returns the total size of all sectors in 16-bit words
- `get_nsectors()`: Returns the total number of sectors

## 2. One-Time Programmable (OTP) Memory Management

### 2.1 User OTP Interface

The `User_otp` class provides functionality to read and write unique system identifiers (UID64) to OTP memory:

```cpp
class User_otp {
public:
    static const Uint32 user_otp_start;
    static const Uint32 user_otp_end;
    static const Bsp::Uid64& get_uid_ref();
    static bool set_uid(const Bsp::Uid64 uid0);
private:
    static const Uint64 u64_def = 0xFFFFFFFFFFFFFFFF;
    static const void* get_ptr0(const void* start0, const void* last0, bool search_def);
    static inline const void* get_fdef_ptr(const void* start0, const void* last0);
    static inline const void* get_lprg_ptr(const void* start0, const void* last0);
    static inline bool is_def_u64_otp(const Uint64 u64);
};
```

Key characteristics:
- OTP memory is one-time programmable (cannot be erased)
- Default state of OTP memory is 0xFFFF
- The class manages UID64 (User Identifier as 64-bit word) structures

### 2.2 UID64 Structure

The UID64 structure contains system identification information:

| Offset | Type   | Name | Content                           |
|--------|--------|------|-----------------------------------|
| 0      | Uint8  | app  | Application identifier            |
| 1      | Uint8  | hwv  | Hardware version identifier       |
| 2      | Uint8  | var  | Product variant identifier        |
| 3      | Uint8  | res  | Reserved                          |
| 4      | Uint32 | phy  | Physical address / System address |

### 2.3 OTP Memory Operations

The class provides methods to read and write UID64 values:

```cpp
const Bsp::Uid64& User_otp::get_uid_ref() {
    static Bsp::Uid64 uid_null = {0};
    const Bsp::Uid64* ptr = reinterpret_cast<const Bsp::Uid64*>(
            get_lprg_ptr(reinterpret_cast<const void*>(user_otp_start),
                         reinterpret_cast<const void*>(user_otp_end)));
    if(ptr==0) {
        uid_null.phy = Base::Address0::null;
        ptr = &uid_null;
    }
    return *ptr;
}

bool User_otp::set_uid(const Bsp::Uid64 uid0) {
    bool ret = false;
    const void* free = get_fdef_ptr(reinterpret_cast<const void*>(user_otp_start),
                                    reinterpret_cast<const void*>(user_otp_end));
    if(free) {
        Uint16* buffer = reinterpret_cast<Uint16*>(const_cast<Uint64*>(&(uid0.all)));
        ret = Bsp::Flash_wr::write_otp(reinterpret_cast<Uint32 *>(const_cast<void*>(free)), buffer, 4);
    }
    return ret;
}
```

- `get_uid_ref()`: Retrieves the last programmed UID64 from OTP memory
- `set_uid()`: Permanently stores a new UID64 in OTP memory
- Helper methods locate free or last programmed UID64 locations in OTP memory

### 2.4 OTP Memory Search Algorithm

The `get_ptr0()` method implements the search algorithm for OTP memory:

```cpp
const void* User_otp::get_ptr0(const void* start0, const void* last0, bool search_def) {
    const void* ret_ptr = 0;
    const Uint64* curr = reinterpret_cast<const Uint64*>(start0);
    const Uint64* const last = reinterpret_cast<const Uint64*>(last0);
    bool prev_ok = false;
    while(!ret_ptr && (curr < last)) {
        bool curr_is_def = is_def_u64_otp(*curr++);
        ret_ptr = (prev_ok && curr_is_def) ? reinterpret_cast<const void*>(curr-2) : 0;
        prev_ok = (search_def) ? curr_is_def : !curr_is_def;
    }
    return ret_ptr;
}
```

- When `search_def` is true, it finds the first UID64 next to two consecutive programmed ones (free location)
- When `search_def` is false, it finds the last not-yet programmed UID64 (last programmed location)

## 3. System Addressing

The system provides two different implementations for system addressing: single-core and multi-core.

### 3.1 Single-Core System Address Implementation

```cpp
// From code/source/Sysaddr_sc.cpp
namespace Bsp {
    namespace {
        volatile Base::Address0& get_address_prv() {
            static Base::Address ip_address = Base::Address(Base::Address0::null);
            return ip_address;
        }
        
        volatile Base::Address0& get_vsmaddr_prv() {
            static Base::Address vsm_addr = Base::Address(Base::Address0::null);
            return vsm_addr;
        }
    }

    volatile const Base::Address0& sysaddr() {
        return get_address_prv();
    }

    void set_sysaddr(Base::Address addr0) {
        get_address_prv().id = addr0.id;
    }

    const volatile Base::Address0& vsmaddr() {
        return get_vsmaddr_prv();
    }
}
```

Key characteristics:
- Uses static local variables to store system and VSM addresses
- Addresses are initially set to null and can be updated through `set_sysaddr()`
- Provides separate functions for system address and VSM address access

### 3.2 Multi-Core System Address Implementation

```cpp
// From code/source/Sysaddr_mc.cpp
namespace Bsp {
    volatile const Base::Address0& sysaddr() {
        return get_addr_location_k();
    }

    void set_sysaddr(Base::Address addr0) {
        get_addr_location().id = addr0.id;
    }

    const volatile Base::Address0& vsmaddr() {
        return get_kvsmaddr();
    }
}
```

Key characteristics:
- Uses different helper functions (`get_addr_location_k()`, `get_addr_location()`, `get_kvsmaddr()`)
- These functions likely access shared memory regions accessible by multiple cores
- Maintains the same interface as the single-core implementation

### 3.3 System UID from OTP

The `Sysuid_otp.cpp` file implements the `get_uid()` function to retrieve the system UID from OTP memory:

```cpp
namespace Bsp {
    namespace {
        Uid64 get_uid_aux() {
            const Uid64 otp_uid = Dsp28335_ent::User_otp::get_uid_ref();
            return otp_uid;
        }
    }

    Uid64 get_uid(bool force_read) {
        static Uid64 otp_uid = get_uid_aux();
        if (force_read) {
            otp_uid = get_uid_aux();
        }
        return otp_uid;
    }
}
```

- Caches the UID64 value in a static variable for efficiency
- Provides a `force_read` parameter to refresh the cached value if needed
- Uses the `User_otp::get_uid_ref()` function to access the OTP memory

## 4. Stack Usage Monitoring

### 4.1 Stack Check Implementation

The `Stackchk` class monitors stack usage to prevent stack overflow:

```cpp
class Stackchk {
public:
    Stackchk();
    bool check();
private:
    static const Uint16 fill_v = 0xA5A5;
    static const Uint16 check_cnt = 16;
    static const Uint16 check_margin = 32;
    Uint16 free;
};
```

Key characteristics:
- Initializes the stack with a known pattern (0xA5A5)
- Monitors how much of this pattern remains to determine stack usage
- Provides a warning when available stack space falls below a threshold

### 4.2 Stack Initialization

The constructor initializes the stack monitoring:

```cpp
Stackchk::Stackchk() : free(static_cast<Uint16>(get_stack_size())) {
    Uint16* pt = 0;
    Uint16 sp = 0;
    pt = &sp + sizeof(Uint16) + sizeof(Uint16*); // Do not override local objects
    free = get_stack_end() - pt;
    while(pt <= (get_stack_end()-1)) {
        *pt = fill_v;
        ++pt;
    }
}
```

- Retrieves stack size and end address from linker-generated variables
- Fills the stack area with the pattern value (0xA5A5)
- Calculates the initial free stack space

### 4.3 Stack Usage Checking

The `check()` method monitors stack usage:

```cpp
bool Stackchk::check() {
    Base::Assertions::Compile_time<(check_cnt > 8)>();

    const Uint16* end = get_stack_end();
    Uint16 const* top = get_stack_end() - free;
    Uint16 cnt = 0;

    if(&cnt >= end) {
        free = 0;
    } else {
        while((top < end) && (cnt < check_cnt)) {
            if(*top == fill_v) {
                ++cnt;
            } else {
                cnt = 0;
            }
            ++top;
        }
        top -= cnt;
        free = end - top;
    }
    bool res = (free > check_margin);
    return res;
}
```

- Looks for consecutive words with the pattern value (0xA5A5)
- Updates the `free` variable with the current available stack space
- Returns false if available space is less than the margin (32 words)

### 4.4 Stack Size and End Retrieval

The code uses linker-generated variables to determine stack parameters:

```cpp
inline Uint32 get_stack_size() {
    #if defined(__TI_EABI__)
        return reinterpret_cast<Uint32>(&__TI_STACK_SIZE);
    #else
        return reinterpret_cast<Uint32>(&_STACK_SIZE);
    #endif
}

inline Uint16 const* get_stack_end() {
    #if defined(__TI_EABI__)
        return &__TI_STACK_END;
    #else
        return &_STACK_END;
    #endif
}
```

- Supports both TI EABI and traditional naming conventions
- Retrieves stack size and end address from linker-generated variables

### 4.5 Simulation Environment Implementation

For the simulation environment, a simplified implementation is provided:

```cpp
// From code/source_SIL/Stackchk.cpp
Stackchk::Stackchk() : free(100) {
    //SIL_CODE: Do nothing
}

bool Stackchk::check() {
    return true; //SIL_CODE: stack is always ok in computer
}
```

- Assumes a fixed free stack size (100)
- Always returns true for stack checks in simulation

## 5. Dynamic Memory Allocation Prevention

The system explicitly prevents dynamic memory allocation by providing dummy implementations of standard memory allocation functions:

```cpp
// From code/source/dummy_malloc.c
_CODE_ACCESS void* malloc(size_t size) {
//    __asm(" ESTOP0");
    return 0;
}

_CODE_ACCESS void* calloc(size_t _num, size_t _size) {
    __asm(" ESTOP0");
    return 0;
}

_CODE_ACCESS void* realloc(void *_ptr, size_t _size) {
    __asm(" ESTOP0");
    return 0;
}

_CODE_ACCESS void free(void *userptr) {
    __asm(" ESTOP0");
}
```

Key characteristics:
- All dynamic memory allocation functions are overridden
- Most functions trigger a processor stop (ESTOP0) to catch usage at runtime
- `malloc()` simply returns null without stopping (possibly for compatibility)
- This ensures the system never uses heap memory, which is critical for deterministic embedded systems

## 6. Warning and Error Handling

The system provides basic warning and error handling mechanisms:

```cpp
// From code/source/Warning.cpp
namespace Bsp {
    void warning() {
        Dsp28335_ent::asm_stop();
    }

    bool warning_assrt(bool b) {
        if (!b) {
            Dsp28335_ent::asm_stop();
        }
        return b;
    }
}
```

- `warning()`: Triggers a processor stop
- `warning_assrt()`: Conditional warning that stops the processor if the condition is false

## 7. Template Instantiation Issues Workarounds

The `tiiw.h` file contains workarounds for C++ template instantiation issues:

```cpp
// From code/include/tiiw.h
namespace {
    template <typename T>
    struct Declval {
        static T& ref();
    };

    template <typename T>
    inline T& Declval<T>::ref() {
        T* ptr=0;
        return *ptr;
    }
    
    // Various template instantiation helper functions
    // ...
}
```

- Provides helper functions to force template instantiation
- Uses a `Declval` template to create references to types without constructing them
- Helps resolve template instantiation issues in the build process

## 8. Communication Manager Helpers

The `CM_helpers.h` file defines structures for configuring communication manager pins:

```cpp
namespace Dsp28335_ent {
    namespace CM_helpers {
        struct Pin_cfg {
            GPIOid id;
            GPIOtun::Mux mux;
        };
        
        struct Pinout_eth_mii {
            // MII ethernet pin configuration fields
            // ...
        };
        
        struct Pinout_eth_rmii {
            // RMII ethernet pin configuration fields
            // ...
        };
        
        struct Pinout_mii {
            Pin_cfg cm_uarta_rx;
            Pin_cfg cm_uarta_tx;
            Pinout_eth_mii eth;
        };
        
        struct Pinout_rmii {
            Pin_cfg cm_uarta_rx;
            Pin_cfg cm_uarta_tx;
            Pinout_eth_rmii eth;
        };
        
        void cm_init_start(const Pinout_mii& pinout);
        void cm_init_start(const Pinout_rmii& pinout);
        void cm_boot();
        void cm_init_end();
    }
}
```

- Defines structures for configuring MII and RMII Ethernet pins
- Provides functions for initializing and booting the communication manager
- Supports both MII and RMII Ethernet modes

## 9. Cross-Component Relationships

### 9.1 Flash and OTP Memory Integration

The flash and OTP memory subsystems are closely related:
- Both are non-volatile memory types on the DSP28335
- The `User_otp` class uses `Flash_wr::write_otp()` to write to OTP memory
- System identifiers stored in OTP are used for system addressing

### 9.2 System Address and OTP Integration

The system address subsystem integrates with OTP memory:
- System addresses are initially loaded from OTP memory
- The `get_uid()` function retrieves the UID64 from OTP memory
- The physical address component of the UID64 is used as the system address

### 9.3 Stack Monitoring and Memory Management

The stack monitoring subsystem is part of the overall memory management strategy:
- Prevents stack overflow by monitoring stack usage
- Works alongside the dynamic memory allocation prevention to ensure deterministic memory usage
- Both components help maintain system stability and predictability

## 10. Referenced Context Files

The following context files provided useful information for understanding the DSP28335 memory management subsystem:

- `Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/DSP28x/06_Core_Hardware_Abstraction.md`: Provided information about the core hardware abstraction layer, which helps understand how the memory management subsystem integrates with the hardware.

## Summary

The DSP28335 memory management subsystem provides comprehensive facilities for managing flash memory, OTP memory, system addressing, and stack usage. Key features include:

1. **Flash Memory Management**:
   - Initialization of flash peripheral access timings
   - Comprehensive sector management with address-to-sector mapping
   - Support for operations across multiple sectors

2. **OTP Memory Management**:
   - Storage and retrieval of system identifiers (UID64)
   - One-time programming of OTP memory
   - Structured format for system identification information

3. **System Addressing**:
   - Dual implementation for single-core and multi-core systems
   - Integration with OTP memory for system identifier retrieval
   - Support for both system addresses and VSM addresses

4. **Stack Usage Monitoring**:
   - Pattern-based stack usage detection
   - Early warning of potential stack overflow
   - Integration with linker-generated stack information

5. **Dynamic Memory Prevention**:
   - Explicit prevention of heap memory usage
   - Overriding of standard memory allocation functions
   - Processor stops to catch unintended dynamic memory usage

These components work together to provide a robust memory management subsystem that ensures deterministic behavior, prevents memory-related failures, and supports system identification and addressing needs.