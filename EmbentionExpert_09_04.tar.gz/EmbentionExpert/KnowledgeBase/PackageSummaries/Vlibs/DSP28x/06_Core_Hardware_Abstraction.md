# Generated from:

- code/include/DSP28x_types.h (112 tokens)
- code/include/Hregmap.h (491 tokens)
- code/include/Asm.h (1591 tokens)
- code/include/Dbgier_impl.h (95 tokens)
- code/include/Idisable.h (188 tokens)
- code/include/Reset.h (274 tokens)
- code/include/Isrptr.h (28 tokens)
- code/source/DSP28x_CodeStartBranch.asm (1139 tokens)
- code/source/DSP28x_DisInt.asm (558 tokens)
- code/source/Dbgier.asm (43 tokens)
- code/source/Dbgier_impl.cpp (162 tokens)
- code/include_SIL/Hregmap.h (443 tokens)
- code/include_SIL/Asm.h (223 tokens)
- code/include_SIL/Isrptr.h (26 tokens)
- code/source_SIL/Asm.cpp (46 tokens)

---

# DSP28335 Core Hardware Abstraction Layer

This document provides a comprehensive summary of the DSP28335 core hardware abstraction layer, focusing on how the code provides access to hardware registers, manages interrupts, controls processor state, and handles boot sequences.

## 1. Functional Behavior and Logic

### 1.1 Hardware Register Access

The core of the hardware abstraction layer is built around the `Hregmap` structure, which provides a template-based mechanism for accessing memory-mapped hardware registers.

#### Key Components:
- **Template-based Register Access**: Uses template parameters to specify register type and address
- **Volatile Register References**: Ensures compiler doesn't optimize away register access
- **Handler Class**: Provides a convenient wrapper for register access

```cpp
// From code/include/Hregmap.h
template <typename T, Uint32 addr>
inline volatile T& Hregmap::get()
{
    return (*reinterpret_cast<volatile T*>(addr));
}
```

The `Handler` class constructor initializes a reference to the hardware register:

```cpp
template <typename T, Uint32 addr>
inline Hregmap::Handler<T, addr>::Handler() : regs(Hregmap::get<T, addr>())
{
}
```

This approach allows for type-safe access to hardware registers while maintaining direct memory access performance.

### 1.2 Assembly Instruction Wrappers

The `Asm.h` file provides a comprehensive set of inline functions that wrap assembly instructions for controlling the processor state, managing interrupts, and performing debug operations.

#### Processor Control Functions:
- **Debug Operations**: `asm_stop()`, `asm_nop()`, `asm_itrap0()`
- **Pipeline Management**: `asm_pipeline_flush7()`, `asm_5NOP()`, `asm_20NOP()`, `asm_195NOP()`, `asm_200NOP()`, `asm_ALNOP()`
- **Interrupt Control**: `asm_eint()`, `asm_dint()`, `asm_ertm()`, `asm_drtm()`, `asm_DBGM()`
- **Register Protection**: `asm_eallow()`, `asm_edis()`

Each function is carefully documented with its purpose and the underlying assembly instruction it wraps:

```cpp
// From code/include/Asm.h
inline void asm_eint()
{
    __asm(" clrc INTM");
}

inline void asm_dint()
{
    __asm(" setc INTM");
}
```

### 1.3 Boot Sequence Management

The boot sequence is managed through assembly code in `DSP28x_CodeStartBranch.asm`, which handles the initial code execution after exiting the boot ROM.

#### Boot Sequence Flow:
1. Code starts at the `code_start` section, which is placed at the memory location where the BOOT ROM redirects execution
2. Optionally disables the watchdog timer (controlled by `WD_DISABLE` setting)
3. Branches to `_c_int00` to start the C runtime initialization

```assembly
// From code/source/DSP28x_CodeStartBranch.asm
code_start:
    .if WD_DISABLE == 1
        LB wd_disable       ;Branch to watchdog disable code
    .else
        LB _c_int00         ;Branch to start of boot._asm in RTS library
    .endif
```

The watchdog disable sequence:
```assembly
wd_disable:
    SETC OBJMODE        ;Set OBJMODE for 28x object code
    EALLOW              ;Enable EALLOW protected register access
    MOVZ DP, #7029h>>6  ;Set data page for WDCR register
    MOV @7029h, #0068h  ;Set WDDIS bit in WDCR to disable WD
    EDIS                ;Disable EALLOW protected register access
    LB _c_int00         ;Branch to start of boot._asm in RTS library
```

### 1.4 Interrupt Management

The HAL provides several mechanisms for managing interrupts:

#### 1.4.1 Debug Interrupt Enable Register (DBGIER)

The `Dbgier_impl.h` and `Dbgier_impl.cpp` files provide functions to configure the Debug Interrupt Enable Register:

```cpp
// From code/include/Dbgier_impl.h
void set_dbgier(unsigned char num);

// From code/source/Dbgier_impl.cpp
void set_dbgier(unsigned char num)
{
    set_DBGIER(num);
}
```

The actual implementation is in assembly (`Dbgier.asm`):
```assembly
// From code/source/Dbgier.asm
_set_DBGIER:
    MOV     *SP++,AL
    POP     DBGIER
    LRETR
```

#### 1.4.2 Global Interrupt Control

The `DSP28x_DisInt.asm` file provides functions to disable and restore global interrupts:

```assembly
// From code/source/DSP28x_DisInt.asm
_DSP28x_DisableInt:
_global_disable__Q2_3Bsp10InterruptsFv:
    PUSH  ST1
    SETC  INTM,DBGM
    MOV   AL, *--SP
    LRETR

_DSP28x_RestoreInt:
_global_restore__Q2_3Bsp10InterruptsFUi:
    MOV   *SP++, AL
    POP   ST1
    LRETR
```

These functions save and restore the processor status register (ST1) to properly manage interrupt state.

#### 1.4.3 Interrupt Service Routine Pointer Type

The `Isrptr.h` file defines a type for interrupt service routine pointers:

```cpp
// From code/include/Isrptr.h
typedef interrupt void(*Isrptr)(void);
```

## 2. Control Flow and State Transitions

### 2.1 Hardware Register Access Pattern

The control flow for hardware register access follows this pattern:

1. Create a `Handler` instance for a specific register type and address
2. Access the register through the `regs` member variable
3. Read or write to the register as needed

This pattern ensures type safety and encapsulation while maintaining direct access to hardware registers.

### 2.2 Interrupt Control Flow

The interrupt control flow involves several steps:

1. **Disable Interrupts**: Using `asm_dint()` or `DSP28x_DisableInt()`
2. **Perform Critical Operation**: Execute code that should not be interrupted
3. **Restore Interrupts**: Using `asm_eint()` or `DSP28x_RestoreInt()`

For debug interrupts, a similar pattern is used with `asm_drtm()` and `asm_ertm()`.

### 2.3 Protected Register Access

For registers protected by EALLOW, the control flow is:

1. **Enable Access**: Call `asm_eallow()`
2. **Modify Protected Registers**: Perform register operations
3. **Disable Access**: Call `asm_edis()`

## 3. Inputs and Stimuli

### 3.1 Hardware Register Templates

The primary input to the hardware register access system is the template parameters:

- **Type Parameter (T)**: Specifies the register structure type
- **Address Parameter (addr)**: Specifies the memory address of the register

These parameters are used at compile time to generate appropriate register access code.

### 3.2 Interrupt Configuration

Inputs for interrupt configuration include:

- **Interrupt Number**: Passed to `set_dbgier()` to enable specific debug interrupts
- **Previous Interrupt State**: Saved state from `DSP28x_DisableInt()` passed to `DSP28x_RestoreInt()`

## 4. Outputs and Effects

### 4.1 Hardware Register Modification

The primary effect of the HAL is direct modification of hardware registers, which controls the behavior of the DSP28335 processor and its peripherals.

### 4.2 Processor State Changes

The assembly wrappers directly modify processor state:

- **Interrupt Mask (INTM)**: Modified by `asm_eint()` and `asm_dint()`
- **Debug Mode (DBGM)**: Modified by `asm_ertm()`, `asm_drtm()`, and `asm_DBGM()`
- **EALLOW Protection**: Modified by `asm_eallow()` and `asm_edis()`

### 4.3 Pipeline Effects

Several functions affect the processor pipeline:

- `asm_pipeline_flush7()`: Inserts 7 NOPs to flush the pipeline
- `asm_5NOP()`, `asm_20NOP()`, `asm_195NOP()`, `asm_200NOP()`: Insert specific numbers of NOPs
- `asm_ALNOP()`: Inserts as many NOPs as specified in the AL register

## 5. Parameters and Configuration

### 5.1 Boot Configuration

- **WD_DISABLE**: Set to 1 to disable the watchdog timer during boot, 0 to leave it enabled
  - Defined in `DSP28x_CodeStartBranch.asm`
  - Controls whether the watchdog timer is disabled during the boot sequence

### 5.2 Data Types

The system defines specific data types for portability:

```cpp
// From code/include/DSP28x_types.h
typedef float              float32;
typedef long double        float64;
```

## 6. Error Handling and Contingency Logic

### 6.1 Debug Stop

The `asm_stop()` function provides a mechanism to halt execution when a critical error is detected:

```cpp
// From code/include/Asm.h
inline void asm_stop()
{
    #ifndef VCAST_COMPILE // Exception for JSF/PRQA required, ESTOP0 makes VectorCast testing fail.
    __asm(" ESTOP0");
    #endif
}
```

In the simulation environment, this is reimplemented to print an error message:

```cpp
// From code/source_SIL/Asm.cpp
void asm_stop()
{
    printf("Assertion raised\r\n");
}
```

### 6.2 Illegal Interrupt Trigger

The `asm_itrap0()` function can be used to deliberately trigger an illegal interrupt for testing or error handling:

```cpp
// From code/include/Asm.h
inline void asm_itrap0()
{
    __asm(" ITRAP0");
}
```

### 6.3 System Reset

The `Reset` class provides a mechanism for safely rebooting the system:

```cpp
// From code/include/Reset.h
class Reset : public Base::Ireset
{
public:
    explicit Reset(Idisable& idisable0);
    static void reset0();
    virtual void reset() const;
private:
    Idisable& idisable;
    // ...
};
```

The reset process involves:
1. Disabling peripherals through the `Idisable` interface
2. Performing the actual system reset

## 7. File-by-File Breakdown

### 7.1 Core Hardware Access

#### 7.1.1 Hregmap.h
- Defines the template-based hardware register access mechanism
- Provides the `Handler` class for convenient register access
- Implements the `get()` template function for direct register access

#### 7.1.2 Asm.h
- Provides inline functions that wrap assembly instructions
- Controls processor state, interrupts, and debug operations
- Includes functions for pipeline management

### 7.2 Interrupt Management

#### 7.2.1 Isrptr.h
- Defines the `Isrptr` type for interrupt service routine pointers
- Used for registering interrupt handlers

#### 7.2.2 Dbgier_impl.h and Dbgier_impl.cpp
- Provides the `set_dbgier()` function to configure debug interrupts
- Wraps the assembly implementation in `Dbgier.asm`

#### 7.2.3 DSP28x_DisInt.asm
- Implements functions to disable and restore global interrupts
- Preserves processor state during interrupt management

### 7.3 Boot and Reset

#### 7.3.1 DSP28x_CodeStartBranch.asm
- Handles the initial code execution after boot ROM
- Optionally disables the watchdog timer
- Branches to C runtime initialization

#### 7.3.2 Reset.h
- Defines the `Reset` class for system reboot
- Implements the `Ireset` interface
- Uses the `Idisable` interface to safely shut down peripherals

### 7.4 Simulation Support

#### 7.4.1 include_SIL/Hregmap.h
- Reimplements the hardware register access for simulation
- Uses static variables to simulate hardware registers

#### 7.4.2 include_SIL/Asm.h and source_SIL/Asm.cpp
- Provide simulation versions of the assembly wrapper functions
- Replace hardware-specific operations with simulation equivalents

#### 7.4.3 include_SIL/Isrptr.h
- Redefines the `Isrptr` type for the simulation environment
- Removes the `interrupt` keyword

## 8. Cross-Component Relationships

### 8.1 Hardware Access Pattern

The hardware access components form a layered architecture:

1. **Template-Based Register Access**: `Hregmap::get<T, addr>()`
2. **Register Handler**: `Hregmap::Handler<T, addr>`
3. **Peripheral-Specific Code**: Uses handlers to access registers

This pattern is used consistently across the codebase to provide type-safe, direct access to hardware registers.

### 8.2 Dual Implementation Strategy

The codebase uses a dual implementation strategy for hardware and simulation environments:

| Hardware Implementation | Simulation Implementation | Purpose |
|------------------------|---------------------------|---------|
| `code/include/Hregmap.h` | `code/include_SIL/Hregmap.h` | Hardware register access |
| `code/include/Asm.h` | `code/include_SIL/Asm.h` | Assembly instruction wrappers |
| `code/include/Isrptr.h` | `code/include_SIL/Isrptr.h` | Interrupt service routine pointers |

This allows the same high-level code to run in both hardware and simulation environments.

### 8.3 Interface Hierarchy

The codebase uses interfaces to define abstract capabilities:

- **Idisable**: Interface for disabling peripherals
- **Ireset**: Interface for system reset

These interfaces allow for dependency injection and modular design.

## 9. Referenced Context Files

The following context files provided useful information for understanding the DSP28335 core hardware abstraction layer:

- `code/include_SIL/SCI_Regs.h`: Register definitions for SCI peripheral used in simulation
- `code/include_SIL/SPI_Regs.h`: Register definitions for SPI peripheral used in simulation
- `code/include_SIL/ECAP_Regs.h`: Register definitions for ECAP peripheral used in simulation
- `code/include_SIL/Timer_Regs.h`: Register definitions for Timer peripheral used in simulation
- `code/include_SIL/I2Cif_Regs.h`: Register definitions for I2C peripheral used in simulation
- `code/source/common/Emif1_regs.h`: Register definitions for EMIF1 peripheral used in simulation

## Summary

The DSP28335 core hardware abstraction layer provides a comprehensive set of tools for accessing hardware registers, managing interrupts, controlling processor state, and handling boot sequences. The code uses a template-based approach for hardware register access, providing type safety and encapsulation while maintaining direct access to hardware. The dual implementation strategy allows the same high-level code to run in both hardware and simulation environments.

Key features include:
1. Template-based hardware register access
2. Assembly instruction wrappers for processor control
3. Interrupt management functions
4. Boot sequence handling
5. System reset capabilities
6. Dual implementation for hardware and simulation

This architecture provides a solid foundation for building higher-level peripheral drivers and application code on the DSP28335 platform.