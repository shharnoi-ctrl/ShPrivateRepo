# Generated from:

- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/DSP28x/06_Core_Hardware_Abstraction.md (3562 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/DSP28x/03_Memory_Management.md (4840 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/DSP28x/05_Interrupt_Management.md (4755 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/DSP28x/04_Timer_and_Capture.md (7102 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/DSP28x/03_ADC_and_PWM.md (6154 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/DSP28x/04_GPIO_Module.md (6220 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/DSP28x/03_Communication_Interfaces.md (7095 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/DSP28x/02_Test_Infrastructure.md (6532 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/DSP28x/02_Build_System.md (2355 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/DSP28x/01_System_Architecture.md (5078 tokens)

---

# DSP28335 Software System Overview

This document provides a comprehensive overview of the DSP28335 software system, serving as an entry point for understanding the system architecture and components.

## System Architecture

The DSP28335 software system is built as a layered architecture with clear separation of concerns:

1. **Core Hardware Abstraction Layer**: Provides direct access to hardware registers through template-based mechanisms
2. **Peripheral-Specific Drivers**: Built on top of the core HAL to provide peripheral functionality
3. **Utility Layer**: Provides common functionality used across different components
4. **Interface Layer**: Defines abstract interfaces for polymorphic behavior and dependency injection

A key architectural feature is the clean separation between hardware-specific and hardware-independent code:
- **Hardware-specific code**: Located in `include/` and `source/` directories
- **Hardware-independent code**: Located in `include_SIL/` and `source_SIL/` directories (Software-In-Loop simulation)

This separation enables the same high-level code to run in both hardware and simulation environments.

## Key Architectural Patterns

### Template-Based Hardware Access

The core hardware access pattern uses templates to provide type-safe access to hardware registers:

```cpp
template <typename T, Uint32 addr>
inline volatile T& Hregmap::get()
{
    return (*reinterpret_cast<volatile T*>(addr));
}
```

### Interface-Based Design

The library uses interfaces to define abstract capabilities:

```cpp
class IGpio {
public:
    virtual void set_hi() = 0;
    virtual void set_lo() = 0;
    virtual void set(bool v) = 0;
    virtual void toggle() = 0;
    virtual bool get() const = 0;
};
```

### Configuration Structures

Peripherals use dedicated configuration structures:

```cpp
struct SPIcfg {
    bool master;        // Flag to identify if working as master or slave
    Smode sm;           // SPI current mode
    Uint32 baudrate;    // Baudrate configured (no effect in slave mode)
    Uint16 nbits;       // Number of bits configured
    
    bool validate_spi() const;
    void cset(Base::Lossy_error& str);
};
```

## Major System Components

### Core Hardware Abstraction

The core hardware abstraction layer provides:
- Register access through `Hregmap`
- Assembly instruction wrappers in `Asm.h`
- Interrupt management through `Interrupts` namespace
- Reset functionality through `Reset` class

For more details, see [06_Core_Hardware_Abstraction.md](06_Core_Hardware_Abstraction.md).

### Memory Management

The memory management subsystem includes:
- Flash memory operations through `Flash` and `Fsector` classes
- One-time programmable (OTP) memory management through `User_otp`
- System addressing through `sysaddr()` and related functions
- Stack usage monitoring through `Stackchk`
- Dynamic memory allocation prevention through dummy implementations

For more details, see [03_Memory_Management.md](03_Memory_Management.md).

### Interrupt Management

The interrupt management system provides:
- Global interrupt state control
- Debug interrupt enable register configuration
- Interrupt service routine pointer types
- Critical section protection

For more details, see [05_Interrupt_Management.md](05_Interrupt_Management.md).

### Timer and Capture

The timer and capture peripherals provide:
- Precise timing operations through the `Timer` class
- Signal measurement through the `ECAP` class
- Busy-wait delays through the `Delay` utility
- Absolute time tracking through the `Absolute_time` utility

For more details, see [04_Timer_and_Capture.md](04_Timer_and_Capture.md).

### ADC and PWM

The ADC and PWM modules provide:
- Analog-to-digital conversion through the `ADC_mc` class
- Channel-specific ADC access through the `ADCch` template
- PWM management through the `Pwmsuite` template
- Motor control PWM through the `Pwmdev_mc` class
- DMA transfers through the `DMAtrigger` structure

For more details, see [03_ADC_and_PWM.md](03_ADC_and_PWM.md).

### GPIO Module

The GPIO module provides:
- Direct hardware control through the `GPIO` class
- Interface implementation through the `GPIOv` class
- Inverted behavior through the `GPIONOT` template
- Automatic toggling through the `GPIOtoggler` classes
- Precise pulse generation through the `GPIOpulse_action` class
- Crossbar configuration through the `GPIOxbar_in` class
- Configuration serialization through the `TGPIOtun` template

For more details, see [04_GPIO_Module.md](04_GPIO_Module.md).

### Communication Interfaces

The communication interfaces include:
- SPI communication through the `SPI` class
- Serial communication through the `SCI` class
- I2C communication through the `I2Cif` class
- I2C device abstraction through the `I2Cdevice` class
- I2C bus arbitration through the `I2Carbiter` class
- CAN-FD communication through the `CAN_FD` class

For more details, see [03_Communication_Interfaces.md](03_Communication_Interfaces.md).

## Testing and Build Infrastructure

### Test Infrastructure

The system includes a comprehensive test infrastructure:
- VectorCAST integration for automated testing
- Component-specific test files
- Mock objects for dependency isolation
- Coverage analysis for quality assurance

For more details, see [02_Test_Infrastructure.md](02_Test_Infrastructure.md).

### Build System

The build system supports:
- Eclipse project configuration for hardware and SIL targets
- C++17 language standard
- Position-independent code and threading support
- Linker command files for different deployment scenarios

For more details, see [02_Build_System.md](02_Build_System.md).

## System Architecture Diagram

```
+----------------------------------+
|        Application Layer         |
+----------------------------------+
                 |
+----------------------------------+
|        Interface Layer           |
| (IGpio, Itport_u16, etc.)        |
+----------------------------------+
                 |
+----------------------------------+
|      Peripheral Drivers          |
| (Timer, ECAP, ADC, PWM, GPIO,    |
|  SPI, SCI, I2C, CAN-FD)          |
+----------------------------------+
                 |
+----------------------------------+
|   Core Hardware Abstraction      |
| (Hregmap, Asm, Interrupts)       |
+----------------------------------+
                 |
+----------------------------------+
|        Hardware/SIL              |
| (DSP28335 / Simulation)          |
+----------------------------------+
```

## Conclusion

The DSP28335 software system provides a comprehensive set of components for embedded systems development. Its layered architecture, template-based hardware access, interface-based design, and dual implementation strategy make it a robust foundation for building applications on the DSP28335 microcontroller.

The system effectively balances performance and abstraction, providing zero-overhead access to hardware while maintaining a clean, object-oriented design. The comprehensive testing infrastructure and build system support ensure reliability and ease of development.

For more detailed information about specific components, please refer to the linked documents.