# Generated from:

- code/include/Feature.h (1617 tokens)
- code/include/Feature_fw.h (22 tokens)
- code/include/Fid.h (1675 tokens)
- code/include/Fref.h (1165 tokens)
- code/include/Fref_fw.h (21 tokens)
- code/include/Fsmem.h (3027 tokens)
- code/include/Fsmem_fw.h (35 tokens)
- code/include/Fstr.h (596 tokens)
- code/include/Fstr1.h (601 tokens)
- code/include/Fstrbase.h (541 tokens)
- code/include/Fstrt.h (406 tokens)
- code/include/Fstrtypes.h (939 tokens)
- code/source/Feature.cpp (1569 tokens)
- code/source/Fid.cpp (785 tokens)
- code/source/Fref.cpp (633 tokens)
- code/source/Fsmem.cpp (2584 tokens)
- code/source/Fstr.cpp (2822 tokens)
- code/source/Fstr1.cpp (387 tokens)
- code/source/Fstrt.cpp (789 tokens)

---

# Feature Management System: Comprehensive Summary

## 1. Functional Behavior and Logic

### Feature Representation System

The feature management system provides a comprehensive framework for representing, storing, and manipulating spatial positions within the system. Features represent positions that can be either absolute (in global coordinates) or relative to other features.

#### Core Feature Structure
The `Feature` struct is the fundamental building block for position representation:

```cpp
struct Feature {
    union Fdata {
        Tllhcompressed llh;  // Absolute position with centimeter precision
        Rv3 dr;             // Relative position with respect to wrt in meters
    };

    static const Uint16 wrt_abs = 0xFFFF;  // Id of absolute feature
    Uint16 wrt;                           // Id of reference feature (0xFFFF if absolute)
    Fdata data;                           // Position data (relative NED or absolute LLH)
};
```

This structure allows for two types of position representation:
1. **Absolute positions**: Stored in LLH (Longitude, Latitude, Height) coordinates over the WGS84 ellipsoid
2. **Relative positions**: Stored in local NED (North, East, Down) coordinates relative to another feature

#### Feature Identification System

Features are identified using the `Fid` enumeration, which organizes features into logical groups:

```cpp
enum Fid {
    // 0 - Approach features (0x0000-0x0009)
    ca_0a = 0x0000,
    // ...
    ca_all = 0x0009,

    // 1 - Climb features (0x0400-0x0409)
    cc_0a = 0x0400,
    // ...

    // 8 - Individual features (0x2000-0x2008)
    c_vpu = 0x2000,           // UAV position
    c_current_phase = 0x2001,
    c_vpuc = 0x2002,
    c_null = 0x2003,          // Value used when invalid ID is tried
    c_track = 0x2004,         // Closest point in route to current desired position
    // ...

    // 28 - Moving features (0x7000-0x7020)
    moving_00 = 0x7000,
    // ...
    moving_31 = 0x701F,
    moving_all = 0x7020,
    
    // 29 - Route waypoints (0x7400-0x7600)
    wp_0000 = 0x7400,
    // ...
    wp_0512 = 0x75FF,
    wp_all = 0x7600,
    
    // Additional feature groups...
};
```

The `Fidtrait` structure and `Jfid` type provide additional functionality for feature ID management:

```cpp
struct Fidtrait {
    typedef Fid Idtype;
    typedef Tnarray<Uint16,Ku16::u46> Sztype;
    static const Uint16 nbits_grp = 6;
    static const Fid nullid = c_null;
    static const Sztype szarray;
};

typedef Base::Jid<Fidtrait> Jfid;
```

### Feature Creation and Manipulation

The system provides several methods for creating and manipulating features:

#### Absolute Feature Creation
```cpp
// Create absolute feature from compressed LLH coordinates
static Feature build_abs(const Tllhcompressed& llh0);

// Create absolute feature from double precision LLH coordinates
static Feature build_abs(const Base::Tllh& llh0);

// Set a feature to absolute position
void set_abs(const Tllhcompressed& llh0);
void set_abs(const Base::Tllh& llh0);
```

#### Relative Feature Creation
```cpp
// Create relative feature with specific NED offset
static Feature build_rel(Fid wrt0, Real rx, Real ry, Real rz);

// Create relative feature with zero offset
static Feature build_rel(Fid wrt0);
```

#### Feature Type Checking
```cpp
// Check if feature is absolute
bool is_abs() const;

// Check if features can be set relative to a specific feature
static bool check_rel(const Fid wrt);
```

### Feature References

The `Fref` structure provides a way to either directly reference an existing feature or store a constant feature value:

```cpp
struct Fref {
    enum Type {
        fref = 0,      // Direct reference
        kval = 65534,  // Constant value
        none = 65535   // None value
    };

    Type type;           // Reference type
    Base::Fid id;        // Feature identifier
    Base::Feature value; // Local object with constant value
    
    // Methods for manipulating feature references
    static Fref build_fref(const Base::Fid id0, const Base::Feature& f0);
    bool is_abs() const;
    void set_ref(Base::Fid f);
    void set_ftr(const Feature& f);
    Feature get_feature() const;
    void get(Base::Feature& f) const;
};
```

## 2. Control Flow and State Transitions

### Feature Serialization and Deserialization

Features can be serialized to and deserialized from binary data streams:

```cpp
// Feature deserialization
void cset(Lossy_error& str);
void cset(U16stream_r_error& is);

// Feature serialization
void cget(Lossy& str) const;
void cget(U16stream_w& os) const;
```

The serialization format for features depends on whether they are absolute or relative:

For absolute features (wrt == 0xFFFF):
| Type | Name | Content | Range |
|------|------|---------|-------|
| Uint16 | wrt | 0xFFFF for absolute | - |
| Base::Tllhcompressed | llh | Absolute position in LLH WGS84 ellipsoid | - |

For relative features (wrt != 0xFFFF):
| Type | Name | Content | Range |
|------|------|---------|-------|
| Uint16 | wrt | Feature ID reference | see check_rel |
| Real | dr (N) | North component of position relative to wrt | - |
| Real | dr (E) | East component of position relative to wrt | - |
| Real | dr (D) | Down component of position relative to wrt | - |

### Feature Reference Serialization

Feature references also have serialization and deserialization methods:

```cpp
void cset(Base::Lossy_error& str);
void cget(Base::Lossy& str) const;
```

The serialization format for feature references:
| Type | Name | Description | Range |
|------|------|-------------|-------|
| Uint16 | type | Reference type | Fref::Type enum |
| Feature | value | Local object with constant value (if type == kval) | - |
| Uint16 | id | Feature identifier (if type == fref) | Base::Fid enum |

## 3. Inputs and Stimuli

### Feature System Inputs

The feature system accepts several types of inputs:

1. **Absolute Position Data**:
   - Compressed LLH coordinates (Tllhcompressed)
   - Double-precision LLH coordinates (Tllh)

2. **Relative Position Data**:
   - Reference feature ID (Fid)
   - North, East, Down offsets (Real values)

3. **Feature References**:
   - Direct references to existing features
   - Constant feature values

4. **Serialized Feature Data**:
   - Binary data streams for deserialization

### Feature Validation

The system validates inputs to ensure data integrity:

```cpp
// Validates that a feature can be referenced relatively
bool Feature::check_rel(const Fid wrt) {
    return ((wrt == c_vpu) ||
            (wrt == opn_home) ||
            (wrt == c_track) ||
            (wrt == c_vpuc) ||
            ((wrt >= opg_000) && (wrt <= opg_31)) ||
            ((wrt >= moving_00) && (wrt <= moving_31)));
}
```

Only specific features can be used as reference points for relative positioning, including:
- UAV position (c_vpu)
- Home position (opn_home)
- Track position (c_track)
- Desired position (c_vpuc)
- Generic operation features (opg_000 to opg_31)
- Moving object features (moving_00 to moving_31)

## 4. Outputs and Effects

### Feature System Outputs

The feature system produces several types of outputs:

1. **Feature Instances**:
   - Absolute features with global coordinates
   - Relative features with local coordinates

2. **Feature References**:
   - References to existing features
   - Constant feature values

3. **Serialized Feature Data**:
   - Binary data streams for storage or transmission

### Feature Data Access

The system provides methods to access feature data:

```cpp
// For Feature objects
bool is_abs() const;  // Check if feature is absolute

// For Fref objects
Feature get_feature() const;  // Get referenced feature
void get(Base::Feature& f) const;  // Get feature value
```

## 5. Parameters and Configuration

### Feature System Parameters

The feature system uses several important parameters:

1. **Feature Reference Constants**:
   ```cpp
   static const Uint16 wrt_abs = 0xFFFF;  // ID for absolute features
   ```

2. **Feature ID Organization**:
   - Features are organized into logical groups with specific ID ranges
   - Each group has an "all" identifier (e.g., ca_all, cc_all)

3. **Feature ID Traits**:
   ```cpp
   static const Uint16 nbits_grp = 6;  // Number of bits for group identification
   static const Fid nullid = c_null;   // Null feature ID
   ```

4. **Feature Reference Types**:
   ```cpp
   enum Type {
       fref = 0,      // Direct reference
       kval = 65534,  // Constant value
       none = 65535   // None value
   };
   ```

## 6. Error Handling and Contingency Logic

### Feature System Error Handling

The feature system includes several error handling mechanisms:

1. **Feature Reference Validation**:
   ```cpp
   // In Feature::cset
   str.assrt(check_rel(static_cast<Fid>(wrt)), Base::err_relf);
   ```
   If a feature is set relative to an invalid reference, the system raises a `Base::err_relf` error.

2. **Feature Reference Type Validation**:
   ```cpp
   // In Fref::cset
   str.assrt(type == fref, err_fref);
   ```
   If a feature reference has an invalid type, the system raises an `err_fref` error.

3. **Feature ID Validation**:
   ```cpp
   // In Fref::cset
   Jfid::validate_pdicheck(id, str.get_error());
   ```
   Validates that the feature ID is valid.

## 7. File-by-File Breakdown

### Feature.h / Feature.cpp

Defines the `Feature` structure for representing positions in absolute or relative coordinates:
- Provides methods for creating and manipulating features
- Implements serialization and deserialization
- Validates feature references

Key functionality:
- Feature creation (build_abs, build_rel)
- Feature type checking (is_abs)
- Feature reference validation (check_rel)
- Serialization and deserialization (cset, cget)

### Fid.h / Fid.cpp

Defines the feature identification system:
- Enumerates all feature IDs organized into logical groups
- Provides traits and utilities for feature ID management
- Implements functions to check feature write permissions

Key functionality:
- Feature ID enumeration (Fid)
- Feature ID traits (Fidtrait)
- Feature ID utilities (Jfid)
- Write permission checking (can_write_cpulo, user_writable)

### Fref.h / Fref.cpp

Defines the feature reference system:
- Provides a structure to either reference existing features or store constant feature values
- Implements methods to create and manipulate feature references
- Handles serialization and deserialization of feature references

Key functionality:
- Feature reference creation (build_fref)
- Feature reference type checking (is_abs)
- Feature reference manipulation (set_ref, set_ftr)
- Feature value retrieval (get_feature, get)
- Serialization and deserialization (cset, cget)

### Fsmem.h / Fsmem.cpp

Implements a memory-based file system for storing feature data:
- Manages file entries in memory or flash storage
- Provides methods for creating, finding, and removing files
- Handles file data access and manipulation

Key functionality:
- File system initialization
- File entry management (find_file, create_new)
- File data access (get_file_data)
- File system operations (clear, copy)

### Fstr.h / Fstr.cpp, Fstr1.h / Fstr1.cpp, Fstrt.h / Fstrt.cpp

Implement file serialization for feature data:
- `Fstr`: Base class for file serialization
- `Fstr1`: One-shot file serialization for event-driven logging
- `Fstrt`: Periodic file serialization for on-board logging

Key functionality:
- Data sampling and serialization
- Session management
- Asynchronous file operations
- Periodic and event-driven logging

### Fstrbase.h, Fstrtypes.h

Define base structures and types for feature serialization:
- `Fstrbase`: Base structure for log files
- `Fstrtfields`: Structure for on-board low-rate log fields
- `Fstr1fields`: Structure for event-driven log fields
- `FstrFast`: Structure for fast log fields

Key functionality:
- Field management for serialization
- Deserialization of log fields
- Memory block retrieval for fields

## 8. Cross-Component Relationships

### Feature and Feature ID Relationship

Features are identified by Feature IDs (Fid):
- Each feature has a unique ID from the Fid enumeration
- Features can reference other features using these IDs
- The system validates feature references based on ID

### Feature and Feature Reference Relationship

Feature references (Fref) can point to features:
- Direct references use a feature ID
- Constant values store a feature instance
- Feature references can be resolved to actual features

### Feature and File System Relationship

Features can be stored in the memory-based file system:
- Features are serialized to binary data
- Binary data is stored in files managed by Fsmem
- Files can be in RAM (writable) or flash (read-only)

### Feature and Logging Relationship

Features can be logged using the serialization system:
- `Fstr` provides base serialization functionality
- `Fstr1` handles event-driven logging
- `Fstrt` handles periodic logging
- Log fields are defined in `Fstrbase` and related structures

## 9. Referenced Context Files

The following context files provided valuable insights:

1. **Tllhcompressed.h**: Defines the compressed representation of longitude, latitude, and height used for absolute feature positions.

2. **Exyz.h**: Likely defines the coordinate system and vector types used for relative feature positions.

3. **Lossy_fw.h** and **Lossy_error.h**: Define the serialization and deserialization interfaces used by features.

4. **U16stream_r_error.h** and **U16stream_w.h**: Define the stream interfaces for 16-bit data used in feature serialization.

5. **Ifile.h**: Defines the file interface used by the memory-based file system.

6. **Itimeprovider.h**: Defines the time provider interface used for file timestamps.

7. **Ilogcontrol.h**: Defines the log control interface used by the serialization system.

8. **Session_fw.h**: Defines the session management interface used for logging.

## Summary

The feature management system provides a comprehensive framework for representing, storing, and manipulating spatial positions within the system. Features can be absolute (in global coordinates) or relative to other features, and they are identified by unique feature IDs organized into logical groups. The system includes mechanisms for feature creation, manipulation, validation, serialization, and logging. Features can be stored in a memory-based file system and referenced by other components of the system. The feature reference system allows for both direct references to existing features and constant feature values.