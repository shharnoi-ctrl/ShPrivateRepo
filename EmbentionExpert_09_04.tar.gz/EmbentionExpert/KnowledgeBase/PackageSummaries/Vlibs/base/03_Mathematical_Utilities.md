# Generated from:

- code/include/Angle_integer.h (3149 tokens)
- code/include/Sincos_integer.h (338 tokens)
- code/include/Isincos_signal.h (326 tokens)
- code/include/Iangular_estimator.h (732 tokens)
- code/include/Eangle_offset.h (445 tokens)
- code/include/Decimator.h (221 tokens)
- code/include/Int_decimator.h (654 tokens)
- code/include/Dbhyst.h (338 tokens)
- code/include/Limit.h (428 tokens)
- code/include/Lonlat.h (329 tokens)
- code/include/Modarith.h (490 tokens)
- code/include/Rand16.h (117 tokens)
- code/include/Sort3.h (1226 tokens)
- code/include/Wrapper_ref.h (584 tokens)
- code/source/Angle_integer.cpp (25 tokens)
- code/source/Sincos_integer.cpp (129 tokens)
- code/source/Eangle_offset.cpp (tokens unknown)
- code/source/Decimator.cpp (189 tokens)
- code/source/Int_decimator.cpp (543 tokens)
- code/source/Dbhyst.cpp (252 tokens)
- code/source/Limit.cpp (359 tokens)
- code/source/Lonlat.cpp (tokens unknown)
- code/source/Rand16.cpp (53 tokens)
- code/source/Sort3.cpp (tokens unknown)
- code/source/Wrapper_ref.cpp (351 tokens)

---

# Mathematical Utilities in the System

This document provides a comprehensive summary of the mathematical utilities in the system, focusing on angle representation, trigonometric functions, decimation, filtering, geographic coordinates, and various utility functions for mathematical operations.

## 1. Angle Representation and Trigonometric Functions

### 1.1 Angle_integer Class

The `Angle_integer` class provides a fixed-point representation of angles and associated trigonometric operations.

#### Key Characteristics:
- Uses unsigned integer representation for angles
- Provides conversion between radians and fixed-point representation
- Supports basic angle arithmetic operations (addition, subtraction, negation, multiplication)
- Offers trigonometric functions (sine, cosine) and approximations for inverse trigonometric functions

#### Implementation Details:

```cpp
class Angle_integer {
public:
    // Constructors
    Angle_integer();                // Default constructor
    Angle_integer(Real radians);    // Constructor from radians
    
    // Arithmetic operations
    Angle_integer operator+(const Angle_integer & rhs) const;
    Angle_integer& operator+=(const Angle_integer & rhs);
    Angle_integer operator-(const Angle_integer & rhs) const;
    Angle_integer operator-() const;
    Angle_integer& operator-=(const Angle_integer & rhs);
    Angle_integer operator*(int32 multiplier) const;
    
    // Accessors and trigonometric functions
    Real get_real() const;          // Get angle in radians [-Pi...+Pi)
    Real sin_int() const;           // Get sine of angle
    Real cos_int() const;           // Get cosine of angle
    
    // Static approximation functions
    static Real asin_approx(Real sin_theta);
    static Real atan_approx_pos(Real tan_theta);
    static Real atan_approx(Real tan_theta);
}
```

#### Fixed-Point Representation:
- Uses 25 bits for the fractional portion (`s_fixed_point_bits = 25`)
- This provides resolution comparable to single-precision floating point
- Can represent values up to 63*2*pi radians before overflow concerns

#### Trigonometric Approximations:
- `asin_approx`: Approximates arc-sine with varying accuracy based on angle magnitude
  - For θ < 25°: error ~0.1°
  - For θ < 45°: error ~1.25°
  - For θ < 60°: error ~4.25°
- `atan_approx_pos`: First quadrant arc-tangent approximation
- `atan_approx`: General arc-tangent approximation for first and fourth quadrants

### 1.2 Sincos_integer Class

The `Sincos_integer` class provides pre-calculated sine and cosine values using lookup tables.

#### Key Characteristics:
- Uses lookup tables for fast trigonometric calculations
- Provides 10-bit resolution (1024 entries) in the lookup table
- Supports direct access to sine and cosine values by index

#### Implementation Details:

```cpp
class Sincos_integer {
public:
    static const Uint32 s_lut_bits = 10;
    static const Uint32 s_lut_length = (0x1UL << s_lut_bits);  // 1024 entries
    
    Sincos_integer();  // Constructor that initializes the lookup table
    
    // Access functions
    Real sin_t(Uint32 index) const;  // Get sine value at index
    Real cos_t(Uint32 index) const;  // Get cosine value at index
    
private:
    Base::Array<Maverick::Sincos> sin_cos_table;  // Lookup table storage
};
```

#### Lookup Table Initialization:
The constructor initializes the lookup table with 1024 entries, calculating sine and cosine values at evenly spaced angles around the unit circle:

```cpp
Sincos_integer::Sincos_integer() :
        sin_cos_table(s_lut_length, Memmgr::external)
{
    const Real theta_step = (Const::PI2 / static_cast<Real>(s_lut_length));
    
    // fill the table
    for (Uint32 i = 0; i < s_lut_length; ++i)
    {
        const Real theta = (i * theta_step);
        const Maverick::Sincos sc(theta);
        sin_cos_table[i] = sc;
    }
}
```

### 1.3 Trigonometric Interfaces

#### 1.3.1 Isincos_signal Interface

An interface class for generating orthogonal sine and cosine signals:

```cpp
class Isincos_signal {
public:
    virtual ~Isincos_signal();
    virtual Maverick::Sincos get_sincos() const = 0;  // Get sine and cosine signals
    virtual bool is_ready() const = 0;                // Check if signal is ready
};
```

#### 1.3.2 Iangular_estimator Interface

An interface for angular estimation to compute speed from sensors and rotor poles:

```cpp
class Iangular_estimator {
public:
    virtual ~Iangular_estimator();
    virtual void step() = 0;                          // Perform a step and compute speed
    virtual Real get_speed() const = 0;               // Get current angular speed
    virtual Real get_angle() const = 0;               // Get current angle
    virtual bool is_ok() const = 0;                   // Check if estimator is ok
    virtual void set_offset(Real offset0) = 0;        // Set offset
    virtual void reset(Real theta0 = 0.0F, Real omega0 = 0.0F) = 0; // Reset parameters
    virtual Real get_error() const = 0;               // Get angle error in radians
};
```

## 2. Decimation and Filtering Utilities

### 2.1 Decimator Class

The `Decimator` class provides time-based decimation functionality.

#### Key Characteristics:
- Controls execution frequency based on time
- Uses system time to determine when to execute
- Configurable control period

#### Implementation Details:

```cpp
class Decimator {
public:
    Decimator();
    void reset();                           // Reset the timer
    bool step();                            // Check if it's time to execute
    void set_cp(const Real cp0);            // Set control period in seconds
    Real get_cp() const;                    // Get control period
    void cset(Base::Lossy_error& str);      // Deserialize configuration
    void cget(Base::Lossy& str) const;      // Serialize configuration
    
private:
    Real cp;                                // Control period (seconds)
    Ttime cptics;                           // Control period in tics
    Ttime last;                             // Last execution time
};
```

#### Operation:
- `step()` returns true when the elapsed time since the last execution exceeds the control period
- When true is returned, the last execution time is updated
- Control period is set in seconds but internally converted to system ticks

### 2.2 Int_decimator Class

The `Int_decimator` class provides integer-based decimation functionality.

#### Key Characteristics:
- Controls execution frequency based on count
- Works using integer multiples of base frequency
- Configurable decimation factor

#### Implementation Details:

```cpp
class Int_decimator {
public:
    Int_decimator();                                                // Default constructor
    Int_decimator(const Uint16 decimation0, bool step_first = false); // Constructor with decimation
    Int_decimator(const Real max_freq, const Real freq, bool step_first = false); // Constructor with frequencies
    
    bool step();                           // Update counter and check if decimation is complete
    Uint16 get_decimation() const;         // Get decimation factor
    
private:
    Uint16 decimation;                     // Decimation factor
    Uint16 counter;                        // Internal counter
};
```

#### Operation:
- `step()` returns true when the internal counter reaches zero
- Counter increments with each call and wraps around based on the decimation factor
- Can be initialized to execute on first call with `step_first = true`
- Frequency-based constructor calculates decimation factor from frequency ratio

### 2.3 Dbhyst Class (Dead Band with Hysteresis)

The `Dbhyst` class implements a dead band with hysteresis around zero.

#### Key Characteristics:
- Applies hysteresis to input signals
- Helps eliminate noise and oscillations around zero
- Configurable hysteresis value

#### Implementation Details:

```cpp
class Dbhyst {
public:
    Dbhyst();                              // Default constructor
    Real step(Real vin);                   // Apply hysteresis to input value
    void cset(Base::Lossy& str);           // Deserialize configuration
    void cget(Base::Lossy& str) const;     // Serialize configuration
    void reset();                          // Reset internal state
    bool check() const;                    // Check if configuration is valid
    
private:
    Real hyst;                             // Hysteresis configured value
    Real prev_vin;                         // Previous input
    Real prev_vout;                        // Previous output
};
```

#### Operation:
- When input crosses zero, output remains zero until input exceeds hysteresis threshold
- When input exceeds threshold, output becomes (input - hysteresis) with appropriate sign
- Maintains state between calls to track direction of input changes
- Hysteresis must be non-negative for valid configuration

## 3. Geographic Coordinate Handling

### 3.1 Lonlat Structure

The `Lonlat` structure manages 2D absolute positions using longitude and latitude.

#### Key Characteristics:
- Stores longitude and latitude in radians
- Uses double precision (Real64) for high accuracy
- Provides utility functions for initialization

#### Implementation Details:

```cpp
struct Lonlat {
    Real64 lon;                                        // Longitude in radians
    Real64 lat;                                        // Latitude in radians
    
    void zeros();                                      // Set both coordinates to zero
    static Lonlat build(const Real64 lon0, const Real64 lat0); // Create new instance
};
```

#### Usage:
- Geographic positioning
- Navigation calculations
- Mapping applications

## 4. Utility Functions

### 4.1 Limit Class

The `Limit` class manages limits for system variables.

#### Key Characteristics:
- Checks if a system variable is within allowed limits
- Supports minimum and maximum limit types
- Configurable through deserialization

#### Implementation Details:

```cpp
class Limit: public Base::Ideserializable {
public:
    enum Type {
        min = 0,     // Minimum type limit value
        max = 1,     // Maximum type limit value
        max_type = 2 // Max type of limits
    };
    
    Limit();                           // Default constructor
    bool check() const;                // Check if variable is within limits
    virtual void cset(Lossy_error& str); // Deserialize configuration
    
private:
    Vref var;                          // System variable
    Type type;                         // System variable type
    Vref limit;                        // System variable limit
};
```

#### Operation:
- For maximum limits: checks if variable < limit
- For minimum limits: checks if variable > limit
- Configuration includes variable reference, limit type, and limit value

### 4.2 Wrapper_ref Class

The `Wrapper_ref` class wraps real variables within configured minimum and maximum reference values.

#### Key Characteristics:
- Constrains values to a specified range
- Uses reference values for limits
- Configurable through serialization/deserialization

#### Implementation Details:

```cpp
class Wrapper_ref {
public:
    Wrapper_ref();                                // Default constructor
    bool wrap(Real& v) const;                     // Wrap value within limits
    void cset(Base::Lossy_error& str);            // Deserialize configuration
    void cget(Base::Lossy& str) const;            // Serialize configuration
    
private:
    Base::Vref min;                               // Minimum reference value
    Base::Vref max;                               // Maximum reference value
};
```

#### Operation:
- `wrap()` constrains the input value to the range [min, max]
- Returns true if the value was already within range, false if it was adjusted
- Configuration validates that min <= max

### 4.3 Eangle_offset Class

The `Eangle_offset` class computes offsets between wrapped angles.

#### Key Characteristics:
- Calculates and filters angle differences
- Tracks whether offset has been applied
- Uses exponential weighted moving average for filtering

#### Implementation Details:

```cpp
class Eangle_offset {
public:
    Eangle_offset(Real alpha0);                   // Constructor with filter gain
    void reset();                                 // Reset offset state
    void step(Real angle0, Real angle1);          // Compute angle offset
    void set_offset();                            // Mark offset as set
    bool get_is_offsetted() const;                // Check if offset is set
    Real get_diff() const;                        // Get computed difference
    
private:
    Real mean_diff;                               // Computed angle difference
    bool is_offsetted;                            // Offset is already set
    const Real alpha;                             // Filter gain
};
```

#### Operation:
- `step()` calculates the difference between two angles, wrapping to [-π, π]
- Applies exponential filtering to smooth the difference
- `set_offset()` marks that the offset has been applied

### 4.4 Modarith Namespace

The `Modarith` namespace provides modular arithmetic helper functions.

#### Key Characteristics:
- Handles cyclic/modular arithmetic operations
- Works with various integral types or pointers
- Provides functions for navigating ranges

#### Implementation Details:

```cpp
namespace Modarith {
    // Get next value in range [v0, vz]
    template <typename T>
    T next(T v0, T vz, T v);
    
    // Get next value in range [0, sz-1]
    template <typename T>
    T next(T sz, T v);
}
```

#### Operation:
- `next(v0, vz, v)` increments v by 1 if within range, otherwise returns v0
- `next(sz, v)` increments v by 1 if less than sz-1, otherwise returns 0
- Useful for circular buffers, state machines, and other cyclic structures

### 4.5 Rand16 Class

The `Rand16` class provides a fast 16-bit random number generator.

#### Key Characteristics:
- Simple linear congruential generator
- 16-bit output range
- Seedable for reproducible sequences

#### Implementation Details:

```cpp
class Rand16 {
public:
    static inline void srand(Uint32 seed0);       // Initialize random seed
    static Uint16 rand();                         // Get next random number
    
private:
    static Uint32 seed;                           // Random number seed
};
```

#### Operation:
- Uses the formula: seed = seed * 1103515245UL + 12345UL
- Returns the middle 16 bits of the resulting 32-bit value
- Not cryptographically secure, but fast and suitable for simple randomization

### 4.6 Sort3 Structure

The `Sort3` structure sorts three values in ascending order.

#### Key Characteristics:
- Sorts three values and tracks their original indices
- Template-based to work with different data types
- Optimized for the specific case of three elements

#### Implementation Details:

```cpp
struct Sort3 {
    typedef Tnarray<Uint16, Ku16::u3> Tindices;
    
    template<typename T>
    static void sort(typename JSF116_param<T>::type d0,
                     typename JSF116_param<T>::type d1,
                     typename JSF116_param<T>::type d2,
                     Tindices& idxs);
};
```

#### Operation:
- Compares the three input values and determines their sorted order
- Updates the indices array to reflect the sorted positions
- Uses a decision tree approach optimized for exactly three values

## 5. Practical Applications

### 5.1 Motor Control and Signal Processing

- `Angle_integer` and `Sincos_integer` provide efficient angle representation and trigonometric functions for motor control algorithms
- `Iangular_estimator` interface enables speed estimation from sensor inputs
- `Isincos_signal` interface supports generation of orthogonal signals for field-oriented control

### 5.2 Timing and Execution Control

- `Decimator` enables time-based execution control for periodic tasks
- `Int_decimator` provides count-based execution control for rate limiting
- Together they support different approaches to managing execution frequency

### 5.3 Signal Conditioning

- `Dbhyst` implements hysteresis for noise reduction in sensor readings
- `Wrapper_ref` constrains values to valid ranges
- `Limit` checks if values exceed operational boundaries

### 5.4 Navigation and Positioning

- `Lonlat` structure supports geographic coordinate representation
- Angle utilities provide functions needed for heading and bearing calculations

### 5.5 General Utilities

- `Modarith` supports cyclic operations common in embedded systems
- `Rand16` provides simple randomization capabilities
- `Sort3` offers efficient sorting for the specific case of three values

## 6. Referenced Context Files

The following context files provided useful information for understanding the mathematical utilities:

- `Entypes.h` - Defines basic types used throughout the system
- `Const.h` - Contains mathematical constants like PI
- `Rmath.h` - Provides basic math functions
- `Rfun.h` - Contains utility functions for mathematical operations
- `Array.h` - Implements array data structure used in lookup tables
- `Sincos.h` - Defines the Sincos structure used in trigonometric calculations
- `Ewma0.h` - Implements exponential weighted moving average filtering
- `Lossy_fw.h` and `Lossy_error_fw.h` - Support serialization/deserialization
- `Htime.h` - Provides time-related functions for the Decimator class
- `Vref.h` - Implements variable references used in Limit and Wrapper_ref classes