# Generated from:

- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/base/03_STANAG_Protocol.md (4559 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/base/03_Field_Message_System.md (4224 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/base/03_CAN_Communication.md (6410 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/base/03_Iridium_Communication.md (3305 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/base/03_ADSB_System.md (4428 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/base/03_Telemetry_System.md (5230 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/base/03_Security_Cryptography.md (2871 tokens)

---

# Comprehensive Communication Protocols and Data Exchange Framework

This document provides a detailed analysis of the communication protocols and data exchange mechanisms used throughout the system, synthesizing information from multiple subsystems to explain how data is formatted, secured, and transmitted between components.

## 1. Protocol Architecture Overview

The system implements a multi-layered communication architecture with several complementary protocols:

```
┌───────────────────────────────────────────────────────────────────┐
│                     Application Layer                             │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌──────────┐  │
│  │  Telemetry  │  │Field Message│  │  On-demand  │  │  Moving  │  │
│  │   System    │  │   System    │  │  Telemetry  │  │ Obstacle │  │
│  └──────┬──────┘  └──────┬──────┘  └──────┬──────┘  └────┬─────┘  │
└────────┼───────────────┼───────────────┼─────────────────┼────────┘
         │               │               │                 │
┌────────┼───────────────┼───────────────┼─────────────────┼────────┐
│        │               │               │                 │        │
│  ┌─────▼───────────────▼───────────────▼─────────────────▼─────┐  │
│  │                  Message Routing Layer                     │  │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────┐  │  │
│  │  │ STANAG Pkt  │  │ Pkt Router  │  │ Packet Processing   │  │  │
│  │  │   System    │  │             │  │    (Pkt64proc)      │  │  │
│  │  └──────┬──────┘  └──────┬──────┘  └──────────┬──────────┘  │  │
│  └─────────┼───────────────┼────────────────────┼──────────────┘  │
│            │               │                    │                 │
└────────────┼───────────────┼────────────────────┼─────────────────┘
             │               │                    │
┌────────────┼───────────────┼────────────────────┼─────────────────┐
│            │               │                    │                 │
│  ┌─────────▼───────────────▼────────────────────▼──────────────┐  │
│  │                  Transport Layer                           │  │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────┐  │  │
│  │  │ CAN System  │  │   Iridium   │  │       ADS-B         │  │  │
│  │  │             │  │   System    │  │       System        │  │  │
│  │  └──────┬──────┘  └──────┬──────┘  └──────────┬──────────┘  │  │
│  └─────────┼───────────────┼────────────────────┼──────────────┘  │
│            │               │                    │                 │
└────────────┼───────────────┼────────────────────┼─────────────────┘
             │               │                    │
┌────────────┼───────────────┼────────────────────┼─────────────────┐
│            │               │                    │                 │
│  ┌─────────▼───────┐  ┌────▼────┐  ┌───────────▼────────────┐     │
│  │ Physical Layer  │  │ Satellite│  │ RF Transmission Layer │     │
│  └─────────────────┘  └──────────┘  └────────────────────────┘     │
│                                                                    │
└────────────────────────────────────────────────────────────────────┘
```

## 2. Core Protocol: STANAG Packet System

The STANAG packet system forms the backbone of the communication architecture, providing a standardized format for message exchange.

### 2.1 Standard STANAG Packet Format

```
┌───────────────────┬───────────────────┬───────────────┐
│ Header (16 bytes) │ Payload (1-528B)  │ CRC (0-4B)    │
└───────────────────┴───────────────────┴───────────────┘

Header Structure:
┌─────────────┬─────────────┬─────────────┬─────────────┐
│ Reserved    │ Msg Length  │ Source      │ Destination │
│ (2 bytes)   │ (2 bytes)   │ (4 bytes)   │ (4 bytes)   │
├─────────────┼─────────────┴─────────────┴─────────────┤
│ Msg Type    │ Message Properties                      │
│ (2 bytes)   │ (2 bytes)                               │
└─────────────┴───────────────────────────────────────┘

Message Properties:
┌───┬───────────┬─────────┬───────────┐
│ACK│    IDD    │CHK_TYPE │ RESERVED  │
│(1)│   (7)     │  (2)    │   (6)     │
└───┴───────────┴─────────┴───────────┘
```

### 2.2 Embention Extended STANAG Format

The system extends the standard STANAG format with additional header fields:

```
┌─────────────────┬─────────────────┬─────────────────┬─────────┐
│ Extended Header │ STANAG Header   │ Payload         │ CRC32   │
│ (6 bytes)       │ (16 bytes)      │ (0-532 bytes)   │ (4B)    │
└─────────────────┴─────────────────┴─────────────────┴─────────┘

Extended Header:
┌─────────┬─────────┬───────────┬─────────┬───────────┐
│ Sync    │ Flags   │ Identifier│ Session │ Header CRC│
│ (1B)    │ (1B)    │ (2B)      │ (1B)    │ (1B)      │
└─────────┴─────────┴───────────┴─────────┴───────────┘

Flags:
┌─────────┬─────────┬───────────────────────┐
│ Crypted │ Reserved│         TTL           │
│ (1 bit) │ (1 bit) │       (6 bits)        │
└─────────┴─────────┴───────────────────────┘
```

## 3. Message Routing and Processing

### 3.1 Packet Router Architecture

The `Pkt_router` class forms the central hub for message routing:

```
┌───────────────────────────────────────────────────────────┐
│                      Pkt_router                           │
│                                                           │
│  ┌─────────────┐    ┌─────────────┐    ┌─────────────┐    │
│  │ Port 1      │    │ Port 2      │    │ Port N      │    │
│  │ (Serial)    │    │ (CAN)       │    │ (Iridium)   │    │
│  └──────┬──────┘    └──────┬──────┘    └──────┬──────┘    │
│         │                  │                  │           │
└─────────┼──────────────────┼──────────────────┼───────────┘
          │                  │                  │
┌─────────▼──────────────────▼──────────────────▼───────────┐
│                     Routing Table                          │
└───────────────────────────────────────────────────────────┘
```

The router:
1. Receives packets from ports
2. Examines destination addresses
3. Consults the routing table to determine appropriate output ports
4. Forwards packets to destination ports
5. Manages TTL (Time To Live) to prevent routing loops
6. Tracks packet identifiers to prevent duplicate processing

### 3.2 Packet Processing Pipeline

```
┌───────────────┐    ┌───────────────┐    ┌───────────────┐
│ Packet        │    │ Header        │    │ Payload       │
│ Reception     │──▶│ Processing    │──▶│ Processing    │
└───────────────┘    └───────────────┘    └───────────────┘
```

The `Pkt64proc` class implements a two-stage processing pipeline:
1. Header processing (`IHdrproc`) - Validates and potentially modifies headers
2. Data processing (`IDataproc`) - Processes payload data

This architecture allows for flexible processing chains, including:
- Encryption/decryption of payloads
- Compression/decompression
- Protocol translation
- Security filtering

## 4. Transport Layer Protocols

### 4.1 CAN Communication System

The CAN system provides reliable communication over Controller Area Network buses:

```
┌───────────────────────────────────────────────────────────┐
│                   CAN Communication                        │
│                                                           │
│  ┌─────────────┐    ┌─────────────┐    ┌─────────────┐    │
│  │ CANin_mgr   │    │ CANframe    │    │ CANout_mgr  │    │
│  │ (Reception) │    │ (Data)      │    │ (Transmission) │  │
│  └──────┬──────┘    └──────┬──────┘    └──────┬──────┘    │
│         │                  │                  │           │
│  ┌──────▼──────┐    ┌──────▼──────┐    ┌──────▼──────┐    │
│  │ CANin_p     │    │ CANid_filter│    │ CANout_c    │    │
│  │ (Producers) │    │ (Filtering) │    │ (Consumers) │    │
│  └─────────────┘    └─────────────┘    └─────────────┘    │
└───────────────────────────────────────────────────────────┘
```

Key features:
- Support for both standard (11-bit) and extended (29-bit) identifiers
- Message filtering based on ID and port
- FIFO buffering for message queuing
- Thread-safe implementation with atomic operations
- Serial-CAN conversion for tunneling CAN over serial links

### 4.2 Iridium Satellite Communication

The Iridium system enables global communication via satellite:

```
┌───────────────────────────────────────────────────────────┐
│                   Iridium Communication                    │
│                                                           │
│  ┌─────────────┐    ┌─────────────┐    ┌─────────────┐    │
│  │ State       │    │ ATcmd_task  │    │ ATmsg_parser│    │
│  │ Machine     │    │             │    │             │    │
│  └──────┬──────┘    └──────┬──────┘    └──────┬──────┘    │
│         │                  │                  │           │
│         ▼                  ▼                  ▼           │
│  ┌─────────────────────────────────────────────────────┐  │
│  │              Short Burst Data (SBD)                 │  │
│  └─────────────────────────────────────────────────────┘  │
└───────────────────────────────────────────────────────────┘
```

Key features:
- Short Burst Data (SBD) protocol for message exchange
- AT command interface to the satellite modem
- State machine for managing modem operations
- Support for Mobile Originated (MO) and Mobile Terminated (MT) messages
- Optional P2P addressing header for direct device-to-device communication

### 4.3 ADS-B System

The ADS-B system enables aircraft surveillance and communication:

```
┌───────────────────────────────────────────────────────────┐
│                   ADS-B Communication                      │
│                                                           │
│  ┌─────────────┐    ┌─────────────┐    ┌─────────────┐    │
│  │ ADSB_cfg    │    │ ADSB_Mavlink│    │ ADSB_Sagetech│   │
│  │             │    │             │    │             │    │
│  └──────┬──────┘    └──────┬──────┘    └──────┬──────┘    │
│         │                  │                  │           │
│         ▼                  ▼                  ▼           │
│  ┌─────────────────────────────────────────────────────┐  │
│  │              ADS-B IN/OUT Processing               │  │
│  └─────────────────────────────────────────────────────┘  │
└───────────────────────────────────────────────────────────┘
```

Key features:
- Support for multiple transponder models and protocols (MAVLink, Sagetech)
- ADS-B OUT for broadcasting aircraft position and status
- ADS-B IN for receiving data from other aircraft
- Configurable transmission and reception parameters
- Integration with system variables for data exchange

## 5. Application Layer Protocols

### 5.1 Field Message System

The Field Message System enables custom message definition and exchange:

```
┌───────────────────────────────────────────────────────────┐
│                   Field Message System                     │
│                                                           │
│  ┌─────────────┐    ┌─────────────┐    ┌─────────────┐    │
│  │ Fmsgmgr     │    │ Fmsgproducer│    │ Fmsgconsumer│    │
│  │             │    │             │    │             │    │
│  └──────┬──────┘    └──────┬──────┘    └──────┬──────┘    │
│         │                  │                  │           │
│         ▼                  ▼                  ▼           │
│  ┌─────────────────────────────────────────────────────┐  │
│  │              Message Configuration                  │  │
│  │           (Fmsg_cfg, Fmsg_trigger)                 │  │
│  └─────────────────────────────────────────────────────┘  │
└───────────────────────────────────────────────────────────┘
```

Key features:
- Custom message definition with field sets
- Producer-consumer architecture for message exchange
- Configurable message timing and triggering
- Message frequency monitoring
- Byte-level serialization and deserialization

### 5.2 Telemetry System

The Telemetry System provides structured data transmission:

```
┌───────────────────────────────────────────────────────────┐
│                   Telemetry System                         │
│                                                           │
│  ┌─────────────┐    ┌─────────────┐    ┌─────────────┐    │
│  │ Nominal     │    │Complementary│    │ On-demand   │    │
│  │ Telemetry   │    │ Telemetry   │    │ Telemetry   │    │
│  └──────┬──────┘    └──────┬──────┘    └──────┬──────┘    │
│         │                  │                  │           │
│         ▼                  ▼                  ▼           │
│  ┌─────────────────────────────────────────────────────┐  │
│  │              Datalink System                        │  │
│  │  (Datalink_buffer, Receiver, Transmitter)          │  │
│  └─────────────────────────────────────────────────────┘  │
└───────────────────────────────────────────────────────────┘
```

Key features:
- Three telemetry types (Nominal, Complementary, On-demand)
- Vectorized field structure for data organization
- Configurable transmission periods and destinations
- Expiration functionality for on-demand telemetry
- Reliable data transfer with acknowledgment and retransmission

## 6. Data Formats and Serialization

### 6.1 Common Data Structures

The system uses several common data structures across protocols:

1. **Address Format**: 32-bit identifiers for source and destination
   ```
   ┌───────────┬───────────┬───────────┬───────────┐
   │ Network ID │ Group ID  │ Node Type │ Node ID   │
   │ (8 bits)   │ (8 bits)  │ (8 bits)  │ (8 bits)  │
   └───────────┴───────────┴───────────┴───────────┘
   ```

2. **Message Data Structure**:
   ```cpp
   struct Msg_data {
       Address dst;                        // Destination address
       Stanag_msg_type::Msg_type mtype;    // Message type
       Uint16 sub_mtype;                   // Message subtype
       Stimestamp ts;                      // Original timestamp
       Ack_type ack_t;                     // Acknowledgement type
       Presence_vec pres_vec_req;          // Presence vector requested
       bool req_ack;                       // Request ACK
   };
   ```

3. **Moving Obstacle Data**:
   ```cpp
   class Mobs_data {
       Uint32 id;                      // ICAO address for ADS-B
       Base::Feature pos;              // Position
       Maverick::Rvector3 vel;         // Velocity
       Real heading;                   // Heading
       Flags flags;                    // Validity flags
       ADSB_Mavlink::Emitter_type emitter_type; // Emitter type
       Real tslc;                      // Time since last communication
       Uint16 squawk;                  // Squawk code
       Callsign callsign;              // Call-sign
   };
   ```

4. **Position Data**:
   ```cpp
   class Apos_data {
       Base::Tllh llh;  // Absolute position (longitude, latitude, WGS84 height)
       Base::Tllcs cs;  // Sines and cosines of longitude and latitude
   };
   ```

### 6.2 Serialization Mechanisms

The system uses several serialization approaches:

1. **PDIC (Parameter Data Interchange Container)**:
   - Used for configuration serialization/deserialization
   - Implemented via `Lossy` and `Lossy_error` classes
   - Supports various data types (integers, floats, strings, arrays)
   - Used in `cset()` and `cget()` methods throughout the system

2. **Binary Serialization**:
   - Used for efficient wire transmission
   - Implemented via stream classes (`U8ostream`, `U8istream`)
   - Handles endianness conversion when needed
   - Supports various data types with explicit size control

3. **Field-based Serialization**:
   - Used in the Field Message System
   - Maps system variables to message fields
   - Supports different field types and sizes
   - Handles field presence vectors for optional fields

## 7. Security and Data Integrity

### 7.1 Encryption and Authentication

The system implements several security mechanisms:

```
┌───────────────────────────────────────────────────────────┐
│                   Security Components                      │
│                                                           │
│  ┌─────────────┐    ┌─────────────┐    ┌─────────────┐    │
│  │ AES         │    │ Cryptermgr  │    │ Permission  │    │
│  │ Encryption  │    │             │    │ System      │    │
│  └──────┬──────┘    └──────┬──────┘    └──────┬──────┘    │
│         │                  │                  │           │
│         ▼                  ▼                  ▼           │
│  ┌─────────────────────────────────────────────────────┐  │
│  │              Data Processors                        │  │
│  │       (DCencrypt, DCdecrypt, Hdrcrypt)             │  │
│  └─────────────────────────────────────────────────────┘  │
└───────────────────────────────────────────────────────────┘
```

Key features:
- AES encryption (128, 192, 256-bit keys)
- Support for ECB and CBC modes
- Header and payload encryption
- Permission-based access control
- Interface-based design for cryptographic algorithms

### 7.2 Data Integrity Mechanisms

The system implements multiple checksum and CRC algorithms:

1. **CRC32**: Standard 32-bit CRC for file integrity
2. **CRC16**: Various 16-bit CRC implementations for different protocols
3. **MAVLink CRC**: Specialized CRC for MAVLink protocol
4. **Fletcher Checksum**: For Ublox GNSS receivers
5. **Sagetech Checksum**: Specialized for Sagetech XP Series
6. **Simple Checksums**: Basic addition-based checksums

These mechanisms ensure data integrity across different communication channels and protocols.

## 8. Common Communication Patterns

### 8.1 Producer-Consumer Pattern

The system extensively uses the producer-consumer pattern:

```
┌───────────────┐    ┌───────────────┐    ┌───────────────┐
│ Producer      │    │ Buffer/Queue  │    │ Consumer      │
│ Interface     │──▶│               │──▶│ Interface     │
└───────────────┘    └───────────────┘    └───────────────┘
```

Examples:
- `Itproducer_can`/`Itconsumer_can` for CAN communication
- `Itproducer_u8`/`Itconsumer_u8` for byte-level communication
- `Fmsgproducer`/`Fmsgconsumer` for field messages

This pattern enables:
- Decoupling of data production and consumption
- Buffering for asynchronous communication
- Thread safety through appropriate buffer implementations
- Standardized interfaces for different data types

### 8.2 Request-Response Pattern

For command and control operations:

```
┌───────────────┐    ┌───────────────┐    ┌───────────────┐
│ Requester     │──▶│ Command        │──▶│ Responder     │
│               │    │ (with ID)     │    │               │
└───────────────┘    └───────────────┘    └───────────────┘
                            ▲                     │
                            │                     │
                            └─────────────────────┘
                                  Response
                               (with same ID)
```

Examples:
- Telemetry requests and responses
- Configuration commands and acknowledgments
- Status queries and reports

### 8.3 Publish-Subscribe Pattern

For one-to-many communication:

```
┌───────────────┐
│ Publisher     │
└───────┬───────┘
        │
        ▼
┌───────────────┐
│ Topic/Channel │
└───────┬───────┘
        │
        ├─────────────┬─────────────┐
        │             │             │
        ▼             ▼             ▼
┌───────────────┐ ┌───────────────┐ ┌───────────────┐
│ Subscriber 1  │ │ Subscriber 2  │ │ Subscriber 3  │
└───────────────┘ └───────────────┘ └───────────────┘
```

Examples:
- Telemetry broadcasting to multiple destinations
- Status updates to multiple systems
- Alert notifications

## 9. Protocol Integration and Interoperability

### 9.1 Protocol Bridging

The system implements several protocol bridges:

1. **CAN-Serial Bridge**:
   - `CANserial`: Converts CAN frames to serial data
   - `SerialCAN`: Converts serial data to CAN frames
   - Enables tunneling CAN over serial links

2. **STANAG-CAN Bridge**:
   - Converts between STANAG packets and CAN frames
   - Enables routing STANAG messages over CAN networks

3. **Iridium-STANAG Bridge**:
   - Encapsulates STANAG packets in Iridium SBD messages
   - Enables global routing of STANAG messages

### 9.2 Protocol Translation

The system supports protocol translation through:

1. **Packet Processors**:
   - `Pkt64proc` provides a framework for packet transformation
   - Header and data processors can modify packet format and content

2. **Field Mapping**:
   - Field Message System maps between different field formats
   - Enables translation between different message structures

3. **Data Adapters**:
   - Adapter classes convert between different data representations
   - Enables interoperability between different subsystems

## 10. Reliability and Error Handling

### 10.1 Acknowledgment and Retransmission

The system implements several reliability mechanisms:

1. **STANAG Acknowledgments**:
   - ACK bit in message properties
   - Explicit acknowledgment messages
   - Support for different acknowledgment types (received, completed, rejected)

2. **Datalink Reliability**:
   - Window-based transmission protocol
   - Selective acknowledgment of received blocks
   - Retransmission of unacknowledged blocks

3. **Timeout Handling**:
   - Configurable timeouts for different operations
   - Timeout detection and recovery
   - Expiration of stale data

### 10.2 Error Detection and Recovery

The system implements robust error handling:

1. **CRC Validation**:
   - Multiple CRC algorithms for different protocols
   - Validation before processing received data
   - Rejection of corrupted messages

2. **State Machine Recovery**:
   - Well-defined state transitions
   - Error states with recovery paths
   - Timeout-based state resets

3. **Buffer Management**:
   - Overflow detection and handling
   - Discarding of oldest data when buffers are full
   - Tracking of discarded messages

## 11. Common Communication Abstractions

Throughout the system, several key abstractions enable flexible and extensible communication:

### 11.1 Interface-Based Design

The system uses interfaces to define communication contracts:

```cpp
// Producer interface for CAN frames
class Itproducer_can {
public:
    virtual bool read(CANframe& frame) = 0;
};

// Consumer interface for CAN frames
class Itconsumer_can {
public:
    virtual bool write(const CANframe& data) = 0;
    virtual bool wr_available() const = 0;
};
```

This approach enables:
- Polymorphic behavior for different implementations
- Dependency injection for testing and configuration
- Clear separation of concerns

### 11.2 Composition-Based Architecture

The system uses composition to build complex communication components:

```cpp
// CAN-Serial converter uses composition
class CANserial : public Itconsumer_can, public Itproducer_u8 {
private:
    Windowbuff<CANdata> wb;  // Window buffer for data
    // Other implementation details
};
```

This approach enables:
- Flexible combination of different components
- Reuse of common functionality
- Clear separation of responsibilities

### 11.3 Configuration-Driven Behavior

The system uses configuration structures to define communication behavior:

```cpp
// Configuration for CAN input
struct Config {
    CANport::Port port;    // Accepted ports
    In_filter filter;      // CAN ID enhanced filter
    
    bool match(CANpid port0, const CANid& id) const;
    static Config build_default();
    void cset(Lossy_error& str);
};
```

This approach enables:
- Runtime configuration of communication components
- Serialization and deserialization of configurations
- Default behaviors with customization options

## 12. Conclusion: A Unified Communication Framework

The system implements a comprehensive communication framework that spans multiple protocols, layers, and use cases. Key strengths include:

1. **Protocol Flexibility**: Support for multiple protocols (STANAG, CAN, Iridium, ADS-B) with bridges between them

2. **Layered Architecture**: Clear separation between application, routing, transport, and physical layers

3. **Security Integration**: Built-in encryption, authentication, and integrity checking

4. **Reliability Mechanisms**: Acknowledgment, retransmission, and error recovery across protocols

5. **Extensible Design**: Interface-based design and composition enable easy extension

6. **Configuration Options**: Extensive configuration options for all communication components

7. **Performance Optimization**: Efficient buffer management and processing pipelines

The communication framework provides a solid foundation for reliable, secure, and flexible data exchange between system components and with external systems.