# Generated from:

- code/include/CANdata.h (633 tokens)
- code/include/CANframe.h (181 tokens)
- code/include/CANframe_fifo32.h (884 tokens)
- code/include/CANid.h (742 tokens)
- code/include/CANid_filter.h (219 tokens)
- code/include/CANids.h (403 tokens)
- code/include/CANin_mgr.h (855 tokens)
- code/include/CANin_p.h (1567 tokens)
- code/include/CANin_suite.h (320 tokens)
- code/include/CANout_c.h (1272 tokens)
- code/include/CANout_mgr.h (1055 tokens)
- code/include/CANout_suite.h (316 tokens)
- code/include/CANport.h (485 tokens)
- code/include/CANserial.h (726 tokens)
- code/include/CANserial_parser.h (791 tokens)
- code/include/CANstdp.h (463 tokens)
- code/include/CANunwrapper.h (555 tokens)
- code/include/CANwrapper.h (572 tokens)
- code/include/CAN_stats.h (330 tokens)
- code/include/ICAN_drv.h (63 tokens)
- code/include/SerialCAN.h (1289 tokens)
- code/source/CANid.cpp (215 tokens)
- code/source/CANid_filter.cpp (221 tokens)
- code/source/CANin_mgr.cpp (1055 tokens)
- code/source/CANin_p.cpp (504 tokens)
- code/source/CANout_mgr.cpp (2002 tokens)
- code/source/CANserial.cpp (914 tokens)
- code/source/CANserial_parser.cpp (2274 tokens)
- code/source/CANunwrapper.cpp (283 tokens)
- code/source/CANwrapper.cpp (780 tokens)
- code/source/CAN_stats.cpp (221 tokens)
- code/source/CANframe.cpp (68 tokens)
- code/source/CANframe_fifo32.cpp (651 tokens)
- code/source/SerialCAN.cpp (777 tokens)

---

# CAN Communication System: Comprehensive Summary

This document provides a detailed analysis of the CAN communication system, covering data structures, input/output management, filtering mechanisms, serial-CAN conversion, and protocol definitions.

## 1. Core Data Structures

### 1.1 CANdata
`CANdata` is a fundamental structure for storing CAN message payloads:

```cpp
struct CANdata {
    static const Uint8 length_max_std = 8;   // Max data length for standard CAN
    static const Uint8 length_max_fd = 64;   // Max data length for CAN-FD
    
    typedef Base::U8pkrszarray<length_max_fd> CANdata_type;
    CANdata_type data;      // CAN data buffer
    
    // Core operations:
    Uint8 get(Uint8 i) const;                    // Get byte at index
    void set(Uint8 i, Uint8 value);              // Set byte at index
    Uint8 get_length() const;                    // Get buffer length
    const Mblock<const Uint32> to_mblock32() const;  // Get data as 32-bit words (const)
    Mblock<Uint32> to_mblock32();                // Get data as 32-bit words
}
```

The structure uses a resizable byte array with a maximum capacity of 64 bytes (for CAN-FD) and provides methods to access individual bytes, get the buffer length, and convert the data to 32-bit word blocks for efficient processing.

### 1.2 CANid
`CANid` manages the identifier in CAN messages:

```cpp
class CANid {
private:
    static const Uint16 id_bits_standard = 11;      // Standard format id length
    static const Uint16 id_bits_extended = 29;      // Extended format id length
    static const Uint16 extended_mask_pos = 31;     // Extended mask position
    static const Uint32 extended_mask = Bitutils::get_mask_1bit_c<Uint32,extended_mask_pos>::value;
    
public:
    static const Uint32 id_msk_std = Lsbmask<Uint32, id_bits_standard>::value; // 11-bit mask
    static const Uint32 id_msk_ext = Lsbmask<Uint32, id_bits_extended>::value; // 29-bit mask
    
    bool extended;      // Extended mode flag
    Uint32 id;          // CAN id
    
    // Core operations:
    bool equals(const volatile CANid& id0) const;   // Check equality
    void cset(Lossy_error& str);                    // Deserialize from PDIC
    void set_packed_id(Uint32 id0);                 // Set packed id
    Uint32 get_packed_id() const;                   // Get packed id
    Uint32 get_max() const;                         // Get max id based on extended flag
    bool operator == (const CANid &c);              // Equality operator
}
```

The class handles both standard (11-bit) and extended (29-bit) CAN identifiers, with methods to pack/unpack the ID and check for equality.

### 1.3 CANframe
`CANframe` combines a CAN identifier with data:

```cpp
struct CANframe {
    CANid id;       // CAN id for this message
    CANdata data;   // Data in the message
    
    // Builder method
    static CANframe build(const bool extended, const Uint32 id, const Uint32 sz);
}
```

This structure represents a complete CAN message with both identifier and payload, providing a builder method to create frames with specified parameters.

### 1.4 CANframe_fifo32
`CANframe_fifo32` implements a FIFO buffer for CAN frames:

```cpp
class CANframe_fifo32 {
private:
    static const Uint16 hdr_data_sz_w32 = 1 + 1;    // Header size (ID + size)
    
public:
    CANframe_fifo32(Uint32 sz_bytes, Memmgr::Type mtype);
    
    bool wr_available() const;                      // Check if write is available (max size)
    bool wr_available(Uint8 sz_bytes) const;        // Check if write is available for given size
    bool wr_available(const CANframe& frame) const; // Check if write is available for frame
    bool write(const CANframe& frame);              // Write frame to buffer
    bool rd_available() const;                      // Check if read is available
    bool read(CANframe& frame);                     // Read frame from buffer
    
private:
    Array<Uint32> buffer;                           // FIFO buffer
    Fifospscwr_commit<Uint32> fifo;                 // FIFO with "atomic" write
}
```

This class provides a thread-safe FIFO buffer for CAN frames, optimized for performance by using 32-bit words as the data unit. It supports checking for available space before writing and atomic write operations.

## 2. CAN Port and Identifier Filtering

### 2.1 CANport
`CANport` manages CAN port identifiers:

```cpp
struct CANport {
    enum Port {
        can_a   = 1U << canpid_a,    // (1) CAN-A port
        can_b   = 1U << canpid_b,    // (2) CAN-B port
        canfd_a = 1U << canpid_fda,  // (4) CANFD-A (only for 2838x)
        
        can_ab  = can_a | can_b,     // Combination of CAN-A and CAN-B ports
        can_all = can_a | can_b | canfd_a   // All CAN ports combined
    };
    
    static const Uint16 nports = 3;  // Number of simple CAN ports
    
    static bool validate(Port p);    // Check if port is valid
    static bool port_match(CANpid pi, Port p);  // Check if port ID matches port
}
```

This structure defines the available CAN ports and provides methods to validate ports and check if a port ID matches a specific port.

### 2.2 CANid_filter
`CANid_filter` implements filtering for CAN identifiers:

```cpp
struct CANid_filter {
    CANid  id;      // ID value to filter
    Uint32 msk;     // Mask over ID (0 => don't care)
    
    bool match(const CANid& id) const;  // Check if ID matches filter
    void cset(Lossy_error& str);        // Deserialize from PDIC
}
```

This structure filters CAN identifiers using a mask, where bits set to 0 in the mask are "don't care" bits. The `match` method checks if a given ID matches the filter.

### 2.3 CANids
`CANids` stores a set of CAN identifiers:

```cpp
template<Uint16 sz>
class CANids {
public:
    typedef Base::Tnarrayresz<Base::CANid, sz> Tcanids;
    Tcanids ids;
    
    Uint16 find(const CANid& id) const;  // Find ID in array
    void cset(Lossy_error& str);         // Deserialize from PDIC
}
```

This template class stores an array of CAN identifiers and provides methods to find an ID in the array and deserialize from a PDIC.

## 3. Input Management Components

### 3.1 CANin_p (CAN Producer)
`CANin_p` is a CAN producer that stores frames and can be read as a producer:

```cpp
class CANin_p : public Itproducer_can {
public:
    static const Uint16 default_buffer_size = 160U;
    static const Uint16 default_buffer_size_pa = 320U;
    
    struct In_filter {
        CANid_filter can_filter;  // CAN ID filter
        bool supp_both;           // Support both extended and simple CANids
        
        bool match(const CANid& id) const;  // Check if ID matches filter
        void cset(Lossy_error& str);        // Deserialize from PDIC
    };
    
    struct Config {
        CANport::Port port;    // Accepted ports
        In_filter filter;      // CAN ID enhanced filter
        
        bool match(CANpid port0, const CANid& id) const;  // Check if port and ID match
        static Config build_default();                    // Build default config
        void cset(Lossy_error& str);                      // Deserialize from PDIC
    };
    
    CANin_p(Uint16 buffsize, Memmgr::Type mtype);
    
    void config(const Config& cfg0);                  // Configure filters
    void cset(Lossy_error& str);                      // Deserialize from PDIC
    bool match(CANpid port, const CANid& id) const;   // Check if port and ID match
    bool write(const CANframe& frame);                // Store frame in buffer
    virtual bool read(CANframe& frame);               // Read next pending frame
    void set_connected(bool val);                     // Set connected flag
    bool get_connected() const;                       // Get connected flag
    
private:
    Config cfg;             // Configuration
    bool connected;         // Flag indicating if producer has consumer connected
    CANframe_fifo32 fifo;   // Data buffer
}
```

This class implements a CAN producer that stores frames in a FIFO buffer and can be read by consumers. It includes filtering based on port and ID, and tracks whether it has a connected consumer.

### 3.2 CANin_mgr (CAN Input Manager)
`CANin_mgr` manages reading from CAN port peripherals:

```cpp
class CANin_mgr {
public:
    CANin_mgr(Mblock<Itproducer_can*> can_per0,
              Base::Array<Base::CANin_p>& prods,
              Uint16 max_transfer);
              
    CANin_mgr(Mblock<Itproducer_can*> can_per0,
              Mblock<const CANpid> can_ports0,
              Base::Array<Base::CANin_p>& prods,
              Uint16 max_transfer);
              
    void step_hi();                           // High priority stepper
    const Uint16& get_rx_counter() const;     // Get received messages counter
    
private:
    Mblock<Itproducer_can*> can_per;          // CAN producer peripherals
    Base::Array<Base::CANin_p>& p;            // CAN producers array
    Uint16 max_transfer;                      // Max frames to transfer per step
    Mblock<const CANpid> can_ports;           // Port of each CAN consumer
    
    void write(CANpid port, const CANframe& frame);  // Write frame to producer
    Uint16 rx_counter;                        // Received messages counter
}
```

This class handles reading from CAN port peripherals and distributing frames to the appropriate producers based on port and ID filtering. It includes a high-priority stepper method that should be called from a high-priority task.

### 3.3 CANin_suite
`CANin_suite` provides configuration for CAN producers:

```cpp
template <Uint16 n>
struct CANin_suite: public Tnarrayresz<CANin_p::Config, n> {
    void cset(Lossy_error& str);  // Deserialize from PDIC
}
```

This template class stores an array of CAN producer configurations and provides a method to deserialize from a PDIC.

## 4. Output Management Components

### 4.1 CANout_c (CAN Consumer)
`CANout_c` is a CAN consumer that outputs frames to a configured port:

```cpp
class CANout_c : public Itconsumer_can {
public:
    static const Uint16 default_buffer_size = 160U;
    
    struct Config {
        CANport::Port port;     // Accepted ports
        
        void cset(Lossy_error& str);  // Deserialize from PDIC
    };
    
    CANout_c(Uint16 buffsize, Memmgr::Type mtype);
    
    void config(const Config& cfg0);                // Configure consumer
    void cset(Lossy_error& str);                    // Deserialize from PDIC
    virtual bool write(const CANframe& data);       // Write frame to buffer
    virtual bool wr_available() const;              // Check if write is available
    bool read(CANframe& d);                         // Read next pending frame
    bool rd_available();                            // Check if read is available
    CANport::Port get_port() const;                 // Get configured port
    
private:
    Config cfg;             // Configuration
    CANframe_fifo32 fifo;   // Buffer of data to be sent
}
```

This class implements a CAN consumer that outputs frames to a configured port. It includes a FIFO buffer for storing frames to be sent.

### 4.2 CANout_mgr (CAN Output Manager)
`CANout_mgr` manages writing to CAN peripherals:

```cpp
class CANout_mgr {
public:
    struct CAN_rates_vars {
        volatile Real& canx_tx_rate;        // Send rate statistics
        volatile Real& canx_tx_skip_rate;   // Skip rate statistics
    };
    typedef Mblock<CAN_rates_vars> Rate_vars_arr;
    
    CANout_mgr(Mblock<Itconsumer_can*> can_per0,
               Base::Array<CANout_c>& consumers,
               Uint16 max_transfer,
               Rate_vars_arr rate_vars);
               
    CANout_mgr(Mblock<Itconsumer_can*> can_per0,
               Mblock<const CANport::Port> can_ports,
               Base::Array<CANout_c>& consumers,
               Uint16 max_transfer,
               Rate_vars_arr rate_vars);
               
    void step_hi();  // High priority stepper
    void step();     // Statistics stepper
    
private:
    Mblock<Itconsumer_can*> can_per;        // CAN consumer peripherals
    Mblock<const CANport::Port> can_ports;  // Port of each CAN consumer
    Array<CANout_c>& cons;                  // Consumers generating data
    Uint16 max_transfer;                    // Max frames to transfer per step
    
    Uint16 tx_idx;                          // Next consumer to check
    Array<bool> tx_st;                      // Consumer write status flags
    
    Array<Call_stat> cs;                    // Send rate statistics
    Array<Call_stat> cs_skip;               // Skip rate statistics
    Rate_vars_arr rate_vars;                // Rate variables array
}
```

This class handles writing frames from consumers to CAN peripherals. It includes a high-priority stepper method for transferring frames and a regular stepper method for updating statistics.

### 4.3 CANout_suite
`CANout_suite` provides configuration for CAN consumers:

```cpp
template <Uint16 n>
struct CANout_suite : public Tnarrayresz<CANout_c::Config, n> {
    void cset(Lossy_error& str);  // Deserialize from PDIC
}
```

This template class stores an array of CAN consumer configurations and provides a method to deserialize from a PDIC.

## 5. Serial-CAN Conversion Components

### 5.1 CANserial
`CANserial` converts CAN packets to a serial stream:

```cpp
class CANserial : public Itconsumer_can, public Itproducer_u8 {
public:
    static const Uint8 default_buffer_size = 8U;
    static const Uint8 max_buffer_size = 32U;
    
    explicit CANserial(Uint8 w_size);
    
    virtual bool write(const CANframe& data);  // Write CAN packet for serialization
    virtual bool wr_available() const;         // Check if write is available
    virtual bool read(Uint8& data);            // Read serialized data
    Uint32 get_discarded() const;              // Get number of discarded frames
    
private:
    Windowbuff<CANdata> wb;           // Receive window buffer
    Uint8 rd_idx;                     // Reading index on current frame
    CANdata rd_curr;                  // Current frame being serialized
    
    static const Real def_reset_tout; // Default reset timeout
    Real reset_tout;                  // Buffer reset timeout
    Chrono cr_reset;                  // Reset timeout chrono
    Uint32 discarded;                 // Number of discarded frames
}
```

This class receives CAN packets and generates a serial stream. It includes a window buffer for receiving frames and tracks discarded frames.

### 5.2 SerialCAN
`SerialCAN` converts a serial stream to CAN packets:

```cpp
class SerialCAN : public Itconsumer_u8, public Itproducer_can {
public:
    struct Config {
        CANid id;       // ID to use on output
        Real timeout;   // Timeout to retain data until packet is full
        
        static Config build(Uint32 id0, bool ext0, Real tout0);  // Build config
        void cset(Lossy_error& str);                            // Deserialize from PDIC
    };
    
    SerialCAN();
    
    void config(const Config& cfg);           // Configure
    void cset(Lossy_error& str);              // Deserialize from PDIC
    Uint32 get_discarded() const;             // Get number of buffer overflows
    virtual bool read(CANframe& frame);       // Read CAN frame
    virtual bool write(Uint8 data);           // Write byte for streaming
    virtual bool wr_available() const;        // Check if write is available
    
private:
    static const Uint16 buff_sz = 28;   // Serial buffer size
    U8pkfifospsc buff;                  // Serial buffer
    
    Uint8 seq_idx;                      // Sequence index
    Config cfg;                         // Configuration
    CANframe curr_frame;                // Current working frame
    Timeout tout;                       // Timeout
    
    Uint32 discarded;                   // Discarded bytes count
}
```

This class receives a serial stream and generates CAN packets. It includes a buffer for receiving bytes and tracks discarded bytes.

### 5.3 CANserial_parser
`CANserial_parser` parses serialized CAN data:

```cpp
class CANserial_parser {
public:
    enum State {
        st_canid,      // CAN id
        st_frame_size, // Size of data
        st_frame,      // Sending the CAN frame
        st_crc0,       // Writing the first byte of the CRC
        st_crc1,       // Writing the second byte of the CRC
        st_completed,  // Message completed
        st_desync      // Desynchronized state
    };
    
    static const Uint16 data_sync = 0xCAU;          // Header byte
    static const Uint32 extended_bit = 0x80000000U; // Extended flag bit
    static const Uint16 max_size_bytes = 8 + CANdata::length_max_fd;  // Max message size
    
    CANserial_parser();
    
    State parse(Uint8 data);              // Parse incoming byte
    const CANframe& get_frame() const;    // Get last parsed frame
    
private:
    State st;                       // Parser state
    Uint8 payload_idx;              // Current byte index
    CRC crc;                        // CRC calculator
    CANframe frame;                 // Last parsed frame
    
    U8pkfifospscrd_commit ff;       // Circular buffer for header control
    
    State parse_priv(Uint8 data);   // Private parse method
}
```

This class parses serialized CAN data into CAN frames. It implements a state machine for parsing the different parts of a serialized CAN message.

### 5.4 CANwrapper
`CANwrapper` converts CAN frames to wrapped serial messages:

```cpp
class CANwrapper : public Itconsumer_can, public Itproducer_u8 {
public:
    CANwrapper();
    
    virtual bool write(const CANframe& data);  // Write CAN frame
    virtual bool wr_available() const;         // Check if write is available
    virtual bool read(Uint8& data);            // Read serialized byte
    
private:
    CANframe_fifo32 fifo_can;  // CAN frames buffer
    U8pkfifospsc fifo_u8;      // Output buffer
    CRC ck;                    // CRC calculator
}
```

This class converts CAN frames to wrapped serial messages with a sync byte and CRC. It includes buffers for CAN frames and output bytes.

### 5.5 CANunwrapper
`CANunwrapper` unwraps serialized CAN messages:

```cpp
class CANunwrapper : public Itproducer_can, public Itconsumer_u8 {
public:
    CANunwrapper();
    
    virtual bool read(CANframe& data);  // Read CAN frame
    virtual bool write(Uint8 data);     // Write serialized byte
    virtual bool wr_available() const;  // Check if write is available
    
private:
    CANframe_fifo32 fifo;       // CAN frames buffer
    CANserial_parser parser;    // Message parser
}
```

This class unwraps serialized CAN messages into CAN frames. It includes a buffer for CAN frames and a parser for serialized messages.

## 6. Statistics and Monitoring

### 6.1 CAN_stats
`CAN_stats` tracks discarded CAN messages:

```cpp
class CAN_stats {
public:
    CAN_stats(const Base::Array<Base::CANserial>& can, Uvar last_var);
    
    void step();  // Update statistics
    
private:
    const Base::Array<Base::CANserial>& can_ser;  // CAN to serial consumers
    const Uint8 n_vars;                           // Number of variables to track
}
```

This class computes statistics for discarded CAN messages and updates system variables. It should be called periodically from a low-priority thread.

## 7. Standard Protocol Definitions

### 7.1 CANstdp
`CANstdp` defines standard CAN protocol message types:

```cpp
namespace CANstdp {
    enum Type {
        t_arbitration   =  0,     // Arbitration message
        t_version       =  1,     // Version request/response
        t_pwm_0_3_set   =  2,     // CEX: 4 PWMs (0-3)
        t_pwm_4_7_set   =  3,     // CEX: 4 PWMs (4-7)
        t_esc_tm        =  5,     // CEX: Lift ESC telemetry
        t_esc_tm2       =  6,     // CEX: Jeti ESC telemetry
        t_bec_tm1       =  7,     // CEX: Jeti BEC telemetry
        t_bec_tm2       =  8,     // CEX: Jeti BEC telemetry (more)
        t_temp_tm       =  9,     // CEX: Jeti Temperature sensor telemetry
        t_mcu_cmd       =  10,    // CEX: LIFT MCU battery command
        t_pwm_8_11_set  =  11,    // CEX: 4 PWMs (8-11)
        t_pwm_12_15_set =  12,    // CEX: 4 PWMs (12-15)
        t_pwm_16_19_set =  13,    // CEX: 4 PWMs (16-19)
        t_cmd_maint     =  16,    // Command to go to maintenance mode
        t_stick_sel     =  17,    // Command for stick selection
        t_mcu_tm1       =  18,    // CEX: Lift MCU telemetry
        t_mcu_tm2       =  19,    // CEX: Lift MCU telemetry
        t_4x_consens    =  20     // Consensus 4x variables
    };
    
    static const Uint16 t_max = 21;       // Max valid type value
    static const Uint16 pwms_msg = 20;    // Max IDs in a pwmset message
}
```

This namespace defines standard CAN protocol message types for various purposes, including arbitration, version control, PWM settings, telemetry, and commands.

## 8. Data Flow Architecture

The CAN communication system follows a producer-consumer architecture with the following data flow:

1. **Input Path (Physical CAN Bus → Application)**:
   - `CANin_mgr` reads frames from physical CAN peripherals
   - Frames are filtered by port and ID using `CANid_filter`
   - Matching frames are written to `CANin_p` producers
   - Application code reads frames from producers

2. **Output Path (Application → Physical CAN Bus)**:
   - Application code writes frames to `CANout_c` consumers
   - `CANout_mgr` reads frames from consumers
   - Frames are sent to the appropriate physical CAN peripherals based on port

3. **Serial-CAN Conversion**:
   - `CANserial` converts CAN frames to serial data
   - `SerialCAN` converts serial data to CAN frames
   - `CANwrapper` wraps CAN frames with sync byte and CRC
   - `CANunwrapper` unwraps serialized CAN messages
   - `CANserial_parser` parses serialized CAN data

4. **Filtering and Routing**:
   - `CANid_filter` filters frames by ID
   - `CANport` manages port routing
   - `CANids` stores sets of CAN identifiers

5. **Buffering and Thread Safety**:
   - `CANframe_fifo32` provides thread-safe FIFO buffers
   - Optimized for performance using 32-bit words
   - Supports atomic write operations

6. **Statistics and Monitoring**:
   - `CAN_stats` tracks discarded messages
   - `CANout_mgr` maintains send and skip rate statistics

## 9. Key Implementation Details

### 9.1 Thread Safety and Priority

The system is designed with thread safety in mind:
- `CANin_mgr::step_hi()` and `CANout_mgr::step_hi()` should be called from high-priority tasks
- `CAN_stats::step()` should be called from a low-priority thread
- FIFO buffers use atomic operations for thread safety

### 9.2 Error Handling

The system includes several error handling mechanisms:
- Tracking of discarded frames in `CANserial` and `SerialCAN`
- CRC validation in `CANserial_parser`
- Buffer overflow detection in various components

### 9.3 Performance Optimization

Performance optimizations include:
- Using 32-bit words as the data unit in `CANframe_fifo32`
- Window buffers in `CANserial`
- Efficient bit manipulation for ID filtering

### 9.4 Configuration and Deserialization

Most components support configuration and deserialization from PDIC (Parameter Data Interface Configuration):
- `CANid::cset()`
- `CANid_filter::cset()`
- `CANin_p::Config::cset()`
- `CANout_c::Config::cset()`
- `SerialCAN::Config::cset()`

## 10. Referenced Context Files

The following context files provided useful information for understanding the CAN communication system:

- `ICAN_drv.h`: Defines the interface for CAN drivers
- `CANpid.h` (referenced but not provided): Defines CAN peripheral identifiers
- `SerialCAN_p.h` (referenced but not provided): Contains SerialCAN protocol constants

## 11. Summary

The CAN communication system provides a comprehensive framework for CAN communication, including:

1. Core data structures for CAN frames, identifiers, and data
2. Input and output management components
3. Filtering mechanisms for CAN identifiers and ports
4. Serial-CAN conversion components
5. Standard protocol definitions

The system follows a producer-consumer architecture with thread safety, error handling, and performance optimizations. It supports both standard CAN and CAN-FD, with filtering based on port and ID.