# Generated from:

- code/include/Spkt.h (1829 tokens)
- code/include/Spkt_buffer.h (652 tokens)
- code/include/Spkt_hdr.h (2457 tokens)
- code/include/Spkt_own.h (305 tokens)
- code/include/Espkt.h (4164 tokens)
- code/include/Espkt_hdr.h (760 tokens)
- code/include/Espkt_parser.h (577 tokens)
- code/include/Ipkt_parser.h (701 tokens)
- code/include/Ipkt_port.h (392 tokens)
- code/include/Ispkt_port.h (77 tokens)
- code/include/Ispkt_sender.h (131 tokens)
- code/include/Pkt_router.h (1799 tokens)
- code/include/Pkt64proc.h (552 tokens)
- code/include/IPkt64proc.h (164 tokens)
- code/source/Spkt.cpp (1615 tokens)
- code/source/Spkt_hdr.cpp (1376 tokens)
- code/source/Espkt.cpp (745 tokens)
- code/source/Espkt_parser.cpp (1332 tokens)
- code/source/Pkt_router.cpp (3774 tokens)
- code/source/Pkt64proc.cpp (230 tokens)

---

# STANAG Packet System: Comprehensive Summary

This document provides a detailed analysis of the STANAG packet system, including the core packet structure, Embention extensions, packet processing mechanisms, and interfaces for communication.

## 1. Core STANAG Packet Structure

### 1.1 Base STANAG Packet (`Spkt`)

The STANAG packet system is built around the `Spkt` class, which represents a standard STANAG packet with the following structure:

| Component | Size | Description |
|-----------|------|-------------|
| Header    | 16 bytes | Contains routing, message type, and properties information |
| Payload   | 1-528 bytes | Variable-length message data |
| CRC       | 0-4 bytes | Optional checksum/CRC for data integrity |

#### 1.1.1 STANAG Packet Header (`Spkt_hdr`)

The header contains critical routing and message information with the following fields:

| Field | Offset | Size | Description |
|-------|--------|------|-------------|
| Reserved | 0 | 2 bytes | Sequence number (int16) |
| Message Length | 2 | 2 bytes | Payload length in bytes (1-528) |
| Source | 4 | 4 bytes | Source address |
| Destination | 8 | 4 bytes | Destination address |
| Message Type | 12 | 2 bytes | Type of message (from Stanag_msg_type) |
| Message Properties | 14 | 2 bytes | Flags and properties (see below) |

The Message Properties field is structured as:
- ACK [15]: When "1", acknowledgment is required
- IDD [14:8]: IDD version number (30 for STANAG 4586 Edition 3)
- CHK_TYPE [7:6]: Checksum/CRC type (0=none, 1=2 bytes, 2=4 bytes, 3=CRC32)
- RESERVED [5:0]: Reserved for future use

Valid system versions are defined in the `SVersion` enum:
- `stanag_4586_ed_3` (30): STANAG 4586 Edition 3
- `stanag_4568_ed_3_v1` (31): STANAG 4586 Edition 3 Version 1
- `stanag_4586_ed_4_vol2` (32): STANAG 4586 Edition 4 Volume 2

#### 1.1.2 STANAG Packet Operations

The `Spkt` class provides methods to:

1. **Construct packets**:
   ```cpp
   Spkt(U8pkmblock mb, bool built = false);
   ```

2. **Copy packets**:
   ```cpp
   void copy(const Spkt& orig);
   void copy(const Spkt_buffer& orig);
   ```

3. **Manipulate headers**:
   ```cpp
   void set_hdr(const Spkt_hdr& hdr);
   bool get_hdr(Spkt_hdr& hdr) const;
   ```

4. **Access payload**:
   ```cpp
   U8pkmblock_k get_payload() const;
   ```

5. **Finalize packets**:
   ```cpp
   void end_pkt();  // Computes CRC and adds it to the packet
   ```

6. **Retrieve packet information**:
   ```cpp
   Uint32 get_crc(const Spkt_hdr& hdr);
   Uint32 get_payload_len() const;
   Uint32 get_pkt_len() const;
   Uint32 get_pkt_len_no_crc() const;
   bool is_valid() const;
   ```

7. **Convert to memory blocks**:
   ```cpp
   const U8pkmblock_k to_mblock_k() const;
   const U8pkmblock_k to_mblock_no_crc() const;
   ```

#### 1.1.3 Packet Mutation

The `Spkt` class includes a nested `Mutator` class that facilitates changing packet payloads:

```cpp
class Mutator {
public:
    explicit Mutator(Spkt& pkt0);
    ~Mutator();  // Automatically calls end_pkt() on destruction
    U8ostream os;  // Stream for payload serialization
private:
    Spkt& pkt;
};
```

This allows for RAII-style packet modification where the CRC is automatically computed when the mutator goes out of scope.

### 1.2 STANAG Packet Buffer (`Spkt_buffer`)

The `Spkt_buffer` class manages memory for STANAG packets:

```cpp
class Spkt_buffer {
public:
    Spkt_buffer();
    void copy(const U8pkmblock_k& mb);
    void copy(const Base::Spkt& pkt);
    U8pkmblock to_mblock8();
    U8pkmblock_k to_mblock8() const;
private:
    U8pkrszarray<Spkt_hdr::max_pkt_size> buffer;
};
```

This class provides a resizable buffer for packet storage and manipulation, with methods to copy data from memory blocks or existing packets.

### 1.3 STANAG Packet with Owned Memory (`Spkt_own`)

The `Spkt_own` class combines a STANAG packet with its own memory buffer:

```cpp
class Spkt_own {
public:
    Spkt_own();
    Spkt& get_spkt();
    void copy(const Spkt& obj);
    Spkt_buffer& get_buffer();
private:
    Spkt_buffer buffer;
    Spkt pkt;
};
```

This class simplifies memory management by owning both the packet and its buffer.

## 2. Embention Extensions to STANAG Protocol

### 2.1 Embention STANAG Packet (`Espkt`)

Embention extends the standard STANAG protocol with additional header fields and functionality. The `Espkt` class represents this extended packet format:

| Component | Size | Description |
|-----------|------|-------------|
| Extended Header | 6 bytes | Additional Embention-specific header fields |
| STANAG Header | 16 bytes | Standard STANAG header |
| Payload | 0-532 bytes | Variable-length message data |
| CRC32 | 4 bytes | CRC for data integrity |

#### 2.1.1 Embention Header Structure (`Espkt_hdr`)

The extended header contains:

| Field | Offset | Size | Description |
|-------|--------|------|-------------|
| Sync | 0 | 1 byte | Header start marker (0x45) |
| Flags | 1 | 1 byte | TTL, reserved bit, and crypted flag |
| Identifier | 2 | 2 bytes | Packet identifier |
| Session | 4 | 1 byte | Session ID |
| Header CRC | 5 | 1 byte | CRC8 for header integrity |

The Flags field is structured as:
- TTL [5:0]: Time to live (0-63)
- Reserved [6]: Reserved bit
- Crypted [7]: Flag indicating if packet is encrypted

#### 2.1.2 Embention STANAG Packet Operations

The `Espkt` class provides methods to:

1. **Construct packets**:
   ```cpp
   Espkt();
   ```

2. **Copy data**:
   ```cpp
   void copy(const U8pkmblock_k& buffer);
   ```

3. **Finalize packets**:
   ```cpp
   void end_pkt();  // Computes CRCs and adds them to the packet
   void update_header_crc();
   ```

4. **Manipulate TTL**:
   ```cpp
   void set_ttl(Uint8 ttl);
   bool decrease_ttl();
   Uint8 get_ttl() const;
   ```

5. **Access header fields**:
   ```cpp
   Espkt_hdr::Flags get_flags() const;
   void set_flags(Espkt_hdr::Flags flags);
   Uint8 get_session() const;
   void set_session(Uint8 session);
   Uint16 get_ident() const;
   void set_ident(Uint16 ident) const;
   Uint8 get_hdr_crc() const;
   ```

6. **Access addressing information**:
   ```cpp
   Address get_src_address() const;
   Address get_dst_address() const;
   void set_dst_address(Address addr);
   ```

7. **Access packet data**:
   ```cpp
   Uint16 get_type() const;
   Uint32 get_crc() const;
   Uint16 get_full_len() const;
   Uint16 get_len_nocrc() const;
   Uint16 get_payload_len() const;
   ```

8. **Convert to memory blocks**:
   ```cpp
   const U8pkmblock_k to_mblock() const;
   ```

9. **Access as standard STANAG packet**:
   ```cpp
   Spkt& get_as_spkt();
   const Spkt& get_as_spkt() const;
   ```

### 2.2 Packet Processing (`Pkt64proc`)

The system includes classes for processing STANAG packets:

```cpp
class Pkt64proc : public IPkt64proc {
public:
    Pkt64proc(IHdrproc& hdrproc, IDataproc& dataproc);
    void set_hdr_processor(IHdrproc& hdrproc);
    void set_data_processor(IDataproc& dataproc);
    virtual bool process(Spkt& pkt);
protected:
    IHdrproc& hdrproc;
    IDataproc& dataproc;
    Array<Uint8> wbuffer;
};
```

The `Pkt64proc` class processes STANAG packets by:
1. Extracting the header and payload
2. Processing the header using an `IHdrproc` implementation
3. Processing the payload using an `IDataproc` implementation
4. Reconstructing the packet with the processed data

A dummy implementation (`Pkt64proc_dummy`) is also provided for testing or placeholder purposes.

## 3. Packet Parsing and Processing

### 3.1 Packet Parser Interface (`Ipkt_parser`)

The system defines an interface for packet parsers:

```cpp
class Ipkt_parser {
public:
    static const Real clear_tout;
    enum Protocol { ext_stanag = 0, stanag = 1 };
    enum State { decoding, decoded, discarded, finished };
    
    virtual State parse(Uint8 data) = 0;
    virtual State parse_async() = 0;
    virtual Espkt& get_packet() = 0;
    virtual void update_protocol(Ipkt_parser::Protocol prot0) = 0;
    static void shift_nbytes(U8ostream& wr, Uint16 offset);
};
```

This interface defines the protocol for parsing packets byte by byte, with states to track the parsing progress.

### 3.2 Embention STANAG Packet Parser (`Espkt_parser`)

The `Espkt_parser` class implements the packet parser interface for Embention STANAG packets:

```cpp
class Espkt_parser {
public:
    Espkt_parser();
protected:
    Espkt epkt;
    Uint16 data_end;
    Uint16 pkt_end;
    Ipkt_parser::State st;
    Timeout tout;
    bool sent;
    CRC32 crc;
    U8ostream wr;
    U8istream rd;
    
    void reset();
    void restart();
    Ipkt_parser::State parse_priv();
private:
    Uint16 sync_found;
    Uint8 hdr_crc;
};
```

The parser works by:
1. Looking for the sync byte (0x45)
2. Parsing the header and validating the header CRC
3. Calculating the expected packet length
4. Parsing the payload and validating the packet CRC
5. Transitioning between states (decoding, decoded, discarded)

The parser includes timeout functionality to reset if no bytes are received for a period.

## 4. Packet Routing and Communication

### 4.1 Packet Port Interface (`Ipkt_port`)

The system defines an interface for packet ports:

```cpp
class Ipkt_port : public Istep {
public:
    virtual void get_pkt_loss(Uint16& npkts_disc0, Real& loss_rate) = 0;
    virtual void write(Espkt& pkt) = 0;
    virtual void reset() = 0;
protected:
    virtual ~Ipkt_port();
};
```

This interface represents a communication port that can send and receive packets, with methods to write packets and track packet loss.

### 4.2 STANAG Packet Sender Interface (`Ispkt_sender`)

The system defines an interface for sending STANAG packets:

```cpp
class Ispkt_sender {
public:
    virtual void send(const Spkt& pkt) = 0;
protected:
    ~Ispkt_sender();
};
```

This interface is used by components that need to send standard STANAG packets.

### 4.3 Packet Router (`Pkt_router`)

The `Pkt_router` class routes packets between ports and processors:

```cpp
class Pkt_router : public Istep {
public:
    Pkt_router(Base::IAddress_handler& addr_handler0,
               Irouting_table& rtable0,
               Ipkt_sender& pkt_sender0,
               Icomstats& com_stats0,
               Uint16 ident_map_size,
               const volatile bool& disable_out_comms0);
               
    void set_current_session(Uint8 session0);
    void add_port(Ipkt_port& port);
    void route(Espkt& pkt, const Ipkt_port* src_port);
    void step();
    Icomstats& get_com_stats();
    
    typedef Tnarrayresz<Ipkt_port*, Irouting_table::max_ports> Tports;
    const Tports& get_ports() const;
    
private:
    // Internal state and helper methods
    Uint8 next_session;
    Uint8 session;
    Uint16 n_ident;
    Base::IAddress_handler& addr_handler;
    Ipkt_sender& pkt_sender;
    Irouting_table& rtable;
    Tports ports;
    const volatile bool& disable_out_comms;
    Chrono restart_cr;
    Icomstats& com_stats;
    
    struct Ident_data {
        Uint8 session;
        Uint16 ident;
        Uint32 tlc;
        Uint8 fail_cnt;
    };
    
    typedef Map<Address0, Ident_data> Tidents;
    Tidents idents;
    
    void clean_ident_map();
    bool validate_ident(const Espkt& epkt);
    bool packet_to_me(Espkt& epkt) const;
    void packet_from_me(Espkt& epkt, const Ipkt_port* src_port);
};
```

The router performs several key functions:

1. **Packet Routing**: Routes packets between ports based on destination addresses and routing tables
2. **TTL Management**: Decreases TTL for forwarded packets and drops packets with TTL=0
3. **Session Management**: Manages session IDs for outgoing packets
4. **Identity Validation**: Validates packet identifiers to prevent duplicates
5. **Statistics Collection**: Tracks communication statistics

The routing process involves:
1. Checking if the packet is addressed to the local system (`packet_to_me`)
2. If so, passing it to the packet processor
3. If not, or if it's a broadcast, forwarding it to appropriate ports (`packet_from_me`)
4. For outgoing packets, setting TTL, session, and identifier

## 5. STANAG Packet Interfaces

### 5.1 STANAG Packet Consumer/Producer Interfaces

The system defines interfaces for components that consume or produce STANAG packets:

```cpp
typedef Itconsumer<Spkt_buffer> Itconsumer_spktb;
typedef Itproducer<Spkt_buffer> Itproducer_spktb;
```

These interfaces allow for standardized communication between components that work with STANAG packets.

## 6. Packet Processing Flow

The complete packet processing flow in the system works as follows:

1. **Packet Reception**:
   - Bytes are received on a port implementing `Ipkt_port`
   - The bytes are passed to an `Espkt_parser` instance
   - The parser assembles and validates the packet

2. **Packet Routing**:
   - The assembled packet is passed to the `Pkt_router`
   - The router checks if the packet is addressed to the local system
   - If so, it's passed to the `Ipkt_sender` (packet processor)
   - If not, it's forwarded to appropriate ports based on the routing table

3. **Packet Processing**:
   - The packet processor (implementing `Ipkt_sender`) processes the packet
   - For complex processing, a `Pkt64proc` instance may be used
   - The processor may generate response packets

4. **Packet Transmission**:
   - Response packets are created using `Spkt` or `Espkt`
   - The packets are passed to the `Pkt_router`
   - The router sets TTL, session, and identifier for outgoing packets
   - The packets are sent to appropriate ports

## 7. CRC and Data Integrity

The system uses multiple CRC mechanisms to ensure data integrity:

1. **Header CRC**: A CRC8 checksum for the Embention header
   ```cpp
   Uint8 compute_hdr_crc() const;
   void update_header_crc();
   ```

2. **Packet CRC**: A configurable checksum for the entire packet
   - `nb0`: No checksum
   - `nb2`: 2-byte checksum
   - `nb4`: 4-byte checksum
   - `crc32`: CRC32 (4 bytes)

The CRC calculation is performed in the `end_pkt()` methods of both `Spkt` and `Espkt` classes.

## 8. Memory Management

The system uses several memory management approaches:

1. **External Memory Blocks**: Using `U8pkmblock` for working with external memory
   ```cpp
   Spkt(U8pkmblock mb, bool built = false);
   ```

2. **Owned Memory**: Using `Spkt_own` and `Spkt_buffer` for self-contained packets
   ```cpp
   Spkt_own();
   Spkt_buffer();
   ```

3. **Resizable Arrays**: Using `U8pkrszarray` for dynamic buffer management
   ```cpp
   U8pkrszarray<Spkt_hdr::max_pkt_size> buffer;
   ```

This allows for flexible memory management depending on the use case.

## 9. Practical Usage Patterns

### 9.1 Creating and Sending a STANAG Packet

```cpp
// Create a packet with owned memory
Spkt_own pkt_own;
Spkt& pkt = pkt_own.get_spkt();

// Set up the header
Spkt_hdr hdr(payload_size, src_addr, dst_addr, msg_type, props);
pkt.set_hdr(hdr);

// Write payload data
{
    Spkt::Mutator mut(pkt);
    mut.os.put_uint32_be(some_data);
    mut.os.put_uint16_be(more_data);
    // Mutator destructor calls end_pkt() automatically
}

// Send the packet
pkt_sender.send(pkt);
```

### 9.2 Receiving and Processing a STANAG Packet

```cpp
// In a port implementation
void MyPort::receive_bytes(const Uint8* data, Uint16 size) {
    for (Uint16 i = 0; i < size; i++) {
        if (parser.parse(data[i]) == Ipkt_parser::decoded) {
            Espkt& pkt = parser.get_packet();
            router.route(pkt, this);
        }
    }
}

// In a packet processor implementation
void MyProcessor::send(const Spkt& pkt) {
    Spkt_hdr hdr;
    if (pkt.get_hdr(hdr)) {
        // Process the packet based on message type
        switch (hdr.mtype) {
            case Stanag_msg_type::some_type:
                process_some_type(pkt);
                break;
            // Handle other message types
        }
    }
}
```

### 9.3 Routing Configuration

```cpp
// Set up routing
Pkt_router router(addr_handler, routing_table, pkt_processor, com_stats, 100, disable_flag);

// Add ports
router.add_port(serial_port);
router.add_port(ethernet_port);
router.add_port(radio_port);

// Set session
router.set_current_session(1);

// In main loop
void main_loop() {
    while (true) {
        router.step();
        // Other processing
    }
}
```

## 10. Referenced Context Files

The following context files provided valuable insights:

- `IPkt64proc.h`: Defined the interface for packet processors
- `Pkt64proc.h`: Implemented the packet processor functionality
- `Ipkt_port.h`: Defined the interface for packet ports
- `Ispkt_sender.h`: Defined the interface for STANAG packet senders
- `Ispkt_port.h`: Defined consumer/producer interfaces for STANAG packets

## Conclusion

The STANAG packet system provides a comprehensive framework for packet-based communication with the following key features:

1. **Standard STANAG Packet Format**: A structured format with header, payload, and optional CRC
2. **Embention Extensions**: Additional header fields for enhanced functionality
3. **Flexible Parsing**: Robust parsing mechanisms for assembling packets from byte streams
4. **Efficient Routing**: Intelligent routing based on addresses and routing tables
5. **Data Integrity**: Multiple CRC mechanisms to ensure packet integrity
6. **Memory Management**: Flexible memory management for different use cases

This system enables reliable communication between components in a distributed system, with support for addressing, routing, and data integrity verification.