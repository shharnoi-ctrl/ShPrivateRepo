# Generated from:

- code/include/Xclog.h (1321 tokens)
- code/include/Xclogmng.h (463 tokens)
- code/include/Xclogsvc.h (864 tokens)
- code/include/Bootlog.h (728 tokens)
- code/include/Bootlog_fw.h (22 tokens)
- code/include/Ilogcontrol.h (608 tokens)
- code/include/Herrors.h (481 tokens)
- code/include/Ierrors.h (138 tokens)
- code/include/Errors_dual.h (478 tokens)
- code/include/Errors_single.h (317 tokens)
- code/include/Syserr_bits.h (408 tokens)
- code/source/Xclogsvc.cpp (3769 tokens)
- code/source/Bootlog.cpp (4464 tokens)
- code/source/Herrors.cpp (409 tokens)
- code/source/Errors_single.cpp (183 tokens)
- code/source/Syserr_bits.cpp (276 tokens)

---

# Comprehensive Summary of Logging and Error Handling System

This document provides a detailed analysis of the cross-core logging architecture, boot logging system, error reporting mechanisms, and error tracking systems. The system implements a client-server model for logging across multiple CPU cores with sophisticated error handling capabilities.

## 1. Cross-Core Logging Architecture

### 1.1 Client-Server Model Overview

The logging system is built on a client-server architecture that spans multiple CPU cores:

- **Server Side (CPU1)**: Hosts the `Xclogsvc` class that provides logging services to CPU2
- **Client Side (CPU2)**: Uses `Xclogmng` to send log requests and data to the server
- **Communication**: Uses shared memory structures and synchronized FIFOs for cross-core data transfer

The architecture enables CPU2 to write logs that are processed and stored by CPU1, allowing for efficient logging across cores without blocking the client core's execution.

### 1.2 Core Components

#### 1.2.1 Control Structures

```cpp
struct Xclogctrl {
    enum Status {
        xcl_uninitialized,  // Not initialized
        xcl_start,          // Processing write
        xcl_stop,           // Session is stopped
        xcl_success,        // Idle, completed successfully
        xcl_err             // Idle, finished with errors
    };
    Uint16 reqid;   // Incremental request ID
    Status status;  // Current status
    
    // Status checking methods
    bool is_busy() const volatile;
    bool is_success() const volatile;
    bool is_initialized() const volatile;
    bool is_err() const volatile;
};
```

This structure manages the cross-core log control state and provides methods to check its status. It's shared between cores to coordinate logging operations.

#### 1.2.2 Request Structure

```cpp
struct Xclogreq {
    static const Uint16 session_start = 0x0001;  // Start a session
    static const Uint16 session_stop = 0x0002;   // Stop a session
    Uint16 cmd;                                  // Command identifier
    
    // Command checking methods
    bool start_session() const;
    bool stop_session() const;
};
```

This structure defines the commands that can be sent from the client to the server to control logging sessions.

#### 1.2.3 Server-Side Implementation (`Xclogsvc`)

The server-side implementation in `Xclogsvc` class:

- Processes log requests from the client
- Manages log sessions (start/stop)
- Writes log data to storage
- Handles the cross-core communication protocol

Key methods:
- `step()`: Main processing function that handles requests and writes logs
- `reset()`: Resets the FIFO read pointer
- `write()`: Writes data from the cross-core buffer to the log

#### 1.2.4 Client-Side Implementation (`Xclogmng`)

The client-side implementation in `Xclogmng` class:

- Provides an interface for CPU2 to send log requests to CPU1
- Manages the client-side of the cross-core communication
- Buffers log data for transfer to the server

### 1.3 Communication Mechanism

The cross-core logging system uses several specialized data structures for communication:

1. **Synchronized Request Channel**: `Xclogreq_sync` - A synchronized channel for sending commands
2. **Cross-Core File Structures**:
   - `Xclogsvc_rdo`: Server-side read-only structure
   - `Xclogcli_wro<sz>`: Client-side write-only structure with configurable buffer size

3. **Data Transfer Protocol**:
   - Client writes log data to a shared buffer
   - Client sends a request to the server
   - Server processes the request and reads data from the shared buffer
   - Server writes the data to the actual log storage
   - Server updates the control structure to indicate completion

### 1.4 Session Management

The logging system uses sessions to organize log data:

1. **Session Start**:
   - Client sends a `session_start` command
   - Server initializes a new log session
   - Server sets status to `xcl_start`

2. **During Session**:
   - Client writes log data to the shared buffer
   - Server continuously processes and stores this data

3. **Session Stop**:
   - Client sends a `session_stop` command
   - Server flushes remaining data
   - Server sets status to `xcl_success` when complete

## 2. Boot Logging System

### 2.1 Purpose and Functionality

The boot logging system (`Bootlog` class) serves critical functions during system initialization:

- Records the system's boot status and history
- Determines the appropriate boot mode (normal or maintenance)
- Provides recovery mechanisms for failed boots
- Maintains redundant copies of boot information for reliability

### 2.2 Boot Log Data Structure

```cpp
struct Booting_info {
    Loadst load_status;  // Last power-up load result
    Uint16 retries;      // Number of partial loading tries
};
```

This structure stores:
- The load status from the previous boot (`load_status`)
- A counter of partial loading attempts (`retries`)

### 2.3 Boot States

The system defines several boot states (`Loadst` enum):
- `lst_normal`: Normal operation mode
- `lst_maintenance`: Maintenance/recovery mode
- `lst_ongoing`: Boot in progress
- `lst_failed`: Boot failed

### 2.4 Boot Log Operations

#### 2.4.1 Loading Boot Information

The `load()` method:
1. Attempts to read the primary boot log file
2. If corrupted, tries to read the backup copy
3. Determines the appropriate boot mode based on previous boot status
4. Updates retry counters if needed
5. Implements automatic fallback to maintenance mode after repeated failed boots
6. Returns the determined boot mode

```cpp
Loadst Bootlog::load() {
    // Algorithm:
    // 1. Try to read primary boot log file
    // 2. If successful, determine boot mode based on previous status
    // 3. If primary file corrupted, try backup copy
    // 4. If both corrupted, default to maintenance mode
    // 5. Update and save new boot status
    // 6. Return determined boot mode
}
```

#### 2.4.2 Saving Boot Information

Two methods for saving boot information:

1. **Synchronous Save** (`save()`):
   ```cpp
   void Bootlog::save(Loadst final_lst) {
       // Repeatedly call save_async until complete
       Base::Async_res res = Base::async_ongoing;
       while(res == Base::async_ongoing) {
           res = save_async(final_lst);
       }
   }
   ```

2. **Asynchronous Save** (`save_async()`):
   - Implements a state machine for non-blocking file operations
   - Writes to both primary and backup boot log files
   - Handles errors during the save process

### 2.5 Redundancy and Recovery

The boot logging system implements several reliability features:

1. **Dual File Storage**:
   - Maintains two copies of boot information (`last_boot_id` and `last_boot_copy_id`)
   - If one file is corrupted, the system can recover from the other

2. **Automatic Recovery**:
   - After a configurable number of failed boots (default: 30), automatically enters maintenance mode
   - Resets retry counter after successful boot

3. **Safe State Transitions**:
   - Uses the `set_states()` function to determine appropriate transitions between boot states
   - Ensures system doesn't get stuck in an unrecoverable state

## 3. Error Reporting and Handling

### 3.1 Error FIFO System

The system implements a FIFO-based error reporting mechanism that allows components to report errors without blocking:

```cpp
class Herrors {
public:
    // For multi-core platforms (shared memory)
    static Fifo_err_wr& get_xcerr_wr_remote();
    static Fifo_err_rd& get_xcerr_rd_remote();
    
    // For same-core error reporting
    static Fifo_err_wr& get_err_wr();
    static Fifo_err_rd& get_err_rd();
};
```

Key features:
- Separate FIFOs for local and cross-core error reporting
- Non-blocking write operations
- Thread-safe implementation

### 3.2 Error Reading Interfaces

The system provides interfaces for reading errors from the FIFOs:

```cpp
class Ierrors {
public:
    virtual Uint32 read(U8ostream& os) = 0;
};
```

Two implementations:

1. **Single-Core Error Reader** (`Errors_single`):
   ```cpp
   class Errors_single: public Ierrors {
   public:
       Errors_single(Fifo_err_rd& err_ff0);
       virtual Uint32 read(U8ostream& os);
   private:
       Fifo_err_rd& err_ff;
   };
   ```

2. **Dual-Core Error Reader** (`Errors_dual`):
   ```cpp
   class Errors_dual: public Ierrors {
   public:
       Errors_dual(Fifo_err_rd& ff_0, Fifo_err_rd& ff_1);
       virtual Uint32 read(U8ostream& os);
   private:
       Errors_single ff0;
       Errors_single ff1;
   };
   ```

The dual-core reader combines errors from two different FIFOs, allowing unified error handling across cores.

### 3.3 Error FIFO Implementation

The error FIFO implementation in `Herrors.cpp`:

```cpp
namespace {
    static volatile Array<Uint16>& get_cpu2_buff() {
        static const Uint32 ff_sz = 50UL;
        static Array<Uint16> buff(ff_sz, Memmgr::external);
        return buff;
    };

    static volatile Uint16* wrptr = get_cpu2_buff().first();
    static const volatile Uint16* rdptr = get_cpu2_buff().first();
}

Fifo_err_wr& Herrors::get_err_wr() {
    static Fifo_err_wr ff(get_cpu2_buff().first(), get_cpu2_buff().last(), rdptr, wrptr);
    return ff;
}

Fifo_err_rd& Herrors::get_err_rd() {
    static Fifo_err_rd ff(get_cpu2_buff().first(), get_cpu2_buff().last(), rdptr,
                          const_cast<const volatile Uint16* const volatile&>(wrptr));
    return ff;
}
```

This implementation:
- Uses a fixed-size array (50 elements) for storing errors
- Maintains separate read and write pointers
- Provides thread-safe access to the FIFO

## 4. System Error Bit Tracking

### 4.1 System Error Bits Class

The `Syserr_bits` class tracks system errors by monitoring boolean flags and updating a bitmask:

```cpp
class Syserr_bits {
public:
    Syserr_bits(Mblock<const volatile bool* const> bits0, 
                volatile Uint16& uvar0, 
                const volatile Uint16& loadst0);
    void step();

private:
    Bitmask<Uint16> mask;
    volatile Uint16& uvar;
    const volatile Uint16& loadst;
    Mblock<const volatile bool* const> bits;
};
```

### 4.2 Error Bit Tracking Algorithm

The `step()` method implements the error bit tracking logic:

```cpp
void Syserr_bits::step() {
    if (loadst != lst_ongoing) {
        for (Uint8 i = Ku16::u0; i < bits.size(); i++) {
            if(!*bits[i]) {
                mask.set(i);
            }
        }
        uvar = mask.value;
    }
}
```

Key features:
- Only updates error bits after system loading is complete (`loadst != lst_ongoing`)
- Sets bits in the bitmask when corresponding boolean flags are false
- Updates a shared variable with the current error state

## 5. Log Control Interface

### 5.1 Log Control Interface Definition

The `Ilogcontrol` interface defines the operations for writing logs:

```cpp
class Ilogcontrol {
public:
    virtual Base::Async_res write(const Kfieldset& fields,
                                 const U8pkmblock_k& data,
                                 Uint32& written) = 0;
    virtual Base::Async_res start_session() = 0;
    virtual Base::Async_res stop_session() = 0;
    virtual Base::Async_res del_logs(Uint16 initlog, Uint16 numlogsm, Uint16& deleted) = 0;

protected:
    Ilogcontrol();
    virtual ~Ilogcontrol();
};
```

This interface:
- Defines methods for writing log data
- Manages log sessions
- Provides log deletion capabilities
- Uses asynchronous operations for non-blocking behavior

## 6. Cross-Core Logging Process Flow

### 6.1 Initialization

1. Server-side (`Xclogsvc`) initialization:
   - Set up control structures
   - Initialize read buffers
   - Set initial status to `xcl_success`

2. Client-side (`Xclogmng`) initialization:
   - Set up client-server communication channels
   - Initialize write buffers

### 6.2 Session Start

1. Client sends `session_start` command via `Xclogreq_sync`
2. Server detects command in `step()` method
3. Server calls `reset()` to initialize read pointers
4. Server sets status to `xcl_start`
5. Server calls `log_ctrl.start_session()` to begin a new log session
6. When session start completes, server sets `session_started` flag to true

### 6.3 Log Writing

1. Client writes log data to shared buffer via `Xcwr`
2. Server's `step()` method detects data in buffer
3. Server processes data in chunks (up to 256 words at a time)
4. For each chunk:
   - Server creates a memory block (`U8pkmblock`) from the data
   - Server calls `log_ctrl.write()` with the data and header fields
   - Server updates read pointer after successful write
   - Server handles buffer wrap-around when end is reached

### 6.4 Session Stop

1. Client sends `session_stop` command via `Xclogreq_sync`
2. Server detects command in `step()` method
3. Server sets status to `xcl_stop`
4. Server continues processing remaining data in buffer
5. When buffer is empty (read pointer equals write pointer), server sets status to `xcl_success`

## 7. Boot Logging Process Flow

### 7.1 System Initialization

1. System creates `Bootlog` instance with file interface and file IDs
2. System calls `Bootlog::load()` to determine boot mode
3. `load()` reads boot information from files
4. Based on previous boot status and retry count, `load()` determines appropriate boot mode
5. System enters either normal or maintenance mode based on returned value

### 7.2 Boot Status Update

1. During system operation, system monitors boot progress
2. At shutdown or after successful boot, system calls `Bootlog::save()` with final status
3. `save()` updates boot information and writes to both primary and backup files
4. Updated boot information is used on next system startup

### 7.3 Boot Recovery

If system fails to boot properly:
1. Retry counter is incremented in boot log
2. After configurable number of retries (default: 30), system enters maintenance mode
3. Maintenance mode allows for recovery operations
4. Successful boot resets retry counter

## 8. Error Handling Process Flow

### 8.1 Error Reporting

1. Components report errors by writing to error FIFO:
   - Local components use `Herrors::get_err_wr()`
   - Remote components use `Herrors::get_xcerr_wr_remote()`

2. Error data is stored in the FIFO buffer without blocking the reporting component

### 8.2 Error Reading

1. Error handling components read errors using `Ierrors` interface
2. `Errors_single::read()` or `Errors_dual::read()` extracts errors from FIFOs
3. Errors are serialized to output stream for processing or logging
4. FIFO read pointer is updated, but content is not discarded (allowing multiple readers)

### 8.3 System Error Bit Tracking

1. `Syserr_bits` monitors boolean error flags
2. When system loading completes, `step()` method updates error bitmask
3. Error bits are set when corresponding flags are false
4. Updated bitmask is stored in shared variable for system-wide access

## 9. Key Design Patterns and Architectural Decisions

### 9.1 Client-Server Architecture

The cross-core logging system uses a client-server architecture to:
- Separate log generation (client) from log storage (server)
- Allow non-blocking log operations on the client side
- Enable efficient cross-core communication

### 9.2 FIFO-Based Communication

FIFOs are used extensively for:
- Cross-core data transfer
- Error reporting
- Non-blocking operations

### 9.3 Redundancy and Recovery

The boot logging system implements redundancy through:
- Dual file storage
- Automatic recovery mechanisms
- Retry counting and fallback modes

### 9.4 Asynchronous Operations

Many operations are implemented asynchronously to:
- Prevent blocking critical system functions
- Allow operations to be spread across multiple execution cycles
- Support real-time system requirements

### 9.5 Interface-Based Design

The system uses interfaces (e.g., `Ilogcontrol`, `Ierrors`) to:
- Decouple components
- Allow multiple implementations
- Facilitate testing and mocking

## 10. Referenced Context Files

The following context files provided useful information for understanding the logging and error handling system:

- `Xclog.h`: Defines core cross-core logging structures
- `Xclogmng.h`: Implements client-side logging management
- `Xclogsvc.h` and `Xclogsvc.cpp`: Implement server-side logging service
- `Bootlog.h` and `Bootlog.cpp`: Implement boot logging system
- `Herrors.h` and `Herrors.cpp`: Implement error FIFO access
- `Errors_single.h` and `Errors_single.cpp`: Implement single-core error reading
- `Errors_dual.h`: Implements dual-core error reading
- `Syserr_bits.h` and `Syserr_bits.cpp`: Implement system error bit tracking
- `Ilogcontrol.h`: Defines log control interface