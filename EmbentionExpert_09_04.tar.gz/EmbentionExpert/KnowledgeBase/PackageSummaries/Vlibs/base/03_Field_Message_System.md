# Generated from:

- code/include/Fmsg.h (791 tokens)
- code/include/Fmsgmgr.h (3262 tokens)
- code/include/Fmsgproducer.h (1058 tokens)
- code/include/Fmsgconsumer.h (1273 tokens)
- code/include/Fmsgchecker.h (634 tokens)
- code/include/Fmsg_cfg.h (241 tokens)
- code/include/Fmsg_cfg_entry.h (101 tokens)
- code/include/Fmsg_trigger.h (644 tokens)
- code/include/Ifmsg_trigger.h (106 tokens)
- code/source/Fmsg.cpp (447 tokens)
- code/source/Fmsgmgr.cpp (520 tokens)
- code/source/Fmsgproducer.cpp (1662 tokens)
- code/source/Fmsgconsumer.cpp (3536 tokens)
- code/source/Fmsgchecker.cpp (525 tokens)
- code/source/Fmsg_cfg.cpp (552 tokens)
- code/source/Fmsg_trigger.cpp (757 tokens)

---

# Field Message System: Comprehensive Summary

This document provides a high-fidelity extraction of the field message system, which enables custom message definition, production, consumption, and management with precise timing control.

## 1. System Architecture Overview

The field message system is built around several key components:

1. **Base Message Classes**:
   - `Fmsg`: Base class for message handling with timing capabilities
   - `Fmsgtx`: Producer-specific message handling (extends `Fmsg`)
   - `Fmsgrx`: Consumer-specific message handling (extends `Fmsg`)

2. **Message Management**:
   - `Fmsgmgr`: Central manager coordinating producers and consumers
   - `Fmsgproducer`: Handles message generation and transmission
   - `Fmsgconsumer`: Handles message reception and parsing

3. **Configuration and Triggering**:
   - `Fmsg_cfg`: Configuration for individual messages
   - `Fmsg_trigger`: Mechanism to trigger message transmission
   - `Fmsgchecker`: Monitors message reception frequency

4. **Interfaces**:
   - `Ifmsg_trigger`: Interface for triggering message transmission
   - `Itproducer_u8`: Interface for byte-level message production
   - `Itconsumer_u8`: Interface for byte-level message consumption

## 2. Base Message Classes

### 2.1 Fmsg Class

The `Fmsg` class serves as the foundation for both message producers and consumers, providing timing functionality.

```cpp
class Fmsg {
public:
    Fmsg();
    bool is_timeout(Real tcfg) const;
    Base::Chrono clk;  // Chrono to check timeout and allow delays or periods
};
```

Key behaviors:
- Initializes a chronometer (`clk`) for timing control
- Provides timeout checking via `is_timeout(Real tcfg)` which returns true if the current time has reached the specified timeout

Implementation details:
- `is_timeout(Real tcfg)` returns true if `tcfg` is greater than or equal to 0 AND `clk.toc()` is greater than or equal to `tcfg`
- The chronometer is initialized with `true` to start it immediately

### 2.2 Fmsgtx Class (Producer)

The `Fmsgtx` class extends `Fmsg` with producer-specific functionality:

```cpp
class Fmsgtx : public Fmsg {
public:
    Fmsgtx();
    bool cmdtx_async_send;  // Flag for pending send requests
    void time_check(Real time);
    bool first;  // Flag for first time execution
};
```

Key behaviors:
- Tracks whether a message has been requested to be sent asynchronously
- Manages timing for periodic message transmission
- Handles first-time execution logic to avoid computing time delta initially

Implementation details:
- `time_check(Real time)` calculates time differences and adjusts the chronometer
- `cmdtx_async_send` is initialized to false and set to true when a message needs to be sent on demand
- `first` is initialized to true and used to avoid computing time delta on first execution

### 2.3 Fmsgrx Class (Consumer)

The `Fmsgrx` class extends `Fmsg` with consumer-specific functionality:

```cpp
class Fmsgrx : public Fmsg {
public:
    Fmsgrx();
    Uint32 xstart;  // Bit index inside a custom message
    bool eof;       // End of file flag
};
```

Key behaviors:
- Tracks the current bit position within a message being processed
- Indicates when a message has been completely processed via the `eof` flag

Implementation details:
- `xstart` is initialized to 0 and updated as message parsing progresses
- `eof` is initialized to false and set to true when a message has been fully processed

## 3. Message Manager (Fmsgmgr)

The `Fmsgmgr` class serves as the central coordinator for all message producers and consumers:

```cpp
class Fmsgmgr : public Itunable, public Istep, public Itriggers_get {
public:
    Fmsgmgr(IFMCP& adsb_v, IFMCP& ext_sen);
    Fmsgproducer& get_producer(Uint16 idx);
    Fmsgconsumer& get_consumer(Uint16 idx);
    Mblock<Fmsgproducer> get_producers();
    Mblock<Fmsgconsumer> get_consumers();
    void cset(Base::Lossy_error& str);
    void cget(Base::Lossy& str) const;
    void step();
    
    template <Uint16 nprods, Uint16 nphdrs, Uint16 ncons, Uint16 nchdrs>
    void config(const Base::Fmsgproducer::Config& pcfg,
                const Mblock<const volatile typename Fmsg_cfg_entry<nphdrs>::Type>& pvecs,
                Uint16 max_psz_allowed,
                const Base::Fmsgconsumer::Config& ccfg,
                const Mblock<const volatile typename Fmsg_cfg_entry<nchdrs>::Type>& cvecs,
                Uint16 max_csz_allowed);
                
    virtual Ifmsg_trigger* get_trigger(Uint16 idx);
};
```

Key responsibilities:
1. **Producer/Consumer Management**:
   - Creates and manages arrays of message producers and consumers
   - Provides access to individual producers and consumers via getter methods

2. **Configuration**:
   - Configures producers and consumers with their respective settings
   - Allocates memory for message buffers based on configuration

3. **Message Processing**:
   - Processes incoming messages via the `step()` method
   - Triggers message generation via the `cset()` method

4. **Trigger Management**:
   - Provides access to message triggers via the `get_trigger()` method

Implementation details:
- Uses `FMCPmgr` (Field Message Processor Manager) to process messages
- Maintains arrays of producers (`fmps`), consumers (`fmcs`), and triggers (`prod_trigers`)
- The `config()` template method configures producers and consumers with their respective settings
- The `step()` method calls the `step()` method of each consumer to process incoming messages
- The `cset()` method deserializes a command to trigger message generation

## 4. Message Producer (Fmsgproducer)

The `Fmsgproducer` class handles the generation and transmission of messages:

```cpp
class Fmsgproducer : public Itproducer_u8, public Ifmsg_trigger {
public:
    struct Config {
        Iget& src0;                         // Interface to read variable values
        const Fmset_kfsv& mset0;            // Field sets
        const volatile Dsync& fmc_dsync;    // Custom messages Dsync
    };
    
    Fmsgproducer(const Config& cfg, const Fmsg_cfg_vec& pvecs);
    virtual bool read(Uint8& data);
    virtual void send_cmdtx(Uint16 msg_id);
    static inline Uint16 get_mem_used();
};
```

Key responsibilities:
1. **Message Generation**:
   - Reads data from a source interface
   - Formats data according to configured field sets
   - Generates messages at configured intervals

2. **On-Demand Transmission**:
   - Supports triggering message transmission on demand via `send_cmdtx()`

3. **Byte-Level Access**:
   - Implements the `Itproducer_u8` interface to provide byte-level access to generated messages

Implementation details:
- Uses a `Lossy` stream to build messages
- Maintains state for each configured message vector
- Tracks timing for periodic message generation
- Implements buffer management to optimize memory usage
- The `read(Uint8& data)` method provides the next byte of a message if available
- The `send_cmdtx(Uint16 msg_id)` method triggers the generation of a specific message

## 5. Message Consumer (Fmsgconsumer)

The `Fmsgconsumer` class handles the reception and parsing of messages:

```cpp
class Fmsgconsumer : public Itconsumer_u8 {
public:
    struct Config {
        Iset& dst;                          // Iset to store parsed values
        const Fmset::Kfsv& mset;            // Field sets
        Imsgchecker& msgcheck;              // Custom msg checker interface
        const volatile Dsync& fmc_dsync;    // Custom messages Dsync
        Uint16 max_fields_per_msg;          // Max number of fields per message
        Uint16 max_frefs_per_msg;           // Max number of Frefs per message
        Uint16 max_r64_per_msg;             // Maximum number of double precision variables
        Uint16 max_n_bmap_msg;              // Maximum number of Bitmap type message
    };
    
    Fmsgconsumer(const Config& cfg, const Fmsg_cfg_vec& cvecs);
    virtual bool write(Uint8 data);
    virtual bool wr_available() const;
    void step(FMCPmgr& fmcp);
    static inline Uint16 get_mem_used();
};
```

Key responsibilities:
1. **Message Reception**:
   - Receives bytes via the `write()` method
   - Buffers incoming data for processing

2. **Message Parsing**:
   - Parses received data according to configured field sets
   - Handles endianness conversion if needed
   - Stores parsed values in a destination interface

3. **Frequency Monitoring**:
   - Notifies a message checker when messages are received
   - Handles timeout logic for message reception

Implementation details:
- Uses a `Lossy` stream to buffer incoming data
- Maintains state for each configured message vector
- Implements buffer management to optimize memory usage
- The `write(Uint8 data)` method adds a byte to the buffer
- The `step(FMCPmgr& fmcp)` method processes buffered data
- Handles partial message reception and timeout logic

## 6. Message Configuration

### 6.1 Fmsg_cfg Structure

The `Fmsg_cfg` structure defines the configuration for a single message:

```cpp
struct Fmsg_cfg {
    Uint16          id;              // Message identifier
    Real            delay_discard;   // Delay/discard time
    FMCPmgr::Type   process_type;    // Processor type
    Uint16          bitid;           // Timeout bit offset
    
    void cset(Base::Lossy_error& str);
};
```

Key fields:
- `id`: Identifies the message within the system
- `delay_discard`: For producers, the delay until the next message can be sent; for consumers, the time to discard partially parsed bytes
- `process_type`: Specifies which processor should handle the message
- `bitid`: Offset to show timeout results

Implementation details:
- The `cset()` method deserializes configuration from a PDIC (Portable Data Interchange Container)
- Validates configuration parameters to ensure they are within valid ranges

### 6.2 Fmsg_cfg_entry Template

The `Fmsg_cfg_entry` template defines a collection of message configurations:

```cpp
template <Uint16 NVECS>
struct Fmsg_cfg_entry {
    typedef Tnarrayresz<Base::Fmsg_cfg, NVECS> Vecs;    // Data of one consumer/producer
    typedef Tuple<Uint16, Vecs> Type;                   // cfg for one consumer/producer
};
```

This template is used to create arrays of message configurations for producers and consumers.

## 7. Message Frequency Checking (Fmsgchecker)

The `Fmsgchecker` class monitors message reception frequency:

```cpp
class Fmsgchecker: public Imsgchecker {
public:
    Fmsgchecker(Bvar id, Uint16 size);
    Fmsgchecker(Bvar id, Uint16 size, Uint16 max_ids);
    void check(Uint16 bitid, Uint16 msgid);
    virtual bool msg_arrived(Uint16 msgid, Real timeout);
};
```

Key responsibilities:
1. **Timeout Tracking**:
   - Tracks timeouts for each configured message
   - Updates status bits when messages are received or timeouts expire

2. **Status Reporting**:
   - Reports message reception status via boolean variables
   - Provides a way to check if messages are being received at the expected frequency

Implementation details:
- Uses arrays of boolean variables (`bits`) and timeout handlers (`touts`)
- The `check()` method updates status bits based on timeout expiration
- The `msg_arrived()` method is called when a message is received and updates the timeout

## 8. Message Triggering

### 8.1 Ifmsg_trigger Interface

The `Ifmsg_trigger` interface defines the contract for triggering message transmission:

```cpp
class Ifmsg_trigger {
public:
    virtual void send_cmdtx(Uint16 msg_id) = 0;
};
```

This interface is implemented by `Fmsgproducer` to allow triggering message transmission.

### 8.2 Fmsg_trigger Class

The `Fmsg_trigger` class provides a mechanism to trigger multiple messages:

```cpp
class Fmsg_trigger : public Ideserializable {
public:
    Fmsg_trigger(Itriggers_get& can_trg, Uint16 can_idx0,
                 Itriggers_get& u8_trg, Uint16 u8_idx0);
    virtual void cset(Lossy_error& str);
    void trigger();
};
```

Key responsibilities:
1. **Message Triggering**:
   - Triggers the transmission of configured CAN and serial messages
   - Supports triggering multiple messages at once

2. **Configuration**:
   - Configures which messages should be triggered
   - Deserializes configuration from a PDIC

Implementation details:
- Maintains arrays of message IDs for CAN and serial messages
- The `trigger()` method iterates through configured message IDs and triggers their transmission
- Supports up to 3 messages per trigger (defined by `max_n_msgs`)

## 9. Message Flow and Processing

### 9.1 Message Production Flow

1. **Configuration**:
   - Message producers are configured with field sets and timing parameters
   - Each producer is associated with a data source interface

2. **Periodic Generation**:
   - Producers check their timing parameters to determine when to generate messages
   - When a timeout is reached, the producer reads data from its source interface
   - The data is formatted according to the configured field set
   - The formatted message is stored in a buffer

3. **On-Demand Generation**:
   - Messages can be triggered on demand via the `send_cmdtx()` method
   - This sets the `cmdtx_async_send` flag, which causes the message to be generated on the next `read()` call

4. **Byte-Level Access**:
   - The `read()` method provides byte-level access to generated messages
   - This allows the message to be transmitted one byte at a time

### 9.2 Message Consumption Flow

1. **Reception**:
   - Bytes are received via the `write()` method
   - The received bytes are stored in a buffer

2. **Parsing**:
   - The `step()` method processes buffered data
   - For each configured message vector, the consumer attempts to parse the data
   - If parsing is successful, the parsed values are stored in the destination interface
   - The message checker is notified of the message reception

3. **Timeout Handling**:
   - If a message is not received within the configured timeout, the consumer discards partially parsed data
   - The message checker updates status bits to indicate timeout expiration

### 9.3 Manager Coordination

The message manager coordinates the overall flow:

1. **Configuration**:
   - The manager configures producers and consumers with their respective settings
   - Memory is allocated for message buffers based on configuration

2. **Processing**:
   - The manager's `step()` method calls each consumer's `step()` method
   - This processes any received messages

3. **Triggering**:
   - The manager's `cset()` method deserializes commands to trigger message generation
   - This calls the appropriate producer's `send_cmdtx()` method

## 10. Memory Management

The field message system includes careful memory management:

1. **Buffer Sizing**:
   - Producers calculate buffer sizes based on the maximum message size
   - Consumers calculate buffer sizes based on the sum of all message sizes
   - Static counters (`mem_used`) track memory usage

2. **Memory Allocation**:
   - Memory is allocated from the external memory manager
   - Assertions ensure that memory usage does not exceed configured limits

3. **Buffer Reuse**:
   - Producers reuse buffers for different messages
   - Consumers discard processed data to free buffer space

## 11. Error Handling and Validation

The field message system includes robust error handling:

1. **Configuration Validation**:
   - Message configurations are validated during deserialization
   - Invalid configurations trigger assertions

2. **Buffer Management**:
   - If a consumer's buffer is full, it discards the oldest data
   - If a producer's buffer is full, it waits until space is available

3. **Timeout Handling**:
   - Consumers discard partially parsed messages after a timeout
   - The message checker reports timeout expiration via status bits

## Referenced Context Files

The following context files provided useful information for understanding the field message system:

1. `Fmsg_cfg_vec.h` - Provided insight into how message vectors are configured
2. `Imsgchecker.h` - Helped understand the message checking interface
3. `Itproducer_u8.h` and `Itconsumer_u8.h` - Clarified the byte-level interfaces for message production and consumption
4. `FMCPmgr.h` - Provided context on the field message processor manager