# Generated from:

- code/include/Iridium.h (1552 tokens)
- code/include/ATcmd_task.h (356 tokens)
- code/include/ATmsg_parser.h (305 tokens)
- code/source/Iridium.cpp (3463 tokens)
- code/source/ATcmd_task.cpp (521 tokens)
- code/source/ATmsg_parser.cpp (266 tokens)

---

# Iridium Communication System: Comprehensive Summary

## 1. System Overview and Architecture

The Iridium communication system provides satellite-based communication using the Short Burst Data (SBD) protocol. This system enables sending and receiving data packets via the Iridium satellite network, which provides global coverage. The implementation consists of several interconnected components that manage the communication flow between the application and the satellite modem.

### Core Components

1. **Iridium Class** (`Iridium.h`, `Iridium.cpp`)
   - Main controller for satellite communication
   - Implements the `Ipkt_port` interface
   - Manages the state machine for modem operations
   - Handles packet transmission and reception

2. **AT Command Handling** (`ATcmd_task.h`, `ATcmd_task.cpp`)
   - Manages sending AT commands to the modem
   - Handles command timeouts and responses

3. **AT Message Parsing** (`ATmsg_parser.h`, `ATmsg_parser.cpp`)
   - Parses responses from the modem
   - Detects success/error conditions
   - Extracts data from responses

4. **Data Buffering**
   - Uses FIFO buffers for input/output data
   - Manages packet construction and validation

### Communication Flow

```
Application Layer
      ↕
   Iridium
      ↕
  ATcmd_task
      ↕
 ATmsg_parser
      ↕
Serial Interface
      ↕
Iridium Modem
      ↕
Satellite Network
```

## 2. Iridium State Machine

The Iridium class implements a comprehensive state machine to manage the satellite modem's operation cycle. The state machine handles initialization, message checking, reading, and sending operations.

### State Diagram

```
                  ┌───────────┐
                  │  st_init  │
                  └─────┬─────┘
                        │
                        ▼
                ┌───────────────┐
                │ st_init_wait  │
                └───────┬───────┘
                        │
                        ▼
                   ┌────────┐
          ┌────────│ st_idle│◄────────┐
          │        └────┬───┘         │
          │             │             │
          ▼             ▼             ▼
┌──────────────┐  ┌──────────────┐  ┌──────────────┐
│ st_check_mb  │  │ st_read_msg  │  │ st_send_msg  │
└──────┬───────┘  └──────┬───────┘  └──────┬───────┘
       │                 │                 │
       │                 │                 ▼
       │                 │          ┌──────────────────┐
       │                 │          │st_send_msg_check │
       │                 │          └────────┬─────────┘
       │                 │                   │
       ▼                 ▼                   ▼
┌─────────────────────────────────────────────────────┐
│                     st_idle                         │
└─────────────────────────────────────────────────────┘
```

### State Descriptions

1. **st_init**
   - Flushes any pending data
   - Sends initialization AT commands to configure the modem
   - Transitions to `st_init_wait`

2. **st_init_wait**
   - Waits for modem to respond to initialization
   - On success: Sets `ready = true` and transitions to `st_idle`
   - On failure: Retries initialization

3. **st_idle**
   - Central waiting state
   - Checks for pending MT (Mobile Terminated) messages
   - Checks for messages to send (MO - Mobile Originated)
   - Monitors for ring alerts from the modem
   - Transitions based on conditions:
     - If MT message pending: → `st_read_msg`
     - If MO message to send: → `st_send_msg`
     - If check timeout or ring alert: → `st_check_mb`

4. **st_check_mb**
   - Initiates an SBD session with `AT+SBDIX` command
   - Parses the six-integer response to determine message status
   - Updates the `sbd_session` structure with status information
   - Transitions based on results:
     - If message sent successfully: Clears MO buffer
     - If error: Returns to `st_idle`

5. **st_read_msg**
   - Reads binary data from the modem with `AT+SBDRB`
   - Processes the received data into a packet
   - Sends the packet to the registered packet sender
   - Clears the MT buffer
   - Returns to `st_idle`

6. **st_send_msg**
   - Prepares to send binary data with `AT+SBDWB=<length>`
   - Waits for "READY" response from modem
   - Sends packet data followed by checksum
   - Transitions to `st_send_msg_check`

7. **st_send_msg_check**
   - Checks if the message was accepted by the modem
   - On success: Sets `sent = true` and transitions to `st_check_mb`
   - On failure: Returns to `st_idle`

8. **st_clear_msg_wait**
   - Waits for confirmation that message buffers were cleared
   - Returns to `st_idle` when complete

## 3. AT Command Handling

The system uses a dedicated task (`ATcmd_task`) to manage AT command execution and response handling.

### ATcmd_task State Machine

```
┌──────────┐      ┌────────────────┐      ┌──────────┐
│ st_send  │─────►│st_wait_answer  │─────►│ st_ended │
└──────────┘      └────────────────┘      └──────────┘
```

1. **st_send**
   - Sends the AT command prefix ("AT")
   - Sends the command string
   - Sends carriage return (0x0D)
   - Transitions to `st_wait_answer`

2. **st_wait_answer**
   - Monitors for response using the provided parser
   - Checks for timeout if specified
   - Transitions to `st_ended` when response received or timeout occurs

3. **st_ended**
   - Final state indicating command execution is complete
   - Result available via `step()` return value

### Command Types

The Iridium class defines several AT commands used for SBD communication:

1. **at_init_cmd**: `"&K0;E0;+SBDAREG=1;+SBDMTA=1;+SBDD2"`
   - Disables RTS/CTS flow control
   - Disables echo
   - Sets automatic registration
   - Enables ring alert
   - Clears MO and MT buffers

2. **at_sbdix**: `"+SBDIX"`
   - Initiates an SBD session
   - Returns six integers with status information

3. **at_sbdrb**: `"+SBDRB"`
   - Reads binary data from the module
   - Returns format: LengthH, LengthL, Message, CRC

4. **at_sdbwb**: `"+SBDWB=<length>"`
   - Writes binary data to the modem
   - Requires length parameter
   - Expects "READY" response before sending data

5. **at_sbdd0**: `"+SBDD0"`
   - Clears SBD MO message buffers

6. **at_sbdd1**: `"+SBDD1"`
   - Clears SBD MT message buffers

7. **at_sbdd2**: `"+SBDD2"`
   - Clears both SBD MO and MT message buffers

## 4. AT Message Parsing

The `ATmsg_parser` class handles parsing responses from the modem. It monitors the incoming data stream for specific success or error strings.

### Parser States

The parser returns one of four result states:
1. **res_unfinished**: Parsing is ongoing, no definitive result yet
2. **res_ok**: Success string detected
3. **res_error**: Error string detected
4. **res_timeout**: Command timed out

### Parsing Process

1. Reads bytes from the input port
2. Appends bytes to a buffer
3. Checks if the success string is matched
4. Checks if the error string is matched
5. Returns appropriate result when a match is found

### Special Response Handling

The system includes specialized parsers for different response types:
- **p_std_res**: Standard "OK"/"ERROR" responses
- **p_ringalert**: Detects "SBDRING" notifications
- **p_send_ready**: Detects "READY" response for binary transfers

## 5. SBD Session Management

The Iridium system manages SBD sessions through a structured approach to sending and receiving messages.

### SBD Session Structure

The `SBDSession` structure stores six integers returned by the `AT+SBDIX` command:
```cpp
struct SBDSession {
    Uint16 mo_status;   // MO status (0-2 = success)
    Uint16 mo_msn;      // MO message sequence number
    Uint16 mt_status;   // MT status
    Uint16 mt_msn;      // MT message sequence number
    Uint16 mt_length;   // MT message length
    Uint16 mt_queued;   // MT messages queued
};
```

### Message Reception Process

1. Detect pending message via `AT+SBDIX` response
2. Issue `AT+SBDRB` command to read binary data
3. Parse the binary data format:
   - First byte: Length high byte
   - Second byte: Length low byte
   - Next N bytes: Message data
   - Last 2 bytes: CRC
4. Validate message using CRC
5. Process valid message into an `Espkt` packet
6. Forward packet to registered packet sender
7. Clear MT buffer with `AT+SBDD1`

### Message Transmission Process

1. Prepare message in `tx_pkt`
2. Issue `AT+SBDWB=<length>` command
3. Wait for "READY" response
4. Send optional P2P header if configured
5. Send packet data
6. Calculate and send CRC
7. Check for acceptance
8. Initiate SBD session with `AT+SBDIX`
9. Verify successful transmission
10. Clear MO buffer with `AT+SBDD0`

## 6. Packet Handling and Validation

The system implements robust packet handling with validation mechanisms to ensure data integrity.

### Packet Structure

Packets are handled using the `Espkt` class, which appears to be a wrapper around a standard packet format. The system supports:

1. **Standard packets**: Basic SBD messages
2. **P2P packets**: Messages with additional addressing header

### P2P Header Format

When `cfg.serial_dst` is non-zero, a 5-byte header is added:
```
'R', 'B', <dst_high>, <dst_mid>, <dst_low>
```
Where the last three bytes encode the destination serial number.

### CRC Calculation

CRC is calculated by summing all bytes in the message:
```cpp
Uint16 crc = 0;
for (each byte in message) {
    crc += byte;
}
```

The CRC is appended as two bytes (high byte, low byte) after the message data.

### Packet Validation

When receiving a packet:
1. Extract length from first two bytes
2. Read message data
3. Extract CRC from last two bytes
4. Calculate CRC from message data
5. Compare calculated CRC with received CRC
6. Accept packet only if CRCs match

## 7. Error Handling and Recovery

The system implements several error handling mechanisms to ensure reliable operation.

### Timeout Handling

- Command timeouts are managed by the `ATcmd_task` class
- Different timeout values are used for different operations:
  - `w_med` (5.0 seconds): Standard commands
  - `w_vslow` (120.0 seconds): SBD session initiation

### Error Recovery

- Failed commands typically result in a transition to `st_idle`
- The system tracks failed message reception with `msgs_rec_fail` counter
- Initialization failures trigger a retry of the initialization process

### State Transition on Error

The `set_error()` method handles error conditions by:
1. Setting `busy = false`
2. Transitioning to `st_idle`

## 8. Configuration and Status Tracking

### Configuration Parameters

The `Iridium_cfg` structure contains configuration parameters:
- `enabled`: Enables/disables the Iridium system
- `check_timeout`: Time between mailbox checks (default 120 seconds)
- `serial_dst`: Destination serial for P2P mode (0 = disabled)

### Status Tracking

The system maintains several status indicators:
- `ready`: Indicates if the modem is initialized and ready
- `busy`: Indicates if an operation is in progress
- `msgs_sent`: Counter for successfully sent messages
- `msgs_rec`: Counter for successfully received messages
- `msgs_rec_fail`: Counter for failed message receptions

## 9. Buffer Management

The system uses several buffers to manage data flow:

1. **ff_in/ff_out**: FIFO buffers for external communication
   - Size: `max_buff_sz` (258 bytes)
   - Used for port communication

2. **buffer**: Main buffer for AT command responses
   - Size: `max_buff_sz` (258 bytes)
   - Stores parsed command responses

3. **buffer_ring**: Buffer for ring alert detection
   - Size: 24 bytes
   - Used specifically for detecting "SBDRING" notifications

4. **aux**: Auxiliary string buffer
   - Size: 12 bytes
   - Used for command construction

## 10. Practical Aspects of Satellite Communication

### Communication Timing

The Iridium system implements timing considerations specific to satellite communication:
- Regular mailbox checks every 120 seconds (configurable)
- Extended timeout (120 seconds) for SBD session initiation
- Standard timeout (5 seconds) for most AT commands

### Ring Alert Handling

The system monitors for "SBDRING" notifications, which indicate incoming messages:
- Dedicated parser (`p_ringalert`) watches for this notification
- When detected, triggers immediate mailbox check

### Message Prioritization

The system prioritizes message handling in this order:
1. Reading pending MT messages
2. Sending queued MO messages
3. Regular mailbox checks

## Referenced Context Files

No context files were provided in the input.

## Conclusion

The Iridium communication system provides a robust implementation of the Short Burst Data (SBD) protocol for satellite communication. It features a comprehensive state machine for managing modem operations, dedicated components for AT command handling and response parsing, and mechanisms for packet validation and error recovery. The system supports both standard SBD messages and P2P communication with addressing headers, making it suitable for various satellite communication applications.