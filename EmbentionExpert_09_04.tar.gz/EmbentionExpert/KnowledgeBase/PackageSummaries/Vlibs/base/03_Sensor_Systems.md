# Generated from:

- code/include/Tmeas1D.h (490 tokens)
- code/include/Tmeas3D.h (718 tokens)
- code/include/Tcal1D.h (492 tokens)
- code/include/Tcal3D.h (701 tokens)
- code/include/Xcal0.h (502 tokens)
- code/include/Xcal1D.h (58 tokens)
- code/include/Xcal3D.h (58 tokens)
- code/include/Varsens1D_cfg.h (197 tokens)
- code/include/Varsens3D_cfg.h (222 tokens)
- code/include/Rvarsensor1D_cfg.h (291 tokens)
- code/include/Rvarsensor3D_cfg.h (351 tokens)
- code/include/Meastypes.h (3170 tokens)
- code/include/Meastypes_fw.h (23 tokens)
- code/include/Sensel.h (162 tokens)
- code/include/Radrng.h (483 tokens)
- code/include/Radrng_fw.h (64 tokens)
- code/include/Gnss_nav_raw.h (531 tokens)
- code/include/Tllh.h (778 tokens)
- code/include/Tllh_fw.h (20 tokens)
- code/include/Tllh_low_res.h (256 tokens)
- code/include/Tllh_low_res_fw.h (30 tokens)
- code/include/Tllcs.h (253 tokens)
- code/include/Tllcs_fw.h (21 tokens)
- code/include/Tllhcompressed.h (491 tokens)
- code/include/Tllhcompressed_fw.h (88 tokens)
- code/source/Tmeas1D.cpp (163 tokens)
- code/source/Tmeas3D.cpp (296 tokens)
- code/source/Tcal1D.cpp (341 tokens)
- code/source/Tcal3D.cpp (375 tokens)
- code/source/Varsens1D_cfg.cpp (193 tokens)
- code/source/Varsens3D_Cfg.cpp (193 tokens)
- code/source/Rvarsensor1D_cfg.cpp (423 tokens)
- code/source/Rvarsensor3D_cfg.cpp (549 tokens)
- code/source/Meastypes.cpp (476 tokens)
- code/source/Sensel.cpp (97 tokens)
- code/source/Radrng.cpp (81 tokens)
- code/source/Tllh.cpp (640 tokens)
- code/source/Tllh_low_res.cpp (149 tokens)
- code/source/Tllcs.cpp (187 tokens)
- code/source/Tllhcompressed.cpp (850 tokens)

---

# Comprehensive Summary of Sensor Measurement and Calibration System

## 1. Functional Behavior and Logic

The sensor measurement and calibration system provides a comprehensive framework for handling various types of sensor measurements, applying calibrations, and managing geographic coordinates. The system supports both 1D (scalar) and 3D (vector) sensor measurements with temperature-dependent calibration capabilities.

### Core Measurement Classes

#### Tmeas1D
- **Purpose**: Applies 1D calibration to 1D sensor measurements
- **Key Components**:
  - `enable_cal`: Flag to enable/disable calibration
  - `measure`: Reference to the sensor measurement handler
  - `cal`: Calibration configuration for the sensor
- **Behavior**:
  - When writing a value, applies calibration if enabled, then writes to the measurement handler
  - Provides access to the calibration object via `get_cal()`

#### Tmeas3D
- **Purpose**: Applies 3D calibration to 3D sensor measurements
- **Key Components**:
  - `enable_cal`: Flag to enable/disable calibration
  - `measure`: Reference to the 3D sensor measurement handler
  - `cal`: 3D calibration configuration
- **Behavior**:
  - Supports writing 3D measurements as individual x,y,z components or as a vector
  - When writing values, applies 3D calibration if enabled, then writes to the measurement handler
  - Provides access to the calibration object via `get_cal()`

### Calibration System

#### Tcal1D
- **Purpose**: Configures and applies linear calibration to 1D sensors
- **Key Components**:
  - `cfg`: Configuration for calibration parameters
  - `curr_temp`: Current working temperature
  - `cal_params`: Calibration values (bias, scale) for current temperature
- **Behavior**:
  - Computes calibrated output using formula: `v_out = (1.0 + scale) * v_in - bias`
  - Updates calibration parameters based on temperature using `set_temp()`
  - Uses temperature hysteresis to avoid recalculating parameters for small temperature changes

#### Tcal3D
- **Purpose**: Applies 3D calibration with temperature compensation
- **Key Components**:
  - `cfg`: Calibration configuration
  - `prev_temp`: Previous working temperature
  - `a`: 3x3 calibration matrix
  - `b`: 3x1 bias vector
- **Behavior**:
  - Computes calibrated output using formula: `v_out = A * (v_in - bias)`
  - Updates calibration parameters based on temperature using `set_temp()`
  - Uses temperature hysteresis to avoid recalculating parameters for small temperature changes

#### Xcal0
- **Purpose**: Base template structure for temperature calibration configuration
- **Key Components**:
  - `temp_hyst`: Temperature hysteresis threshold
  - `cal_data`: Calibration values table for different temperatures
- **Behavior**:
  - Supports up to 3 temperature entries for calibration
  - Deserializable from PDI (Protocol Data Interface)

#### Xcal1D and Xcal3D
- **Purpose**: Specialized calibration configuration types for 1D and 3D sensors
- **Behavior**:
  - Xcal1D uses 2 calibration parameters (bias, scale)
  - Xcal3D uses 12 calibration parameters (3 for bias vector, 9 for calibration matrix)

## 2. Control Flow and State Transitions

### Sensor Measurement Flow

1. **Measurement Collection**:
   - Raw sensor values are collected from physical sensors or simulated via variables
   - Values are passed to appropriate measurement handlers (Hmeas1, Hmeas3, etc.)

2. **Calibration Application**:
   - If calibration is enabled, raw values are processed through calibration objects
   - Temperature-dependent calibration parameters are updated when temperature changes beyond hysteresis threshold
   - Calibrated values are computed using appropriate formulas

3. **Measurement Storage**:
   - Calibrated (or raw if calibration disabled) values are stored in measurement handlers
   - Values become available for reading by other system components

### Temperature Compensation State Transitions

| State | Trigger | Actions | Next State | Location |
|-------|---------|---------|------------|----------|
| Current calibration parameters | Temperature change > hysteresis | Interpolate new calibration parameters from table | Updated calibration parameters | Tcal1D::set_temp, Tcal3D::set_temp |
| Current calibration parameters | Temperature change ≤ hysteresis | No action | Current calibration parameters | Tcal1D::set_temp, Tcal3D::set_temp |

## 3. Inputs and Stimuli

### Sensor Measurements

The system handles various types of sensor inputs:

1. **1D Sensor Measurements**:
   - Static pressure sensors (mstp_*)
   - Dynamic pressure sensors (mqinf_*)
   - Range measurements (lidar, external range sensors, radar altimeter)

2. **3D Sensor Measurements**:
   - Accelerometers (macc_*)
   - Gyroscopes (mgyr_*)
   - Magnetometers (mmag_*)

3. **Position and Navigation Measurements**:
   - GPS positions (pos)
   - GPS velocities (vel)
   - GPS relative positions (drn)
   - Absolute time fixes (time_fix)

4. **Variable Sensor Inputs**:
   - Real variable sensors (1D and 3D)
   - Support for configurable variable-based sensor simulation

### Sensor Selection

The `Sensel` structure manages active sensor selection:
- `mag`: Bitmask of selected magnetometers
- `stp`: Bitmask of selected static pressure sensors
- `done`: Flag indicating if configuration has been read

## 4. Outputs and Effects

### Calibrated Measurements

The primary outputs of the system are calibrated sensor measurements:

1. **1D Calibrated Values**:
   - Output formula: `v_out = (1.0 + scale) * v_in - bias`
   - Available through measurement handlers (Hmeas1)

2. **3D Calibrated Values**:
   - Output formula: `v_out = A * (v_in - bias)`
   - Available through measurement handlers (Hmeas3)

### Geographic Coordinate Representations

The system provides multiple representations of geographic coordinates:

1. **High-Precision Coordinates (Tllh)**:
   - 64-bit representation of longitude, latitude, and height
   - Full precision for navigation applications

2. **Low-Resolution Coordinates (Tllh_low_res)**:
   - 32-bit representation with approximately 2-meter precision
   - Used for relative positioning and error calculations

3. **Compressed Coordinates (Tllhcompressed)**:
   - Integer representation for efficient storage and transmission
   - Longitude and latitude in 1e-7 degrees units
   - Height in millimeters

4. **Longitude/Latitude Sines and Cosines (Tllcs)**:
   - Pre-computed trigonometric values for efficient coordinate transformations

## 5. Parameters and Configuration

### Calibration Parameters

1. **1D Calibration Parameters**:
   - `bias`: Offset correction
   - `scale`: Scale factor correction
   - `temp_hyst`: Temperature hysteresis threshold

2. **3D Calibration Parameters**:
   - `b0, b1, b2`: Bias vector components
   - `a00...a22`: 3x3 calibration matrix elements
   - `temp_hyst`: Temperature hysteresis threshold

### Variable Sensor Configuration

1. **1D Variable Sensor Configuration (Rvarsensor1D_cfg)**:
   - `rvar_id`: Internal variable ID
   - `min_value`: Minimum allowed value
   - `max_value`: Maximum allowed value
   - `max_delta`: Maximum allowed increment
   - `max_count_nv`: Maximum non-variation count to discard measurement

2. **3D Variable Sensor Configuration (Rvarsensor3D_cfg)**:
   - `rvar_id0, rvar_id1, rvar_id2`: Variable IDs for X, Y, Z components
   - `min_value`: Minimum allowed value
   - `max_value`: Maximum allowed value
   - `max_delta`: Maximum allowed increment
   - `max_count_nv`: Maximum non-variation count to discard measurement

## 6. Error Handling and Contingency Logic

### Parameter Validation

1. **Calibration Configuration Validation**:
   - Ensures temperature hysteresis is within valid range (0.0 to 100.0K)
   - Verifies calibration table has at least one entry
   - Sets `err_invalid_cal_table` PDI error if validation fails

2. **Variable Sensor Configuration Validation**:
   - Ensures variable IDs are valid
   - Verifies min_value < max_value
   - Sets `err_rvarsensor` PDI error if validation fails

3. **Geographic Coordinate Validation**:
   - Validates longitude is within [-π, π] range
   - Validates latitude is within [-π/2, π/2] range
   - Sets `err_tllhcompressed` PDI error if validation fails

### Measurement Handling

1. **Measurement Value Setting**:
   - `Meas::set_meas_value()` returns false if sensor ID is invalid
   - Validates sensor IDs before writing measurements

2. **Coordinate Wrapping**:
   - Longitude difference calculations handle wrapping at ±π
   - `Radrng` provides utilities for handling angle ranges and wrapping

## 7. File-by-File Breakdown

### Measurement Classes

#### Tmeas1D.h/cpp
- Defines `Tmeas1D` class for applying 1D calibration to 1D sensor measurements
- Provides methods to write values and access calibration

#### Tmeas3D.h/cpp
- Defines `Tmeas3D` class for applying 3D calibration to 3D sensor measurements
- Provides methods to write vector values and access calibration

### Calibration Classes

#### Tcal1D.h/cpp
- Implements linear calibration for 1D sensors
- Provides temperature compensation and parameter interpolation

#### Tcal3D.h/cpp
- Implements matrix-based calibration for 3D sensors
- Provides temperature compensation and parameter interpolation

#### Xcal0.h
- Template structure for temperature calibration configuration
- Defines serialization/deserialization methods

#### Xcal1D.h and Xcal3D.h
- Specialized calibration configuration types for 1D and 3D sensors

### Variable Sensor Configuration

#### Varsens1D_cfg.h/cpp and Varsens3D_cfg.h/cpp
- Define configurations for variable-based sensor simulation
- Support optional configuration of multiple sensors

#### Rvarsensor1D_cfg.h/cpp and Rvarsensor3D_cfg.h/cpp
- Define configuration parameters for individual variable sensors
- Implement validation and serialization/deserialization

### Measurement Types and Structures

#### Meastypes.h/cpp
- Defines core measurement types and structures
- Implements measurement handlers and sensor selection
- Provides enumerations for different sensor types and sources

#### Sensel.h/cpp
- Manages active sensor selection via bitmasks
- Provides initialization method

### Geographic Coordinate Handling

#### Tllh.h/cpp
- Implements high-precision geographic coordinates
- Provides methods for coordinate manipulation and conversion

#### Tllh_low_res.h/cpp
- Implements low-resolution geographic coordinates
- Provides methods for conversion from high-precision coordinates

#### Tllcs.h/cpp
- Computes and stores longitude/latitude sines and cosines
- Provides efficient access to trigonometric values for coordinate transformations

#### Tllhcompressed.h/cpp
- Implements compressed representation of geographic coordinates
- Provides conversion methods to/from high-precision coordinates

#### Radrng.h/cpp
- Implements range handling for angular values
- Provides methods for checking if angles are within range and wrapping

## 8. Cross-Component Relationships

### Measurement and Calibration Flow

```
Sensor Input → Tmeas1D/Tmeas3D → Tcal1D/Tcal3D → Measurement Handler
```

- `Tmeas1D` and `Tmeas3D` act as controllers that decide whether to apply calibration
- `Tcal1D` and `Tcal3D` perform the actual calibration calculations
- Calibration parameters are configured via `Xcal1D` and `Xcal3D`

### Variable Sensor Configuration Hierarchy

```
Varsens1D_cfg/Varsens3D_cfg → Rvarsensor1D_cfg/Rvarsensor3D_cfg → Rvar
```

- `Varsens1D_cfg` and `Varsens3D_cfg` contain multiple optional sensor configurations
- Each sensor configuration is defined by `Rvarsensor1D_cfg` or `Rvarsensor3D_cfg`
- Sensor values are accessed via `Rvar` identifiers

### Geographic Coordinate Relationships

```
Tllh ↔ Tllh_low_res ↔ Tllhcompressed
  ↓
Tllcs
```

- `Tllh` provides high-precision coordinate representation
- `Tllh_low_res` offers lower precision for relative positioning
- `Tllhcompressed` provides compact representation for storage/transmission
- `Tllcs` computes trigonometric values from coordinates for transformations

### Measurement Type Hierarchy

```
Meas
  ├── Type_array_stp (static pressure)
  ├── Type_array_qinf (dynamic pressure)
  ├── Type_array_range (range measurements)
  ├── Type_array_acc (accelerometers)
  ├── Type_array_gyr (gyroscopes)
  ├── Type_array_mag (magnetometers)
  ├── Type_array_pos (GPS positions)
  ├── Type_array_vel (GPS velocities)
  └── Type_array_drn (GPS relative positions)
```

- `Meas` contains arrays of different measurement types
- Each array contains measurements from different sources (internal, external, variable)
- Measurement handlers (`Hmeas1`, `Hmeas3`, etc.) provide thread-safe access

## 9. Referenced Context Files

No context files were provided in the input.

## Detailed Technical Implementation

### Sensor Measurement Representation

The system uses template-based measurement handlers with specific synchronization traits:

```cpp
template <typename T>
struct Tmeasure : type_is<Tdsync<T, Tdsynctraits::Rd_blocking<T>, Tdsynctraits::Wr_mutex<T> > >
{
};

typedef Tmeasure<Real   >::type Hmeas1;
typedef Tmeasure<Rv3    >::type Hmeas3;
```

This provides thread-safe access to measurements with blocking reads and mutex-protected writes.

### Calibration Computation

#### 1D Calibration

```cpp
Real Tcal1D::compute(const Real vin) const
{
    return ((1.0F + cal_params[scale])*vin - cal_params[bias]);
}
```

#### 3D Calibration

```cpp
void Tcal3D::compute(const Maverick::Irvector3& vin, Rv3& vout) const
{
    // A*(x-b)
    Maverick::Irvector3 rout(vout);
    rout.vecres(vin, Maverick::Irvector3::K(b).kvec);
    rout.matthis(Maverick::Irmatrix3::K(a).kmat);
}
```

### Temperature Compensation

Both calibration classes implement temperature-based parameter interpolation:

```cpp
void Tcal1D::set_temp(Real temp)
{
    if((Rmath::fabsr(curr_temp-temp) > cfg.temp_hyst))
    {
        Maverick::Rvectorn<Xcal1D0::cal_sz> v0;
        Maverick::Rtable t(const_cast<const Xcal0<Xcal1D0::cal_sz>::Type_table&>(cfg.cal_data));
        t.interp1_linear(temp, v0);
        curr_temp = temp;
        cal_params.copy(v0);
    }
}
```

### Geographic Coordinate Handling

The system provides multiple representations of geographic coordinates with conversion methods:

```cpp
void Tllhcompressed::set(const Tllh& llh0)
{
    lon    = static_cast<int32>(scale64_lonlat_i*llh0.ll.lon);
    lat    = static_cast<int32>(scale64_lonlat_i*llh0.ll.lat);
    height = static_cast<int32>(scale64_height_i*llh0.h);
}

void Tllhcompressed::get(Tllh& llh0) const
{
    llh0.ll.lon = scale64_lonlat_o*static_cast<Real64>(lon);
    llh0.ll.lat = scale64_lonlat_o*static_cast<Real64>(lat);
    llh0.h      = scale64_height_o*static_cast<Real64>(height);
}
```

### GNSS Time Handling

The system includes specialized structures for handling GNSS time:

```cpp
struct GNSS_week_tow
{
    Uint16 week;     // GPS week number
    Uint32 tow_ms;   // GPS millisecond since start of week

    void set_total_ms(const int64 total_gnss_ms);
    int64 get_total_ms() const;
    void add_ms(const int64 inc_ms);
};
```

### Sensor Selection and Management

The `Sensel` structure manages active sensor selection:

```cpp
struct Sensel
{
    Bitmask<Uint16> mag;   // Bit mask of selected magnetometers
    Bitmask<Uint16> stp;   // Bit mask of selected static pressure sensors
    bool done;             // True if all configuration has been read

    void init();           
};
```

### Measurement Collection

The `Meas` structure provides a comprehensive collection of all sensor measurements:

```cpp
struct Meas
{
    Type_array_stp      stp;        // Static pressure sensors
    Type_array_qinf     qinf;       // Dynamic pressure sensors
    Type_array_range    range;      // Range measures
    Hmeas_time          imu_stamp;  // Timestamp for IMU
    Type_array_acc      acc;        // Accelerometers
    Type_array_gyr      gyr;        // Gyroscopes
    Type_array_mag      mag;        // Magnetometers
    Type_array_pos      pos;        // GPS positions
    Type_array_vel      vel;        // GPS speeds
    Type_array_drn      drn;        // GPS relative positions
    Type_array_time_fix time_fix;   // Absolute time fix
    Hmeas_abs_time      abs_time;   // Absolute time
    // Additional navigation-related measurements
    Hmeasinest          inest;
    Hmeasnavsim         navsim;
    Hmeasnav            navext;
    Hmeasnav            navig_vn300;
    Hmeasnav            navextsen;
};
```

## Summary

The sensor measurement and calibration system provides a comprehensive framework for handling various types of sensor data with temperature-dependent calibration. It supports both 1D and 3D sensors, offers multiple geographic coordinate representations, and includes mechanisms for sensor selection and configuration. The system is designed with thread safety in mind and provides extensive error handling and validation.

The architecture allows for flexible sensor configuration, including the use of variable-based sensor simulation, and supports a wide range of sensor types including accelerometers, gyroscopes, magnetometers, pressure sensors, and range sensors. The calibration system provides temperature compensation through parameter interpolation, ensuring accurate measurements across different operating conditions.