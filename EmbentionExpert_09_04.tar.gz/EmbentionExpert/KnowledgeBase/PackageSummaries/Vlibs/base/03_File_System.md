# Generated from:

- code/include/Xcfile.h (2344 tokens)
- code/include/Xcfilecli.h (3073 tokens)
- code/include/Xcfilectrl.h (1748 tokens)
- code/include/Xcfilesvc.h (1411 tokens)
- code/include/Xcff.h (1097 tokens)
- code/include/Xcff_fw.h (132 tokens)
- code/include/Ifile_null.h (286 tokens)
- code/include/Mem_file.h (2434 tokens)
- code/include/Mem_range.h (65 tokens)
- code/include/XMem_file_reader.h (721 tokens)
- code/include/DFS2_fs_fw.h (22 tokens)
- code/source/Xcfile.cpp (988 tokens)
- code/source/Xcfilecli.cpp (8069 tokens)
- code/source/Xcfilesvc.cpp (6900 tokens)
- code/source/Ifile_null.cpp (364 tokens)
- code/source/Mem_file.cpp (3821 tokens)

---

# Cross-Core File System Architecture

This document provides a comprehensive analysis of the cross-core file system implementation. The system enables file operations across multiple processor cores, using a client-server architecture with asynchronous operations.

## 1. System Architecture Overview

The cross-core file system implements a client-server model where:

- **Client Side (Xcfile/Xcfilecli)**: Runs on one core and provides file operation interfaces to applications
- **Service Side (Xcfilesvc)**: Runs on another core and handles the actual file operations
- **Communication**: Uses shared memory buffers and synchronization mechanisms to transfer data and commands

### 1.1 Core Components

```
┌─────────────────────┐      ┌─────────────────────┐
│     Client Core     │      │    Service Core     │
│                     │      │                     │
│  ┌───────────────┐  │      │  ┌───────────────┐  │
│  │    Xcfile     │  │      │  │  Xcfilesvc    │  │
│  │ (User API)    │──┼──────┼──│ (File Server) │  │
│  └───────┬───────┘  │      │  └───────┬───────┘  │
│          │          │      │          │          │
│  ┌───────┴───────┐  │      │          │          │
│  │   Xcfilecli   │  │      │          │          │
│  │ (Client impl) │  │      │          │          │
│  └───────┬───────┘  │      │          │          │
│          │          │      │          │          │
│  ┌───────┴───────┐  │      │  ┌───────┴───────┐  │
│  │ Cross-core    │◄─┼──────┼─►│ Cross-core    │  │
│  │ Buffers       │  │      │  │ Buffers       │  │
│  └───────────────┘  │      │  └───────┬───────┘  │
│                     │      │          │          │
└─────────────────────┘      │  ┌───────┴───────┐  │
                             │  │   Mem_file    │  │
                             │  │  (or other    │  │
                             │  │  file impl)   │  │
                             │  └───────────────┘  │
                             │                     │
                             └─────────────────────┘
```

### 1.2 Key Classes and Their Roles

1. **Xcfile**: User-facing API implementing the `Ifile` interface
2. **Xcfilecli**: Client-side implementation handling communication with the service
3. **Xcfilesvc**: Service-side implementation handling actual file operations
4. **Xcfilectrl**: Control structure for cross-core file operations
5. **Xcfilereq**: Request structure for file operations
6. **Mem_file**: Memory-based file system implementation (used by service side)

## 2. Cross-Core Communication Mechanism

### 2.1 Shared Memory Structures

The system uses several shared memory structures for cross-core communication:

1. **Xcfilectrl**: Status information from service to client
   - Current operation status
   - File size and position
   - CRC information
   - Request ID for synchronization

2. **Xcfilereq_sync**: Request information from client to service
   - Operation type (open, read, write, seek, close)
   - File ID and mode
   - Offset and size parameters

3. **Cross-core Buffers**: Data transfer between cores
   - `Xcfilecli_rw::Txcbuffer`: Client-side buffer (512 bytes)
   - `Xcfilesvc_rw::Txcbuffer`: Service-side buffer (512 bytes)

### 2.2 Synchronization Mechanism

The system uses a request-acknowledge pattern:

1. Client sends a request with a unique ID
2. Service processes the request and updates status
3. Service acknowledges by copying the request ID to its control structure
4. Client checks for acknowledgment by comparing IDs

```
┌─────────┐                      ┌─────────┐
│ Client  │                      │ Service │
└────┬────┘                      └────┬────┘
     │                                │
     │ 1. Send request (reqid=X)      │
     │────────────────────────────────►
     │                                │
     │                                │ 2. Process request
     │                                │
     │ 3. Check if reqid in ctrl = X  │
     │◄────────────────────────────────┤ 4. Set reqid in ctrl = X
     │                                │
     │ 5. Request complete            │
     │                                │
```

## 3. File System Operations

### 3.1 File Opening Process

1. Client calls `Xcfile::open_async` with file ID and mode
2. `Xcfilecli` creates an open request and sends it to service
3. `Xcfilesvc` receives request and calls `Ifile::open_async` on the actual file implementation
4. Service updates status to `xcf_open_finished` or `xcf_err`
5. Client checks status and returns appropriate result

### 3.2 File Reading Process

1. Client calls `Xcfile::read_async` with a memory block
2. `Xcfilecli` enters `st_req_read` state and sends read request
3. `Xcfilesvc` enters `xcf_wait_read` state and prepares buffer
4. Service reads data from file into cross-core buffer
5. Service updates status to `xcf_read_finished`
6. Client reads data from cross-core buffer into user's memory block
7. Client returns completion status

```
┌─────────┐                      ┌─────────┐
│ Client  │                      │ Service │
└────┬────┘                      └────┬────┘
     │                                │
     │ 1. read_async(block, size)     │
     │────────────────────────────────►
     │                                │
     │                                │ 2. Read from file
     │                                │
     │                                │ 3. Write to cross-core buffer
     │                                │
     │ 4. Read from cross-core buffer │
     │◄────────────────────────────────┤
     │                                │
     │ 5. Return data to caller       │
     │                                │
```

### 3.3 File Writing Process

1. Client calls `Xcfile::write_async` with data
2. `Xcfilecli` enters `st_write_xcf` state and writes data to cross-core buffer
3. `Xcfilecli` sends write request to service
4. `Xcfilesvc` enters `xcf_wait_write` state and reads from cross-core buffer
5. Service writes data to file
6. Service updates status to `xcf_write_finished`
7. Client returns completion status

```
┌─────────┐                      ┌─────────┐
│ Client  │                      │ Service │
└────┬────┘                      └────┬────┘
     │                                │
     │ 1. write_async(data, size)    │
     │                                │
     │ 2. Write to cross-core buffer │
     │                                │
     │ 3. Send write request          │
     │────────────────────────────────►
     │                                │
     │                                │ 4. Read from cross-core buffer
     │                                │
     │                                │ 5. Write to file
     │                                │
     │ 6. Check completion status     │
     │◄────────────────────────────────┤
     │                                │
     │ 7. Return result to caller     │
     │                                │
```

### 3.4 File Seeking Process

1. Client calls `Xcfile::seek_async` with offset and mode
2. `Xcfilecli` creates a seek request with calculated position
3. `Xcfilesvc` receives request and calls `Ifile::seek_async` on the file implementation
4. Service updates status to `xcf_seek_finished` or `xcf_err`
5. Client checks status and returns appropriate result

### 3.5 File Closing Process

1. Client calls `Xcfile::close_async`
2. `Xcfilecli` sends close request to service
3. `Xcfilesvc` calls `Ifile::close_async` on the file implementation
4. Service updates status to `xcf_idle` or `xcf_err`
5. Client checks status and returns appropriate result
6. `Xcfile` releases the client interface

## 4. Asynchronous Operation Pattern

All file operations follow an asynchronous pattern:

1. Initial call returns `async_ongoing` if operation cannot complete immediately
2. Caller must repeatedly call the same function with identical parameters
3. Function returns `async_done_ok` or `async_done_error` when complete

```cpp
// Example usage pattern
Async_res res;
do {
    res = file.open_async(id, mode);
} while (res == async_ongoing);

if (res == async_done_ok) {
    // Operation succeeded
} else {
    // Operation failed
}
```

### 4.1 State Machine Implementation

Both client and service use state machines to track operation progress:

#### Client States (Xcfilecli::State)
- `st_idle`: No operation in progress
- `st_opening`, `st_seeking`, `st_closing`: Waiting for service to complete operation
- `st_write_xcf`, `st_req_write`, `st_wait_write`: Writing data to file
- `st_req_read`, `st_wait_read`, `st_read`: Reading data from file

#### Service States (Xcfilectrl::Status)
- `xcf_uninitialized`: Initial state
- `xcf_idle`: No file operation in progress
- `xcf_opening`, `xcf_seeking`, `xcf_closing`: Processing file operations
- `xcf_wait_write`, `xcf_writing`, `xcf_write_finished`: Writing data
- `xcf_wait_read`, `xcf_reading`, `xcf_read_finished`: Reading data
- `xcf_err`: Error state

## 5. Data Transfer Mechanism

### 5.1 Cross-Core Buffer Management

The system uses fixed-size buffers (512 bytes) for data transfer:

1. **For Writing**:
   - Client writes data to its buffer using `Xcbuffer::Writer`
   - Service reads from client's buffer using `Xcbuffer::Reader`
   - Service writes to file

2. **For Reading**:
   - Service reads from file
   - Service writes to its buffer using `Xcbuffer::Writer`
   - Client reads from service's buffer using `Xcbuffer::Reader`

### 5.2 Chunked Data Transfer

For data larger than the buffer size, the system uses chunked transfers:

1. `Async_transfer_data` tracks total bytes and current chunk
2. Each iteration processes one buffer-sized chunk
3. Client must call the function repeatedly until all data is transferred

## 6. File Reference and Management

### 6.1 File Identification

Files are identified by a `Ifile::Uid` structure:
- Contains a file index
- Partition information (though some implementations like `Mem_file` ignore this)

### 6.2 File Modes

Files can be opened in different modes:
- `m_read`: Read-only access
- `m_write`: Write-only access
- `m_create`: Create new file
- `m_create_crc`: Create with CRC calculation

### 6.3 CRC Management

The system supports CRC (Cyclic Redundancy Check) for file integrity:

1. CRC is calculated during write operations
2. CRC is stored in file descriptor
3. CRC is verified during read operations when opened with appropriate mode
4. CRC can be retrieved via `get_crc()` and set via `set_crc()`

## 7. Memory-Based File System

The `Mem_file` class implements a memory-based file system:

1. Files are stored in RAM using the `Fsmem` structure
2. Each file has a header (`Fs_entry`) containing:
   - Size information
   - CRC value
   - Timestamp
3. File data is stored as 16-bit words

### 7.1 Memory File Operations

- **Opening**: Finds or creates file entry in memory
- **Reading**: Copies data from memory to user buffer
- **Writing**: Copies data from user buffer to memory
- **Seeking**: Updates current position pointer
- **Closing**: Updates file header and CRC

## 8. Error Handling

### 8.1 Error Detection

Errors are detected through:
1. Return values from asynchronous operations
2. Status flags in the control structure
3. CRC verification for data integrity

### 8.2 Error Recovery

When errors occur:
1. Service sets status to `xcf_err`
2. Client receives `async_done_error` from operations
3. Service attempts to close file to recover
4. Client releases resources and may retry operation

## 9. Cross-Component Relationships

### 9.1 Class Dependencies

```
┌─────────┐     ┌───────────┐     ┌───────────┐
│ Xcfile  │────►│ Xcfilecli │────►│ Xcfilereq │
└─────────┘     └───────────┘     └─────┬─────┘
                      │                  │
                      │                  │
                      ▼                  ▼
┌─────────┐     ┌───────────┐     ┌───────────┐
│ Ifile   │◄────│ Xcfilesvc │◄────│Xcfilectrl │
└─────────┘     └───────────┘     └───────────┘
     ▲
     │
┌────┴────┐
│ Mem_file│
└─────────┘
```

### 9.2 Interface Implementation

- `Xcfile` implements `Ifile` interface for client applications
- `Mem_file` implements `Ifile` interface for actual storage
- `Ifile_null` provides a null implementation for testing

### 9.3 Shared Memory Access

- Client has read-only access to service control structure
- Service has read-only access to client request structure
- Both have read-write access to their own buffers
- Both have read-only access to the other's buffer

## 10. Practical Usage

### 10.1 Client-Side Usage

```cpp
// Create file client
Xcfile file(xcfilecli_instance);

// Open file
Async_res res;
do {
    res = file.open_async(fileId, Ifile::m_read);
} while (res == async_ongoing);

if (res == async_done_ok) {
    // Read data
    U8pkmblock data(buffer, size);
    Uint32 bytesRead;
    
    do {
        res = file.read_async(data, bytesRead);
    } while (res == async_ongoing);
    
    // Close file
    do {
        res = file.close_async();
    } while (res == async_ongoing);
}
```

### 10.2 Service-Side Setup

```cpp
// Create file service
Mem_file memFile(fileSystem);
Xcfilesvc fileService(requestSync, control, serviceBuf, clientBuf, memFile);

// In main loop
while (true) {
    fileService.step();
    // Other processing...
}
```

## 11. Referenced Context Files

The following context files provided valuable insights:

1. **Ifile.h** - Defines the file interface used by both client and service
2. **Async_transfer_data.h** - Handles chunked data transfers
3. **Xcbuffer.h** - Implements cross-core buffer access
4. **Fsmem.h** - Memory-based file system implementation
5. **U8pkmblock.h** - Memory block handling for data transfers

## 12. Performance Considerations

1. **Buffer Size**: Fixed at 512 bytes, affecting transfer efficiency
2. **Chunking Overhead**: Multiple iterations needed for large files
3. **Synchronization**: Request-acknowledge pattern adds latency
4. **Memory Usage**: In-memory file system limited by available RAM
5. **CRC Calculation**: Adds computational overhead during writes

## 13. Security and Access Control

1. **Cross-Core Isolation**: Each core can only access its own memory directly
2. **No User Permissions**: System does not implement user-level access control
3. **CRC Protection**: Provides data integrity but not security
4. **No Encryption**: Data is stored and transferred in plaintext

## 14. Limitations

1. **Fixed Buffer Size**: 512 bytes may be inefficient for large transfers
2. **Synchronous Step Function**: Requires regular polling
3. **Limited Error Recovery**: Basic error states without detailed diagnostics
4. **No Directory Support**: Flat file structure with numeric IDs
5. **Single Client**: `Xcfile::current` limits to one active client at a time