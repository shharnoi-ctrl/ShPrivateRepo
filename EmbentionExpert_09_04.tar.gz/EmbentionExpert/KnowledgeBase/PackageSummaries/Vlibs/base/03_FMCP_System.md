# Generated from:

- code/include/IFMCP.h (142 tokens)
- code/include/IFMCP_fw.h (21 tokens)
- code/include/FMCPmgr.h (567 tokens)
- code/include/FMCPh.h (335 tokens)
- code/include/FMCP_null.h (242 tokens)
- code/source/FMCPmgr.cpp (195 tokens)
- code/source/FMCPh.cpp (tokens unknown)
- code/source/FMCP_null.cpp (49 tokens)

---

# Field Message Consumer Processor (FMCP) System

The Field Message Consumer Processor (FMCP) system provides a framework for processing custom messages with different sets of variables. It implements a processor interface hierarchy, management system, and helper functions for byte manipulation.

## 1. Functional Behavior and Logic

### Core Responsibilities
- Processes parsed custom messages with different variable sets
- Supports multiple processor types (Variable manager, ADS-B processor, External sensor)
- Provides a null implementation for the processor interface
- Manages processor instances and selection based on message type
- Offers helper functions for byte manipulation and conversion

### System Architecture
The FMCP system is built around an interface-based design pattern with the following key components:
- `IFMCP`: Base interface for all processors
- `FMCPmgr`: Manager class that maintains and provides access to processor instances
- `FMCP_null`: Null implementation of the processor interface
- `FMCPh`: Helper class with static utility functions

## 2. Interface Hierarchy and Core Components

### IFMCP Interface
The `IFMCP` class serves as the base interface for all Field Custom Message Processors.

**File: code/include/IFMCP.h**

```cpp
class IFMCP
{
public:
    virtual ~IFMCP();
    virtual void process(Vrefdstbuff& data, Iset& dst) = 0;
};
```

Key aspects:
- Defines a pure virtual `process` method that must be implemented by all concrete processors
- Takes a `Vrefdstbuff` reference for input data and an `Iset` reference for destination variables
- Implements a virtual destructor to ensure proper cleanup of derived classes

### FMCP Manager

The `FMCPmgr` class manages different types of processors and provides access to them based on type.

**File: code/include/FMCPmgr.h**

```cpp
class FMCPmgr
{
public:
    enum Type
    {
        tVarmgr      = 0,       ///< Generic variable manager processor (FMCP_varmgr).
        tADSB_v      = 1,       ///< ADS-B vehicle processor.
        t_ext_sensor = 2,       ///< External sensors.

        t_AFE        = tADSB_v  ///< AFE parser.
    };
    static const Uint16 num_types = 3U;     ///< Number of field message processor types.

    explicit FMCPmgr(IFMCP& adsb_v, IFMCP& ext_sen);
    IFMCP& get_proccesor(Type t);

private:
    Base::Suiteref<IFMCP,num_types + 1U> processors;
    
    // Deleted constructors/operators
    FMCPmgr();
    FMCPmgr(const FMCPmgr& orig);
    FMCPmgr& operator=(const FMCPmgr& orig);
};
```

Implementation details from **code/source/FMCPmgr.cpp**:

```cpp
FMCPmgr::FMCPmgr(IFMCP& adsb_v, IFMCP& ext_sen) :
    processors(*Memmgr::get_instance().get_allocator(Memmgr::external).allocate_new<FMCP_varmgr>(),
               adsb_v,
               ext_sen,
               *Memmgr::get_instance().get_allocator(Memmgr::external).allocate_new<FMCP_null>())
{
}

IFMCP& FMCPmgr::get_proccesor(Type t)
{
    return processors.get(Base::Assertions::runtime(t < num_types) ? t : num_types);
}
```

Key aspects:
- Defines an enumeration `Type` for different processor types:
  - `tVarmgr` (0): Generic variable manager processor
  - `tADSB_v` (1): ADS-B vehicle processor (also aliased as `t_AFE`)
  - `t_ext_sensor` (2): External sensors processor
- Constructor takes references to ADS-B and external sensor processors
- Internally creates a variable manager processor and a null processor
- Uses `Suiteref` to store references to all processors
- `get_proccesor` method returns the appropriate processor based on type
- Returns the null processor if the requested type is invalid
- Memory management is handled through `Memmgr::get_instance().get_allocator(Memmgr::external)`

### Null Processor Implementation

The `FMCP_null` class provides a null implementation of the `IFMCP` interface.

**File: code/include/FMCP_null.h**

```cpp
class FMCP_null : public IFMCP
{
public:
    FMCP_null();
    virtual void process(Vrefdstbuff& data, Iset& dst);

private:
    FMCP_null(const FMCP_null& orig);
    FMCP_null& operator=(const FMCP_null& orig);
};
```

Implementation details from **code/source/FMCP_null.cpp**:

```cpp
FMCP_null::FMCP_null()
{
}

void FMCP_null::process(Vrefdstbuff& data, Iset& dst)
{
    // Do nothing.
}
```

Key aspects:
- Implements the `IFMCP` interface
- `process` method is a no-op (does nothing)
- Follows the null object pattern to provide a safe default implementation
- Copy constructor and assignment operator are deleted

### Helper Functions

The `FMCPh` class provides static utility functions for byte manipulation and conversion.

**File: code/include/FMCPh.h**

```cpp
class FMCPh
{
public:
    static void get_uint8_uint8(const Uint16 in,
                                Uint8& outL,
                                Uint8& outH);

    static int32 get_int32_from_24b(const int32 in);

private:
    FMCPh();
    ~FMCPh();
    FMCPh(const FMCPh& orig);
    FMCPh& operator=(const FMCPh& orig);
};

inline void FMCPh::get_uint8_uint8(const Uint16 in,
                            Uint8& outL,
                            Uint8& outH)
{
    outH = static_cast<Uint8>((in >> Ku16::u8) & Ku16::u0xFF);
    outL = static_cast<Uint8>(in & Ku16::u0xFF);
}

inline int32 FMCPh::get_int32_from_24b(const int32 in)
{
    return ((in<<Ku16::u8)>>Ku16::u8);
}
```

Key aspects:
- `get_uint8_uint8`: Splits a 16-bit unsigned integer into high and low bytes
  - `outH` receives the most significant byte (bits 8-15)
  - `outL` receives the least significant byte (bits 0-7)
  - Uses bit shifting and masking operations
- `get_int32_from_24b`: Converts a 24-bit 2's complement number to a 32-bit integer
  - Preserves the sign bit by left-shifting and then right-shifting
- All constructors and operators are private (utility class pattern)

## 3. Processor Types and Selection

The FMCP system supports three main types of processors:

1. **Variable Manager (tVarmgr)**
   - Generic variable manager processor
   - Implemented by `FMCP_varmgr` class
   - Created internally by the `FMCPmgr` constructor

2. **ADS-B Vehicle Processor (tADSB_v)**
   - Processes variables for the ADS-B transponder
   - Also referred to as AFE parser (t_AFE)
   - Provided externally to the `FMCPmgr` constructor

3. **External Sensor Processor (t_ext_sensor)**
   - Processes data from external IMU or magnetometer
   - Provided externally to the `FMCPmgr` constructor

The processor selection logic is implemented in `FMCPmgr::get_proccesor`:
- Takes a `Type` enum value as input
- Performs a runtime assertion to check if the type is valid
- Returns the appropriate processor if the type is valid
- Returns the null processor if the type is invalid

## 4. Memory Management

The FMCP system uses the `Memmgr` class for memory allocation:

```cpp
FMCPmgr::FMCPmgr(IFMCP& adsb_v, IFMCP& ext_sen) :
    processors(*Memmgr::get_instance().get_allocator(Memmgr::external).allocate_new<FMCP_varmgr>(),
               adsb_v,
               ext_sen,
               *Memmgr::get_instance().get_allocator(Memmgr::external).allocate_new<FMCP_null>())
{
}
```

Key aspects:
- Uses a singleton pattern to access the memory manager (`Memmgr::get_instance()`)
- Allocates memory from the "external" allocator
- Creates instances of `FMCP_varmgr` and `FMCP_null` dynamically
- The `Suiteref` template is used to store and manage references to these processors

## 5. Design Patterns

The FMCP system employs several design patterns:

1. **Interface-based Design**
   - `IFMCP` defines the interface for all processors
   - Concrete implementations provide specific behavior

2. **Null Object Pattern**
   - `FMCP_null` provides a safe default implementation
   - Returned when an invalid processor type is requested

3. **Factory Method Pattern**
   - `FMCPmgr::get_proccesor` acts as a factory method
   - Returns the appropriate processor based on type

4. **Singleton Pattern**
   - `Memmgr::get_instance()` uses the singleton pattern

5. **Utility Class Pattern**
   - `FMCPh` is a utility class with static methods
   - All constructors and operators are private

## 6. File-by-File Breakdown

### IFMCP.h
- Defines the `IFMCP` interface
- Declares the virtual destructor and pure virtual `process` method
- Implements the destructor inline

### IFMCP_fw.h
- Forward declaration of the `IFMCP` class
- Used to avoid circular dependencies

### FMCPmgr.h
- Defines the `FMCPmgr` class
- Declares the processor types enum
- Declares methods for construction and processor retrieval

### FMCPh.h
- Defines the `FMCPh` utility class
- Declares and implements helper functions for byte manipulation
- Implements functions inline for performance

### FMCP_null.h
- Defines the `FMCP_null` class
- Implements the null object pattern for the `IFMCP` interface

### FMCPmgr.cpp
- Implements the `FMCPmgr` constructor
- Implements the `get_proccesor` method
- Creates instances of `FMCP_varmgr` and `FMCP_null`

### FMCP_null.cpp
- Implements the `FMCP_null` constructor
- Implements the `process` method as a no-op

## 7. Cross-Component Relationships

### Class Relationships
- `IFMCP` is the base interface for all processors
- `FMCP_null` implements `IFMCP`
- `FMCP_varmgr` implements `IFMCP` (referenced but not shown in the provided files)
- `FMCPmgr` contains references to multiple `IFMCP` implementations
- `FMCPh` is independent and provides utility functions

### Dependency Flow
- `FMCPmgr` depends on `IFMCP`, `FMCP_null`, and `FMCP_varmgr`
- `FMCP_null` depends on `IFMCP`
- `IFMCP_fw.h` provides forward declarations to break circular dependencies

## 8. Usage Patterns

### Typical Usage Flow
1. Create specific processor implementations (ADS-B, external sensor)
2. Create an instance of `FMCPmgr` with these processors
3. Use `FMCPmgr::get_proccesor` to retrieve the appropriate processor based on message type
4. Call the `process` method on the retrieved processor to handle the message

### Example Usage
```cpp
// Create specific processors
ADSB_Processor adsb_processor;
ExtSensor_Processor ext_sensor_processor;

// Create the manager
FMCPmgr manager(adsb_processor, ext_sensor_processor);

// Get the appropriate processor based on message type
IFMCP& processor = manager.get_proccesor(FMCPmgr::tADSB_v);

// Process the message
Vrefdstbuff data = /* ... */;
Iset destination = /* ... */;
processor.process(data, destination);
```

## 9. Error Handling and Contingency Logic

- If an invalid processor type is requested, `FMCPmgr::get_proccesor` returns the null processor
- The null processor's `process` method does nothing, preventing crashes or undefined behavior
- Runtime assertions are used to check if the requested type is valid

## 10. Helper Functions Details

### get_uint8_uint8
- **Purpose**: Splits a 16-bit unsigned integer into high and low bytes
- **Implementation**:
  ```cpp
  outH = static_cast<Uint8>((in >> Ku16::u8) & Ku16::u0xFF);
  outL = static_cast<Uint8>(in & Ku16::u0xFF);
  ```
- **Usage**: Useful for protocols that require byte-level access to 16-bit values

### get_int32_from_24b
- **Purpose**: Converts a 24-bit 2's complement number to a 32-bit integer
- **Implementation**:
  ```cpp
  return ((in<<Ku16::u8)>>Ku16::u8);
  ```
- **Usage**: Useful for handling 24-bit sensor data that needs to be processed as 32-bit values

## Summary

The Field Message Consumer Processor (FMCP) system provides a flexible framework for processing different types of custom messages. It uses an interface-based design with a manager class to select the appropriate processor based on message type. The system includes a null implementation for safety and helper functions for byte manipulation. Memory management is handled through a dedicated memory manager, and the system employs several design patterns including interface-based design, null object pattern, and factory method pattern.