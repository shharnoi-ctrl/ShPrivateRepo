# Generated from:

- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/base/03_Variable_Management.md (3303 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/base/03_Feature_Management.md (3824 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/base/03_File_System.md (3858 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/base/03_Core_Data_Structures.md (4318 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/base/03_FMCP_System.md (3043 tokens)

---

# Comprehensive Data Management Architecture in the System

This document provides a detailed analysis of the data management approach used throughout the system, synthesizing information from the provided summaries to explain how data is represented, stored, accessed, and processed across the system.

## 1. Core Data Representation Paradigms

The system employs several fundamental paradigms for representing and managing data:

### 1.1 Variable-Based Data Model

The system uses a centralized variable management approach where data is organized into typed variables with unique identifiers:

- **Variable Types**:
  - `Rvar`: Real (floating-point) variables
  - `Uvar`: Unsigned 16-bit integer variables
  - `Bvar`: Boolean variables
  - `Fid`: Feature variables (spatial positions)
  - `Bvar_map`: Bitmap variables (bit arrays)
  - `Uint64`: 64-bit unsigned integer variables

- **Variable Manager (Varmgr)**:
  - Serves as the central access point for all system variables
  - Implements a singleton pattern for global access
  - Provides getters and setters for all variable types
  - Ensures consistent access patterns across the system

- **Variable Access Patterns**:
  - `Commit`: Write to member variable, commit on explicit request
  - `Rcache`: Read/write to member variable, commit on write
  - `Wdif`: Write to Varmgr only if read value differs
  - `Rcwd`: Read/write to member variable, commit on write when value differs
  - `Rdblocking`: Wait until data is valid before reading
  - `Reg<k0>`: Element in shared memory with changes applied to CPU2
  - `Regarray<from0, to_inclusive0>`: Contiguous variables in dedicated shared memory

### 1.2 Feature-Based Spatial Representation

For spatial data, the system uses a specialized "Feature" representation:

- **Feature Structure**:
  ```cpp
  struct Feature {
      union Fdata {
          Tllhcompressed llh;  // Absolute position with centimeter precision
          Rv3 dr;             // Relative position with respect to wrt in meters
      };
      Uint16 wrt;            // Id of reference feature (0xFFFF if absolute)
      Fdata data;            // Position data (relative NED or absolute LLH)
  };
  ```

- **Feature Types**:
  - **Absolute Features**: Global positions in LLH (Longitude, Latitude, Height) coordinates
  - **Relative Features**: Local positions in NED (North, East, Down) coordinates relative to another feature

- **Feature References (Fref)**:
  - Allow indirect reference to features
  - Can store either a reference to an existing feature or a constant feature value

### 1.3 Field-Based Data Serialization

For data serialization and structured representation, the system uses a Field system:

- **Field Class**:
  - Represents a data field with type information and configuration
  - Supports numerous types including real numbers, integers, bits, checksums, etc.
  - Provides serialization/deserialization logic for each type

- **Field Organization**:
  - `Fieldset`: Collection of fields
  - `Fieldsvec`: Vectors of field sets with associated data
  - `Kfieldset`/`Kfieldsvec`: Read-only views of field sets/vectors

## 2. Data Storage Mechanisms

The system employs multiple storage mechanisms for different data types and use cases:

### 2.1 Memory-Based File System

- **Mem_file Class**:
  - Implements a memory-based file system
  - Files are stored in RAM using the `Fsmem` structure
  - Each file has a header (`Fs_entry`) containing size, CRC, and timestamp
  - File data is stored as 16-bit words

- **Cross-Core File System**:
  - Client-server architecture for file operations across processor cores
  - `Xcfile`: User-facing API implementing the `Ifile` interface
  - `Xcfilecli`: Client-side implementation handling communication
  - `Xcfilesvc`: Service-side implementation handling actual file operations
  - Uses shared memory buffers and synchronization mechanisms

### 2.2 Container Data Structures

The system provides several container data structures for in-memory data storage:

- **Map<K, V>**:
  - Key-value association container
  - Uses parallel containers for keys and values
  - Fixed capacity defined at construction

- **Jarray<T>** (Jagged Array):
  - Array of arrays/vectors where each sub-array can have a different size
  - All elements stored in a single contiguous memory block
  - Sub-arrays defined by pointers into this memory block

- **Hash_map<T>**:
  - Hash map container for elements with ID and hash functionality
  - Fixed-size allocation with hash buckets
  - Open addressing with linear probing for collision handling

- **Linkedlist<T>**:
  - Singly-linked list for sequential access
  - Elements allocated using a provided `Allocator`
  - Designed for ever-growing lists (only addition operations)

- **Set<T>**:
  - Collection with no duplicate elements
  - Fixed capacity defined at construction
  - Provides serialization/deserialization methods

### 2.3 Shared Memory for Cross-Core Communication

- **Registry Pattern**:
  - `Var<K>::Reg<k0>`: Variables in shared memory
  - `Var<K>::Regarray<from0, to_inclusive0>`: Contiguous variables in shared memory
  - Allows direct access via `.value` member
  - Synchronization with Varmgr via `copy_to_varmgr()`

- **Cross-Core Buffers**:
  - Fixed-size buffers (512 bytes) for data transfer between cores
  - `Xcfilecli_rw::Txcbuffer`: Client-side buffer
  - `Xcfilesvc_rw::Txcbuffer`: Service-side buffer
  - Support for chunked transfers for data larger than buffer size

## 3. Data Access Patterns

The system implements several patterns for accessing and manipulating data:

### 3.1 Direct vs. Indirect Access

- **Direct Access**:
  - Through `Varmgr` singleton for variables
  - Through memory blocks for contiguous data
  - Through registry arrays for shared memory variables

- **Indirect Access**:
  - Through variable references (`Vref_wr`)
  - Through feature references (`Fref`)
  - Through buffered destinations (`Vrefdstbuff`)

### 3.2 Synchronous vs. Asynchronous Operations

- **Synchronous Operations**:
  - Immediate completion or failure
  - Used for simple, fast operations

- **Asynchronous Operations**:
  - Return `async_ongoing` if operation cannot complete immediately
  - Caller must repeatedly call the same function with identical parameters
  - Function returns `async_done_ok` or `async_done_error` when complete
  - Used for operations that may take time or require multiple steps

### 3.3 Reader-Writer Synchronization

- **Dsync**:
  - Used by `Fieldsvec` and `Kfieldsvec` for reader-writer synchronization
  - Allows multiple readers or a single writer

- **Writer and Reader Classes**:
  - `Dsync::Writer` provides exclusive write access
  - `Dsync::Reader` provides shared read access
  - `Dsync::Writer_async` supports asynchronous writing operations

### 3.4 Buffered Updates

- **Vrefdstbuff**:
  - Buffers variable changes before committing them
  - Allows batch updates to variables
  - Supports different variable types (Rvar, Uvar, Bvar, Fid, Bvar_map, Uint64)

## 4. Data Flow Patterns

The system implements several patterns for data flow between components:

### 4.1 Variable Update Flow

```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│ Application │────►│ Variable    │────►│ Variable    │
│ Code        │     │ Reference   │     │ Manager     │
└─────────────┘     └─────────────┘     └─────────────┘
                                              │
                                              ▼
                                        ┌─────────────┐
                                        │ Shared      │
                                        │ Memory      │
                                        └─────────────┘
```

1. Application code creates a variable reference with type, ID, and value
2. Reference is passed to a variable destination
3. Destination translates reference to appropriate Varmgr calls
4. Variable Manager updates the variable value
5. For shared memory variables, changes propagate to other cores

### 4.2 Cross-Core File Operations

```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│ Application │────►│ Xcfile      │────►│ Xcfilecli   │
│ Code        │     │ (User API)  │     │ (Client)    │
└─────────────┘     └─────────────┘     └─────────────┘
                                              │
                                              ▼
                                        ┌─────────────┐
                                        │ Cross-core  │
                                        │ Buffers     │
                                        └─────────────┘
                                              │
                                              ▼
                                        ┌─────────────┐
                                        │ Xcfilesvc   │
                                        │ (Service)   │
                                        └─────────────┘
                                              │
                                              ▼
                                        ┌─────────────┐
                                        │ Mem_file    │
                                        │ (Storage)   │
                                        └─────────────┘
```

1. Application code calls `Xcfile` methods
2. `Xcfilecli` handles communication with the service
3. Data is transferred through cross-core buffers
4. `Xcfilesvc` performs actual file operations
5. `Mem_file` provides storage in memory

### 4.3 Field Message Processing

```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│ Message     │────►│ FMCPmgr     │────►│ Processor   │
│ Data        │     │ (Manager)   │     │ (IFMCP)     │
└─────────────┘     └─────────────┘     └─────────────┘
                                              │
                                              ▼
                                        ┌─────────────┐
                                        │ Variable    │
                                        │ Manager     │
                                        └─────────────┘
```

1. Message data is received
2. `FMCPmgr` selects appropriate processor based on message type
3. Processor processes the message and updates variables
4. Variable Manager stores the updated values

## 5. Key Design Principles

The data management architecture is built on several key design principles:

### 5.1 Centralized Variable Management

- Single point of access for all system variables
- Consistent access patterns across the system
- Support for different variable types and access modes
- Cross-core synchronization for shared variables

### 5.2 Memory Efficiency

- Fixed-size allocations for predictable memory usage
- Contiguous storage for related data (e.g., Jarray)
- Memory type specification for controlled allocation
- Reuse of memory blocks for efficient data transfer

### 5.3 Type Safety

- Strong typing for variables and fields
- Type-specific serialization and deserialization
- Compile-time validation where possible
- Runtime validation for dynamic operations

### 5.4 Concurrency Control

- Reader-writer synchronization for shared data
- Asynchronous operations for time-consuming tasks
- State machines for tracking operation progress
- Cross-core communication with synchronization mechanisms

### 5.5 Extensibility

- Interface-based design for pluggable components
- Template-based implementation for type flexibility
- Configuration-driven behavior for fields
- Support for custom processors and serializers

## 6. Common Data Abstractions

The system uses several common abstractions across different components:

### 6.1 Identifiers

- **Variable IDs**: Type-specific identifiers for variables (Rvar, Uvar, Bvar, Fid)
- **Feature IDs**: Enumeration values organized into logical groups
- **File IDs**: Unique identifiers for files in the file system

### 6.2 References

- **Variable References**: References to variables by ID and type
- **Feature References**: References to features by ID or value
- **Memory Blocks**: References to contiguous memory regions

### 6.3 Containers

- **Arrays**: Fixed-size containers for homogeneous data
- **Maps**: Key-value associations for lookup operations
- **Sets**: Collections of unique elements
- **Lists**: Sequential collections for ordered data

### 6.4 Serialization Formats

- **Field-Based**: Structured serialization with type information
- **Binary**: Raw binary serialization for efficient storage
- **Compressed**: Specialized formats for specific data types (e.g., LLH coordinates)

## 7. Data Flow Through the System

### 7.1 Data Acquisition

1. Data is acquired from sensors or external sources
2. Raw data is processed and converted to appropriate types
3. Processed data is stored in system variables through the Variable Manager
4. Variables may be absolute values or relative to other variables

### 7.2 Data Storage

1. Variables are stored in memory managed by the Variable Manager
2. Important data may be serialized to files using the Field system
3. Files are stored in the memory-based file system
4. Cross-core file operations allow access from different processor cores

### 7.3 Data Processing

1. Data is accessed through the Variable Manager or directly from memory
2. Processing logic operates on the data to produce new values
3. Results are stored back in system variables
4. Changes may trigger further processing or actions

### 7.4 Data Transmission

1. Data to be transmitted is serialized using the Field system
2. Serialized data is written to files or transmitted directly
3. Cross-core communication allows data sharing between processor cores
4. External communication uses appropriate protocols and formats

## 8. Integration Points Between Subsystems

### 8.1 Variable Management and Feature System

- Features are stored as variables with Fid type
- Feature references can be used to access features indirectly
- Features can be absolute or relative to other features

### 8.2 Variable Management and Field System

- Fields can serialize/deserialize variables
- Field sets can represent collections of related variables
- Field vectors can represent arrays of variable collections

### 8.3 Field System and File System

- Fields are serialized to binary data
- Binary data is stored in files
- Files are managed by the memory-based file system

### 8.4 File System and Cross-Core Communication

- Files can be accessed from different processor cores
- Cross-core file operations use shared memory buffers
- Synchronization ensures data consistency

## 9. Architectural Patterns

The data management architecture employs several architectural patterns:

### 9.1 Singleton Pattern

- Used by `Varmgr` for centralized variable management
- Ensures a single point of access for all system variables
- Provides global access to the variable manager

### 9.2 Adapter Pattern

- Used by `Vardst` to adapt variable references to the sniffer telemetry system
- Adapts `Iset` interface to variable mapping system
- Handles different variable types through templated methods

### 9.3 Proxy Pattern

- Used by `Xcfile` to provide a client-side proxy for file operations
- Implements the `Ifile` interface for client applications
- Delegates operations to the service-side implementation

### 9.4 Factory Method Pattern

- Used by `FMCPmgr` to create and select appropriate processors
- Returns the appropriate processor based on message type
- Provides a consistent interface for processor creation

### 9.5 Null Object Pattern

- Used by `FMCP_null` to provide a safe default implementation
- Implements the `IFMCP` interface with no-op methods
- Returned when an invalid processor type is requested

## 10. Conclusion: Unified Data Management Approach

The system implements a comprehensive and unified approach to data management, with several key characteristics:

1. **Centralized Variable Management**: All system variables are managed through a central Variable Manager, providing consistent access patterns and cross-core synchronization.

2. **Specialized Representations**: Different data types have specialized representations (e.g., Features for spatial data) that capture their unique characteristics and relationships.

3. **Flexible Serialization**: The Field system provides a flexible framework for data serialization and deserialization, supporting various data types and formats.

4. **Efficient Storage**: Data is stored efficiently using specialized containers and memory management strategies, with support for both in-memory and file-based storage.

5. **Cross-Core Communication**: Data can be shared between processor cores through shared memory variables and cross-core file operations.

6. **Asynchronous Operations**: Time-consuming operations are implemented asynchronously, allowing the system to remain responsive while processing data.

7. **Type Safety and Validation**: Strong typing and validation ensure data integrity and correctness throughout the system.

This unified approach enables efficient and reliable data management across the system, supporting the complex requirements of real-time operation and cross-core communication.