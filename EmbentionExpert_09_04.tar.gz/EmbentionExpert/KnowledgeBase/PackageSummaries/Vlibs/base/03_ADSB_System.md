# Generated from:

- code/include/ADSB_cfg.h (1909 tokens)
- code/include/ADSB_Mavlink.h (2006 tokens)
- code/include/ADSB_Sagetech.h (504 tokens)
- code/include/ADSB_Vars.h (1467 tokens)
- code/source/ADSB_cfg.cpp (1931 tokens)

---

# ADS-B System Comprehensive Summary

## 1. System Overview

The ADS-B (Automatic Dependent Surveillance-Broadcast) system is an aircraft surveillance technology that enables aircraft to broadcast their identification, position, altitude, velocity, and other information to ground stations and other aircraft. The codebase implements a flexible ADS-B system supporting multiple transponder models and protocols, with both ADS-B OUT (transmission) and ADS-B IN (reception) capabilities.

## 2. Configuration Components

### 2.1 Static Configuration (`ADSB_cfg::Static_cfg`)

The static configuration represents setup parameters that typically don't change during operation:

```cpp
struct Static_cfg: public Ideserializable {
    Trspd_model model;                      // Transponder type
    Uint16 cm_id;                           // Producer/Consumer Custom Message ID (0xFFFF=none)
    Uint16 init_mode;                       // Initial mode
    Uint32 icao;                            // ICAO identifier
    Uint16 em_type;                         // Mavlink's Emitter type
    ADSB_Mavlink::Callsign_arr callsign;    // Callsign CHAR[8]
    Uint16 custom;                          // Custom value for specific usages
};
```

Key fields:
- `model`: Specifies the transponder hardware model
- `init_mode`: Initial control mode (RX/TX settings)
- `icao`: 24-bit unique aircraft identifier
- `em_type`: Aircraft/emitter category
- `callsign`: 8-character aircraft identifier (e.g., tail number, flight number)

The static configuration is deserialized from a PDI (Parameter Data Item Configuration) and is initialized once during system startup.

### 2.2 Dynamic Configuration (`ADSB_cfg::Dynamic_cfg`)

The dynamic configuration represents operational parameters that can change during flight:

```cpp
struct Dynamic_cfg: public Ideserializable {
    bool has_changed;                       // Used to detect changes
    Uint16 ctrl;                            // Control mode (RX/TX etc.)
    Uint16 squawk;                          // Squawk code
    Uint16 is_ident;                        // Ident enable
    Uint16 custom;                          // Custom value for specific usages
};
```

Key fields:
- `ctrl`: Control mode that determines if reception (ADS-B IN) and/or transmission (ADS-B OUT) are enabled
- `squawk`: 4-digit octal transponder code (used by ATC)
- `is_ident`: Flag to enable identification mode (makes aircraft stand out on ATC screens)

The dynamic configuration can be updated during operation, and changes are detected via the `has_changed` flag.

## 3. Transponder Models

The system supports multiple transponder models through the `Trspd_model` enumeration:

```cpp
enum Trspd_model {
    tr_none,        // No transponder configured
    tr_internal,    // Internal Transponder (extended TT-SC1A)
    tr_png_s20,     // uAvionix Ping S20 (GDL90 protocol)
    tr_png_1090,    // uAvionix Ping 1090 (Mavlink protocol)
    tr_sag_mx,      // Sagetech MX Series (Sagetech MX proprietary protocol)
    tr_sag_xpstr,   // Sagetech XPS-TR (Sagetech XP proprietary protocol)
    tr_sag_xpgtr,   // Sagetech XPG-TR (Sagetech XP proprietary protocol)
    tr_sag_xpstrb,  // Sagetech XPS-TRB (Sagetech XP proprietary protocol)
    tr_daedalean,   // Daedalean ADS-B IN like (Vision computing, proprietary protocol)
    tr_remoteid,    // Internal RemoteID
    tr_aer_tt,      // Aerobits TT-series (Mavlink protocol)
    tr_aer_tr       // Aerobits TR-series (Mavlink protocol)
};
```

The system determines if a transponder is "internal" (directly integrated) using the `is_internal()` method, which checks if the type is either `tr_internal` or `tr_remoteid`.

## 4. Protocol Support

### 4.1 MAVLink Protocol

The system implements the MAVLink protocol for ADS-B communication, defined in `ADSB_Mavlink.h`:

- Frame structure:
  - Header (6 bytes)
  - Payload (38 bytes)
  - CRC (2 bytes)
  - Total size: 46 bytes

- Key constants:
  - `mav_hdr_start = 0xFE`: Header start byte
  - `mav_vhc_id = 0xF6`: MAVLink-1 ADSB-IN vehicle report message identifier
  - `mav_crc_ex = 0xB8`: Extra byte for MAVLink CRC computation

- Conversion factors:
  - `conv_dege7_to_rad = (1.0E-7L) * Kr64::DEG2RAD`: Converts from deg^-7 to radians
  - `conv_heading = Const::CM2M * Const::DEG2RAD`: Converts from deg^-2 to radians
  - `conv_cvel = Const::CM2M`: Converts from cm/s to m/s

- Field positions are defined in the `Position` enumeration, specifying the byte offsets for each field in the MAVLink frame

- Flag structure (`Mav_flags`):
  ```cpp
  union Mav_flags {
      Uint16 valid_all;               // Variable for all flags
      struct {
          Uint16 valid_coords:1;      // [0]  ADSB_FLAGS_VALID_COORDS
          Uint16 valid_alt:1;         // [1]  ADSB_FLAGS_VALID_ALTITUDE
          Uint16 valid_heading:1;     // [2]  ADSB_FLAGS_VALID_HEADING
          Uint16 valid_velocity:1;    // [3]  ADSB_FLAGS_VALID_VELOCITY
          Uint16 valid_callsign:1;    // [4]  ADSB_FLAGS_VALID_CALLSIGN
          Uint16 valid_ident:1;       // [5]  ADSB_FLAGS_VALID_SQUAWK
          Uint16 simulated:1;         // [6]  ADSB_FLAGS_SIMULATED
          Uint16 valid_vvel:1;        // [7]  ADSB_FLAGS_VALID_VERTICAL_VELOCITY
          Uint16 valid_baro:1;        // [8]  ADSB_FLAGS_VALID_BARO
          Uint16 source_uat:1;        // [9]  ADSB_SOURCE_UAT
      };
  };
  ```

### 4.2 Sagetech Protocol

The system also supports Sagetech transponders with their proprietary protocol, defined in `ADSB_Sagetech.h`:

- Conversion factors:
  - `conv_pos_215em7 = 0.000021457672119140625f * Const::DEG2RAD`: Converts from 24-bits position to radians
  - `conv_alt_ft = 0.015625f * Const::FT2M`: Converts from 24-bits 2's complement altitude to meters
  - `conv_vvl_ft = 0.0166667f * Const::FT2M`: Converts from 16-bits 2's complement vertical rate to m/s
  - `conv_hvl_knt = 0.125f * Const::kn2ms`: Converts from 16-bits 2's complement horizontal rate to m/s

- Flag structure (`Sag_flags`):
  ```cpp
  union Sag_flags {
      Uint16 valid_all;
      struct {
          Uint16 reserved0:     6;  // [0:5]
          Uint16 estm_hvel:     1;  // [6]      : Estimated N/S and E/W Velocity
          Uint16 estm_pos :     1;  // [7]      : Estimated Latitude and Longitude
          Uint16 bar_vvel :     1;  // [8]      : Vertical Rate, Barometric
          Uint16 geo_vvel :     1;  // [9]      : Vertical Rate, Geometric
          Uint16 bar_alt  :     1;  // [10]     : Altitude, Barometric
          Uint16 heading  :     1;  // [11]     : Heading while on the Surface
          Uint16 gnd_vel  :     1;  // [12]     : Ground Speed while on Surface
          Uint16 geo_hvel :     1;  // [13]     : N/S and E/W Velocity
          Uint16 geo_alt  :     1;  // [14]     : Altitude, Geometric
          Uint16 geo_pos  :     1;  // [15]     : Latitude and Longitude
      };
  };
  ```

## 5. System Variables Integration

### 5.1 ADS-B System Variables

The system uses a set of system variables to store and process ADS-B data, defined in `ADSB_Vars.h`:

```cpp
enum Uvar_adsb {
    // Variables used for ADS-B vehicle parsing
    mobs_id16         = 1000,         // Used for messages with Id of 16bits
    mobs_icao32       = 1001,         // ICAO address Uint32
    mobs_lat32_e7     = 1002,         // Latitude as a Uint32 (DegE7)
    mobs_lon32_e7     = 1003,         // Longitude as a Uint32 (DegE7)
    mobs_alt32_mm     = 1004,         // Altitude as a Uint32 (mm)
    mobs_heading_e2   = 1005,         // Heading (DegE2)
    mobs_hor_vel_mm_s = 1006,         // Horizontal velocity (mm/s)
    mobs_ver_vel_mm_s = 1007,         // Vertical velocity (mm/s)
    mobs_callsign_0   = 1008,         // Callsign bytes [0,1]
    // ... additional variables ...
    mobs_adsb_none    = 1032          // Undefined, shall not be used
};
```

### 5.2 ADS-B OUT Variables

The `ADSB_out_vars` structure defines references to system variables used for ADS-B OUT transmission:

```cpp
struct ADSB_out_vars {
    // Specific to UAV
    const volatile bool& pos_fixed;      // GPS Position fixed
    const volatile Real& uav_hdg;        // UAV heading
    const volatile Real& uav_gs;         // UAV ground speed
    const volatile Real& uav_vdwn;       // UAV down speed
    const Fid uav_fid;                   // UAV feature identifier

    // Specific to ADS-B configuration
    const volatile Uint16& type;         // Transponder type
    const volatile Uint16& ctrl;         // Transponder control mode
    const volatile Uint16& icao_h;       // ICAO high part
    const volatile Uint16& icao_l;       // ICAO low part
    const volatile Uint16& calls0;       // Callsign character 0
    // ... additional variables ...
    const volatile Uint16& squawk;       // Squawk code

    // Specific to RemoteID
    const volatile Real& agl;            // AGL
    const volatile Real& tow_ms;         // GNSS Time of week (in milliseconds)
    const volatile int16& week;          // GNSS week

    // Enable bit (useful in case of AP onto 4X)
    const volatile bool& enable;
};
```

## 6. Data Flow and Processing

### 6.1 Configuration Flow

1. The system initializes with the `ADSB_cfg` class, which manages both static and dynamic configurations.
2. On first execution of the `step()` method, static configuration is applied to system variables via `set_static_vars()`.
3. When dynamic configuration changes (detected via `has_changed` flag), the changes are applied to system variables via `set_dynamic_vars()`.

```cpp
void ADSB_cfg::step() {
    if(static_cfg.model != tr_none) {
        // Setup system variables for static configuration
        if(!is_first) {
            set_static_vars();
            is_first = true;
            dynamic_cfg.has_changed = false;
        }

        if(dynamic_cfg.has_changed) {
            set_dynamic_vars();
            dynamic_cfg.has_changed = false;
        }
    }
}
```

### 6.2 ADS-B OUT Processing

For ADS-B OUT, the system:
1. Retrieves aircraft data (position, velocity, altitude) from system variables
2. Formats this data according to the selected protocol (MAVLink, Sagetech, etc.)
3. Transmits the formatted data via the configured transponder

The control mode (`ctrl`) determines if transmission is enabled:
```cpp
inline bool ADSB_cfg::is_tx_on(Uint16 ctrl0) {
    return ((Bitutils::get_u16_h(ctrl0) & 2U) != 0);
}
```

### 6.3 ADS-B IN Processing

For ADS-B IN, the system:
1. Receives ADS-B messages from other aircraft
2. Parses the messages according to the protocol
3. Stores the extracted data in system variables for use by other system components

The control mode (`ctrl`) determines if reception is enabled:
```cpp
inline bool ADSB_cfg::is_rx_on(Uint16 ctrl0) {
    return ((Bitutils::get_u16_h(ctrl0) & 1U) != 0);
}
```

## 7. Emitter Types

The system supports various aircraft/emitter types through the `Emitter_type` enumeration:

```cpp
enum Emitter_type {
    et_undefined         = 0x00,    // Unspecified powered aircraft
    et_light             = 0x01,    // Light (<15500 lbs)
    et_small             = 0x02,    // Small (from 15500 to 75000 lbs)
    et_large             = 0x03,    // Large (from 75000 to 300000 lbs)
    et_high_vortex_large = 0x04,    // High Vortex Large (such as B-757)
    et_heavy             = 0x05,    // Heavy (>300000 lbs)
    et_highly_maeuv      = 0x06,    // High performance (>5g of acceleration and >400 knots)
    et_rotorcraft        = 0x07,    // Rotorcraft
    et_unassigned1       = 0x08,    // Unspecified unpowered aircraft or UAV or spacecraft
    et_glider            = 0x09,    // Glider/sailplane
    et_lighter_air       = 0x0A,    // Ligther than air
    et_parachute         = 0x0B,    // Parachutist/Skydiver
    et_ultra_light       = 0x0C,    // Ultralight/hang-glider/paraglider
    et_unassigned2       = 0x0D,    // Reserved
    et_uav               = 0x0E,    // Unmanned Aerial Vehicle
    et_space             = 0x0F,    // Space/Trans-atmospheric vehicle
    et_unassigned3       = 0x10,    // Unspecified ground installation or vehicle
    et_emergency_surface = 0x11,    // Surface Vehicle / Emergency Vehicle
    et_service_surface   = 0x12,    // Surface Vehicle / Service Vehicle
    et_point_obstacle    = 0x13     // Fixed Ground or Tethered Obstruction
};
```

## 8. Data Conversion and Processing

### 8.1 Coordinate Conversion

The system uses various conversion factors to transform between different coordinate systems and units:

- For MAVLink:
  - Position: Degrees * 10^7 → Radians
  - Velocity: cm/s → m/s
  - Heading: Degrees * 10^2 → Radians

- For Sagetech:
  - Position: 24-bit value (resolution of 180/2^23 degrees) → Radians
  - Altitude: 24-bit value (resolution of 0.015625 feet) → Meters
  - Vertical rate: 16-bit value (feet/minute) → Meters/second
  - Horizontal rate: 16-bit value (resolution of 0.125 knots) → Meters/second

### 8.2 Data Validation

Both protocols use flag structures to indicate the validity of different data fields:

- MAVLink uses `Mav_flags` with bits for coordinates, altitude, heading, velocity, etc.
- Sagetech uses `Sag_flags` with bits for position, altitude, velocity components, etc.

These flags help the system determine which fields in received messages contain valid data.

## 9. Implementation Details

### 9.1 Class Structure

- `ADSB_cfg`: Main configuration class that manages both static and dynamic configurations
  - `Static_cfg`: Structure for static (setup) configuration
  - `Dynamic_cfg`: Structure for dynamic (operational) configuration

- `ADSB_Mavlink`: Namespace containing MAVLink protocol definitions
- `ADSB_Sagetech`: Namespace containing Sagetech protocol definitions
- `ADSB_Vars`: Namespace containing system variable definitions

### 9.2 Key Methods

- `ADSB_cfg::step()`: Main processing method that applies configuration changes
- `ADSB_cfg::set_static_vars()`: Applies static configuration to system variables
- `ADSB_cfg::set_dynamic_vars()`: Applies dynamic configuration to system variables
- `ADSB_cfg::is_internal()`: Checks if a transponder type is internal
- `ADSB_cfg::is_rx_on()`: Checks if reception is enabled
- `ADSB_cfg::is_tx_on()`: Checks if transmission is enabled

### 9.3 Configuration Deserialization

Both static and dynamic configurations are deserialized from PDI (Parameter Data Item Configuration):

```cpp
void ADSB_cfg::Static_cfg::cset(Lossy_error& str) {
    str.get_enum16(model);
    str.get_uint16(init_mode);
    str.get_uint16(cm_id);
    str.get_uint32(icao);
    str.get_uint16(em_type);
    U8pkmblock mb = callsign.to_mblock8();
    str.get_n_uint8(mb);
    str.get_uint16(custom);
}

void ADSB_cfg::Dynamic_cfg::cset(Lossy_error& str) {
    has_changed = true;
    str.get_enum16(ctrl);
    str.get_uint16(squawk);
    str.get_uint16(is_ident);
    str.get_uint16(custom);
}
```

## 10. Practical Usage

### 10.1 ADS-B OUT Configuration

To configure ADS-B OUT:

1. Set the static configuration:
   - Select transponder model (`model`)
   - Set ICAO identifier (`icao`)
   - Set aircraft callsign (`callsign`)
   - Set emitter type (`em_type`)
   - Enable transmission in initial mode (`init_mode`)

2. Set the dynamic configuration as needed:
   - Update control mode (`ctrl`) to enable/disable transmission
   - Set squawk code (`squawk`) as assigned by ATC
   - Enable/disable ident mode (`is_ident`) when requested by ATC

### 10.2 ADS-B IN Processing

To process ADS-B IN data:

1. Enable reception in the control mode (`ctrl`)
2. Receive messages from other aircraft
3. Parse messages according to the protocol (MAVLink, Sagetech)
4. Check validity flags to determine which fields contain valid data
5. Convert coordinates, velocities, and altitudes to appropriate units
6. Use the extracted data for collision avoidance, situational awareness, etc.

## 11. System Variables

The system uses various system variables to store and process ADS-B data:

- Configuration variables:
  - `vu_adsbout_type`: Transponder type
  - `vu_adsbout_control`: Control mode
  - `vu_adsbout_icao_h`, `vu_adsbout_icao_l`: ICAO identifier
  - `vu_adsbout_emtype`: Emitter type
  - `vu_adsbout_calls0` through `vu_adsbout_calls7`: Callsign characters
  - `vu_adsbout_squawk`: Squawk code
  - `vu_adsbout_ident`: Ident mode
  - `vu_adsbout_custom`: Custom value

- Aircraft data variables:
  - Position: Latitude, longitude, altitude
  - Velocity: Ground speed, vertical speed
  - Heading
  - AGL (Above Ground Level)
  - GNSS time information

These variables are used to exchange data between different components of the system, such as the ADS-B module, flight controller, and user interface.

## 12. Summary

The ADS-B system provides a comprehensive solution for aircraft surveillance and collision avoidance. It supports multiple transponder models and protocols, with both ADS-B OUT (transmission) and ADS-B IN (reception) capabilities. The system is highly configurable, with separate static and dynamic configurations, and integrates with other system components through system variables.

Key features include:
- Support for multiple transponder models (internal, uAvionix, Sagetech, etc.)
- Support for multiple protocols (MAVLink, Sagetech, GDL90)
- Flexible configuration options
- Comprehensive data validation
- Coordinate and unit conversion
- Integration with system variables

The system is designed to be used in aircraft for surveillance, collision avoidance, and compliance with aviation regulations.