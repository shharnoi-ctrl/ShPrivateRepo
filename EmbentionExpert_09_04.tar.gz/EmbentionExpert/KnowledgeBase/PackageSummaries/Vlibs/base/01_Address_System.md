# Generated from:

- code/include/Address.h (610 tokens)
- code/include/Address0.h (2162 tokens)
- code/include/Address_fw.h (22 tokens)
- code/include/Address_handler_generic.h (732 tokens)
- code/include/Address_tunnel.h (183 tokens)
- code/include/IAddress_handler.h (788 tokens)
- code/source/Address.cpp (tokens unknown)
- code/source/Address0.cpp (tokens unknown)
- code/source/Address_handler_generic.cpp (114 tokens)

---

# Address System Comprehensive Summary

This document provides a high-fidelity extraction of the address system implementation, detailing how addresses are represented, compared, and handled throughout the system.

## 1. Address Representation and Core Structures

### Address0 Structure

`Address0` serves as the foundational structure for representing addresses in the system. It defines the raw address format and basic operations.

```cpp
struct Address0 {
    enum Addr {
        invalid             = 0x00000000UL, // Invalid address
        null                = 0xFF000000UL, // Null address
        cyphal              = 0x00FFFFF0UL, // Cyphal address
        cyphal_broadcast    = 0x00FFFFFFUL, // Cyphal broadcast address
        broadcast           = 0xFFFFFFFFUL  // Broadcast address
    };

    static const Uint32 own_offset = 24;    // Offset to owning data
    typedef Uint32 Id_t;                    // Type for id
    Id_t id;                               // Address id
}
```

Key characteristics:
- Addresses are represented as 32-bit unsigned integers (`Uint32`)
- The most significant byte (bits 24-31) represents the "owning ID"
- The remaining three bytes (bits 0-23) are assigned by the authority associated with the owning ID
- Special address values are defined as enum constants (invalid, null, cyphal, broadcast, etc.)

### Address Class

`Address` extends `Address0` to provide higher-level address functionality:

```cpp
class Address : public Address0 {
public:
    Address();                                  // Default constructor
    explicit Address(const Address0& orig);     // Copy constructor from Address0
    explicit Address(const volatile Address0& orig); // Volatile copy constructor
    explicit Address(Id_t id0);                 // Constructor with given ID
    
    bool is_broadcast() const;                  // Check if address is broadcast
    bool is_null() const;                       // Check if address is null
};
```

The `Address` class provides:
- Multiple constructors for different initialization scenarios
- Methods to check for special address types (broadcast, null)
- Inherits all comparison and serialization capabilities from `Address0`

## 2. Address Comparison and Operations

### Equality and Inequality Operations

`Address0` provides comprehensive comparison operations:

```cpp
bool operator==(const Address0& other) const;
bool operator==(const volatile Address0& other) const;
bool operator==(Addr other) const volatile;
bool operator!=(const Address0& other) const;
```

Implementation details:
- Equality comparison simply checks if the internal `id` values match
- Inequality is implemented as the negation of equality
- Special overloads handle volatile addresses and enum constant comparisons

### Address Building and Manipulation

`Address0` provides static factory methods for creating addresses:

```cpp
static Address0 build_default();       // Creates address with null ID
static Address0 build_invalid();       // Creates address with invalid ID
static Address0 build(Id_t id0);       // Creates address with specified ID
```

Additional manipulation methods:
- `void set(const Address0& other) volatile;` - Sets address to match another address
- `Uint8 get_owning() volatile;` - Extracts the owning part of the address (most significant byte)

## 3. Address Serialization and Deserialization

`Address0` supports multiple serialization formats:

### Binary Serialization with Lossy

```cpp
void cset(Lossy& str);                // Deserialize from Lossy stream
void cget(Lossy& str) const;          // Serialize to Lossy stream
void cset(Lossy& str) volatile;       // Volatile deserialize
void cget(Lossy& str) const volatile; // Volatile serialize
```

### Big-Endian Serialization

```cpp
void cget(U8ostream& os) const;       // Serialize to U8ostream in big-endian
void cset(U8istream& is);             // Deserialize from U8istream in big-endian
void cget(U8ostream& os) const volatile; // Volatile serialize in big-endian
void cset(U8istream& is) volatile;    // Volatile deserialize in big-endian
```

### Little-Endian Serialization

```cpp
void cget(U16stream_w& os) const;     // Serialize to U16stream_w in little-endian
void cset(U16stream_r& is);           // Deserialize from U16stream_r in little-endian
```

Implementation details:
- All serialization methods handle the 32-bit address ID as a single unit
- Big-endian serialization uses explicit big-endian conversion methods
- Little-endian serialization assumes the native memory configuration is little-endian

## 4. Address Handler Interface and Implementations

### IAddress_handler Interface

`IAddress_handler` defines the interface for address handling components:

```cpp
class IAddress_handler {
public:
    virtual ~IAddress_handler();
    virtual bool from_me(Base::Espkt& epkt) const = 0;
    virtual bool to_me(Base::Espkt& epkt) const = 0;

protected:
    IAddress_handler(const volatile Base::Address0& own_address0);
    static Uint8 get_espkt_core(const Base::Espkt& epkt);
    
    const volatile Address0& own_address; // Own address
};
```

Key responsibilities:
- Provides a common interface for address handling
- Stores a reference to the system's own address
- Defines pure virtual methods for checking if a packet is from or to the current system
- Provides a utility method to extract the core data from an Embention STANAG packet

### Address_handler_generic Implementation

`Address_handler_generic` implements the `IAddress_handler` interface for general address handling:

```cpp
class Address_handler_generic : public Base::IAddress_handler {
public:
    Address_handler_generic(const volatile Base::Address0& own_address0);
    static Address_handler_generic& get_instance();
    
    virtual bool from_me(Base::Espkt& epkt) const;
    virtual bool to_me(Base::Espkt& epkt) const;
};
```

Implementation details:
- `from_me()` checks if the packet's source address matches the system's own address
- `to_me()` checks if the packet's destination address matches the system's own address
- `get_instance()` provides a singleton instance using the system address from `Bsp::sysaddr()`

### Address_tunnel Implementation

`Address_tunnel` implements the `IAddress_handler` interface for tunnel-specific address handling:

```cpp
class Address_tunnel : public Base::IAddress_handler {
public:
    Address_tunnel(const volatile Base::Address0& own_address0);
    
    virtual bool from_me(Base::Espkt& epkt) const;
    virtual bool to_me(Base::Espkt& epkt) const;
};
```

Implementation details:
- `from_me()` checks if the packet's source address matches the system's own address
- `to_me()` always returns false, indicating that tunneled packets are never considered as directly addressed to this system

## 5. Special Address Types and Handling

### Broadcast Addresses

The system defines broadcast addresses and provides methods to identify them:

```cpp
// In Address0 enum
broadcast = 0xFFFFFFFFUL  // Broadcast address
cyphal_broadcast = 0x00FFFFFFUL // Cyphal broadcast address

// In Address class
bool is_broadcast() const {
    return id == broadcast;
}
```

Broadcast addresses are used for messages intended for all recipients in the network.

### Null Addresses

Null addresses are defined and can be checked:

```cpp
// In Address0 enum
null = 0xFF000000UL // Null address

// In Address class
bool is_null() const {
    return id == null;
}
```

Null addresses represent the absence of a valid address and are used as default values.

### Invalid Addresses

The system defines an invalid address constant:

```cpp
// In Address0 enum
invalid = 0x00000000UL // Invalid address

// Static method to create invalid addresses
static Address0 build_invalid() {
    Address0 res = { static_cast<Id_t>(invalid) };
    return res;
}
```

Invalid addresses are used to represent error conditions or uninitialized addresses.

## 6. Address Usage in Packet Routing

### Packet Address Checking

The address handlers provide methods to check packet routing:

```cpp
// In Address_handler_generic
bool from_me(Base::Espkt& epkt) const {
    return epkt.get_src_address() == own_address;
}

bool to_me(Base::Espkt& epkt) const {
    return epkt.get_dst_address() == own_address;
}
```

These methods are used to determine:
- If the current system is the source of a packet (`from_me`)
- If the current system is the intended recipient of a packet (`to_me`)

### Packet Core Data Extraction

The `IAddress_handler` provides a utility method to extract core data from packets:

```cpp
static Uint8 get_espkt_core(const Base::Espkt& epkt) {
    Base::U8istream is(epkt.get_as_spkt().get_payload());
    const Uint8 cmd = is.get_uint8();
    return is.get_uint8();
}
```

This method:
1. Gets the STANAG packet payload
2. Creates a stream to read from the payload
3. Reads the command byte
4. Returns the next byte (core data)

## 7. System Address Management

### System Address Singleton

The system provides a singleton instance of the address handler:

```cpp
// In Address_handler_generic
static Address_handler_generic& get_instance() {
    static Address_handler_generic ret(Bsp::sysaddr());
    return ret;
}
```

This singleton:
- Is initialized with the system address from `Bsp::sysaddr()`
- Provides a global access point for address handling functionality
- Ensures consistent address handling throughout the system

## 8. Address Structure and Format

### Address Format

Addresses follow the STANAG format:
- 32-bit unsigned integer
- Most significant byte (bits 24-31): owning ID
- Remaining three bytes (bits 0-23): assigned by the authority associated with the owning ID

```
+---------------+------------------------+
| Owning ID     | Authority-assigned ID  |
| (8 bits)      | (24 bits)              |
+---------------+------------------------+
```

This format allows for hierarchical addressing with a clear ownership structure.

## 9. File-by-File Breakdown

### Address.h

Defines the `Address` class that extends `Address0` with additional functionality:
- Constructors for different initialization scenarios
- Methods to check for special address types (broadcast, null)
- Inline implementations of all methods

### Address0.h

Defines the foundational `Address0` structure:
- Core address representation as a 32-bit ID
- Special address constants (invalid, null, broadcast, etc.)
- Comparison operators
- Serialization and deserialization methods
- Static factory methods for creating addresses
- Methods for address manipulation

### Address_fw.h

A forward declaration file that simply declares the `Address` class in the `Base` namespace.

### Address_handler_generic.h

Defines the `Address_handler_generic` class:
- Implementation of the `IAddress_handler` interface
- Methods for checking if packets are from or to the current system
- Singleton instance accessor

### Address_tunnel.h

Defines the `Address_tunnel` class:
- Implementation of the `IAddress_handler` interface for tunnel-specific handling
- Modified behavior where `to_me` always returns false

### IAddress_handler.h

Defines the `IAddress_handler` interface:
- Pure virtual methods for address checking
- Protected constructor and member variable for the system's own address
- Utility method for packet core data extraction

### Address_handler_generic.cpp

Implements the singleton accessor for `Address_handler_generic`:
- Creates a static instance using the system address
- Returns a reference to this instance

## 10. Cross-Component Relationships

### Inheritance Relationships

```
Address0 (base structure)
  ↑
Address (extends with additional functionality)

IAddress_handler (interface)
  ↑
Address_handler_generic (general implementation)
  
IAddress_handler (interface)
  ↑
Address_tunnel (tunnel-specific implementation)
```

### Dependency Relationships

- `Address` depends on `Address0` for core functionality
- `IAddress_handler` depends on `Address0` for address representation
- `Address_handler_generic` depends on `IAddress_handler` for interface definition
- `Address_tunnel` depends on `IAddress_handler` for interface definition
- `Address_handler_generic` depends on `Sysaddr` for system address retrieval
- All address handlers depend on `Espkt` for packet handling

## 11. Practical Usage Patterns

### Address Creation and Comparison

```cpp
// Create addresses
Address addr1;                      // Default address (null)
Address addr2(0x12345678);          // Address with specific ID
Address addr3(existingAddress0);    // Copy from Address0

// Compare addresses
if (addr1 == addr2) { /* ... */ }   // Direct comparison
if (addr1.is_null()) { /* ... */ }  // Check for null
if (addr2.is_broadcast()) { /* ... */ } // Check for broadcast
```

### Packet Routing

```cpp
// Get the singleton address handler
Address_handler_generic& handler = Address_handler_generic::get_instance();

// Check if packet is from this system
if (handler.from_me(packet)) {
    // Handle outgoing packet
}

// Check if packet is addressed to this system
if (handler.to_me(packet)) {
    // Process incoming packet
}
```

### Address Serialization

```cpp
// Serialize address to binary stream
U8ostream stream;
address.cget(stream);  // Writes address in big-endian format

// Deserialize address from binary stream
U8istream stream;
address.cset(stream);  // Reads address in big-endian format
```

## 12. Error Handling and Edge Cases

### Invalid Addresses

The system defines an `invalid` address constant (0x00000000) and provides a method to create invalid addresses:

```cpp
Address0 invalid_addr = Address0::build_invalid();
```

### Null Addresses

Null addresses (0xFF000000) are used as default values and can be checked:

```cpp
Address addr;  // Default constructor creates null address
if (addr.is_null()) {
    // Handle null address case
}
```

### Broadcast Handling

Broadcast addresses (0xFFFFFFFF) are used for messages intended for all recipients:

```cpp
if (addr.is_broadcast()) {
    // Handle broadcast message
}
```

## Summary

The address system provides a comprehensive framework for representing, comparing, and handling addresses throughout the system. It uses a STANAG format with a hierarchical structure, where the most significant byte represents the owning ID and the remaining three bytes are assigned by the associated authority.

The system includes:
- Core address representation (`Address0`)
- Extended address functionality (`Address`)
- Interface for address handling (`IAddress_handler`)
- Generic implementation for standard address handling (`Address_handler_generic`)
- Specialized implementation for tunnel address handling (`Address_tunnel`)

Special address types (broadcast, null, invalid) are defined and can be checked using dedicated methods. The system provides comprehensive serialization and deserialization capabilities for different formats and endianness.

Address handlers are used for packet routing, determining if packets are from or to the current system. A singleton instance of the address handler provides consistent address handling throughout the system.