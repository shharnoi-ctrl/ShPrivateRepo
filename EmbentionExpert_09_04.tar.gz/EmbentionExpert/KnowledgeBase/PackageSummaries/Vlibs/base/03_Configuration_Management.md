# Generated from:

- code/include/Cfg.h (10571 tokens)
- code/include/Cfg_utils.h (144 tokens)
- code/include/Cfgid_mode.h (397 tokens)
- code/include/Cfgsync.h (1711 tokens)
- code/include/Xcfgmgr.h (1385 tokens)
- code/include/Xcfieldsvec.h (104 tokens)
- code/include/Pfields_cfg.h (845 tokens)
- code/include/Nmeacfg.h (317 tokens)
- code/include/Arcadecfg.h (188 tokens)
- code/include/Channelmgr.h (190 tokens)
- code/include/Channelmgrcfg.h (1176 tokens)
- code/include/Xchannelmgr.h (98 tokens)
- code/include/Internestcfg.h (434 tokens)
- code/include/Iridium_cfg.h (233 tokens)
- code/include/Ussa76excfg.h (385 tokens)
- code/include/Vargpscfg.h (468 tokens)
- code/include/Evactcfg.h (497 tokens)
- code/include/Evactcfg_fw.h (130 tokens)
- code/source/Cfg_utils.cpp (170 tokens)
- code/source/Cfgid_mode.cpp (1075 tokens)
- code/source/Cfgsync.cpp (2015 tokens)
- code/source/Xcfgmgr.cpp (233 tokens)
- code/source/Nmeacfg.cpp (335 tokens)
- code/source/Arcadecfg.cpp (134 tokens)
- code/source/Channelmgr.cpp (1176 tokens)
- code/source/Channelmgrcfg.cpp (1306 tokens)
- code/source/Internestcfg.cpp (751 tokens)
- code/source/Iridium_cfg.cpp (190 tokens)
- code/source/Ussa76excfg.cpp (499 tokens)
- code/source/Vargpscfg.cpp (811 tokens)
- code/source/Evactcfg.cpp (304 tokens)

---

# Configuration Management System in Base Library

This document provides a comprehensive analysis of the configuration management system within the Base library. The system handles how configurations are defined, stored, accessed, synchronized across cores, and tracked for changes.

## 1. Core Configuration Architecture

### 1.1 Configuration Identifier System

The configuration system is built around a comprehensive enumeration of configuration identifiers (`Base::Cfg::Id`) defined in `Cfg.h`. These identifiers serve as unique keys for accessing specific configuration elements:

```cpp
enum Id {
    cfg_cfgmgr            =   0,    // Lock PDIFs
    cfg_gpio              =   1,    // GPIOs function configuration
    cfg_accsuite          =   2,    // Accelerometer Suite
    // ... many more configuration IDs
    cfg_cex_mag0_rot      = 320,    // CEX 1.5 magnetometer board to body
    // ... continues to cfg_all = 512
};
```

The system supports up to 512 different configuration elements (`cfg_all = 512`), organized into logical groups:
- General setup configurations (0-124)
- Meta configurations (125-151)
- Other setup configurations (153-174)
- Command configurations (175-248)
- Calibration setup configurations (249-254)
- Device-specific configurations (CEX, VMC, etc.)

### 1.2 Configuration Access Protocol

The configuration manager supports several operations through the `Config_arg` enum:

```cpp
enum Config_arg {
    cfg_nack_arg     =  1,  // Element does not exist response
    cfg_set_arg      =  2,  // Set configuration for a PDI
    cfg_get_arg      =  3,  // Get configuration for a PDI
    cfg_save_arg     =  4,  // Save tunable to its PDI file
    cfg_load_arg     =  5,  // Load tunable from its PDI file
    cfg_save_op_arg  =  6,  // Save operation tunable data into a temporary file
    cfg_load_op_arg  =  7,  // Load operation tunable data from temporary file
    cfg_query_arg    =  8,  // Query configuration IDs
    cfg_get_sync_arg = 10,  // Get synchronization data (CRC)
    cfg_maxcfg_arg   = 11   // Query maximum number of configurable
};
```

These operations allow for retrieving, modifying, saving, and loading configuration data, as well as querying the system for available configurations.

## 2. Configuration Storage and Serialization

### 2.1 PDI (Parameter Data Interface) Files

Configurations are stored in PDI files, which are serialized representations of configuration data. The system provides utilities for serializing and deserializing configuration data:

```cpp
// Serializing a configuration header
void get_cget_response_header(Cfg::Id id0, Lossy& str_reponse);

// Deserializing configuration data (example from Nmeacfg)
void Nmeacfg::cset(Base::Lossy_error& str) {
    str.get_enum16(id_pos);
    str.get_enum16(id_time);
    str.get_enum16(id_fix);
    str.get_float(timeout);
}
```

Each configuration type implements a `cset` method that deserializes its data from a `Lossy_error` stream, which contains the PDI data.

### 2.2 Configuration Types

The system supports various configuration types, each with specific structures and purposes:

1. **Channel Management Configuration** (`Channelmgrcfg`):
   - Manages cryptographic channels for secure communication
   - Configures encryption types, keys, and channel selection rules

2. **GPS Variable Configuration** (`Vargpscfg`):
   - Configures external GPS variables
   - Manages position, velocity, and timing data

3. **Event-Action Configuration** (`Evactcfg`):
   - Associates events with actions
   - Configures logic, delays, and execution parameters

4. **Internest Configuration** (`Internestcfg`):
   - Configures version, range, and rotation matrix for Internest

5. **NMEA Parser Configuration** (`Nmeacfg`):
   - Configures parsing of NMEA sentences
   - Maps parsed data to system variables

6. **Persistent Fields Configuration** (`Pfields_cfg`):
   - Configures non-volatile fields
   - Maps field types to identifiers

7. **Iridium Configuration** (`Iridium_cfg`):
   - Configures Iridium satellite communication
   - Sets timeouts and destination serials

8. **Atmospheric Model Configuration** (`Ussa76excfg`):
   - Configures USSA76 atmospheric model parameters
   - Sets calibration altitude and temperature

## 3. Configuration Access Control

### 3.1 Mode-Based Access Restrictions

The `Cfgid_mode` class implements a mode-based access control system for configurations:

```cpp
enum Mode {
    none        = 0, // No restrictions to write file
    normal      = 1, // Restriction in normal mode to write
    maintenance = 2, // Restriction in maintenance mode to write
    both        = 3  // Restriction in both mode to write
};
```

Each configuration ID is associated with a mode that determines when it can be modified:

```cpp
bool Cfgid_mode::wr_allowed(const Cfg::Id id0) const volatile {
    static const bool lst_done_err = lst_is_done_err(static_cast<Loadst>(Bsp::Huvar(vu_cfg_loadst).get()));
    const Cfgid_mode::Mode m = (id0 < static_cast<Cfg::Id>(v.size())) ? v[id0] : none;
    bool ret = true;
    switch (m) {
        case none:        { ret = true; break; }
        case normal:      { ret = !lst_done_err; break; }
        case maintenance: { ret = lst_done_err; break; }
        case both:        { ret = false; break; }
    }
    return ret;
}
```

This ensures that certain configurations can only be modified in specific system modes (normal or maintenance).

## 4. Configuration Synchronization

### 4.1 Change Tracking with CRCs

The `Cfgsync` class manages synchronization between in-memory configurations and their on-disk representations:

```cpp
class Cfgsync {
public:
    // Check if a configuration exists
    bool has(Cfg::Id id) const;
    
    // Get file/memory CRCs
    CRC::Tck get_fcrc(Cfg::Id id) const;
    CRC::Tck get_mcrc(Cfg::Id id) const;
    
    // Track modifications
    bool set_modified(Cfg::Id id, const Lossy& str);
    bool set_modified(Cfg::Id id, CRC::Tck crcval);
    bool is_modified(Cfg::Id id) const;
    
    // Synchronize configurations
    bool set_sync(Cfg::Id id, CRC::Tck crcval);
    void sync_all(const bool from_file);
    
    // Other utility methods
    bool add(Cfg::Id id);
    bool is_enabled(Cfg::Id id) const;
    void get_ids(Lossy& str, const Uint16& offset) const;
};
```

The system uses CRCs (Cyclic Redundancy Checks) to track changes between memory and file versions of configurations. When a configuration is modified in memory, its memory CRC is updated. When it's saved to disk, the file CRC is updated to match the memory CRC.

### 4.2 Synchronization States

Each configuration can be in one of two states:
- **Synchronized**: Memory and file CRCs match
- **Modified**: Memory CRC differs from file CRC

The system provides methods to check if a configuration has been modified and to synchronize memory and file versions.

## 5. Cross-Core Configuration Management

### 5.1 Xcfgmgr (Cross-Core Configuration Manager)

The `Xcfgmgr` class manages configuration sharing across multiple processor cores:

```cpp
class Xcfgmgr : public Istep {
public:
    // Add a receiver configuration
    template <typename XCFG, typename RECEIVER>
    void add(typename XCFG::Type_kpodsync& tds0, RECEIVER& rx0);
    
    // Execute all stored configurations
    virtual void step();
    
    // Get singleton instance
    static Xcfgmgr& get_instance();
};
```

This class allows configurations to be shared between cores by:
1. Registering receiver configurations with `add()`
2. Executing those configurations with `step()`

### 5.2 Cross-Core Configuration Types

Several configuration types are designed for cross-core use:

```cpp
typedef Xcfg_des<Nmeacfg> Xcfg_nmea;           // NMEA parser configuration
typedef Xcfg_des<Internestcfg> Xcfg_internest;  // Internest configuration
typedef Xcfg_des<Iridium_cfg> Xcfg_iridium;     // Iridium configuration
typedef Xcfg_des<Ussa76excfg> Xcfg_ussa76ex;    // USSA76 atmospheric model
typedef Xcfg_des<Vargpscfg> Xcfg_vargps;        // GPS variables
typedef Xcfg_des<Channelmgrcfg> Xchannelmgr;    // Channel manager
```

These types use the `Xcfg_des` template to create cross-core compatible configuration structures.

### 5.3 Shared Memory Configuration

The `Xcfieldsvec` template provides a structure for sharing field vectors across cores:

```cpp
template <typename VECDATA, Uint32 poolsz, Uint16 nvecs>
struct Xcfieldsvec {
    Dsync                           sync;
    Xcjarray<Field, poolsz, nvecs>  fields_jarray;
    Tnarray<VECDATA, nvecs>         vdat;
};
```

This structure includes:
- A synchronization mechanism (`sync`)
- A cross-core array of fields (`fields_jarray`)
- An array of vector data (`vdat`)

## 6. Configuration Types in Detail

### 6.1 Channel Manager Configuration

The `Channelmgrcfg` structure configures secure communication channels:

```cpp
struct Channelmgrcfg {
    // Channel configuration (encryption type, key, etc.)
    struct Chncfg {
        Cryptype type;                  // Cryptographic type
        Uint8 times;                    // Number of encryptions
        Uint32 random;                  // Random value
        U8pkrszarray<max_keysz> key;    // Key array
        void cset(Lossy_error& str);
    };
    
    // Channel selection (source/destination addresses)
    struct Chnsel {
        Address0 srcval;    // Source Address
        Address0 dstval;    // Destination Address
        Address0 srcmsk;    // Mask for source Address
        Address0 dstmsk;    // Mask for destination Address
        Uint8 CfgIndex;     // Configuration index
        bool match(const Spkt_hdr& header) const volatile;
        void cset(Lossy_error& str);
    };
    
    Arraymsk<Chncfg,max_configs> configs;   // Channel configurations
    Arraymsk<Chnsel,max_channels> channels; // Channel selections
    void cset(Lossy_error& str);
};
```

The `Channelmgr` class uses this configuration to process packets:

```cpp
class Channelmgr {
public:
    enum Proc_dir { outDir = 0, inDir = 1 };
    bool process(Spkt& pkt, Proc_dir dir) const;
    void config(const Channelmgrcfg& cfg0);
};
```

### 6.2 Event-Action Configuration

The `Evactcfg0` structure associates events with actions:

```cpp
struct Evactcfg0 {
    bool enabled;                   // Enable/disable this automation
    Real delay;                     // Delay after logic detection
    Uint16 max_delayed;             // Limit for pending delayed actions
    Xclkcfg config_xclk;            // Clock configuration
    Flogic nodes;                   // Logic applied to events
    Tnuarray<evact_actsz> actions;  // Action IDs to execute
    
    bool compute_logic(const Eventresult& e) const volatile;
    void cset(Lossy_error& str);
};
```

The system supports up to 100 event-action associations:

```cpp
static const Uint16 evact_sz = 100;
typedef Arraymsk<Evactcfg0, evact_sz> Evactcfg;
typedef Xcfg_des<Evactcfg, Tuntraits::Tunarraymsk<Evactcfg0, evact_sz>> Xevact;
```

### 6.3 GPS Variables Configuration

The `Vargpscfg` structure configures external GPS variables:

```cpp
struct Vargpscfg {
    Real period;      // Configured period (seconds)
    
    Bvar fix;         // True if fix
    Rvar tow;         // Time of week
    Rvar week;        // Week
    
    Fid fid;          // Feature ID for GPS position
    Vref hpe;         // Horizontal position error
    Vref vpe;         // Vertical position error
    
    Rvar vn;          // North velocity
    Rvar ve;          // East velocity
    Rvar vd;          // Down velocity
    Vref hve;         // Horizontal velocity error
    Vref vve;         // Vertical velocity error
    
    bool pos_enabled; // Enable position data
    bool vel_enabled; // Enable velocity data
    
    void init();
    void cset(Base::Lossy_error& str);
};
```

## 7. Configuration Usage Patterns

### 7.1 Configuration Lifecycle

The typical lifecycle of a configuration is:

1. **Definition**: Configuration structure is defined with appropriate fields
2. **Initialization**: Default values are set with `init()`
3. **Deserialization**: Configuration is loaded from PDI with `cset()`
4. **Usage**: Configuration is used by system components
5. **Modification**: Configuration is modified in memory
6. **Synchronization**: Changes are tracked with CRCs
7. **Persistence**: Configuration is saved back to PDI

### 7.2 Cross-Core Configuration Flow

When configurations need to be shared across cores:

1. Configuration is defined as a cross-core type (`Xcfg_des<T>`)
2. Receiver is registered with `Xcfgmgr::add()`
3. `Xcfgmgr::step()` is called periodically
4. When configuration changes, it's read from shared memory
5. Receiver's `config()` method is called with the new configuration

## 8. Security and Integrity

### 8.1 Access Control

The system implements access control through:
- Mode-based restrictions (`Cfgid_mode`)
- CRC validation for integrity checking
- Encryption for secure communication channels

### 8.2 Error Handling

Configuration errors are handled through:
- Assertions in `cset()` methods
- Error codes in `Lossy_error`
- CRC validation for detecting corruption

## 9. Configuration Types Summary

| Configuration Type | Purpose | Key Features |
|-------------------|---------|-------------|
| `Channelmgrcfg` | Secure communication | Encryption types, keys, channel selection |
| `Evactcfg` | Event-action associations | Logic, delays, action IDs |
| `Vargpscfg` | GPS variables | Position, velocity, timing data |
| `Internestcfg` | Internest configuration | Version, range, rotation matrix |
| `Nmeacfg` | NMEA parsing | Position, time, fix variables |
| `Pfields_cfg` | Persistent fields | Field types and IDs |
| `Iridium_cfg` | Satellite communication | Timeouts, destination serials |
| `Ussa76excfg` | Atmospheric model | Calibration parameters |
| `Arcadecfg` | Arcade channel | Gain, dead band, stick zero |

## Conclusion

The configuration management system in the Base library provides a comprehensive framework for defining, storing, accessing, and synchronizing configuration data across the system. It supports a wide range of configuration types, implements access control and integrity checking, and facilitates cross-core configuration sharing. The system's design allows for efficient management of hundreds of different configuration elements while maintaining security and consistency.