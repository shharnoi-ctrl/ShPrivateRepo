# Generated from:

- code/include/Telemetry.h (1745 tokens)
- code/include/Ftelemetry.h (148 tokens)
- code/include/Ftelemetryc.h (128 tokens)
- code/include/Ftelemetryod.h (1414 tokens)
- code/include/Datalink_buffer.h (2262 tokens)
- code/include/Datalink_receiver.h (768 tokens)
- code/include/Datalink_transmitter.h (1019 tokens)
- code/include/Apos_data.h (1767 tokens)
- code/include/Apos_data_fw.h (24 tokens)
- code/include/Mobs_data.h (1570 tokens)
- code/include/Msg_data.h (1355 tokens)
- code/include/Tmovdat.h (914 tokens)
- code/include/Tmvdat.h (843 tokens)
- code/source/Ftelemetryod.cpp (4043 tokens)
- code/source/Datalink_buffer.cpp (1764 tokens)
- code/source/Datalink_receiver.cpp (860 tokens)
- code/source/Datalink_transmitter.cpp (1421 tokens)
- code/source/Apos_data.cpp (80 tokens)
- code/source/Mobs_data.cpp (1882 tokens)
- code/source/Msg_data.cpp (993 tokens)
- code/source/Tmovdat.cpp (317 tokens)
- code/source/Tmvdat.cpp (614 tokens)

---

# Comprehensive Telemetry System Summary

## 1. Telemetry System Architecture Overview

The telemetry system provides a robust framework for transmitting various types of monitoring data from the system to destination addresses. It supports three distinct telemetry types, each with specific characteristics and use cases:

1. **Nominal Telemetry (`Ftelemetry`)**: The primary telemetry system supporting up to 600 fields shared across up to 4 vectors.
2. **Complementary Telemetry (`Ftelemetryc`)**: Secondary telemetry supporting up to 150 fields for a single vector.
3. **On-demand Telemetry (`Ftelemetryod`)**: Special-purpose telemetry supporting up to 200 fields shared across up to 10 vectors, with configurable expiration times.

The system is built around a vectorized field structure, where each vector contains a set of data fields and metadata controlling transmission frequency, destination, and other parameters.

## 2. Core Telemetry Components

### 2.1 Base Telemetry Class Template

The `Telemetry<FTM>` class template serves as the foundation for all telemetry types:

```cpp
template <typename FTM>
class Telemetry : public Stanag::Stanag_msg_tx
{
public:
    explicit Telemetry(const typename FTM::Kfsv& fsv0);
    void step(Imsg_sender& res_fifo, Stanag_msg_type::Msg_type mtype);
    virtual bool on_tx(Tx_params& pull_p);
private:
    const typename FTM::Kfsv& fsv;      // Constant reference to the vectorized fieldset
    Array<Chrono> clk;                  // Array of Chrono objects for timing each vector
};
```

Key responsibilities:
- Initializes timing mechanisms for each telemetry vector
- Manages periodic transmission of telemetry data
- Handles the actual data transmission process

### 2.2 Telemetry Vector Data Structures

#### 2.2.1 Basic Telemetry Vector Data (`Tmvdat`)

The `Tmvdat` structure defines the core properties of a telemetry vector:

```cpp
struct Tmvdat
{
    Bvar enable;        // Enabling bit (from system variable)
    Real period;        // 1/frequency
    Address0 address;   // Destination
    Uint32 hash;        // Hash for this vector
    
    bool is_enabled() const;
    Address get_address() const;
    bool check_period(Real time) const;
    void build(const Kfieldset& fset, Lossy_error& str) const;
    Async_sres cset_async(Base::Lossy_error& str, const Kfieldset& kfset, Uint16& curr_idx);
    void cset(Base::Lossy_error& str, const Kfieldset& kfset);
    void cget(Base::Lossy& str) const;
};
```

This structure:
- Controls whether a vector is enabled
- Defines the transmission period (inverse of frequency)
- Specifies the destination address
- Contains a hash value for vector identification
- Provides methods to check if transmission is due based on elapsed time
- Handles serialization and deserialization of vector data

#### 2.2.2 On-demand Telemetry Vector Data (`Tmodvdat`)

The `Tmodvdat` structure extends `Tmvdat` with expiration functionality:

```cpp
struct Tmodvdat
{
    Tmvdat tmdat;       // Telemetry vector data (contains period, address and hash)
    Real lifespan;      // Amount of time until vector data expired
    Real t_end;         // Computed expired time
    
    bool is_enabled() const;
    Address get_address() const;
    bool check_period(Real time) const;
    void build(const Kfieldset& kfset, Lossy_error& str) const;
    Async_sres cset_async(Base::Lossy_error& str, const Kfieldset& kfset, Uint16& curr_idx);
    void cset(Base::Lossy_error& str, const Kfieldset& kfset);
    void cget(Base::Lossy& str) const;
};
```

This structure adds:
- A lifespan parameter defining how long the vector should be active
- A computed end time after which the vector is considered expired
- Modified `is_enabled()` method that checks both the base enable flag and expiration time

### 2.3 Telemetry Type Definitions

#### 2.3.1 Nominal Telemetry

```cpp
static const Uint16 tm_size_600 = 600;
static const Uint16 tm_size_4 = 4;
typedef Fvecdata<Tmvdat, tm_size_600, tm_size_4> Ftelemetry;
```

Nominal telemetry supports up to 600 fields shared across up to 4 vectors.

#### 2.3.2 Complementary Telemetry

```cpp
typedef Fvecdata_async<Tmvdat, Ku16::u150, 1> Ftelemetryc;
```

Complementary telemetry supports up to 150 fields for a single vector.

#### 2.3.3 On-demand Telemetry

```cpp
static const Uint16 size_200 = 200;
static const Uint16 size_10 = 10;
class Ftelemetryod: private Fvecdata_async<Tmodvdat, size_200, size_10>
{
public:
    class Fsvod: public Itunable_async, public Istep
    {
        // Configuration and expiration mechanisms
    };
    
    // Type definitions and constants
};
```

On-demand telemetry supports up to 200 fields shared across up to 10 vectors, with additional configuration for expiration.

## 3. Telemetry Transmission Process

### 3.1 Periodic Transmission

The `Telemetry<FTM>::step` method handles periodic transmission of telemetry data:

```cpp
template <typename FTM>
void Telemetry<FTM>::step(Imsg_sender& res_fifo, Stanag_msg_type::Msg_type mtype)
{
    bool aux = false;
    typename FTM::Kfsv::Reader rd(fsv);
    for (int16 i = rd.size() - 1; (i >= 0) && (!aux); --i)
    {
        Chrono& clki = clk[i];
        const typename FTM::Vecdata& vdat = rd.get_vdat(i);
        if(vdat.is_enabled() && vdat.check_period(clki.toc()))
        {
            Address dst = vdat.get_address();
            if(rd.is_valid())
            {
                res_fifo.send(Base::Msg_data(dst, mtype, static_cast<Uint16>(i)));
                clki.tic();
            }
            else
            {
                aux = true;
            }
        }
    }
}
```

This method:
1. Iterates through all vectors in the fieldset
2. For each enabled vector, checks if it's time to transmit based on the elapsed time
3. If transmission is due, sends a message to the specified destination
4. Resets the timer for that vector
5. Stops processing if any vector is invalid

### 3.2 Data Transmission

The `Telemetry<FTM>::on_tx` method handles the actual data transmission:

```cpp
template <typename FTM>
bool Telemetry<FTM>::on_tx(Tx_params& pull_p)
{
    bool ret = true;
    Data_mutator<Lossy_error::Mutator_traits8, U8ostream::Data_traits8<> > mutator(pull_p.os);
    Lossy_error& str(mutator.m);
    typename FTM::Kfsv::Reader rd(fsv);
    Uint16 i = pull_p.res_data.sub_mtype;
    const typename FTM::Vecdata& vdat = rd.get_vdat(i);

    if(vdat.is_enabled())
    {
        Kfieldset fset = rd.get_fset(i);
        vdat.build(fset, str);
        if(!rd.is_valid())
        {
            ret = false;
        }
    }
    return ret;
}
```

This method:
1. Creates a data mutator to work with the output stream
2. Gets the vector data for the specified sub-message type
3. If the vector is enabled, builds the telemetry data from the fieldset
4. Returns false if the reader is invalid

## 4. On-demand Telemetry Management

The `Ftelemetryod::Fsvod` class manages on-demand telemetry configuration and expiration:

```cpp
class Fsvod: public Itunable_async, public Istep
{
public:
    explicit Fsvod(Xcfsv& xfsv);
    virtual Async_sres cset(Lossy_error& str);
    virtual Async_sres cget(Lossy& str) const;
    virtual void step();

private:
    // State management for configuration and expiration
    enum State { st_idle, st_remove };
    enum Astate { ast_idle, ast_hash, ast_check, ast_update, ast_add };
    
    State st;
    Astate ast;
    
    // Vector tracking
    Uint32 vec_pos;
    Uint16 vec_sz;
    Uint16 vec_id;
    Tuncrc tcrc;
    
    Uint16 exp_vec_idx;
    Fsv0 fsv;
    
    Bitmask<Uint16> expired_vecs;
    Dsync::Writer_async wr_a;
    
    void init();
};
```

Key functionality:
1. **Configuration (`cset`)**: Asynchronously deserializes on-demand telemetry data
   - Processes vector data in multiple states (idle, hash computation, checking, updating, adding)
   - Computes hash values for vector identification
   - Updates or adds vectors as needed

2. **Expiration Management (`step`)**: Checks for and removes expired vectors
   - Identifies vectors that have exceeded their lifespan
   - Marks them for removal in a bitmask
   - Removes expired vectors in a separate state

## 5. Datalink System for Reliable Data Transfer

The telemetry system relies on a datalink subsystem for reliable data transfer, consisting of:

### 5.1 Datalink Buffer

The `Datalink_buffer` class manages data buffers and tracks transmission status:

```cpp
class Datalink_buffer
{
public:
    typedef Uint32 Tmsk;
    struct Status
    {
        Uint8 sequence;    // Sequence number in "window blocks"
        Tmsk window;       // Bit for each block in current window
    };
    
    Datalink_buffer(Uint8 wsize, Uint32 block_size);
    
    // Status management
    Uint32 get_window_full_mask() const;
    Uint8 get_window_size() const;
    Uint16 get_block_size() const;
    U8pkmblock get_data_buffer();
    void reset(Uint32 size);
    void set_status(Status st_new);
    Status get_status() const;
    void set_available_blocks(Tmsk available);
    Uint32 get_data_count() const;
    void inc_sequence_offset();
    
    // State checks
    bool is_full() const;
    bool is_finished_receive() const;
    bool is_finished_send() const;
    
    // Data operations
    bool write(const U8pkmblock_k& mb);
    bool read(U8pkmblock& mb);
    bool rd_available() const;

private:
    static const Uint8 max_wsize = 32;
    
    const Uint8 window_size;
    const Uint16 block_size;
    U8pkmblock data;
    
    const Tmsk mask_full;
    Status st;
    Tmsk available_mask;
    
    Uint8 min_av_idx;
    Uint32 data_size;
    Uint32 transferred_data_size;
    Uint32 block_offset;
    
    void update_min_index();
    void reset_window();
    static Tmsk get_msk(Uint8 idx);
};
```

Key features:
- Manages a window-based transmission protocol
- Tracks which blocks have been sent and acknowledged
- Provides methods to read and write data blocks
- Maintains sequence numbers and window status

### 5.2 Datalink Receiver

The `Datalink_receiver` class handles receiving data from a remote source:

```cpp
class Datalink_receiver
{
public:
    Datalink_receiver(Datalink_buffer& buffer0);
    void set_block_dev(Ifile& file);
    void clear_block_dev();
    void set_expected_data_size(Uint32 size);
    void get_status_msg(U8ostream& os);
    Async_res write(const U8pkmblock_k& mb);

private:
    Datalink_buffer& buffer;
    Ifile* file;
    bool finished;
};
```

Key functionality:
- Receives data blocks and writes them to the buffer
- Manages the status of received blocks
- Writes completed data to a file
- Tracks when reception is complete

### 5.3 Datalink Transmitter

The `Datalink_transmitter` class handles sending data to a remote destination:

```cpp
class Datalink_transmitter
{
public:
    Datalink_transmitter(Datalink_buffer& buffer0);
    bool is_finished();
    void set_block_dev(Ifile& file);
    void clear_block_dev();
    Async_res set_status_msg(Lossy& str);
    bool read(U8pkmblock& mb);
    bool rd_available();
    Async_res read_window();

private:
    Datalink_buffer& buffer;
    Ifile* file;
};
```

Key functionality:
- Reads data from a file into the buffer
- Tracks which blocks have been acknowledged by the receiver
- Manages retransmission of unacknowledged blocks
- Handles window advancement when blocks are acknowledged

## 6. Message Data Structures

### 6.1 Message Data (`Msg_data`)

The `Msg_data` structure defines the metadata for messages sent through the system:

```cpp
struct Msg_data
{
    enum Ack_type
    {
        received = 0,       // Message received
        not_completed = 1,  // Message received, but not completed
        completed = 2,      // Message received and completed
        rejected = 3,       // Message received, but rejected
        failed = 4          // Message received, but failed
    };

    Address dst;                        // Destination address
    Stanag_msg_type::Msg_type mtype;    // Message type
    Uint16 sub_mtype;                   // Message subtype for Acknowledge message or private data
    Stimestamp ts;                       // Original timestamp
    Ack_type ack_t;                     // Acknowledgement type
    Presence_vec pres_vec_req;          // Presence vector requested
    bool req_ack;                       // Request ACK

    // Constructors and serialization methods
};
```

This structure:
- Defines the destination address for a message
- Specifies the message type and subtype
- Includes timestamp information
- Tracks acknowledgment status
- Supports presence vector requests
- Provides serialization and deserialization methods

### 6.2 Moving Obstacle Data (`Mobs_data`)

The `Mobs_data` class manages data about moving obstacles:

```cpp
class Mobs_data
{
public:
    struct Flags
    {
        bool pos_ok;        // Latitude and longitude is valid
        bool alt_ok;        // Altitude is valid
        bool squawk_ok;     // Squawk code is valid
        bool callsign_ok;   // Calling signal is valid
        bool ident_enabled; // Ident is enabled
        bool hdg_ok;        // Heading is valid
        bool vel_ok;        // Velocity is valid
        
        // Methods for flag management
    };

    static const Uint32 nmax_mobs;  // Maximum number of moving obstacles
    
    Uint32 id;                      // ICAO address for ADS-B
    Base::Feature pos;              // Position
    Maverick::Rvector3 vel;         // Velocity
    Real heading;                   // Heading
    Flags flags;                    // Validity flags
    ADSB_Mavlink::Emitter_type emitter_type; // Emitter type
    Real tslc;                      // Time since last communication
    Uint16 squawk;                  // Squawk code
    
    static const Uint16 cs_sz = 8;  // Total size for call-sign array
    typedef Base::U8pkarray<cs_sz> Callsign; // Typedef for call-sign
    Callsign callsign;              // Handler for call-sign
    
    // Methods for obstacle management
};
```

This class:
- Stores position, velocity, and heading information for obstacles
- Tracks validity flags for different data fields
- Manages obstacle identification (ICAO address, callsign, squawk code)
- Provides methods to compute obstacle radius based on emitter type
- Supports serialization and deserialization of obstacle data

### 6.3 Absolute Position Data (`Apos_data`)

The `Apos_data` class manages absolute position information:

```cpp
class Apos_data
{
public:
    Apos_data();
    explicit Apos_data(const Base::Tllh& llh0);
    explicit Apos_data(const Base::Tllhcompressed& llh0);
    
    void copynr(const Apos_data& pos);
    void zeros();
    void set_llh(const Base::Tllh& llh0);
    void set_llh(const Base::Tllhcompressed& llh0);
    const Base::Tllh& get_llh() const;
    const Base::Tllcs& get_cs() const;
    void set_wgs84_h(const Real h);
    void move_h(const Real dh);
    void cset(Base::Lossy_error& str);
    void cget(Base::Lossy& str) const;

protected:
    Base::Tllh llh;  // Absolute position (longitude, latitude, WGS84 height)
    Base::Tllcs cs;  // Sines and cosines of longitude and latitude
    
    void compute_dep_llh();
};
```

This class:
- Manages longitude, latitude, and WGS84 height information
- Pre-computes sines and cosines for faster operations
- Provides methods to set and retrieve position data
- Supports serialization and deserialization of position data

## 7. Telemetry System Operation

### 7.1 Nominal and Complementary Telemetry

1. **Initialization**:
   - Create a vectorized fieldset with the desired fields
   - Configure telemetry vectors with periods and destination addresses
   - Instantiate a `Telemetry<Ftelemetry>` or `Telemetry<Ftelemetryc>` object

2. **Periodic Processing**:
   - Call the `step` method regularly to check if any vectors are due for transmission
   - When a vector is due, the system sends a message to the appropriate destination

3. **Transmission**:
   - The `on_tx` method is called when a message is being transmitted
   - It builds the telemetry data from the fieldset and sends it to the destination

### 7.2 On-demand Telemetry

1. **Configuration**:
   - Create on-demand telemetry vectors with fields, periods, and lifespans
   - Add vectors to the on-demand telemetry system

2. **Periodic Processing**:
   - Call the `step` method to check for expired vectors
   - Remove vectors that have exceeded their lifespan

3. **Transmission**:
   - Similar to nominal telemetry, but with additional checks for expiration
   - Only transmits vectors that are both enabled and not expired

### 7.3 Datalink Operation

1. **Initialization**:
   - Create a datalink buffer with appropriate window and block sizes
   - Set up a transmitter or receiver with the buffer

2. **Transmission**:
   - Read data from a file into the buffer
   - Send data blocks to the remote destination
   - Process acknowledgments and retransmit as needed

3. **Reception**:
   - Receive data blocks and store them in the buffer
   - Send acknowledgments for received blocks
   - Write completed data to a file

## 8. Key Algorithms and Processes

### 8.1 Telemetry Vector Transmission

```
For each vector in the fieldset (from last to first):
    Get the Chrono object for this vector
    Get the vector data
    If the vector is enabled and it's time to transmit (check_period):
        Get the destination address
        If the reader is valid:
            Send a message to the destination
            Reset the timer for this vector
        Else:
            Set aux to true to exit the loop
```

### 8.2 On-demand Telemetry Expiration

```
For each vector in the fieldset (from last to first):
    Get the vector data
    If the vector is not enabled (including expiration check):
        Set the expiration index
        Set the bit in the expired vectors bitmask

If any vectors are expired:
    Enter the remove state
    
In the remove state:
    Start a write operation
    Remove the expired vector
    Clear the bit in the expired vectors bitmask
    If more vectors are expired:
        Find the next expired vector
    Else:
        End the write operation
        Return to the idle state
```

### 8.3 Datalink Buffer Management

```
When writing data:
    Get the sequence number from the data
    Calculate the index in the window
    If the index is valid and the block is empty:
        Copy the data to the buffer
        Mark the block as available to read
        Update the minimum available index if needed

When reading data:
    If there is data available to read:
        Get the block at the minimum available index
        Copy the data to the output buffer
        Mark the block as read
        Update the minimum available index
```

## 9. Referenced Context Files

The following context files provided valuable information for understanding the telemetry system:

1. **Telemetry.h**: Defines the core telemetry template class used by all telemetry types.
2. **Ftelemetry.h**: Defines the nominal telemetry type with 600 fields and 4 vectors.
3. **Ftelemetryc.h**: Defines the complementary telemetry type with 150 fields and 1 vector.
4. **Ftelemetryod.h**: Defines the on-demand telemetry type with 200 fields and 10 vectors, plus expiration.
5. **Tmvdat.h**: Defines the basic telemetry vector data structure.
6. **Tmovdat.h**: Defines the on-demand telemetry vector data structure with expiration.
7. **Datalink_buffer.h**: Defines the buffer management for reliable data transfer.
8. **Datalink_receiver.h**: Defines the receiver side of the datalink system.
9. **Datalink_transmitter.h**: Defines the transmitter side of the datalink system.
10. **Msg_data.h**: Defines the message data structure used for communication.
11. **Mobs_data.h**: Defines the moving obstacle data structure.
12. **Apos_data.h**: Defines the absolute position data structure.

These files collectively provide a comprehensive view of the telemetry system architecture and operation.