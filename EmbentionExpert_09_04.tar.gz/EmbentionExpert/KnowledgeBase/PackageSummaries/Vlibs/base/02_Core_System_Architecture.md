# Generated from:

- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/base/03_Task_Management.md (6542 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/base/03_Timing_System.md (4641 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/base/03_Configuration_Management.md (3922 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/base/03_Variable_Management.md (3303 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/base/03_Feature_Management.md (3824 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/base/03_File_System.md (3858 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/base/03_Logging_System.md (4319 tokens)

---

# System Architecture Overview: Comprehensive Analysis

This document provides a high-level architectural overview of the embedded system, synthesizing information from the various subsystem summaries to present a cohesive understanding of the overall system design, initialization sequence, communication patterns, and architectural patterns.

## 1. System Architecture Overview

The system follows a multi-core architecture with sophisticated cross-core communication mechanisms. It is built on a foundation of several key subsystems that work together to provide a robust, real-time embedded platform:

### 1.1 Core Subsystems

1. **Task Management System**
   - Provides flexible task scheduling and execution across cores
   - Supports time-based, cyclic, and dynamic task execution models
   - Includes CPU resource monitoring for performance analysis

2. **Timing System**
   - Manages various chronometer types (time-based, position-based)
   - Provides absolute time tracking and standardized timestamps
   - Implements watchdog functionality for system monitoring

3. **Configuration Management**
   - Handles system-wide configuration storage and access
   - Provides change tracking and synchronization mechanisms
   - Supports cross-core configuration sharing

4. **Variable Management**
   - Centralizes access to system variables across cores
   - Supports multiple variable types and access patterns
   - Implements buffering and validation mechanisms

5. **Feature Management**
   - Represents spatial positions (absolute and relative)
   - Organizes features into logical groups with unique IDs
   - Provides serialization and reference mechanisms

6. **File System**
   - Implements cross-core file operations
   - Provides memory-based file storage
   - Supports asynchronous file access

7. **Logging System**
   - Enables cross-core logging with client-server architecture
   - Includes boot logging for system initialization tracking
   - Provides error reporting and handling mechanisms

### 1.2 System Architecture Diagram

```
┌─────────────────────────────────────────┐  ┌─────────────────────────────────────────┐
│               Core 1                    │  │               Core 2                    │
│                                         │  │                                         │
│  ┌─────────────┐      ┌─────────────┐   │  │  ┌─────────────┐      ┌─────────────┐   │
│  │    Task     │◄────►│   Timing    │   │  │  │    Task     │◄────►│   Timing    │   │
│  │  Management │      │   System    │   │  │  │  Management │      │   System    │   │
│  └──────┬──────┘      └──────┬──────┘   │  │  └──────┬──────┘      └──────┬──────┘   │
│         │                    │          │  │         │                    │          │
│         ▼                    ▼          │  │         ▼                    ▼          │
│  ┌─────────────┐      ┌─────────────┐   │  │  ┌─────────────┐      ┌─────────────┐   │
│  │ Variable    │◄────►│ Feature     │   │  │  │ Variable    │◄────►│ Feature     │   │
│  │ Management  │      │ Management  │   │  │  │ Management  │      │ Management  │   │
│  └──────┬──────┘      └──────┬──────┘   │  │  └──────┬──────┘      └──────┬──────┘   │
│         │                    │          │  │         │                    │          │
│         ▼                    ▼          │  │         ▼                    ▼          │
│  ┌─────────────┐      ┌─────────────┐   │  │  ┌─────────────┐      ┌─────────────┐   │
│  │Configuration│◄────►│  Logging    │   │  │  │Configuration│◄────►│  Logging    │   │
│  │ Management  │      │  System     │   │  │  │ Management  │      │  System     │   │
│  └──────┬──────┘      └──────┬──────┘   │  │  └──────┬──────┘      └──────┬──────┘   │
│         │                    │          │  │         │                    │          │
│         └────────┬───────────┘          │  │         └────────┬───────────┘          │
│                  │                      │  │                  │                      │
│                  ▼                      │  │                  ▼                      │
│  ┌─────────────────────────────────┐    │  │  ┌─────────────────────────────────┐    │
│  │      Cross-Core Communication   │◄───┼──┼─►│      Cross-Core Communication   │    │
│  │      (Shared Memory, FIFOs)     │    │  │  │      (Shared Memory, FIFOs)     │    │
│  └─────────────────────────────────┘    │  │  └─────────────────────────────────┘    │
│                                         │  │                                         │
└─────────────────────────────────────────┘  └─────────────────────────────────────────┘
                                 │                              │
                                 ▼                              ▼
                        ┌─────────────────────────────────────────────┐
                        │                File System                  │
                        │      (Memory-based, Cross-Core Access)      │
                        └─────────────────────────────────────────────┘
```

## 2. System Initialization Sequence

The system follows a structured initialization sequence to ensure proper startup across all cores:

### 2.1 Boot Process

1. **Boot Logging Initialization**
   - System creates `Bootlog` instance
   - `Bootlog::load()` reads boot information from storage
   - System determines boot mode (normal or maintenance)
   - Boot retry counters are updated if needed

2. **Core Subsystem Initialization**
   - Memory management systems are initialized
   - Cross-core communication structures are set up
   - Variable manager is initialized with default values
   - Configuration manager loads configurations from storage

3. **Task Management Setup**
   - Task managers are created on each core
   - Cyclic tasks are registered
   - CPU resource monitoring is initialized

4. **Cross-Core Services Initialization**
   - File services are initialized
   - Logging services are started
   - Cross-core configuration synchronization is established

### 2.2 Initialization Sequence Diagram

```
┌────────────┐  ┌────────────┐  ┌────────────┐  ┌────────────┐  ┌────────────┐
│ Boot       │  │ Memory     │  │ Variable   │  │ Config     │  │ Task       │
│ Logging    │──►│ Management│──►│ Management│──►│ Management │──►│ Management│
└────────────┘  └────────────┘  └────────────┘  └────────────┘  └────────────┘
                                                                      │
                                                                      ▼
┌────────────┐  ┌────────────┐  ┌────────────┐  ┌────────────┐  ┌────────────┐
│ System     │◄─┤ Cross-Core │◄─┤ Logging    │◄─┤ File       │◄─┤ Feature    │
│ Running    │  │ Services   │  │ System     │  │ System     │  │ Management │
└────────────┘  └────────────┘  └────────────┘  └────────────┘  └────────────┘
```

## 3. Cross-Core Communication Patterns

The system implements several sophisticated patterns for cross-core communication:

### 3.1 Shared Memory Structures

1. **Registry Variables**
   - Contiguous variables in dedicated shared memory
   - Accessed via `Var<K>::Regarray<from0, to_inclusive0>`
   - Synchronized with `Varmgr` through explicit calls

2. **Cross-Core Buffers**
   - Fixed-size buffers (typically 512 bytes)
   - Used for data transfer between cores
   - Implemented with reader/writer access control

3. **Control Structures**
   - Status information shared between cores
   - Request-acknowledge patterns for synchronization
   - Atomic operations for thread safety

### 3.2 Synchronization Mechanisms

1. **Request-Acknowledge Pattern**
   - Client sends request with unique ID
   - Server processes request and updates status
   - Server acknowledges by copying request ID to control structure
   - Client checks for acknowledgment by comparing IDs

2. **FIFO-Based Communication**
   - Non-blocking write operations
   - Thread-safe implementation
   - Separate read and write pointers
   - Used for logging and error reporting

3. **Blocking Reads**
   - `Rdblocking::get()` waits until data is valid
   - Prevents reading invalid or partially updated data
   - Used for critical data access

### 3.3 Cross-Core Data Flow

```
┌─────────────────┐                      ┌─────────────────┐
│    Core 1       │                      │    Core 2       │
│                 │                      │                 │
│  ┌───────────┐  │                      │  ┌───────────┐  │
│  │ Client    │  │  1. Send Request     │  │ Service   │  │
│  │ Component │──┼──────────────────────┼─►│ Component │  │
│  └───────────┘  │                      │  └───────────┘  │
│        ▲        │                      │        │        │
│        │        │                      │        ▼        │
│  ┌───────────┐  │  2. Write Data       │  ┌───────────┐  │
│  │ Shared    │◄─┼──────────────────────┼──┤ Shared    │  │
│  │ Memory    │  │                      │  │ Memory    │  │
│  └───────────┘  │                      │  └───────────┘  │
│        │        │                      │        ▲        │
│        ▼        │                      │        │        │
│  ┌───────────┐  │  3. Read Response    │  ┌───────────┐  │
│  │ Client    │◄─┼──────────────────────┼──┤ Service   │  │
│  │ Component │  │                      │  │ Component │  │
│  └───────────┘  │                      │  └───────────┘  │
└─────────────────┘                      └─────────────────┘
```

## 4. Task Management and Execution

The system provides multiple task execution models to accommodate different requirements:

### 4.1 Task Execution Models

1. **Time-Based Scheduling (`Taskmgr`)**
   - Tasks are scheduled based on absolute or relative time
   - Tasks can be immediate or delayed
   - Multiple tasks may execute in a single step
   - Tasks remain in queue until completion

2. **Round-Robin Execution (`Cyclic_tasks`)**
   - Tasks execute in sequence, one step at a time
   - Each task gets fair execution time
   - Tasks that complete quickly execute more frequently
   - All tasks remain in the cycle indefinitely

3. **Dynamic Task Handling (`Tdtask`)**
   - Policy-based task execution
   - Separates initialization from execution
   - Tasks can complete immediately during initialization
   - Integrates with task manager for scheduled execution

### 4.2 Task State Machines

Each task execution model implements its own state machine:

1. **Taskmgr State Machine**
   - States: Pending, Ready, Running, Completed, Canceled
   - Transitions based on time and task completion

2. **Cyclic_tasks State Machine**
   - States: Waiting, Running, Completed
   - Transitions based on task completion and cycle position

3. **Tdtask State Machine**
   - States: Idle, Initializing, Scheduled, Running, Completed
   - Transitions based on initialization result and task completion

### 4.3 Resource Monitoring

The system includes sophisticated resource monitoring:

1. **CPU Usage Monitoring**
   - `CPUrc<S>` template with different statistics implementations
   - `CPUrc_avg` for average usage calculation
   - `CPUrc_all` for comprehensive statistics
   - RAII pattern for scope-based measurement

2. **Real-Time Task Monitoring**
   - `Rtaskrc` for measuring task execution time
   - Tracks current and maximum intervals
   - Uses EWMA for smoothing measurements

## 5. Configuration Management

The configuration system provides a comprehensive framework for managing system settings:

### 5.1 Configuration Organization

1. **Configuration Identifiers**
   - Up to 512 different configuration elements
   - Organized into logical groups
   - Each with unique ID from `Base::Cfg::Id` enumeration

2. **Configuration Types**
   - Channel management (`Channelmgrcfg`)
   - Event-action associations (`Evactcfg`)
   - GPS variables (`Vargpscfg`)
   - And many others for specific subsystems

3. **Cross-Core Configuration**
   - `Xcfg_des<T>` template for cross-core compatible configurations
   - `Xcfgmgr` for managing configuration sharing
   - `Xcfieldsvec` for sharing field vectors

### 5.2 Configuration Lifecycle

```
┌────────────┐     ┌────────────┐     ┌────────────┐     ┌────────────┐
│ Definition │────►│Initialization│───►│ Loading    │────►│   Usage    │
└────────────┘     └────────────┘     └────────────┘     └────────────┘
                                                               │
                                                               ▼
┌────────────┐     ┌────────────┐     ┌────────────┐     ┌────────────┐
│Persistence │◄────┤Synchronization│◄──┤ Validation │◄────┤Modification│
└────────────┘     └────────────┘     └────────────┘     └────────────┘
```

### 5.3 Configuration Access Control

1. **Mode-Based Restrictions**
   - `Cfgid_mode` associates modes with configuration IDs
   - Modes: none, normal, maintenance, both
   - Restricts when configurations can be modified

2. **Change Tracking**
   - CRCs track changes between memory and file versions
   - `Cfgsync` manages synchronization states
   - Configurations can be synchronized or modified

## 6. Variable Management

The variable management system provides a flexible framework for accessing system variables:

### 6.1 Variable Types and Access Patterns

1. **Variable Types**
   - `Rvar`: Real (floating-point) variables
   - `Uvar`: Unsigned 16-bit variables
   - `Bvar`: Boolean variables
   - `Fid`: Feature variables
   - `Bvar_map`: Bitmap variables
   - `Uint64`: 64-bit unsigned integers

2. **Access Patterns**
   - `Commit`: Explicit commit on request
   - `Rcache`: Automatic commit on write
   - `Wdif`: Write only if value differs
   - `Rcwd`: Commit on write when value differs
   - `Rdblocking`: Wait until data is valid
   - `Reg<k0>`: Shared memory element
   - `Regarray<from0, to_inclusive0>`: Contiguous variables

### 6.2 Variable References and Destinations

1. **Variable References**
   - `Vref_wr`: References variables by ID and type
   - `Vref_wr_tun`: Checks if variables are user-writable
   - Supports serialization and deserialization

2. **Variable Destinations**
   - `Vrefdst`: Abstract interface for setting variables
   - `Vrefdstbuff`: Buffers variable changes
   - `Vardst`: Adapts to sniffer telemetry system

## 7. Feature Management

The feature management system represents spatial positions within the system:

### 7.1 Feature Representation

1. **Feature Structure**
   - Absolute positions in LLH coordinates
   - Relative positions in NED coordinates
   - Reference to other features via `wrt` field

2. **Feature Identification**
   - `Fid` enumeration organizes features into logical groups
   - Special IDs for system features (UAV position, home, etc.)
   - Groups for waypoints, moving objects, etc.

3. **Feature References**
   - `Fref` structure for referencing existing features
   - Can store constant feature values
   - Supports serialization and deserialization

## 8. File System and Logging

The system provides robust file and logging capabilities:

### 8.1 Cross-Core File System

1. **Client-Server Architecture**
   - `Xcfile`: User-facing API
   - `Xcfilecli`: Client-side implementation
   - `Xcfilesvc`: Service-side implementation
   - Asynchronous operations for non-blocking behavior

2. **Memory-Based Storage**
   - `Mem_file` implements memory-based file system
   - Files stored in RAM with headers
   - CRC validation for data integrity

### 8.2 Logging System

1. **Cross-Core Logging**
   - Client-server model spans multiple cores
   - Session-based logging organization
   - Buffered data transfer for efficiency

2. **Boot Logging**
   - Tracks system boot status and history
   - Determines appropriate boot mode
   - Implements redundancy and recovery mechanisms

3. **Error Handling**
   - FIFO-based error reporting
   - Non-blocking write operations
   - Dual-core error reading
   - System error bit tracking

## 9. Key Architectural Patterns

The system implements several sophisticated architectural patterns:

### 9.1 Singleton Pattern

Used for system-wide access to key managers:
- `Varmgr::get_instance()`
- `Stepmgr::get_instance()`
- `Xcfgmgr::get_instance()`

### 9.2 Template Method Pattern

Used for customizable behavior with common structure:
- `CPUrc<S>` for different statistics implementations
- `Tdtask<DTSK_POLICY>` for policy-based task handling
- `Xcfg_des<T>` for cross-core configuration types

### 9.3 Observer Pattern

Used for event notification:
- Configuration change notifications
- Timer events
- Error reporting

### 9.4 Command Pattern

Used for encapsulating operations:
- File operations (open, read, write, seek, close)
- Configuration operations (get, set, save, load)
- Logging commands (start_session, stop_session)

### 9.5 State Pattern

Used for managing complex state transitions:
- Task state machines
- File operation state machines
- Boot state management

### 9.6 Proxy Pattern

Used for remote access:
- Cross-core file access
- Cross-core logging
- Cross-core configuration

### 9.7 Adapter Pattern

Used for interface compatibility:
- `Vardst` adapts variable references to sniffer telemetry
- `Ifile_null` provides null implementation for testing
- `Errors_dual` adapts two error FIFOs to single interface

## 10. System Integration

The various subsystems are integrated through several mechanisms:

### 10.1 Task Management Integration

- Task managers execute periodic steps of other subsystems
- Watchdog timers monitor system health
- CPU resource monitoring tracks performance

### 10.2 Configuration Integration

- Cross-core configuration manager synchronizes settings
- Configuration changes trigger system updates
- Mode-based restrictions control when changes are allowed

### 10.3 Variable Integration

- Central variable manager provides access to all system variables
- Cross-core variable access through shared memory
- Variable references allow indirect access and buffering

### 10.4 Logging Integration

- Error reporting feeds into logging system
- Boot logging tracks system initialization
- Cross-core logging enables comprehensive system monitoring

## 11. Conclusion

The system architecture demonstrates a sophisticated design that addresses the challenges of real-time embedded systems with multiple cores. Key strengths include:

1. **Modularity**: Clear separation of concerns between subsystems
2. **Flexibility**: Multiple patterns for task execution, variable access, and configuration
3. **Efficiency**: Non-blocking operations and optimized cross-core communication
4. **Reliability**: Redundancy, error handling, and recovery mechanisms
5. **Scalability**: Template-based designs that can adapt to different requirements

The architecture provides a solid foundation for building complex embedded applications that require deterministic behavior, efficient resource usage, and robust error handling across multiple processor cores.