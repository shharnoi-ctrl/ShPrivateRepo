# Generated from:

- code/include/Map.h (3490 tokens)
- code/include/Jarray.h (5471 tokens)
- code/include/Hash_map.h (3152 tokens)
- code/include/Linkedlist.h (2316 tokens)
- code/include/Set.h (923 tokens)
- code/include/Auto_array.h (127 tokens)
- code/include/Fieldsvec.h (8814 tokens)
- code/include/Fieldset.h (1098 tokens)
- code/include/Field.h (1626 tokens)
- code/include/Field_cfg.h (1031 tokens)
- code/include/Field_BCD.h (660 tokens)
- code/include/FieldASCII.h (613 tokens)
- code/include/Kfieldset.h (1138 tokens)
- code/include/Kfieldsvec.h (1368 tokens)
- code/source/Field.cpp (11644 tokens)
- code/source/Fieldset.cpp (370 tokens)
- code/source/Field_BCD.cpp (891 tokens)
- code/source/FieldASCII.cpp (1344 tokens)
- code/source/Kfieldset.cpp (1413 tokens)

---

# High-Fidelity Semantic Knowledge Graph: Core Data Structures

This document provides a comprehensive analysis of the core data structures used throughout the system, focusing on their implementation details, memory management strategies, and usage patterns.

## Map Class

`Map<K, V>` is a key-value association container that stores pairs of keys and values, providing efficient lookup and manipulation operations.

### Implementation Details

- **Storage Structure**: Uses two parallel containers:
  - `Stlvector<K> keys`: Stores the keys
  - `Array<V> values`: Stores the values at corresponding indices

- **Memory Management**:
  - Constructed with a specified number of elements (`n0`) and memory type (`memtype`)
  - Both `keys` and `values` are allocated with the same size and memory type
  - Does not dynamically resize - has a fixed capacity defined at construction

- **Key Operations**:
  - `put(K& k0, V& v0)`: Adds or updates a key-value pair
  - `del(K& k0)`: Removes a key-value pair
  - `get(K& k0, V& def)`: Retrieves a value by key, returning a default if not found
  - `get_ref(K& k0)`: Returns a pointer to the value associated with a key
  - `has_key(K& k0)`: Checks if a key exists
  - `admits_key(K& k0)`: Checks if a key exists or if there's space to add it

- **Iteration**:
  - Provides an `Iterator` inner class to traverse all key-value pairs
  - Iterator maintains pointers to the current key and value elements
  - `next(K& key0, V& value0)` method advances the iterator and returns the current pair

- **Key Removal Behavior**:
  - When a key is deleted, the last element in the map is moved to fill the gap
  - This reordering means iteration may fail after deletion operations

### Usage Pattern

The Map is designed for scenarios where:
- The maximum number of elements is known in advance
- Fast lookup by key is required
- Elements may need to be added or removed during operation
- Memory allocation needs to be controlled (via the `memtype` parameter)

## Jarray Class (Jagged Array)

`Jarray<T>` implements a jagged array - an array of arrays/vectors where each sub-array can have a different size.

### Implementation Details

- **Storage Structure**:
  - `Mblock<T> pool`: A contiguous memory block containing all elements
  - `Uint16& m`: Current number of sub-arrays
  - `Mblock<T*> ptr`: Array of pointers to the start of each sub-array, plus one extra pointer to the first unallocated element

- **Memory Management**:
  - All elements are stored in a single contiguous memory block (`pool`)
  - Sub-arrays are defined by pointers into this memory block
  - No dynamic reallocation - fixed capacity defined at construction

- **Key Operations**:
  - `sub_add(Uint16 sub_sz)`: Adds a new sub-array of specified size
  - `sub_remove(Uint16 idx)`: Asynchronously removes a sub-array
  - `sub_get(Uint16 idx)`: Returns a sub-array as a memory block
  - `get(Uint16 idx, Uint16 sub_idx)`: Accesses an element by sub-array and element indices
  - `zeros0()`: Sets all elements to zero
  - `clear()`: Removes all sub-arrays

- **Asynchronous Operations**:
  - `sub_remove` operates asynchronously, moving elements in chunks
  - Uses member variables `vsrc` and `vdst` to track progress between calls

- **Constant View**:
  - Provides a `Kjarray` inner class for a read-only view of the jagged array

### Usage Pattern

Jarray is used when:
- Data naturally forms groups of varying sizes
- Memory efficiency is important (all elements stored contiguously)
- Sub-arrays need to be added or removed dynamically
- The total capacity is known in advance

## Hash_map Class

`Hash_map<T>` implements a hash map container where elements of type T must provide specific methods for ID management and hash calculation.

### Implementation Details

- **Requirements for Type T**:
  - Must define an `Idtype` type for IDs
  - Must provide `Idtype get_id() const` method
  - Must provide `void set_id(const Idtype& id0)` method
  - Must provide `void hash_func(const Idtype& key)` static method
  - Must support copy assignment

- **Storage Structure**:
  - `Array<T> map`: A flat array of elements organized by hash
  - `const Uint16 nb_hash`: Number of hash buckets
  - `const Uint16 nb_sub`: Number of elements per hash bucket
  - `const Idtype null_id`: ID value indicating an empty element
  - `Uint16 nb_subscribed`: Counter for the number of elements in the map

- **Memory Management**:
  - Fixed-size allocation with `nb_hash * nb_sub` elements
  - All elements initialized with `null_id`
  - No dynamic resizing

- **Key Operations**:
  - `push(const T& elem)`: Adds an element to the map
  - `get(const Idtype& key)`: Retrieves an element by key
  - `get_nb_subscribed()`: Returns the number of elements in the map

- **Collision Handling**:
  - Uses open addressing with linear probing within a hash bucket
  - If a hash collision occurs, checks subsequent slots in the same bucket
  - Returns false if all slots for a hash are full

- **Iteration**:
  - Provides an `Iterator` inner class to traverse elements
  - `next()` method advances to the next non-null element
  - `get_element(Iterator& it)` retrieves the element at the iterator's position

### Usage Pattern

Hash_map is designed for:
- Fast lookup by ID
- Fixed capacity known at construction time
- Elements that have a natural ID and hash function
- Scenarios where collision handling is important but simple

## Linkedlist Class

`Linkedlist<T>` implements a singly-linked list where elements can only be added (no removal).

### Implementation Details

- **Node Structure**:
  - Uses an inner `Element` struct containing:
    - `T elem`: The stored element
    - `Element* next`: Pointer to the next element

- **List Management**:
  - `Element* first`: Pointer to the first element
  - `Element* last`: Pointer to the last element (for efficient addition)

- **Memory Management**:
  - Elements are allocated using a provided `Allocator`
  - No built-in deallocation - memory must be managed externally
  - Designed for ever-growing lists (only addition operations)

- **Key Operations**:
  - `build_add_elem(Base::Allocator& alloc, const P0& param0)`: Creates and adds an element
  - `add_elem(Element* p)`: Adds a pre-allocated element to the list

- **Iteration**:
  - Provides both `Iterator` and `Const_iterator` classes
  - `next()` method returns the current element and advances the iterator

### Usage Pattern

Linkedlist is used when:
- Elements need to be added but never removed
- Memory allocation needs to be controlled via an external allocator
- Sequential access is the primary usage pattern
- The list may need to grow indefinitely

## Set Class

`Set<T>` implements a collection with no duplicate elements.

### Implementation Details

- **Storage Structure**:
  - Internally uses a `Stlvector<T>` for element storage

- **Memory Management**:
  - Constructed with a specified size and memory type
  - Fixed capacity defined at construction

- **Key Operations**:
  - `add(const T& value)`: Adds an element if it doesn't already exist
  - `add_all(const Set<T>& value)`: Adds all elements from another set
  - `remove(const T& value)`: Removes an element
  - `has(const T& value)`: Checks if an element exists
  - `equals(const Set<T>& other)`: Checks if two sets contain the same elements

- **Serialization**:
  - `cset(Lossy& str, void(Lossy::*get)(T2&))`: Deserializes from a stream
  - `cget(Lossy& str, void(Lossy::*put)(T2))`: Serializes to a stream

### Usage Pattern

Set is used when:
- Uniqueness of elements must be maintained
- Fast membership testing is required
- The maximum number of elements is known in advance
- Serialization/deserialization may be needed

## Auto_array Class

`Auto_array<T, n0>` is a simple wrapper around `Array<T>` that provides automatic storage allocation.

### Implementation Details

- **Storage Structure**:
  - Inherits from `Base::Array<T>`
  - Contains a fixed-size buffer `T buf[n0]`

- **Memory Management**:
  - Automatically allocates storage on the stack
  - Size is determined by the template parameter `n0`
  - No dynamic memory allocation

### Usage Pattern

Auto_array is used when:
- A fixed-size array is needed
- Stack allocation is preferred over heap allocation
- The Array interface is desired

## Field System Components

The Field system provides a framework for data representation, serialization, and type conversion. It consists of several interconnected classes:

### Field Class

`Field` represents a data field with type information and configuration for serialization/deserialization.

#### Implementation Details

- **Core Structure**:
  - Inherits from `Field_data` which contains:
    - `Vtype tfield`: Type of the field
    - `Uint16 id`: Element identifier
    - `Field_cfg::Config cfg`: Configuration structure

- **Field Types**:
  - Supports numerous types including real numbers, integers, bits, checksums, etc.
  - Each type has specific serialization/deserialization logic

- **Key Operations**:
  - `compress(Lossy& str, const Iget& src)`: Serializes data from a source
  - `uncompress(Lossy_error& str, Iset& dst)`: Deserializes data to a destination
  - `cset(Base::Lossy_error& str)`: Deserializes field configuration
  - `cget(Base::Lossy& str)`: Serializes field configuration
  - `get_size()`: Returns the size of the field in bits
  - `user_writable()`: Checks if the field can be written by the user

- **Position Serialization**:
  - Provides an `Iapos_serializator` interface for position serialization
  - Supports different position formats (feature, LLH)

### Fieldset Class

`Fieldset` manages a set of fields, providing collective operations.

#### Implementation Details

- **Storage Structure**:
  - `Array<Field> fields`: Array of Field objects

- **Key Operations**:
  - `resize(Uint32 sz)`: Changes the size of the field set
  - `get_kfset()`: Returns a constant view of the field set
  - `cset_size16(Lossy_error& str)`: Deserializes with size information
  - `cset_nosize(Lossy_error& str)`: Deserializes without size information
  - `cset_nosize_async(Lossy_error& str, Uint16 max_count, Uint16& curr_idx)`: Asynchronously deserializes

### Kfieldset Class

`Kfieldset` provides a read-only view of a field set.

#### Implementation Details

- **Storage Structure**:
  - `Mblock<const Field> fields`: Memory block with constant Field objects

- **Key Operations**:
  - `get_hash()`: Computes a hash of the field set
  - `get_hash_async(Uint32& hash, Uint16& curr_idx)`: Asynchronously computes a hash
  - `compress(Lossy& str, const Iget& src)`: Serializes all fields
  - `uncompress(Lossy_error& str, Iset& dst)`: Deserializes all fields
  - `get_size()`: Returns the total size of all fields in bits
  - `user_writable()`: Checks if all fields are user-writable

### Fieldsvec Class

`Fieldsvec<VECDATA, max_cxet_steps0>` manages vectors of fields with associated data.

#### Implementation Details

- **Storage Structure**:
  - `Dsync& sync`: Concurrent modification control
  - `Jarray<Field> jfields`: Jagged array of fields
  - `Mblock<VECDATA> vdat`: Related data for each vector

- **Asynchronous State Management**:
  - `enum Astate`: Tracks the current asynchronous state
  - `Dsync::Writer_async wra`: Asynchronous writer for synchronization
  - Various state variables for tracking progress

- **Key Operations**:
  - `add_sub_vec(Uint16 sz)`: Adds a new vector with specified size
  - `add_sub_field(Uint16 vector_idx, Uint16 field_idx, Field field)`: Sets a field in a vector
  - `sub_vdat(Uint16 idx, VECDATA vdata)`: Sets vector data
  - `add(TT& str)`: Deserializes a new field vector
  - `cset(TT& str)`: Deserializes all field vectors
  - `cget(Lossy& str)`: Serializes all field vectors
  - `clear()`: Resets the internal state

- **Synchronization**:
  - Uses `Dsync` for thread safety
  - Provides both synchronous and asynchronous operations based on template parameter

### Kfieldsvec Class

`Kfieldsvec<VECDATA>` provides a read-only view of field vectors.

#### Implementation Details

- **Storage Structure**:
  - `const volatile Dsync& sync`: Concurrent modification control
  - `const Jarray<Field>::Kjarray jfields`: Constant jagged array of fields
  - `const Mblock<const VECDATA> vdat`: Related data for each vector

- **Reader Class**:
  - Provides a `Reader` inner class for safe concurrent access
  - Reader validates access through the synchronization mechanism

- **Key Operations**:
  - `size()`: Returns the number of vectors
  - `get_fset(Uint16 i)`: Returns a field set for a vector
  - `get_vdat(Uint16 i)`: Returns data for a vector
  - `is_valid()`: Checks if the reader is valid

## Memory Management Strategies

The data structures employ several memory management strategies:

1. **Fixed Allocation**:
   - Most containers use fixed-size allocation determined at construction
   - No dynamic resizing, which provides predictable memory usage
   - Memory type (location) can be specified via `Memmgr::Type`

2. **Memory Blocks**:
   - `Mblock<T>` is used extensively to represent contiguous memory regions
   - Provides a uniform interface regardless of memory location

3. **Jagged Arrays**:
   - Efficient storage of variable-length arrays in a single memory block
   - Avoids fragmentation by keeping all elements contiguous

4. **External Allocation**:
   - `Linkedlist` delegates memory allocation to an external `Allocator`
   - Allows for custom memory management strategies

5. **Stack Allocation**:
   - `Auto_array` uses stack allocation for small, fixed-size arrays

## Synchronization for Concurrent Access

Several mechanisms ensure thread safety:

1. **Dsync**:
   - Used by `Fieldsvec` and `Kfieldsvec` for reader-writer synchronization
   - Allows multiple readers or a single writer

2. **Writer and Reader Classes**:
   - `Dsync::Writer` provides exclusive write access
   - `Dsync::Reader` provides shared read access
   - `Dsync::Writer_async` supports asynchronous writing operations

3. **Asynchronous Operations**:
   - Many operations support both synchronous and asynchronous modes
   - Asynchronous operations track state between calls
   - Return `Async_sres` to indicate completion status

4. **Mutex**:
   - Used in specific operations (e.g., in `Field` for incremental counters)
   - Provides exclusive access to critical sections

## Field System Usage Patterns

The Field system is designed for flexible data representation and serialization:

1. **Type Conversion**:
   - Fields convert between native types and serialized formats
   - Support for various numeric formats, strings, and specialized types

2. **Configuration-Driven Behavior**:
   - Field behavior is determined by its configuration
   - Configuration can be serialized/deserialized

3. **Hierarchical Organization**:
   - Fields are organized into sets (`Fieldset`)
   - Sets can be organized into vectors (`Fieldsvec`)
   - Provides a flexible structure for complex data

4. **Read-Only Views**:
   - `Kfieldset` and `Kfieldsvec` provide read-only views
   - Ensures data integrity in multi-threaded environments

5. **Asynchronous Processing**:
   - Support for processing large data sets incrementally
   - Useful for resource-constrained environments

## Referenced Context Files

The following context files provided useful information for understanding the data structures:

- `code/include/Map.h`: Defined the Map container for key-value associations
- `code/include/Jarray.h`: Implemented the jagged array data structure
- `code/include/Hash_map.h`: Provided the hash map implementation
- `code/include/Linkedlist.h`: Implemented the linked list container
- `code/include/Set.h`: Defined the Set container for unique elements
- `code/include/Auto_array.h`: Implemented a simple wrapper for Array with automatic storage
- `code/include/Field.h`, `code/source/Field.cpp`: Defined the Field class for data representation
- `code/include/Fieldset.h`, `code/source/Fieldset.cpp`: Implemented the Fieldset container
- `code/include/Kfieldset.h`, `code/source/Kfieldset.cpp`: Provided a read-only view of field sets
- `code/include/Fieldsvec.h`: Implemented vectors of field sets
- `code/include/Kfieldsvec.h`: Provided a read-only view of field vectors
- `code/include/Field_cfg.h`: Defined configuration structures for fields
- `code/include/Field_BCD.h`, `code/source/Field_BCD.cpp`: Implemented BCD format fields
- `code/include/FieldASCII.h`, `code/source/FieldASCII.cpp`: Implemented ASCII format fields