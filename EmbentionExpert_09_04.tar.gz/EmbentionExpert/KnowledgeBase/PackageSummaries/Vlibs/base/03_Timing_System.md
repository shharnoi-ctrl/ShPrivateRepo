# Generated from:

- code/include/Uclk.h (655 tokens)
- code/include/Uclkmgr.h (645 tokens)
- code/include/Xclk.h (757 tokens)
- code/include/Xclkcfg.h (867 tokens)
- code/include/Xclkcfg_fw.h (77 tokens)
- code/include/Pchrono.h (823 tokens)
- code/include/Wchrono.h (777 tokens)
- code/include/Stimestamp.h (1145 tokens)
- code/include/Absolute_time.h (317 tokens)
- code/include/Itimeprovider.h (316 tokens)
- code/include/Timeprovider_null.h (152 tokens)
- code/source/Uclk.cpp (1479 tokens)
- code/source/Uclkmgr.cpp (828 tokens)
- code/source/Xclk.cpp (1329 tokens)
- code/source/Xclkcfg.cpp (1387 tokens)
- code/source/Pchrono.cpp (245 tokens)
- code/source/Stimestamp.cpp (800 tokens)

---

# Comprehensive Timing System Summary

This document provides a detailed analysis of the timing system, including the various chronometer implementations, time representation, management, synchronization, and integration with other system components.

## 1. Timing System Architecture Overview

The timing system consists of several key components that work together to provide time management capabilities:

### 1.1 Core Chronometer Types

The system implements multiple specialized chronometer types:

- **Chrono**: Base time-based chronometer (referenced but not fully defined in provided files)
- **Pchrono**: Position/distance-based chronometer
- **Xclk**: Cross-core clock that abstracts between time and position-based chronometers
- **Uclk**: User chronometer with command support
- **Wchrono**: Watchdog chronometer for timeout monitoring

### 1.2 Management Components

- **Uclkmgr**: Manages collections of user-defined timers
- **Absolute_time**: Handles system absolute time
- **Stimestamp**: Implements STANAG-compliant timestamps
- **Itimeprovider**: Interface for time provider abstraction

## 2. Time Representation and Standards

### 2.1 Absolute Time

```cpp
struct Absolute_time {
    // Returns number of UTC milliseconds since January 5-6, 1980 (GPS epoch)
    static int64 get_utc_ms();
    
    // Initializes system time with UTC milliseconds since GPS epoch
    static void init_utc_ms(const int64 utc_ms);
};
```

The system uses multiple time references:

- **GPS Epoch**: January 5-6, 1980 (midnight UTC) - used as the base reference for `Absolute_time`
- **STANAG Epoch**: January 1, 2000 - used for `Stimestamp`

### 2.2 STANAG Time Format

```cpp
struct Stimestamp {
    int64 value;   // Milliseconds since January 1st, 2000 using 5 bytes (rolls over if overflow)
    
    static Stimestamp get_current();
    static int64 time_between_ms(const Stimestamp& start, const Stimestamp& end);
    static Real time_between_secs(const Stimestamp& start, const Stimestamp& end);
    // Serialization/deserialization methods...
};
```

STANAG time is represented as:
- 5-byte unsigned integer (40 bits)
- Counts milliseconds since January 1st, 2000 UTC
- LSB represents 0.001 seconds
- Rolls over in 2034 when the 5-byte field is exceeded

Implementation details:
- Uses a mask (`stanag_time_mask`) with 40 least significant bits set to true
- Calculates offset from GPS epoch: `stanag_start_ms = (Ku32::week_ms * stanag_start_week) + stanag_start_tow_ms`
- Where `stanag_start_week = 1042U` and `stanag_start_tow_ms = 518400000U`

## 3. Chronometer Implementations

### 3.1 Position Chronometer (Pchrono)

```cpp
class Pchrono {
public:
    Pchrono();
    void enable_uh(const Rv3& uh0);
    void disable_uh();
    const Maverick::Irvector3& get_uh() const;
    void tic();
    Real toc() const;
    void cancel();
    bool ongoing() const;
private:
    bool on;                    // On going enabled flag
    Apos_data pos0;             // Initial position
    bool use_uh;                // Make use of uh if true
    Maverick::Rvector3 uh;      // Vector to compare with
};
```

The `Pchrono` class measures distance or position changes rather than time:

- **Initialization**: Starts with `on=false` and `use_uh=false`
- **Direction Control**:
  - `enable_uh()`: Sets a direction vector for measuring distance along a specific axis
  - `disable_uh()`: Measures total Euclidean distance in any direction
- **Operation**:
  - `tic()`: Records current position as the starting point
  - `toc()`: Returns distance traveled since `tic()` was called
    - If `use_uh=true`: Returns dot product of displacement with direction vector
    - If `use_uh=false`: Returns Euclidean norm of displacement vector
  - `cancel()`: Stops the chronometer
  - `ongoing()`: Returns whether the chronometer is active

### 3.2 Cross-Core Clock (Xclk)

```cpp
class Xclk {
public:
    explicit Xclk(const Xclkcfg& cfg0);
    bool step();
    void tic();
    void tic(Real t0);
    Real toc() const;
    void cancel();
    bool ongoing() const;
    void on_change_type();
private:
    Chrono t;                // Time-based chronometer instance
    Pchrono p;               // Distance-based chronometer instance
    const Xclkcfg& cfg;      // Cross-core clock configuration reference
};
```

The `Xclk` class provides a unified interface for both time-based and position-based chronometers:

- **Configuration**: Uses `Xclkcfg` to determine behavior
- **Type Selection**: Can operate as:
  - `type_time`: Standard time-based chronometer
  - `type_distance`: Position-based chronometer without direction constraint
  - `type_vector`: Position-based chronometer with direction constraint
- **Periodic Behavior**: Supports different periodic modes:
  - `pcmd_disable`: No periodic behavior
  - `pcmd_fixed_period`: Constant period (delayed reset makes next period shorter)
  - `pcmd_fixed_delay`: Maintains minimum time between resets
- **Operation**:
  - `tic()`: Starts the appropriate chronometer based on configuration
  - `toc()`: Returns elapsed time or distance
  - `step()`: Advances the clock and handles periodic resets
  - `on_change_type()`: Handles switching between chronometer types

### 3.3 User Chronometer (Uclk)

```cpp
class Uclk {
public:
    explicit Uclk(Rvar rv);
    bool step();
    void cset(Base::Lossy_error& str);
    void cget(Base::Lossy& str) const;
private:
    typedef Uint16 Cmdmsk;
    static const Cmdmsk rstmsk = 0x01;  // Reset command mask
    static const Cmdmsk runmsk = 0x02;  // Run command mask
    static const Cmdmsk prdmsk = 0x04;  // Periodic command mask
    static const Cmdmsk typmsk = 0x08;  // Type command mask
    
    enum Cmd_run {
        rcmd_stop = 0,          // Stop chronometer
        rcmd_run  = 1,          // Set running mode
        rcmd_max  = 2           // Leave run mode unchanged
    };
    
    Xclkcfg xconfig;        // Configuration settings
    Xclk com_xclk;          // Command for the user chronometer
    Cmdmsk cmsk;            // Command mask for managing the chronometer
    Bsp::Hrvar value;       // Current value of the chronometer
};
```

The `Uclk` class provides a user-configurable chronometer with command support:

- **Command Masks**: Uses bit flags to control behavior:
  - `rstmsk (0x01)`: Reset command
  - `runmsk (0x02)`: Run command
  - `prdmsk (0x04)`: Periodic command
  - `typmsk (0x08)`: Type command
- **Configuration**: Uses `Xclkcfg` for settings and `Xclk` for implementation
- **Value Storage**: Maintains current value in `Bsp::Hrvar value`
- **Operation**:
  - `step()`: Advances the chronometer and updates its value
  - `cset()`: Deserializes configuration from PDIC
  - `cget()`: Serializes configuration to PDIC

### 3.4 Watchdog Chronometer (Wchrono)

```cpp
template<typename TOK>
class Twchrono : public Chrono {
public:
    explicit Twchrono(Real tout0);
    Twchrono(Real tout0, Bvar bv);
    bool watch();
    bool is_ok() const;
    void set_nok();
    void set_timeout(Real t);
private:
    Real timeout;   // Timeout to check if watchdog okay
    TOK ok;         // Okay set handler
};

typedef Twchrono<Txet<bool> > Wchrono;      // Watchdog with bool type
typedef Twchrono<Bvar_rcwd> Wchronovar;     // Watchdog with Bvar type
```

The `Wchrono` class implements a watchdog timer for detecting timeouts:

- **Timeout Management**: Monitors if elapsed time exceeds a specified timeout
- **Status Reporting**: Can report status via boolean or `Bvar` variable
- **Operation**:
  - `watch()`: Checks if watchdog has triggered (returns true if not triggered)
  - `is_ok()`: Returns current status
  - `set_nok()`: Manually sets watchdog to not-okay state
  - `set_timeout()`: Changes the timeout threshold

## 4. Timer Management

### 4.1 User Clock Manager (Uclkmgr)

```cpp
class Uclkmgr : private Array<Uclk> {
public:
    Uclkmgr();
    void step();
    void cset(Base::Lossy_error& str);
    void cget(Base::Lossy& str) const;
    bool timer_event(Uint32 id) const;
private:
    static const Uint16 uclk_sz = 10;    // User clock array maximum valid range
    Uint32 emask;                        // Timer event mask (LSB is timer 0)
};
```

The `Uclkmgr` class manages a collection of user-defined timers:

- **Timer Collection**: Maintains an array of up to 10 `Uclk` instances
- **Event Tracking**: Uses a bit mask (`emask`) to track which timers have triggered events
- **Operation**:
  - `step()`: Advances all timers and updates the event mask
  - `timer_event(id)`: Checks if a specific timer has triggered an event
  - `cset()`: Deserializes timer configuration
  - `cget()`: Serializes timer configuration

### 4.2 Time Provider Abstraction

```cpp
class Itimeprovider {
public:
    virtual Uint64 get_current_time() const = 0;
protected:
    Itimeprovider();
    ~Itimeprovider();
};

class Timeprovider_null : public Itimeprovider {
public:
    virtual inline Uint64 get_current_time() const { return 0; }
};
```

The system provides an abstract interface for time providers:

- **Interface**: `Itimeprovider` defines the common interface
- **Null Implementation**: `Timeprovider_null` provides a dummy implementation for testing

## 5. Configuration Management

### 5.1 Cross-Core Clock Configuration (Xclkcfg)

```cpp
struct Xclkcfg {
    enum Cmd_period {
        pcmd_disable      = 0,  // Period feature disabled
        pcmd_fixed_period = 1,  // Periodic, constant period
        pcmd_fixed_delay  = 2,  // Holds time between resets
        pcmd_max          = 3   // Maximum periodic modes
    };
    
    enum Type {
        type_time          = 0, // Time-based clock
        type_distance      = 1, // Distance-based clock
        type_vector        = 2, // Vector-based clock
        type_max           = 3  // Maximum clock types
    };

    Cmd_period pmode;      // Optional period mode change
    Rv3 uh;                // Direction in case of position chrono
    Real period_s;         // Period in seconds for periodic behavior
    Type type;             // Type of chrono (time, vector, distance)
    
    // Serialization/deserialization methods...
};
```

The `Xclkcfg` structure defines configuration for cross-core clocks:

- **Period Modes**:
  - `pcmd_disable`: No periodic behavior
  - `pcmd_fixed_period`: Constant period with adjustment for delayed resets
  - `pcmd_fixed_delay`: Maintains minimum separation between resets
- **Clock Types**:
  - `type_time`: Standard time-based chronometer
  - `type_distance`: Position-based chronometer without direction constraint
  - `type_vector`: Position-based chronometer with direction constraint
- **Direction Vector**: `uh` specifies direction for vector-based chronometers
- **Period**: `period_s` defines the period in seconds for periodic behavior

## 6. Functional Behavior and Logic

### 6.1 Time Measurement and Tracking

The system provides multiple mechanisms for time measurement:

1. **Absolute Time Tracking**:
   - `Absolute_time::get_utc_ms()`: Returns UTC milliseconds since GPS epoch
   - `Stimestamp::get_current()`: Returns STANAG-compliant timestamp

2. **Relative Time Measurement**:
   - `Chrono`: Measures elapsed time
   - `Pchrono`: Measures elapsed distance or position change
   - `Xclk`: Abstracts between time and position measurements

3. **Periodic Timing**:
   - Fixed period mode: Maintains constant period length
   - Fixed delay mode: Ensures minimum time between events

### 6.2 Watchdog Functionality

The watchdog system provides timeout detection:

1. **Initialization**:
   ```cpp
   Wchrono watchdog(5.0);  // 5-second timeout
   ```

2. **Monitoring**:
   ```cpp
   if (!watchdog.watch()) {
       // Handle timeout condition
   }
   ```

3. **Manual Control**:
   ```cpp
   watchdog.set_nok();  // Force watchdog to triggered state
   watchdog.set_timeout(10.0);  // Change timeout to 10 seconds
   ```

### 6.3 User Timer Management

The user timer system allows for multiple configurable timers:

1. **Timer Creation**:
   ```cpp
   Uclkmgr timers;  // Creates array of 10 user timers
   ```

2. **Timer Advancement**:
   ```cpp
   timers.step();  // Advances all timers and updates event mask
   ```

3. **Event Detection**:
   ```cpp
   if (timers.timer_event(3)) {
       // Timer 3 has triggered an event
   }
   ```

## 7. Time Synchronization and Conversion

### 7.1 Time Standard Conversions

The system handles conversions between different time standards:

1. **GPS to STANAG Conversion**:
   ```cpp
   // Milliseconds difference between STANAG start and GPS start
   static const int64 stanag_start_ms = static_cast<int64>((Ku32::week_ms * stanag_start_week) + stanag_start_tow_ms);
   ```

2. **STANAG Time Calculations**:
   ```cpp
   // Calculate time between two STANAG timestamps
   int64 ms_diff = Stimestamp::time_between_ms(start_time, end_time);
   Real sec_diff = Stimestamp::time_between_secs(start_time, end_time);
   ```

### 7.2 Timestamp Serialization

The system supports multiple serialization formats for timestamps:

1. **U16stream Format**:
   ```cpp
   void Stimestamp::cset(U16stream_r& str) {
       value = str.get_uint64();
   }
   
   void Stimestamp::cget(U16stream_w& str) const {
       str.put_uint64(value);
   }
   ```

2. **U8stream Format (5-byte encoding)**:
   ```cpp
   void Stimestamp::cset(U8istream& str) {
       value = str.get_uint64_be(time_stamp_bytes_sz);  // 5 bytes
   }
   
   void Stimestamp::cget(U8ostream& str) const {
       str.put_uint64_be(value, time_stamp_bytes_sz);  // 5 bytes
   }
   ```

3. **Lossy Format**:
   ```cpp
   void Stimestamp::cset(Lossy& str) {
       str.get_uint64(*reinterpret_cast<Uint64*>(&value));
   }
   
   void Stimestamp::cget(Lossy& str) const {
       str.put_uint64(value);
   }
   ```

## 8. Integration with Other Components

### 8.1 Task Management Integration

The timing system integrates with task management through:

1. **Periodic Timer Events**:
   - `Uclkmgr::step()`: Updates all timers and generates events
   - `Uclkmgr::timer_event()`: Allows tasks to check for timer events

2. **Watchdog Monitoring**:
   - `Wchrono::watch()`: Allows tasks to check for timeout conditions

### 8.2 Position System Integration

The position-based chronometers integrate with the position system:

1. **Position Tracking**:
   ```cpp
   void Pchrono::tic() {
       pos0.copynr(Vpuposrd::get_pos());  // Records current position
       on = true;
   }
   ```

2. **Distance Calculation**:
   ```cpp
   Real Pchrono::toc() const {
       if(on) {
           Maverick::Rvector3 drh;
           Vpuposrd::get_rel_pos(pos0, drh);  // Gets position relative to starting point
           res = (use_uh) ? uh.dot(drh) : drh.norm2();  // Calculates distance
       }
       return res;
   }
   ```

## 9. File-by-File Breakdown

### 9.1 Uclk.h/cpp
Defines the user chronometer class with command support. Provides functionality to manage user-defined timers with configurable behavior including reset, run/stop, periodic operation, and type selection.

### 9.2 Uclkmgr.h/cpp
Manages a collection of user-defined timers. Provides methods to advance all timers, track timer events, and serialize/deserialize timer configurations.

### 9.3 Xclk.h/cpp
Implements the cross-core clock that abstracts between time-based and position-based chronometers. Provides unified interface for starting, stopping, and querying chronometers regardless of their underlying type.

### 9.4 Xclkcfg.h/cpp
Defines configuration structure for cross-core clocks. Includes settings for period mode, clock type, direction vector, and period duration.

### 9.5 Pchrono.h/cpp
Implements position-based chronometer that measures distance or position changes. Supports direction-constrained and unconstrained measurements.

### 9.6 Wchrono.h
Implements watchdog chronometer for timeout detection. Provides methods to check if elapsed time exceeds a specified timeout.

### 9.7 Stimestamp.h/cpp
Implements STANAG-compliant timestamp representation. Provides methods for timestamp creation, comparison, and serialization/deserialization.

### 9.8 Absolute_time.h
Defines interface for system absolute time management. Provides methods to get and set system time based on GPS epoch.

### 9.9 Itimeprovider.h and Timeprovider_null.h
Define interface for time provider abstraction and a null implementation for testing.

## 10. Cross-Component Relationships

### 10.1 Component Hierarchy

```
Itimeprovider
    └── Timeprovider_null

Chrono (base class)
    ├── Twchrono<TOK>
    │       ├── Wchrono
    │       └── Wchronovar
    └── Used by Xclk

Pchrono
    └── Used by Xclk

Xclk
    ├── Uses Chrono
    ├── Uses Pchrono
    └── Used by Uclk

Uclk
    ├── Uses Xclk
    ├── Uses Xclkcfg
    └── Used by Uclkmgr

Uclkmgr
    └── Manages Array<Uclk>

Absolute_time
    └── Used by Stimestamp
```

### 10.2 Data Flow

1. **Time Source → Absolute Time**:
   - External time source → `Itimeprovider::get_current_time()` → `Absolute_time::init_utc_ms()`

2. **Absolute Time → Timestamps**:
   - `Absolute_time::get_utc_ms()` → `Stimestamp::get_current()`

3. **User Commands → Timer Configuration**:
   - User commands → `Uclk::cset()` → `Xclkcfg` configuration → `Xclk` behavior

4. **Timer Events → Task Notification**:
   - `Uclkmgr::step()` → Updates `emask` → `Uclkmgr::timer_event()` → Task notification

## 11. Referenced Context Files

The following context files were helpful in understanding the timing system:

- **Chrono.h**: Referenced but not provided - appears to implement the base time-based chronometer
- **Apos_data.h**: Referenced for position data storage in Pchrono
- **Vpuposrd.h**: Referenced for position reading functionality in Pchrono
- **Lossy.h/Lossy_error.h**: Used for serialization/deserialization
- **Bsp::Hrvar**: Used for value storage in Uclk
- **Maverick::Rvector3/Irvector3**: Used for vector operations in Pchrono