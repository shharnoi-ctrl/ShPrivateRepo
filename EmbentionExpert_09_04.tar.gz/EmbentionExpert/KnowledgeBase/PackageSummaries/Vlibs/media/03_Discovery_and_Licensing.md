# Generated from:

- code/include/Discovery.h (667 tokens)
- code/include/Discover_dummy.h (405 tokens)
- code/include/Licdata.h (396 tokens)
- code/include/Licdata_fw.h (23 tokens)
- code/include/Ilicsrc.h (362 tokens)
- code/include/Ilicsrc_fw.h (78 tokens)
- code/include/Licsrc_null.h (294 tokens)
- code/include/PDI_loader.h (535 tokens)
- code/source/Discovery.cpp (2459 tokens)
- code/source/Discover_dummy.cpp (1080 tokens)
- code/source/Licdata.cpp (516 tokens)
- code/source/Licsrc_null.cpp (120 tokens)
- code/source/PDI_loader.cpp (583 tokens)

## With context from:

- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/media/04_Configuration_Management.md (4320 tokens)

---

# High-Fidelity Semantic Knowledge Graph: Discovery and Licensing Components in Media Library

## 1. Functional Behavior and Logic

### Discovery System Overview

The Media library implements a comprehensive device discovery system centered around the `Discovery` class, which handles the discovery protocol for Veronte devices. This system enables devices to:

1. **Respond to discovery requests** with essential initialization information
2. **Exchange system information** including version, time, configuration state, and license data
3. **Establish communication sessions** with unique identifiers
4. **Validate license status** through the license management system

### License Management System Overview

The license management system consists of:

1. **License Data Interface (`Ilicsrc`)**: Abstract interface for retrieving license data
2. **License Data Structure (`Licdata`)**: Container for license information including permissions, validity dates, and usage statistics
3. **Null License Implementation (`Licsrc_null`)**: Default implementation providing dummy license data

### PDI Loader Overview

The `PDI_loader` class provides functionality to:

1. **Load PDI (Parameter Data Item) files** from persistent storage
2. **Update system load state** variables
3. **Handle and commit errors** during the loading process

## 2. Control Flow and State Transitions

### Discovery Protocol Flow

The discovery protocol follows a request-response pattern:

| State | Trigger | Actions | Next State | Location |
|-------|---------|---------|------------|----------|
| Idle | Receive discovery request (`disc_request_arg`) | 1. Deserialize request<br>2. Extract PC time<br>3. Update system time<br>4. Increment session ID | Responding | `Discovery::on_rx()` |
| Responding | Discovery request processed | 1. Send discovery response<br>2. Include system info, license data, configuration CRCs | Idle | `Discovery::on_rx()` |

### Bootloader Discovery Flow (Simplified)

For bootloader mode, a simplified discovery flow is implemented in `Discover_dummy`:

| State | Trigger | Actions | Next State | Location |
|-------|---------|---------|------------|----------|
| Idle | Receive discovery request (`disc_request_arg`) | 1. Deserialize request<br>2. Extract time information<br>3. Increment session ID | Responding | `Discover_dummy::on_rx()` |
| Responding | Discovery request processed | 1. Send simplified discovery response<br>2. Include minimal system info | Idle | `Discover_dummy::on_rx()` |

### PDI Loading Flow

The PDI loading process follows this sequence:

| State | Trigger | Actions | Next State | Location |
|-------|---------|---------|------------|----------|
| Initial | `load()` called | 1. Set load state to `lst_ongoing`<br>2. Call configuration manager's load method | Loading | `PDI_loader::load()` |
| Loading | Configuration loading in progress | 1. Load PDI files based on desired mode<br>2. Track success/failure | Error Handling | `PDI_loader::load()` |
| Error Handling | Loading complete | 1. Check for errors<br>2. Commit errors if detected<br>3. Update load state if successful | Complete | `PDI_loader::load_priv()` |

## 3. Inputs and Stimuli

### Discovery Request Processing

The `Discovery` class processes discovery requests through its `on_rx()` method:

- **Input**: Discovery request message with argument `disc_request_arg`
- **Processing**:
  - Deserializes the message version information
  - Extracts PC time using `Ubxtime::discovery_uncompress()`
  - Updates system time through `pctime.init()`
  - Increments session request ID if the request is new
  - Sends a discovery response message
- **Location**: `Discovery::on_rx()` in `Discovery.cpp`

### Bootloader Discovery Request Processing

The `Discover_dummy` class processes simplified discovery requests:

- **Input**: Discovery request message with argument `disc_request_arg`
- **Processing**:
  - Deserializes the message version information
  - Extracts week and time-of-week information
  - Increments session request ID
  - Sends a simplified discovery response message
- **Location**: `Discover_dummy::on_rx()` in `Discover_dummy.cpp`

### PDI Loading Request Processing

The `PDI_loader` class processes loading requests:

- **Input**: Desired load mode (`lst_secure`, `lst_normal`, `lst_maintenance`)
- **Processing**:
  - Sets load state to `lst_ongoing`
  - Calls configuration manager's load method
  - Processes the result and handles errors
  - Updates load state if successful
- **Location**: `PDI_loader::load()` in `PDI_loader.cpp`

## 4. Outputs and Effects

### Discovery Response Generation

The `Discovery` class generates discovery responses through its `on_tx()` method:

- **Output**: Discovery response message with detailed system information
- **Content**:
  - Current discovery protocol version
  - System version information
  - PC time from the original request
  - Unique session request ID
  - System load state
  - Platform UID
  - Current PC time
  - Configuration CRCs (file and memory)
  - License status
  - Product UID
- **Effect**: Provides the requesting device with essential system information
- **Location**: `Discovery::on_tx()` in `Discovery.cpp`

### Bootloader Discovery Response Generation

The `Discover_dummy` class generates simplified discovery responses:

- **Output**: Simplified discovery response message
- **Content**:
  - Current discovery protocol version
  - Application ID and firmware version
  - Session request ID
  - Load state (always `lst_secure`)
  - System UID
- **Effect**: Provides minimal system information in bootloader mode
- **Location**: `Discover_dummy::on_tx()` in `Discover_dummy.cpp`

### PDI Loading Effects

The `PDI_loader` class produces these effects:

- **Output**: Updated load state and error information
- **Effects**:
  - Updates `vu_cfg_loadst` system variable with the current load state
  - Commits errors through `PDIcheck::commit()` if loading fails
  - Returns the final load state to the caller
- **Location**: `PDI_loader::load()` and `PDI_loader::load_priv()` in `PDI_loader.cpp`

## 5. Parameters and Configuration

### Discovery Protocol Parameters

1. **Protocol Version**:
   - Request version: `current_mver_request = {0, 0}`
   - Response version: `current_mver_response = {0, 1}`
   - Defined in `Discovery.cpp` and `Discover_dummy.cpp`

2. **Discovery Arguments**:
   - Request argument: `disc_request_arg = 0x00`
   - Response argument: `disc_response_arg = 0x01`
   - Defined in `Discovery.cpp` and `Discover_dummy.cpp`

3. **System Configuration State**:
   - File CRC: `hcfg_gfcrc_l` and `hcfg_gfcrc_h`
   - Memory CRC: `hcfg_gmcrc_l` and `hcfg_gmcrc_h`
   - Load state: `hcfg_lst`
   - Defined in `Discovery.h`

### License Data Parameters

1. **License Failure Status**:
   - `fail_none = 0x00`: No failure
   - `fail_id = 0x01`: ID failure
   - `fail_date = 0x02`: Date failure
   - `fail_zone = 0x04`: Zone failure
   - `fail_format = 0x08`: Format failure
   - Defined in `Licdata.h`

2. **License Data Fields**:
   - `fail`: License failure status
   - `p_flags`: Permission flags
   - `t_start`: License start date
   - `t_end`: License end date
   - `total_flight_time`: Total flight time
   - `total_flight_distance`: Total flight distance
   - Defined in `Licdata.h`

### PDI Loading Parameters

1. **Load States**:
   - `lst_secure = 0`: Secure mode loaded (Bootloader)
   - `lst_normal = 1`: Loaded successfully
   - `lst_maintenance = 2`: Loaded in maintenance mode
   - `lst_ongoing = 3`: Load processing
   - `lst_failed = 4`: Loaded normal mode with errors
   - Referenced in `PDI_loader.h`

## 6. Error Handling and Contingency Logic

### Discovery Protocol Error Handling

1. **Version Compatibility Check**:
   - Checks if the major version of the request matches the expected version
   - Only processes time information if versions are compatible
   - Location: `Discovery::on_rx()` in `Discovery.cpp`

2. **Session Request Tracking**:
   - Compares received PC time with last received time
   - Increments session request ID only for new requests
   - Helps distinguish between new requests and retries
   - Location: `Discovery::on_rx()` in `Discovery.cpp`

### License Validation Error Handling

1. **License Failure Status**:
   - `Licdata` structure includes a `fail` field to track license validation failures
   - Different failure types are defined as constants (`fail_id`, `fail_date`, etc.)
   - Location: `Licdata.h`

2. **Null License Fallback**:
   - `Licsrc_null` provides a fallback implementation that returns dummy license data
   - Used when no valid license source is available
   - Location: `Licsrc_null.cpp`

### PDI Loading Error Handling

1. **Load State Tracking**:
   - Sets load state to `lst_ongoing` during loading
   - Updates to final state based on loading result
   - Location: `PDI_loader::load()` in `PDI_loader.cpp`

2. **Error Commitment**:
   - Detects loading failures by checking if result is `lst_failed` or `lst_ongoing`
   - Commits appropriate errors through `PDIcheck::commit()`
   - Different errors for secure mode (`err_cfgmgr_load_secure`) and normal mode (`err_cfgmgr_finit`)
   - Location: `PDI_loader::load_priv()` in `PDI_loader.cpp`

## 7. File-by-File Breakdown

### Discovery.h / Discovery.cpp

Defines and implements the `Discovery` class for handling the discovery protocol:
- Responds to discovery requests with system information
- Manages session IDs for unique request identification
- Serializes and deserializes discovery messages
- Integrates with license management and configuration systems

Key methods:
- `on_rx()`: Processes discovery requests
- `on_tx()`: Generates discovery responses

### Discover_dummy.h / Discover_dummy.cpp

Defines and implements the `Discover_dummy` class for simplified discovery in bootloader mode:
- Provides minimal discovery functionality
- Responds with essential system information
- Uses simplified message format

Key methods:
- `on_rx()`: Processes discovery requests in bootloader mode
- `on_tx()`: Generates simplified discovery responses

### Licdata.h / Licdata.cpp

Defines and implements the `Licdata` structure for license information:
- Stores license status, permissions, and validity dates
- Provides serialization functionality for discovery protocol

Key methods:
- `cget()`: Serializes license data for transmission

### Ilicsrc.h / Ilicsrc_fw.h

Defines the abstract interface `Ilicsrc` for license data retrieval:
- Provides a virtual method for getting license data
- Enables different license source implementations

Key methods:
- `get_licdata()`: Virtual method for retrieving license data

### Licsrc_null.h / Licsrc_null.cpp

Implements the `Licsrc_null` class as a null implementation of `Ilicsrc`:
- Provides dummy license data when no valid license is available
- Implements the `get_licdata()` method to return default values

Key methods:
- `get_licdata()`: Returns default license data

### PDI_loader.h / PDI_loader.cpp

Defines and implements the `PDI_loader` class for loading PDI files:
- Loads configuration from persistent storage
- Updates system load state
- Handles and commits errors during loading

Key methods:
- `load()`: Loads configuration based on desired mode
- `load_priv()`: Handles error checking and commitment

## 8. Cross-Component Relationships

### Discovery and License Management Integration

The `Discovery` class integrates with the license management system:
- Receives an `Ilicsrc` reference in its constructor
- Calls `get_licdata()` to retrieve license information
- Includes license data in discovery responses
- Location: `Discovery::on_tx()` in `Discovery.cpp`

### Discovery and Configuration Management Integration

The `Discovery` class integrates with the configuration management system:
- Accesses configuration CRCs through system variables
- Includes file CRC (`gfcrc`) and memory CRC (`gmcrc`) in discovery responses
- Includes load state in discovery responses
- Location: `Discovery::on_tx()` in `Discovery.cpp`

### PDI Loader and Configuration Management Integration

The `PDI_loader` class integrates with the configuration management system:
- Calls the configuration manager's `load()` method
- Processes the loading result
- Updates the load state system variable
- Location: `PDI_loader::load()` in `PDI_loader.cpp`

### License Management Component Relationships

The license management components relate as follows:
- `Ilicsrc`: Abstract interface for license data retrieval
- `Licdata`: Structure for storing license information
- `Licsrc_null`: Concrete implementation of `Ilicsrc`
- `Discovery`: Consumer of license data through `Ilicsrc`

## 9. Discovery Protocol Message Format

### Discovery Request Format

| Field | Type | Description | Notes |
|-------|------|-------------|-------|
| `arg` | Uint16 | Discovery argument | Must be `disc_request_arg` (0) |
| `mver` | Version | Discovery protocol version | Contains major and minor version |
| `pctime` | Base::Ubxtime | PC time of requesting device | Only included if major version matches |

### Discovery Response Format

| Field | Type | Description | Notes |
|-------|------|-------------|-------|
| `arg` | Uint16 | Discovery argument | Set to `disc_response_arg` (1) |
| `curr_ver` | Version | Current discovery version | Set to `current_mver_response` |
| `sys_ver` | Base::Sysver | System version information | Application ID and version |
| `pctime_last` | Base::Ubxtime | Last PC time received | From the request |
| `session_req` | Uint16 | Current session ID | Incremented for each new request |
| `hcfg_lst` | Uint16 | Load state | Current system load state |
| `uid` | Base::Uid | Platform UID | System identifier |
| `pctime` | Base::Ubxtime | Current PC time | Current system time |
| `gfcrc` | Uint32 | Global file CRC | Configuration file CRC |
| `lic` | Licdata | License status | License information |
| `gmcrc` | Uint32 | Global memory CRC | Configuration memory CRC |
| `uid64` | Uint64 | System UID | System identifier (64-bit) |

### Bootloader Discovery Response Format (Simplified)

| Field | Type | Description | Notes |
|-------|------|-------------|-------|
| `arg` | Uint16 | Discovery argument | Set to `disc_response_arg` (1) |
| `curr_ver` | Version | Current discovery version | Set to `current_mver_response` |
| `app_id` | Uint16 | Application ID | From system version |
| `ver` | Version | Firmware version | From system version |
| `time` | Uint16, Uint64 | Time fields | Set to zero |
| `session_req` | Uint16 | Current session ID | Incremented for each new request |
| `st` | Uint16 | Load state | Current load state |
| `padding` | Uint8[82] | Padding | Set to zeros |
| `uid` | Uint64 | System UID | System identifier |

## 10. License Data Format

### License Data Serialization Format

| Field | Type | Description | Notes |
|-------|------|-------------|-------|
| `fail` | Uint16 | License failure status | Combination of failure flags |
| `p_flags` | Base::Permission | Permission flags | Serialized through `Permission::cget()` |
| `t_start` | Base::Ubxtime | License start date | Serialized through `Ubxtime::discovery_compress()` |
| `t_end` | Base::Ubxtime | License end date | Serialized through `Ubxtime::discovery_compress()` |
| `total_flight_time` | Uint64 | Total flight time | Usage statistic |
| `total_flight_distance` | Uint64 | Total flight distance | Usage statistic |

## Referenced Context Files

- **04_Configuration_Management.md**: Provided essential information about the configuration management system that the discovery and PDI loader components interact with. Specifically, it helped understand:
  - How configuration CRCs are computed and managed
  - The structure of the configuration loading process
  - The relationship between file and memory configurations
  - The error handling mechanisms in the configuration system

## Conclusion

The discovery and licensing components in the Media library form a comprehensive system for device discovery, license validation, and configuration loading. The discovery protocol enables devices to exchange essential system information, including version, time, configuration state, and license data. The license management system provides a flexible interface for retrieving and validating license information. The PDI loader component integrates with the configuration management system to load configuration data from persistent storage.

These components work together to provide a robust foundation for device initialization and communication, ensuring that devices can discover each other, validate licenses, and load appropriate configurations. The system handles various error conditions gracefully and provides detailed information about the system state through the discovery protocol.