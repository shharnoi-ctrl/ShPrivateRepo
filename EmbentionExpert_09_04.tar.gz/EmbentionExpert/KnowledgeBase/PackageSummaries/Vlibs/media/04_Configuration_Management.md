# Generated from:

- code/include/Cfgmgr.h (11414 tokens)
- code/include/Cfgmgr_fw.h (22 tokens)
- code/include/Cfgcrcpub.h (574 tokens)
- code/include/Icfgcrc.h (515 tokens)
- code/include/Cfgcrc_async.h (858 tokens)
- code/source/Cfgmgr.cpp (28167 tokens)
- code/source/Cfgcrcpub.cpp (440 tokens)
- code/source/Cfgcrc_async.cpp (1348 tokens)

## With context from:

- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/media/05_File_System_Core.md (4185 tokens)

---

# High-Fidelity Semantic Knowledge Graph: Configuration Management System in Media Library

## 1. Functional Behavior and Logic: Configuration Manager Overview

The Media library provides a comprehensive configuration management system centered around the `Cfgmgr` class. This system handles configuration loading, saving, and synchronization between memory and files, with support for different types of configuration elements.

### Core Responsibilities

1. **Configuration Management**:
   - Manages configuration data through PDI (Parameter Data Item) files in the file system
   - Handles three distinct types of configuration elements:
     - **Configuration PDIFs**: Have dedicated files in the file system
     - **Operation PDIFs**: Can only load/save their dedicated tunables through temporary files
     - **Command PDIFs**: Can only load/save through tunables (no file persistence)
   - Tracks configuration changes with a counter (`changed_counter`)

2. **Configuration Synchronization**:
   - Maintains CRC values for both file-based configurations (`gfcrc`) and memory-based configurations (`gmcrc`)
   - Detects and handles configuration changes between memory and files
   - Provides interfaces to retrieve global CRC values

3. **Asynchronous Operations**:
   - Implements a state machine for non-blocking configuration operations
   - Supports cross-core file operations through step-based execution
   - Handles timeouts and error recovery

### Key Components

1. **Configuration Manager (`Cfgmgr`)**:
   - Main class implementing configuration management functionality
   - Implements `Stanag::Stanag_msg` for message handling
   - Implements `Base::Istep` for step-based execution
   - Implements `Icfgcrc` for CRC management

2. **CRC Management**:
   - `Cfgcrc_async`: Handles asynchronous computation of global CRCs
   - `Cfgcrcpub`: Publishes global CRC values to system variables
   - `Icfgcrc`: Interface for retrieving global CRC values

3. **Configuration Interfaces**:
   - `Base::Itunable`: Interface for synchronous configuration objects
   - `Base::Itunable_async`: Interface for asynchronous configuration objects
   - `Base::Ideserializable`: Interface for synchronous deserialization
   - `Base::Ideserializable_async`: Interface for asynchronous deserialization

## 2. Control Flow and State Transitions: Configuration Operations

### Main State Machine

The `Cfgmgr` class implements a complex state machine for asynchronous configuration operations:

| State | Trigger | Actions | Next State | Location |
|-------|---------|---------|------------|----------|
| `st_idle` | Request to load/save | Initialize operation | `st_open_file` | `start_load()`, `start_save()`, etc. |
| `st_performing_cset` | Deserialization request | Deserialize data to tunable | `st_idle` or `st_comp_gcrc` | `step_cset()` |
| `st_open_file` | File open request | Open file asynchronously | `st_save_file` or `st_load_file` | `step_open()` |
| `st_save_file` | File opened for writing | Write data to file | `st_close_file` | `step_save()` |
| `st_load_file` | File opened for reading | Read data from file | `st_close_file` | `step_load()` |
| `st_close_file` | File operation complete | Close file and update CRCs | `st_init_gcrc` or `st_idle` | `step_close()` |
| `st_init_gcrc` | CRC update needed | Initialize global CRC computation | `st_comp_gcrc` | `step_init_gcrc()` |
| `st_comp_gcrc` | CRC computation in progress | Compute global CRC | `st_idle` | `step_comp_gcrc()` |
| `st_send_crc` | CRC sync request | Send CRC state asynchronously | `st_idle` | `send_sync_state_async()` |

### Asynchronous Deserialization State Machine

For handling asynchronous deserialization during file loading:

| State | Trigger | Actions | Next State | Location |
|-------|---------|---------|------------|----------|
| `ast_idle` | Load operation | Initialize deserialization | `ast_load` | `step_load()` |
| `ast_load` | File read complete | Read file data | `ast_version` or `st_close_file` | `step_load()` |
| `ast_version` | Data available | Deserialize version information | `ast_data` | `step_load()` |
| `ast_data` | Version deserialized | Deserialize configuration data | `ast_idle` | `step_load()` |

### CRC Synchronization State Machine

For handling asynchronous CRC synchronization:

| State | Trigger | Actions | Next State | Location |
|-------|---------|---------|------------|----------|
| `st_init` | Sync request | Initialize synchronization | `st_cfgs_req` | `send_sync_state_async()` |
| `st_cfgs_req` | Initialization complete | Construct configuration groups | `st_crcs` | `step_sync_cfgs()` |
| `st_crcs` | Groups constructed | Append CRC values | `st_idle` | `step_sync_crcs()` |

## 3. Inputs and Stimuli

### Configuration Commands

The `Cfgmgr` class processes various commands through its `on_rx()` method:

| Command ID | Name | Description | Processing |
|------------|------|-------------|------------|
| 2 | `cfg_set_arg` | Set configuration for a PDI | Deserializes data into tunable |
| 3 | `cfg_get_arg` | Get configuration for a PDI | Serializes tunable data as response |
| 4 | `cfg_save_arg` | Save tunable to its PDI file | Initiates save operation |
| 5 | `cfg_load_arg` | Load tunable from its PDI file | Initiates load operation |
| 6 | `cfg_save_op_arg` | Save operation tunable to temporary file | Initiates operation save |
| 7 | `cfg_load_op_arg` | Load operation tunable from temporary file | Initiates operation load |
| 8 | `cfg_query_arg` | Query configuration IDs | Returns available configuration IDs |
| 10 | `cfg_get_sync_arg` | Get synchronization data (CRC) | Returns CRC information |
| 11 | `cfg_maxcfg_arg` | Query maximum number of configurables | Returns `Cfg::cfg_all` value |

### Configuration Registration

The `Cfgmgr` class provides methods to register different types of configuration elements:

1. **Synchronous Configurables**:
   ```cpp
   void add(Base::Cfg::Id id0, Base::Itunable& tun0);
   void add(Base::Cfg::Id id0, Base::Ideserializable& des0);
   ```

2. **Asynchronous Configurables**:
   ```cpp
   void add(Base::Cfg::Id id0, Base::Itunable_async& tun0);
   void add(Base::Cfg::Id id0, Base::Ideserializable_async& des0);
   ```

3. **Special Configurables**:
   ```cpp
   void add_meta(Base::Cfg::Id id0);
   void add_cmd(Base::Cfg::Id id0, Base::Itunable_async& tun0);
   void add_cmd(Base::Cfg::Id id0, Base::Itunable& tun0);
   ```

### Configuration Loading Modes

The `load()` method supports different loading modes:

| Mode | Description | Behavior |
|------|-------------|----------|
| `lst_secure` | Secure loading | Load all PDIFs, abort on error |
| `lst_normal` | Normal loading | Load all PDIFs, continue on error |
| `lst_maintenance` | Maintenance loading | Load only CRC values |

## 4. Outputs and Effects

### Configuration Responses

The `Cfgmgr` class generates various responses through its `on_tx()` method:

1. **Save Results**:
   - Sent after save operations complete
   - Includes configuration ID and success status
   - Generated by `send_save_result()` and `send_save_result0()`

2. **Load Results**:
   - Sent after load operations complete
   - Includes configuration ID and success status
   - Generated by `send_load_result()` and `send_load_result0()`

3. **Operation Results**:
   - Sent after operation save/load complete
   - Includes request ID, configuration ID, and success status
   - Generated by `send_save_op_result()`, `send_load_op_result()`, etc.

4. **Configuration Data**:
   - Sent in response to get requests
   - Includes serialized configuration data
   - Generated by `send_config()`

5. **Synchronization Data**:
   - Sent in response to sync requests
   - Includes CRC values for configurations
   - Generated by `send_sync_state_async()`

### File System Effects

1. **File Creation/Modification**:
   - Save operations create or modify PDI files
   - Files contain serialized configuration data with version information
   - CRC values are computed and stored

2. **File Reading**:
   - Load operations read PDI files
   - Data is deserialized into tunable objects
   - CRC values are validated

3. **Temporary Files**:
   - Operation save/load uses temporary files
   - Identified by `tmp_uid` unique identifier
   - Used for transient configuration data

## 5. Parameters and Configuration

### Core Configuration Parameters

1. **Block Size**:
   - Configured through constructor parameter `buf`
   - Determines the size of the serialization buffer

2. **File Permissions**:
   - Configured through constructor parameter `fsperm0`
   - Controls which configurations can be modified

3. **Unique Identifiers**:
   - `tmp_uid`: Unique identifier for temporary files
   - Used for operation save/load operations

4. **Timeouts**:
   - Various timeout values for blocking operations
   - Example: `timeout = 0.5F` for blocking file loads

### CRC Configuration

1. **CRC Preset**:
   - `CRCpreset::for_cfgsync()`: Standard CRC preset for configuration
   - Used for both file and memory CRC calculations

2. **CRC Computation Parameters**:
   - `Remain_async_crc`: Controls time allocation for CRC computation
   - Includes chrono reference, period, and margin values

## 6. Error Handling and Contingency Logic

### Error Detection

1. **File Operation Errors**:
   - Detected through `async_done_error` result codes
   - Tracked in `last_result` flag
   - Reported through response messages

2. **Timeout Errors**:
   - Detected through `Timeout::expired()` checks
   - Handled by `recover_from_tout()` method
   - Closes opened files and resets state machine

3. **CRC Validation Errors**:
   - Detected by comparing file and memory CRCs
   - Reported through `PDIcheck::commit()` calls
   - Tracked in error source (`err_src`)

4. **Deserialization Errors**:
   - Detected through `Lossy_error::is_ok()` checks
   - Reported through `PDIcheck::commit()` calls
   - Can trigger state transitions to error handling

### Recovery Mechanisms

1. **File Recovery**:
   - `fload_blocking_failed()`: Recovers from failed blocking loads
   - Closes opened files and resets state machine
   - Returns to idle state for next operation

2. **Partial Loading**:
   - `finit()`: Handles partial loading of configurations
   - Continues loading even if some configurations fail
   - Reports errors through `PDIcheck` system

3. **Timeout Recovery**:
   - `recover_from_tout()`: Handles timeout conditions
   - Closes opened files and resets state machine
   - Prevents resource leaks from abandoned operations

## 7. File-by-File Breakdown

### Cfgmgr.h

Defines the `Cfgmgr` class with:
- Core configuration management functionality
- State machines for asynchronous operations
- Methods for adding, loading, and saving configurations
- Message handling through `on_rx()` and `on_tx()`
- CRC management through `get_gfcrc()` and `get_gmcrc()`

Key structures:
- `Remain_async_crc`: Controls CRC computation timing
- `Itundes_wrap`: Wrapper for asynchronous deserialization
- State enumerations: `State`, `StateCRC`, `Astate`

### Cfgmgr_fw.h

Forward declaration of the `Cfgmgr` class for use in other headers.

### Cfgcrcpub.h

Defines the `Cfgcrcpub` class for publishing global CRC values:
- Implements `Base::Istep` for step-based execution
- Retrieves CRC values from `Icfgcrc` interface
- Publishes values to system variables (`Bsp::Huvar`)

### Icfgcrc.h

Defines the `Icfgcrc` interface for CRC management:
- `get_gfcrc()`: Retrieves global file CRC
- `get_gmcrc()`: Retrieves global memory CRC
- `get_last_changed_idx()`: Retrieves last changed configuration ID

### Cfgcrc_async.h

Defines the `Cfgcrc_async` class for asynchronous CRC computation:
- `init()`: Initializes CRC computation
- `compute()`: Performs incremental CRC computation
- `has()`: Checks if configuration is included in CRC

### Cfgmgr.cpp

Implements the `Cfgmgr` class with:
- Helper classes: `Itunable_as_async`, `Ideserializable_as_async`, `Meta_async`, `Actionhelper`
- State machine implementation through `step()` and related methods
- Message handling through `on_rx()` and `on_tx()`
- File operations through `fload_blocking()`, `fload_crc_blocking()`, etc.
- CRC management through `compute_gfcrc_blocking()`, etc.

### Cfgcrcpub.cpp

Implements the `Cfgcrcpub` class with:
- Constructor that initializes system variables
- `step()` method that updates system variables with CRC values

### Cfgcrc_async.cpp

Implements the `Cfgcrc_async` class with:
- `init()` method for initializing CRC computation
- `has()` method for checking configuration inclusion
- `compute()` method for incremental CRC computation

## 8. Cross-Component Relationships

### Configuration Manager and File System

The `Cfgmgr` class interacts with the file system through:
- `Base::Ifile` interface for file operations
- `Ifspermission` interface for permission checking
- File operations: open, read, write, close
- CRC validation for file integrity

### Configuration Manager and Synchronization

The `Cfgmgr` class manages synchronization through:
- `Base::Cfgsync` for tracking configuration changes
- `Cfgcrc_async` for computing global CRCs
- Memory vs. file CRC comparison
- Modified state tracking

### Configuration Manager and Messaging

The `Cfgmgr` class handles messaging through:
- `Stanag::Stanag_msg` interface for message handling
- `Base::Imsg_sender` for sending responses
- Command processing in `on_rx()`
- Response formatting in `on_tx()`

### CRC Management Components

The CRC management components interact through:
- `Icfgcrc` interface implemented by `Cfgmgr`
- `Cfgcrc_async` used by `Cfgmgr` for computation
- `Cfgcrcpub` using `Icfgcrc` for publishing
- System variables (`Bsp::Huvar`) for exposing CRCs

## 9. Detailed Configuration Flow Analysis

### Configuration Loading Flow

1. **Initialization**:
   - Client calls `load(desired_mode)`
   - System determines loading strategy based on mode

2. **File Loading**:
   - For each configuration in `finit()`:
     - Check if configuration exists with `ftun_exists()`
     - Load configuration with `fload_blocking()` or `fload_crc_blocking()`
     - Handle errors through `PDIcheck::commit()`

3. **Synchronization**:
   - Update synchronization state with `cfg_sync.sync_all()`
   - Compute global file CRC with `compute_gfcrc_blocking()`
   - Set memory CRC equal to file CRC

4. **Error Recovery**:
   - If loading fails, call `fload_blocking_failed()`
   - Close opened files and reset state machine
   - Load CRCs in maintenance mode

### Configuration Saving Flow

1. **Initialization**:
   - Client calls `save_req(id)` or sends save command
   - System checks if operation can start with `is_startable()`

2. **Data Serialization**:
   - Serialize tunable data with `tun2str()`
   - Prepare file operation with `set_process()`

3. **File Writing**:
   - Open file with `step_open()`
   - Write data with `step_save()`
   - Close file with `step_close()`

4. **Synchronization**:
   - Update file CRC in `step_close0()`
   - Compute global CRC if needed
   - Send response with result

### CRC Computation Flow

1. **Initialization**:
   - Call `gcrc_async.init()` with appropriate type
   - Set state to `st_comp_gcrc`

2. **Computation**:
   - Call `gcrc_async.compute()` repeatedly
   - Process configurations incrementally
   - Update global CRC value

3. **Completion**:
   - Send response when computation completes
   - Update last changed index
   - Return to idle state

### Synchronization Flow

1. **Request Processing**:
   - Receive `cfg_get_sync_arg` command
   - Extract requested configurations
   - Set state to `st_send_crc`

2. **Configuration Processing**:
   - Process configurations in `step_sync_cfgs()`
   - Track modified configurations
   - Group configurations for efficient transfer

3. **CRC Processing**:
   - Compute CRCs for requested configurations in `step_sync_crcs()`
   - Group CRCs for efficient transfer
   - Send response with CRC data

## Conclusion

The configuration management system in the Media library provides a comprehensive solution for handling configuration data across different system components. It supports various types of configurations (standard, operation, command), manages synchronization between memory and files, and provides robust error handling and recovery mechanisms.

The system's state machine design allows for efficient asynchronous operations, while the CRC management components ensure data integrity and change tracking. The integration with the file system and messaging components creates a complete configuration management solution that can handle complex scenarios like cross-core operations, permission checking, and timeout recovery.