# Generated from:

- code/include/Logctrl.h (3157 tokens)
- code/include/Fdr.h (1418 tokens)
- code/include/Sampler.h (1548 tokens)
- code/source/Logctrl.cpp (12027 tokens)
- code/source/Fdr.cpp (2180 tokens)
- code/source/Sampler.cpp (3101 tokens)

## With context from:

- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/media/05_File_System_Core.md (4185 tokens)

---

# Logging and Diagnostics System in Media Library

This document provides a comprehensive analysis of the logging and diagnostics components in the Media library, focusing on the Logctrl, Fdr, and Sampler classes. These components work together to provide a robust logging infrastructure for system monitoring, debugging, and data collection.

## 1. Logctrl - Log Control System

### Overview and Responsibilities

The `Logctrl` class serves as the primary controller for logging operations within the file system. It implements the `Base::Ilogcontrol` interface and provides capabilities to:

- Manage log files within a specific partition
- Start and stop logging sessions
- Write data to logs with appropriate headers
- Delete log files
- Maintain indexes of log files for efficient access
- Handle file system interactions asynchronously

### Key Components and Structure

#### Core Attributes

- `part`: Partition identifier where logs are stored
- `fdata`: File handler for log data
- `session`: Session information for logging
- `header_id`: Header unique identifier
- `first_file` and `last_file`: References to first and last file IDs for current session
- `max_n_files`: Maximum number of files allowed in the partition
- `curr_file_index`: Current log file being written
- `last_written`: Count of last written bytes
- `last_file_date`: Timestamp of the last written file
- `index_file` and `index_aux`: File handlers for index management
- `file_helper`: Optional step helper for file operations

#### State Machines

The `Logctrl` class implements two state machines:

1. **Main FSM** (`Status` enum):
   - `st_idle`: No active operation
   - `st_start_session`: Starting a new logging session
   - `st_stop_session`: Stopping the current session
   - `st_write_header`: Writing session header
   - `st_write_header2`: Flushing session header
   - `st_write_data`: Writing log data
   - `st_write_flush`: Flushing data to disk
   - `st_write_stop_ss`: Stopping session while writing (when file is full)
   - `st_deleting`: Deleting log files
   - `st_reindexing`: Closing and updating index

2. **Reindexing FSM** (`Reindexing_status` enum):
   - `rst_index_opening`: Opening index file
   - `rst_index_write_version`: Writing version to index file
   - `rst_index_opening_aux`: Opening a log file
   - `rst_index_write`: Writing data to index file
   - `rst_index_closing_aux`: Closing a log file
   - `rst_index_next`: Moving to next file index
   - `rst_index_closing`: Closing index file
   - `rst_index_error`: Error handling state

#### Session Data Structure

The `Session_data` inner structure manages metadata for each log file:
- `fileid`: ID of the file in the log partition
- `time`: GPS timestamp when the file was created
- `size`: Size in bytes (zero indicates log does not exist)
- Methods for serialization (`cget`) and deserialization (`cset`)

### Control Flow

#### Initialization

The `Logctrl` class provides two constructors:
1. For existing log partitions: Initializes with DFS2 file system
2. For new log partitions: Initializes with provided file handlers

Both constructors set up the state machines and internal attributes. The `init` method:
1. Caches the index of existing log files
2. Sets the current file index to the last valid index found
3. Computes the next file index if logs exist
4. Updates first and last file references

#### Session Management

The `start_session` method:
1. Checks if a file is already open
2. Sets state to `st_start_session`
3. Opens a file with the current file index
4. Updates the last file reference
5. Returns to idle state when complete

The `stop_session` method:
1. Checks if a file is open
2. Closes the file asynchronously
3. Computes the next file index for future sessions
4. Returns to idle state when complete

#### Data Writing

The `write` method implements a complex state machine:
1. Checks if file is open
2. If in idle state:
   - Checks if data fits in current file
   - If not, transitions to `st_write_stop_ss` to close and create new file
   - If file is empty, prepares header and transitions to `st_write_header`
   - Otherwise transitions to `st_write_data`
3. In `st_write_header` state:
   - Writes header data
   - Transitions to `st_write_header2` when complete
4. In `st_write_header2` state:
   - Flushes header data
   - Transitions to `st_write_data` when complete
5. In `st_write_data` state:
   - Writes actual log data
   - Checks timeout for flushing
   - Transitions to `st_write_flush` if timeout expired
6. In `st_write_flush` state:
   - Flushes data to disk
7. In `st_write_stop_ss` state:
   - Closes current file
   - Computes next file index
   - Returns to idle state

#### Index Management

The `cache_index` and `cache_index_async` methods implement a state machine for indexing:
1. Opens the index file
2. Writes the log version
3. Iterates through all possible log files:
   - Opens each file
   - Extracts metadata (time, size)
   - Updates last file date and index if newer
   - Writes entry to index file
   - Closes file
4. Closes index file when complete

#### Log Deletion

The `del_logs` method:
1. Sets up deletion parameters (first file, number of files)
2. Transitions to `st_deleting` state
3. Iterates through files to delete:
   - Removes each file
   - Counts successful deletions
4. Transitions to `st_reindexing` to update index
5. Returns to idle state when complete

### Error Handling

The `Logctrl` class implements robust error handling:
1. Checks asynchronous operation results (`async_done_ok`, `async_done_error`, etc.)
2. Handles file system errors during open, read, write, and close operations
3. Maintains state consistency even when operations fail
4. Uses assertions to validate critical operations

## 2. Fdr - File Data Record System

### Overview and Responsibilities

The `Fdr` class serves as a bridge between the logging system and the STANAG protocol, handling packet reception, transmission, and processing related to file data records. It implements:
- `Base::Istep`: For step-based execution
- `Stanag::Stanag_msg_tx`: For message transmission
- `Stanag::IStanag_rx_pkt`: For packet reception

The class manages three types of logs:
1. Periodic logs (`fperiod`)
2. Event-driven logs (`fevent`)
3. Fast logs (`fast`)

### Key Components and Structure

#### Core Attributes

- `str_t`: Handler for periodic on-board logs
- `str_1`: Handler for one-shot event-driven logs
- `fperiod`, `fevent`, `fast`: References to log controllers
- `pkt_sender`: Interface for packet sending
- `irx_fw`: Interface for sending standard STANAG packets
- `delete_pending`: Flag indicating a deletion operation is pending
- `delete_logtype`: Type of log to delete
- `delete_findex`: First index to delete
- `delete_numfiles`: Number of files to delete

#### Log Types

The `Type_log` enum defines the available log types:
- `periodic_log`: Regular interval logging
- `event_log`: Event-triggered logging
- `fastlog`: High-frequency logging

#### Command Arguments

The `Fdr_arg` enum defines the commands that can be processed:
- `fdr_save100`: Start burst storage at maximum frequency for fastlog
- `fdr_is100`: Request storage state at maximum frequency for fastlog
- `fdr_stop100`: Stop fastlog buffering (starts save file)
- `fdr_del`: Delete logs

### Control Flow

#### Packet Reception

The `on_rx_pkt` method handles incoming packets:
1. Extracts the command argument from the packet
2. For delete commands (`fdr_del`):
   - Checks if a deletion is already pending
   - If not, extracts log type, first index, and number of files
   - Sets `delete_pending` flag
   - Returns `not_completed` to start asynchronous task
   - If deletion is already pending, sends response with zero deleted files
3. For other commands, forwards the packet to another core

#### Packet Transmission

The `on_tx` method handles outgoing packets:
1. Writes the message subtype to the output stream
2. Writes the number of deleted files to the output stream

#### Log Deletion

The `step_task` method handles asynchronous log deletion:
1. Checks if deletion is pending
2. Based on log type, calls `del_logs` on the appropriate controller
3. When deletion completes, sends response message
4. Clears the `delete_pending` flag
5. Returns `true` when deletion is complete

#### Periodic Processing

The `step` method performs regular processing:
1. Calls `step` on the periodic log handler (`str_t`)
2. Calls `step` on the event-driven log handler (`str_1`)

### Error Handling

The `Fdr` class implements error handling through:
1. Checking asynchronous operation results
2. Issuing warnings on unexpected conditions
3. Sending appropriate responses for failed operations

## 3. Sampler - Data Sampling System

### Overview and Responsibilities

The `Sampler` class provides a mechanism to collect and store real-time data samples from system variables. It implements the `Stanag::Stanag_msg` interface for message handling and provides:
- Configurable data sampling from system variables
- Multiple trigger mechanisms
- Decimation control
- Efficient storage of sampled data
- Asynchronous file operations

### Key Components and Structure

#### Core Attributes

- `f`: File handler for storing samples
- `file_id`: File identifier for storage
- `request_id`: Request identifier for communications
- `trg`: Trigger configuration
- `decimation`: Sample every n samples
- `nsamples`: Maximum number of samples
- `st`: Sampler state
- `save_st`: Saving state
- `svecs`: Sample data vectors

#### Inner Classes

1. **Source**: Manages access to system variables
   - `var`: Variable identifier
   - `value`: Pointer to variable value
   - Methods to get value and variable ID

2. **Trigger**: Controls when sampling starts
   - Types: `trg_on_rx`, `trg_rising`, `trg_falling`, `trg_on_change`
   - `src`: Input signal source
   - `threshold`: Value for comparison
   - `step()`: Evaluates trigger condition

3. **Sample_vector**: Stores samples for one variable
   - `src`: Source of data
   - `v`: Array of samples
   - Methods to sample and retrieve data

#### State Machines

1. **Sampling State Machine** (`State` enum):
   - `st_idle`: No operation
   - `st_wait_trigger`: Waiting for trigger condition
   - `st_sampling`: Actively collecting samples
   - `st_saving`: Saving sampled data

2. **Saving State Machine** (`State_saving` enum):
   - `sst_opening`: Opening file
   - `sst_header_prep`: Preparing header data
   - `sst_saving_header`: Saving header data
   - `sst_saving_prep`: Preparing data for saving
   - `sst_saving`: Saving data to file
   - `sst_closing`: Closing file

### Control Flow

#### Message Handling

The `on_rx` method processes incoming messages:
1. Extracts the argument type (`arg_sample_start` or `arg_sample_status`)
2. For `arg_sample_start`:
   - Checks if sampler is in saving state
   - If not, configures sampler with `cset`
3. For `arg_sample_status`:
   - Always sends status response
4. Sends status message with current state

The `on_tx` method formats outgoing messages:
1. Writes message subtype
2. Writes request ID
3. Writes current state
4. Writes current sample count

#### Sampling Process

The `step_sample` method drives the sampling state machine:
1. In `st_wait_trigger` state:
   - Evaluates trigger condition
   - If triggered, samples once and transitions to `st_sampling`
2. In `st_sampling` state:
   - Calls `sample` method
   - If sampling complete, transitions to `st_saving`

The `sample` method:
1. Checks if sampling is complete
2. If not and decimation counter reached:
   - Samples all variables
   - Increments sample counter
   - Resets decimation counter
3. Otherwise increments decimation counter
4. Returns true when sampling is complete

#### Saving Process

The `step_save` method drives the saving state machine:
1. In `sst_opening` state:
   - Opens file asynchronously
   - Transitions to `sst_header_prep` when complete
2. In `sst_header_prep` state:
   - Prepares header with number of vectors and samples
   - Adds variable IDs
   - Transitions to `sst_saving_header`
3. In `sst_saving_header` state:
   - Writes header to file
   - Transitions to `sst_saving_prep` when complete
4. In `sst_saving_prep` state:
   - Prepares data from current vector
   - Transitions to `sst_saving`
5. In `sst_saving` state:
   - Writes data to file
   - Moves to next vector or transitions to `sst_closing`
6. In `sst_closing` state:
   - Closes file
   - Transitions to `st_idle` when complete

### Configuration

The `cset` method configures the sampler:
1. Reads request ID
2. Configures trigger
3. Sets decimation factor
4. Configures sample vectors
5. Resets counters
6. Transitions to `st_wait_trigger`

### Error Handling

The `Sampler` class implements error handling through:
1. Checking asynchronous operation results
2. Transitioning to appropriate error states
3. Protecting against concurrent access with mutex
4. Validating configuration parameters

## 4. Integration Between Components

### Log Control Flow

The three components work together to provide a complete logging solution:

1. **Fdr** acts as the command processor:
   - Receives commands from external systems
   - Routes commands to appropriate log controllers
   - Manages periodic and event-driven logging

2. **Logctrl** handles the file system operations:
   - Manages log files and sessions
   - Writes data with headers
   - Maintains indexes for efficient access
   - Handles file deletion

3. **Sampler** provides data collection:
   - Captures real-time variable values
   - Stores samples efficiently
   - Saves data to files when complete

### Data Flow

1. **Command Reception**:
   - External system sends command to `Fdr`
   - `Fdr` processes command and initiates appropriate action

2. **Log Session Management**:
   - `Fdr` calls methods on `Logctrl` instances
   - `Logctrl` manages file sessions and writes data

3. **Data Sampling**:
   - `Sampler` collects data based on triggers
   - Data is stored in memory until complete
   - Complete data sets are written to files

4. **Status Reporting**:
   - Components send status messages to requesters
   - Status includes operation state and completion information

### Cross-Component Relationships

```
+----------------+     +----------------+     +----------------+
|      Fdr       |---->|    Logctrl     |     |    Sampler    |
+----------------+     +----------------+     +----------------+
       |                      |                      |
       v                      v                      v
+----------------+     +----------------+     +----------------+
| Stanag Protocol|     |  File System   |     |System Variables|
+----------------+     +----------------+     +----------------+
```

## 5. State Machines and Control Logic

### Logctrl State Machine

```
                           +----------+
                           |  st_idle |<-----------------+
                           +----------+                  |
                               |  |                      |
                 start_session |  | write                |
                               v  v                      |
+---------------+     +------------------+     +-----------------+
| st_start_     |     | st_write_header  |---->| st_write_      |
| session       |     +------------------+     | header2        |
+---------------+              |               +-----------------+
       |                       |                      |
       |                       v                      v
       |               +------------------+     +-----------------+
       |               | st_write_data    |---->| st_write_flush |
       |               +------------------+     +-----------------+
       |                       |                      |
       v                       v                      |
+---------------+     +------------------+            |
| st_stop_      |<----| st_write_stop_ss |            |
| session       |     +------------------+            |
+---------------+              |                      |
       |                       |                      |
       +-----------------------------------------------+
```

### Reindexing State Machine

```
+-------------------+     +----------------------+     +--------------------+
| rst_index_opening |---->| rst_index_write_    |---->| rst_index_         |
|                   |     | version             |     | opening_aux        |
+-------------------+     +----------------------+     +--------------------+
       ^                                                       |
       |                                                       v
+-------------------+     +----------------------+     +--------------------+
| rst_index_closing |<----| rst_index_next      |<----| rst_index_write    |
|                   |     |                     |     |                    |
+-------------------+     +----------------------+     +--------------------+
       |                          ^                           |
       |                          |                           v
       |                  +----------------------+     +--------------------+
       +----------------->| rst_index_error     |<----| rst_index_         |
                          |                     |     | closing_aux        |
                          +----------------------+     +--------------------+
```

### Sampler State Machine

```
+----------+     +------------------+     +-------------+     +------------+
| st_idle  |---->| st_wait_trigger  |---->| st_sampling |---->| st_saving  |
+----------+     +------------------+     +-------------+     +------------+
     ^                                                              |
     +--------------------------------------------------------------+
```

### Saving State Machine

```
+-------------+     +----------------+     +------------------+
| sst_opening |---->| sst_header_   |---->| sst_saving_      |
|             |     | prep          |     | header           |
+-------------+     +----------------+     +------------------+
                                                   |
                                                   v
+-------------+     +----------------+     +------------------+
| sst_closing |<----| sst_saving     |<----| sst_saving_prep  |
|             |     |                |     |                  |
+-------------+     +----------------+     +------------------+
      |
      v
+-------------+
| st_idle     |
+-------------+
```

## 6. Log Types and Their Characteristics

### Periodic Logs

Managed by `fperiod` in the `Fdr` class:
- Collected at regular intervals
- Configured through `str_t` (Fstrt)
- Suitable for continuous system monitoring
- Lower priority than event logs

### Event-Driven Logs

Managed by `fevent` in the `Fdr` class:
- Triggered by specific events
- Configured through `str_1` (Fstr1)
- Suitable for capturing important state changes
- Higher priority than periodic logs

### Fast Logs

Managed by `fast` in the `Fdr` class:
- Collected at maximum frequency
- Controlled by `fdr_save100`, `fdr_is100`, and `fdr_stop100` commands
- Suitable for high-resolution data capture
- Highest priority among log types

## 7. File System Interaction

### Log File Organization

The `Logctrl` class organizes log files within a partition:
- Each file has a unique ID within the partition
- Files are created sequentially
- When maximum file count is reached, oldest files are overwritten
- Index file maintains metadata for all logs

### File Format

Log files consist of:
1. **Header**:
   - Field set data
   - Session information
   - Address information
   - CRC for validation

2. **Data**:
   - Binary log data
   - Written in chunks
   - Flushed periodically or when buffer full

### Index File Format

The index file contains:
1. **Version**: 16-bit version identifier
2. **Entries**: For each log file:
   - File ID (16-bit)
   - Timestamp (64-bit)
   - Size (32-bit)
   - CRC (32-bit)

### Asynchronous File Operations

All file operations are performed asynchronously:
- `open_async`: Opens files with appropriate mode
- `write_async`: Writes data in chunks
- `flush_async`: Ensures data is written to disk
- `close_async`: Closes files and updates metadata

## 8. Error Handling and Contingencies

### File System Errors

The `Logctrl` class handles file system errors:
1. **Open Failures**:
   - Attempts to open next file
   - Updates file index
   - Returns appropriate error code

2. **Write Failures**:
   - Issues warning
   - Returns error code
   - Maintains state consistency

3. **Close Failures**:
   - Attempts to close file
   - Returns to idle state regardless of result

### Deletion Errors

The `Fdr` class handles deletion errors:
1. **Permission Issues**:
   - Skips files that cannot be deleted
   - Continues with next file
   - Reports actual number of files deleted

2. **Concurrent Deletion**:
   - Rejects new deletion requests if one is pending
   - Sends response with zero deleted files

### Sampling Errors

The `Sampler` class handles sampling errors:
1. **File Open Failures**:
   - Transitions to idle state
   - Reports error in status

2. **Write Failures**:
   - Transitions to closing state
   - Attempts to close file
   - Reports error in status

## 9. Performance Considerations

### Buffering and Flushing

The `Logctrl` class optimizes disk operations:
- Writes data in chunks
- Uses timeout-based flushing
- Flushes only when necessary
- Handles full files by creating new ones

### Sampling Efficiency

The `Sampler` class optimizes data collection:
- Uses decimation to reduce sample frequency
- Collects multiple variables simultaneously
- Stores data in memory until complete
- Writes to disk in efficient chunks

### Asynchronous Processing

All components use asynchronous processing:
- Operations return immediately with status
- Processing continues in subsequent steps
- State machines track progress
- Resources are released promptly

## 10. File-by-File Breakdown

### Logctrl.h

Defines the `Logctrl` class for log file management:
- Implements `Base::Ilogcontrol` interface
- Defines state machines for logging operations
- Provides methods for session management, writing, and deletion
- Contains `Session_data` structure for log metadata

### Logctrl.cpp

Implements the `Logctrl` class:
- Constructors for different initialization scenarios
- Session management with `start_session` and `stop_session`
- Data writing with complex state machine
- Index management with `cache_index` and `cache_index_async`
- Log deletion with `del_logs`

### Fdr.h

Defines the `Fdr` class for file data record handling:
- Implements `Base::Istep`, `Stanag::Stanag_msg_tx`, and `Stanag::IStanag_rx_pkt` interfaces
- Defines log types and command arguments
- Provides methods for packet handling and log management

### Fdr.cpp

Implements the `Fdr` class:
- Constructor for initialization
- Packet reception with `on_rx_pkt`
- Packet transmission with `on_tx`
- Asynchronous deletion with `step_task`
- Periodic processing with `step`

### Sampler.h

Defines the `Sampler` class for data sampling:
- Implements `Stanag::Stanag_msg` interface
- Defines inner classes for source, trigger, and sample vector
- Provides methods for sampling, saving, and configuration

### Sampler.cpp

Implements the `Sampler` class:
- Inner class implementations
- Message handling with `on_rx` and `on_tx`
- Sampling process with `step_sample` and `sample`
- Saving process with `step_save`
- Configuration with `cset`

## Conclusion

The logging and diagnostics system in the Media library provides a comprehensive solution for system monitoring, debugging, and data collection. The three main components work together to offer:

1. **Flexible Log Management**: Through the `Logctrl` class, which handles file operations, session management, and index maintenance.

2. **Protocol Integration**: Through the `Fdr` class, which bridges the STANAG protocol with the logging system and manages different log types.

3. **Efficient Data Sampling**: Through the `Sampler` class, which provides configurable data collection with various trigger mechanisms.

The system is designed for robustness, with comprehensive error handling, state machines for operation management, and asynchronous processing for efficiency. It supports multiple log types (periodic, event-driven, and fast) to accommodate different monitoring needs and provides efficient file system interaction through buffering, flushing, and index management.