# Generated from:

- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/media/05_File_System_Core.md (4185 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/media/03_Storage_Management.md (3634 tokens)

---

# Comprehensive Storage System in Media Library

This document provides a high-level synthesis of the Media library's storage system, integrating information from the File System Core and Storage Management components to present a complete picture of the storage architecture.

## 1. Storage Architecture Overview

The Media library implements a comprehensive storage solution with multiple layers:

### 1.1 Architectural Layers

```
+---------------------------+
|      Client Applications  |
+---------------------------+
            ↓
+---------------------------+
|    Remote File Interface  |  ← Filecom system
+---------------------------+
            ↓
+---------------------------+
|    Permission Control     |  ← Ifspermission interface
+---------------------------+
            ↓
+---------------------------+
|    File System Core       |  ← Base::Ifile implementations
+---------------------------+
            ↓
+---------------------------+
|    Storage Management     |  ← Flash & SD card operations
+---------------------------+
            ↓
+---------------------------+
|    Physical Storage       |  ← Flash memory, SD cards
+---------------------------+
```

### 1.2 Key Components

1. **Remote File Interface**: `Filecom` provides network-accessible file operations
2. **Permission System**: `Ifspermission` enforces access control policies
3. **File Serialization**: `Fstrfast` optimizes data logging and transfer
4. **Flash Storage**: `Flashtun_wr` persists file system configurations
5. **SD Card Management**: `HformatSD` formats SD cards with DFS2 file system

### 1.3 Storage Types

The system supports multiple storage types:

1. **Volatile Storage (RAM)**:
   - Primary working storage for file operations
   - Fast access but non-persistent

2. **Non-volatile Storage (Flash)**:
   - Persistent storage for file system configurations
   - Limited write cycles but retains data without power

3. **Removable Storage (SD Card)**:
   - High-capacity storage with DFS2 file system
   - Removable and replaceable

## 2. Common Design Patterns

### 2.1 State Machine Pattern

Multiple components implement state machines for complex operations:

1. **Filecom State Machine**:
   - Task states: `no_task_id`, `open_task_id`, `write_task_id`, etc.
   - Subtask states: `sub_idle`, `sub_open_close_last`, etc.
   - Driven by `step()` method

2. **Fstrfast State Machine**:
   - States: `st_idle`, `st_start`, `st_buffering`, etc.
   - Controls logging session lifecycle

3. **HformatSD State Machine**:
   - States: `st_idle`, `st_ongoing`, `st_error`
   - Tracks SD card format operations

This consistent pattern enables complex, multi-step operations while maintaining clear state transitions and error handling.

### 2.2 Interface-Based Design

The system uses interfaces extensively for flexibility and modularity:

1. **File Interface**: `Base::Ifile` defines standard file operations
2. **Permission Interface**: `Ifspermission` defines access control contract
3. **Message Interface**: `Stanag::Stanag_msg` for consistent communication
4. **Step Interface**: `Base::Istep` for state machine execution
5. **Tunable Interface**: `Base::Itunable` for configuration

This approach enables:
- Dependency injection for testing
- Alternative implementations for different hardware
- Consistent interfaces across components

### 2.3 Null Object Pattern

The system uses null implementations for optional components:

1. **Fspermission_null**: Permissive implementation of `Ifspermission`
2. **Flashtun_wr_null**: No-op implementation for systems without Flash

This pattern allows:
- Consistent code paths regardless of hardware
- Simplified conditional logic
- Easier testing and development

### 2.4 Singleton Pattern

Used selectively for system-wide resources:

1. **Fspermission_null**: Singleton with `get_instance()`

### 2.5 Message-Based Communication

Components communicate through standardized message patterns:

1. **Command/Response Protocol**:
   - Commands like `fl_open_arg`, `ftwr_save`
   - Responses with status codes and data

2. **Serialization/Deserialization**:
   - `on_rx()` deserializes incoming commands
   - `on_tx()` serializes outgoing responses

## 3. Cross-Component Integration

### 3.1 File System and Storage Integration

The file system core integrates with storage management through:

1. **Flash Persistence**:
   - `Flashtun_wr` saves file system configurations from RAM to Flash
   - Updates status bit to reflect persistence state

2. **SD Card Management**:
   - `HformatSD` formats SD cards with DFS2 file system
   - Integrates with system reset for post-format restart

3. **File Resources**:
   - `Filecom` manages multiple file resources through `rc[ftype_all]`
   - Resources implement `Base::Ifile` interface

### 3.2 Permission System Integration

The permission system integrates across components:

1. **Filecom Integration**:
   - Constructor injection: `Filecom(Ifspermission& fsperm0, ...)`
   - Permission checks before operations: `fsperm.is_wr_allowed(file_id)`

2. **Flexible Policies**:
   - Default permissive implementation: `Fspermission_null`
   - Extensible for custom security policies

### 3.3 Cross-Core Communication

The system supports cross-core data transfer:

1. **Fstrfast Integration**:
   - Uses `Xclogmng` for file writing across cores
   - Uses `Xcpktwr` for packet writing across cores

## 4. Storage Workflows

### 4.1 Remote File Operations

```
Client                  Filecom                 Storage
  |                        |                       |
  |-- fl_open_arg -------->|                       |
  |                        |-- permission check -->|
  |                        |<-- result ------------|
  |                        |-- open file --------->|
  |<-- ack/nack ------------|<-- result ------------|
  |                        |                       |
  |-- fl_wdata_arg -------->|                       |
  |                        |-- write data -------->|
  |<-- ack/nack ------------|<-- result ------------|
  |                        |                       |
  |-- fl_close_arg -------->|                       |
  |                        |-- close file -------->|
  |                        |-- validate CRC ------>|
  |<-- ack/nack ------------|<-- result ------------|
```

### 4.2 Flash Persistence

```
Client               Flashtun_wr             Flash Memory
  |                       |                       |
  |-- ftwr_save --------->|                       |
  |<-- ack --------------|                       |
  |                       |-- get FS data ------->|
  |                       |<-- data --------------|
  |                       |-- write to Flash ---->|
  |<-- result ------------|<-- result ------------|
```

### 4.3 SD Card Formatting

```
Client                HformatSD               DFS2_fs
  |                       |                       |
  |-- format command ---->|                       |
  |<-- ack --------------|                       |
  |                       |-- format request ---->|
  |                       |<-- result ------------|
  |<-- status ------------|                       |
  |                       |-- system reset ------>| (optional)
```

### 4.4 Fast Serialization

```
Client                 Fstrfast              Cross-Core
  |                       |                       |
  |-- fdr_save100 ------->|                       |
  |<-- ack --------------|                       |
  |                       |-- start session ----->|
  |                       |-- compress data ----->|
  |                       |-- commit data ------->|
  |-- fdr_is100 --------->|                       |
  |<-- status ------------|                       |
  |-- fdr_stop100 ------->|                       |
  |                       |-- stop session ------>|
  |<-- ack --------------|<-- result ------------|
```

## 5. Error Handling and Contingencies

### 5.1 Comprehensive Error Handling

The storage system implements robust error handling:

1. **Permission Denial**:
   - `Filecom` checks permissions via `fsperm.is_wr_allowed()`
   - Returns `nack_permission_id` if denied

2. **Timeout Management**:
   - `Filecom` monitors inactivity (20 seconds)
   - Automatically closes files and cancels operations
   - Sends `fl_timeout_arg` notification

3. **Data Integrity**:
   - CRC validation when closing files
   - Returns `nack_crc_failed_result_id` if mismatched

4. **Concurrent Access Control**:
   - Prevents multiple sources from accessing the same file
   - Sends `fl_nak_other_comm` if already in use

5. **Format Operation Tracking**:
   - `HformatSD` maintains state (`st_idle`, `st_ongoing`, `st_error`)
   - Reports format status through queries

### 5.2 Thread Safety Mechanisms

Multiple components implement thread safety:

1. **Mutex Protection**:
   - `Flashtun_wr` uses mutex for Flash operations
   - `HformatSD` uses mutex for format operations

2. **Volatile Status Flags**:
   - `Flashtun_wr` uses volatile boolean for file system status
   - Ensures visibility across threads

3. **State Machine Isolation**:
   - Components maintain internal state
   - State transitions only occur in controlled methods

## 6. Performance Optimizations

### 6.1 Data Transfer Optimizations

1. **Windowed Buffering**:
   - `Filecom` uses fixed window size (8 blocks)
   - Enables efficient transfer with acknowledgment

2. **Bandwidth Control**:
   - `Filecom` limits output rate with `tx_tout`
   - Prevents network saturation

3. **Data Compression**:
   - `Fstrfast` compresses data before transfer
   - Reduces bandwidth requirements

### 6.2 Memory Optimizations

1. **Buffered Writing**:
   - `Fstrfast` commits data in chunks
   - Optimizes memory usage and transfer efficiency

2. **Resource Management**:
   - `Filecom` tracks and reports resource usage
   - `Flashtun_wr` reports free words and entries

### 6.3 Asynchronous Operations

1. **Non-blocking Design**:
   - `Filecom` uses `async_*` result codes
   - Continues processing in subsequent steps

2. **Step-Based Execution**:
   - Components implement `Base::Istep`
   - Enables cooperative multitasking

## 7. Storage Adaptability

### 7.1 Hardware Flexibility

The storage system adapts to different hardware configurations:

1. **Flash Storage Options**:
   - `Flashtun_wr` for systems with Flash
   - `Flashtun_wr_null` for systems without Flash

2. **Permission Policies**:
   - `Fspermission_null` for permissive systems
   - Extensible for custom security policies

3. **File Resource Types**:
   - `Filecom` supports multiple file resource types
   - Resources added via `add_resource()`

### 7.2 Cross-Platform Support

The architecture enables deployment across different platforms:

1. **Consistent Interfaces**:
   - Standard interfaces like `Base::Ifile`, `Stanag::Stanag_msg`
   - Enables consistent behavior across platforms

2. **Configurable Parameters**:
   - Adjustable block size, bandwidth, timeouts
   - Tunable for different hardware capabilities

3. **Optional Components**:
   - Null implementations for optional features
   - Maintains consistent interfaces

## 8. Design Principles

The storage system embodies several key design principles:

### 8.1 Separation of Concerns

1. **Layer Separation**:
   - Remote interface separate from file operations
   - Permission control separate from storage management
   - Physical storage separate from logical file system

2. **Component Specialization**:
   - `Filecom` for remote file operations
   - `Flashtun_wr` for Flash persistence
   - `HformatSD` for SD card formatting

### 8.2 Defensive Programming

1. **Validation Checks**:
   - Size validation in `Flashtun_wr`
   - Permission checks in `Filecom`
   - Command validation in message handlers

2. **Error Recovery**:
   - Timeout handling in `Filecom`
   - Status tracking in `HformatSD`
   - CRC validation in file operations

### 8.3 Interface-Based Design

1. **Dependency Injection**:
   - Components receive dependencies via constructors
   - Enables testing and alternative implementations

2. **Consistent Interfaces**:
   - `Stanag::Stanag_msg` for message handling
   - `Base::Istep` for state machine execution

### 8.4 Robust State Management

1. **Explicit State Machines**:
   - Clear state definitions and transitions
   - Comprehensive error states

2. **Status Tracking**:
   - Components maintain and report status
   - Enables monitoring and diagnostics

## 9. Conclusion: A Complete Storage Solution

The Media library provides a comprehensive storage solution with several key strengths:

1. **Multi-Layer Architecture**:
   - Remote file interface
   - Permission control
   - File system core
   - Storage management
   - Physical storage

2. **Multiple Storage Types**:
   - Volatile (RAM)
   - Non-volatile (Flash)
   - Removable (SD Card)

3. **Robust Error Handling**:
   - Permission checks
   - Timeout management
   - Data integrity validation
   - Concurrent access control

4. **Performance Optimizations**:
   - Windowed buffering
   - Bandwidth control
   - Data compression
   - Asynchronous operations

5. **Hardware Flexibility**:
   - Adaptable to different configurations
   - Consistent interfaces across platforms
   - Optional components with null implementations

The design emphasizes robustness, flexibility, and performance while maintaining clear separation of concerns and consistent interfaces. This approach enables the storage system to operate reliably across different hardware configurations and use cases, from embedded systems with limited resources to more complex platforms with multiple storage options.