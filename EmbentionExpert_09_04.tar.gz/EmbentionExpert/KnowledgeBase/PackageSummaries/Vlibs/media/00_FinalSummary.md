# Generated from:

- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/media/05_File_System_Core.md (4185 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/media/03_Storage_Management.md (3634 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/media/04_Configuration_Management.md (4320 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/media/02_Logging_and_Diagnostics.md (6262 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/media/03_Discovery_and_Licensing.md (4397 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/media/03_Update_and_Maintenance.md (6231 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/media/02_Test_Infrastructure.md (2673 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/media/02_Project_Configuration.md (1643 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/media/02_Storage_System.md (3518 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/media/02_Configuration_and_Update_System.md (2943 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/media/01_Media_Library_Architecture.md (3570 tokens)

---

# Media Library System Architecture Overview

This document provides a comprehensive overview of the Media Library software system, serving as the primary entry point for understanding the system's architecture, components, and functionality.

## System Purpose and Scope

The Media Library is a sophisticated embedded software framework designed for real-time systems with a focus on reliability, modularity, and performance. It provides core services for file management, configuration, logging, diagnostics, and system maintenance across different hardware platforms.

## High-Level Architecture

The Media Library is organized into four primary subsystems:

```
+---------------------------------------------------------------------+
|                          Media Library                               |
+---------------------------------------------------------------------+
|                                                                     |
|  +----------------+  +----------------+  +----------------+         |
|  |    Storage     |  | Configuration  |  |   Logging &    |         |
|  |    System      |  |   & Update     |  |  Diagnostics   |         |
|  +----------------+  +----------------+  +----------------+         |
|                                                                     |
|  +----------------+                                                 |
|  |      Test      |                                                 |
|  | Infrastructure |                                                 |
|  +----------------+                                                 |
|                                                                     |
+---------------------------------------------------------------------+
```

### Core Architectural Principles

1. **Interface-Based Design**: Extensive use of interfaces (e.g., `Base::Ifile`, `Base::Istep`, `Base::Itunable`) enables dependency injection, alternative implementations, and consistent behavior.

2. **State Machine Pattern**: Components implement explicit state machines for complex operations, ensuring clear state transitions and robust error handling.

3. **Asynchronous Operations**: Non-blocking operations with `Base::Async_res` return types and step-based execution through the `Base::Istep` interface.

4. **Layered Architecture**: Each subsystem implements multiple layers of abstraction, separating concerns like protocol handling, permission control, and physical storage access.

5. **Message-Based Communication**: Components communicate through standardized message patterns with command/response protocols and serialization/deserialization.

## Subsystem Overview

### 1. Storage System

The Storage System provides a comprehensive solution for managing persistent data across multiple storage types:

#### Key Components
- **Remote File Interface** (`Filecom`): Network-accessible file operations
- **Permission System** (`Ifspermission`): Access control policies
- **File System Core**: File operation implementations
- **Storage Management**: Flash and SD card operations
- **Physical Storage**: Interfaces to Flash memory and SD cards

#### Storage Types
- **Volatile Storage (RAM)**: Primary working storage
- **Non-volatile Storage (Flash)**: Persistent configuration storage
- **Removable Storage (SD Card)**: High-capacity storage with DFS2 file system

[More details in Storage System documentation](05_File_System_Core.md)

### 2. Configuration and Update System

The Configuration and Update System manages device configuration, discovery, and firmware updates:

#### Key Components
- **Configuration Manager** (`Cfgmgr`): Manages configuration data through PDI files
- **Update System** (`Iupdate`, `Updaterx`): Handles firmware updates
- **Maintenance Mode**: Manages maintenance transitions
- **Discovery Protocol**: Implements device discovery
- **License Management**: Handles license validation

#### Operational Modes
- **Normal Operation**: Full configuration loading
- **Maintenance Mode**: Limited configuration loading
- **Update Mode**: Special handling during firmware updates

[More details in Configuration Management documentation](04_Configuration_Management.md)

### 3. Logging and Diagnostics System

The Logging and Diagnostics System provides comprehensive monitoring, debugging, and data collection:

#### Key Components
- **Log Control** (`Logctrl`): Manages log files and sessions
- **File Data Records** (`Fdr`): Bridges logging and STANAG protocol
- **Data Sampling** (`Sampler`): Collects and stores real-time data samples

#### Log Types
- **Periodic Logs**: Regular interval logging
- **Event-Driven Logs**: Event-triggered logging
- **Fast Logs**: High-frequency logging

[More details in Logging and Diagnostics documentation](02_Logging_and_Diagnostics.md)

### 4. Test Infrastructure

The Test Infrastructure provides comprehensive testing capabilities:

#### Key Components
- **VCast Projects**: Organized by component
- **Test Classes**: Dedicated test class per component
- **Mock Objects**: Simulate dependencies for isolated testing

#### Testing Approaches
- **Unit Testing**: Components tested in isolation
- **State Testing**: Verification of state transitions
- **Error Path Testing**: Testing of error conditions
- **Interface Testing**: Verification of component interfaces

[More details in Test Infrastructure documentation](02_Test_Infrastructure.md)

## Cross-Cutting Architectural Patterns

Several architectural patterns are consistently applied across all subsystems:

### Asynchronous Operation Pattern
- `Base::Async_res` return type for non-blocking operations
- `Base::Istep` interface for step-based execution
- State machines for managing complex operations
- Timeout handling and error recovery

### Message Handling Pattern
- `Stanag::Stanag_msg` interface for message processing
- `on_rx()` method for receiving commands
- `on_tx()` method for generating responses
- Argument-based command dispatching

### Configuration Interface Pattern
- `Base::Itunable` interface for synchronous configuration objects
- `Base::Itunable_async` interface for asynchronous configuration objects
- `Base::Ideserializable` interface for data serialization/deserialization

### Error Handling Pattern
- `PDIcheck::commit()` for reporting and tracking errors
- `Base::Assertions::runtime()` for validation
- Error state tracking and recovery mechanisms

## Key System Workflows

### Remote File Operations
```
Client                  Filecom                 Storage
  |                        |                       |
  |-- fl_open_arg -------->|                       |
  |                        |-- permission check -->|
  |                        |<-- result ------------|
  |                        |-- open file --------->|
  |<-- ack/nack ------------|<-- result ------------|
  |                        |                       |
  |-- fl_wdata_arg -------->|                       |
  |                        |-- write data -------->|
  |<-- ack/nack ------------|<-- result ------------|
  |                        |                       |
  |-- fl_close_arg -------->|                       |
  |                        |-- close file -------->|
  |                        |-- validate CRC ------>|
  |<-- ack/nack ------------|<-- result ------------|
```

### Configuration Loading Flow
1. **Initialization**: Client calls `load(desired_mode)`
2. **File Loading**: Load configurations with appropriate strategy
3. **Synchronization**: Update CRCs and synchronization state
4. **Error Recovery**: Handle loading failures

### Discovery Protocol Flow
```
Client                  Discovery               System
  |                        |                       |
  |-- disc_request_arg ---->|                       |
  |                        |-- extract PC time --->|
  |                        |-- update system time->|
  |                        |-- increment session ->|
  |<-- disc_response_arg --|<-- get system info ---|
```

### Logging Session Flow
```
Client                  Logctrl                 Storage
  |                        |                       |
  |-- start_session ------>|                       |
  |                        |-- open file --------->|
  |<-- result -------------|<-- result ------------|
  |                        |                       |
  |-- write data --------->|                       |
  |                        |-- write header ------>|
  |                        |-- write data -------->|
  |<-- result -------------|<-- result ------------|
  |                        |                       |
  |-- stop_session ------->|                       |
  |                        |-- close file -------->|
  |<-- result -------------|<-- result ------------|
```

## System Integration Points

The Media Library integrates with other systems through:

1. **File System Interface**: `Base::Ifile` provides a standard interface for file operations
2. **Message Interface**: `Stanag::Stanag_msg` standardizes communication protocols
3. **Configuration Interface**: `Base::Itunable` provides a standard interface for configuration
4. **Step Interface**: `Base::Istep` enables asynchronous processing

## Error Handling and Resilience

The Media Library implements comprehensive error handling:

1. **Permission Checks**: Validate access before operations
2. **Timeout Management**: Prevent deadlocks and resource leaks
3. **Data Integrity**: CRC validation for file operations
4. **Concurrent Access Control**: Prevent conflicts in shared resources
5. **Recovery Mechanisms**: State machine transitions for error recovery

## Extensibility Points

The architecture provides several extension points:

1. **Interface Implementations**: Custom implementations of standard interfaces
2. **Configuration Extensions**: New configuration types through `Cfgmgr::add()`
3. **Custom Update Implementations**: Through the `Iupdate` interface
4. **Custom License Sources**: Through the `Ilicsrc` interface
5. **File Resource Types**: Through `Filecom::add_resource()`

## Referenced Documentation

For more detailed information about specific components, refer to:

- [File System Core](05_File_System_Core.md)
- [Storage Management](03_Storage_Management.md)
- [Configuration Management](04_Configuration_Management.md)
- [Update and Maintenance](03_Update_and_Maintenance.md)
- [Discovery and Licensing](03_Discovery_and_Licensing.md)
- [Logging and Diagnostics](02_Logging_and_Diagnostics.md)
- [Test Infrastructure](02_Test_Infrastructure.md)
- [Project Configuration](02_Project_Configuration.md)

## Conclusion

The Media Library represents a sophisticated embedded software architecture designed for reliability, flexibility, and performance. Its modular design, comprehensive error handling, and consistent use of interfaces create a robust foundation for embedded systems. The architecture successfully balances flexibility, performance, and robustness while maintaining hardware independence and efficiency.