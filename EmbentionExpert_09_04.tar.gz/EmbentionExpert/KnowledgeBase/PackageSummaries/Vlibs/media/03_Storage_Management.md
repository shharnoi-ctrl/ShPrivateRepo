# Generated from:

- code/include/Flashtun_wr.h (622 tokens)
- code/include/Flashtun_wr_null.h (403 tokens)
- code/include/Flastun_wr_arg.h (54 tokens)
- code/include/HformatSD.h (930 tokens)
- code/source/Flashtun_wr.cpp (1128 tokens)
- code/source/Flashtun_wr_null.cpp (534 tokens)
- code/source/HformatSD.cpp (2017 tokens)

## With context from:

- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/media/05_File_System_Core.md (4185 tokens)

---

# Storage Management Components in Media Library

This document provides a comprehensive analysis of the storage management components in the Media library, focusing on Flash memory operations and SD card formatting capabilities. These components provide persistent storage capabilities that integrate with the core file system.

## 1. Flash Memory Operations

### 1.1 Flashtun_wr Class - Flash File System Driver

#### Overview and Responsibilities

The `Flashtun_wr` class manages the remote Flash File system driver, providing a mechanism to save file system configurations from RAM to Flash memory. It implements the `Stanag::Stanag_msg` interface for message handling.

#### Key Components and Structure

- **File System Reference**: `fmem` - Reference to the file system in RAM
- **Flash Memory Block**: `mb_flash` - Memory block to store configuration into Flash
- **File System Status Bit**: `fs_bit` - Volatile boolean reference indicating file system status

#### Functional Behavior and Logic

**Constructor**:
```cpp
Flashtun_wr(Base::Fsmem& fsmem0, Base::Mblock<const Uint16> mb_flash0, volatile bool& fs_bit0)
```
- Initializes internal members with provided parameters
- Performs runtime assertion to ensure file system data size is less than or equal to Flash memory block size

**Flash Configuration Saving**:
```cpp
bool flash_cfg_save()
```
- Creates a mutex with exclusive access (true parameter)
- Gets file system data from RAM
- Verifies size constraints
- Writes data to Flash sector using `Bsp::Flash_wr::write_sector`
- Updates file system status bit based on operation success
- Returns success/failure status

#### Message Handling

**Receiving Messages** (`on_rx`):
- Deserializes incoming command (expecting `ftwr_save`)
- If valid command, sends acknowledgment message
- Returns appropriate acknowledgment type (`received` or `rejected`)

**Transmitting Messages** (`on_tx`):
- Calls `flash_cfg_save()` to perform the actual Flash writing operation
- Gets free resource counts from file system
- Serializes operation result and resource statistics (free words and entries)
- Always returns true

#### Error Handling and Contingency Logic

- **Size Validation**: Runtime assertion ensures file system data fits in Flash memory block
- **Mutex Protection**: Uses mutex to prevent concurrent Flash write operations
- **Status Tracking**: Updates `fs_bit` to reflect Flash write success/failure
- **Command Validation**: Rejects invalid commands with warning

#### Thread Safety Mechanisms

- Uses `Base::Mutex` with exclusive access to protect Flash write operations
- Uses volatile boolean reference for file system status bit to ensure visibility across threads

### 1.2 Flashtun_wr_null Class - Null Flash Implementation

#### Overview and Responsibilities

The `Flashtun_wr_null` class provides a null implementation for systems without Flash storage. It accepts Flash tunable messages and responds as if operations succeeded, but doesn't actually perform any Flash operations.

#### Functional Behavior and Logic

**Constructor**:
```cpp
Flashtun_wr_null()
```
- Empty constructor as no initialization is needed

**Message Handling**:

**Receiving Messages** (`on_rx`):
- Deserializes incoming command (expecting `ftwr_save`)
- If valid command, sends acknowledgment message
- Returns appropriate acknowledgment type (`received` or `rejected`)

**Transmitting Messages** (`on_tx`):
- Always reports success (true) for Flash operations
- Reports zero available words and entries in Flash memory
- Always returns true

#### Use Cases

- Used in systems where Flash memory is not available or not used for file storage
- Provides compatibility with systems that expect Flash storage capabilities
- Allows code to function without conditional compilation for different hardware configurations

## 2. SD Card Formatting

### 2.1 HformatSD Class - SD Card Formatter

#### Overview and Responsibilities

The `HformatSD` class provides functionality to format SD cards with the DFS2 file system. It implements both `Base::Itunable` and `Stanag::Stanag_msg` interfaces for configuration and message handling.

#### Key Components and Structure

- **DFS2 File System**: `fsd` - Reference to DFS2 file system
- **Reset Handler**: `reset_hnd` - Reference to system reset handler
- **Status Tracking**: `st` - Enum tracking format process status (idle, ongoing, error)
- **Mode Enumeration**: Defines format actions (format all, format specific partition, query status)

#### State Machine

The `HformatSD` class implements a state machine for format operations:

**Status States**:
1. `st_idle`: Format operation is not active or has completed successfully
2. `st_ongoing`: Format operation is in progress
3. `st_error`: Error occurred during last format operation

**Mode States**:
1. `m_format_all`: Format all enabled partitions
2. `m_format_part`: Format a specific partition
3. `m_format_query`: Query format status

#### Functional Behavior and Logic

**Constructor**:
```cpp
HformatSD(DFS2::DFS2_fs& fsd0, Base::Ireset& reset_hnd0)
```
- Initializes status to `st_idle`
- Stores references to DFS2 file system and reset handler

**Command Processing** (`cset`):
- Deserializes format mode from input stream
- For format operations, also deserializes reset flag
- Based on mode:
  - `m_format_all`: Formats all partitions using `fsd.format_all()`
  - `m_format_part`: Deserializes partition index and descriptor, then formats specific partition using `fsd.format_part()`
  - `m_format_query`: Returns current format status
- Updates status based on operation result
- Performs system reset if requested and format succeeded

#### Message Handling

**Receiving Messages** (`on_rx`):
- Creates data mutator to process incoming data
- Calls `cset()` to process format command
- Sends acknowledgment message
- Returns `Base::Msg_data::completed`

**Transmitting Messages** (`on_tx`):
- Serializes format success status (true if status is `st_idle`)
- Always returns true

#### Error Handling and Contingency Logic

- **Status Tracking**: Maintains format operation status (idle, ongoing, error)
- **Mutex Protection**: Uses mutex to protect format operations
- **Reset Handling**: Optionally resets system after successful format
- **Format Failure**: Sets status to `st_error` if format operation fails

#### Thread Safety Mechanisms

- Uses `Base::Mutex` with exclusive access to protect format operations
- Status variable (`st`) tracks operation state across method calls

## 3. Cross-Component Relationships

### 3.1 Integration with Core File System

#### Flash Storage Integration

1. **File System to Flash**:
   - `Flashtun_wr` connects the file system (`Base::Fsmem`) to Flash memory
   - Provides mechanism to persist file system configuration from RAM to Flash
   - Updates file system status bit to reflect persistence state

2. **Null Implementation**:
   - `Flashtun_wr_null` provides compatibility layer for systems without Flash
   - Maintains same interface but doesn't perform actual Flash operations

#### SD Card Integration

1. **DFS2 File System**:
   - `HformatSD` works with `DFS2::DFS2_fs` to format SD cards
   - Supports both full formatting and partition-specific formatting
   - Integrates with system reset mechanism for post-format restart

### 3.2 Message Flow

```
                  +----------------+
                  |  Stanag_msg    |
                  +----------------+
                         ^
                         |
        +----------------+----------------+
        |                                 |
+----------------+                +----------------+
|  Flashtun_wr   |                |   HformatSD    |
+----------------+                +----------------+
        |                                 |
        v                                 v
+----------------+                +----------------+
|  Flash Memory  |                |  DFS2 File Sys |
+----------------+                +----------------+
```

### 3.3 Key Relationships

1. **Flashtun_wr and File System**:
   - `Flashtun_wr` depends on `Base::Fsmem` for file system data
   - `Flashtun_wr` updates `fs_bit` to reflect persistence status
   - Relationship established through constructor injection

2. **HformatSD and DFS2**:
   - `HformatSD` depends on `DFS2::DFS2_fs` for formatting operations
   - `HformatSD` depends on `Base::Ireset` for system reset
   - Relationships established through constructor injection

3. **Message Handling**:
   - Both classes implement `Stanag::Stanag_msg` for consistent message interface
   - Both use similar command/response patterns for operations

## 4. Storage Scenarios

### 4.1 Systems with Flash Storage

In systems with Flash storage:
1. File system configurations are stored in RAM during operation
2. `Flashtun_wr` provides mechanism to persist configurations to Flash
3. Flash write operations are protected by mutex for thread safety
4. File system status bit tracks persistence state

**Typical Workflow**:
1. System receives `ftwr_save` command
2. `Flashtun_wr::on_rx` processes command and sends acknowledgment
3. `Flashtun_wr::on_tx` calls `flash_cfg_save()` to write data to Flash
4. Operation result and resource statistics are returned

### 4.2 Systems without Flash Storage

In systems without Flash storage:
1. `Flashtun_wr_null` is used instead of `Flashtun_wr`
2. Commands are processed normally but no actual Flash operations occur
3. Success responses are always returned
4. Zero available resources are reported

**Typical Workflow**:
1. System receives `ftwr_save` command
2. `Flashtun_wr_null::on_rx` processes command and sends acknowledgment
3. `Flashtun_wr_null::on_tx` returns success without performing Flash operations
4. Zero resource statistics are returned

### 4.3 SD Card Formatting

For SD card operations:
1. `HformatSD` provides formatting capabilities for DFS2 file system
2. Supports formatting all partitions or specific partitions
3. Optional system reset after successful format
4. Status tracking for format operations

**Typical Workflow**:
1. System receives format command with mode and parameters
2. `HformatSD::on_rx` processes command and calls `cset()`
3. Format operation is performed based on mode
4. Status is updated based on operation result
5. System is optionally reset after successful format

## 5. File-by-File Breakdown

### 5.1 Flashtun_wr.h

Defines the `Flashtun_wr` class for Flash file system operations:
- Constructor with file system, Flash memory block, and status bit
- Message handling methods (`on_rx`, `on_tx`)
- Flash configuration saving method (`flash_cfg_save`)
- Private members for file system, Flash memory, and status tracking

### 5.2 Flashtun_wr.cpp

Implements the `Flashtun_wr` class:
- Constructor initialization with runtime assertion
- Message handling with command validation
- Flash configuration saving with mutex protection
- Resource statistics reporting

### 5.3 Flashtun_wr_null.h

Defines the `Flashtun_wr_null` class for systems without Flash storage:
- Empty constructor
- Message handling methods (`on_rx`, `on_tx`)
- Inline implementation for constructor

### 5.4 Flashtun_wr_null.cpp

Implements the `Flashtun_wr_null` class:
- Message handling with command validation
- Success response generation without actual Flash operations
- Zero resource statistics reporting

### 5.5 Flastun_wr_arg.h

Defines the `Flashtun_wr_arg` enumeration for Flash file commands:
- `ftwr_save`: Command to save tunable to Flash

### 5.6 HformatSD.h

Defines the `HformatSD` class for SD card formatting:
- Constructor with DFS2 file system and reset handler
- Message handling methods (`on_rx`, `on_tx`)
- Configuration methods (`cset`, `cget`)
- Enumerations for mode and status
- Inline implementation for constructor and `cget`

### 5.7 HformatSD.cpp

Implements the `HformatSD` class:
- Message handling with data mutator
- Command processing with mode-specific logic
- Format operations with mutex protection
- Status tracking and reset handling

## 6. Referenced Context Files

The following context file provided valuable insights:

- **05_File_System_Core.md**: Provided understanding of the core file system operations that these storage components integrate with. Specifically:
  - Explained the `Filecom` system for remote file management
  - Detailed the permission system (`Ifspermission` and implementations)
  - Described the fast file serialization (`Fstrfast`)
  - Showed how these components work together to provide a complete file system interface

This context helped establish how the Flash storage and SD card formatting components fit into the broader file system architecture, particularly how they provide the persistent storage layer that the core file system relies on.

## 7. Conclusion

The storage management components in the Media library provide essential persistent storage capabilities that integrate with the core file system:

1. **Flash Memory Operations**:
   - `Flashtun_wr` provides mechanism to persist file system configurations from RAM to Flash
   - `Flashtun_wr_null` offers compatibility for systems without Flash storage
   - Both implement consistent message interface for seamless integration

2. **SD Card Formatting**:
   - `HformatSD` provides SD card formatting with DFS2 file system
   - Supports various formatting modes and optional system reset
   - Implements state machine for operation tracking

These components work together with the core file system to provide a complete storage solution with both volatile (RAM) and non-volatile (Flash, SD) storage options. The design emphasizes thread safety, error handling, and compatibility across different hardware configurations.

The architecture allows for flexible deployment in systems with or without Flash storage, maintaining consistent interfaces and behavior while adapting to available hardware resources. This approach enables code reuse and simplifies system integration across different platforms.