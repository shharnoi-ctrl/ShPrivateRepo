# Generated from:

- code/include/Iupdate.h (146 tokens)
- code/include/Update_arg.h (37 tokens)
- code/include/Updaterx.h (155 tokens)
- code/include/Maint_mode_bl.h (514 tokens)
- code/include/Maint_mode_no_reset.h (457 tokens)
- code/source/Updaterx.cpp (205 tokens)
- code/source/Maint_mode_bl.cpp (506 tokens)
- code/source/Maint_mode_no_reset.cpp (752 tokens)

## With context from:

- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/media/04_Configuration_Management.md (4320 tokens)

---

# High-Fidelity Semantic Knowledge Graph: Update and Maintenance Mode Components in Media Library

## 1. Functional Behavior and Logic: Update Interface and Implementation

The Media library provides a comprehensive framework for firmware updates and maintenance mode management through several key components that work together to enable system updates and special operational modes.

### Iupdate Interface

The `Iupdate` class serves as an abstract interface for implementing firmware update functionality across different projects or hardware platforms:

```cpp
namespace Media
{
    class Iupdate
    {
    public:
        virtual ~Iupdate();
        virtual void update(Uint16 slot) = 0;

    protected:
        Iupdate();

    private:
        Iupdate(const Iupdate& orig); // = delete
        Iupdate& operator=(const Iupdate& orig); // = delete
    };
}
```

Key characteristics:
- Pure virtual interface requiring concrete implementations to define the `update()` method
- Takes a `slot` parameter (Uint16) to specify which firmware slot to update
- Copy constructor and assignment operator are private (effectively deleted) to prevent copying
- Protected constructor ensures the class can only be instantiated by derived classes

### Update Arguments

The `Update_arg.h` file defines an enumeration for update message arguments:

```cpp
namespace Media
{
    enum Updaterx_arg
    {
        update_sd = 2 // Update firmware
    };
}
```

This enumeration is used to identify the type of update operation requested in update messages, with `update_sd` (value 2) representing a firmware update operation.

### Updaterx Class

The `Updaterx` class implements the `Stanag::Stanag_msg_rx` interface to receive and process update messages:

```cpp
namespace Media
{
    class Updaterx : public Stanag::Stanag_msg_rx
    {
    public:
        Updaterx(Iupdate& u0);
        virtual Base::Msg_data::Ack_type on_rx(Rx_params& push_p);

    private:
        Iupdate& u;    // Update handler (system dependent)

        Updaterx(); // = delete
        Updaterx(const Updaterx& orig); // = delete
        Updaterx& operator=(const Updaterx& orig); // = delete
    };
}
```

Key characteristics:
- Receives an `Iupdate` reference in its constructor to delegate actual update operations
- Implements `on_rx()` to process incoming update messages
- Private default constructor, copy constructor, and assignment operator prevent improper instantiation

## 2. Control Flow and State Transitions: Update Message Processing

### Updaterx Message Processing Flow

The `Updaterx::on_rx()` method processes incoming update messages with the following flow:

1. Initialize acknowledgment type to `rejected`
2. Extract the update argument from the input stream as a `Updaterx_arg`
3. If the argument is `update_sd`:
   - Build a default system version object
   - Set the system version from the input stream
   - Extract the target slot number from the input stream
   - Validate that:
     - The application ID in the received version matches the current application ID
     - The payload length is sufficient for the data read so far
   - If validation passes:
     - Set acknowledgment type to `completed`
     - Call the `update()` method on the `Iupdate` implementation with the specified slot
4. Return the acknowledgment type

```cpp
Base::Msg_data::Ack_type Updaterx::on_rx(Rx_params& push_p)
{
    Base::Msg_data::Ack_type ret = Base::Msg_data::rejected;
    Updaterx_arg arg = static_cast<Updaterx_arg>(push_p.is.get_uint16_le());
    if(arg == update_sd)
    {
        Base::Sysver v = Base::Sysver::build_default();
        v.cset(push_p.is);
        Uint16 slot = 0;
        slot = push_p.is.get_uint16_le();
        if(Base::Assertions::runtime((Base::Sysver::get_current().app_id == v.app_id)
                && (push_p.hdr.get_payload_len() >= push_p.is.get_pos())))
        {
            ret = Base::Msg_data::completed;
            u.update(slot);
        }
    }
    return ret;
}
```

## 3. Maintenance Mode Management

The Media library provides two different implementations for maintenance mode management:

1. `Maint_mode_bl`: For systems with bootlog storage
2. `Maint_mode_no_reset`: For systems without bootlog storage

Both implement the `Base::Imaint_mode` interface but with different behaviors for entering and exiting maintenance mode.

### Maint_mode_bl Class

The `Maint_mode_bl` class manages maintenance mode using a bootlog file:

```cpp
namespace Media
{
    class Maint_mode_bl : public Base::Imaint_mode
    {
    public:
        explicit Maint_mode_bl(Base::Bootlog& boot_log);
        virtual Base::Async_res enter_maint_mode(Base::Ireset* reset_hnd);
        virtual Base::Async_res exit_maint_mode(Base::Ireset* reset_hnd);

    private:
        Base::Bootlog& boot_log;    // Boot log manager reference
        bool ongoing;               // Indicates a reset is ongoing
        Base::Loadst load_st;       // Desired "next" load state

        Base::Async_res step(Base::Ireset* reset_hnd, Base::Loadst load_st);
    };
}
```

Key characteristics:
- Uses a `Bootlog` reference to store the desired load state
- Tracks whether a reset operation is ongoing with the `ongoing` flag
- Implements both `enter_maint_mode()` and `exit_maint_mode()` methods
- Uses a private `step()` method to handle the common logic for both operations

### Maint_mode_no_reset Class

The `Maint_mode_no_reset` class manages maintenance mode for systems without bootlog storage:

```cpp
namespace Media
{
    class Maint_mode_no_reset : public Base::Imaint_mode
    {
    public:
        explicit Maint_mode_no_reset(Imaint_mode::Enter_hook& mmode_hook);
        virtual Base::Async_res enter_maint_mode(Base::Ireset* reset_hnd);
        virtual Base::Async_res exit_maint_mode(Base::Ireset* reset_hnd);

    private:
        Imaint_mode::Enter_hook& mmode_hook;    // Maintenance mode hook

        Maint_mode_no_reset(const Maint_mode_no_reset&);                // = delete
        Maint_mode_no_reset& operator=(const Maint_mode_no_reset&);     // = delete
    };
}
```

Key characteristics:
- Uses an `Enter_hook` reference to perform actual maintenance mode actions
- Implements both `enter_maint_mode()` and `exit_maint_mode()` methods
- Does not reset when entering maintenance mode, but does reset when exiting
- Uses the configuration management system to store the load state

## 4. Control Flow and State Transitions: Maintenance Mode

### Maint_mode_bl State Transitions

The `Maint_mode_bl` class implements a state machine for maintenance mode transitions:

| State | Trigger | Actions | Next State | Location |
|-------|---------|---------|------------|----------|
| Idle | `enter_maint_mode()` call | Set `load_st` to `lst_maintenance`, set `ongoing` to true | Saving | `enter_maint_mode()` |
| Idle | `exit_maint_mode()` call | Set `load_st` to `lst_normal`, set `ongoing` to true | Saving | `exit_maint_mode()` |
| Saving | `step()` call | Save load state to bootlog | Complete or Busy | `step()` |
| Busy | `step()` call | Retry saving load state | Complete or Busy | `step()` |
| Complete | Save operation complete | Set `ongoing` to false, call `reset()` if handler provided | Idle | `step()` |

The state transitions are managed through the `ongoing` flag and the asynchronous result of the bootlog save operation.

### Maint_mode_no_reset State Transitions

The `Maint_mode_no_reset` class implements a simpler state model:

| State | Trigger | Actions | Next State | Location |
|-------|---------|---------|------------|----------|
| Any | `enter_maint_mode()` call with valid reset handler | Call `mmode_hook.enter_maint_mode()`, set load state to `lst_maintenance` | Maintenance Mode | `enter_maint_mode()` |
| Maintenance Mode | `exit_maint_mode()` call | Set load state to `lst_normal`, call `reset()` if handler provided | Normal Mode | `exit_maint_mode()` |

The state is stored in the configuration system using the `vu_cfg_loadst` variable.

## 5. Inputs and Stimuli

### Update Message Processing

The `Updaterx` class processes incoming update messages with the following inputs:

1. **Update Command**:
   - Received through the `on_rx()` method
   - Contains an update argument (`update_sd`)
   - Includes system version information
   - Specifies the target slot for the update

2. **System Version**:
   - Extracted from the update message
   - Used to validate that the update is compatible with the current system
   - Must have the same application ID as the current system

3. **Slot Number**:
   - Extracted from the update message
   - Specifies which firmware slot to update
   - Passed to the `Iupdate::update()` method

### Maintenance Mode Transitions

The maintenance mode classes respond to the following inputs:

1. **Enter Maintenance Mode Request**:
   - Received through the `enter_maint_mode()` method
   - Includes an optional reset handler
   - Triggers the transition to maintenance mode

2. **Exit Maintenance Mode Request**:
   - Received through the `exit_maint_mode()` method
   - Includes an optional reset handler
   - Triggers the transition back to normal mode

3. **Reset Handler**:
   - Provided to both enter and exit methods
   - Used to trigger a system reset when needed
   - May be null, in which case no reset is performed

## 6. Outputs and Effects

### Update Process

The `Updaterx` class produces the following outputs and effects:

1. **Acknowledgment**:
   - Returns `completed` if the update was successfully initiated
   - Returns `rejected` if the update request was invalid

2. **System Update**:
   - Calls the `Iupdate::update()` method with the specified slot
   - The actual update process depends on the concrete implementation of `Iupdate`
   - May involve writing to flash memory, verifying checksums, etc.

### Maintenance Mode Effects

The maintenance mode classes produce the following outputs and effects:

#### Maint_mode_bl

1. **Bootlog Update**:
   - Saves the desired load state (`lst_maintenance` or `lst_normal`) to the bootlog
   - This persists across system resets

2. **System Reset**:
   - Calls `reset_hnd->reset()` if a reset handler is provided
   - This triggers a system restart with the new load state

3. **Asynchronous Result**:
   - Returns `async_ongoing` if the operation is still in progress
   - Returns `async_done_ok` if the operation completed successfully
   - Returns `async_done_error` if the operation failed

#### Maint_mode_no_reset

1. **Configuration Update**:
   - Updates the `vu_cfg_loadst` configuration variable with the new load state
   - This persists in the configuration system

2. **Maintenance Mode Hook**:
   - Calls `mmode_hook.enter_maint_mode()` when entering maintenance mode
   - This allows for custom actions when entering maintenance mode

3. **System Reset**:
   - Calls `reset_hnd->reset()` when exiting maintenance mode (not when entering)
   - This triggers a system restart with the normal load state

4. **Asynchronous Result**:
   - Returns `async_done_ok` if the operation completed successfully
   - Returns `async_done_error` if the operation failed

## 7. Parameters and Configuration

### Update Parameters

The `Updaterx` class uses the following parameters:

1. **Update Handler**:
   - Provided through the constructor as an `Iupdate` reference
   - Used to delegate the actual update operation

2. **Update Argument**:
   - Defined in `Update_arg.h` as `update_sd` (value 2)
   - Used to identify firmware update requests

### Maintenance Mode Parameters

The maintenance mode classes use the following parameters:

#### Maint_mode_bl

1. **Bootlog Reference**:
   - Provided through the constructor
   - Used to save the desired load state

2. **Load State**:
   - `lst_maintenance`: Used when entering maintenance mode
   - `lst_normal`: Used when exiting maintenance mode
   - Stored in the `load_st` member variable

3. **Ongoing Flag**:
   - Tracks whether a reset operation is in progress
   - Prevents multiple concurrent operations

#### Maint_mode_no_reset

1. **Maintenance Mode Hook**:
   - Provided through the constructor as an `Enter_hook` reference
   - Used to perform custom actions when entering maintenance mode

2. **Load State**:
   - `lst_maintenance`: Used when entering maintenance mode
   - `lst_normal`: Used when exiting maintenance mode
   - Stored in the configuration system using `vu_cfg_loadst`

## 8. Error Handling and Contingency Logic

### Update Error Handling

The `Updaterx` class implements the following error handling:

1. **Invalid Update Argument**:
   - If the update argument is not `update_sd`, the message is rejected
   - Returns `rejected` as the acknowledgment type

2. **Version Mismatch**:
   - If the application ID in the received version does not match the current application ID, the message is rejected
   - Uses `Base::Assertions::runtime()` to validate the condition

3. **Insufficient Payload**:
   - If the payload length is insufficient for the data read so far, the message is rejected
   - Uses `Base::Assertions::runtime()` to validate the condition

### Maintenance Mode Error Handling

The maintenance mode classes implement the following error handling:

#### Maint_mode_bl

1. **Busy Error**:
   - If the bootlog save operation returns `async_busy_error`, it is converted to `async_ongoing`
   - This allows the operation to be retried in the next step

2. **Save Failure**:
   - If the bootlog save operation fails with any other error, it is returned to the caller
   - The `ongoing` flag is reset to allow future operations

#### Maint_mode_no_reset

1. **Invalid Load State**:
   - If the current load state is already `lst_maintenance` when entering maintenance mode, returns `async_done_error`
   - If the current load state is not in a done or error state when exiting maintenance mode, returns `async_done_error`

2. **Missing Reset Handler**:
   - If the reset handler is null when entering maintenance mode, the operation is rejected
   - Returns `async_done_error` as the result

3. **Hook Failure**:
   - If the maintenance mode hook returns `false` when entering maintenance mode, the operation is rejected
   - Returns `async_done_error` as the result

## 9. File-by-File Breakdown

### Iupdate.h

Defines the `Iupdate` interface for firmware updates:
- Pure virtual `update()` method that takes a slot number
- Protected constructor and destructor
- Private copy constructor and assignment operator

### Update_arg.h

Defines the `Updaterx_arg` enumeration:
- `update_sd` (value 2) for firmware updates

### Updaterx.h

Defines the `Updaterx` class for receiving update messages:
- Inherits from `Stanag::Stanag_msg_rx`
- Implements `on_rx()` to process update messages
- Stores a reference to an `Iupdate` implementation

### Maint_mode_bl.h

Defines the `Maint_mode_bl` class for bootlog-based maintenance mode:
- Inherits from `Base::Imaint_mode`
- Implements `enter_maint_mode()` and `exit_maint_mode()`
- Uses a bootlog to store the load state
- Tracks ongoing operations with the `ongoing` flag

### Maint_mode_no_reset.h

Defines the `Maint_mode_no_reset` class for systems without bootlog storage:
- Inherits from `Base::Imaint_mode`
- Implements `enter_maint_mode()` and `exit_maint_mode()`
- Uses a maintenance mode hook for custom actions
- Uses the configuration system to store the load state

### Updaterx.cpp

Implements the `Updaterx::on_rx()` method:
- Extracts the update argument, system version, and slot number
- Validates the application ID and payload length
- Calls the `Iupdate::update()` method if validation passes

### Maint_mode_bl.cpp

Implements the `Maint_mode_bl` class methods:
- `enter_maint_mode()`: Sets the load state to `lst_maintenance`
- `exit_maint_mode()`: Sets the load state to `lst_normal`
- `step()`: Saves the load state to the bootlog and handles resets

### Maint_mode_no_reset.cpp

Implements the `Maint_mode_no_reset` class methods:
- `enter_maint_mode()`: Calls the maintenance mode hook and updates the configuration
- `exit_maint_mode()`: Updates the configuration and triggers a reset

## 10. Cross-Component Relationships

### Update and Maintenance Mode Integration

The update and maintenance mode components work together to provide a complete firmware update and system management solution:

1. **Update Process**:
   - The `Updaterx` class receives update messages and delegates to the `Iupdate` implementation
   - The concrete `Iupdate` implementation performs the actual update
   - The system may need to enter maintenance mode to complete the update

2. **Maintenance Mode Transitions**:
   - The `Maint_mode_bl` and `Maint_mode_no_reset` classes manage transitions between normal and maintenance modes
   - These transitions may be triggered by update operations or other system events

3. **Reset Handling**:
   - Both maintenance mode implementations can trigger system resets
   - The `Maint_mode_bl` class resets after both entering and exiting maintenance mode
   - The `Maint_mode_no_reset` class only resets when exiting maintenance mode

### Configuration Management Integration

The maintenance mode components integrate with the configuration management system:

1. **Bootlog Integration**:
   - The `Maint_mode_bl` class uses the bootlog to store the load state
   - This allows the load state to persist across system resets

2. **Configuration Variable Integration**:
   - The `Maint_mode_no_reset` class uses the `vu_cfg_loadst` configuration variable
   - This allows the load state to be stored in the configuration system

3. **Load State Handling**:
   - Both implementations use the `Base::Loadst` enumeration
   - `lst_maintenance` indicates maintenance mode
   - `lst_normal` indicates normal operation
   - The configuration manager uses these states to determine how to load configurations

### System Reset Integration

Both maintenance mode implementations integrate with the system reset mechanism:

1. **Reset Handler**:
   - Both implementations accept an optional `Base::Ireset*` parameter
   - This allows them to trigger system resets when needed

2. **Reset Timing**:
   - The `Maint_mode_bl` class resets after saving the load state
   - The `Maint_mode_no_reset` class only resets when exiting maintenance mode

3. **Reset Conditions**:
   - Resets are only triggered if a reset handler is provided
   - This allows the system to control when resets occur

## 11. Detailed Behavioral Analysis

### Update Message Processing Flow

The update message processing flow in `Updaterx::on_rx()` follows these steps:

1. **Message Parsing**:
   ```cpp
   Updaterx_arg arg = static_cast<Updaterx_arg>(push_p.is.get_uint16_le());
   ```
   - Extracts the update argument from the input stream
   - Casts it to the `Updaterx_arg` enumeration type

2. **Argument Validation**:
   ```cpp
   if(arg == update_sd)
   ```
   - Checks if the argument is `update_sd` (value 2)
   - Only proceeds if the argument is valid

3. **Version Extraction**:
   ```cpp
   Base::Sysver v = Base::Sysver::build_default();
   v.cset(push_p.is);
   ```
   - Creates a default system version object
   - Sets its values from the input stream

4. **Slot Extraction**:
   ```cpp
   Uint16 slot = 0;
   slot = push_p.is.get_uint16_le();
   ```
   - Initializes the slot number to 0
   - Sets its value from the input stream

5. **Validation**:
   ```cpp
   if(Base::Assertions::runtime((Base::Sysver::get_current().app_id == v.app_id)
           && (push_p.hdr.get_payload_len() >= push_p.is.get_pos())))
   ```
   - Checks that the application ID matches the current system
   - Checks that the payload length is sufficient
   - Uses runtime assertions for validation

6. **Update Execution**:
   ```cpp
   ret = Base::Msg_data::completed;
   u.update(slot);
   ```
   - Sets the acknowledgment type to `completed`
   - Calls the `update()` method on the `Iupdate` implementation

### Maint_mode_bl Operation Flow

The `Maint_mode_bl` class operates as follows:

1. **Enter Maintenance Mode**:
   ```cpp
   if(!ongoing)
   {
       load_st = lst_maintenance;
       ongoing = true;
   }
   return step(reset_hnd, load_st);
   ```
   - Sets the load state to `lst_maintenance` if not already ongoing
   - Sets the `ongoing` flag to true
   - Calls the `step()` method to save the load state

2. **Exit Maintenance Mode**:
   ```cpp
   if(!ongoing)
   {
       load_st = lst_normal;
       ongoing = true;
   }
   return step(reset_hnd, load_st);
   ```
   - Sets the load state to `lst_normal` if not already ongoing
   - Sets the `ongoing` flag to true
   - Calls the `step()` method to save the load state

3. **Step Execution**:
   ```cpp
   Base::Async_res res = boot_log.save_async(load_st);
   if(res == Base::async_busy_error)
   {
       res = Base::async_ongoing;  // If busy, try again
   }
   if(res != Base::async_ongoing)
   {
       ongoing = false;
       if(reset_hnd != 0)
       {
           reset_hnd->reset();
       }
   }
   return res;
   ```
   - Saves the load state to the bootlog asynchronously
   - Converts `async_busy_error` to `async_ongoing` to allow retries
   - If the operation completes (success or failure), resets the `ongoing` flag
   - If a reset handler is provided, calls its `reset()` method
   - Returns the asynchronous result

### Maint_mode_no_reset Operation Flow

The `Maint_mode_no_reset` class operates as follows:

1. **Enter Maintenance Mode**:
   ```cpp
   Async_res res = async_done_error;
   Evar<Loadst> e_lst(vu_cfg_loadst);
   Loadst lst = e_lst.get();
   if(lst != lst_maintenance)
   {
       if(reset_hnd != 0)
       {
           if(mmode_hook.enter_maint_mode())
           {
               res = async_done_ok;
               e_lst.set(lst_maintenance);
           }
       }
   }
   return res;
   ```
   - Gets the current load state from the configuration
   - Checks if it's not already in maintenance mode
   - Checks if a reset handler is provided
   - Calls the maintenance mode hook to perform custom actions
   - If successful, sets the load state to `lst_maintenance`
   - Returns `async_done_ok` if successful, `async_done_error` otherwise

2. **Exit Maintenance Mode**:
   ```cpp
   Async_res res = async_done_error;
   Evar<Loadst> e_lst(vu_cfg_loadst);
   Loadst lst = e_lst.get();
   if(lst_is_done_err(lst))
   {
       res = async_done_ok;
       e_lst.set(lst_normal);
       if(reset_hnd != 0)
       {
           reset_hnd->reset();
       }
   }
   return res;
   ```
   - Gets the current load state from the configuration
   - Checks if it's in a done or error state
   - Sets the load state to `lst_normal`
   - If a reset handler is provided, calls its `reset()` method
   - Returns `async_done_ok` if successful, `async_done_error` otherwise

## 12. Integration with Configuration Management System

The maintenance mode components integrate with the configuration management system as described in the context file:

1. **Load State Management**:
   - The `Maint_mode_bl` class uses the bootlog to store the load state
   - The `Maint_mode_no_reset` class uses the `vu_cfg_loadst` configuration variable
   - Both use the `Base::Loadst` enumeration to represent the load state

2. **Configuration Loading Modes**:
   - The configuration manager supports different loading modes:
     - `lst_secure`: Load all PDIFs, abort on error
     - `lst_normal`: Load all PDIFs, continue on error
     - `lst_maintenance`: Load only CRC values
   - The maintenance mode components set the load state to control this behavior

3. **Error Handling**:
   - The configuration manager reports errors through the `PDIcheck` system
   - The maintenance mode components handle errors through asynchronous results
   - Both systems work together to ensure proper error recovery

## Referenced Context Files

- `Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/media/04_Configuration_Management.md`: Provided valuable information about the configuration management system, including load states, CRC management, and error handling. This helped understand how the maintenance mode components interact with the configuration system, particularly how the `Maint_mode_no_reset` class uses the `vu_cfg_loadst` configuration variable.