# Generated from:

- code/include/Autopilot.h (1654 tokens)
- code/include/APstatus.h (403 tokens)
- code/source/Autopilot.cpp (794 tokens)
- code/test/Autopilot_test.cpp (1163 tokens)

---

# Autopilot and APstatus Classes: High-Fidelity Semantic Knowledge Graph

## 1. Functional Behavior and Logic

### APstatus Class
The `APstatus` class represents the status of an autopilot in the arbitration system. It maintains a simple validity flag that indicates whether the autopilot is ready for arbitration.

#### Core Functionality:
- **Status Tracking**: Maintains a single boolean flag (`valid`) that indicates if the autopilot is ready for arbitration
- **Serialization Support**: Provides capability to deserialize status from a PDIC (Protocol Data Independent Container)

#### Key Methods:
- `reset()`: Sets the validity flag to false
- `get_valid()`: Returns the current validity state
- `set_valid(bool)`: Sets the validity flag to the provided value
- `cset(Base::Lossy&)`: Deserializes the validity flag from a buffer

### Autopilot Class
The `Autopilot` class represents an individual autopilot within the arbitration system. It tracks the autopilot's status, monitors its health through deadman checks, and manages variables used for arbitration scoring.

#### Core Responsibilities:
1. **Autopilot Detection**: Tracks whether an autopilot has been detected (received at least one HLI message)
2. **Health Monitoring**: Monitors autopilot health through deadman checks and variable update frequency
3. **Status Management**: Maintains and updates the autopilot's status
4. **Variable Management**: Stores and updates variables used for arbitration scoring
5. **Scoring**: Computes a score for the autopilot based on reference values for arbitration

#### Detection Logic:
An autopilot is considered detected when:
- It has a valid status (`status.get_valid() == true`)
- Its deadman checker is OK (`dm.is_ok() == true`)

#### Failure Detection Logic:
An autopilot is marked as failed (`kill_me = true`) when any of these conditions are met:
- The deadman signal is not OK (`!dm.is_ok()`)
- Variables haven't been updated within the maximum time threshold (`dt > Autopilot::tmax`)
- The autopilot sets itself as invalid (`!status.get_valid()`)
- No watchdog signal is received for more than 5 seconds after the first status message

## 2. Control Flow and State Transitions

### Autopilot State Machine

| State | Trigger | Actions | Next State | Location |
|-------|---------|---------|------------|----------|
| Not Detected | `status.get_valid() == true` AND `dm.is_ok() == true` | Set `detected = true`, Start variable chrono | Detected | `Autopilot::step()` |
| Not Detected | `status.get_valid() == true` AND `dm.is_ok() == false` AND `first_st.toc() > max_time` | Set `kill_me = true` | Failed | `Autopilot::step()` |
| Detected | `!dm.is_ok()` OR `dt > Autopilot::tmax` | Set `kill_me = true` | Failed | `Autopilot::step()` |
| Failed | `restart()` called | Reset `detected` and `kill_me` flags, Reset status | Not Detected | `Autopilot::restart()` |
| Any | `set_state(alive, ready)` called | Set `kill_me = !alive`, Set `status.valid = ready` | Depends on parameters | `Autopilot::set_state()` |

### Variable Update Flow
1. A variable is updated via `set_var(j, value)`
2. The corresponding bit in the `updated` bitarray is set
3. If all variables have been updated:
   - The `updated` bitarray is reset
   - The variable chrono is restarted (`chrono_var.tic()`)
4. If no variables are updated within `tmax` (150ms), the autopilot is marked as failed

## 3. Inputs and Stimuli

### Autopilot Constructor Inputs
- **Build_params**: Structure containing:
  - `ideadmanchecker`: Reference to a deadman checker interface
  - `arb_cfg`: Reference to arbitration configuration

### Runtime Inputs
- **Status Updates**: Via `set_status(const Arb::APstatus&)` - Updates the autopilot's status
- **Variable Updates**: Via `set_var(Uint16 j, Real value)` - Sets a specific arbitration variable
- **State Control**: Via `set_state(bool alive, bool ready)` - Forces the autopilot's state
- **Reset Command**: Via `restart()` - Resets the autopilot to its initial state
- **Deadman Signal**: Monitored via the deadman checker interface (`dm.is_ok()`)
- **Reference Values**: Provided to `vote()` method for score computation

### Processing Logic
- Status updates trigger detection logic if the autopilot wasn't previously detected
- Variable updates reset the variable timeout timer when all variables have been updated
- Deadman signals and variable update frequency are checked on each `step()` call

## 4. Outputs and Effects

### Primary Outputs
- **Detection Status**: Via `get_detected()` - Indicates if the autopilot has been detected
- **Kill Status**: Via `get_kill_me()` - Indicates if the autopilot should be excluded from arbitration
- **Variables**: Via `get_var()` - Returns the current values of arbitration variables
- **Status**: Via `get_status()` - Returns the autopilot's status
- **Score**: Via `vote()` - Computes and returns the autopilot's score for arbitration

### Effects
- **Deadman Checking**: The `int_step()` method triggers the deadman checker's step
- **Arbitration Participation**: The `kill_me` flag determines if the autopilot participates in arbitration
- **Variable Monitoring**: The class tracks which variables have been updated and when

## 5. Parameters and Configuration

### Constants
- `vmaxsize = 32`: Maximum number of arbitration variables
- `tmax = 0.150F`: Maximum time (150ms) for variables to change state before failure
- `max_time = 5.0F`: Maximum time (5s) without receiving watchdog signal after first status message

### Configuration Parameters
- **Arbitration Configuration**: Provided via constructor, contains:
  - `var_cfg`: Configuration for each arbitration variable
    - `max_error`: Maximum allowed error for each variable
    - `weight`: Weight of each variable in the scoring calculation
  - `icum_weights`: Cumulative weight factor for scoring

## 6. Error Handling and Contingency Logic

### Failure Detection
1. **Deadman Check Failure**:
   - Triggered when `dm.is_ok()` returns false
   - Detected in `step()` method
   - Results in `kill_me = true`

2. **Variable Update Timeout**:
   - Triggered when `chrono_var.toc() > Autopilot::tmax`
   - Detected in `step()` method
   - Results in `kill_me = true`

3. **Self-Invalidation**:
   - Triggered when autopilot sets its status to invalid
   - Detected in `set_status()` method
   - Results in `kill_me = true`

4. **Watchdog Timeout After First Status**:
   - Triggered when no watchdog signal is received for more than 5 seconds after first status
   - Detected in `step()` method
   - Results in `kill_me = true`

### Recovery Mechanisms
- **Restart**: The `restart()` method resets the autopilot's state, clearing the `detected` and `kill_me` flags
- **State Forcing**: The `set_state()` method allows external control of the autopilot's state

## 7. File-by-File Breakdown

### APstatus.h
- **Purpose**: Defines the `APstatus` class that represents an autopilot's status
- **Key Components**:
  - `APstatus` class with methods to manage a validity flag
  - Inline implementations of all methods

### Autopilot.h
- **Purpose**: Declares the `Autopilot` class that represents an arbitrated autopilot
- **Key Components**:
  - `Autopilot` class declaration with methods for detection, monitoring, and scoring
  - `Build_params` structure for constructor parameters
  - Constants for variable limits and timing thresholds
  - Inline implementations of simple accessor methods

### Autopilot.cpp
- **Purpose**: Implements the `Autopilot` class methods
- **Key Components**:
  - Constructor implementation
  - `step()` method implementing detection and failure logic
  - `set_var()` method for updating variables and tracking updates
  - `vote()` method implementing the scoring algorithm
  - `set_status()`, `set_state()`, and `restart()` implementations

### Autopilot_test.cpp
- **Purpose**: Contains tests for the `Autopilot` class
- **Key Components**:
  - `Dummy_Deadmanchecker` class that implements the `Ideadmanchecker` interface for testing
  - `Autopilot_test` class with test methods
  - Test cases covering detection, failure conditions, and state transitions

## 8. Cross-Component Relationships

### Class Dependencies
- `Autopilot` depends on:
  - `APstatus`: For tracking autopilot status
  - `Ideadmanchecker`: For monitoring deadman signals
  - `Arbitration_cfg`: For configuration parameters
  - `Rvector`: For storing arbitration variables
  - `Bitarray`: For tracking variable updates
  - `Chrono`: For timing operations

### Interface Implementations
- `Dummy_Deadmanchecker` implements `Ideadmanchecker` for testing

### Data Flow
1. External components update autopilot status via `set_status()`
2. External components update variables via `set_var()`
3. `step()` method checks deadman signals and variable update frequency
4. `vote()` method computes scores based on variables and reference values
5. External components check autopilot status via `get_detected()`, `get_kill_me()`, etc.

## 9. Detailed Behavioral Analysis

### Variable Management System
The `Autopilot` class maintains a vector of variables (`var`) used for arbitration scoring. Each variable has:
- A value stored in the `var` vector
- An update status tracked in the `updated` bitarray
- Configuration parameters in `cfg.var_cfg` including:
  - `max_error`: Maximum allowed error for scoring
  - `weight`: Weight in the scoring calculation

Variables are updated through the `set_var()` method, which:
1. Sets the variable value
2. Marks the variable as updated in the `updated` bitarray
3. Checks if all variables have been updated
4. If all variables are updated, resets the `updated` bitarray and restarts the variable chrono

The system monitors the time since the last complete variable update set. If this time exceeds `tmax` (150ms), the autopilot is marked as failed.

### Detection and Failure Logic
The detection logic in `step()` works as follows:

1. If the autopilot is not yet detected:
   - Check if status is valid (`status.get_valid()`)
   - If valid and deadman check is OK (`dm.is_ok()`), mark as detected
   - If valid but deadman check fails, start a timer
   - If the timer exceeds `max_time` (5s), mark the autopilot as failed

2. If the autopilot is already detected:
   - Check if deadman signal is OK (`dm.is_ok()`)
   - Check if variables have been updated recently (`chrono_var.toc() <= Autopilot::tmax`)
   - If either check fails, mark the autopilot as failed (`kill_me = true`)

3. Additionally, if the autopilot sets its status to invalid, it is immediately marked as failed

### Scoring Mechanism
The `vote()` method implements the scoring algorithm for autopilot selection:

1. For each variable:
   - Calculate the normalized error: `x = (var[j] - refval[j]) / var_cfg.max_error`
   - Square the error and cap it at 1.0: `min(x*x, 1.0)`
   - Multiply by the variable's weight: `var_cfg.weight`
   - Add to the running score

2. Multiply the final score by the cumulative weight factor: `cfg.icum_weights`

The resulting score represents how closely the autopilot's variables match the reference values, with lower scores indicating better matches.

## 10. Implementation Details

### Deadman Checking
- The `Autopilot` class delegates deadman checking to an external `Ideadmanchecker` interface
- The `int_step()` method must be called from a high-priority context to trigger the deadman checker
- The `step()` method checks the result of the deadman check via `dm.is_ok()`

### Chronos Usage
- `chrono_var`: Tracks time since the last complete variable update
- `first_st`: Tracks time since the first status message was received

### Bitarray Usage
- The `updated` bitarray tracks which variables have been updated
- When all variables are updated, the bitarray is reset and the chrono is restarted

### Scoring Algorithm
The scoring algorithm in `vote()` computes a weighted sum of squared normalized errors:
```
score = Σ(min((var[j] - refval[j])²/max_error[j]², 1.0) * weight[j]) * icum_weights
```

This produces a score where:
- Lower values indicate better matches to reference values
- Each variable's contribution is limited by its `max_error` parameter
- Variables with higher weights have more influence on the final score
- The overall score is scaled by `icum_weights`

## Summary

The `Autopilot` and `APstatus` classes form a comprehensive system for tracking, monitoring, and evaluating autopilots in an arbitration framework. The system detects autopilots based on status messages and deadman signals, monitors their health through continuous checks, and evaluates them for selection using a sophisticated scoring mechanism.

Key features include:
- Robust detection and failure monitoring
- Flexible variable management with update tracking
- Configurable scoring based on weighted variable comparisons
- Support for external control and reset operations

The system is designed to ensure that only healthy, responsive autopilots participate in the arbitration process, with clear mechanisms for detecting and handling failures.