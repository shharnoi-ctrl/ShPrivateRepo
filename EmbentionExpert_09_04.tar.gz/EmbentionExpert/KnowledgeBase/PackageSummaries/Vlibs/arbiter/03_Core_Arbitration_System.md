# Generated from:

- code/include/Arbitration.h (4488 tokens)
- code/include/Arbitration_fw.h (25 tokens)
- code/include/Arbitration_cfg.h (1089 tokens)
- code/include/Arbitration_cfg_fw.h (28 tokens)
- code/source/Arbitration.cpp (5200 tokens)
- code/source/Arbitration_cfg.cpp (673 tokens)

---

# Arbitration System Analysis

This document provides a comprehensive analysis of the core arbitration system that selects between multiple autopilots. The system is designed to determine the Current AutoPilot (CAP) using various selection methods and handle autopilot failures.

## 1. System Overview

The arbitration system is responsible for selecting the most appropriate autopilot from a set of 3-4 available autopilots based on their health status and performance scores. The system implements several selection algorithms and provides mechanisms to handle autopilot failures.

### Key Components

- **Arbitration Class**: Core class that manages the arbitration process
- **Autopilot Class**: Represents individual autopilots with their variables and status
- **Arbitration_cfg**: Configuration structure for the arbitration system
- **Message Handlers**: Structures for handling incoming and outgoing messages

## 2. Arbitration Configuration

The `Arbitration_cfg` structure defines the configuration parameters for the arbitration system:

```cpp
struct Arbitration_cfg {
    static const Uint16 nmaxautopilots = 4;    // Maximum number of autopilots
    static const Uint16 nminautopilots = 3;    // Minimum number of autopilots
    static const Uint16 ap_id_bits = 7;        // Number of bits for CAP id in status message
    
    // Configuration variables
    typedef Base::Tnarrayresz<Variable_cfg, Autopilot::vmaxsize> Tvar_cfg;
    Tvar_cfg var_cfg;               // Variable configurations
    Real icum_weights;              // Inverse of the sum of all weights
    Uint16 preferred;               // Initial/default autopilot in control
    Method method;                  // Take-over method
    Real arb_tmin;                  // Minimum time to stay with a CAP during arbitration
    Real hysteresis;                // Hysteresis range 0.001-1 to validate an AP
    bool use_external_ap;           // Enables use of an external autopilot
};
```

### Selection Methods

The arbitration system supports several selection methods defined in the `Method` enum:

```cpp
enum Method {
    always_best     = 0,    // Always gives control to the best vote
    change_if_worst = 1,    // Gives control to best vote if current has worst vote
    round_robin     = 2,    // Gives control sequentially to all alive APs
    fixed_always_0  = 4,    // Fixed to first veronte (Mux: 0,0)
    fixed_always_1  = 5,    // Fixed to second veronte (Mux: 0,1)
    fixed_always_2  = 6,    // Fixed to third veronte (Mux: 1,0)
    fixed_always_3  = 7,    // Fixed to external inputs (Mux: 1,1)
    fixed_while_ok  = 8     // Gives control to preferred AP unless it fails
};
```

## 3. Arbitration Process

### 3.1 Initialization

The arbitration system is initialized with:
- A reference to a deadman checker interface
- A callback interface
- Default configuration values:
  - Variable configurations
  - Inverse of the sum of all weights set to 1.0
  - Preferred autopilot set to the first one (index 0)
  - Method set to `change_if_worst`
  - Minimum time to stay with a CAP set to 100 milliseconds
  - Hysteresis range set to 1 millisecond
  - External arbiter usage flag set to False

### 3.2 Main Arbitration Step

The `step()` method is the main entry point for the arbitration process:

```cpp
void Arbitration::step() {
    // If configured method is 'Fixed on', call fixed step
    if ((cfg.method == Arbitration_cfg::fixed_always_0) || 
        (cfg.method == Arbitration_cfg::fixed_always_1) ||
        (cfg.method == Arbitration_cfg::fixed_always_2) || 
        (cfg.method == Arbitration_cfg::fixed_always_3)) {
        step_fixed(cfg.method - Arbitration_cfg::fixed_always_0);
    }
    else {
        step_dyn(); // Call dynamic step
    }
}
```

#### Fixed Step Mode

In fixed step mode, the system simply selects a predefined autopilot:

```cpp
void Arbitration::step_fixed(Uint16 ap_idx) {
    arbiter_ready = true;
    set_current(ap_idx);
}
```

#### Dynamic Step Mode

The dynamic step mode is more complex and involves:
1. Stepping through all autopilots
2. Checking if arbitration has started
3. Computing scores for each autopilot
4. Determining the next autopilot to select based on the configured method

```cpp
void Arbitration::step_dyn() {
    // Step over all autopilots
    Uint16 naps = autopilots.size();
    for(Uint16 i=0; i< naps; i++) {
        autopilots[i].step();
    }
    
    // Check if arbitration has started
    if((arbiter_ready == false) || (naps == 0)) {
        Uint16 nok = 0;
        for(Uint16 i = 0; i < naps; i++) {
            if(autopilots[i].get_detected()) {
                nok++;
            }
        }
        if((nok == naps) && (naps > 0)) {
            arbiter_ready = true;
        }
    }
    else {
        // Check for alive autopilots
        bool any_alive = false;
        for(Uint16 i=0; i<naps && !any_alive; i++) {
            if(!autopilots[i].get_kill_me()) {
                any_alive = true;
            }
        }
        
        if(any_alive) {
            Base::Mutex m(true);    // Block Arbiter from overwriting Arbitration Status
            Uint16 best = current;
            Uint16 worst = current;
            compute_scores(best, worst);
            bool is_curr_dead = autopilots[current].get_kill_me();
            Uint16 nextCAP = get_next_ap(best, worst, is_curr_dead);
            
            // Change CAP if current is dead or if selection time has elapsed
            if(is_curr_dead || ((nextCAP != current) && (cr_cap.toc() > cfg.arb_tmin))) {
                set_current(nextCAP);
                cr_cap.tic();
            }
        }
        else {
            set_current(cfg.preferred);
        }
    }
}
```

### 3.3 Score Computation

The system computes scores for each autopilot to determine which one is performing best:

```cpp
void Arbitration::compute_scores(Uint16& best, Uint16& worst) {
    // Compute reference values for voting
    Base::Tnarray<Real, Autopilot::vmaxsize> refval;
    for (Uint16 i = 0U; i < cfg.var_cfg.size(); ++i) {
        refval[i] = cfg.var_cfg[i].is_rel ? compute_mean(i) : cfg.var_cfg[i].abs_ref;
    }

    // Compute votes
    Real min = Const::MAX;            // Min vote value
    Real max = 0;                     // Max vote value
    best = current;                   // Best AP Id. Current by default
    worst = (current+1) % autopilots.size(); // Worst AP Id

    for (Uint16 i = 0; i < autopilots.size(); i++) {
        if (!autopilots[i].get_kill_me()) {
            votes[i] = autopilots[i].vote(refval);
            
            // Apply hysteresis for stability
            const Real vote_min = (i == prev_best) ? (votes[i] - cfg.hysteresis) : votes[i];
            if (vote_min < min) {
                min = vote_min;
                best = i;
            }
            
            const Real vote_max = (i == prev_worst) ? (votes[i] + cfg.hysteresis) : votes[i];
            if (vote_max > max) {
                max = vote_max;
                worst = i;
            }
        }
        else {
            votes[i] = Const::MAX; // Maximum score for dead autopilots
        }
    }
    
    // Update previous best and worst
    prev_best = best;
    prev_worst = worst;
}
```

### 3.4 Mean Computation

For relative variables, the system computes a mean value across autopilots:

```cpp
Real Arbitration::compute_mean(const Uint16 var_idx) const {
    Base::Tnarray<bool, Arbitration_cfg::nmaxautopilots> mask;
    mask.set_all(true);
    Real avg = 0.0F;
    bool done = false;
    
    while (!done) {
        // Sum the variable at given index for each available autopilot
        Real sumok = 0.0F;
        Uint16 numok = 0U;
        for (Uint16 i = 0U; i < autopilots.size(); ++i) {
            if ((!autopilots[i].get_kill_me()) && mask[i]) {
                sumok += autopilots[i].get_var()[var_idx];
                ++numok;
            }
        }
        
        avg = (numok > 1U) ? (sumok / static_cast<Real>(numok)) : sumok;
        done = (numok <= Ku16::u2);
        
        if (!done) {
            // Find worst deviation
            Real worst_dev = -1.0F;
            Uint16 worst_idx = 0U;
            for (Uint16 i = 0U; i < autopilots.size(); ++i) {
                const Real dev = Rmath::fabsr(autopilots[i].get_var()[var_idx] - avg);
                if ((!autopilots[i].get_kill_me()) && mask[i] && (dev > worst_dev)) {
                    worst_dev = dev;
                    worst_idx = i;
                }
            }
            
            done = (worst_dev <= cfg.var_cfg[var_idx].max_error);
            mask[worst_idx] = false;
        }
    }
    
    return avg;
}
```

### 3.5 Next Autopilot Selection

Based on the configured method, the system determines which autopilot should be selected next:

```cpp
Uint16 Arbitration::get_next_ap(Uint16 best, Uint16 worst, bool is_curr_dead) const {
    Uint16 nextCAP = current;
    
    switch(cfg.method) {
        case Arbitration_cfg::always_best:
            nextCAP = best;
            break;
            
        case Arbitration_cfg::change_if_worst:
            if((current == worst) || is_curr_dead) {
                nextCAP = best;
            }
            break;
            
        case Arbitration_cfg::round_robin:
            nextCAP = current;
            get_next_alive_ap(nextCAP);
            break;
            
        case Arbitration_cfg::fixed_while_ok:
            nextCAP = current;
            if (is_curr_dead) {
                get_next_alive_ap(nextCAP);
            }
            break;
            
        default:
            break;
    }
    
    return nextCAP;
}
```

## 4. Autopilot Status Management

### 4.1 Status Structure

The system maintains status information for each autopilot:

```cpp
struct Status {
    bool arbiter_ready;  // Indicates if arbiter is ready to start the arbitration
    Uint8 current;       // Current selected autopilot
    Base::Tnarray<bool, Arbitration_cfg::nmaxautopilots> alive;  // Alive status for each AP
    Base::Tnarray<bool, Arbitration_cfg::nmaxautopilots> ready;  // Ready status for each AP
};
```

### 4.2 Status Serialization/Deserialization

The system can serialize and deserialize status information for communication:

```cpp
void Arbitration::Message_tx::Status::cget(Base::Lossy& str) const {
    str.put_ubits(current, Arbitration_cfg::ap_id_bits);
    str.put_bool1(arbiter_ready);

    for(Uint16 i=0; i<Arbitration_cfg::nmaxautopilots; i++) {
        str.put_bool1(alive[i]);
    }
    for(Uint16 i=0; i<Arbitration_cfg::nmaxautopilots; i++) {
        str.put_bool1(ready[i]);
    }
}
```

### 4.3 Building Status

The system builds status information from the current state:

```cpp
void Arbitration::build_status(Message_tx::Status& st) const {
    st.arbiter_ready = get_arbiter_ready();
    st.current = static_cast<Uint8>(get_current());
    st.alive.zeros();
    st.ready.zeros();
    for(Uint16 i=0; i<get_nautopilots(); i++) {
        st.alive[i] = !autopilots[i].get_kill_me();
        st.ready[i] = autopilots[i].get_status().get_valid();
    }
}
```

## 5. Message Handling

### 5.1 Receiving Messages

The system can receive and process messages from autopilots:

```cpp
void Arbitration::set_data(Uint16 ap_idx, const Message_rx& msg) {
    if(Base::Assertions::runtime(ap_idx < get_nautopilots())) {
        if(msg.is_status()) {
            autopilots[ap_idx].set_status(msg.status);
        }
        else {
            autopilots[ap_idx].set_var(msg.ivar, msg.data);
        }
    }
}
```

### 5.2 Processing Received Messages

```cpp
bool Arbitration::process_rx_msg(Uint16 ap_idx, Base::Lossy& str) {
    bool res = false;
    Base::CANstdp::Type cmd = Base::CANstdp::t_arbitration;
    str.get_enum8(cmd);
    if(cmd == Base::CANstdp::t_arbitration) {
        Arbitration::Message_rx msg;
        msg.cset(str);
        set_data(ap_idx, msg);
        res = true;
    }
    return res;
}
```

### 5.3 Sending Status Messages

```cpp
void Arbitration::get_status_msg(Base::Lossy& str) const {
    str.put_uint8(Base::CANstdp::t_arbitration);
    str.put_uint8(Message_tx::msgstatus);
    get_status_data(str);
}
```

## 6. Failure Handling

### 6.1 Detecting Failed Autopilots

The system detects failed autopilots through the `get_kill_me()` method, which indicates if an autopilot should be excluded from arbitration.

### 6.2 Finding Next Available Autopilot

When an autopilot fails, the system can find the next available one:

```cpp
bool Arbitration::get_next_alive_ap(Uint16& nextCAP) const {
    bool found = false;
    for(Uint16 i=1; (i< get_nautopilots()) && (!found); i++) {
        Uint16 next = (current+i) % get_nautopilots();
        if(!autopilots[next].get_kill_me()) {
            nextCAP = next;
            found = true;
        }
    }
    return found;
}
```

### 6.3 Restarting Arbitration

The system can restart the arbitration process:

```cpp
void Arbitration::restart() {
    for(Uint16 i=0; i<get_nautopilots(); i++) {
        autopilots[i].restart();
    }
}
```

## 7. Configuration Parameters Impact

### 7.1 Method

The `method` parameter determines the algorithm used to select the CAP:
- `always_best`: Always selects the autopilot with the best score
- `change_if_worst`: Only changes the CAP if it has the worst score
- `round_robin`: Rotates through all available autopilots
- `fixed_always_X`: Always selects a specific autopilot
- `fixed_while_ok`: Selects the preferred autopilot unless it fails

### 7.2 Hysteresis

The `hysteresis` parameter (range 0.001-1.0) adds stability to the selection process by requiring a significant difference in scores before changing the CAP. This prevents rapid switching between autopilots when their scores are close.

### 7.3 Minimum Time (arb_tmin)

The `arb_tmin` parameter (default 100ms) sets the minimum time an autopilot must remain selected before switching to another. This prevents rapid switching that could destabilize the system.

### 7.4 Preferred Autopilot

The `preferred` parameter sets the default autopilot to use when:
- No autopilots are available
- Using the `fixed_while_ok` method
- The arbitration is first initialized

### 7.5 Variable Weights

Each variable used in scoring has a weight that determines its importance in the overall score. The `icum_weights` parameter stores the inverse of the sum of all weights for normalization.

## 8. State Management

### 8.1 Arbitration Ready State

The `arbiter_ready` flag indicates if the arbitration system is ready to start selecting autopilots. It becomes true when all configured autopilots have been detected.

### 8.2 Current Autopilot State

The `current` variable stores the index of the currently selected autopilot. This is updated by the `set_current` method, which also updates a system variable and calls a callback.

### 8.3 Previous Best/Worst State

The `prev_best` and `prev_worst` variables store the indices of the previously determined best and worst autopilots. These are used in conjunction with the hysteresis parameter to add stability to the selection process.

## 9. Cross-Component Relationships

The arbitration system interacts with several other components:

- **Deadman Checker**: Used to initialize autopilots and monitor their health
- **Callback Interface**: Notified when the CAP changes
- **Autopilot Class**: Represents individual autopilots with their variables and status
- **Variable Configuration**: Defines the variables used for scoring and their weights
- **System Variables**: The CAP index is stored in a system variable (Base::vu_arb_cap)

## Conclusion

The arbitration system provides a robust mechanism for selecting between multiple autopilots based on their health status and performance scores. It supports various selection methods, handles autopilot failures, and provides configuration parameters to tune its behavior. The system is designed to be stable, with features like hysteresis and minimum selection time to prevent rapid switching between autopilots.