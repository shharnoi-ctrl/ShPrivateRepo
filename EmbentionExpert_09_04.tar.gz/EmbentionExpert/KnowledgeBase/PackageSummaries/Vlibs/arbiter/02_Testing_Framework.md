# Generated from:

- code/test/Arbitration_test.cpp (767 tokens)
- code/Vcast_projects/4xVTC-1/4xVTC-1.bat (62 tokens)
- code/Vcast_projects/4xVTC-1/Readme.md (580 tokens)
- code/Vcast_projects/4xVTC-3/4xVTC-3.bat (106 tokens)
- code/Vcast_projects/4xVTC-3/Readme.md (649 tokens)

---

# Arbitration System Testing Framework Analysis

This document provides a comprehensive analysis of the testing framework for the arbitration system, focusing on test cases, infrastructure, and validation approaches. The analysis covers how VectorCAST projects are structured, what they test, and how they validate the arbitration system's behavior.

## 1. Functional Behavior and Logic

### Arbitration Test Framework Overview

The arbitration system testing framework consists of:

1. A dedicated test class (`Arbitration_test`) in `code/test/Arbitration_test.cpp`
2. Multiple VectorCAST test projects organized to validate different aspects of the arbitration system
3. Specific test scenarios designed to verify critical safety features and edge cases

The testing framework validates the arbitration system's ability to select the appropriate autopilot based on various conditions, including:
- Different arbitration methods
- Autopilot health status
- Score-based selection
- Failure handling
- Deadman checker functionality

### Core Test Class: `Arbitration_test`

The `Arbitration_test` class in `code/test/Arbitration_test.cpp` provides the foundation for testing the arbitration system:

```cpp
class Arbitration_test {
public:
    Arbitration_test();
    
    Uint16 test_step(const Tnarray<Rv3, Arbitration_cfg::nmaxautopilots>& weights,
                     const Tnarray<Rv3, Arbitration_cfg::nmaxautopilots>& vars,
                     Arbitration_cfg::Method method,
                     Uint16 preferred,
                     Uint16 current_ap);
    
    static Array<Uint16>& get_gpio_ids();
    
private:
    Array<Deadmanchecker_null> dmcks;
    Aux_Iiterator aux_iiterator;
    Arbitration arb;
    
    // Deleted copy constructor and assignment operator
    Arbitration_test(const Arbitration_test& orig);
    Arbitration_test& operator=(const Arbitration_test& orig);
};
```

The class includes:
- An array of `Deadmanchecker_null` objects for testing
- An auxiliary iterator (`Aux_Iiterator`) that implements the `Iiterator<Ideadmanchecker&>` interface
- An instance of the `Arbitration` class under test

## 2. Control Flow and State Transitions

### `test_step` Method Logic Flow

The `test_step` method in `Arbitration_test` is the primary test driver that:

1. Configures the arbitration system with specified parameters
2. Sets up autopilot weights and variables
3. Executes the arbitration step
4. Returns the selected autopilot

Detailed flow:
```
1. Initialize buffer for error handling
2. Configure arbitration with provided method and preferences
3. Configure each autopilot with specified weights
4. Set variables for each autopilot
5. Set the current autopilot
6. Execute the arbitration step
7. Return the newly selected autopilot
```

This method allows tests to verify the arbitration logic by comparing the expected autopilot selection with the actual selection under various conditions.

## 3. Inputs and Stimuli

### Test Inputs for Arbitration

The `test_step` method accepts several key inputs:

1. `weights` - An array of weight vectors for each autopilot (Tnarray<Rv3, Arbitration_cfg::nmaxautopilots>)
2. `vars` - An array of variable vectors for each autopilot (Tnarray<Rv3, Arbitration_cfg::nmaxautopilots>)
3. `method` - The arbitration method to use (Arbitration_cfg::Method)
4. `preferred` - The preferred autopilot ID (Uint16)
5. `current_ap` - The currently active autopilot ID (Uint16)

These inputs allow tests to simulate different scenarios and configurations to validate the arbitration system's behavior.

### Autopilot Test Inputs

For the Autopilot step tests (4xVTC-3), the inputs include:
- System time settings (ranging from 0.0 to 7.0)
- Autopilot status flags (valid/invalid)
- Deadmanchecker status (is_ok true/false)
- Ready flag settings

## 4. Outputs and Effects

### Test Outputs

The primary output of the `test_step` method is the ID of the selected autopilot after arbitration, which is compared against expected values to determine test success.

For the Autopilot tests (4xVTC-3), the outputs include:
- Autopilot detection status (`get_detected()`)
- Kill me status (`get_kill_me()`)
- Overall test success/failure

## 5. Parameters and Configuration

### Arbitration Configuration Parameters

The test framework configures the arbitration system with the following parameters:

```cpp
static Arbitration_cfg cfg;
cfg.preferred = preferred;
cfg.method = method;
cfg.arb_tmin = -Const::MAX;  // Makes PDI fail, but it's intentional for testing
cfg.use_external_ap = (num_aps == Arbitration_cfg::nmaxautopilots);
```

These parameters allow tests to validate different arbitration methods and configurations.

## 6. Error Handling and Contingency Logic

### Error Handling in Tests

The test framework includes error handling mechanisms:

1. `Lossy_error` for capturing and reporting errors
2. `PDIcheck::commit` for handling PDI errors
3. Special handling for intentional PDI failures (setting `arb_tmin` to `-Const::MAX`)

## 7. File-by-File Breakdown

### code/test/Arbitration_test.cpp

This file contains the core test infrastructure for the arbitration system:

- `Aux_Iiterator` class: Implements the `Iiterator<Ideadmanchecker&>` interface for testing
- `Arbitration_test` class: Provides the main test functionality
  - Constructor: Initializes the test environment
  - `test_step`: Configures and executes arbitration tests
  - Private members: Manages test resources

### code/Vcast_projects/4xVTC-1/4xVTC-1.bat

This batch file executes the VectorCAST tests for the arbitration step functionality:

1. Builds the test environment (`4xVTC-1.env`)
2. Runs the test script (`4xVTC-1.tst`)
3. Executes the tests using CLICAST
4. Generates coverage reports for statement and MCDC coverage

### code/Vcast_projects/4xVTC-1/Readme.md

This file documents the 4xVTC-1 test project, which focuses on verifying the CAP (Current AutoPilot) selection function by testing the `Arb::Arbitration::Step` method. The tests validate:

1. Different arbitration methods:
   - Fixed on AP1, AP2, AP3, APExt
   - Change if worst
   - Always best
   - Change on kill me

2. Various autopilot states:
   - All autopilots alive
   - All autopilots dead
   - Best autopilot dead
   - Two best autopilots dead

The test cases are organized as follows:

| Test Case | Description | Iterations | Focus |
|-----------|-------------|------------|-------|
| 001.changefixed | Fixed methods | 4 | One for each fixed method |
| 002.changebestworst.nokilled | Change if worst, Always best | 8 | All APs alive, current AP 0-3 |
| 003.changebestworst.allkilled | Change if worst, Always best | 8 | All APs dead, current AP 0-3 |
| 004.changebestworst.bestkilled | Change if worst, Always best | 8 | Best AP dead, current AP 0-3 |
| 005.changeifworst.bestkilled | Change if worst | 1 | Best AP dead, current AP 3 |
| 006.changeonkill.bestkilled | Change on kill me | 4 | Best AP dead, current AP 0-3 |
| 007.changebestworst.2bestkilled | Change if worst, Always best | 8 | Two best APs dead, current AP 0-3 |

### code/Vcast_projects/4xVTC-3/4xVTC-3.bat

This batch file executes the VectorCAST tests for the autopilot step functionality:

1. Builds the test environment (`4xVTC-3.env`)
2. Runs the test script (`4xVTC-3.tst`)
3. Executes the tests using CLICAST
4. Disables UUT coverage for specific units:
   - Endian64_big
   - Endian64_little
   - Autopilot_test

### code/Vcast_projects/4xVTC-3/Readme.md

This file documents the 4xVTC-3 test project, which focuses on verifying the High Level Information checking by testing the `Arb::Autopilot::step` method. The tests validate:

1. Autopilot status detection
2. Kill me flag behavior
3. Deadman checker functionality
4. Timing-related behaviors

The test cases are organized as a sequence of subtests (0.1 through 0.9) that build upon each other, with each subtest modifying specific parameters:

| Subtest | System Time | AP Status | Deadmanchecker | Ready Flag | Expected Outputs |
|---------|-------------|-----------|----------------|------------|------------------|
| 0.1 | 0.0 | valid(true) | is_ok(true) | - | get_status=valid, get_detected=true |
| 0.2 | 0.25 | - | is_ok(true) | - | get_kill_me=true |
| 0.3 | 0.25 | - | is_ok(true) | - | get_detected=false, get_kill_me=false |
| 0.4 | 0.25 | valid(true) | is_ok(false) | - | get_detected=false, get_kill_me=false |
| 0.5 | 7.0 | - | is_ok(false) | - | get_detected=false, get_kill_me=true |
| 0.6 | 7.0 | - | is_ok(true) | - | get_detected=true, get_kill_me=true |
| 0.7 | 7.0 | - | is_ok(true) | - | get_detected=true, get_kill_me=true |
| 0.8 | 0.0 | valid(true) | is_ok(true) | true | get_detected=true, get_kill_me=false |
| 0.9 | 0.0 | valid(true) | is_ok(false) | true | get_detected=true, get_kill_me=true |

## 8. Cross-Component Relationships

### Test Framework Integration

The test framework integrates with several components of the arbitration system:

1. **Arbitration Component**:
   - `Arbitration_test` directly interacts with the `Arbitration` class
   - Tests validate the arbitration logic and autopilot selection

2. **Deadmanchecker Component**:
   - Tests use `Deadmanchecker_null` for testing
   - `Aux_Iiterator` provides an iterator interface for deadman checkers

3. **Autopilot Component**:
   - Tests configure and validate autopilot behavior
   - Verify autopilot status detection and kill me flag behavior

4. **PDIcheck Component**:
   - Tests interact with PDI for configuration and error handling

### VectorCAST Project Relationships

The VectorCAST projects are organized to test different aspects of the arbitration system:

1. **4xVTC-1**: Tests the arbitration step functionality and CAP selection
2. **4xVTC-3**: Tests the autopilot step functionality and HLI checking

## 9. Test Scenarios for Critical Safety Features

### Safety-Critical Test Scenarios

The test framework includes several scenarios designed to verify critical safety features:

1. **Autopilot Failure Detection**:
   - Tests verify that the system correctly detects when autopilots are dead or unresponsive
   - Validates the "kill_me" flag behavior under various conditions

2. **Failover Behavior**:
   - Tests validate that the system correctly switches to alternative autopilots when the current one fails
   - Verifies different arbitration methods handle failures appropriately

3. **Timing-Related Safety**:
   - Tests with different system times (0.0, 0.25, 7.0) verify timing-dependent behaviors
   - Validates that timeouts are correctly handled

4. **Edge Cases**:
   - Tests with all autopilots dead
   - Tests with the best autopilot dead
   - Tests with the two best autopilots dead

### Arbitration Method Validation

The tests thoroughly validate all arbitration methods:

1. **Fixed Methods**:
   - Fixed on AP1, AP2, AP3, APExt
   - Verifies that the system correctly maintains the specified autopilot

2. **Dynamic Selection Methods**:
   - Change if worst: Switches only if current AP is the worst
   - Always best: Always selects the best available AP
   - Change on kill me: Switches when the current AP is killed

## 10. Test Infrastructure Details

### VectorCAST Integration

The testing framework leverages VectorCAST for:

1. **Test Execution**:
   - Batch files (.bat) automate test execution
   - CLICAST commands run tests and generate reports

2. **Coverage Analysis**:
   - Statement coverage
   - MCDC (Modified Condition/Decision Coverage)
   - Selective UUT (Unit Under Test) coverage disabling

3. **Test Organization**:
   - Environment files (.env) define test environments
   - Test scripts (.tst) define test sequences

### Test Validation Approach

The tests use a pass/fail approach based on:

1. **Expected vs. Actual Comparison**:
   - For 4xVTC-1: Compare selected autopilot with expected selection
   - For 4xVTC-3: Compare autopilot status flags with expected values

2. **Sequential Testing**:
   - Some tests build upon previous test states
   - Tests verify both immediate and cumulative effects

## Conclusion

The arbitration system testing framework provides comprehensive validation of the system's behavior through:

1. A dedicated test class (`Arbitration_test`) that enables detailed testing of arbitration logic
2. Multiple VectorCAST projects (4xVTC-1, 4xVTC-3) that focus on different aspects of the system
3. Detailed test scenarios that verify normal operation, edge cases, and failure handling
4. Comprehensive coverage of all arbitration methods and autopilot states

The framework ensures that the arbitration system correctly selects autopilots based on their health, scores, and the configured arbitration method, even in failure scenarios. The tests validate critical safety features such as autopilot failure detection, failover behavior, and timing-related safety mechanisms.

## Referenced Context Files

No additional context files were provided beyond the primary source files analyzed above.