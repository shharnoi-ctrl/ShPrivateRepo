# Generated from:

- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/arbiter/03_Core_Arbitration_System.md (4083 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/arbiter/03_Autopilot_Management.md (3302 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/arbiter/03_Safety_Monitoring.md (3869 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/arbiter/03_Communication_Interfaces.md (4010 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/arbiter/02_Testing_Framework.md (3308 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/arbiter/02_Arbitration_System_Integration.md (3609 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/arbiter/01_Complete_Arbitration_Framework.md (3065 tokens)

---

# Arbitration System Knowledge Graph: System Overview

## Executive Summary

The Arbitration System is a safety-critical component designed to select the most appropriate autopilot from multiple redundant options (3-4 autopilots) in a drone control system. It implements sophisticated voting mechanisms, comprehensive health monitoring, and robust communication interfaces to ensure reliable operation even when individual autopilots fail. The system continuously evaluates autopilot health and performance, dynamically selecting the best option based on configurable criteria while maintaining flight stability during transitions.

## System Architecture

The Arbitration Framework consists of four primary subsystems:

```
┌─────────────────────────────────────────────────────────────────┐
│                     Arbitration System                          │
│                                                                 │
│  ┌───────────────────┐        ┌───────────────────────────┐     │
│  │                   │        │                           │     │
│  │  Core Arbitration ◄────────► Autopilot Management      │     │
│  │  System           │        │ (3-4 Autopilots)          │     │
│  │                   │        │                           │     │
│  └─────────┬─────────┘        └─────────────┬─────────────┘     │
│            │                                │                   │
│            │                                │                   │
│            ▼                                ▼                   │
│  ┌─────────────────────┐      ┌─────────────────────────────┐   │
│  │                     │      │                             │   │
│  │  Communication      │      │  Safety Monitoring          │   │
│  │  Interfaces         │      │  (Deadman Checker)          │   │
│  │                     │      │                             │   │
│  └─────────────────────┘      └─────────────────────────────┘   │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### 1. Core Arbitration System

The central decision-making engine that:
- Implements multiple selection algorithms (always_best, change_if_worst, round_robin, etc.)
- Computes scores for each autopilot based on weighted variables
- Applies hysteresis to prevent rapid switching
- Enforces minimum selection time between switches
- Maintains the Current AutoPilot (CAP) selection

For detailed information, see [03_Core_Arbitration_System.md](03_Core_Arbitration_System.md).

### 2. Autopilot Management

Tracks and evaluates individual autopilots by:
- Monitoring health status through deadman checks
- Tracking variable freshness (updates within 150ms)
- Computing performance scores for arbitration
- Detecting and handling autopilot failures
- Managing autopilot state (detected, killed)

For detailed information, see [03_Autopilot_Management.md](03_Autopilot_Management.md).

### 3. Safety Monitoring

Ensures autopilot health through:
- Deadman signal checking (100-125 Hz frequency)
- Edge detection requiring transitions every 8ms
- Real-time monitoring via periodic interrupts
- Immediate failure reporting when timeouts occur

For detailed information, see [03_Safety_Monitoring.md](03_Safety_Monitoring.md).

### 4. Communication Interfaces

Enables data exchange via:
- CAN bus for status and variable updates
- Periodic status messages (default: 250ms)
- Periodic score messages (default: 3s)
- GPIO control for physical autopilot selection
- Multiplexing of inputs from multiple autopilots

For detailed information, see [03_Communication_Interfaces.md](03_Communication_Interfaces.md).

## Key System Features

### Selection Methods

The system supports multiple selection algorithms:
- **always_best**: Always selects the autopilot with the best score
- **change_if_worst**: Only changes if current autopilot has worst score
- **round_robin**: Rotates through all available autopilots
- **fixed_always_X**: Always selects a specific autopilot
- **fixed_while_ok**: Uses preferred autopilot unless it fails

### Health Monitoring

Multiple layers of health monitoring ensure reliable operation:
1. **Deadman Signal Checking**: Requires signal transitions at least once every 8ms
2. **Variable Freshness**: Ensures updates occur at least once every 150ms
3. **Self-Reported Status**: Respects autopilot's own health assessment
4. **Watchdog Monitoring**: Detects complete autopilot failures within 5s

### Stability Mechanisms

To prevent rapid switching between autopilots:
- **Hysteresis Parameter**: Requires significant score differences before switching
- **Minimum Selection Time**: Enforces a minimum dwell time (default 100ms)
- **Selection Method Options**: Provides varying levels of stability vs. responsiveness

### Safety Features

The system implements several critical safety features:
- **N-1 Redundancy**: Can lose one autopilot and continue operation
- **Diverse Selection Methods**: Different strategies for various failure scenarios
- **Fallback Mechanisms**: Preferred autopilot selection if all others fail
- **Defensive Programming**: Extensive error checking and validation

## Testing and Validation

The system is validated through a comprehensive testing framework:
- **VectorCAST Test Projects**: Validate CAP selection and health monitoring
- **Diverse Test Scenarios**: Cover normal operation, failures, and edge cases
- **Coverage Metrics**: Statement coverage and MCDC (Modified Condition/Decision Coverage)

For detailed information, see [02_Testing_Framework.md](02_Testing_Framework.md).

## System Integration

The Arbitration Framework integrates with multiple drone systems:
- **Autopilot Systems**: Receives status and variables via CAN, monitors deadman signals
- **Control Systems**: Controls outputs through GPIO multiplexing, provides status information
- **Configuration**: Supports PDI deserialization, CAN ID mapping, variable configuration

For detailed information, see [02_Arbitration_System_Integration.md](02_Arbitration_System_Integration.md).

## Data Flow

### Input Processing
- Autopilot status messages received via CAN bus
- Variable updates for scoring received via CAN bus
- Deadman signals monitored via GPIO pins at 100-125 Hz

### Core Processing
- Health evaluation for each autopilot
- Score computation based on weighted variables
- Autopilot selection using configurable methods
- Hysteresis application to prevent rapid switching

### Output Generation
- Status messages sent via CAN bus (250ms default period)
- Score messages sent via CAN bus (3s default period)
- GPIO control signals for physical autopilot selection

## Conclusion

The Arbitration System provides a robust, configurable mechanism for selecting between multiple autopilots based on their health and performance. Its comprehensive health monitoring, flexible selection algorithms, and stability mechanisms ensure reliable operation in safety-critical applications. The system's architecture follows sound design principles, with clear separation of concerns, interface-based design, and defensive programming practices.

For a complete understanding of the system, please refer to the detailed documentation in the linked files.