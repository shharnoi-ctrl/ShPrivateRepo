# Generated from:

- code/include/Arbitration_can.h (1421 tokens)
- code/include/CANgpio_c.h (1062 tokens)
- code/source/Arbitration_can.cpp (1293 tokens)
- code/source/CANgpio_c.cpp (732 tokens)

---

# Arbitration System Communication Interfaces Analysis

This document provides a comprehensive analysis of the communication interfaces that connect the arbitration system to external components, focusing on CAN bus communication and GPIO control integration.

## 1. CAN Communication Architecture

### 1.1 Core Components

The arbitration system implements a CAN-based communication architecture through two primary classes:

- **`Arb::Arbitration_can`**: Handles CAN message processing for the arbitration system
- **`Base::CANgpio_c`**: Manages GPIO control via CAN messages

These components work together to enable:
1. Reception of inputs from multiple autopilots via CAN
2. Transmission of arbitration status and voting scores
3. Control of GPIO outputs based on arbitration decisions

### 1.2 Arbitration_can Class Structure

```cpp
class Arbitration_can : public Base::Ideserializable, public Base::Itproducer_can, public Base::Itconsumer_can
```

The `Arbitration_can` class implements three interfaces:
- `Base::Ideserializable`: Allows configuration via PDI (Parameter Data Item)
- `Base::Itproducer_can`: Enables sending CAN messages (status and scores)
- `Base::Itconsumer_can`: Enables receiving CAN messages from autopilots

#### 1.2.1 Key Member Variables

```cpp
Arb::Arbitration&   arb;            // Arbitration reference
Base::Chrono        clk_status;     // Chrono to trigger status telemetry send
Base::Chrono        clk_score;      // Chrono to trigger score telemetry send
Base::Map<Base::CANid, Uint16> rxtelemetry; // Map with accepted ids for each autopilot
Base::CANid         txtelemetry;    // CAN ID for send info of autopilots
bool                status_enabled; // Enable status report
Real                status_p;       // Period for status telemetry
bool                score_enabled;  // Enable score report
Real                score_p;        // Period for voting telemetry
Uint16              sendstate;      // Used to retrieve sequentially data to send by CAN
Istatus_hook*       status_hook;    // Hook for additional status information
```

#### 1.2.2 Constants

```cpp
namespace Arbitration_consts {
    const Base::CANid def_txid = { false, 0xFF };   // Default TX CAN id
    const Real def_status_p = 0.25F;                // Default period to send status (250ms)
    const Real def_score_p  = 3.0F;                 // Default period to send scores (3s)
    const Real min_telemetry_p = 0.001F;            // Min period values for status and scores
    static const Uint8 str_sz = 4;                  // 4 words are needed to store a CAN message
    static const Uint16 max_ap_entries = 20;        // Max entries for autopilots CAN ids
}
```

## 2. CAN Message Reception and Processing

### 2.1 Autopilot Identification

The system maps CAN IDs to specific autopilot indices using a lookup table:

```cpp
void Arbitration_can::set_ap_can_id(const Base::CANid& id, Uint16 ap_idx)
{
    if(Base::Assertions::runtime(ap_idx < arb.get_nautopilots()))
    {
        rxtelemetry.put(id, ap_idx);
    }
}

Uint16 Arbitration_can::get_ap_idx(const Base::CANid& CANid0)
{
    const Uint16* id = rxtelemetry.get_ref(CANid0);
    const Uint16 ap_idx = (id != 0) ? (*id) : Ku16::uMAX;
    return ap_idx;
}
```

This mapping allows the system to identify which autopilot is sending a particular CAN message.

### 2.2 Message Processing

When a CAN message is received, it's processed as follows:

```cpp
bool Arbitration_can::write(const Base::CANframe& rx)
{
    Uint16 ap_idx = get_ap_idx(rx.id);
    if(ap_idx < arb.get_nautopilots())
    {
        Base::Lossy str(const_cast<Base::CANdata&>(rx.data).data.to_mblock8().to_mblock());
        arb.process_rx_msg(ap_idx, str);
    }
    return true;
}
```

The system:
1. Identifies the autopilot index based on the CAN ID
2. Converts the CAN data to a `Lossy` stream
3. Passes the message to the arbitration engine for processing

## 3. Status and Score Transmission

### 3.1 Periodic Transmission

The `Arbitration_can` class sends two types of messages at configurable intervals:

1. **Status Messages**: Sent every `status_p` seconds (default: 0.25s)
2. **Score Messages**: Sent every `score_p` seconds (default: 3.0s)

```cpp
bool Arbitration_can::read(Base::CANframe& data)
{
    bool res = false;
    Base::Data_mutator<Base::Lossy::Mutator_traits8<>, Base::CANdata::CANdata_type::Data_traits8> m(data.data.data);
    Base::Lossy& str(m.m);

    if(status_enabled && (clk_status.toc() > status_p))
    {
        arb.get_status_msg(str);
        if(status_hook)
        {
            status_hook->read_status(str);
        }
        clk_status.tic();  //Start time counter again
    }
    else
    {
        if(score_enabled && (clk_score.toc() > score_p))
        {
            arb.get_vote_msg(sendstate, str);
            sendstate = (sendstate+1) % arb.get_nautopilots();
            if(sendstate == 0)
            {
                clk_score.tic();
            }
        }
    }
    
    Uint16 str_sz = str.ceil_size_bytes();
    if(str_sz > 0)
    {
        data.id = txtelemetry;
        if(Base::Assertions::runtime(str_sz <= Base::CANdata::length_max_std))
        {
            res = true;
        }
    }
    return res;
}
```

### 3.2 Message Rotation for Scores

For score messages, the system rotates through all autopilots, sending one autopilot's score per call:

1. Gets the vote message for the current autopilot index (`sendstate`)
2. Increments `sendstate` for the next call
3. When all autopilots have been processed, resets the timer

This rotation mechanism allows the system to distribute score information for all autopilots over time.

### 3.3 Status Hook Interface

The system provides a hook interface for additional status information:

```cpp
class Istatus_hook
{
public:
    virtual void read_status(Base::Lossy& str) = 0;
protected:
    Istatus_hook(); ///< = delete
    ~Istatus_hook(); ///< = delete
private:
    Istatus_hook(const Istatus_hook&); ///< = delete
    Istatus_hook operator=(const Istatus_hook&); ///< = delete
};
```

This allows external components to add information to the status messages.

## 4. Configuration via PDI

The `Arbitration_can` class can be configured via a Parameter Data Item (PDI):

```cpp
void Arbitration_can::cset(Base::Lossy_error& str)
{
    Uint16 size = 0;
    str.get_uint16(size);
    for (Uint16 i = 0; i<size; i++)
    {
        Base::CANid id;
        id.cset(str);
        Uint16 ap_id;
        str.get_uint16(ap_id);
        rxtelemetry.put(id, ap_id);
    }
    txtelemetry.cset(str);
    str.get_float(status_p);
    str.get_float(score_p);
    str.get_bool16(status_enabled);
    str.get_bool16(score_enabled);

    str.assrt(status_p > (Arbitration_consts::min_telemetry_p-Const::EPS),Base::err_arbitration_can);
    str.assrt(score_p > (Arbitration_consts::min_telemetry_p-Const::EPS), Base::err_arbitration_can);
}
```

The PDI structure is:

| Type | Name | Description | Range |
|------|------|-------------|-------|
| Array<CANid, nmax> | rxtelemetry | Array of CAN identifier for each AP (with nmax=4) | - |
| CANid | txtelemetry | Unique CAN identifier | - |
| Real32 | status_p | Period for status telemetry | > 0.001 s |
| Real32 | score_p | Period for voting telemetry | > 0.001 s |
| Bool16 | status_enabled | At true if status outputed | [0,1] |
| Bool16 | score_enabled | At true if voting outputed | [0,1] |

With CANid defined as:

| Type | Name | Description | Range |
|------|------|-------------|-------|
| bool | extended | Extended identifier flag | [0,1] |
| Uint32 | id | CAN identifier (11 bits if standard or 29 if extended) | [0:2,047] or [0:536,870,911] |

## 5. GPIO Control Integration

### 5.1 CANgpio_c Class Structure

```cpp
class CANgpio_c : public Base::Itconsumer_can, public Base::Icallback
```

The `CANgpio_c` class implements:
- `Base::Itconsumer_can`: Receives CAN messages for GPIO control
- `Base::Icallback`: Provides a callback mechanism to update GPIO outputs

### 5.2 Input Multiplexing

The class uses an `Input_mux` template to multiplex inputs from different autopilots:

```cpp
typedef Input_mux<bool, Arb::Arbitration_cfg::nmaxautopilots> GPIO_mux;
Base::Array<GPIO_mux> input_mgr; // GPIO input multiplexer
```

This allows the system to:
1. Receive GPIO control commands from multiple autopilots
2. Select which autopilot's command to use based on arbitration decisions

### 5.3 GPIO Control Message Format

GPIO control messages have a specific format:

```
|Type   |Name   |Comment                |
|-------|-------|------------------------|
|Uint32 |mask   |Mask with selected GPIOS|
|Uint32 |values |Value to set each GPIO  |
```

The `mask` indicates which GPIOs to modify, and `values` contains the desired state for each selected GPIO.

### 5.4 GPIO Activation Process

When a GPIO control message is received, it's processed as follows:

```cpp
void CANgpio_c::activate_gpios(Uint32 mask, Uint32 values, Uint16 idx)
{
    for (Uint16 i = 0; i < CANgpio_p::Config::max_gpios; ++i)
    {
        const Uint32 sel = Ku32::u1 << i; //current index mask
        if (mask & sel)
        {
            input_mgr[i].set_input(((values & sel) != 0), idx);
        }
    }
}
```

For each GPIO:
1. Check if it's selected in the mask
2. If selected, set its input value based on the corresponding bit in `values`
3. Associate the input with the autopilot index

### 5.5 GPIO Update Mechanism

The `call()` method updates all GPIO outputs based on the current arbitration state:

```cpp
void CANgpio_c::call()
{
    for (Uint16 i = 0; i <input_mgr.size(); i++)
    {
        input_mgr[i].update();
    }
}
```

This method is called periodically to ensure GPIO outputs reflect the latest arbitration decisions.

## 6. GPIO Build Iterator

The `GPIO_build_iterator` class is used to initialize the GPIO multiplexers:

```cpp
class GPIO_build_iterator : public Base::Iiterator<GPIO_mux::Build_params>
{
public:
    GPIO_build_iterator(Base::Igpiosuite& isuite0, const Base::Icurrent& icurrent0) :
        isuite(isuite0),
        icurrent(icurrent0),
        ids(0,isuite0.get_bvar_size() -1)
    {
    }

    virtual inline Uint16 pending_size() const
    {
        return ids.pending_size();
    }

    inline GPIO_mux::Build_params next()
    {
        return (GPIO_mux::Build_params) { isuite, icurrent, ids.next() };
    }
private:
    Base::Igpiosuite& isuite;            // GPIO suite to be used
    const Base::Icurrent& icurrent;      // Icurrent interface to get current selected input
    Base::Rngit<Uint16> ids;             // IDs range
};
```

This iterator:
1. Provides build parameters for each GPIO multiplexer
2. Includes references to the GPIO suite and current selection interface
3. Iterates through all GPIO IDs in the suite

## 7. Communication Flow Diagram

```
                  +-------------------+
                  |  Arbitration_can  |
                  +-------------------+
                  | - rxtelemetry     |
                  | - txtelemetry     |
                  | - clk_status      |
                  | - clk_score       |
                  +--------+----------+
                           |
           +---------------+---------------+
           |                               |
+----------v-----------+       +-----------v----------+
|  CAN Bus (Incoming)  |       |  CAN Bus (Outgoing)  |
+----------+-----------+       +-----------+----------+
           |                               |
           |                               |
+----------v-----------+       +-----------v----------+
|  Autopilot Messages  |       | - Status Messages    |
|  (Inputs to Arbiter) |       | - Score Messages     |
+----------+-----------+       +----------------------+
           |
           |
+----------v-----------+
|     Arbitration      |
|       Engine         |
+----------+-----------+
           |
           |
+----------v-----------+
|     CANgpio_c        |
+----------+-----------+
| - input_mgr          |
+----------+-----------+
           |
           |
+----------v-----------+
|    GPIO Outputs      |
+---------------------+
```

## 8. Timing Characteristics

### 8.1 Status Message Timing

- Default period: 250ms (0.25s)
- Minimum period: 1ms (0.001s)
- Controlled by: `status_p` parameter
- Triggered by: `clk_status` chronometer

### 8.2 Score Message Timing

- Default period: 3000ms (3.0s)
- Minimum period: 1ms (0.001s)
- Controlled by: `score_p` parameter
- Triggered by: `clk_score` chronometer
- Rotation: One autopilot per cycle, complete cycle resets timer

### 8.3 GPIO Update Timing

- Triggered by: External call to `CANgpio_c::call()`
- Updates all GPIO outputs based on current arbitration state

## 9. Message Format Details

### 9.1 Status Message

The status message is generated by:
```cpp
arb.get_status_msg(str);
if(status_hook)
{
    status_hook->read_status(str);
}
```

The exact format is determined by the `Arbitration` class and any registered status hooks.

### 9.2 Score Message

The score message is generated by:
```cpp
arb.get_vote_msg(sendstate, str);
```

Where `sendstate` is the index of the autopilot whose score is being reported.

### 9.3 GPIO Control Message

```
|Type   |Name   |Comment                |
|-------|-------|------------------------|
|Uint32 |mask   |Mask with selected GPIOS|
|Uint32 |values |Value to set each GPIO  |
```

## 10. Error Handling and Validation

### 10.1 CAN ID Validation

```cpp
void Arbitration_can::set_ap_can_id(const Base::CANid& id, Uint16 ap_idx)
{
    if(Base::Assertions::runtime(ap_idx < arb.get_nautopilots()))
    {
        rxtelemetry.put(id, ap_idx);
    }
}
```

The system validates that autopilot indices are within the valid range before adding them to the mapping.

### 10.2 Message Size Validation

```cpp
Uint16 str_sz = str.ceil_size_bytes();
if(str_sz > 0)
{
    data.id = txtelemetry;
    if(Base::Assertions::runtime(str_sz <= Base::CANdata::length_max_std))
    {
        res = true;
    }
}
```

The system validates that outgoing messages fit within the standard CAN frame size.

### 10.3 Configuration Validation

```cpp
str.assrt(status_p > (Arbitration_consts::min_telemetry_p-Const::EPS),Base::err_arbitration_can);
str.assrt(score_p > (Arbitration_consts::min_telemetry_p-Const::EPS), Base::err_arbitration_can);
```

The system validates that the status and score periods are above the minimum threshold.

## 11. Referenced Context Files

The following context files were helpful in understanding the communication interfaces:

- **Arbitration_cfg.h**: Provides configuration constants like `nmaxautopilots` and `nminautopilots`
- **Input_mux.h**: Implements the multiplexing logic for GPIO inputs
- **Igpiosuite.h**: Defines the interface for GPIO suite operations
- **Icurrent.h**: Provides the interface for determining the current selected input

## 12. Summary

The arbitration system's communication interfaces are built around:

1. **CAN Bus Communication**:
   - Receives inputs from multiple autopilots
   - Sends status and score information
   - Maps CAN IDs to autopilot indices

2. **GPIO Control Integration**:
   - Multiplexes GPIO inputs from different autopilots
   - Selects outputs based on arbitration decisions
   - Updates GPIO states based on CAN messages

3. **Timing Characteristics**:
   - Status messages: Default 250ms
   - Score messages: Default 3000ms, rotated through autopilots
   - Configurable periods with minimum threshold of 1ms

4. **Message Formats**:
   - Status messages: Generated by arbitration engine
   - Score messages: One autopilot per message, rotated
   - GPIO control messages: Mask and values for selected GPIOs

This architecture enables the arbitration system to effectively communicate with external components while maintaining control over critical outputs based on arbitration decisions.