# Generated from:

- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/arbiter/03_Core_Arbitration_System.md (4083 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/arbiter/03_Autopilot_Management.md (3302 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/arbiter/03_Safety_Monitoring.md (3869 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/arbiter/03_Communication_Interfaces.md (4010 tokens)

---

# Comprehensive System-Level Summary of the Arbitration System

## 1. System Architecture Overview

The Arbitration System is a robust, safety-critical component designed to select the most appropriate autopilot from multiple available options based on their health status and performance. The system implements a sophisticated voting mechanism with multiple selection algorithms, comprehensive health monitoring, and reliable communication interfaces.

The architecture consists of four primary subsystems:
1. **Core Arbitration System**: The central decision-making engine
2. **Autopilot Management**: Tracks and evaluates individual autopilots
3. **Safety Monitoring**: Ensures autopilot health through deadman signal checking
4. **Communication Interfaces**: Enables data exchange via CAN bus and GPIO control

```
┌─────────────────────────────────────────────────────────────────┐
│                     Arbitration System                          │
│                                                                 │
│  ┌───────────────────┐        ┌───────────────────────────┐     │
│  │                   │        │                           │     │
│  │  Core Arbitration ◄────────► Autopilot Management      │     │
│  │  System           │        │ (3-4 Autopilots)          │     │
│  │                   │        │                           │     │
│  └─────────┬─────────┘        └─────────────┬─────────────┘     │
│            │                                │                   │
│            │                                │                   │
│            ▼                                ▼                   │
│  ┌─────────────────────┐      ┌─────────────────────────────┐   │
│  │                     │      │                             │   │
│  │  Communication      │      │  Safety Monitoring          │   │
│  │  Interfaces         │      │  (Deadman Checker)          │   │
│  │                     │      │                             │   │
│  └─────────────────────┘      └─────────────────────────────┘   │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

## 2. Data Flow Architecture

The Arbitration System implements a comprehensive data flow architecture that enables reliable selection of the Current AutoPilot (CAP):

### 2.1 Input Data Flow

1. **Autopilot Status Messages**
   - Received via CAN bus through `Arbitration_can`
   - Mapped to specific autopilot instances using CAN ID mapping
   - Processed by `Arbitration::process_rx_msg()`
   - Updates autopilot status via `Autopilot::set_status()`

2. **Variable Updates**
   - Received via CAN bus through `Arbitration_can`
   - Contains arbitration variables used for scoring
   - Updates autopilot variables via `Autopilot::set_var()`
   - Tracked for freshness using `updated` bitarray

3. **Deadman Signals**
   - Received via GPIO pins
   - Monitored by `Deadmanchecker` at 100-125 Hz
   - Expected to transition at least once every 8ms
   - Status accessible via `Deadmanchecker::is_ok()`

### 2.2 Processing Flow

1. **Autopilot Health Monitoring**
   - Each autopilot's health is evaluated in `Autopilot::step()`
   - Checks deadman signal via `dm.is_ok()`
   - Verifies variable freshness via `chrono_var.toc()`
   - Sets `kill_me` flag if any check fails

2. **Score Computation**
   - Triggered in `Arbitration::compute_scores()`
   - For relative variables, computes mean across autopilots
   - Calculates normalized error for each variable
   - Applies variable weights and computes final score
   - Identifies best and worst performing autopilots

3. **Autopilot Selection**
   - Based on configured method in `Arbitration::get_next_ap()`
   - Methods include `always_best`, `change_if_worst`, `round_robin`, etc.
   - Applies hysteresis to prevent rapid switching
   - Enforces minimum selection time via `arb_tmin`

### 2.3 Output Data Flow

1. **Status Messages**
   - Generated via `Arbitration::get_status_msg()`
   - Sent periodically (default: 250ms) via CAN
   - Contains current autopilot selection and health status
   - Can be extended via `Istatus_hook` interface

2. **Score Messages**
   - Generated via `Arbitration::get_vote_msg()`
   - Sent periodically (default: 3s) via CAN
   - Rotates through autopilots, one per message
   - Contains voting scores for arbitration decisions

3. **GPIO Control**
   - Managed by `CANgpio_c` class
   - Multiplexes inputs from multiple autopilots
   - Selects outputs based on current autopilot selection
   - Updates GPIO states via `input_mgr[i].update()`

## 3. Key Interfaces

### 3.1 Core Arbitration Interfaces

1. **Arbitration to Autopilot Interface**
   - `Autopilot::step()`: Evaluates autopilot health
   - `Autopilot::vote(refval)`: Computes autopilot score
   - `Autopilot::get_kill_me()`: Reports autopilot failure status
   - `Autopilot::get_detected()`: Reports autopilot detection status

2. **Arbitration to Safety Monitoring Interface**
   - `Ideadmanchecker::is_ok()`: Reports deadman signal status
   - `Ideadmanchecker::step()`: Processes deadman signal

3. **Arbitration to Communication Interface**
   - `Arbitration::process_rx_msg()`: Processes incoming CAN messages
   - `Arbitration::get_status_msg()`: Generates status messages
   - `Arbitration::get_vote_msg()`: Generates score messages

### 3.2 External Interfaces

1. **CAN Bus Interface**
   - `Itconsumer_can::write()`: Receives CAN messages
   - `Itproducer_can::read()`: Sends CAN messages
   - Maps CAN IDs to autopilot indices

2. **GPIO Interface**
   - `Igpiosuite`: Provides access to GPIO pins
   - `Icurrent`: Reports current autopilot selection
   - `Input_mux`: Multiplexes inputs from multiple autopilots

3. **Callback Interface**
   - `Icallback::call()`: Notifies of autopilot selection changes
   - `Istatus_hook::read_status()`: Extends status messages

## 4. System Behavior

### 4.1 Initialization and Startup

1. The Arbitration System initializes with:
   - Configuration parameters (method, hysteresis, etc.)
   - Deadman checker interface
   - Callback interface
   - Default preferred autopilot (typically index 0)

2. Startup sequence:
   - All autopilots start in "Not Detected" state
   - System waits for valid status and deadman signals
   - Once all autopilots are detected, `arbiter_ready` is set to true
   - Initial autopilot selection is made based on configuration

### 4.2 Normal Operation

During normal operation, the system:

1. Continuously monitors all autopilots via `step()` method
2. Computes scores for each autopilot based on their variables
3. Selects the Current AutoPilot (CAP) based on the configured method
4. Sends status and score messages via CAN bus
5. Controls GPIO outputs based on the selected autopilot

The selection method determines how aggressively the system switches between autopilots:
- `always_best`: Always selects the autopilot with the best score
- `change_if_worst`: Only changes if current autopilot has worst score
- `round_robin`: Rotates through all available autopilots
- `fixed_always_X`: Always selects a specific autopilot
- `fixed_while_ok`: Uses preferred autopilot unless it fails

### 4.3 Failure Handling

The system implements multiple layers of failure detection:

1. **Autopilot-level failures**:
   - Deadman signal loss (no transitions within 8ms)
   - Variable update timeout (no updates within 150ms)
   - Self-reported invalid status
   - Watchdog timeout (5s after first status)

2. **System-level responses**:
   - Failed autopilots are marked with `kill_me = true`
   - Failed autopilots are excluded from arbitration
   - System selects next best autopilot based on method
   - If all autopilots fail, system selects preferred autopilot

3. **Recovery mechanisms**:
   - Autopilots can be restarted via `restart()` method
   - External control via `set_state()` method
   - Configurable hysteresis for stability during transitions

## 5. Critical Safety Features

### 5.1 Deadman Signal Monitoring

The Deadman Checker is a critical safety component that:
- Expects a signal with 100-125 Hz frequency
- Detects transitions (edges) rather than levels
- Requires transitions at least once every 8ms
- Reports failure immediately when timeout occurs
- Operates in real-time via periodic interrupts

This mechanism ensures that autopilots are actively functioning and responsive.

### 5.2 Variable Freshness Monitoring

The system tracks variable update frequency to detect:
- Stale or frozen autopilot outputs
- Communication failures
- Processing delays

Variables must be updated at least once every 150ms, or the autopilot is marked as failed.

### 5.3 Hysteresis and Stability Mechanisms

To prevent rapid switching between autopilots (which could cause system instability):
- Hysteresis parameter (0.001-1.0) requires significant score differences
- Minimum selection time (`arb_tmin`, default 100ms) enforces a minimum dwell time
- Different selection methods provide varying levels of stability vs. responsiveness

### 5.4 Redundancy and Fault Tolerance

The system supports 3-4 autopilots, providing:
- N-1 redundancy (can lose one autopilot and continue)
- Diverse selection methods for different failure scenarios
- Fallback to preferred autopilot if all others fail

## 6. Configuration Parameters

The Arbitration System is highly configurable through several key parameters:

### 6.1 Core Arbitration Parameters

- `method`: Selection algorithm (always_best, change_if_worst, etc.)
- `hysteresis`: Stability parameter (0.001-1.0)
- `arb_tmin`: Minimum selection time (default 100ms)
- `preferred`: Default/fallback autopilot index
- `use_external_ap`: Flag to enable external autopilot

### 6.2 Variable Configuration

Each arbitration variable has:
- `max_error`: Maximum allowed error for scoring
- `is_rel`: Flag for relative vs. absolute reference
- `abs_ref`: Absolute reference value (if is_rel=false)
- `weight`: Variable's importance in scoring

### 6.3 Communication Parameters

- `status_p`: Status message period (default 250ms)
- `score_p`: Score message period (default 3s)
- `status_enabled`: Flag to enable status messages
- `score_enabled`: Flag to enable score messages
- CAN ID mappings for autopilots

## 7. Architectural Patterns and Design Principles

### 7.1 Interface-Based Design

The system extensively uses interfaces to enable:
- Loose coupling between components
- Testability through mock implementations
- Extensibility via interface implementations
- Clear separation of concerns

Key interfaces include:
- `Ideadmanchecker`: For safety monitoring
- `Icallback`: For notification of state changes
- `Itproducer_can`/`Itconsumer_can`: For CAN communication
- `Istatus_hook`: For extending status messages

### 7.2 Composition Over Inheritance

The system favors composition over inheritance:
- `Arbitration` contains multiple `Autopilot` instances
- `Arbitration_can` contains an `Arbitration` reference
- `CANgpio_c` contains multiple `Input_mux` instances

This approach provides flexibility and avoids deep inheritance hierarchies.

### 7.3 Separation of Concerns

Each component has a clear, focused responsibility:
- `Arbitration`: Core selection logic
- `Autopilot`: Individual autopilot tracking
- `Deadmanchecker`: Safety monitoring
- `Arbitration_can`: CAN communication
- `CANgpio_c`: GPIO control

### 7.4 Defensive Programming

The system implements extensive error checking:
- Parameter validation in configuration methods
- Runtime assertions for array bounds
- Timeout detection for critical signals
- Multiple failure detection mechanisms

### 7.5 Real-Time Design Patterns

The system incorporates patterns suitable for real-time operation:
- Thread-safe status reporting
- Periodic execution via interrupts
- Timeout-based failure detection
- Hysteresis for stability

## 8. System Integration

### 8.1 Integration with Autopilot Systems

The Arbitration System integrates with multiple autopilots through:
- CAN message reception for status and variables
- Deadman signal monitoring via GPIO
- Score computation and selection logic
- Status and score reporting via CAN

### 8.2 Integration with Control Systems

The system controls outputs through:
- GPIO multiplexing based on selected autopilot
- CAN message transmission for status and scores
- Callback notifications for selection changes

### 8.3 Configuration Integration

The system can be configured through:
- PDI (Parameter Data Item) deserialization
- CAN ID mapping for autopilot identification
- Variable configuration for scoring parameters
- Timing parameters for message transmission

## 9. Conclusion

The Arbitration System provides a robust, configurable mechanism for selecting between multiple autopilots based on their health and performance. Key strengths include:

1. **Comprehensive Health Monitoring**: Multiple mechanisms detect autopilot failures
2. **Flexible Selection Algorithms**: Various methods for different operational needs
3. **Stability Mechanisms**: Hysteresis and minimum selection time prevent rapid switching
4. **Extensive Configuration**: Highly tunable for different operational scenarios
5. **Robust Communication**: CAN-based messaging with configurable timing
6. **Safety-Critical Design**: Real-time monitoring and redundancy features

The system's architecture follows sound design principles, with clear separation of concerns, interface-based design, and defensive programming practices. These characteristics make it suitable for safety-critical applications where reliable autopilot selection is essential.