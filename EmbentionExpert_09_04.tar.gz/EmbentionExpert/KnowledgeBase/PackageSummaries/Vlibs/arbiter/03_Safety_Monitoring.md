# Generated from:

- code/include/Deadmanchecker.h (508 tokens)
- code/include/Deadmanchecker_fw.h (27 tokens)
- code/include/Deadmanchecker_null.h (274 tokens)
- code/include/Ideadmanchecker.h (156 tokens)
- code/include/Variable_cfg.h (336 tokens)
- code/source/Deadmanchecker.cpp (219 tokens)
- code/source/Variable_cfg.cpp (339 tokens)

---

# Deadman Checker and Variable Configuration System Analysis

## 1. Functional Behavior and Logic

### Deadman Checker System

The Deadman Checker is a critical safety monitoring component that detects autopilot (AP) failures by monitoring a specific signal pattern. Its primary responsibility is to verify that the autopilot is functioning correctly by checking for a deadman signal with a frequency between 100-125 Hz.

#### Key Responsibilities:
- Monitor a GPIO signal from the autopilot
- Detect signal transitions (edges)
- Verify the signal is within expected frequency parameters
- Report autopilot status (OK or failed)

#### Signal Monitoring Logic:
- The system expects regular transitions on the GPIO pin
- A valid signal must transition (change state) at least once every 8 milliseconds
- If no transition occurs within this timeout period, the autopilot is considered failed
- The system uses edge detection (transitions between high and low) rather than level detection

#### Implementation Details:
- Located in `Deadmanchecker.h` and `Deadmanchecker.cpp`
- Implements the `Ideadmanchecker` interface
- Uses a timeout mechanism to detect signal absence
- Designed to be called from a real-time task (periodic interrupt)

### Variable Configuration System

The Variable Configuration system provides a structure to handle arbitration variable configuration, which affects how the arbitration system makes decisions based on weighted inputs and error thresholds.

#### Key Responsibilities:
- Store configuration parameters for arbitration variables
- Define error thresholds for variables
- Specify whether variables use relative or absolute references
- Assign weights to variables for voting/arbitration decisions
- Deserialize configuration from PDIC (Persistent Data Interface Container)

#### Implementation Details:
- Located in `Variable_cfg.h` and `Variable_cfg.cpp`
- Provides a structure with configuration parameters
- Includes deserialization capability from a PDIC source

## 2. Control Flow and State Transitions

### Deadman Checker State Machine

| State | Trigger | Actions | Next State | Location |
|-------|---------|---------|------------|----------|
| Initial | Constructor called | Initialize GPIO interface, set dm_ok=false, last_v=false, first_pulse=true, configure timeout to 8ms | Monitoring | Deadmanchecker.cpp constructor |
| Monitoring (first_pulse=true) | Signal transition detected | Set dm_ok=true, first_pulse=false, restart timeout | Monitoring (first_pulse=false) | Deadmanchecker.cpp step() |
| Monitoring (first_pulse=false) | Signal transition detected | Restart timeout | Monitoring (first_pulse=false) | Deadmanchecker.cpp step() |
| Monitoring (any) | Timeout expired without transition | Set dm_ok=false | Monitoring (same first_pulse state) | Deadmanchecker.cpp step() |

### Variable Configuration State Transitions

| State | Trigger | Actions | Next State | Location |
|-------|---------|---------|------------|----------|
| Default | Constructor called | Set max_error=0.0F, is_rel=true, abs_ref=0.0F, weight=0.0F | Configured | Variable_cfg.cpp constructor |
| Configured | cset() called | Deserialize configuration from PDIC, validate parameters | Configured (with new values) | Variable_cfg.cpp cset() |

## 3. Inputs and Stimuli

### Deadman Checker Inputs

| Input | Processing | Effect | Location |
|-------|------------|--------|----------|
| GPIO signal | Read via gpio.get() in step() method | Detects transitions between high/low states | Deadmanchecker.cpp step() |
| step() call | Called from real-time task (periodic interrupt) | Triggers signal checking and status update | Deadmanchecker.cpp step() |

### Variable Configuration Inputs

| Input | Processing | Effect | Location |
|-------|------------|--------|----------|
| PDIC data stream | Processed by cset() method | Deserializes configuration parameters | Variable_cfg.cpp cset() |
| max_error value | Read from PDIC | Sets maximum allowed error for variable | Variable_cfg.cpp cset() |
| is_rel flag | Read from PDIC | Determines if variable uses relative or absolute reference | Variable_cfg.cpp cset() |
| abs_ref value | Read from PDIC if is_rel=false | Sets absolute reference value | Variable_cfg.cpp cset() |
| weight value | Read from PDIC | Sets variable's weight for voting | Variable_cfg.cpp cset() |

## 4. Outputs and Effects

### Deadman Checker Outputs

| Output | Trigger | Effect | Location |
|--------|---------|--------|----------|
| dm_ok status | Signal transitions within timeout period | Returns true when is_ok() called | Deadmanchecker.cpp is_ok() |
| dm_ok status | No signal transition within timeout period | Returns false when is_ok() called | Deadmanchecker.cpp is_ok() |

### Variable Configuration Outputs

| Output | Trigger | Effect | Location |
|--------|---------|--------|----------|
| Configuration parameters | After successful deserialization | Provides arbitration parameters for decision making | Variable_cfg.cpp cset() |
| Assertion error | Invalid parameters (max_error < 0 or weight < 0) | Triggers error via str.assrt() | Variable_cfg.cpp cset() |

## 5. Parameters and Configuration

### Deadman Checker Parameters

| Parameter | Value | Effect | Location |
|-----------|-------|--------|----------|
| max_dt | 0.008F (8 milliseconds) | Maximum allowed time between signal transitions | Deadmanchecker.cpp static const |
| dm_ok | false (initial) | Status flag indicating AP health | Deadmanchecker.cpp constructor |
| last_v | false (initial) | Stores previous GPIO value for edge detection | Deadmanchecker.cpp constructor |
| first_pulse | true (initial) | Indicates waiting for first pulse | Deadmanchecker.cpp constructor |

### Variable Configuration Parameters

| Parameter | Default Value | Effect | Location |
|-----------|---------------|--------|----------|
| max_error | 0.0F | Maximum allowed error for variable in arbitration | Variable_cfg.cpp constructor |
| is_rel | true | Determines if variable uses relative or absolute reference | Variable_cfg.cpp constructor |
| abs_ref | 0.0F | Absolute reference value (used when is_rel=false) | Variable_cfg.cpp constructor |
| weight | 0.0F | Variable's weight for voting in arbitration | Variable_cfg.cpp constructor |

## 6. Error Handling and Contingency Logic

### Deadman Checker Error Handling

| Error Condition | Detection | Response | Location |
|-----------------|-----------|----------|----------|
| Missing signal transitions | Timeout expiration (>8ms without transition) | Set dm_ok=false, indicating AP failure | Deadmanchecker.cpp step() |
| Initial state (no transitions yet) | first_pulse=true | dm_ok remains false until first transition | Deadmanchecker.cpp step() |

### Variable Configuration Error Handling

| Error Condition | Detection | Response | Location |
|-----------------|-----------|----------|----------|
| Invalid max_error (negative) | Assertion check | Triggers error via str.assrt() with Base::err_arb_varcfg | Variable_cfg.cpp cset() |
| Invalid weight (negative) | Assertion check | Triggers error via str.assrt() with Base::err_arb_varcfg | Variable_cfg.cpp cset() |

## 7. File-by-File Breakdown

### Deadmanchecker.h

This header file defines the `Deadmanchecker` class that implements the `Ideadmanchecker` interface. It provides the capability to check the status of an autopilot by monitoring a deadman signal through a GPIO interface.

Key components:
- `Deadmanchecker` class declaration
- Public methods: constructor, `is_ok()`, and `step()`
- Private attributes: `max_dt`, `gpio`, `dm_ok`, `last_v`, `first_pulse`, and `tout`

### Deadmanchecker.cpp

This implementation file contains the logic for the `Deadmanchecker` class, including the constructor and methods for checking the autopilot status.

Key components:
- Definition of `max_dt` constant (8 milliseconds)
- Constructor implementation
- `is_ok()` method implementation
- `step()` method implementation with signal transition detection logic

### Deadmanchecker_fw.h

A forward declaration header for the `Deadmanchecker` class, allowing other files to reference the class without including the full header.

### Deadmanchecker_null.h

This header defines a null implementation of the `Deadmanchecker` class for testing or situations where actual GPIO monitoring is not needed.

Key components:
- `Deadmanchecker_null` class declaration
- Implementation that always returns `true` for `is_ok()`
- Empty `step()` implementation

### Ideadmanchecker.h

This header defines the interface for deadman checker implementations, providing a common API for different implementations.

Key components:
- `Ideadmanchecker` abstract class declaration
- Pure virtual methods: `is_ok()` and `step()`
- Protected destructor

### Variable_cfg.h

This header defines the `Variable_cfg` structure for handling arbitration variable configuration.

Key components:
- `Variable_cfg` structure declaration
- Configuration attributes: `max_error`, `is_rel`, `abs_ref`, and `weight`
- Constructor and `cset()` method declarations

### Variable_cfg.cpp

This implementation file contains the logic for the `Variable_cfg` structure, including the constructor and deserialization method.

Key components:
- Constructor implementation
- `cset()` method implementation for deserializing configuration from PDIC
- Parameter validation logic

## 8. Cross-Component Relationships

### Deadman Checker Integration

| Component | Relationship | Interaction |
|-----------|--------------|------------|
| Deadmanchecker ↔ IGpio | Dependency | Deadmanchecker uses IGpio to read signal state |
| Deadmanchecker ↔ Timeout | Dependency | Deadmanchecker uses Timeout to detect signal absence |
| Deadmanchecker ↔ Ideadmanchecker | Implementation | Deadmanchecker implements Ideadmanchecker interface |
| Deadmanchecker_null ↔ Deadmanchecker | Inheritance | Deadmanchecker_null extends Deadmanchecker |
| Deadmanchecker_null ↔ GPIO_null | Dependency | Deadmanchecker_null uses GPIO_null for null implementation |

### Variable Configuration Integration

| Component | Relationship | Interaction |
|-----------|--------------|------------|
| Variable_cfg ↔ Lossy_error | Dependency | Variable_cfg uses Lossy_error for deserialization |
| Variable_cfg ↔ Arbitration System | Configuration | Variable_cfg provides parameters for arbitration decisions |

## 9. Detailed Behavioral Analysis

### Deadman Checker Signal Detection Logic

The Deadman Checker implements a precise timing-based detection mechanism:

1. The system expects a signal with frequency between 100-125 Hz
   - This corresponds to a period of 8-10 milliseconds
   - The timeout is set to 8 milliseconds (max_dt)

2. Signal detection process:
   ```
   On each step() call:
     Read current GPIO value (v)
     If v != last_v (transition detected):
       Restart timeout
       If this is the first pulse (first_pulse == true):
         Set first_pulse = false
         Set dm_ok = true (AP is functioning)
     Else (no transition):
       If timeout has expired:
         Set dm_ok = false (AP has failed)
     Store current value for next comparison (last_v = v)
   ```

3. Thread safety considerations:
   - The `is_ok()` method is designed to be thread-safe
   - It can be called from outside the interrupt task
   - The `step()` method is called from a real-time task (periodic interrupt)

### Variable Configuration Deserialization Logic

The Variable Configuration system deserializes configuration parameters from a PDIC with the following structure:

1. PDIC structure:
   - Float: max_error (Maximum error per variable)
   - Bool16: is_rel (True if variable has relative reference)
   - Float: abs_ref (Only if is_rel is false)
   - Float: weight (Variable weight for voting)

2. Deserialization process:
   ```
   In cset() method:
     Read max_error from PDIC
     Read is_rel from PDIC
     If is_rel is true:
       Set abs_ref = 0.0F
     Else:
       Read abs_ref from PDIC
     Read weight from PDIC
     Assert that max_error >= 0.0F and weight >= 0.0F
   ```

3. Parameter validation:
   - Both max_error and weight must be non-negative
   - Validation failure triggers an assertion error (Base::err_arb_varcfg)

## 10. Safety Monitoring Integration

### Deadman Checker in Safety Architecture

The Deadman Checker plays a critical role in the system's safety architecture:

1. Signal monitoring:
   - Continuously monitors the autopilot's deadman signal
   - Expects regular transitions (100-125 Hz frequency)
   - Detects absence of transitions within 8ms timeout

2. Integration with arbitration system:
   - Provides autopilot health status via `is_ok()` method
   - Status likely influences arbitration decisions
   - Allows system to detect and respond to autopilot failures

3. Real-time operation:
   - Designed for real-time execution via periodic interrupts
   - Thread-safe status reporting for cross-thread access

### Variable Configuration in Arbitration

The Variable Configuration system provides essential parameters for the arbitration decision-making process:

1. Error thresholds:
   - `max_error` defines acceptable deviation limits
   - Different variables can have different error tolerances

2. Reference handling:
   - `is_rel` flag determines if relative or absolute references are used
   - `abs_ref` provides absolute reference value when needed

3. Weighting mechanism:
   - `weight` parameter assigns importance to different variables
   - Higher weights give variables more influence in arbitration decisions
   - All weights must be non-negative

4. Configuration flexibility:
   - Parameters can be loaded from persistent storage (PDIC)
   - Allows for runtime or deployment-specific configuration

## 11. Safety-Critical Timing Requirements

### Deadman Checker Timing

The Deadman Checker implements strict timing requirements for safety monitoring:

1. Signal frequency requirements:
   - Expected frequency: 100-125 Hz
   - Corresponding period: 8-10 milliseconds

2. Timeout mechanism:
   - Maximum allowed time without transition: 8 milliseconds (max_dt)
   - Exceeding this timeout triggers failure detection

3. First pulse handling:
   - System starts in failed state (dm_ok = false)
   - First transition sets dm_ok = true
   - Subsequent timeouts can set it back to false

4. Real-time execution:
   - `step()` method must be called from a real-time task
   - Periodic interrupts ensure timely signal monitoring

## 12. Null Implementation Analysis

The `Deadmanchecker_null` class provides a null implementation of the Deadman Checker:

1. Implementation details:
   - Always returns `true` for `is_ok()`
   - Empty `step()` implementation
   - Uses `GPIO_null` instead of actual GPIO

2. Usage scenarios:
   - Testing without hardware dependencies
   - Simulation environments
   - Systems where deadman checking is not required

3. Safety implications:
   - Always reports autopilot as functioning correctly
   - Should not be used in safety-critical deployments
   - Useful for development and testing only

## Referenced Context Files

No context files were provided in the input.