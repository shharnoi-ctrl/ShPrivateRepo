# Generated from:

- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/arbiter/02_Arbitration_System_Integration.md (3609 tokens)
- Amazon-PrimeAir/items/BMS/items/sw_BMS/items/_Vlibs/arbiter/02_Testing_Framework.md (3308 tokens)

---

# Comprehensive Arbitration Framework: System Architecture and Validation

## Executive Summary

The Arbitration Framework is a safety-critical system designed to ensure reliable drone operation by dynamically selecting the most appropriate autopilot from multiple redundant options. This framework implements a sophisticated voting mechanism with comprehensive health monitoring, multiple selection algorithms, and robust communication interfaces. The system's architecture, combined with its extensive testing framework, creates a highly reliable solution for managing autopilot redundancy in safety-critical drone operations.

## 1. System Purpose and Critical Role

The Arbitration Framework serves as the central decision-making authority for autopilot selection, playing a critical role in ensuring safe drone operation by:

- Continuously monitoring the health and performance of 3-4 redundant autopilots
- Dynamically selecting the most appropriate autopilot based on configurable criteria
- Providing N-1 redundancy to maintain flight control even if one autopilot fails
- Implementing multiple layers of safety checks to detect autopilot failures
- Ensuring smooth transitions between autopilots to maintain flight stability
- Providing transparent status reporting for system monitoring

This system is essential for maintaining flight safety in scenarios where individual autopilot failures could otherwise lead to catastrophic outcomes. By implementing a "fail-operational" rather than merely "fail-safe" approach, the Arbitration Framework enables continued mission execution even when components fail.

## 2. System Architecture

### 2.1 Core Components

The Arbitration Framework consists of four primary subsystems working in concert:

1. **Core Arbitration System**: The central decision-making engine that implements the selection algorithms, score computation, and autopilot switching logic.

2. **Autopilot Management**: Tracks and evaluates individual autopilots, monitoring their health status, variable freshness, and performance metrics.

3. **Safety Monitoring**: Ensures autopilot health through deadman signal checking, watchdog timers, and variable freshness verification.

4. **Communication Interfaces**: Enables data exchange via CAN bus for status/variable updates and GPIO control for physical autopilot selection.

```
┌─────────────────────────────────────────────────────────────────┐
│                     Arbitration System                          │
│                                                                 │
│  ┌───────────────────┐        ┌───────────────────────────┐     │
│  │                   │        │                           │     │
│  │  Core Arbitration ◄────────► Autopilot Management      │     │
│  │  System           │        │ (3-4 Autopilots)          │     │
│  │                   │        │                           │     │
│  └─────────┬─────────┘        └─────────────┬─────────────┘     │
│            │                                │                   │
│            │                                │                   │
│            ▼                                ▼                   │
│  ┌─────────────────────┐      ┌─────────────────────────────┐   │
│  │                     │      │                             │   │
│  │  Communication      │      │  Safety Monitoring          │   │
│  │  Interfaces         │      │  (Deadman Checker)          │   │
│  │                     │      │                             │   │
│  └─────────────────────┘      └─────────────────────────────┘   │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### 2.2 Data Flow Architecture

The system implements a comprehensive data flow that enables reliable selection of the Current AutoPilot (CAP):

1. **Input Processing**:
   - Autopilot status messages received via CAN bus
   - Variable updates for scoring received via CAN bus
   - Deadman signals monitored via GPIO pins at 100-125 Hz

2. **Core Processing**:
   - Health evaluation for each autopilot
   - Score computation based on weighted variables
   - Autopilot selection using configurable methods
   - Hysteresis application to prevent rapid switching

3. **Output Generation**:
   - Status messages sent via CAN bus (250ms default period)
   - Score messages sent via CAN bus (3s default period)
   - GPIO control signals for physical autopilot selection

## 3. Key Design Decisions

### 3.1 Multiple Selection Algorithms

The framework implements several selection methods to accommodate different operational needs:

- **always_best**: Maximizes performance by always selecting the highest-scoring autopilot
- **change_if_worst**: Improves stability by only switching when current autopilot is worst
- **round_robin**: Ensures all autopilots are exercised regularly
- **fixed_always_X**: Forces selection of a specific autopilot for testing/debugging
- **fixed_while_ok**: Uses preferred autopilot unless it fails, then selects best alternative

This flexibility allows operators to balance between performance optimization and stability based on mission requirements.

### 3.2 Comprehensive Health Monitoring

The system implements multiple layers of health monitoring:

1. **Deadman Signal Checking**: Requires signal transitions at least once every 8ms
2. **Variable Freshness Verification**: Ensures updates occur at least once every 150ms
3. **Self-Reported Status**: Respects autopilot's own health assessment
4. **Watchdog Monitoring**: Detects complete autopilot failures within 5s

This multi-layered approach ensures that no single point of failure can compromise system safety.

### 3.3 Stability Mechanisms

To prevent rapid switching between autopilots (which could cause system instability):

- **Hysteresis Parameter**: Requires significant score differences (0.001-1.0) before switching
- **Minimum Selection Time**: Enforces a minimum dwell time (`arb_tmin`, default 100ms)
- **Selection Method Options**: Provides varying levels of stability vs. responsiveness

These mechanisms ensure smooth transitions between autopilots, preventing control oscillations.

### 3.4 Interface-Based Design

The system extensively uses interfaces to enable:

- **Loose Coupling**: Components interact through well-defined interfaces
- **Testability**: Mock implementations facilitate comprehensive testing
- **Extensibility**: New implementations can be added without modifying core code
- **Clear Separation of Concerns**: Each component has focused responsibilities

Key interfaces include `Ideadmanchecker`, `Icallback`, `Itproducer_can`/`Itconsumer_can`, and `Istatus_hook`.

## 4. Safety Mechanisms

### 4.1 Deadman Signal Monitoring

The Deadman Checker is a critical safety component that:

- Expects a signal with 100-125 Hz frequency
- Detects transitions (edges) rather than levels
- Requires transitions at least once every 8ms
- Reports failure immediately when timeout occurs
- Operates in real-time via periodic interrupts

This mechanism ensures that autopilots are actively functioning and responsive.

### 4.2 Redundancy and Fault Tolerance

The system supports 3-4 autopilots, providing:

- **N-1 Redundancy**: Can lose one autopilot and continue operation
- **Diverse Selection Methods**: Different strategies for various failure scenarios
- **Fallback Mechanisms**: Preferred autopilot selection if all others fail

This redundancy ensures continued operation even when individual components fail.

### 4.3 Defensive Programming

The system implements extensive error checking:

- Parameter validation in configuration methods
- Runtime assertions for array bounds
- Timeout detection for critical signals
- Multiple failure detection mechanisms

These practices prevent subtle errors from compromising system safety.

## 5. Testing and Validation Approach

The Arbitration Framework is validated through a comprehensive testing strategy that combines unit tests, integration tests, and scenario-based validation.

### 5.1 Testing Framework Components

1. **Core Test Infrastructure**:
   - `Arbitration_test` class provides the foundation for testing
   - Mock implementations of key interfaces (e.g., `Deadmanchecker_null`)
   - Auxiliary classes to support testing (e.g., `Aux_Iiterator`)

2. **VectorCAST Test Projects**:
   - **4xVTC-1**: Validates CAP selection function (`Arb::Arbitration::Step`)
   - **4xVTC-3**: Validates autopilot health monitoring (`Arb::Autopilot::step`)

### 5.2 Comprehensive Test Scenarios

The testing framework validates the system through diverse scenarios:

1. **Arbitration Method Validation**:
   - Tests for all selection methods (fixed, change_if_worst, always_best, etc.)
   - Verifies correct behavior under various autopilot states

2. **Failure Handling Validation**:
   - All autopilots alive
   - All autopilots dead
   - Best autopilot dead
   - Two best autopilots dead

3. **Timing-Related Validation**:
   - Tests with different system times (0.0, 0.25, 7.0)
   - Validates timeout detection and recovery

### 5.3 Coverage and Validation Metrics

The testing framework ensures comprehensive validation through:

- **Statement Coverage**: Ensures all code paths are exercised
- **MCDC Coverage**: Validates complex decision logic
- **Expected vs. Actual Comparison**: Verifies system behavior against specifications
- **Sequential Testing**: Validates both immediate and cumulative effects

## 6. Integration with Broader Systems

The Arbitration Framework integrates with multiple drone systems:

1. **Integration with Autopilot Systems**:
   - Receives status and variables via CAN
   - Monitors deadman signals via GPIO
   - Reports selection decisions via CAN

2. **Integration with Control Systems**:
   - Controls outputs through GPIO multiplexing
   - Provides status information via CAN messages
   - Notifies of selection changes via callbacks

3. **Configuration Integration**:
   - PDI (Parameter Data Item) deserialization
   - CAN ID mapping for autopilot identification
   - Variable configuration for scoring parameters

## 7. Key Strengths of the Arbitration Framework

The Arbitration Framework's design offers several key strengths:

1. **Robust Redundancy Management**: Provides reliable autopilot selection even during failures
2. **Configurable Selection Logic**: Adapts to different operational requirements
3. **Comprehensive Health Monitoring**: Detects failures through multiple mechanisms
4. **Stability-Focused Design**: Prevents rapid switching and control oscillations
5. **Extensive Testability**: Supports thorough validation through comprehensive testing
6. **Interface-Based Architecture**: Enables flexibility and future extensibility
7. **Real-Time Performance**: Designed for safety-critical, time-sensitive operations

## 8. Conclusion

The Arbitration Framework represents a sophisticated solution to the challenge of managing autopilot redundancy in safety-critical drone operations. By combining intelligent selection algorithms, comprehensive health monitoring, and robust communication interfaces with extensive testing and validation, the system ensures reliable autopilot selection under all operating conditions.

The framework's architecture follows sound design principles, with clear separation of concerns, interface-based design, and defensive programming practices. These characteristics make it suitable for safety-critical applications where reliable autopilot selection is essential for mission success and safety.

Through its ability to detect failures, select the most appropriate autopilot, and maintain stable control transitions, the Arbitration Framework plays a crucial role in ensuring safe drone operation in the face of potential component failures or degradation.