# PolarionWebServiceExample.py
import sys, os
sys.path.append("../../../_docs-lib")
from Tools import polarionWebService
from suds.client import Client
import requests
import argparse
from Tools import parseTexLib

HOSTNAME = os.environ['POLARION_HOST']
USERNAME = os.environ['POLARION_TOKEN'].split(":")[0]
PASSWORD = os.environ['POLARION_TOKEN'].split(":")[1]
FILENAME = "../tr.tex"

def delete_empty_lines(string):
    temp = ""
    for str in string.splitlines():
        if not str.isspace() and str:
             temp += str + "\n"

    return temp


def PolarionWebServiceExample(query, fields,version, ignore_error):
    tracker = polarionWebService.init_session()

    queriedWIs = polarionWebService.get_raw_work_items(tracker, query, fields, version, orden="title")

    testcases = polarionWebService.get_raw_work_items(tracker,'(type:testcase) AND (status:verified)', ['id','title','customFields.testid'],version,orden="title")

    count = 0
    error = False
    list_tc = []
    if testcases:
        for tc in testcases:
            try:
                list_tc.append(tc[4][0][0].value)
            except Exception:
                count=count
                # print("Exists TC without ID:")
                # print(tc)
    file=open(FILENAME,"w")
    if queriedWIs:
        for Wi in queriedWIs:
            if Wi.title in list_tc:
                count = count + 1
                file.write("\\begin{itemize}\n")
                wi_data = Client.dict(Wi)
                title = Wi.title
                title = title.replace("&", "\&")
                title = title.replace("_", "\_")
                title = title.replace("#", "\#")

                if hasattr(Wi,"attachments") and Client.dict(wi_data["attachments"])!={}:file.write("\\newpage \n")
                file.write("    \\item [\\textbf{" + Wi.id + "}] " + title + "\n")
                file.write("    \\begin{itemize}\n")

                if hasattr(Wi, "customFields"):
                    #print(wi_data["customFields"])
                    try:
                        custom_fields = Client.dict(wi_data["customFields"])
                        #print (custom_fields)
                        if Client.dict(custom_fields["Custom"][0])['key']=='state':
                            custom_state = Client.dict(custom_fields["Custom"][0])['value']['id']
                            if title.find("V") == -1:
                                custom_log = Client.dict(custom_fields["Custom"][1])['value']['content']#.replace('#','\#').replace('\n',' \\\\ ').replace('_','\_').replace('&','\&').replace("á","").replace(" ","")
                        else:
                            custom_log = Client.dict(custom_fields["Custom"][0])['value']['content']#.replace('#','\#').replace('\n',' \\\\ ').replace('_','\_').replace('&','\&').replace("á","").replace(" ","")
                            custom_state = Client.dict(custom_fields["Custom"][1])['value']['id']
                        #Here we have the state of pass or fail in the result
                        #print(custom_state['value']['id'])
                        file.write("            \\item [\\textit{ Status }] " + custom_state + "\n")
                        if (custom_log.split('<br/>',1)[0] != "#LATEX"):
                            # custom_log = parseTexLib.parse_html_chars(parseTexLib.parse_chars(custom_log.replace("\\", "\\textbackslash "))).replace("<br/>", "\n").replace("<br>", "\n")
                            custom_state = parseTexLib.parse_html_chars(custom_state)
                            custom_log = (custom_log.replace("_", "\_")).replace("&", "\&").replace("^", "\^")
                            custom_log = custom_log.replace("\n", " \\\\ \n ")
                            custom_log = custom_log.replace('<span style="font-size: 10pt;line-height: 1.5;">',"").replace('</span>',"").replace('<br/>',"\n")
                            if custom_log.find("VCAST") == -1: file.write("        \\item [\\textit{ Log }] " + "\n"+ custom_log + "\n")
                        else: 
                            custom_log=(custom_log.split('<br/>',1)[1]).replace("<br/>", "\n")
                            custom_log=(parseTexLib.parse_html_chars(custom_log, False)).replace('&amp;','&')
                            custom_log = delete_empty_lines(custom_log)
                            file.write("        \\item [\\textit{ Log }] " + "\n"+ custom_log + "\n")
                        if(custom_state != "pass"):
                            print(Wi.id + " " + title+": is in status in version " + str(version) + "--->"+str(custom_state))
                            error = True
                        file.write("    \\end{itemize}\n")
                        file.write("\\end{itemize}\n\n")
                    except Exception as e:
                        print(e)
                        print(Wi)
                else:
                    print("WI without Custom field"+Wi.title)
                if hasattr(Wi,"attachments") and Client.dict(wi_data["attachments"])!={} and Client.dict(custom_fields["Custom"][0])['value']['content'].split('<br/>',1)[0] != "#LATEX":
                    if Client.dict(wi_data["attachments"]):
                        url = Client.dict(wi_data["attachments"])['Attachment'][0]['url'].replace('localhost',  HOSTNAME)
                        result = requests.get(url,auth=(USERNAME, PASSWORD), verify=False)
                        with open("../"+title+".pdf","wb") as file_pdf:
                            file_pdf.write(result.content)
                            file_pdf.close()
                            file.write("\includepdf[pages={1-},scale=0.85,offset={30mm -30mm},pagecommand={},frame=false]{"+title+".pdf"+"} \n \n")
    if not ignore_error:
        exit(error)


if __name__ == "__main__":

    parser = argparse.ArgumentParser(description='Extract Test Result')
    parser.add_argument("version", help="Version to be parsed")
    parser.add_argument("-ignore_errors", type=bool, default=False,
                        help="Flag that forces the script to exit when a polarionWebService.relation is not found")
    args = parser.parse_args()


    PolarionWebServiceExample('linkedWorkItems:(VER-4014) AND (type:testresults)',['id','title','attachments','customFields.state','customFields.log_test'],args.version,args.ignore_errors)