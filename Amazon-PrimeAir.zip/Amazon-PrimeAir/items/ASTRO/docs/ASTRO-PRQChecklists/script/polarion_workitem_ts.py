# PolarionWebServiceExample.py
import sys, os, re
from suds.client import Client
import sys
sys.path.append("../../../_docs-lib/")
from Tools import polarionWebService
from Tools import workItemLib
from suds.client import Client
import argparse


def PolarionWebServiceExample(file,query,fields,version):
    tracker = polarionWebService.init_session()
    queriedWIs = polarionWebService.get_raw_work_items(tracker, query, fields, version, orden="id")

    file=open(file,"w")
    if queriedWIs:
        for Wi in queriedWIs:
            if hasattr(Wi,'customFields'):
                file.write("¨"+Wi.id+" "+Wi.title+"\n")
                # print(Wi[4][0][0].value.content)
                file.write(Wi[4][0][0].value.content+"\n")
        print(len(queriedWIs))
    file.close()


if __name__=="__main__":
    parser = argparse.ArgumentParser(description='Process some integers.')
    parser.add_argument("version", help="Version to be parsed")
    args = parser.parse_args()
    error = 0
    for key in ["unit","system","integration","robustness", "analysis"]:
        filename = "test-step-" + key + ".txt"
        PolarionWebServiceExample(filename ,'linkedWorkItems:(VER-4014) AND (type:testcase) AND (status:verified) AND (testType.KEY:' + key + ')',['id','title','customFields.testStep'],args.version)#AND testid:TC-*
        error &= os.system("python htmltocsv.py "+ filename)
    sys.exit(error)