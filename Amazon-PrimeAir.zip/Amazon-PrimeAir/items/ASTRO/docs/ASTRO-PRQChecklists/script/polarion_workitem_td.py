import sys
import argparse
sys.path.append("../../../_docs-lib")
from Tools import polarionWebService
from Tools import parseTexLib
from enum import Enum
from Tools import acronyms

args = {}

class relation(Enum):
    NONE = 0
    HLR4x_LLR4x = 1
    LLR4x_TC4x = 2
    SYS_HLR4x = 3
    HLR4x_TC4x = 4
    SYS_HLR = 5
    HLR_LLR = 6
    HLR_TC = 7
    LLR_TC = 8
    TC4x_TR4x = 9
    SYS_PR4x = 10
    PR4x_PR = 11
    PR4x_HLR4x = 12
    PR_HLR = 13
    TC_TR = 14
    LLR4x = 15
    LLR = 16
    SYS_PR = 17
    LLR_ALG = 18
    
class work_item:
    def __init__(self, id, title, code, list_linked_wi, description, relation):
        self.relation = relation
        self.id = id
        self.title = title
        self.list_linked_wi = list_linked_wi      
        self.code = code
        self.description = description
        
    def set_relation(self, value):
        self.relation = relation

    def get_role(self):
        role = ""
        if self.relation in (relation.HLR4x_LLR4x, relation.HLR_LLR, relation.PR4x_HLR4x, relation.PR_HLR):    
            role = "refined by"
        elif self.relation in (relation.HLR4x_TC4x, relation.LLR4x_TC4x, relation.HLR_TC, relation.LLR_TC):
            role = "verified_by"
        elif self.relation in (relation.SYS_HLR4x, relation.SYS_HLR, relation.SYS_PR4x, relation.PR4x_PR, relation.SYS_PR):
            role = "traces" 
        elif self.relation in (relation.TC4x_TR4x, relation.TC_TR): 
            role = "result"        
        elif self.relation == relation.LLR_ALG:    
            role = "is_described_by"            
        return role


    def get_tex_WI(self):
        tex = "%s - %s" %(self.id, parseTexLib.parse_special_chars(self.title))
        show_line = True
        if self.relation == relation.LLR4x or self.relation == relation.LLR:
            tex += "& " + "%s" %(self.code)
        else:
            if len(self.list_linked_wi) > 0:
                count = 0
                for i in range(0, len(self.list_linked_wi)):
                    if self.list_linked_wi[i][0] == self.get_role():
                        if count == 0:
                            tex += "&"
                        tex += "%s %s" %(self.list_linked_wi[i][1], parseTexLib.parse_special_chars(self.list_linked_wi[i][2]))
                        if(count < len(self.list_linked_wi) - 1):
                            tex += "\\\\" + " \\cline{2-2} &"
                        count += 1
                # if the table to be listed is Low-Level VS Algorithms, just show the LLRs that are related to at least one Algorithm
                if self.relation == relation.LLR_ALG and count == 0 : 
                    show_line = False
            else:
                if self.relation == relation.LLR_ALG :
                    show_line = False
                else:
                    tex += "&"
        if show_line == False :
            tex = ""
        else :
            tex += "\\\\"   
            tex = acronyms.parse_acronyms(tex)
            tex += " \\hline"
            tex += "\n"            
        return tex        

        
class work_item_list:
    def __init__(self, list):
        self.list = list

    def get_tex(self, col1_title, col2_title):
        tex = ""
        if len(self.list) > 0:
            if(self.list[0].relation in (relation.LLR, relation.LLR4x)):
                for i in range(0, len(self.list)):
                    tex += "\\subsubsection{%s: %s}" %(self.list[i].id, parseTexLib.parse_special_chars(self.list[i].title))
                    tex += "\\raggedright{%s}" %(parseTexLib.parse_special_chars(self.list[i].code))
                    tex += "\n"
            else:
                tex += "\\begin{center}" + "\n"
                tex += "\\renewcommand{\\arraystretch}{1.25}" + '\n'
                tex += "\\begin{small}" + '\n'
                tex += "\\begin{longtable}" + "{| p{6,5cm} | p{6,5cm} |}" + "\n"
                for i in range(0, len(self.list)):
                    if i == 0:
                        tex += "\\hline" + "\n"
                        tex += "\\centering{\\textbf{%s}}" %col1_title + " & \\centering{\\textbf{%s}}" %col2_title+" \\tabularnewline " + "\\hline" + "\n"
                        tex += "\\endhead" + "\n"
                    tex += self.list[i].get_tex_WI()
                    
                tex += "\\end{longtable}" + '\n'
                tex += "\\end{small}" + '\n'
                tex += "\\renewcommand{\\arraystretch}{1}" + '\n'
                tex += "\\end{center}" + '\n'  
        return tex

        
def not_applicable_field(path):
    file=open(path,"w")    
    file.write("Not applicable.")
    file.close()
    

def make_related_list(parent_list, child_list, type, relation):
    list = []
    if len(parent_list) > 0:
        for i in range(0, len(parent_list)):
            linkedWi = []
            for j in range(0, len(child_list)):
                for z in range(0, len(parent_list[i].list_linked_wi)):
                    if(child_list[j].id == parent_list[i].list_linked_wi[z][1]):
                        if parent_list[i].list_linked_wi[z][0] == relation:
                            linkedWi.append([relation, child_list[j].id, child_list[j].title])
            wi = work_item(parent_list[i].id, parent_list[i].title, "", linkedWi, "", type)
            list.append(wi)
    return list
        

def make_inverse_related_list(parent_list, child_list, type, relation, inverse_relation):
    list = []
    if len(parent_list) > 0:
        for i in range(0, len(parent_list)):
            linkedWi = []
            for j in range(0, len(child_list)):
                for z in range(0, len(child_list[j].list_linked_wi)):
                    if(parent_list[i].id == child_list[j].list_linked_wi[z][1]):
                        if child_list[j].list_linked_wi[z][0] == relation:
                            linkedWi.append([inverse_relation, child_list[j].id, child_list[j].title])
            wi = work_item(parent_list[i].id, parent_list[i].title, "", linkedWi, "", type)
            list.append(wi)       
    return list

    
def get_testcases_related_to_requirement(l_tc, l_req):
    result = []
    if len(l_tc):
        for i in range(0, len(l_tc)):
            match = False
            for j in range(0, len(l_req)):
                for z in range(0, len(l_tc[i].list_linked_wi)):
                    if l_req[j].id == l_tc[i].list_linked_wi[z][1] and l_tc[i].list_linked_wi[z][0] == "verified_by":   
                        match = True
                        break
                if match:
                    break
            if match:
                result.append(l_tc[i])
    return result    


def remove_duplicates(list1, list2):
    result = []
    for i in range(0, len(list1)):
        found = False
        for j in range(0, len(list2)):
            if list1[i] == list2[j]:
                found = True
                break
        if not found :
            result.append(list1[i])
    for i in range(0, len(list2)):
        result.append(list2[i])
    return result


def check_null_childs(list, relation):
    on_error = False
    if relation != "traces":
        for i in range(0, len(list)):
            if len(list[i].list_linked_wi) == 0:
                print("ERROR : [%s] requirement has not \"%s\" relation" %(list[i].id, relation))
                on_error = True
    return on_error

    
def make_tex(path, list, col1_title, col2_title):
    file = open(path,"w")   
    tex = work_item_list(list).get_tex(col1_title, col2_title)
    file.write(tex)
    file.close()        

    
def get_raw_work(queriedWIs, relation, path):
    list_work_items = []
    if queriedWIs:
        file_out_polarion=open(path, "w", encoding="utf-8") 
        
        for Wi in queriedWIs:
            file_out_polarion.write(str(Wi))
            id = ""
            title = ""
            code = ""
            list_linked_wi = []
            description = ""       
            external_id = ""
            if hasattr(Wi,'id'):
                id = Wi.id
            if hasattr(Wi,'title'):
                title = Wi.title
            if hasattr(Wi,'customFields'):
                for custom in Wi.customFields.Custom:
                    if custom.key == "code" :
                        code = custom.value
                    if custom.key == "External_ID" :
                        external_id = custom.value
            if hasattr(Wi,'linkedWorkItems') and hasattr(Wi.linkedWorkItems,'LinkedWorkItem') :
                role = ""
                uri = ""
                for linkedWi in Wi.linkedWorkItems.LinkedWorkItem:
                    role = linkedWi.role.id
                    uri = linkedWi.workItemURI
                    uri = uri[uri.find("{WorkItem}"):]
                    uri = uri.replace("{WorkItem}", "")
                    if "%" in uri: # When query is performed against baseline, Polarion adds "%" after req. ID
                        uri = uri[:uri.find(r"%")]
                        uri = uri.replace(r"%", "")
                    list_linked_wi.append([role, uri, ""])
            if hasattr(Wi,'description'):
                description = Wi.description.content
            
            if external_id != "" :
                wi = work_item(id, "["+external_id+"] " + title, code, list_linked_wi, description , relation)
            else : 
                wi = work_item(id, title, code, list_linked_wi, description, relation)
            list_work_items.append(wi)
        file_out_polarion.close()

    return list_work_items  
    
    
def make_latex_documents():
    tracker = polarionWebService.init_session()
    verified_filter = ""
    if args.all == False:
        verified_filter = ' AND (status:verified)'    

    #System Req
    criteria = "linkedWorkItems:(VER-4014) AND type:sreq AND project.id:"+args.sys_project
    fields = ['id','title','linkedWorkItems', 'customFields.External_ID']
    l_sreq = get_raw_work(polarionWebService.get_raw_work_items(tracker, criteria, fields, args.version), relation.NONE, "Polarion-QUERY-SYS.txt")
    
    #Test Cases
    criteria = "linkedWorkItems:(VER-4014) AND type:testcase  AND HAS_VALUE:linkedWorkItems" + verified_filter
    fields = ['id','title','linkedWorkItems']
    l_tc = get_raw_work(polarionWebService.get_raw_work_items(tracker, criteria, fields, args.version), relation.NONE, "Polarion-QUERY-TC.txt")
    
    #Test Results
    criteria = "linkedWorkItems:(VER-4014) AND type:testresults AND version_result:%s" % args.version
    fields = ['id','title']
    l_tr = get_raw_work(polarionWebService.get_raw_work_items(tracker, criteria, fields, args.version), relation.NONE, "Polarion-QUERY-TR.txt")
    
    #Product
    criteria = "linkedWorkItems:(VER-4014) AND type:productrequirement"
    fields = ['id','title']
    l_pr = get_raw_work(polarionWebService.get_raw_work_items(tracker, criteria, fields, args.version), relation.NONE, "Polarion-QUERY-PR.txt")    
    
    #HLR
    criteria = "linkedWorkItems:(VER-4014) AND type:hlrequirement" + verified_filter
    fields = ['id','title','linkedWorkItems']
    l_hlr = get_raw_work(polarionWebService.get_raw_work_items(tracker, criteria, fields, args.version), relation.NONE, "Polarion-QUERY-HLR.txt")    
    
    #LLR
    criteria = "linkedWorkItems:(VER-4014) AND type:llrequirement" + verified_filter
    fields = ['id','title','linkedWorkItems','customFields.code']
    l_llr = get_raw_work(polarionWebService.get_raw_work_items(tracker, criteria, fields, args.version), relation.LLR, "Polarion-QUERY-LLR.txt")    
    
    #Algorithms
    criteria = "linkedWorkItems:(VER-4014) AND type:algorithm"
    fields = ['id','title','linkedWorkItems']
    l_alg = get_raw_work(polarionWebService.get_raw_work_items(tracker, criteria, fields, args.version), relation.NONE, "Polarion-QUERY-Algorithms.txt")
    
    #Diagrams
    criteria = "linkedWorkItems:(VER-4014) AND type:diagram"
    fields = ['id','title','linkedWorkItems']
    l_diag = get_raw_work(polarionWebService.get_raw_work_items(tracker, criteria, fields, args.version), relation.NONE, "Polarion-QUERY-Diagrams.txt")    

    sys_pr = make_related_list(l_sreq, l_pr, relation.SYS_PR, "traces")
    sys_hlr = make_related_list(l_sreq, l_hlr, relation.SYS_HLR, "traces")
    pr_hlr = make_inverse_related_list(l_pr, l_hlr, relation.PR_HLR, "refines", "refined by") #Inverted: Because the Polarion's relationship is "HLR refines PRODUCT" 
    hlr_llr = make_inverse_related_list(l_hlr, l_llr, relation.HLR_LLR, "refines", "refined by") #Inverted: Because the Polarion's relationship is "LLR refines HLR" 
    hlr_diag = make_inverse_related_list(l_hlr, l_diag, relation.HLR_LLR, "refines", "refined by") #Inverted: Because the Polarion's relationship is "LLR refines HLR" 
    diag_llr = make_related_list(l_diag, l_llr, relation.SYS_HLR,"traces")
    hlr_tc = make_inverse_related_list(l_hlr, l_tc, relation.HLR_TC, "verified_by", "verified_by") #Inverted: Because the Polarion's relationship is "HLR verified_by Test Case" 
    llr_tc = make_inverse_related_list(l_llr, l_tc, relation.LLR_TC, "verified_by", "verified_by") #Inverted: Because the Polarion's relationship is "LLR Case verified_by Test Case"
    tc_tr = make_related_list(remove_duplicates(get_testcases_related_to_requirement(l_tc, l_hlr), 
                                                get_testcases_related_to_requirement(l_tc, l_llr)), 
                                                l_tr, relation.TC_TR, "result")
    llr_alg = make_inverse_related_list(l_llr, l_alg, relation.LLR_ALG, "describe", "is_described_by") #Inverted: Because the Polarion's relationship is "Algorithm describes LLR"
 
    on_error = 0
    on_error |= check_null_childs(hlr_llr, "refined by")
    on_error |= check_null_childs(hlr_tc, "verified_by") 
    on_error |= check_null_childs(llr_tc, "verified_by") 
    
    if not args.soi2:
        on_error |= check_null_childs(tc_tr, "result") 

    if on_error and not args.ignore_errors:
        sys.exit("======= ERROR")
 
    make_tex("../sys_pr.tex", sys_pr, "System Level Requirements", "Product-level Requirements")
    make_tex("../sys_hlr.tex", sys_hlr, "System Level Requirements", "High-level Requirements")
    make_tex("../pr_hlr.tex", pr_hlr, "Product Level Requirements", "High-level Requirements")
    make_tex("../hlr_llr.tex", hlr_llr, "High-level Requirements", "Low-level Requirements")
    make_tex("../hlr_diag.tex", hlr_diag, "High-level Requirements", "Design Model")
    make_tex("../diag_llr.tex",diag_llr , "Design Model", "Low-level Requirements" )
    make_tex("../hlr_tc.tex", hlr_tc, "High-level Requirements", "Test-case")
    make_tex("../llr_tc.tex", llr_tc, "Low-level Requirements", "Test-case")
    make_tex("../llr_alg.tex", llr_alg, "Low-level Requirements", "Algorithms")
   
    if not args.soi2:
        make_tex("../tc_tr.tex", tc_tr, "Test-case", "Test-result")        
    else:
        not_applicable_field("../tc_tr.tex")
    
    make_tex("../llr_code.tex", l_llr, "Low", "Low-level Requirements")
 

def read_input_arguments():
    global args
    parser = argparse.ArgumentParser()
    parser.add_argument("version", help="Version to be parsed")
    parser.add_argument("rootDirectory", help="Root directory of repository. For example: c:\docs")
    parser.add_argument("sys_project", help="Polarion system project")
    parser.add_argument("-ignore_errors", type=bool, default=False, help="Flag that forces the script to exit when a polarionWebService.relation is not found")
    parser.add_argument("-soi2", type=bool, default=False)
    parser.add_argument("-all", type=bool, default=False, help="Verified Filter")
    args = parser.parse_args()
    print("Version:%s" % args.version)
    print("Ignore Errors:%s" % args.ignore_errors)
    print("SOI2:%s" %args.soi2)
    
    
if __name__=="__main__":    
    acronyms.make_acronym_dictionary("../../../_docs-lib/Texts/abbreviations.tex")
    read_input_arguments()
    make_latex_documents()
