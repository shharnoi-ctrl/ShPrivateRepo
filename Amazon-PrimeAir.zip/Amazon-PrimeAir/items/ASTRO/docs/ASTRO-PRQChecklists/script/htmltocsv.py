import pandas as pd
import os, subprocess,time, sys,re
sys.path.append("../../../_docs-lib/")
from Tools import parseTexLib
from Tools import acronyms
from Tools import workItemLib


filename = sys.argv[1]
directory = "\\temp"
comi = '"'
con = 0

f = open(filename, "r")
f_lines = list(f)
caption = []
table_list = []
table_n = ""

for line in f_lines:
    if '¨' in line:
        bline=line.replace('¨', '').strip('\n')
        caption.append(bline)
        table_list.append(table_n)
        table_n = ""
    else:
        table_n = table_n + str(line)
table_list.append(table_n)
f.close()
acronyms.make_acronym_dictionary("../../../_docs-lib/Texts/abbreviations.tex")
file = open(filename.split(".")[0]+".tex","w")
error = False
for tablei in table_list[1:]:
    #print(caption[con])

    content = parseTexLib.parse_html_chars(tablei)
    content = parseTexLib.parse_chars(content)
    content = acronyms.parse_acronyms(content)
    try:
        table = parseTexLib.parse_table(content, parseTexLib.parse_chars(caption[con]), False, False, True).replace("__TABLE__", "").replace("</span>","")
        file.write(re.sub(r'<.*?>', "",parseTexLib.parse_html_chars(table)) + "\n")
    except:
        print("Error in test Case with id:"+caption[con])
        error = True



    con += 1
file.close()
sys.exit(error)
