# fpa_router.py

import sys
import subprocess
import os

os.system("cls")

def main():
    # Retrieve the arguments from the command line
    if len(sys.argv) != 8:
        print("Usage: python fpa_router.py <csv_directory> <function_name> <json_directory>")
        sys.exit(1)

    csv_directory = sys.argv[1]
    function_name = sys.argv[2]
    json_directory = sys.argv[3]
    accumulative = sys.argv[4]
    algorithm_name = sys.argv[5]
    description = sys.argv[6]
    extra_conclusion = sys.argv[7]

    # Path to the executable
    exe_path = os.path.join(os.path.abspath("../../../"), "items", "ASTRO", "items", "sw", "sw_PA_SIL", "code", "Debug_fpa", "PA_SIL.exe")
    parser_path = os.path.join(os.path.abspath("../../../"), "items", "ASTRO", "items", "sw", "sw_Astro","items","_sw_Veronte","items","_Vlibs","artifacts","FPA_test","config","fpa_parser.py")
    os.system("cls")

    # Forward the arguments to fpa_parser.py
    python_executable = r"C:\Program Files (x86)\Python37-32\python.exe"
    
    # Update the subprocess call
    subprocess.run([python_executable, parser_path, csv_directory, function_name, json_directory, exe_path,accumulative,algorithm_name,description,extra_conclusion])

if __name__ == "__main__":
    main()
