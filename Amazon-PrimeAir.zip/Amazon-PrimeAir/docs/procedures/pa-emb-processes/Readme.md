# Readme
- **Repositories:** EMB organization repositories for internal development (internal repositories) and AMZ-PA access (AMZ-PA repository).
- **DEV/SUPPORT branch:** current project working branch. Support branch is generated after closing scope of functionality.
- **Drop xx release:** unstable and not 100% tested software release.
- **DROPs Δ RC:** Release Candidate with functional increments. Stable release that may still cause Problem Reports and/or is not 100% functionaly validated.
- **DROPs Δ RTM:** Release To Manufacturing with functional increments. Verification status to be agreed with PA.
- **Releases assets will include:** SIL library (.so), TI binaries, changelog, PDI configuration and/or external flash image.