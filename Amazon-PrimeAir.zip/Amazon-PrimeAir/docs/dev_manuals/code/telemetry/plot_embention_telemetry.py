# pylint: skip-file
import argparse


# Define functions to plot GNC task & Acquisition task info
from dataclasses import dataclass
from functools import reduce
from pathlib import Path
import re

import pandas as pd
import plotly.express as px


@dataclass(eq=True, frozen=True)
class ComputeMetadata:
    device_id: int
    compute: str
    gnc_task: str


MONITOR = ComputeMetadata(
    device_id=94657053978,
    compute="Monitor",
    gnc_task="Monitor",
)
RECOVERY_0 = ComputeMetadata(
    device_id=120426857753,
    compute="Recovery0",
    gnc_task="Navigation",
)
RECOVERY_1 = ComputeMetadata(
    device_id=133311759643,
    compute="Recovery1",
    gnc_task="Controls",
)
COMPUTE_METADATA = [MONITOR, RECOVERY_0, RECOVERY_1]


# Variables
@dataclass(eq=True, frozen=True)
class TelemetryVariable:
    units: str
    name: str


# TODO: Read this from the XML + EMB release config documented in https://manuals.embention.com/veronte-autopilot/en/6.4.90/veronte-configuration/setup-toolbar/variables/list-of-variables/index.html
TIME = TelemetryVariable(
    units="s",
    name="Relative Timestamp",
)


EMB_TELEMETRY_SESSION_NAME_PATTERN = (
    r"^(?P<device_id>\d+)_(?P<ip>\d.+)_Telemetry(Complementary)?_(\d-\d)\.csv$"
)
TELEMETRY_VARIABLE = "variable"
TELEMETRY_VALUE = "value"


def infer_compute_metadata(file: Path):
    try:
        # old school
        regex = re.match(EMB_TELEMETRY_SESSION_NAME_PATTERN, file.name)
        device_id = int(regex.group("device_id"))
        matching_metadata = [
            metadata for metadata in COMPUTE_METADATA if metadata.device_id == device_id
        ]
        assert 0 < len(
            matching_metadata
        ), f"Unable to find metadata for device ID {device_id}!"
        assert (
            len(matching_metadata) < 2
        ), f"Found multiple metadata entries for device ID {device_id}!"
        return next(iter(matching_metadata))
    except Exception as e:
        # new school
        dir = file.parent.name
        if dir == "recovery0":
            return ComputeMetadata(
                device_id=120426857753,
                compute="R0",
                gnc_task="Navigation",
            )
        elif dir == "recovery1":
            return ComputeMetadata(
                device_id=133311759643,
                compute="R1",
                gnc_task="Controls",
            )
        else:
            raise RuntimeError(f"Can't infer compute metadata from path {file}!") from e


def trim_embention_telemetry(
    df: pd.DataFrame, trim_leading_by: pd.Timedelta
) -> pd.DataFrame:
    # Remove first N seconds of data to get rid of startup spikes
    times = pd.to_timedelta(df[TIME.name], unit="s")
    trim_start = times.min() + trim_leading_by
    return df.loc[trim_start < times]


def sanitize_column(column: str) -> str:
    # Ensure casing matches for known columns
    if column.strip().casefold() == TIME.name:
        return TIME.name
    else:
        return column.strip()


@dataclass
class EmbentionTelemetry:
    files: list[Path]
    data: pd.DataFrame
    metadata: ComputeMetadata

    @classmethod
    def from_csvs(
        cls, csvs: list[Path], trim_leading_by: pd.Timedelta
    ) -> "EmbentionTelemetry":
        """Read EMB telemetry CSVs, infer their metadata, and load them into memory"""
        metadatas = {infer_compute_metadata(csv) for csv in csvs}
        assert (
            len(metadatas) == 1
        ), f"Expected exactly one metadata match for CSVs {csvs}, got {len(metadatas)}: {metadatas}"
        metadata = next(iter(metadatas))

        # Read all data
        wide_dfs = [
            pd.read_csv(csv, delimiter=";", encoding="ISO-8859-1") for csv in csvs
        ]

        # Sanitize column names, removing leading and trailing whitespace and throwing away any empty columns/column names
        sanitized_dfs = [
            df.rename(
                columns={column: sanitize_column(column) for column in df.columns}
            ).drop(
                columns="",
                errors="ignore",
            )
            for df in wide_dfs
        ]

        # Merge data
        def join_telemetry(left, right):
            # Drop duplicate columns
            duplicate_columns = (set(left.columns) & set(right.columns)) - set([TIME.name])
            if duplicate_columns:
                print(f"Dropping repeated columns: {', '.join(duplicate_columns)}")

            return pd.merge_asof(
                left,
                right.drop(columns=duplicate_columns),
                on=TIME.name,
                direction="nearest",
                tolerance=0.1,
            )

        merged_df = reduce(join_telemetry, sanitized_dfs)

        # "melt"/"unpivot" data so different variables can all share a DataFrame
        long_df = merged_df.melt(
            id_vars=[TIME.name],
            var_name=TELEMETRY_VARIABLE,
            value_name=TELEMETRY_VALUE,
        )
        trimmed_df = trim_embention_telemetry(long_df, trim_leading_by)

        return cls(files=csvs, data=trimmed_df, metadata=metadata)

    @classmethod
    def from_dir(cls, directory: Path) -> "EmbentionTelemetry":
        return cls.from_csvs(list(directory.glob("*.csv")))

    @classmethod
    def from_csv(cls, csv: Path) -> "EmbentionTelemetry":
        return cls.from_csvs([csv])

    @property
    def long(self) -> pd.DataFrame:
        return self.data

    @property
    def wide(self) -> pd.DataFrame:
        return self.data.pivot(
            index=TIME.name, columns=TELEMETRY_VARIABLE, values=TELEMETRY_VALUE
        ).reset_index()

    def get(self, var_name: str) -> pd.Series:
        var_data = self.data.loc[self.data[TELEMETRY_VARIABLE] == var_name]
        return var_data.set_index(TIME.name)[TELEMETRY_VALUE]


if __name__ == "__main__":
    # CLI
    parser = argparse.ArgumentParser(
        description="A simple CLI for plotting Embention Telemetry vector data.",
    )
    parser.add_argument(
        "-t",
        "--telemetry-csv",
        required=False,
        type=str,
        action="append",
        help="Path to the CSV containing Embention Telemetry Vector data to plot. Data in the directory should all be for the same compute (Monitor/Recovery0/Recovery1).",
    )
    parser.add_argument(
        "-d",
        "--telemetry-csvs",
        required=False,
        type=str,
        action="store",
        help="Path to a directory containing Embention Telemetry CSV data. Data should all be for the same compute (Monitor, Recovery0, Recovery1).",
    )
    parser.add_argument(
        "-o",
        "--output",
        required=True,
        type=str,
        action="store",
        help="Path to the plot that will be written to disk.",
    )
    parser.add_argument(
        "--trim-leading-data-by",
        required=False,
        default="60s",
        type=str,
        action="store",
        help='Length of time to trim leading data by, to reduce noise created by startup churn. Written as [value][unit], e.g. "60s". See https://pandas.pydata.org/docs/reference/api/pandas.Timedelta.html',
    )
    parser.add_argument(
        "-f",
        "--flight-id",
        required=False,
        type=str,
        action="store",
        help="Flight ID being plotted. Used to populate the title of the plot.",
    )
    args = parser.parse_args()

    # Read
    csvs = [
        *(list(Path(args.telemetry_csvs).glob("*.csv")) if args.telemetry_csvs else []),
        *([Path(csv) for csv in args.telemetry_csv] if args.telemetry_csv else []),
    ]
    trim = pd.Timedelta(args.trim_leading_data_by)
    telemetry = EmbentionTelemetry.from_csvs(csvs, trim)

    # Plot
    title = f"EMB telemetry<br><sub>flight ID: {args.flight_id if args.flight_id else 'unknown'}, first {args.trim_leading_data_by} omitted<br>{telemetry.metadata}</sub>"
    plot = px.line(
        telemetry.data,
        x=TIME.name,
        y=TELEMETRY_VALUE,
        color=TELEMETRY_VARIABLE,
        title=title,
    ).update_layout(
        # make space for our bigass title
        margin=dict(t=150),
    )
    plot.write_html(args.output)
    print(f"Wrote {len(telemetry.data)} records to {args.output}")

    # Open
    import webbrowser

    webbrowser.open(f"file://{str(Path(args.output).absolute())}", new=2)
