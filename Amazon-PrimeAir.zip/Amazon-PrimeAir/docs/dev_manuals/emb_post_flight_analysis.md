# Post Flight Analisys
After Hilsim flight test, it will be possible to access flight logs by selecting a completed job and clicking in "**View simulations**" (in upper right part of the page). You will see:
![](./files/flight_1.png)

By pressing in "**Flights**" you will enter *Flights.adninfra.net*. In the files section you will find a long list of available data. However, all data needs time to be processed and displayed in this page, so it will take some time from the conclusion of the job.

![](./files/flight_2.png)

Let's analyze the one that could be more useful for debugging:
- *console_logs*: Different `*.txt` files subdivided by categories. For instance, if you want to check the `Navigation` status and how the sensors were considered by the navigation algorithm you can select `PRIMARY0-LIO-FASTBUS_vsdk.task.adn.vehicle.navigationandsensingsystem.Navigation_ParsedEntries.txt`-
- *vehicle_logs*: It is possible to find the analysis of the different CAN buses present on board, subdivided in a folder depending on the producer and the CAN frame. For instance, by looking at `MONITOR_STAB_A_RECOVERY0_STAB_A.vlog` you will see all the messages produced by the monitor in the STAB-A (CAN-FD). Inside the list of all the messages received and how they have been parsed is present and can be easily analyzed through `*.csv` files:

![](./files/flight_logs.png)

- *Visualization*: In this section, it will be possible to analyze plots of the data. For instance, could be the sensed `Air data` coming from the recovery compute:

![](./files/flight_visualization.png)

- *animation_state_estimate.html*: This file allows us to see the animation of the flight.

![](./files/flight_simulation.png)

- *embention*: This folder only contains the file, `telemetry.pcap`. Read [Recovery telemetry analysis](#recovery-telemetry-analysis) to learn how to analyze this file.it contains all the network traffic from `Astro` board related to `Recovery` telemetry. 

## Recovery telemetry analysis.
You can ask *PA*'s VIPA team to generate the telemetry. Otherwise, if you want to generate it manually, use the `telemetry.pcap` file that `Hilsim` test flight generates. It contains all the network traffic from `Astro` board related to `Recovery` telemetry. Follow these steps to obtain `*.html` file with a graph with the `Recovery` telemetry.

1. Use *Packetplayer* to replay the network traffic from `telemetry.pcap`. It is available in `Embention PM`.
2. Run [Telemetry_app](https://github.com/embention/Amazon-PrimeAir/blob/feature/Amazon-PrimeAir/9388_pa_mk30/items/VCP/items/Telemetry_app/README.md) application to gather all network traffic and generate the `CSV` files related to the telemetry.
3. Run [plot_embention_telemetry.py](./code/telemetry/plot_embention_telemetry.py) to create a `*.html` file with the plots of the acquired telemetry. Note that `Monitor`, `Recovery0` and `Recovery1` session IDs are harcoded in the python script. In case they change, you should modify them in the script.

![](./files/rec_telemetry.png)


### Plot embention telemetry example
```cmd
python3 plot_embention_telemetry.py -h
usage: plot_embention_telemetry.py [-h] [-t TELEMETRY_CSV] [-d TELEMETRY_CSVS] -o OUTPUT
                                   [--trim-leading-data-by TRIM_LEADING_DATA_BY]
                                   [-f FLIGHT_ID]

A simple CLI for plotting Embention Telemetry vector data.

options:
  -h, --help            show this help message and exit
  -t TELEMETRY_CSV, --telemetry-csv TELEMETRY_CSV
                        Path to the CSV containing Embention Telemetry Vector data to plot.
                        Data in the directory should all be for the same compute
                        (Monitor/Recovery0/Recovery1).
  -d TELEMETRY_CSVS, --telemetry-csvs TELEMETRY_CSVS
                        Path to a directory containing Embention Telemetry CSV data. Data
                        should all be for the same compute (Monitor, Recovery0, Recovery1).
  -o OUTPUT, --output OUTPUT
                        Path to the plot that will be written to disk.
  --trim-leading-data-by TRIM_LEADING_DATA_BY
                        Length of time to trim leading data by, to reduce noise created by
                        startup churn. Written as [value][unit], e.g. "60s". See
                        https://pandas.pydata.org/docs/reference/api/pandas.Timedelta.html
  -f FLIGHT_ID, --flight-id FLIGHT_ID
                        Flight ID being plotted. Used to populate the title of the plot.
```

```cmd
python3 plot_embention_telemetry.py -t ~/Downloads/non_switchover/133/133311759643_2024.11.13.12.30.04_Telemetry_4-1.csv -o ~/Downloads/non_switchover/133/133311759643_2024.11.13.12.30.04_Telemetry_4-1.html
```
