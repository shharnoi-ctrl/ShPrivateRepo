# README.md

1. Open ver_spdif_varini.xml

2. Find:
>	    <str-tunarray-element>
>            <vtype>3</vtype>
>            <id>1340</id>
>            <val0>0.0</val0>
>        </str-tunarray-element>

3. Change <val0> value to 1.0.