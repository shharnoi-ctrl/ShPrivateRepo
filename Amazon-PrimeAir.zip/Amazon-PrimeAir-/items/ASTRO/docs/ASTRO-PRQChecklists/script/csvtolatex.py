import argparse
import csv
import re


class Csv2LatexTable:
    def __init__(self, inputFile, delimiter, quotechar, tablepos, first_col_bold, first_row_bold, width1, width2, longTable, lessSpacing):
        self.inputFile = inputFile
        self.delimiter = delimiter
        self.quotechar = quotechar
        self.tablePos  = tablepos 
        self.first_col_bold   = first_col_bold
        self.first_row_bold  = first_row_bold
        self.width1 = width1
        self.width2 = width2
        self.longTable = longTable
        self.lessSpacing = lessSpacing

    def readCsvandMakeTable(self):
        """Reads a csv file and outputs a table to stdout"""
        with open(self.inputFile, "r") as csvfile:
            tablereader = csv.reader(csvfile, delimiter=self.delimiter, quotechar=self.quotechar)
            columnHeaders = next(tablereader)
            numColumn = len(columnHeaders)


            temp = '|' +'p{%s cm}' %(self.width1)+'|' + 'p{%s cm}' %(self.width2) + '|'

            print("\\begin{longtable}{%s}" % (temp))

            #Header
            print("\\hline")

            if (self.first_col_bold and not self.first_row_bold):
                print(" \\textbf{ %s \\\\" % (' }& '.join(columnHeaders[:numColumn])))
            elif(self.first_row_bold):
                print("\\textbf{%s\\\\" % ('}&\\textbf{'.join(columnHeaders[:numColumn])+"}"))
            else:
                print(" %s \\\\" % (' & '.join(columnHeaders[:numColumn])))

            print("\\hline")

            #Body
            for row in tablereader:

                if (self.first_col_bold):
                    print("\\textbf{%s\\\\" % ('}&'.join(row[:numColumn]) ))
                else:
                    print(" %s \\\\" % (' & '.join(row[:numColumn])))

                print("\\hline")

            print("\\end{longtable}")







if __name__=="__main__":
    parser = argparse.ArgumentParser(
        description="""Csv to latex table converter.  """)
    parser.add_argument('-i', dest='inputFile', default="convertcsv.csv",
                        help="Csv file to read, default=convertcsv.csv")
    parser.add_argument('-d', dest='delimiter', default=",",
                        help="Set csv delimiter, default=,")
    parser.add_argument('-q', dest='quotechar', default='"', 
                        help='Set csv quotechar, default="')    
    parser.add_argument('-pos', dest='tablePos', default="ht",
                        help="Set table position, default=h")
    parser.add_argument('--first_col_bold',
                        help="Add bold to first column'")
    parser.add_argument('--first_row_bold',
                        help="Add bold to first row'")
    parser.add_argument('-width1', dest='width1', default="7",
                        help="Width of the first column")
    parser.add_argument('-width2', dest='width2', default="7",
                        help="Width of the second column")
    parser.add_argument('--longtable', dest='longTable', action='store_true',
                        help="Use longtable package") 
    parser.add_argument('--lessspacing', dest='lessSpacing', action='store_true',
                        help="Don't add '&&&\\\\' as spacings between entries")   
    

    args = parser.parse_args()

    c2lt = Csv2LatexTable(args.inputFile, args.delimiter, args.quotechar, args.tablePos, args.first_col_bold, args.first_row_bold, args.width1, args.width2, args.longTable, args.lessSpacing)
    c2lt.readCsvandMakeTable()