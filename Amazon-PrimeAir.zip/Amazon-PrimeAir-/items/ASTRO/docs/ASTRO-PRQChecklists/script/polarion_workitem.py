# PolarionWebServiceExample.py
import sys, os
import argparse
sys.path.append("../../../_docs-lib")
from Tools import acronyms
from Tools import polarionWebService
from Tools import workItemLib
from enum import Enum
from Tools import acronyms

HOSTNAME = os.environ['POLARION_HOST']

def get_diagram(WI_id):
    WI_id=WI_id.split('-')
    criteria = '(id:'+WI_id[0]+'\-'+WI_id[1]+')'
    fields = ['id','title','description','attachments.content']
    WI=workItemLib.get_work_items(polarionWebService.get_raw_work_items(tracker, criteria, fields, args.version), "Polarion-QUERY.txt")
    i=polarionWebService.get_diagram((WI[0].list_attachments[-1]).replace('localhost', HOSTNAME))
    i.save('../figures/wi_'+WI[0].id+'.png')

def make_tex(path, list, parse_description=True, is_diagram=False):
    file = open(path,"w")   
    tex = workItemLib.work_item_list(list).get_tex(parse_description, is_diagram)
    file.write(tex)
    file.close() 

def read_input_arguments():
    global args
    parser = argparse.ArgumentParser()
    parser.add_argument("version", help="Version to be parsed")
    parser.add_argument("rootDirectory", help="Root directory of repository. For example: c:\docs")
    parser.add_argument("-all", type=bool, default=False, help="Verified Filter")
    args = parser.parse_args()
    print("Version:%s" % args.version)
    print("all llrs:%s" % args.all)
    
if __name__=="__main__":    
    read_input_arguments()
    acronyms.make_acronym_dictionary("../../../_docs-lib/Texts/abbreviations.tex")
    tracker = polarionWebService.init_session()
    
    verified_filter = ""
    if args.all == False:
        verified_filter = ' AND (status:verified)'
    

    criteria = '(type:productrequirement) AND linkedWorkItems:(VER-4014)'
    fields = ['id','title','description','customFields.derived','customFields.rationale', 'status']
    make_tex("../PR.tex", workItemLib.get_work_items(polarionWebService.get_raw_work_items(tracker, criteria, fields, args.version), "Polarion-QUERY-PR.txt"))          
    
    criteria = '(type:hlrequirement)' + verified_filter + 'AND linkedWorkItems:(VER-4014)'
    fields = ['id','title','description','customFields.derived','customFields.rationale', 'status']
    make_tex("../HLR.tex", workItemLib.get_work_items(polarionWebService.get_raw_work_items(tracker, criteria, fields, args.version), "Polarion-QUERY-HL.txt"))          
    
    criteria = '(type:llrequirement)' + verified_filter + '  AND linkedWorkItems:(VER-4014)'
    fields = ['id','title','description','customFields.derived','customFields.rationale', 'status']  
    make_tex("../LLR.tex", workItemLib.get_work_items(polarionWebService.get_raw_work_items(tracker, criteria, fields, args.version), "Polarion-QUERY-LLR.txt")) 
    
    criteria = '(type:algorithm) ' + verified_filter + ' AND linkedWorkItems:(VER-4014)'
    fields = ['id','title','description','customFields.derived','customFields.rationale', 'status']
    make_tex("../SW_Algorithms.tex",workItemLib.get_work_items(polarionWebService.get_raw_work_items(tracker, criteria, fields, args.version), "Polarion-QUERY-Algorithms.txt"), False)   
    
    criteria = '(type:pdireq) ' + ' AND linkedWorkItems:(VER-4014)'
    fields = ['id','title','description','customFields.derived','customFields.rationale', 'status']
    make_tex("../PDIR.tex",workItemLib.get_work_items(polarionWebService.get_raw_work_items(tracker, criteria, fields, args.version), "Polarion-QUERY-PDIR.txt"))   
    
    criteria = '(type:diagram) AND linkedWorkItems:(VER-4014)'
    fields = ['id','title','description','attachments.content','customFields.rationale']
    Wi = workItemLib.get_work_items(polarionWebService.get_raw_work_items(tracker, criteria, fields, args.version), "Polarion-QUERY-Diagrams.txt")
    for i in Wi:
        diagram = polarionWebService.get_diagram((i.list_attachments[-1]).replace('localhost', HOSTNAME))
        diagram.save('../figures/wi_'+i.id+'.png')
    make_tex("../SW_Diagrams.tex", Wi, False, True)
                
    figures=['VER-4057', 'VER-4056']
    for fig in figures:
        get_diagram(fig)