# PolarionWebServiceExample.py
import sys, os, re
from suds.client import Client
import sys
sys.path.append("../../../_docs-lib/")
from Tools import polarionWebService
from Tools import parseTexLib
from Tools import acronyms
import argparse


def build_item(id, title , data):
    item = "\\begin{itemize}\n"
    item += "    \\item [\\textbf{" + id + "}] " + parseTexLib.parse_special_chars(title) + "\n"
    item += "    \\begin{itemize}\n"
    for key,value in data.items():
        item += "        \\item [\\textit{ " + key + " }] " + acronyms.parse_acronyms(parseTexLib.parse_html_chars(parseTexLib.parse_chars(value)))+ "\n"
    item += "    \\end{itemize}\n"
    item += "\\end{itemize}\n\n"
    return item


def PolarionWebServiceExample(file,query,fields,version):
    acronyms.make_acronym_dictionary("../../../_docs-lib/Texts/abbreviations.tex")
    tracker = polarionWebService.init_session()
    queriedWIs = polarionWebService.get_raw_work_items(tracker,query,fields,version,orden="id")

    file=open(file,"w")
    if queriedWIs:

        for Wi in queriedWIs:
            print("¨"+Wi.id+" "+Wi.title+"\n")
            dic = {}
            key = ""
            value = ""
            desc = str(Wi[2][1]).replace("<pre>", "").replace("</pre>", "").replace("<br/>", "\n")
            desc = re.sub(r'<.*?>', "", parseTexLib.parse_html_chars(desc))
            for line in desc.splitlines():
                if "##" in line:
                    value = ""
                    key = line.replace("##","")
                    dic[key] = value
                else:
                    if not line.isspace() and not line.strip() == '':
                        value += line + r" \\"
                        dic[key] = value

            file.write(build_item(Wi.id, Wi.title, dic).replace(u"\u202c", "").replace(u"\u202d", ""))

        print(len(queriedWIs))
        #print(Wi.id+" "+Wi.title)

    
if __name__=="__main__":

    parser = argparse.ArgumentParser(description='Process some integers.')
    parser.add_argument("version", help="Version to be parsed")
    args = parser.parse_args()
    fields = ['id', 'title', 'description', 'customFields.testid', 'customFields.testType', 'customFields.testSteps']
    for key in ["unit","system","integration","robustness", "analysis"]:
        PolarionWebServiceExample("test-description-" + key + ".tex",
                                  'linkedWorkItems:(VER-4014) AND (type:testcase) AND (status:verified) AND (testType.KEY:' + key + ')',
                                  fields, args.version)
        
