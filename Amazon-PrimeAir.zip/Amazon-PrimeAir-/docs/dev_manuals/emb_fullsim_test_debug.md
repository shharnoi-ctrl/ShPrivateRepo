# FULLSIM test debug

## Prerequisites
- You have SSH access to an Amazon Cloud Desktop.
- You set up SSH credential to access Embention’s Git Hub repositories (Amazon-PrimeAir , Vlibs , sw_Veronte). 
- You have the adn-flights cli installed on your Cloud Desktop (you can test it with (adn-flights -h). 
- If you don't, read [set up prerequisites](./emb_setup_prerequisites.md).

## How to run Emb code in FullSim
1. Create a brazil workspace and checkout the `AdnFullSimMonitorRecoveryTestFiles` package:
```bash
brazil ws create --root emb_fullsim_ws --vs AdnCX3GNCControls/block20-build-emb
cd emb_fullsim_ws
root=$PWD
brazil ws use -p AdnFullSimMonitorRecoveryTestFiles --latest
```

2. Checkout the following packages:
```bash
brazil ws use -p AdnEmbRecoverySource --latest
brazil ws use -p AdnVehicleControllersAlgorithms --latest
brazil ws use -p AdnVehicleRecoveryWrapperAlgorithms --latest
brazil ws use -p AdnVehicleMonitorWrapperAlgorithms --latest
```

3. Build `AdnEmbRecoverySource` package with the desired feature branch:
```bash
cd $root/src/AdnEmbRecoverySource
brazil-build -b <feature branch>
```

4. Build the rest of the packages:
```bash
cd $root/src/AdnVehicleControllersAlgorithms && brazil-build
cd $root/src/AdnVehicleRecoveryWrapperAlgorithms && brazil-build
cd $root/src/AdnVehicleMonitorWrapperAlgorithms && brazil-build
cd $root/src/AdnFullSimMonitorRecoveryTestFiles && brazil-build
```

5. Make changes to EMB code in `AdnEmbRecoverySource` package at `git-hub/Amazon-PrimeAir` folder.
6. Rebuild using local build to prevent overwriting the manual code changes:
```bash
bb local
```
7. Finally, you can run a FullSim test as follows:
```bash
cd $root/src/AdnFullSimMonitorRecoveryTestFiles && brazil-test-exec ipytest
ipytest simulations/<path-to-your-test-file>.py::<name-of-your-test-case>
```

### Test examples:
```bash
brazil-test-exec ipytest
ipytest simulations/regression/test_cx3_recovery_switchover.py::test_cx3_recovery_switchover[20.0-id_10_1_hybrid_a_b_gps_land-PRIME_AIR-1-FullSimCX3_H-9.dv_knobs] --should-run-generate-parquet-plots=always --where-to-run-generate-parquet-plots=foreground
```

```bash
cd $root/src/AdnFullSimMonitorRecoveryTestFiles
./bin/run_merge_tests.sh --fullsim-test-only
```


## Tips
- To print logs on the terminal when running a specific *Hillsim* test, you can use `Emb_log.h`. To enable it you shall set `DEBUG_MODE` to `true` [here](https://github.com/embention/Amazon-PrimeAir/blob/51e23515ba9802b4ea6efdaeeb2f08165afb590d/items/ASTRO/items/sw/sw_Astro/code/pa_blocks/code/include/Emb_log.h#L8).


- Auto-complete with <tab> works pretty well when selecting a test file / test case. 
- You can add extra flags to the *ipytest* command to generate specific plots to better interpret the results of the test.
```cpp
// To generate recovery plots:
--should-run-generate-recovery-parquet-plots=always --where-to-run-generate-recovery-parquet-plots=foreground 
// To generate monitor plots:
--should-run-generate-monitor-parquet-plots=always --where-to-run-generate-recovery-parquet-plots=foreground
// To generate all plots:
--should-run-generate-parquet-plots=always --where-to-run-generate-parquet-plots=foreground
```
- Note that the test case within the test file should have the desired *EMB SIL* enabled. In the following example, Rec Nav serialized FullSim Wrapper and the Rec Controls serialized FullSim Wrapper are enabled, it is used the Hardcoded Mission with ID 1.
```python
# Set embention knobs.
override_knobs(
    {
        "adn.vehicle.recovery.control.use_embention_hardcoded_mission": True,
        "adn.vehicle.recovery.control.emb_hardcoded_mission_id": 1,
        "adn.vehicle.recovery.control.use_embention_recovery_wrapper": False,
        "adn.vehicle.recovery.control.use_embention_fullsim_wrapper_serialized": True,
        "adn.vehicle.recovery.navigation.use_embention_fullsim_wrapper_serialized": True,
    }
)
```

## VSCode debug
When running a test, you can debug *EMB* code using the debug mode of *VSCode*. 
1. Enable debug in *VSCode*.

![](./files/debug_1.png)

2. Modify the debug file `launch.json` with

```json
{
    // Use IntelliSense to learn about possible attributes.
    // Hover to view descriptions of existing attributes.
    // For more information, visit: https://go.microsoft.com/fwlink/?linkid=830387
    "version": "0.2.0",
    "configurations": [
        {
            "name": "(gdb) Attach",
            "type": "cppdbg",
            "request": "attach",
            "program": "/lib64/ld-linux-x86-64.so.2",
            "MIMode": "gdb",
            "setupCommands": [
                {
                    "description": "Enable pretty-printing for gdb",
                    "text": "-enable-pretty-printing",
                    "ignoreFailures": true
                },
                {
                    "description": "Set Disassembly Flavor to Intel",
                    "text": "-gdb-set disassembly-flavor intel",
                    "ignoreFailures": true
                }
            ]
        },
    ]
}
```

3. In `brazil-test-exec ipytest` run:
```python
import os
os.get_pid()
```

![](./files/debug_2.png)

4. Attach the *console ID* to the debugger.

![](./files/debug_3.png)

5. Finally run the desired test. You can add breakpoints at any part of *EMB* code to debug.