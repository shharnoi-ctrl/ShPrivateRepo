# Oasis brief introduction - Tips and tricks

## Reserve Resources
In Oasis it is possible to reserve a certain resource for a certain amount of time. In resources it’s possible to see the status and the disponibility of all the simulation hardwares:

![](./files/oasis_resources.png)

It will be possible to reserve a HILsim that is "*Available*" and not reserved. In this case for example `hilsim-107` is not reserved but it is not available "*Occupied*", while `hilsim-109` is available but reserved (user `alesqbol`). Instead, `hilsim-106` can be reserved. Therefore, by selecting it, and clicking in "**Actions**" -> "**Reserve**", you will be able to select the time window for the reservation.

![](./files/oasis_reserve.png)

It is good practice to release HILSim when no longer used. In addition, if you want to run a job in a specific Hilsim, remember to choose it before running a job.

![](./files/oasis_run_reserved.png)

## Cloning and modifying jobs
It is possible to clone and modify by selecting a previous job clicking in "**Clone job**" (upper-right).

![](./files/oasis_clone_job.png)

It is also possible to introduce modifications, as change bundle to be deployed, test to be run, etc, by modifying the information reported in the blue box:

![](./files/oasis_clone_job_modification.png)

## Re-run without deploying
Since deploying a bundle requires time, it’s possible to run a flight without deploying if the bundle already deployed and the configuration loaded in Astro is the correct one. In order to be sure to re-perform the correct test executed immediately after the deploy it’s possible to clone just the execute flight.

![](./files/oasis_rerun.png)

In fact by clicking in the logs of "**Block20CollectAndRunFlights**" -> "**RunFlight**" and then pressing in "**Clone Current Job**", it will be possible to re-run the flight saving time.

If some changes in the configuration are needed it will be necessary to deploy another bundle or to modify manually the firmware and/or the PDI of the EMB computes (Monitor, Recovery 0 and Recovery 1).

## Switching between menu
By pressing the gear settings in the upper right it will be possible to switch the menu inside Oasis.

![](./files/oasis_menu.png)

As an example HILSim resources will be visible in `Blk20HilsimDev`, while the bundle generation in `SoftwareSigning`

## Filtering jobs by Resources or Requester ID 
When looking for a certain job it could be helpful to filter the research by imposing a certain resource or requester ID. It is important to press Apply to set the filter. For instance:
- Resource ID: hilsim-109
- Requester: alesqbol

![](./files/oasis_search.png)




