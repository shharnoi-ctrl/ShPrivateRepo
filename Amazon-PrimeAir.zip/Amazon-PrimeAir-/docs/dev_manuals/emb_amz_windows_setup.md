# Amazon Windows Laptop Setup
Amazon windows laptop is needed to access *PA* environment and develop/test *PA-EMB* code. Developers usually need to test new *PA* features, change *EMB* code and compile different `brazil` workspaces. This work is normally done with *VS Code* through the [Cloud Desktop](./emb_cloud_desktop_setup.md).

## Windows authentication
Windows authentication is needed for ssh connection with the Cloud desktop. It shall be done following these steps:
1. Install `wssh` from [this page](https://w.amazon.com/bin/view/WSSH/).
2. Generate *RSA* keys: `ssh-keygen -t rsa` (Press enter at each field to select the default configuration).
3. Generate *ECDSA* keys: `ssh-keygen -t ecdsa` (Press enter at each field to select the default configuration).
4. Refer to this [PDF](./docs/VS%20Code%20for%20ContainerBuild.pdf) to properly configure *VSCode*. You can skip the *install Private Extensions on Cloud desktop* section, these tools are rarely needed as *EMB* does not develop *PA* code.
5. Run the command `mwinit && mwinit -k C:\Users\<user>/.ssh/id_ecdsa.pub` to sign up new sessions at *VSCode*.

Sometimes, the connection to VSCode fails because VSCode server is disconfigured. Then, open a terminal at the cloud desktop from a web browser, remove the configuration by `rm -r ~/.vscode-server`, and try the connection again. Contact Joe Rutland (@jrrutlan) for any problem related to Cloud Desktop/VSCode.

## Tmux tool
In Fullsim, a terminal shall be open until the end of the test and it usually takes a long time. If the terminal is closed due to internet connection issues, the Fullsim test will no longer run. `Tmux` is a linux tool used to create terminal sessions that keep a terminal open until a specific session is killed. You can find how to use `Tmux` in [Tmux cheat sheet](https://tmuxcheatsheet.com/). 

Furthermore, `Tmux` allows the user to see all the history and logs but it has a limit that can be modified as follows:
```bash
echo 'set-option -g history-limit 10000' >> ~/.tmux.conf
tmux source-file ~/.tmux.conf
```
In addition, the terminal history can be added to a file running this command inside a `Tmux` session:
```bash
tmux capture-pane -pS -50000 > output.txt
```

Additional useful commands are shown hereafter:
- Scroll: `Ctrl`+`b`, then `[`. Then you can use your normal navigation keys. Press `q` to quit scroll mode.
