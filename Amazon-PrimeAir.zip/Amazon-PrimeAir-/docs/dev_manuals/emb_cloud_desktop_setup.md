# Setup Amazon Cloud Desktop
An AMZN Cloud Dev Desktop is required to create `brazil` workspaces for a developer to use *PA* packaged necessary for FullSim and Hilsim  tests. To start, go to https://builderhub.corp.amazon.com/app.html#/cloud-desktop/users/<amz_username> (replace "<amz_username>" with your Amazon username), then follow these steps:

1. In the upper-right corner select the "Create" drop down menu.
2. Then select the option for "Create my cloud dev desktop" under "For myself".
3. For Host type select "m7i.24xlarge". See [here](https://aws.amazon.com/ec2/instance-types/) for more information about the available AWS cloud desktops.
4. For the Fleet select "ADN Systems Engineering"
5. Leave all other options as the default.
6. Click `Create my Cloud Desktop`. The Cloud Desktop creation will last 40-60 minutes.
7. After Cloud Desktop creation, follow https://builderhub.corp.amazon.com/docs/brazil/cli-guide/setup-clouddesk.html steps to setup `BrazilCLI` tools.
8. Install `adn-panda-tools` toolbox:
```bash
toolbox registry add 's3://buildertoolbox-registry-adn-panda-tools-us-west-2/tools.json'
toolbox install adn-panda-tools
```
9. Install `adn-fullsim-tools` toolbox:
```bash
toolbox registry add 's3://buildertoolbox-registry-adn-fullsim-tools-us-west-2/tools.json'
toolbox install adn-fullsim-tools --channel cx3
```
10. Install `adn-simulation-tools` toolbox:
```bash
toolbox registry add 's3://buildertoolbox-registry-adn-simulation-tools-us-west-2/tools.json'
toolbox install adn-simulation-tools
```
11. (Optional) To add a GUI to your Cloud Desktop, see [this link](https://docs.hub.amazon.dev/dev-setup/clouddesktop-optional-gui-dcv/).


## Set Up Access to PA/EMB
The Cloud Desktop needs access to *PA* and *EMB* code using pair of `public-private` keygen, follow these steps to set it up correctly:
1. Log in into your Cloud desktop.
2. Generate *RSA* keys: `ssh-keygen -t rsa` (Press enter at each field to select the default configuration).
3. Generate *ECDSA* keys: `ssh-keygen -t ecdsa` (Press enter at each field to select the default configuration).
4. Find out what your *RSA* ssh public key is by typing the command `cat ~/.ssh/id_rsa.pub`.
5. Copy the entire output of the `cat` command and add it to your SSH keys at your *EMB* github account. Watch [this video](./files/Adding_SSH_pub_ky_to_git_hub.webm) with the instructions on how to do it.
6. Run the command `mwinit -o` to sign up new sessions.

If you encounter authentication issues, please refer to [this page](https://docs.hub.amazon.dev/gitfarm/user-guide/troubleshooting-auth/).

