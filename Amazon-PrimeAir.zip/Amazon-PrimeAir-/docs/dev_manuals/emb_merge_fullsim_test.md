# Merge FULLSIM Test
Before any merge to `feature/Amazon-PrimeAir/integration` or `feature/Amazon-PrimeAir/9388_pa_mk30` branches, a Fullsim test shall be run. Follow the commands below to run it (modify 'my_feature_branch' to the branch you want to test):
```cmd
brazil ws create --root pr_testing_ws_incremental -vs AdnCX3GNCControls/block20-build-emb
cd pr_testing_ws_incremental
brazil ws use -p AdnFullSimMonitorRecoveryTestFiles --latest 
./src/AdnFullSimMonitorRecoveryTestFiles/bin/run_merge_tests.sh my_feature_branch
```

Don't forget to paste the Fullsim test result as a comment in the pull request associated. 

More information can be found [here](https://quip-amazon.com/KVaYAtDzWD5W/FullSim-Testing-Prior-To-PR-Merges).

## Run failing test
When running *merge FULLSIM test*, many tests are run and one or more could fail.

![](./files/merge_fullsim_test_fail.png)

Then, you can rerun a specific test executing the following command lines:

```cmd
cd src/AdnFullSimMonitorRecoveryTestFiles
brazil-test-exec ipytest
ipytest simulations/release/test_cx3_tam_fault_injection_embention_wrapper.py::test_cx3_tam_fault_injection_hybrid_embention_wrapper[EMBENTION_FWSIM-bc06bf3e-c10a-473a-9b19-96731efdfed7-FullSimCX3_H-9.dv_knobs] --use-beta-converter --should-run-generate-recovery-parquet-plots=always --should-run-generate-controls-parquet-plots=always --where-to-run-generate-recovery-parquet-plots=foreground 
```

All the available tests are in folder `src/AdnFullSimMonitorRecoveryTestFiles/simulation/`. Change `simulations/release/test_cx3_tam_fault_injection_embention_wrapper.py::test_cx3_tam_fault_injection_hybrid_embention_wrapper[EMBENTION_FWSIM-bc06bf3e-c10a-473a-9b19-96731efdfed7-FullSimCX3_H-9.dv_knobs]` with the test you want to rerun, use *tab* to autocomplete the test path and features.