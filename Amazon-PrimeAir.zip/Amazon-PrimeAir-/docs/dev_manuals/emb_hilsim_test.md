# Hilsim Test
> Check the latest Hilsim manual version [here](https://code.amazon.com/packages/AdnEmbToPaUtilities/blobs/mainline/--/HILSIM_README.md#) or [here](https://quip-amazon.com/P7vLAUwJ7r1U/EMB-Release-Testing-with-IBHilsim)

## Prerequisites
These instructions have only been validated on AL2 cloud machines.

1. Make sure you have run mwinit.
2. Make sure you have the Oasis CLI installed. If you don't it can be installed via:
    ```bash
    toolbox registry add 's3://buildertoolbox-registry-adn-simulation-tools-us-west-2/tools.json'
    toolbox install adn-simulation-tools
    toolbox update adn-simulation-tools
    ```

3. If you have `adn-fcm-tools` installed, you will need to remove this deprecated toolchain using:
    ```
    toolbox uninstall adn-fcm-tools
    toolbox clean
    ```

4. (Recommended, but not strictly required) Reserve a Block 20 Hilsim [here](https://oasis.primeair.amazon.dev/rc/Blk20HilsimDev/resources).

    1. Using the right radio button, select a Hilsim that does not have a `User` assigned to it.
    2. Under `Actions`, select `Reservations > Reserve`.
    3. You can now send oasis jobs to the reserved Hilsim.

## Step 0 - Workspace Setup

1. Create a new "source" workspace that tracks the GNC team's Embention version set.
    ```bash
    root=$PWD
    brazil ws create --name ws-emb-src -vs AdnCX3GNCControls/block20-build-emb
    ```

2. Create a new "build" workspace that tracks the version set with the tests you want to run. The most robust choice is Block20 PIE:
    ```bash
    brazil ws create --name ws-emb-build -vs AdnCX3/principal-block20-env
    ```

## Step 1 - Modify Embention Code

1. In the `ws-emb-src` workspace, checkout the Embention code and the `AdnEmbToPaUtilities` package:
    ```bash
    cd $root/ws-emb-src
    brazil ws use -p AdnEmbRecoverySource --latest
    brazil ws use -p AdnEmbToPaUtilities
    ```
    Note that `AdnEmbToPaUtilities` is not currently in common version sets, thus `--latest` is omitted.

2. Build the `AdnEmbToPaUtilities` package. This will generate binaries that will be used in Step 4.
    ```bash
    cd src/AdnEmbToPaUtilities && brazil-build
    ```

3. Pull and build the Embention code:
    ```bash
    cd src/AdnEmbRecoverySource && brazil-build
    ```
    This will take ~13 minutes. If you want to build a specific remote branch, you can use `brazil-build -b <remote-branch>`. By default, this command will checkout and build the `feature/Amazon-PrimeAir/integration` branch.

4. Make the code changes that you want to test.

5. Run a `bb release`. This takes roughly 13 minutes to complete. Once successful, the on-target artifacts have been generated successfully, proceed to Step 2.

## Step 2 - Generating a Test Bundle
If you do not need to modify any FullSim packages (e.g., AdnFullSim*TestFiles, AdnFullSimGisMissions, etc), skip ahead to Step 3.

1. In the `ws-emb-build` workspace, pull in the `Adn*TestFiles` package that you want to modify, along with any supporting packages (e.g., AdnFullSimGisMissions).

2. Make the required modifications.

3. From the `Adn*TestFiles` package, run `bb bundle --dryrun`. This should take 5-6 minutes.

4. Once complete, you will see a `local-<uuid>` string appear at the bottom. For example `local-86bf2fe9eeca4387a835901caf26117b`. **Save this value for later.**

## Step 3 - Create Dryrun from Local Embention Artifacts
Next, we will generate a dryrun from the locally generated Embention artifacts.

1. Navigate to the `AdnEmbToPaUtilities` package in the `ws-emb-src` workspace and , and run:
    ```bash
    cd $root/ws-emb-src/src/AdnEmbToPaUtilities
    chmod +x bin/generate_dryrun_from_packaged_emb_artifacts.sh
    ./bin/generate_dryrun_from_packaged_emb_artifacts.sh -e $root/ws-emb-src -d $root/ws-emb-build
    ```
    This will copy all of the packaged on-target artifacts into the `ws-emb-build` workspace, commit them, and create a dryrun build. Note that the resulting dryrun will only include any local Embention code changes. If you want to include other code changes (e.g. Primary lane code changes, Fullsim changes, etc),
    run the script with the `--no-dryrun` option, and create the dryrun manually once the script has completed:
    ```bash
    ./bin/generate_dryrun_from_packaged_emb_artifacts.sh -e $root/ws-emb-src -d $root/ws-emb-build --no-dryrun
    cd $root/ws-emb-build
    brazil ws dryrun
    ```

3. The dryrun takes roughly 60 minutes to complete. On successful completion, proceed to Step 4.

## Step 4 - Manifest Machine and Bundle Generation

1. Navigate to the root of the `AdnEmbToPaUtilities` package in the `ws-emb-src` workspace, and run:
    ```bash
    cd $root/ws-emb-src/src/AdnEmbToPaUtilities/
    chmod +x bin/generate_bundle_from_dryrun.sh
    ./bin/generate_bundle_from_dryrun.sh -b <dryrun_build_request_id>
    ```
    You should see an output similar to the one below after around 5 minutes. This means that an Oasis bundling (aka signing) job was kicked off.

    **Save the `Bundle ID` for use in Step 5.**
    ```
    2025/03/21 23:26:39 Oasis Signing Job ID:    189468b3-ca1b-4c56-91d1-8f6b51238215
    2025/03/21 23:26:39 Oasis Signing Job Link:  https://prod-na.oasis.primeair.amazon.dev/rc/SoftwareSigning/jobs/189468b3-ca1b-4c56-91d1-8f6b51238215
    2025/03/21 23:26:39 Bundle ID:               dhentzen-70cb12a5-ef29-4774-8829-a5256288e51c
    ```

    The signing job should take 20-25 minutes to complete. Upon successful completion, you will get a Slack notification from ChirpBot similar to the one below.
    ```
    Your job 412A9E7316E1 in the Oasis SoftwareSigning resource collection has finished with result: SUCCESS
    ```
2. Alternatively, you can find the Bundle ID as follows:

    1. Open the Oasis Signing Job Link displayed in the terminal.
    2. At the Oasis link, go to `Logs`.
    3. In the `GenerateInstallBundleTypeJob` row, click on `Job Logs`.
    4. In the `GenerateBundle` row, click `Logs`.
    5. Scroll all the way down. The very last line should say `Finished creating bundle <bundle-guid>`, and you should see a few s3 links above this that indicate where certain artifacts are. Copy the `bundle-guid` and proceed to Step 5.

## Step 5 - Run the HilSim
The easiest way to do this is by cloning an existing job -- alternatively you can create a new "Block 20 Fly Job".

1. If cloning an existing job, open the Oasis link and click on `Clone Root Job` in the top right.

    1. Under `Where should the job run?`, select the Hilsim you reserved (e.g. `hilsim-109`).

    2. In the `Configuration` pane, replace `#@ installerBundleVersion = 'bundle-id'` where `bundle-id` is the Bundle ID saved in Step 4.

    3. If you modified any Fullsim packages in Step 2, replace `#@ testPackageVersion = 'local-uuid'` where `local-uuid` is from Step 2.4.

    4. Other noteworthy entries:
        1. `testIterations` is the number of times the tests are repeated.
        2. `knobsAndTestCommands` defines the knob set and pytest that will be run.

    5. Click `Submit Job` once everything has been defined.

2. If creating a new Block 20 Fly Job, [this document](./docs/HILSim_testing_guide.pdf) is the official resource. Check [Notes](#notes) to see available flight knobs and test commands. 

3. If you want to run another test with the same software bundle, but different knobs and/or test command, you can clone the `CollectAndRunFlights` sub job of the `Fly` job, make the update and submit the job. This will avoid re-deploying the same bundle again.
    * This assumes you have the hilsim reserved and did not send the job to the pool


## Notes: Embention telemetry
The PA team together with EMB team developed a tool to directly get EMB telemetry plots on a HILSIM flight. However it could fail due to a mismatch between the expected telemetry configuration and the bundle configuration. This mismatch can be avoided with a correct configuration in the Oasis SofwareSigning Job, adding the desired dryrun at these two parameters:
```
#@ ANALYSIS_MK30_BLK20_ALL_EMBENTION_CONFIG_version = 'dryrun_xyz'
#@ ANALYSIS_MK30_BLK20_ALL_VSDK_PLATFORM_CONFIG_version = 'dryrun_xyz'
```
If you create the oasis job manually, don't forget to update those paremeters. However, if you follow that guide to do that, these parameters are empty so the telemetry expected is `Last-Known-Good`. If you don't modify EMB telemetry configuration on the dryrun you used, you probably will obtain the EMB telemetry plots.

However, if you want to be 100% sure that the telemetry will show up, follow these steps:
Execute the step 4-1 to create a Oasis SoftwareSigning Job.
1. Clone that job.
2. Change these parameters accordingly:
```
#@ ANALYSIS_MK30_BLK20_ALL_EMBENTION_CONFIG_version = 'dryrun_xyz'
#@ ANALYSIS_MK30_BLK20_ALL_VSDK_PLATFORM_CONFIG_version = 'dryrun_xyz'
```
3. Modify the installer bundle path:
```
#@ installerBundleS3Path = 'InstallerBundle/bertomes-dryrun_xyz'
```
4. Submit job.
5. When the job is finished, you will be able to used the Bundle ID generated with that job, i.e. what you put in the installer bundle path (`bertomes-dryrun_xyz`)

## Notes

* If you run into any issues with this script, reach out in the `#primeair-gnc-hilsim-helpline` slack channel, or contact the [Hilsim oncall](https://oncall.corp.amazon.com/#/view/primeair-hips/schedule).

* In general Hilsims do not support IPCs and will likely be used for Monitor and Recovery testing only. Although this is generally true there are "ITV" Hilsims that have IPCs connected, but they can only be run on site in `SEA109` as they have IPCs + real motors and props. Hilsim flight test are found in [Blk20HilsimDevOasis resource collection](https://oasis.primeair.amazon.dev/rc/Blk20HilsimDev/resources).

* The most common test used by EMBENTION team is:
```
#@ knobsPath = hilsim/H-9
#@ testCommand = simulations/regression/test_blk20_outdoor_flights.py::test_hybrid_missions[Cx3IntegrationHilsimRuntime-recovery_switchover_hybrid]
```