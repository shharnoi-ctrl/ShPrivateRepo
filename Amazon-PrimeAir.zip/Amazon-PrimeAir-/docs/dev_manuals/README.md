# How to Run FULLSIM - HILSIM from Embention
1. [Cloud desktop configuration](./emb_cloud_desktop_setup.md)
2. [AMZ Windows configuration](./emb_amz_windows_setup.md)
3. [Fullsim test debug](./emb_fullsim_test_debug.md)
4. [Merge Fullsim test](./emb_merge_fullsim_test.md)
5. [Hilsim test](./emb_hilsim_test.md)
6. [Oasis Brief Introduction](./emb_oasis_brief_intro.md)
7. [Post Flight Analysis](./emb_post_flight_analysis.md)